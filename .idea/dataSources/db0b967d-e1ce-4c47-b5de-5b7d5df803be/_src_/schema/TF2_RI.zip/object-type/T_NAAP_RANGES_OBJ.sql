CREATE TYPE          "T_NAAP_RANGES_OBJ"                                          AS OBJECT(
  MSISDN_START        VARCHAR2(30),
  MSISDN_END          VARCHAR2(30),
  IMSI_START          VARCHAR2(20),
  IMSI_END            VARCHAR2(20)
)
/
