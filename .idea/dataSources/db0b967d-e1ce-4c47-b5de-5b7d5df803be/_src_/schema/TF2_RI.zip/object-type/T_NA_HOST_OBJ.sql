CREATE TYPE          "T_NA_HOST_OBJ"                                          AS OBJECT (NETWORK_OPERATOR_ID NUMBER, MSC_HOST_CODE VARCHAR2(15))
/
