CREATE type OT_INTERVAL is object
(
  interval_id number,
  date_from date,
  date_to date,
  str1 nvarchar2(50),
  num1 number
)
/
