CREATE TYPE          "T_BSC_LAC_MSC_OBJ"                                          AS OBJECT (BASE_STATION_CODE    VARCHAR2(10), 
                                                                          LOCATION_AREA_CODE   VARCHAR2(10),
                                                                          MSC_CODE             VARCHAR2(30))
/
