CREATE TYPE          "T_NAAP_RANGES_TAB"                                          AS TABLE OF T_NAAP_RANGES_OBJ
/
