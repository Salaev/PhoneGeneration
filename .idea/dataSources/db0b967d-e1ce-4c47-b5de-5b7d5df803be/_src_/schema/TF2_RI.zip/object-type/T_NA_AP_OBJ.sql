CREATE TYPE          "T_NA_AP_OBJ"                                          AS OBJECT (SN                      VARCHAR2(60), 
                                                                    INTERNATIONAL_FORMAT    VARCHAR2(30),
                                                                    EXCHANGE_PORT           VARCHAR2(40),
                                                                    VALIDITY_DATE           DATE)
/
