CREATE TYPE          "T_PHONE_RES_OBJ"                                          AS OBJECT (INTERNATIONAL_FORMAT VARCHAR2(30), result NUMBER)
/
