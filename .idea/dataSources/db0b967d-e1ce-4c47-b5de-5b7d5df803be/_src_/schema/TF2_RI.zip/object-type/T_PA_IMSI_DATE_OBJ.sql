CREATE TYPE          "T_PA_IMSI_DATE_OBJ"                                          AS
  OBJECT (PA          NUMBER(15),
          IMSI        VARCHAR2(20),
          datetime    DATE
         );
/
