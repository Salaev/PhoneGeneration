CREATE type CT_SYS_ITEM is table of OT_SYS_ITEM
/
