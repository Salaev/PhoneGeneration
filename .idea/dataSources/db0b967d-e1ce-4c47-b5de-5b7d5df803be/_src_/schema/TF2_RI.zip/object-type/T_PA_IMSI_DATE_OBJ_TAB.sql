CREATE TYPE          "T_PA_IMSI_DATE_OBJ_TAB"                                          AS TABLE OF t_PA_IMSI_DATE_obj;
/
