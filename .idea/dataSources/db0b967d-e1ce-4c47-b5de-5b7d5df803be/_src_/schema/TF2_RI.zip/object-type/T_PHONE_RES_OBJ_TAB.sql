CREATE TYPE          "T_PHONE_RES_OBJ_TAB"                                          AS TABLE OF T_PHONE_RES_OBJ
/
