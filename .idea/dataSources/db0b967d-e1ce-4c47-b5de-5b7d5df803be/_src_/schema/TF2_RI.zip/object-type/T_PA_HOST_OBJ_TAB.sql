CREATE TYPE          "T_PA_HOST_OBJ_TAB"                                          AS TABLE OF t_PA_HOST_obj;
/
