CREATE TYPE          "TABLE_OF_NUMBER"                                          IS TABLE OF NUMBER
/
