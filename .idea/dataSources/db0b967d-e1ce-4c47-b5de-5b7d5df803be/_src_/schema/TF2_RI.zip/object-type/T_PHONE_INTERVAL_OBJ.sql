CREATE TYPE          "T_PHONE_INTERVAL_OBJ"                                          IS OBJECT ( 
  start_number NUMBER,
  end_number NUMBER,
  port_type CHAR(2),
  port_count NUMBER,
  result  NUMBER
 )
/
