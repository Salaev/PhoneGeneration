CREATE type          SYS_PLSQL_CC9D9B0E_DUMMY_1 as table of number;
/
