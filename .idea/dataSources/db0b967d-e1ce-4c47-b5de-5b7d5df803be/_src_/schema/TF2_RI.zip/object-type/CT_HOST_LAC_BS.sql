CREATE type CT_HOST_LAC_BS is table of OT_HOST_LAC_BS
/
