CREATE type OT_RANGE is object
(
  val1 nvarchar2(50),
  val2 nvarchar2(50),
  num1 number,
  num2 number,
  num3 number,
  dat1 date,
  num4 number
)
/
