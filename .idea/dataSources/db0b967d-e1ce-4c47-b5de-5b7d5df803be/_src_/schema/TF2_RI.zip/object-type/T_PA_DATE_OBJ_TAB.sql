CREATE TYPE          "T_PA_DATE_OBJ_TAB"                                          AS TABLE OF T_PA_DATE_OBJ
/
