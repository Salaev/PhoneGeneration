CREATE TYPE          "T_PA_PHONE_DATE_OBJ_TAB"                                          AS TABLE OF t_PA_Phone_DATE_obj;
/
