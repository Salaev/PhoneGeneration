CREATE TYPE          "T_V2_60_OBJ_TAB"                                          as table of t_v2_60_obj;
/
