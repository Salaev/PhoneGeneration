CREATE TYPE          "T_V2_60_OBJ"                                          as object (v2_60 varchar2(60));
/
