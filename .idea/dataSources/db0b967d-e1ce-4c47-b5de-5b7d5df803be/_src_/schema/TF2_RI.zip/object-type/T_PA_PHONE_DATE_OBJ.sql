CREATE TYPE          "T_PA_PHONE_DATE_OBJ"                                          AS
  OBJECT (PA          NUMBER(15),
          phone       VARCHAR2(30),
          datetime    DATE
         );
/
