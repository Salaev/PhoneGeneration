CREATE TYPE          "t_imsi_obj_tab"                                          as table of "t_imsi_obj"
/
