CREATE TYPE          "T_NET_OP_INF_OBJ"                                          AS OBJECT (HOME_NETWORK_OPERATOR_ID NUMBER,
                                                                         BASE_STATION_CODE        VARCHAR2(10),
                                                                         LOCATION_AREA_CODE       VARCHAR2(10),
                                                                         MSC_CODE                 VARCHAR2(30),
                                                                         VALIDITY_DATE            DATE,
                                                                         ROW_NUMBER               NUMBER)
/
