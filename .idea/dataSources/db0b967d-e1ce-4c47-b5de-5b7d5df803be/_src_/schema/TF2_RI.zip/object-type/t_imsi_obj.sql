CREATE TYPE          "t_imsi_obj"                                          AS OBJECT(imsi varchar2(20))
/
