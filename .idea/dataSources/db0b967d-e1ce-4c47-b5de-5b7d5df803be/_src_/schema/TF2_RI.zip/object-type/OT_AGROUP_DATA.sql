CREATE type OT_AGROUP_DATA is object
(
  agroup_data_id number,
  agroup_id number,
  id1 number,
  id2 number,
  date_from date,
  date_to date,
  user_id number,
  change_date date,
  dsc varchar2(4000),
  date1 date,
  num3 number,
  str2 varchar2(4000)
)
/
