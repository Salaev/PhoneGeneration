CREATE type t_str_concat_impl as object
(
  str clob, -- highest value seen so far
  static function ODCIAggregateInitialize(sctx in out t_str_concat_impl) return number,
  member function ODCIAggregateIterate(self in out t_str_concat_impl, value in clob) return number,
  member function ODCIAggregateTerminate(self in t_str_concat_impl, returnvalue out clob, flags in number) return number,
  member function ODCIAggregateMerge(self in out t_str_concat_impl, ctx2 in t_str_concat_impl) return number
);
/
