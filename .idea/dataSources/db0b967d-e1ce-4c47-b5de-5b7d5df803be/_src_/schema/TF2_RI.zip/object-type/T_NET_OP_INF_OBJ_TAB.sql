CREATE TYPE          "T_NET_OP_INF_OBJ_TAB"                                          AS TABLE OF T_NET_OP_INF_OBJ
/
