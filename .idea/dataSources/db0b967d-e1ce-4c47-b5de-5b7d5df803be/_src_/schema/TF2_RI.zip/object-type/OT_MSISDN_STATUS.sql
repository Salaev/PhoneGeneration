CREATE type OT_MSISDN_STATUS is object
(
  imsi varchar2(50),
  msisdn varchar2(50),
  balance_storage number,
  storage_type varchar2(50),
  uprs_member_code varchar2(50)
)
/
