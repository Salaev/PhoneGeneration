CREATE TYPE MSG_RESOURCE_RESERVATION_TYPE AS OBJECT(MSISDN                VARCHAR2(30),
                                                                                     RESOURCE_PARAM_CODE   VARCHAR2(64),
                                                                                     RESOURCE_PARAM_VALUE  VARCHAR2(128), 
                                                                                     EVENT_DATE            DATE,
                                                                                     EVENT_TYPE            NUMBER(1))
/
