CREATE TYPE          "T_PHONE_DATE_OBJ"                                          AS OBJECT (phone VARCHAR2(30), datetime DATE)
/
