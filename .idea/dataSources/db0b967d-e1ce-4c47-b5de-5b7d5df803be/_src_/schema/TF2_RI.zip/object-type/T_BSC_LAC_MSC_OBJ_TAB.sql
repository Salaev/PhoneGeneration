CREATE TYPE          "T_BSC_LAC_MSC_OBJ_TAB"                                          AS TABLE OF T_BSC_LAC_MSC_OBJ
/
