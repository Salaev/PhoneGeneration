CREATE TYPE          "T_IMSI_OBJ_TAB"                                          AS TABLE OF T_IMSI_OBJ
/
