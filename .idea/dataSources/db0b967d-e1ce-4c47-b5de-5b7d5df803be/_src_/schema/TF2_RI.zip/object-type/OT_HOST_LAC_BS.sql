CREATE type OT_HOST_LAC_BS is object
(
  record_id number,
  host_id number,
  host_code varchar2(50),
  host_code2 varchar2(50),
  location_area_id number,
  location_area_code varchar2(50),
  location_area_code2 varchar2(50),
  base_station_id number,
  base_station_code varchar2(50),
  base_station_code2 varchar2(50),
  validity_date date,
  value_id1 number,
  value_code1 varchar2(50),
  value_id2 number,
  value_code2 varchar2(50),
  rnum number
)
/
