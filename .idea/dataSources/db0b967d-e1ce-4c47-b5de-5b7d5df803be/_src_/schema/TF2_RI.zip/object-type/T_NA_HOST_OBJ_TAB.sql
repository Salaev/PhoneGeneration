CREATE TYPE          "T_NA_HOST_OBJ_TAB"                                          AS TABLE OF T_NA_HOST_OBJ
/
