CREATE TYPE          "T_IMSI_OBJ"                                          AS OBJECT(imsi VARCHAR2(20))
/
