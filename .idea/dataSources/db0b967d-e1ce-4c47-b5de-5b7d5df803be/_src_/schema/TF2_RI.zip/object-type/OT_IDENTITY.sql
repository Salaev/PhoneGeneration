CREATE type OT_IDENTITY is object
(
  record_id number,
  catalogue_data_id number,
  catalogue_data_code varchar2(200),
  catalogue_data_name nvarchar2(4000),
  error_code number,
  error_message varchar2(4000)
)
/
