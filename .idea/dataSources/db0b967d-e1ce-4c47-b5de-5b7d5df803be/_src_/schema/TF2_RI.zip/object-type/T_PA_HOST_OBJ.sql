CREATE TYPE          "T_PA_HOST_OBJ"                                          AS
  OBJECT (personal_account NUMBER(15),
          host_id          NUMBER
         );
/
