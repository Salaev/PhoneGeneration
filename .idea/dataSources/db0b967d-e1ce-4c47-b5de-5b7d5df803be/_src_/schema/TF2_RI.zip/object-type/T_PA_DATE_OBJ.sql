CREATE TYPE          "T_PA_DATE_OBJ"                                          AS OBJECT (PA NUMBER(15), datetime DATE)
/
