CREATE TYPE          "T_NA_AP_OBJ_TAB"                                          AS TABLE OF T_NA_AP_OBJ
/
