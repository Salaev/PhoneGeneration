CREATE TYPE          "T_PHONE_DATE_OBJ_TAB"                                          AS TABLE OF T_PHONE_DATE_OBJ
/
