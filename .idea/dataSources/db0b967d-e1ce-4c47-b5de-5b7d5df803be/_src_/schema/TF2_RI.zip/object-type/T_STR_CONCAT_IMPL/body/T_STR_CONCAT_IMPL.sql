CREATE type body t_str_concat_impl
is
  ------------------------------
  static function ODCIAggregateInitialize(sctx in out t_str_concat_impl)
  return number
  is
  begin
    sctx := t_str_concat_impl(null);
    return ODCIConst.success;
  end;
  ------------------------------
  member function ODCIAggregateIterate(self in out t_str_concat_impl, value in clob)
  return number
  is
  begin
    self.str := self.str || ',' || value;
  return ODCIConst.success;
  end;
  ------------------------------
  member function ODCIAggregateTerminate(self in t_str_concat_impl, returnvalue out clob, flags in number)
  return number
  is
  begin
    returnvalue := ltrim(self.str, ',');
    return ODCIConst.success;
  end;
  ------------------------------
  member function ODCIAggregateMerge(self in out t_str_concat_impl, ctx2 in t_str_concat_impl)
  return number
  is
  begin
    self.str := self.str || ',' || ctx2.str;
    return ODCIConst.success;
  end;
  ------------------------------
end;
/
