CREATE TYPE          "T_IMSI_DATE_OBJ"                                          AS
  OBJECT (IMSI        VARCHAR2(20),
          datetime    DATE
         );
/
