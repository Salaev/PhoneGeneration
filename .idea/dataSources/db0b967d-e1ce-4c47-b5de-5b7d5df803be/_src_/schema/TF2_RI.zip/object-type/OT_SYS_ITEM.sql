CREATE type OT_SYS_ITEM is object
(
  sys_item_id number,
  sys_type_code varchar2(30),
  sys_error_code number,
  sys_error_message varchar2(4000),
  sys_id number,
  sys_code varchar2(200),
  sys_name nvarchar2(4000)
)
/
