CREATE TYPE          "T_PHONE_INTERVAL_OBJ_TAB"                                          IS TABLE OF t_phone_interval_obj
/
