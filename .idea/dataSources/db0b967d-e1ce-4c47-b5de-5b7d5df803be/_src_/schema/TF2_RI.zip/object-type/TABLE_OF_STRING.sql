CREATE TYPE          "TABLE_OF_STRING"                                          AS TABLE OF VARCHAR2(2000)
/
