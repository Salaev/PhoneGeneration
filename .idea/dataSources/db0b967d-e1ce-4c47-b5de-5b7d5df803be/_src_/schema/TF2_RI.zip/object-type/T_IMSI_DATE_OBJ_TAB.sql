CREATE TYPE          "T_IMSI_DATE_OBJ_TAB"                                          AS TABLE OF t_IMSI_DATE_obj;
/
