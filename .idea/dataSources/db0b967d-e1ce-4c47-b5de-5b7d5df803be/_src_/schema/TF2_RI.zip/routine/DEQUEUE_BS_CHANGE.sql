CREATE procedure dequeue_bs_change
(
  p_subscriber varchar2,
  p_imsi out varchar2,
  p_msisdn out varchar2,
  p_start_date_msisdn out date,
  p_end_date_msisdn out date,
  p_personal_account out number,
  p_balance_storage_type out varchar2,
  p_balance_storage_code out varchar2,
  p_start_date_bs out date,
  p_end_date_bs out date,
  p_operation_type out varchar2,
  p_ms_handle out varchar2
)
as
begin
  ------------------------------
  queue_ri.get_bs_change_msg
  (
    p_subscriber => p_subscriber,
    p_imsi => p_imsi,
    p_msisdn => p_msisdn,
    p_start_date_msisdn => p_start_date_msisdn,
    p_end_date_msisdn => p_end_date_msisdn,
    p_personal_account => p_personal_account,
    p_balance_storage_type => p_balance_storage_type,
    p_balance_storage_code => p_balance_storage_code,
    p_start_date_bs => p_start_date_bs,
    p_end_date_bs => p_end_date_bs,
    p_operation_type => p_operation_type,
    p_ms_handle => p_ms_handle
  );
  ------------------------------
end;
/
