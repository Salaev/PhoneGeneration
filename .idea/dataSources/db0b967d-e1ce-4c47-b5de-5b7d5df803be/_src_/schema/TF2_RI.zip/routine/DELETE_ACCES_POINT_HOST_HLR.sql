CREATE PROCEDURE          "DELETE_ACCES_POINT_HOST_HLR" IS
/*this PROCEDURE deletes records from table ACCESS_POINT_HOST which hosts_type_code is 'HL' */
BEGIN
  DELETE FROM access_point_host aph
 WHERE EXISTS (SELECT 1
    FROM host h
                WHERE h.host_id = aph.host_id
                 AND h.host_type_code = 'HL');

 COMMIT;
END DELETE_ACCES_POINT_HOST_HLR;


/
