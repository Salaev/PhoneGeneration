CREATE procedure REFRESH_MSISDN_HOST_MV is
begin
  execute immediate 'alter session set optimizer_index_cost_adj=1';
  execute immediate 'alter session set optimizer_index_caching=100';
  execute immediate 'alter session set "_mv_refresh_use_stats"=true';
  execute immediate 'ALTER SESSION SET "_optimizer_ignore_hints"=TRUE';
  dbms_refresh.refresh('"RI"."MSISDN_HOST_RF"');
end REFRESH_MSISDN_HOST_MV;
/
