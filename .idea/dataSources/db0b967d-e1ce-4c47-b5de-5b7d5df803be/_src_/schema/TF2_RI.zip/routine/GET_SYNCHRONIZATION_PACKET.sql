CREATE PROCEDURE          "GET_SYNCHRONIZATION_PACKET" 
(
  p_synchronization_sn   IN NUMBER,
  p_network_operator_id  IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_synchronization_date IN SYNCHRONIZATION_HISTORY.REQUEST_DATE%TYPE,
  p_synchronization_type IN SYNCHRONIZATION_HISTORY.SYNCHRONIZATION_TYPE%TYPE,
  p_delete_temp          IN CHAR DEFAULT 'Y',
  handle_tran            IN CHAR,
  p_raise_error          IN CHAR,
  ERROR_CODE             OUT NUMBER,
  error_message          OUT VARCHAR2,
  result_list            OUT sys_refcursor
) IS
  v_module varchar2(30) := 'get_synchronization_packet';
  v_sqlcode              NUMBER;
  v_network_operator_id TABLE_OF_NUMBER;
BEGIN
  RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_start,
                       RSIG_UTILS.c_debug_level_1,
                       RSIG_UTILS.c_debug_event_type_d,
                       v_module);

  v_network_operator_id := TABLE_OF_NUMBER();
  v_network_operator_id.extend(1);
  v_network_operator_id(1) := p_network_operator_id;

  GET_SYNCHRONIZATION_PACKET_INT(
    p_synchronization_sn => p_synchronization_sn,
    p_network_operator_id => v_network_operator_id,
    p_synchronization_date => p_synchronization_date,
    p_synchronization_type => p_synchronization_type,
    p_delete_temp => p_delete_temp,
    handle_tran => handle_tran,
    p_raise_error => p_raise_error,
    ERROR_CODE => ERROR_CODE,
    error_message => error_message,
    result_list => result_list
  );

  RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_end,
                       RSIG_UTILS.c_debug_level_1,
                       RSIG_UTILS.c_debug_event_type_d,
                       v_module);

EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --      dbms_output.put_line(error_message);
    ERROR_CODE := RSIG_UTILS.handle_error(v_sqlcode);
    RSIG_UTILS.debug_rsi(to_char(ERROR_CODE),
                         RSIG_UTILS.c_debug_level_0,
                         RSIG_UTILS.c_debug_event_type_er,
                         v_module);
    /*CASE handle_tran
      WHEN RSIG_UTILS.c_handle_tran_s THEN
        ROLLBACK TO SAVEPOINT get_synchronization_packet;
      WHEN RSIG_UTILS.c_handle_tran_y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;*/
    IF upper(p_raise_error) = RSIG_UTILS.c_yes THEN
      RAISE;
    END IF;
END get_synchronization_packet;


/
