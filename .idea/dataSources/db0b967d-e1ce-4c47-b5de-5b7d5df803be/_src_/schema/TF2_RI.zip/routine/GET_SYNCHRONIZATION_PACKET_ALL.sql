CREATE PROCEDURE          "GET_SYNCHRONIZATION_PACKET_ALL" 
  (
    p_synchronization_sn           IN NUMBER,
    p_network_operator_id  IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_synchronization_type IN SYNCHRONIZATION_HISTORY.SYNCHRONIZATION_TYPE%TYPE,
    p_include_child        IN SYNCHRONIZATION_HISTORY.INCLUDING_CHILD%TYPE,
    p_request_date         IN SYNCHRONIZATION_HISTORY.REQUEST_DATE%TYPE,
    handle_tran            IN CHAR,
    p_raise_error          IN CHAR,
    p_synchronization_date OUT SYNCHRONIZATION_HISTORY.REQUEST_DATE%TYPE,
    ERROR_CODE             OUT NUMBER,
    error_message          OUT VARCHAR2,
    result_list            OUT sys_refcursor
  ) IS
    --v_delete_temp CHAR(1);
    --pom_cur                sys_refcursor;
    --    v_last_synch           DATE;
    --    v_synchronization_date DATE;
    v_sysdate DATE;
    v_sqlcode NUMBER;
    v_network_operator_id TABLE_OF_NUMBER;
  BEGIN
    RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_start,
                         RSIG_UTILS.c_debug_level_1,
                         RSIG_UTILS.c_debug_event_type_d,
                         'synchronization.GET_SYNCHRONIZATION_PACKET_ALL');

    IF handle_tran = RSIG_UTILS.c_handle_tran_s THEN
      SAVEPOINT GET_SYNCHRONIZATION_PACKET_ALL;
    END IF;
    v_sysdate              := SYSDATE;
    p_synchronization_date := nvl(p_request_date, v_sysdate);

    -- loop for all net.ops and all its children
    SELECT NETWORK_OPERATOR_ID BULK COLLECT INTO v_network_operator_id
                  FROM NETWORK_OPERATOR n
                 WHERE (LEVEL = 1 OR upper(p_include_child) = RSIG_UTILS.c_YES)
                 START WITH n.NETWORK_OPERATOR_ID = p_network_operator_id
                CONNECT BY PRIOR n.NETWORK_OPERATOR_ID = n.NETWORK_OPERATOR_ID_UPPER
    ;

    get_synchronization_packet_int(
                                 p_synchronization_sn   => p_synchronization_sn,
                                 p_network_operator_id => v_network_operator_id,
                                 p_synchronization_type => p_synchronization_type,
                                 p_synchronization_date => nvl(p_request_date, v_sysdate),
                                 p_delete_temp          => 'Y',
                                 handle_tran            => RSIG_UTILS.c_HANDLE_TRAN_N,
                                 p_raise_error          => RSIG_UTILS.c_YES,
                                 ERROR_CODE             => ERROR_CODE,
                                 error_message          => error_message,
                                 result_list            => result_list);

    OPEN result_list FOR
      SELECT /*+ ordered use_hash(tmp, no) full(tmp) full(no)*/
             INTERNATIONAL_FORMAT startrange,
             INT_FORMAT_END       endrange,
             ACTION               editcode,
             no.UPRS_MEMBER_CODE  serviceprovidercode,
             1                    ascode
        FROM TMP_SYNCH_PHONE_NUMBERS tmp
        JOIN NETWORK_OPERATOR no ON tmp.NETWORK_OPERATOR_ID = no.NETWORK_OPERATOR_ID
        WHERE SYNCHRONIZATION_SN = p_synchronization_sn
       ORDER BY INTERNATIONAL_FORMAT;

    IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
      COMMIT;
    END IF;
    RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_end,
                         RSIG_UTILS.c_debug_level_1,
                         RSIG_UTILS.c_debug_event_type_d,
                         'synchronization.get_synchronization_data');

  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --      dbms_output.put_line(error_message);
      ERROR_CODE := RSIG_UTILS.handle_error(v_sqlcode);
      RSIG_UTILS.debug_rsi(to_char(ERROR_CODE),
                           RSIG_UTILS.c_debug_level_0,
                           RSIG_UTILS.c_debug_event_type_er,
                           'GET_SYNCHRONIZATION_PACKET_ALL');
      OPEN Result_list FOR
        SELECT ERROR_CODE FROM dual;

      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT GET_SYNCHRONIZATION_PACKET_ALL;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
      IF upper(p_raise_error) = RSIG_UTILS.c_YES THEN
        RAISE;
      END IF;
  END GET_SYNCHRONIZATION_PACKET_ALL;


/
