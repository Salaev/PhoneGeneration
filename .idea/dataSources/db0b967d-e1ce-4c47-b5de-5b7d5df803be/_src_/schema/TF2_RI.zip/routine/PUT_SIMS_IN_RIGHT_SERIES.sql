CREATE PROCEDURE          "PUT_SIMS_IN_RIGHT_SERIES" is
/*
 this procedure put wrongly placed sim cards in right series, if exist...
    when no serie (start_imsi .. end_imsi) exists for sim_card -> stay unchanged
*/
begin
    update sim_card sc set
    sc.sim_series_id = (select ss.sim_series_id
         from sim_series ss
                        where TO_NUMBER(sc.imsi) BETWEEN TO_NUMBER(ss.start_imsi_number)
                               AND TO_NUMBER(ss.end_imsi_number))
 where
     exists (select 1

          from sim_card sc2
                join SIM_SERIES ss2 on sc2.sim_series_id = ss2.sim_series_id
                join sim_series ss3 on (TO_NUMBER(sc2.imsi) BETWEEN TO_NUMBER(ss3.start_imsi_number)
                         AND TO_NUMBER(ss3.end_imsi_number))
                where sc.access_point_id = sc2.access_point_id
                and
                 NOT (TO_NUMBER(sc.imsi) BETWEEN TO_NUMBER(ss2.start_imsi_number)
                         AND TO_NUMBER(ss2.end_imsi_number)));

 commit;
end PUT_SIMS_IN_RIGHT_SERIES;


/
