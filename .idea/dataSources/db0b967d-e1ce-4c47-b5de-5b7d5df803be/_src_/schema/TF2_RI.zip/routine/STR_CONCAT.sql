CREATE function str_concat(input clob)
/** Replacement of LISTAGG for strings of 4000++ characters */
return clob
parallel_enable aggregate using t_str_concat_impl;
/
