CREATE procedure get_imsi_msisdn_bs_changes(
  p_start_date          date,
  p_network_operator_id number,
  p_result_list         out sys_refcursor
)
is
begin
  ------------------------------
  rsig_synchronization.get_msisdn_status_for_cust
  (
    p_start_date => p_start_date,
    p_network_operator_id => p_network_operator_id,
    p_result_list => p_result_list
  );
  ------------------------------
end;
/
