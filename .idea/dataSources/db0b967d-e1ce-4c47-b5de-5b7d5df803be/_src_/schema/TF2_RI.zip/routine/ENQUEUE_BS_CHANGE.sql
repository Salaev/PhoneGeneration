CREATE procedure enqueue_bs_change
(
  p_imsi varchar2,
  p_msisdn varchar2,
  p_start_date_msisdn date,
  p_end_date_msisdn date,
  p_personal_account number,
  p_balance_storage_type varchar2,
  p_balance_storage_code varchar2,
  p_start_date_bs date,
  p_end_date_bs date,
  p_operation_type varchar2
)
as
begin
  ------------------------------
  queue_ri.set_bs_change_msg
  (
    p_imsi => p_imsi,
    p_msisdn => p_msisdn,
    p_start_date_msisdn => p_start_date_msisdn,
    p_end_date_msisdn => p_end_date_msisdn,
    p_personal_account => p_personal_account,
    p_balance_storage_type => p_balance_storage_type,
    p_balance_storage_code => p_balance_storage_code,
    p_start_date_bs => p_start_date_bs,
    p_end_date_bs => p_end_date_bs,
    p_operation_type => p_operation_type
  );
  ------------------------------
end;
/
