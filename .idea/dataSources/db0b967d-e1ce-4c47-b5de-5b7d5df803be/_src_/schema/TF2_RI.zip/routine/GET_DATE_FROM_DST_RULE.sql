CREATE PROCEDURE          "GET_DATE_FROM_DST_RULE" (
  p_year                        IN   VARCHAR2,
  p_dst_rule_mask               IN   VARCHAR2,
  p_dst_rule_date               IN   VARCHAR2,
  p_date                        OUT  DATE
)
IS
  v_sqlcode                     number;
  v_event_source                varchar2(60) :='EXTERNAL_INTERFACE.Get_time_zone_offset_list';

  v_year                        VARCHAR2(100);
  v_day                         VARCHAR2(100);
  v_day_of_week                 NUMBER;
  v_date                        DATE;
  v_string                      VARCHAR2(100);
  v_rule_date                   VARCHAR2(100);
  v_day_of_month                VARCHAR2(100);
  v_number_of_week              NUMBER;
  
  v_counter                     NUMBER;
  v_flag                        NUMBER;

BEGIN
  p_date := null;
  
  if p_year is null or p_year = ''
  then
    v_year := TO_CHAR(SYSDATE, 'YYYY');
  else
    v_year := p_year;
  end if;
  
  if p_dst_rule_mask = UPPER('DATE')
  then
    --p_dst_rule_mask = DATE
    v_string := v_year || p_dst_rule_date;
    p_date := TO_DATE(v_string, 'YYYYDDMMHH24MISS');
    return;
  end if;

  --p_dst_rule_mask = WEEK_MONTH_WEEKDAY
  v_day_of_week := TO_NUMBER(substr(p_dst_rule_date, 1, 1));
  -- v_day_of_week
  -- 1 - Monday
  -- 2 - Tuesday
  -- 3 - Wednesday
  -- 4 - Thursday
  -- 5 - Friday
  -- 6 - Saturday
  -- 7 - Sunday
  v_day_of_week := v_day_of_week + 1;
  if v_day_of_week = 8
  then
    v_day_of_week := 1;
  end if;
  -- v_day_of_week
  -- 2 - Monday
  -- 3 - Tuesday
  -- 4 - Wednesday
  -- 5 - Thursday
  -- 6 - Friday
  -- 7 - Saturday
  -- 1 - Sunday
  
  v_number_of_week := 0;
  
  if substr(p_dst_rule_date, 2, 2) = '+1'
  then
    v_number_of_week := 1;    
  end if;
  if substr(p_dst_rule_date, 2, 2) = '+2'
  then
    v_number_of_week := 2;    
  end if;  
  if substr(p_dst_rule_date, 2, 2) = '+3'
  then
    v_number_of_week := 3;    
  end if;  
  if substr(p_dst_rule_date, 2, 2) = '+4'
  then
    v_number_of_week := 4;    
  end if;  
  
  v_rule_date := substr(p_dst_rule_date, 4); 
  
  v_counter := 0;
  v_flag := 0;
  v_day := '01';
  v_day_of_month := '01';
  
  loop
  
    v_string := v_year || v_day || v_rule_date;
    --dbms_output.put_line(v_string);
    begin
      v_date := TO_DATE(v_string, 'YYYYDDMMHH24MISS');
      v_string := TO_CHAR(v_date, 'D');
      --dbms_output.put_line(v_string);
    exception
      when others then 
        exit; 
    end;
    --dbms_output.put_line(v_string);
    
    if TO_NUMBER(v_string) = v_day_of_week
    then
      v_day_of_month := TO_CHAR(v_date, 'DD');
      v_counter := v_counter + 1;
      if v_counter = v_number_of_week
      then
        v_flag := 0;
        exit;
      end if;
    end if;
    
    v_day := v_day + 1;
    if v_day < 10
    then
      v_day := '0' || v_day;
    end if;
    
  end loop;
  
  v_string := v_year || v_day_of_month || v_rule_date;
  p_date := TO_DATE(v_string, 'YYYYDDMMHH24MISS');

END;

/
