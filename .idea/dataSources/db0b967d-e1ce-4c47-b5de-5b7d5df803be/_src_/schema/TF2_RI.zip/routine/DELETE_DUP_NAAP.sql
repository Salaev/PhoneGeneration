CREATE procedure delete_dup_naap (
  p_date_from           date,
  p_network_operator_id number
)
is
begin
  ------------------------------
  rsig_synchronization.delete_dup_naap_for_cust
  (
    p_date_from => p_date_from,
    p_network_operator_id => p_network_operator_id
  );
  ------------------------------
end;
/
