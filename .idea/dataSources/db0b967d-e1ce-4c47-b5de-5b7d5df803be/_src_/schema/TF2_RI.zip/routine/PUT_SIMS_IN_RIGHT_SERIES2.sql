CREATE PROCEDURE          "PUT_SIMS_IN_RIGHT_SERIES2" 
(
  P_COMMIT_AMOUNT NUMBER, -- how many records are processed during one loop
  p_counter       NUMBER --how many times do loop 
) IS
  /*
      this procedure put wrongly placed sim cards in right series, if exist... 
      when no serie (start_imsi .. end_imsi) exists for sim_card -> stay unchanged 
  */

  TYPE t_number IS TABLE OF NUMBER;

  col_sc_id t_number;
  --  col_ss_from_id t_number;
  col_ss_to_id t_number;

  CURSOR CUR IS
    SELECT SC.ACCESS_POINT_ID,
           --         SS2.SIM_SERIES_ID _FROM,
           SS3.SIM_SERIES_ID TO_
      FROM SIM_CARD SC
      JOIN SIM_SERIES SS2 ON SC.SIM_SERIES_ID = SS2.SIM_SERIES_ID
      JOIN SIM_SERIES SS3 ON (TO_NUMBER(SC.IMSI) BETWEEN TO_NUMBER(SS3.START_IMSI_NUMBER) AND TO_NUMBER(SS3.END_IMSI_NUMBER))
     WHERE NOT (TO_NUMBER(SC.IMSI) BETWEEN TO_NUMBER(SS2.START_IMSI_NUMBER) AND TO_NUMBER(SS2.END_IMSI_NUMBER));
  v_limit NUMBER;
  i       NUMBER;
  counter NUMBER;
BEGIN
  counter := 0;
  LOOP
    v_limit := nvl(P_COMMIT_AMOUNT,
                   1000);
    OPEN cur;
    FETCH cur BULK COLLECT
      INTO col_sc_id, col_ss_to_id LIMIT v_limit;
    EXIT WHEN col_sc_id.FIRST IS NULL;
    EXIT WHEN counter > p_counter;
    counter := counter + 1;
    FORALL i IN col_sc_id.FIRST .. col_sc_id.LAST
      UPDATE sim_card sc SET sc.SIM_SERIES_ID = col_ss_to_id(i)
      WHERE sc.ACCESS_POINT_ID = col_sc_id(i);
   
    IF cur%ISOPEN THEN
      CLOSE cur;
    END IF;
    COMMIT;
  
  END LOOP;
END PUT_SIMS_IN_RIGHT_SERIES2;


/
