CREATE PROCEDURE          "GET_SYNCHRONIZATION_PACKET_INT" 
(
  p_synchronization_sn   IN NUMBER,
  p_network_operator_id  IN TABLE_OF_NUMBER,
  p_synchronization_date IN SYNCHRONIZATION_HISTORY.REQUEST_DATE%TYPE,
  p_synchronization_type IN SYNCHRONIZATION_HISTORY.SYNCHRONIZATION_TYPE%TYPE,
  p_delete_temp          IN CHAR DEFAULT 'Y',
  handle_tran            IN CHAR,
  p_raise_error          IN CHAR,
  ERROR_CODE             OUT NUMBER,
  error_message          OUT VARCHAR2,
  result_list            OUT sys_refcursor
) IS
  v_module varchar2(30) := 'get_synchronization_packet_int';
  v_sqlcode              NUMBER;
  v_sysdate              DATE;
  v_bef_area             VARCHAR2(15) := NULL;
  v_bef_country          VARCHAR2(15) := NULL;
  v_bef_num              NUMBER := NULL;
  v_bef_int              VARCHAR2(30) := NULL;
  v_act_area             VARCHAR2(15) := NULL;
  v_act_country          VARCHAR2(15) := NULL;
  v_act_num              NUMBER := NULL;
  v_act_int              VARCHAR2(30) := NULL;
  v_start_area           VARCHAR2(15) := NULL;
  v_start_country        VARCHAR2(15) := NULL;
  v_start_int            VARCHAR2(30) := NULL;
  v_bef_action           VARCHAR2(10);
  v_act_action           VARCHAR2(10);
  v_curs                    sys_refcursor;
  v_synchronization_date DATE;
  v_last_synch           DATE;
  --v_last_na_id           NUMBER;
  v_bef_net_op           NUMBER := NULL;
  v_act_net_op           NUMBER := NULL;
  --g_false constant number := 0;
  g_true constant number := 1;
  v_on_inc_sync_big_bang constant varchar2(127) := 'incremental_synchronization_big_bang';
  v_odv_inc_sync_big_bang constant varchar2(255) := '0';
  v_o_inc_sync_big_bang varchar2(255);

function get_option(p_name varchar2, p_default varchar2 := null) return varchar2 is
v_res varchar2(255);
begin
    select /*+ full(z)*/ --need func index lower(db_parameter_name)
        db_parameter_value into v_res from db_parameters z
        where lower(db_parameter_name) = lower(p_name)
    ;
    return v_res;
exception
when others then
    return p_default;
end;
BEGIN
  RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_start,
                       RSIG_UTILS.c_debug_level_1,
                       RSIG_UTILS.c_debug_event_type_d,
                       v_module);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_handle_tran_s, RSIG_UTILS.c_handle_tran_y, RSIG_UTILS.c_handle_tran_n) OR
     (handle_tran IS NULL)) THEN
    raise_application_error(RSIG_UTILS.c_ora_invalid_handle, 'invalid handle_tran parameter!');
  END IF;

  v_sysdate              := SYSDATE;
  v_synchronization_date := nvl(p_synchronization_date, v_sysdate);
  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_handle_tran_s) THEN
    SAVEPOINT get_synchronization_packet_int;
  END IF;

  -- delete temporary table if required
  IF upper(p_delete_temp) = 'Y' THEN
    DELETE FROM tmp_synch_phone_numbers;
  END IF;

  delete from tt_n;

  insert into tt_n(id) select distinct column_value id from table(cast(p_network_operator_id as table_of_number));

  -- full synchronization
  ----------------------------------------------------------------------------------------------

  IF p_synchronization_type = RSIG_UTILS.c_SYNCHRONIZATION_FULL THEN

    --preparing intervals of telephone numbers
    OPEN v_curs FOR
      SELECT country_code, area_code, num, international_format, network_operator_id
        FROM (SELECT /*+ ordered use_hash(z, pso, pns, p) full(z) full(pso) full(pns) full(p) parallel(z, 8) parallel(pso, 8) parallel(pns, 8) parallel(p, 8)*/
                     pns.country_code,
                     pns.area_code,
                     to_number(p.international_format) num,
                     p.international_format,
                     z.id network_operator_id
                FROM tt_n z
                JOIN phone_series_operator pso ON pso.network_operator_id = z.id
                JOIN phone_number_series pns ON pns.phone_number_series_id = pso.phone_number_series_id
                JOIN phone_number p ON p.phone_number_series_id = pns.phone_number_series_id
               WHERE 1 = 1
                 AND v_synchronization_date BETWEEN pso.start_date AND nvl(pso.end_date, v_synchronization_date)
                 AND (pns.deleted IS NULL OR pns.deleted > v_synchronization_date)
                 AND NOT EXISTS
               (SELECT /*+ hash_aj full(nash) parallel(nash, 8)*/ 1
                        FROM NETWORK_ADDRESS_STATUS_HISTORY nash
                       WHERE nash.NETWORK_ADDRESS_ID = p.NETWORK_ADDRESS_ID
                         AND v_synchronization_date BETWEEN nash.START_DATE AND nvl(nash.END_DATE, v_synchronization_date)
                         AND nash.NET_ADDRESS_STATUS_CODE = RSIG_UTILS.c_OTHER_PHONE_NUMBER_CODE)
             )
       ORDER BY network_operator_id, country_code, area_code, international_format;

    -- inserting intervals of telephone numbers into temp table
    v_start_int := NULL;
    LOOP
      FETCH v_curs
        INTO v_act_country, v_act_area, v_act_num, v_act_int, v_act_net_op;
      IF v_curs%NOTFOUND
         OR v_start_int IS NULL
         OR v_act_net_op <> v_bef_net_op
         OR v_act_country <> v_bef_country
         OR v_act_area <> v_bef_area
         OR v_act_num <> v_bef_num + 1
         THEN
        IF v_start_int IS NOT NULL THEN
          INSERT INTO tmp_synch_phone_numbers
            (SYNCHRONIZATION_SN,
             COUNTRY_CODE,
             AREA_CODE,
             INTERNATIONAL_FORMAT,
             COUNTRY_CODE_END,
             AREA_CODE_END,
             INT_FORMAT_END,
             ACTION,
             NETWORK_OPERATOR_ID)
          VALUES
            (p_synchronization_sn,
             v_start_country,
             v_start_area,
             v_start_int,
             v_bef_country,
             v_bef_area,
             v_bef_int,
             RSIG_UTILS.c_synchronization_add,
             v_bef_net_op);
        END IF;
        IF v_curs%NOTFOUND THEN
          EXIT;
        END IF;
        v_start_country := v_act_country;
        v_start_area := v_act_area;
        v_start_int := v_act_int;
      END IF;
      v_bef_country := v_act_country;
      v_bef_area := v_act_area;
      v_bef_num := v_act_num;
      v_bef_int := v_act_int;
      v_bef_net_op := v_act_net_op;
    END LOOP;

    -- incremental synchronization
    ----------------------------------------------------------------------------------------------
  ELSIF p_synchronization_type = RSIG_UTILS.c_synchronization_incremental THEN

    -- check last synchronization
    -- incremental synchronization is possible ONLY for all regions in current RI installation,
    -- and not for particular regions, so it will exist data in table, and for childs could be only full

    SELECT MAX(sh.TRANSFER_DATE)
      INTO v_last_synch
      FROM (SELECT NETWORK_OPERATOR_ID
              FROM NETWORK_OPERATOR n
             START WITH n.NETWORK_OPERATOR_ID in (SELECT ID FROM TT_N)
            CONNECT BY PRIOR n.NETWORK_OPERATOR_ID_UPPER = n.NETWORK_OPERATOR_ID) nos
      JOIN SYNCHRONIZATION_HISTORY sh ON sh.NETWORK_OPERATOR_ID = nos.network_operator_id
     WHERE sh.COMPLETION_DATE IS NOT NULL
       AND sh.COMPLETION_RESULT_CODE = RSIG_SYNCHRONIZATION.c_SYNCH_UPRS_DONE_OK;

    IF v_last_synch IS NULL THEN
      raise_application_error(RSIG_UTILS.c_ORA_INVALID_PARAMETER,
                              'wrong synchronization type, first must be full!!!');
    END IF;

    IF v_last_synch > p_synchronization_date THEN
      raise_application_error(RSIG_UTILS.c_ORA_INVALID_DATE,
                              'Date of last successfull synchronization greather than date of actual synchronization!');
    END IF;

    DELETE FROM tt_synchronization1;
    DELETE FROM tt_synchronization2;
    DELETE FROM tt_synchronization3;
    DELETE FROM tt_synchronization4;

    v_o_inc_sync_big_bang := nvl(get_option(v_on_inc_sync_big_bang, v_odv_inc_sync_big_bang), v_odv_inc_sync_big_bang);

    --IF (C_USE_BRANCH_IF_LONG_PERIOD = 'Y') AND (v_synchronization_date - v_last_synch > C_MAXIMUM_PERIOD_VALUE)
    IF to_number(v_o_inc_sync_big_bang) = g_true THEN
      INSERT INTO tt_synchronization3 (ID, DT, ACTION)
                   SELECT /*+ full(nash) parallel(nash, 8)*/
                          nash.NETWORK_ADDRESS_ID,
                          nash.START_DATE max_date,
                          RSIG_UTILS.c_synchronization_sub ACTION
                   FROM NETWORK_ADDRESS_STATUS_HISTORY nash -- kandidati na Other billing
                   WHERE 1 = 1
                     AND nash.START_DATE BETWEEN v_last_synch AND v_synchronization_date
                     AND nvl(nash.END_DATE, v_synchronization_date) >= v_synchronization_date
                     AND nash.net_address_status_code = RSIG_UTILS.c_OTHER_PHONE_NUMBER_CODE
                   UNION ALL
                   SELECT /*+ ordered use_hash(nash) full(nash) parallel(nash, 8)*/
                          nash.NETWORK_ADDRESS_ID,
                          nash.end_date max_date,
                          RSIG_UTILS.c_synchronization_add ACTION
                   FROM NETWORK_ADDRESS_STATUS_HISTORY nash
                   WHERE 1 = 1
                     AND nash.END_DATE BETWEEN v_last_synch AND v_synchronization_date
                     AND nash.net_address_status_code = RSIG_UTILS.c_OTHER_PHONE_NUMBER_CODE
                     AND NOT EXISTS(SELECT /*+ hash_aj full(nash2) parallel(nash2, 8)*/ 1
                                    FROM NETWORK_ADDRESS_STATUS_HISTORY nash2
                                    WHERE 1 = 1
                                      AND nash.NETWORK_ADDRESS_ID = nash2.NETWORK_ADDRESS_ID
                                      AND nash2.end_date BETWEEN v_last_synch AND v_synchronization_date
                                      AND nash2.end_date > nash.END_DATE
                                      AND nash2.NET_ADDRESS_STATUS_CODE = RSIG_UTILS.c_OTHER_PHONE_NUMBER_CODE)
      ;
      INSERT INTO tt_synchronization4 (ID, DT, ACTION, ID2)
                 SELECT /*+ ordered use_hash(z, pso) full(z) full(pso)*/
                        pso.PHONE_NUMBER_SERIES_ID,
                        pso.START_DATE max_date,
                        RSIG_UTILS.c_synchronization_add ACTION,
                        pso.NETWORK_OPERATOR_ID
                 FROM PHONE_SERIES_OPERATOR pso
                 JOIN TT_N z
                   ON z.ID = pso.NETWORK_OPERATOR_ID
                 WHERE (pso.START_DATE BETWEEN v_last_synch AND v_synchronization_date /*AND  (pso.END_DATE NOT BETWEEN v_last_synch AND v_synchronization_date)*/)
                   AND nvl(pso.END_DATE, v_synchronization_date) >= v_synchronization_date
                 UNION ALL
                 SELECT /*+ ordered use_hash(z, pso) full(z) full(pso)*/
                        pso.PHONE_NUMBER_SERIES_ID,
                        pso.END_DATE max_date,
                        RSIG_UTILS.c_synchronization_sub ACTION,
                        pso.NETWORK_OPERATOR_ID
                 FROM PHONE_SERIES_OPERATOR pso
                 JOIN TT_N z
                   ON z.ID = pso.NETWORK_OPERATOR_ID
                 WHERE 1 = 1
                   AND pso.END_DATE BETWEEN v_last_synch AND v_synchronization_date
                   AND NOT EXISTS(SELECT /*+ hash_aj full(pso2)*/ 1
                                  FROM PHONE_SERIES_OPERATOR pso2
                                  WHERE pso2.START_DATE BETWEEN v_last_synch AND v_synchronization_date
                                    AND pso2.PHONE_NUMBER_SERIES_ID = pso.PHONE_NUMBER_SERIES_ID
                                    AND (pso2.START_DATE > pso.END_DATE /*OR pso2.START_DATE = pso.START_DATE*/) -- jho 31.05.2005 removed to detect all last changes
                                    AND pso2.NETWORK_OPERATOR_ID = pso.NETWORK_OPERATOR_ID)
      ;
      INSERT INTO tt_synchronization2 (ID, DT, ACTION, ID2, CODE)
           SELECT /*+ ordered use_hash(n, pn, pso, z) full(n) full(pn) full(pso) full(z) parallel(n, 8) parallel(pn, 8) parallel(pso, 8) parallel(z, 8)*/
            n.ID,
            n.DT,
            n.ACTION,
            pso.NETWORK_OPERATOR_ID,
            pn.international_format
             FROM tt_synchronization3 n
             JOIN PHONE_NUMBER pn ON n.ID = pn.NETWORK_ADDRESS_ID
             JOIN PHONE_SERIES_OPERATOR pso ON pso.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
                  AND v_synchronization_date BETWEEN pso.START_DATE AND nvl(pso.END_DATE, v_synchronization_date)
             JOIN TT_N z
               ON z.ID = pso.NETWORK_OPERATOR_ID
      ;
      INSERT INTO tt_synchronization2 (ID, DT, ACTION, ID2, CODE)
           SELECT /*+ ordered use_hash(tpso, pn) full(tpso) full(pn) parallel(tpso, 8) parallel(pn, 8)*/
            pn.NETWORK_ADDRESS_ID,
            tpso.DT,
            tpso.ACTION,
            tpso.ID2,
            pn.international_format
           FROM tt_synchronization4 tpso
           JOIN PHONE_NUMBER pn ON pn.PHONE_NUMBER_SERIES_ID = tpso.ID
      ;
    ELSE
      INSERT INTO tt_synchronization3 (ID, DT, ACTION)
                   SELECT /*+ index_asc(nash, PK_NETWORK_ADDRESS_STATUS_HIST)*/
                          nash.NETWORK_ADDRESS_ID,
                          nash.START_DATE max_date,
                          RSIG_UTILS.c_synchronization_sub ACTION
                   FROM NETWORK_ADDRESS_STATUS_HISTORY nash -- kandidati na Other billing
                   WHERE 1 = 1
                     AND nash.START_DATE BETWEEN v_last_synch AND v_synchronization_date
                     AND nvl(nash.END_DATE, v_synchronization_date) >= v_synchronization_date
                     AND nash.net_address_status_code = RSIG_UTILS.c_OTHER_PHONE_NUMBER_CODE
                   UNION ALL
                   SELECT /*+ index_asc(nash, I_NETADSTAHI_END_DATE)*/
                          nash.NETWORK_ADDRESS_ID,
                          nash.end_date max_date,
                          RSIG_UTILS.c_synchronization_add ACTION
                   FROM NETWORK_ADDRESS_STATUS_HISTORY nash
                   WHERE 1 = 1
                     AND nash.END_DATE BETWEEN v_last_synch AND v_synchronization_date
                     AND nash.net_address_status_code = RSIG_UTILS.c_OTHER_PHONE_NUMBER_CODE
                     AND NOT EXISTS(SELECT /*+ hash_aj index_asc(nash2, I_NETADSTAHI_END_DATE)*/ 1
                                    FROM NETWORK_ADDRESS_STATUS_HISTORY nash2
                                    WHERE 1 = 1
                                      AND nash.NETWORK_ADDRESS_ID = nash2.NETWORK_ADDRESS_ID
                                      AND nash2.end_date BETWEEN v_last_synch AND v_synchronization_date
                                      AND nash2.end_date > nash.END_DATE
                                      AND nash2.NET_ADDRESS_STATUS_CODE = RSIG_UTILS.c_OTHER_PHONE_NUMBER_CODE)
      ;
      INSERT INTO tt_synchronization4 (ID, DT, ACTION, ID2)
                 SELECT /*+ ordered use_hash(z, pso) full(z) full(pso)*/
                        pso.PHONE_NUMBER_SERIES_ID,
                        pso.START_DATE max_date,
                        RSIG_UTILS.c_synchronization_add ACTION,
                        pso.NETWORK_OPERATOR_ID
                 FROM PHONE_SERIES_OPERATOR pso
                 JOIN TT_N z
                   ON z.ID = pso.NETWORK_OPERATOR_ID
                 WHERE (pso.START_DATE BETWEEN v_last_synch AND v_synchronization_date /*AND  (pso.END_DATE NOT BETWEEN v_last_synch AND v_synchronization_date)*/)
                   AND nvl(pso.END_DATE, v_synchronization_date) >= v_synchronization_date
                 UNION ALL
                 SELECT /*+ ordered use_hash(z, pso) full(z) full(pso)*/
                        pso.PHONE_NUMBER_SERIES_ID,
                        pso.END_DATE max_date,
                        RSIG_UTILS.c_synchronization_sub ACTION,
                        pso.NETWORK_OPERATOR_ID
                 FROM PHONE_SERIES_OPERATOR pso
                 JOIN TT_N z
                   ON z.ID = pso.NETWORK_OPERATOR_ID
                 WHERE 1 = 1
                   AND pso.END_DATE BETWEEN v_last_synch AND v_synchronization_date
                   AND NOT EXISTS(SELECT /*+ hash_aj full(pso2)*/ 1
                                  FROM PHONE_SERIES_OPERATOR pso2
                                  WHERE pso2.START_DATE BETWEEN v_last_synch AND v_synchronization_date
                                    AND pso2.PHONE_NUMBER_SERIES_ID = pso.PHONE_NUMBER_SERIES_ID
                                    AND (pso2.START_DATE > pso.END_DATE /*OR pso2.START_DATE = pso.START_DATE*/) -- jho 31.05.2005 removed to detect all last changes
                                    AND pso2.NETWORK_OPERATOR_ID = pso.NETWORK_OPERATOR_ID)
      ;
      INSERT INTO tt_synchronization2 (ID, DT, ACTION, ID2, CODE)
           SELECT /*+ ordered use_nl(n, pn) use_hash(pso, z) full(n) index_asc(pn, PK_PHONE_NUMBER) full(pso) full(z)*/
            n.ID,
            n.DT,
            n.ACTION,
            pso.NETWORK_OPERATOR_ID,
            pn.international_format
             FROM tt_synchronization3 n
             JOIN PHONE_NUMBER pn ON n.ID = pn.NETWORK_ADDRESS_ID
             JOIN PHONE_SERIES_OPERATOR pso ON pso.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
                  AND v_synchronization_date BETWEEN pso.START_DATE AND nvl(pso.END_DATE, v_synchronization_date)
             JOIN TT_N z
               ON z.ID = pso.NETWORK_OPERATOR_ID
      ;
      INSERT INTO tt_synchronization2 (ID, DT, ACTION, ID2, CODE)
           SELECT /*+ ordered use_nl(tpso, pn) full(tpso) index_asc(pn, I_PHONENUM_PHONE_NUM_SERIES_ID)*/
            pn.NETWORK_ADDRESS_ID,
            tpso.DT,
            tpso.ACTION,
            tpso.ID2,
            pn.international_format
           FROM tt_synchronization4 tpso
           JOIN PHONE_NUMBER pn ON pn.PHONE_NUMBER_SERIES_ID = tpso.ID
      ;
    END IF;

    insert into tt_synchronization1 (id, dt, action, id2, code)
select id, max(dt) dt, max(action) action, max(id2) id2, max(code) code
    from (
select id, dt, action, id2, code, max(dt) over(partition by id) aaa
    from tt_synchronization2
    )
    where 1 = 1
    and aaa = dt
    group by id
    ;

    OPEN v_curs FOR
select to_number(code) num, code, action, id2
    from tt_synchronization1 z
    order by id2, code
    ;

    -- inserting intervals of telephone numbers into temp table
    v_start_int := NULL;
    LOOP
      FETCH v_curs
        INTO v_act_num, v_act_int, v_act_action, v_act_net_op;
      IF v_curs%NOTFOUND
         OR v_start_int IS NULL
         OR v_act_action <> v_bef_action
         OR v_act_net_op <> v_bef_net_op
         OR v_act_num <> v_bef_num + 1
         THEN
        IF v_start_int IS NOT NULL THEN
          INSERT INTO TMP_SYNCH_PHONE_NUMBERS
            (SYNCHRONIZATION_SN,
             INTERNATIONAL_FORMAT,
             INT_FORMAT_END,
             ACTION,
             NETWORK_OPERATOR_ID)
          VALUES
            (p_synchronization_sn,
             v_start_int,
             v_bef_int,
             v_bef_action,
             v_bef_net_op);
        END IF;
        IF v_curs%NOTFOUND THEN
          EXIT;
        END IF;
        v_start_int := v_act_int;
      END IF;
      v_bef_num := v_act_num;
      v_bef_int := v_act_int;
      v_bef_action := v_act_action;
      v_bef_net_op := v_act_net_op;
    END LOOP;

  END IF; -- incremental synchronization
  ----------------------------------------------------------------------------------------------

  IF v_curs%ISOPEN THEN
    CLOSE v_curs;
  END IF;

  IF upper(handle_tran) = 'Y' THEN
    COMMIT;
  END IF;

  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- result -> select intervals
  OPEN result_list FOR
    SELECT /*+ ordered use_hash(tmp, no) full(tmp) full(no)*/
           INTERNATIONAL_FORMAT startrange,
           INT_FORMAT_END       endrange,
           ACTION               editcode,
           no.UPRS_MEMBER_CODE  serviceprovidercode
      FROM TMP_SYNCH_PHONE_NUMBERS tmp
      JOIN NETWORK_OPERATOR no ON tmp.NETWORK_OPERATOR_ID = no.NETWORK_OPERATOR_ID
        WHERE tmp.SYNCHRONIZATION_SN = p_synchronization_sn
     ORDER BY INTERNATIONAL_FORMAT;


  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_ok;
  RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_end,
                       RSIG_UTILS.c_debug_level_1,
                       RSIG_UTILS.c_debug_event_type_d,
                       v_module);

EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --      dbms_output.put_line(error_message);
    ERROR_CODE := RSIG_UTILS.handle_error(v_sqlcode);
    RSIG_UTILS.debug_rsi(to_char(ERROR_CODE),
                         RSIG_UTILS.c_debug_level_0,
                         RSIG_UTILS.c_debug_event_type_er,
                         v_module);
    CASE handle_tran
      WHEN RSIG_UTILS.c_handle_tran_s THEN
        ROLLBACK TO SAVEPOINT get_synchronization_packet_int;
      WHEN RSIG_UTILS.c_handle_tran_y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF upper(p_raise_error) = RSIG_UTILS.c_yes THEN
      RAISE;
    END IF;
END get_synchronization_packet_int;


/
