CREATE FUNCTION          "UMRS_IS_ROAMING" 
  ( I_IMSI IN VARCHAR2,
    I_NETWORK_OPERATOR IN NUMBER 
  )
  RETURN  NUMBER IS

  L_NO NUMBER:=0;
  L_RESULT NUMBER:=0;
  cursor c1 is select ss.network_operator_id from sim_series ss, sim_card sc 
    where ss.deleted is null and sc.sim_series_id=ss.sim_series_id and sc.imsi=I_IMSI
    and rownum=1;
  
BEGIN 
  OPEN C1;
  FETCH C1 INTO L_NO;
  IF C1%NOTFOUND THEN
    CLOSE C1;
    RETURN (0);
  END IF;
  
  CLOSE C1;
  
  IF (I_NETWORK_OPERATOR IS NULL) THEN
    L_RESULT:=0;
  ELSIF (L_NO = I_NETWORK_OPERATOR) THEN
    L_RESULT:=0;
  ELSE
    L_RESULT:=1;
  END IF;
  RETURN L_RESULT;
END;


/
