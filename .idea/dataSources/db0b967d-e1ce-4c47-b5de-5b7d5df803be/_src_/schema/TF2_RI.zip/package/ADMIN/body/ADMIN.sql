CREATE package body admin is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_in_hours_window
(
  p_date date,
  p_hour_from number,
  p_hour_to_excl number
) return boolean
is
  v_hour_to number;
  v_hour_cur number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_hour_from is null, 'p_hour_from');
  util_pkg.XCheck_Cond_Missing(p_hour_to_excl is null, 'p_hour_to_excl');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_hour_from != trunc(p_hour_from), 'p_hour_from != trunc(p_hour_from)');
  util_pkg.XCheck_Cond_Invalid(p_hour_to_excl != trunc(p_hour_to_excl), 'p_hour_to_excl != trunc(p_hour_to_excl)');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_hour_from not between 0 and 23, 'p_hour_from not between 0 and 23');
  util_pkg.XCheck_Cond_Invalid(p_hour_to_excl not between 0 and 23, 'p_hour_to_excl not between 0 and 23');
  ------------------------------
  if p_hour_from = p_hour_to_excl --!_!empty window
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
  v_hour_cur := util_pkg.get_hour(p_date);
  ------------------------------
  v_hour_to := p_hour_to_excl - 1;
  ------------------------------
  if p_hour_from > v_hour_to --!_!midnight inside
  then
    ------------------------------
    if 1 = 1
      and v_hour_cur > v_hour_to
      and v_hour_cur < p_hour_from
    then
      ------------------------------
      return FALSE;
      ------------------------------
    end if;
    ------------------------------
  else --!_!midnight outside
    ------------------------------
    if not v_hour_cur between p_hour_from and v_hour_to
    then
      ------------------------------
      return FALSE;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  return TRUE;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_in_service_window
(
  p_date date
) return boolean
is
begin
  ------------------------------
  return is_in_hours_window
  (
    p_date => p_date,
    p_hour_from => install_pkg.nnget_option_num(c_opt_srv_wnd_hour_from, c_def_srv_wnd_hour_from),
    p_hour_to_excl => install_pkg.nnget_option_num(c_opt_srv_wnd_hour_to_excl, c_def_srv_wnd_hour_to_excl)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure job_update
is
  v_do_auto_na_update boolean;
  v_do_auto_sel_cat_update boolean;
  v_do_auto_pn_naap_update boolean;
  v_do_auto_unreg_cache boolean;
  v_do_auto_rem_cache_group boolean;
  v_do_auto_inspect_flows boolean;
  v_use_job_long4insp_flows boolean;
begin
  ------------------------------
  v_do_auto_na_update:= install_pkg.nnget_option_bool(c_sett_do_auto_na_stat_upd, c_def_do_auto_na_stat_upd);
  v_do_auto_sel_cat_update:= install_pkg.nnget_option_bool(c_sett_do_auto_sel_cat_upd, c_def_do_auto_sel_cat_upd);
  v_do_auto_pn_naap_update:= install_pkg.nnget_option_bool(c_sett_do_auto_pn_naap_upd, c_def_do_auto_pn_naap_upd);
  v_do_auto_unreg_cache:= install_pkg.nnget_option_bool(c_opt_do_auto_unreg_cache, c_def_do_auto_unreg_cache);
  v_do_auto_rem_cache_group:= install_pkg.nnget_option_bool(c_opt_do_auto_rem_cache_group, c_def_do_auto_rem_cache_group);
  v_do_auto_inspect_flows := install_pkg.nnget_option_bool(c_sett_do_auto_inspect_flows, c_def_do_auto_inspect_flows);
  v_use_job_long4insp_flows := install_pkg.nnget_option_bool(c_opt_use_job_long4insp_flows, c_def_use_job_long4insp_flows);
  ------------------------------
  if v_do_auto_na_update
  then
    ------------------------------
    proc_changes_nash;
    ------------------------------
  end if;
  ------------------------------
  if v_do_auto_sel_cat_update
  then
    ------------------------------
    proc_changes_pnsc;
    ------------------------------
  end if;
  ------------------------------
  if v_do_auto_pn_naap_update
  then
    ------------------------------
    proc_changes_naap;
    ------------------------------
  end if;
  ------------------------------
  if v_do_auto_unreg_cache
  then
    auto_unreg_roaming_cache_group;
  end if;
  ------------------------------
  if v_do_auto_rem_cache_group
  then
    auto_rem_roaming_cache_group;
  end if;
  ------------------------------
  if 1 = 1
    and NOT v_use_job_long4insp_flows
    and v_do_auto_inspect_flows
  then
    ------------------------------
    proc_inspect_flows;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure job_update_long_process
is
  v_date date;
  v_do_auto_reserv_batch_update boolean;
  v_do_auto_phone_status_update boolean;
  v_do_auto_apoint_per_host_stat boolean;
  v_do_auto_mnp_prepare_ph2ret boolean;
  v_do_auto_mnp_del_compl_btch boolean;
  v_do_auto_mnp_pr_po_exp boolean;
  v_do_auto_split_po_parts boolean;
  v_do_auto_inspect_flows boolean;
  v_use_job_long4insp_flows boolean;
begin
  ------------------------------
  v_do_auto_reserv_batch_update := install_pkg.nnget_option_bool(c_sett_do_auto_res_bch_upd, c_def_do_auto_res_bch_upd);
  v_do_auto_phone_status_update := install_pkg.nnget_option_bool(c_sett_do_auto_ph_stat_upd, c_def_do_auto_ph_stat_upd);
  v_do_auto_apoint_per_host_stat := install_pkg.nnget_option_bool(c_sett_do_auto_apoint_per_host, c_def_do_auto_apoint_per_host);
  v_do_auto_mnp_prepare_ph2ret := install_pkg.nnget_option_bool(c_sett_do_auto_mnp_prep_ph2ret, c_def_do_auto_mnp_prep_ph2ret);
  v_do_auto_mnp_del_compl_btch := install_pkg.nnget_option_bool(c_sett_do_auto_mnp_dlcmplbtch, c_def_do_auto_mnp_dlcmplbtch);
  v_do_auto_mnp_pr_po_exp := install_pkg.nnget_option_bool(c_sett_do_auto_mnp_pr_po_exp, c_def_do_auto_mnp_pr_po_exp);
  v_do_auto_split_po_parts := install_pkg.nnget_option_bool(c_sett_do_auto_split_po_parts, c_def_do_auto_split_po_parts);
  v_do_auto_inspect_flows := install_pkg.nnget_option_bool(c_sett_do_auto_inspect_flows, c_def_do_auto_inspect_flows);
  v_use_job_long4insp_flows := install_pkg.nnget_option_bool(c_opt_use_job_long4insp_flows, c_def_use_job_long4insp_flows);
  ------------------------------
  if v_do_auto_reserv_batch_update
  then
    ------------------------------
    Reservation_Batch_Update;
    ------------------------------
  end if;
  ------------------------------
  if v_do_auto_phone_status_update
  then
    ------------------------------
    Auto_Phone_Status_Update;
    ------------------------------
  end if;
  ------------------------------
  if v_do_auto_apoint_per_host_stat
  then
    ------------------------------
    Access_Point_Per_Host(SYSDATE);
    ------------------------------
  end if;
  ------------------------------
  if v_do_auto_mnp_prepare_ph2ret
  then
    ------------------------------
    auto_mnp_prepare_phone2return;
    ------------------------------
  end if;
  ------------------------------
  if v_do_auto_mnp_del_compl_btch
  then
    ------------------------------
    auto_mnp_del_complete_batch;
    ------------------------------
  end if;
  ------------------------------
  if v_do_auto_mnp_pr_po_exp
  then
    ------------------------------
    auto_mnp_po_expired;
    ------------------------------
  end if;
  ------------------------------
  v_date := sysdate;
  ------------------------------
  if 1 = 1
    and v_do_auto_split_po_parts
    and (1 = 0
      or NOT install_pkg.nnget_option_bool(c_opt_part_po_use_srv_wnd, c_def_part_po_use_srv_wnd)
      or is_in_service_window(v_date)
    )
  then
    ------------------------------
    auto_split_po_parts(v_date);
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and v_use_job_long4insp_flows
    and v_do_auto_inspect_flows
  then
    ------------------------------
    proc_inspect_flows;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure proc_changes_nash
is
begin
  ------------------------------
  pn_life_pkg.proc_changes_nash;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure proc_changes_pnsc
is
begin
  ------------------------------
  pn_life_pkg.proc_changes_pnsc;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure proc_changes_naap
is
begin
  ------------------------------
  pn_life_pkg.proc_changes_naap;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure proc_inspect_flows
is
begin
  ------------------------------
  fast_parallel_pkg.at_inspect_flows;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure update_network_address_status
is
begin
  ------------------------------
  proc_changes_nash;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_salability_category
is
begin
  ------------------------------
  proc_changes_pnsc;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Reservation_Batch_Update
is
  v_sp_name varchar2(30);
  v_user_id number;
  v_date date := sysdate;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  v_user_id := util_ri.xget_default_user_id;
  ------------------------------
  reset_expired_res_batchs
  (
    p_batch_type => batch_pkg.c_BATCH_TYPE_NA_UNMNG,
    p_user_id => v_user_id,
    p_date => v_date
  );
  ------------------------------
  reset_expired_res_batchs
  (
    p_batch_type => batch_pkg.c_BATCH_TYPE_NA_MNG,
    p_user_id => v_user_id,
    p_date => v_date
  );
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure reset_expired_res_batchs
(
    p_batch_type varchar2,
    p_user_id number,
    p_date date
)
is
  v_sp_name2 varchar2(30);
  v_cursor sys_refcursor;
  --
  v_batch_id number;
  v_batch batch%rowtype;
begin
  ------------------------------
  v_cursor := batch_pkg.get_expired_batch_cursor2
  (
    p_type => p_batch_type,
    p_date => p_date
  );
  ------------------------------
  loop
    ------------------------------
    fetch v_cursor into v_batch_id;
    ------------------------------
    exit when v_cursor%notfound;
    ------------------------------
    begin
      ------------------------------
      v_sp_name2 := util_sys_pkg.make_savepoint;
      ------------------------------
      v_batch := vp_batch.xlock_get1(v_batch_id);
      ------------------------------
      rsig_phone_number.ResetPhoneNumberReserveInt(p_user_id, v_batch.batch_id);
      ------------------------------
      commit;
      ------------------------------
    exception
    when others then
      ------------------------------
      util_sys_pkg.rollback_savepoint(v_sp_name2);
      ------------------------------
      continue;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
  if v_cursor%isopen
  then
    close v_cursor;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  if v_cursor%isopen
  then
    close v_cursor;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Auto_Phone_Status_Update
is
  v_user_id number;
  v_date date := sysdate;
  --
  v_ct_date ct_date;
  v_ct_user_id ct_number;
  v_status ct_varchar_s;
  v_na_id ct_number;
  v_phones_batch_size number;
  v_error_code ct_number;
  v_error_message ct_varchar;
  v_res_set_na_status boolean;
  v_rej_numbers ct_number;
  v_tmp ct_number;
begin
  ------------------------------
  v_user_id := util_ri.xget_default_user_id;
  ------------------------------
  v_phones_batch_size := install_pkg.nnget_option_num(c_sett_ph_st_up_batch_size, c_def_ph_st_up_batch_size);
  ------------------------------
  for v_i in (select natr.na_trans_reason_code, natr.na_status_trans_code, natr.auto_trans_timeout, nast.status_code_from, nast.status_code_to
              from na_trans_reason natr
              join na_status_trans nast on nast.na_status_trans_code = natr.na_status_trans_code
             where (natr.deleted is null or natr.deleted >= v_date)
               and (nast.deleted is null or nast.deleted >= v_date)
               and natr.auto_trans_timeout is not null)
  loop
    ------------------------------
    loop
      ------------------------------
      if (v_i.status_code_from = rsig_utils.c_RESERVE_PHONE_NUMBER_CODE)
      then
        ------------------------------
        select /*+ ordered use_nl(bd b) index(bd I_BATCH_DETAILS_OBJ_ID) index(b PK_BATCH)*/
              z.network_address_id,
              v_i.status_code_to
          bulk collect into v_na_id, v_status
          from
            (
              select /*+ ordered use_hash(t) full(pn) full(t)*/
                  pn.network_address_id
                from
                  phone_number pn,
                  (select column_value network_address_id from table(cast(v_rej_numbers as ct_number))) t
              where 1 = 1
              and t.network_address_id(+) = pn.network_address_id
              and t.network_address_id is null
              and pn.net_address_status_code = v_i.status_code_from
              and pn.date_of_status_change <= v_date - util_pkg.date_dif_from_seconds(v_i.auto_trans_timeout)
            ) z,
            batch_details bd,
            batch b,
            (select column_value batch_type from table(batch_pkg.get_na_res_batch_types)) z2
          where 1 = 1
          and bd.object_id(+) = z.network_address_id
          and b.batch_id(+) = bd.batch_id
          and z2.batch_type(+) = b.batch_type
          and z2.batch_type is null
          and rownum <= v_phones_batch_size
        ;
        ------------------------------
      else
        ------------------------------
        select /*+ ordered use_hash(t) full(pn) full(t)*/
            pn.network_address_id,
            v_i.status_code_to
          bulk collect into v_na_id, v_status
          from phone_number pn,
               (select column_value network_address_id from table(cast(v_rej_numbers as ct_number))) t
          where 1 = 1
          and t.network_address_id(+) = pn.network_address_id
          and t.network_address_id is null
          and pn.net_address_status_code = v_i.status_code_from
          and pn.date_of_status_change <= v_date - util_pkg.date_dif_from_seconds(v_i.auto_trans_timeout)
          and rownum <= v_phones_batch_size
        ;
        ------------------------------
      end if;
      ------------------------------
      exit when util_pkg.get_count_ct_number(v_na_id) = 0;
      ------------------------------
      util_pkg.resize_ct_date(v_ct_date, util_pkg.get_count_ct_number(v_na_id));
      util_pkg.resize_ct_number(v_ct_user_id, util_pkg.get_count_ct_number(v_na_id));
      ------------------------------
      util_pkg.fill_ct_date(v_ct_date, v_date);
      util_pkg.fill_ct_number(v_ct_user_id, v_user_id);
      ------------------------------
      v_res_set_na_status := util_ext_ri.set_na_status
      (
        p_na_id => v_na_id,
        p_status => v_status,
        p_date => v_ct_date,
        p_user_id => v_ct_user_id,
        p_break_on_error => false,
        p_lock_pn => true,
        p_error_code => v_error_code,
        p_error_message => v_error_message
      );
      ------------------------------
      select /*+ full(z)*/
        network_address_id
        bulk collect into v_tmp
        from
          (select column_value network_address_id, rownum rn from table(cast(v_na_id as ct_number))) q1,
          (select column_value error_code, rownum rn from table(cast(v_error_code as ct_number))) q2
        where 1 = 1
        and q2.rn(+) = q1.rn
        and error_code <> util_pkg.c_ora_ok
      ;
      ------------------------------
      util_pkg.add_ct_number(v_rej_numbers, v_tmp);
      ------------------------------
      commit;
      ------------------------------
      exit when util_pkg.get_count_ct_number(v_na_id) < v_phones_batch_size;
      ------------------------------
    end loop;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Access_Point_Per_Host(p_date date := sysdate)
is
  v_date date := nvl(p_date, sysdate);
  v_delimiter varchar2(1):= ',';
  v_host_ids ri_settings.setting_value%type;
  v_arr_host_id_chr ct_varchar;
  v_arr_host_id ct_number;
begin
  ------------------------------
  v_host_ids := install_pkg.nnget_option_str(c_sett_host_ids_for_ap, NULL, c_def_host_ids_for_ap);
  ------------------------------
  if v_host_ids = c_def_host_ids_for_ap
  then
    return;
  end if;
  ------------------------------
  v_arr_host_id_chr := util_pkg.split_string(v_host_ids, v_delimiter);
  ------------------------------
  v_arr_host_id := util_pkg.cast_ct_varchar2ct_number(v_arr_host_id_chr, TRUE);
  ------------------------------
  UPDATE /*+ INDEX(aphs I_APHS_DATE)*/
          ACCESS_POINT_HOST_STATISTICS aphs
     SET aphs.date_to = v_date
   WHERE v_date between aphs.date_from and aphs.date_to
  ;
  ------------------------------
  INSERT INTO ACCESS_POINT_HOST_STATISTICS(HOST_ID,
                                           ACCESS_POINT_COUNT,
                                           DATE_FROM,
                                           DATE_TO)
      SELECT /*+ ordered use_hash(pah, appa) full(pah) full(appa)*/
             d.host_id,
             COUNT(appa.access_point_id) as cnt_of_access_point,
             v_date as date_from,
             UTIL_PKG.c_open_date_to as date_to
        FROM (SELECT /*+ ordered use_nl(ht, h) index(h PK_HOST)*/
                     ht.column_value AS host_id
                FROM TABLE(v_arr_host_id ) ht
                     JOIN host h ON (ht.column_value = h.host_id)
             )d LEFT JOIN
             personal_account_history pah ON (d.host_id = pah.balance_storage
                                               AND v_date BETWEEN pah.start_date AND NVL(pah.end_date, v_date))
             LEFT JOIN
             access_point_personal_account appa ON(pah.personal_account = appa.personal_account
                                                   AND v_date BETWEEN appa.from_date AND NVL(appa.to_date, v_date))
       WHERE 1=1
       GROUP BY d.host_id
  ;
  ------------------------------
  COMMIT;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Get_APoint_Per_Host_Stat
(
    p_host_tcodes util_pkg.cit_varchar_s,
    p_src_date date := sysdate,
    p_src_option integer := c_all_apoint,
    p_error_code out number,
    p_error_message out varchar2,
    p_result out sys_refcursor
)
is
  v_cnt integer;
  v_max_cnt_of_apoint integer;
  v_min_cnt_of_apoint integer;
  v_option_value integer;
  v_arr_nt ct_varchar_s;
begin
  ------------------------------
  if util_pkg.CheckP_cit_varchar_s(p_host_tcodes)
  then
    ------------------------------
    v_arr_nt := util_pkg.cast_cit2ct_varchar_s(p_host_tcodes, true);
    ------------------------------
    SELECT /*+ ORDERED use_hash(ht h aphs) INDEX(aphs I_APHS_HOST_ID)*/
             max(aphs.access_point_count) as max_cnt_of_apoint,
             min(aphs.access_point_count) as min_cnt_of_apoint,
             count(1) as cnt_of_rec
        INTO v_max_cnt_of_apoint,
             v_min_cnt_of_apoint,
             v_cnt
        FROM TABLE(v_arr_nt)ht JOIN
             host h ON(ht.column_value = h.host_type_code)JOIN
             access_point_host_statistics aphs ON( h.host_id = aphs.host_id)
       WHERE 1=1
         AND p_src_date BETWEEN aphs.date_from AND aphs.date_to
    ;
    ------------------------------
    if v_cnt != 0
    then
      ------------------------------
      CASE p_src_option
        WHEN c_all_apoint          THEN v_option_value := NULL;
        WHEN c_min_count_of_apoint THEN v_option_value := v_min_cnt_of_apoint;
        WHEN c_max_count_of_apoint THEN v_option_value := v_max_cnt_of_apoint;
        ELSE v_option_value := NULL;
      END CASE;
      ------------------------------
      open p_result for
              SELECT /*+ ORDERED use_hash(ht aphs) INDEX(aphs I_APHS_HOST_ID)*/
                     aphs.host_id
                     ,h.host_name
                     ,h.host_code
                     ,h.host_type_code
                     ,aphs.access_point_count
                FROM TABLE(v_arr_nt)ht JOIN
                     host h ON(ht.column_value = h.host_type_code)JOIN
                     access_point_host_statistics aphs ON(h.host_id = aphs.host_id
                                                          AND p_src_date BETWEEN aphs.date_from AND aphs.date_to
                                                         )
               WHERE 1=1
                 AND NVL(v_option_value, aphs.access_point_count) = aphs.access_point_count
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    SELECT  /*+ INDEX(aphs I_APHS_HOST_ID)*/
             max(aphs.access_point_count) as max_cnt_of_apoint,
             min(aphs.access_point_count) as min_cnt_of_apoint,
             count(1) as cnt_of_rec
        INTO v_max_cnt_of_apoint,
             v_min_cnt_of_apoint,
             v_cnt
        FROM access_point_host_statistics aphs
       WHERE 1=1
         AND p_src_date BETWEEN aphs.date_from AND aphs.date_to
    ;
    ------------------------------
    if v_cnt != 0
    then
      ------------------------------
      CASE p_src_option
        WHEN c_all_apoint          THEN v_option_value := NULL;
        WHEN c_min_count_of_apoint THEN v_option_value := v_min_cnt_of_apoint;
        WHEN c_max_count_of_apoint THEN v_option_value := v_max_cnt_of_apoint;
        ELSE v_option_value := NULL;
      END CASE;
      ------------------------------
      open p_result for
                 SELECT /*+ INDEX(aphs I_APHS_HOST_ID)*/
                        aphs.host_id
                        ,h.host_name
                        ,h.host_code
                        ,h.host_type_code
                        ,aphs.access_point_count
                   FROM access_point_host_statistics aphs JOIN
                        host h ON(h.host_id = aphs.host_id)
                  WHERE 1=1
                    AND p_src_date BETWEEN aphs.date_from AND aphs.date_to
                    AND NVL(v_option_value, aphs.access_point_count) = aphs.access_point_count
      ;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure mnp_prepare_new_phone2return
is
  v_sp_name varchar2(30);
  v_sp_name2 varchar2(30);
  v_user_id number;
  v_date date := sysdate;
  v_expire_period number;
  v_expire_date date;
  v_cursor sys_refcursor;
  --
  v_phones_batch_size number;
  v_phones_total_count number;
  v_na_id number;
  v_batch_id number;
  v_cnt number;
  v_in_batch_cnt number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  v_user_id := util_ri.xget_default_user_id;
  ------------------------------
  v_phones_batch_size := install_pkg.nnget_option_num(c_sett_mnp_ph_ret_batch_size, c_def_mnp_ph_ret_batch_size);
  ------------------------------
  v_phones_total_count := install_pkg.nnget_option_num(c_sett_mnp_ph_cnt_ret_per_job, c_def_mnp_ph_cnt_ret_per_job);
  ------------------------------
  v_expire_period := install_pkg.nnget_option_num(c_sett_mnp_ph_return_delay, c_def_mnp_ph_return_delay);
  ------------------------------
  v_expire_date := v_date - util_pkg.date_dif_from_seconds(v_expire_period);
  ------------------------------
  v_cnt := 0;
  v_in_batch_cnt := 0;
  v_batch_id := null;
  ------------------------------
  v_cursor := util_ri.get_pn_cursor_by_status
  (
    p_status => util_ri.c_NASH_CODE_CLOSE,
    p_date => v_expire_date
  );
  ------------------------------
  loop
    ------------------------------
    exit when (v_cnt >= v_phones_total_count);
    ------------------------------
    fetch v_cursor into v_na_id;
    ------------------------------
    exit when v_cursor%notfound;
    ------------------------------
    begin
      ------------------------------
      v_sp_name2 := util_sys_pkg.make_savepoint;
      ------------------------------
      util_ri.xlock_1pn(v_na_id);
      ------------------------------
      mnp_pkg.mnp_port_out2_i
      (
        p_na_id => v_na_id,
        p_date => v_date,
        p_user_id => v_user_id
      );
      ------------------------------
      if v_batch_id is null
      then
        ------------------------------
        v_batch_id := batch_pkg.batch_ins(batch_pkg.c_BATCH_TYPE_NA_MNP_RETURN, v_date, util_pkg.c_open_date_to, v_user_id);
        ------------------------------
      end if;
      ------------------------------
      batch_pkg.na_mnp_batch_add_to2(v_batch_id, v_na_id, v_user_id);
      ------------------------------
    exception
    when others then
      ------------------------------
      util_sys_pkg.rollback_savepoint(v_sp_name2);
      ------------------------------
      continue;
      ------------------------------
    end;
    ------------------------------
    v_cnt := v_cnt + 1;
    v_in_batch_cnt := v_in_batch_cnt + 1;
    ------------------------------
    if v_in_batch_cnt >= v_phones_batch_size
    then
      ------------------------------
      commit;
      ------------------------------
      v_sp_name := util_sys_pkg.make_savepoint;
      ------------------------------
      v_in_batch_cnt := 0;
      v_batch_id := null;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  if v_cursor%isopen
  then
    close v_cursor;
  end if;
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  if v_cursor%isopen
  then
    close v_cursor;
  end if;
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure mnp_retry_sent_phone2return
is
  v_sp_name varchar2(30);
  v_user_id number;
  v_date date := sysdate;
  v_expire_period number;
  v_expire_date date;
  --
  v_batch_id number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  v_user_id := util_ri.xget_default_user_id;
  ------------------------------
  v_expire_period := install_pkg.nnget_option_num(c_sett_mnp_ph_batch_expire, c_def_mnp_ph_batch_expire);
  ------------------------------
  v_expire_date := v_date - util_pkg.date_dif_from_seconds(v_expire_period);
  ------------------------------
  loop
    ------------------------------
    v_batch_id := batch_pkg.get_first_batch_by_status
    (
      p_status => batch_pkg.c_bs_process,
      p_type => batch_pkg.c_BATCH_TYPE_NA_MNP_RETURN,
      p_date => v_expire_date
    );
    ------------------------------
    exit when v_batch_id is null;
    ------------------------------
    batch_pkg.na_mnp_batch_reset_status(v_batch_id, v_user_id);
    ------------------------------
    commit;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure auto_mnp_prepare_phone2return
is
begin
  ------------------------------
  mnp_retry_sent_phone2return;
  ------------------------------
  mnp_prepare_new_phone2return;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure auto_mnp_del_complete_batch
is
  v_sp_name2 varchar2(30);
  v_user_id number;
  v_date date := sysdate;
  v_expire_period number;
  v_expire_date date;
  v_cursor sys_refcursor;
  v_piece_size number;
  v_piece_count number;
  --
  v_batch_id number;
  v_batch batch%rowtype;
begin
  ------------------------------
  v_user_id := util_ri.xget_default_user_id;
  ------------------------------
  v_expire_period := install_pkg.nnget_option_num(c_sett_mnp_keep_complete_batch, c_def_mnp_keep_complete_batch);
  v_piece_size := install_pkg.nnget_option_num(c_sett_mnp_kp_cmplt_btch_piece, c_def_mnp_kp_cmplt_btch_piece);
  ------------------------------
  v_expire_date := v_date - util_pkg.date_dif_from_seconds(v_expire_period);
  ------------------------------
  v_cursor := batch_pkg.get_expired_batch_cursor2
  (
    p_type => batch_pkg.c_BATCH_TYPE_NA_MNP_RETURN,
    p_date => v_expire_date
  );
  ------------------------------
  v_piece_count := 0;
  ------------------------------
  loop
    ------------------------------
    fetch v_cursor into v_batch_id;
    ------------------------------
    exit when v_cursor%notfound;
    ------------------------------
    begin
      ------------------------------
      v_sp_name2 := util_sys_pkg.make_savepoint;
      ------------------------------
      v_batch := vp_batch.xlock_get1(v_batch_id);
      ------------------------------
      batch_pkg.na_mnp_batch_del_full(v_batch.batch_id, v_user_id);
      ------------------------------
      commit;
      ------------------------------
      v_piece_count := v_piece_count + 1;
      ------------------------------
      exit when v_piece_size > 0 and v_piece_count >= v_piece_size; --!_! v_piece_size <= 0 - infinitely
      ------------------------------
    exception
    when others then
      ------------------------------
      util_sys_pkg.rollback_savepoint(v_sp_name2);
      ------------------------------
      continue;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
  if v_cursor%isopen
  then
    close v_cursor;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure auto_mnp_po_expired
is
  v_sp_name2 varchar2(30);
  --!_!v_user_id number;
  v_date date := sysdate;
  v_expire_period number;
  v_expire_date date;
  v_cursor sys_refcursor;
  v_piece_size number;
  v_piece_count number;
  --
  v_na_id number;
  v_date_from date;
  v_rec phone_operator%rowtype;
begin
  ------------------------------
  --!_!v_user_id := util_ri.xget_default_user_id;
  ------------------------------
  v_expire_period := install_pkg.nnget_option_num(c_sett_mnp_po_expired_sec, c_def_mnp_po_expired_sec);
  v_piece_size := install_pkg.nnget_option_num(c_sett_mnp_po_expired_piece, c_def_mnp_po_expired_piece);
  ------------------------------
  v_expire_date := v_date - util_pkg.date_dif_from_seconds(v_expire_period);
  ------------------------------
  v_cursor := mnp_pkg.get_expired_phone_operator
  (
    p_expire_date => v_expire_date
  );
  ------------------------------
  v_piece_count := 0;
  ------------------------------
  loop
    ------------------------------
    fetch v_cursor into v_na_id, v_date_from;
    ------------------------------
    exit when v_cursor%notfound;
    ------------------------------
    begin
      ------------------------------
      v_sp_name2 := util_sys_pkg.make_savepoint;
      ------------------------------
      v_rec := vp_phone_operator.xlock_get1(v_na_id, v_date_from);
      ------------------------------
      if v_rec.network_address_id is not null
      then
        ------------------------------
        vp_phone_operator.drop_date_to_act(v_na_id, v_date_from);
        ------------------------------
      end if;
      ------------------------------
      commit;
      ------------------------------
      v_piece_count := v_piece_count + 1;
      ------------------------------
      exit when v_piece_size > 0 and v_piece_count >= v_piece_size; --!_! v_piece_size <= 0 - infinitely
      ------------------------------
    exception
    when others then
      ------------------------------
      util_sys_pkg.rollback_savepoint(v_sp_name2);
      ------------------------------
      continue;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
  if v_cursor%isopen
  then
    close v_cursor;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure auto_split_po_parts(p_date date)
is
  lc_stable_top_part_count constant number := 2; --!_! PO_NOTACTIVE, PO_ACTIVE
  lc_part_name_4split constant varchar2(30) := 'PO_NOTACTIVE';
  --
  v_table_name varchar2(30) := VP_PHONE_OPERATOR.c_this_name;
  v_rec_ptable user_part_tables%rowtype;
  v_rec_part_last user_tab_partitions%rowtype;
  --
  v_use_expired_width boolean;
  v_part_active_dif number;
  v_part_archive_dif number;
  v_parts_stable_dif number;
  v_part_month_round_up boolean;
  v_part_arc_init_date date;
  v_part_part_name_fmt varchar2(100);
  v_part_rebuild_inds boolean;
  --
  v_date_dif_stable number;
  v_date_arc_expiration date;
  v_old_high_value date;
  v_new_high_value date;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  --!_!v_user_id := util_ri.xget_default_user_id;
  ------------------------------
  v_rec_ptable := install_pkg.get_part_table(v_table_name);
  ------------------------------
  if v_rec_ptable.table_name is null
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || 'part_table' || util_pkg.c_msg_delim02 || VP_PHONE_OPERATOR.c_this_name);
    ------------------------------
  end if;
  ------------------------------
  v_use_expired_width := install_pkg.nnget_option_bool(c_opt_part_po_use_expird_width, c_def_part_po_use_expird_width);
  v_part_active_dif := util_pkg.date_dif_from_seconds(install_pkg.nnget_option_num(c_sett_mnp_po_expired_sec, c_def_mnp_po_expired_sec));
  v_part_archive_dif := util_pkg.date_dif_from_days(install_pkg.nnget_option_num(c_opt_part_po_arc_width_days, c_def_part_po_arc_width_days));
  v_parts_stable_dif := util_pkg.date_dif_from_days(install_pkg.nnget_option_num(c_opt_part_po_stabl_width_days, c_def_part_po_stabl_width_days));
  v_part_month_round_up := install_pkg.nnget_option_bool(c_opt_part_po_month_rnd_up, c_def_part_po_month_rnd_up);
  v_part_arc_init_date := install_pkg.nnget_option_date(c_opt_part_po_arc_init_date, c_def_part_po_arc_init_date);
  v_part_part_name_fmt := install_pkg.nnget_option_str(c_opt_part_po_part_name_fmt, NULL, c_def_part_po_part_name_fmt);
  v_part_rebuild_inds := install_pkg.nnget_option_bool(c_opt_part_po_rebuild_inds, c_def_part_po_rebuild_inds);
  ------------------------------
  if v_use_expired_width
  then
    ------------------------------
    v_date_dif_stable := v_part_active_dif + v_part_archive_dif; --!_! PO_ACTIVE + PO_NOTACTIVE; PO_NOTACTIVE - special (stable) archive partition
    ------------------------------
  else
    ------------------------------
    v_date_dif_stable := v_parts_stable_dif;
    ------------------------------
  end if;
  ------------------------------
  v_date_arc_expiration := p_date - (v_date_dif_stable + v_part_archive_dif); --!_! v_date - (stable parts + new arc part)
  ------------------------------
  if v_rec_ptable.partition_count <= lc_stable_top_part_count --!_! initial state
  then
    ------------------------------
    if p_date <= v_part_arc_init_date
    then
      ------------------------------
      return;
      ------------------------------
    end if;
    ------------------------------
    v_new_high_value := v_part_arc_init_date;
    ------------------------------
  else
    ------------------------------
    v_rec_part_last := install_pkg.get_tab_partition2(v_table_name, v_rec_ptable.partition_count - lc_stable_top_part_count); --!_! max part excluding stable parts
    ------------------------------
    v_old_high_value := install_pkg.eval_as_date(v_rec_part_last.high_value);
    ------------------------------
    if v_date_arc_expiration < v_old_high_value
    then
      ------------------------------
      return;
      ------------------------------
    end if;
    ------------------------------
    v_new_high_value := v_old_high_value + v_part_archive_dif;
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and v_part_month_round_up
    and v_new_high_value != util_pkg.month_begin(v_new_high_value)
  then
    ------------------------------
    v_new_high_value := util_pkg.month_next_begin(v_new_high_value);
    ------------------------------
  end if;
  ------------------------------
  install_pkg.split_partition_down_date
  (
    p_table_name => v_table_name,
    p_partition_name => lc_part_name_4split,
    p_bottom_high_value => v_new_high_value,
    p_bottom_part_name_date_fmt => v_part_part_name_fmt,
    p_rebuild_ind_partitions => v_part_rebuild_inds
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure auto_unreg_roaming_cache_group
is
  --
  v_user_id number;
  v_date date := sysdate;
  v_expire_period number;
  v_expire_date date;
  --
  v_dsc ct_varchar;
  v_date1 ct_date;
  v_main_count number;
  --
begin
  ------------------------------
  v_user_id := util_ri.xget_default_user_id;
  ------------------------------
  v_expire_period := install_pkg.nnget_option_num(c_opt_rc_group_expire, c_def_rc_group_expire);
  ------------------------------
  v_expire_date := v_date - util_pkg.date_dif_from_seconds(v_expire_period);
  ------------------------------
  roaming_cache_pkg.get_cache_activity_date
  (
    p_date => v_date,
    p_dsc => v_dsc,
    p_date1 => v_date1
  );
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar(v_dsc);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    begin
      ------------------------------
      if v_date1(v_i) < v_expire_date
      then
        roaming_cache_pkg.at_unreg_roam_cache_subscr(v_dsc(v_i), v_user_id);
      end if;
      ------------------------------
    exception
    when others then
      ------------------------------
      null;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure auto_rem_roaming_cache_group
is
  --
  v_user_id number;
  v_date date := sysdate;
  v_delay_period number;
  v_delay_date date;
  --
  v_dsc ct_varchar;
  v_date_to ct_date;
  v_main_count number;
  --
begin
  ------------------------------
  v_user_id := util_ri.xget_default_user_id;
  ------------------------------
  v_delay_period := install_pkg.nnget_option_num(c_opt_rc_del_group_delay, c_def_rc_del_group_delay);
  ------------------------------
  v_delay_date := v_date - util_pkg.date_dif_from_seconds(v_delay_period);
  ------------------------------
  roaming_cache_pkg.get_expired_cache
  (
    p_date => v_date,
    p_delay_date => v_delay_date,
    p_dsc => v_dsc,
    p_date_to => v_date_to
  );
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar(v_dsc);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    begin
      ------------------------------
      roaming_cache_pkg.at_remove_roam_cache_subscr(v_dsc(v_i), v_date_to(v_i), v_user_id);
      ------------------------------
    exception
    when others then
      ------------------------------
      null;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
