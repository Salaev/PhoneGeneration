CREATE package API_RI_I_PKG is

----------------------------------!---------------------------------------------
  procedure get_salability_cat_rules
  (
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure get_phone_number_decomposition
  (
    p_msisdns ct_varchar_s,
    p_country_code out ct_varchar_s,
    p_area_code out ct_varchar_s,
    p_local_phone out ct_varchar_s,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  );

----------------------------------!---------------------------------------------
  procedure GetSimCardStatusHistChanges
  (
    p_iccid varchar2,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure create_msisdn_by_number_for_ps
  (
    p_msisdns ct_varchar_s,
    p_date date,
    p_date_reserved date,
    p_user_id number,
    p_break_on_error boolean,
    p_reserve_number out number,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

----------------------------------!---------------------------------------------
  procedure open_network_operator_srvc
  (
    p_no_ids ct_number,
    p_svc_codes ct_varchar_s,
    p_date_from ct_date,
    p_date_to ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure close_network_operator_srvc
  (
    p_no_ids ct_number,
    p_svc_codes ct_varchar_s,
    p_old_date_from ct_date,
    p_old_date_to ct_date,
    p_date_from ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure get_network_operator_srvc
  (
    p_no_id integer,
    p_date date,
    p_no_date boolean,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure get_uprs_member_code_by_phone
  (
    p_msisdn varchar2,
    p_validity_date date,
    p_uprs_member_code out varchar2,
    p_net_operator_name out varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure prod_check_sim_list_i
  (
    p_host_id number,
    p_net_op_id number,
    p_iccid_without_control_digit ct_varchar_s,
    p_iccid out ct_varchar_s,
    p_imsi out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

----------------------------------!---------------------------------------------
  procedure create_sim_cards_on_host
  (
    p_host_id number,
    p_iccid ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_ki ct_nvarchar_s,
    p_auth_type ct_varchar_s,
    p_sim_card_type_code varchar2,
    p_user_id number,
    p_date date,
    p_imsi out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure create_sim_cards
  (
    p_msisdn_list ct_varchar_s,
    p_iccid_list ct_varchar_s,
    p_pin_list ct_varchar_s,
    p_pin2_list ct_varchar_s,
    p_puk_list ct_varchar_s,
    p_puk2_list ct_varchar_s,
    p_ki_list ct_nvarchar_s,
    p_auth_type_list ct_varchar_s,
    p_sim_card_type_code varchar2,
    p_user_id number,
    p_imsi out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

----------------------------------!---------------------------------------------
  procedure cancel_param_sim_cards
  (
    p_iccid_list ct_varchar_s,
    p_user_id number,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

----------------------------------!---------------------------------------------
  procedure get_series_cont_free_phones
  (
    p_host_id ct_number,
    p_host_empty boolean,
    p_network_operator_id number,
    p_phone_number_type varchar2,
    p_salability_category ct_varchar_s,
    p_phone_number_status_code ct_varchar_s,
    p_use_linked number,
    p_ps_id out ct_number,
    p_pn_count out ct_number
  );

  procedure get_series_cont_free_phones2
  (
    p_host_id ct_number,
    p_host_empty boolean,
    p_network_operator_code varchar2,
    p_phone_number_type varchar2,
    p_salability_category ct_varchar_s,
    p_phone_number_status_code ct_varchar_s,
    p_use_linked number,
    p_ps_id out ct_number,
    p_pn_count out ct_number
  );

----------------------------------!---------------------------------------------
  procedure get_ap_host_smart
  (
    p_ap_ids ct_number,
    p_host_type_code varchar2,
    p_date date,
    p_get_subhosts boolean,
    p_host_ids out ct_number,
    p_subhost_ids out ct_number
  );

  procedure get_imsi_host_smart
  (
    p_imsis ct_varchar_s,
    p_host_type_code varchar2,
    p_date date,
    p_get_subhosts boolean,
    p_host_ids out ct_number,
    p_subhost_ids out ct_number
  );

  procedure get_iccid_host_smart_ex
  (
    p_iccids ct_varchar_s,
    p_host_type_code varchar2,
    p_date date,
    p_get_subhosts boolean,
    p_host_ids out ct_number,
    p_subhost_ids out ct_number,
    p_no_ids out ct_number
  );

  procedure get_na_host_smart
  (
    p_na_ids ct_number,
    p_host_type_code varchar2,
    p_date date,
    p_get_subhosts boolean,
    p_host_ids out ct_number,
    p_subhost_ids out ct_number
  );

  procedure get_msisdn_host_smart
  (
    p_msisdns ct_varchar_s,
    p_host_type_code varchar2,
    p_date date,
    p_get_subhosts boolean,
    p_host_ids out ct_number,
    p_subhost_ids out ct_number
  );

----------------------------------!---------------------------------------------
  function get_cur_ap_pahost_smart
  (
    p_ap_ids ct_number
  ) return ct_number;

  function get_cur_imsi_pahost_smart
  (
    p_imsis ct_varchar_s
  ) return ct_number;

  function get_cur_na_pahost_smart
  (
    p_na_ids ct_number
  ) return ct_number;

  function get_cur_msisdn_pahost_smart
  (
    p_msisdns ct_varchar_s
  ) return ct_number;

----------------------------------!---------------------------------------------

end;
/
