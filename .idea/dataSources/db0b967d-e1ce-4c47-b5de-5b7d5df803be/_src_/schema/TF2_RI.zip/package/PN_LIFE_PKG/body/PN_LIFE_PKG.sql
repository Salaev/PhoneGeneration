CREATE package body pn_life_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xvalidate_action_type(p_action_type number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_action_type not in (c_act_type_auto, c_act_type_accept, c_act_type_reject), 'p_action_type not in (c_act_type_auto, c_act_type_accept, c_act_type_reject)');
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_current_change(p_change_date date, p_date date) return boolean
is
begin
  ------------------------------
  if p_change_date between p_date and p_date + g_now_margin_right
  then
    return true;
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_future_change(p_change_date date, p_date date) return boolean
is
begin
  ------------------------------
  if p_change_date > p_date + g_now_margin_right
  then
    return true;
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_future_open(p_date_from date, p_date date) return boolean
is
begin
  ------------------------------
  return is_future_change(p_date_from, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_future_close(p_date_to date, p_date date) return boolean
is
begin
  ------------------------------
  if util_ri.is_date_open(p_date_to)
  then
    return false;
  end if;
  ------------------------------
  return is_future_change(p_date_to, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_current_version(p_date_from date, p_date_to date, p_date date) return boolean
is
begin
  ------------------------------
  if is_future_open(p_date_from, p_date)
  then
    return false;
  end if;
  ------------------------------
  if util_ri.is_date_open(p_date_to)
  then
    return true;
  end if;
  ------------------------------
  if is_future_close(p_date_to, p_date)
  then
    return true;
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_act_accept_change_type(p_date_from date, p_date_to date, p_date date) return number
is
begin
  ------------------------------
  if is_current_version(p_date_from, p_date_to, p_date)
  then
    return c_ch_type_open;
  end if;
  ------------------------------
  if is_current_change(p_date_to, p_date)
  then
    return c_ch_type_close;
  end if;
  ------------------------------
  return c_ch_type_none;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_act_reject_change_type(p_date_from date, p_date_to date, p_date date) return number
is
begin
  ------------------------------
  if is_current_version(p_date_from, p_date_to, p_date)
  then
    return c_ch_type_close;
  end if;
  ------------------------------
  return c_ch_type_none;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_act_auto_change_type(p_date_from date, p_date_to date, p_date date) return number
is
begin
  ------------------------------
  util_loc_pkg.touch_date(p_date_from);
  util_loc_pkg.touch_date(p_date);
  ------------------------------
  if util_ri.is_date_open(p_date_to)
  then
    return c_ch_type_open;
  end if;
  ------------------------------
  return c_ch_type_close;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_change_type(p_action_type number, p_date_from date, p_date_to date, p_date date) return number
is
  v_res number;
begin
  ------------------------------
  xvalidate_action_type(p_action_type);
  ------------------------------
  if p_action_type = c_act_type_accept
  then
    ------------------------------
    v_res := get_act_accept_change_type(p_date_from, p_date_to, p_date);
    ------------------------------
  elsif p_action_type = c_act_type_reject
  then
    ------------------------------
    v_res := get_act_reject_change_type(p_date_from, p_date_to, p_date);
    ------------------------------
  else
    ------------------------------
    v_res := get_act_auto_change_type(p_date_from, p_date_to, p_date);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_change_date(p_action_type number, p_change_type number, p_date_from date, p_date_to date) return date
is
  v_res date;
begin
  ------------------------------
  xvalidate_action_type(p_action_type);
  ------------------------------
  if p_change_type = c_ch_type_close and p_action_type != c_act_type_reject
  then
    v_res := p_date_to + util_pkg.c_second;
  else
    v_res := p_date_from;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_pn_nash(p_na_id number, p_na_stat varchar2, p_date_from date)
is
begin
  ------------------------------
  update /*+ index_asc(z, PK_PHONE_NUMBER)*/
    phone_number z
  set
    net_address_status_code = p_na_stat,
    date_of_status_change = p_date_from
  where 1 = 1
  and network_address_id = p_na_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_pn_pnsc(p_na_id number, p_sal_cat varchar2)
is
begin
  ------------------------------
  update /*+ index_asc(z, PK_PHONE_NUMBER)*/
    phone_number z
  set
    salability_category_code = p_sal_cat
  where 1 = 1
  and network_address_id = p_na_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_pn_naap(p_na_id number, p_ap_id number, p_date_from date)
is
begin
  ------------------------------
  update /*+ index_asc(z, PK_PHONE_NUMBER)*/
    phone_number z
  set
    naap_access_point_id = p_ap_id,
    naap_date_from = p_date_from
  where 1 = 1
  and network_address_id = p_na_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_pn_pl_main(p_na_id number, p_msisdn varchar2)
is
begin
  ------------------------------
  update /*+ index_asc(z, PK_PHONE_NUMBER)*/
    phone_number z
  set
    pl_main_msisdn = p_msisdn
  where 1 = 1
  and network_address_id = p_na_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_pn_pl_link(p_na_id number, p_msisdn varchar2)
is
begin
  ------------------------------
  update /*+ index_asc(z, PK_PHONE_NUMBER)*/
    phone_number z
  set
    pl_linked_msisdn = p_msisdn
  where 1 = 1
  and network_address_id = p_na_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure regch_nash_i(p_rec changes_nash%rowtype, p_change_type number)
is
  v_rec changes_nash%rowtype;
begin
  ------------------------------
  if p_change_type = c_ch_type_close
  then
    RETURN;
  end if;
  ------------------------------
  v_rec := p_rec;
  ------------------------------
  if p_change_type = c_ch_type_open
  then
    v_rec.date_to := util_pkg.c_open_date_to;
  end if;
  ------------------------------
  insert into changes_nash
  values v_rec
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unregch_nash_ii(p_rec changes_nash%rowtype, p_change_type number) return boolean
is
  v_rec changes_nash%rowtype;
begin
  ------------------------------
  if p_change_type = c_ch_type_close
  then
    RETURN true;
  end if;
  ------------------------------
  v_rec := p_rec;
  ------------------------------
  if p_change_type = c_ch_type_open
  then
    v_rec.date_to := util_pkg.c_open_date_to;
  end if;
  ------------------------------
  delete /*+ index_asc(z, I_CHANGES_NASH_NAID)*/
    from changes_nash z
  where 1 = 1
  and network_address_id = v_rec.network_address_id
  and date_from = v_rec.date_from
  and date_to = v_rec.date_to
  and net_address_status_code = v_rec.net_address_status_code
  ;
  ------------------------------
  if sql%rowcount > 0
  then
    return true;
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure unregch_nash_i(p_rec changes_nash%rowtype, p_change_type number)
is
begin
  ------------------------------
  util_loc_pkg.touch_boolean(unregch_nash_ii(p_rec, p_change_type));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function nash2changes(p_rec network_address_status_history%rowtype) return changes_nash%rowtype
is
  v_res changes_nash%rowtype;
begin
  ------------------------------
  v_res.network_address_id := p_rec.network_address_id;
  v_res.date_from := p_rec.start_date;
  v_res.date_to := p_rec.end_date;
  v_res.net_address_status_code := util_ri.valid_code2(p_rec.net_address_status_code);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure regch_pnsc_i(p_rec changes_pnsc%rowtype, p_change_type number)
is
  v_rec changes_pnsc%rowtype;
begin
  ------------------------------
  if p_change_type = c_ch_type_close
  then
    RETURN;
  end if;
  ------------------------------
  v_rec := p_rec;
  ------------------------------
  if p_change_type = c_ch_type_open
  then
    v_rec.date_to := util_pkg.c_open_date_to;
  end if;
  ------------------------------
  insert into changes_pnsc
  values v_rec
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unregch_pnsc_ii(p_rec changes_pnsc%rowtype, p_change_type number) return boolean
is
  v_rec changes_pnsc%rowtype;
begin
  ------------------------------
  if p_change_type = c_ch_type_close
  then
    RETURN true;
  end if;
  ------------------------------
  v_rec := p_rec;
  ------------------------------
  if p_change_type = c_ch_type_open
  then
    v_rec.date_to := util_pkg.c_open_date_to;
  end if;
  ------------------------------
  delete /*+ index_asc(z, I_CHANGES_PNSC_NAID)*/
    from changes_pnsc z
  where 1 = 1
  and network_address_id = v_rec.network_address_id
  and date_from = v_rec.date_from
  and date_to = v_rec.date_to
  and salability_category_code = v_rec.salability_category_code
  ;
  ------------------------------
  if sql%rowcount > 0
  then
    return true;
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure unregch_pnsc_i(p_rec changes_pnsc%rowtype, p_change_type number)
is
begin
  ------------------------------
  util_loc_pkg.touch_boolean(unregch_pnsc_ii(p_rec, p_change_type));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function pnsc2changes(p_rec phone_number_salability_categ%rowtype) return changes_nash%rowtype
is
  v_res changes_pnsc%rowtype;
begin
  ------------------------------
  v_res.network_address_id := p_rec.network_address_id;
  v_res.date_from := p_rec.start_date;
  v_res.date_to := p_rec.end_date;
  v_res.salability_category_code := util_ri.valid_code2(p_rec.salability_category_code);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure regch_naap_i(p_rec changes_naap%rowtype, p_change_type number)
is
  v_rec changes_naap%rowtype;
begin
  ------------------------------
  v_rec := p_rec;
  ------------------------------
  if p_change_type = c_ch_type_open
  then
    v_rec.date_to := util_pkg.c_open_date_to;
  end if;
  ------------------------------
  insert into changes_naap
  values v_rec
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unregch_naap_ii(p_rec changes_naap%rowtype, p_change_type number) return boolean
is
  v_rec changes_naap%rowtype;
begin
  ------------------------------
  v_rec := p_rec;
  ------------------------------
  if p_change_type = c_ch_type_open
  then
    v_rec.date_to := util_pkg.c_open_date_to;
  end if;
  ------------------------------
  delete /*+ index_asc(z, I_CHANGES_NAAP_NAID)*/
    from changes_naap z
  where 1 = 1
  and network_address_id = v_rec.network_address_id
  and access_point_id = v_rec.access_point_id
  and date_from = v_rec.date_from
  and date_to = v_rec.date_to
  and link_type_code = v_rec.link_type_code
  ;
  ------------------------------
  if sql%rowcount > 0
  then
    return true;
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure unregch_naap_i(p_rec changes_naap%rowtype, p_change_type number)
is
begin
  ------------------------------
  util_loc_pkg.touch_boolean(unregch_naap_ii(p_rec, p_change_type));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function naap2changes(p_rec network_address_access_point%rowtype) return changes_naap%rowtype
is
  v_res changes_naap%rowtype;
begin
  ------------------------------
  v_res.network_address_id := p_rec.network_address_id;
  v_res.access_point_id := p_rec.access_point_id;
  v_res.date_from := p_rec.from_date;
  v_res.date_to := util_ri.valid_date_to(p_rec.to_date);
  v_res.link_type_code := util_ri.valid_code2(p_rec.link_type_code);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure use_pn_nash_ii(p_rec changes_nash%rowtype, p_change_date date)
is
begin
  ------------------------------
  set_pn_nash(p_rec.network_address_id, p_rec.net_address_status_code, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure free_pn_nash_ii(p_rec changes_nash%rowtype, p_change_date date)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(p_rec.network_address_id);
  util_loc_pkg.touch_date(p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure change_pn_nash_i(p_rec changes_nash%rowtype, p_action_type number)
is
  v_date date := sysdate;
  v_change_type number;
  v_change_date date;
begin
  ------------------------------
  xvalidate_action_type(p_action_type);
  ------------------------------
  if p_action_type = c_act_type_accept
  then
    ------------------------------
    if is_future_open(p_rec.date_from, v_date)
    then
      regch_nash_i(p_rec, c_ch_type_open);
    end if;
    ------------------------------
    if is_future_close(p_rec.date_to, v_date)
    then
      regch_nash_i(p_rec, c_ch_type_close);
    end if;
    ------------------------------
  end if;
  ------------------------------
  if p_action_type = c_act_type_reject
  then
    ------------------------------
    unregch_nash_i(p_rec, c_ch_type_open);
    ------------------------------
    unregch_nash_i(p_rec, c_ch_type_close);
    ------------------------------
  end if;
  ------------------------------
  v_change_type := get_change_type(p_action_type, p_rec.date_from, p_rec.date_to, v_date);
  ------------------------------
  v_change_date := get_change_date(p_action_type, v_change_type, p_rec.date_from, p_rec.date_to);
  ------------------------------
  if v_change_type = c_ch_type_open
  then
    ------------------------------
    use_pn_nash_ii(p_rec, v_change_date);
    ------------------------------
  elsif v_change_type = c_ch_type_close
  then
    ------------------------------
    free_pn_nash_ii(p_rec, v_change_date);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure accept_pn_nash_i(p_rec changes_nash%rowtype)
is
begin
  ------------------------------
  change_pn_nash_i(p_rec, c_act_type_accept);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure reject_pn_nash_i(p_rec changes_nash%rowtype)
is
begin
  ------------------------------
  change_pn_nash_i(p_rec, c_act_type_reject);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure accept_pn_nash(p_rec network_address_status_history%rowtype)
is
begin
  ------------------------------
  accept_pn_nash_i(nash2changes(p_rec));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure reject_pn_nash(p_rec network_address_status_history%rowtype)
is
begin
  ------------------------------
  reject_pn_nash_i(nash2changes(p_rec));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_diff_nash(p_old network_address_status_history%rowtype, p_new network_address_status_history%rowtype) return boolean
is
begin
  ------------------------------
  if 1 = 1
    and P_OLD.net_address_status_code = P_NEW.net_address_status_code
    and P_OLD.network_address_id = P_NEW.network_address_id
    and P_OLD.start_date = P_NEW.start_date
    and util_ri.valid_date_to(P_OLD.end_date) = util_ri.valid_date_to(P_NEW.end_date)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_pn_nash_flds_aft_ins(p_old network_address_status_history%rowtype, p_new network_address_status_history%rowtype)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(P_OLD.network_address_id);
  ------------------------------
  accept_pn_nash(P_NEW);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_pn_nash_flds_aft_upd(p_old network_address_status_history%rowtype, p_new network_address_status_history%rowtype)
is
begin
  ------------------------------
  if is_diff_nash(P_OLD, P_NEW)
  then
    ------------------------------
    reject_pn_nash(P_OLD);
    ------------------------------
    accept_pn_nash(P_NEW);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_pn_nash_flds_aft_del(p_old network_address_status_history%rowtype, p_new network_address_status_history%rowtype)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(P_NEW.network_address_id);
  ------------------------------
  reject_pn_nash(P_OLD);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure use_pn_pnsc_ii(p_rec changes_pnsc%rowtype, p_change_date date)
is
begin
  ------------------------------
  util_loc_pkg.touch_date(p_change_date);
  ------------------------------
  set_pn_pnsc(p_rec.network_address_id, p_rec.salability_category_code);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure free_pn_pnsc_ii(p_rec changes_pnsc%rowtype, p_change_date date)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(p_rec.network_address_id);
  util_loc_pkg.touch_date(p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure change_pn_pnsc_i(p_rec changes_pnsc%rowtype, p_action_type number)
is
  v_date date := sysdate;
  v_change_type number;
  v_change_date date;
begin
  ------------------------------
  xvalidate_action_type(p_action_type);
  ------------------------------
  if p_action_type = c_act_type_accept
  then
    ------------------------------
    if is_future_open(p_rec.date_from, v_date)
    then
      regch_pnsc_i(p_rec, c_ch_type_open);
    end if;
    ------------------------------
    if is_future_close(p_rec.date_to, v_date)
    then
      regch_pnsc_i(p_rec, c_ch_type_close);
    end if;
    ------------------------------
  end if;
  ------------------------------
  if p_action_type = c_act_type_reject
  then
    ------------------------------
    unregch_pnsc_i(p_rec, c_ch_type_open);
    ------------------------------
    unregch_pnsc_i(p_rec, c_ch_type_close);
    ------------------------------
  end if;
  ------------------------------
  v_change_type := get_change_type(p_action_type, p_rec.date_from, p_rec.date_to, v_date);
  ------------------------------
  v_change_date := get_change_date(p_action_type, v_change_type, p_rec.date_from, p_rec.date_to);
  ------------------------------
  if v_change_type = c_ch_type_open
  then
    ------------------------------
    use_pn_pnsc_ii(p_rec, v_change_date);
    ------------------------------
  elsif v_change_type = c_ch_type_close
  then
    ------------------------------
    free_pn_pnsc_ii(p_rec, v_change_date);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure accept_pn_pnsc_i(p_rec changes_pnsc%rowtype)
is
begin
  ------------------------------
  change_pn_pnsc_i(p_rec, c_act_type_accept);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure reject_pn_pnsc_i(p_rec changes_pnsc%rowtype)
is
begin
  ------------------------------
  change_pn_pnsc_i(p_rec, c_act_type_reject);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure accept_pn_pnsc(p_rec phone_number_salability_categ%rowtype)
is
begin
  ------------------------------
  accept_pn_pnsc_i(pnsc2changes(p_rec));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure reject_pn_pnsc(p_rec phone_number_salability_categ%rowtype)
is
begin
  ------------------------------
  reject_pn_pnsc_i(pnsc2changes(p_rec));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_diff_pnsc(p_old phone_number_salability_categ%rowtype, p_new phone_number_salability_categ%rowtype) return boolean
is
begin
  ------------------------------
  if 1 = 1
    and P_OLD.salability_category_code = P_NEW.salability_category_code
    and P_OLD.network_address_id = P_NEW.network_address_id
    and P_OLD.start_date = P_NEW.start_date
    and util_ri.valid_date_to(P_OLD.end_date) = util_ri.valid_date_to(P_NEW.end_date)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_pn_pnsc_flds_aft_ins(p_old phone_number_salability_categ%rowtype, p_new phone_number_salability_categ%rowtype)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(P_OLD.network_address_id);
  ------------------------------
  accept_pn_pnsc(P_NEW);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_pn_pnsc_flds_aft_upd(p_old phone_number_salability_categ%rowtype, p_new phone_number_salability_categ%rowtype)
is
begin
  ------------------------------
  if is_diff_pnsc(P_OLD, P_NEW)
  then
    ------------------------------
    reject_pn_pnsc(P_OLD);
    ------------------------------
    accept_pn_pnsc(P_NEW);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_pn_pnsc_flds_aft_del(p_old phone_number_salability_categ%rowtype, p_new phone_number_salability_categ%rowtype)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(P_NEW.network_address_id);
  ------------------------------
  reject_pn_pnsc(P_OLD);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure use_pn_naap_ii(p_rec changes_naap%rowtype, p_change_date date)
is
begin
  ------------------------------
  set_pn_naap(p_rec.network_address_id, p_rec.access_point_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure free_pn_naap_ii(p_rec changes_naap%rowtype, p_change_date date)
is
begin
  ------------------------------
  set_pn_naap(p_rec.network_address_id, search_pkg.c_dummy_access_point_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure change_pn_naap_i(p_rec changes_naap%rowtype, p_action_type number)
is
  v_date date := sysdate;
  v_change_type number;
  v_change_date date;
begin
  ------------------------------
  xvalidate_action_type(p_action_type);
  ------------------------------
  if p_action_type = c_act_type_accept
  then
    ------------------------------
    if is_future_open(p_rec.date_from, v_date)
    then
      regch_naap_i(p_rec, c_ch_type_open);
    end if;
    ------------------------------
    if is_future_close(p_rec.date_to, v_date)
    then
      regch_naap_i(p_rec, c_ch_type_close);
    end if;
    ------------------------------
  end if;
  ------------------------------
  if p_action_type = c_act_type_reject
  then
    ------------------------------
    unregch_naap_i(p_rec, c_ch_type_open);
    ------------------------------
    unregch_naap_i(p_rec, c_ch_type_close);
    ------------------------------
  end if;
  ------------------------------
  v_change_type := get_change_type(p_action_type, p_rec.date_from, p_rec.date_to, v_date);
  ------------------------------
  v_change_date := get_change_date(p_action_type, v_change_type, p_rec.date_from, p_rec.date_to);
  ------------------------------
  if v_change_type = c_ch_type_open
  then
    ------------------------------
    use_pn_naap_ii(p_rec, v_change_date);
    ------------------------------
  elsif v_change_type = c_ch_type_close
  then
    ------------------------------
    free_pn_naap_ii(p_rec, v_change_date);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure accept_pn_naap_i(p_rec changes_naap%rowtype)
is
begin
  ------------------------------
  change_pn_naap_i(p_rec, c_act_type_accept);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure reject_pn_naap_i(p_rec changes_naap%rowtype)
is
begin
  ------------------------------
  change_pn_naap_i(p_rec, c_act_type_reject);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure accept_pn_naap(p_rec network_address_access_point%rowtype)
is
begin
  ------------------------------
  accept_pn_naap_i(naap2changes(p_rec));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure reject_pn_naap(p_rec network_address_access_point%rowtype)
is
begin
  ------------------------------
  reject_pn_naap_i(naap2changes(p_rec));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_diff_naap(p_old network_address_access_point%rowtype, p_new network_address_access_point%rowtype) return boolean
is
begin
  ------------------------------
  if 1 = 1
    and P_OLD.access_point_id = P_NEW.access_point_id
    and P_OLD.network_address_id = P_NEW.network_address_id
    --!_!and P_OLD.link_type_code = P_NEW.link_type_code
    and P_OLD.from_date = P_NEW.from_date
    and util_ri.valid_date_to(P_OLD.to_date) = util_ri.valid_date_to(P_NEW.to_date)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_pn_naap_flds_aft_ins(p_old network_address_access_point%rowtype, p_new network_address_access_point%rowtype)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(P_OLD.network_address_id);
  ------------------------------
  accept_pn_naap(P_NEW);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_pn_naap_flds_aft_upd(p_old network_address_access_point%rowtype, p_new network_address_access_point%rowtype)
is
begin
  ------------------------------
  if is_diff_naap(P_OLD, P_NEW)
  then
    ------------------------------
    reject_pn_naap(P_OLD);
    ------------------------------
    accept_pn_naap(P_NEW);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_pn_naap_flds_aft_del(p_old network_address_access_point%rowtype, p_new network_address_access_point%rowtype)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(P_NEW.network_address_id);
  ------------------------------
  reject_pn_naap(P_OLD);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure accept_pn_pl(p_rec phone_link%rowtype)
is
  v_date date := sysdate;
begin
  ------------------------------
  set_pn_pl_link(util_ri.get_na_id2(p_rec.main_msisdn, v_date), p_rec.linked_msisdn);
  ------------------------------
  set_pn_pl_main(util_ri.get_na_id2(p_rec.linked_msisdn, v_date), p_rec.main_msisdn);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure reject_pn_pl(p_rec phone_link%rowtype)
is
  v_date date := sysdate;
begin
  ------------------------------
  set_pn_pl_link(util_ri.get_na_id2(p_rec.main_msisdn, v_date), search_pkg.c_dummy_msisdn);
  ------------------------------
  set_pn_pl_main(util_ri.get_na_id2(p_rec.linked_msisdn, v_date), search_pkg.c_dummy_msisdn);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_diff_pl(p_old phone_link%rowtype, p_new phone_link%rowtype) return boolean
is
begin
  ------------------------------
  if 1 = 1
    and P_OLD.main_msisdn = P_NEW.main_msisdn
    and P_OLD.linked_msisdn = P_NEW.linked_msisdn
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_pn_pl_flds_aft_ins(p_old phone_link%rowtype, p_new phone_link%rowtype)
is
begin
  ------------------------------
  util_loc_pkg.touch_varchar(P_OLD.main_msisdn);
  ------------------------------
  accept_pn_pl(P_NEW);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_pn_pl_flds_aft_upd(p_old phone_link%rowtype, p_new phone_link%rowtype)
is
begin
  ------------------------------
  if is_diff_pl(P_OLD, P_NEW)
  then
    ------------------------------
    reject_pn_pl(P_OLD);
    ------------------------------
    accept_pn_pl(P_NEW);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_pn_pl_flds_aft_del(p_old phone_link%rowtype, p_new phone_link%rowtype)
is
begin
  ------------------------------
  util_loc_pkg.touch_varchar(P_NEW.main_msisdn);
  ------------------------------
  reject_pn_pl(P_OLD);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ctl_changes_nash(p_coll ctl_changes_nash) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_changes_nash(p_date date) return ctl_changes_nash
is
  v_res ctl_changes_nash;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ full(z)*/
    * bulk collect into v_res
  from changes_nash z
  where 1 = 1
  and date_from <= p_date
  order by date_from, network_address_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure proc_changes_nash_i(p_date date, p_commit_batch number)
is
  v_sp_name varchar2(30);
  v_coll ctl_changes_nash;
  v_rec changes_nash%rowtype;
  v_cnt_opt number;
  v_cnt_act number;
  v_cnt_commit_batch number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_commit_batch is null, 'p_commit_batch');
  ------------------------------
  v_coll := get_changes_nash(p_date);
  ------------------------------
  if get_count_ctl_changes_nash(v_coll) = 0
  then
    return;
  end if;
  ------------------------------
  v_cnt_opt := install_pkg.nnget_option_num(c_sett_pendch_nash_bcount, c_def_pendch_nash_bcount);
  ------------------------------
  v_cnt_act := 0;
  v_cnt_commit_batch := 0;
  ------------------------------
  for v_i in v_coll.first..v_coll.last
  loop
    ------------------------------
    v_cnt_act := v_cnt_act + 1;
    ------------------------------
    exit when v_cnt_opt >= 0 and v_cnt_act > v_cnt_opt;
    ------------------------------
    v_rec := v_coll(v_i);
    ------------------------------
    v_sp_name := util_sys_pkg.make_savepoint;
    ------------------------------
    if NOT unregch_nash_ii(v_rec, c_ch_type_auto)
    then
      continue;
    end if;
    ------------------------------
    begin
      ------------------------------
      change_pn_nash_i(v_rec, c_act_type_auto);
      ------------------------------
    exception
    when others then
      ------------------------------
      util_sys_pkg.rollback_savepoint(v_sp_name);
      ------------------------------
    end;
    ------------------------------
    v_cnt_commit_batch := v_cnt_commit_batch + 1;
    ------------------------------
    if p_commit_batch > 0 and v_cnt_commit_batch >= p_commit_batch
    then
      ------------------------------
      COMMIT;
      ------------------------------
      v_cnt_commit_batch := 0;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  if p_commit_batch > 0
  then
    COMMIT;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure proc_changes_nash
is
begin
  ------------------------------
  proc_changes_nash_i(sysdate, c_def_commit_batch_nash);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ctl_changes_pnsc(p_coll ctl_changes_pnsc) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_changes_pnsc(p_date date) return ctl_changes_pnsc
is
  v_res ctl_changes_pnsc;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ full(z)*/
    * bulk collect into v_res
  from changes_pnsc z
  where 1 = 1
  and date_from <= p_date
  order by date_from, network_address_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure proc_changes_pnsc_i(p_date date, p_commit_batch number)
is
  v_sp_name varchar2(30);
  v_coll ctl_changes_pnsc;
  v_rec changes_pnsc%rowtype;
  v_cnt_opt number;
  v_cnt_act number;
  v_cnt_commit_batch number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_commit_batch is null, 'p_commit_batch');
  ------------------------------
  v_coll := get_changes_pnsc(p_date);
  ------------------------------
  if get_count_ctl_changes_pnsc(v_coll) = 0
  then
    return;
  end if;
  ------------------------------
  v_cnt_opt := install_pkg.nnget_option_num(c_sett_pendch_pnsc_bcount, c_def_pendch_pnsc_bcount);
  ------------------------------
  v_cnt_act := 0;
  v_cnt_commit_batch := 0;
  ------------------------------
  for v_i in v_coll.first..v_coll.last
  loop
    ------------------------------
    v_cnt_act := v_cnt_act + 1;
    ------------------------------
    exit when v_cnt_opt >= 0 and v_cnt_act > v_cnt_opt;
    ------------------------------
    v_rec := v_coll(v_i);
    ------------------------------
    v_sp_name := util_sys_pkg.make_savepoint;
    ------------------------------
    if NOT unregch_pnsc_ii(v_rec, c_ch_type_auto)
    then
      continue;
    end if;
    ------------------------------
    begin
      ------------------------------
      change_pn_pnsc_i(v_rec, c_act_type_auto);
      ------------------------------
    exception
    when others then
      ------------------------------
      util_sys_pkg.rollback_savepoint(v_sp_name);
      ------------------------------
    end;
    ------------------------------
    v_cnt_commit_batch := v_cnt_commit_batch + 1;
    ------------------------------
    if p_commit_batch > 0 and v_cnt_commit_batch >= p_commit_batch
    then
      ------------------------------
      COMMIT;
      ------------------------------
      v_cnt_commit_batch := 0;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  if p_commit_batch > 0
  then
    COMMIT;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure proc_changes_pnsc
is
begin
  ------------------------------
  proc_changes_pnsc_i(sysdate, c_def_commit_batch_pnsc);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ctl_changes_naap(p_coll ctl_changes_naap) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_changes_naap(p_date date) return ctl_changes_naap
is
  v_res ctl_changes_naap;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ full(z)*/
    * bulk collect into v_res
  from changes_naap z
  where 1 = 1
  and (1 = 0
    or (date_to = util_pkg.c_open_date_to and date_from <= p_date)
    or (date_to <= p_date)
  )
  order by decode(date_to, util_pkg.c_open_date_to, date_from, date_to), network_address_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure proc_changes_naap_i(p_date date, p_commit_batch number)
is
  v_sp_name varchar2(30);
  v_coll ctl_changes_naap;
  v_rec changes_naap%rowtype;
  v_cnt_opt number;
  v_cnt_act number;
  v_cnt_commit_batch number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_commit_batch is null, 'p_commit_batch');
  ------------------------------
  v_coll := get_changes_naap(p_date);
  ------------------------------
  if get_count_ctl_changes_naap(v_coll) = 0
  then
    return;
  end if;
  ------------------------------
  v_cnt_opt := install_pkg.nnget_option_num(c_sett_pendch_naap_bcount, c_def_pendch_naap_bcount);
  ------------------------------
  v_cnt_act := 0;
  v_cnt_commit_batch := 0;
  ------------------------------
  for v_i in v_coll.first..v_coll.last
  loop
    ------------------------------
    v_cnt_act := v_cnt_act + 1;
    ------------------------------
    exit when v_cnt_opt >= 0 and v_cnt_act > v_cnt_opt;
    ------------------------------
    v_rec := v_coll(v_i);
    ------------------------------
    v_sp_name := util_sys_pkg.make_savepoint;
    ------------------------------
    if NOT unregch_naap_ii(v_rec, c_ch_type_auto)
    then
      continue;
    end if;
    ------------------------------
    begin
      ------------------------------
      change_pn_naap_i(v_rec, c_act_type_auto);
      ------------------------------
    exception
    when others then
      ------------------------------
      util_sys_pkg.rollback_savepoint(v_sp_name);
      ------------------------------
    end;
    ------------------------------
    v_cnt_commit_batch := v_cnt_commit_batch + 1;
    ------------------------------
    if p_commit_batch > 0 and v_cnt_commit_batch >= p_commit_batch
    then
      ------------------------------
      COMMIT;
      ------------------------------
      v_cnt_commit_batch := 0;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  if p_commit_batch > 0
  then
    COMMIT;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure proc_changes_naap
is
begin
  ------------------------------
  proc_changes_naap_i(sysdate, c_def_commit_batch_naap);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
begin
  ------------------------------
  g_now_margin_left := util_pkg.c_second*install_pkg.nnget_option_num(c_sett_pendch_now_margin_l_sec, c_def_pendch_now_margin_l_sec);
  g_now_margin_right := util_pkg.c_second*install_pkg.nnget_option_num(c_sett_pendch_now_margin_r_sec, c_def_pendch_now_margin_r_sec);
  ------------------------------
end;
/
