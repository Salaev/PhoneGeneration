CREATE PACKAGE RSIG_DST_RULE IS

PROCEDURE Get_DST_Rules_List(
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
);

PROCEDURE Insert_DST_Rule
(
  p_country_code          IN DST_RULE.COUNTRY_CODE%TYPE,
  p_DST_name              IN DST_RULE.DST_NAME%TYPE,
  p_date_start_rule_mask  IN DST_RULE.DATE_START_RULE_MASK%TYPE,
  p_date_start            IN DST_RULE.DATE_START%TYPE,
  p_date_end_rule_mask    IN DST_RULE.DATE_END_RULE_MASK%TYPE,
  p_date_end              IN DST_RULE.DATE_END%TYPE,
  p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_DST_rule_id           OUT HOST.HOST_ID%TYPE,
  p_error_code            OUT NUMBER
);

PROCEDURE Delete_DST_Rule
(
  p_DST_Rule_id           IN DST_RULE.DST_RULE_ID%TYPE,
  p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_error_code            OUT NUMBER
);

PROCEDURE Update_DST_Rule
(
  p_DST_Rule_id           IN DST_RULE.DST_RULE_ID%TYPE,
  p_country_code          IN DST_RULE.COUNTRY_CODE%TYPE,
  p_DST_name              IN DST_RULE.DST_NAME%TYPE,
  p_date_start_rule_mask  IN DST_RULE.DATE_START_RULE_MASK%TYPE,
  p_date_start            IN DST_RULE.DATE_START%TYPE,
  p_date_end_rule_mask    IN DST_RULE.DATE_END_RULE_MASK%TYPE,
  p_date_end              IN DST_RULE.DATE_END%TYPE,
  p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_error_code            OUT NUMBER
);

PROCEDURE Get_DST_Rule_By_ID(
  p_DST_Rule_id      IN   DST_RULE.DST_RULE_ID%TYPE,
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
);

PROCEDURE Get_DST_Rule_By_Name(
  p_DST_Name         IN   DST_RULE.DST_NAME%TYPE,
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
);

PROCEDURE Get_Country_List(
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

END RSIG_DST_RULE;
/
