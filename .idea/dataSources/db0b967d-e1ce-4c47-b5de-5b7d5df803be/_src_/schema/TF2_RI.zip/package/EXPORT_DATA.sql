CREATE PACKAGE          "EXPORT_DATA" as

/****************************************************************************
  <header>
    <name>              package EXPORT_DATA
    </name>

    <author>            Lucie Sevcikova
    </author>

    <version>           1.0.0   26/10/2004
                                Lucie Sevcikova
                                created first version
    </version>

    <Description>       package contains procedures, which are necessary
                        for data exporting
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS.ResourceInventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
****************************************************************************/

c_user_id_of_change   CONSTANT VARCHAR2(20)  := '1';

/****************************************************************************
  <header>
    <name>              procedure Export_Data
    </name>

    <author>            Lucie Sevcikova
    </author>

    <version>           1.0.0   26/10/2004
                                Lucie Sevcikova
                                created first version
    </version>

    <Description>       procedure exports data from any table
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS.ResourceInventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Export_Data(
  p_table_name    IN  VARCHAR2,
  p_join          IN  VARCHAR2,
  p_where         IN  VARCHAR2,
  p_result        OUT CLOB
  );

/****************************************************************************
  <header>
    <name>              procedure Export_sim_series
    </name>

    <author>            Lucie Sevcikova
    </author>

    <version>           1.0.0   26/10/2004
                                Lucie Sevcikova
                                created first version
    </version>

    <Description>       procedure exports data from tables SIM_SERIES,
                        SIM_SERIES_STATUS_VALIDITY, ACCESS_POINT,
                        ACCESS_POINT_STATUS_HISTORY and SIM_CARD for given
                        sei_series_id
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS.ResourceInventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Export_sim_series (
  p_sim_series       IN  INT,
  p_result_script    OUT CLOB
  );

end EXPORT_DATA;


/
