CREATE PACKAGE          "PBX" IS
  /****************************************************************************
    <header>
      <name>              package PBX
      </name>

      <author>            Petr Cepek
      </author>

      <version>           1.2.2     11.09.2009   Pavel Vasiliev
                          procedure Get_DDI_By_GDN_And_Ext_List updated
      </version>
      <version>           1.2.1     30.06.2006   Petr Cepek
                          procedure Get_DDI_By_GDN_And_Ext_List updated
      </version>
      <version>           1.2.0   29.03.2006     Petr Cepek
                          procedure Get_PBX_Of_External_Operator created
                          procedure Get_DDI_By_GDN_And_Ext_List updated
      </version>
      <version>           1.1.0   09.01.2005     Petr Cepek
                          procedure Get_DDI_By_GDN_And_Ext_List updated
      </version>
      <version>           1.0.0   14.12.2005     Petr Cepek
                                  created first version
      </version>

      <Description>       Package contains procedures for managing PBX.
      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>
      </Parameters>

    </header>
  ****************************************************************************/
  TYPE t_PN IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
  TYPE t_port IS TABLE OF VARCHAR2(40) INDEX BY BINARY_INTEGER;
  TYPE t_vdate IS TABLE OF DATE INDEX BY BINARY_INTEGER;

/****************************************************************************
<header>
  <name>            procedure Get_DDI_By_GDN_And_Ext_List
  </name>

  <author>          Petr Cepek
  </author>

  <version>         1.3    30.06.2006    Petr Cepek
                    table network_address removed
  </version>
  <version>         1.2    29.3.2006    Petr Cepek
                    fixed problem with same DDI and GDN phone number
  </version>
  <version>         1.1  0.9.01.2005    Petr Cepek
                    input parameter p_date_list is changed to the sysdate when is null,
                    deleted exchange ports are excluded
  </version>
  <version>
                    1.0  14.12.2005 -  created
  </version>

  <Description>     Procedure returns DDI for given list of GDN.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_DDI_By_GDN_And_Ext_List(
   p_GDN_list            IN  t_PN,
   p_Extension_list      IN  t_port,
   p_date_list           IN  t_vdate,
   p_raise_error         IN  CHAR,
   error_code            OUT NUMBER,
   error_message         OUT VARCHAR2,
   result_list           OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure Get_PBX_Of_External_Operator
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  29.3.2006  -  created
  </version>

  <Description>     Procedure returns all PBX for given external network operator.
                    Procedure returns all PBX when no network operator ID is
                    specified.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_PBX_Of_External_Operator(
  p_network_operator_id    IN  network_operator.network_operator_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

END PBX;


/
