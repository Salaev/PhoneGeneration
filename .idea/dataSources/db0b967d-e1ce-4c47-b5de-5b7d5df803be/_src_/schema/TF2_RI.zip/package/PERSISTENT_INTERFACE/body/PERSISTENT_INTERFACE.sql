CREATE package body PERSISTENT_INTERFACE is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function cast_lcit2ct_number(p_coll cit_number) return ct_number
is
  v_coll util_pkg.cit_number;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return null;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_coll(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return util_pkg.cast_cit2ct_number(p_coll => v_coll, p_smart_cit => TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_lcit2ct_date(p_coll cit_date) return ct_date
is
  v_coll util_pkg.cit_date;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return null;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_coll(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return util_pkg.cast_cit2ct_date(p_coll => v_coll, p_smart_cit => TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_lcit2ct_varchar_s(p_coll cit_varchar_s) return ct_varchar_s
is
  v_coll util_pkg.cit_varchar_s;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return null;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_coll(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return util_pkg.cast_cit2ct_varchar_s(p_coll => v_coll, p_smart_cit => TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_lcit2ct_varchar(p_coll cit_varchar) return ct_varchar
is
  v_coll util_pkg.cit_varchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return null;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_coll(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return util_pkg.cast_cit2ct_varchar(p_coll => v_coll, p_smart_cit => TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_lcit2ct_nvarchar_s(p_coll cit_nvarchar_s) return ct_nvarchar_s
is
  v_coll util_pkg.cit_nvarchar_s;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return null;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_coll(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return util_pkg.cast_cit2ct_nvarchar_s(p_coll => v_coll, p_smart_cit => TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_lcit2ct_nvarchar(p_coll cit_nvarchar) return ct_nvarchar
is
  v_coll util_pkg.cit_nvarchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return null;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_coll(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return util_pkg.cast_cit2ct_nvarchar(p_coll => v_coll, p_smart_cit => TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function cast_ct_number2number(p_coll ct_number) return cit_number
is
  v_res cit_number;
begin
  ------------------------------
  if util_pkg.get_count_ct_number(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_date2date(p_coll ct_date) return cit_date
is
  v_res cit_date;
begin
  ------------------------------
  if util_pkg.get_count_ct_date(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_varchar_s2varchar_s(p_coll ct_varchar_s) return cit_varchar_s
is
  v_res cit_varchar_s;
begin
  ------------------------------
  if util_pkg.get_count_ct_varchar_s(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_varchar2varchar(p_coll ct_varchar) return cit_varchar
is
  v_res cit_varchar;
begin
  ------------------------------
  if util_pkg.get_count_ct_varchar(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_nvarchar_s2nvarchar_s(p_coll ct_nvarchar_s) return cit_nvarchar_s
is
  v_res cit_nvarchar_s;
begin
  ------------------------------
  if util_pkg.get_count_ct_nvarchar_s(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_nvarchar2nvarchar(p_coll ct_nvarchar) return cit_nvarchar
is
  v_res cit_nvarchar;
begin
  ------------------------------
  if util_pkg.get_count_ct_nvarchar(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_prefix_replacement
(
  error_code out number,
  p_validity_start_date date,
  p_validity_end_date date,
  p_host_code varchar2,
  p_result out sys_refcursor
)
is
  v_vpool_vlot number;
begin
  ------------------------------
  v_vpool_vlot := util.loop_acquire_vpool_slot(c_VPOOL_GET_PREFIX_REPLACEMENT);
  ------------------------------
  if v_vpool_vlot is null
  then
    ------------------------------
    util_pkg.raise_exception(c_ORA_ACQUIRE_VPOOL_SLOT_FAIL, c_em_ACQUIRE_VPOOL_SLOT_FAIL);
    ------------------------------
  end if;
  ------------------------------
  RSIG_PREFIX_REPLACEMENT.Get_Prefix_Replacement
  (
    error_code => error_code,
    p_validity_start_date => p_validity_start_date,
    p_validity_end_date => p_validity_end_date,
    p_host_code => p_host_code,
    p_result => p_result
  );
  ------------------------------
  util_loc_pkg.touch_boolean(util.release_vpool_slot(c_VPOOL_GET_PREFIX_REPLACEMENT, v_vpool_vlot));
  ------------------------------
  error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  error_code := util_pkg.get_err_code;
  ------------------------------
  util_loc_pkg.touch_boolean(util.release_vpool_slot(c_VPOOL_GET_PREFIX_REPLACEMENT, v_vpool_vlot));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure reports_get_net_op_neighbours
(
  p_network_operator_codes cit_varchar_s,
  p_date date,
  p_result_list out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  report.get_net_op_neighbours
  (
    p_network_operator_codes => cast_lcit2ct_varchar_s(p_network_operator_codes),
    p_date => p_date,
    p_result_list => p_result_list,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure delete_last_open_previous
(
  p_phone_list cit_varchar_s,
  p_user_login varchar2,
  p_error_code out number,
  p_error_message out varchar2,
  p_result_list out sys_refcursor
)
is
begin
  ------------------------------
  phone_number_pck.delete_last_open_previous_int
  (
    p_msisdn => cast_lcit2ct_varchar_s(p_phone_list),
    p_user_id => util_ri.xget_user_id(p_user_login)
  );
  ------------------------------
  open p_result_list for
  select international_format,
         result
  from tt_batch_na_ap
  where result != util_pkg.c_ora_ok
  ;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure reports_get_phones
(
  p_host_id number,
  p_network_operator_id number,
  p_phone_type varchar2,
  p_salability_category_l cit_varchar_s,
  p_phone_number_status_code cit_varchar_s,
  p_search_date date,
  p_error_code out number,
  p_error_message out varchar2,
  p_result_list out sys_refcursor
)
is
begin
  ------------------------------
  REPORT.reports_get_phones
  (
    p_host_id => p_host_id,
    p_network_operator_id => p_network_operator_id,
    p_phone_type => p_phone_type,
    p_salability_category_l => cast_lcit2ct_varchar_s(p_salability_category_l),
    p_phone_number_status_code => cast_lcit2ct_varchar_s(p_phone_number_status_code),
    p_search_date => p_search_date,
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_result_list => p_result_list
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure reports_get_salability_categ
(
  p_result_list out sys_refcursor
)
is
begin
  ------------------------------
  open p_result_list for
  select
    phone_salability_category_code,
    phone_salability_category_name,
    attractiveness_level,
    user_id_of_change,
    date_of_change,
    deleted,
    sn
  from phone_salability_category
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_network_operator_id0(p_network_operator_code cit_varchar_s, p_date cit_date, p_trim_empty boolean, p_xcheck_data boolean := true) return cit_number
is
  v_network_operator_code ct_varchar_s;
  v_date ct_date;
begin
  ------------------------------
  v_network_operator_code := cast_lcit2ct_varchar_s(p_network_operator_code);
  v_date := cast_lcit2ct_date(p_date);
  ------------------------------
  return cast_ct_number2number(util_ri.get_network_operator_id0(v_network_operator_code, v_date, p_trim_empty, p_xcheck_data));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_id(p_network_operator_code cit_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return cit_number
is
  v_network_operator_code ct_varchar_s;
begin
  ------------------------------
  v_network_operator_code := cast_lcit2ct_varchar_s(p_network_operator_code);
  ------------------------------
  return cast_ct_number2number(util_ri.get_network_operator_id(v_network_operator_code, p_date, p_trim_empty, p_xcheck_data));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_id2(p_network_operator_code varchar2, p_date date) return number
is
begin
  ------------------------------
  return util_ri.get_network_operator_id2(p_network_operator_code, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure prod_check_sim_list
(
  p_host_id number,
  p_net_op_id number,
  p_iccid_without_control_digit cit_nvarchar_s,
  p_iccid out cit_nvarchar_s,
  p_imsi out cit_nvarchar_s,
  p_error_code out cit_number,
  p_error_message out cit_varchar
)
is
  v_iccid ct_varchar_s;
  v_imsi ct_varchar_s;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  api_ri_i_pkg.prod_check_sim_list_i
  (
    p_host_id => p_host_id,
    p_net_op_id => p_net_op_id,
    p_iccid_without_control_digit => util_pkg.cast_ct_nvarchar_s2varchar_s(cast_lcit2ct_nvarchar_s(p_iccid_without_control_digit)),
    p_iccid => v_iccid,
    p_imsi => v_imsi,
    p_error_codes => v_error_code,
    p_error_messages => v_error_message
  );
  ------------------------------
  p_iccid := cast_ct_nvarchar_s2nvarchar_s(util_pkg.cast_ct_varchar_s2nvarchar_s(v_iccid));
  p_imsi := cast_ct_nvarchar_s2nvarchar_s(util_pkg.cast_ct_varchar_s2nvarchar_s(v_imsi));
  p_error_code := cast_ct_number2number(v_error_code);
  p_error_message := cast_ct_varchar2varchar(v_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure check_roam_partner4imsi_list
(
    p_imsi cit_varchar_s,
    p_date cit_date,
    p_roam_partner_flag out cit_number
)
is
  v_roam_partner_flag ct_number;
begin
  ------------------------------
  rsig_imsi_prefix.xcheck_roam_partner4imsi_list
  (
    p_imsi => cast_lcit2ct_varchar_s(p_imsi),
    p_date => cast_lcit2ct_date(p_date),
    p_roam_partner_flag => v_roam_partner_flag
  );
  ------------------------------
  p_roam_partner_flag := cast_ct_number2number(v_roam_partner_flag);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure check_roam_partner4imsi_list2
(
    p_imsi cit_varchar_s,
    p_date cit_date,
    p_roam_partner_flag_cur out sys_refcursor
)
is
  v_imsi ct_varchar_s;
  v_roam_partner_flag ct_number;
begin
  ------------------------------
  v_imsi := cast_lcit2ct_varchar_s(p_imsi);
  ------------------------------
  rsig_imsi_prefix.xcheck_roam_partner4imsi_list
  (
    p_imsi => v_imsi,
    p_date => cast_lcit2ct_date(p_date),
    p_roam_partner_flag => v_roam_partner_flag
  );
  ------------------------------
  p_roam_partner_flag_cur := rsig_imsi_prefix.get_result_cursor02(p_imsi => v_imsi, p_roam_partner_flag => v_roam_partner_flag);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
end;
/
