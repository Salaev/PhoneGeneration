CREATE package VP_BATCH_DETAILS is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'BATCH_DETAILS';

----------------------------------!---------------------------------------------
  function get1_i(p_batch_id integer, p_object_id integer, p_lock boolean, p_wait boolean, p_is_locked out boolean) return batch_details%rowtype;

  function get1(p_batch_id integer, p_object_id integer) return batch_details%rowtype;
  function xlock_get1(p_batch_id integer, p_object_id integer) return batch_details%rowtype;

----------------------------------!---------------------------------------------
  function find_i_id2(p_rec batch_details%rowtype) return boolean;

  function find_i(p_rec batch_details%rowtype) return boolean;
  procedure xunique_i(p_rec batch_details%rowtype);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec batch_details%rowtype);

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy batch_details%rowtype);

  procedure version_close
  (
    p_batch_id integer,
    p_object_id integer
  );

----------------------------------!---------------------------------------------

end;
/
