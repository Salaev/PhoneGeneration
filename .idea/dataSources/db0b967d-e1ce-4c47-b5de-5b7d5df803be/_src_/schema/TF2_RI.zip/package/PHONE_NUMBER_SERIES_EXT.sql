CREATE PACKAGE PHONE_NUMBER_SERIES_EXT IS

PROCEDURE Is_Net_Op_External(
  p_network_operator_id    IN   network_operator.network_operator_id%TYPE
);

PROCEDURE Insert_Phone_Series_For_Ext_op
(
  handle_tran                IN     CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_phone_number_type_code   IN     PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE, -- phone number type code of the given serie of phone numbers
  p_country_code             IN     PHONE_NUMBER_SERIES.COUNTRY_CODE%TYPE, -- country code of given phone number serie
  p_area_code                IN     PHONE_NUMBER_SERIES.AREA_CODE%TYPE, -- area code of given phone number serie
  p_starting_local_number    IN     PHONE_NUMBER_SERIES.LOCAL_NUMBER_START%TYPE, -- starting local phone number of new phone number serie
  p_ending_local_number      IN     PHONE_NUMBER_SERIES.LOCAL_NUMBER_END%TYPE, -- ending local phone number of new phone number serie
  p_phone_number_status_code IN     PHONE_NUMBER.NET_ADDRESS_STATUS_CODE%TYPE, 
  p_network_operator_id      IN     NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE, -- id of the network operator who will own this new inserted serie
  p_start_date               IN     DATE, -- the date since when given network operator owns this new inserted serie
  p_user_id_of_change        IN     NUMBER, -- id of the user who insert this serie
  p_host_id                  IN     PHONE_NUMBER_SERIES.HOST_ID%TYPE,
  error_code                 OUT    NUMBER,
  p_phone_serie_id           OUT    PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE
);

PROCEDURE Get_Phone_Series(
  p_network_operator_id    IN  network_operator.network_operator_id%TYPE,
  p_show_deleted           IN  CHAR DEFAULT rsig_utils.c_NO,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

PROCEDURE Delete_Phone_Serie(
  p_phone_serie_id      IN  phone_number_series.phone_number_series_id%TYPE,
  p_user_id_of_change   IN  NUMBER,
  handle_tran	          IN  CHAR,
  p_raise_error	        IN  CHAR,
  error_code            OUT NUMBER,
  error_message	        OUT VARCHAR2
);

PROCEDURE Change_Network_Operator(
  p_phone_serie_id      IN  phone_number_series.phone_number_series_id%TYPE,
  p_new_operator_id     IN  network_operator.network_operator_id%TYPE,
  p_user_id_of_change   IN  NUMBER,
  handle_tran	          IN  CHAR,
  p_raise_error	        IN  CHAR,
  error_code            OUT NUMBER,
  error_message	        OUT VARCHAR2
);

PROCEDURE Get_Phone_Series_History(
  p_phone_series_id        IN  phone_number_series.phone_number_series_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

END;
/
