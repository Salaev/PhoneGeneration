CREATE PACKAGE BODY RSIG_PREFIX_REPLACEMENT IS
-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Insert_Prefix_Replacement
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_Prefix_Replacement(
  p_host_id               IN   PREFIX_REPLACEMENT.HOST_ID%TYPE,
  p_location_area_id      IN   PREFIX_REPLACEMENT.LOCATION_AREA_ID%TYPE,
  p_base_station_id       IN   PREFIX_REPLACEMENT.BASE_STATION_ID%TYPE,
  p_home_network_operator IN   PREFIX_REPLACEMENT.HOME_NETWORK_OPERATOR_ID%TYPE,
  p_phone_number_length   IN   PREFIX_REPLACEMENT.ORIGINAL_PHONE_NUMBER_LENGTH%TYPE,
  p_original_prefix       IN   PREFIX_REPLACEMENT.ORIGINAL_PREFIX%TYPE,
  p_start_date            IN   PREFIX_REPLACEMENT.START_DATE%TYPE,
  p_overwritting_prefix   IN   PREFIX_REPLACEMENT.OVERWRITTING_PREFIX%TYPE,
  p_description           IN   prefix_replacement.description%TYPE,
  p_user_id_of_change     IN   NUMBER,
  handle_tran	            IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN   CHAR DEFAULT rsig_utils.c_NO,
  error_code              OUT  NUMBER,
  error_message	          OUT  VARCHAR2
)
IS
	v_sqlcode	              number;
  v_event_source          varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Insert_Prefix_Replacement';
  v_start_date            DATE;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

	IF p_user_id_of_change IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


	-- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Insert_Prefix_Replacement_a;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
  v_start_date := nvl(p_start_date, SYSDATE);


  UPDATE prefix_replacement pr
  SET pr.end_date = v_start_date - rsig_utils.c_INTERVAL_DIFFERENCE,
      pr.user_id_of_change=p_user_id_of_change,
      pr.date_of_change=SYSDATE
  WHERE (pr.host_id=p_host_id OR (p_host_id IS NULL AND pr.host_id IS NULL))
    AND (pr.location_area_id=p_location_area_id OR (p_location_area_id IS NULL AND pr.location_area_id IS NULL))
    AND (pr.base_station_id=p_base_station_id OR (p_base_station_id IS NULL AND pr.base_station_id IS NULL))
    AND (pr.home_network_operator_id=p_home_network_operator OR (p_home_network_operator IS NULL AND pr.home_network_operator_id IS NULL))
    AND (pr.original_phone_number_length=p_phone_number_length
          OR (p_phone_number_length IS NULL AND pr.original_phone_number_length IS NULL))
    AND (pr.original_prefix=p_original_prefix OR (p_original_prefix IS NULL AND pr.original_prefix IS NULL))
    AND v_start_date BETWEEN pr.start_date AND nvl(pr.end_date,v_start_date);

  BEGIN
    insert into PREFIX_REPLACEMENT
      (PREFIX_REPLACEMENT_ID,
       HOST_ID,
       LOCATION_AREA_ID,
       BASE_STATION_ID,
       HOME_NETWORK_OPERATOR_ID,
       ORIGINAL_PHONE_NUMBER_LENGTH,
       ORIGINAL_PREFIX,
       OVERWRITTING_PREFIX,
       description,
       START_DATE,
       END_DATE,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE)
    values
      (s_prefix_replacement.nextval,
       p_host_id,
       p_location_area_id,
       p_base_station_id,
       p_home_network_operator,
       p_phone_number_length,
       p_original_prefix,
       p_overwritting_prefix,
       p_description,
       v_start_date,
       NULL,
       sysdate,
       p_user_id_of_change);

  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_PHONE_PREFIX_EXISTS, 'Prefix is not unique.');
  END;
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Insert_Prefix_Replacement_a;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Insert_Prefix_Replacement;

---------------------------------------------
--     PROCEDURE Close_Prefix_Replacement
---------------------------------------------

PROCEDURE Close_Prefix_Replacement(
  handle_tran              IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code               OUT  NUMBER,
  p_prefix_replacement_id  IN   prefix_replacement.prefix_replacement_id%TYPE,
  p_end_date               IN   PREFIX_REPLACEMENT.END_DATE%TYPE,
  p_user_id_of_change      IN   PREFIX_REPLACEMENT.USER_ID_OF_CHANGE%TYPE
)
IS
  v_event_source VARCHAR2(60) := 'RSIG_PREFIX_REPLACEMENT.Close_Prefix_Replacement';
  v_end_date     DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF p_prefix_replacement_id IS NULL OR p_user_id_of_change IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint close_prefix_replacement_a;
  END IF;


  v_end_date := nvl(p_end_date, SYSDATE);


  UPDATE PREFIX_REPLACEMENT pr
     SET pr.end_date = v_end_date,
         pr.date_of_change = SYSDATE,
         pr.user_id_of_change = p_user_id_of_change
   WHERE pr.prefix_replacement_id=p_prefix_replacement_id;

  IF SQL%NOTFOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
  END IF;
  --
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;
  error_code := RSIG_UTILS.c_OK; -- succesfully completed
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint close_prefix_replacement_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Close_Prefix_Replacement;

---------------------------------------------
--     PROCEDURE Get_Prefix_Replacement
---------------------------------------------

PROCEDURE Get_Prefix_Replacement(
  error_code            OUT NUMBER,
  p_validity_start_date IN PREFIX_REPLACEMENT.START_DATE%TYPE,
  p_validity_end_date   IN PREFIX_REPLACEMENT.END_DATE%TYPE,
  p_host_code           IN HOST.HOST_CODE%TYPE,
  p_result              OUT RSIG_UTILS.REF_CURSOR
)
IS
  v_event_source        VARCHAR2(60) := 'RSIG_PREFIX_REPLACEMENT.Get_Prefix_Replacement';
  v_validity_start_date DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);



  v_validity_start_date:=nvl(p_validity_start_date,SYSDATE);

  IF p_validity_end_date IS NOT NULL AND p_validity_end_date <= v_validity_start_date THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;
  
  if p_host_code is not null 
  THEN
    OPEN p_result FOR 
         SELECT prne.network_operator_id,
                prne.host_id,
                la.location_area_code,
                bs.base_station_code,
                prr.min_phone_length,
                prr.max_phone_length,
                prr.original_prefix,
                prr.overwritting_prefix,
                prg.start_date,
                prg.end_date,
                prr.description,
                prr.home_network_operator_id,
                prg.deleted,
				prr.list_of_allowed_services
            FROM PREFIX_REPLACEMENT_GROUPS prg
            LEFT JOIN PREFIX_REPLACEMENT_RULES prr ON (prg.rule_id = prr.rule_id)
            LEFT JOIN PREFIX_REPLACEMENT_NET_EL prne ON (prg.group_id = prne.group_id)
            LEFT JOIN LOCATION_AREA la on la.location_area_id = prne.location_area_id
            LEFT JOIN BASE_STATION bs on bs.base_station_id = prne.base_station_id
            LEFT JOIN HOST h ON h.host_id = prne.host_id
            WHERE (h.host_code = p_host_code)
              AND (v_validity_start_date<prg.end_date OR prg.end_date IS NULL) 
              AND (p_validity_end_date>prg.start_date OR p_validity_end_date IS NULL)
              AND prr.home_network_operator_id IS NULL
              AND prg.deleted IS NULL;
  ELSE
    OPEN p_result FOR 
         SELECT prne.network_operator_id,
                prne.host_id,
                la.location_area_code,
                bs.base_station_code,
                prr.min_phone_length,
                prr.max_phone_length,
                prr.original_prefix,
                prr.overwritting_prefix,
                prg.start_date,
                prg.end_date,
                prr.description,
                prr.home_network_operator_id,
                prg.deleted,
				prr.list_of_allowed_services
            FROM PREFIX_REPLACEMENT_GROUPS prg
            LEFT JOIN PREFIX_REPLACEMENT_RULES prr ON (prg.rule_id = prr.rule_id)
            LEFT JOIN PREFIX_REPLACEMENT_NET_EL prne ON (prg.group_id = prne.group_id)
            LEFT JOIN LOCATION_AREA la on la.location_area_id = prne.location_area_id
            LEFT JOIN BASE_STATION bs on bs.base_station_id = prne.base_station_id
            WHERE (v_validity_start_date<prg.end_date OR prg.end_date IS NULL) 
              AND (p_validity_end_date>prg.start_date OR p_validity_end_date IS NULL)
              AND prr.home_network_operator_id IS NULL
              AND prg.deleted IS NULL;
  END IF;
 /* then 
	  OPEN p_result FOR 
		SELECT location_area_code,
			   base_station_code,
			   original_phone_number_length,
			   original_prefix,
			   overwritting_prefix,
			   start_date,
			   end_date
		FROM MV_PREFIX_REPLACEMENT
		where host_code=p_host_code
		  AND (v_validity_start_date<end_date OR end_date IS NULL)
		  AND (p_validity_end_date>start_date OR p_validity_end_date IS NULL)
		  AND home_network_operator_id IS NULL;
  ELSE 
	  OPEN p_result FOR 
		SELECT 
		    NULL location_area_code, 
		    NULL base_station_code, 
		    pr.original_phone_number_length, 
		    pr.original_prefix, 
		    pr.overwritting_prefix, 
		    pr.start_date, 
		    pr.end_date 
		  FROM PREFIX_REPLACEMENT pr 
		 WHERE pr.host_id IS NULL
		   AND (v_validity_start_date<pr.end_date OR pr.end_date IS NULL) 
		   AND (p_validity_end_date>pr.start_date OR p_validity_end_date IS NULL)
		   AND home_network_operator_id IS NULL;
 end if;*/

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_result FOR
        select error_code from dual;
    END;
END Get_Prefix_Replacement;

------------------------------------------------------------------------------------------------------------------------------
--  Get_GUI_Prefix_Replacement
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_GUI_Prefix_Replacement(
  p_network_operator_id    IN  network_operator.network_operator_id%TYPE,
  p_show_deleted           IN  CHAR,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Get_GUI_Prefix_Replacement';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

	IF p_network_operator_id IS NULL OR p_show_deleted NOT IN(rsig_utils.c_YES,rsig_utils.c_No) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


-- start of the procedure body --------------------------------------------------------------------------------------------------

  OPEN result_list FOR
	SELECT pr.prefix_replacement_id,
         pr.host_id,
         h.host_name,
         pr.location_area_id,
         la.location_area_name,
         pr.base_station_id,
         bs.base_station_name,
         pr.original_phone_number_length,
         pr.original_prefix,
         pr.overwritting_prefix,
         pr.start_date,
         pr.end_date,
         pr.description,
         pr.date_of_change,
         u.user_name,
         pr.deleted,
         pr.home_network_operator_id,
         no.network_operator_name
  FROM prefix_replacement pr
  JOIN users u ON u.user_id=pr.user_id_of_change
  LEFT JOIN host h ON h.host_id=pr.host_id
  LEFT JOIN location_area la ON la.location_area_id=pr.location_area_id
  LEFT JOIN base_station bs ON bs.base_station_id=pr.base_station_id
  LEFT JOIN network_operator no ON no.network_operator_id=pr.home_network_operator_id
  WHERE ((SYSDATE BETWEEN pr.start_date AND nvl(pr.end_date,SYSDATE)) OR p_show_deleted=rsig_utils.c_YES)
    AND (p_show_deleted=rsig_utils.c_YES OR pr.deleted IS NULL OR pr.deleted>SYSDATE)
    AND (h.network_operator_id=p_network_operator_id OR pr.host_id IS NULL)
  ORDER BY h.host_name NULLS FIRST,la.location_area_name NULLS FIRST,bs.base_station_name NULLS FIRST;



-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
	  v_sqlcode := sqlcode;
		error_message := sqlerrm;
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_GUI_Prefix_Replacement;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Delete_Prefix_Replacement
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Delete_Prefix_Replacement(
  p_prefix_replacement_id  IN  prefix_replacement.prefix_replacement_id%TYPE,
  p_user_id_of_change      IN  NUMBER,
  handle_tran	             IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	           IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message	           OUT VARCHAR2
)
IS
	v_sqlcode	              number;
  v_event_source          varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Delete_Prefix_Replacement';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

	IF p_prefix_replacement_id IS NULL OR p_user_id_of_change IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


	-- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Delete_Prefix_Replacement_a;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------

  UPDATE prefix_replacement pr
  SET pr.deleted = SYSDATE,
      pr.user_id_of_change = p_user_id_of_change,
      pr.date_of_change = SYSDATE
  WHERE pr.prefix_replacement_id=p_prefix_replacement_id;

  IF SQL%NOTFOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Deleted record was not found.');
  END IF;

-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Delete_Prefix_Replacement_a;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Delete_Prefix_Replacement;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Update_Prefix_Replacement
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Update_Prefix_Replacement(
  p_prefix_replacement_id  IN  prefix_replacement.prefix_replacement_id%TYPE,
  p_host_id                IN   PREFIX_REPLACEMENT.HOST_ID%TYPE,
  p_location_area_id       IN   PREFIX_REPLACEMENT.LOCATION_AREA_ID%TYPE,
  p_base_station_id        IN   PREFIX_REPLACEMENT.BASE_STATION_ID%TYPE,
  p_home_network_operator  IN   PREFIX_REPLACEMENT.HOME_NETWORK_OPERATOR_ID%TYPE,
  p_phone_number_length    IN   PREFIX_REPLACEMENT.ORIGINAL_PHONE_NUMBER_LENGTH%TYPE,
  p_original_prefix        IN   PREFIX_REPLACEMENT.ORIGINAL_PREFIX%TYPE,
  p_start_date             IN   PREFIX_REPLACEMENT.START_DATE%TYPE,
  p_overwritting_prefix    IN   PREFIX_REPLACEMENT.OVERWRITTING_PREFIX%TYPE,
  p_description            IN   prefix_replacement.description%TYPE,
  p_user_id_of_change      IN   NUMBER,
  handle_tran	             IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	           IN   CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT  NUMBER,
  error_message	           OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Update_Prefix_Replacement';
  v_start_date             DATE;
  v_exist                  INT;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

	IF p_prefix_replacement_id IS NULL OR p_overwritting_prefix IS NULL OR p_user_id_of_change IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


	-- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_Prefix_Replacement_a;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
  v_start_date := nvl(p_start_date, SYSDATE);

  SELECT COUNT(1)
  INTO v_exist
  FROM dual
  WHERE EXISTS (SELECT 1
                FROM prefix_replacement pr
                WHERE (pr.host_id=p_host_id
                       OR (pr.host_id IS NULL AND p_host_id IS NULL))
                  AND (pr.location_area_id=p_location_area_id
                       OR (pr.location_area_id IS NULL AND p_location_area_id IS NULL))
                  AND (pr.base_station_id=p_base_station_id
                       OR (pr.base_station_id IS NULL AND p_base_station_id IS NULL))
                  AND (pr.home_network_operator_id=p_home_network_operator
                       OR (pr.home_network_operator_id IS NULL AND p_home_network_operator IS NULL))
                  AND (pr.original_phone_number_length=p_phone_number_length
                       OR (pr.original_phone_number_length IS NULL AND p_phone_number_length IS NULL))
                  AND (pr.original_prefix=p_original_prefix
                       OR (pr.original_prefix IS NULL AND p_original_prefix IS NULL))
                  AND (v_start_date<=pr.end_date OR pr.end_date IS NULL)
                  AND pr.prefix_replacement_id<>p_prefix_replacement_id);

  IF v_exist = 1 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_PHONE_PREFIX_EXISTS, '');
  END IF;


  UPDATE prefix_replacement pr
  SET pr.host_id=p_host_id,
      pr.location_area_id=p_location_area_id,
      pr.base_station_id=p_base_station_id,
      pr.home_network_operator_id = p_home_network_operator,
      pr.original_phone_number_length=p_phone_number_length,
      pr.original_prefix=p_original_prefix,
      pr.overwritting_prefix = p_overwritting_prefix,
      pr.description = p_description,
      pr.start_date=v_start_date,
      pr.end_date=NULL,
      pr.user_id_of_change = p_user_id_of_change,
      pr.date_of_change = SYSDATE
  WHERE pr.prefix_replacement_id=p_prefix_replacement_id;

  IF SQL%NOTFOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Deleted record was not found.');
  END IF;

-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Update_Prefix_Replacement_a;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Update_Prefix_Replacement;
/*
-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Insert_Prefix_Replacement_Rule
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_Prefix_Replacement_Rule(
  p_original_prefix            IN   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE,
  p_overwritting_prefix        IN   PREFIX_REPLACEMENT_RULES.OVERWRITTING_PREFIX%TYPE,
  p_min_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE,
  p_max_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE,
  p_start_date                 IN   PREFIX_REPLACEMENT_RULES.START_DATE%TYPE,
  p_end_date                   IN   PREFIX_REPLACEMENT_RULES.END_DATE%TYPE,
  p_description                IN   PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE,
  p_user_id_of_change          IN   NUMBER,
  handle_tran	                 IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_row_identifer              OUT  NUMBER,
  error_code                   OUT  NUMBER,
  error_message	               OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Insert_Prefix_Replacement_Rule';
  v_start_date             DATE;
  v_exist                  INT;
  v_rule_id                NUMBER;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

	IF p_original_prefix IS NULL OR p_overwritting_prefix IS NULL OR p_user_id_of_change IS NULL 
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


	-- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_Prefix_Replacement_a;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
  v_start_date := nvl(p_start_date, SYSDATE);

  LOOP
    v_rule_id:= S_PREFIX_REPLACEMENT_RULES.NEXTVAL;
    v_exist:=0;
    SELECT COUNT(1) INTO v_exist
      FROM PREFIX_REPLACEMENT_RULES prr
       WHERE prr.rule_id = v_rule_id;
    IF (v_exist = 0)
    THEN
       EXIT;
    END IF;
  END LOOP;
  
  INSERT INTO PREFIX_REPLACEMENT_RULES(
         RULE_ID,
         ORIGINAL_PREFIX,
         OVERWRITTING_PREFIX,
         MIN_PHONE_LENGTH,
         MAX_PHONE_LENGTH,
         DESCRIPTION,
         START_DATE,
         END_DATE,
         USER_ID_OF_CHANGE,
         DATE_OF_CHANGE)
         VALUES(
         v_rule_id,
         p_original_prefix,
         p_overwritting_prefix,
         p_min_phone_number_length,
         p_max_phone_number_length,
         p_description,
         v_start_date,
         p_end_date,
         p_user_id_of_change,
         sysdate);
         
  p_row_identifer := v_rule_id;

-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Update_Prefix_Replacement_a;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Insert_Prefix_Replacement_Rule;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Insert_Prefix_Replacement_Rule_2
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_PrefixReplacement_Rule2(
  p_original_prefix            IN   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE,
  p_overwritting_prefix        IN   PREFIX_REPLACEMENT_RULES.OVERWRITTING_PREFIX%TYPE,
  p_min_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE,
  p_max_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE,
  p_start_date                 IN   PREFIX_REPLACEMENT_RULES.START_DATE%TYPE,
  p_end_date                   IN   PREFIX_REPLACEMENT_RULES.END_DATE%TYPE,
  p_description                IN   PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE,
  p_network_operator_id        IN   common.t_number,
  p_host_id                    IN   common.t_number,
  p_location_area_id           IN   common.t_number,
  p_base_station_id            IN   common.t_number,
  p_user_id_of_change          IN   NUMBER,
  handle_tran	                 IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_row_identifer              OUT  NUMBER,
  error_code                   OUT  NUMBER,
  error_message	               OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Insert_PrefixReplacement_Rule2';
  v_start_date             DATE;
  v_exist                  INT;
  v_rule_id                NUMBER;
  v_group_id                NUMBER;
  v_id                      NUMBER;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

	IF p_original_prefix IS NULL OR p_overwritting_prefix IS NULL OR p_user_id_of_change IS NULL 
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

  IF p_network_operator_id.COUNT <> p_host_id.COUNT OR
     p_network_operator_id.COUNT <> p_location_area_id.COUNT OR
     p_network_operator_id.COUNT <> p_base_station_id.COUNT
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

	-- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_Prefix_Replacement_a;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
  v_start_date := nvl(p_start_date, SYSDATE);

  LOOP
    v_rule_id:= S_PREFIX_REPLACEMENT_RULES.NEXTVAL;
    v_exist:=0;
    SELECT COUNT(1) INTO v_exist
      FROM PREFIX_REPLACEMENT_RULES prr
       WHERE prr.rule_id = v_rule_id;
    IF (v_exist = 0)
    THEN
       EXIT;
    END IF;
  END LOOP;
  
  INSERT INTO PREFIX_REPLACEMENT_RULES(
         RULE_ID,
         ORIGINAL_PREFIX,
         OVERWRITTING_PREFIX,
         MIN_PHONE_LENGTH,
         MAX_PHONE_LENGTH,
         DESCRIPTION,
         START_DATE,
         END_DATE,
         USER_ID_OF_CHANGE,
         DATE_OF_CHANGE)
         VALUES(
         v_rule_id,
         p_original_prefix,
         p_overwritting_prefix,
         p_min_phone_number_length,
         p_max_phone_number_length,
         p_description,
         v_start_date,
         p_end_date,
         p_user_id_of_change,
         sysdate);
         
  p_row_identifer := v_rule_id;

  LOOP
    v_group_id:= S_PREFIX_REPLACEMENT_GROUPS.NEXTVAL;
    v_exist:=0;
    SELECT COUNT(1) INTO v_exist
      FROM PREFIX_REPLACEMENT_GROUPS prg
       WHERE prg.group_id = v_group_id;
    IF (v_exist = 0)
    THEN
       EXIT;
    END IF;
  END LOOP;
  
  INSERT INTO PREFIX_REPLACEMENT_GROUPS(
              GROUP_ID,
              RULE_ID,
              USER_ID_OF_CHANGE,
              DATE_OF_CHANGE)
              VALUES(
              v_group_id,
              v_rule_id,
              p_user_id_of_change,
              sysdate);
         
  FOR i IN p_network_operator_id.FIRST..p_network_operator_id.LAST
  LOOP
    LOOP
      v_id:= S_PREFIX_REPLACEMENT_NET_EL.NEXTVAL;
      v_exist:=0;
      SELECT COUNT(1) INTO v_exist
        FROM PREFIX_REPLACEMENT_NET_EL prne
         WHERE prne.id = v_id;
      IF (v_exist = 0)
      THEN
         EXIT;
      END IF;
    END LOOP;
    INSERT INTO PREFIX_REPLACEMENT_NET_EL(
                ID,
                NETWORK_OPERATOR_ID,
                HOST_ID,
                LOCATION_AREA_ID,
                BASE_STATION_ID,
                GROUP_ID,
                USER_ID_OF_CHANGE,
                DATE_OF_CHANGE)
                VALUES(
                v_id,
                p_network_operator_id(i),
                p_host_id(i),
                p_location_area_id(i),
                p_base_station_id(i),
                v_group_id,
                p_user_id_of_change,
                sysdate);
  END LOOP;
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Update_Prefix_Replacement_a;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Insert_PrefixReplacement_Rule2;


-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Insert_Prefix_Replacement_Net_El
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_Prefix_Replacement_NE(
  p_rule_id                    IN   PREFIX_REPLACEMENT_RULES.RULE_ID%TYPE,
  p_network_operator_id        IN   common.t_number,
  p_host_id                    IN   common.t_number,
  p_location_area_id           IN   common.t_number,
  p_base_station_id            IN   common.t_number,
  p_user_id_of_change          IN   NUMBER,
  handle_tran	                 IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  error_code                   OUT  NUMBER,
  error_message	               OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Insert_Prefix_Replacement_NE';
  v_exist                  INT;
  v_group_id                NUMBER;
  v_id                      NUMBER;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

	IF p_rule_id IS NULL OR p_user_id_of_change IS NULL 
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
  
  IF p_network_operator_id.COUNT <> p_host_id.COUNT OR
     p_network_operator_id.COUNT <> p_location_area_id.COUNT OR
     p_network_operator_id.COUNT <> p_base_station_id.COUNT
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


	-- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_Prefix_Replacement_a;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
 
  LOOP
    v_group_id:= S_PREFIX_REPLACEMENT_GROUPS.NEXTVAL;
    v_exist:=0;
    SELECT COUNT(1) INTO v_exist
      FROM PREFIX_REPLACEMENT_GROUPS prg
       WHERE prg.group_id = v_group_id;
    IF (v_exist = 0)
    THEN
       EXIT;
    END IF;
  END LOOP;
  
  INSERT INTO PREFIX_REPLACEMENT_GROUPS(
              GROUP_ID,
              RULE_ID,
              USER_ID_OF_CHANGE,
              DATE_OF_CHANGE)
              VALUES(
              v_group_id,
              p_rule_id,
              p_user_id_of_change,
              sysdate);
         
  FOR i IN p_network_operator_id.FIRST..p_network_operator_id.LAST
  LOOP
    LOOP
      v_id:= S_PREFIX_REPLACEMENT_NET_EL.NEXTVAL;
      v_exist:=0;
      SELECT COUNT(1) INTO v_exist
        FROM PREFIX_REPLACEMENT_NET_EL prne
         WHERE prne.id = v_id;
      IF (v_exist = 0)
      THEN
         EXIT;
      END IF;
    END LOOP;
    INSERT INTO PREFIX_REPLACEMENT_NET_EL(
                ID,
                NETWORK_OPERATOR_ID,
                HOST_ID,
                LOCATION_AREA_ID,
                BASE_STATION_ID,
                GROUP_ID,
                USER_ID_OF_CHANGE,
                DATE_OF_CHANGE)
                VALUES(
                v_id,
                p_network_operator_id(i),
                p_host_id(i),
                p_location_area_id(i),
                p_base_station_id(i),
                v_group_id,
                p_user_id_of_change,
                sysdate);
  END LOOP;
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Update_Prefix_Replacement_a;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Insert_Prefix_Replacement_NE;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Insert_Prefix_Replacement_Net_El
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Prefix_Replacement_Rule(
  p_rule_id                    IN   PREFIX_REPLACEMENT_RULES.RULE_ID%TYPE,
  p_network_operator_id        IN   NUMBER,
  p_validity_date              IN   DATE,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  error_code                   OUT  NUMBER,
  error_message	               OUT  VARCHAR2,
  p_result                     OUT  SYS_REFCURSOR
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Get_Prefix_Replacement_Rule';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	

	--IF p_rule_id IS NULL
  --  THEN
	--	RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	--END IF;
 

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------

 
   OPEN p_result FOR
     SELECT prr.rule_id,
            prr.original_prefix,
            prr.overwritting_prefix,
            prr.min_phone_length,
            prr.max_phone_length,
            prr.description,
            prr.start_date,
            prr.end_date,
            prr.user_id_of_change,
            prr.date_of_change
       FROM prefix_replacement_rules prr
       JOIN prefix_replacement_groups prg ON prg.rule_id = prr.rule_id
       JOIN prefix_replacement_net_el prne ON 
       (prne.group_id = prg.group_id 
       AND ( p_network_operator_id IS NULL 
       OR prne.network_operator_id IS NULL 
       OR prne.network_operator_id = p_network_operator_id ))
       WHERE (prr.rule_id = p_rule_id OR p_rule_id IS NULL)
         AND prr.end_date >=p_validity_date;
  
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Prefix_Replacement_Rule;*/

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_fit_group
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_fit_group(
  p_network_operator_id        IN   common.t_varchar2_10,
  p_host_id                    IN   common.t_varchar2_10,
  p_location_area_id           IN   common.t_varchar2_10,
  p_base_station_id            IN   common.t_varchar2_10,
  p_user_id_of_change          IN   NUMBER,
  p_handle_tran	               IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2,
  p_group_id                   OUT NUMBER
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Get_fit_group';
  v_exist                  INT;
  v_group_id                NUMBER;
  v_cnt                     NUMBER;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(p_handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (p_handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;
  
  IF p_network_operator_id.COUNT <> p_host_id.COUNT OR
     p_network_operator_id.COUNT <> p_location_area_id.COUNT OR
     p_network_operator_id.COUNT <> p_base_station_id.COUNT
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

	-- set savepoint
  IF (upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_Prefix_Replacement_a;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
v_cnt:=p_network_operator_id.COUNT;
--Заносим сетевые элементы во временную таюлицу

DELETE FROM tmp_net_elements;

FOR i IN p_network_operator_id.FIRST..p_network_operator_id.LAST
  LOOP
    INSERT INTO tmp_net_elements(
                NETWORK_OPERATOR_ID,
                HOST_ID,
                LOCATION_AREA_ID,
                BASE_STATION_ID)
                VALUES(
                p_network_operator_id(i),
                p_host_id(i),
                p_location_area_id(i),
                p_base_station_id(i));
  END LOOP;

--Ищем подходящую группу
  v_group_id := -1;
  for i in ( SELECT a.group_id, a.cnt 
                    FROM (SELECT prne.group_id,count(1) AS cnt FROM PREFIX_REPLACEMENT_NET_EL prne 
                                 GROUP BY prne.group_id) a
                    WHERE a.cnt = v_cnt)
  LOOP
    v_exist := 0;
    SELECT COUNT(1) INTO v_exist
      FROM 
      ((SELECT prne.NETWORK_OPERATOR_ID,
              prne.HOST_ID,
              prne.LOCATION_AREA_ID,
              prne.BASE_STATION_ID FROM PREFIX_REPLACEMENT_NET_EL prne
                where prne.group_id = i.group_id)
       MINUS
       (SELECT tt.NETWORK_OPERATOR_ID,
              tt.HOST_ID,
              tt.LOCATION_AREA_ID,
              tt.BASE_STATION_ID FROM tmp_net_elements tt
              ));
    IF v_exist = 0
    THEN
      v_group_id:=i.group_id;
      EXIT;
    END IF;
  END LOOP;           
             
             
 --Если не нашли подходящей группы-добавляем новую
 IF (v_group_id = -1)
 THEN
  LOOP
    v_group_id:= S_PR_GROUPS.NEXTVAL;
    v_exist:=0;
    SELECT COUNT(1) INTO v_exist
      FROM PREFIX_REPLACEMENT_NET_EL prg
       WHERE prg.group_id = v_group_id;
    IF (v_exist = 0)
    THEN
       EXIT;
    END IF;
  END LOOP;
  /*
  INSERT INTO PREFIX_REPLACEMENT_GROUPS(
              GROUP_ID,
              RULE_ID,
              USER_ID_OF_CHANGE,
              DATE_OF_CHANGE)
              VALUES(
              v_group_id,
              p_rule_id,
              p_user_id_of_change,
              sysdate);*/
         
  
    INSERT INTO PREFIX_REPLACEMENT_NET_EL(
                GROUP_ID,
                NETWORK_OPERATOR_ID,
                HOST_ID,
                LOCATION_AREA_ID,
                BASE_STATION_ID,
                USER_ID_OF_CHANGE,
                DATE_OF_CHANGE)
                SELECT v_group_id,
                       tt.network_operator_id,
                       tt.host_id,
                       tt.location_area_id,
                       tt.base_station_id,
                       p_user_id_of_change,
                       sysdate
                  FROM tmp_net_elements tt;
  END IF;
  
  p_group_id := v_group_id;
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE p_handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Update_Prefix_Replacement_a;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_fit_group;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_fit_rule
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_fit_rule(
  p_original_prefix            IN   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE,
  p_overwritting_prefix        IN   PREFIX_REPLACEMENT_RULES.OVERWRITTING_PREFIX%TYPE,
  p_min_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE,
  p_max_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE,
  p_description                IN   PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE,
  p_home_network_operator_id   IN   PREFIX_REPLACEMENT_RULES.HOME_NETWORK_OPERATOR_ID%TYPE,
  p_user_id_of_change          IN   NUMBER,
  p_handle_tran	               IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2,
  p_rule_id                    OUT NUMBER
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Get_fit_rule';
  v_exist                  INT;
  v_rule_id                NUMBER;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(p_handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (p_handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;
  
  	IF p_original_prefix IS NULL OR p_overwritting_prefix IS NULL OR p_user_id_of_change IS NULL 
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


	-- set savepoint
  IF (upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_Prefix_Replacement_a;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------

--Ищем подходящую группу
  v_rule_id := -1;
  
   SELECT COUNT(1)  INTO v_exist
    FROM PREFIX_REPLACEMENT_RULES prr
      WHERE ((prr.original_prefix IS NULL AND p_original_prefix IS NULL) OR prr.original_prefix = p_original_prefix)
        AND ((prr.overwritting_prefix IS NULL AND p_overwritting_prefix IS NULL) OR prr.overwritting_prefix = p_overwritting_prefix)
        AND ((prr.min_phone_length IS NULL AND p_min_phone_number_length IS NULL) OR prr.min_phone_length = p_min_phone_number_length)
        AND ((prr.max_phone_length IS NULL AND p_max_phone_number_length IS NULL) OR prr.max_phone_length = p_max_phone_number_length)
        AND ((prr.description IS NULL AND p_description IS NULL) OR prr.description = p_description)
        AND ((prr.home_network_operator_id IS NULL AND p_home_network_operator_id IS NULL) OR prr.home_network_operator_id = p_home_network_operator_id);
  IF (v_exist>0)
  THEN
        
  SELECT prr.rule_id  INTO v_rule_id
    FROM PREFIX_REPLACEMENT_RULES prr
      WHERE ((prr.original_prefix IS NULL AND p_original_prefix IS NULL) OR prr.original_prefix = p_original_prefix)
        AND ((prr.overwritting_prefix IS NULL AND p_overwritting_prefix IS NULL) OR prr.overwritting_prefix = p_overwritting_prefix)
        AND ((prr.min_phone_length IS NULL AND p_min_phone_number_length IS NULL) OR prr.min_phone_length = p_min_phone_number_length)
        AND ((prr.max_phone_length IS NULL AND p_max_phone_number_length IS NULL) OR prr.max_phone_length = p_max_phone_number_length)
        AND ((prr.description IS NULL AND p_description IS NULL) OR prr.description = p_description)
        AND ((prr.home_network_operator_id IS NULL AND p_home_network_operator_id IS NULL) OR prr.home_network_operator_id = p_home_network_operator_id)
        AND rownum = 1;
             
  ELSE        
 --Если не нашли подходящей группы-добавляем новую
  LOOP
    v_rule_id:= S_PREFIX_REPLACEMENT_RULES.NEXTVAL;
    v_exist:=0;
    SELECT COUNT(1) INTO v_exist
      FROM PREFIX_REPLACEMENT_RULES prr
       WHERE prr.rule_id = v_rule_id;
    IF (v_exist = 0)
    THEN
       EXIT;
    END IF;
  END LOOP;
  
  INSERT INTO PREFIX_REPLACEMENT_RULES(
         RULE_ID,
         ORIGINAL_PREFIX,
         OVERWRITTING_PREFIX,
         MIN_PHONE_LENGTH,
         MAX_PHONE_LENGTH,
         DESCRIPTION,
         HOME_NETWORK_OPERATOR_ID,
         USER_ID_OF_CHANGE,
         DATE_OF_CHANGE)
         VALUES(
         v_rule_id,
         p_original_prefix,
         p_overwritting_prefix,
         p_min_phone_number_length,
         p_max_phone_number_length,
         p_description,
         p_home_network_operator_id,
         p_user_id_of_change,
         sysdate);
  END IF;
  
  p_rule_id := v_rule_id;
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE p_handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Update_Prefix_Replacement_a;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_fit_rule;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Insert_New_Rule
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_New_Rule(
  p_original_prefix            IN   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE,
  p_overwritting_prefix        IN   PREFIX_REPLACEMENT_RULES.OVERWRITTING_PREFIX%TYPE,
  p_min_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE,
  p_max_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE,
  p_description                IN   PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE,
  p_home_network_operator_id   IN   PREFIX_REPLACEMENT_RULES.HOME_NETWORK_OPERATOR_ID%TYPE,
  p_start_date                 IN   DATE,
  p_end_date                   IN   DATE,
  p_network_operator_id        IN   common.t_varchar2_10,
  p_host_id                    IN   common.t_varchar2_10,
  p_location_area_id           IN   common.t_varchar2_10,
  p_base_station_id            IN   common.t_varchar2_10,
  p_user_id_of_change          IN   NUMBER,
  p_handle_tran	               IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_row_identifer              OUT  NUMBER,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Insert_New_Rule';
  v_start_date             DATE;
  v_exist                  INT;
  v_rule_id                NUMBER;
  v_group_id               NUMBER;
  v_link_id                NUMBER;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(p_handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (p_handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

	IF p_start_date < sysdate 
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
  
  IF p_original_prefix IS NULL OR p_overwritting_prefix IS NULL OR p_user_id_of_change IS NULL 
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

  IF p_network_operator_id.COUNT <> p_host_id.COUNT OR
     p_network_operator_id.COUNT <> p_location_area_id.COUNT OR
     p_network_operator_id.COUNT <> p_base_station_id.COUNT OR
     p_network_operator_id.COUNT = 0
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

  IF (p_start_date > p_end_date OR p_start_date IS NULL) 
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
	-- set savepoint
  IF (upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_Prefix_Replacement_a;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
  v_start_date := nvl(p_start_date, SYSDATE + 1);
  
  Get_fit_rule(p_original_prefix => p_original_prefix,
               p_overwritting_prefix => p_overwritting_prefix,
               p_min_phone_number_length => p_min_phone_number_length,
               p_max_phone_number_length => p_max_phone_number_length,
               p_description => p_description,
               p_home_network_operator_id => p_home_network_operator_id,
               p_user_id_of_change => p_user_id_of_change,
               p_handle_tran => 'N',
               p_raise_error => 'Y',
               p_error_code => p_error_code,
               p_error_message => p_error_message,
               p_rule_id => v_rule_id );

  Get_fit_group(p_network_operator_id => p_network_operator_id,
                p_host_id => p_host_id,
                p_location_area_id => p_location_area_id,
                p_base_station_id => p_base_station_id,
                p_user_id_of_change => p_user_id_of_change,
                p_handle_tran => 'N',
                p_raise_error => 'Y',
                p_error_code => p_error_code,
                p_error_message => p_error_message,
                p_group_id => v_group_id);   
                
--Свяжем правило и группу сетевых элементов
             
  LOOP
    v_link_id:= S_PREFIX_REPLACEMENT_GROUP_ID.NEXTVAL;
    v_exist:=0;
    SELECT COUNT(1) INTO v_exist
      FROM PREFIX_REPLACEMENT_GROUPS prg
       WHERE prg.id = v_link_id;
    IF (v_exist = 0)
    THEN
       EXIT;
    END IF;
  END LOOP;  
  
  INSERT INTO PREFIX_REPLACEMENT_GROUPS
  (
         ID,
         GROUP_ID,
         RULE_ID,
         START_DATE,
         END_DATE,
         USER_ID_OF_CHANGE,
         DATE_OF_CHANGE
   ) VALUES
   (
         v_link_id,
         v_group_id,
         v_rule_id,
         v_start_date,
         p_end_date,
         p_user_id_of_change,
         sysdate
   );        
  p_row_identifer := v_link_id;
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE p_handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Update_Prefix_Replacement_a;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Insert_New_Rule;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Close_Rule
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Close_Rule(
  p_link_id                    IN   NUMBER,
  p_end_date                   IN   DATE,
  p_network_operator_id        IN   common.t_varchar2_10,
  p_host_id                    IN   common.t_varchar2_10,
  p_location_area_id           IN   common.t_varchar2_10,
  p_base_station_id            IN   common.t_varchar2_10,
  p_close_all_group            IN   CHAR DEFAULT rsig_utils.c_NO,
  p_user_id_of_change          IN   NUMBER,
  p_handle_tran	               IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_row_identifer              OUT  NUMBER,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Close_Rule';
  v_start_date             DATE;
  v_exist                  INT;
  v_group_id               NUMBER;
  v_link_id                NUMBER;
  
  v_original_prefix                   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE;
  v_overwritting_prefix               PREFIX_REPLACEMENT_RULES.OVERWRITTING_PREFIX%TYPE;
  v_min_phone_number_length           PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE;
  v_max_phone_number_length           PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE;
  v_description                       PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE;
  v_home_network_operator_id          PREFIX_REPLACEMENT_RULES.HOME_NETWORK_OPERATOR_ID%TYPE;
  v_end_date                          DATE;
  v_deleted                           DATE;
  v_new_network_operator_id           common.t_varchar2_10;
  v_new_host_id                       common.t_varchar2_10;
  v_new_location_area_id              common.t_varchar2_10;
  v_new_base_station_id               common.t_varchar2_10;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(p_handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (p_handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

	IF p_link_id IS NULL 
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

  IF (p_network_operator_id.COUNT <> p_host_id.COUNT OR
     p_network_operator_id.COUNT <> p_location_area_id.COUNT OR
     p_network_operator_id.COUNT <> p_base_station_id.COUNT OR
     p_network_operator_id.COUNT = 0) AND p_close_all_group <> rsig_utils.c_YES
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

  IF p_end_date IS NULL OR p_end_date<sysdate
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
	-- set savepoint
  IF (upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_Prefix_Replacement_a;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
  SELECT COUNT(1) INTO v_exist
  FROM PREFIX_REPLACEMENT_GROUPS prg
  WHERE prg.id = p_link_id;  
  
  IF (v_exist IS NULL OR v_exist = 0)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Rule not exist');
  END IF;
  
  SELECT prg.start_date,
         prg.end_date ,
         prr.original_prefix,
         prr.overwritting_prefix,
         prr.min_phone_length,
         prr.max_phone_length,
         prr.description,
         prr.home_network_operator_id,
         prg.group_id,
         prg.deleted
    INTO v_start_date, 
         v_end_date,
         v_original_prefix,
         v_overwritting_prefix,
         v_min_phone_number_length,
         v_max_phone_number_length,
         v_description,
         v_home_network_operator_id,
         v_group_id,
         v_deleted
     FROM PREFIX_REPLACEMENT_GROUPS prg
     JOIN PREFIX_REPLACEMENT_RULES prr ON prr.rule_id = prg.rule_id
  WHERE prg.id = p_link_id;
  
  IF v_deleted IS NOT NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, 'Rule deleted');
  END IF;
  
  IF v_start_date>p_end_date
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'start_date>end_date');
  END IF;
  /*
  IF v_end_date<=p_end_date
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Rule already closed');
  END IF;*/
  
  --Закроем существующую связку
  
  UPDATE PREFIX_REPLACEMENT_GROUPS prg
    SET prg.end_date = p_end_date
  WHERE prg.id = p_link_id;
  
  --Если закрываем не всю группу
  IF (p_close_all_group <> rsig_utils.c_YES)
  THEN
  --Заносим сетевые элементы во временную таюлицу

  DELETE FROM tmp_net_elements;

  FOR i IN p_network_operator_id.FIRST..p_network_operator_id.LAST
    LOOP
      INSERT INTO tmp_net_elements(
                  NETWORK_OPERATOR_ID,
                  HOST_ID,
                  LOCATION_AREA_ID,
                  BASE_STATION_ID)
                  VALUES(
                  p_network_operator_id(i),
                  p_host_id(i),
                  p_location_area_id(i),
                  p_base_station_id(i));
    END LOOP;
    
    --Определим набор сетевых элементов для новой группы
    
    SELECT NETWORK_OPERATOR_ID,
           HOST_ID,
           LOCATION_AREA_ID,
           BASE_STATION_ID
       BULK COLLECT INTO v_new_network_operator_id,
                         v_new_host_id,
                         v_new_location_area_id,
                         v_new_base_station_id
           FROM 
           ((SELECT prne.NETWORK_OPERATOR_ID,
                    prne.HOST_ID,
                    prne.LOCATION_AREA_ID,
                    prne.BASE_STATION_ID FROM PREFIX_REPLACEMENT_NET_EL prne
                      where prne.group_id = v_group_id)
             MINUS
             (SELECT tt.NETWORK_OPERATOR_ID,
                    tt.HOST_ID,
                    tt.LOCATION_AREA_ID,
                    tt.BASE_STATION_ID FROM tmp_net_elements tt
              ));
              
              
    --Если правило закрыто не для всех сетевых элементов,
    --создадим новую связку
    IF (v_new_network_operator_id.COUNT>0)
    THEN
      Insert_New_Rule(p_original_prefix => v_original_prefix,
                      p_overwritting_prefix => v_overwritting_prefix,
                      p_min_phone_number_length => v_min_phone_number_length,
                      p_max_phone_number_length => v_max_phone_number_length,
                      p_description => v_description,
                      p_home_network_operator_id => v_home_network_operator_id,
                      p_start_date => p_end_date+1/24/60/60,
                      p_end_date => v_end_date,
                      p_network_operator_id => v_new_network_operator_id,
                      p_host_id => v_new_host_id,
                      p_location_area_id => v_new_location_area_id,
                      p_base_station_id => v_new_base_station_id,
                      p_user_id_of_change => p_user_id_of_change,
                      p_handle_tran => 'N',
                      p_raise_error => 'Y',
                      p_row_identifer => v_link_id,
                      p_error_code => p_error_code,
                      p_error_message => p_error_message);
                      
       p_row_identifer := v_link_id;
    END IF;
  END IF;
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE p_handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Update_Prefix_Replacement_a;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Close_Rule;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Delete_Rule
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Delete_Rule(
  p_link_id                    IN   NUMBER,
  p_network_operator_id        IN   common.t_varchar2_10,
  p_host_id                    IN   common.t_varchar2_10,
  p_location_area_id           IN   common.t_varchar2_10,
  p_base_station_id            IN   common.t_varchar2_10,
  p_delete_all_group            IN   CHAR DEFAULT rsig_utils.c_NO,
  p_user_id_of_change          IN   NUMBER,
  p_handle_tran	               IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_row_identifer              OUT  NUMBER,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Delete_Rule';
  v_start_date             DATE;
  v_exist                  INT;
  v_group_id               NUMBER;
  v_link_id                NUMBER;
  
  v_original_prefix                   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE;
  v_overwritting_prefix               PREFIX_REPLACEMENT_RULES.OVERWRITTING_PREFIX%TYPE;
  v_min_phone_number_length           PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE;
  v_max_phone_number_length           PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE;
  v_description                       PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE;
  v_home_network_operator_id          PREFIX_REPLACEMENT_RULES.HOME_NETWORK_OPERATOR_ID%TYPE;
  v_end_date                          DATE;
  v_new_network_operator_id           common.t_varchar2_10;
  v_new_host_id                       common.t_varchar2_10;
  v_new_location_area_id              common.t_varchar2_10;
  v_new_base_station_id               common.t_varchar2_10;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(p_handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (p_handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

	IF p_link_id IS NULL 
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

   IF (p_network_operator_id.COUNT <> p_host_id.COUNT OR
     p_network_operator_id.COUNT <> p_location_area_id.COUNT OR
     p_network_operator_id.COUNT <> p_base_station_id.COUNT OR
     p_network_operator_id.COUNT = 0) AND p_delete_all_group <> rsig_utils.c_YES
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

	-- set savepoint
  IF (upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_Prefix_Replacement_a;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
  SELECT COUNT(1) INTO v_exist
  FROM PREFIX_REPLACEMENT_GROUPS prg
  WHERE prg.id = p_link_id;  
  
  IF (v_exist IS NULL OR v_exist = 0)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Rule not exist');
  END IF;
  
  SELECT prg.start_date,
         prg.end_date ,
         prr.original_prefix,
         prr.overwritting_prefix,
         prr.min_phone_length,
         prr.max_phone_length,
         prr.description,
         prr.home_network_operator_id,
         prg.group_id
    INTO v_start_date, 
         v_end_date,
         v_original_prefix,
         v_overwritting_prefix,
         v_min_phone_number_length,
         v_max_phone_number_length,
         v_description,
         v_home_network_operator_id,
         v_group_id
     FROM PREFIX_REPLACEMENT_GROUPS prg
     JOIN PREFIX_REPLACEMENT_RULES prr ON prr.rule_id = prg.rule_id
  WHERE prg.id = p_link_id;
  
  --Проверим что правило не активно.
  
  IF (v_start_date <=sysdate)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, 'Rule is active.');
  END IF;
  
  --Удаляем существующую связку
  
  UPDATE PREFIX_REPLACEMENT_GROUPS prg
    SET prg.deleted = sysdate
  WHERE prg.id = p_link_id;
  
  --Заносим сетевые элементы во временную таюлицу

  DELETE FROM tmp_net_elements;

  FOR i IN p_network_operator_id.FIRST..p_network_operator_id.LAST
    LOOP
      INSERT INTO tmp_net_elements(
                  NETWORK_OPERATOR_ID,
                  HOST_ID,
                  LOCATION_AREA_ID,
                  BASE_STATION_ID)
                  VALUES(
                  p_network_operator_id(i),
                  p_host_id(i),
                  p_location_area_id(i),
                  p_base_station_id(i));
    END LOOP;
    
    --Определим набор сетевых элементов для новой группы
    
    SELECT NETWORK_OPERATOR_ID,
           HOST_ID,
           LOCATION_AREA_ID,
           BASE_STATION_ID
       BULK COLLECT INTO v_new_network_operator_id,
                         v_new_host_id,
                         v_new_location_area_id,
                         v_new_base_station_id
           FROM 
           ((SELECT prne.NETWORK_OPERATOR_ID,
                    prne.HOST_ID,
                    prne.LOCATION_AREA_ID,
                    prne.BASE_STATION_ID FROM PREFIX_REPLACEMENT_NET_EL prne
                      where prne.group_id = v_group_id)
             MINUS
             (SELECT tt.NETWORK_OPERATOR_ID,
                    tt.HOST_ID,
                    tt.LOCATION_AREA_ID,
                    tt.BASE_STATION_ID FROM tmp_net_elements tt
              ));
              
              
    --Если правило удалено не для всех сетевых элементов
    IF (p_delete_all_group <> rsig_utils.c_YES)
    THEN
    --создадим новую связку
    IF (v_new_network_operator_id.COUNT>0)
    THEN
      Insert_New_Rule(p_original_prefix => v_original_prefix,
                      p_overwritting_prefix => v_overwritting_prefix,
                      p_min_phone_number_length => v_min_phone_number_length,
                      p_max_phone_number_length => v_max_phone_number_length,
                      p_description => v_description,
                      p_home_network_operator_id => v_home_network_operator_id,
                      p_start_date => v_start_date,
                      p_end_date => v_end_date,
                      p_network_operator_id => v_new_network_operator_id,
                      p_host_id => v_new_host_id,
                      p_location_area_id => v_new_location_area_id,
                      p_base_station_id => v_new_base_station_id,
                      p_user_id_of_change => p_user_id_of_change,
                      p_handle_tran => 'N',
                      p_raise_error => 'Y',
                      p_row_identifer => v_link_id,
                      p_error_code => p_error_code,
                      p_error_message => p_error_message);
                      
       p_row_identifer := v_link_id;
    END IF;
    END IF;

-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE p_handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Update_Prefix_Replacement_a;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Delete_Rule;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Update_Rule
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Update_Rule(
  p_link_id                    IN   NUMBER,
  p_original_prefix            IN   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE,
  p_overwritting_prefix        IN   PREFIX_REPLACEMENT_RULES.OVERWRITTING_PREFIX%TYPE,
  p_min_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE,
  p_max_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE,
  p_description                IN   PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE,
  p_home_network_operator_id   IN   PREFIX_REPLACEMENT_RULES.HOME_NETWORK_OPERATOR_ID%TYPE,
  p_start_date                 IN   DATE,
  p_end_date                   IN   DATE,
  p_network_operator_id        IN   common.t_varchar2_10,
  p_host_id                    IN   common.t_varchar2_10,
  p_location_area_id           IN   common.t_varchar2_10,
  p_base_station_id            IN   common.t_varchar2_10,
  p_group_operation            IN   CHAR DEFAULT rsig_utils.c_NO,
  p_user_id_of_change          IN   NUMBER,
  p_handle_tran	               IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Update_Rule';
  v_start_date             DATE;
  v_exist                  INT;
  v_rule_id                NUMBER;
  v_group_id               NUMBER;
  v_link_id                NUMBER;
  
  v_original_prefix                   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE;
  v_overwritting_prefix               PREFIX_REPLACEMENT_RULES.OVERWRITTING_PREFIX%TYPE;
  v_min_phone_number_length           PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE;
  v_max_phone_number_length           PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE;
  v_description                       PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE;
  v_home_network_operator_id          PREFIX_REPLACEMENT_RULES.HOME_NETWORK_OPERATOR_ID%TYPE;
  v_end_date                          DATE;
  v_deleted                           DATE;
  v_new_network_operator_id           common.t_varchar2_10;
  v_new_host_id                       common.t_varchar2_10;
  v_new_location_area_id              common.t_varchar2_10;
  v_new_base_station_id               common.t_varchar2_10;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(p_handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (p_handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

	IF p_original_prefix IS NULL OR p_overwritting_prefix IS NULL OR p_user_id_of_change IS NULL 
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

  IF p_network_operator_id.COUNT <> p_host_id.COUNT OR
     p_network_operator_id.COUNT <> p_location_area_id.COUNT OR
     p_network_operator_id.COUNT <> p_base_station_id.COUNT OR
     p_network_operator_id.COUNT = 0
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
  
  IF (p_start_date > p_end_date OR p_start_date IS NULL) 
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
  
	-- set savepoint
  IF (upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_Prefix_Replacement_a;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
 SELECT COUNT(1) INTO v_exist
  FROM PREFIX_REPLACEMENT_GROUPS prg
  WHERE prg.id = p_link_id;  
  
  IF (v_exist IS NULL OR v_exist = 0)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Rule not exist');
  END IF;
  
  SELECT prg.start_date,
         prg.end_date ,
         prr.original_prefix,
         prr.overwritting_prefix,
         prr.min_phone_length,
         prr.max_phone_length,
         prr.description,
         prr.home_network_operator_id,
         prg.group_id,
         prg.deleted
    INTO v_start_date, 
         v_end_date,
         v_original_prefix,
         v_overwritting_prefix,
         v_min_phone_number_length,
         v_max_phone_number_length,
         v_description,
         v_home_network_operator_id,
         v_group_id,
         v_deleted
     FROM PREFIX_REPLACEMENT_GROUPS prg
     JOIN PREFIX_REPLACEMENT_RULES prr ON prr.rule_id = prg.rule_id
  WHERE prg.id = p_link_id;
    
  IF v_deleted IS NOT NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, 'Rule deleted');
  END IF;
  
  IF (v_start_date>sysdate)
  THEN
    --Если правило не активно
    --Заносим сетевые элементы во временную таюлицу

    DELETE FROM tmp_net_elements;

    FOR i IN p_network_operator_id.FIRST..p_network_operator_id.LAST
      LOOP
        INSERT INTO tmp_net_elements(
                    NETWORK_OPERATOR_ID,
                    HOST_ID,
                    LOCATION_AREA_ID,
                    BASE_STATION_ID)
                    VALUES(
                    p_network_operator_id(i),
                    p_host_id(i),
                    p_location_area_id(i),
                    p_base_station_id(i));
      END LOOP;
      
      --Если не групповая операция
    IF (p_group_operation = rsig_utils.c_NO )
    THEN
      --Определим набор сетевых элементов для новой группы
      
      SELECT NETWORK_OPERATOR_ID,
             HOST_ID,
             LOCATION_AREA_ID,
             BASE_STATION_ID
         BULK COLLECT INTO v_new_network_operator_id,
                           v_new_host_id,
                           v_new_location_area_id,
                           v_new_base_station_id
             FROM 
             ((SELECT prne.NETWORK_OPERATOR_ID,
                      prne.HOST_ID,
                      prne.LOCATION_AREA_ID,
                      prne.BASE_STATION_ID FROM PREFIX_REPLACEMENT_NET_EL prne
                        where prne.group_id = v_group_id)
               MINUS
               (SELECT tt.NETWORK_OPERATOR_ID,
                      tt.HOST_ID,
                      tt.LOCATION_AREA_ID,
                      tt.BASE_STATION_ID FROM tmp_net_elements tt
                ));
                
                
      --Если правило изменено не для всех сетевых элементов,
      --создадим новую связку
      IF (v_new_network_operator_id.COUNT>0)
      THEN
        Insert_New_Rule(p_original_prefix => v_original_prefix,
                        p_overwritting_prefix => v_overwritting_prefix,
                        p_min_phone_number_length => v_min_phone_number_length,
                        p_max_phone_number_length => v_max_phone_number_length,
                        p_description => v_description,
                        p_home_network_operator_id => v_home_network_operator_id,
                        p_start_date => v_start_date,
                        p_end_date => v_end_date,
                        p_network_operator_id => v_new_network_operator_id,
                        p_host_id => v_new_host_id,
                        p_location_area_id => v_new_location_area_id,
                        p_base_station_id => v_new_base_station_id,
                        p_user_id_of_change => p_user_id_of_change,
                        p_handle_tran => 'N',
                        p_raise_error => 'Y',
                        p_row_identifer => v_link_id,
                        p_error_code => p_error_code,
                        p_error_message => p_error_message);                        
      END IF;
    END IF;
    --Изменим правило для заданных элементов
    Get_fit_rule(p_original_prefix => p_original_prefix,
               p_overwritting_prefix => p_overwritting_prefix,
               p_min_phone_number_length => p_min_phone_number_length,
               p_max_phone_number_length => p_max_phone_number_length,
               p_description => p_description,
               p_home_network_operator_id => p_home_network_operator_id,
               p_user_id_of_change => p_user_id_of_change,
               p_handle_tran => 'N',
               p_raise_error => 'Y',
               p_error_code => p_error_code,
               p_error_message => p_error_message,
               p_rule_id => v_rule_id );

   Get_fit_group(p_network_operator_id => p_network_operator_id,
                p_host_id => p_host_id,
                p_location_area_id => p_location_area_id,
                p_base_station_id => p_base_station_id,
                p_user_id_of_change => p_user_id_of_change,
                p_handle_tran => 'N',
                p_raise_error => 'Y',
                p_error_code => p_error_code,
                p_error_message => p_error_message,
                p_group_id => v_group_id); 
                  
    UPDATE PREFIX_REPLACEMENT_GROUPS prg
       SET prg.group_id = v_group_id,
           prg.rule_id = v_rule_id,
           prg.start_date = p_start_date,
           prg.end_date = p_end_date
     WHERE prg.id = p_link_id;
  ELSE
--    если правило активно
 --Закроем существующую связку
  
  UPDATE PREFIX_REPLACEMENT_GROUPS prg
    SET prg.end_date = p_start_date - 1/24/60/60
  WHERE prg.id = p_link_id AND (prg.end_date IS NULL OR prg.end_date > sysdate);
  
  --Заносим сетевые элементы во временную таюлицу

  DELETE FROM tmp_net_elements;

  FOR i IN p_network_operator_id.FIRST..p_network_operator_id.LAST
    LOOP
      INSERT INTO tmp_net_elements(
                  NETWORK_OPERATOR_ID,
                  HOST_ID,
                  LOCATION_AREA_ID,
                  BASE_STATION_ID)
                  VALUES(
                  p_network_operator_id(i),
                  p_host_id(i),
                  p_location_area_id(i),
                  p_base_station_id(i));
    END LOOP;
    
      --Если не групповая операция
    IF (p_group_operation = rsig_utils.c_NO )
    THEN
      --Определим набор сетевых элементов оставшийся от старой группы
      
      SELECT NETWORK_OPERATOR_ID,
             HOST_ID,
             LOCATION_AREA_ID,
             BASE_STATION_ID
         BULK COLLECT INTO v_new_network_operator_id,
                           v_new_host_id,
                           v_new_location_area_id,
                           v_new_base_station_id
             FROM 
             ((SELECT prne.NETWORK_OPERATOR_ID,
                      prne.HOST_ID,
                      prne.LOCATION_AREA_ID,
                      prne.BASE_STATION_ID FROM PREFIX_REPLACEMENT_NET_EL prne
                        where prne.group_id = v_group_id)
               MINUS
               (SELECT tt.NETWORK_OPERATOR_ID,
                      tt.HOST_ID,
                      tt.LOCATION_AREA_ID,
                      tt.BASE_STATION_ID FROM tmp_net_elements tt
                ));
                
                
      --Если правило изменено не для всех сетевых элементов,
      --создадим новую связку
      IF (v_new_network_operator_id.COUNT>0)
      THEN
        Insert_New_Rule(p_original_prefix => v_original_prefix,
                        p_overwritting_prefix => v_overwritting_prefix,
                        p_min_phone_number_length => v_min_phone_number_length,
                        p_max_phone_number_length => v_max_phone_number_length,
                        p_description => v_description,
                        p_home_network_operator_id => v_home_network_operator_id,
                        p_start_date => p_start_date,
                        p_end_date => v_end_date,
                        p_network_operator_id => v_new_network_operator_id,
                        p_host_id => v_new_host_id,
                        p_location_area_id => v_new_location_area_id,
                        p_base_station_id => v_new_base_station_id,
                        p_user_id_of_change => p_user_id_of_change,
                        p_handle_tran => 'N',
                        p_raise_error => 'Y',
                        p_row_identifer => v_link_id,
                        p_error_code => p_error_code,
                        p_error_message => p_error_message);
      END IF;
    END IF;
    
    --Создадим связку для правила с новыми параметрами
    Insert_New_Rule(p_original_prefix => p_original_prefix,
                      p_overwritting_prefix => p_overwritting_prefix,
                      p_min_phone_number_length => p_min_phone_number_length,
                      p_max_phone_number_length => p_max_phone_number_length,
                      p_description => p_description,
                      p_home_network_operator_id => p_home_network_operator_id,
                      p_start_date => p_start_date,
                      p_end_date => p_end_date,
                      p_network_operator_id => p_network_operator_id,
                      p_host_id => p_host_id,
                      p_location_area_id => p_location_area_id,
                      p_base_station_id => p_base_station_id,
                      p_user_id_of_change => p_user_id_of_change,
                      p_handle_tran => 'N',
                      p_raise_error => 'Y',
                      p_row_identifer => v_link_id,
                      p_error_code => p_error_code,
                      p_error_message => p_error_message);
  END IF;
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE p_handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Update_Prefix_Replacement_a;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Update_Rule;


-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Check_Rules_Conflict
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Check_Rules_Conflict(
  p_link_except_id             IN   NUMBER,
  p_original_prefix            IN   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE,
  p_min_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE,
  p_max_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE,
  p_home_network_operator_id   IN   PREFIX_REPLACEMENT_RULES.HOME_NETWORK_OPERATOR_ID%TYPE,
  p_start_date                 IN   DATE,
  p_end_date                   IN   DATE,
  p_network_operator_id        IN   common.t_varchar2_10,
  p_host_id                    IN   common.t_varchar2_10,
  p_location_area_id           IN   common.t_varchar2_10,
  p_base_station_id            IN   common.t_varchar2_10,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Check_Rules_Conflict';
  
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

	IF p_original_prefix IS NULL   
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

  IF p_network_operator_id.COUNT <> p_host_id.COUNT OR
     p_network_operator_id.COUNT <> p_location_area_id.COUNT OR
     p_network_operator_id.COUNT <> p_base_station_id.COUNT OR
     p_network_operator_id.COUNT = 0
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
 
    --Заносим сетевые элементы во временную таюлицу

    DELETE FROM tmp_net_elements;

    FOR i IN p_network_operator_id.FIRST..p_network_operator_id.LAST
      LOOP
        INSERT INTO tmp_net_elements(
                    NETWORK_OPERATOR_ID,
                    HOST_ID,
                    LOCATION_AREA_ID,
                    BASE_STATION_ID)
                    VALUES(
                    p_network_operator_id(i),
                    p_host_id(i),
                    p_location_area_id(i),
                    p_base_station_id(i));
      END LOOP;
      
      --Найдем все конфликты
      OPEN p_result FOR
           SELECT 
              prg.id AS LINK_ID,
              prne.group_id,
              prne.network_operator_id,
              no.network_operator_name,
              prne.host_id,
              h.host_name,
              prne.location_area_id,
              la.location_area_name,
              prne.base_station_id,
              bs.base_station_name,
              prr.original_prefix,
              prr.overwritting_prefix,
              prr.min_phone_length,
              prr.max_phone_length,
              prg.start_date,
              prg.end_date,
              prr.description,
              prr.home_network_operator_id,
              hno.network_operator_name,
              prg.deleted
          FROM PREFIX_REPLACEMENT_GROUPS prg
          LEFT JOIN PREFIX_REPLACEMENT_RULES prr ON (prg.rule_id = prr.rule_id)
          LEFT JOIN PREFIX_REPLACEMENT_NET_EL prne ON (prg.group_id = prne.group_id)
          LEFT JOIN NETWORK_OPERATOR no ON no.network_operator_id = prne.network_operator_id
          LEFT JOIN HOST h ON h.host_id = prne.host_id
          LEFT JOIN LOCATION_AREA la ON la.location_area_id = prne.location_area_id
          LEFT JOIN BASE_STATION bs ON bs.base_station_id = prne.base_station_id
          LEFT JOIN NETWORK_OPERATOR hno ON hno.network_operator_id = prr.home_network_operator_id
          WHERE (prg.deleted IS NULL OR prg.deleted >=sysdate) AND
                (p_link_except_id IS NULL OR p_link_except_id <> prg.id) AND
                (prr.original_prefix = p_original_prefix) AND
                ((p_home_network_operator_id IS NULL ) OR
                 (p_home_network_operator_id = prr.home_network_operator_id)) AND
                NOT((prr.max_phone_length IS NOT NULL AND p_min_phone_number_length IS NOT NULL AND prr.max_phone_length < p_min_phone_number_length) OR
                    (prr.min_phone_length IS NOT NULL AND p_max_phone_number_length IS NOT NULL AND p_max_phone_number_length < prr.min_phone_length)) AND
                NOT((prg.end_date IS NOT NULL AND p_start_date IS NOT NULL AND prg.end_date < p_start_date) OR
                    (prg.start_date IS NOT NULL AND p_end_date IS NOT NULL AND p_end_date <prg.start_date)) AND
                EXISTS
                (
                    SELECT tne.network_operator_id,tne.host_id,tne.location_area_id,tne.base_station_id FROM 
                          tmp_net_elements tne
                          WHERE 
                          ((tne.network_operator_id IS NULL AND prne.network_operator_id IS NULL) OR tne.network_operator_id = prne.network_operator_id) AND
                          ((tne.host_id IS NULL AND prne.host_id IS NULL) OR tne.host_id = prne.host_id) AND
                          ((tne.location_area_id IS NULL AND prne.location_area_id IS NULL) OR tne.location_area_id = prne.location_area_id) AND
                          ((tne.base_station_id IS NULL AND prne.base_station_id IS NULL) OR tne.base_station_id = prne.base_station_id)
                )/**/;
   
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------


	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Check_Rules_Conflict;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_List_Of_Rules
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_List_Of_Rules(
  p_network_operator_id        IN   NUMBER,
  p_network_operator_name      IN   VARCHAR2 DEFAULT '%',
  p_network_operator_code      IN   VARCHAR2 DEFAULT '%',
  p_host_id                    IN   NUMBER,
  p_host_name                  IN   VARCHAR2 DEFAULT '%',
  p_host_code                  IN   VARCHAR2 DEFAULT '%',
  p_location_area_id           IN   NUMBER,
  p_location_area_name         IN   VARCHAR2 DEFAULT '%',
  p_location_area_code         IN   VARCHAR2 DEFAULT '%',
  p_base_station_id            IN   NUMBER,
  p_base_station_name          IN   VARCHAR2 DEFAULT '%',
  p_base_station_code          IN   VARCHAR2 DEFAULT '%',
  p_original_prefix_mask       IN   VARCHAR2 DEFAULT '%',
  p_overwritting_prefix_mask   IN   VARCHAR2 DEFAULT '%',
  p_min_phone_number_length    IN   NUMBER,
  p_max_phone_number_length    IN   NUMBER,
  p_description                IN   VARCHAR2 DEFAULT '%',
  p_validity_date              IN   DATE,
  p_show_deleted               IN   CHAR,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Get_List_Of_Rules';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
 
  OPEN p_result FOR 
       SELECT 
              prg.id AS LINK_ID,
              prne.group_id,
              prne.network_operator_id,
              no.network_operator_name,
              prne.host_id,
              h.host_name,
              prne.location_area_id,
              la.location_area_name,
              prne.base_station_id,
              bs.base_station_name,
              prr.original_prefix,
              prr.overwritting_prefix,
              prr.min_phone_length,
              prr.max_phone_length,
              prg.start_date,
              prg.end_date,
              prr.description,
              prr.home_network_operator_id,
              hno.network_operator_name,
              prg.deleted
          FROM PREFIX_REPLACEMENT_GROUPS prg
          LEFT JOIN PREFIX_REPLACEMENT_RULES prr ON (prg.rule_id = prr.rule_id)
          LEFT JOIN PREFIX_REPLACEMENT_NET_EL prne ON (prg.group_id = prne.group_id)
          LEFT JOIN NETWORK_OPERATOR no ON no.network_operator_id = prne.network_operator_id
          LEFT JOIN HOST h ON h.host_id = prne.host_id
          LEFT JOIN LOCATION_AREA la ON la.location_area_id = prne.location_area_id
          LEFT JOIN BASE_STATION bs ON bs.base_station_id = prne.base_station_id
          LEFT JOIN NETWORK_OPERATOR hno ON hno.network_operator_id = prr.home_network_operator_id
          WHERE ((prne.network_operator_id = p_network_operator_id OR 
                    p_network_operator_id IS NULL) AND
                    (p_network_operator_code IS NULL OR no.network_operator_code like p_network_operator_code) AND
                    (p_network_operator_name IS NULL OR no.network_operator_name like p_network_operator_name))
             AND ((prne.host_id = p_host_id OR 
                    p_host_id IS NULL) AND
                    (p_host_code IS NULL OR h.host_code like p_host_code) AND
                    (p_host_name IS NULL OR h.host_name like p_host_name))
             AND ((prne.location_area_id = p_location_area_id OR 
                    p_location_area_id IS NULL) AND
                    (p_location_area_code IS NULL OR la.location_area_code like p_location_area_code) AND
                    (p_location_area_name IS NULL OR la.location_area_name like p_location_area_name))
             AND ((prne.base_station_id = p_base_station_id OR 
                    p_base_station_id IS NULL) AND
                    (p_base_station_code IS NULL OR bs.base_station_code like p_base_station_code) AND
                    (p_base_station_name IS NULL OR bs.base_station_name like p_base_station_name))
            AND (prr.original_prefix like p_original_prefix_mask OR 
                 p_original_prefix_mask IS NULL)
            AND (prr.overwritting_prefix like p_overwritting_prefix_mask OR 
                 p_overwritting_prefix_mask IS NULL)
            AND (prr.description like p_description OR 
                 p_description IS NULL)
            AND (prr.min_phone_length >=p_min_phone_number_length OR 
                 p_min_phone_number_length IS NULL)
            AND (prr.max_phone_length <=p_max_phone_number_length OR 
                 p_max_phone_number_length IS NULL)
            AND (prg.start_date <= p_validity_date OR p_validity_date IS NULL)
            AND (prg.end_date >= p_validity_date OR
                 p_validity_date IS NULL OR
                 prg.end_date IS NULL)
            AND (p_show_deleted = 'Y' OR prg.deleted IS NULL/* OR p_validity_date IS NULL OR prg.deleted >=p_validity_date*/);
        
   
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_List_Of_Rules;


-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_List_Of_Rules2
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_List_Of_Rules2(
  p_network_operator_id        IN   NUMBER,
  p_network_operator_name      IN   VARCHAR2 DEFAULT '%',
  p_network_operator_code      IN   VARCHAR2 DEFAULT '%',
  p_host_id                    IN   NUMBER,
  p_host_name                  IN   VARCHAR2 DEFAULT '%',
  p_host_code                  IN   VARCHAR2 DEFAULT '%',
  p_location_area_id           IN   NUMBER,
  p_location_area_name         IN   VARCHAR2 DEFAULT '%',
  p_location_area_code         IN   VARCHAR2 DEFAULT '%',
  p_base_station_id            IN   NUMBER,
  p_base_station_name          IN   VARCHAR2 DEFAULT '%',
  p_base_station_code          IN   VARCHAR2 DEFAULT '%',
  p_original_prefix_mask       IN   VARCHAR2 DEFAULT '%',
  p_overwritting_prefix_mask   IN   VARCHAR2 DEFAULT '%',
  p_min_phone_number_length    IN   NUMBER,
  p_max_phone_number_length    IN   NUMBER,
  p_description                IN   VARCHAR2 DEFAULT '%',
  p_validity_date              IN   DATE,
  p_show_deleted               IN   CHAR,
  p_return_rows_count          IN   NUMBER,
  p_return_total_count_value   IN   CHAR DEFAULT rsig_utils.c_NO,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_total_count_value          OUT  NUMBER,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Get_List_Of_Rules2';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  p_total_count_value:=0;
-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
 
  OPEN p_result FOR 
       SELECT 
              prg.id AS LINK_ID,
              prne.group_id,
              prne.network_operator_id,
              no.network_operator_name,
              prne.host_id,
              h.host_name,
              prne.location_area_id,
              la.location_area_name,
              prne.base_station_id,
              bs.base_station_name,
              prr.original_prefix,
              prr.overwritting_prefix,
              prr.min_phone_length,
              prr.max_phone_length,
              prg.start_date,
              prg.end_date,
              prr.description,
              prr.home_network_operator_id,
              hno.network_operator_name,
              prg.deleted
          FROM PREFIX_REPLACEMENT_GROUPS prg
          LEFT JOIN PREFIX_REPLACEMENT_RULES prr ON (prg.rule_id = prr.rule_id)
          LEFT JOIN PREFIX_REPLACEMENT_NET_EL prne ON (prg.group_id = prne.group_id)
          LEFT JOIN NETWORK_OPERATOR no ON no.network_operator_id = prne.network_operator_id
          LEFT JOIN HOST h ON h.host_id = prne.host_id
          LEFT JOIN LOCATION_AREA la ON la.location_area_id = prne.location_area_id
          LEFT JOIN BASE_STATION bs ON bs.base_station_id = prne.base_station_id
          LEFT JOIN NETWORK_OPERATOR hno ON hno.network_operator_id = prr.home_network_operator_id
          WHERE ((prne.network_operator_id = p_network_operator_id OR 
                    p_network_operator_id IS NULL) AND
                    (p_network_operator_code IS NULL OR no.network_operator_code like p_network_operator_code) AND
                    (p_network_operator_name IS NULL OR no.network_operator_name like p_network_operator_name))
             AND ((prne.host_id = p_host_id OR 
                    p_host_id IS NULL) AND
                    (p_host_code IS NULL OR h.host_code like p_host_code) AND
                    (p_host_name IS NULL OR h.host_name like p_host_name))
             AND ((prne.location_area_id = p_location_area_id OR 
                    p_location_area_id IS NULL) AND
                    (p_location_area_code IS NULL OR la.location_area_code like p_location_area_code) AND
                    (p_location_area_name IS NULL OR la.location_area_name like p_location_area_name))
             AND ((prne.base_station_id = p_base_station_id OR 
                    p_base_station_id IS NULL) AND
                    (p_base_station_code IS NULL OR bs.base_station_code like p_base_station_code) AND
                    (p_base_station_name IS NULL OR bs.base_station_name like p_base_station_name))
            AND (prr.original_prefix like p_original_prefix_mask OR 
                 p_original_prefix_mask IS NULL)
            AND (prr.overwritting_prefix like p_overwritting_prefix_mask OR 
                 p_overwritting_prefix_mask IS NULL)
            AND (prr.description like p_description OR 
                 p_description IS NULL)
            AND (prr.min_phone_length >=p_min_phone_number_length OR 
                 p_min_phone_number_length IS NULL)
            AND (prr.max_phone_length <=p_max_phone_number_length OR 
                 p_max_phone_number_length IS NULL)
            AND (prg.start_date <= p_validity_date OR p_validity_date IS NULL)
            AND (prg.end_date >= p_validity_date OR
                 p_validity_date IS NULL OR
                 prg.end_date IS NULL)
            AND (p_show_deleted = 'Y' OR prg.deleted IS NULL/* OR p_validity_date IS NULL OR prg.deleted >=p_validity_date*/)
            AND (p_return_rows_count IS NULL OR rownum<=p_return_rows_count);
        
   IF (p_return_total_count_value = rsig_utils.c_YES)
  THEN
    p_total_count_value:=0;
    SELECT
          COUNT(1) INTO p_total_count_value
          FROM PREFIX_REPLACEMENT_GROUPS prg
          LEFT JOIN PREFIX_REPLACEMENT_RULES prr ON (prg.rule_id = prr.rule_id)
          LEFT JOIN PREFIX_REPLACEMENT_NET_EL prne ON (prg.group_id = prne.group_id)
          LEFT JOIN NETWORK_OPERATOR no ON no.network_operator_id = prne.network_operator_id
          LEFT JOIN HOST h ON h.host_id = prne.host_id
          LEFT JOIN LOCATION_AREA la ON la.location_area_id = prne.location_area_id
          LEFT JOIN BASE_STATION bs ON bs.base_station_id = prne.base_station_id
          LEFT JOIN NETWORK_OPERATOR hno ON hno.network_operator_id = prr.home_network_operator_id
          WHERE ((prne.network_operator_id = p_network_operator_id OR 
                    p_network_operator_id IS NULL) AND
                    (p_network_operator_code IS NULL OR no.network_operator_code like p_network_operator_code) AND
                    (p_network_operator_name IS NULL OR no.network_operator_name like p_network_operator_name))
             AND ((prne.host_id = p_host_id OR 
                    p_host_id IS NULL) AND
                    (p_host_code IS NULL OR h.host_code like p_host_code) AND
                    (p_host_name IS NULL OR h.host_name like p_host_name))
             AND ((prne.location_area_id = p_location_area_id OR 
                    p_location_area_id IS NULL) AND
                    (p_location_area_code IS NULL OR la.location_area_code like p_location_area_code) AND
                    (p_location_area_name IS NULL OR la.location_area_name like p_location_area_name))
             AND ((prne.base_station_id = p_base_station_id OR 
                    p_base_station_id IS NULL) AND
                    (p_base_station_code IS NULL OR bs.base_station_code like p_base_station_code) AND
                    (p_base_station_name IS NULL OR bs.base_station_name like p_base_station_name))
            AND (prr.original_prefix like p_original_prefix_mask OR 
                 p_original_prefix_mask IS NULL)
            AND (prr.overwritting_prefix like p_overwritting_prefix_mask OR 
                 p_overwritting_prefix_mask IS NULL)
            AND (prr.description like p_description OR 
                 p_description IS NULL)
            AND (prr.min_phone_length >=p_min_phone_number_length OR 
                 p_min_phone_number_length IS NULL)
            AND (prr.max_phone_length <=p_max_phone_number_length OR 
                 p_max_phone_number_length IS NULL)
            AND (prg.start_date <= p_validity_date OR p_validity_date IS NULL)
            AND (prg.end_date >= p_validity_date OR
                 p_validity_date IS NULL OR
                 prg.end_date IS NULL)
            AND (p_show_deleted = 'Y' OR prg.deleted IS NULL);
  END IF;
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_List_Of_Rules2;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_GUI_Rules
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_GUI_Rules(
  p_network_operator_id        IN   NUMBER,
  p_show_deleted               IN   CHAR,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Get_GUI_Rules';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
 
  OPEN p_result FOR 
       SELECT 
              prg.id AS LINK_ID,
              prne.group_id,
              prne.network_operator_id,
              no.network_operator_name,
              prne.host_id,
              h.host_name,
              prne.location_area_id,
              la.location_area_name,
              prne.base_station_id,
              bs.base_station_name,
              prr.original_prefix,
              prr.overwritting_prefix,
              prr.min_phone_length,
              prr.max_phone_length,
              prg.start_date,
              prg.end_date,
              prr.description,
              prr.home_network_operator_id,
              hno.network_operator_name,
              prg.deleted
          FROM PREFIX_REPLACEMENT_GROUPS prg
          LEFT JOIN PREFIX_REPLACEMENT_RULES prr ON (prg.rule_id = prr.rule_id)
          LEFT JOIN PREFIX_REPLACEMENT_NET_EL prne ON (prg.group_id = prne.group_id)
          LEFT JOIN NETWORK_OPERATOR no ON no.network_operator_id = prne.network_operator_id
          LEFT JOIN HOST h ON h.host_id = prne.host_id
          LEFT JOIN LOCATION_AREA la ON la.location_area_id = prne.location_area_id
          LEFT JOIN BASE_STATION bs ON bs.base_station_id = prne.base_station_id
          LEFT JOIN NETWORK_OPERATOR hno ON hno.network_operator_id = prr.home_network_operator_id
          WHERE ((prne.network_operator_id = p_network_operator_id OR 
                    p_network_operator_id IS NULL) OR
                    prne.network_operator_id IS NULL)
            AND (p_show_deleted = 'Y' OR prg.deleted IS NULL/* OR p_validity_date IS NULL OR prg.deleted >=p_validity_date*/);
        
   
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_GUI_Rules;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_GUI_Rules2
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_GUI_Rules2(
  p_network_operator_id        IN   NUMBER,
  p_show_deleted               IN   CHAR,
  p_return_rows_count          IN   NUMBER,
  p_return_total_count_value   IN   CHAR DEFAULT rsig_utils.c_NO,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_total_count_value          OUT  NUMBER,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Get_GUI_Rules2';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
  
  p_total_count_value:=0;
-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
 
  OPEN p_result FOR 
       SELECT 
              prg.id AS LINK_ID,
              prne.group_id,
              prne.network_operator_id,
              no.network_operator_name,
              prne.host_id,
              h.host_name,
              prne.location_area_id,
              la.location_area_name,
              prne.base_station_id,
              bs.base_station_name,
              prr.original_prefix,
              prr.overwritting_prefix,
              prr.min_phone_length,
              prr.max_phone_length,
              prg.start_date,
              prg.end_date,
              prr.description,
              prr.home_network_operator_id,
              hno.network_operator_name,
              prg.deleted
          FROM PREFIX_REPLACEMENT_GROUPS prg
          LEFT JOIN PREFIX_REPLACEMENT_RULES prr ON (prg.rule_id = prr.rule_id)
          LEFT JOIN PREFIX_REPLACEMENT_NET_EL prne ON (prg.group_id = prne.group_id)
          LEFT JOIN NETWORK_OPERATOR no ON no.network_operator_id = prne.network_operator_id
          LEFT JOIN HOST h ON h.host_id = prne.host_id
          LEFT JOIN LOCATION_AREA la ON la.location_area_id = prne.location_area_id
          LEFT JOIN BASE_STATION bs ON bs.base_station_id = prne.base_station_id
          LEFT JOIN NETWORK_OPERATOR hno ON hno.network_operator_id = prr.home_network_operator_id
          WHERE ((prne.network_operator_id = p_network_operator_id OR 
                    p_network_operator_id IS NULL) OR
                    prne.network_operator_id IS NULL)
            AND (p_show_deleted = 'Y' OR prg.deleted IS NULL/* OR p_validity_date IS NULL OR prg.deleted >=p_validity_date*/)
            AND (p_return_rows_count IS NULL OR rownum<=p_return_rows_count);
    
  IF (p_return_total_count_value = rsig_utils.c_YES)
  THEN
    p_total_count_value:=0;
    SELECT
          COUNT(1) INTO p_total_count_value
          FROM PREFIX_REPLACEMENT_GROUPS prg
          LEFT JOIN PREFIX_REPLACEMENT_RULES prr ON (prg.rule_id = prr.rule_id)
          LEFT JOIN PREFIX_REPLACEMENT_NET_EL prne ON (prg.group_id = prne.group_id)
          LEFT JOIN NETWORK_OPERATOR no ON no.network_operator_id = prne.network_operator_id
          LEFT JOIN HOST h ON h.host_id = prne.host_id
          LEFT JOIN LOCATION_AREA la ON la.location_area_id = prne.location_area_id
          LEFT JOIN BASE_STATION bs ON bs.base_station_id = prne.base_station_id
          LEFT JOIN NETWORK_OPERATOR hno ON hno.network_operator_id = prr.home_network_operator_id
          WHERE ((prne.network_operator_id = p_network_operator_id OR 
                    p_network_operator_id IS NULL) OR
                    prne.network_operator_id IS NULL)
            AND (p_show_deleted = 'Y' OR prg.deleted IS NULL);
  END IF;
   
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_GUI_Rules2;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_Rules
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Rules(
  p_link_id                    IN   NUMBER,
  p_network_operator_id        IN   NUMBER,
  p_validity_date              IN   DATE,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Get_Rules';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
 
  OPEN p_result FOR 
       SELECT prg.id AS LINK_ID,
              prne.group_id,
              prne.network_operator_id,
              prne.host_id,
              prne.location_area_id,
              prne.base_station_id,
              prr.original_prefix,
              prr.overwritting_prefix,
              prr.min_phone_length,
              prr.max_phone_length,
              prg.start_date,
              prg.end_date,
              prr.description,
              prr.home_network_operator_id,
              prg.deleted
          FROM PREFIX_REPLACEMENT_GROUPS prg
          JOIN PREFIX_REPLACEMENT_RULES prr ON (prg.rule_id = prr.rule_id)
          JOIN PREFIX_REPLACEMENT_NET_EL prne ON (prg.group_id = prne.group_id)
          WHERE (prg.id = p_link_id OR p_link_id IS NULL)
            AND (prne.network_operator_id = p_network_operator_id OR 
                 p_network_operator_id IS NULL OR
                 (prne.network_operator_id IS NULL AND
                  prne.host_id IS NULL AND
                  prne.location_area_id IS NULL AND
                  prne.base_station_id IS NULL))
            AND (prg.end_date >= p_validity_date OR
                 p_validity_date IS NULL OR
                 prg.end_date IS NULL);
        
   
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Rules;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_Prfix_Replacement_Rules
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Prfix_Replacement_Rules(
  p_network_operator_id        IN   PREFIX_REPLACEMENT_NET_EL.NETWORK_OPERATOR_ID%TYPE,
  p_host_id                    IN   PREFIX_REPLACEMENT_NET_EL.HOST_ID%TYPE,
  p_location_area_id           IN   PREFIX_REPLACEMENT_NET_EL.LOCATION_AREA_ID%TYPE,
  p_base_station_id            IN   PREFIX_REPLACEMENT_NET_EL.BASE_STATION_ID%TYPE,
  p_validity_date_start        IN   DATE,
  p_validity_date_end          IN   DATE,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Get_Prfix_Replacement_Rules';
  v_validity_start_date    DATE;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  v_validity_start_date:=nvl(p_validity_date_start,SYSDATE);

  IF p_validity_date_end IS NOT NULL AND p_validity_date_end <= v_validity_start_date THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;
-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
  IF p_network_operator_id IS NOT NULL 
  THEN
    OPEN p_result FOR 
         SELECT prne.network_operator_id,
                prne.host_id,
                la.location_area_code,
                bs.base_station_code,
                prr.min_phone_length,
                prr.max_phone_length,
                prr.original_prefix,
                prr.overwritting_prefix,
                prg.start_date,
                prg.end_date,
                prr.description,
                prr.home_network_operator_id,
                prg.deleted
            FROM PREFIX_REPLACEMENT_GROUPS prg
            LEFT JOIN PREFIX_REPLACEMENT_RULES prr ON (prg.rule_id = prr.rule_id)
            LEFT JOIN PREFIX_REPLACEMENT_NET_EL prne ON (prg.group_id = prne.group_id)
            LEFT JOIN LOCATION_AREA la on la.location_area_id = prne.location_area_id
            LEFT JOIN BASE_STATION bs on bs.base_station_id = prne.base_station_id
            WHERE prne.network_operator_id = p_network_operator_id
              AND (p_host_id IS NULL OR prne.host_id = p_host_id)
              AND (p_location_area_id IS NULL OR prne.location_area_id = p_location_area_id)
              AND (p_base_station_id IS NULL OR prne.base_station_id = p_base_station_id)
              AND (v_validity_start_date<prg.end_date OR prg.end_date IS NULL) 
              AND (p_validity_date_end>prg.start_date OR p_validity_date_end IS NULL)
              AND prr.home_network_operator_id IS NULL
              AND prg.deleted IS NULL;
  ELSE
    OPEN p_result FOR 
         SELECT prne.network_operator_id,
                prne.host_id,
                la.location_area_code,
                bs.base_station_code,
                prr.min_phone_length,
                prr.max_phone_length,
                prr.original_prefix,
                prr.overwritting_prefix,
                prg.start_date,
                prg.end_date,
                prr.description,
                prr.home_network_operator_id,
                prg.deleted
            FROM PREFIX_REPLACEMENT_GROUPS prg
            LEFT JOIN PREFIX_REPLACEMENT_RULES prr ON (prg.rule_id = prr.rule_id)
            LEFT JOIN PREFIX_REPLACEMENT_NET_EL prne ON (prg.group_id = prne.group_id)
            LEFT JOIN LOCATION_AREA la on la.location_area_id = prne.location_area_id
            LEFT JOIN BASE_STATION bs on bs.base_station_id = prne.base_station_id
            WHERE (v_validity_start_date<prg.end_date OR prg.end_date IS NULL) 
              AND (p_validity_date_end>prg.start_date OR p_validity_date_end IS NULL)
              AND prr.home_network_operator_id IS NULL
              AND prg.deleted IS NULL;
  END IF;
        
   
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Prfix_Replacement_Rules;


-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_Network_Elements
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Network_Elements(
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Get_Network_Elements';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  -- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
 OPEN p_result FOR 
  SELECT distinct no.network_operator_id,
         no.network_operator_code,
         no.network_operator_name,
         h.host_id,
         h.host_code,
         h.host_name,
         la.location_area_id,
         la.location_area_code,
         la.location_area_name,
         bs.base_station_id,
         bs.base_station_code,
         bs.base_station_name
           FROM NETWORK_OPERATOR no
           JOIN HOST h ON h.network_operator_id = no.network_operator_id
           JOIN HOST_TYPE ht ON ht.HOST_TYPE_CODE = h.host_type_code
           JOIN LOCATION_AREA la ON la.host_id = h.host_id
           JOIN BASE_STATION bs ON bs.location_area_id = la.location_area_id
           WHERE --no.NETWORK_OPERATOR_TYPE IS null AND 
                 no.deleted is NULL AND 
                 h.deleted is NULL AND 
                 la.deleted is NULL AND 
                 bs.deleted is NULL AND
                 UPPER(ht.IS_EXCHANGE) = 'Y'
   UNION SELECT distinct no.network_operator_id,
         no.network_operator_code,
         no.network_operator_name,
         h.host_id,
         h.host_code,
         h.host_name,
         la.location_area_id,
         la.location_area_code,
         la.location_area_name,
         TO_NUMBER(NULL) AS base_station_id,
         TO_CHAR(NULL) AS base_station_code,
         TO_CHAR(NULL) AS base_station_name
           FROM NETWORK_OPERATOR no
           JOIN HOST h ON h.network_operator_id = no.network_operator_id
           JOIN HOST_TYPE ht ON ht.HOST_TYPE_CODE = h.host_type_code
           JOIN LOCATION_AREA la ON la.host_id = h.host_id
           WHERE --no.NETWORK_OPERATOR_TYPE IS null AND 
                 no.deleted is NULL AND 
                 h.deleted is NULL AND 
                 la.deleted is NULL AND
                 UPPER(ht.IS_EXCHANGE) = 'Y'
   UNION SELECT distinct no.network_operator_id,
         no.network_operator_code,
         no.network_operator_name,
         h.host_id,
         h.host_code,
         h.host_name,
         TO_NUMBER(NULL) AS location_area_id,
         TO_CHAR(NULL) AS location_area_code,
         TO_CHAR(NULL) AS location_area_name,
         TO_NUMBER(NULL) AS base_station_id,
         TO_CHAR(NULL) AS base_station_code,
         TO_CHAR(NULL) AS base_station_name
           FROM NETWORK_OPERATOR no
           JOIN HOST h ON h.network_operator_id = no.network_operator_id
           JOIN HOST_TYPE ht ON ht.HOST_TYPE_CODE = h.host_type_code
           WHERE --no.NETWORK_OPERATOR_TYPE IS null AND  
                 no.deleted is NULL AND 
                 h.deleted is NULL AND
                 UPPER(ht.IS_EXCHANGE) = 'Y'
   UNION SELECT distinct no.network_operator_id,
         no.network_operator_code,
         no.network_operator_name,
         TO_NUMBER(NULL) AS host_id,
         TO_CHAR(NULL) AS host_code,
         TO_CHAR(NULL) AS host_name,
         TO_NUMBER(NULL) AS location_area_id,
         TO_CHAR(NULL) AS location_area_code,
         TO_CHAR(NULL) AS location_area_name,
         TO_NUMBER(NULL) AS base_station_id,
         TO_CHAR(NULL) AS base_station_code,
         TO_CHAR(NULL) AS base_station_name
           FROM NETWORK_OPERATOR no
           WHERE --no.NETWORK_OPERATOR_TYPE IS null AND 
                 no.deleted is NULL;
  
        
   
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		
END Get_Network_Elements;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Extend_Network_Element_Group
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Extend_Network_Element_Group(
  p_old_link_id                    IN   NUMBER,
  p_upd_link_id                    IN   NUMBER,
  p_new_description                IN   PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE,
  p_new_start_date                 IN   DATE,
  p_new_end_date                   IN   DATE,
  p_new_network_operator_id        IN   common.t_varchar2_10,
  p_new_host_id                    IN   common.t_varchar2_10,
  p_new_location_area_id           IN   common.t_varchar2_10,
  p_new_base_station_id            IN   common.t_varchar2_10,
  p_group_operation                IN   CHAR DEFAULT rsig_utils.c_NO,
  p_user_id_of_change              IN   NUMBER,
  p_handle_tran	                   IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	                   IN   CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                     OUT  NUMBER,
  p_error_message	                 OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Extend_Network_Element_Group';
  v_exist                  INT;
  v_link_id                NUMBER;
  
  v_old_group_id                          NUMBER;
  v_old_original_prefix                   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE;
  v_old_overwritting_prefix               PREFIX_REPLACEMENT_RULES.OVERWRITTING_PREFIX%TYPE;
  v_old_min_phone_number_length           PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE;
  v_old_max_phone_number_length           PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE;
  v_old_description                       PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE;
  v_old_home_network_operator_id          PREFIX_REPLACEMENT_RULES.HOME_NETWORK_OPERATOR_ID%TYPE;
  v_old_start_date                        DATE;
  v_old_end_date                          DATE;
  v_old_deleted                           DATE;
  
  v_upd_group_id                          NUMBER;
  v_upd_original_prefix                   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE;
  v_upd_overwritting_prefix               PREFIX_REPLACEMENT_RULES.OVERWRITTING_PREFIX%TYPE;
  v_upd_min_phone_number_length           PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE;
  v_upd_max_phone_number_length           PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE;
  v_upd_description                       PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE;
  v_upd_home_network_operator_id          PREFIX_REPLACEMENT_RULES.HOME_NETWORK_OPERATOR_ID%TYPE;
  v_upd_start_date                        DATE;
  v_upd_end_date                          DATE;
  v_upd_deleted                           DATE;
  
  v_end_date                              DATE;
  
  v_new_network_operator_id           common.t_varchar2_10;
  v_new_host_id                       common.t_varchar2_10;
  v_new_location_area_id              common.t_varchar2_10;
  v_new_base_station_id               common.t_varchar2_10; 
  
  v_ext_network_operator_id           common.t_varchar2_10;
  v_ext_host_id                       common.t_varchar2_10;
  v_ext_location_area_id              common.t_varchar2_10;
  v_ext_base_station_id               common.t_varchar2_10;   
  
  v_old_network_operator_id           common.t_varchar2_10;
  v_old_host_id                       common.t_varchar2_10;
  v_old_location_area_id              common.t_varchar2_10;
  v_old_base_station_id               common.t_varchar2_10;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(p_handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (p_handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

	IF p_user_id_of_change IS NULL 
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

  IF p_new_network_operator_id.COUNT <> p_new_host_id.COUNT OR
     p_new_network_operator_id.COUNT <> p_new_location_area_id.COUNT OR
     p_new_network_operator_id.COUNT <> p_new_base_station_id.COUNT OR
     p_new_network_operator_id.COUNT = 0
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
  
  IF (p_new_start_date > p_new_end_date OR p_new_start_date IS NULL) 
    THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
  
	-- set savepoint
  IF (upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_Prefix_Replacement_a;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
 SELECT COUNT(1) INTO v_exist
  FROM PREFIX_REPLACEMENT_GROUPS prg
  WHERE prg.id = p_old_link_id;  
  
  IF (v_exist IS NULL OR v_exist = 0)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Rule not exist');
  END IF;
  
  SELECT prg.start_date,
         prg.end_date ,
         prr.original_prefix,
         prr.overwritting_prefix,
         prr.min_phone_length,
         prr.max_phone_length,
         prr.description,
         prr.home_network_operator_id,
         prg.group_id,
         prg.deleted
    INTO v_old_start_date, 
         v_old_end_date,
         v_old_original_prefix,
         v_old_overwritting_prefix,
         v_old_min_phone_number_length,
         v_old_max_phone_number_length,
         v_old_description,
         v_old_home_network_operator_id,
         v_old_group_id,
         v_old_deleted
     FROM PREFIX_REPLACEMENT_GROUPS prg
     JOIN PREFIX_REPLACEMENT_RULES prr ON prr.rule_id = prg.rule_id
  WHERE prg.id = p_old_link_id;
    
  IF v_old_deleted IS NOT NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, 'Rule deleted');
  END IF;
  
  IF (p_upd_link_id IS NOT NULL)
  THEN
    SELECT COUNT(1) INTO v_exist
    FROM PREFIX_REPLACEMENT_GROUPS prg
    WHERE prg.id = p_upd_link_id;  
    
    IF (v_exist IS NULL OR v_exist = 0)
    THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Rule not exist');
    END IF;
  
    SELECT prg.start_date,
           prg.end_date ,
           prr.original_prefix,
           prr.overwritting_prefix,
           prr.min_phone_length,
           prr.max_phone_length,
           prr.description,
           prr.home_network_operator_id,
           prg.group_id,
           prg.deleted
      INTO v_upd_start_date, 
           v_upd_end_date,
           v_upd_original_prefix,
           v_upd_overwritting_prefix,
           v_upd_min_phone_number_length,
           v_upd_max_phone_number_length,
           v_upd_description,
           v_upd_home_network_operator_id,
           v_upd_group_id,
           v_upd_deleted
       FROM PREFIX_REPLACEMENT_GROUPS prg
       JOIN PREFIX_REPLACEMENT_RULES prr ON prr.rule_id = prg.rule_id
  WHERE prg.id = p_upd_link_id;
  END IF;
    
  IF v_upd_deleted IS NOT NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, 'Rule deleted');
  END IF;
  
  --Получим смешанный набор сетевых элементов
  --Заносим сетевые элементы во временную таюлицу

  DELETE FROM tmp_net_elements;
  
  INSERT INTO tmp_net_elements(
                  NETWORK_OPERATOR_ID,
                  HOST_ID,
                  LOCATION_AREA_ID,
                  BASE_STATION_ID)
      SELECT prne.NETWORK_OPERATOR_ID,
             prne.HOST_ID,
             prne.LOCATION_AREA_ID,
             prne.BASE_STATION_ID
             FROM PREFIX_REPLACEMENT_NET_EL prne
                 WHERE prne.group_id = v_old_group_id;

  FOR i IN p_new_network_operator_id.FIRST..p_new_network_operator_id.LAST
    LOOP
      INSERT INTO tmp_net_elements(
                  NETWORK_OPERATOR_ID,
                  HOST_ID,
                  LOCATION_AREA_ID,
                  BASE_STATION_ID)
                  VALUES(
                  p_new_network_operator_id(i),
                  p_new_host_id(i),
                  p_new_location_area_id(i),
                  p_new_base_station_id(i));
    END LOOP;
  
  --Удалим перекрывающиеся сетевые элементы
  DELETE FROM tmp_net_elements t1
     WHERE EXISTS(SELECT 1 FROM tmp_net_elements t2
                   WHERE t2.network_operator_id = t1.network_operator_id
                     AND ((t2.host_id IS NULL AND t1.host_id IS NOT NULL)
                       OR (t2.host_id IS NOT NULL AND t2.host_id = t1.host_id
                         AND ((t2.location_area_id IS NULL AND t1.location_area_id IS NOT NULL)
                           OR (t2.location_area_id IS NOT NULL AND t2.location_area_id = t1.location_area_id
                            AND (t2.base_station_id IS NULL AND t1.base_station_id IS NOT NULL))))));
                            
   SELECT distinct NETWORK_OPERATOR_ID,
          HOST_ID,
          LOCATION_AREA_ID,
          BASE_STATION_ID
     BULK COLLECT INTO v_ext_network_operator_id,
                       v_ext_host_id,
                       v_ext_location_area_id,
                       v_ext_base_station_id
     FROM tmp_net_elements;
  
  
  
  IF (v_old_start_date >= p_new_end_date OR v_old_end_date<= p_new_start_date)
  THEN
  --Если периоды действия правил не пересекаются.
  --просто добавим новое правило
   IF (p_upd_link_id IS NOT NULL)
   THEN
      Update_Rule(p_upd_link_id,
                  p_original_prefix => v_old_original_prefix,
                  p_overwritting_prefix => v_old_overwritting_prefix,
                  p_min_phone_number_length => v_old_min_phone_number_length,
                  p_max_phone_number_length => v_old_max_phone_number_length,
                  p_description => p_new_description,
                  p_home_network_operator_id => v_old_home_network_operator_id,
                  p_start_date => p_new_start_date,
                  p_end_date => p_new_end_date,
                  p_network_operator_id => p_new_network_operator_id,
                  p_host_id => p_new_host_id,
                  p_location_area_id => p_new_location_area_id,
                  p_base_station_id => p_new_base_station_id,
                  p_group_operation => p_group_operation,
                  p_user_id_of_change => p_user_id_of_change,
                  p_handle_tran => 'N',
                  p_raise_error => 'Y',
                  p_error_code => p_error_code,
                  p_error_message => p_error_message);
    ELSE
      Insert_New_Rule( p_original_prefix => v_old_original_prefix,
                       p_overwritting_prefix => v_old_overwritting_prefix,
                       p_min_phone_number_length => v_old_min_phone_number_length,
                       p_max_phone_number_length => v_old_max_phone_number_length,
                       p_description => p_new_description,
                       p_home_network_operator_id => v_old_home_network_operator_id,
                       p_start_date => p_new_start_date,
                       p_end_date => p_new_end_date,
                       p_network_operator_id => p_new_network_operator_id,
                       p_host_id => p_new_host_id,
                       p_location_area_id => p_new_location_area_id,
                       p_base_station_id => p_new_base_station_id,
                       p_user_id_of_change => p_user_id_of_change,
                       p_handle_tran => 'N',
                       p_raise_error => 'Y',
                       p_row_identifer => v_link_id,
                       p_error_code => p_error_code,
                       p_error_message => p_error_message);
    END IF;
  ELSE  
    IF (v_old_start_date<=sysdate OR v_old_start_date<=p_new_start_date - 1/24/60/60)
    THEN
      --Если группа правил к которой хотим добавить активна или начинает действовать
      -- до начала действия нового/изменяемого правила закроем ее
       UPDATE PREFIX_REPLACEMENT_GROUPS prg
          SET prg.end_date = p_new_start_date - 1/24/60/60
          WHERE prg.id = p_old_link_id AND (prg.end_date IS NULL OR prg.end_date > p_new_start_date - 1/24/60/60);
    ELSE
        UPDATE PREFIX_REPLACEMENT_GROUPS prg
          SET prg.deleted = sysdate
        WHERE prg.id = p_old_link_id;
    END IF;
    
    IF (v_upd_start_date<=sysdate)
    THEN
       v_upd_start_date := sysdate;
      --Если обновляемое правило активно закроем его
       UPDATE PREFIX_REPLACEMENT_GROUPS prg
          SET prg.end_date = v_upd_start_date
          WHERE prg.id = p_upd_link_id AND (prg.end_date IS NULL OR prg.end_date > v_upd_start_date);
    ELSE 
        UPDATE PREFIX_REPLACEMENT_GROUPS prg
          SET prg.deleted = sysdate
        WHERE prg.id = p_upd_link_id;
    END IF;
    
    --- Если обновляемое правило начинается раньшеБ создадим правило на период p_new_start_date..v_old_start_date
    IF (p_new_start_date<=v_old_start_date - 1/24/60/60)
    THEN
      --Создадим связку для правила с новыми параметрами
      Insert_New_Rule(  p_original_prefix => v_old_original_prefix,
                        p_overwritting_prefix => v_old_overwritting_prefix,
                        p_min_phone_number_length => v_old_min_phone_number_length,
                        p_max_phone_number_length => v_old_max_phone_number_length,
                        p_description => p_new_description,
                        p_home_network_operator_id => v_old_home_network_operator_id,
                        p_start_date => p_new_start_date,
                        p_end_date => v_old_start_date - 1/24/60/60,
                        p_network_operator_id => p_new_network_operator_id,
                        p_host_id => p_new_host_id,
                        p_location_area_id => p_new_location_area_id,
                        p_base_station_id => p_new_base_station_id,
                        p_user_id_of_change => p_user_id_of_change,
                        p_handle_tran => 'N',
                        p_raise_error => 'Y',
                        p_row_identifer => v_link_id,
                        p_error_code => p_error_code,
                        p_error_message => p_error_message);
    END IF;
    
    v_end_date:=v_old_end_date;
    
    IF (v_end_date IS NULL OR
        (p_new_end_date IS NOT NULL AND 
         v_end_date> p_new_end_date - 1/24/60/60))
    THEN
      v_end_date:=p_new_end_date;
    END IF;
    
    --Создадим связку для общей группы
    IF (p_new_start_date<=v_old_start_date - 1/24/60/60)
    THEN
      Insert_New_Rule(p_original_prefix => v_old_original_prefix,
                      p_overwritting_prefix => v_old_overwritting_prefix,
                      p_min_phone_number_length => v_old_min_phone_number_length,
                      p_max_phone_number_length => v_old_max_phone_number_length,
                      p_description => v_old_description,
                      p_home_network_operator_id => v_old_home_network_operator_id,
                      p_start_date => v_old_start_date,
                      p_end_date => v_end_date,
                      p_network_operator_id => v_ext_network_operator_id,
                      p_host_id => v_ext_host_id,
                      p_location_area_id => v_ext_location_area_id,
                      p_base_station_id => v_ext_base_station_id,
                      p_user_id_of_change => p_user_id_of_change,
                      p_handle_tran => 'N',
                      p_raise_error => 'Y',
                      p_row_identifer => v_link_id,
                      p_error_code => p_error_code,
                      p_error_message => p_error_message);
     ELSE
       
      Insert_New_Rule(p_original_prefix => v_old_original_prefix,
                      p_overwritting_prefix => v_old_overwritting_prefix,
                      p_min_phone_number_length => v_old_min_phone_number_length,
                      p_max_phone_number_length => v_old_max_phone_number_length,
                      p_description => v_old_description,
                      p_home_network_operator_id => v_old_home_network_operator_id,
                      p_start_date => p_new_start_date,
                      p_end_date => v_end_date,
                      p_network_operator_id => v_ext_network_operator_id,
                      p_host_id => v_ext_host_id,
                      p_location_area_id => v_ext_location_area_id,
                      p_base_station_id => v_ext_base_station_id,
                      p_user_id_of_change => p_user_id_of_change,
                      p_handle_tran => 'N',
                      p_raise_error => 'Y',
                      p_row_identifer => v_link_id,
                      p_error_code => p_error_code,
                      p_error_message => p_error_message);
     END IF;
    --Создадим заключительную связку
    IF (v_end_date IS NOT NULL AND 
        (v_old_end_date IS NULL OR v_end_date + 1/24/60/60 < v_old_end_date))
    THEN
      --Определим набор сетевых элементов для новой группы
        
        SELECT prne.NETWORK_OPERATOR_ID,
               prne.HOST_ID,
               prne.LOCATION_AREA_ID,
               prne.BASE_STATION_ID
           BULK COLLECT INTO v_old_network_operator_id,
                             v_old_host_id,
                             v_old_location_area_id,
                             v_old_base_station_id
               FROM PREFIX_REPLACEMENT_NET_EL prne
                   WHERE prne.group_id = v_old_group_id;
      IF (v_old_network_operator_id.COUNT>0)
      THEN            
        Insert_New_Rule(p_original_prefix => v_old_original_prefix,
                        p_overwritting_prefix => v_old_overwritting_prefix,
                        p_min_phone_number_length => v_old_min_phone_number_length,
                        p_max_phone_number_length => v_old_max_phone_number_length,
                        p_description => v_old_description,
                        p_home_network_operator_id => v_old_home_network_operator_id,
                        p_start_date => v_end_date + 1/24/60/60,
                        p_end_date => v_old_end_date,
                        p_network_operator_id => v_old_network_operator_id,
                        p_host_id => v_old_host_id,
                        p_location_area_id => v_old_location_area_id,
                        p_base_station_id => v_old_base_station_id,
                        p_user_id_of_change => p_user_id_of_change,
                        p_handle_tran => 'N',
                        p_raise_error => 'Y',
                        p_row_identifer => v_link_id,
                        p_error_code => p_error_code,
                        p_error_message => p_error_message);
      END IF;
    END IF;
    
    IF (v_end_date IS NOT NULL AND 
        (p_new_end_date IS NULL OR v_end_date + 1/24/60/60 < p_new_end_date))
    THEN
      Insert_New_Rule(p_original_prefix => v_old_original_prefix,
                      p_overwritting_prefix => v_old_overwritting_prefix,
                      p_min_phone_number_length => v_old_min_phone_number_length,
                      p_max_phone_number_length => v_old_max_phone_number_length,
                      p_description => p_new_description,
                      p_home_network_operator_id => v_old_home_network_operator_id,
                      p_start_date => v_end_date + 1/24/60/60,
                      p_end_date => p_new_end_date,
                      p_network_operator_id => p_new_network_operator_id,
                      p_host_id => p_new_host_id,
                      p_location_area_id => p_new_location_area_id,
                      p_base_station_id => p_new_base_station_id,
                      p_user_id_of_change => p_user_id_of_change,
                      p_handle_tran => 'N',
                      p_raise_error => 'Y',
                      p_row_identifer => v_link_id,
                      p_error_code => p_error_code,
                      p_error_message => p_error_message);
    END IF;
    
     --Если не групповая операция
    IF (p_group_operation = rsig_utils.c_NO )
    THEN
      --Определим набор сетевых элементов для новой группы
      --Заносим сетевые элементы во временную таюлицу

      DELETE FROM tmp_net_elements;

      FOR i IN p_new_network_operator_id.FIRST..p_new_network_operator_id.LAST
        LOOP
          INSERT INTO tmp_net_elements(
                      NETWORK_OPERATOR_ID,
                      HOST_ID,
                      LOCATION_AREA_ID,
                      BASE_STATION_ID)
                      VALUES(
                      p_new_network_operator_id(i),
                      p_new_host_id(i),
                      p_new_location_area_id(i),
                      p_new_base_station_id(i));
        END LOOP;
        
      SELECT NETWORK_OPERATOR_ID,
             HOST_ID,
             LOCATION_AREA_ID,
             BASE_STATION_ID
         BULK COLLECT INTO v_new_network_operator_id,
                           v_new_host_id,
                           v_new_location_area_id,
                           v_new_base_station_id
             FROM 
             ((SELECT prne.NETWORK_OPERATOR_ID,
                      prne.HOST_ID,
                      prne.LOCATION_AREA_ID,
                      prne.BASE_STATION_ID FROM PREFIX_REPLACEMENT_NET_EL prne
                        where prne.group_id = v_upd_group_id)
               MINUS
               (SELECT tt.NETWORK_OPERATOR_ID,
                      tt.HOST_ID,
                      tt.LOCATION_AREA_ID,
                      tt.BASE_STATION_ID FROM tmp_net_elements tt
                ));
                
                
      --Если правило изменено не для всех сетевых элементов,
      --создадим новую связку
      IF (v_new_network_operator_id.COUNT>0)
      THEN
        Insert_New_Rule(p_original_prefix => v_upd_original_prefix,
                        p_overwritting_prefix => v_upd_overwritting_prefix,
                        p_min_phone_number_length => v_upd_min_phone_number_length,
                        p_max_phone_number_length => v_upd_max_phone_number_length,
                        p_description => v_upd_description,
                        p_home_network_operator_id => v_upd_home_network_operator_id,
                        p_start_date => v_upd_start_date,
                        p_end_date => v_upd_end_date,
                        p_network_operator_id => v_new_network_operator_id,
                        p_host_id => v_new_host_id,
                        p_location_area_id => v_new_location_area_id,
                        p_base_station_id => v_new_base_station_id,
                        p_user_id_of_change => p_user_id_of_change,
                        p_handle_tran => 'N',
                        p_raise_error => 'Y',
                        p_row_identifer => v_link_id,
                        p_error_code => p_error_code,
                        p_error_message => p_error_message);                        
      END IF;
    END IF;
  END IF;
   
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE p_handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Update_Prefix_Replacement_a;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Extend_Network_Element_Group;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_Rules_Count
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Rules_Count(
  p_show_deleted               IN   CHAR,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_total_count_value          OUT  NUMBER,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Get_Rules_Count';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
  
  p_total_count_value:=0;
-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
 
    p_total_count_value:=0;
    SELECT
          COUNT(1) INTO p_total_count_value
          FROM PREFIX_REPLACEMENT_GROUPS prg
          LEFT JOIN PREFIX_REPLACEMENT_RULES prr ON (prg.rule_id = prr.rule_id)
          LEFT JOIN PREFIX_REPLACEMENT_NET_EL prne ON (prg.group_id = prne.group_id)
          LEFT JOIN NETWORK_OPERATOR no ON no.network_operator_id = prne.network_operator_id
          LEFT JOIN HOST h ON h.host_id = prne.host_id
          LEFT JOIN LOCATION_AREA la ON la.location_area_id = prne.location_area_id
          LEFT JOIN BASE_STATION bs ON bs.base_station_id = prne.base_station_id
          LEFT JOIN NETWORK_OPERATOR hno ON hno.network_operator_id = prr.home_network_operator_id
          WHERE (p_show_deleted = 'Y' OR prg.deleted IS NULL);
   
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Rules_Count;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_Network_Elements_2
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Network_Elements_2(
  p_level                      IN NUMBER,
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_PREFIX_REPLACEMENT.Get_Network_Elements_2';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  -- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
 OPEN p_result FOR 
  SELECT distinct no.network_operator_id,
         no.network_operator_code,
         no.network_operator_name,
         h.host_id,
         h.host_code,
         h.host_name,
         la.location_area_id,
         la.location_area_code,
         la.location_area_name,
         bs.base_station_id,
         bs.base_station_code,
         bs.base_station_name
           FROM NETWORK_OPERATOR no
           JOIN HOST h ON h.network_operator_id = no.network_operator_id
           JOIN HOST_TYPE ht ON ht.HOST_TYPE_CODE = h.host_type_code
           JOIN LOCATION_AREA la ON la.host_id = h.host_id
           JOIN BASE_STATION bs ON bs.location_area_id = la.location_area_id
           WHERE --no.NETWORK_OPERATOR_TYPE IS null AND 
                 no.deleted is NULL AND 
                 h.deleted is NULL AND 
                 la.deleted is NULL AND 
                 bs.deleted is NULL AND 
                 (p_level >=3 OR p_level IS NULL) AND
                 UPPER(ht.IS_EXCHANGE) = 'Y'
   UNION SELECT distinct no.network_operator_id,
         no.network_operator_code,
         no.network_operator_name,
         h.host_id,
         h.host_code,
         h.host_name,
         la.location_area_id,
         la.location_area_code,
         la.location_area_name,
         TO_NUMBER(CASE WHEN p_level=2 THEN -1 ELSE NULL END) AS base_station_id,
         TO_CHAR(NULL) AS base_station_code,
         TO_CHAR(NULL) AS base_station_name
           FROM NETWORK_OPERATOR no
           JOIN HOST h ON h.network_operator_id = no.network_operator_id
           JOIN HOST_TYPE ht ON ht.HOST_TYPE_CODE = h.host_type_code
           JOIN LOCATION_AREA la ON la.host_id = h.host_id
           WHERE --no.NETWORK_OPERATOR_TYPE IS null AND 
                 no.deleted is NULL AND 
                 h.deleted is NULL AND 
                 la.deleted is NULL AND 
                 (p_level >=2 OR p_level IS NULL) AND
                 UPPER(ht.IS_EXCHANGE) = 'Y'
   UNION SELECT distinct no.network_operator_id,
         no.network_operator_code,
         no.network_operator_name,
         h.host_id,
         h.host_code,
         h.host_name,
         TO_NUMBER(CASE WHEN p_level=1 THEN -1 ELSE NULL END) AS location_area_id,
         TO_CHAR(NULL) AS location_area_code,
         TO_CHAR(NULL) AS location_area_name,
         TO_NUMBER(NULL) AS base_station_id,
         TO_CHAR(NULL) AS base_station_code,
         TO_CHAR(NULL) AS base_station_name
           FROM NETWORK_OPERATOR no
           JOIN HOST h ON h.network_operator_id = no.network_operator_id
           JOIN HOST_TYPE ht ON ht.HOST_TYPE_CODE = h.host_type_code
           WHERE --no.NETWORK_OPERATOR_TYPE IS null AND 
                 no.deleted is NULL AND 
                 h.deleted is NULL AND 
                 (p_level >=1 OR p_level IS NULL) AND
                 UPPER(ht.IS_EXCHANGE) = 'Y'
   UNION SELECT distinct no.network_operator_id,
         no.network_operator_code,
         no.network_operator_name,
         TO_NUMBER(CASE WHEN p_level<=0 THEN -1 ELSE NULL END) AS host_id,
         TO_CHAR(NULL) AS host_code,
         TO_CHAR(NULL) AS host_name,
         TO_NUMBER(NULL) AS location_area_id,
         TO_CHAR(NULL) AS location_area_code,
         TO_CHAR(NULL) AS location_area_name,
         TO_NUMBER(NULL) AS base_station_id,
         TO_CHAR(NULL) AS base_station_code,
         TO_CHAR(NULL) AS base_station_name
           FROM NETWORK_OPERATOR no
           WHERE --no.NETWORK_OPERATOR_TYPE IS null AND 
                 no.deleted is NULL;
  
        
   
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- set error code to succesfully completed
	p_error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		
END Get_Network_Elements_2;

END RSIG_PREFIX_REPLACEMENT;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_PREFIX_REPLACEMENT.pkb,v 1.12 2004/01/05 10:17:38 jstodulk Exp $
/
