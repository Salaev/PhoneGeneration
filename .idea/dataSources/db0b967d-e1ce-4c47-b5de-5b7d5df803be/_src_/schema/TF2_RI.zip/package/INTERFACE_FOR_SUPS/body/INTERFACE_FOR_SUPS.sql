CREATE PACKAGE BODY INTERFACE_FOR_SUPS IS
------------------------------------------------------------------------------------------------------------------------------
--  Get_Phones_By_SIM_list2
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Phones_By_SIM_list2(
  p_IMSI_list        IN   t_imsi,
  p_date_list        IN   t_date,
  p_raise_error      IN   CHAR,
  error_code         OUT  NUMBER,
  error_message      OUT  VARCHAR2,
  result_list        OUT  SYS_REFCURSOR
)
IS
	v_sqlcode	         number;
  v_event_source     varchar2(60) :='INTERFACE_FOR_SUPS.Get_Phones_By_SIM_list';
  v_sysdate          DATE:=SYSDATE;
  v_IMSI_DATE_OBJ         t_imsi_date_obj:=t_imsi_date_obj(NULL,NULL);
  v_IMSI_DATE_list			  t_imsi_date_obj_tab:= t_imsi_date_obj_tab(); 
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
  --check p_IMSI_list parameter
  IF (p_IMSI_list.COUNT = 0) OR (p_IMSI_list.COUNT = 1 AND p_IMSI_list(p_IMSI_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
  
	IF p_IMSI_list.COUNT <> p_date_list.COUNT THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

-- start of the procedure body --------------------------------------------------------------------------------------------------
    FOR i IN nvl(p_IMSI_list.FIRST, 1) .. nvl(p_IMSI_list.LAST, 0) 
  loop 
    v_IMSI_DATE_OBJ:=t_imsi_date_obj(p_IMSI_list(i),nvl(p_date_list(i),v_sysdate));
    v_IMSI_DATE_list.extend; 
    v_IMSI_DATE_list(i):=v_IMSI_DATE_OBJ; 
  end loop; 

  OPEN result_list FOR
  SELECT /*+ ordered use_nl(tt, sc, naap, pn)
    full(tt)
    index_asc(sc, I_IMSI_ACCESS_POINT_ID)
    index_asc(naap, I_NETADDRACCPO_ACCESS_POINT_ID)
    index_asc(pn, PK_PHONE_NUMBER)
    vsmirnov*/
        tt.imsi,
        tt.datetime,
        pn.International_Format
  FROM TABLE(CAST(v_IMSI_DATE_list AS t_imsi_date_obj_tab)) tt
  JOIN sim_card sc ON sc.imsi=tt.imsi
  JOIN network_address_access_point naap ON naap.access_point_id=sc.access_point_id
        AND tt.datetime BETWEEN naap.from_date AND nvl(naap.to_date,tt.datetime)
        AND TRIM(naap.link_type_code)=rsig_utils.c_MAIN_LINK_TYPE
  JOIN phone_number pn ON pn.network_address_id=naap.network_address_id
  WHERE (pn.deleted IS NULL OR pn.deleted>tt.datetime);


  COMMIT;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Phones_By_SIM_list2;


  -------------------------------------------
  ------- Get_Phone_By_PA_And_IMSI
  -------------------------------------------
  PROCEDURE Get_Phone_By_PA_And_IMSI
  (
    ERROR_CODE         OUT NUMBER,
    p_PA               IN  sim_card.personal_account%TYPE,
    p_IMSI             IN  sim_card.imsi%TYPE,
    p_Date_of_validity IN  DATE,
    p_Phone_number     OUT phone_number.International_Format%TYPE
  ) IS
    v_package_name          VARCHAR2(30) := 'INTERFACE_FOR_SUPS';
    v_procedure_name        VARCHAR2(30) := 'Get_Phone_By_PA_And_IMSI';
    v_event_source          VARCHAR2(60);
    v_date                  DATE := NVL(p_date_of_validity,SYSDATE);
  BEGIN
    ERROR_CODE := rsig_utils.c_ok;

    v_event_source:=v_package_name || '.' || v_procedure_name;
    -- log start of procedure
    Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);

    -- check input parameters
    IF p_IMSI IS NULL THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
    END IF;

    SELECT /*+ leading(appa) use_nl(appa, sc, naap, pn)
    index_asc(appa, I_APPA_PERSONAL_ACCOUNT)
    index_asc(sc, I_ACCESS_POINT_ID_IMSI)
    index_asc(naap, I_NETADDRACCPO_ACCESS_POINT_ID)
    index_asc(pn, PK_PHONE_NUMBER)
    vsmirnov*/
      pn.international_format INTO p_phone_number
      FROM sim_card sc
      JOIN access_point_personal_account appa ON appa.access_point_id = sc.access_point_id
      JOIN network_address_access_point naap ON sc.access_point_id = naap.access_point_id
      JOIN phone_number pn ON pn.network_address_id = naap.network_address_id
     WHERE appa.personal_account = p_PA
       AND TRIM(sc.imsi) = TRIM(p_imsi)
       AND v_date BETWEEN naap.from_date AND NVL(naap.to_date, v_date)
       AND v_date BETWEEN appa.from_date AND NVL(appa.to_date, v_date)
       AND (pn.deleted IS NULL OR pn.deleted>SYSDATE);

    -- log end of procedure
    Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      p_phone_number := NULL;
    WHEN OTHERS THEN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(p_Text         => TO_CHAR(ERROR_CODE),
                           p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_0,
                           p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           p_Event_Source => 'INTERFACE_FOR_SUPS.Get_Phone_By_PA_And_IMSI');

  END Get_Phone_By_PA_And_IMSI;

  -------------------------------------------
  ------- Get_IMSI_By_PA_And_Phone
  -------------------------------------------

  PROCEDURE Get_IMSI_By_PA_And_Phone
  (
    ERROR_CODE          OUT NUMBER,
    p_PA                IN  sim_card.personal_account%TYPE,
    p_Phone_number      IN  phone_number.international_format%TYPE,
    p_Date_of_validity  IN  DATE,
    p_IMSI              OUT sim_card.imsi%TYPE
  ) IS
    v_package_name          VARCHAR2(30) := 'INTERFACE_FOR_SUPS';
    v_procedure_name        VARCHAR2(30) := 'Get_IMSI_By_PA_And_Phone';
    v_event_source          VARCHAR2(60);
    v_date                  DATE := NVL(p_date_of_validity,SYSDATE);
  BEGIN
    ERROR_CODE := rsig_utils.c_ok;

    v_event_source:=v_package_name || '.' || v_procedure_name;
    -- log start of procedure
    Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);

    -- check input parameters
    IF p_Phone_number IS NULL THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
    END IF;

    SELECT sc.imsi INTO p_IMSI
      FROM (SELECT *
              FROM phone_number
             WHERE international_format = p_phone_number) pn
      JOIN network_address_access_point naap ON naap.network_address_id = pn.network_address_id
           AND v_date BETWEEN naap.from_date AND NVL(naap.to_date, v_date)
      JOIN (SELECT sc2.access_point_id,
                   appa2.personal_account,
                   sc2.imsi
              FROM sim_card sc2
              LEFT JOIN access_point_personal_account appa2
                ON appa2.access_point_id = sc2.access_point_id
                   AND v_date BETWEEN appa2.from_date AND NVL(appa2.to_date, v_date)) sc ON sc.access_point_id = naap.access_point_id
     WHERE sc.personal_account = p_PA
       AND (pn.deleted IS NULL OR pn.deleted>SYSDATE);

    -- log end of procedure
    Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      p_IMSI := NULL;
    WHEN OTHERS THEN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(p_Text         => TO_CHAR(ERROR_CODE),
                           p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_0,
                           p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           p_Event_Source => 'INTERFACE_FOR_SUPS.Get_IMSI_By_PA_And_Phone');

  END Get_IMSI_By_PA_And_Phone;

  -------------------------------------------
  ------- Get_IMSI_And_Phone_By_PA
  -------------------------------------------

  PROCEDURE Get_IMSI_And_Phone_By_PA
  (
    ERROR_CODE         OUT NUMBER,
    p_PA               IN  sim_card.personal_account%TYPE,
    p_Date_of_validity IN  DATE,
    result_list        OUT sys_refcursor
  ) IS
    v_package_name          VARCHAR2(30) := 'INTERFACE_FOR_SUPS';
    v_procedure_name        VARCHAR2(30) := 'Get_IMSI_And_Phone_By_PA';
    v_event_source          VARCHAR2(60);
    v_date                  DATE := NVL(p_date_of_validity,SYSDATE);
  BEGIN
    ERROR_CODE := rsig_utils.c_ok;

    v_event_source:=v_package_name || '.' || v_procedure_name;
    -- log start of procedure
    Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);

    OPEN result_list FOR
      SELECT /*+ leading(appa) use_nl(appa, sc, naap, pn)
    index_asc(appa, I_APPA_PERSONAL_ACCOUNT)
    index_asc(sc, I_ACCESS_POINT_ID_IMSI)
    index_asc(naap, I_NETADDRACCPO_ACCESS_POINT_ID)
    index_asc(pn, PK_PHONE_NUMBER)
    vsmirnov*/
             sc.imsi, pn.international_format AS pnumber
        FROM network_address_access_point naap
        JOIN sim_card sc ON sc.access_point_id = naap.access_point_id
        JOIN access_point_personal_account appa ON appa.access_point_id = sc.access_point_id
        JOIN phone_number pn ON pn.network_address_id = naap.network_address_id
       WHERE appa.personal_account = p_PA
         AND TRIM(naap.link_type_code) = TRIM(rsig_utils.c_MAIN_LINK_TYPE)
         AND v_date BETWEEN naap.from_date AND NVL(naap.to_date, v_date)
         AND v_date BETWEEN appa.from_date AND NVL(appa.to_date, v_date)
         AND (pn.deleted IS NULL OR pn.deleted>SYSDATE);
    -- log end of procedure
    Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      OPEN Result_list FOR
        SELECT ERROR_CODE FROM dual;
    WHEN OTHERS THEN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(p_Text         => TO_CHAR(ERROR_CODE),
                           p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_0,
                           p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           p_Event_Source => 'INTERFACE_FOR_SUPS.Get_IMSI_By_PA_And_Phone');

  END Get_IMSI_And_Phone_By_PA;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Phone_By_PA_And_IMSI_List
------------------------------------------------------------------------------------------------------------------------------
procedure Get_Phone_By_PA_And_IMSI_List(
  p_PA_list         IN  t_PA,
  p_IMSI_list       IN  t_imsi,
  p_Date_list       IN  t_date,
  p_raise_error     IN  CHAR,
  error_code        OUT NUMBER,
  error_message     OUT VARCHAR2,
  result_list       OUT sys_refcursor
)
IS
	v_sqlcode	        number;
  v_event_source    varchar2(60) :='INTERFACE_FOR_SUPS.Get_Phone_By_PA_And_IMSI_List';
  v_sysdate         DATE:=SYSDATE;
  v_PA_IMSI_DATE_OBJ        t_pa_imsi_date_obj:=t_pa_imsi_date_obj(NULL,NULL,NULL);
  v_PA_IMSI_DATE_list			  t_pa_imsi_date_obj_tab:= t_pa_imsi_date_obj_tab();
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
  
  --check p_PA_list parameter
  IF (p_PA_list.COUNT = 0) OR (p_PA_list.COUNT = 1 AND p_PA_list(p_PA_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
    --check p_IMSI_list parameter
  IF (p_IMSI_list.COUNT = 0) OR (p_IMSI_list.COUNT = 1 AND p_IMSI_list(p_IMSI_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF; 

	IF p_PA_list.COUNT != p_IMSI_list.COUNT OR p_IMSI_list.COUNT != p_Date_list.COUNT THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

-- start of the procedure body --------------------------------------------------------------------------------------------------
    FOR i IN nvl(p_PA_list.FIRST, 1) .. nvl(p_PA_list.LAST, 0)
  loop 
    v_PA_IMSI_DATE_OBJ:=t_pa_imsi_date_obj(p_PA_list(i),p_IMSI_list(i),nvl(p_Date_list(i),v_sysdate));
    v_PA_IMSI_DATE_list.extend; 
    v_PA_IMSI_DATE_list(i):=v_PA_IMSI_DATE_OBJ; 
  end loop; 

    OPEN result_list FOR
    SELECT /*+ ordered use_nl(tt, sc, appa, naap, pn)
    full(tt)
    index_asc(sc, UK_SIM_IMSI)
    index_asc(appa, I_APPA_ACCESS_POINT_ID)
    index_asc(naap, I_NETADDRACCPO_ACCESS_POINT_ID)
    index_asc(pn, PK_PHONE_NUMBER)
    vsmirnov*/
             appa.personal_account,
             sc.imsi,
             pn.international_format
    	FROM TABLE(CAST(v_PA_IMSI_DATE_list AS t_pa_imsi_date_obj_tab)) tt
      JOIN sim_card sc ON sc.imsi = tt.imsi
      JOIN access_point_personal_account appa
        ON appa.access_point_id = sc.access_point_id
       AND tt.datetime BETWEEN appa.from_date AND NVL(appa.to_date, tt.datetime)
      JOIN network_address_access_point naap ON naap.access_point_id=sc.access_point_id
           AND tt.datetime BETWEEN naap.FROM_DATE AND nvl(naap.to_date, tt.datetime)
           AND TRIM(naap.LINK_TYPE_CODE) = TRIM(rsig_utils.c_MAIN_LINK_TYPE)
      JOIN phone_number pn ON pn.network_address_id=naap.network_address_id
     WHERE sc.access_point_id=sc.access_point_id
       AND sc.personal_account = tt.pa
       AND (pn.deleted IS NULL OR pn.deleted>tt.datetime);

  COMMIT;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Phone_By_PA_And_IMSI_List;

------------------------------------------------------------------------------------------------------------------------------
--  Get_IMSI_By_PA_And_Phone_List
------------------------------------------------------------------------------------------------------------------------------
procedure Get_IMSI_By_PA_And_Phone_List(
  p_PA_list          IN   t_PA,
  p_PN_list          IN   t_PHONE,
  p_date_list        IN   t_date,
  p_raise_error      IN   CHAR,
  error_code         OUT  NUMBER,
  error_message      OUT  VARCHAR2,
  result_list        OUT  SYS_REFCURSOR
)
IS
	v_sqlcode	         number;
  v_event_source     varchar2(60) :='INTERFACE_FOR_SUPS.Get_IMSI_By_PA_And_Phone_List';
  v_sysdate          DATE :=SYSDATE;
  v_PA_PHONE_DATE_OBJ        t_pa_phone_date_obj:=t_pa_phone_date_obj(NULL,NULL,NULL);
  v_PA_PHONE_DATE_list			  t_pa_phone_date_obj_tab:= t_pa_phone_date_obj_tab();
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

  --check p_PA_list parameter
  IF (p_PA_list.COUNT = 0) OR (p_PA_list.COUNT = 1 AND p_PA_list(p_PA_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
    --check p_PN_list parameter
  IF (p_PN_list.COUNT = 0) OR (p_PN_list.COUNT = 1 AND p_PN_list(p_PN_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
    
	IF p_PA_list.COUNT <> p_PN_list.COUNT OR p_PN_list.COUNT<>p_date_list.COUNT THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

  DELETE FROM tt_batch_na_ap;

-- start of the procedure body --------------------------------------------------------------------------------------------------
   FOR i IN nvl(p_PA_list.FIRST, 1) .. nvl(p_PA_list.LAST, 0) 
  loop 
    v_PA_PHONE_DATE_OBJ:=t_pa_phone_date_obj(p_PA_list(i),p_PN_list(i),nvl(p_date_list(i),v_sysdate));
    v_PA_PHONE_DATE_list.extend; 
    v_PA_PHONE_DATE_list(i):=v_PA_PHONE_DATE_OBJ; 
  end loop; 

      OPEN result_list FOR
      SELECT /*+ ordered use_nl(tt, pn, naap, sc, appa)
    full(tt)
    index_asc(pn, UK_PHONE_NUM_PHONE_NUMBER)
    index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID)
    index_asc(sc, I_ACCESS_POINT_ID_IMSI)
    index_asc(appa, I_APPA_ACCESS_POINT_ID)
    vsmirnov*/
             appa.personal_account,
             sc.imsi,
             tt.phone
      FROM TABLE(CAST(v_PA_PHONE_DATE_list AS t_pa_phone_date_obj_tab)) tt
      LEFT JOIN phone_number pn ON pn.international_format=tt.phone
           AND (pn.deleted IS NULL OR pn.deleted>tt.datetime)
      LEFT JOIN network_address_access_point naap ON naap.network_address_id=pn.network_address_id
           AND tt.datetime BETWEEN naap.from_date AND nvl(naap.to_date,tt.datetime)
      LEFT JOIN sim_card sc ON sc.access_point_id = naap.access_point_id
      LEFT JOIN access_point_personal_account appa
        ON appa.access_point_id = sc.access_point_id
       AND tt.datetime BETWEEN appa.from_date AND NVL(appa.to_date, tt.datetime)
      ORDER BY tt.pa,tt.phone;

  COMMIT;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_IMSI_By_PA_And_Phone_List;

------------------------------------------------------------------------------------------------------------------------------
--  Get_IMSI_And_Phone_By_PA_List
------------------------------------------------------------------------------------------------------------------------------
procedure Get_IMSI_And_Phone_By_PA_List(
  p_PA_list          IN   t_PA,
  p_date_list        IN   t_date,
  p_raise_error      IN   CHAR,
  error_code         OUT  NUMBER,
  error_message      OUT  VARCHAR2,
  result_list        OUT  SYS_REFCURSOR
)
IS
	v_sqlcode	         number;
  v_event_source     varchar2(60) :='INTERFACE_FOR_SUPS.Get_IMSI_And_Phone_By_PA_List';
  v_sysdate          DATE :=SYSDATE;
  v_PA_DATE_OBJ        t_pa_date_obj:=t_pa_date_obj(NULL,NULL);
  v_PA_DATE_list			  t_pa_date_obj_tab:= t_pa_date_obj_tab();
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

  --check p_PA_list parameter
  IF (p_PA_list.COUNT = 0) OR (p_PA_list.COUNT = 1 AND p_PA_list(p_PA_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
    
	IF p_PA_list.COUNT <> p_date_list.COUNT THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

-- start of the procedure body --------------------------------------------------------------------------------------------------
  FOR i IN nvl(p_PA_list.FIRST, 1) .. nvl(p_PA_list.LAST, 0) 
  loop 
    v_PA_DATE_OBJ:=t_pa_date_obj(p_PA_list(i),nvl(p_date_list(i),v_sysdate));
    v_PA_DATE_list.extend; 
    v_PA_DATE_list(i):=v_PA_DATE_OBJ; 
  end loop;

    OPEN result_list FOR
    SELECT /*+ ordered use_nl(tt, appa, sc, naap, pn)
    full(tt)
    index_asc(appa, I_APPA_PERSONAL_ACCOUNT)
    index_asc(sc, I_ACCESS_POINT_ID_IMSI)
    index_asc(naap, I_NETADDRACCPO_ACCESS_POINT_ID)
    index_asc(pn, PK_PHONE_NUMBER)
    vsmirnov*/
           tt.pa,
           sc.imsi ACCESS_POINT_DESC,
           pn.International_Format NETWORK_ADDRESS_DESC
    FROM TABLE(CAST(v_PA_DATE_list AS t_pa_date_obj_tab)) tt
    LEFT JOIN access_point_personal_account appa
      ON appa.personal_account = tt.pa
     AND tt.datetime BETWEEN appa.from_date AND NVL(appa.to_date, tt.datetime)
    LEFT JOIN sim_card sc ON sc.access_point_id = appa.access_point_id
    LEFT JOIN network_address_access_point naap ON naap.access_point_id=sc.access_point_id
              AND tt.datetime BETWEEN naap.from_date AND nvl(naap.to_date,tt.datetime)
              AND TRIM(naap.link_type_code)=rsig_utils.c_MAIN_LINK_TYPE
    LEFT JOIN phone_number pn ON pn.network_address_id=naap.network_address_id
         AND (pn.deleted IS NULL OR pn.deleted>tt.datetime)
    ORDER BY tt.pa,sc.imsi;

  COMMIT;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_IMSI_And_Phone_By_PA_List;

------------------------------------------------------------------------------------------------------------------------------
--  Get_IMSI_By_Phone_list
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_IMSI_By_Phone_list(
  p_PN_list          IN   t_PHONE,
  p_date_list        IN   t_date,
  p_raise_error      IN   CHAR,
  error_code         OUT  NUMBER,
  error_message      OUT  VARCHAR2,
  result_list        OUT  SYS_REFCURSOR
)
IS
	v_sqlcode	         number;
  v_event_source     varchar2(60) :='INTERFACE_FOR_SUPS.Get_IMSI_By_Phone_list';
  v_sysdate          DATE :=SYSDATE;
  v_PHONE_DATE_OBJ        t_phone_date_obj:=t_phone_date_obj(NULL,NULL);
  v_PHONE_DATE_list			  t_phone_date_obj_tab:= t_phone_date_obj_tab();
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

    --check p_PN_list parameter
  IF (p_PN_list.COUNT = 0) OR (p_PN_list.COUNT = 1 AND p_PN_list(p_PN_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
  
	IF p_PN_list.COUNT <> p_date_list.COUNT THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

-- start of the procedure body --------------------------------------------------------------------------------------------------
  FOR i IN nvl(p_PN_list.FIRST, 1) .. nvl(p_PN_list.LAST, 0) 
  loop 
    v_PHONE_DATE_OBJ:=t_phone_date_obj(p_PN_list(i),nvl(p_date_list(i),v_sysdate));
    v_PHONE_DATE_list.extend; 
    v_PHONE_DATE_list(i):=v_PHONE_DATE_OBJ; 
  end loop;

  OPEN result_list FOR
  SELECT /*+ ordered use_nl(tt, pn, naap, sc)
    full(tt)
    index_asc(pn, UK_PHONE_NUM_PHONE_NUMBER)
    index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID)
    index_asc(sc, I_ACCESS_POINT_ID_IMSI)
    vsmirnov*/
        tt.phone PHONE_NUMBER,
        tt.datetime,
        sc.imsi IMSI
  FROM TABLE(CAST(v_PHONE_DATE_list AS t_phone_date_obj_tab)) tt
  LEFT JOIN phone_number pn ON pn.international_format=tt.phone
       AND (pn.deleted IS NULL OR pn.deleted>tt.datetime)
  LEFT JOIN network_address_access_point naap ON naap.network_address_id=pn.network_address_id
        AND tt.datetime BETWEEN naap.from_date AND nvl(naap.to_date,tt.datetime)
  LEFT JOIN sim_card sc ON sc.access_point_id=naap.access_point_id;


  COMMIT;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_IMSI_By_Phone_list;
  -------------------------------------------------------------------------------
  --      procedure Get_Phones_By_SIM_list_Ext
  -------------------------------------------------------------------------------

  PROCEDURE Get_Phones_By_SIM_list_Ext
  (
    p_SIM_list  IN t_IMSI,
    p_date_list IN t_date,
    result_list OUT sys_refcursor,
    ERROR_CODE  OUT NUMBER
  ) IS
    v_sysdate DATE;
    v_IMSI_DATE_OBJ  t_IMSI_date_obj := t_IMSI_date_obj(NULL, NULL);
    v_IMSI_DATE_list   t_IMSI_date_obj_tab := t_IMSI_date_obj_tab();
  BEGIN
    -- debug start
    RSIG_UTILS.Debug_Rsi(p_Text         => RSIG_UTILS.c_DEBUG_TEXT_START,
                         p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_1,
                         p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         p_Event_Source => 'INTERFACE_FOR_SUPS.Get_Phones_By_SIM_list_Ext');

    ERROR_CODE := rsig_utils.c_ok;


    --check p_SIM_list parameter
    IF (p_SIM_list.COUNT = 0) OR (p_SIM_list.COUNT = 1 AND p_SIM_list(p_SIM_list.FIRST) IS NULL) THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
    END IF;
      --check p_Date_list parameter
    IF (p_date_list.COUNT = 0) OR (p_date_list.COUNT = 1 AND p_date_list(p_date_list.FIRST) IS NULL) THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
    END IF;
      
    IF (p_SIM_list.COUNT <> p_date_list.COUNT) THEN
       RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
    END IF;
    
    -- fill object from input parameter
    FOR i IN nvl(p_SIM_list.FIRST, 1) .. nvl(p_SIM_list.LAST, 0) 
    loop 
      v_IMSI_DATE_OBJ:=t_imsi_date_obj(p_SIM_list(i),nvl(p_date_list(i),v_sysdate));
      v_IMSI_DATE_list.extend; 
      v_IMSI_DATE_list(i):=v_IMSI_DATE_OBJ; 
    end loop;

    v_sysdate := SYSDATE;
    DELETE TT_GET_PHONES_BY_SIM_LIST_EXT;

    INSERT INTO TT_GET_PHONES_BY_SIM_LIST_EXT
      (ACCESS_POINT_DESC,
       DATE_TIME,
       NETWORK_ADDRESS_DESC,
       UPRS_MEMBER_CODE,
       NETWORK_OPERATOR_ID)
      SELECT /*+ ordered use_nl(t, sc, naap, p, pso, no)
    full(t)
    index_asc(sc, I_IMSI_ACCESS_POINT_ID)
    index_asc(naap, I_NETADDRACCPO_ACCESS_POINT_ID)
    index_asc(p, PK_PHONE_NUMBER)
    index_asc(pso, I_PHOSEOPER_NO_PNS)
    index_asc(no, PK_NETWORK_OPERATOR)
    vsmirnov*/
             t.IMSI ACCESS_POINT_DESC,
             nvl(t.DATETIME, v_sysdate),
             p.INTERNATIONAL_FORMAT,
             no.UPRS_MEMBER_CODE,
             no.NETWORK_OPERATOR_ID
        FROM TABLE(CAST(v_IMSI_DATE_list AS t_IMSI_date_obj_tab)) t
        JOIN SIM_CARD sc ON sc.IMSI = t.IMSI
        JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON sc.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
        JOIN PHONE_NUMBER p ON naap.NETWORK_ADDRESS_ID = p.NETWORK_ADDRESS_ID
        JOIN PHONE_SERIES_OPERATOR pso ON pso.PHONE_NUMBER_SERIES_ID = p.PHONE_NUMBER_SERIES_ID
        JOIN NETWORK_OPERATOR NO ON pso.NETWORK_OPERATOR_ID = NO.NETWORK_OPERATOR_ID
       WHERE NVL(t.datetime, v_sysdate) BETWEEN naap.FROM_DATE AND
             nvl(naap.TO_DATE, NVL(t.DATETIME, v_sysdate))
         AND NVL(t.datetime, v_sysdate) BETWEEN pso.START_DATE AND
             nvl(pso.END_DATE, NVL(t.DATETIME, v_sysdate))
         AND TRIM(naap.LINK_TYPE_CODE) = TRIM(rsig_utils.c_MAIN_LINK_TYPE)
         AND (p.deleted IS NULL OR p.deleted>NVL(t.DATETIME, v_sysdate));

    OPEN result_list FOR
      SELECT /*+ ordered use_nl(t, s, pa, h)
    full(t)
    index_asc(s, UK_SIM_IMSI)
    index_asc(pa, PK_PER_ACCOUNT_HISTORY)
    index_asc(h, PK_HOST)
    vsmirnov*/
       ACCESS_POINT_DESC,
       DATE_TIME,
       NETWORK_ADDRESS_DESC,
       h.host_type_code balance_storage_type,
       h.host_address balance_storage_address,
       t.UPRS_MEMBER_CODE Operator_UPRS_MEMBER_CODE,
       t.NETWORK_OPERATOR_ID
        FROM (SELECT ACCESS_POINT_DESC,
                     DATE_TIME,
                     NETWORK_ADDRESS_DESC,
                     UPRS_MEMBER_CODE,
                     NETWORK_OPERATOR_ID
                FROM TT_GET_PHONES_BY_SIM_LIST_EXT tt
              UNION ALL (SELECT t.IMSI ACCESS_POINT_DESC,
                           nvl(DATETIME, v_sysdate) DATE_TIME,
                           NULL NETWORK_ADDRESS_DESC,
                           NULL UPRS_MEMBER_CODE,
                           NULL NETWORK_OPERATOR_ID
                      FROM TABLE(CAST(v_IMSI_DATE_list AS t_IMSI_date_obj_tab)) t
                    MINUS
                    SELECT ACCESS_POINT_DESC,
                           DATE_TIME,
                           NULL NETWORK_ADDRESS_DESC,
                           NULL UPRS_MEMBER_CODE,
                           NULL NETWORK_OPERATOR_ID
                      FROM TT_GET_PHONES_BY_SIM_LIST_EXT tt)) t
        LEFT JOIN sim_card s ON s.imsi = t.access_point_desc
        LEFT JOIN personal_account_history pa ON pa.personal_account = s.personal_account
             AND NVL(t.date_time, v_sysdate) BETWEEN pa.start_date
             AND nvl(pa.end_date, NVL(t.DATE_TIME, v_sysdate))
        LEFT JOIN host h ON h.host_id = pa.balance_storage;

  EXCEPTION
    WHEN OTHERS THEN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(p_Text         => TO_CHAR(ERROR_CODE) || ' ' || SQLERRM,
                           p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_0,
                           p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           p_Event_Source => 'INTERFACE_FOR_SUPS.Get_Phones_By_SIM_list_Ext');
      OPEN Result_list FOR
        SELECT ERROR_CODE FROM dual;
  END Get_Phones_By_SIM_list_ext;

  -------------------------------------------------------------------------------
  --      procedure Get_IMSI_By_Phone_list
  -------------------------------------------------------------------------------
  PROCEDURE Get_IMSI_By_Phone_list_Ext
  (
    p_Phone_list IN t_PHONE,
    p_date_list  IN t_date,
    result_list  OUT sys_refcursor,
    ERROR_CODE   OUT NUMBER
  ) IS
    v_sysdate                DATE:=SYSDATE;
    obj       t_PA_PHONE_date_obj := t_PA_PHONE_date_obj(NULL, NULL, NULL);
    obj_col   t_pa_phone_date_obj_tab := t_pa_phone_date_obj_tab();
    j         NUMBER;

  BEGIN

    RSIG_UTILS.Debug_Rsi(p_Text         => RSIG_UTILS.c_DEBUG_TEXT_START,
                         p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_1,
                         p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         p_Event_Source => 'INTERFACE_FOR_SUPS.Get_IMSI_By_Phone_list_Ext');

   --check p_SIM_list parameter
    IF (p_Phone_list.COUNT = 0) OR (p_Phone_list.COUNT = 1 AND p_Phone_list(p_Phone_list.FIRST) IS NULL) THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
    END IF;
      --check p_Date_list parameter
    IF (p_date_list.COUNT = 0) OR (p_date_list.COUNT = 1 AND p_date_list(p_date_list.FIRST) IS NULL) THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
    END IF;
      
    IF (p_phone_list.COUNT <> p_date_list.COUNT) THEN
       RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
    END IF;
    
    -- fill object from input parameter
    j := 1;
    FOR i IN nvl(p_Phone_list.FIRST, 1) .. nvl(p_Phone_list.LAST, 0)
    LOOP
      obj := t_PA_Phone_date_obj(NULL, p_Phone_list(i), p_date_list(i)); -- create object
      obj_col.EXTEND; -- grow
      obj_col(j) := obj; -- insert into collection
      j := j + 1;
    END LOOP;

    ERROR_CODE := rsig_utils.c_ok;
    DELETE TT_GET_PHONES_BY_SIM_LIST_EXT;

    INSERT INTO TT_GET_PHONES_BY_SIM_LIST_EXT
      (ACCESS_POINT_DESC,
       DATE_TIME,
       NETWORK_ADDRESS_DESC,
       UPRS_MEMBER_CODE,
       NETWORK_OPERATOR_ID)
      SELECT /*+ ordered use_nl(t, p, naap, sc, pso, no)
    full(t)
    index_asc(p, UK_PHONE_NUM_PHONE_NUMBER)
    index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID)
    index_asc(sc, I_ACCESS_POINT_ID_IMSI)
    index_asc(pso, I_PHOSEOPER_NO_PNS)
    index_asc(no, PK_NETWORK_OPERATOR)
    vsmirnov*/
       sc.imsi,
       nvl(t.DATETIME, v_SYSDATE),
       t.PHONE,
       no.UPRS_MEMBER_CODE,
       no.NETWORK_OPERATOR_ID
        FROM TABLE(CAST(obj_col AS t_pa_phone_date_obj_tab)) t
        JOIN PHONE_NUMBER p ON t.PHONE = p.INTERNATIONAL_FORMAT
        JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.NETWORK_ADDRESS_ID = p.NETWORK_ADDRESS_ID
        JOIN SIM_CARD sc ON sc.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
        JOIN PHONE_SERIES_OPERATOR pso ON pso.PHONE_NUMBER_SERIES_ID = p.PHONE_NUMBER_SERIES_ID
        JOIN NETWORK_OPERATOR NO ON pso.NETWORK_OPERATOR_ID = NO.NETWORK_OPERATOR_ID
       WHERE nvl(t.datetime, v_SYSDATE) BETWEEN naap.FROM_DATE AND
             nvl(naap.TO_DATE, nvl(t.datetime, v_SYSDATE))
         AND nvl(t.DATETIME, v_SYSDATE) BETWEEN pso.start_date AND
             nvl(pso.end_date, nvl(t.DATETIME, v_SYSDATE))
         AND (p.deleted IS NULL OR p.deleted> nvl(t.DATETIME, v_SYSDATE));
    --        AND naap.LINK_TYPE_CODE = rsig_utils.c_MAIN_LINK_TYPE;

     OPEN result_list FOR
      SELECT /*+ ordered use_nl(t, s, pa, h)
    full(t)
    index_asc(s, UK_SIM_IMSI)
    index_asc(pa, PK_PER_ACCOUNT_HISTORY)
    index_asc(h, PK_HOST)
    vsmirnov*/
      NETWORK_ADDRESS_DESC,
       DATE_TIME,
       ACCESS_POINT_DESC,
       h.HOST_TYPE_CODE balance_storage_type,
       h.HOST_ADDRESS balance_storage_address,
       t.UPRS_MEMBER_CODE Operator_UPRS_MEMBER_CODE,
       t.NETWORK_OPERATOR_ID
        FROM (SELECT ACCESS_POINT_DESC,
                     DATE_TIME,
                     NETWORK_ADDRESS_DESC,
                     UPRS_MEMBER_CODE,
                     NETWORK_OPERATOR_ID
                FROM TT_GET_PHONES_BY_SIM_LIST_EXT tt
              UNION ALL (SELECT NULL ACCESS_POINT_DESC,
                           nvl(DATETIME, v_sysdate) DATE_TIME,
                           t.PHONE NETWORK_ADDRESS_DESC,
                           NULL UPRS_MEMBER_CODE,
                           NULL NETWORK_OPERATOR_ID
                      FROM TABLE(CAST(obj_col AS t_pa_phone_date_obj_tab)) t
                    MINUS
                    SELECT NULL ACCESS_POINT_DESC,
                           nvl(DATE_TIME, v_SYSDATE) DATE_TIME,
                           tt.network_address_desc NETWORK_ADDRESS_DESC,
                           NULL UPRS_MEMBER_CODE,
                           NULL NETWORK_OPERATOR_ID
                      FROM TT_GET_PHONES_BY_SIM_LIST_EXT tt)) t
        LEFT JOIN sim_card s ON s.imsi = t.access_point_desc
        LEFT JOIN personal_account_history pa ON pa.personal_account = s.personal_account
             AND NVL(t.date_time, v_sysdate) BETWEEN pa.start_date
             AND nvl(pa.end_date, NVL(t.DATE_TIME, v_sysdate))
        LEFT JOIN host h ON h.host_id = pa.balance_storage;

  EXCEPTION
    WHEN OTHERS THEN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(p_Text         => TO_CHAR(ERROR_CODE),
                           p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_0,
                           p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           p_Event_Source => 'INTERFACE_FOR_SUPS.Get_IMSI_By_Phone_list_Ext');
      OPEN Result_list FOR
        SELECT ERROR_CODE FROM dual;
  END Get_IMSI_By_Phone_list_Ext;

  -------------------------------------------
  ------- Get_Ballance_storage_by_PA
  -------------------------------------------
  PROCEDURE Get_Balance_storage_by_PA
  (
    p_PA_list   IN t_PA,
    result_list OUT sys_refcursor,
    ERROR_CODE  OUT NUMBER
  ) IS
    obj     t_pa_host_obj := t_pa_host_obj(NULL, NULL);
    obj_col t_pa_host_obj_tab := t_pa_host_obj_tab();
    j       NUMBER;
  v_sysdate                DATE:=SYSDATE;
  BEGIN

    RSIG_UTILS.Debug_Rsi(p_Text         => RSIG_UTILS.c_DEBUG_TEXT_START,
                         p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_1,
                         p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         p_Event_Source => 'INTERFACE_FOR_SUPS.Get_Balance_storage_by_PA');
--check p_PA_list parameter
  IF (p_PA_list.COUNT = 0) OR (p_PA_list.COUNT = 1 AND p_PA_list(p_PA_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
  
    -- fill object from input parameter
    j := 1;
    FOR i IN nvl(p_PA_list.FIRST, 1) .. nvl(p_PA_list.LAST, 0)
    LOOP
      obj := t_pa_host_obj(p_PA_list(i), NULL); -- create object
      obj_col.EXTEND; -- grow
      obj_col(j) := obj; -- insert into collection
      j := j + 1;
    END LOOP;

    ERROR_CODE := rsig_utils.c_ok;

    OPEN result_list FOR
     SELECT /*+ ordered use_nl(t, pah, h)
    full(t)
    index_asc(pah, I_PA_PERSONAL_ACCOUNT_HISTORY)
    index_asc(h, PK_HOST)
    vsmirnov*/
            t.PERSONAL_ACCOUNT PersonalAccount,
             pah.BALANCE_STORAGE BalanceStorage,
             h.host_type_code   HostType
        FROM TABLE(CAST(obj_col AS t_pa_host_obj_tab)) t
        LEFT JOIN personal_account_history pah ON pah.personal_account = t.personal_account
          AND (pah.end_date >= v_sysdate OR pah.end_date IS NULL)
        LEFT JOIN host h ON h.host_id = pah.balance_storage;

  EXCEPTION
    WHEN OTHERS THEN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(p_Text         => TO_CHAR(ERROR_CODE),
                           p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_0,
                           p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           p_Event_Source => 'INTERFACE_FOR_SUPS.Get_Balance_storage_by_PA');
      OPEN Result_list FOR
        SELECT ERROR_CODE FROM dual;
  END Get_Balance_storage_by_PA;

  -------------------------------------------------------------------------------
  --      procedure Get_SIM_and_Main_Phn_By_Phones
  -------------------------------------------------------------------------------
  PROCEDURE Get_SIM_and_Main_Phn_By_Phones
  (
    p_phone_list IN t_PHONE,
    p_date_list  IN t_date,
    result_list  OUT sys_refcursor,
    ERROR_CODE   OUT NUMBER
  ) IS
    v_sysdate                DATE :=SYSDATE;
    p_access_point_id NUMBER;
    p_network_address_id NUMBER;
    CURSOR get_network_add_id_cur (p_phone VARCHAR2) IS
       SELECT network_address_id FROM phone_number WHERE international_format = p_phone;
    CURSOR get_access_point_id_cur (p_network_address_id VARCHAR2) IS
       SELECT access_point_id FROM network_address_access_point
        WHERE network_address_id = p_network_address_id;

  BEGIN
    ERROR_CODE := rsig_utils.c_ok;

    RSIG_UTILS.Debug_Rsi(p_Text         => RSIG_UTILS.c_DEBUG_TEXT_START,
                         p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_1,
                         p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         p_Event_Source => 'INTERFACE_FOR_SUPS.Get_SIM_and_Main_Phn_By_Phones');
  --check p_phone_list parameter
  IF (p_phone_list.COUNT = 0) OR (p_phone_list.COUNT = 1 AND p_phone_list(p_phone_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF (p_phone_list.COUNT <> p_date_list.COUNT) THEN
     RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;
  
  DELETE TT_Get_SIM_Main_Phn_By_Phones2;

     FOR i IN p_phone_list.FIRST .. p_phone_list.LAST LOOP

       OPEN get_network_add_id_cur (p_phone_list(i));
       FETCH get_network_add_id_cur INTO p_network_address_id;
       CLOSE get_network_add_id_cur;

       OPEN get_access_point_id_cur (p_network_address_id);
       FETCH get_access_point_id_cur INTO p_access_point_id;
       CLOSE get_access_point_id_cur;

       INSERT INTO TT_Get_SIM_Main_Phn_By_Phones2 (access_point_id, datetime, original_phone_number)
         VALUES (p_access_point_id, nvl(p_date_list(i),v_sysdate), p_phone_list(i));
     END LOOP;

    OPEN result_list FOR
      SELECT /*+ ordered use_nl(t, naap, p, sc, pso, no, pah, h)
    full(t)
    index_asc(naap, I_NETADDRACCPO_ACCESS_POINT_ID)
    index_asc(p, PK_PHONE_NUMBER)
    index_asc(sc, PK_SIM_CARD)
    index_asc(pso, I_PHOSEOPER_NO_PNS)
    index_asc(no, PK_NETWORK_OPERATOR)
    index_asc(pah, PK_PER_ACCOUNT_HISTORY)
    index_asc(h, PK_HOST)
    vsmirnov*/
             t.original_phone_number network_address_desc,
             nvl(t.DATETIME, v_SYSDATE) date_time,
             sc.imsi access_point_desc,
             h.HOST_TYPE_CODE balance_storage_type,
             h.HOST_ADDRESS balance_storage_address,
             no.UPRS_MEMBER_CODE Operator_UPRS_member_code,
             no.NETWORK_OPERATOR_ID,
             p.international_format main_number
        FROM TT_Get_SIM_Main_Phn_By_Phones2 t
        JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.access_point_id = t.access_point_id
        JOIN PHONE_NUMBER p ON p.NETWORK_ADDRESS_ID = naap.NETWORK_ADDRESS_ID
        JOIN SIM_CARD sc ON sc.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
        JOIN PHONE_SERIES_OPERATOR pso ON pso.PHONE_NUMBER_SERIES_ID = p.PHONE_NUMBER_SERIES_ID
        JOIN NETWORK_OPERATOR NO ON pso.NETWORK_OPERATOR_ID = NO.NETWORK_OPERATOR_ID
        JOIN personal_account_history pah ON pah.personal_account=sc.personal_account
             AND nvl(t.DATETIME, v_SYSDATE) BETWEEN pah.start_date AND
             nvl(pah.end_date, nvl(t.DATETIME, v_SYSDATE))
        JOIN host h ON h.host_id = pah.balance_storage
       WHERE nvl(t.datetime, v_SYSDATE) BETWEEN naap.FROM_DATE AND
             nvl(naap.TO_DATE, nvl(t.datetime, v_SYSDATE))
         AND nvl(t.DATETIME, v_SYSDATE) BETWEEN pso.start_date AND
             nvl(pso.end_date, nvl(t.DATETIME, v_SYSDATE))
         AND nvl(t.datetime, v_SYSDATE) BETWEEN naap.FROM_DATE AND
             nvl(naap.TO_DATE, nvl(t.datetime, v_SYSDATE))
         AND TRIM(naap.LINK_TYPE_CODE) = TRIM(rsig_utils.c_MAIN_LINK_TYPE)
         AND (p.deleted IS NULL OR p.deleted>nvl(t.datetime, v_SYSDATE));

  EXCEPTION
    WHEN OTHERS THEN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(p_Text         => TO_CHAR(ERROR_CODE),
                           p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_0,
                           p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           p_Event_Source => 'INTERFACE_FOR_SUPS.Get_SIM_and_Main_Phn_By_Phones');
      OPEN Result_list FOR
        SELECT ERROR_CODE FROM dual;
  END Get_SIM_and_Main_Phn_By_Phones;

  -------------------------------------------
  ------- Get_Ballance_stor_by_one_PA
  -------------------------------------------
PROCEDURE Get_Balance_stor_by_one_PA
(
  p_personal_account IN sim_card.PERSONAL_ACCOUNT%TYPE,
  result_list        OUT SYS_REFCURSOR,
  ERROR_CODE         OUT NUMBER
) IS
v_sysdate                DATE:=SYSDATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(p_Text         => RSIG_UTILS.c_DEBUG_TEXT_START,
                       p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_1,
                       p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       p_Event_Source => 'INTERFACE_FOR_SUPS.Get_Balance_stor_by_one_PA');

  ERROR_CODE := rsig_utils.c_ok;

  OPEN result_list FOR
      SELECT /*+ ordered use_nl(pah, h)
    index_asc(pah, I_PA_PERSONAL_ACCOUNT_HISTORY)
    index_asc(h, PK_HOST)
    vsmirnov*/
             pah.PERSONAL_ACCOUNT PersonalAccount,
             pah.BALANCE_STORAGE BalanceStorage,
             h.host_type_code HostType
      FROM personal_account_history pah
      LEFT JOIN host h ON h.host_id = pah.balance_storage
      WHERE pah.personal_account = p_personal_account
        AND (pah.end_date >= v_sysdate OR pah.end_date IS NULL);


EXCEPTION
  WHEN OTHERS THEN
    ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(p_Text         => TO_CHAR(ERROR_CODE),
                         p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_0,
                         p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         p_Event_Source => 'INTERFACE_FOR_SUPS.Get_Balance_stor_by_one_PA');
    OPEN Result_list FOR
      SELECT ERROR_CODE FROM dual;
END Get_Balance_stor_by_one_PA;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Bal_Storage_By_PA_and_Date
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Bal_Storage_By_PA_and_Date(
  p_PA_list                IN  t_PA,
  p_validity_date          IN  t_date,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='INTERFACE_FOR_SUPS.Get_Bal_Storage_By_PA_and_Date';
  v_sysdate                DATE :=SYSDATE;
  v_PA_DATE_OBJ        t_pa_date_obj:=t_pa_date_obj(NULL,NULL);
  v_PA_DATE_list			  t_pa_date_obj_tab:= t_pa_date_obj_tab();
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
  --check p_PA_list parameter
  IF (p_PA_list.COUNT = 0) OR (p_PA_list.COUNT = 1 AND p_PA_list(p_PA_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
    --check p_validity_date parameter
  IF (p_validity_date.COUNT = 0) OR (p_validity_date.COUNT = 1 AND p_validity_date(p_validity_date.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
  
	IF p_PA_list.COUNT = 0 OR p_PA_list.COUNT <> p_validity_date.COUNT  THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
-- start of the procedure body --------------------------------------------------------------------------------------------------
  FOR i IN nvl(p_PA_list.FIRST, 1) .. nvl(p_PA_list.LAST, 0) 
  loop 
    v_PA_DATE_OBJ:=t_pa_date_obj(p_PA_list(i),nvl(p_validity_date(i),v_sysdate));
    v_PA_DATE_list.extend; 
    v_PA_DATE_list(i):=v_PA_DATE_OBJ; 
  end loop;


  OPEN result_list FOR
	SELECT /*+ ordered use_nl(tt, pah, hh)
    full(tt)
    index_asc(pah, I_PA_PERSONAL_ACCOUNT_HISTORY)
    index_asc(hh, PK_HOST)
    vsmirnov*/
         tt.pa,
         tt.datetime,
         hh.host_address balance_storage_address,
         hh.host_type_code host_type,
         pah.start_date,
         pah.end_date,
         hh.host_id
  FROM TABLE(CAST(v_PA_DATE_list AS t_pa_date_obj_tab)) tt
  LEFT JOIN personal_account_history pah ON pah.personal_account=tt.pa
       ---(pah.end_date>=tt.datetime OR pah.end_date IS NULL)
  LEFT JOIN host hh ON hh.host_id=pah.balance_storage
  WHERE tt.datetime IS NULL OR
         (tt.datetime >= pah.start_date AND
          (tt.datetime <= pah.end_date OR pah.end_date IS NULL));


-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
	  v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Bal_Storage_By_PA_and_Date;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Home_Network_Operator
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Home_Network_Operator(
  p_phone_list             IN  t_PHONE,
  p_validity_date          IN  t_date,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='INTERFACE_FOR_SUPS.Get_Home_Network_Operator';
  v_sysdate                DATE:=SYSDATE;
  v_PHONE_DATE_OBJ        t_phone_date_obj:=t_phone_date_obj(NULL,NULL);
  v_PHONE_DATE_list			  t_phone_date_obj_tab:= t_phone_date_obj_tab();
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
  --check p_phone_list parameter
  IF (p_phone_list.COUNT = 0) OR (p_phone_list.COUNT = 1 AND p_phone_list(p_phone_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
    --check p_validity_date parameter
  IF (p_validity_date.COUNT = 0) OR (p_validity_date.COUNT = 1 AND p_validity_date(p_validity_date.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
  
	IF p_phone_list.COUNT=0 OR p_phone_list.COUNT<>p_validity_date.COUNT THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
-- start of the procedure body --------------------------------------------------------------------------------------------------
  FOR i IN nvl(p_phone_list.FIRST, 1) .. nvl(p_phone_list.LAST, 0)
  loop 
    v_PHONE_DATE_OBJ:=t_phone_date_obj(p_phone_list(i),nvl(p_validity_date(i),v_sysdate));
    v_PHONE_DATE_list.extend; 
    v_PHONE_DATE_list(i):=v_PHONE_DATE_OBJ; 
  end loop;

  OPEN result_list FOR
	SELECT /*+ ordered use_nl(t, pn, pso)
    full(t)
    index_asc(pn, UK_PHONE_NUM_PHONE_NUMBER)
    index_asc(pso, I_PHOSEOPER_NO_PNS)
    vsmirnov*/
         t.phone,
         t.datetime,
         pso.network_operator_id
  FROM TABLE(CAST(v_PHONE_DATE_list AS t_phone_date_obj_tab))  t
  LEFT JOIN phone_number pn ON pn.international_format=t.phone
       AND (pn.deleted IS NULL OR pn.deleted>t.datetime)
  LEFT JOIN phone_series_operator pso ON pn.phone_number_series_id=pso.phone_number_series_id
       AND t.datetime BETWEEN pso.start_date AND nvl(pso.end_date,t.datetime);


  COMMIT;
-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
	  v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Home_Network_Operator;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Balance_Storage_by_IMSI
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Balance_Storage_by_IMSI(
  p_IMSI_list              IN  t_IMSI,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
IS
	v_sqlcode	           number;
  v_event_source           varchar2(60) :='INTERFACE_FOR_SUPS.Get_Balance_Storage_by_IMSI';
  v_sysdate                DATE:=SYSDATE;
  v_IMSI_OBJ               t_imsi_obj:=t_imsi_obj(NULL);
  v_IMSI_list			   t_imsi_obj_tab:= t_imsi_obj_tab(); 
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
  
	IF (p_IMSI_list.COUNT=0) OR (p_IMSI_list.COUNT = 1 AND p_IMSI_list(p_IMSI_list.FIRST) IS NULL) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

-- start of the procedure body --------------------------------------------------------------------------------------------------

   
  FOR i IN nvl(p_IMSI_list.FIRST, 1) .. nvl(p_IMSI_list.LAST, 0) 
  loop 
    v_IMSI_OBJ:=t_imsi_obj(p_IMSI_list(i));
    v_IMSI_list.extend; 
    v_IMSI_list(i):=v_IMSI_OBJ; 
  end loop; 


  OPEN result_list FOR
  SELECT /*+ ordered use_nl(t, sc, pah, h)
    full(t)
    index_asc(sc, UK_SIM_IMSI)
    index_asc(pah, PK_PER_ACCOUNT_HISTORY)
    index_asc(h, PK_HOST)
    vsmirnov*/
        t.imsi,
         trim(h.host_type_code) host_type_code,
         h.host_address
  FROM TABLE(CAST(v_IMSI_list AS t_imsi_obj_tab)) t
  LEFT JOIN sim_card sc ON sc.imsi=t.imsi
  LEFT JOIN personal_account_history pah ON pah.personal_account=sc.personal_account
       AND v_sysdate BETWEEN pah.start_date AND nvl(pah.end_date,v_sysdate)
  LEFT JOIN host h ON h.host_id=pah.balance_storage;

  COMMIT;
-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
	  v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Balance_Storage_by_IMSI;


------------------------------------------------------------------------------------------------------------------------------
--  Get_Balance_Storage_by_MSISDN
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Balance_Storage_by_MSISDN(
  p_MSISDN                   IN  phone_number.international_format%TYPE,
  p_personal_account         OUT sim_card.personal_account%TYPE,
  p_balance_storage_type     OUT host.host_type_code%TYPE,
  p_balance_storage_address  OUT host.host_address%TYPE,
  p_host_id                  OUT host.host_id%TYPE,
  p_error_code                 OUT NUMBER,
  p_error_message              OUT VARCHAR2
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='INTERFACE_FOR_SUPS.Get_Balance_Storage_by_MSISDN';
  v_sysdate                DATE:=SYSDATE;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

	IF p_MSISDN IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


-- start of the procedure body --------------------------------------------------------------------------------------------------
  BEGIN

    SELECT /*+ ordered use_nl(pn, naap, s, pah, h)
    index_asc(pn, UK_PHONE_NUM_PHONE_NUMBER)
    index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID)
    index_asc(s, PK_SIM_CARD)
    index_asc(pah, PK_PER_ACCOUNT_HISTORY)
    index_asc(h, PK_HOST)
    vsmirnov*/
           s.personal_account,
           trim(h.host_type_code) host_type_code,
           h.host_address,
           h.host_id
    INTO p_personal_account,
         p_balance_storage_type,
         p_balance_storage_address,
         p_host_id
    FROM phone_number pn
    JOIN network_address_access_point naap ON naap.network_address_id=pn.network_address_id
         AND v_sysdate BETWEEN naap.from_date AND nvl(naap.to_date,v_sysdate)
    JOIN sim_card s ON s.access_point_id = naap.access_point_id
    JOIN personal_account_history pah ON pah.personal_account=s.personal_account
         AND v_sysdate BETWEEN pah.start_date AND nvl(pah.end_date,v_sysdate)
    JOIN host h ON h.host_id=pah.balance_storage
    WHERE pn.international_format=p_MSISDN
      AND (pn.deleted IS NULL OR pn.deleted>v_sysdate);

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      p_personal_account:=NULL;
      p_balance_storage_type:=NULL;
      p_balance_storage_address:=NULL;
      p_host_id := NULL;
  END;
-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  p_error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
	  v_sqlcode := sqlcode;
		p_error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);

END Get_Balance_Storage_by_MSISDN;

  -------------------------------------------
  ------- Get_PA_Exist
  -------------------------------------------
  PROCEDURE Get_PA_Exist
  (
    p_PA_list   IN t_PA,
    result_list OUT sys_refcursor,
    ERROR_CODE  OUT NUMBER
  ) IS
    obj     t_pa_host_obj := t_pa_host_obj(NULL, NULL);
    obj_col t_pa_host_obj_tab := t_pa_host_obj_tab();
    j       NUMBER;
  BEGIN

    RSIG_UTILS.Debug_Rsi(p_Text         => RSIG_UTILS.c_DEBUG_TEXT_START,
                         p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_1,
                         p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         p_Event_Source => 'INTERFACE_FOR_SUPS.Get_PA_Exist');

--check p_PA_list parameter
  IF (p_PA_list.COUNT = 0) OR (p_PA_list.COUNT = 1 AND p_PA_list(p_PA_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
  
    -- fill object from input parameter
    j := 1;
    FOR i IN nvl(p_PA_list.FIRST, 1) .. nvl(p_PA_list.LAST, 0)
    LOOP
      obj := t_pa_host_obj(p_PA_list(i), NULL); -- create object
      obj_col.EXTEND; -- grow
      obj_col(j) := obj; -- insert into collection
      j := j + 1;
    END LOOP;

    ERROR_CODE := rsig_utils.c_ok;

    OPEN result_list FOR
     SELECT
            t.PERSONAL_ACCOUNT PersonalAccount,
             nvl(PA_Exist(t.PERSONAL_ACCOUNT), 0) PAExist
        FROM TABLE(CAST(obj_col AS t_pa_host_obj_tab)) t;

  EXCEPTION
    WHEN OTHERS THEN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(p_Text         => TO_CHAR(ERROR_CODE),
                           p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_0,
                           p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           p_Event_Source => 'INTERFACE_FOR_SUPS.Get_Balance_storage_by_PA');
      OPEN Result_list FOR
        SELECT ERROR_CODE FROM dual;
  END Get_PA_Exist;

  -------------------------------------------
  ------- Get_one_PA_exist
  -------------------------------------------
PROCEDURE Get_one_PA_exist
(
  p_personal_account IN sim_card.PERSONAL_ACCOUNT%TYPE,
  result_list        OUT SYS_REFCURSOR,
  ERROR_CODE         OUT NUMBER
) IS
BEGIN

  RSIG_UTILS.Debug_Rsi(p_Text         => RSIG_UTILS.c_DEBUG_TEXT_START,
                       p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_1,
                       p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       p_Event_Source => 'INTERFACE_FOR_SUPS.Get_one_PA_exist');

  ERROR_CODE := rsig_utils.c_ok;

  OPEN result_list FOR
      SELECT p_personal_account PersonalAccount,
             nvl(PA_Exist(p_personal_account), 0) PAExist
      FROM dual;


EXCEPTION
  WHEN OTHERS THEN
    ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(p_Text         => TO_CHAR(ERROR_CODE),
                         p_Level        => RSIG_UTILS.c_DEBUG_LEVEL_0,
                         p_Event_Type   => RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         p_Event_Source => 'INTERFACE_FOR_SUPS.Get_Balance_stor_by_one_PA');
    OPEN Result_list FOR
      SELECT ERROR_CODE FROM dual;
END Get_one_PA_exist;

FUNCTION PA_Exist(
  p_PA IN personal_account_history.personal_account%TYPE
)
RETURN INT IS
  v_pom number;
BEGIN
  select 1
  into v_pom
  from personal_account_history
  where personal_account = p_PA
    AND rownum=1;
  return v_pom;
END PA_Exist;

------------------------------------------------------------------------------------------------------------------------------
--  Get_DST_Rules_List
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_DST_Rules_List(
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
)
IS
  v_sqlcode          number;
  v_event_source     varchar2(60) :='INTERFACE_FOR_SUPS.Get_DST_Rules_List';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

-- start of the procedure body --------------------------------------------------------------------------------------------------
  
  OPEN p_result_list FOR
    SELECT dr.DST_RULE_ID, 
           dr.COUNTRY_CODE,
           dr.DST_NAME,
           dr.DATE_START_RULE_MASK,
           dr.DATE_START,
           dr.DATE_END_RULE_MASK,
           dr.DATE_END 
      FROM DST_RULE dr;           

  COMMIT;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
    p_error_code := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
    WHEN OTHERS THEN
        v_sqlcode := sqlcode;
        p_error_message := sqlerrm;
--        DBMS_OUTPUT.PUT_LINE(p_error_message);
        p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
        RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
        OPEN p_result_list FOR SELECT v_sqlcode, p_error_message FROM dual;
END Get_DST_Rules_List;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function cast_cit2t_bsc_lac_msc_obj_tab
(
    p_msc util_pkg.cit_varchar_s,
    p_location_area_code util_pkg.cit_varchar_s,
    p_base_station_code util_pkg.cit_varchar_s
) return t_bsc_lac_msc_obj_tab
is
  v_main_count number;
  v_res t_bsc_lac_msc_obj_tab;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_cit_varchar_s(p_msc);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_cit_varchar_s(p_msc) != v_main_count, 'p_msc.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_cit_varchar_s(p_location_area_code) != v_main_count, 'p_location_area_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_cit_varchar_s(p_base_station_code) != v_main_count, 'p_base_station_code.count != v_main_count');
  ------------------------------
  v_res := t_bsc_lac_msc_obj_tab();
  v_res.extend(v_main_count);
  for i in 1..v_main_count
  loop
    v_res(i):= t_bsc_lac_msc_obj
    (
      base_station_code=> p_base_station_code(i),
      location_area_code => p_location_area_code(i),
      msc_code => p_msc(i)
    );
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_t_bsc_lac_msc_obj_tab_val(p_coll in out nocopy t_bsc_lac_msc_obj_tab, p_val t_bsc_lac_msc_obj)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := t_bsc_lac_msc_obj_tab();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_t_bsc_lac_msc(p_coll t_bsc_lac_msc_obj_tab) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host4hlb0(p_hlb t_bsc_lac_msc_obj_tab, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := get_count_t_bsc_lac_msc(p_hlb);
  util_pkg.XCheck_Cond_Invalid(get_count_t_bsc_lac_msc(p_hlb) != v_main_count, 'p_hlb.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, I_HOST_CODE)*/
  z.host_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select t.*, rownum rn from table(p_hlb) t) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    host z
  where 1 = 1
  and q2.rn = q.rn
  and z.host_code = q.msc_code
  and nvl(deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'host');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host4hlb(p_hlb t_bsc_lac_msc_obj_tab, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, get_count_t_bsc_lac_msc(p_hlb));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_host4hlb0(p_hlb, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host4hlb2(p_hlb t_bsc_lac_msc_obj, p_date date) return number
is
  v_hlb t_bsc_lac_msc_obj_tab;
begin
  ------------------------------
  add_t_bsc_lac_msc_obj_tab_val(v_hlb, p_hlb);
  ------------------------------
  return get_host4hlb(v_hlb, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_location_area4hlb_par0(p_hlb t_bsc_lac_msc_obj_tab, p_parent_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := get_count_t_bsc_lac_msc(p_hlb);
  util_pkg.XCheck_Cond_Invalid(get_count_t_bsc_lac_msc(p_hlb) != v_main_count, 'p_hlb.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_parent_id) != v_main_count, 'p_parent_id.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2 q3) use_nl(z) index_asc(z, I_LOCATION_AREA_CODE)*/
  z.location_area_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select t.*, rownum rn from table(p_hlb) t) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    (select column_value parent_id, rownum rn from table(p_parent_id)) q3,
    location_area z
  where 1 = 1
  and q2.rn = q.rn
  and q3.rn = q.rn
  and z.location_area_code = q.location_area_code
  and nvl(deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > q2.validity_date
  and z.host_id = q3.parent_id
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'location_area');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_location_area4hlb_par(p_hlb t_bsc_lac_msc_obj_tab, p_parent_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, get_count_t_bsc_lac_msc(p_hlb));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_location_area4hlb_par0(p_hlb, p_parent_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_location_area4hlb_par2(p_hlb t_bsc_lac_msc_obj, p_parent_id number, p_date date) return number
is
  v_hlb t_bsc_lac_msc_obj_tab;
  v_parent_id ct_number;
begin
  ------------------------------
  add_t_bsc_lac_msc_obj_tab_val(v_hlb, p_hlb);
  util_pkg.add_ct_number_val(v_parent_id, p_parent_id);
  ------------------------------
  return get_location_area4hlb_par(v_hlb, v_parent_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_base_station4hlb_par0(p_hlb t_bsc_lac_msc_obj_tab, p_parent_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := get_count_t_bsc_lac_msc(p_hlb);
  util_pkg.XCheck_Cond_Invalid(get_count_t_bsc_lac_msc(p_hlb) != v_main_count, 'p_hlb.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_parent_id) != v_main_count, 'p_parent_id.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2 q3) use_nl(z) index_asc(z, I_BASE_STATION_CODE)*/
  z.base_station_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select t.*, rownum rn from table(p_hlb) t) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    (select column_value parent_id, rownum rn from table(p_parent_id)) q3,
    base_station z
  where 1 = 1
  and q2.rn = q.rn
  and q3.rn = q.rn
  and z.base_station_code = q.base_station_code
  and nvl(deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > q2.validity_date
  and z.location_area_id= q3.parent_id
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'base_station');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_base_station4hlb_par(p_hlb t_bsc_lac_msc_obj_tab, p_parent_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, get_count_t_bsc_lac_msc(p_hlb));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_base_station4hlb_par0(p_hlb, p_parent_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_base_station4hlb_par2(p_hlb t_bsc_lac_msc_obj, p_parent_id number, p_date date) return number
is
  v_hlb t_bsc_lac_msc_obj_tab;
  v_parent_id ct_number;
begin
  ------------------------------
  add_t_bsc_lac_msc_obj_tab_val(v_hlb, p_hlb);
  util_pkg.add_ct_number_val(v_parent_id, p_parent_id);
  ------------------------------
  return get_base_station4hlb_par(v_hlb, v_parent_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_locno4bs0(p_base_station_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_base_station_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_base_station_id) != v_main_count, 'p_base_station_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, UK_BASE_STATION_LOCNO)*/
  z.location_number, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value base_station_id, rownum rn from table(p_base_station_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    base_station_locno z
  where 1 = 1
  and q2.rn = q.rn
  and z.base_station_id = q.base_station_id
  --and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'base_station_locno');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_locno4bs(p_base_station_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_base_station_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_locno4bs0(p_base_station_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_locno4bs2(p_base_station_id number, p_date date) return varchar2
is
  v_base_station_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_base_station_id, p_base_station_id);
  ------------------------------
  return get_locno4bs(v_base_station_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_location_number_by_bs_ii
(
    p_bsc_lac_msc_tab t_bsc_lac_msc_obj_tab,
    p_loc_no out ct_varchar_s,
    p_rn out ct_number
)
is
  v_date date := sysdate;
begin
  ------------------------------
  select /*+ ordered use_nl(t h la bs bsln)
    full(t)
    index(h I_HOST_CODE)
    index(la I_LOCATION_AREA_CODE)
    index(bs I_BASE_STATION_CODE)
    index(bsln UK_BASE_STATION_LOCNO)
  */
    bsln.location_number,
    t.rn
  bulk collect into p_loc_no, p_rn
  from
    (select q.*, rownum rn from table(cast(p_bsc_lac_msc_tab as t_bsc_lac_msc_obj_tab)) q) t,
    host h,
    location_area la,
    base_station bs,
    base_station_locno bsln
  where 1 = 1
  and h.host_code = t.msc_code
  and nvl(h.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_date
  and la.host_id = h.host_id
  and la.location_area_code = t.location_area_code
  and nvl(la.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_date
  and bs.base_station_code = t.base_station_code
  and bs.location_area_id = la.location_area_id
  and nvl(bs.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_date
  and bsln.base_station_id = bs.base_station_id
  --!_! and nvl(bsln.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_date is null
  order by t.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_location_number_by_bs_i1(p_bsc_lac_msc_tab t_bsc_lac_msc_obj_tab) return ct_varchar_s
is
  v_main_count number;
  v_date date := sysdate;
  v_dates ct_date;
  v_ms_id ct_number;
  v_la_id ct_number;
  v_bs_id ct_number;
  v_res ct_varchar_s;
begin
  ------------------------------
  v_main_count := get_count_t_bsc_lac_msc(p_bsc_lac_msc_tab);
  v_dates := util_pkg.make_ct_date(v_main_count, v_date);
  ------------------------------
  v_ms_id := get_host4hlb0(p_hlb => p_bsc_lac_msc_tab, p_date => v_dates, p_trim_empty => FALSE);
  v_la_id := get_location_area4hlb_par0(p_hlb => p_bsc_lac_msc_tab, p_parent_id => v_ms_id, p_date => v_dates, p_trim_empty => FALSE);
  v_bs_id := get_base_station4hlb_par0(p_hlb => p_bsc_lac_msc_tab, p_parent_id => v_la_id, p_date => v_dates, p_trim_empty => FALSE);
  v_res := get_locno4bs0(p_base_station_id => v_bs_id, p_date => v_dates, p_trim_empty => FALSE);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_location_number_by_bs_i2(p_bsc_lac_msc_tab t_bsc_lac_msc_obj_tab) return ct_varchar_s
is
  v_main_count number;
  v_loc_no ct_varchar_s;
  v_res ct_varchar_s;
  v_rn ct_number;
  v_pivot ct_number;
begin
  ------------------------------
  v_main_count := get_count_t_bsc_lac_msc(p_bsc_lac_msc_tab);
  ------------------------------
  get_location_number_by_bs_ii
  (
    p_bsc_lac_msc_tab => p_bsc_lac_msc_tab,
    p_loc_no => v_loc_no,
    p_rn => v_rn
  );
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  v_res := util_pkg.join2pivot_ct_varchar_s(p_vals => v_loc_no, p_ids_pivot_main => v_pivot, p_ids_pivot_for_vals => v_rn);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_location_number_by_bs_i3
(
    p_bsc_lac_msc_tab t_bsc_lac_msc_obj_tab,
    p_result out sys_refcursor
) is
  v_loc_no ct_varchar_s;
  v_rn ct_number;
begin
  ------------------------------
  get_location_number_by_bs_ii
  (
    p_bsc_lac_msc_tab => p_bsc_lac_msc_tab,
    p_loc_no => v_loc_no,
    p_rn => v_rn
  );
  ------------------------------
  open p_result for
  with loc_no as (
  select /*+ use_hash(q1 q2) full(q1) full(q2)*/
    location_number,
    row_rn rn
  from
    (select column_value row_rn, rownum rn from table(cast(v_rn as ct_number))) q1,
    (select column_value location_number, rownum rn from table(cast(v_loc_no as ct_varchar_s))) q2
  where 1 = 1
  and q2.rn = q1.rn
  order by q1.rn
  )
  select /*+ use_hash(z1 z2) full(z1) full(z2)*/
    z1.base_station_code as Base_station_code,
    z1.location_area_code as location_area_code,
    z1.msc_code as MSC,
    z2.location_number
  from
    (select q.*, rownum rn from table(cast(p_bsc_lac_msc_tab as t_bsc_lac_msc_obj_tab)) q) z1,
    loc_no z2
  where 1 = 1
  and z2.rn(+) = z1.rn
  order by z1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_cursor_result1
(
    p_bsc_lac_msc_tab t_bsc_lac_msc_obj_tab,
    p_loc_no ct_varchar_s
) return sys_refcursor is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ use_hash(z1 z2) full(z1) full(z2)*/
    z1.base_station_code as Base_station_code,
    z1.location_area_code as location_area_code,
    z1.msc_code as MSC,
    z2.location_number
  from
    (select q.*, rownum rn from table(cast(p_bsc_lac_msc_tab as t_bsc_lac_msc_obj_tab)) q) z1,
    (select column_value location_number, rownum rn from table(cast(p_loc_no as ct_varchar_s))) z2
  where 1 = 1
  and z2.rn = z1.rn
  order by z1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_location_number_by_bs
(
    p_msc util_pkg.cit_varchar_s,
    p_location_area_code util_pkg.cit_varchar_s,
    p_base_station_code util_pkg.cit_varchar_s,
    p_raise_error char,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
) IS
  v_bsc_lac_msc_tab t_bsc_lac_msc_obj_tab;
  v_get_ln_mode number;
  v_locno ct_varchar_s;
BEGIN
  ------------------------------
  util_pkg.XCheckP_cit_varchar_s(p_msc, 'p_msc', true);
  util_pkg.XCheckP_cit_varchar_s(p_location_area_code, 'p_location_area_code', true);
  util_pkg.XCheckP_cit_varchar_s(p_base_station_code, 'p_base_station_code', true);
  ------------------------------
  v_get_ln_mode := install_pkg.nnget_option_num(c_opt_get_locno_mode, c_default_get_locno_mode);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_get_ln_mode not in (c_get_locno_mode_collections, c_get_locno_mode_com_sel1, c_get_locno_mode_com_sel2),
   'v_get_ln_mode not in (c_get_locno_mode_collections, c_get_locno_mode_com_sel1, c_get_locno_mode_com_sel2)');
  ------------------------------
  v_bsc_lac_msc_tab := cast_cit2t_bsc_lac_msc_obj_tab
  (
    p_msc => p_msc,
    p_location_area_code => p_location_area_code,
    p_base_station_code => p_base_station_code
  );
  ------------------------------
  if v_get_ln_mode = c_get_locno_mode_collections
  then
    ------------------------------
    v_locno := get_location_number_by_bs_i1(p_bsc_lac_msc_tab => v_bsc_lac_msc_tab);
    ------------------------------
    p_result := get_cursor_result1(p_bsc_lac_msc_tab => v_bsc_lac_msc_tab, p_loc_no => v_locno);
    ------------------------------
  elsif v_get_ln_mode = c_get_locno_mode_com_sel1
  then
    ------------------------------
    v_locno := get_location_number_by_bs_i2(p_bsc_lac_msc_tab => v_bsc_lac_msc_tab);
    ------------------------------
    p_result := get_cursor_result1(p_bsc_lac_msc_tab => v_bsc_lac_msc_tab, p_loc_no => v_locno);
    ------------------------------
  elsif v_get_ln_mode = c_get_locno_mode_com_sel2
  then
    ------------------------------
    get_location_number_by_bs_i3
    (
      p_bsc_lac_msc_tab => v_bsc_lac_msc_tab,
      p_result => p_result
    );
    ------------------------------
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if upper(p_raise_error)=rsig_utils.c_yes then
    raise;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

------------------------------------------------------------------------------------------------------------------------------
--  get_dst_rule_for_root_no (get daylight saving time (DTS) rule for root network operator)
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE get_dst_rule_for_root_no(
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
)
IS
  v_sqlcode           number;
  v_event_source      varchar2(60) :='INTERFACE_FOR_SUPS.get_dst_rule_for_root_no';
  
  v_check             number;
  v_dst_rule_id       number;
             
  v_network_operator_code   varchar2(100);
  
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

-- start of the procedure body --------------------------------------------------------------------------------------------------
  
  select count(*) into v_check
    from ri_settings rs
   where UPPER(RS.SETTING_NAME) = UPPER('ROOT_NETWORK_OPERATOR_CODE'); 
   
  if v_check = 0
  then
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NO_DATA_FOUND, 'Parameter ROOT_NETWORK_OPERATOR_CODE missing in RI_SETTINGS table.');
  end if; 

  select RS.SETTING_VALUE into v_network_operator_code
    from ri_settings rs
   where UPPER(RS.SETTING_NAME) = UPPER('ROOT_NETWORK_OPERATOR_CODE'); 
   
  if v_network_operator_code IS NULL
  then
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NULL_VALUE, 'Value of ROOT_NETWORK_OPERATOR_CODE parameter in RI_SETTINGS table is not specified.');
  end if; 
  
  select count(*) into v_check
    from network_operator no
   where NO.NETWORK_OPERATOR_CODE = v_network_operator_code
     and NO.DELETED IS NULL;
  
  if v_check = 0
  then
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NO_DATA_FOUND, 'Network operator with code ' || v_network_operator_code || ' is not found in NETWORK_OPERATOR table.');
  end if;
   
  select NO.DST_RULE_ID into v_dst_rule_id
    from network_operator no
   where NO.NETWORK_OPERATOR_CODE = v_network_operator_code
     and NO.DELETED IS NULL;   
/*
  if v_dst_rule_id IS NULL
  then
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NULL_VALUE, 'Value of DST_RULE_ID parameter for network operator with code ' || v_network_operator_code || ' is not specified.');  
  end if;

  select count(*) into v_check
     from dst_rule dr
    where DR.DST_RULE_ID = v_dst_rule_id;
    
  if v_check = 0
  then
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NO_DATA_FOUND, 'DST rule with DST_RULE_ID=' || TO_CHAR(v_dst_rule_id) || ' is not found in DST_RULE table.');  
  end if;
  
  if v_check <> 1
  then
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_TOO_MANY_ROWS_RETRIEVED, 'Too many rows retieved for DST rule with DST_RULE_ID=' || TO_CHAR(v_dst_rule_id) || '.');  
  end if;     
*/
  OPEN p_result_list FOR
    SELECT dr.DST_RULE_ID, 
           dr.COUNTRY_CODE,
           dr.DST_NAME,
           dr.DATE_START_RULE_MASK,
           dr.DATE_START,
           dr.DATE_END_RULE_MASK,
           dr.DATE_END 
      FROM DST_RULE dr
       WHERE DR.DST_RULE_ID = v_dst_rule_id;           

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
    p_error_code := RSIG_UTILS.c_OK;
	p_error_message := 'Succesfully completed';

    RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
    WHEN OTHERS THEN
        v_sqlcode := sqlcode;
        p_error_message := sqlerrm;
        --DBMS_OUTPUT.PUT_LINE(p_error_message);
        p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
        RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
        --OPEN p_result_list FOR SELECT v_sqlcode, p_error_message FROM dual;
        
END get_dst_rule_for_root_no;

END;
/
