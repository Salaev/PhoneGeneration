CREATE package body LEGACY_PKG is

------------------------------!------------------------------
------------------------------!------------------------------
function xis_tran_yes(p_handle_tran varchar2, p_label varchar2 := null) return boolean
is
begin
  xcheck_handle_tran(p_handle_tran, p_label);
  return (p_handle_tran = rsig_utils.c_HANDLE_TRAN_Y);
end;

------------------------------!------------------------------
function xis_tran_no(p_handle_tran varchar2, p_label varchar2 := null) return boolean
is
begin
  xcheck_handle_tran(p_handle_tran, p_label);
  return (p_handle_tran = rsig_utils.c_HANDLE_TRAN_N);
end;

------------------------------!------------------------------
function xis_tran_s(p_handle_tran varchar2, p_label varchar2 := null) return boolean
is
begin
  xcheck_handle_tran(p_handle_tran, p_label);
  return (p_handle_tran = rsig_utils.c_HANDLE_TRAN_S);
end;

------------------------------!------------------------------
------------------------------!------------------------------
function xis_yes(p_yes_no varchar2, p_label varchar2 := null) return boolean is
begin
  xcheck_yes_no(p_yes_no, p_label);
  return (p_yes_no = rsig_utils.c_YES);
end;

------------------------------!------------------------------
function xis_no(p_yes_no varchar2, p_label varchar2 := null) return boolean is
begin
  xcheck_yes_no(p_yes_no, p_label);
  return (p_yes_no = rsig_utils.c_NO);
end;

------------------------------!------------------------------
------------------------------!------------------------------
procedure xcheck_handle_tran(p_handle_tran varchar2, p_label varchar2 := null)
is
begin
  ------------------------------
  util_pkg.xcheck_cond_missing(p_handle_tran is null, nvl(p_label, 'p_handle_tran'));
  ------------------------------
  util_pkg.xcheck_cond_invalid(
    p_handle_tran not in (rsig_utils.c_HANDLE_TRAN_Y, rsig_utils.c_HANDLE_TRAN_N, rsig_utils.c_HANDLE_TRAN_S),
    'p_handle_tran not in (' || rsig_utils.c_HANDLE_TRAN_Y || ', ' || rsig_utils.c_HANDLE_TRAN_N || ', ' || rsig_utils.c_HANDLE_TRAN_S || ')'
  );
  ------------------------------
end;

------------------------------!------------------------------
procedure xcheck_yes_no(p_yes_no varchar2, p_label varchar2 := null)
is
begin
  ------------------------------
  util_pkg.xcheck_cond_missing(p_yes_no is null, nvl(p_label, 'p_yes_no'));
  ------------------------------
  util_pkg.xcheck_cond_invalid(
    p_yes_no not in (rsig_utils.c_HANDLE_TRAN_S, rsig_utils.c_YES, rsig_utils.c_NO),
    'p_yes_no not in (' || rsig_utils.c_YES || ', ' || rsig_utils.c_NO || ')'
  );
  ------------------------------
end;

------------------------------!------------------------------
end;
/
