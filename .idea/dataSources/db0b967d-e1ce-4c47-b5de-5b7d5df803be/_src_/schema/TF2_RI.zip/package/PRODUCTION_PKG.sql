CREATE package PRODUCTION_PKG is

------------------------------!------------------------------
  --!_! moved from RSIG_PHONE_NUMBER
  procedure PROD_FindFreePhoneNumbers_i
  (
    p_host_id host.host_id%type,
    p_msisdn_mask varchar2,
    p_msisdn_start varchar2,
    p_msisdn_end varchar2,
    p_network_operator_code varchar2,
    p_linked_network_operator_code varchar2,
    p_phone_status_code phone_number.net_address_status_code%type,
    p_phone_type_code phone_number_series.phone_number_type_code%type,
    p_quantity_limit number,
    p_salability_category varchar2,
    p_user_login users.login_name%type,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor,
    p_rejected_list out sys_refcursor
  );

------------------------------!------------------------------
  --!_! moved from RSIG_PHONE_NUMBER
  procedure PROD_CheckPhonesByRange_2_i
  (
    p_msisdn_start varchar2,
    p_msisdn_end varchar2,
    p_host_id host.host_id%type,
    p_network_operator_code varchar2,
    p_linked_network_operator_code varchar2,
    p_phone_status_code phone_number.net_address_status_code%type,
    p_phone_type_code phone_number_series.phone_number_type_code%type,
    p_salability_category varchar2,
    p_user_login users.login_name%type,
    p_requestedcnt number,
    p_result_list out sys_refcursor,
    p_rejected_list out sys_refcursor
  );

  --!_! moved from RSIG_PHONE_NUMBER
  procedure PROD_GetLinkedPhonesAll_i
  (
    p_host_id host.host_id%type,
    p_network_operator_code network_operator.network_operator_code%type,
    p_linked_network_operator_code network_operator.network_operator_code%type,
    p_phone_type phone_number_series.phone_number_type_code%type,
    p_salability_category phone_number.salability_category_code%type,
    p_mask varchar2,
    p_phone_number_status_code phone_number.net_address_status_code%type,
    p_set_phone_number_status_code phone_number.net_address_status_code%type,
    p_phone_number_count number,
    p_user_login varchar2,
    p_result_list out sys_refcursor
  );

  --!_! moved from RSIG_PHONE_NUMBER
  procedure PROD_GetNotLinkedPhones_2_i
  (
    p_host_id host.host_id%type,
    p_network_operator_code network_operator.network_operator_code%type,
    p_phone_type phone_number_series.phone_number_type_code%type,
    p_salability_category phone_number.salability_category_code%type,
    p_mask varchar2,
    p_phone_number_status_code phone_number.net_address_status_code%type,
    p_set_phone_number_status_code phone_number.net_address_status_code%type,
    p_phone_number_count number,
    p_user_login varchar2,
    p_result_list out sys_refcursor
  );

------------------------------!------------------------------
end;
/
