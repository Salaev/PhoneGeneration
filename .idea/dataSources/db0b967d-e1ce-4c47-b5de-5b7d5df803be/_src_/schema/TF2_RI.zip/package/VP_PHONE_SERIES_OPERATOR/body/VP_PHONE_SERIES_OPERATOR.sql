CREATE package body VP_PHONE_SERIES_OPERATOR is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_rct_this(p_coll rct_this) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_rct_this(p_coll in out nocopy rct_this, p_size number)
is
  v_dif number;
begin
  ------------------------------
  util_pkg.XCheck_size0(p_size, 'p_size');
  ------------------------------
  if p_coll is null
  then
    p_coll := rct_this();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get1_i(p_id integer, p_id2 integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return phone_series_operator%rowtype
is
  v_res phone_series_operator%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_id2 is null, 'p_id2');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_PSO_PNS)*/
        * into v_res
      from phone_series_operator z
      where 1 = 1
        and phone_number_series_id = p_id
        and p_date between start_date and nvl(end_date, to_date('01.01.4000','dd.mm.yyyy'))
        and network_operator_id = p_id2
      for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_PSO_PNS)*/
        * into v_res
      from phone_series_operator z
      where 1 = 1
        and phone_number_series_id = p_id
        and p_date between start_date and nvl(end_date, to_date('01.01.4000','dd.mm.yyyy'))
        and network_operator_id = p_id2
      for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_PSO_PNS)*/
      * into v_res
    from phone_series_operator z
    where 1 = 1
      and phone_number_series_id = p_id
      and p_date between start_date and nvl(end_date, to_date('01.01.4000','dd.mm.yyyy'))
      and network_operator_id = p_id2
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1(p_id integer, p_id2 integer, p_date date) return phone_series_operator%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get1_i(p_id, p_id2, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget1(p_id integer, p_id2 integer, p_date date) return phone_series_operator%rowtype
is
  v_res phone_series_operator%rowtype;
begin
  ------------------------------
  v_res := get1(p_id, p_id2, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotFound_OnDate2(p_id, p_id2, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get1(p_id integer, p_id2 integer, p_date date) return phone_series_operator%rowtype
is
  v_res phone_series_operator%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_i(p_id, p_id2, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_xget1(p_id integer, p_id2 integer, p_date date) return phone_series_operator%rowtype
is
  v_res phone_series_operator%rowtype;
begin
  ------------------------------
  v_res := xlock_get1(p_id, p_id2, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotFound_OnDate2(p_id, p_id2, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xlock(p_id integer, p_id2 integer, p_date date)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(xlock_xget1(p_id, p_id2, p_date).phone_number_series_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function getN_i(p_id_weak number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return rct_this
is
  v_res rct_this;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id_weak is null, 'p_id_weak');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_PSO_PNS)*/
        * bulk collect into v_res
      from phone_series_operator z
      where 1 = 1
        and phone_number_series_id = p_id_weak
        and p_date between start_date and nvl(end_date, to_date('01.01.4000','dd.mm.yyyy'))
      order by phone_number_series_id, network_operator_id
      for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_PSO_PNS)*/
        * bulk collect into v_res
      from phone_series_operator z
      where 1 = 1
        and phone_number_series_id = p_id_weak
        and p_date between start_date and nvl(end_date, to_date('01.01.4000','dd.mm.yyyy'))
      order by phone_number_series_id, network_operator_id
      for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_PSO_PNS)*/
      * bulk collect into v_res
    from phone_series_operator z
    where 1 = 1
      and phone_number_series_id = p_id_weak
      and p_date between start_date and nvl(end_date, to_date('01.01.4000','dd.mm.yyyy'))
    order by phone_number_series_id, network_operator_id
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function getN(p_id_weak number, p_date date) return rct_this
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return getN_i(p_id_weak, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_getN(p_id_weak number, p_date date) return rct_this
is
  v_res rct_this;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := getN_i(p_id_weak, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xvalid_i(p_rec phone_series_operator%rowtype)
is
begin
  ------------------------------
  util_pkg.xcheck_version_dates(p_rec.start_date, nvl(p_rec.end_date, to_date('01.01.4000','dd.mm.yyyy')));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function find_i_id(p_rec phone_series_operator%rowtype) return boolean
is
  v_cnt number;
begin
  ------------------------------
  select /*+ index_asc(z, I_PSO_PNS)*/
    count(1) cnt into v_cnt
  from phone_series_operator z
  where 1 = 1
    and phone_number_series_id = p_rec.phone_number_series_id
    and greatest(p_rec.start_date, start_date) <= least(p_rec.end_date, nvl(end_date, to_date('01.01.4000','dd.mm.yyyy')))
    and network_operator_id = p_rec.network_operator_id
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i(p_rec phone_series_operator%rowtype) return boolean
is
begin
  ------------------------------
  if find_i_id(p_rec)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xunique(p_rec phone_series_operator%rowtype)
is
begin
  ------------------------------
  if find_i_id(p_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_Vers2(p_rec.phone_number_series_id, p_rec.network_operator_id, p_rec.start_date, p_rec.end_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_i(p_rec phone_series_operator%rowtype)
is
  v_rec phone_series_operator%rowtype;
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
  xunique(p_rec);
  ------------------------------
  v_rec := p_rec;
  v_rec.end_date := util_ri.valid_date_to2invalid_date_to(p_rec.end_date);
  ------------------------------
  insert into phone_series_operator
  values v_rec;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure close_i(p_rec phone_series_operator%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
  update /*+ index_asc(z, I_PSO_PNS)*/
    phone_series_operator z
  set
    end_date = p_rec.end_date,
    user_id_of_change = p_rec.user_id_of_change,
    date_of_change = p_rec.date_of_change
  where 1 = 1
    and phone_number_series_id = p_rec.phone_number_series_id
    and p_rec.end_date between start_date and nvl(end_date, to_date('01.01.4000','dd.mm.yyyy'))
    and start_date = p_rec.start_date
    and network_operator_id = p_rec.network_operator_id
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotFound_Vers2(p_rec.phone_number_series_id, p_rec.network_operator_id, p_rec.start_date, p_rec.end_date, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_OnDate2(p_rec.phone_number_series_id, p_rec.network_operator_id, p_rec.end_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_identified(p_rec phone_series_operator%rowtype) return boolean
is
begin
  ------------------------------
  return (p_rec.phone_number_series_id is not null and p_rec.network_operator_id is not null);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open(p_rec in out nocopy phone_series_operator%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  --!_!p_rec.phone_number_series_id := sq_phone_series_operator.nextval;
  --!_!p_rec.network_operator_id := sq_network_operator.nextval;
  ------------------------------
  p_rec.start_date := nvl(p_rec.start_date, v_sysdate);
  p_rec.end_date := nvl(p_rec.end_date, util_pkg.c_open_date_to);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change(p_rec in out nocopy phone_series_operator%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_to_prev date;
  v_rec phone_series_operator%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.phone_number_series_id is null, 'p_rec.phone_number_series_id');
  util_pkg.XCheck_Cond_Missing(p_rec.network_operator_id is null, 'p_rec.network_operator_id');
  ------------------------------
  p_rec.start_date := nvl(p_rec.start_date, v_sysdate);
  p_rec.end_date := nvl(p_rec.end_date, util_pkg.c_open_date_to);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(p_rec.start_date);
  ------------------------------
  v_rec := xlock_get1(p_rec.phone_number_series_id, p_rec.network_operator_id, v_date_to_prev);
  ------------------------------
  if not is_identified(v_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotFound_OnDate2(p_rec.phone_number_series_id, p_rec.network_operator_id, v_date_to_prev, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.user_id_of_change := p_rec.user_id_of_change;
  ------------------------------
  v_rec.date_of_change := v_sysdate;
  v_rec.end_date := v_date_to_prev;
  ------------------------------
  close_i(v_rec);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close
(
  p_id integer,
  p_id2 integer,
  p_user_id integer,
  p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_to_prev date;
  v_rec phone_series_operator%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_id2 is null, 'p_id2');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(nvl(p_date_from, v_sysdate));
  ------------------------------
  v_rec := xlock_get1(p_id, p_id2, v_date_to_prev);
  ------------------------------
  if not is_identified(v_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotFound_OnDate2(p_id, p_id2, v_date_to_prev, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.user_id_of_change := p_user_id;
  ------------------------------
  v_rec.date_of_change := v_sysdate;
  v_rec.end_date := v_date_to_prev;
  ------------------------------
  close_i(v_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_4_net_op_type(p_external boolean, p_pns_id integer, p_date date) return phone_series_operator%rowtype
is
  v_coll rct_this;
  v_count number;
  v_row phone_series_operator%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_external is null, 'p_external');
  util_pkg.XCheck_Cond_Missing(p_pns_id is null, 'p_pns_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_coll := getN(p_id_weak => p_pns_id, p_date => p_date);
  ------------------------------
  v_count := get_count_rct_this(v_coll);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_row := v_coll(v_i);
    ------------------------------
    if p_external = vp_network_operator.is_external3(p_network_operator_id => v_row.network_operator_id, p_date => p_date)
    then
      ------------------------------
      return v_row;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
