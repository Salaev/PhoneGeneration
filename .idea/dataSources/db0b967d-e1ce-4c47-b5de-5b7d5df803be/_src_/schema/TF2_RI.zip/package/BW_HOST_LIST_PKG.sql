CREATE package BW_HOST_LIST_PKG is

----------------------------------!---------------------------------------------
  c_agroup_id_black_host_list    constant number := 1001;
  c_agroup_id_white_host_list    constant number := 1002;

  c_agroup_name_black_host_list  constant nvarchar2(255) := 'BLACK_HOST_LIST';
  c_agroup_name_white_host_list  constant nvarchar2(255) := 'WHITE_HOST_LIST';

----------------------------------!---------------------------------------------
  procedure add_host2black_list(p_host_id ct_number, p_date date, p_user_id number);
  procedure add_host2black_list2(p_host_id ct_number, p_user_id number);
  procedure add_host2black_list3(p_host_id number, p_user_id number);

  procedure del_host2black_list(p_host_id ct_number, p_date date, p_user_id number);
  procedure del_host2black_list2(p_host_id ct_number, p_user_id number);
  procedure del_host2black_list3(p_host_id number, p_user_id number);

  function get_black_list(p_date date) return ct_number;
  function get_black_list2 return ct_number;

----------------------------------!---------------------------------------------
  procedure add_host2white_list(p_host_id ct_number, p_date date, p_user_id number);
  procedure add_host2white_list2(p_host_id ct_number, p_user_id number);
  procedure add_host2white_list3(p_host_id number, p_user_id number);

  procedure del_host2white_list(p_host_id ct_number, p_date date, p_user_id number);
  procedure del_host2white_list2(p_host_id ct_number, p_user_id number);
  procedure del_host2white_list3(p_host_id number, p_user_id number);

  function get_white_list(p_date date) return ct_number;
  function get_white_list2 return ct_number;

----------------------------------!---------------------------------------------
end;
/
