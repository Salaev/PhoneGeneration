CREATE package hlb_pkg is

----------------------------------!---------------------------------------------
  c_opt_HOST_nl_limit            constant varchar2(100) := 'HOST_NL_LIMIT';
  c_opt_LA_nl_limit              constant varchar2(100) := 'LOCATION_AREA_NL_LIMIT';
  c_opt_BS_nl_limit              constant varchar2(100) := 'BASE_STATIONNL_LIMIT';

----------------------------------!---------------------------------------------
  c_default_HOST_nl_limit        constant number := 10;
  c_default_LA_nl_limit          constant number := 10;
  c_default_BS_nl_limit          constant number := 10;

----------------------------------!---------------------------------------------
  --!_!error code
  c_ec_home_no_not_found         number := -133;
  c_ec_no_not_found              number := -230;

  --!_!error message
  c_em_home_no_not_found         varchar2(4000) := 'Home network operator not found';
  c_em_no_not_found              varchar2(4000)  := 'Network operator not found';

  --!_!roaming type
  c_rt_no_roaming                number := 0;
  c_rt_international_roaming     number := 4;

----------------------------------!---------------------------------------------
  procedure dbg_ct_host_lac_bs(p_coll ct_host_lac_bs, p_label varchar2 := null);

----------------------------------!---------------------------------------------
  function get_host_for_host_lac_bs(p_coll ct_host_lac_bs, p_trim_empty boolean) return ct_host_lac_bs;
  function get_la_for_host_lac_bs(p_coll ct_host_lac_bs, p_trim_empty boolean) return ct_host_lac_bs;
  function get_bs_for_host_lac_bs(p_coll ct_host_lac_bs, p_trim_empty boolean) return ct_host_lac_bs;
  function get_zbs_for_host_lac_bs(p_coll ct_host_lac_bs, p_trim_empty boolean) return ct_host_lac_bs;

  function get_roaming_for_host_lac_bs
  (
    p_home_no_id ct_number,
    p_neighbour_no_id ct_number,
    p_coll ct_host_lac_bs,
    p_trim_empty boolean
  ) return ct_host_lac_bs;

  function get_zone_result(p_base_coll ct_host_lac_bs, p_coll ct_host_lac_bs, p_trim_empty boolean) return ct_host_lac_bs;
  function get_roaming_result(p_base_coll ct_host_lac_bs, p_coll ct_host_lac_bs, p_trim_empty boolean) return ct_host_lac_bs;

  function get_roaming_by_msc_lac_cell_i
  (
    p_home_no_id ct_number,
    p_neighbour_no_id ct_number,
    p_msc ct_varchar_s,
    p_lac ct_varchar_s,
    p_cell ct_varchar_s,
    p_validity_date ct_date
  ) return ct_number;

----------------------------------!---------------------------------------------
  procedure Get_Roaming_Type_i
  (
    p_msisdn ct_varchar_s,
    p_validity_date ct_date,
    p_msc ct_varchar_s,
    p_lac ct_varchar_s,
    p_cell ct_varchar_s,
    p_mcc ct_varchar_s,
    p_mnc ct_varchar_s,
    p_roaming_type out ct_number,
    p_network_operator_id out ct_number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  );

----------------------------------!---------------------------------------------

end;
/
