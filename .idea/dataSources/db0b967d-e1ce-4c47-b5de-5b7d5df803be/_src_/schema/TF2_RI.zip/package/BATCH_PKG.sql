CREATE package batch_pkg is

----------------------------------!---------------------------------------------
  c_BATCH_TYPE_NA_UNMNG          constant number := 1;
  c_BATCH_TYPE_NA_MNG            constant number := 2;
  c_BATCH_TYPE_NA_MNP_RETURN     constant number := 3;

  c_BATCH_ID_DUMMY               constant number := 0;

  c_bs_new                       constant number := 0;
  c_bs_process                   constant number := 1;
  c_bs_complete                  constant number := 2;

----------------------------------!---------------------------------------------
  type t_batch is table of batch%rowtype;


----------------------------------!---------------------------------------------
  function get_batch_details_i(p_batch_id number) return ct_number;
  procedure get_batch_details_by_object_i(p_object_id ct_number, p_batch_type ct_number, p_trim_empty boolean, p_object_id2 out ct_number, p_batch_id out ct_number);
  function get_batches_by_object_i(p_object_id ct_number, p_batch_type ct_number) return ct_number;
  function get_batches_by_object2_i(p_object_id number, p_batch_type ct_number) return ct_number;

----------------------------------!---------------------------------------------
  procedure batch_upd_date_to_i(p_batch_id number, p_date_to date, p_user_id number);
  procedure batch_upd_status_i(p_batch_id number, p_status number, p_user_id number);

  function batch_ins_i(p_batch_type number, p_date_from date, p_date_to date, p_user_id number, p_batch_status number) return number;
  procedure batch_del_ii(p_batch_id number, p_user_id number);
  procedure batch_del_i(p_batch_id number, p_user_id number, p_silent_not_empty boolean);
  procedure batches_del_i(p_batch_id ct_number, p_user_id number, p_silent_not_empty boolean);

  procedure batch_del_full_i(p_batch_id number, p_user_id number);

  procedure batch_add_to_i(p_batch_id number, p_object_id ct_number, p_user_id number);
  procedure batch_remove_from_i(p_object_id ct_number, p_batch_type ct_number, p_user_id number);

----------------------------------!---------------------------------------------
  function lock_1batch(p_id number, p_wait boolean) return boolean;

----------------------------------!---------------------------------------------
  function get_first_batch_by_status
  (
    p_status number,
    p_type number,
    p_date date
  ) return number;

  function get_expired_batch_cursor
  (
    p_status number,
    p_type number,
    p_date date
  ) return sys_refcursor;

  function get_expired_batch_cursor2
  (
    p_type number,
    p_date date
  ) return sys_refcursor;

----------------------------------!---------------------------------------------
  procedure batch_add_to(p_batch_id number, p_object_id ct_number, p_user_id number);
  procedure batch_remove_from(p_object_id ct_number, p_batch_type ct_number, p_user_id number);

  function batch_ins(p_batch_type number, p_date_from date, p_date_to date, p_user_id number) return number;
  procedure batch_del(p_batch_id number, p_user_id number, p_silent_not_empty boolean);
  procedure batch_del_full(p_batch_id number, p_user_id number);

  procedure batch_upd_date_to(p_batch_id number, p_date_to date, p_user_id number);
  procedure move_batch_to_next_status(p_batch_id number, p_user_id number, p_lock boolean);
  procedure reset_batch_status(p_batch_id number, p_user_id number, p_lock boolean);

----------------------------------!---------------------------------------------
  procedure resize_t_batch(p_coll in out nocopy t_batch, p_size number);
  function get_nbatches(p_ids ct_number, p_lock boolean, p_batchs out t_batch, p_error_codes out ct_number, p_error_message out ct_varchar) return boolean;

  function get_batch_details(p_batch_id number, p_xlock_batch boolean) return ct_number;

----------------------------------!---------------------------------------------
  procedure XCheck_na_res_batch_type(p_batch_type number);
  function get_na_res_batch_types return ct_number;

  procedure get_na_res_batch_details_by_na(p_na_id ct_number, p_trim_empty boolean, p_na_id2 out ct_number, p_batch_id out ct_number);
  function get_na_res_batches_by_na(p_na_id ct_number) return ct_number;
  function get_na_res_batches_by_na2(p_na_id number) return ct_number;

  function get_res_batch_msisdns(p_batch_id number, p_date date, p_xlock_batch boolean) return ct_varchar_s;

  procedure na_res_batch_del_i(p_batch_id number, p_user_id number, p_silent_not_empty boolean);
  procedure na_res_batch_del_plain(p_batch_id number, p_user_id number);
  procedure na_res_batch_del_smart(p_batch_id number, p_user_id number);

  procedure na_res_batches_del_i(p_batch_id ct_number, p_user_id number, p_silent_not_empty boolean);
  procedure na_res_batches_del2_i(p_batch_id number, p_user_id number, p_silent_not_empty boolean);
  procedure na_res_batches_del_plain(p_batch_id ct_number, p_user_id number);
  procedure na_res_batches_del_smart(p_batch_id ct_number, p_user_id number);
  procedure na_res_batches_del2_plain(p_batch_id number, p_user_id number);
  procedure na_res_batches_del2_smart(p_batch_id number, p_user_id number);

  procedure na_res_batch_add_to(p_batch_id number, p_na_id ct_number, p_user_id number);
  procedure na_res_batch_add_to2(p_batch_id number, p_na_id number, p_user_id number);
  procedure na_res_batch_remove_from(p_na_id ct_number, p_user_id number);
  procedure na_res_batch_remove_from2(p_na_id number, p_user_id number);

  procedure na_res_batch_del_full_i(p_batch_id number, p_user_id number);
  procedure na_res_batch_del_full(p_batch_id number, p_user_id number);

  function na_res_batch_get_details(p_batch_id number) return ct_number;

  procedure na_res_batch_upd_date_to(p_batch_id number, p_date_to date, p_user_id number);
  procedure na_res_batch_to_next_status(p_batch_id number, p_user_id number);
  procedure na_res_batch_reset_status(p_batch_id number, p_user_id number);

----------------------------------!---------------------------------------------
  procedure XCheck_na_mnp_batch_type(p_batch_type number);
  function get_na_mnp_batch_types return ct_number;

  procedure get_na_mnp_batch_details_by_na(p_na_id ct_number, p_trim_empty boolean, p_na_id2 out ct_number, p_batch_id out ct_number);
  function get_na_mnp_batches_by_na(p_na_id ct_number) return ct_number;
  function get_na_mnp_batches_by_na2(p_na_id number) return ct_number;

  function get_mnp_batch_nas(p_batch_id number, p_date date, p_xlock_batch boolean) return ct_number;

  procedure na_mnp_batch_del_i(p_batch_id number, p_user_id number, p_silent_not_empty boolean);
  procedure na_mnp_batch_del_plain(p_batch_id number, p_user_id number);
  procedure na_mnp_batch_del_smart(p_batch_id number, p_user_id number);

  procedure na_mnp_batches_del_i(p_batch_id ct_number, p_user_id number, p_silent_not_empty boolean);
  procedure na_mnp_batches_del2_i(p_batch_id number, p_user_id number, p_silent_not_empty boolean);
  procedure na_mnp_batches_del_plain(p_batch_id ct_number, p_user_id number);
  procedure na_mnp_batches_del_smart(p_batch_id ct_number, p_user_id number);
  procedure na_mnp_batches_del2_plain(p_batch_id number, p_user_id number);
  procedure na_mnp_batches_del2_smart(p_batch_id number, p_user_id number);

  procedure na_mnp_batch_del_full_i(p_batch_id number, p_user_id number);
  procedure na_mnp_batch_del_full(p_batch_id number, p_user_id number);

  procedure na_mnp_batch_add_to(p_batch_id number, p_na_id ct_number, p_user_id number);
  procedure na_mnp_batch_add_to2(p_batch_id number, p_na_id number, p_user_id number);
  procedure na_mnp_batch_remove_from(p_na_id ct_number, p_user_id number);
  procedure na_mnp_batch_remove_from2(p_na_id number, p_user_id number);

  function na_mnp_batch_get_details(p_batch_id number) return ct_number;

  procedure na_mnp_batch_upd_date_to(p_batch_id number, p_date_to date, p_user_id number);
  procedure na_mnp_batch_to_next_status(p_batch_id number, p_user_id number);
  procedure na_mnp_batch_reset_status(p_batch_id number, p_user_id number);

----------------------------------!---------------------------------------------
end;
/
