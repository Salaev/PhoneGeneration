CREATE package body RSIG_STATISTICS is

---------------------------------------------
--     PROCEDURE Run_Statistics
---------------------------------------------

PROCEDURE Run_Statistics
(
  error_code  OUT NUMBER,
  handle_tran CHAR DEFAULT RSIG_UTILS.C_HANDLE_TRAN_Y,
  p_rundate   DATE
) IS
  v_event_source            VARCHAR2(60) := 'RSIG_STATISTICS.Run_Statistics';
  v_child_operators         NUMBER;
  v_location_area           NUMBER;
  v_base_station            NUMBER;
  v_payment_entrance        NUMBER;
  v_pay_desk                NUMBER;
  v_sysdate                 DATE;
  v_net_op_id               NUMBER;
  v_child_network_operators NUMBER;
  v_zone                    NUMBER;
  v_stats_id                NUMBER;

  --defien types for collections
  TYPE Net_op_idT IS TABLE OF NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE;
  TYPE Net_op_nameT IS TABLE OF NETWORK_OPERATOR.NETWORK_OPERATOR_NAME%TYPE;

  -- define collections
  Net_op_id   Net_op_idT;
  Net_op_name Net_op_nameT;

  i NUMBER;
  j NUMBER;
  k NUMBER;
  l NUMBER;

  CURSOR cNetwork_operator IS
    SELECT NETWORK_OPERATOR_ID,
           NETWORK_OPERATOR_NAME
      FROM NETWORK_OPERATOR
     WHERE deleted IS NULL;
  v_rundate DATE;
BEGIN
  v_sysdate := SYSDATE;
  IF p_rundate IS NULL THEN
    v_rundate := v_sysdate;
  ELSE
    v_rundate := p_rundate;
  END IF;
  -- for all network operator
  OPEN cNetwork_operator;
  FETCH cNetwork_operator BULK COLLECT
    INTO Net_op_id, Net_op_name;
  FOR j IN Net_op_id.FIRST .. Net_op_id.LAST
  LOOP
    v_net_op_id := Net_op_id(j);
    --amount of locations
    SELECT COUNT(1)
      INTO v_location_area
      FROM zone z
      JOIN zone_base_station zbs ON zbs.zone_id = z.zone_id
      JOIN base_station bs ON zbs.base_station_id = bs.base_station_id
      JOIN location_area la ON bs.location_area_id = la.location_area_id
     WHERE z.network_operator_id = v_net_op_id
       AND v_rundate BETWEEN zbs.start_date AND nvl(zbs.end_date, v_rundate)
       AND (bs.deleted IS NULL OR bs.deleted > v_rundate)
       AND (la.deleted IS NULL OR la.deleted > v_rundate);
    --amount of base stations
    SELECT COUNT(1)
      INTO v_base_station
      FROM HOST h
      JOIN LOCATION_AREA la ON la.host_id = h.host_id
      JOIN base_station bs ON bs.location_area_id = la.location_area_id
     WHERE h.network_operator_id = v_net_op_id
       AND (bs.deleted IS NULL OR bs.deleted > v_rundate)
       AND (la.deleted IS NULL OR la.deleted > v_rundate);

    --amount of payment places
    SELECT COUNT(1)
      INTO v_pay_desk
      FROM PAY_DESK p
      JOIN PAYMENT_ENTRANCE pe ON p.payment_entrance_id = pe.payment_entrance_id
     WHERE pe.network_operator_id = v_net_op_id
       AND (pe.deleted IS NULL OR pe.deleted > v_rundate)
       AND (p.DELETED IS NULL OR p.deleted > v_rundate);

    --amount of payment entrances
    SELECT COUNT(1)
      INTO v_payment_entrance
      FROM PAYMENT_ENTRANCE pe
     WHERE pe.network_operator_id = v_net_op_id
       AND (pe.deleted IS NULL OR pe.deleted > v_rundate);

    --amount of child network operators
    SELECT COUNT(1)
      INTO v_child_network_operators
      FROM network_operator n
     WHERE n.network_operator_id_upper = v_net_op_id
       AND (n.deleted IS NULL OR n.deleted > v_rundate);
    --amount of zones
    SELECT COUNT(1)
      INTO v_zone
      FROM zone z
     WHERE z.network_operator_id = v_net_op_id
       AND (z.deleted IS NULL OR z.deleted > v_rundate);

    INSERT INTO STATS_MAIN
      (stats_id,
       network_operator_id,
       run_date,
       network_operator_name,
       location_area,
       base_station,
       payment_entrance,
       pay_desk,
       child_network_operators,
       zone)
    VALUES
      (S_STATS_MAIN.NEXTVAL,
       v_net_op_id,
       v_sysdate,
       Net_op_name(j),
       v_location_area,
       v_base_station,
       v_payment_entrance,
       v_pay_desk,
       v_child_network_operators,
       v_zone)
    RETURNING stats_id INTO v_stats_id;

    -- host statistic
    INSERT INTO STATS_HOST
      (stats_id,
       host_type_code,
       amount)
      SELECT v_stats_id,
             h.host_type_code,
             COUNT(h.host_id)
        FROM HOST h
       WHERE h.network_operator_id = v_net_op_id
         AND (h.deleted IS NULL OR h.deleted > v_rundate)
       GROUP BY h.host_type_code;
    -- sim serie statistic
    INSERT INTO STATS_SIM_SERIE
      (stats_id,
       sim_serie_status,
       sim_card_type_code,
       amount)
      SELECT v_stats_id,
             ss.status_code,
             s.sim_card_type_code,
             COUNT(1)
        FROM SIM_SERIES s
        JOIN sim_series_status_validity ss ON s.sim_series_id = ss.sim_series_id
       WHERE s.network_operator_id = v_net_op_id
         AND (s.deleted IS NULL OR s.deleted > v_rundate)
         AND v_rundate BETWEEN ss.start_date AND NVL(ss.end_date, v_rundate)
       GROUP BY s.sim_card_type_code,
                ss.status_code;

    --phone serie statistic
    INSERT INTO STATS_PHONE_SERIE
      (STATS_ID,
       PHONE_SERIE_TYPE_CODE,
       AMOUNT)
      SELECT v_stats_id,
             pns.phone_number_type_code,
             COUNT(1)
        FROM phone_series_operator pso
        JOIN phone_number_series pns ON pso.phone_number_series_id = pns.phone_number_series_id
       WHERE pso.network_operator_id = v_net_op_id
         AND (pns.deleted IS NULL OR pns.deleted > v_rundate)
         AND v_rundate BETWEEN pso.start_date AND NVL(pso.end_date, v_rundate)
       GROUP BY pns.phone_number_type_code;
    --phone number statistic
    INSERT INTO stats_phone_number
      (stats_id,
       salability_category_code,
       phone_number_type_code,
       bind,
       amount)
      SELECT v_stats_id,
             scc,
             pntc,
             bind,
             SUM(amount)
        FROM (SELECT --directly binded phone numbers to operator
               ps.salability_category_code scc,
               pns.phone_number_type_code pntc,
               decode(nvl(naap.access_point_id, -1), -1, RSIG_UTILS.c_PHONE_NOT_BIND, RSIG_UTILS.c_PHONE_BIND) bind, -- if naap.acces point id is null then return 0 (not_bind), else set it to 1 (bind)
               COUNT(1) amount
                FROM phone_operator po
                JOIN PHONE_NUMBER pn ON po.network_address_id = pn.network_address_id
                JOIN PHONE_NUMBER_SERIES pns ON pns.phone_number_series_id = pn.phone_number_series_id
                JOIN phone_number_salability_categ ps ON ps.network_address_id = pn.network_address_id
                left JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.network_address_id = pn.network_address_id
               WHERE po.network_operator_id = v_net_op_id
                 AND (pns.deleted IS NULL OR pns.deleted > v_rundate)
                 AND v_rundate BETWEEN nvl(naap.from_date, v_rundate) AND nvl(naap.to_date, v_rundate)
                 AND v_rundate BETWEEN po.start_date AND nvl(po.end_date, v_rundate)
                 AND v_rundate BETWEEN ps.start_date AND nvl(ps.end_date, v_rundate)
               GROUP BY ps.salability_category_code,
                        pns.phone_number_type_code,
                        decode(nvl(naap.access_point_id, -1),
                               -1,
                               RSIG_UTILS.c_PHONE_NOT_BIND,
                               RSIG_UTILS.c_PHONE_BIND)
              UNION ALL
              SELECT --phone numbers from sim series belonging to operator
               ps.salability_category_code scc,
               pns.phone_number_type_code pntc,
               decode(nvl(naap.access_point_id, -1), -1, RSIG_UTILS.c_PHONE_NOT_BIND, RSIG_UTILS.c_PHONE_BIND) bind, -- if naap.acces point id is null then return 0 (not_bind), else set it to 1 (bind)
               COUNT(1) amount
                FROM phone_series_operator pso
                JOIN PHONE_NUMBER_SERIES pns ON pns.phone_number_series_id = pso.phone_number_series_id
                JOIN phone_number pn ON pns.phone_number_series_id = pn.phone_number_series_id
                JOIN phone_number_salability_categ ps ON ps.network_address_id = pn.network_address_id
                left JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.network_address_id = pn.network_address_id
               WHERE pso.network_operator_id = v_net_op_id
                 AND (pns.deleted IS NULL OR pns.deleted > v_rundate)
                 AND v_rundate BETWEEN nvl(naap.from_date, v_rundate) AND nvl(naap.to_date, v_rundate)
                 AND v_rundate BETWEEN pso.start_date AND nvl(pso.end_date, v_rundate)
                 AND v_rundate BETWEEN ps.start_date AND nvl(ps.end_date, v_rundate)
               GROUP BY ps.salability_category_code,
                        pns.phone_number_type_code,
                        decode(nvl(naap.access_point_id, -1),
                               -1,
                               RSIG_UTILS.c_PHONE_NOT_BIND,
                               RSIG_UTILS.c_PHONE_BIND))
       GROUP BY scc,
                pntc,
                bind;
    --sim cards statistic
    INSERT INTO STATS_SIM_CARD
      (STATS_ID,
       SIM_CARD_STATUS,
       BIND,
       AMOUNT)
      SELECT v_stats_id,
             apsh.access_point_status_code,
             decode(nvl(naap.access_point_id, -1), -1, RSIG_UTILS.c_PHONE_NOT_BIND, RSIG_UTILS.c_PHONE_BIND) bind, -- if naap.acces point id is null then return 0 (not_bind), else set it to 1 (bind)
             COUNT(1)
        FROM SIM_SERIES ss
        JOIN sim_card sc ON ss.sim_series_id = sc.sim_series_id
        JOIN ACCESS_POINT_STATUS_HISTORY apsh ON apsh.access_point_id = sc.access_point_id
        left JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.access_point_id = sc.access_point_id
       WHERE ss.network_operator_id = v_net_op_id
         AND (ss.deleted IS NULL OR ss.deleted > v_rundate)
         AND v_rundate BETWEEN naap.from_date AND nvl(naap.to_date, v_rundate)
         AND v_rundate BETWEEN apsh.start_date AND nvl(apsh.end_date, v_rundate)
       GROUP BY apsh.access_point_status_code,
                decode(nvl(naap.access_point_id, -1),
                       -1,
                       RSIG_UTILS.c_PHONE_NOT_BIND,
                       RSIG_UTILS.c_PHONE_BIND);

  END LOOP;
  CLOSE cNetwork_operator;

  IF upper(handle_tran) = RSIG_UTILS.C_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK;

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE upper(handle_tran)
      WHEN RSIG_UTILS.C_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT RUN_STATISTICS;
      WHEN RSIG_UTILS.C_HANDLE_TRAN_Y THEN
        ROLLBACK;
    END CASE;
END Run_Statistics;

---------------------------------------------
--     PROCEDURE Get_Statistic
---------------------------------------------

PROCEDURE Get_Statistic
(
  p_stats_id            IN NUMBER,
  p_network_operator_id IN STATS_MAIN.NETWORK_OPERATOR_ID%TYPE,
  p_statistic_type      IN NUMBER,
  p_rundate             IN DATE,
  error_code            OUT NUMBER,
  result_list           OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_STATISTICS.Get_Statistic';
  EX_WRONG_TYPE EXCEPTION;
  v_rundate DATE;
BEGIN
  IF p_stats_id IS NULL
     AND p_statistic_type <> c_STATS_MAIN THEN
    raise_application_error(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Wrong combination of stats parameters');
  END IF;

  CASE p_statistic_type
    WHEN c_STATS_HOST THEN
      OPEN result_list FOR
        SELECT 0,
               ht.host_type_name,
               h.amount
          FROM STATS_HOST h
          JOIN host_type ht on TRIM(ht.host_type_code) = TRIM(h.host_type_code)
         WHERE stats_id = p_stats_id;
    WHEN c_STATS_MAIN THEN
      IF p_rundate IS NOT NULL THEN
        BEGIN
          SELECT run_date
            INTO v_rundate
            FROM (SELECT m.run_date
                    FROM STATS_MAIN m
                   WHERE 1 = 1
                     AND (m.network_operator_id = p_network_operator_id OR p_network_operator_id IS NULL)
                     AND (m.run_date <= p_rundate OR p_rundate IS NULL)
                     AND (m.stats_id = p_stats_id OR p_stats_id IS NULL)
                   ORDER BY m.run_date DESC)
           WHERE rownum = 1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            v_rundate := p_rundate;
        END;
      END IF;

      OPEN result_list FOR
        SELECT 0,
               m.stats_id,
               m.network_operator_id,
               m.run_date,
               m.network_operator_name,
               m.location_area,
               m.base_station,
               m.payment_entrance,
               m.pay_desk,
               m.child_network_operators,
               m.zone
          FROM STATS_MAIN m
         WHERE 1 = 1
           AND (m.network_operator_id = p_network_operator_id OR p_network_operator_id IS NULL)
           AND (m.run_date = v_rundate OR v_rundate IS NULL)
           AND (m.stats_id = p_stats_id OR p_stats_id IS NULL)
         ORDER BY m.network_operator_id,
                  m.run_date,
                  m.stats_id;
    WHEN c_STATS_PHONE_NUMBER THEN
      OPEN result_list FOR
        SELECT 0,
               nas.net_address_status_name,
               psc.phone_salability_category_name salability_category_name,
               p.bind,
               p.amount
          FROM STATS_PHONE_NUMBER p
          JOIN network_address_status nas on TRIM(nas.net_address_status_code) = TRIM(p.phone_number_type_code)
          JOIN phone_salability_category psc on TRIM(psc.phone_salability_category_code) = TRIM(p.salability_category_code)
         WHERE stats_id = p_stats_id;
    WHEN c_STATS_PHONE_SERIE THEN
      OPEN result_list FOR
        SELECT 0,
               pnt.phone_number_type_name,
               ps.amount
          FROM STATS_PHONE_SERIE ps
          JOIN phone_number_type pnt on TRIM(pnt.phone_number_type_code) = TRIM(ps.phone_serie_type_code)
         WHERE stats_id = p_stats_id;
    WHEN c_STATS_SIM_CARD THEN
      OPEN result_list FOR
        SELECT 0,
               aps.access_point_status_name,
               sc.bind,
               sc.amount
          FROM STATS_SIM_CARD sc
          JOIN access_point_status aps on TRIM(aps.access_point_status_code) = TRIM(sc.sim_card_status)
         WHERE stats_id = p_stats_id;
    WHEN c_STATS_SIM_SERIE THEN
      OPEN result_list FOR
        SELECT 0,
               aps.ap_prod_status_name,
               trim(sct.sim_card_type_name),
               ss.amount
          FROM STATS_SIM_SERIE ss
          JOIN ap_prod_status aps on aps.ap_prod_status_code = ss.sim_serie_status
          JOIN sim_card_type sct on TRIM(sct.sim_card_type_code) = TRIM(ss.sim_card_type_code)
         WHERE stats_id = p_stats_id;
    ELSE
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Unknown stats parameter');
  END CASE;
  error_code := RSIG_UTILS.C_OK;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Get_Statistic;

---------------------------------------------
--     PROCEDURE Get_Rundates
---------------------------------------------

PROCEDURE Get_Rundates
(
  p_start_date IN DATE,
  p_end_date   IN DATE,
  error_code   OUT NUMBER,
  result_list  OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_STATISTICS.Get_Rundates';
BEGIN
  OPEN result_list FOR
    SELECT m.run_date,
           COUNT(1) operator_amount
      FROM STATS_MAIN m
     WHERE m.run_date BETWEEN NVL(p_start_date, m.run_date) AND NVL(p_end_date, m.run_date)
     GROUP BY m.run_date;

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN result_list FOR
      SELECT error_code FROM dual;
END Get_Rundates;

---------------------------------------------
--     PROCEDURE Statistic_Job
---------------------------------------------

PROCEDURE Statistic_Job IS
  v_event_source VARCHAR2(60) := 'RSIG_STATISTICS.Statistic_Job';
  v_error_code   NUMBER;
BEGIN
  RSIG_STATISTICS.RUN_STATISTICS(v_error_code, RSIG_UTILS.C_HANDLE_TRAN_Y, SYSDATE);
  IF v_error_code <> RSIG_UTILS.C_OK THEN
    RSIG_UTILS.Debug_Rsi(TO_CHAR(v_error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    RSIG_UTILS.Debug_Rsi(TO_CHAR(v_error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Statistic_Job;





end;
/
