CREATE PACKAGE RSIG_ACCESS_POINT_STATUS IS
/****************************************************************************
<header>
  <name>             	package RSIG_ACCESS_POINT_STATUS
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>           1.0.6   30.07.2008    Josef Hartman
                      procedure Lock_sims added
                      procedure Lock_sims_by_id added
                      procedure Lock_sims with params added
                      procedure Is_Status_Change_Allowed updated
  </version>
  <version>           1.0.5   30.04.2008    Josef Hartman
                      procedure Check_SIM_status_change added
  </version>
  <version>           1.0.4   13.11.2006    Petr Cepek
                      function Test_Row_For_Exist deleted
                      procedure Update_Access_Point_Status deleted
  </version>
  <version>           1.0.3   13.10.2006    Petr Cepek
                      procedure Is_Prod_Status_Change_Allowed created
                      procedure Is_Status_Change_Allowed created
                      procedure Change_SIM_Prod_Status created
  </version>
  <version>          	1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	Package contains procedures for managing access point status.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/

/****************************************************************************
  PROCEDURE

  %author            Josef Hartman
  %created           30.07.2008
  %version           1.0.0
  %application       Resource Inventory

  %usage            Procedure locks sims by give parameters

*/
/* {%skip}
  %version_log
  {*}

****************************************************************************/
PROCEDURE Lock_sims;

PROCEDURE Lock_sims_by_id;

PROCEDURE Lock_sims
(
  p_sn               IN  sim_card.sn%TYPE,
  p_access_point_id  OUT sim_card.access_point_id%TYPE,
  p_error            OUT INT
);

/****************************************************************************
<header>
  <name>             	procedure Get_Access_Point_Statuses
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>          	1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	Procedure returns all sim statuses as IN OUT ref cursor.
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      Exists variable:
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_TEXT_BEFORE_SELECT
                        RSIG_UTILS.c_DEBUG_TEXT_AFTER_SELECT
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        error_code - OUT - NUMBER
                      p_cur_access_point_statuses - IN OUT - ref cursor containing
                        ACCESS_POINT_STATUS_CODE
                        ACCESS_POINT_STATUS_NAME
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Get_Access_Point_Statuses (
    error_code                   OUT    NUMBER,
    p_cur_access_point_statuses  IN OUT RSIG_UTILS.REF_CURSOR
  );

/****************************************************************************
<header>
  <name>            procedure Is_Prod_Status_Change_Allowed
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0         4.10.2006  -  created
  </version>

  <Description>     Procedure check if for some access point can
                    be changed production status to new status.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
FUNCTION Is_Prod_Status_Change_Allowed(
  p_access_point_id        IN  access_point.access_point_id%TYPE,
  p_new_status             IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_IS_BP                  IN  VARCHAR2,
  p_date                   IN  DATE
)RETURN INT;

/****************************************************************************
<header>
  <name>            procedure Check_SIM_Status_Change
  </name>

  <author>          Josef Hartman
  </author>

  <version>
                    1.0.0   30.04.2008   created
  </version>

  <Description>     Procedure checks whether can be changed access point status
                    for some sim card in table tt_batch_na_ap according
                    to defined rules..
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Check_SIM_Status_Change(
  p_sim_status      IN  access_point_status_history.access_point_status_code%TYPE,
  p_date            IN  DATE
);

/****************************************************************************
<header>
  <name>            procedure Is_Status_Change_Allowed
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.1  30.07.2008  Josef Hartman
                           Added check for last interval
  </version>
  <version>
                    1.0.0  4.10.2006  -  created
  </version>

  <Description>     Procedure check if for some access point can
                    be changed access point status to new status.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
FUNCTION Is_Status_Change_Allowed(
  p_access_point_id        IN  access_point.access_point_id%TYPE,
  p_new_status             IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_IS_BP                  IN  VARCHAR2,
  p_date                   IN  DATE
)RETURN INT;

/****************************************************************************
<header>
  <name>            procedure Change_SIM_Prod_Status
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  11.10.2006  -  created
  </version>

  <Description>     Procedure closes old production status for sim card
                    and set new production status if rules in
                    ap_prod_status_trans view allow that.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Change_SIM_Prod_Status(
  p_access_point_id       IN  access_point.access_point_id%TYPE,
  p_prod_status_code      IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_start_date            IN  DATE,
  p_user_id               IN  NUMBER,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message	        OUT VARCHAR2
);

END RSIG_ACCESS_POINT_STATUS;
/
