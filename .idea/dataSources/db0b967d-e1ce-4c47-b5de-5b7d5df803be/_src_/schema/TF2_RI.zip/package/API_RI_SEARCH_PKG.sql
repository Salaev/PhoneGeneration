CREATE package API_RI_SEARCH_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure GetPhonesByStatus3
  (
    p_host_id                      varchar2,
    p_network_operator_id          number,
    p_phone_type                   varchar2,
    p_salability_category          util_pkg.cit_varchar_s,
    p_series_id                    number,
    p_mask                         varchar2,
    p_phone_number_status_code     varchar2,
    p_set_phone_number_status_code varchar2,
    p_StartingRow                  number,
    p_Phone_Number_Count           number,
    p_user_login                   varchar2,
    p_error_code                   out number,
    p_error_message                out varchar2,
    p_result_list                  out sys_refcursor
  );

  procedure GetPhonesByStatus2
  (
    p_host_id                      util_pkg.cit_varchar_s,
    p_network_operator_code        varchar2,
    p_phone_type                   varchar2,
    p_salability_category          util_pkg.cit_varchar_s,
    p_series_id                    number,
    p_mask                         varchar2,
    p_use_linked                   number,
    p_phone_number_status_code     util_pkg.cit_varchar_s,
    p_set_phone_number_status_code varchar2,
    p_startingrow                  number,
    p_phone_number_count           number,
    p_user_login                   varchar2,
    p_error_code                   out number,
    p_error_message                out varchar2,
    p_result_list                  out sys_refcursor
  );

  procedure GetPhonesByStatus22
  (
    p_host_id                      util_pkg.cit_varchar_s,
    p_network_operator_code        varchar2,
    p_phone_type                   varchar2,
    p_salability_category          util_pkg.cit_varchar_s,
    p_series_id                    number,
    p_mask                         varchar2,
    p_use_linked                   number,
    p_phone_number_status_code     util_pkg.cit_varchar_s,
    p_set_phone_number_status_code varchar2,
    p_StartingRow                  number,
    p_Phone_Number_Count           number,
    p_user_login                   varchar2,
    p_error_code                   out number,
    p_error_message                out varchar2,
    p_result_list                  out sys_refcursor
  );

  --!_!no network operator, no phone type filter
  procedure get_phones_by_status_series
  (
      p_host_id                  util_pkg.cit_varchar_s,
      p_salability_category      util_pkg.cit_varchar_s,
      p_series_id                phone_number_series.phone_number_series_id%type,
      p_mask                     varchar2,
      p_use_linked               number,
      p_phone_number_status_code util_pkg.cit_varchar_s,
      p_set_phone_number_status_code phone_number.net_address_status_code%type,
      p_startingrow              number,
      p_phone_number_count       number,
      p_user_login               varchar2,
      p_handle_tran              char := rsig_utils.c_HANDLE_TRAN_Y,
      p_raise_error              char := rsig_utils.c_NO,
      p_error_code               out number,
      p_error_message            out varchar2,
      p_result_list              out sys_refcursor
  );

  procedure Get_Free_Phones
  (
    p_network_operator_id          number,
    p_salability_category          varchar2,
    p_phone_type                   varchar2,
    p_number_of_phones             number,
    p_reserve                      number,
    p_user_login                   varchar2,
    p_mask                         varchar2,
    p_error_code                   out number,
    p_error_message                out varchar2,
    p_cur_free_phones_history      out sys_refcursor
  );

  procedure get_phone_numbers_2
  (
    p_network_operator_id    number,
    p_external_operator_id   number,
    p_phone_number_series_id number,
    p_host_id                varchar2,
    p_mask                   varchar2,
    p_status                 util_pkg.cit_varchar_s,
    p_category               util_pkg.cit_varchar_s,
    p_phone_number_type      varchar2,
    p_count                  number,
    p_linked_naap            number,
    p_msisdn_lower_bound     varchar2,
    p_cur_series             out rsig_utils.ref_cursor,
    p_error_code             out number,
    p_error_message          out varchar2
  );

  procedure Get_Phones
  (
    p_host_id                      varchar2,
    p_network_operator_code        varchar2,
    p_phone_type                   varchar2,
    p_salability_category_l        util_pkg.cit_varchar_s,
    p_series_id                    number,
    p_mask                         varchar2,
    p_phone_number_status_code_l   util_pkg.cit_varchar_s,
    p_set_phone_number_status_code varchar2,
    p_StartingRow                  number,
    p_Phone_Number_Count           number,
    p_user_login                   varchar2,
    p_error_code                   out number,
    p_error_message                out varchar2,
    p_result_list                  out sys_refcursor
  );

  procedure Get_Free_Phones_By_Host2
  (
    p_host_id              varchar2,
    p_operator_id          number,
    p_phone_number_type    varchar2,
    p_salability_category  varchar2,
    p_series_id            number,
    p_mask                 varchar2,
    p_phone_number_count   number,
    p_starting_row         number,
    p_error_code           out number,
    p_error_message        out varchar2,
    p_result_list          out sys_refcursor
  );

  procedure get_free_phones999
  (
    p_host_codes                   util_pkg.cit_varchar_s,
    p_network_operator_code        varchar2,
    p_network_operator_code_linked varchar2,
    p_phone_type_codes             util_pkg.cit_varchar_s,
    p_salability_category_codes    util_pkg.cit_varchar_s,
    p_mask                         varchar2,
    p_phone_number_status_codes    util_pkg.cit_varchar_s,
    p_phone_number_count           number,
    p_user_login                   varchar2,
    p_result_list                  out sys_refcursor,
    p_error_code                   out number,
    p_error_message                out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure Find_Linked_Phones
  (
    p_host_id                  varchar2,
    p_network_operator_code    varchar2,
    p_phone_number_series_id   number,
    p_linked_network_operator  varchar2,
    p_salability_cat_code_l    util_pkg.cit_varchar_s,
    p_phone_status_code_l      util_pkg.cit_varchar_s,
    p_mask                     varchar2,
    p_phone_count              number,
    p_set_phone_status_code    varchar2,
    p_user_login               varchar2,
    p_error_code               out number,
    p_error_message            out varchar2,
    p_result_list              out sys_refcursor
  );

  procedure Find_Linked_Phones_Ex
  (
    p_host_id                  varchar2,
    p_network_operator_code    varchar2,
    p_phone_number_series_id   number,
    p_linked_network_operator  varchar2,
    p_salability_cat_code_l    util_pkg.cit_varchar_s,
    p_phone_status_code_l      util_pkg.cit_varchar_s,
    p_mask                     varchar2,
    p_phone_count              number,
    p_set_phone_status_code    varchar2,
    p_user_login               varchar2,
    p_link_status              number, --0 - all, 1 - free, 2 - linked
    p_error_code               out number,
    p_error_message            out varchar2,
    p_result_list              out sys_refcursor
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure GetFreePhonesToNewBatch
  (
    p_host_codes                     util_pkg.cit_varchar_s,
    p_network_operator_code          varchar2,
    p_network_operator_code_linked   varchar2,
    p_phone_type                     util_pkg.cit_varchar_s,
    p_salability_categorys           util_pkg.cit_varchar_s,
    p_mask                           varchar2,
    p_phone_number_status_code       util_pkg.cit_varchar_s,
    p_phone_number_count             number,
    p_reserve_date                   date,
    p_reservation_period             number,
    p_user_login                     varchar2,
    p_batch_type                     number,
    p_error_code                     out number,
    p_error_message                  out varchar2,
    p_result_list                    out sys_refcursor,
    p_reserve_number                 out number
);

  procedure GetFreePhonesToExistBatch
  (
    p_host_codes                     util_pkg.cit_varchar_s,
    p_network_operator_code          varchar2,
    p_phone_type                     varchar2,
    p_salability_categorys           util_pkg.cit_varchar_s,
    p_mask                           varchar2,
    p_phone_number_status_code       util_pkg.cit_varchar_s,
    p_phone_number_count             number,
    p_user_login                     varchar2,
    p_reserve_number                 number,
    p_error_code                     out number,
    p_error_message                  out varchar2,
    p_result_list                    out sys_refcursor
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  --!_! SPECIAL CASE is pn.date_of_status_change <= p_date_of_change
  procedure GetPhonesByTypeAndStatus
  (
    p_phone_type varchar2,
    p_phone_number_status_code varchar2,
    p_set_phone_number_status varchar2,
    p_phone_number_count number,
    p_network_operator_code varchar2,
    p_date_of_change date,
    p_user_login varchar2,
    p_error_code out number,
    p_error_message out varchar2,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure reserve_phones4period
  (
    p_msisdn_ml util_pkg.cit_varchar_s,
    p_reserve_period_minutes number,
    p_user_login varchar2,
    p_reserve_number out number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
