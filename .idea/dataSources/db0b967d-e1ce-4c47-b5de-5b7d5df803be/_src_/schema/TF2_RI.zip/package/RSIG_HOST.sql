CREATE PACKAGE RSIG_HOST IS
/****************************************************************************
<header>
  <name>       packager RSIG_HOST
  </name>

  <author>     Jan Stodulka - GITUS
  </author>
  <version>    1.2.17  20.04.2011  Sergey Ermakov
               procedure Get_Host_By_ICCID_List updated.
  </version>
  <version>    1.2.16  09.02.2011  Pavel Vasiliev
               procedure Delete_Hosts updated.
  </version>
  <version>    1.2.15  18.09.2010  Pavel Vasiliev
               procedure Get_Hosts_By_Host_Type_Codes added.
  </version>
  <version>    1.2.14  08.09.2010  Pavel Vasiliev
               procedure Get_Hosts added.
  </version>
  <version>    1.2.13  26.07.2010  Sergey Ermakov
               procedure Get_Host_And_Net_Op updated.
  </version>
  <version>    1.2.12  12.07.2010  Sergey Ermakov
               procedure Get_Host_All updated.
               procedure Get_host_by_date updated.
  </version>
  <version>    1.2.11  01.06.2010  Sergey Ermakov
               procedure Insert_Host2 updated.
               procedure Update_Host2 updated.
  </version>
  <version>    1.2.10  21.05.2010  Sergey Ermakov
               procedure Get_Host updated.
  </version>
  <version>    1.2.9   10.09.2009  Pavel Vasiliev
               procedure Get_Host_By_ICCID_List updated.
               procedure Get_Host_Time_Zone updated.
               procedure Get_Type_Host_By_Host_Id updated.
               procedure Get_Type_Host_By_PA updated.
               procedure Get_Host_By_ICCID_List updated.
  </version>
  <version>    1.2.8   25.10.2008  Josef Hartman
               procedure Get_Type_Host_By_PA updated.
  </version>
  <version>    1.2.7   18.09.2008  Josef Hartman
               procedure Get_Type_Host_By_Host_Id added.
               procedure Get_Type_Host_By_PA added.
  </version>
  <version>    1.2.6   25.04.2008  Josef Hartman
               procedure Get_host_by_date added.
  </version>
  <version>    1.2.5   29.02.2008  Petr Cepek
               procedure Get_Host_By_IMSI_List updated.
  </version>
  <version>    1.2.4   26.02.2008  Petr Cepek
               procedure Get_Host_By_IMSI_List updated.
  </version>
  <version>    1.2.3   06.02.2008  Roger Stockley
               procedure Get_Host_By_IMSI_List added.
  </version>
  <version>    1.2.2.1   04.7.2007  Petr Cepek
               procedure Get_Host_By_MSISDN updated.
  </version>
  <version>    1.2.2     6.11.2006  Roger Stockley
               procedure Search_Hosts updated.
  </version>

  <version>    1.2.1     27.10.2006  Petr Cepek
               procedure Test_Row_For_Exist_And_Deleted:
               header added
  </version>
  <version>    1.2.0     20.09.2006  Petr Cepek
               procedure Search_Hosts created
               procedure Get_Hosts_By_AP_IDs deleted
  </version>
  <version>    1.1.6     31.08.2006  Petr Cepek
               procedure Get_Hosts_By_IMSI_Interval updated
  </version>
  <version>    1.1.5     01.06.2006  Petr Cepek
               procedure Get_Network_Operator_By_MSC updated
               procedure Get_Host_By_MSISDN updated
  </version>
  <version>    1.1.4     11.05.2006  Petr Cepek
               procedure Get_Hosts_By_IMSI_Interval updated
  </version>
  <version>    1.1.3     5.4.2006    Petr Cepek
               procedures Get_Hosts_By_MSISDN_Interval, Get_Hosts_By_IMSI_Interval,
               Get_Host_By_ICCID_List, Get_Host_By_MSISDN updated
  </version>
  <version>    1.1.2     21.3.2006   Petr Cepek
               procedure Get_Host_By_ICCID_List updated
  </version>
  <version>    1.1.1     17.2.2006   Petr Cepek
               procedure Get_Host_By_ICCID_List updated
  </version>
  <version>    1.1.0     28.11.2005  Petr Cepek
               procedure Get_Host_By_ICCID_List updated
  </version>
  <version>    1.0.8    11.08.2005   Petr Cepek
               procedure Get_Hosts_By_MSISDN_Interval updated,
               constant c_RESULT_LIST_TIME_ZONE deleted
  </version>
  <version>    1.0.7    09.06.2005   Radomir Lipka
                        create procedures Get_Host_By_MSISDN
  </version>

  <version>    1.0.6    06.06.2005   Petr Cepek
                        procedures Get_Network_Operator_By_MSC,Get_Host_Time_Zone updated
  </version>

  <version> 	 1.0.5    30.5.2005     Jaroslav Holub
               Get_Host_By_ICCID_List - added join to table ACCESS_POINT_HOST - fro proper handling
               connection to SMS centrum, or Voice mail....
  </version>
  <version>    1.0.4    27.5.2005     Jaroslav Holub
                Get_Hosts_By_IMSI_Interval - added test for input parameter p_host_type
                - if not exist in table host_type, or this type was deleted,
                then report error
  </version>
  <version> 	 1.0.3    21.3.2005     Jaroslav Holub
               for procedures GET_HOST, GET_HOST_ALL, GET_HOSTS_BY_MSISDN_INTERVAL,
                 GET_HOSTS_BY_AP_IDS, GET_HOST_PARENT_OPERATOR, GET_HOST_EXTENDED,
                 GET_HOSTS_BY_IMSI_INTERVAL, GET_HOSTS_BY_PORT_TYPE,
                 GET_HOST_BY_ICCID_LIST, GET_HOST_AND_NET_OP -
                 added column to output cursor (TIME_ZONE)
                 this column is handled by c_RESULT_LIST_TIME_ZONE constant -
                      'Y' add column,
                      'N' - without column
               added new procedure GET_HOST_TIME_ZONE
               added procedures Insert_Host2, Update_Host2 - with parameter p_time_zone

  </version>
  <version>    1.1.34   .03.2005	Jaroslav Holub
               added type t_NUMBER_tab

  </version>
  <version>    1.1.33   03.03.2005	Jaroslav Holub
               Get_Hosts_By_Port_Type - optimized select
  </version>
  <version>    1.1.32   21.10.2004      Lucie Sevcikova
							 Added procedure Get_Host_and_Net_Op
  </version>

  <version>    1.1.31   7.9.2004      Jaroslav Holub
							 Get_Network_Operator_By_MSC - when operator not found then
               return RSIG_UTILS.c_NOT_FOUND in error code and in
               network operator ID
  </version>

  <version>    1.1.30	29.8.2004	Jaroslav Holub
               Get_Host_By_ICCID_List added host name into output cursor
  </version>

  <version>    1.1.29	29.8.2004	Jaroslav Holub
               Get_Host_By_ICCID_List created first version
  </version>

  <version>		1.1.28	3.8.2004     Jaroslav Holub
							Delete_Host,Get_Hosts_By_AP_IDs - fixed for time difference between client and server,
							date should be null and it means sysdate
							Get_Hosts_By_IMSI_Interval - fix working with validity date
  </version>

  <version>   1.1.27	15.7.2004	Jaroslav Holub
							Get_Hosts_By_Port_Type - created first version
  </version>

  <version>		1.1.26  18.2.2004		Skorotkevich
            	- added procedure Check_Host_Referenced
              - added call of Check_Host_Referenced into Delete_Host
  </version>

  <version>		1.1.25  11.2.2004		Skorotkevich
              Change function Get_Hosts_By_MSISDN_Interval - fixed bug of incorrect phone numbers (lost left zeros of localnumber),
  </version>

  <version>		1.1.24  17.12.2003		jstodulk
              Change function Get_Hosts_By_MSISDN_Interval - insert parameter handle_tran.
  </version>

  <version>		1.1.23  15.12.2003		jstodulk
              Insert debug constant.
  </version>

  <version>		1.1.22  15.12.2003		jstodulk
              Insert parameter RSIG_UTILS.c_MIN_DATE.
  </version>

  <version>		1.1.21  11.12.2003		jstodulk
              Change procedure Get_Hosts_By_MSISDN_Interval.
  </version>

  <version>		1.1.20  9.12.2003		jstodulk
              Insert procedure Get_Hosts_By_MSISDN_Interval.
  </version>

  <version>		1.1.19  8.12.2003		jstodulk
		          Created new function Get_Hosts_By_AP_IDs.
  </version>

  <version>		1.0.1   15.9.2003    	Jan Stodulka
              created fisrts version
  </version>

  <Description>  Package contains procedure for managing hosts.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	 Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
/****************************************************************************/

TYPE t_v2_60_tab IS TABLE OF VARCHAR2(60) INDEX BY BINARY_INTEGER;
TYPE t_number_tab IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;



PROCEDURE Test_Row_For_Exist_And_Deleted(p_host_id IN HOST.HOST_ID%TYPE);

/****************************************************************************
  <header>
    <name>              procedure Insert_Host
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure inserts a new host.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code       - Error code
                        p_host_code      - Code of host
                        p_host_name      - Name of host
                        p_host_address   - Address of host
                        p_host_location  - Location of host
                        p_host_type_code - Code of host type
                        p_network_operator_id - Network operator ID
                        p_user_id_of_change - User id of change
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Insert_Host(
    handle_tran           IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code            OUT  NUMBER,
    p_host_code           IN   HOST.HOST_CODE%TYPE,
    p_host_name           IN   HOST.HOST_NAME%TYPE,
    p_host_address        IN   HOST.HOST_ADDRESS%TYPE,
    p_host_location       IN   HOST.HOST_LOCATION%TYPE,
    p_host_type_code      IN   HOST.HOST_TYPE_CODE%TYPE,
    p_network_operator_id IN   HOST.NETWORK_OPERATOR_ID%TYPE,
    p_user_id_of_change   IN   NUMBER,
    p_host_id             OUT  HOST.HOST_ID%TYPE
  );

/****************************************************************************
  <header>
    <name>              procedure Update_Host
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure updates values of host  given by host id,
                        if given host is currently not deleted.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_ORA_DELETED
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code       - Error code
                        p_host_id        - updated this row - this column not updated
                        p_host_code      - Code of host
                        p_host_name      - name of host
                        p_host_address   - Address of host
                        p_host_location  - Location of host
                        p_host_type_code - Code of host type
                        p_network_operator_id - Network operator
                        p_user_id_of_change - User id of change
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Update_Host(
    handle_tran           IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code            OUT  NUMBER,
    p_host_id             IN   HOST.HOST_ID%TYPE,
    p_host_code           IN   HOST.HOST_CODE%TYPE,
    p_host_name           IN   HOST.HOST_NAME%TYPE,
    p_host_address        IN   HOST.HOST_ADDRESS%TYPE,
    p_host_location       IN   HOST.HOST_LOCATION%TYPE,
    p_host_type_code      IN   HOST.HOST_TYPE_CODE%TYPE,
    p_network_operator_id IN   HOST.NETWORK_OPERATOR_ID%TYPE,
    p_user_id_of_change   IN   NUMBER
  );

/****************************************************************************
  <header>
    <name>              procedure Check_Host_Referenced(
    </name>

    <author>            Sergei Korotkevich
    </author>

    <version>           1.0.1   18.02.2004     Sergei Korotkevich
                                created first version
    </version>

    <Description>       Procedure checks if some table has reference to Host for id.
    </Description>

    <Prerequisites>
                      Exists function:
                      Exists variable:
                        RSIG_UTILS.c_ORA_REFERENCED

    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        p_host_id IN HOST.HOST_ID%TYPE

    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Check_Host_Referenced(
    p_host_id IN HOST.HOST_ID%TYPE
  );

/****************************************************************************
  <header>
    <name>              procedure Delete_Host
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

	<version>			1.0.3	3.8.2004     Jaroslav Holub
								Delete_Host - fixed for time difference between client and server,
								date should be null and it means sysdate
	</version>
    <version>           1.0.2   18.02.2004    Sergei Korotkevich
                                added call of Check_Host_Referenced just before marking rows as deleted
    </version>
    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure sets column DELETED to value of parameter
                        deleted in host given by host id, if given host is
                        currently not deleted.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_ORA_DELETED
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code - Error code
                        p_host_id  - Host ID
                        p_deleted	 - value for set attribute (DELETED)
                        p_user_id_of_change - User id of change
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Delete_Host(
    handle_tran         IN    CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code          OUT   NUMBER,
    p_host_id           IN    HOST.HOST_ID%TYPE,
    p_deleted           IN    HOST.DELETED%TYPE,
    p_user_id_of_change IN    NUMBER
  );

/****************************************************************************
  <header>
    <name>              procedure Get_Host
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version> 			1.0.4    21.05.2010     Sergey Eramfkov
                             added column to output cursor (DST_RULE_ID)

    <version> 			1.0.3    21.3.2005     Jaroslav Holub
                             added column to output cursor (TIME_ZONE)
                             this column is handled by
                             c_RESULT_LIST_TIME_ZONE constant - 'Y' add column,
                                                                'N' - without column

    </version>
    <version> 			1.0.2    4.12.2003     Jan Stodulka
                                mandatory parameter p_network_operator_id
                                returned columns DELETED
    </version>
    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>      Procedure provides cursor containing data of hosts
                       given type or network operator.
                      nput parameters are optional, the contents of output ref cursor depends on input parameter:
                      1.	If input parameter p_host_type_code is not null then ref cursor
                      contains records of table host with given host_type_code.
                      2.	If input parameter p_network_operator_id is not null then ref
                      cursor contains records of table host with given network_operator_id.
                      Ref cursor contains columns: HOST_ID, HOST_CODE, HOST_NAME,
                      HOST_ADDRESS, HOST_LOCATION, DATE_OF_CHANGE, USER_ID_OF_CHANGE, DELETED

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        rror_code             - Error code
                        p_host_type_code      - Code of host type
                        p_network_operator_id - Network operator id
                        p_cur_host            - cursor to retrieve all host (ref cursor columns by equally as return value function Get_Host)
                        (HOST_ID, HOST_CODE, HOST_NAME, HOST_ADDRESS, HOST_LOCATION, DATE_OF_CHANGE, USER_ID_OF_CHANGE, NETWORK_OPERATOR_ID, HOST_TYPE_CODE, DELETED)
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Get_Host(
    error_code            OUT  NUMBER,
    p_host_type_code      IN   HOST.HOST_TYPE_CODE%TYPE,
    p_network_operator_id IN   HOST.NETWORK_OPERATOR_ID%TYPE,
    p_cur_host            OUT  RSIG_UTILS.REF_CURSOR
  );

/****************************************************************************
  <header>
    <name>              procedure Get_host_by_date
    </name>

    <author>            Josef Hartman
    </author>

    <version>           1.0.0   25.04.2008     Josef Hartman
                                created first version
    </version>

    <Description>     Procedure returns hosts by given parameters.
    </Description>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code              - Error code
                        p_host_type_code        - Code of host type
                        p_network_operator_code - Network operator code
                        p_validity_date         - Date when host is valid
                        p_cur_host              - cursor to retrieve all hosts
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Get_host_by_date
  (
    error_code               OUT NUMBER,
    p_host_type_code         IN HOST.HOST_TYPE_CODE%TYPE,
    p_network_operator_code  IN NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
    p_validity_date          IN DATE,
    p_cur_host               OUT RSIG_UTILS.REF_CURSOR
  );

/****************************************************************************
  <header>
    <name>              procedure Get_Host_All
    </name>

    <author>            JPavel Stengl
    </author>

    <version> 			1.0.2    21.3.2005     Jaroslav Holub
                             added column to output cursor (TIME_ZONE)
                             this column is handled by
                             c_RESULT_LIST_TIME_ZONE constant - 'Y' add column,
                                                                'N' - without column

    </version>
    <version>  					1.0.1   5.2.2004     Pavel Stengl
                                created first version
    </version>

    <Description>      Procedure provides cursor containing data of all hosts (deleted rows too)
                       given type or network operator.
                      nput parameters are optional, the contents of output ref cursor depends on input parameter:
                      1.	If input parameter p_host_type_code is not null then ref cursor
                      contains records of table host with given host_type_code.
                      2.	If input parameter p_network_operator_id is not null then ref
                      cursor contains records of table host with given network_operator_id.
                      Ref cursor contains columns: HOST_ID, HOST_CODE, HOST_NAME,
                      HOST_ADDRESS, HOST_LOCATION, DATE_OF_CHANGE, USER_ID_OF_CHANGE, DELETED.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        rror_code             - Error code
                        p_host_type_code      - Code of host type
                        p_network_operator_id - Network operator id
                        p_cur_host            - cursor to retrieve all host (ref cursor columns by equally as return value function Get_Host)
                        (HOST_ID, HOST_CODE, HOST_NAME, HOST_ADDRESS, HOST_LOCATION, DATE_OF_CHANGE, USER_ID_OF_CHANGE, NETWORK_OPERATOR_ID, HOST_TYPE_CODE, DELETED)
    </Parameters>

  </header>
/****************************************************************************/

	PROCEDURE Get_Host_All(
    error_code            OUT  NUMBER,
    p_host_type_code      IN   HOST.HOST_TYPE_CODE%TYPE,
    p_network_operator_id IN   HOST.NETWORK_OPERATOR_ID%TYPE,
    p_cur_host            OUT  RSIG_UTILS.REF_CURSOR
  );


/****************************************************************************
  <header>
    <name>              procedure Get_Host_Statistic
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       procedure provides cursor variable containing count of access points group
                        by host for given network operator
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code - OUT - NUMBER
                        p_network_operator_id - Network operator id
                        p_cur_host_statistic  - cursor to retrieve all host (ref cursor columns by equally as return value function Get_Host)
                                                (HOST_ID, ACCES_POINT_COUNT)
                                                not return deleted rows
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Get_Host_Statistic(
    error_code              OUT  NUMBER,
    p_network_operator_id   IN   HOST.NETWORK_OPERATOR_ID%TYPE,
    p_cur_host_statistic    OUT  RSIG_UTILS.REF_CURSOR
  );


/****************************************************************************
  <header>
    <name>              procedure Get_Network_Operator_By_MSC
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.0.5   01.06.2006    Petr Cepek
                        fixed bug with duplicate host, because of deleted host
    </version>
    <version>           1.0.4   06.06.2005    Petr Cepek
                                error handling updated
    </version>
    <version>           1.0.3   7.9.2004      Jaroslav Holub
								when operator not found then return RSIG_UTILS.c_NOT_FOUND
								in error code and in network operator ID
    </version>
    <version>           1.0.2   3.2.2004      Lucie Sevcikova
                                Deleted check of HOST type MSC. Checked is
                                only HOST code.
    </version>
    <version>           1.0.1   4.12.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       procedure returns network operator for given MSC code
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code - OUT - NUMBER
                        p_host_code      - Host code
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Get_Network_Operator_By_MSC(
    error_code              OUT  NUMBER,
    p_host_code             IN   HOST.HOST_CODE%TYPE,
    p_network_operator_id   OUT  NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
  );

/****************************************************************************
  <header>
    <name>              procedure Get_Host_Parent_Operator
    </name>

    <author>            Pavel Stengl
    </author>

    <version> 			1.0.2    21.3.2005     Jaroslav Holub
                             added column to output cursor (TIME_ZONE)
                             this column is handled by
                             c_RESULT_LIST_TIME_ZONE constant - 'Y' add column,
                                                                'N' - without column

    </version>
    <version>           1.0.1    5.2.2004			 Pavel Stengl
                                created first version
    </version>

    <Description>      Procedure provides cursor containing data of hosts
                       given type or network operator. Rerurned ref cursor containing data
											 of all hosts given network operator and its parents.
                      Input parameters are optional, the contents of output ref cursor depends on input parameter:
                      1.	If input parameter p_host_type_code is not null then ref cursor
                      contains records of table host with given host_type_code.
                      2.	If input parameter p_network_operator_id is not null then ref
                      cursor contains records of table host with given network_operator_id.
                      Ref cursor contains columns: HOST_ID, HOST_CODE, HOST_NAME,
                      HOST_ADDRESS, HOST_LOCATION, DATE_OF_CHANGE, USER_ID_OF_CHANGE.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        rror_code             - Error code
                        p_host_type_code      - Code of host type
                        p_network_operator_id - Network operator id
                        p_cur_host            - cursor to retrieve all host (ref cursor columns by equally as return value function Get_Host)
                        (HOST_ID, HOST_CODE, HOST_NAME, HOST_ADDRESS, HOST_LOCATION, DATE_OF_CHANGE, USER_ID_OF_CHANGE, NETWORK_OPERATOR_ID, HOST_TYPE_CODE, DELETED)
    </Parameters>

  </header>
/****************************************************************************/


PROCEDURE Get_Host_Parent_Operator(
    error_code            OUT  NUMBER,
    p_host_type_code      IN   HOST.HOST_TYPE_CODE%TYPE,
    p_network_operator_id IN   HOST.NETWORK_OPERATOR_ID%TYPE,
    p_show_deleted        IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_N,
    p_cur_host            OUT  RSIG_UTILS.REF_CURSOR
  );

/****************************************************************************
  <header>
    <name>              procedure Get_Host_Extended
    </name>

    <author>            Pavel Stengl
    </author>

    <version> 			1.0.2    21.3.2005     Jaroslav Holub
                             added column to output cursor (TIME_ZONE)
                             this column is handled by
                             c_RESULT_LIST_TIME_ZONE constant - 'Y' add column,
                                                                'N' - without column

    </version>
    <version>           1.0.1    9.2.2004			 Pavel Stengl
                                created first version
    </version>

    <Description>      Procedure provides cursor containing data of hosts
                       given type or network operator. Rerurned ref cursor containing data
											 of all hosts given network operator and its parents.
                      Input parameters are optional, the contents of output ref cursor depends on input parameter:
                      1.	If input parameter p_host_type_code is not null then ref cursor
                      contains records of table host with given host_type_code.
                      2.  If input paremater p_include_child is "Y" then procedure returns HOSTS of given network operator and all of its children.
											3.  If input paremater p_include_parent is "Y" then procedure returns HOSTS of given network operator and its entire parent.
											Ref cursor contains columns: HOST_CODE, HOST_NAME, HOST_ADDRESS, HOST_LOCATION,
													NETWORK_OPERATOR_ID, NETWORK_OPERATOR_ID, NETWORK_OPERATOR_NAME.


    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        rror_code             - Error code
                        p_host_type_code      - Code of host type
                        p_network_operator_id - Network operator id
											  p_validity_date
												p_include_child				-  network operator and all of its children
												p_include_parent			-  network operator and its entire parent
                        p_cur_host            - cursor to retrieve all host (ref cursor columns by equally as return value function Get_Host)
                        (HOST_CODE, HOST_NAME, HOST_ADDRESS, HOST_LOCATION, NETWORK_OPERATOR_ID, NETWORK_OPERATOR_ID, NETWORK_OPERATOR_NAME)
    </Parameters>

  </header>
/****************************************************************************/

PROCEDURE Get_Host_Extended(
    error_code            OUT  NUMBER,
    p_host_type_code      IN   HOST.HOST_TYPE_CODE%TYPE,
    p_network_operator_id IN   HOST.NETWORK_OPERATOR_ID%TYPE,
		p_validity_date       IN   DATE,
		p_include_child				IN 	 CHAR,   --  network operator and all of its children
		p_include_parent			IN   CHAR,   --  network operator and its entire parent
    p_cur_host            OUT  RSIG_UTILS.REF_CURSOR
 );

/****************************************************************************
  <header>
    <name>              procedure Get_Host_By_ICCID_List
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.8    5.4.2006      Petr Cepek
                        new table sim_card_host considered in procedur
    </version>
    <version>           1.0.7    21.3.2006     Petr Cepek
                        bug with duplicate records in output cursor fixed
    </version>
    <version>           1.0.6    17.02.2006    Petr Cepek
                        column network_operator_id added to result cursor
    </version>
    <version>           1.0.5    28.11.2005    Petr Cepek
                        procedure fixed, splited to two cases - one for HLR and
                        one for other types of host
    </version>
    <version> 			    1.0.4    30.5.2005     Jaroslav Holub
                             added join to table ACCESS_POINT_HOST - fro proper handling
                             connection to SMS centrum, or Voice mail....
    </version>
    <version> 			    1.0.3    21.3.2005     Jaroslav Holub
                             added column to output cursor (TIME_ZONE)
                             this column is handled by
                             c_RESULT_LIST_TIME_ZONE constant - 'Y' add column,
                                                                'N' - without column

    </version>
    <version>           1.0.1   29.8.2004	Jaroslav Holub
                                added host name into output cursor
    </version>
    <version>           1.0.0   28.8.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure returns hosts for SN of sim card

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
                        col_iccid 		associative array of varchar2(60) - ICCID numbers
					    p_host_type 		host type -if null then should be any type
						p_validity_date 	date of validity (sim_series deleted check) if NULL then sysdtae
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/

----------------------------------------------------------------------------
--  Get_Host_By_ICCID_List
----------------------------------------------------------------------------

PROCEDURE Get_Host_By_ICCID_List (


   	col_iccid 			IN 	t_v2_60_tab,
    p_host_type 		IN	HOST_TYPE.HOST_TYPE_CODE%TYPE,
	p_validity_date 	IN	DATE,
	p_raise_error		IN 	CHAR,
	error_code 			OUT	NUMBER,
	error_message  		OUT VARCHAR2,
    result_list 		OUT	sys_refcursor

);

/****************************************************************************
  <header>
    <name>              procedure Get_Host_and_Net_Op
    </name>

    <author>            Lucie Sevcikova
    </author>

    <version> 		1.0.4    26.07.2010     Sergey Ermakov
                        added column to output cursor (DST_RULEE)
    </version>
    <version> 		1.0.3    21.3.2005     Jaroslav Holub
                        added column to output cursor (TIME_ZONE)
                        this column is handled by
                        c_RESULT_LIST_TIME_ZONE constant - 'Y' add column,
                                                           'N' - without column

    </version>
    <version>           1.0.0   21.10.2004     Lucie Sevcikova
                                created first version
    </version>

    <Description>       Procedure returns host attributes for given HOST
                        type and network operator. If host type is not given,
                        then hosts of all types will be returned.

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
/****************************************************************************/

PROCEDURE Get_Host_and_Net_Op(
  error_code            OUT  NUMBER,
  p_host_type_code      IN   HOST.HOST_TYPE_CODE%TYPE,
  p_cur_host            OUT  RSIG_UTILS.REF_CURSOR
);

/****************************************************************************
  <header>
    <name>              procedure Get_HOST_TIME_ZONE
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>
                        1.0.1    06.06.2005  Petr Cepek
                                 error handling updated
    </version>
    <version>           1.0.0   18.3.2005	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure returns for list of host their timezones

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
                        p_host_col,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Get_Host_Time_Zone(
                             p_host_col    IN t_number_tab,
                             p_raise_error IN CHAR,
                             ERROR_CODE    OUT NUMBER,
                             error_message OUT VARCHAR2,
                             result_list   OUT sys_refcursor
                             );


/****************************************************************************
  <header>
    <name>              procedure Get_Type_Host_By_Host_Id
    </name>

    <author>            Josef Hartman
    </author>

    <version>           1.0.0   08.09.2008	Josef Hartman
                                created first version
    </version>

    <Description>       procedure returns list of host_types by given ids

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

  </header>
****************************************************************************/
PROCEDURE Get_Type_Host_By_Host_Id
(
  p_col_host_id    IN t_number_tab,
  p_raise_error    IN CHAR,
  p_error_code     OUT NUMBER,
  p_error_message  OUT VARCHAR2,
  result_list      OUT SYS_REFCURSOR
);

/****************************************************************************
  <header>
    <name>              procedure Get_Type_Host_By_PA
    </name>

    <author>            Josef Hartman
    </author>

    <version>           1.0.2   25.10.2008	Josef Hartman
                                Method optimized
    </version>
    <version>           1.0.1   18.09.2008	Josef Hartman
                                Changed input parameters
    </version>
    <version>           1.0.0   08.09.2008	Josef Hartman
                                created first version
    </version>

    <Description>       procedure returns list of host_types by given personal_account

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

  </header>
****************************************************************************/
PROCEDURE Get_Type_Host_By_PA
(
  p_col_pa         IN t_number_tab,
  p_validity_date  IN DATE,
  p_raise_error    IN CHAR,
  error_code       OUT NUMBER,
  error_message    OUT VARCHAR2,
  result_list      OUT SYS_REFCURSOR
);

/****************************************************************************
  <header>
    <name>              procedure Insert_Host2
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.0.1   21.3.2005     Jaroslav Holub
                                created first version
    </version>

    <Description>       Procedure inserts a new host (with time_zone).
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code       - Error code
                        p_host_code      - Code of host
                        p_host_name      - Name of host
                        p_host_address   - Address of host
                        p_host_location  - Location of host
                        p_host_type_code - Code of host type
                        p_network_operator_id - Network operator ID
                        p_user_id_of_change - User id of change
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Insert_Host2(
    handle_tran           IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code            OUT  NUMBER,
    p_host_code           IN   HOST.HOST_CODE%TYPE,
    p_host_name           IN   HOST.HOST_NAME%TYPE,
    p_host_address        IN   HOST.HOST_ADDRESS%TYPE,
    p_host_location       IN   HOST.HOST_LOCATION%TYPE,
    p_host_type_code      IN   HOST.HOST_TYPE_CODE%TYPE,
    p_network_operator_id IN   HOST.NETWORK_OPERATOR_ID%TYPE,
    p_user_id_of_change   IN   NUMBER,
    p_time_zone           IN   NUMBER,
    p_dst_rule_id         IN   NUMBER,
    p_host_id             OUT  HOST.HOST_ID%TYPE
  );

/****************************************************************************
  <header>
    <name>              procedure Update_Host2
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.0.1   21.3.2005     Jaroslav Holub
                                created first version
    </version>

    <Description>       Procedure updates values of host  given by host id,
                        if given host is currently not deleted.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_ORA_DELETED
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code       - Error code
                        p_host_id        - updated this row - this column not updated
                        p_host_code      - Code of host
                        p_host_name      - name of host
                        p_host_address   - Address of host
                        p_host_location  - Location of host
                        p_host_type_code - Code of host type
                        p_network_operator_id - Network operator
                        p_user_id_of_change - User id of change
                        p_time_zone         - time zone (shift in hours
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Update_Host2(
    handle_tran           IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code            OUT  NUMBER,
    p_host_id             IN   HOST.HOST_ID%TYPE,
    p_host_code           IN   HOST.HOST_CODE%TYPE,
    p_host_name           IN   HOST.HOST_NAME%TYPE,
    p_host_address        IN   HOST.HOST_ADDRESS%TYPE,
    p_host_location       IN   HOST.HOST_LOCATION%TYPE,
    p_host_type_code      IN   HOST.HOST_TYPE_CODE%TYPE,
    p_network_operator_id IN   HOST.NETWORK_OPERATOR_ID%TYPE,
    p_user_id_of_change   IN   NUMBER,
    p_time_zone           IN   NUMBER,
    p_dst_rule_id         IN   NUMBER
  );

  /****************************************************************************
    <header>
      <name>              procedure Get_Hosts_by_host_type
      </name>

      <author>            Jaroslav Holub
      </author>

      <version>           1.0.0   24.3.2005	Jaroslav Holub
                                  created first version
      </version>

      <Description>       procedure returns Hosts by host type, or all if null

      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       FORIS Resource inventory
      </Application>

      <Parameters>
                          ,
                          handle_tran       IN  CHAR,
                          p_raise_error     IN  CHAR,
                          error_code        OUT NUMBER,
                          error_message     OUT VARCHAR2
      </Parameters>

    </header>
  ****************************************************************************/
PROCEDURE Get_Hosts_by_host_type
(
  p_host_type_code IN HOST.HOST_TYPE_CODE%TYPE,
  p_raise_error    IN CHAR,
  ERROR_CODE       OUT NUMBER,
  error_message    OUT VARCHAR2,
  result_list      OUT sys_refcursor
);

/****************************************************************************
  <header>
    <name>              procedure Get_Host_By_MSISDN
    </name>

    <author>            Radomir Lipka
    </author>

    <version>           1.0.2.1   04.7.2007    Petr Cepek
                        column host_id was added into output cursor
    </version>
    <version>           1.0.2   12.06.2006    Petr Cepek
                        error handling changed, parameter p_error_code added
    </version>
    <version>           1.0.1   5.4.2006  Petr Cepek
                        new table sim_card_host considered in procedur
    </version
    <version>           1.0.0   9.6.2005	Radomir Lipka
                                created first version
    </version>

    <Description>
                    procedure Returns list of phone numbers, host_code, host_name, host_address
                    from HOST  where are active in given date range ( if host_type not HLR )
                    and host_type.

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
                    p_phone_number     -- selected phone number
                    p_host_type        -- host type code
	                  p_validity_date    -- Validity date and time for range
	                  p_result_list      -- output cursor (INTERNATIONAL_FORMAT, IMSI, LINK_TYPE_CODE)
    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Get_Host_By_MSISDN
(
  p_phone_number   IN  PHONE_NUMBER.INTERNATIONAL_FORMAT%TYPE,
  p_host_type      IN  HOST.HOST_TYPE_CODE%TYPE,
  p_validity_date  IN  DATE,
  p_raise_error    IN  CHAR,
  p_error_code     OUT NUMBER,
  p_error_message  OUT VARCHAR2,
  p_cur_host       OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure Search_Hosts
  </name>

  <author>          Petr Cepek
  </author>


  <version>         1.0.1    6.11.2006      Roger Stockley
                    Addition of new parameter (p_show_deleted) and altered
                    query to return result set with or without deleted items.
  </version>

  <version>
                    1.0.0  19.9.2006  -  created
  </version>

  <Description>     Procedure returns hosts matching entered conditions
                    in parameters p_network_operator_id, p_host_code,
                    p_host_name. When parameter is NULL then condition
                    is not applied.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Search_Hosts(
  p_network_operator_id    IN  network_operator.network_operator_id%TYPE,
  p_host_code              IN  host.host_code%TYPE,
  p_host_name              IN  host.host_name%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_show_deleted           IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_N,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);

/****************************************************************************
  <header>
    <name>              procedure Get_Hosts
    </name>

    <author>            Pavel Vasiliev
    </author>

    <version>           1.0.1    8.09.2010			 Pavel Vasiliev
                                created first version
    </version>

    <Description>      Procedure provides cursor containing data of hosts
                       given type or network operator.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>
                        error_code             - Error code
                        p_host_type_code      - Code of host type
                        p_network_operator_id - Network operator id
                        p_show_deleted
                        p_cur_host            - cursor to retrieve all host

    </Parameters>

  </header>
/****************************************************************************/

PROCEDURE Get_Hosts
(
  error_code            OUT NUMBER,
  p_host_type_code      IN HOST.HOST_TYPE_CODE%TYPE,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_show_deleted        IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_N,
  p_cur_host            OUT RSIG_UTILS.REF_CURSOR
);

/****************************************************************************
  <header>
    <name>              procedure Get_Hosts_By_Host_Type_Codes
    </name>

    <author>            Pavel Vasiliev
    </author>
    <version>           1.0.0   18.09.2010	Pavel Vasiliev
                        created first version
    </version>

    <Description>       procedure returns host for given host type codes

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
						            p_host_type_codes   IN 	t_v2_60_tab
                        p_raise_error       IN  CHAR,
                        p_error_code        OUT NUMBER,
                        p_error_message     OUT VARCHAR2,
                        p_result_list       OUT sys_refcursor
    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Get_Hosts_By_Host_Type_Codes
(
  p_host_type_codes  IN t_v2_60_tab,
  p_raise_error      IN CHAR,
  p_error_code       OUT NUMBER,
  p_error_message    OUT VARCHAR2,
  p_result_list      OUT sys_refcursor
);

END;
/
