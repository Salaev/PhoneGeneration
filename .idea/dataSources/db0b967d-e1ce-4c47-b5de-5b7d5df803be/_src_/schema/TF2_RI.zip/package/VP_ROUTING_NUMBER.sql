CREATE package vp_routing_number is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'ROUTING_NUMBER';

----------------------------------!---------------------------------------------
  function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return routing_number%rowtype;
  function get1(p_id integer, p_date date) return routing_number%rowtype;
  function xlock_get1(p_id integer, p_date date) return routing_number%rowtype;

----------------------------------!---------------------------------------------
  procedure xvalid_i(p_rec routing_number%rowtype);

----------------------------------!---------------------------------------------
  function find_i_id(p_rec routing_number%rowtype) return boolean;
  function find_i_code(p_rec routing_number%rowtype) return boolean;
  function find_i_name(p_rec routing_number%rowtype) return boolean;

  function find_i(p_rec routing_number%rowtype) return boolean;
  procedure xunique_i(p_rec routing_number%rowtype);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec routing_number%rowtype);
  procedure close_i(p_rec routing_number%rowtype);

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy routing_number%rowtype);
  procedure version_change(p_rec in out nocopy routing_number%rowtype);

  procedure version_close
  (
    p_id integer,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------

end;
/
