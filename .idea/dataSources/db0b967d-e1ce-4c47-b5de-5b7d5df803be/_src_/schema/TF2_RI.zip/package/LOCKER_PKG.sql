CREATE package locker_pkg is

----------------------------------!---------------------------------------------
  type ct_locker_data_range is table of TT_LOCKER_DATA_RANGE%rowtype;
  type ct_locker_data_eq is table of TT_LOCKER_DATA_EQ%rowtype;

  type t_locker is record
  (
    locker_group_id number,
    locker_id number
  );

  type t_locker_parameters is record
  (
    locker t_locker,
    ignore_type number,
    split_batch_count_limit number
  );

----------------------------------!---------------------------------------------
  c_mutex_locker_data_lr         constant number := 1;

  c_def_data_type                constant number := 0;

----------------------------------!---------------------------------------------
  c_opt_mutex_timeout_sec        constant nvarchar2(50) := 'MUTEX_TIMEOUT';
  c_opt_ignore_model_type        constant nvarchar2(50) := 'IGNORE_MODEL_TYPE';
  c_opt_max_size_split_range     constant nvarchar2(50) := 'MAX_SIZE_SPLITTABLE_RANGE';
  c_opt_locker_expire_period_sec constant nvarchar2(50) := 'LOCKER_EXPIRE_PERIOD';

----------------------------------!---------------------------------------------
  c_def_mutex_timeout_sec        constant number := 60;
  c_def_ignore_model_type        constant boolean := true;
  c_def_max_size_split_range     constant number := 10000;
  c_def_locker_expire_period_sec constant number := 36000;

----------------------------------!---------------------------------------------
  latch_exception exception;
  --!_!pragma exception_init (latch_exception, util_pkg.c_ora_object_latched);
  pragma exception_init (latch_exception, -20804);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function get_count_ct_locker_data_range(p_coll ct_locker_data_range) return number;
  function get_count_ct_locker_data_eq(p_coll ct_locker_data_eq) return number;

  procedure add_ct_locker_data_range_val(p_coll in out nocopy ct_locker_data_range, p_val tt_locker_data_range%rowtype);
  procedure add_ct_locker_data_eq_val(p_coll in out nocopy ct_locker_data_eq, p_val tt_locker_data_eq%rowtype);

  procedure add_ct_locker_data_range(p_coll in out nocopy ct_locker_data_range, p_coll_add ct_locker_data_range);
  procedure add_ct_locker_data_eq(p_coll in out nocopy ct_locker_data_eq, p_coll_add ct_locker_data_eq);

  function make_tt_locker_data_range
  (
    p_type_id number,
    p_sn_from nvarchar2,
    p_sn_to nvarchar2
  )
  return tt_locker_data_range%rowtype;

  function make_tt_locker_data_eq
  (
    p_type_id number,
    p_stock_id number
  )
  return tt_locker_data_eq%rowtype;

  function make_ct_locker_data_range
  (
    p_type_id number,
    p_sn_from nvarchar2,
    p_sn_to nvarchar2
  )
  return ct_locker_data_range;

  function make_ct_locker_data_eq
  (
    p_type_id number,
    p_stock_id number
  )
  return ct_locker_data_eq;

----------------------------------!---------------------------------------------
  function GS_locker_expire_period_sec return number;
  function GS_mutex_timeout_sec return number;
  function GS_ignore_model_type return boolean;
  function GS_max_size_split_range return number;

----------------------------------!---------------------------------------------
  function get_long_range_data return ct_range;
  procedure set_long_range_data(p_range ct_range);

----------------------------------!---------------------------------------------
  function Get_Locker(p_locker_id number) return locker%rowtype;
  function Create_Locker(p_locker_group_id number := null) return t_locker;
  procedure Set_Locker_Finished(p_locker_param t_locker_parameters);
  procedure Add_Mutex(p_mutex_id number);
  procedure Switch_On_Mutex(p_mutex_id number);

----------------------------------!---------------------------------------------
  procedure Handle_Wrong_Equipment(p_locker_error ct_locker_data_range, p_error_code number, p_error_message varchar2, p_label varchar2 := '');
  function Handle_Wrong_Equipment_Str(p_seria_start varchar2, p_seria_end varchar2, p_equipment_model_id varchar2, p_label varchar2) return varchar2;

----------------------------------!---------------------------------------------
  --!_!xl_latch_ranges
  procedure Insert_Locker_Data(p_locker_data ct_locker_data_range);
  procedure Check_Locker_Data(p_allow_non_digit_sn boolean := false);
  procedure Clear_Temporary_Tables;
  procedure Fill_Temporary_Tables(p_locker_param t_locker_parameters, p_allow_input_overlap boolean);
  procedure Make_Uniq_TT_LONG_RANGE_DATA;
  procedure Check_TT_LONG_RANGE_DATA;

  procedure XL_Check_Locker_Data_SR;
  procedure XL_Check_Locker_Data_LR(p_locker_param t_locker_parameters);
  procedure XL_Lock_Single_Short_Rg_Data(p_locker_param t_locker_parameters, p_allow_input_overlap boolean);
  procedure XL_Lock_Big_Range_Data(p_locker_param t_locker_parameters);

----------------------------------!---------------------------------------------
  --!_!xl_latch_types_on_stocks
  procedure Insert_Locker_Data_Eq(p_locker_data_eq ct_locker_data_eq);

  procedure XL_Check_Locker_Eq_Data;
  procedure XL_Lock_Equipment_Data(p_locker_param t_locker_parameters);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_!interface begin
----------------------------------!---------------------------------------------
  procedure Release_Locker_Group(p_locker_group_id number);
  procedure Release_Locker(p_locker_id number);
  procedure Release_Expired_Lockers;

----------------------------------!---------------------------------------------
  function Check_Locker(p_locker_id number) return number;
  function Check_Locker_Group(p_locker_group_id number) return number;

----------------------------------!---------------------------------------------
  --!_!serial equipment
  function xl_latch_ranges
  (
    p_locker_data ct_locker_data_range,
    p_locker_group_id number,
    p_allow_non_digit_sn boolean,
    p_allow_input_overlap boolean
  ) return t_locker;

  --!_!serial equipment
  function xl_latch_ranges2
  (
    p_locker_data ct_locker_data_range
  ) return t_locker;

  --!_!serial equipment
  function xl_latch_range
  (
    p_type_id number,
    p_sn_from nvarchar2,
    p_sn_to nvarchar2,
    p_locker_group_id number,
    p_allow_non_digit_sn boolean,
    p_allow_input_overlap boolean
  ) return t_locker;

  --!_!serial equipment
  function xl_latch_range2
  (
    p_type_id number,
    p_sn_from nvarchar2,
    p_sn_to nvarchar2
  ) return t_locker;

  --!_!non-serial equipment
  function xl_latch_types_on_stocks
  (
    p_locker_data_eq ct_locker_data_eq,
    p_locker_group_id number
  ) return t_locker;

  --!_!non-serial equipment
  function xl_latch_types_on_stocks2
  (
    p_locker_data_eq ct_locker_data_eq
  ) return t_locker;

  --!_!non-serial equipment
  function xl_latch_type_on_stock
  (
    p_type_id number,
    p_stock_id number,
    p_locker_group_id number
  ) return t_locker;

  --!_!non-serial equipment
  function xl_latch_type_on_stock2
  (
    p_type_id number,
    p_stock_id number
  ) return t_locker;

----------------------------------!---------------------------------------------
  function get_locker_eq(p_type_id number, p_stock_id number) return t_locker;

  function get_locker_data_sr4group(p_locker_group_id number) return ct_locker_data_range;

----------------------------------!---------------------------------------------
--!_!interface end
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
