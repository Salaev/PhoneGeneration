CREATE package util_pkg is

----------------------------------!---------------------------------------------
  c_date_format_short            constant varchar2(30) := 'dd.mm.yyyy';
  c_date_format_full             constant varchar2(30) := 'dd.mm.yyyy hh24:mi:ss';
  c_date_format_full_compact     constant varchar2(30) := 'yyyymmddhh24miss';
  c_minus_infinity               constant date := to_date('01.01.1000', c_date_format_short);
  c_plus_infinity                constant date := to_date('01.01.4000', c_date_format_short);
  c_open_date_to                 constant date := c_plus_infinity;

  c_hour                         constant number := 1/24;
  c_minute                       constant number := c_hour/60;
  c_second                       constant number := c_minute/60;
  c_dt_dif                       constant number := c_second;

  c_false                        constant number := 0;
  c_true                         constant number := 1;

  c_false_str                    constant varchar2(10) := 'false';
  c_true_str                     constant varchar2(10) := 'true';

  c_max_error_message_length     constant number := 4000;
  c_max_error_message_length2    constant number := 2048;

  c_number_format1               constant varchar2(100) := 'tm';
  c_number_format2               constant varchar2(100) := '9999999999999999999999999999999999999999D9999999999999999999999';
  c_number_nlsparam              constant varchar2(100) := q'{nls_numeric_characters = '.,'}';

  c_varchar_s_length             constant number := 50;
  c_nvarchar_s_length            constant number := 50;
  c_varchar_length               constant number := 4000;
  c_nvarchar_length              constant number := 2000;

  c_index_not_found              constant number := 0;
  c_index_one                    constant number := 1;

  c_def_trimed_chars             constant varchar2(100) := ' ' || chr(9) || chr(10) || chr(13);
  c_def_trimed_nchars            constant nvarchar2(100) := to_nchar(c_def_trimed_chars);

  c_no_value_not_null_number     constant number := c_false;
  c_no_value_not_null_date       constant date := c_minus_infinity;
  c_no_value_not_null_varchar_s  constant varchar2(50) := 'qwerty';
  c_no_value_not_null_varchar    constant varchar2(4000) := 'qwerty';
  c_no_value_not_null_nvarchar_s constant nvarchar2(50) := 'qwerty';
  c_no_value_not_null_nvarchar   constant nvarchar2(2000) := 'qwerty';

----------------------------------!---------------------------------------------
  c_ora_ok                       constant number(5) := 0;

  c_ora_x_user_min               constant number(5) := -20999;
  c_ora_x_user_max               constant number(5) := -20000;
  c_ora_x_common                 constant number(5) := c_ora_x_user_max;

  c_ora_missing_parameter        constant number(5) := -20123;
  c_ora_invalid_parameter        constant number(5) := -20132;

  c_ora_user_not_found           constant number(5) := -20602;
  c_ora_table_not_found          constant number(5) := -20603;
  c_ora_unsupport_table_scheme   constant number(5) := -20604;

  c_ora_object_not_found         constant number(5) := -20700;
  c_ora_object_not_unique        constant number(5) := -20701;
  c_ora_parent_object_not_found  constant number(5) := -20702;
  c_ora_option_nspec             constant number(5) := -20703;
  c_ora_option_wrong             constant number(5) := -20704;
  c_ora_option_nspec_wrong       constant number(5) := -20705;
  c_ora_object_empty             constant number(5) := -20706;
  c_ora_object_wrong             constant number(5) := -20707;
  c_ora_not_allowed              constant number(5) := -20708;
  c_ora_object_locked            constant number(5) := -20709;
  c_ora_object_changed           constant number(5) := -20710;
  c_ora_not_executed             constant number(5) := -20711;
  c_ora_rolled_back              constant number(5) := -20712;
  c_ora_object_not_empty         constant number(5) := -20713;

  c_ora_interval_intersection    constant number(5) := -20800;
  c_ora_expired                  constant number(5) := -20801;
  c_ora_execution_error          constant number(5) := -20802;
  c_ora_exceeded                 constant number(5) := -20803;
  c_ora_object_latched           constant number(5) := -20804;
  c_ora_no_action_required       constant number(5) := -20805;

----------------------------------!---------------------------------------------
  c_msg_delim_dot                constant varchar2(10) := '.';
  c_msg_delim_comma              constant varchar2(10) := ',';
  c_msg_delim_colon              constant varchar2(10) := ':';
  c_msg_delim_semicolon          constant varchar2(10) := ';';
  c_msg_delim01                  constant varchar2(10) := c_msg_delim_colon;
  c_msg_delim02                  constant varchar2(10) := c_msg_delim_semicolon;

  c_msg_ok                       constant varchar2(200) := 'Successfully completed';

  c_msg_x_common                 constant varchar2(200) := 'Common error';

  c_msg_missing_parameter        constant varchar2(200) := 'Missing parameter';
  c_msg_invalid_parameter        constant varchar2(200) := 'Invalid parameter';

  c_msg_user_not_found           constant varchar2(200) := 'User is not found';
  c_msg_table_not_found          constant varchar2(200) := 'Table is not found';
  c_msg_unsupport_table_scheme   constant varchar2(200) := 'Unsupported structure of table';

  c_msg_object_not_found         constant varchar2(200) := 'Object is not found';
  c_msg_object_not_unique        constant varchar2(200) := 'Object is not unique';
  c_msg_parent_object_not_found  constant varchar2(200) := 'Parent object is not found';
  c_msg_option_nspec             constant varchar2(200) := 'Option is not specified';
  c_msg_option_wrong             constant varchar2(200) := 'Wrong option';
  c_msg_option_nspec_wrong       constant varchar2(200) := 'Option is not specified or wrong';
  c_msg_object_empty             constant varchar2(200) := 'Object is empty';
  c_msg_object_wrong             constant varchar2(200) := 'Object is wrong';
  c_msg_not_allowed              constant varchar2(200) := 'Not allowed';
  c_msg_object_locked            constant varchar2(200) := 'Object is locked';
  c_msg_object_changed           constant varchar2(200) := 'Object is changed';
  c_msg_not_executed             constant varchar2(200) := 'Action is not executed';
  c_msg_rolled_back              constant varchar2(200) := 'Action is rolled back';
  c_msg_object_not_empty         constant varchar2(200) := 'Object is not empty';

  c_msg_interval_intersection    constant varchar2(200) := 'Intersection of intervals';
  c_msg_expired                  constant varchar2(200) := 'Expired';
  c_msg_execution_error          constant varchar2(200) := 'Execution error';
  c_msg_exceeded                 constant varchar2(200) := 'Exceeded allowed value';
  c_msg_object_latched           constant varchar2(200) := 'Object is latched';
  c_msg_no_action_required       constant varchar2(200) := 'No action required';

----------------------------------!---------------------------------------------
  c_quote                        constant varchar2(5) := '''';

----------------------------------!---------------------------------------------
  c_msg_label                    constant varchar2(100) := 'label:';
  c_msg_p_coll_is_null           constant varchar2(100) := 'p_coll is NULL';
  c_msg_p_coll_count             constant varchar2(100) := 'p_coll.count:';
  c_msg_v_i                      constant varchar2(100) := 'v_i:';

----------------------------------!---------------------------------------------
  type cit_number is table of number index by pls_integer;
  type cit_date is table of date index by pls_integer;
  type cit_varchar_s is table of varchar2(50) index by pls_integer;
  type cit_varchar is table of varchar2(4000) index by pls_integer;
  type cit_nvarchar_s is table of nvarchar2(50) index by pls_integer;
  type cit_nvarchar is table of nvarchar2(2000) index by pls_integer;

----------------------------------!---------------------------------------------
  unique_exception exception;
  pragma exception_init (unique_exception, -00001);
  lock_nowait_exception exception;
  pragma exception_init (lock_nowait_exception, -00054);
  lock_wait_exception exception;
  pragma exception_init (lock_wait_exception, -30006);

----------------------------------!---------------------------------------------
  function date_from2date_to_prev(p_date date) return date;
  function date_to2date_from_next(p_date date) return date;

----------------------------------!---------------------------------------------
  procedure raise_exception(p_code number, p_message varchar2);
  procedure raise_label_exception(p_label varchar2, p_code number, p_message varchar2);
  procedure reraise_exception;

  function cut_err_msg(p_str varchar2) return varchar2;
  function get_err_msg return varchar2;
  function get_err_code return number;
  function is_error(p_err_code number) return boolean;
  function is_ok(p_err_code number) return boolean;
  procedure set_error(p_code out number, p_message out varchar2);
  procedure set_ok(p_code out number, p_message out varchar2);
  procedure set_clear(p_code out number, p_message out varchar2);
  function get_err_msg_ondate(p_id_str varchar2, p_date date) return varchar2;
  function get_err_msg_ondate2(p_id1_str varchar2, p_id2_str varchar2, p_date date) return varchar2;
  function get_err_msg_ondate3(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_date date) return varchar2;
  function get_err_msg_vers(p_id_str varchar2, p_date_from date, p_date_to date) return varchar2;
  function get_err_msg_vers2(p_id1_str varchar2, p_id2_str varchar2, p_date_from date, p_date_to date) return varchar2;
  function get_err_msg_vers3(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_date_from date, p_date_to date) return varchar2;

----------------------------------!---------------------------------------------
  function date_to_char(p_val date) return varchar2;
  function char_to_date(p_val varchar2) return date;
  function date_to_char_full_compact(p_val date) return varchar2;
  function char_to_date_full_compact(p_val varchar2) return date;

  function number_to_char(p_val number) return varchar2;
  function char_to_number(p_val varchar2) return number;

  function nchar_to_char(p_val nvarchar2) return varchar2;
  function char_to_nchar(p_val varchar2) return nvarchar2;

  function bool_to_char(p_val boolean) return varchar2;
  function char_to_bool(p_val varchar2) return boolean;

  function bool_to_int(p_val boolean) return number;
  function bool_to_int_2val(p_val boolean) return number;
  function bool_to_int_3val(p_val boolean) return number;
  function int_to_bool(p_val number) return boolean;
  function int_to_bool_2val(p_val number) return boolean;
  function int_to_bool_3val(p_val number) return boolean;

  function bool_to_bool_2val(p_val boolean) return boolean;
  function int_to_int_2val(p_val number) return number;
  function int_to_int_3val(p_val number) return number;

----------------------------------!---------------------------------------------
  function date_dif_from_days(p_val number) return number;
  function date_dif_from_hours(p_val number) return number;
  function date_dif_from_minutes(p_val number) return number;
  function date_dif_from_seconds(p_val number) return number;

  function days_from_date_dif(p_val number) return number;
  function hours_from_date_dif(p_val number) return number;
  function minutes_from_date_dif(p_val number) return number;
  function seconds_from_date_dif(p_val number) return number;

----------------------------------!---------------------------------------------
  function month_begin(p_val date) return date;
  function month_end(p_val date) return date;
  function month_next_begin(p_val date) return date;

  function year_begin(p_val date) return date;
  function year_end(p_val date) return date;
  function year_next_begin(p_val date) return date;

----------------------------------!---------------------------------------------
  function get_year(p_val date) return number;
  function get_month(p_val date) return number;
  function get_day(p_val date) return number;
  function get_hour(p_val date) return number;
  function get_minute(p_val date) return number;
  function get_second(p_val date) return number;

  function wrap_date_part(p_val number, p_max_len number) return varchar2;

  function make_date
  (
    p_year number,
    p_month number,
    p_day number,
    p_hour number,
    p_minute number,
    p_second number
  ) return date;

  function change_date_year(p_date date, p_year number) return date;
  function change_date_month(p_date date, p_month number) return date;
  function change_date_day(p_date date, p_day number) return date;
  function change_date_hour(p_date date, p_hour number) return date;
  function change_date_minute(p_date date, p_minute number) return date;
  function change_date_second(p_date date, p_second number) return date;

----------------------------------!---------------------------------------------
  function empty_cit_number return cit_number;
  function cast_ct2cit_number(p_coll ct_number) return cit_number;
  function cast_cit2ct_number(p_coll cit_number, p_smart_cit boolean) return ct_number;
  function is_equal_ct_number(p_coll1 ct_number, p_coll2 ct_number, p_only_len boolean := false) return boolean;
  function is_equal_cit_number(p_coll1 cit_number, p_coll2 cit_number, p_only_len boolean := false) return boolean;

  function empty_cit_date return cit_date;
  function cast_ct2cit_date(p_coll ct_date) return cit_date;
  function cast_cit2ct_date(p_coll cit_date, p_smart_cit boolean) return ct_date;
  function is_equal_ct_date(p_coll1 ct_date, p_coll2 ct_date, p_only_len boolean := false) return boolean;
  function is_equal_cit_date(p_coll1 cit_date, p_coll2 cit_date, p_only_len boolean := false) return boolean;

  function empty_cit_varchar_s return cit_varchar_s;
  function cast_ct2cit_varchar_s(p_coll ct_varchar_s) return cit_varchar_s;
  function cast_cit2ct_varchar_s(p_coll cit_varchar_s, p_smart_cit boolean) return ct_varchar_s;
  function is_equal_ct_varchar_s(p_coll1 ct_varchar_s, p_coll2 ct_varchar_s, p_only_len boolean := false) return boolean;
  function is_equal_cit_varchar_s(p_coll1 cit_varchar_s, p_coll2 cit_varchar_s, p_only_len boolean := false) return boolean;

  function empty_cit_varchar return cit_varchar;
  function cast_ct2cit_varchar(p_coll ct_varchar) return cit_varchar;
  function cast_cit2ct_varchar(p_coll cit_varchar, p_smart_cit boolean) return ct_varchar;
  function is_equal_ct_varchar(p_coll1 ct_varchar, p_coll2 ct_varchar, p_only_len boolean := false) return boolean;
  function is_equal_cit_varchar(p_coll1 cit_varchar, p_coll2 cit_varchar, p_only_len boolean := false) return boolean;

  function empty_cit_nvarchar_s return cit_nvarchar_s;
  function cast_ct2cit_nvarchar_s(p_coll ct_nvarchar_s) return cit_nvarchar_s;
  function cast_cit2ct_nvarchar_s(p_coll cit_nvarchar_s, p_smart_cit boolean) return ct_nvarchar_s;
  function is_equal_ct_nvarchar_s(p_coll1 ct_nvarchar_s, p_coll2 ct_nvarchar_s, p_only_len boolean := false) return boolean;
  function is_equal_cit_nvarchar_s(p_coll1 cit_nvarchar_s, p_coll2 cit_nvarchar_s, p_only_len boolean := false) return boolean;

  function empty_cit_nvarchar return cit_nvarchar;
  function cast_ct2cit_nvarchar(p_coll ct_nvarchar) return cit_nvarchar;
  function cast_cit2ct_nvarchar(p_coll cit_nvarchar, p_smart_cit boolean) return ct_nvarchar;
  function is_equal_ct_nvarchar(p_coll1 ct_nvarchar, p_coll2 ct_nvarchar, p_only_len boolean := false) return boolean;
  function is_equal_cit_nvarchar(p_coll1 cit_nvarchar, p_coll2 cit_nvarchar, p_only_len boolean := false) return boolean;

----------------------------------!---------------------------------------------
  function cast_ct_varchar_s2varchar(p_coll ct_varchar_s) return ct_varchar;
  function cast_ct_nvarchar_s2nvarchar(p_coll ct_nvarchar_s) return ct_nvarchar;

  function cast_ct_varchar2varchar_s(p_coll ct_varchar, p_raise boolean) return ct_varchar_s;
  function cast_ct_nvarchar2nvarchar_s(p_coll ct_nvarchar, p_raise boolean) return ct_nvarchar_s;

  function cast_cit_varchar_s2varchar(p_coll cit_varchar_s) return cit_varchar;
  function cast_cit_nvarchar_s2nvarchar(p_coll cit_nvarchar_s) return cit_nvarchar;

  function cast_cit_varchar2varchar_s(p_coll cit_varchar, p_raise boolean) return cit_varchar_s;
  function cast_cit_nvarchar2nvarchar_s(p_coll cit_nvarchar, p_raise boolean) return cit_nvarchar_s;

----------------------------------!---------------------------------------------
  function cast_ct_varchar_s2nvarchar_s(p_coll ct_varchar_s) return ct_nvarchar_s;
  function cast_ct_varchar2nvarchar(p_coll ct_varchar) return ct_nvarchar;

  function cast_ct_nvarchar_s2varchar_s(p_coll ct_nvarchar_s) return ct_varchar_s;
  function cast_ct_nvarchar2varchar(p_coll ct_nvarchar) return ct_varchar;

  function cast_cit_varchar_s2nvarchar_s(p_coll cit_varchar_s) return cit_nvarchar_s;
  function cast_cit_varchar2nvarchar(p_coll cit_varchar) return cit_nvarchar;

  function cast_cit_nvarchar_s2varchar_s(p_coll cit_nvarchar_s) return cit_varchar_s;
  function cast_cit_nvarchar2varchar(p_coll cit_nvarchar) return cit_varchar;

----------------------------------!---------------------------------------------
  function cast_ct_varchar_s2ct_number(p_coll ct_varchar_s, p_raise boolean) return ct_number;
  function cast_ct_varchar2ct_number(p_coll ct_varchar, p_raise boolean) return ct_number;
  function cast_ct_nvarchar_s2ct_number(p_coll ct_nvarchar_s, p_raise boolean) return ct_number;
  function cast_ct_nvarchar2ct_number(p_coll ct_nvarchar, p_raise boolean) return ct_number;

  function cast_ct_number2ct_varchar_s(p_coll ct_number) return ct_varchar_s;
  function cast_ct_number2ct_varchar(p_coll ct_number) return ct_varchar;
  function cast_ct_number2ct_nvarchar_s(p_coll ct_number) return ct_nvarchar_s;
  function cast_ct_number2ct_nvarchar(p_coll ct_number) return ct_nvarchar;

----------------------------------!---------------------------------------------
  procedure fill_ct_number(p_coll in out nocopy ct_number, p_val number);
  procedure fill_ct_date(p_coll in out nocopy ct_date, p_val date);
  procedure fill_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_val varchar2);
  procedure fill_ct_varchar(p_coll in out nocopy ct_varchar, p_val varchar2);
  procedure fill_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_val nvarchar2);
  procedure fill_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_val nvarchar2);

  procedure fill_cit_number(p_coll in out nocopy cit_number, p_val number);
  procedure fill_cit_date(p_coll in out nocopy cit_date, p_val date);
  procedure fill_cit_varchar_s(p_coll in out nocopy cit_varchar_s, p_val varchar2);
  procedure fill_cit_varchar(p_coll in out nocopy cit_varchar, p_val varchar2);
  procedure fill_cit_nvarchar_s(p_coll in out nocopy cit_nvarchar_s, p_val nvarchar2);
  procedure fill_cit_nvarchar(p_coll in out nocopy cit_nvarchar, p_val nvarchar2);

----------------------------------!---------------------------------------------
  function make_ct_number(p_count number, p_val number) return ct_number;
  function make_ct_date(p_count number, p_val date) return ct_date;
  function make_ct_varchar_s(p_count number, p_val varchar2) return ct_varchar_s;
  function make_ct_varchar(p_count number, p_val varchar2) return ct_varchar;
  function make_ct_nvarchar_s(p_count number, p_val nvarchar2) return ct_nvarchar_s;
  function make_ct_nvarchar(p_count number, p_val nvarchar2) return ct_nvarchar;

  function make_cit_number(p_count number, p_val number) return cit_number;
  function make_cit_date(p_count number, p_val date) return cit_date;
  function make_cit_varchar_s(p_count number, p_val varchar2) return cit_varchar_s;
  function make_cit_varchar(p_count number, p_val varchar2) return cit_varchar;
  function make_cit_nvarchar_s(p_count number, p_val nvarchar2) return cit_nvarchar_s;
  function make_cit_nvarchar(p_count number, p_val nvarchar2) return cit_nvarchar;

----------------------------------!---------------------------------------------
  procedure add_ct_number_val(p_coll in out nocopy ct_number, p_val number);
  procedure add_ct_date_val(p_coll in out nocopy ct_date, p_val date);
  procedure add_ct_varchar_s_val(p_coll in out nocopy ct_varchar_s, p_val varchar2);
  procedure add_ct_varchar_val(p_coll in out nocopy ct_varchar, p_val varchar2);
  procedure add_ct_nvarchar_s_val(p_coll in out nocopy ct_nvarchar_s, p_val nvarchar2);
  procedure add_ct_nvarchar_val(p_coll in out nocopy ct_nvarchar, p_val nvarchar2);

----------------------------------!---------------------------------------------
  procedure add_ct_number(p_coll in out nocopy ct_number, p_coll_add ct_number);
  procedure add_ct_date(p_coll in out nocopy ct_date, p_coll_add ct_date);
  procedure add_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_coll_add ct_varchar_s);
  procedure add_ct_varchar(p_coll in out nocopy ct_varchar, p_coll_add ct_varchar);
  procedure add_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_coll_add ct_nvarchar_s);
  procedure add_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_coll_add ct_nvarchar);

  procedure add_cit_number(p_coll in out nocopy cit_number, p_coll_add cit_number);
  procedure add_cit_date(p_coll in out nocopy cit_date, p_coll_add cit_date);
  procedure add_cit_varchar_s(p_coll in out nocopy cit_varchar_s, p_coll_add cit_varchar_s);
  procedure add_cit_varchar(p_coll in out nocopy cit_varchar, p_coll_add cit_varchar);
  procedure add_cit_nvarchar_s(p_coll in out nocopy cit_nvarchar_s, p_coll_add cit_nvarchar_s);
  procedure add_cit_nvarchar(p_coll in out nocopy cit_nvarchar, p_coll_add cit_nvarchar);

----------------------------------!---------------------------------------------
  procedure resize_ct_number(p_coll in out nocopy ct_number, p_size number);
  procedure resize_ct_date(p_coll in out nocopy ct_date, p_size number);
  procedure resize_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_size number);
  procedure resize_ct_varchar(p_coll in out nocopy ct_varchar, p_size number);
  procedure resize_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_size number);
  procedure resize_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_size number);

  procedure resize_cit_number(p_coll in out nocopy cit_number, p_size number);
  procedure resize_cit_date(p_coll in out nocopy cit_date, p_size number);
  procedure resize_cit_varchar_s(p_coll in out nocopy cit_varchar_s, p_size number);
  procedure resize_cit_varchar(p_coll in out nocopy cit_varchar, p_size number);
  procedure resize_cit_nvarchar_s(p_coll in out nocopy cit_nvarchar_s, p_size number);
  procedure resize_cit_nvarchar(p_coll in out nocopy cit_nvarchar, p_size number);

----------------------------------!---------------------------------------------
  function cut_ct_number(p_coll ct_number, p_count number, p_start_pos number := 1) return ct_number;
  function cut_ct_date(p_coll ct_date, p_count number, p_start_pos number := 1) return ct_date;
  function cut_ct_varchar_s(p_coll ct_varchar_s, p_count number, p_start_pos number := 1) return ct_varchar_s;
  function cut_ct_varchar(p_coll ct_varchar, p_count number, p_start_pos number := 1) return ct_varchar;
  function cut_ct_nvarchar_s(p_coll ct_nvarchar_s, p_count number, p_start_pos number := 1) return ct_nvarchar_s;
  function cut_ct_nvarchar(p_coll ct_nvarchar, p_count number, p_start_pos number := 1) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function unique_ct_number(p_coll ct_number, p_save_order boolean, p_trim_empty boolean := true, p_empty_val number := null) return ct_number;
  function unique_ct_date(p_coll ct_date, p_save_order boolean, p_trim_empty boolean := true, p_empty_val date := null) return ct_date;
  function unique_ct_varchar_s(p_coll ct_varchar_s, p_save_order boolean, p_trim_empty boolean := true, p_empty_val varchar2 := null) return ct_varchar_s;
  function unique_ct_varchar(p_coll ct_varchar, p_save_order boolean, p_trim_empty boolean := true, p_empty_val varchar2 := null) return ct_varchar;
  function unique_ct_nvarchar_s(p_coll ct_nvarchar_s, p_save_order boolean, p_trim_empty boolean := true, p_empty_val nvarchar2 := null) return ct_nvarchar_s;
  function unique_ct_nvarchar(p_coll ct_nvarchar, p_save_order boolean, p_trim_empty boolean := true, p_empty_val nvarchar2 := null) return ct_nvarchar;

  function unique_cit_number(p_coll cit_number, p_save_order boolean, p_trim_empty boolean := true, p_empty_val number := null) return cit_number;
  function unique_cit_date(p_coll cit_date, p_save_order boolean, p_trim_empty boolean := true, p_empty_val date := null) return cit_date;
  function unique_cit_varchar_s(p_coll cit_varchar_s, p_save_order boolean, p_trim_empty boolean := true, p_empty_val varchar2 := null) return cit_varchar_s;
  function unique_cit_varchar(p_coll cit_varchar, p_save_order boolean, p_trim_empty boolean := true, p_empty_val varchar2 := null) return cit_varchar;
  function unique_cit_nvarchar_s(p_coll cit_nvarchar_s, p_save_order boolean, p_trim_empty boolean := true, p_empty_val nvarchar2 := null) return cit_nvarchar_s;
  function unique_cit_nvarchar(p_coll cit_nvarchar, p_save_order boolean, p_trim_empty boolean := true, p_empty_val nvarchar2 := null) return cit_nvarchar;

----------------------------------!---------------------------------------------
  --!_! p_vals trimmed on the basis of p_ids_pivot_for_vals; initial basis is p_ids_pivot_main
  ------------------------------
  function join2pivot_ct_number(p_vals ct_number, p_ids_pivot_main ct_number, p_ids_pivot_for_vals ct_number) return ct_number;
  function join2pivot_ct_date(p_vals ct_date, p_ids_pivot_main ct_number, p_ids_pivot_for_vals ct_number) return ct_date;
  function join2pivot_ct_varchar_s(p_vals ct_varchar_s, p_ids_pivot_main ct_number, p_ids_pivot_for_vals ct_number) return ct_varchar_s;
  function join2pivot_ct_varchar(p_vals ct_varchar, p_ids_pivot_main ct_number, p_ids_pivot_for_vals ct_number) return ct_varchar;
  function join2pivot_ct_nvarchar_s(p_vals ct_nvarchar_s, p_ids_pivot_main ct_number, p_ids_pivot_for_vals ct_number) return ct_nvarchar_s;
  function join2pivot_ct_nvarchar(p_vals ct_nvarchar, p_ids_pivot_main ct_number, p_ids_pivot_for_vals ct_number) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function filter_ct_number(p_vals ct_number, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_number;
  function filter_ct_date(p_vals ct_date, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_date;
  function filter_ct_varchar_s(p_vals ct_varchar_s, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_varchar_s;
  function filter_ct_varchar(p_vals ct_varchar, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_varchar;
  function filter_ct_nvarchar_s(p_vals ct_nvarchar_s, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_nvarchar_s;
  function filter_ct_nvarchar(p_vals ct_nvarchar, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_nvarchar;

  function filter_ct_number_1val(p_vals ct_number, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_number;
  function filter_ct_date_1val(p_vals ct_date, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_date;
  function filter_ct_varchar_s_1val(p_vals ct_varchar_s, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_varchar_s;
  function filter_ct_varchar_1val(p_vals ct_varchar, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_varchar;
  function filter_ct_nvarchar_s_1val(p_vals ct_nvarchar_s, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_nvarchar_s;
  function filter_ct_nvarchar_1val(p_vals ct_nvarchar, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function filter_val_ct_number(p_vals ct_number, p_filter_vals ct_number, p_include_by_filter boolean) return ct_number;
  function filter_val_ct_date(p_vals ct_date, p_filter_vals ct_date, p_include_by_filter boolean) return ct_date;
  function filter_val_ct_varchar_s(p_vals ct_varchar_s, p_filter_vals ct_varchar_s, p_include_by_filter boolean) return ct_varchar_s;
  function filter_val_ct_varchar(p_vals ct_varchar, p_filter_vals ct_varchar, p_include_by_filter boolean) return ct_varchar;
  function filter_val_ct_nvarchar_s(p_vals ct_nvarchar_s, p_filter_vals ct_nvarchar_s, p_include_by_filter boolean) return ct_nvarchar_s;
  function filter_val_ct_nvarchar(p_vals ct_nvarchar, p_filter_vals ct_nvarchar, p_include_by_filter boolean) return ct_nvarchar;

  function filter_val_ct_number_1val(p_vals ct_number, p_filter_val number, p_include_by_filter boolean) return ct_number;
  function filter_val_ct_date_1val(p_vals ct_date, p_filter_val date, p_include_by_filter boolean) return ct_date;
  function filter_val_ct_varchar_s_1val(p_vals ct_varchar_s, p_filter_val varchar2, p_include_by_filter boolean) return ct_varchar_s;
  function filter_val_ct_varchar_1val(p_vals ct_varchar, p_filter_val varchar2, p_include_by_filter boolean) return ct_varchar;
  function filter_val_ct_nvarchar_s_1val(p_vals ct_nvarchar_s, p_filter_val nvarchar2, p_include_by_filter boolean) return ct_nvarchar_s;
  function filter_val_ct_nvarchar_1val(p_vals ct_nvarchar, p_filter_val nvarchar2, p_include_by_filter boolean) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function mark_ct_number(p_vals ct_number, p_marker_vals ct_number, p_mark_value number := c_true, p_unmark_value number := c_false, p_x_marker_vals_not_unique boolean := false) return ct_number;
  function mark_ct_date(p_vals ct_date, p_marker_vals ct_date, p_mark_value number := c_true, p_unmark_value number := c_false, p_x_marker_vals_not_unique boolean := false) return ct_number;
  function mark_ct_varchar_s(p_vals ct_varchar_s, p_marker_vals ct_varchar_s, p_mark_value number := c_true, p_unmark_value number := c_false, p_x_marker_vals_not_unique boolean := false) return ct_number;
  function mark_ct_varchar(p_vals ct_varchar, p_marker_vals ct_varchar, p_mark_value number := c_true, p_unmark_value number := c_false, p_x_marker_vals_not_unique boolean := false) return ct_number;
  function mark_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marker_vals ct_nvarchar_s, p_mark_value number := c_true, p_unmark_value number := c_false, p_x_marker_vals_not_unique boolean := false) return ct_number;
  function mark_ct_nvarchar(p_vals ct_nvarchar, p_marker_vals ct_nvarchar, p_mark_value number := c_true, p_unmark_value number := c_false, p_x_marker_vals_not_unique boolean := false) return ct_number;

----------------------------------!---------------------------------------------
  function mark_val_ct_number(p_vals ct_number, p_marker_val number, p_mark_value number := c_true, p_unmark_value number := c_false) return ct_number;
  function mark_val_ct_date(p_vals ct_date, p_marker_val date, p_mark_value number := c_true, p_unmark_value number := c_false) return ct_number;
  function mark_val_ct_varchar_s(p_vals ct_varchar_s, p_marker_val varchar2, p_mark_value number := c_true, p_unmark_value number := c_false) return ct_number;
  function mark_val_ct_varchar(p_vals ct_varchar, p_marker_val varchar2, p_mark_value number := c_true, p_unmark_value number := c_false) return ct_number;
  function mark_val_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marker_val nvarchar2, p_mark_value number := c_true, p_unmark_value number := c_false) return ct_number;
  function mark_val_ct_nvarchar(p_vals ct_nvarchar, p_marker_val nvarchar2, p_mark_value number := c_true, p_unmark_value number := c_false) return ct_number;

----------------------------------!---------------------------------------------
  function get_marked_ct_number(p_vals ct_number, p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_value number := null) return ct_number;
  function get_marked_ct_date(p_vals ct_date, p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_value date := null) return ct_date;
  function get_marked_ct_varchar_s(p_vals ct_varchar_s, p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_value varchar2 := null) return ct_varchar_s;
  function get_marked_ct_varchar(p_vals ct_varchar, p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_value varchar2 := null) return ct_varchar;
  function get_marked_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_value nvarchar2 := null) return ct_nvarchar_s;
  function get_marked_ct_nvarchar(p_vals ct_nvarchar, p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_value nvarchar2 := null) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function mark2pos(p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_mark_pos number := null) return ct_number;
  function pos2mark(p_positions ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_unmark_value number := c_false, p_no_mark_pos number := null) return ct_number;

----------------------------------!---------------------------------------------
  function map_ct_number(p_vals1 ct_number, p_vals2 ct_number, p_trim_empty boolean, p_reverse boolean := false, p_no_value_rn number := null) return ct_number;
  function map_ct_date(p_vals1 ct_date, p_vals2 ct_date, p_trim_empty boolean, p_reverse boolean := false, p_no_value_rn number := null) return ct_number;
  function map_ct_varchar_s(p_vals1 ct_varchar_s, p_vals2 ct_varchar_s, p_trim_empty boolean, p_reverse boolean := false, p_no_value_rn number := null) return ct_number;
  function map_ct_varchar(p_vals1 ct_varchar, p_vals2 ct_varchar, p_trim_empty boolean, p_reverse boolean := false, p_no_value_rn number := null) return ct_number;
  function map_ct_nvarchar_s(p_vals1 ct_nvarchar_s, p_vals2 ct_nvarchar_s, p_trim_empty boolean, p_reverse boolean := false, p_no_value_rn number := null) return ct_number;
  function map_ct_nvarchar(p_vals1 ct_nvarchar, p_vals2 ct_nvarchar, p_trim_empty boolean, p_reverse boolean := false, p_no_value_rn number := null) return ct_number;

----------------------------------!---------------------------------------------
  function get_by_pos_ct_number(p_vals ct_number, p_positions ct_number, p_trim_empty boolean, p_no_value number := null) return ct_number;
  function get_by_pos_ct_date(p_vals ct_date, p_positions ct_number, p_trim_empty boolean, p_no_value date := null) return ct_date;
  function get_by_pos_ct_varchar_s(p_vals ct_varchar_s, p_positions ct_number, p_trim_empty boolean, p_no_value varchar2 := null) return ct_varchar_s;
  function get_by_pos_ct_varchar(p_vals ct_varchar, p_positions ct_number, p_trim_empty boolean, p_no_value varchar2 := null) return ct_varchar;
  function get_by_pos_ct_nvarchar_s(p_vals ct_nvarchar_s, p_positions ct_number, p_trim_empty boolean, p_no_value nvarchar2 := null) return ct_nvarchar_s;
  function get_by_pos_ct_nvarchar(p_vals ct_nvarchar, p_positions ct_number, p_trim_empty boolean, p_no_value nvarchar2 := null) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function get_by_pos2_ct_number(p_vals ct_number, p_positions ct_number, p_trim_empty boolean, p_no_value number := null) return ct_number;
  function get_by_pos2_ct_date(p_vals ct_date, p_positions ct_number, p_trim_empty boolean, p_no_value date := null) return ct_date;
  function get_by_pos2_ct_varchar_s(p_vals ct_varchar_s, p_positions ct_number, p_trim_empty boolean, p_no_value varchar2 := null) return ct_varchar_s;
  function get_by_pos2_ct_varchar(p_vals ct_varchar, p_positions ct_number, p_trim_empty boolean, p_no_value varchar2 := null) return ct_varchar;
  function get_by_pos2_ct_nvarchar_s(p_vals ct_nvarchar_s, p_positions ct_number, p_trim_empty boolean, p_no_value nvarchar2 := null) return ct_nvarchar_s;
  function get_by_pos2_ct_nvarchar(p_vals ct_nvarchar, p_positions ct_number, p_trim_empty boolean, p_no_value nvarchar2 := null) return ct_nvarchar;

----------------------------------!---------------------------------------------
  procedure set_by_pos_ct_number(p_coll in out nocopy ct_number, p_vals ct_number, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_by_pos_ct_date(p_coll in out nocopy ct_date, p_vals ct_date, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_by_pos_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_vals ct_varchar_s, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_by_pos_ct_varchar(p_coll in out nocopy ct_varchar, p_vals ct_varchar, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_by_pos_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_vals ct_nvarchar_s, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_by_pos_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_vals ct_nvarchar, p_positions ct_number, p_ignore_lack boolean := false);

----------------------------------!---------------------------------------------
  procedure set_by_pos2_ct_number(p_coll in out nocopy ct_number, p_vals ct_number, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_by_pos2_ct_date(p_coll in out nocopy ct_date, p_vals ct_date, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_by_pos2_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_vals ct_varchar_s, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_by_pos2_ct_varchar(p_coll in out nocopy ct_varchar, p_vals ct_varchar, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_by_pos2_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_vals ct_nvarchar_s, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_by_pos2_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_vals ct_nvarchar, p_positions ct_number, p_ignore_lack boolean := false);

----------------------------------!---------------------------------------------
  procedure set_val_by_pos_ct_number(p_coll in out nocopy ct_number, p_val number, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_val_by_pos_ct_date(p_coll in out nocopy ct_date, p_val date, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_val_by_pos_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_val varchar2, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_val_by_pos_ct_varchar(p_coll in out nocopy ct_varchar, p_val varchar2, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_val_by_pos_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_val nvarchar2, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_val_by_pos_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_val nvarchar2, p_positions ct_number, p_ignore_lack boolean := false);

----------------------------------!---------------------------------------------
  procedure set_val_by_pos2_ct_number(p_coll in out nocopy ct_number, p_val number, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_val_by_pos2_ct_date(p_coll in out nocopy ct_date, p_val date, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_val_by_pos2_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_val varchar2, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_val_by_pos2_ct_varchar(p_coll in out nocopy ct_varchar, p_val varchar2, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_val_by_pos2_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_val nvarchar2, p_positions ct_number, p_ignore_lack boolean := false);
  procedure set_val_by_pos2_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_val nvarchar2, p_positions ct_number, p_ignore_lack boolean := false);

----------------------------------!---------------------------------------------
  function supplement_ct_number(p_vals ct_number, p_supplement ct_number, p_trim_empty boolean, p_no_value number := null) return ct_number;
  function supplement_ct_date(p_vals ct_date, p_supplement ct_date, p_trim_empty boolean, p_no_value date := null) return ct_date;
  function supplement_ct_varchar_s(p_vals ct_varchar_s, p_supplement ct_varchar_s, p_trim_empty boolean, p_no_value varchar2 := null) return ct_varchar_s;
  function supplement_ct_varchar(p_vals ct_varchar, p_supplement ct_varchar, p_trim_empty boolean, p_no_value varchar2 := null) return ct_varchar;
  function supplement_ct_nvarchar_s(p_vals ct_nvarchar_s, p_supplement ct_nvarchar_s, p_trim_empty boolean, p_no_value nvarchar2 := null) return ct_nvarchar_s;
  function supplement_ct_nvarchar(p_vals ct_nvarchar, p_supplement ct_nvarchar, p_trim_empty boolean, p_no_value nvarchar2 := null) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function lower_ct_varchar_s(p_vals ct_varchar_s) return ct_varchar_s;
  function lower_ct_varchar(p_vals ct_varchar) return ct_varchar;
  function lower_ct_nvarchar_s(p_vals ct_nvarchar_s) return ct_nvarchar_s;
  function lower_ct_nvarchar(p_vals ct_nvarchar) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function upper_ct_varchar_s(p_vals ct_varchar_s) return ct_varchar_s;
  function upper_ct_varchar(p_vals ct_varchar) return ct_varchar;
  function upper_ct_nvarchar_s(p_vals ct_nvarchar_s) return ct_nvarchar_s;
  function upper_ct_nvarchar(p_vals ct_nvarchar) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function is_nulls_ct_number(p_vals ct_number) return boolean;
  function is_nulls_ct_date(p_vals ct_date) return boolean;
  function is_nulls_ct_varchar_s(p_vals ct_varchar_s) return boolean;
  function is_nulls_ct_varchar(p_vals ct_varchar) return boolean;
  function is_nulls_ct_nvarchar_s(p_vals ct_nvarchar_s) return boolean;
  function is_nulls_ct_nvarchar(p_vals ct_nvarchar) return boolean;

  function is_nulls_cit_number(p_vals cit_number, p_smart_cit boolean) return boolean;
  function is_nulls_cit_date(p_vals cit_date, p_smart_cit boolean) return boolean;
  function is_nulls_cit_varchar_s(p_vals cit_varchar_s, p_smart_cit boolean) return boolean;
  function is_nulls_cit_varchar(p_vals cit_varchar, p_smart_cit boolean) return boolean;
  function is_nulls_cit_nvarchar_s(p_vals cit_nvarchar_s, p_smart_cit boolean) return boolean;
  function is_nulls_cit_nvarchar(p_vals cit_nvarchar, p_smart_cit boolean) return boolean;

----------------------------------!---------------------------------------------
  procedure xis_nulls_ct_number(p_vals ct_number, p_label varchar2 := null);
  procedure xis_nulls_ct_date(p_vals ct_date, p_label varchar2 := null);
  procedure xis_nulls_ct_varchar_s(p_vals ct_varchar_s, p_label varchar2 := null);
  procedure xis_nulls_ct_varchar(p_vals ct_varchar, p_label varchar2 := null);
  procedure xis_nulls_ct_nvarchar_s(p_vals ct_nvarchar_s, p_label varchar2 := null);
  procedure xis_nulls_ct_nvarchar(p_vals ct_nvarchar, p_label varchar2 := null);

  procedure xis_nulls_cit_number(p_vals cit_number, p_smart_cit boolean, p_label varchar2 := null);
  procedure xis_nulls_cit_date(p_vals cit_date, p_smart_cit boolean, p_label varchar2 := null);
  procedure xis_nulls_cit_varchar_s(p_vals cit_varchar_s, p_smart_cit boolean, p_label varchar2 := null);
  procedure xis_nulls_cit_varchar(p_vals cit_varchar, p_smart_cit boolean, p_label varchar2 := null);
  procedure xis_nulls_cit_nvarchar_s(p_vals cit_nvarchar_s, p_smart_cit boolean, p_label varchar2 := null);
  procedure xis_nulls_cit_nvarchar(p_vals cit_nvarchar, p_smart_cit boolean, p_label varchar2 := null);

----------------------------------!---------------------------------------------
  function is_unique_ct_number(p_vals ct_number) return boolean;
  function is_unique_ct_date(p_vals ct_date) return boolean;
  function is_unique_ct_varchar_s(p_vals ct_varchar_s) return boolean;
  function is_unique_ct_varchar(p_vals ct_varchar) return boolean;
  function is_unique_ct_nvarchar_s(p_vals ct_nvarchar_s) return boolean;
  function is_unique_ct_nvarchar(p_vals ct_nvarchar) return boolean;

  function is_unique_cit_number(p_vals cit_number) return boolean;
  function is_unique_cit_date(p_vals cit_date) return boolean;
  function is_unique_cit_varchar_s(p_vals cit_varchar_s) return boolean;
  function is_unique_cit_varchar(p_vals cit_varchar) return boolean;
  function is_unique_cit_nvarchar_s(p_vals cit_nvarchar_s) return boolean;
  function is_unique_cit_nvarchar(p_vals cit_nvarchar) return boolean;

----------------------------------!---------------------------------------------
  procedure xis_unique_ct_number(p_vals ct_number, p_label varchar2 := null);
  procedure xis_unique_ct_date(p_vals ct_date, p_label varchar2 := null);
  procedure xis_unique_ct_varchar_s(p_vals ct_varchar_s, p_label varchar2 := null);
  procedure xis_unique_ct_varchar(p_vals ct_varchar, p_label varchar2 := null);
  procedure xis_unique_ct_nvarchar_s(p_vals ct_nvarchar_s, p_label varchar2 := null);
  procedure xis_unique_ct_nvarchar(p_vals ct_nvarchar, p_label varchar2 := null);

  procedure xis_unique_cit_number(p_vals cit_number, p_label varchar2 := null);
  procedure xis_unique_cit_date(p_vals cit_date, p_label varchar2 := null);
  procedure xis_unique_cit_varchar_s(p_vals cit_varchar_s, p_label varchar2 := null);
  procedure xis_unique_cit_varchar(p_vals cit_varchar, p_label varchar2 := null);
  procedure xis_unique_cit_nvarchar_s(p_vals cit_nvarchar_s, p_label varchar2 := null);
  procedure xis_unique_cit_nvarchar(p_vals cit_nvarchar, p_label varchar2 := null);

----------------------------------!---------------------------------------------
  function index_of_ct_number(p_coll ct_number, p_val number, p_occurence number := 1, p_equality number := c_true) return number;
  function index_of_ct_date(p_coll ct_date, p_val date, p_occurence number := 1, p_equality number := c_true) return number;
  function index_of_ct_varchar_s(p_coll ct_varchar_s, p_val varchar2, p_occurence number := 1, p_equality number := c_true) return number;
  function index_of_ct_varchar(p_coll ct_varchar, p_val varchar2, p_occurence number := 1, p_equality number := c_true) return number;
  function index_of_ct_nvarchar_s(p_coll ct_nvarchar_s, p_val nvarchar2, p_occurence number := 1, p_equality number := c_true) return number;
  function index_of_ct_nvarchar(p_coll ct_nvarchar, p_val nvarchar2, p_occurence number := 1, p_equality number := c_true) return number;

  function index_of_cit_number(p_coll cit_number, p_val number, p_occurence number := 1, p_equality number := c_true) return number;
  function index_of_cit_date(p_coll cit_date, p_val date, p_occurence number := 1, p_equality number := c_true) return number;
  function index_of_cit_varchar_s(p_coll cit_varchar_s, p_val varchar2, p_occurence number := 1, p_equality number := c_true) return number;
  function index_of_cit_varchar(p_coll cit_varchar, p_val varchar2, p_occurence number := 1, p_equality number := c_true) return number;
  function index_of_cit_nvarchar_s(p_coll cit_nvarchar_s, p_val nvarchar2, p_occurence number := 1, p_equality number := c_true) return number;
  function index_of_cit_nvarchar(p_coll cit_nvarchar, p_val nvarchar2, p_occurence number := 1, p_equality number := c_true) return number;

----------------------------------!---------------------------------------------
  function is_eq_null_vals_number(p_val1 number, p_val2 number) return boolean;
  function is_eq_null_vals_date(p_val1 date, p_val2 date) return boolean;
  function is_eq_null_vals_varchar(p_val1 varchar2, p_val2 varchar2) return boolean;
  function is_eq_null_vals_nvarchar(p_val1 nvarchar2, p_val2 nvarchar2) return boolean;

  function is_eq_null_vals_boolean(p_val1 boolean, p_val2 boolean) return boolean;

----------------------------------!---------------------------------------------
  function cmp_ct_number(p_vals1 ct_number, p_vals2 ct_number, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number;
  function cmp_ct_date(p_vals1 ct_date, p_vals2 ct_date, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number;
  function cmp_ct_varchar_s(p_vals1 ct_varchar_s, p_vals2 ct_varchar_s, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number;
  function cmp_ct_varchar(p_vals1 ct_varchar, p_vals2 ct_varchar, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number;
  function cmp_ct_nvarchar_s(p_vals1 ct_nvarchar_s, p_vals2 ct_nvarchar_s, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number;
  function cmp_ct_nvarchar(p_vals1 ct_nvarchar, p_vals2 ct_nvarchar, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number;

  function cmp_cit_number(p_vals1 cit_number, p_vals2 cit_number, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number;
  function cmp_cit_date(p_vals1 cit_date, p_vals2 cit_date, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number;
  function cmp_cit_varchar_s(p_vals1 cit_varchar_s, p_vals2 cit_varchar_s, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number;
  function cmp_cit_varchar(p_vals1 cit_varchar, p_vals2 cit_varchar, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number;
  function cmp_cit_nvarchar_s(p_vals1 cit_nvarchar_s, p_vals2 cit_nvarchar_s, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number;
  function cmp_cit_nvarchar(p_vals1 cit_nvarchar, p_vals2 cit_nvarchar, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number;

----------------------------------!---------------------------------------------
  function get_count_ct_number(p_coll ct_number) return number;
  function get_count_ct_date(p_coll ct_date) return number;
  function get_count_ct_varchar_s(p_coll ct_varchar_s) return number;
  function get_count_ct_varchar(p_coll ct_varchar) return number;
  function get_count_ct_nvarchar_s(p_coll ct_nvarchar_s) return number;
  function get_count_ct_nvarchar(p_coll ct_nvarchar) return number;

  function get_count_cit_number(p_coll cit_number) return number;
  function get_count_cit_date(p_coll cit_date) return number;
  function get_count_cit_varchar_s(p_coll cit_varchar_s) return number;
  function get_count_cit_varchar(p_coll cit_varchar) return number;
  function get_count_cit_nvarchar_s(p_coll cit_nvarchar_s) return number;
  function get_count_cit_nvarchar(p_coll cit_nvarchar) return number;

----------------------------------!---------------------------------------------
  procedure dbg_ct_number(p_coll ct_number, p_label varchar2 := null);
  procedure dbg_ct_date(p_coll ct_date, p_label varchar2 := null);
  procedure dbg_ct_varchar_s(p_coll ct_varchar_s, p_label varchar2 := null);
  procedure dbg_ct_varchar(p_coll ct_varchar, p_label varchar2 := null);
  procedure dbg_ct_nvarchar_s(p_coll ct_nvarchar_s, p_label varchar2 := null);
  procedure dbg_ct_nvarchar(p_coll ct_nvarchar, p_label varchar2 := null);

  procedure dbg_cit_number(p_coll cit_number, p_label varchar2 := null);
  procedure dbg_cit_date(p_coll cit_date, p_label varchar2 := null);
  procedure dbg_cit_varchar_s(p_coll cit_varchar_s, p_label varchar2 := null);
  procedure dbg_cit_varchar(p_coll cit_varchar, p_label varchar2 := null);
  procedure dbg_cit_nvarchar_s(p_coll cit_nvarchar_s, p_label varchar2 := null);
  procedure dbg_cit_nvarchar(p_coll cit_nvarchar, p_label varchar2 := null);

----------------------------------!---------------------------------------------
  function smart_label0(p_label varchar2) return varchar2;
  function smart_label1(p_label varchar2, p_label_def varchar2) return varchar2;
  function smart_label2(p_label varchar2, p_label_def varchar2, p_label_main varchar2) return varchar2;

  procedure Raise_Miss_Param(p_label varchar2 := null);
  procedure Raise_Invalid_Param(p_label varchar2 := null, p_val varchar2 := null);
  procedure Raise_Obj_NotFound(p_label varchar2 := null);
  procedure Raise_Obj_NotUniq(p_label varchar2 := null);

  procedure Raise_Obj_NotFound_ID(p_id_str varchar2, p_label varchar2 := null);
  procedure Raise_Obj_NotFound_ID2(p_id_num number, p_label varchar2 := null);
  procedure Raise_Obj_NotUniq_ID(p_id_str varchar2, p_label varchar2 := null);
  procedure Raise_Obj_NotUniq_ID2(p_id_num number, p_label varchar2 := null);

  procedure Raise_Obj2_NotFound_ID(p_id1_str varchar2, p_id2_str varchar2, p_label varchar2 := null);
  procedure Raise_Obj2_NotFound_ID2(p_id1_num number, p_id2_num number, p_label varchar2 := null);
  procedure Raise_Obj2_NotFound_ID3(p_id1_num number, p_id2_str varchar2, p_label varchar2 := null);
  procedure Raise_Obj2_NotUniq_ID(p_id1_str varchar2, p_id2_str varchar2, p_label varchar2 := null);
  procedure Raise_Obj2_NotUniq_ID2(p_id1_num number, p_id2_num number, p_label varchar2 := null);
  procedure Raise_Obj2_NotUniq_ID3(p_id1_num number, p_id2_str varchar2, p_label varchar2 := null);

  procedure Raise_Obj3_NotFound_ID(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_label varchar2 := null);
  procedure Raise_Obj3_NotFound_ID2(p_id1_num number, p_id2_num number, p_id3_num number, p_label varchar2 := null);
  procedure Raise_Obj3_NotUniq_ID(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_label varchar2 := null);
  procedure Raise_Obj3_NotUniq_ID2(p_id1_num number, p_id2_num number, p_id3_num number, p_label varchar2 := null);

  procedure Raise_Obj_NotFound_OnDate(p_id_str varchar2, p_date date, p_label varchar2 := null);
  procedure Raise_Obj_NotFound_OnDate2(p_id_num number, p_date date, p_label varchar2 := null);
  procedure Raise_Obj_NotFound_Vers(p_id_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null);
  procedure Raise_Obj_NotFound_Vers2(p_id_num number, p_date_from date, p_date_to date, p_label varchar2 := null);
  procedure Raise_Obj_NotUniq_OnDate(p_id_str varchar2, p_date date, p_label varchar2 := null);
  procedure Raise_Obj_NotUniq_OnDate2(p_id_num number, p_date date, p_label varchar2 := null);
  procedure Raise_Obj_NotUniq_Vers(p_id_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null);
  procedure Raise_Obj_NotUniq_Vers2(p_id_num number, p_date_from date, p_date_to date, p_label varchar2 := null);

  procedure Raise_Obj2_NotFound_OnDate(p_id1_str varchar2, p_id2_str varchar2, p_date date, p_label varchar2 := null);
  procedure Raise_Obj2_NotFound_OnDate2(p_id1_num number, p_id2_num number, p_date date, p_label varchar2 := null);
  procedure Raise_Obj2_NotFound_OnDate3(p_id1_num number, p_id2_str varchar2, p_date date, p_label varchar2 := null);
  procedure Raise_Obj2_NotFound_Vers(p_id1_str varchar2, p_id2_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null);
  procedure Raise_Obj2_NotFound_Vers2(p_id1_num number, p_id2_num number, p_date_from date, p_date_to date, p_label varchar2 := null);
  procedure Raise_Obj2_NotFound_Vers3(p_id1_num number, p_id2_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null);
  procedure Raise_Obj2_NotUniq_OnDate(p_id1_str varchar2, p_id2_str varchar2, p_date date, p_label varchar2 := null);
  procedure Raise_Obj2_NotUniq_OnDate2(p_id1_num number, p_id2_num number, p_date date, p_label varchar2 := null);
  procedure Raise_Obj2_NotUniq_OnDate3(p_id1_num number, p_id2_str varchar2, p_date date, p_label varchar2 := null);
  procedure Raise_Obj2_NotUniq_Vers(p_id1_str varchar2, p_id2_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null);
  procedure Raise_Obj2_NotUniq_Vers2(p_id1_num number, p_id2_num number, p_date_from date, p_date_to date, p_label varchar2 := null);
  procedure Raise_Obj2_NotUniq_Vers3(p_id1_num number, p_id2_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null);

  procedure Raise_Obj3_NotFound_OnDate(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_date date, p_label varchar2 := null);
  procedure Raise_Obj3_NotFound_OnDate2(p_id1_num number, p_id2_num number, p_id3_num number, p_date date, p_label varchar2 := null);
  procedure Raise_Obj3_NotFound_Vers(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null);
  procedure Raise_Obj3_NotFound_Vers2(p_id1_num number, p_id2_num number, p_id3_num number, p_date_from date, p_date_to date, p_label varchar2 := null);
  procedure Raise_Obj3_NotUniq_OnDate(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_date date, p_label varchar2 := null);
  procedure Raise_Obj3_NotUniq_OnDate2(p_id1_num number, p_id2_num number, p_id3_num number, p_date date, p_label varchar2 := null);
  procedure Raise_Obj3_NotUniq_Vers(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null);
  procedure Raise_Obj3_NotUniq_Vers2(p_id1_num number, p_id2_num number, p_id3_num number, p_date_from date, p_date_to date, p_label varchar2 := null);

----------------------------------!---------------------------------------------
  procedure XCheckP_ct_number(p_param ct_number, p_label varchar2 := null);
  procedure XCheckP_ct_date(p_param ct_date, p_label varchar2 := null);
  procedure XCheckP_ct_varchar_s(p_param ct_varchar_s, p_label varchar2 := null);
  procedure XCheckP_ct_varchar(p_param ct_varchar, p_label varchar2 := null);
  procedure XCheckP_ct_nvarchar_s(p_param ct_nvarchar_s, p_label varchar2 := null);
  procedure XCheckP_ct_nvarchar(p_param ct_nvarchar, p_label varchar2 := null);

  procedure XCheckP_cit_number(p_param cit_number, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_cit_date(p_param cit_date, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_cit_varchar_s(p_param cit_varchar_s, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_cit_varchar(p_param cit_varchar, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_cit_nvarchar_s(p_param cit_nvarchar_s, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_cit_nvarchar(p_param cit_nvarchar, p_label varchar2 := null, p_smart_cit boolean := true);

----------------------------------!---------------------------------------------
  function CheckP_ct_number(p_param ct_number) return boolean;
  function CheckP_ct_date(p_param ct_date) return boolean;
  function CheckP_ct_varchar_s(p_param ct_varchar_s) return boolean;
  function CheckP_ct_varchar(p_param ct_varchar) return boolean;
  function CheckP_ct_nvarchar_s(p_param ct_nvarchar_s) return boolean;
  function CheckP_ct_nvarchar(p_param ct_nvarchar) return boolean;

  function CheckP_cit_number(p_param cit_number, p_smart_cit boolean := true) return boolean;
  function CheckP_cit_date(p_param cit_date, p_smart_cit boolean := true) return boolean;
  function CheckP_cit_varchar_s(p_param cit_varchar_s, p_smart_cit boolean := true) return boolean;
  function CheckP_cit_varchar(p_param cit_varchar, p_smart_cit boolean := true) return boolean;
  function CheckP_cit_nvarchar_s(p_param cit_nvarchar_s, p_smart_cit boolean := true) return boolean;
  function CheckP_cit_nvarchar(p_param cit_nvarchar, p_smart_cit boolean := true) return boolean;

----------------------------------!---------------------------------------------
  procedure XCheck_Cond_Missing(p_raise_condition boolean, p_label varchar2 := null);
  procedure XCheck_Cond_Invalid(p_raise_condition boolean, p_label varchar2 := null);
  procedure XCheck_Num_As_Bool_Invalid(p_value number, p_label varchar2 := null);
  procedure XCheck_index(p_index integer, p_count integer, p_label varchar2, p_base integer := 1);
  procedure XCheck_index2(p_index integer, p_label varchar2, p_base integer := 1);
  procedure XCheck_size(p_size number, p_label varchar2);
  procedure XCheck_size0(p_size number, p_label varchar2);

----------------------------------!---------------------------------------------
  --!_!FS = Filled Solid
  procedure XCheckP_FS_ct_number(p_param ct_number, p_label varchar2 := null);
  procedure XCheckP_FS_ct_date(p_param ct_date, p_label varchar2 := null);
  procedure XCheckP_FS_ct_varchar_s(p_param ct_varchar_s, p_label varchar2 := null);
  procedure XCheckP_FS_ct_varchar(p_param ct_varchar, p_label varchar2 := null);
  procedure XCheckP_FS_ct_nvarchar_s(p_param ct_nvarchar_s, p_label varchar2 := null);
  procedure XCheckP_FS_ct_nvarchar(p_param ct_nvarchar, p_label varchar2 := null);

  procedure XCheckP_FS_cit_number(p_param cit_number, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_FS_cit_date(p_param cit_date, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_FS_cit_varchar_s(p_param cit_varchar_s, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_FS_cit_varchar(p_param cit_varchar, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_FS_cit_nvarchar_s(p_param cit_nvarchar_s, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_FS_cit_nvarchar(p_param cit_nvarchar, p_label varchar2 := null, p_smart_cit boolean := true);

----------------------------------!---------------------------------------------
  function CheckP_FS_ct_number(p_param ct_number) return boolean;
  function CheckP_FS_ct_date(p_param ct_date) return boolean;
  function CheckP_FS_ct_varchar_s(p_param ct_varchar_s) return boolean;
  function CheckP_FS_ct_varchar(p_param ct_varchar) return boolean;
  function CheckP_FS_ct_nvarchar_s(p_param ct_nvarchar_s) return boolean;
  function CheckP_FS_ct_nvarchar(p_param ct_nvarchar) return boolean;

  function CheckP_FS_cit_number(p_param cit_number, p_smart_cit boolean := true) return boolean;
  function CheckP_FS_cit_date(p_param cit_date, p_smart_cit boolean := true) return boolean;
  function CheckP_FS_cit_varchar_s(p_param cit_varchar_s, p_smart_cit boolean := true) return boolean;
  function CheckP_FS_cit_varchar(p_param cit_varchar, p_smart_cit boolean := true) return boolean;
  function CheckP_FS_cit_nvarchar_s(p_param cit_nvarchar_s, p_smart_cit boolean := true) return boolean;
  function CheckP_FS_cit_nvarchar(p_param cit_nvarchar, p_smart_cit boolean := true) return boolean;

----------------------------------!---------------------------------------------
  --!_!FSU = Filled Solid Unique
  procedure XCheckP_FSU_ct_number(p_param ct_number, p_label varchar2 := null);
  procedure XCheckP_FSU_ct_date(p_param ct_date, p_label varchar2 := null);
  procedure XCheckP_FSU_ct_varchar_s(p_param ct_varchar_s, p_label varchar2 := null);
  procedure XCheckP_FSU_ct_varchar(p_param ct_varchar, p_label varchar2 := null);
  procedure XCheckP_FSU_ct_nvarchar_s(p_param ct_nvarchar_s, p_label varchar2 := null);
  procedure XCheckP_FSU_ct_nvarchar(p_param ct_nvarchar, p_label varchar2 := null);

  procedure XCheckP_FSU_cit_number(p_param cit_number, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_FSU_cit_date(p_param cit_date, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_FSU_cit_varchar_s(p_param cit_varchar_s, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_FSU_cit_varchar(p_param cit_varchar, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_FSU_cit_nvarchar_s(p_param cit_nvarchar_s, p_label varchar2 := null, p_smart_cit boolean := true);
  procedure XCheckP_FSU_cit_nvarchar(p_param cit_nvarchar, p_label varchar2 := null, p_smart_cit boolean := true);

----------------------------------!---------------------------------------------
  function CheckP_FSU_ct_number(p_param ct_number) return boolean;
  function CheckP_FSU_ct_date(p_param ct_date) return boolean;
  function CheckP_FSU_ct_varchar_s(p_param ct_varchar_s) return boolean;
  function CheckP_FSU_ct_varchar(p_param ct_varchar) return boolean;
  function CheckP_FSU_ct_nvarchar_s(p_param ct_nvarchar_s) return boolean;
  function CheckP_FSU_ct_nvarchar(p_param ct_nvarchar) return boolean;

  function CheckP_FSU_cit_number(p_param cit_number, p_smart_cit boolean := true) return boolean;
  function CheckP_FSU_cit_date(p_param cit_date, p_smart_cit boolean := true) return boolean;
  function CheckP_FSU_cit_varchar_s(p_param cit_varchar_s, p_smart_cit boolean := true) return boolean;
  function CheckP_FSU_cit_varchar(p_param cit_varchar, p_smart_cit boolean := true) return boolean;
  function CheckP_FSU_cit_nvarchar_s(p_param cit_nvarchar_s, p_smart_cit boolean := true) return boolean;
  function CheckP_FSU_cit_nvarchar(p_param cit_nvarchar, p_smart_cit boolean := true) return boolean;

----------------------------------!---------------------------------------------
  procedure xcheck_version_dates(p_date_from date, p_date_to date);

----------------------------------!---------------------------------------------
  function check_bit_mask(p_active_bits number, p_mask_bits number) return number;
  function check_bit_mask2(p_active_bits number, p_mask_bits number) return boolean;

----------------------------------!---------------------------------------------
  function get_page_start(p_page_number number, p_page_size number, p_base number := 1) return number;
  function get_page_end(p_page_number number, p_page_size number, p_base number := 1) return number;

  function get_index_on_page(p_common_index number, p_page_size number, p_base_index number := 1, p_base_index_on_page number := 1) return number;
  function get_page_number(p_common_index number, p_page_size number, p_base_index number := 1, p_base_page number := 1) return number;
  function get_page_count(p_total_count number, p_page_size number, p_always_have_first_page boolean) return number;
  function get_page_count_i(p_total_count number, p_page_size number, p_always_have_first_page number) return number;
  function get_page_size(p_total_count number, p_page_count number, p_always_have_nonempty_page boolean) return number;
  function get_page_size_i(p_total_count number, p_page_count number, p_always_have_nonempty_page number) return number;

----------------------------------!---------------------------------------------
  function get_sum_ct_number(p_coll ct_number) return number;

----------------------------------!---------------------------------------------
  function split_string(p_str varchar2, p_delim varchar2, p_trimed_chars varchar2 := null) return ct_varchar;
  function split_nstring(p_str nvarchar2, p_delim nvarchar2, p_trimed_chars nvarchar2 := null) return ct_nvarchar;
  function merge_string(p_coll ct_varchar, p_delim varchar2, p_prefix varchar2 := '', p_postfix varchar2 := '') return varchar2;
  function merge_nstring(p_coll ct_nvarchar, p_delim nvarchar2, p_prefix nvarchar2 := '', p_postfix nvarchar2 := '') return nvarchar2;

----------------------------------!---------------------------------------------
  function str_length(p_value varchar2) return integer;
  function nstr_length(p_value nvarchar2) return integer;

  procedure str_split2(p_value varchar2, p_length1 integer, p_value1 out varchar2, p_value2 out varchar2);
  procedure nstr_split2(p_value nvarchar2, p_length1 integer, p_value1 out nvarchar2, p_value2 out nvarchar2);

----------------------------------!---------------------------------------------
  function get_mask_digits_at_begin(p_mask varchar2) return number;
  function get_mask_digits_at_middle(p_mask varchar2) return number;

----------------------------------!---------------------------------------------
  function make_pivot(p_count number, p_start number := 1) return ct_number;
  function make_pivot_or_empty(p_count number, p_start number := 1) return ct_number;

----------------------------------!---------------------------------------------
  function split_str_list(p_str_list varchar2, p_delim varchar2, p_null_str_is_empty_list boolean) return ct_varchar_s;
  function split_str_list2(p_str_list varchar2, p_delim varchar2, p_null_str_is_empty_list boolean) return ct_varchar;
  function split_nstr_list(p_str_list nvarchar2, p_delim nvarchar2, p_null_str_is_empty_list boolean) return ct_nvarchar_s;
  function split_nstr_list2(p_str_list nvarchar2, p_delim nvarchar2, p_null_str_is_empty_list boolean) return ct_nvarchar;

  function merge_str_list(p_coll ct_varchar_s, p_delim varchar2) return varchar2;
  function merge_str_list2(p_coll ct_varchar, p_delim varchar2) return varchar2;  --!!! COPY OF merge_string
  function merge_nstr_list(p_coll ct_nvarchar_s, p_delim nvarchar2) return nvarchar2;
  function merge_nstr_list2(p_coll ct_nvarchar, p_delim nvarchar2) return nvarchar2;  --!!! COPY OF merge_nstring

----------------------------------!---------------------------------------------
  function xor(p_value1 boolean, p_value2 boolean) return boolean;
  function xor_int_bool(p_value1 number, p_value2 number) return number;

----------------------------------!---------------------------------------------

end;
/
