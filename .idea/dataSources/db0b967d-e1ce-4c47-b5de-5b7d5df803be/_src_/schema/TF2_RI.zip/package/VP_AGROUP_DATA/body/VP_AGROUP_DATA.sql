CREATE package body vp_agroup_data is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ct_agroup_data(p_coll ct_agroup_data) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_rct_agroup_data(p_coll rct_agroup_data) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_ct_agroup_data(p_coll in out nocopy ct_agroup_data, p_size number)
is
  v_dif number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_agroup_data();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_rct_agroup_data(p_coll in out nocopy rct_agroup_data, p_size number)
is
  v_dif number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := rct_agroup_data();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_rct2ct_agroup_data(p_coll rct_agroup_data) return ct_agroup_data
is
  v_res ct_agroup_data;
  v_main_count number;
begin
  ------------------------------
  v_main_count := get_count_rct_agroup_data(p_coll);
  ------------------------------
  if v_main_count = 0
  then
    return v_res;
  end if;
  ------------------------------
  resize_ct_agroup_data(v_res, v_main_count);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := row2type(p_coll(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct2rct_agroup_data(p_coll ct_agroup_data) return rct_agroup_data
is
  v_res rct_agroup_data;
  v_main_count number;
begin
  ------------------------------
  v_main_count := get_count_ct_agroup_data(p_coll);
  ------------------------------
  if v_main_count = 0
  then
    return v_res;
  end if;
  ------------------------------
  resize_rct_agroup_data(v_res, v_main_count);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := type2row(p_coll(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_ct_agroup_data
(
  p_main_count number,
  p_agroup_data_id ct_number,
  p_agroup_id ct_number,
  p_id1 ct_number,
  p_id2 ct_number,
  p_date_from ct_date,
  p_date_to ct_date,
  p_user_id ct_number,
  p_change_date ct_date,
  p_dsc ct_varchar,
  p_date1 ct_date,
  p_num3 ct_number,
  p_str2 ct_varchar
) return ct_agroup_data
is
  v_res ct_agroup_data;
  v_pivot_null ct_number;
begin
  ------------------------------
  util_pkg.XCheck_size(p_main_count, 'p_main_count');
  ------------------------------
  util_pkg.resize_ct_number(v_pivot_null, p_main_count);
  ------------------------------
  select /*+ ordered use_hash(q0, q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11)*/
    ot_agroup_data
    (
      agroup_data_id => q1.agroup_data_id,
      agroup_id => q2.agroup_id,
      id1 => q3.id1,
      id2 => q4.id2,
      date_from => q5.date_from,
      date_to => q6.date_to,
      user_id => q7.user_id,
      change_date => q8.change_date,
      dsc => q9.dsc,
      date1 => q10.date1,
      num3 => q11.num3,
      str2 => q12.str2
    ) val
  bulk collect into v_res
  from
    (select rownum rn from table(v_pivot_null)) q0,
    (select column_value agroup_data_id, rownum rn from table(p_agroup_data_id)) q1,
    (select column_value agroup_id, rownum rn from table(p_agroup_id)) q2,
    (select column_value id1, rownum rn from table(p_id1)) q3,
    (select column_value id2, rownum rn from table(p_id2)) q4,
    (select column_value date_from, rownum rn from table(p_date_from)) q5,
    (select column_value date_to, rownum rn from table(p_date_to)) q6,
    (select column_value user_id, rownum rn from table(p_user_id)) q7,
    (select column_value change_date, rownum rn from table(p_change_date)) q8,
    (select column_value dsc, rownum rn from table(p_dsc)) q9,
    (select column_value date1, rownum rn from table(p_date1)) q10,
    (select column_value num3, rownum rn from table(p_num3)) q11,
    (select column_value str2, rownum rn from table(p_str2)) q12
  where 1 = 1
    and q1.rn(+) = q0.rn
    and q2.rn(+) = q0.rn
    and q3.rn(+) = q0.rn
    and q4.rn(+) = q0.rn
    and q5.rn(+) = q0.rn
    and q6.rn(+) = q0.rn
    and q7.rn(+) = q0.rn
    and q8.rn(+) = q0.rn
    and q9.rn(+) = q0.rn
    and q10.rn(+) = q0.rn
    and q11.rn(+) = q0.rn
    and q12.rn(+) = q0.rn
  order by q0.rn, q1.rn, q2.rn, q3.rn, q4.rn, q5.rn, q6.rn, q7.rn, q8.rn, q9.rn, q10.rn, q11.rn, q12.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_agroup_data_lim
(
  p_main_count number,
  p_accept_nulls boolean,
  p_agroup_data_id ct_number,
  p_agroup_id ct_number,
  p_id1 ct_number,
  p_id2 ct_number,
  p_date_from ct_date,
  p_date_to ct_date,
  p_user_id ct_number,
  p_change_date ct_date,
  p_dsc ct_varchar,
  p_date1 ct_date,
  p_num3 ct_number,
  p_str2 ct_varchar
) return ct_agroup_data
is
begin
  ------------------------------
  util_pkg.XCheck_size(p_main_count, 'p_main_count');
  util_pkg.XCheck_Cond_Missing(p_accept_nulls is null, 'p_accept_nulls');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid((not p_accept_nulls or p_agroup_data_id is not null) and util_pkg.get_count_ct_number(p_agroup_data_id) != p_main_count, 'p_agroup_data_id.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid((not p_accept_nulls or p_agroup_id is not null) and util_pkg.get_count_ct_number(p_agroup_id) != p_main_count, 'p_agroup_id.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid((not p_accept_nulls or p_id1 is not null) and util_pkg.get_count_ct_number(p_id1) != p_main_count, 'p_id1.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid((not p_accept_nulls or p_id2 is not null) and util_pkg.get_count_ct_number(p_id2) != p_main_count, 'p_id2.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid((not p_accept_nulls or p_date_from is not null) and util_pkg.get_count_ct_date(p_date_from) != p_main_count, 'p_date_from.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid((not p_accept_nulls or p_date_to is not null) and util_pkg.get_count_ct_date(p_date_to) != p_main_count, 'p_date_to.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid((not p_accept_nulls or p_user_id is not null) and util_pkg.get_count_ct_number(p_user_id) != p_main_count, 'p_user_id.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid((not p_accept_nulls or p_change_date is not null) and util_pkg.get_count_ct_date(p_change_date) != p_main_count, 'p_change_date.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid((not p_accept_nulls or p_dsc is not null) and util_pkg.get_count_ct_varchar(p_dsc) != p_main_count, 'p_dsc.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid((not p_accept_nulls or p_date1 is not null) and util_pkg.get_count_ct_date(p_date1) != p_main_count, 'p_date1.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid((not p_accept_nulls or p_num3 is not null) and util_pkg.get_count_ct_number(p_num3) != p_main_count, 'p_num3.count != p_main_count');
  ------------------------------
  return make_ct_agroup_data
  (
    p_main_count => p_main_count,
    p_agroup_data_id => p_agroup_data_id,
    p_agroup_id => p_agroup_id,
    p_id1 => p_id1,
    p_id2 => p_id2,
    p_date_from => p_date_from,
    p_date_to => p_date_to,
    p_user_id => p_user_id,
    p_change_date => p_change_date,
    p_dsc => p_dsc,
    p_date1 => p_date1,
    p_num3 => p_num3,
    p_str2 => p_str2
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function row2type(p_row agroup_data%rowtype) return ot_agroup_data
is
  v_res ot_agroup_data;
begin
  ------------------------------
  v_res := ot_agroup_data
  (
    agroup_data_id => p_row.agroup_data_id,
    agroup_id => p_row.agroup_id,
    id1 => p_row.id1,
    id2 => p_row.id2,
    date_from => p_row.date_from,
    date_to => p_row.date_to,
    user_id => p_row.user_id,
    change_date => p_row.change_date,
    dsc => p_row.dsc,
    date1 => p_row.date1,
    num3 => p_row.num3,
    str2 => p_row.str2
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function type2row(p_obj ot_agroup_data) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  v_res := null;
  ------------------------------
  v_res.agroup_data_id := p_obj.agroup_data_id;
  v_res.agroup_id := p_obj.agroup_id;
  v_res.id1 := p_obj.id1;
  v_res.id2 := p_obj.id2;
  v_res.date_from := p_obj.date_from;
  v_res.date_to := p_obj.date_to;
  v_res.user_id := p_obj.user_id;
  v_res.change_date := p_obj.change_date;
  v_res.dsc := p_obj.dsc;
  v_res.date1 := p_obj.date1;
  v_res.num3 := p_obj.num3;
  v_res.str2 := p_obj.str2;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_AGROUP_DATA_ID)*/
        * into v_res
        from agroup_data z
        where 1 = 1
        and agroup_data_id = p_id
        and p_date between date_from and date_to
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_AGROUP_DATA_ID)*/
        * into v_res
        from agroup_data z
        where 1 = 1
        and agroup_data_id = p_id
        and p_date between date_from and date_to
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_AGROUP_DATA_ID)*/
      * into v_res
      from agroup_data z
      where 1 = 1
      and agroup_data_id = p_id
      and p_date between date_from and date_to
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1_lock_wait_i(p_id integer, p_date date, p_wait_sec number, p_is_locked out boolean) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
  v_sql_text clob;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_wait_sec is null, 'p_wait_sec');
  util_pkg.XCheck_Cond_Invalid(p_wait_sec < 0, 'p_wait_sec < 0');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  v_sql_text := q'{select /*+ index_asc(z, I_AGROUP_DATA_ID)*/
  *
  from agroup_data z
  where 1 = 1
  and agroup_data_id = :p_id
  and :p_date between date_from and date_to
  for update wait :p_wait_sec
}'
  ;
  ------------------------------
  v_sql_text := replace(v_sql_text, ':p_wait_sec', util_pkg.number_to_char(p_wait_sec));
  ------------------------------
  execute immediate v_sql_text into v_res using p_id, p_date;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_wait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1(p_id integer, p_date date) return agroup_data%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get1_i(p_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget1(p_id integer, p_date date) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  v_res := get1(p_id, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get1(p_id integer, p_date date) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_i(p_id, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_wait_get1(p_id integer, p_date date, p_wait_sec number) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_lock_wait_i(p_id, p_date, p_wait_sec, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_wait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_xget1(p_id integer, p_date date) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  v_res := xlock_get1(p_id, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_wait_xget1(p_id integer, p_date date, p_wait_sec number) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  v_res := xlock_wait_get1(p_id, p_date, p_wait_sec);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xpget1_id1(p_pid integer, p_id1 number, p_date date) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_id1 is null, 'p_id1');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ index_asc(z, I_AGROUP_DATA_ID1)*/
    * into v_res
    from agroup_data z
    where 1 = 1
    and agroup_id = p_pid
    and id1 = p_id1
    and p_date between date_from and date_to
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xpget1_id2(p_pid integer, p_id2 number, p_date date) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_id2 is null, 'p_id2');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ index_asc(z, I_AGROUP_DATA_ID2)*/
    * into v_res
    from agroup_data z
    where 1 = 1
    and agroup_id = p_pid
    and id2 = p_id2
    and p_date between date_from and date_to
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xpget1_id1id2(p_pid integer, p_id1 number, p_id2 number, p_date date) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_id1 is null, 'p_id1');
  util_pkg.XCheck_Cond_Missing(p_id2 is null, 'p_id2');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ index_asc(z, I_AGROUP_DATA_ID2)*/
    * into v_res
    from agroup_data z
    where 1 = 1
    and agroup_id = p_pid
    and id1 = p_id1
    and id2 = p_id2
    and p_date between date_from and date_to
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xpget1_dsc_nocase(p_pid integer, p_dsc varchar2, p_date date) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_dsc is null, 'p_dsc');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ index_asc(z, I_AGROUP_DATA_ID3)*/
    * into v_res
    from agroup_data z
    where 1 = 1
    and agroup_id = p_pid
    and upper(dsc) = upper(p_dsc)
    and p_date between date_from and date_to
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xpget1_dsc_case(p_pid integer, p_dsc varchar2, p_date date) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_dsc is null, 'p_dsc');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ index_asc(z, I_AGROUP_DATA_AGROUP_ID)*/
    * into v_res
    from agroup_data z
    where 1 = 1
    and agroup_id = p_pid
    and dsc = p_dsc
    and p_date between date_from and date_to
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xpget1_dsc(p_pid integer, p_dsc varchar2, p_date date, p_ignore_case boolean) return agroup_data%rowtype
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ignore_case is null, 'p_ignore_case');
  ------------------------------
  if p_ignore_case
  then
    ------------------------------
    return xpget1_dsc_nocase(p_pid => p_pid, p_dsc => p_dsc, p_date => p_date);
    ------------------------------
  else
    ------------------------------
    return xpget1_dsc_case(p_pid => p_pid, p_dsc => p_dsc, p_date => p_date);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xpget1_date1(p_pid integer, p_date1 date, p_date date) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_date1 is null, 'p_date1');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ index_asc(z, I_AGROUP_DATA_ID4)*/
    * into v_res
    from agroup_data z
    where 1 = 1
    and agroup_id = p_pid
    and nvl(date1, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) = p_date1
    and p_date between date_from and date_to
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function pget1_id1(p_pid integer, p_id1 number, p_date date) return agroup_data%rowtype
is
begin
  ------------------------------
  return xpget1_id1(p_pid, p_id1, p_date);
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function pget1_id2(p_pid integer, p_id2 number, p_date date) return agroup_data%rowtype
is
begin
  ------------------------------
  return xpget1_id2(p_pid, p_id2, p_date);
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function pget1_id1id2(p_pid integer, p_id1 number, p_id2 number, p_date date) return agroup_data%rowtype
is
begin
  ------------------------------
  return xpget1_id1id2(p_pid, p_id1, p_id2, p_date);
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function pget1_dsc(p_pid integer, p_dsc varchar2, p_date date, p_ignore_case boolean) return agroup_data%rowtype
is
begin
  ------------------------------
  return xpget1_dsc(p_pid, p_dsc, p_date, p_ignore_case);
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function pget1_date1(p_pid integer, p_date1 date, p_date date) return agroup_data%rowtype
is
begin
  ------------------------------
  return xpget1_date1(p_pid, p_date1, p_date);
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function getN(p_pid number, p_date date) return ct_agroup_data
is
  v_res ct_agroup_data;
  v_agroup agroup%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_agroup := vp_agroup.xget1(p_pid, p_date);
  ------------------------------
  select /*+ index(z I_AGROUP_DATA_AGROUP_ID)*/
    ot_agroup_data
    (
      agroup_data_id => agroup_data_id,
      agroup_id => agroup_id,
      id1 => id1,
      id2 => id2,
      date_from => date_from,
      date_to => date_to,
      user_id => user_id,
      change_date => change_date,
      dsc => dsc,
      date1 => date1,
      num3 => num3,
      str2 => str2
    )
  bulk collect into v_res
  from agroup_data z
  where 1 = 1
    and agroup_id = v_agroup.agroup_id
    and p_date between date_from and date_to
  order by agroup_data_id, date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function getN_closed(p_pid number, p_date date, p_closed_on_date date) return ct_agroup_data
is
  v_res ct_agroup_data;
  v_agroup agroup%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_closed_on_date is null, 'p_closed_on_date');
  ------------------------------
  v_agroup := vp_agroup.xget1(p_pid, p_date);
  ------------------------------
  select /*+ index(z I_AGROUP_DATA_AGROUP_ID)*/
    ot_agroup_data
    (
      agroup_data_id => agroup_data_id,
      agroup_id => agroup_id,
      id1 => id1,
      id2 => id2,
      date_from => date_from,
      date_to => date_to,
      user_id => user_id,
      change_date => change_date,
      dsc => dsc,
      date1 => date1,
      num3 => num3,
      str2 => str2
    )
  bulk collect into v_res
  from agroup_data z
  where 1 = 1
    and agroup_id = v_agroup.agroup_id
    and date_to <= p_closed_on_date
  order by agroup_data_id, date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function getN_all_versions(p_pid number) return ct_agroup_data
is
begin
  ------------------------------
  return getN_closed(p_pid => p_pid, p_date => sysdate, p_closed_on_date => util_pkg.c_open_date_to);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN_id_i(p_id ct_number, p_date date, p_xcheck_data boolean := true) return ct_agroup_data
is
  v_res ct_agroup_data;
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  select /*+ ordered no_expand use_nl(z) full(q) index_asc(z, I_AGROUP_DATA_ID)*/
    ot_agroup_data
    (
      agroup_data_id => z.agroup_data_id,
      agroup_id => z.agroup_id,
      id1 => z.id1,
      id2 => z.id2,
      date_from => z.date_from,
      date_to => z.date_to,
      user_id => z.user_id,
      change_date => z.change_date,
      dsc => z.dsc,
      date1 => z.date1,
      num3 => z.num3,
      str2 => z.str2
    ) res,
    q.rn
  bulk collect into
    v_res,
    v_rn
  from
    (select column_value agroup_data_id, rownum rn from table(p_id)) q,
    agroup_data z
  where 1 = 1
    and z.agroup_data_id(+) = q.agroup_data_id
    and p_date between z.date_from(+) and z.date_to(+)
  order by q.rn, z.agroup_data_id, z.date_from
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN_id(p_pid number, p_id ct_number, p_date date, p_xcheck_data boolean := true) return ct_agroup_data
is
  v_res ct_agroup_data;
  v_agroup agroup%rowtype;
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_agroup := vp_agroup.xget1(p_pid, p_date);
  ------------------------------
  select /*+ ordered no_expand use_nl(z) full(q) index_asc(z, I_AGROUP_DATA_ID)*/
    ot_agroup_data
    (
      agroup_data_id => z.agroup_data_id,
      agroup_id => z.agroup_id,
      id1 => z.id1,
      id2 => z.id2,
      date_from => z.date_from,
      date_to => z.date_to,
      user_id => z.user_id,
      change_date => z.change_date,
      dsc => z.dsc,
      date1 => z.date1,
      num3 => z.num3,
      str2 => z.str2
    ) res,
    q.rn
  bulk collect into
    v_res,
    v_rn
  from
    (select column_value agroup_data_id, rownum rn from table(p_id)) q,
    agroup_data z
  where 1 = 1
    and z.agroup_id(+) = v_agroup.agroup_id
    and z.agroup_data_id(+) = q.agroup_data_id
    and p_date between z.date_from(+) and z.date_to(+)
  order by q.rn, z.agroup_data_id, z.date_from
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN_id1(p_pid number, p_id1 ct_number, p_date date, p_xcheck_data boolean := true) return ct_agroup_data
is
  v_res ct_agroup_data;
  v_agroup agroup%rowtype;
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_agroup := vp_agroup.xget1(p_pid, p_date);
  ------------------------------
  select /*+ ordered no_expand use_nl(z) full(q) index_asc(z, I_AGROUP_DATA_ID1)*/
    ot_agroup_data
    (
      agroup_data_id => z.agroup_data_id,
      agroup_id => z.agroup_id,
      id1 => z.id1,
      id2 => z.id2,
      date_from => z.date_from,
      date_to => z.date_to,
      user_id => z.user_id,
      change_date => z.change_date,
      dsc => z.dsc,
      date1 => z.date1,
      num3 => z.num3,
      str2 => z.str2
    ) res,
    q.rn
  bulk collect into
    v_res,
    v_rn
  from
    (select column_value id1, rownum rn from table(p_id1)) q,
    agroup_data z
  where 1 = 1
    and z.agroup_id(+) = v_agroup.agroup_id
    and z.id1(+) = q.id1
    and p_date between z.date_from(+) and z.date_to(+)
  order by q.rn, z.agroup_data_id, z.date_from
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN_id2(p_pid number, p_id2 ct_number, p_date date, p_xcheck_data boolean := true) return ct_agroup_data
is
  v_res ct_agroup_data;
  v_agroup agroup%rowtype;
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_agroup := vp_agroup.xget1(p_pid, p_date);
  ------------------------------
  select /*+ ordered no_expand use_nl(z) full(q) index_asc(z, I_AGROUP_DATA_ID2)*/
    ot_agroup_data
    (
      agroup_data_id => z.agroup_data_id,
      agroup_id => z.agroup_id,
      id1 => z.id1,
      id2 => z.id2,
      date_from => z.date_from,
      date_to => z.date_to,
      user_id => z.user_id,
      change_date => z.change_date,
      dsc => z.dsc,
      date1 => z.date1,
      num3 => z.num3,
      str2 => z.str2
    ) res,
    q.rn
  bulk collect into
    v_res,
    v_rn
  from
    (select column_value id2, rownum rn from table(p_id2)) q,
    agroup_data z
  where 1 = 1
    and z.agroup_id(+) = v_agroup.agroup_id
    and z.id2(+) = q.id2
    and p_date between z.date_from(+) and z.date_to(+)
  order by q.rn, z.agroup_data_id, z.date_from
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN_id1id2(p_pid number, p_id1 ct_number, p_id2 ct_number, p_date date, p_xcheck_data boolean := true) return ct_agroup_data
is
  v_res ct_agroup_data;
  v_main_count number;
  v_agroup agroup%rowtype;
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_id1);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_id1) != v_main_count, 'p_id1.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_id2) != v_main_count, 'p_id2.count != p_main_count');
  ------------------------------
  v_agroup := vp_agroup.xget1(p_pid, p_date);
  ------------------------------
  select /*+ ordered no_expand use_nl(z) full(q1) full(q) index_asc(z, I_AGROUP_DATA_ID2)*/
    ot_agroup_data
    (
      agroup_data_id => z.agroup_data_id,
      agroup_id => z.agroup_id,
      id1 => z.id1,
      id2 => z.id2,
      date_from => z.date_from,
      date_to => z.date_to,
      user_id => z.user_id,
      change_date => z.change_date,
      dsc => z.dsc,
      date1 => z.date1,
      num3 => z.num3,
      str2 => z.str2
    ) res,
    q.rn
  bulk collect into
    v_res,
    v_rn
  from
    (
      select /*+ ordered use_hash(q2) full(q1) full(q2)*/
        q1.rn,
        q1.id1,
        q2.id2
      from
        (select column_value id1, rownum rn from table(p_id1)) q1,
        (select column_value id2, rownum rn from table(p_id2)) q2
      where 1 = 1
        and q2.rn(+) = q1.rn
      order by q1.rn
    ) q,
    agroup_data z
  where 1 = 1
    and z.agroup_id(+) = v_agroup.agroup_id
    and z.id1(+) = q.id1
    and z.id2(+) = q.id2
    and p_date between z.date_from(+) and z.date_to(+)
  order by q.rn, z.agroup_data_id, z.date_from
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN_dsc_nocase(p_pid number, p_dsc ct_varchar, p_date date, p_xcheck_data boolean := true) return ct_agroup_data
is
  v_res ct_agroup_data;
  v_agroup agroup%rowtype;
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_agroup := vp_agroup.xget1(p_pid, p_date);
  ------------------------------
  select /*+ ordered no_expand use_nl(z) full(q) index_asc(z, I_AGROUP_DATA_ID3)*/
    ot_agroup_data
    (
      agroup_data_id => z.agroup_data_id,
      agroup_id => z.agroup_id,
      id1 => z.id1,
      id2 => z.id2,
      date_from => z.date_from,
      date_to => z.date_to,
      user_id => z.user_id,
      change_date => z.change_date,
      dsc => z.dsc,
      date1 => z.date1,
      num3 => z.num3,
      str2 => z.str2
    ) res,
    q.rn
  bulk collect into
    v_res,
    v_rn
  from
    (select column_value dsc, rownum rn from table(p_dsc)) q,
    agroup_data z
  where 1 = 1
    and z.agroup_id(+) = v_agroup.agroup_id
    and upper(z.dsc(+)) = upper(q.dsc)
    and p_date between z.date_from(+) and z.date_to(+)
  order by q.rn, z.agroup_data_id, z.date_from
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN_dsc_case(p_pid number, p_dsc ct_varchar, p_date date, p_xcheck_data boolean := true) return ct_agroup_data
is
  v_res ct_agroup_data;
  v_agroup agroup%rowtype;
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_agroup := vp_agroup.xget1(p_pid, p_date);
  ------------------------------
  select /*+ ordered no_expand use_nl(z) full(q) index_asc(z, I_AGROUP_DATA_AGROUP_ID)*/
    ot_agroup_data
    (
      agroup_data_id => z.agroup_data_id,
      agroup_id => z.agroup_id,
      id1 => z.id1,
      id2 => z.id2,
      date_from => z.date_from,
      date_to => z.date_to,
      user_id => z.user_id,
      change_date => z.change_date,
      dsc => z.dsc,
      date1 => z.date1,
      num3 => z.num3,
      str2 => z.str2
    ) res,
    q.rn
  bulk collect into
    v_res,
    v_rn
  from
    (select column_value dsc, rownum rn from table(p_dsc)) q,
    agroup_data z
  where 1 = 1
    and z.agroup_id(+) = v_agroup.agroup_id
    and z.dsc(+) = q.dsc
    and p_date between z.date_from(+) and z.date_to(+)
  order by q.rn, z.agroup_data_id, z.date_from
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN_dsc(p_pid number, p_dsc ct_varchar, p_date date, p_ignore_case boolean, p_xcheck_data boolean := true) return ct_agroup_data
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ignore_case is null, 'p_ignore_case');
  ------------------------------
  if p_ignore_case
  then
    ------------------------------
    return xgetN_dsc_nocase(p_pid => p_pid, p_dsc => p_dsc, p_date => p_date, p_xcheck_data => p_xcheck_data);
    ------------------------------
  else
    ------------------------------
    return xgetN_dsc_case(p_pid => p_pid, p_dsc => p_dsc, p_date => p_date, p_xcheck_data => p_xcheck_data);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN_date1(p_pid number, p_date1 ct_date, p_date date, p_xcheck_data boolean := true) return ct_agroup_data
is
  v_res ct_agroup_data;
  v_agroup agroup%rowtype;
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_agroup := vp_agroup.xget1(p_pid, p_date);
  ------------------------------
  select /*+ ordered no_expand use_nl(z) full(q) index_asc(z, I_AGROUP_DATA_ID4)*/
    ot_agroup_data
    (
      agroup_data_id => z.agroup_data_id,
      agroup_id => z.agroup_id,
      id1 => z.id1,
      id2 => z.id2,
      date_from => z.date_from,
      date_to => z.date_to,
      user_id => z.user_id,
      change_date => z.change_date,
      dsc => z.dsc,
      date1 => z.date1,
      num3 => z.num3,
      str2 => z.str2
    ) res,
    q.rn
  bulk collect into
    v_res,
    v_rn
  from
    (select column_value date1, rownum rn from table(p_date1)) q,
    agroup_data z
  where 1 = 1
    and z.agroup_id(+) = v_agroup.agroup_id
    and nvl(z.date1(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) = q.date1
    and p_date between z.date_from(+) and z.date_to(+)
  order by q.rn, z.agroup_data_id, z.date_from
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN1_id_i(p_id ct_number, p_date date) return ct_agroup_data
is
begin
  ------------------------------
  return xgetN_id_i(p_id => p_id, p_date => p_date, p_xcheck_data => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN1_id(p_pid number, p_id ct_number, p_date date) return ct_agroup_data
is
begin
  ------------------------------
  return xgetN_id(p_pid => p_pid, p_id => p_id, p_date => p_date, p_xcheck_data => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN1_id1(p_pid number, p_id1 ct_number, p_date date) return ct_agroup_data
is
begin
  ------------------------------
  return xgetN_id1(p_pid => p_pid, p_id1 => p_id1, p_date => p_date, p_xcheck_data => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN1_id2(p_pid number, p_id2 ct_number, p_date date) return ct_agroup_data
is
begin
  ------------------------------
  return xgetN_id2(p_pid => p_pid, p_id2 => p_id2, p_date => p_date, p_xcheck_data => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN1_id1id2(p_pid number, p_id1 ct_number, p_id2 ct_number, p_date date) return ct_agroup_data
is
begin
  ------------------------------
  return xgetN_id1id2(p_pid => p_pid, p_id1 => p_id1, p_id2 => p_id2, p_date => p_date, p_xcheck_data => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN1_dsc_nocase(p_pid number, p_dsc ct_varchar, p_date date) return ct_agroup_data
is
begin
  ------------------------------
  return xgetN_dsc_nocase(p_pid => p_pid, p_dsc => p_dsc, p_date => p_date, p_xcheck_data => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN1_dsc_case(p_pid number, p_dsc ct_varchar, p_date date) return ct_agroup_data
is
begin
  ------------------------------
  return xgetN_dsc_case(p_pid => p_pid, p_dsc => p_dsc, p_date => p_date, p_xcheck_data => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN1_dsc(p_pid number, p_dsc ct_varchar, p_date date, p_ignore_case boolean) return ct_agroup_data
is
begin
  ------------------------------
  return xgetN_dsc(p_pid => p_pid, p_dsc => p_dsc, p_date => p_date, p_ignore_case => p_ignore_case, p_xcheck_data => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN1_date1(p_pid number, p_date1 ct_date, p_date date) return ct_agroup_data
is
begin
  ------------------------------
  return xgetN_date1(p_pid => p_pid, p_date1 => p_date1, p_date => p_date, p_xcheck_data => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN2_id_i(p_id number, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data
is
  v_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_id, p_id);
  ------------------------------
  return xgetN_id_i(p_id => v_id, p_date => p_date, p_xcheck_data => p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN2_id(p_pid number, p_id number, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data
is
  v_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_id, p_id);
  ------------------------------
  return xgetN_id(p_pid => p_pid, p_id => v_id, p_date => p_date, p_xcheck_data => p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN2_id1(p_pid number, p_id1 number, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data
is
  v_id1 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id1 is null, 'p_id1');
  ------------------------------
  util_pkg.add_ct_number_val(v_id1, p_id1);
  ------------------------------
  return xgetN_id1(p_pid => p_pid, p_id1 => v_id1, p_date => p_date, p_xcheck_data => p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN2_id2(p_pid number, p_id2 number, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data
is
  v_id2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id2 is null, 'p_id2');
  ------------------------------
  util_pkg.add_ct_number_val(v_id2, p_id2);
  ------------------------------
  return xgetN_id2(p_pid => p_pid, p_id2 => v_id2, p_date => p_date, p_xcheck_data => p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN2_id1id2(p_pid number, p_id1 number, p_id2 number, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data
is
  v_id1 ct_number;
  v_id2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id1 is null, 'p_id1');
  util_pkg.XCheck_Cond_Missing(p_id2 is null, 'p_id2');
  ------------------------------
  util_pkg.add_ct_number_val(v_id1, p_id1);
  util_pkg.add_ct_number_val(v_id2, p_id2);
  ------------------------------
  return xgetN_id1id2(p_pid => p_pid, p_id1 => v_id1, p_id2 => v_id2, p_date => p_date, p_xcheck_data => p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN2_dsc_nocase(p_pid number, p_dsc varchar2, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data
is
  v_dsc ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_dsc is null, 'p_dsc');
  ------------------------------
  util_pkg.add_ct_varchar_val(v_dsc, p_dsc);
  ------------------------------
  return xgetN_dsc_nocase(p_pid => p_pid, p_dsc => v_dsc, p_date => p_date, p_xcheck_data => p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN2_dsc_case(p_pid number, p_dsc varchar2, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data
is
  v_dsc ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_dsc is null, 'p_dsc');
  ------------------------------
  util_pkg.add_ct_varchar_val(v_dsc, p_dsc);
  ------------------------------
  return xgetN_dsc_case(p_pid => p_pid, p_dsc => v_dsc, p_date => p_date, p_xcheck_data => p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN2_dsc(p_pid number, p_dsc varchar2, p_date date, p_ignore_case boolean, p_xcheck_data boolean := FALSE) return ct_agroup_data
is
  v_dsc ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_dsc is null, 'p_dsc');
  ------------------------------
  util_pkg.add_ct_varchar_val(v_dsc, p_dsc);
  ------------------------------
  return xgetN_dsc(p_pid => p_pid, p_dsc => v_dsc, p_ignore_case => p_ignore_case, p_date => p_date, p_xcheck_data => p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xgetN2_date1(p_pid number, p_date1 date, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data
is
  v_date1 ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date1 is null, 'p_date1');
  ------------------------------
  util_pkg.add_ct_date_val(v_date1, p_date1);
  ------------------------------
  return xgetN_date1(p_pid => p_pid, p_date1 => v_date1, p_date => p_date, p_xcheck_data => p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xvalid_i(p_rec agroup_data%rowtype)
is
begin
  ------------------------------
  util_pkg.xcheck_version_dates(p_rec.date_from, p_rec.date_to);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_Num_As_Mode_Invalid(p_unq_mode integer, p_label varchar2 := null)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_unq_mode is null, case when p_label is not null then p_label else 'p_unq_mode' end);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_unq_mode not in (c_unq_none, c_unq_id1, c_unq_id2, c_unq_id1id2, c_unq_dsc, c_unq_dsc_ic), case when p_label is not null then p_label else 'p_unq_mode' end || ' not in (c_unq_none, c_unq_id1, c_unq_id2, c_unq_id1id2, c_unq_dsc, c_unq_dsc_ic)');
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function find_i_id(p_rec agroup_data%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_cnt number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(p_check_only_other_ids and p_rec.agroup_data_id is null, 'p_rec.agroup_data_id');
  util_pkg.XCheck_Cond_Missing(p_rec.agroup_data_id is null, 'p_rec.agroup_data_id');
  ------------------------------
  if p_check_only_other_ids
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
select /*+ index_asc(z, I_AGROUP_DATA_ID)*/
  count(1) cnt into v_cnt
  from agroup_data z
  where 1 = 1
  and agroup_data_id = p_rec.agroup_data_id
  and greatest(p_rec.date_from, date_from) <= least(p_rec.date_to, date_to)
  --!_!and (v_check_only_other_ids = util_pkg.c_false or agroup_data_id != p_rec.agroup_data_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_pid_id1(p_rec agroup_data%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids and p_rec.agroup_data_id is null, 'p_rec.agroup_data_id');
  util_pkg.XCheck_Cond_Missing(p_rec.id1 is null, 'p_rec.id1');
  ------------------------------
select /*+ index_asc(z, I_AGROUP_DATA_ID1)*/
  count(1) cnt into v_cnt
  from agroup_data z
  where 1 = 1
  and agroup_id = p_rec.agroup_id
  and id1 = p_rec.id1
  and greatest(p_rec.date_from, date_from) <= least(p_rec.date_to, date_to)
  and (v_check_only_other_ids = util_pkg.c_false or agroup_data_id != p_rec.agroup_data_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_pid_id2(p_rec agroup_data%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids and p_rec.agroup_data_id is null, 'p_rec.agroup_data_id');
  util_pkg.XCheck_Cond_Missing(p_rec.id2 is null, 'p_rec.id2');
  ------------------------------
select /*+ index_asc(z, I_AGROUP_DATA_ID2)*/
  count(1) cnt into v_cnt
  from agroup_data z
  where 1 = 1
  and agroup_id = p_rec.agroup_id
  and id2 = p_rec.id2
  and greatest(p_rec.date_from, date_from) <= least(p_rec.date_to, date_to)
  and (v_check_only_other_ids = util_pkg.c_false or agroup_data_id != p_rec.agroup_data_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_pid_id1id2(p_rec agroup_data%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids and p_rec.agroup_data_id is null, 'p_rec.agroup_data_id');
  util_pkg.XCheck_Cond_Missing(p_rec.id1 is null, 'p_rec.id1');
  util_pkg.XCheck_Cond_Missing(p_rec.id2 is null, 'p_rec.id2');
  ------------------------------
select /*+ index_asc(z, I_AGROUP_DATA_ID1)*/
  count(1) cnt into v_cnt
  from agroup_data z
  where 1 = 1
  and agroup_id = p_rec.agroup_id
  and id1 = p_rec.id1
  and id2 = p_rec.id2
  and greatest(p_rec.date_from, date_from) <= least(p_rec.date_to, date_to)
  and (v_check_only_other_ids = util_pkg.c_false or agroup_data_id != p_rec.agroup_data_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_pid_dsc(p_rec agroup_data%rowtype, p_ignore_case boolean, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids and p_rec.agroup_data_id is null, 'p_rec.agroup_data_id');
  util_pkg.XCheck_Cond_Missing(p_rec.dsc is null, 'p_rec.dsc');
  util_pkg.XCheck_Cond_Missing(p_ignore_case is null, 'p_ignore_case');
  ------------------------------
  if p_ignore_case
  then
    ------------------------------
select /*+ index_asc(z, I_AGROUP_DATA_ID3)*/
  count(1) cnt into v_cnt
  from agroup_data z
  where 1 = 1
  and agroup_id = p_rec.agroup_id
  and upper(dsc) = upper(p_rec.dsc)
  and greatest(p_rec.date_from, date_from) <= least(p_rec.date_to, date_to)
  and (v_check_only_other_ids = util_pkg.c_false or agroup_data_id != p_rec.agroup_data_id)
  ;
    ------------------------------
  else
    ------------------------------
select /*+ index_asc(z, I_AGROUP_DATA_ID3)*/
  count(1) cnt into v_cnt
  from agroup_data z
  where 1 = 1
  and agroup_id = p_rec.agroup_id
  and upper(dsc) = upper(p_rec.dsc)
  and dsc = p_rec.dsc
  and greatest(p_rec.date_from, date_from) <= least(p_rec.date_to, date_to)
  and (v_check_only_other_ids = util_pkg.c_false or agroup_data_id != p_rec.agroup_data_id)
  ;
    ------------------------------
  end if;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i(p_rec agroup_data%rowtype, p_unq_mode integer, p_check_only_other_ids boolean) return boolean
is
begin
  ------------------------------
  XCheck_Num_As_Mode_Invalid(p_unq_mode, 'p_unq_mode');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  if find_i_id(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and util_pkg.check_bit_mask2(p_unq_mode, c_unq_id1)
    and find_i_pid_id1(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and util_pkg.check_bit_mask2(p_unq_mode, c_unq_id2)
    and find_i_pid_id2(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and util_pkg.check_bit_mask2(p_unq_mode, c_unq_id1id2)
    and find_i_pid_id1id2(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and util_pkg.check_bit_mask2(p_unq_mode, c_unq_dsc)
    and find_i_pid_dsc(p_rec, FALSE, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and util_pkg.check_bit_mask2(p_unq_mode, c_unq_dsc_ic)
    and find_i_pid_dsc(p_rec, TRUE, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xunique_i(p_rec agroup_data%rowtype, p_unq_mode integer, p_check_only_other_ids boolean)
is
begin
  ------------------------------
  XCheck_Num_As_Mode_Invalid(p_unq_mode, 'p_unq_mode');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  if find_i_id(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_Vers2(p_rec.agroup_data_id, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and util_pkg.check_bit_mask2(p_unq_mode, c_unq_id1)
    and find_i_pid_id1(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_Vers2(p_rec.agroup_id, p_rec.id1, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and util_pkg.check_bit_mask2(p_unq_mode, c_unq_id2)
    and find_i_pid_id2(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_Vers2(p_rec.agroup_id, p_rec.id2, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and util_pkg.check_bit_mask2(p_unq_mode, c_unq_id1id2)
    and find_i_pid_id1id2(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    util_pkg.Raise_Obj3_NotUniq_Vers2(p_rec.agroup_id, p_rec.id1, p_rec.id2, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and util_pkg.check_bit_mask2(p_unq_mode, c_unq_dsc)
    and find_i_pid_dsc(p_rec, FALSE, p_check_only_other_ids)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_Vers(util_pkg.number_to_char(p_rec.agroup_id), p_rec.dsc, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and util_pkg.check_bit_mask2(p_unq_mode, c_unq_dsc_ic)
    and find_i_pid_dsc(p_rec, TRUE, p_check_only_other_ids)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_Vers(util_pkg.number_to_char(p_rec.agroup_id), p_rec.dsc, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_i(p_rec agroup_data%rowtype, p_unq_mode integer)
is
begin
  ------------------------------
  XCheck_Num_As_Mode_Invalid(p_unq_mode, 'p_unq_mode');
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
  xunique_i(p_rec, p_unq_mode, FALSE);
  ------------------------------
  insert into agroup_data
  values p_rec;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure close_i(p_rec agroup_data%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
update /*+ index_asc(z, I_AGROUP_DATA_ID)*/
  agroup_data z
  set
    date_to = p_rec.date_to,
    user_id = p_rec.user_id,
    change_date = p_rec.change_date
  where 1 = 1
  and agroup_data_id = p_rec.agroup_data_id
  and p_rec.date_to between date_from and date_to
  and date_from = p_rec.date_from
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_Vers2(p_rec.agroup_data_id, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_OnDate2(p_rec.agroup_data_id, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure delete_i(p_rec agroup_data%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
delete /*+ index_asc(z, I_AGROUP_DATA_ID)*/
  agroup_data z
  where 1 = 1
  and agroup_data_id = p_rec.agroup_data_id
  and p_rec.date_to between date_from and date_to
  and date_from = p_rec.date_from
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_Vers2(p_rec.agroup_data_id, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_OnDate2(p_rec.agroup_data_id, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_i(p_rec agroup_data%rowtype, p_unq_mode integer)
is
  v_cnt number;
begin
  ------------------------------
  XCheck_Num_As_Mode_Invalid(p_unq_mode, 'p_unq_mode');
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
  xunique_i(p_rec, p_unq_mode, TRUE);
  ------------------------------
update /*+ index_asc(z, I_AGROUP_DATA_ID)*/
  agroup_data z
  set
    id1 = p_rec.id1,
    id2 = p_rec.id2,
    date1 = p_rec.date1,
    dsc = p_rec.dsc,
    user_id = p_rec.user_id,
    change_date = p_rec.change_date,
    num3 = p_rec.num3,
    str2 = p_rec.str2
  where 1 = 1
  and agroup_data_id = p_rec.agroup_data_id
  and p_rec.date_to between date_from and date_to
  and date_from = p_rec.date_from
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_Vers2(p_rec.agroup_data_id, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_OnDate2(p_rec.agroup_data_id, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_identified(p_rec agroup_data%rowtype) return boolean
is
begin
  ------------------------------
  return (p_rec.agroup_data_id is not null);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_present_id1(p_pid number, p_id1 number, p_date_from date, p_date_to date) return boolean
is
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_id1 is null, 'p_id1');
  util_pkg.XCheck_Cond_Missing(p_date_from is null, 'p_date_from');
  util_pkg.XCheck_Cond_Missing(p_date_to is null, 'p_date_to');
  ------------------------------
  v_rec.agroup_id := p_pid;
  v_rec.id1 := p_id1;
  v_rec.date_from := p_date_from;
  v_rec.date_to := p_date_to;
  ------------------------------
  return find_i_pid_id1(p_rec => v_rec, p_check_only_other_ids => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_present_id2(p_pid number, p_id2 number, p_date_from date, p_date_to date) return boolean
is
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_id2 is null, 'p_id2');
  util_pkg.XCheck_Cond_Missing(p_date_from is null, 'p_date_from');
  util_pkg.XCheck_Cond_Missing(p_date_to is null, 'p_date_to');
  ------------------------------
  v_rec.agroup_id := p_pid;
  v_rec.id2 := p_id2;
  v_rec.date_from := p_date_from;
  v_rec.date_to := p_date_to;
  ------------------------------
  return find_i_pid_id2(p_rec => v_rec, p_check_only_other_ids => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_present_id1id2(p_pid number, p_id1 number, p_id2 number, p_date_from date, p_date_to date) return boolean
is
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_id1 is null, 'p_id1');
  util_pkg.XCheck_Cond_Missing(p_id2 is null, 'p_id2');
  util_pkg.XCheck_Cond_Missing(p_date_from is null, 'p_date_from');
  util_pkg.XCheck_Cond_Missing(p_date_to is null, 'p_date_to');
  ------------------------------
  v_rec.agroup_id := p_pid;
  v_rec.id1 := p_id1;
  v_rec.id2 := p_id2;
  v_rec.date_from := p_date_from;
  v_rec.date_to := p_date_to;
  ------------------------------
  return find_i_pid_id1id2(p_rec => v_rec, p_check_only_other_ids => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_present_dsc(p_pid number, p_dsc varchar2, p_date_from date, p_date_to date, p_ignore_case boolean) return boolean
is
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pid is null, 'p_pid');
  util_pkg.XCheck_Cond_Missing(p_dsc is null, 'p_dsc');
  util_pkg.XCheck_Cond_Missing(p_date_from is null, 'p_date_from');
  util_pkg.XCheck_Cond_Missing(p_date_to is null, 'p_date_to');
  util_pkg.XCheck_Cond_Missing(p_ignore_case is null, 'p_ignore_case');
  ------------------------------
  v_rec.agroup_id := p_pid;
  v_rec.dsc := p_dsc;
  v_rec.date_from := p_date_from;
  v_rec.date_to := p_date_to;
  ------------------------------
  return find_i_pid_dsc(p_rec => v_rec, p_ignore_case => p_ignore_case, p_check_only_other_ids => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function acquire_id return number
is
begin
  ------------------------------
  return sq_agroup_data.nextval;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_open(p_rec in out nocopy agroup_data%rowtype, p_unq_mode integer)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  XCheck_Num_As_Mode_Invalid(p_unq_mode, 'p_unq_mode');
  ------------------------------
  p_rec.agroup_data_id := nvl(p_rec.agroup_data_id, acquire_id);
  ------------------------------
  p_rec.date_from := nvl(p_rec.date_from, v_sysdate);
  p_rec.date_to := nvl(p_rec.date_to, util_pkg.c_open_date_to);
  ------------------------------
  p_rec.change_date := v_sysdate;
  ------------------------------
  p_rec.id1 := nvl(p_rec.id1, c_not_defined_id);
  p_rec.id2 := nvl(p_rec.id2, c_not_defined_id);
  p_rec.num3 := nvl(p_rec.num3, c_not_defined_id);
  ------------------------------
  open_i(p_rec, p_unq_mode);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change(p_rec in out nocopy agroup_data%rowtype, p_unq_mode integer)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_to_prev date;
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.agroup_data_id is null, 'p_rec.agroup_data_id');
  XCheck_Num_As_Mode_Invalid(p_unq_mode, 'p_unq_mode');
  ------------------------------
  p_rec.date_from := nvl(p_rec.date_from, v_sysdate);
  p_rec.date_to := nvl(p_rec.date_to, util_pkg.c_open_date_to);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(p_rec.date_from);
  ------------------------------
  v_rec := xlock_xget1(p_rec.agroup_data_id, v_date_to_prev);
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.user_id := p_rec.user_id;
  ------------------------------
  v_rec.change_date := v_sysdate;
  v_rec.date_to := v_date_to_prev;
  ------------------------------
  close_i(v_rec);
  ------------------------------
  p_rec.change_date := v_sysdate;
  ------------------------------
  open_i(p_rec, p_unq_mode);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_touch(p_rec in out nocopy agroup_data%rowtype, p_unq_mode integer)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_on date;
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.agroup_data_id is null, 'p_rec.agroup_data_id');
  XCheck_Num_As_Mode_Invalid(p_unq_mode, 'p_unq_mode');
  ------------------------------
  p_rec.date_from := nvl(p_rec.date_from, v_sysdate);
  p_rec.date_to := nvl(p_rec.date_to, util_pkg.c_open_date_to);
  ------------------------------
  v_date_on := p_rec.date_from;
  ------------------------------
  v_rec := xlock_xget1(p_rec.agroup_data_id, v_date_on);
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.id1 := p_rec.id1;
  v_rec.id2 := p_rec.id2;
  v_rec.date1 := p_rec.date1;
  v_rec.dsc := p_rec.dsc;
  v_rec.num3 := p_rec.num3;
  v_rec.str2 := p_rec.str2;
  ------------------------------
  v_rec.user_id := p_rec.user_id;
  ------------------------------
  v_rec.change_date := v_sysdate;
  ------------------------------
  touch_i(v_rec, p_unq_mode);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_touch_date1
(
  p_id integer,
  p_user_id integer,
  p_date1 date,
  p_date date
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date date;
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_date1 is null, 'p_date1');
  --!_!util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_date := nvl(p_date, v_sysdate);
  ------------------------------
  v_rec := xlock_xget1(p_id, v_date);
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.date1 := p_date1;
  ------------------------------
  v_rec.user_id := p_user_id;
  ------------------------------
  v_rec.change_date := v_sysdate;
  ------------------------------
  version_touch(v_rec, c_unq_none);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close
(
    p_id integer,
    p_user_id integer,
    p_date_from date := null, --!_!for p_hard_delete: p_date_from = v_rec.date_from (p_id = v_rec.table_name_id)
    p_hard_delete boolean := false
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_to_prev date;
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_hard_delete is null, 'p_hard_delete');
  util_pkg.XCheck_Cond_Missing(p_hard_delete and p_date_from is null, 'p_date_from');
  ------------------------------
  if p_hard_delete
  then
    ------------------------------
    v_date_to_prev := p_date_from;
    ------------------------------
  else
    ------------------------------
    v_date_to_prev := util_pkg.date_from2date_to_prev(nvl(p_date_from, v_sysdate));
    ------------------------------
  end if;
  ------------------------------
  v_rec := xlock_xget1(p_id, v_date_to_prev);
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.user_id := p_user_id;
  ------------------------------
  v_rec.change_date := v_sysdate;
  v_rec.date_to := v_date_to_prev;
  ------------------------------
  if p_hard_delete
  then
    delete_i(v_rec);
  else
    close_i(v_rec);
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open_N(p_items in out nocopy rct_agroup_data, p_unq_mode number)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_error_code number;
  v_error_message varchar2(4000);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  XCheck_Num_As_Mode_Invalid(p_unq_mode, 'p_unq_mode');
  ------------------------------
  v_main_count := get_count_rct_agroup_data(p_items);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    version_open(p_items(v_i), p_unq_mode);
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(v_error_code, v_error_message);
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.raise_exception(v_error_code, v_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_open_N2(p_items in out nocopy ct_agroup_data, p_unq_mode number)
is
  v_items rct_agroup_data;
begin
  ------------------------------
  v_items := cast_ct2rct_agroup_data(p_items);
  ------------------------------
  version_open_N(v_items, p_unq_mode);
  ------------------------------
  p_items := cast_rct2ct_agroup_data(v_items);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_touch_N(p_items in out nocopy rct_agroup_data, p_unq_mode number)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_error_code number;
  v_error_message varchar2(4000);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  XCheck_Num_As_Mode_Invalid(p_unq_mode, 'p_unq_mode');
  ------------------------------
  v_main_count := get_count_rct_agroup_data(p_items);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    version_touch(p_items(v_i), p_unq_mode);
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(v_error_code, v_error_message);
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.raise_exception(v_error_code, v_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_touch_N2(p_items in out nocopy ct_agroup_data, p_unq_mode number)
is
  v_items rct_agroup_data;
begin
  ------------------------------
  v_items := cast_ct2rct_agroup_data(p_items);
  ------------------------------
  version_touch_N(v_items, p_unq_mode);
  ------------------------------
  p_items := cast_rct2ct_agroup_data(v_items);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_touch_date1_N
(
  p_ids ct_number,
  p_date1s ct_date,
  p_dates ct_date,
  p_user_id integer
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_error_code number;
  v_error_message varchar2(4000);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != v_main_count, 'p_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date1s) != v_main_count, 'p_date1s.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_dates) != v_main_count, 'p_dates.count != v_main_count');
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    version_touch_date1
    (
      p_id => p_ids(v_i),
      p_user_id => p_user_id,
      p_date1 => p_date1s(v_i),
      p_date => p_dates(v_i)
    );
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(v_error_code, v_error_message);
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.raise_exception(v_error_code, v_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_touch_date1_N2
(
  p_ids ct_number,
  p_date1 date,
  p_date date,
  p_user_id integer
)
is
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  ------------------------------
  version_touch_date1_N
  (
    p_ids => p_ids,
    p_date1s => util_pkg.make_ct_date(v_main_count, p_date1),
    p_dates => util_pkg.make_ct_date(v_main_count, p_date),
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close_N
(
  p_ids ct_number,
  p_date_froms ct_date,
  p_user_id integer,
  p_hard_delete boolean := false
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_error_code number;
  v_error_message varchar2(4000);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_hard_delete is null, 'p_hard_delete');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != v_main_count, 'p_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date_froms) != v_main_count, 'p_date_froms.count != v_main_count');
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    version_close
    (
      p_id => p_ids(v_i),
      p_user_id => p_user_id,
      p_date_from => p_date_froms(v_i),
      p_hard_delete => p_hard_delete
    );
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(v_error_code, v_error_message);
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.raise_exception(v_error_code, v_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close_N2
(
  p_ids ct_number,
  p_date_from date,
  p_user_id integer,
  p_hard_delete boolean := false
)
is
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  ------------------------------
  version_close_N
  (
    p_ids => p_ids,
    p_date_froms => util_pkg.make_ct_date(v_main_count, p_date_from),
    p_user_id => p_user_id,
    p_hard_delete => p_hard_delete
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
