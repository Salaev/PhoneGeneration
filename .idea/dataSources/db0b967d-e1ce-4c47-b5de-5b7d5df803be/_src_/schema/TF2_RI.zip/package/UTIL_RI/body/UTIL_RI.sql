CREATE package body util_ri is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xget_default_user_id return number
is
begin
  ------------------------------
  return install_pkg.xget_default_user_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_user_id(p_user_id number)
is
begin
  ------------------------------
  install_pkg.xcheck_user_id(p_user_id, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_user_name(p_user_name users.login_name%type)
is
begin
  ------------------------------
  install_pkg.xcheck_user_name(p_user_name, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_user_id(p_user_id number) return number
is
begin
  ------------------------------
  return install_pkg.check_user_id(p_user_id, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_user_name(p_user_name users.login_name%type) return number
is
begin
  ------------------------------
  return install_pkg.check_user_name(p_user_name, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_user_id(p_user_name users.login_name%type) return number
is
begin
  ------------------------------
  return install_pkg.xget_user_id(p_user_name, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_user_name(p_user_id number) return users.login_name%type
is
begin
  ------------------------------
  return install_pkg.xget_user_name(p_user_id, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_id(p_user_name users.login_name%type) return number
is
begin
  ------------------------------
  return install_pkg.get_user_id(p_user_name, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_name(p_user_id number) return users.login_name%type
is
begin
  ------------------------------
  return install_pkg.get_user_name(p_user_id, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_naap_link_type_code(p_link_type_code varchar2, p_label varchar2 := null)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_link_type_code is null, util_pkg.smart_label1(p_label, 'p_link_type_code'));
  ------------------------------
  XCheck_naap_link_type_code_any(p_link_type_code, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_naap_link_type_code_any(p_link_type_code varchar2, p_label varchar2 := null)
is
begin
  ------------------------------
  if p_link_type_code is null --!_!
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_link_type_code not in (c_NAAP_LINK_TYPE_CODE_MAIN, c_NAAP_LINK_TYPE_CODE_SECOND),
    util_pkg.smart_label2(p_label, 'p_link_type_code', ' not in (c_NAAP_LINK_TYPE_CODE_MAIN, c_NAAP_LINK_TYPE_CODE_SECOND)'));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xis_main_link(p_link_type_code varchar2) return boolean
is
begin
  ------------------------------
  XCheck_naap_link_type_code(p_link_type_code);
  ------------------------------
  return p_link_type_code = c_NAAP_LINK_TYPE_CODE_MAIN;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function det_link_type_code(p_main_link boolean) return varchar2
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_main_link is null, 'p_main_link');
  ------------------------------
  if p_main_link
  then
    ------------------------------
    return c_NAAP_LINK_TYPE_CODE_MAIN;
    ------------------------------
  end if;
  ------------------------------
  return c_NAAP_LINK_TYPE_CODE_SECOND;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xget_not_available_host_id return number
is
  v_res number;
begin
  ------------------------------
  v_res := install_pkg.xget_option_num(c_opt_na_host_id);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_res is null, 'na_host_id is null');
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function valid_code2(p_code varchar2) return varchar2
is
  v_res varchar2(2);
begin
  ------------------------------
  v_res := TRIM(p_code);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function valid_date_to(p_date date) return date
is
  v_res date;
begin
  ------------------------------
  v_res := nvl(p_date, util_pkg.c_open_date_to);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function invalid_date_to2valid_date_to(p_date date) return date
is
begin
  ------------------------------
  return valid_date_to(p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function valid_date_to2invalid_date_to(p_date date) return date
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  if p_date = util_pkg.c_open_date_to
  then
    return null;
  end if;
  ------------------------------
  return p_date;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function deleted2valid_date_to(p_date date) return date
is
  v_res date;
begin
  ------------------------------
  v_res := valid_date_to(p_date - util_pkg.c_dt_dif);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function valid_date_to2deleted(p_date date) return date
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  if p_date = util_pkg.c_open_date_to
  then
    return null;
  end if;
  ------------------------------
  return p_date + util_pkg.c_dt_dif;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_date_open(p_date date) return boolean
is
begin
  ------------------------------
  if valid_date_to(p_date) = util_pkg.c_open_date_to
  then
    return true;
  end if;
  ------------------------------
  return false;
  ------------------------------
end;


----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function split_str_list(p_str_list varchar2, p_null_str_is_empty_list boolean) return ct_varchar_s
is
begin
  ------------------------------
  return util_pkg.cast_ct_varchar2varchar_s(split_str_list2(p_str_list, p_null_str_is_empty_list), true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function split_str_list2(p_str_list varchar2, p_null_str_is_empty_list boolean) return ct_varchar
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_null_str_is_empty_list is null, 'p_null_str_is_empty_list');
  ------------------------------
  if 1 = 1
    and p_null_str_is_empty_list
    and p_str_list is null
  then
    ------------------------------
    return NULL;
    ------------------------------
  end if;
  ------------------------------
  return util_pkg.split_string(p_str_list, c_list_delimiter, util_pkg.c_def_trimed_chars);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function split_nstr_list(p_str_list nvarchar2, p_null_str_is_empty_list boolean) return ct_nvarchar_s
is
begin
  ------------------------------
  return util_pkg.cast_ct_nvarchar2nvarchar_s(split_nstr_list2(p_str_list, p_null_str_is_empty_list), true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function split_nstr_list2(p_str_list nvarchar2, p_null_str_is_empty_list boolean) return ct_nvarchar
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_null_str_is_empty_list is null, 'p_null_str_is_empty_list');
  ------------------------------
  if 1 = 1
    and p_null_str_is_empty_list
    and p_str_list is null
  then
    ------------------------------
    return NULL;
    ------------------------------
  end if;
  ------------------------------
  return util_pkg.split_nstring(p_str_list, util_pkg.char_to_nchar(c_list_delimiter), util_pkg.c_def_trimed_nchars);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function merge_str_list(p_coll_list ct_varchar_s) return varchar2
is
begin
  ------------------------------
  return merge_str_list2(util_pkg.cast_ct_varchar_s2varchar(p_coll_list));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function merge_str_list2(p_coll_list ct_varchar) return varchar2
is
begin
  ------------------------------
  return util_pkg.merge_string(p_coll_list, util_pkg.char_to_nchar(c_list_delimiter));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function merge_nstr_list(p_coll_list ct_nvarchar_s) return nvarchar2
is
begin
  ------------------------------
  return merge_nstr_list2(util_pkg.cast_ct_nvarchar_s2nvarchar(p_coll_list));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function merge_nstr_list2(p_coll_list ct_nvarchar) return nvarchar2
is
begin
  ------------------------------
  return util_pkg.merge_nstring(p_coll_list, util_pkg.char_to_nchar(c_list_delimiter));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function sid_serial2varchar(p_sid number, p_serial number) return varchar2
is
begin
  ------------------------------
  return util_pkg.number_to_char(p_sid) || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_serial);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure varchar2sid_serial(p_value varchar2, p_sid out number, p_serial out number)
is
  v_recs ct_varchar;
begin
  ------------------------------
  v_recs := util_pkg.split_string(p_value, util_pkg.c_msg_delim02);
  ------------------------------
  util_pkg.XCheckP_ct_varchar(v_recs, 'v_recs');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_recs) <> 2, 'v_recs.count <> 2');
  ------------------------------
  p_sid := util_pkg.char_to_number(v_recs(v_recs.first));
  p_serial := util_pkg.char_to_number(v_recs(v_recs.last));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function cast_cit_arrays2ct_identity(p_rec_ids util_pkg.cit_number, p_record_ids util_pkg.cit_number, p_record_codes util_pkg.cit_varchar) return ct_identity
is
  v_res ct_identity;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_cit_number(p_rec_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_cit_number(p_rec_ids) != v_main_count, 'p_rec_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_cit_number(p_record_ids) != v_main_count, 'p_record_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_cit_varchar(p_record_codes) != v_main_count, 'p_record_codes.count != v_main_count');
  ------------------------------
  if NOT util_pkg.CheckP_cit_number(p_rec_ids, true)
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_identity();
  v_res.extend(v_main_count);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := ot_identity(p_rec_ids(v_i), p_record_ids(v_i), p_record_codes(v_i), null, util_pkg.c_ora_ok, null);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_arrays2ct_identity(p_rec_ids util_pkg.cit_number, p_record_ids util_pkg.cit_number) return ct_identity
is
  v_res ct_identity;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_cit_number(p_rec_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_cit_number(p_rec_ids) != v_main_count, 'p_rec_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_cit_number(p_record_ids) != v_main_count, 'p_record_ids.count != v_main_count');
  ------------------------------
  if NOT util_pkg.CheckP_cit_number(p_rec_ids, true)
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_identity();
  v_res.extend(v_main_count);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := ot_identity(p_rec_ids(v_i), p_record_ids(v_i), null, null, util_pkg.c_ora_ok, null);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function cast_ct_array2ct_sys_item
(
  p_sys_rec_ids ct_number,
  p_sys_type_codes ct_varchar_s,
  p_sys_error_codes ct_number,
  p_sys_error_messages ct_varchar,
  p_sys_ids ct_number,
  p_sys_codes ct_varchar_s,
  p_sys_names ct_nvarchar
) return ct_sys_item
is
  v_res ct_sys_item;
begin
  ------------------------------
  select /*+ ordered use_hash(q2 q3 q4 q5 q6 q7) full(q1) full(q2) full(q3) full(q4) full(q5) full(q6) full(q7)*/
    ot_sys_item
    (
      q1.sys_item_id,
      q2.sys_type_code,
      q3.sys_error_code,
      q4.sys_error_message,
      q5.sys_id,
      q6.sys_code,
      q7.sys_name
    )
    bulk collect into v_res
    from
      (select column_value sys_item_id, rownum rn from table(p_sys_rec_ids)) q1,
      (select column_value sys_type_code, rownum rn from table(p_sys_type_codes)) q2,
      (select column_value sys_error_code, rownum rn from table(p_sys_error_codes)) q3,
      (select column_value sys_error_message, rownum rn from table(p_sys_error_messages)) q4,
      (select column_value sys_id, rownum rn from table(p_sys_ids)) q5,
      (select column_value sys_code, rownum rn from table(p_sys_codes)) q6,
      (select column_value sys_name, rownum rn from table(p_sys_names)) q7
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    and q4.rn(+) = q1.rn
    and q5.rn(+) = q1.rn
    and q6.rn(+) = q1.rn
    and q7.rn(+) = q1.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_array2ct_sys_item11
(
  p_sys_type_codes ct_varchar_s,
  p_sys_error_codes ct_number,
  p_sys_error_messages ct_varchar,
  p_sys_ids ct_number,
  p_sys_codes ct_varchar_s,
  p_sys_names ct_nvarchar
) return ct_sys_item
is
  v_main_count number;
  v_sys_rec_ids ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_sys_ids); --!_!
  ------------------------------
  v_sys_rec_ids := util_pkg.make_pivot(v_main_count);
  ------------------------------
  return cast_ct_array2ct_sys_item
  (
    p_sys_rec_ids => v_sys_rec_ids,
    p_sys_type_codes => p_sys_type_codes,
    p_sys_error_codes => p_sys_error_codes,
    p_sys_error_messages => p_sys_error_messages,
    p_sys_ids => p_sys_ids,
    p_sys_codes => p_sys_codes,
    p_sys_names => p_sys_names
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_array2ct_sys_item12
(
  p_sys_type_codes ct_varchar_s,
  p_sys_error_codes ct_number,
  p_sys_error_messages ct_varchar,
  p_sys_ids ct_number,
  p_sys_codes ct_varchar_s
) return ct_sys_item
is
begin
  ------------------------------
  return cast_ct_array2ct_sys_item11
  (
    p_sys_type_codes => p_sys_type_codes,
    p_sys_error_codes => p_sys_error_codes,
    p_sys_error_messages => p_sys_error_messages,
    p_sys_ids => p_sys_ids,
    p_sys_codes => p_sys_codes,
    p_sys_names => NULL
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_array2ct_sys_item2
(
  p_sys_rec_ids ct_number,
  p_sys_type_code varchar2,
  p_sys_error_codes ct_number,
  p_sys_error_messages ct_varchar,
  p_sys_ids ct_number,
  p_sys_codes ct_varchar_s,
  p_sys_names ct_nvarchar
) return ct_sys_item
is
  v_main_count number;
  v_sys_type_codes ct_varchar_s;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_sys_rec_ids);
  ------------------------------
  v_sys_type_codes := util_pkg.make_ct_varchar_s(v_main_count, p_sys_type_code);
  ------------------------------
  return cast_ct_array2ct_sys_item
  (
    p_sys_rec_ids => p_sys_rec_ids,
    p_sys_type_codes => v_sys_type_codes,
    p_sys_error_codes => p_sys_error_codes,
    p_sys_error_messages => p_sys_error_messages,
    p_sys_ids => p_sys_ids,
    p_sys_codes => p_sys_codes,
    p_sys_names => p_sys_names
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_array2ct_sys_item21
(
  p_sys_type_code varchar2,
  p_sys_error_codes ct_number,
  p_sys_error_messages ct_varchar,
  p_sys_ids ct_number,
  p_sys_codes ct_varchar_s,
  p_sys_names ct_nvarchar
) return ct_sys_item
is
  v_main_count number;
  v_sys_rec_ids ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_sys_ids); --!_!
  ------------------------------
  v_sys_rec_ids := util_pkg.make_pivot(v_main_count);
  ------------------------------
  return cast_ct_array2ct_sys_item2
  (
    p_sys_rec_ids => v_sys_rec_ids,
    p_sys_type_code => p_sys_type_code,
    p_sys_error_codes => p_sys_error_codes,
    p_sys_error_messages => p_sys_error_messages,
    p_sys_ids => p_sys_ids,
    p_sys_codes => p_sys_codes,
    p_sys_names => p_sys_names
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_array2ct_sys_item3
(
  p_sys_rec_ids ct_number,
  p_sys_type_code varchar2,
  p_sys_error_codes ct_number,
  p_sys_error_messages ct_varchar,
  p_sys_ids ct_number,
  p_sys_codes ct_varchar_s
) return ct_sys_item
is
begin
  ------------------------------
  return cast_ct_array2ct_sys_item2
  (
    p_sys_rec_ids => p_sys_rec_ids,
    p_sys_type_code => p_sys_type_code,
    p_sys_error_codes => p_sys_error_codes,
    p_sys_error_messages => p_sys_error_messages,
    p_sys_ids => p_sys_ids,
    p_sys_codes => p_sys_codes,
    p_sys_names => NULL
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_array2ct_sys_item31
(
  p_sys_type_code varchar2,
  p_sys_error_codes ct_number,
  p_sys_error_messages ct_varchar,
  p_sys_ids ct_number,
  p_sys_codes ct_varchar_s
) return ct_sys_item
is
  v_main_count number;
  v_sys_rec_ids ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_sys_ids); --!_!
  ------------------------------
  v_sys_rec_ids := util_pkg.make_pivot(v_main_count);
  ------------------------------
  return cast_ct_array2ct_sys_item3
  (
    p_sys_rec_ids => v_sys_rec_ids,
    p_sys_type_code => p_sys_type_code,
    p_sys_error_codes => p_sys_error_codes,
    p_sys_error_messages => p_sys_error_messages,
    p_sys_ids => p_sys_ids,
    p_sys_codes => p_sys_codes
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ct_host_lac_bs(p_coll ct_host_lac_bs) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure aggregate_results(p_records ct_identity, p_error_code out number, p_error_message out varchar2)
is
  v_cnt number;
begin
  ------------------------------
  select count(1)
    into v_cnt
    from table(p_records) t
   where t.error_code <> util_pkg.c_ora_ok;
  ------------------------------
  if (v_cnt = 0)
  then
    p_error_code := util_pkg.c_ora_ok;
    p_error_message := util_pkg.c_msg_ok;
  else
    p_error_code := util_pkg.c_ora_x_common;
    p_error_message := util_pkg.c_msg_x_common;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure aggregate_results02(p_error_codes ct_number, p_error_code out number, p_error_message out varchar2)
is
  v_cnt number;
begin
  ------------------------------
  select count(1)
    into v_cnt
    from table(p_error_codes) t
   where t.column_value <> util_pkg.c_ora_ok;
  ------------------------------
  if (v_cnt = 0)
  then
    util_pkg.set_ok(p_error_code, p_error_message);
  else
    p_error_code := util_pkg.c_ora_x_common;
    p_error_message := util_pkg.c_msg_x_common;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function check_na_id0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_show_not_found is null, 'p_show_not_found');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_id) != v_main_count, 'p_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_PHONE_NUMBER)*/
  z.network_address_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value network_address_id, rownum rn from table(p_na_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    phone_number z
  where 1 = 1
  and q2.rn = q.rn
  and z.network_address_id = q.network_address_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'phone_number');
    ------------------------------
  end if;
  ------------------------------
  if p_show_not_found
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_rn := util_pkg.filter_ct_number(v_tmp_rn, v_tmp_rn, v_rn, FALSE);
    ------------------------------
  end if;
  ------------------------------
  v_res := util_pkg.get_by_pos2_ct_number(p_na_id, v_rn, p_trim_empty);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_na_id(p_na_id ct_number, p_date date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_na_id), p_date);
  ------------------------------
  return check_na_id0(p_na_id, v_date, p_trim_empty, p_show_not_found, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_na_id2(p_na_id number, p_date date, p_show_not_found boolean) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return check_na_id(v_na_id, p_date, FALSE, p_show_not_found)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_msisdn(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
select /*+ ordered use_nl(q, z) index_asc(z, PK_PHONE_NUMBER)*/
  z.international_format, q.rn
  bulk collect into v_res, v_rn
  from (select column_value network_address_id, rownum rn from table(p_na_id)) q, phone_number z
  where 1 = 1
  and z.network_address_id(+) = q.network_address_id
  and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.network_address_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'phone_number');
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_msisdn2(p_na_id number, p_date date) return varchar2
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_msisdn(v_na_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_id0(p_msisdn ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdn);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdn) != v_main_count, 'p_msisdn.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, UK_PHONE_NUM_PHONE_NUMBER)*/
  z.network_address_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value msisdn, rownum rn from table(p_msisdn)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    phone_number z
  where 1 = 1
  and q2.rn = q.rn
  and z.international_format = q.msisdn
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'phone_number');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_id(p_msisdn ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_msisdn));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_na_id0(p_msisdn, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_id2(p_msisdn varchar2, p_date date) return number
is
  v_msisdn ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_msisdn, p_msisdn);
  ------------------------------
  return get_na_id(v_msisdn, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function qwerty_get_na_id_last(p_msisdn ct_varchar_s, p_view_date date, p_trim_empty boolean) return ct_number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_view_date is null, 'p_view_date');
  ------------------------------
  util_loc_pkg.touch_date(p_view_date);
  ------------------------------
  return get_na_id(p_msisdn, util_pkg.c_minus_infinity, p_trim_empty); --!_! fake last record in history on p_view_date
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_status0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_id) != v_main_count, 'p_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, I_NETADSTAHI_NETWORK_ADDRES_I2)*/
  valid_code2(z.net_address_status_code), q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value network_address_id, rownum rn from table(p_na_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    network_address_status_history z
  where 1 = 1
  and q2.rn = q.rn
  and z.network_address_id = q.network_address_id
  and q2.validity_date between z.start_date and nvl(z.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'network_address_status_history');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_status(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_na_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_na_status0(p_na_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_status2(p_na_id number, p_date date) return varchar2
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_na_status(v_na_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_status_max_date_from0(p_na_id ct_number, p_status ct_varchar_s, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_date
is
  v_res ct_date;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_id) != v_main_count, 'p_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_status) != v_main_count, 'p_status.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select
  start_date, rn
  bulk collect into v_res, v_rn
  from
  (
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, I_NETADSTAHI_NETWORK_ADDRES_I2)*/
  z.start_date, q.rn,
  row_number() over (partition by q.network_address_id order by z.start_date DESC) rrnn
  from
    (select column_value network_address_id, rownum rn from table(p_na_id)) q,
    (select rpad(column_value, 2, ' ') status, rownum rn from table(p_status)) q2, --!_!f...g char
    network_address_status_history z
  where 1 = 1
  and q2.rn = q.rn
  and z.network_address_id = q.network_address_id
  and z.net_address_status_code = q2.status
  )
  where 1 = 1
  and rrnn = 1
  order by rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'network_address_status_history');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_date(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_status_max_date_from(p_na_id ct_number, p_status varchar2, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_date
is
  v_status ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_status := util_pkg.make_ct_varchar_s(util_pkg.get_count_ct_number(p_na_id), p_status);
  ------------------------------
  return get_na_status_max_date_from0(p_na_id, v_status, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_status_max_date_from2(p_na_id number, p_status varchar2) return date
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_na_status_max_date_from(v_na_id, p_status, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_pns_id0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_id) != v_main_count, 'p_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_PHONE_NUMBER)*/
  z.phone_number_series_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value network_address_id, rownum rn from table(p_na_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    phone_number z
  where 1 = 1
  and q2.rn = q.rn
  and z.network_address_id = q.network_address_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'phone_number');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_pns_id(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_na_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_na_pns_id0(p_na_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_pns_id2(p_na_id number, p_date date) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_na_pns_id(v_na_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_host_id0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_pns_id ct_number;
begin
  ------------------------------
  v_pns_id := get_na_pns_id0(p_na_id, p_date, FALSE, p_xcheck_data);
  ------------------------------
  return get_pns_host_id0(v_pns_id, p_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_host_id(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_na_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_na_host_id0(p_na_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_host_id2(p_na_id number, p_date date) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_na_host_id(v_na_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_type0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_pns_id ct_number;
begin
  ------------------------------
  v_pns_id := get_na_pns_id0(p_na_id, p_date, FALSE, p_xcheck_data);
  ------------------------------
  return get_pns_type0(v_pns_id, p_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_type(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_na_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_na_type0(p_na_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_type2(p_na_id number, p_date date) return varchar2
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_na_type(v_na_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_linked_ap_id0(p_na_id ct_number, p_link_type_code varchar2, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_link_type_code char(2) := p_link_type_code; --!_! network_address_access_point.link_type_code%type; fucking char
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(p_link_type_code is null, 'p_link_type_code'); --!_!c_NAAP_LINK_TYPE_CODE_ANYDUMMY
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_id) != v_main_count, 'p_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered no_expand use_hash(q2) use_nl(z) index_asc(z, I_NETADDRACCPO_NET_ADDRESS_ID2)*/
  z.access_point_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value network_address_id, rownum rn from table(p_na_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    network_address_access_point z
  where 1 = 1
  and q2.rn = q.rn
  and z.network_address_id = q.network_address_id
  and q2.validity_date between z.from_date and nvl(z.to_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  and z.link_type_code = nvl(v_link_type_code, z.link_type_code)
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'network_address_access_point');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_linked_ap_id(p_na_id ct_number, p_link_type_code varchar2, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(p_link_type_code is null, 'p_link_type_code'); --!_!c_NAAP_LINK_TYPE_CODE_ANYDUMMY
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_na_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_linked_ap_id0(p_na_id, p_link_type_code, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_linked_ap_id2(p_na_id number, p_link_type_code varchar2, p_date date) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_linked_ap_id(v_na_id, p_link_type_code, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_pns_host_id0(p_pns_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_pns_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_pns_id) != v_main_count, 'p_pns_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_PHONE_NUMBER_SERIES)*/
  z.host_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value phone_number_series_id, rownum rn from table(p_pns_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    phone_number_series z
  where 1 = 1
  and q2.rn = q.rn
  and z.phone_number_series_id = q.phone_number_series_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'phone_number_series');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pns_host_id(p_pns_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_pns_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_pns_host_id0(p_pns_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pns_host_id2(p_pns_id number, p_date date) return number
is
  v_pns_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_pns_id, p_pns_id);
  ------------------------------
  return get_pns_host_id(v_pns_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pns_subhost_id0(p_pns_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_pns_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_pns_id) != v_main_count, 'p_pns_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_PHONE_NUMBER_SERIES)*/
  z.subhost_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value phone_number_series_id, rownum rn from table(p_pns_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    phone_number_series z
  where 1 = 1
  and q2.rn = q.rn
  and z.phone_number_series_id = q.phone_number_series_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'phone_number_series');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pns_subhost_id(p_pns_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_pns_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_pns_subhost_id0(p_pns_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pns_subhost_id2(p_pns_id number, p_date date) return number
is
  v_pns_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_pns_id, p_pns_id);
  ------------------------------
  return get_pns_subhost_id(v_pns_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pns_type0(p_pns_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_pns_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_pns_id) != v_main_count, 'p_pns_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_PHONE_NUMBER_SERIES)*/
  z.phone_number_type_code, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value phone_number_series_id, rownum rn from table(p_pns_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    phone_number_series z
  where 1 = 1
  and q2.rn = q.rn
  and z.phone_number_series_id = q.phone_number_series_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'phone_number_series');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pns_type(p_pns_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_pns_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_pns_type0(p_pns_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pns_type2(p_pns_id number, p_date date) return varchar2
is
  v_pns_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_pns_id, p_pns_id);
  ------------------------------
  return get_pns_type(v_pns_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_na_status_current(p_na_id ct_number, p_date date, p_trim_empty boolean, p_pn_status out ct_varchar_s, p_date_of_status_change out ct_date, p_xcheck_data boolean := true)
is
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_id) != v_main_count, 'p_na_id.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_nl(z) full(q) index_asc(z, PK_PHONE_NUMBER)*/
  valid_code2(z.net_address_status_code), z.date_of_status_change, q.rn
  bulk collect into p_pn_status, p_date_of_status_change, v_rn
  from
    (select column_value network_address_id, rownum rn from table(p_na_id)) q,
    phone_number z
  where 1 = 1
  and z.network_address_id = q.network_address_id
  and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'phone_number');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    p_pn_status := util_pkg.join2pivot_ct_varchar_s(p_pn_status, v_tmp_rn, v_rn);
    p_date_of_status_change := util_pkg.join2pivot_ct_date(p_date_of_status_change, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_status_current1(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_status ct_varchar_s;
  v_date_of_status_change ct_date;
begin
  ------------------------------
  get_na_status_current(p_na_id, p_date, p_trim_empty, v_status, v_date_of_status_change, p_xcheck_data);
  ------------------------------
  return v_status;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_na_status_current2(p_na_id number, p_date date, p_pn_status out varchar2, p_date_of_status_change out date)
is
  v_na_id ct_number;
  v_status ct_varchar_s;
  v_date_of_status_change ct_date;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  get_na_status_current(v_na_id, p_date, FALSE, v_status, v_date_of_status_change);
  ------------------------------
  p_pn_status := v_status(c_index_one);
  p_date_of_status_change := v_date_of_status_change(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_sel_cat_current(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
  v_res ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_id) != v_main_count, 'p_na_id.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_nl(z) full(q) index_asc(z, PK_PHONE_NUMBER)*/
  valid_code2(z.salability_category_code), q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value network_address_id, rownum rn from table(p_na_id)) q,
    phone_number z
  where 1 = 1
  and z.network_address_id = q.network_address_id
  and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'phone_number');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_sel_cat_current2(p_na_id number, p_date date) return varchar2
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_na_sel_cat_current(v_na_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_na_by_pns(p_pns_id number, p_date date) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pns_id is null, 'p_pns_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ index(z I_PHONENUM_PNS_ID_EXT)*/
      network_address_id
    bulk collect into v_res
    from phone_number z
    where 1 = 1
    and phone_number_series_id = p_pns_id
    and nvl(deleted,to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > p_date
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function check_ap_id0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_show_not_found is null, 'p_show_not_found');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ap_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ap_id) != v_main_count, 'p_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_SIM_CARD)*/
  z.access_point_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value access_point_id, rownum rn from table(p_ap_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_card z
  where 1 = 1
  and q2.rn = q.rn
  and z.access_point_id = q.access_point_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_card');
    ------------------------------
  end if;
  ------------------------------
  if p_show_not_found
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_rn := util_pkg.filter_ct_number(v_tmp_rn, v_tmp_rn, v_rn, FALSE);
    ------------------------------
  end if;
  ------------------------------
  v_res := util_pkg.get_by_pos2_ct_number(p_ap_id, v_rn, p_trim_empty);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_ap_id(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_ap_id), p_date);
  ------------------------------
  return check_ap_id0(p_ap_id, v_date, p_trim_empty, p_show_not_found, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_ap_id2(p_ap_id number, p_date date, p_show_not_found boolean) return number
is
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  return check_ap_id(v_ap_id, p_date, FALSE, p_show_not_found)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_iccid_imsi(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_iccid out ct_varchar_s, p_imsi out ct_varchar_s, p_xcheck_data boolean := true)
is
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
select /*+ ordered use_nl(q, z) index_asc(z, PK_SIM_CARD)*/
  z.sn, z.imsi, q.rn
  bulk collect into p_iccid, p_imsi, v_rn
  from (select column_value access_point_id, rownum rn from table(p_ap_id)) q, sim_card z
  where 1 = 1
  and z.access_point_id(+) = q.access_point_id
  and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.access_point_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_card');
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_iccid(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_dummy ct_varchar_s;
begin
  ------------------------------
  get_iccid_imsi(p_ap_id, p_date, p_trim_empty, v_res, v_dummy, p_xcheck_data);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_imsi(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_dummy ct_varchar_s;
begin
  ------------------------------
  get_iccid_imsi(p_ap_id, p_date, p_trim_empty, v_dummy, v_res, p_xcheck_data);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_iccid_imsi2(p_ap_id number, p_date date, p_iccid out varchar2, p_imsi out varchar2)
is
  v_ap_id ct_number;
  v_iccid ct_varchar_s;
  v_imsi ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  get_iccid_imsi(v_ap_id, p_date, FALSE, v_iccid, v_imsi);
  ------------------------------
  p_iccid := v_iccid(c_index_one);
  p_imsi := v_imsi(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_iccid2(p_ap_id number, p_date date) return varchar2
is
  v_res varchar2(50);
  v_dummy varchar2(50);
begin
  ------------------------------
  get_iccid_imsi2(p_ap_id, p_date, v_res, v_dummy);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_imsi2(p_ap_id number, p_date date) return varchar2
is
  v_res varchar2(50);
  v_dummy varchar2(50);
begin
  ------------------------------
  get_iccid_imsi2(p_ap_id, p_date, v_dummy, v_res);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_id0(p_iccid ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_iccid);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_iccid) != v_main_count, 'p_iccid.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, UK_SIM_SN)*/
  z.access_point_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value iccid, rownum rn from table(p_iccid)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_card z
  where 1 = 1
  and q2.rn = q.rn
  and z.sn = q.iccid
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_card');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_id(p_iccid ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_iccid));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ap_id0(p_iccid, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_id2(p_iccid varchar2, p_date date) return number
is
  v_iccid ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_iccid, p_iccid);
  ------------------------------
  return get_ap_id(v_iccid, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function qwerty_get_ap_id2_all(p_iccid varchar2) return ct_number
is
  v_res ct_number;
  v_ap_id number;
begin
  ------------------------------
  v_ap_id := get_ap_id2(p_iccid, util_pkg.c_minus_infinity); --!_! fake history
  ------------------------------
  util_pkg.add_ct_number_val(v_res, v_ap_id);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_own_ap_id03(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_imsi) != v_main_count, 'p_imsi.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, UK_SIM_IMSI)*/
  z.access_point_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value imsi, rownum rn from table(p_imsi)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_card z
  where 1 = 1
  and q2.rn = q.rn
  and z.imsi = q.imsi
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_card');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_own_ap_id3(p_imsi ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_imsi));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_own_ap_id03(p_imsi, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_own_ap_id4(p_imsi varchar2, p_date date) return number
is
  v_imsi ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_imsi, p_imsi);
  ------------------------------
  return get_own_ap_id3(v_imsi, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ext_ap_id03(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  --!_!p_date is not used really
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_imsi) != v_main_count, 'p_imsi.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, I_SIM_IMSI_IMSI_ACCESS_POINT)*/
  z.access_point_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value imsi, rownum rn from table(p_imsi)) q,
    --!_!(select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_imsi z
  where 1 = 1
  --!_!and q2.rn = q.rn
  and z.imsi = q.imsi
  --!_!and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_imsi');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ext_ap_id3(p_imsi ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_imsi));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ext_ap_id03(p_imsi, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ext_ap_id4(p_imsi varchar2, p_date date) return number
is
  v_imsi ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_imsi, p_imsi);
  ------------------------------
  return get_ext_ap_id3(v_imsi, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_id03(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_opt_use_sim_imsi boolean;
begin
  ------------------------------
  v_opt_use_sim_imsi := install_pkg.nnget_option_bool(c_opt_use_sim_imsi, c_def_use_sim_imsi);
  ------------------------------
  if v_opt_use_sim_imsi
  then
    ------------------------------
    return get_ext_ap_id03(p_imsi, p_date, p_trim_empty, p_xcheck_data);
    ------------------------------
  else
    ------------------------------
    return get_own_ap_id03(p_imsi, p_date, p_trim_empty, p_xcheck_data);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_id3(p_imsi ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_imsi));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ap_id03(p_imsi, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_id4(p_imsi varchar2, p_date date) return number
is
  v_imsi ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_imsi, p_imsi);
  ------------------------------
  return get_ap_id3(v_imsi, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_id05(p_iccid_without_control_digit ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_iccid_without_control_digit);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_iccid_without_control_digit) != v_main_count, 'p_iccid_without_control_digit.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, UK_SIM_SN)*/
  z.access_point_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value iccid, rownum rn from table(p_iccid_without_control_digit)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_card z
  where 1 = 1
  and q2.rn = q.rn
  and length(z.sn) like length(q.iccid) + 1
  and z.sn like q.iccid || '_'
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_card');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_id5(p_iccid_without_control_digit ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_iccid_without_control_digit));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ap_id05(p_iccid_without_control_digit, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_id6(p_iccid_without_control_digit varchar2, p_date date) return number
is
  v_iccid_without_control_digit ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_iccid_without_control_digit, p_iccid_without_control_digit);
  ------------------------------
  return get_ap_id5(v_iccid_without_control_digit, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function qwerty_get_ap_id4_all(p_imsi varchar2) return ct_number
is
  v_res ct_number;
  v_ap_id number;
begin
  ------------------------------
  v_ap_id := get_ap_id4(p_imsi, util_pkg.c_minus_infinity); --!_! fake history
  ------------------------------
  util_pkg.add_ct_number_val(v_res, v_ap_id);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_id_sim_imsi(p_imsi ct_varchar_s, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_imsi) != v_main_count, 'p_imsi.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_nl(z) index_asc(z, I_SIM_IMSI_IMSI_ACCESS_POINT)*/
  z.access_point_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value imsi, rownum rn from table(p_imsi)) q,
    --(select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_imsi z
  where 1 = 1
  --and q2.rn = q.rn
  and z.imsi = q.imsi
  --!_!and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_imsi');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

function get_ap_id_sim_imsi2(p_imsi varchar2) return number
is
  v_imsi ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_imsi, p_imsi);
  ------------------------------
  return get_ap_id_sim_imsi(v_imsi, FALSE)(c_index_one);
  ------------------------------
end;
----------------------------------!---------------------------------------------
function get_ap_id_full0(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_tmp_mark ct_number;
  v_tmp_ap1 ct_number;
  v_tmp_ap2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_imsi) != v_main_count, 'p_imsi.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_tmp_ap1 := get_ap_id0(p_imsi, p_date, FALSE, p_xcheck_data);
  v_tmp_ap2 := get_ap_id_sim_imsi(p_imsi, FALSE, p_xcheck_data);
  v_tmp_ap2 := check_ap_id0(v_tmp_ap2, p_date, FALSE, p_xcheck_data);
  v_res := util_pkg.supplement_ct_number(v_tmp_ap1, v_tmp_ap2, FALSE, null);
  ------------------------------
  if p_trim_empty
  then
    ------------------------------
    v_tmp_mark := util_pkg.mark_val_ct_number(v_res, null, util_pkg.c_false, util_pkg.c_true);
    ------------------------------
    v_res := util_pkg.get_marked_ct_number(v_res, v_tmp_mark, TRUE, util_pkg.c_true);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_id_full(p_imsi ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_imsi));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ap_id_full0(p_imsi, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_id_full2(p_imsi varchar2, p_date date) return number
is
  v_imsi ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_imsi, p_imsi);
  ------------------------------
  return get_ap_id_full(v_imsi, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_ss_id0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ap_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ap_id) != v_main_count, 'p_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_SIM_CARD)*/
  z.sim_series_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value access_point_id, rownum rn from table(p_ap_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_card z
  where 1 = 1
  and q2.rn = q.rn
  and z.access_point_id = q.access_point_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_card');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_ss_id(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_ap_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ap_ss_id0(p_ap_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_ss_id2(p_ap_id number, p_date date) return number
is
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  return get_ap_ss_id(v_ap_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_status0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ap_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ap_id) != v_main_count, 'p_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, I_ACCPOSTAHI_ACCESS_POINT_ID)*/
  valid_code2(z.access_point_status_code), q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value access_point_id, rownum rn from table(p_ap_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    access_point_status_history z
  where 1 = 1
  and q2.rn = q.rn
  and z.access_point_id = q.access_point_id
  and q2.validity_date between z.start_date and nvl(z.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) --!_! not present in index
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'access_point_status_history');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_status(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_ap_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ap_status0(p_ap_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_status2(p_ap_id number, p_date date) return varchar2
is
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  return get_ap_status(v_ap_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_pa0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ap_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ap_id) != v_main_count, 'p_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, I_APPA_AP)*/
  z.personal_account, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value access_point_id, rownum rn from table(p_ap_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    access_point_personal_account z
  where 1 = 1
  and q2.rn = q.rn
  and z.access_point_id = q.access_point_id
  and q2.validity_date between z.from_date and nvl(z.to_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'access_point_personal_account');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_pa(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_ap_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ap_pa0(p_ap_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_pa2(p_ap_id number, p_date date) return number
is
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  return get_ap_pa(v_ap_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_cur_ap_pa(p_ap_id ct_number/*!_!, p_date date*/, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_rn ct_number;
  v_date date := SYSDATE;
begin
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
select /*+ ordered use_nl(z) index_asc(z, PK_SIM_CARD)*/
  z.personal_account, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value access_point_id, rownum rn from table(p_ap_id)) q,
    sim_card z
  where 1 = 1
  and z.access_point_id(+) = q.access_point_id
  --!_!and nvl(z.deleted, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > v_date
  and nvl(z.deleted(+), v_date + c_dummy_date_shift) > v_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.access_point_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_card');
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_cur_ap_pa2(p_ap_id number/*!_!, p_date date*/) return number
is
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  return get_cur_ap_pa(v_ap_id/*!_!, p_date*/, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_host_id0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_ss_id ct_number;
begin
  ------------------------------
  v_ss_id := get_ap_ss_id0(p_ap_id, p_date, FALSE, p_xcheck_data);
  ------------------------------
  return get_ss_host_id0(v_ss_id, p_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_host_id(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_ap_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ap_host_id0(p_ap_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_host_id2(p_ap_id number, p_date date) return number
is
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  return get_ap_host_id(v_ap_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_own_ss_host_id0(p_ss_id ct_number, p_host_type_code varchar2, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_host_type_code is null, 'p_host_type_code');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ss_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ss_id) != v_main_count, 'p_ss_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z z2) full(q) index_asc(z, I_SSH_SIM_SERIES_ID) index_asc(z2, PK_HOST)*/
  z.host_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value sim_series_id, rownum rn from table(p_ss_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_series_host z,
    host z2
  where 1 = 1
  and q2.rn = q.rn
  and z.sim_series_id = q.sim_series_id
  and z2.host_id = z.host_id
  and z2.host_type_code = p_host_type_code
  and q2.validity_date between z.start_date and nvl(z.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  and nvl(z2.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_series_host');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_own_ss_host_id(p_ss_id ct_number, p_host_type_code varchar2, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_host_type_code is null, 'p_host_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_ss_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_own_ss_host_id0(p_ss_id, p_host_type_code, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_own_ss_host_id2(p_ss_id number, p_host_type_code varchar2, p_date date) return number
is
  v_ss_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ss_id, p_ss_id);
  ------------------------------
  return get_own_ss_host_id(v_ss_id, p_host_type_code, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_own_ap_host_id0(p_ap_id ct_number, p_host_type_code varchar2, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_host_type_code is null, 'p_host_type_code');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ap_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ap_id) != v_main_count, 'p_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z z2) full(q) index_asc(z, I_ACCPOHOST_ACCESS_POINT_ID) index_asc(z2, PK_HOST)*/
  z.host_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value access_point_id, rownum rn from table(p_ap_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    access_point_host z,
    host z2
  where 1 = 1
  and q2.rn = q.rn
  and z.access_point_id = q.access_point_id
  and z2.host_id = z.host_id
  and z2.host_type_code = p_host_type_code
  and q2.validity_date between z.start_date and nvl(z.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  and nvl(z2.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'access_point_host');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_own_ap_host_id(p_ap_id ct_number, p_host_type_code varchar2, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_host_type_code is null, 'p_host_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_ap_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_own_ap_host_id0(p_ap_id, p_host_type_code, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_own_ap_host_id2(p_ap_id number, p_host_type_code varchar2, p_date date) return number
is
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  return get_own_ap_host_id(v_ap_id, p_host_type_code, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_no_id0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_ss_id ct_number;
begin
  ------------------------------
  v_ss_id := get_ap_ss_id0(p_ap_id, p_date, FALSE, p_xcheck_data);
  ------------------------------
  return get_ss_network_operator0(v_ss_id, p_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_no_id(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_ap_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ap_no_id0(p_ap_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_no_id2(p_ap_id number, p_date date) return number
is
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  return get_ap_no_id(v_ap_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_type0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_ss_id ct_number;
begin
  ------------------------------
  v_ss_id := get_ap_ss_id0(p_ap_id, p_date, FALSE, p_xcheck_data);
  ------------------------------
  return get_ss_type0(v_ss_id, p_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_type(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_ap_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ap_type0(p_ap_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_type2(p_ap_id number, p_date date) return varchar2
is
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  return get_ap_type(v_ap_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_linked_na_id(p_ap_id ct_number, p_link_type_code varchar2, p_date date, p_trim_empty boolean, p_ap_id2 out ct_number, p_na_id out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := FALSE)
is
  v_link_type_code char(2) := p_link_type_code; --!_! network_address_access_point.link_type_code%type; f...g char
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_rn ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(p_link_type_code is null, 'p_link_type_code'); --!_!c_NAAP_LINK_TYPE_CODE_ANYDUMMY
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  util_pkg.XCheck_Cond_Missing(p_xcheck_unique_data is null, 'p_xcheck_unique_data');
  ------------------------------
  util_loc_pkg.touch_boolean(p_xcheck_data); --!_! no check
  ------------------------------
select /*+ ordered no_expand use_nl(q, z) full(q) index_asc(z, I_NETADDRACCPO_ACCESS_POINT_ID)*/
  q.access_point_id, z.network_address_id, q.rn
  bulk collect into p_ap_id2, p_na_id, v_rn
  from (select column_value access_point_id, rownum rn from table(p_ap_id)) q, network_address_access_point z
  where 1 = 1
  and z.access_point_id(+) = q.access_point_id
  and p_date between z.from_date(+) and nvl(z.to_date(+), to_date('01.01.4000', 'dd.mm.yyyy'))
  and z.link_type_code(+) = nvl(v_link_type_code, z.link_type_code(+))
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.access_point_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn, z.network_address_id
  ;
  ------------------------------
  if p_xcheck_unique_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'network_address_access_point');
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_linked_na_id2(p_ap_id number, p_link_type_code varchar2, p_date date, p_xcheck_unique_data boolean := FALSE) return ct_number
is
  v_res ct_number;
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  get_linked_na_id(v_ap_id, p_link_type_code, p_date, TRUE, v_ap_id, v_res, TRUE, p_xcheck_unique_data);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_linked_na_id_main(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_ap_id ct_number;
begin
  ------------------------------
  get_linked_na_id(p_ap_id, c_NAAP_LINK_TYPE_CODE_MAIN, p_date, p_trim_empty, v_ap_id, v_res, p_xcheck_data, TRUE);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_linked_na_id_main2(p_ap_id number, p_date date) return number
is
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  return get_linked_na_id_main(v_ap_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_linked_na_id_sec_no_plink(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_ap_id2 out ct_number, p_na_id out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := FALSE)
is
  v_link_type_code char(2) := c_NAAP_LINK_TYPE_CODE_SECOND; --!_! network_address_access_point.link_type_code%type; f...g char
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_na_id_l ct_number;
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  util_pkg.XCheck_Cond_Missing(p_xcheck_unique_data is null, 'p_xcheck_unique_data');
  ------------------------------
  --!_!util_loc_pkg.touch_boolean(p_xcheck_data); --!_! no check
  ------------------------------
  get_linked_na_id(p_ap_id, v_link_type_code, p_date, TRUE, p_ap_id2, p_na_id, p_xcheck_data, p_xcheck_unique_data);
  ------------------------------
  if util_pkg.get_count_ct_number(p_na_id) > 0
  then
    ------------------------------
    v_na_id_l := get_as_pnlnk_naid_l_fuzzy(p_na_id, p_date);
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered no_expand use_nl(q, z) use_hash(q2) full(q) index_asc(z, I_NETADDRACCPO_ACCESS_POINT_ID)*/
  q.access_point_id, decode(q2.network_address_id, null, z.network_address_id, null) network_address_id, q.rn
  bulk collect into p_ap_id2, p_na_id, v_rn
  from
    (select column_value access_point_id, rownum rn from table(p_ap_id)) q,
    network_address_access_point z,
    (select column_value network_address_id, rownum rn from table(v_na_id_l)) q2
  where 1 = 1
  and z.access_point_id(+) = q.access_point_id
  and p_date between z.from_date(+) and nvl(z.to_date(+), to_date('01.01.4000', 'dd.mm.yyyy'))
  --!_!and z.link_type_code(+) = nvl(v_link_type_code, z.link_type_code(+))
  and z.link_type_code(+) = v_link_type_code
  and q2.network_address_id(+) = z.network_address_id
  --!_!and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.access_point_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(decode(q2.network_address_id, null, z.network_address_id, null), null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn, network_address_id
  ;
  ------------------------------
  if p_xcheck_unique_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'network_address_access_point');
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_linked_na_id_sec_no_plink2(p_ap_id number, p_date date, p_xcheck_unique_data boolean := FALSE) return ct_number
is
  v_res ct_number;
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  get_linked_na_id_sec_no_plink(v_ap_id, p_date, TRUE, v_ap_id, v_res, TRUE, p_xcheck_unique_data);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function check_ss_id0(p_ss_id ct_number, p_date ct_date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_show_not_found is null, 'p_show_not_found');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ss_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ss_id) != v_main_count, 'p_ss_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_SIM_SERIES)*/
  z.sim_series_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value sim_series_id, rownum rn from table(p_ss_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_series z
  where 1 = 1
  and q2.rn = q.rn
  and z.sim_series_id = q.sim_series_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_series');
    ------------------------------
  end if;
  ------------------------------
  if p_show_not_found
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_rn := util_pkg.filter_ct_number(v_tmp_rn, v_tmp_rn, v_rn, FALSE);
    ------------------------------
  end if;
  ------------------------------
  v_res := util_pkg.get_by_pos2_ct_number(p_ss_id, v_rn, p_trim_empty);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_ss_id(p_ss_id ct_number, p_date date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_ss_id), p_date);
  ------------------------------
  return check_ss_id0(p_ss_id, v_date, p_trim_empty, p_show_not_found, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_ss_id2(p_ss_id number, p_date date, p_show_not_found boolean) return number
is
  v_ss_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ss_id, p_ss_id);
  ------------------------------
  return check_ss_id(v_ss_id, p_date, FALSE, p_show_not_found)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ss_host_id0(p_ss_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ss_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ss_id) != v_main_count, 'p_ss_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) full(q) index_asc(z, PK_SIM_SERIES)*/
  z.host_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value sim_series_id, rownum rn from table(p_ss_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_series z
  where 1 = 1
  and q2.rn = q.rn
  and z.sim_series_id = q.sim_series_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_series');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ss_host_id(p_ss_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_ss_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ss_host_id0(p_ss_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ss_host_id2(p_ss_id number, p_date date) return number
is
  v_ss_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ss_id, p_ss_id);
  ------------------------------
  return get_ss_host_id(v_ss_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ss_subhost_id0(p_ss_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ss_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ss_id) != v_main_count, 'p_ss_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) full(q) index_asc(z, PK_SIM_SERIES)*/
  z.subhost_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value sim_series_id, rownum rn from table(p_ss_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_series z
  where 1 = 1
  and q2.rn = q.rn
  and z.sim_series_id = q.sim_series_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_series');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ss_subhost_id(p_ss_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_ss_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ss_subhost_id0(p_ss_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ss_subhost_id2(p_ss_id number, p_date date) return number
is
  v_ss_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ss_id, p_ss_id);
  ------------------------------
  return get_ss_subhost_id(v_ss_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ss_network_operator0(p_ss_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ss_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ss_id) != v_main_count, 'p_ss_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) full(q) index_asc(z, PK_SIM_SERIES)*/
  z.network_operator_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value sim_series_id, rownum rn from table(p_ss_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_series z
  where 1 = 1
  and q2.rn = q.rn
  and z.sim_series_id = q.sim_series_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_series');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ss_network_operator(p_ss_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_ss_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ss_network_operator0(p_ss_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ss_network_operator2(p_ss_id number, p_date date) return number
is
  v_ss_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ss_id, p_ss_id);
  ------------------------------
  return get_ss_network_operator(v_ss_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ss_type0(p_ss_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ss_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ss_id) != v_main_count, 'p_ss_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) full(q) index_asc(z, PK_SIM_SERIES)*/
  z.sim_card_type_code, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value sim_series_id, rownum rn from table(p_ss_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_series z
  where 1 = 1
  and q2.rn = q.rn
  and z.sim_series_id = q.sim_series_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_series');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ss_type(p_ss_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_ss_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ss_type0(p_ss_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ss_type2(p_ss_id number, p_date date) return varchar2
is
  v_ss_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ss_id, p_ss_id);
  ------------------------------
  return get_ss_type(v_ss_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function det_ss_id4imsi0(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_imsi) != v_main_count, 'p_imsi.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, I_SIMSERIES_LOCAL)*/
  z.sim_series_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value imsi, length(column_value) imsi_length, rownum rn from table(p_imsi)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    sim_series z
  where 1 = 1
  and q2.rn = q.rn
  and q.imsi between z.start_imsi_number and z.end_imsi_number
  and length(z.start_imsi_number) = q.imsi_length
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_series');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function det_ss_id4imsi(p_imsi ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_imsi));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return det_ss_id4imsi0(p_imsi, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function det_ss_id4imsi2(p_imsi varchar2, p_date date) return number
is
  v_imsi ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_imsi, p_imsi);
  ------------------------------
  return det_ss_id4imsi(v_imsi, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_pa_host0(p_pa ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_pa);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_pa) != v_main_count, 'p_pa.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, I_PAH_PA)*/
  z.balance_storage, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value personal_account, rownum rn from table(p_pa)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    personal_account_history z
  where 1 = 1
  and q2.rn = q.rn
  and z.personal_account = q.personal_account
  and q2.validity_date between z.start_date and nvl(z.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'personal_account_history');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pa_host(p_pa ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_pa));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_pa_host0(p_pa, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pa_host2(p_pa number, p_date date) return number
is
  v_pa ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_pa, p_pa);
  ------------------------------
  return get_pa_host(v_pa, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_pa_linked_ap_id(p_pa ct_number, p_date date, p_trim_empty boolean, p_pa2 out ct_number, p_ap_id out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := FALSE)
is
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  util_pkg.XCheck_Cond_Missing(p_xcheck_unique_data is null, 'p_xcheck_unique_data');
  ------------------------------
  util_loc_pkg.touch_boolean(p_xcheck_data); --!_! no check
  ------------------------------
select /*+ ordered no_expand use_nl(q, z) full(q) index_asc(z, I_APPA_PERSONAL_ACCOUNT)*/
  q.personal_account, z.access_point_id, q.rn
  bulk collect into p_pa2, p_ap_id, v_rn
  from (select column_value personal_account, rownum rn from table(p_pa)) q, access_point_personal_account z
  where 1 = 1
  and z.personal_account(+) = q.personal_account
  and p_date between z.from_date(+) and nvl(z.to_date(+), to_date('01.01.4000', 'dd.mm.yyyy'))
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.personal_account, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn, z.access_point_id
  ;
  ------------------------------
  if p_xcheck_unique_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'access_point_personal_account');
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pa_linked_ap_id2(p_pa number, p_date date, p_xcheck_unique_data boolean := FALSE) return ct_number
is
  v_res ct_number;
  v_pa ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_pa, p_pa);
  ------------------------------
  get_pa_linked_ap_id(v_pa, p_date, TRUE, v_pa, v_res, TRUE, p_xcheck_unique_data);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function check_host_id0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_show_not_found is null, 'p_show_not_found');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_host_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_host_id) != v_main_count, 'p_host_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_HOST)*/
  z.host_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value host_id, rownum rn from table(p_host_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    host z
  where 1 = 1
  and q2.rn = q.rn
  and z.host_id = q.host_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'host');
    ------------------------------
  end if;
  ------------------------------
  if p_show_not_found
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_rn := util_pkg.filter_ct_number(v_tmp_rn, v_tmp_rn, v_rn, FALSE);
    ------------------------------
  end if;
  ------------------------------
  v_res := util_pkg.get_by_pos2_ct_number(p_host_id, v_rn, p_trim_empty);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_host_id(p_host_id ct_number, p_date date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_host_id), p_date);
  ------------------------------
  return check_host_id0(p_host_id, v_date, p_trim_empty, p_show_not_found, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_host_id2(p_host_id number, p_date date, p_show_not_found boolean) return number
is
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  return check_host_id(v_host_id, p_date, FALSE, p_show_not_found)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_id0(p_host_code ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_host_code);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_host_code) != v_main_count, 'p_host_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, UK_HOST_CODE)*/
  z.host_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value host_code, rownum rn from table(p_host_code)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    host z
  where 1 = 1
  and q2.rn = q.rn
  and z.host_code = q.host_code
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'host');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_id(p_host_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_host_code));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_host_id0(p_host_code, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_id2(p_host_code varchar2, p_date date) return number
is
  v_host_code ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_host_code, p_host_code);
  ------------------------------
  return get_host_id(v_host_code, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_code0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_host_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_host_id) != v_main_count, 'p_host_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_HOST)*/
  z.host_code, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value host_id, rownum rn from table(p_host_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    host z
  where 1 = 1
  and q2.rn = q.rn
  and z.host_id = q.host_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'host');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_code(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_host_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_host_code0(p_host_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_code2(p_host_id number, p_date date) return varchar2
is
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  return get_host_code(v_host_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_name0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar
is
  v_res ct_varchar;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_host_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_host_id) != v_main_count, 'p_host_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_HOST)*/
  z.host_name, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value host_id, rownum rn from table(p_host_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    host z
  where 1 = 1
  and q2.rn = q.rn
  and z.host_id = q.host_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'host');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_name(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_host_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_host_name0(p_host_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_name2(p_host_id number, p_date date) return varchar2
is
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  return get_host_name(v_host_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_address0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar
is
  v_res ct_varchar;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_host_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_host_id) != v_main_count, 'p_host_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_HOST)*/
  z.host_address, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value host_id, rownum rn from table(p_host_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    host z
  where 1 = 1
  and q2.rn = q.rn
  and z.host_id = q.host_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'host');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_address(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_host_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_host_address0(p_host_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_address2(p_host_id number, p_date date) return varchar2
is
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  return get_host_address(v_host_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_type0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_host_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_host_id) != v_main_count, 'p_host_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_HOST)*/
  z.host_type_code, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value host_id, rownum rn from table(p_host_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    host z
  where 1 = 1
  and q2.rn = q.rn
  and z.host_id = q.host_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'host');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_type(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_host_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_host_type0(p_host_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_type2(p_host_id number, p_date date) return varchar2
is
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  return get_host_type(v_host_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_network_operator0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_host_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_host_id) != v_main_count, 'p_host_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z PK_HOST)*/
  z.network_operator_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value host_id, rownum rn from table(p_host_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    host z
  where 1 = 1
  and q2.rn = q.rn
  and z.host_id = q.host_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'host');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_network_operator(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_host_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_host_network_operator0(p_host_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_network_operator2(p_host_id number, p_date date) return number
is
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  return get_host_network_operator(v_host_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_parent0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_host_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_host_id) != v_main_count, 'p_host_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_HOST)*/
  nvl(z.parent_host_id, z.host_id), q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value host_id, rownum rn from table(p_host_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    host z
  where 1 = 1
  and q2.rn = q.rn
  and z.host_id = q.host_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'host');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_parent(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_host_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_host_parent0(p_host_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_parent2(p_host_id number, p_date date) return number
is
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  return get_host_parent(v_host_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_zone_id0(p_zone_code ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_zone_code);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_zone_code) != v_main_count, 'p_zone_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, UK_ZONE_CODE)*/
  z.zone_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value zone_code, rownum rn from table(p_zone_code)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    zone z
  where 1 = 1
  and q2.rn = q.rn
  and z.zone_code = q.zone_code
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'zone');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_zone_id(p_zone_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_zone_code));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_zone_id0(p_zone_code, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_zone_id2(p_zone_code varchar2, p_date date) return number
is
  v_zone_code ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_zone_code, p_zone_code);
  ------------------------------
  return get_zone_id(v_zone_code, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_zone_code0(p_zone_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_zone_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_zone_id) != v_main_count, 'p_zone_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_ZONE)*/
  z.zone_code, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value zone_id, rownum rn from table(p_zone_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    zone z
  where 1 = 1
  and q2.rn = q.rn
  and z.zone_id = q.zone_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'zone');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_zone_code(p_zone_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_zone_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_zone_code0(p_zone_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_zone_code2(p_zone_id number, p_date date) return varchar2
is
  v_zone_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_zone_id, p_zone_id);
  ------------------------------
  return get_zone_code(v_zone_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_network_operator_id0(p_network_operator_code ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_network_operator_code);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_network_operator_code) != v_main_count, 'p_network_operator_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, UK_NETWORK_OPERATOR_CODE)*/
  z.network_operator_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value network_operator_code, rownum rn from table(p_network_operator_code)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    network_operator z
  where 1 = 1
  and q2.rn = q.rn
  and z.network_operator_code = q.network_operator_code
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'network_operator');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;
----------------------------------!---------------------------------------------

function get_network_operator_id(p_network_operator_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_network_operator_code));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_network_operator_id0(p_network_operator_code, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_id2(p_network_operator_code varchar2, p_date date) return number
is
  v_network_operator_code ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_network_operator_code, p_network_operator_code);
  ------------------------------
  return get_network_operator_id(v_network_operator_code, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_network_operator_id2(p_network_operator_code varchar2, p_date date) return number
is
  v_network_operator_id number;
begin
  ------------------------------
  v_network_operator_id := get_network_operator_id2(p_network_operator_code, p_date);
  ------------------------------
  util_pkg.xcheck_cond_invalid(v_network_operator_id is null, util_loc_pkg.c_msg_net_op_not_found);
  ------------------------------
  return v_network_operator_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_code0(p_network_operator_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_network_operator_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_network_operator_id) != v_main_count, 'p_network_operator_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_NETWORK_OPERATOR)*/
  z.network_operator_code, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value network_operator_id, rownum rn from table(p_network_operator_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    network_operator z
  where 1 = 1
  and q2.rn = q.rn
  and z.network_operator_id = q.network_operator_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'network_operator');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_code(p_network_operator_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_network_operator_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_network_operator_code0(p_network_operator_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_code2(p_network_operator_id number, p_date date) return varchar2
is
  v_network_operator_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_network_operator_id, p_network_operator_id);
  ------------------------------
  return get_network_operator_code(v_network_operator_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_type_raw0(p_network_operator_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_network_operator_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_network_operator_id) != v_main_count, 'p_network_operator_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_NETWORK_OPERATOR)*/
  z.network_operator_type, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value network_operator_id, rownum rn from table(p_network_operator_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    network_operator z
  where 1 = 1
  and q2.rn = q.rn
  and z.network_operator_id = q.network_operator_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'network_operator');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_type_raw(p_network_operator_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_network_operator_id), p_date);
  ------------------------------
  return get_network_operator_type_raw0(p_network_operator_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_type_raw2(p_network_operator_id number, p_date date) return varchar2
is
  v_network_operator_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_network_operator_id, p_network_operator_id);
  ------------------------------
  return get_network_operator_type_raw(v_network_operator_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_type_x0(p_network_operator_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_network_operator_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_network_operator_id) != v_main_count, 'p_network_operator_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_NETWORK_OPERATOR)*/
    decode(z.network_operator_type,
      c_NOPT_CODE_INTERNAL_NULLDUMMY, c_NOPT_CODE_INTERNAL_FAKE,
      --!_!c_NOPT_CODE_EXTERNAL, c_NOPT_CODE_EXTERNAL,
      c_NOPT_CODE_EXTERNAL
    ) network_operator_type, --!_!wrap f...g NULL (c_NOPT_CODE_INTERNAL_NULLDUMMY)
    q.rn
  bulk collect into
    v_res,
    v_rn
  from
    (select column_value network_operator_id, rownum rn from table(p_network_operator_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    network_operator z
  where 1 = 1
    and q2.rn = q.rn
    and z.network_operator_id = q.network_operator_id
    and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'network_operator');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_type_x(p_network_operator_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_network_operator_id), p_date);
  ------------------------------
  return get_network_operator_type_x0(p_network_operator_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_type_x2(p_network_operator_id number, p_date date) return varchar2
is
  v_network_operator_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_network_operator_id, p_network_operator_id);
  ------------------------------
  return get_network_operator_type_x(v_network_operator_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_uprsc0(p_network_operator_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_network_operator_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_network_operator_id) != v_main_count, 'p_network_operator_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_NETWORK_OPERATOR)*/
  z.uprs_member_code, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value network_operator_id, rownum rn from table(p_network_operator_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    network_operator z
  where 1 = 1
  and q2.rn = q.rn
  and z.network_operator_id = q.network_operator_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'network_operator');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_uprsc(p_network_operator_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_network_operator_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_network_operator_uprsc0(p_network_operator_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_uprsc2(p_network_operator_id number, p_date date) return varchar2
is
  v_network_operator_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_network_operator_id, p_network_operator_id);
  ------------------------------
  return get_network_operator_uprsc(v_network_operator_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_name0(p_network_operator_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar
is
  v_res ct_varchar;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_network_operator_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_network_operator_id) != v_main_count, 'p_network_operator_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_NETWORK_OPERATOR)*/
  z.network_operator_name, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value network_operator_id, rownum rn from table(p_network_operator_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    network_operator z
  where 1 = 1
  and q2.rn = q.rn
  and z.network_operator_id = q.network_operator_id
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'network_operator');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_name(p_network_operator_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_network_operator_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_network_operator_name0(p_network_operator_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_name2(p_network_operator_id number, p_date date) return varchar2
is
  v_network_operator_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_network_operator_id, p_network_operator_id);
  ------------------------------
  return get_network_operator_name(v_network_operator_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_int_no4na0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_id) != v_main_count, 'p_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z1 z2 z3 z4)
  index_asc(z1, PK_PHONE_NUMBER)
  index_asc(z2, PK_PHONE_NUMBER_SERIES)
  index_asc(z3, I_PHOSEOPER_PHO_NUM_SERIES_ID)
  index_asc(z4, PK_NETWORK_OPERATOR)
  */
  z4.network_operator_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value network_address_id, rownum rn from table(p_na_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    phone_number z1, phone_number_series z2, phone_series_operator z3, network_operator z4
  where 1 = 1
  and q2.rn = q.rn
  and z1.network_address_id = q.network_address_id
  and z2.phone_number_series_id = z1.phone_number_series_id
  and z3.phone_number_series_id = z2.phone_number_series_id
  and z4.network_operator_id = z3.network_operator_id
  and z4.network_operator_type is null --!_!c_NOPT_CODE_INTERNAL_NULLDUMMY
  and nvl(z1.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  and nvl(z2.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  and q2.validity_date between z3.start_date and nvl(z3.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  and nvl(z4.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  util_pkg.xis_unique_ct_number(v_rn, 'Multi network operators on network address');
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_int_no4na(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_na_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_int_no4na0(p_na_id, v_date, p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_int_no4na2(p_na_id number, p_date date) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_int_no4na(v_na_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ext_no4na0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_id) != v_main_count, 'p_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z1 z2 z3 z4)
  index_asc(z1, PK_PHONE_NUMBER)
  index_asc(z2, PK_PHONE_NUMBER_SERIES)
  index_asc(z3, I_PHOSEOPER_PHO_NUM_SERIES_ID)
  index_asc(z4, PK_NETWORK_OPERATOR)
  */
  z4.network_operator_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value network_address_id, rownum rn from table(p_na_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    phone_number z1, phone_number_series z2, phone_series_operator z3, network_operator z4
  where 1 = 1
  and q2.rn = q.rn
  and z1.network_address_id = q.network_address_id
  and z2.phone_number_series_id = z1.phone_number_series_id
  and z3.phone_number_series_id = z2.phone_number_series_id
  and z4.network_operator_id = z3.network_operator_id
  and z4.network_operator_type = c_NOPT_CODE_EXTERNAL
  and nvl(z1.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  and nvl(z2.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  and q2.validity_date between z3.start_date and nvl(z3.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  and nvl(z4.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  util_pkg.xis_unique_ct_number(v_rn, 'Multi network operators on network address');
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ext_no4na(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_na_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_ext_no4na0(p_na_id, v_date, p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ext_no4na2(p_na_id number, p_date date) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_ext_no4na(v_na_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function det_int_no0(p_msisdn ct_varchar_s, p_date ct_date, p_trim_empty boolean) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdn);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdn) != v_main_count, 'p_msisdn.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z1 z2 z3 z4)
  index_asc(z1, I_PHONUMSE_LOCAL)
  index_asc(z2, I_PHOSEOPER_PHO_NUM_SERIES_ID)
  index_asc(z3, PK_NETWORK_OPERATOR)
  */
  z3.network_operator_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value msisdn, rownum rn from table(p_msisdn)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    phone_number_series z1, phone_series_operator z2, network_operator z3
  where 1 = 1
  and q2.rn = q.rn
  and q.msisdn between z1.country_code || z1.area_code || z1.local_number_start and z1.country_code || z1.area_code || z1.local_number_end
  and length(q.msisdn) = length(z1.country_code || z1.area_code || z1.local_number_start)
  and z2.phone_number_series_id = z1.phone_number_series_id
  and z3.network_operator_id = z2.network_operator_id
  and z3.network_operator_type is null --!_!c_NOPT_CODE_INTERNAL_NULLDUMMY
  and nvl(z1.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  and q2.validity_date between z2.start_date and nvl(z2.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  and nvl(z3.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  util_pkg.xis_unique_ct_number(v_rn, 'Multi network operators on network address');
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function det_int_no(p_msisdn ct_varchar_s, p_date date, p_trim_empty boolean) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_msisdn));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return det_int_no0(p_msisdn, v_date, p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function det_int_no2(p_msisdn varchar2, p_date date) return number
is
  v_msisdn ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_msisdn, p_msisdn);
  ------------------------------
  return det_int_no(v_msisdn, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_by_ap0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_ss_id ct_number;
begin
  ------------------------------
  v_ss_id := get_ap_ss_id0(p_ap_id, p_date, FALSE, p_xcheck_data);
  ------------------------------
  return get_ss_network_operator0(v_ss_id, p_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_by_ap(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_ap_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_no_by_ap0(p_ap_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_by_ap2(p_ap_id number, p_date date) return number
is
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  return get_no_by_ap(v_ap_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_by_mcc_mnc0(p_mcc ct_varchar_s, p_mnc ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_mcc);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_mcc) != v_main_count, 'p_mcc.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_mnc) != v_main_count, 'p_mnc.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q1 q2) full(q) full(q1) full(q2) use_nl(z) index_asc(z, UK_NETWORK_OPERATOR_MCC_MNC)*/
  z.network_operator_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value mcc, rownum rn from table(p_mcc)) q,
    (select column_value mnc, rownum rn from table(p_mnc)) q1,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    network_operator z
  where 1 = 1
  and q1.rn = q.rn
  and q2.rn = q.rn
  and z.mcc = q.mcc
  and z.mnc = q1.mnc
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sim_card, sim_series, network_operator');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_by_mcc_mnc(p_mcc ct_varchar_s, p_mnc ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_mcc));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_no_by_mcc_mnc0(p_mcc, p_mnc, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_by_mcc_mnc2(p_mcc varchar2, p_mnc varchar2, p_date date) return varchar2
is
  v_mcc ct_varchar_s;
  v_mnc ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_mcc, p_mcc);
  util_pkg.add_ct_varchar_s_val(v_mnc, p_mnc);
  ------------------------------
  return get_no_by_mcc_mnc(v_mcc, v_mnc, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_by_msc_mask0(p_msc ct_varchar_s, p_date ct_date, p_trim_empty boolean) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
  v_rn01 ct_number;
  v_msc1 ct_varchar_s;
  v_max_len number;
  v_pivot01 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msc);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msc) != v_main_count, 'p_msc.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ full(q)*/
   max(nvl(length(msc), 0))
  into v_max_len
  from (select column_value msc, rownum rn from table(p_msc)) q
  ;
  ------------------------------
  if v_max_len > 0
  then
    ------------------------------
    v_pivot01 := util_pkg.make_pivot(v_max_len, 0);
    ------------------------------
  select /*+ full(q)*/
     substr(q.msc, 1, q.msc_len - q2.shift), q.rn
    bulk collect into v_msc1, v_rn01
    from
      (select column_value msc, nvl(length(column_value), 0) msc_len, rownum rn from table(p_msc)) q,
      (select column_value shift, rownum rn from table(v_pivot01)) q2
    where 1 = 1
    and msc_len > shift
    ;
    ------------------------------
  select a.network_operator_id, a.rn
    bulk collect into v_res, v_rn
    from
      (
      --select /* ordered use_hash(q1 q2) use_nl(z1 z2) full(q) full(q1) full(q2) index_asc(z1 UK_HOST_CODE) index_asc(z2, PK_NETWORK_OPERATOR)*/
      select /*+ ordered use_hash(q q1 q2 z) full(q) full(q1) full(q2) full(z)*/
        z.network_operator_id,
        row_number() over (partition by q1.msc_rn order by msc_len desc) pr,
        q1.msc_rn rn
        from
          (select column_value msc, length(column_value) msc_len, rownum rn from table(v_msc1)) q,
          (select column_value msc_rn, rownum rn from table(v_rn01)) q1,
          (select column_value validity_date, rownum rn from table(p_date)) q2,
          host z
        where 1 = 1
        and q1.rn = q.rn
        and q2.rn = q1.msc_rn
        and z.host_code = q.msc
        and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
      ) a
    where a.pr = 1
    order by a.rn
    ;
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_by_msc_mask(p_msc ct_varchar_s, p_date date, p_trim_empty boolean) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_msc));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_no_by_msc_mask0(p_msc, v_date, p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_by_msc_mask2(p_msc varchar2, p_date date) return varchar2
is
  v_msc ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_msc, p_msc);
  ------------------------------
  return get_no_by_msc_mask(v_msc, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_by_uprsc0(p_uprs_member_code ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_uprs_member_code);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_uprs_member_code) != v_main_count, 'p_uprs_member_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, UK_NETWORK_OPERATOR_UPRSC)*/
    z.network_operator_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value uprs_member_code, rownum rn from table(p_uprs_member_code)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    network_operator z
  where 1 = 1
  and q2.rn = q.rn
  and z.uprs_member_code = q.uprs_member_code
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'network_operator');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;
----------------------------------!---------------------------------------------

function get_no_by_uprsc(p_uprs_member_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_uprs_member_code));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_no_by_uprsc0(p_uprs_member_code, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_by_uprsc2(p_uprs_member_code varchar2, p_date date) return number
is
  v_uprs_member_code ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_uprs_member_code, p_uprs_member_code);
  ------------------------------
  return get_no_by_uprsc(v_uprs_member_code, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function no_is_parent_no(p_child_id ct_number, p_parent_id ct_number, p_date date, p_include_self boolean, p_is_value number := util_pkg.c_true, p_is_not_value number := util_pkg.c_false) return ct_number
is
  v_res ct_number;
  v_include_self number := util_pkg.bool_to_int_2val(p_include_self);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  with in_pars as
  (
    select /*+ ordered use_hash(q1 q2) full(q1) full(q2)*/
      q1.id, q2.parent_id, q1.rn
    from
     (select column_value id, rownum rn from table(p_child_id)) q1,
     (select column_value parent_id, rownum rn from table(p_parent_id)) q2
    where 1 = 1
    and q1.rn = q2.rn
    order by q1.rn
  )
  select /*+ ordered use_hash(z1 z2)*/
    decode(z2.id, null, p_is_not_value, p_is_value)
  bulk collect into v_res
  from in_pars z1,
    (
      select
        zzz.id, zzz.parent_id
        from (
              select
                distinct
                connect_by_root id id,
                connect_by_root parent_id parent_id,
                z.network_operator_id,
                z.network_operator_id_upper
              from (
                    select /*+ ordered use_hash(q1, q2) full(q1)*/
                      z1.network_operator_id,
                      z1.network_operator_id_upper,
                      z2.*
                    from network_operator z1, in_pars z2
                    where 1 = 1
                    and z2.id(+) = z1.network_operator_id
                    and nvl(z1.deleted, p_date + c_dummy_date_shift) > p_date
                   ) z
              start with network_operator_id = id
              connect by network_operator_id = prior network_operator_id_upper
              order siblings by network_operator_id
             ) zzz
        where 1 = 1
        and decode(v_include_self, util_pkg.c_true, network_operator_id , network_operator_id_upper) = parent_id
      ) z2
  where 1 = 1
  and z2.id(+) = z1.id
  and z2.parent_id(+) = z1.parent_id
  order by z1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_child_nos(p_root_parent_id number, p_date date, p_include_self boolean) return ct_number
is
  v_res ct_number;
  v_include_self number := util_pkg.bool_to_int_2val(p_include_self);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_root_parent_id is null, 'p_root_parent_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select
      network_operator_id
    bulk collect into v_res
    from (
          select /*+ index(z I_NETOPER_NET_OPERAT_ID_UPPER)*/
            connect_by_root network_operator_id parent_id,
            network_operator_id,
            network_operator_id_upper
          from network_operator z
          where 1 = 1
          and nvl(deleted, p_date + c_dummy_date_shift) > p_date
          start with network_operator_id = p_root_parent_id
          connect by prior network_operator_id = network_operator_id_upper
         )
    where 1 = 1
    and decode(v_include_self, util_pkg.c_false, decode(network_operator_id, p_root_parent_id, util_pkg.c_false , util_pkg.c_true), util_pkg.c_true) = util_pkg.c_true
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function det_pns_id4msisdn0(p_msisdn ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdn);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdn) != v_main_count, 'p_msisdn.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, I_PHONUMSE_LOCAL)*/
  z.phone_number_series_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value msisdn, length(column_value) msisdn_length, rownum rn from table(p_msisdn)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    phone_number_series z
  where 1 = 1
  and q2.rn = q.rn
  and q.msisdn between country_code || area_code || local_number_start and country_code || area_code || local_number_end
  and length(country_code || area_code || local_number_start) = q.msisdn_length
  and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'phone_number_series');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function det_pns_id4msisdn(p_msisdn ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_msisdn));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return det_pns_id4msisdn0(p_msisdn, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function det_pns_id4msisdn2(p_msisdn varchar2, p_date date) return number
is
  v_msisdn ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_msisdn, p_msisdn);
  ------------------------------
  return det_pns_id4msisdn(v_msisdn, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function check_dst_rule_id0(p_dst_rule_id ct_number, p_date ct_date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_show_not_found is null, 'p_show_not_found');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_dst_rule_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_dst_rule_id) != v_main_count, 'p_dst_rule_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count'); --!_! p_date is NOT USED
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, PK_DST_RULE)*/
  z.dst_rule_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value dst_rule_id, rownum rn from table(p_dst_rule_id)) q,
    --!_!(select column_value validity_date, rownum rn from table(p_date)) q2,
    dst_rule z
  where 1 = 1
  --!_!and q2.rn = q.rn
  and z.dst_rule_id = q.dst_rule_id
  --!_!and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'dst_rule');
    ------------------------------
  end if;
  ------------------------------
  if p_show_not_found
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_rn := util_pkg.filter_ct_number(v_tmp_rn, v_tmp_rn, v_rn, FALSE);
    ------------------------------
  end if;
  ------------------------------
  v_res := util_pkg.get_by_pos2_ct_number(p_dst_rule_id, v_rn, p_trim_empty);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_dst_rule_id(p_dst_rule_id ct_number, p_date date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_dst_rule_id), p_date);
  ------------------------------
  return check_dst_rule_id0(p_dst_rule_id, v_date, p_trim_empty, p_show_not_found, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_dst_rule_id2(p_dst_rule_id number, p_date date, p_show_not_found boolean) return number
is
  v_dst_rule_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_dst_rule_id, p_dst_rule_id);
  ------------------------------
  return check_dst_rule_id(v_dst_rule_id, p_date, FALSE, p_show_not_found)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_linked_naap_value(p_link_status number) return boolean
is
  v_res boolean;
begin
  ------------------------------
  if p_link_status = c_link_status_free
  then
    v_res := false;
  elsif p_link_status = c_link_status_linked
  then
    v_res := true;
  else --p_link_status = c_link_status_all
    v_res := null;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_linked_naap_value2(p_link_status number) return boolean
is
  v_res boolean;
begin
  ------------------------------
  if p_link_status = c_link2_status_free
  then
    v_res := false;
  elsif p_link_status = c_link2_status_linked
  then
    v_res := true;
  else --p_link_status = c_link2_status_all
    v_res := null;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function normalize_mask(p_mask varchar2) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := p_mask;
  ------------------------------
  v_res := replace(v_res, '?', '_');
  ------------------------------
  v_res := replace(v_res, '*', '%');
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure normalize_str_host_alike(p_str_host_alike varchar2, p_str_host_normal out varchar2, p_host_empty out boolean)
is
begin
  ------------------------------
  p_str_host_normal := null;
  p_host_empty := false;
  ------------------------------
  if p_str_host_alike is null
  then
    p_host_empty := true;
  elsif p_str_host_alike = c_str_host_id_any
  then
    p_str_host_normal := null;
  else
    p_str_host_normal := p_str_host_alike;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_str_host_id(p_str_host_id varchar2, p_date date, p_xcheck_exist boolean, p_host_id out number, p_host_empty out boolean)
is
  v_str_host_id varchar2(4000);
  v_coll_str_host_id ct_varchar_s;
  v_coll_host_id ct_number;
  v_host_empty boolean;
begin
  ------------------------------
  normalize_str_host_alike(p_str_host_id, v_str_host_id, p_host_empty);
  ------------------------------
  p_host_id := util_pkg.char_to_number(v_str_host_id);
  ------------------------------
  if p_xcheck_exist and not p_host_empty and v_str_host_id is not null
  then
    ------------------------------
    util_pkg.add_ct_varchar_s_val(v_coll_str_host_id, v_str_host_id);
    ------------------------------
    normalize_coll_str_host_id(v_coll_str_host_id, p_date, p_xcheck_exist, v_coll_host_id, v_host_empty);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_str_host_id2(p_str_host_id varchar2, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean)
is
  v_host_id number;
begin
  ------------------------------
  p_host_id := null;
  ------------------------------
  normalize_str_host_id(p_str_host_id, p_date, p_xcheck_exist, v_host_id, p_host_empty);
  ------------------------------
  if not p_host_empty and v_host_id is not null
  then
    util_pkg.add_ct_number_val(p_host_id, v_host_id);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_coll_str_host_alike(p_coll_str_host_alike ct_varchar_s, p_coll_str_host_normal out ct_varchar_s, p_host_empty out boolean)
is
begin
  ------------------------------
  p_coll_str_host_normal := null;
  p_host_empty := false;
  ------------------------------
  if NOT util_pkg.CheckP_ct_varchar_s(p_coll_str_host_alike)
  then
    p_host_empty := true;
  elsif p_coll_str_host_alike.count > 0 and p_coll_str_host_alike(p_coll_str_host_alike.first) = c_str_host_id_any
  then
    p_coll_str_host_normal := null;
  else
    p_coll_str_host_normal := util_pkg.unique_ct_varchar_s(p_coll_str_host_alike, true);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_coll_str_host_alike2(p_coll_str_host_alike util_pkg.cit_varchar_s, p_coll_str_host_normal out ct_varchar_s, p_host_empty out boolean)
is
begin
  ------------------------------
  normalize_coll_str_host_alike(util_pkg.cast_cit2ct_varchar_s(p_coll_str_host_alike, TRUE), p_coll_str_host_normal, p_host_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_coll_str_host_id(p_coll_str_host_id ct_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean)
is
  v_coll ct_varchar_s;
  v_host_code ct_varchar_s;
begin
  ------------------------------
  normalize_coll_str_host_alike(p_coll_str_host_id, v_coll, p_host_empty);
  ------------------------------
  p_host_id := null; --!_!
  ------------------------------
  if util_pkg.CheckP_ct_varchar_s(v_coll)
  then
    p_host_id := util_pkg.cast_ct_varchar_s2ct_number(v_coll, true);
  end if;
  ------------------------------
  if p_xcheck_exist
  then
    ------------------------------
    v_host_code := null; --!_!
    ------------------------------
    if util_pkg.CheckP_ct_number(p_host_id)
    then
      ------------------------------
      v_host_code := get_host_code(p_host_id, p_date, TRUE);
      ------------------------------
      if NOT util_pkg.CheckP_ct_varchar_s(v_host_code)
      then
        v_host_code := null; --!_!
      end if;
      ------------------------------
    end if;
    ------------------------------
    if 1 = 1
      and not (v_host_code is null and p_host_id is null)
      and ((v_host_code is null and p_host_id is not null)
        or (v_host_code is not null and p_host_id is null)
        or v_host_code.count != p_host_id.count
      )
    then
      util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found);
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_coll_str_host_id2(p_coll_str_host_id util_pkg.cit_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean)
is
begin
  ------------------------------
  normalize_coll_str_host_id(util_pkg.cast_cit2ct_varchar_s(p_coll_str_host_id, TRUE), p_date, p_xcheck_exist, p_host_id, p_host_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_coll_str_host_code(p_coll_str_host_code ct_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean)
is
  v_coll ct_varchar_s;
begin
  ------------------------------
  normalize_coll_str_host_alike(p_coll_str_host_code, v_coll, p_host_empty);
  ------------------------------
  p_host_id := null; --!_!
  ------------------------------
  if util_pkg.CheckP_ct_varchar_s(v_coll)
  then
    ------------------------------
    p_host_id := get_host_id(v_coll, p_date, p_xcheck_exist); --!_!
    ------------------------------
    if NOT util_pkg.CheckP_ct_number(p_host_id)
    then
      p_host_id := null; --!_!
    end if;
    ------------------------------
  end if;
  ------------------------------
  if p_xcheck_exist
  then
    ------------------------------
    if 1 = 1
      and not (v_coll is null and p_host_id is null)
      and ((v_coll is null and p_host_id is not null)
        or (v_coll is not null and p_host_id is null)
        or v_coll.count != p_host_id.count
      )
    then
      util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found);
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_coll_str_host_code2(p_coll_str_host_code util_pkg.cit_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean)
is
begin
  ------------------------------
  normalize_coll_str_host_code(util_pkg.cast_cit2ct_varchar_s(p_coll_str_host_code, TRUE), p_date, p_xcheck_exist, p_host_id, p_host_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_1nash_i(p_id number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return network_address_status_history%rowtype
is
  v_res network_address_status_history%rowtype;
  v_lock boolean := util_pkg.bool_to_bool_2val(p_lock);
  v_wait boolean := util_pkg.bool_to_bool_2val(p_wait);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if v_lock
  then
    ------------------------------
    if v_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_NETADSTAHI_NETWORK_ADDRES_I2)*/
        * into v_res
        from network_address_status_history z
        where 1 = 1
        and network_address_id = p_id
        and p_date between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_NETADSTAHI_NETWORK_ADDRES_I2)*/
        * into v_res
        from network_address_status_history z
        where 1 = 1
        and network_address_id = p_id
        and p_date between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_NETADSTAHI_NETWORK_ADDRES_I2)*/
      * into v_res
      from network_address_status_history z
      where 1 = 1
      and network_address_id = p_id
      and p_date between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_1nash(p_id number, p_date date) return network_address_status_history%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get_1nash_i(p_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_min_date_from_nash(p_id number) return date
is
  v_res date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  ------------------------------
  select /*+ index_asc(z, I_NETADSTAHI_NETWORK_ADDRES_I2)*/
    min(start_date) into v_res
    from network_address_status_history z
    where 1 = 1
    and network_address_id = p_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_max_date_from_nash(p_id number) return date
is
  v_res date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  ------------------------------
  select /*+ index_asc(z, I_NETADSTAHI_NETWORK_ADDRES_I2)*/
    max(start_date) into v_res
    from network_address_status_history z
    where 1 = 1
    and network_address_id = p_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_max_date_to_nash(p_id number) return date
is
  v_res date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  ------------------------------
  select /*+ index_asc(z, I_NETADSTAHI_NETWORK_ADDRES_I2)*/
    max(nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))) into v_res
    from network_address_status_history z
    where 1 = 1
    and network_address_id = p_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_first_nash(p_id number) return network_address_status_history%rowtype
is
  v_date date;
begin
  ------------------------------
  v_date := get_min_date_from_nash(p_id);
  ------------------------------
  if v_date is null
  then
    return null;
  end if;
  ------------------------------
  return get_1nash(p_id, v_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! (if not null) p_robust_date is used to allow for actually encountered previous.date_to = current.date_from (but not previous.date_to + c_dt_dif = current.date_from)
----------------------------------!---------------------------------------------
function get_last_nash(p_id number) return network_address_status_history%rowtype
is
  v_date date;
begin
  ------------------------------
  v_date := get_max_date_to_nash(p_id);
  ------------------------------
  if v_date is null
  then
    return null;
  end if;
  ------------------------------
  return get_1nash(p_id, v_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_prev_nash(p_id number) return network_address_status_history%rowtype
is
  v_date_to_prev date;
  v_last network_address_status_history%rowtype;
begin
  ------------------------------
  v_last := get_last_nash(p_id);
  ------------------------------
  if v_last.network_address_id is null
  then
    ------------------------------
    return NULL;
    ------------------------------
  end if;
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_last.start_date);
  ------------------------------
  return get_1nash(p_id, v_date_to_prev);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_1nash(p_id number, p_date date, p_wait boolean) return boolean
is
  v_is_locked boolean;
  v_rec network_address_status_history%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_rec := get_1nash_i(p_id, p_date, TRUE, p_wait, v_is_locked);
  ------------------------------
  if (1 = 0
    or v_is_locked
    or v_rec.network_address_id is null
  )
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_nash(p_id ct_number, p_date ct_date, p_wait boolean, p_locked_value number := util_pkg.c_true, p_unlocked_value number := util_pkg.c_false) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_check boolean;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_id) != v_main_count, 'p_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count < 1
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_id.first..p_id.last
  loop
    ------------------------------
    v_check := false;
    ------------------------------
    if p_id(v_i) is not null and p_date(v_i) is not null
    then
      v_check := lock_1nash(p_id(v_i), p_date(v_i), p_wait);
    end if;
    ------------------------------
    if v_check
    then
      util_pkg.add_ct_number_val(v_res, p_locked_value);
    else
      util_pkg.add_ct_number_val(v_res, p_unlocked_value);
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_1apsh_i(p_id number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return access_point_status_history%rowtype
is
  v_res access_point_status_history%rowtype;
  v_lock boolean := util_pkg.bool_to_bool_2val(p_lock);
  v_wait boolean := util_pkg.bool_to_bool_2val(p_wait);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if v_lock
  then
    ------------------------------
    if v_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_ACCPOSTAHI_ACCESS_POINT_ID)*/
        * into v_res
        from access_point_status_history z
        where 1 = 1
        and access_point_id = p_id
        and p_date between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_ACCPOSTAHI_ACCESS_POINT_ID)*/
        * into v_res
        from access_point_status_history z
        where 1 = 1
        and access_point_id = p_id
        and p_date between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_ACCPOSTAHI_ACCESS_POINT_ID)*/
      * into v_res
      from access_point_status_history z
      where 1 = 1
      and access_point_id = p_id
      and p_date between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_1apsh(p_id number, p_date date) return access_point_status_history%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get_1apsh_i(p_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_min_date_from_apsh(p_id number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_ACCPOSTAHI_ACCESS_POINT_ID)*/
    min(start_date) into v_res
    from access_point_status_history z
    where 1 = 1
    and access_point_id = p_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_max_date_from_apsh(p_id number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_ACCPOSTAHI_ACCESS_POINT_ID)*/
    max(start_date) into v_res
    from access_point_status_history z
    where 1 = 1
    and access_point_id = p_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_max_date_to_apsh(p_id number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_ACCPOSTAHI_ACCESS_POINT_ID)*/
    max(nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))) into v_res
    from access_point_status_history z
    where 1 = 1
    and access_point_id = p_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_first_apsh(p_id number) return access_point_status_history%rowtype
is
  v_date date;
begin
  ------------------------------
  v_date := get_min_date_from_apsh(p_id);
  ------------------------------
  if v_date is null
  then
    return null;
  end if;
  ------------------------------
  return get_1apsh(p_id, v_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_last_apsh(p_id number) return access_point_status_history%rowtype
is
  v_date date;
begin
  ------------------------------
  v_date := get_max_date_to_apsh(p_id);
  ------------------------------
  if v_date is null
  then
    return null;
  end if;
  ------------------------------
  return get_1apsh(p_id, v_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_1apsh(p_id number, p_date date, p_wait boolean) return boolean
is
  v_is_locked boolean;
  v_rec access_point_status_history%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_rec := get_1apsh_i(p_id, p_date, TRUE, p_wait, v_is_locked);
  ------------------------------
  if (1 = 0
    or v_is_locked
    or v_rec.access_point_id is null
  )
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_apsh(p_id ct_number, p_date ct_date, p_wait boolean, p_locked_value number := util_pkg.c_true, p_unlocked_value number := util_pkg.c_false) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_check boolean;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_id) != v_main_count, 'p_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count < 1
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_id.first..p_id.last
  loop
    ------------------------------
    v_check := false;
    ------------------------------
    if p_id(v_i) is not null and p_date(v_i) is not null
    then
      v_check := lock_1apsh(p_id(v_i), p_date(v_i), p_wait);
    end if;
    ------------------------------
    if v_check
    then
      util_pkg.add_ct_number_val(v_res, p_locked_value);
    else
      util_pkg.add_ct_number_val(v_res, p_unlocked_value);
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_1appsh_i(p_id number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return ap_prod_status_hist%rowtype
is
  v_res ap_prod_status_hist%rowtype;
  v_lock boolean := util_pkg.bool_to_bool_2val(p_lock);
  v_wait boolean := util_pkg.bool_to_bool_2val(p_wait);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if v_lock
  then
    ------------------------------
    if v_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_APPSTHI_ACCESS_POINT_ID)*/
        * into v_res
        from ap_prod_status_hist z
        where 1 = 1
        and access_point_id = p_id
        and p_date between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_APPSTHI_ACCESS_POINT_ID)*/
        * into v_res
        from ap_prod_status_hist z
        where 1 = 1
        and access_point_id = p_id
        and p_date between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_APPSTHI_ACCESS_POINT_ID)*/
      * into v_res
      from ap_prod_status_hist z
      where 1 = 1
      and access_point_id = p_id
      and p_date between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_1appsh(p_id number, p_date date) return ap_prod_status_hist%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get_1appsh_i(p_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_min_date_from_appsh(p_id number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_APPSTHI_ACCESS_POINT_ID)*/
    min(start_date) into v_res
    from ap_prod_status_hist z
    where 1 = 1
    and access_point_id = p_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_max_date_from_appsh(p_id number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_APPSTHI_ACCESS_POINT_ID)*/
    max(start_date) into v_res
    from ap_prod_status_hist z
    where 1 = 1
    and access_point_id = p_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_max_date_to_appsh(p_id number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_APPSTHI_ACCESS_POINT_ID)*/
    max(nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))) into v_res
    from ap_prod_status_hist z
    where 1 = 1
    and access_point_id = p_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_first_appsh(p_id number) return ap_prod_status_hist%rowtype
is
  v_date date;
begin
  ------------------------------
  v_date := get_min_date_from_appsh(p_id);
  ------------------------------
  if v_date is null
  then
    return null;
  end if;
  ------------------------------
  return get_1appsh(p_id, v_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_last_appsh(p_id number) return ap_prod_status_hist%rowtype
is
  v_date date;
begin
  ------------------------------
  v_date := get_max_date_to_appsh(p_id);
  ------------------------------
  if v_date is null
  then
    return null;
  end if;
  ------------------------------
  return get_1appsh(p_id, v_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_1appsh(p_id number, p_date date, p_wait boolean) return boolean
is
  v_is_locked boolean;
  v_rec ap_prod_status_hist%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_rec := get_1appsh_i(p_id, p_date, TRUE, p_wait, v_is_locked);
  ------------------------------
  if (1 = 0
    or v_is_locked
    or v_rec.access_point_id is null
  )
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_appsh(p_id ct_number, p_date ct_date, p_wait boolean, p_locked_value number := util_pkg.c_true, p_unlocked_value number := util_pkg.c_false) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_check boolean;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_id) != v_main_count, 'p_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count < 1
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_id.first..p_id.last
  loop
    ------------------------------
    v_check := false;
    ------------------------------
    if p_id(v_i) is not null and p_date(v_i) is not null
    then
      v_check := lock_1appsh(p_id(v_i), p_date(v_i), p_wait);
    end if;
    ------------------------------
    if v_check
    then
      util_pkg.add_ct_number_val(v_res, p_locked_value);
    else
      util_pkg.add_ct_number_val(v_res, p_unlocked_value);
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_1naap_i(p_na_id number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return network_address_access_point%rowtype
is
  v_res network_address_access_point%rowtype;
  v_lock boolean := util_pkg.bool_to_bool_2val(p_lock);
  v_wait boolean := util_pkg.bool_to_bool_2val(p_wait);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if v_lock
  then
    ------------------------------
    if v_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_NETADDRACCPO_NET_ADDRESS_ID2)*/
        * into v_res
        from network_address_access_point z
        where 1 = 1
        and network_address_id = p_na_id
        and p_date between from_date and nvl(to_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_NETADDRACCPO_NET_ADDRESS_ID2)*/
        * into v_res
        from network_address_access_point z
        where 1 = 1
        and network_address_id = p_na_id
        and p_date between from_date and nvl(to_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_NETADDRACCPO_NET_ADDRESS_ID2)*/
      * into v_res
      from network_address_access_point z
      where 1 = 1
      and network_address_id = p_na_id
      and p_date between from_date and nvl(to_date, to_date('01.01.4000', 'dd.mm.yyyy'))
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_1naap(p_na_id number, p_date date) return network_address_access_point%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get_1naap_i(p_na_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_min_date_from_naap(p_na_id number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_NETADDRACCPO_NET_ADDRESS_ID2)*/
    min(from_date) into v_res
    from network_address_access_point z
    where 1 = 1
    and network_address_id = p_na_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_max_date_from_naap(p_na_id number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_NETADDRACCPO_NET_ADDRESS_ID2)*/
    max(from_date) into v_res
    from network_address_access_point z
    where 1 = 1
    and network_address_id = p_na_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_max_date_to_naap(p_na_id number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_NETADDRACCPO_NET_ADDRESS_ID2)*/
    max(nvl(to_date, to_date('01.01.4000', 'dd.mm.yyyy'))) into v_res
    from network_address_access_point z
    where 1 = 1
    and network_address_id = p_na_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_first_naap(p_na_id number) return network_address_access_point%rowtype
is
  v_date date;
begin
  ------------------------------
  v_date := get_min_date_from_naap(p_na_id);
  ------------------------------
  if v_date is null
  then
    return null;
  end if;
  ------------------------------
  return get_1naap(p_na_id, v_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_last_naap(p_na_id number) return network_address_access_point%rowtype
is
  v_date date;
begin
  ------------------------------
  v_date := get_max_date_to_naap(p_na_id);
  ------------------------------
  if v_date is null
  then
    return null;
  end if;
  ------------------------------
  return get_1naap(p_na_id, v_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_1naap(p_na_id number, p_date date, p_wait boolean) return boolean
is
  v_is_locked boolean;
  v_rec network_address_access_point%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_rec := get_1naap_i(p_na_id, p_date, TRUE, p_wait, v_is_locked);
  ------------------------------
  if (1 = 0
    or v_is_locked
    or v_rec.network_address_id is null
  )
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_naap(p_na_id ct_number, p_date ct_date, p_wait boolean, p_locked_value number := util_pkg.c_true, p_unlocked_value number := util_pkg.c_false) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_check boolean;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_id) != v_main_count, 'p_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count < 1
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_na_id.first..p_na_id.last
  loop
    ------------------------------
    v_check := false;
    ------------------------------
    if p_na_id(v_i) is not null and p_date(v_i) is not null
    then
      v_check := lock_1naap(p_na_id(v_i), p_date(v_i), p_wait);
    end if;
    ------------------------------
    if v_check
    then
      util_pkg.add_ct_number_val(v_res, p_locked_value);
    else
      util_pkg.add_ct_number_val(v_res, p_unlocked_value);
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_1appa_i(p_ap_id number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return access_point_personal_account%rowtype
is
  v_res access_point_personal_account%rowtype;
  v_lock boolean := util_pkg.bool_to_bool_2val(p_lock);
  v_wait boolean := util_pkg.bool_to_bool_2val(p_wait);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if v_lock
  then
    ------------------------------
    if v_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_APPA_ACCESS_POINT_ID)*/
        * into v_res
        from access_point_personal_account z
        where 1 = 1
        and access_point_id = p_ap_id
        and p_date between from_date and nvl(to_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_APPA_ACCESS_POINT_ID)*/
        * into v_res
        from access_point_personal_account z
        where 1 = 1
        and access_point_id = p_ap_id
        and p_date between from_date and nvl(to_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_APPA_ACCESS_POINT_ID)*/
      * into v_res
      from access_point_personal_account z
      where 1 = 1
      and access_point_id = p_ap_id
      and p_date between from_date and nvl(to_date, to_date('01.01.4000', 'dd.mm.yyyy'))
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_1appa(p_ap_id number, p_date date) return access_point_personal_account%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get_1appa_i(p_ap_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_min_date_from_appa(p_ap_id number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_APPA_ACCESS_POINT_ID)*/
    min(from_date) into v_res
    from access_point_personal_account z
    where 1 = 1
    and access_point_id = p_ap_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_max_date_from_appa(p_ap_id number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_APPA_ACCESS_POINT_ID)*/
    max(from_date) into v_res
    from access_point_personal_account z
    where 1 = 1
    and access_point_id = p_ap_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_max_date_to_appa(p_ap_id number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_APPA_ACCESS_POINT_ID)*/
    max(nvl(to_date, to_date('01.01.4000', 'dd.mm.yyyy'))) into v_res
    from access_point_personal_account z
    where 1 = 1
    and access_point_id = p_ap_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_first_appa(p_ap_id number) return access_point_personal_account%rowtype
is
  v_date date;
begin
  ------------------------------
  v_date := get_min_date_from_appa(p_ap_id);
  ------------------------------
  if v_date is null
  then
    return null;
  end if;
  ------------------------------
  return get_1appa(p_ap_id, v_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_last_appa(p_ap_id number) return access_point_personal_account%rowtype
is
  v_date date;
begin
  ------------------------------
  v_date := get_max_date_to_appa(p_ap_id);
  ------------------------------
  if v_date is null
  then
    return null;
  end if;
  ------------------------------
  return get_1appa(p_ap_id, v_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_1appa(p_ap_id number, p_date date, p_wait boolean) return boolean
is
  v_is_locked boolean;
  v_rec access_point_personal_account%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_rec := get_1appa_i(p_ap_id, p_date, TRUE, p_wait, v_is_locked);
  ------------------------------
  if (1 = 0
    or v_is_locked
    or v_rec.access_point_id is null
  )
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_appa(p_ap_id ct_number, p_date ct_date, p_wait boolean, p_locked_value number := util_pkg.c_true, p_unlocked_value number := util_pkg.c_false) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_check boolean;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ap_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ap_id) != v_main_count, 'p_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count < 1
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_ap_id.first..p_ap_id.last
  loop
    ------------------------------
    v_check := false;
    ------------------------------
    if p_ap_id(v_i) is not null and p_date(v_i) is not null
    then
      v_check := lock_1appa(p_ap_id(v_i), p_date(v_i), p_wait);
    end if;
    ------------------------------
    if v_check
    then
      util_pkg.add_ct_number_val(v_res, p_locked_value);
    else
      util_pkg.add_ct_number_val(v_res, p_unlocked_value);
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_1pah_i(p_pa number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return personal_account_history%rowtype
is
  v_res personal_account_history%rowtype;
  v_lock boolean := util_pkg.bool_to_bool_2val(p_lock);
  v_wait boolean := util_pkg.bool_to_bool_2val(p_wait);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if v_lock
  then
    ------------------------------
    if v_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_PA_PERSONAL_ACCOUNT_HISTORY)*/
        * into v_res
        from personal_account_history z
        where 1 = 1
        and personal_account = p_pa
        and p_date between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_PA_PERSONAL_ACCOUNT_HISTORY)*/
        * into v_res
        from personal_account_history z
        where 1 = 1
        and personal_account = p_pa
        and p_date between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_PA_PERSONAL_ACCOUNT_HISTORY)*/
      * into v_res
      from personal_account_history z
      where 1 = 1
      and personal_account = p_pa
      and p_date between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_1pah(p_pa number, p_date date) return personal_account_history%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get_1pah_i(p_pa, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_min_date_from_pah(p_pa number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_PA_PERSONAL_ACCOUNT_HISTORY)*/
    min(start_date) into v_res
    from personal_account_history z
    where 1 = 1
    and personal_account = p_pa
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_max_date_from_pah(p_pa number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_PA_PERSONAL_ACCOUNT_HISTORY)*/
    max(start_date) into v_res
    from personal_account_history z
    where 1 = 1
    and personal_account = p_pa
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_max_date_to_pah(p_pa number) return date
is
  v_res date;
begin
  ------------------------------
  select /*+ index_asc(z, I_PA_PERSONAL_ACCOUNT_HISTORY)*/
    max(nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))) into v_res
    from personal_account_history z
    where 1 = 1
    and personal_account = p_pa
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_first_pah(p_pa number) return personal_account_history%rowtype
is
  v_date date;
begin
  ------------------------------
  v_date := get_min_date_from_pah(p_pa);
  ------------------------------
  if v_date is null
  then
    return null;
  end if;
  ------------------------------
  return get_1pah(p_pa, v_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_last_pah(p_pa number) return personal_account_history%rowtype
is
  v_date date;
begin
  ------------------------------
  v_date := get_max_date_to_pah(p_pa);
  ------------------------------
  if v_date is null
  then
    return null;
  end if;
  ------------------------------
  return get_1pah(p_pa, v_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_1pah(p_pa number, p_date date, p_wait boolean) return boolean
is
  v_is_locked boolean;
  v_rec personal_account_history%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_rec := get_1pah_i(p_pa, p_date, TRUE, p_wait, v_is_locked);
  ------------------------------
  if (1 = 0
    or v_is_locked
    or v_rec.personal_account is null
  )
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_pah(p_pa ct_number, p_date ct_date, p_wait boolean, p_locked_value number := util_pkg.c_true, p_unlocked_value number := util_pkg.c_false) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_check boolean;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_pa);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_pa) != v_main_count, 'p_pa.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count < 1
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_pa.first..p_pa.last
  loop
    ------------------------------
    v_check := false;
    ------------------------------
    if p_pa(v_i) is not null and p_date(v_i) is not null
    then
      v_check := lock_1pah(p_pa(v_i), p_date(v_i), p_wait);
    end if;
    ------------------------------
    if v_check
    then
      util_pkg.add_ct_number_val(v_res, p_locked_value);
    else
      util_pkg.add_ct_number_val(v_res, p_unlocked_value);
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_1pn_i(p_id number, p_lock boolean, p_wait boolean, p_is_locked out boolean) return phone_number%rowtype
is
  v_res phone_number%rowtype;
  v_lock boolean := util_pkg.bool_to_bool_2val(p_lock);
  v_wait boolean := util_pkg.bool_to_bool_2val(p_wait);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if v_lock
  then
    ------------------------------
    if v_wait
    then
      ------------------------------
      select /*+ index_asc(z, PK_PHONE_NUMBER)*/
        * into v_res
        from phone_number z
        where 1 = 1
        and network_address_id = p_id
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, PK_PHONE_NUMBER)*/
        * into v_res
        from phone_number z
        where 1 = 1
        and network_address_id = p_id
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, PK_PHONE_NUMBER)*/
      * into v_res
      from phone_number z
      where 1 = 1
      and network_address_id = p_id
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_1pn(p_id number) return phone_number%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get_1pn_i(p_id, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_1pn(p_id number, p_wait boolean) return boolean
is
  v_is_locked boolean;
  v_rec phone_number%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_rec := get_1pn_i(p_id, TRUE, p_wait, v_is_locked);
  ------------------------------
  if (1 = 0
    or v_is_locked
    or v_rec.network_address_id is null
  )
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get_1pn(p_id number) return phone_number%rowtype
is
  v_res phone_number%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get_1pn_i(p_id, true, false, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_locked, util_pkg.c_msg_object_locked || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_id));
  end if;
  ------------------------------
  if v_res.network_address_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_id));
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xlock_1pn(p_id number)
is
  v_rec phone_number%rowtype;
begin
  ------------------------------
  v_rec := xlock_get_1pn(p_id);
  ------------------------------
  util_loc_pkg.touch_number(v_rec.network_address_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_pn_cursor_by_status
(
  p_status varchar2,
  p_date date
) return sys_refcursor
is
  v_date date := sysdate;
  v_cursor sys_refcursor;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open v_cursor for
select /*+ index(z I_PHONENUM_NASC_EXT)*/
    network_address_id
  from phone_number z
  where 1 = 1
  and net_address_status_code = p_status
  and nvl(deleted, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > v_date
  and nvl(date_of_status_change, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) <= p_date
  ;
  ------------------------------
  return v_cursor;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_1sc_i(p_id number, p_lock boolean, p_wait boolean, p_is_locked out boolean) return sim_card%rowtype
is
  v_res sim_card%rowtype;
  v_lock boolean := util_pkg.bool_to_bool_2val(p_lock);
  v_wait boolean := util_pkg.bool_to_bool_2val(p_wait);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if v_lock
  then
    ------------------------------
    if v_wait
    then
      ------------------------------
      select /*+ index_asc(z, PK_SIM_CARD)*/
        * into v_res
        from sim_card z
        where 1 = 1
        and access_point_id = p_id
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, PK_SIM_CARD)*/
        * into v_res
        from sim_card z
        where 1 = 1
        and access_point_id = p_id
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, PK_SIM_CARD)*/
      * into v_res
      from sim_card z
      where 1 = 1
      and access_point_id = p_id
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_1sc(p_id number) return sim_card%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get_1sc_i(p_id, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_1sc(p_id number, p_wait boolean) return boolean
is
  v_is_locked boolean;
  v_rec sim_card%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_rec := get_1sc_i(p_id, TRUE, p_wait, v_is_locked);
  ------------------------------
  if (1 = 0
    or v_is_locked
    or v_rec.access_point_id is null
  )
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get_1sc(p_id number) return sim_card%rowtype
is
  v_res sim_card%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get_1sc_i(p_id, true, false, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_locked, util_pkg.c_msg_object_locked || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_id));
  end if;
  ------------------------------
  if v_res.access_point_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_id));
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xlock_1sc(p_id number)
is
  v_rec sim_card%rowtype;
begin
  ------------------------------
  v_rec := xlock_get_1sc(p_id);
  ------------------------------
  util_loc_pkg.touch_number(v_rec.access_point_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure prepare_as_pnlnk_i(p_na_id ct_number, p_date date, p_uniquelize boolean, p_trim_empty boolean, p_na_id_m out ct_number, p_na_id_l out ct_number, p_msisdn_m out ct_varchar_s, p_msisdn_l out ct_varchar_s)
is
  v_uniquelize number := util_pkg.bool_to_int_2val(p_uniquelize);
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
select /*+ ordered use_nl(q, pn, plm, pll, pnl, pnm)
  index_asc(pn, PK_PHONE_NUMBER)
  index_asc(plm, PK_PHONE_LINK)
  index_asc(pll, I_PHONE_LINK_LINKED_MSISDN)
  index_asc(pnl, UK_PHONE_NUM_PHONE_NUMBER)
  index_asc(pnm, UK_PHONE_NUM_PHONE_NUMBER)
  */
  decode(v_uniquelize, util_pkg.c_true, 0, q.rn) rn,
  decode(pll.linked_msisdn, null, pn.network_address_id, pnm.network_address_id) na_id_m,
  decode(plm.main_msisdn, null, decode(pll.linked_msisdn, null, null, pn.network_address_id), pnl.network_address_id) na_id_l,
  decode(pll.linked_msisdn, null, pn.international_format, pll.main_msisdn) msisdn_m,
  decode(plm.main_msisdn, null, pll.linked_msisdn, plm.linked_msisdn) msisdn_l
  bulk collect into v_rn, p_na_id_m, p_na_id_l, p_msisdn_m, p_msisdn_l
  from
    (select column_value network_address_id, rownum rn from table(p_na_id)) q,
    phone_number pn,
    phone_link plm, phone_link pll,
    phone_number pnl, phone_number pnm
  where 1 = 1
  --
  and pn.network_address_id(+) = q.network_address_id
  and nvl(pn.deleted(+), p_date + c_dummy_date_shift) > p_date
  --
  and plm.main_msisdn(+) = pn.international_format
  --
  and pll.linked_msisdn(+) = pn.international_format
  --
  and pnl.international_format(+) = plm.linked_msisdn
  and nvl(pnl.deleted(+), p_date + c_dummy_date_shift) > p_date
  --
  and pnm.international_format(+) = pll.main_msisdn
  and nvl(pnm.deleted(+), p_date + c_dummy_date_shift) > p_date
  --
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(pn.network_address_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  --
  group by
  decode(v_uniquelize, util_pkg.c_true, 0, q.rn),
  decode(pll.linked_msisdn, null, pn.network_address_id, pnm.network_address_id),
  decode(plm.main_msisdn, null, decode(pll.linked_msisdn, null, null, pn.network_address_id), pnl.network_address_id),
  decode(pll.linked_msisdn, null, pn.international_format, pll.main_msisdn),
  decode(plm.main_msisdn, null, pll.linked_msisdn, plm.linked_msisdn)
  --
  order by rn, na_id_m, na_id_l, msisdn_m, msisdn_l
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_as_pnlnk_exact(p_na_id ct_number, p_date date, p_na_id_m out ct_number, p_na_id_l out ct_number, p_msisdn_m out ct_varchar_s, p_msisdn_l out ct_varchar_s)
is
begin
  ------------------------------
  prepare_as_pnlnk_i(p_na_id, p_date, FALSE, FALSE, p_na_id_m, p_na_id_l, p_msisdn_m, p_msisdn_l);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_as_pnlnk_fuzzy(p_na_id ct_number, p_date date, p_na_id_m out ct_number, p_na_id_l out ct_number, p_msisdn_m out ct_varchar_s, p_msisdn_l out ct_varchar_s)
is
begin
  ------------------------------
  prepare_as_pnlnk_i(p_na_id, p_date, TRUE, TRUE, p_na_id_m, p_na_id_l, p_msisdn_m, p_msisdn_l);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_as_pnlnk2_exact(p_na_id ct_number, p_date date, p_na_id_m out ct_number, p_na_id_l out ct_number)
is
  v_msisdn_m ct_varchar_s;
  v_msisdn_l ct_varchar_s;
begin
  ------------------------------
  prepare_as_pnlnk_exact(p_na_id, p_date, p_na_id_m, p_na_id_l, v_msisdn_m, v_msisdn_l);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_as_pnlnk2_fuzzy(p_na_id ct_number, p_date date, p_na_id_m out ct_number, p_na_id_l out ct_number)
is
  v_msisdn_m ct_varchar_s;
  v_msisdn_l ct_varchar_s;
begin
  ------------------------------
  prepare_as_pnlnk_fuzzy(p_na_id, p_date, p_na_id_m, p_na_id_l, v_msisdn_m, v_msisdn_l);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_as_pnlnk2_fuzzy_fuzzy(p_na_id ct_number, p_date date, p_na_id_m out ct_number, p_na_id_l out ct_number)
is
  v_msisdn_m ct_varchar_s;
  v_msisdn_l ct_varchar_s;
begin
  ------------------------------
  prepare_as_pnlnk_fuzzy(p_na_id, p_date, p_na_id_m, p_na_id_l, v_msisdn_m, v_msisdn_l);
  ------------------------------
  p_na_id_l := util_pkg.filter_val_ct_number_1val(p_na_id_l, NULL, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_as_pnlnk3_exact(p_na_id ct_number, p_date date, p_msisdn_m out ct_varchar_s, p_msisdn_l out ct_varchar_s)
is
  v_na_id_m ct_number;
  v_na_id_l ct_number;
begin
  ------------------------------
  prepare_as_pnlnk_exact(p_na_id, p_date, v_na_id_m, v_na_id_l, p_msisdn_m, p_msisdn_l);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_as_pnlnk3_fuzzy(p_na_id ct_number, p_date date, p_msisdn_m out ct_varchar_s, p_msisdn_l out ct_varchar_s)
is
  v_na_id_m ct_number;
  v_na_id_l ct_number;
begin
  ------------------------------
  prepare_as_pnlnk_fuzzy(p_na_id, p_date, v_na_id_m, v_na_id_l, p_msisdn_m, p_msisdn_l);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_as_pnlnk3_fuzzy_fuzzy(p_na_id ct_number, p_date date, p_msisdn_m out ct_varchar_s, p_msisdn_l out ct_varchar_s)
is
  v_na_id_m ct_number;
  v_na_id_l ct_number;
begin
  ------------------------------
  prepare_as_pnlnk_fuzzy(p_na_id, p_date, v_na_id_m, v_na_id_l, p_msisdn_m, p_msisdn_l);
  ------------------------------
  p_msisdn_l := util_pkg.filter_val_ct_varchar_s_1val(p_msisdn_l, NULL, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_as_pnlnk_naid_m_exact(p_na_id ct_number, p_date date) return ct_number
is
  v_res ct_number;
  v_dummy ct_number;
begin
  ------------------------------
  prepare_as_pnlnk2_exact(p_na_id, p_date, v_res, v_dummy);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_as_pnlnk_naid_m_fuzzy(p_na_id ct_number, p_date date) return ct_number
is
  v_res ct_number;
  v_dummy ct_number;
begin
  ------------------------------
  prepare_as_pnlnk2_fuzzy(p_na_id, p_date, v_res, v_dummy);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_as_pnlnk_naid_l_exact(p_na_id ct_number, p_date date) return ct_number
is
  v_res ct_number;
  v_dummy ct_number;
begin
  ------------------------------
  prepare_as_pnlnk2_exact(p_na_id, p_date, v_dummy, v_res);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_as_pnlnk_naid_l_fuzzy(p_na_id ct_number, p_date date) return ct_number
is
  v_res ct_number;
  v_dummy ct_number;
begin
  ------------------------------
  prepare_as_pnlnk2_fuzzy(p_na_id, p_date, v_dummy, v_res);
  ------------------------------
  return util_pkg.filter_val_ct_number_1val(v_res, NULL, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_as_pnlnk_naid_exact(p_na_id ct_number, p_date date) return ct_number
is
  v_res ct_number;
  v_add ct_number;
begin
  ------------------------------
  prepare_as_pnlnk2_exact(p_na_id, p_date, v_res, v_add);
  ------------------------------
  util_pkg.add_ct_number(v_res, v_add);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_as_pnlnk_naid_fuzzy(p_na_id ct_number, p_date date) return ct_number
is
  v_res ct_number;
  v_add ct_number;
begin
  ------------------------------
  prepare_as_pnlnk2_fuzzy_fuzzy(p_na_id, p_date, v_res, v_add);
  ------------------------------
  util_pkg.add_ct_number(v_res, v_add);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_as_pnlnk_msisdn_m_exact(p_na_id ct_number, p_date date) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_dummy ct_varchar_s;
begin
  ------------------------------
  prepare_as_pnlnk3_exact(p_na_id, p_date, v_res, v_dummy);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_as_pnlnk_msisdn_m_fuzzy(p_na_id ct_number, p_date date) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_dummy ct_varchar_s;
begin
  ------------------------------
  prepare_as_pnlnk3_fuzzy(p_na_id, p_date, v_res, v_dummy);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_as_pnlnk_msisdn_l_exact(p_na_id ct_number, p_date date) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_dummy ct_varchar_s;
begin
  ------------------------------
  prepare_as_pnlnk3_exact(p_na_id, p_date, v_dummy, v_res);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_as_pnlnk_msisdn_l_fuzzy(p_na_id ct_number, p_date date) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_dummy ct_varchar_s;
begin
  ------------------------------
  prepare_as_pnlnk3_fuzzy(p_na_id, p_date, v_dummy, v_res);
  ------------------------------
  return util_pkg.filter_val_ct_varchar_s_1val(v_res, NULL, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_as_pnlnk_msisdn_exact(p_na_id ct_number, p_date date) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_add ct_varchar_s;
begin
  ------------------------------
  prepare_as_pnlnk3_exact(p_na_id, p_date, v_res, v_add);
  ------------------------------
  util_pkg.add_ct_varchar_s(v_res, v_add);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_as_pnlnk_msisdn_fuzzy(p_na_id ct_number, p_date date) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_add ct_varchar_s;
begin
  ------------------------------
  prepare_as_pnlnk3_fuzzy_fuzzy(p_na_id, p_date, v_res, v_add);
  ------------------------------
  util_pkg.add_ct_varchar_s(v_res, v_add);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pnlnk_other_side_exact(p_na_id ct_number, p_date date) return ct_number
is
  v_res ct_number;
  v_na_id_m ct_number;
  v_na_id_l ct_number;
  v_map_m ct_number;
  v_map_l ct_number;
begin
  ------------------------------
  if util_pkg.get_count_ct_number(p_na_id) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  prepare_as_pnlnk2_exact(p_na_id, p_date, v_na_id_m, v_na_id_l);
  ------------------------------
  util_pkg.resize_ct_number(v_res, util_pkg.get_count_ct_number(p_na_id));
  ------------------------------
  v_map_m := util_pkg.map_ct_number(v_na_id_m, p_na_id, FALSE);
  v_map_l := util_pkg.map_ct_number(v_na_id_l, p_na_id, FALSE);
  ------------------------------
  util_pkg.set_by_pos_ct_number(v_res, v_na_id_m, v_map_l, TRUE);
  util_pkg.set_by_pos_ct_number(v_res, v_na_id_l, v_map_m, TRUE);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pnlnk_other_side_fuzzy(p_na_id ct_number, p_date date) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  v_res := get_pnlnk_other_side_exact(p_na_id, p_date);
  ------------------------------
  v_res := util_pkg.filter_val_ct_number_1val(v_res, NULL, FALSE);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pnlnk_found(p_na_id ct_number, p_na_id_m ct_number, p_na_id_l ct_number) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  v_res := get_pnlnk_not_found(p_na_id, p_na_id_m, p_na_id_l);
  ------------------------------
  v_res := util_pkg.filter_val_ct_number(p_na_id, v_res, FALSE);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pnlnk_found2(p_na_id ct_number, p_na_id_ml ct_number) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  v_res := get_pnlnk_not_found2(p_na_id, p_na_id_ml);
  ------------------------------
  v_res := util_pkg.filter_val_ct_number(p_na_id, v_res, FALSE);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pnlnk_not_found(p_na_id ct_number, p_na_id_m ct_number, p_na_id_l ct_number) return ct_number
is
  v_na_id_ml ct_number;
begin
  ------------------------------
  v_na_id_ml := p_na_id_m;
  ------------------------------
  util_pkg.add_ct_number(v_na_id_ml, p_na_id_l);
  ------------------------------
  return get_pnlnk_not_found2(p_na_id, v_na_id_ml);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pnlnk_not_found2(p_na_id ct_number, p_na_id_ml ct_number) return ct_number
is
  lc_no_value constant number := null;
  v_na_id_ml ct_number;
begin
  ------------------------------
  v_na_id_ml := util_pkg.filter_val_ct_number_1val(p_na_id_ml, lc_no_value, FALSE);
  ------------------------------
  return util_pkg.filter_val_ct_number(p_na_id, v_na_id_ml, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function suppress_plink_m(p_na_id ct_number, p_date date) return ct_number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_na_id := get_as_pnlnk_naid_m_fuzzy(p_na_id, p_date);
  ------------------------------
  return get_pnlnk_not_found2(p_na_id, v_na_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function suppress_plink_l(p_na_id ct_number, p_date date) return ct_number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_na_id := get_as_pnlnk_naid_l_fuzzy(p_na_id, p_date);
  ------------------------------
  return get_pnlnk_not_found2(p_na_id, v_na_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ct_range(p_coll ct_range) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_ct_range(p_coll in out nocopy ct_range, p_val ot_range)
is
begin
  ------------------------------
  if get_count_ct_range(p_coll) = 0
  then
    return;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    p_coll(v_i) := p_val;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_ct_range(p_coll in out nocopy ct_range, p_size number)
is
  v_dif number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_range();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_range(p_count number, p_val ot_range) return ct_range
is
  v_res ct_range;
begin
  ------------------------------
  resize_ct_range(v_res, p_count);
  fill_ct_range(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_range_val(p_coll in out nocopy ct_range, p_val ot_range)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_range();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_range(p_vals ct_range, p_filter_vals ct_range, p_include_by_filter boolean) return ct_range
is
  v_res ct_range;
  v_include_by_filter number := util_pkg.bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_include_by_filter is null, 'p_include_by_filter');
  ------------------------------
  if get_count_ct_range(p_vals) = 0
  then
    return v_res;
  end if;
  ------------------------------
  if get_count_ct_range(p_filter_vals) = 0
  then
    ------------------------------
    if p_include_by_filter
    then
      return v_res;
    else
      return p_vals;
    end if;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q1.val
    bulk collect into v_res
    from
      (select ot_range(val1, val2, num1, num2, num3, dat1, num4) val, rownum rn from table(p_vals)) q1,
      (select ot_range(val1, val2, num1, num2, num3, dat1, num4) val, rownum rn from table(p_filter_vals)) q2
    where 1 = 1
    and nvl2(q2.val(+), util_pkg.c_false, util_pkg.c_true) = nvl2(q1.val, util_pkg.c_false, util_pkg.c_true)
    and nvl(q2.val(+), c_no_value_not_null_ot_range) = nvl(q1.val, c_no_value_not_null_ot_range)
    and decode(q2.rn, null, util_pkg.c_false, util_pkg.c_true) = v_include_by_filter
    order by q1.rn
  ;
    ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_range_1val(p_vals ct_range, p_filter_val ot_range, p_include_by_filter boolean) return ct_range
is
  v_coll ct_range;
begin
  ------------------------------
  add_ct_range_val(v_coll, p_filter_val);
  ------------------------------
  return filter_val_ct_range(p_vals, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_range_num2(p_vals ct_range, p_filter_vals ct_number, p_include_by_filter boolean) return ct_range
is
  v_res ct_range;
  v_include_by_filter number := util_pkg.bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_include_by_filter is null, 'p_include_by_filter');
  ------------------------------
  if get_count_ct_range(p_vals) = 0
  then
    return v_res;
  end if;
  ------------------------------
  if util_pkg.get_count_ct_number(p_filter_vals) = 0
  then
    ------------------------------
    if p_include_by_filter
    then
      return v_res;
    else
      return p_vals;
    end if;
    ------------------------------
  end if;
    ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q1.val
    bulk collect into v_res
    from
      (select ot_range(val1, val2, num1, num2, num3, dat1, num4) val, rownum rn from table(p_vals)) q1,
      (select column_value val_num2, rownum rn from table(p_filter_vals)) q2
    where 1 = 1
    and nvl2(q2.val_num2(+), util_pkg.c_false, util_pkg.c_true) = nvl2(q1.val.num2, util_pkg.c_false, util_pkg.c_true)
    and nvl(q2.val_num2(+), util_pkg.c_no_value_not_null_number) = nvl(q1.val.num2, util_pkg.c_no_value_not_null_number)
    and decode(q2.rn, null, util_pkg.c_false, util_pkg.c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_range_num2_1val(p_vals ct_range, p_filter_val number, p_include_by_filter boolean) return ct_range
is
  v_coll ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_coll, p_filter_val);
  ------------------------------
  return filter_val_ct_range_num2(p_vals, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ot_range
(
  p_val1 nvarchar2,
  p_val2 nvarchar2,
  p_num1 number,
  p_num2 number,
  p_num3 number,
  p_dat1 date,
  p_num4 number
) return ot_range
is
begin
  ------------------------------
  return ot_range
  (
    p_val1,
    p_val2,
    p_num1,
    p_num2,
    p_num3,
    p_dat1,
    p_num4
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ot_range1
(
  p_range_start nvarchar2,
  p_range_end nvarchar2,
  p_model_id number,
  p_id_original number,
  p_quantity number,
  p_valid_until date
) return ot_range
is
begin
  ------------------------------
  return make_ot_range
  (
    p_val1 => p_range_start,
    p_val2 => p_range_end,
    p_num1 => p_model_id,
    p_num2 => p_id_original,
    p_num3 => p_quantity,
    p_dat1 => p_valid_until,
    p_num4 => null
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_range0
(
  p_val1 ct_nvarchar_s,
  p_val2 ct_nvarchar_s,
  p_num1 ct_number,
  p_num2 ct_number,
  p_num3 ct_number,
  p_dat1 ct_date,
  p_num4 ct_number
) return ct_range
is
  v_res ct_range;
begin
  ------------------------------
select /*+ ordered use_hash(q0, q1, q2, q3, q4, q5, q6)*/
  ot_range
  (
    q0.val1,
    q1.val2,
    q2.num1,
    q3.num2,
    q4.num3,
    q5.dat1,
    q6.num4
  ) val
  bulk collect into v_res
  from
    (select column_value val1, rownum rn from table(p_val1)) q0,
    (select column_value val2, rownum rn from table(p_val2)) q1,
    (select column_value num1, rownum rn from table(p_num1)) q2,
    (select column_value num2, rownum rn from table(p_num2)) q3,
    (select column_value num3, rownum rn from table(p_num3)) q4,
    (select column_value dat1, rownum rn from table(p_dat1)) q5,
    (select column_value num4, rownum rn from table(p_num4)) q6
  where 1 = 1
  and q1.rn(+) = q0.rn
  and q2.rn(+) = q0.rn
  and q3.rn(+) = q0.rn
  and q4.rn(+) = q0.rn
  and q5.rn(+) = q0.rn
  and q6.rn(+) = q0.rn
  order by q0.rn, q1.rn, q2.rn, q3.rn, q4.rn, q5.rn, q6.rn
  ;
    ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_range1
(
  p_val1 ct_nvarchar_s,
  p_val2 ct_nvarchar_s
) return ct_range
is
begin
  ------------------------------
  return make_ct_range2
  (
    p_val1 => p_val1,
    p_val2 => p_val2,
    p_num1 => null
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_range2
(
  p_val1 ct_nvarchar_s,
  p_val2 ct_nvarchar_s,
  p_num1 ct_number
) return ct_range
is
begin
  ------------------------------
  return make_ct_range3
  (
    p_val1 => p_val1,
    p_val2 => p_val2,
    p_num1 => p_num1,
    p_num2 => null
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_range3
(
  p_val1 ct_nvarchar_s,
  p_val2 ct_nvarchar_s,
  p_num1 ct_number,
  p_num2 ct_number
) return ct_range
is
begin
  ------------------------------
  return make_ct_range0
  (
    p_val1 => p_val1,
    p_val2 => p_val2,
    p_num1 => p_num1,
    p_num2 => p_num2,
    p_num3 => null,
    p_dat1 => null,
    p_num4 => null
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_sim_series_range4host(p_host_id number, p_date date, p_sim_card_type_code varchar2 := null) return ct_range
is
  v_res ct_range;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  --!_! util_pkg.XCheck_Cond_Missing(p_sim_card_type_code is null, 'p_sim_card_type_code');
  ------------------------------
  select /*+ no_expand index(ss I_SIMSERIES_HOST_ID)*/
    ot_range
    (
      util_pkg.char_to_nchar(ss.start_imsi_number), --val1
      util_pkg.char_to_nchar(ss.end_imsi_number), --val2
      ss.sim_series_id, --num1
      null, --num2
      null, --num3
      null, --dat1
      null --num4
    )
    bulk collect into v_res
    from sim_series ss
    where 1 = 1
    and ss.host_id = p_host_id
    and ss.sim_card_type_code = nvl(p_sim_card_type_code, ss.sim_card_type_code)
    and nvl(ss.deleted, p_date + c_dummy_date_shift) > p_date
    order by ss.start_imsi_number
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
