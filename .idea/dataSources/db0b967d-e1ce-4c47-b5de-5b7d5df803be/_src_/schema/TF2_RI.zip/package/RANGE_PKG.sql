CREATE package RANGE_PKG is

----------------------------------!---------------------------------------------
  c_locker_type                  number := util_ri.c_locker_type_pns_range;

----------------------------------!---------------------------------------------
  c_opt_break_down_desired_cnt   constant varchar2(100) := 'Range.BreakdownDesiredCount';

----------------------------------!---------------------------------------------
  c_def_break_down_desired_cnt   constant number := 1000; --!_! break down to dust

----------------------------------!---------------------------------------------
  --!_!serialization items

  c_srzi_range_id                constant integer := 1;
  c_srzi_range_item_from         constant integer := 2;
  c_srzi_range_item_to           constant integer := 3;
  c_srzi_range_val1              constant integer := 4;
  c_srzi_range_val2              constant integer := 5;
  c_srzi_range_val3              constant integer := 6;
  c_srzi_count_range             constant number := c_srzi_range_val3;

  type t_range is record
  (
    id number,
    item_from varchar2(50),
    item_to varchar2(50),
    val1 number,
    val2 number,
    val3 number
  );

  type lct_range is table of t_range;
  type lcit_range is table of t_range index by binary_integer;

----------------------------------!---------------------------------------------
  procedure XCheck_equivalent(p_item1 varchar2, p_item2 varchar2);
  procedure XCheck_rangeable(p_item_from varchar2, p_item_to varchar2);
  procedure XCheck_3rangeable(p_item_from varchar2, p_item_between varchar2, p_item_to varchar2);
  procedure XCheck_3rangeable4split(p_item_from varchar2, p_item_between varchar2, p_item_to varchar2);
  procedure XCheck_t_range(p_range t_range, p_check_vals boolean);
  procedure XCheck_range_items(p_item_froms ct_varchar_s, p_item_tos ct_varchar_s);
  procedure XCheck_ranges_ordered(p_item_froms ct_varchar_s, p_item_tos ct_varchar_s);
  procedure XCheck_ranges_continuous(p_item_froms ct_varchar_s, p_item_tos ct_varchar_s);

----------------------------------!---------------------------------------------
  function range_serialize(p_obj t_range, p_delim varchar2) return clob;
  function range_deserialize(p_str clob, p_delim varchar2) return t_range;

----------------------------------!---------------------------------------------
  function get_item_length(p_item varchar2) return number;

  function calc_item_count(p_item_from varchar2, p_item_to varchar2) return integer;

  function num2item(p_item_num number, p_length number) return varchar2;
  function item2num(p_item varchar2) return number;

  function is_rangeable(p_item_from varchar2, p_item_to varchar2) return boolean;
  function is_3rangeable(p_item_from varchar2, p_item_between varchar2, p_item_to varchar2) return boolean;

  function is_equal(p_item1 varchar2, p_item2 varchar2) return boolean;
  function is_greater(p_item1 varchar2, p_item2 varchar2) return boolean;
  function is_greater_eq(p_item1 varchar2, p_item2 varchar2) return boolean;
  function is_less(p_item1 varchar2, p_item2 varchar2) return boolean;
  function is_less_eq(p_item1 varchar2, p_item2 varchar2) return boolean;

  function compare_items(p_item1 varchar2, p_item2 varchar2) return number;
  function compare_items_num(p_item_num1 number, p_item_num2 number) return number;

  function shift_item(p_item varchar2, p_shift number) return varchar2;
  function shift_item_num(p_item_num number, p_shift number) return number;

  function item_from2item_to_limited(p_item_from varchar2, p_item_count number, p_item_to_limit varchar2) return varchar2;
  function item_from2item_to(p_item_from varchar2, p_item_count number) return varchar2;
  function item_from_num2item_to_num(p_item_from_num number, p_item_count number) return number;

  function item2prev_item(p_item varchar2) return varchar2;
  function item2next_item(p_item varchar2) return varchar2;
  function item_num2prev_item_num(p_item_num number) return number;
  function item_num2next_item_num(p_item_num number) return number;

----------------------------------!---------------------------------------------
  function calc_ranges_count
  (
    p_item_from varchar2,
    p_item_to varchar2,
    p_range_size integer
  ) return integer;

  function calc_range_index4item
  (
    p_item_of_interest varchar2,
    p_range_size integer,
    p_ranges_item_from varchar2
  ) return integer;

----------------------------------!---------------------------------------------
  procedure get_total_range_items
  (
    p_item_froms ct_varchar_s,
    p_item_tos ct_varchar_s,
    p_total_item_from out varchar2,
    p_total_item_to out varchar2
  );

  procedure make_ranges
  (
    p_item_from varchar2,
    p_item_to varchar2,
    p_range_size integer,
    p_range_item_froms out ct_varchar_s,
    p_range_item_tos out ct_varchar_s
  );

  function associate_ranges
  (
    p_item_from varchar2,
    p_item_to varchar2,
    p_range_size integer,
    p_range_numbers ct_number,
    p_range_item_counts ct_number
  ) return ct_number;

----------------------------------!---------------------------------------------
  procedure calc_dichotomic_counts
  (
    p_boundary_index number,
    p_counts ct_number,
    p_count_before out number,
    p_count_boundary out number,
    p_count_after out number
  );

  procedure make_least_dichotomic_ranges
  (
    p_item_boundary varchar2,
    p_item_from varchar2,
    p_item_to varchar2,
    p_range_size integer,
    p_range_item_real_counts_i ct_number,
    p_range_item_approx_counts_o out ct_number,
    p_range_item_froms out ct_varchar_s,
    p_range_item_tos out ct_varchar_s
  );

  procedure break_down_ranges
  (
    p_desired_range_count integer,
    p_range_item_counts ct_number,
    p_range_item_froms ct_varchar_s,
    p_range_item_tos ct_varchar_s,
    p_range_item_counts_o out ct_number,
    p_range_item_froms_o out ct_varchar_s,
    p_range_item_tos_o out ct_varchar_s
  );

  --!_!results (_o) can be shorter than p_target_range_count for sum(p_range_item_counts) = 0; but 1 range in any case
  procedure merge_ranges
  (
    p_max_target_range_count integer,
    p_range_item_counts ct_number,
    p_range_item_froms ct_varchar_s,
    p_range_item_tos ct_varchar_s,
    p_range_item_counts_o out ct_number,
    p_range_item_froms_o out ct_varchar_s,
    p_range_item_tos_o out ct_varchar_s
  );

  procedure make_target_ranges_by_blocks
  (
    p_item_boundary varchar2,
    p_item_from varchar2,
    p_item_to varchar2,
    p_block_size integer,
    p_block_numbers ct_number,
    p_block_item_counts ct_number,
    p_max_target_range_count integer,
    p_ranges_approx_count out ct_number,
    p_ranges_from out ct_varchar_s,
    p_ranges_to out ct_varchar_s
  );

  function calc_block_size
  (
    p_item_from varchar2,
    p_item_to varchar2,
    p_block_count integer
  ) return integer;

  procedure prepare_splitted_ranges_meta
  (
    p_item_split_from varchar2,
    p_range t_range,
    p_range2change_item_from varchar2,
    p_range2change_item_to varchar2,
    p_range_to_creation_id number,
    p_range_to_truncation out t_range,
    p_range_to_creation out t_range
  );

----------------------------------!---------------------------------------------
  function xget_locker_id(p_range t_range) return number;

----------------------------------!---------------------------------------------
  function make_unique_ranges
  (
    p_range_with_length1 ct_range,
    p_range_with_length2 ct_range
  ) return ct_range;

  function make_unique_ranges2
  (
    p_range_with_length ct_range
  ) return ct_range;

----------------------------------!---------------------------------------------

end;
/
