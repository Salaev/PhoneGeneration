CREATE package pn_life_pkg is

----------------------------------!---------------------------------------------
  --c_ora_                         constant number(5) := -20999;
  
----------------------------------!---------------------------------------------
  --c_msg_                         constant varchar2(200) := '';

----------------------------------!---------------------------------------------
  c_ch_type_none                 constant number := -1;
  c_ch_type_auto                 constant number := 0;
  c_ch_type_open                 constant number := 1;
  c_ch_type_close                constant number := 2;

  c_act_type_auto                constant number := 0;
  c_act_type_accept              constant number := 1;
  c_act_type_reject              constant number := 2;

----------------------------------!---------------------------------------------
  g_now_margin_left              number;
  g_now_margin_right             number;

----------------------------------!---------------------------------------------
  c_sett_pendch_now_margin_l_sec constant varchar2(100) := 'PendingChanges.NowMarginLeftSeconds';
  c_sett_pendch_now_margin_r_sec constant varchar2(100) := 'PendingChanges.NowMarginRightSeconds';
  c_sett_pendch_nash_bcount      constant varchar2(100) := 'PendingChanges.NASHBatchCount';
  c_sett_pendch_pnsc_bcount      constant varchar2(100) := 'PendingChanges.PNSCBatchCount';
  c_sett_pendch_naap_bcount      constant varchar2(100) := 'PendingChanges.NAAPBatchCount';

  c_def_pendch_now_margin_l_sec  constant number := 60;
  c_def_pendch_now_margin_r_sec  constant number := 60;
  c_def_pendch_nash_bcount       constant number := util_ri.c_any_count;
  c_def_pendch_pnsc_bcount       constant number := util_ri.c_any_count;
  c_def_pendch_naap_bcount       constant number := util_ri.c_any_count;

  c_def_commit_batch_nash        constant number := 1;
  c_def_commit_batch_pnsc        constant number := 1;
  c_def_commit_batch_naap        constant number := 1;

----------------------------------!---------------------------------------------
  type ctl_changes_nash is table of changes_nash%rowtype;
  type ctl_changes_pnsc is table of changes_pnsc%rowtype;
  type ctl_changes_naap is table of changes_naap%rowtype;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure xvalidate_action_type(p_action_type number);

----------------------------------!---------------------------------------------
  function is_current_change(p_change_date date, p_date date) return boolean;
  function is_future_change(p_change_date date, p_date date) return boolean;
  function is_future_open(p_date_from date, p_date date) return boolean;
  function is_future_close(p_date_to date, p_date date) return boolean;
  function is_current_version(p_date_from date, p_date_to date, p_date date) return boolean;

----------------------------------!---------------------------------------------
  function get_act_accept_change_type(p_date_from date, p_date_to date, p_date date) return number;
  function get_act_reject_change_type(p_date_from date, p_date_to date, p_date date) return number;
  function get_act_auto_change_type(p_date_from date, p_date_to date, p_date date) return number;

  function get_change_type(p_action_type number, p_date_from date, p_date_to date, p_date date) return number;
  function get_change_date(p_action_type number, p_change_type number, p_date_from date, p_date_to date) return date;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure set_pn_nash(p_na_id number, p_na_stat varchar2, p_date_from date);
  procedure set_pn_pnsc(p_na_id number, p_sal_cat varchar2);
  procedure set_pn_naap(p_na_id number, p_ap_id number, p_date_from date);
  procedure set_pn_pl_main(p_na_id number, p_msisdn varchar2);
  procedure set_pn_pl_link(p_na_id number, p_msisdn varchar2);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure regch_nash_i(p_rec changes_nash%rowtype, p_change_type number);
  function unregch_nash_ii(p_rec changes_nash%rowtype, p_change_type number) return boolean;
  procedure unregch_nash_i(p_rec changes_nash%rowtype, p_change_type number);

  function nash2changes(p_rec network_address_status_history%rowtype) return changes_nash%rowtype;

----------------------------------!---------------------------------------------
  procedure regch_pnsc_i(p_rec changes_pnsc%rowtype, p_change_type number);
  function unregch_pnsc_ii(p_rec changes_pnsc%rowtype, p_change_type number) return boolean;
  procedure unregch_pnsc_i(p_rec changes_pnsc%rowtype, p_change_type number);

  function pnsc2changes(p_rec phone_number_salability_categ%rowtype) return changes_nash%rowtype;

----------------------------------!---------------------------------------------
  procedure regch_naap_i(p_rec changes_naap%rowtype, p_change_type number);
  function unregch_naap_ii(p_rec changes_naap%rowtype, p_change_type number) return boolean;
  procedure unregch_naap_i(p_rec changes_naap%rowtype, p_change_type number);

  function naap2changes(p_rec network_address_access_point%rowtype) return changes_naap%rowtype;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure use_pn_nash_ii(p_rec changes_nash%rowtype, p_change_date date);
  procedure free_pn_nash_ii(p_rec changes_nash%rowtype, p_change_date date);

  procedure change_pn_nash_i(p_rec changes_nash%rowtype, p_action_type number);

  procedure accept_pn_nash_i(p_rec changes_nash%rowtype);
  procedure reject_pn_nash_i(p_rec changes_nash%rowtype);
  procedure accept_pn_nash(p_rec network_address_status_history%rowtype);
  procedure reject_pn_nash(p_rec network_address_status_history%rowtype);

  function is_diff_nash(p_old network_address_status_history%rowtype, p_new network_address_status_history%rowtype) return boolean;

  procedure update_pn_nash_flds_aft_ins(p_old network_address_status_history%rowtype, p_new network_address_status_history%rowtype);
  procedure update_pn_nash_flds_aft_upd(p_old network_address_status_history%rowtype, p_new network_address_status_history%rowtype);
  procedure update_pn_nash_flds_aft_del(p_old network_address_status_history%rowtype, p_new network_address_status_history%rowtype);

----------------------------------!---------------------------------------------
  procedure use_pn_pnsc_ii(p_rec changes_pnsc%rowtype, p_change_date date);
  procedure free_pn_pnsc_ii(p_rec changes_pnsc%rowtype, p_change_date date);

  procedure change_pn_pnsc_i(p_rec changes_pnsc%rowtype, p_action_type number);

  procedure accept_pn_pnsc_i(p_rec changes_pnsc%rowtype);
  procedure reject_pn_pnsc_i(p_rec changes_pnsc%rowtype);
  procedure accept_pn_pnsc(p_rec phone_number_salability_categ%rowtype);
  procedure reject_pn_pnsc(p_rec phone_number_salability_categ%rowtype);

  function is_diff_pnsc(p_old phone_number_salability_categ%rowtype, p_new phone_number_salability_categ%rowtype) return boolean;

  procedure update_pn_pnsc_flds_aft_ins(p_old phone_number_salability_categ%rowtype, p_new phone_number_salability_categ%rowtype);
  procedure update_pn_pnsc_flds_aft_upd(p_old phone_number_salability_categ%rowtype, p_new phone_number_salability_categ%rowtype);
  procedure update_pn_pnsc_flds_aft_del(p_old phone_number_salability_categ%rowtype, p_new phone_number_salability_categ%rowtype);

----------------------------------!---------------------------------------------
  procedure use_pn_naap_ii(p_rec changes_naap%rowtype, p_change_date date);
  procedure free_pn_naap_ii(p_rec changes_naap%rowtype, p_change_date date);

  procedure change_pn_naap_i(p_rec changes_naap%rowtype, p_action_type number);

  procedure accept_pn_naap_i(p_rec changes_naap%rowtype);
  procedure reject_pn_naap_i(p_rec changes_naap%rowtype);
  procedure accept_pn_naap(p_rec network_address_access_point%rowtype);
  procedure reject_pn_naap(p_rec network_address_access_point%rowtype);

  function is_diff_naap(p_old network_address_access_point%rowtype, p_new network_address_access_point%rowtype) return boolean;

  procedure update_pn_naap_flds_aft_ins(p_old network_address_access_point%rowtype, p_new network_address_access_point%rowtype);
  procedure update_pn_naap_flds_aft_upd(p_old network_address_access_point%rowtype, p_new network_address_access_point%rowtype);
  procedure update_pn_naap_flds_aft_del(p_old network_address_access_point%rowtype, p_new network_address_access_point%rowtype);

----------------------------------!---------------------------------------------
  procedure accept_pn_pl(p_rec phone_link%rowtype);
  procedure reject_pn_pl(p_rec phone_link%rowtype);
  function is_diff_pl(p_old phone_link%rowtype, p_new phone_link%rowtype) return boolean;

  procedure update_pn_pl_flds_aft_ins(p_old phone_link%rowtype, p_new phone_link%rowtype);
  procedure update_pn_pl_flds_aft_upd(p_old phone_link%rowtype, p_new phone_link%rowtype);
  procedure update_pn_pl_flds_aft_del(p_old phone_link%rowtype, p_new phone_link%rowtype);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function get_count_ctl_changes_nash(p_coll ctl_changes_nash) return number;
  function get_changes_nash(p_date date) return ctl_changes_nash;
  procedure proc_changes_nash_i(p_date date, p_commit_batch number);
  procedure proc_changes_nash;

----------------------------------!---------------------------------------------
  function get_count_ctl_changes_pnsc(p_coll ctl_changes_pnsc) return number;
  function get_changes_pnsc(p_date date) return ctl_changes_pnsc;
  procedure proc_changes_pnsc_i(p_date date, p_commit_batch number);
  procedure proc_changes_pnsc;

----------------------------------!---------------------------------------------
  function get_count_ctl_changes_naap(p_coll ctl_changes_naap) return number;
  function get_changes_naap(p_date date) return ctl_changes_naap;
  procedure proc_changes_naap_i(p_date date, p_commit_batch number);
  procedure proc_changes_naap;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
