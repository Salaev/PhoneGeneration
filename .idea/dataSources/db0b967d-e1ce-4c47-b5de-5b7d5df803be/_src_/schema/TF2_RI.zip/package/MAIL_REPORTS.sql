CREATE PACKAGE          "MAIL_REPORTS" IS
/****************************************************************************
<header>
  <name>             	package MAIL_REPORTS
  </name>

  <author>           	Petr Cepek
  </author>

  <version>         1.1    13.1.2006  Petr Cepek
                           all procedures for mail reports rewritten
                    1.0  9.6.2005 8:56:22  -  created
  </version>

  <Description>
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/


/****************************************************************************
<header>
  <name>            procedure Get_Log
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  9.6.2005 9:48:13  -  created
  </version>

  <Description>
  </Description>

  <Prerequisites>
                    Procedure returnsin cursor p_result rows from table log_event
                    for defined time period.
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Log(
   p_start_date    IN  DATE,
   p_end_date      IN  DATE,
   p_raise_error   IN  CHAR,
   p_result        OUT sys_refcursor,
   error_code      OUT NUMBER,
   error_message   OUT VARCHAR2
);

/****************************************************************************
<header>
  <name>            procedure Get_Datafiles_Info
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  9.6.2005 9:48:13  -  created
  </version>

  <Description>
  </Description>

  <Prerequisites>
                    Procedure return in cursor p_result information about
                    database files in HTML format.
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
/*
PROCEDURE Get_Datafiles_Info(
  p_raise_error   IN  CHAR,
  p_result        OUT CLOB,
  error_code      OUT NUMBER,
  error_message   OUT VARCHAR2
);*/

/****************************************************************************
<header>
  <name>            procedure Get_Tables_Info
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  9.6.2005 9:48:13  -  created
  </version>

  <Description>
  </Description>

  <Prerequisites>
                    Procedure returns in cursor p_cursor information about all tables.
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Tables_Info(
  p_raise_error   IN   CHAR,
  p_result        OUT  sys_refcursor,
  error_code      OUT  NUMBER,
  error_message   OUT  VARCHAR2
);

/****************************************************************************
<header>
  <name>            procedure Get_Index_Info
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  9.6.2005 9:48:13  -  created
  </version>

  <Description>
  </Description>

  <Prerequisites>
                    Procedure returns in cursor p_result information about all indexes.
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Index_Info(
  p_raise_error   IN   CHAR,
  p_result        OUT  sys_refcursor,
  error_code      OUT  NUMBER,
  error_message   OUT  VARCHAR2
);
/****************************************************************************
<header>
  <name>            procedure Get_Constraints_Info
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  9.6.2005 9:48:13  -  created
  </version>

  <Description>
  </Description>

  <Prerequisites>
                    Procedure returns in cursor p_result information about all constraints.
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Constraints_Info(
  p_raise_error   IN  CHAR,
  p_result        OUT sys_refcursor,
  error_code      OUT NUMBER,
  error_message   OUT VARCHAR2
);

/****************************************************************************
<header>
  <name>            procedure Get_Jobs_Info
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  9.6.2005 9:48:13  -  created
  </version>

  <Description>
  </Description>

  <Prerequisites>
                    Procedure returns in cursor p_result information about all jobs.
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Jobs_Info(
  p_raise_error   IN  CHAR,
  p_result        OUT sys_refcursor,
  error_code      OUT NUMBER,
  error_message   OUT VARCHAR2
);

/****************************************************************************
<header>
  <name>            procedure Get_Version_Info
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  9.6.2005 9:48:13  -  created
  </version>

  <Description>
  </Description>

  <Prerequisites>
                    Procedure returns in cursor p_result information about
                    installation of new versions.
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Version_Info(
  p_raise_error   IN  CHAR,
  p_result        OUT sys_refcursor,
  error_code      OUT NUMBER,
  error_message   OUT VARCHAR2
);

END MAIL_REPORTS;





/
