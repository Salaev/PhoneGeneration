CREATE package body install_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure raise_exception(p_code number, p_message varchar2)
is
  v_code number;
  v_message varchar2(2048);
begin
  ------------------------------
  if p_code between c_ora_x_user_min and c_ora_x_user_max
  then
    v_code := p_code;
  else
    v_code := c_ora_x_user_max;
  end if;
  ------------------------------
  v_message := substr(p_message, 1, c_max_error_message_length2);
  ------------------------------
  raise_application_error(v_code, v_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function date_to_char(p_val date) return varchar2
is
begin
  return to_char(p_val, c_date_format_full);
end;

----------------------------------!---------------------------------------------
function number_to_char(p_val number) return varchar2
is
begin
  return to_char(p_val, c_number_format1, c_number_nlsparam);
end;

----------------------------------!---------------------------------------------
function char_to_number(p_val varchar2) return number
is
begin
  return to_number(p_val, c_number_format2, c_number_nlsparam);
end;

----------------------------------!---------------------------------------------
function char_to_date(p_val varchar2) return date
is
begin
  return to_date(p_val, c_date_format_full);
end;

----------------------------------!---------------------------------------------
function char_to_nchar(p_val varchar2) return nvarchar2
is
begin
  return to_nchar(p_val);
end;

----------------------------------!---------------------------------------------
function nchar_to_char(p_val nvarchar2) return varchar2
is
begin
  return to_char(p_val);
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function bool_to_int(p_val boolean) return number
is
begin
  return sys.diutil.bool_to_int(p_val);
end;

----------------------------------!---------------------------------------------
function bool_to_int_2val(p_val boolean) return number
is
begin
  return bool_to_int(nvl(p_val, false));
end;

----------------------------------!---------------------------------------------
function bool_to_int_3val(p_val boolean) return number
is
begin
  return bool_to_int(p_val);
end;

----------------------------------!---------------------------------------------
function int_to_bool(p_val number) return boolean
is
begin
  return sys.diutil.int_to_bool(p_val);
end;

----------------------------------!---------------------------------------------
function int_to_bool_2val(p_val number) return boolean
is
begin
  ------------------------------
  return nvl(int_to_bool(p_val), false);
  ------------------------------
exception
when others then
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function int_to_bool_3val(p_val number) return boolean
is
begin
  ------------------------------
  return int_to_bool(int_to_int_3val(p_val));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function bool_to_bool_2val(p_val boolean) return boolean
is
begin
  return int_to_bool_2val(bool_to_int_2val(p_val));
end;

----------------------------------!---------------------------------------------
function int_to_int_2val(p_val number) return number
is
begin
  return bool_to_int_2val(int_to_bool_2val(p_val));
end;

----------------------------------!---------------------------------------------
function int_to_int_3val(p_val number) return number
is
begin
  ------------------------------
  if p_val is null
  then
    return null;
  elsif p_val = 0
  then
    return c_false;
  else
    return c_true;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_option(p_option_name varchar2, p_default varchar2) return varchar2
is
begin
  ------------------------------
  return get_option2(p_option_name, p_default);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_exist_option(p_option_name varchar2) return boolean
is
begin
  ------------------------------
  return is_exist_option2(p_option_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_option1(p_option_name varchar2, p_default varchar2) return varchar2
is
begin
  ------------------------------
  return install_loc_pkg.get_option1(p_option_name, p_default);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_option2(p_option_name varchar2, p_default varchar2) return varchar2
is
begin
  ------------------------------
  return install_loc_pkg.get_option2(p_option_name, p_default);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_exist_option1(p_option_name varchar2) return boolean
is
  v_res boolean := false;
  v_str1 varchar2(4000);
  v_str2 varchar2(4000);
begin
  ------------------------------
  v_str1 := get_option1(p_option_name, 'qwerty');
  ------------------------------
  v_str2 := get_option1(p_option_name, 'asdfgh');
  ------------------------------
  if (v_str1 is null and v_str2 is null) or NOT (v_str1 = 'qwerty' and v_str2 = 'asdfgh')
  then
    v_res := true;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_exist_option2(p_option_name varchar2) return boolean
is
  v_res boolean := false;
  v_str1 varchar2(4000);
  v_str2 varchar2(4000);
begin
  ------------------------------
  v_str1 := get_option2(p_option_name, 'qwerty');
  ------------------------------
  v_str2 := get_option2(p_option_name, 'asdfgh');
  ------------------------------
  if (v_str1 is null and v_str2 is null) or NOT (v_str1 = 'qwerty' and v_str2 = 'asdfgh')
  then
    v_res := true;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_option_str(p_option_name varchar2, p_length number, p_default varchar2) return varchar2
is
begin
  ------------------------------
  return get_option2_str(p_option_name, p_length, p_default);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_option_num(p_option_name varchar2, p_default number) return number
is
begin
  ------------------------------
  return get_option2_num(p_option_name, p_default);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_option_bool(p_option_name varchar2, p_default boolean) return boolean
is
begin
  ------------------------------
  return get_option2_bool(p_option_name, p_default);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_option_date(p_option_name varchar2, p_default date) return date
is
begin
  ------------------------------
  return get_option2_date(p_option_name, p_default);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function nnget_option_str(p_option_name varchar2, p_length number, p_default varchar2) return varchar2
is
begin
  ------------------------------
  return nvl(get_option_str(p_option_name, p_length, p_default), p_default);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function nnget_option_num(p_option_name varchar2, p_default number) return number
is
begin
  ------------------------------
  return nvl(get_option_num(p_option_name, p_default), p_default);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function nnget_option_bool(p_option_name varchar2, p_default boolean) return boolean
is
begin
  ------------------------------
  return nvl(get_option_bool(p_option_name, p_default), p_default);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function nnget_option_date(p_option_name varchar2, p_default date) return date
is
begin
  ------------------------------
  return nvl(get_option_date(p_option_name, p_default), p_default);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_option_str(p_option_name varchar2, p_length number) return varchar2
is
begin
  ------------------------------
  return xget_option2_str(p_option_name, p_length);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_option_num(p_option_name varchar2) return number
is
begin
  ------------------------------
  return xget_option2_num(p_option_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_option_bool(p_option_name varchar2) return boolean
is
begin
  ------------------------------
  return xget_option2_bool(p_option_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_option_date(p_option_name varchar2) return date
is
begin
  ------------------------------
  return xget_option2_date(p_option_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option_str(p_option_name varchar2, p_option_value varchar2, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  ins_option2_str(p_option_name, p_option_value, p_option_dsc, p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option_num(p_option_name varchar2, p_option_value number, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  ins_option2_num(p_option_name, p_option_value, p_option_dsc, p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option_bool(p_option_name varchar2, p_option_value boolean, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  ins_option2_bool(p_option_name, p_option_value, p_option_dsc, p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option_date(p_option_name varchar2, p_option_value date, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  ins_option2_date(p_option_name, p_option_value, p_option_dsc, p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option_value_str(p_option_name varchar2, p_option_value varchar2, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  upd_option2_value_str(p_option_name, p_option_value, p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option_value_num(p_option_name varchar2, p_option_value number, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  upd_option2_value_num(p_option_name, p_option_value, p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option_value_bool(p_option_name varchar2, p_option_value boolean, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  upd_option2_value_bool(p_option_name, p_option_value, p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option_value_date(p_option_name varchar2, p_option_value date, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  upd_option2_value_date(p_option_name, p_option_value, p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option_dsc(p_option_name varchar2, p_option_dsc varchar2, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  upd_option2_dsc(p_option_name, p_option_dsc, p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_option(p_option_name varchar2, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  del_option2(p_option_name, p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xget_option1_str(p_option_name varchar2, p_length number) return varchar2
is
  v_res varchar2(4000);
  v_str varchar2(4000);
begin
  ------------------------------
  v_str := get_option1(p_option_name, null);
  ------------------------------
  begin
    ------------------------------
    v_res := null;
    ------------------------------
    if p_length is null or p_length >= nvl(length(v_str), p_length)
    then
      v_res := v_str;
    end if;
    ------------------------------
  exception
  when others then
    ------------------------------
    v_res := null;
    ------------------------------
  end;
  ------------------------------
  if v_res is null
  then
    raise_exception(c_ora_option_nspec_wrong, c_msg_option_nspec_wrong || c_msg_delim01 || p_option_name);
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xget_option1_num(p_option_name varchar2) return number
is
  v_res number;
  v_str varchar2(4000);
begin
  ------------------------------
  v_str := get_option1(p_option_name, null);
  ------------------------------
  begin
    v_res := char_to_number(v_str);
  exception
  when others then
    v_res := null;
  end;
  ------------------------------
  if v_res is null
  then
    raise_exception(c_ora_option_nspec_wrong, c_msg_option_nspec_wrong || c_msg_delim01 || p_option_name);
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_option1_bool(p_option_name varchar2) return boolean
is
begin
  ------------------------------
  return int_to_bool(xget_option1_num(p_option_name));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_option1_date(p_option_name varchar2) return date
is
  v_res date;
  v_str varchar2(4000);
begin
  ------------------------------
  v_str := get_option1(p_option_name, null);
  ------------------------------
  begin
    v_res := char_to_date(v_str);
  exception
  when others then
    v_res := null;
  end;
  ------------------------------
  if v_res is null
  then
    raise_exception(c_ora_option_nspec_wrong, c_msg_option_nspec_wrong || c_msg_delim01 || p_option_name);
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option1_str(p_option_name varchar2, p_option_value varchar2, p_option_dsc varchar2 := null/*, p_user_id number := null, p_change_date date := null*/)
is
pragma autonomous_transaction;
  v_option_dsc varchar2(4000) := substr(nvl(p_option_dsc, p_option_name), 1, 4000);
  --v_user_id number := p_user_id;
  --v_change_date date := nvl(p_change_date, v_sysdate);
begin
  ------------------------------
  if is_exist_option1(p_option_name)
  then
    return;
  end if;
  ------------------------------
  --if v_user_id is null
  --then
  --  v_user_id := xget_default_user_id;
  --end if;
  ------------------------------
  install_loc_pkg.ins_option1_str(p_option_name, p_option_value, v_option_dsc/*, v_user_id, v_change_date*/);
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option1_num(p_option_name varchar2, p_option_value number, p_option_dsc varchar2 := null/*, p_user_id number := null, p_change_date date := null*/)
is
begin
  ------------------------------
  ins_option1_str(p_option_name, number_to_char(p_option_value), p_option_dsc/*, p_user_id, p_change_date*/);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option1_bool(p_option_name varchar2, p_option_value boolean, p_option_dsc varchar2 := null/*, p_user_id number := null, p_change_date date := null*/)
is
begin
  ------------------------------
  ins_option1_num(p_option_name, bool_to_int(p_option_value), p_option_dsc/*, p_user_id, p_change_date*/);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option1_date(p_option_name varchar2, p_option_value date, p_option_dsc varchar2 := null/*, p_user_id number := null, p_change_date date := null*/)
is
begin
  ------------------------------
  ins_option1_str(p_option_name, date_to_char(p_option_value), p_option_dsc/*, p_user_id, p_change_date*/);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option1_value_str(p_option_name varchar2, p_option_value varchar2/*, p_user_id number := null, p_change_date date := null*/)
is
pragma autonomous_transaction;
  --v_user_id number := p_user_id;
  --v_change_date date := nvl(p_change_date, v_sysdate);
begin
  ------------------------------
  --if v_user_id is null
  --then
  --  v_user_id := xget_default_user_id;
  --end if;
  ------------------------------
  install_loc_pkg.upd_option1_value_str(p_option_name, p_option_value/*, v_user_id, v_change_date*/);
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option1_value_num(p_option_name varchar2, p_option_value number/*, p_user_id number := null, p_change_date date := null*/)
is
begin
  ------------------------------
  upd_option1_value_str(p_option_name, number_to_char(p_option_value)/*, p_user_id, p_change_date*/);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option1_value_bool(p_option_name varchar2, p_option_value boolean/*, p_user_id number := null, p_change_date date := null*/)
is
begin
  ------------------------------
  upd_option1_value_num(p_option_name, bool_to_int(p_option_value)/*, p_user_id, p_change_date*/);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option1_value_date(p_option_name varchar2, p_option_value date/*, p_user_id number := null, p_change_date date := null*/)
is
begin
  ------------------------------
  upd_option1_value_str(p_option_name, date_to_char(p_option_value)/*, p_user_id, p_change_date*/);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option1_dsc(p_option_name varchar2, p_option_dsc varchar2/*, p_user_id number := null, p_change_date date := null*/)
is
pragma autonomous_transaction;
  v_option_dsc varchar2(4000) := substr(nvl(p_option_dsc, p_option_name), 1, 4000);
  --v_user_id number := p_user_id;
  --v_change_date date := nvl(p_change_date, v_sysdate);
begin
  ------------------------------
  --if v_user_id is null
  --then
  --  v_user_id := xget_default_user_id;
  --end if;
  ------------------------------
  install_loc_pkg.upd_option1_dsc(p_option_name, v_option_dsc/*, v_user_id, v_change_date*/);
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_option1(p_option_name varchar2/*, p_user_id number := null, p_change_date date := null*/)
is
pragma autonomous_transaction;
  --v_user_id number := p_user_id;
  --v_change_date date := nvl(p_change_date, v_sysdate);
begin
  ------------------------------
  --if v_user_id is null
  --then
  --  v_user_id := xget_default_user_id;
  --end if;
  ------------------------------
  install_loc_pkg.del_option1(p_option_name/*, v_user_id, v_change_date*/);
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_option2_str(p_option_name varchar2, p_length number, p_default varchar2) return varchar2
is
  v_res varchar2(4000);
  v_str varchar2(4000);
begin
  ------------------------------
  if not is_exist_option2(p_option_name)
  then
    return p_default;
  end if;
  ------------------------------
  v_str := get_option2(p_option_name, null);
  ------------------------------
  begin
    ------------------------------
    v_res := p_default;
    ------------------------------
    if p_length is null or p_length >= nvl(length(v_str), p_length)
    then
      v_res := v_str;
    end if;
    ------------------------------
  exception
  when others then
    ------------------------------
    v_res := p_default;
    ------------------------------
  end;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_option2_num(p_option_name varchar2, p_default number) return number
is
  v_res number;
  v_str varchar2(4000);
begin
  ------------------------------
  if not is_exist_option2(p_option_name)
  then
    return p_default;
  end if;
  ------------------------------
  v_str := get_option2(p_option_name, null);
  ------------------------------
  begin
    v_res := char_to_number(v_str);
  exception
  when others then
    v_res := p_default;
  end;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_option2_bool(p_option_name varchar2, p_default boolean) return boolean
is
begin
  ------------------------------
  return int_to_bool(get_option2_num(p_option_name, bool_to_int(p_default)));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_option2_date(p_option_name varchar2, p_default date) return date
is
  v_res date;
  v_str varchar2(4000);
begin
  ------------------------------
  if not is_exist_option2(p_option_name)
  then
    return p_default;
  end if;
  ------------------------------
  v_str := get_option2(p_option_name, null);
  ------------------------------
  begin
    v_res := char_to_date(v_str);
  exception
  when others then
    v_res := p_default;
  end;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_option2_str(p_option_name varchar2, p_length number) return varchar2
is
  v_res varchar2(4000);
  v_str varchar2(4000);
begin
  ------------------------------
  v_str := get_option2(p_option_name, null);
  ------------------------------
  begin
    ------------------------------
    v_res := null;
    ------------------------------
    if p_length is null or p_length >= nvl(length(v_str), p_length)
    then
      v_res := v_str;
    end if;
    ------------------------------
  exception
  when others then
    ------------------------------
    v_res := null;
    ------------------------------
  end;
  ------------------------------
  if v_res is null
  then
    raise_exception(c_ora_option_nspec_wrong, c_msg_option_nspec_wrong || c_msg_delim01 || p_option_name);
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_option2_num(p_option_name varchar2) return number
is
  v_res number;
  v_str varchar2(4000);
begin
  ------------------------------
  v_str := get_option2(p_option_name, null);
  ------------------------------
  begin
    v_res := char_to_number(v_str);
  exception
  when others then
    v_res := null;
  end;
  ------------------------------
  if v_res is null
  then
    raise_exception(c_ora_option_nspec_wrong, c_msg_option_nspec_wrong || c_msg_delim01 || p_option_name);
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_option2_bool(p_option_name varchar2) return boolean
is
begin
  ------------------------------
  return int_to_bool(xget_option2_num(p_option_name));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_option2_date(p_option_name varchar2) return date
is
  v_res date;
  v_str varchar2(4000);
begin
  ------------------------------
  v_str := get_option2(p_option_name, null);
  ------------------------------
  begin
    v_res := char_to_date(v_str);
  exception
  when others then
    v_res := null;
  end;
  ------------------------------
  if v_res is null
  then
    raise_exception(c_ora_option_nspec_wrong, c_msg_option_nspec_wrong || c_msg_delim01 || p_option_name);
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option2_str(p_option_name varchar2, p_option_value varchar2, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null)
is
pragma autonomous_transaction;
  v_sysdate date := sysdate;
  v_option_dsc varchar2(4000) := substr(nvl(p_option_dsc, p_option_name), 1, 4000);
  v_user_id number := p_user_id;
  v_change_date date := nvl(p_change_date, v_sysdate);
begin
  ------------------------------
  if is_exist_option2(p_option_name)
  then
    return;
  end if;
  ------------------------------
  if v_user_id is null
  then
    v_user_id := xget_default_user_id;
  end if;
  ------------------------------
  install_loc_pkg.ins_option2_str(p_option_name, p_option_value, v_option_dsc, v_user_id, v_change_date);
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option2_num(p_option_name varchar2, p_option_value number, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  ins_option2_str(p_option_name, number_to_char(p_option_value), p_option_dsc, p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option2_bool(p_option_name varchar2, p_option_value boolean, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  ins_option2_num(p_option_name, bool_to_int(p_option_value), p_option_dsc, p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option2_date(p_option_name varchar2, p_option_value date, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  ins_option2_str(p_option_name, date_to_char(p_option_value), p_option_dsc, p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option2_value_str(p_option_name varchar2, p_option_value varchar2, p_user_id number := null, p_change_date date := null)
is
pragma autonomous_transaction;
  v_sysdate date := sysdate;
  v_user_id number := p_user_id;
  v_change_date date := nvl(p_change_date, v_sysdate);
begin
  ------------------------------
  if v_user_id is null
  then
    v_user_id := xget_default_user_id;
  end if;
  ------------------------------
  install_loc_pkg.upd_option2_value_str(p_option_name, p_option_value, v_user_id, v_change_date);
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option2_value_num(p_option_name varchar2, p_option_value number, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  upd_option2_value_str(p_option_name, number_to_char(p_option_value), p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option2_value_bool(p_option_name varchar2, p_option_value boolean, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  upd_option2_value_num(p_option_name, bool_to_int(p_option_value), p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option2_value_date(p_option_name varchar2, p_option_value date, p_user_id number := null, p_change_date date := null)
is
begin
  ------------------------------
  upd_option2_value_str(p_option_name, date_to_char(p_option_value), p_user_id, p_change_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option2_dsc(p_option_name varchar2, p_option_dsc varchar2, p_user_id number := null, p_change_date date := null)
is
pragma autonomous_transaction;
  v_option_dsc varchar2(4000) := substr(nvl(p_option_dsc, p_option_name), 1, 4000);
  v_sysdate date := sysdate;
  v_user_id number := p_user_id;
  v_change_date date := nvl(p_change_date, v_sysdate);
begin
  ------------------------------
  if v_user_id is null
  then
    v_user_id := xget_default_user_id;
  end if;
  ------------------------------
  install_loc_pkg.upd_option2_dsc(p_option_name, v_option_dsc, v_user_id, v_change_date);
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_option2(p_option_name varchar2, p_user_id number := null, p_change_date date := null)
is
pragma autonomous_transaction;
  v_sysdate date := sysdate;
  v_user_id number := p_user_id;
  v_change_date date := nvl(p_change_date, v_sysdate);
begin
  ------------------------------
  if v_user_id is null
  then
    v_user_id := xget_default_user_id;
  end if;
  ------------------------------
  install_loc_pkg.del_option2(p_option_name, v_user_id, v_change_date);
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xget_ts_tables return varchar2
is
begin
  ------------------------------
  return xget_option1_str(c_opt1_ts_tables, c_oracle_system_name_length);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_ts_indexes return varchar2
is
begin
  ------------------------------
  return xget_option1_str(c_opt1_ts_indexes, c_oracle_system_name_length);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xget_default_user_id return number
is
begin
  ------------------------------
  return xget_option_num(c_opt_def_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_user(p_user_id number, p_date date := sysdate)
is
begin
  ------------------------------
  xcheck_user_id(p_user_id, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_user_id(p_user_id number, p_date date := sysdate)
is
  v_cnt number;
begin
  ------------------------------
  v_cnt := check_user_id(p_user_id, p_date);
  ------------------------------
  if v_cnt = 0
  then
    raise_exception(c_ora_user_not_found, c_msg_user_not_found || c_msg_delim01 || p_user_id || c_msg_delim02 || date_to_char(p_date));
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_user_name(p_user_name varchar2, p_date date := sysdate)
is
  v_cnt number;
begin
  ------------------------------
  v_cnt := check_user_name(p_user_name, p_date);
  ------------------------------
  if v_cnt = 0
  then
    raise_exception(c_ora_user_not_found, c_msg_user_not_found || c_msg_delim01 || p_user_name || c_msg_delim02 || date_to_char(p_date));
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_user_name2(p_user_name nvarchar2, p_date date := sysdate)
is
  v_cnt number;
begin
  ------------------------------
  v_cnt := check_user_name2(p_user_name, p_date);
  ------------------------------
  if v_cnt = 0
  then
    raise_exception(c_ora_user_not_found, c_msg_user_not_found || c_msg_delim01 || p_user_name || c_msg_delim02 || date_to_char(p_date));
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_user_id(p_user_id number, p_date date := sysdate) return number
is
  v_str varchar2(100);
begin
  ------------------------------
  v_str := get_user_name(p_user_id, p_date);
  ------------------------------
  if v_str is null
  then
    return c_false;
  end if;
  ------------------------------
  return c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_user_name(p_user_name varchar2, p_date date := sysdate) return number
is
  v_num number;
begin
  ------------------------------
  v_num := get_user_id(p_user_name, p_date);
  ------------------------------
  if v_num is null
  then
    return c_false;
  end if;
  ------------------------------
  return c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_user_name2(p_user_name nvarchar2, p_date date := sysdate) return number
is
  v_num number;
begin
  ------------------------------
  v_num := get_user_id2(p_user_name, p_date);
  ------------------------------
  if v_num is null
  then
    return c_false;
  end if;
  ------------------------------
  return c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_user_id(p_user_name varchar2, p_date date := sysdate) return number
is
  v_res number;
begin
  ------------------------------
  v_res := get_user_id(p_user_name, p_date);
  ------------------------------
  if v_res is null
  then
    raise_exception(c_ora_user_not_found, c_msg_user_not_found || c_msg_delim01 || p_user_name || c_msg_delim02 || date_to_char(p_date));
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_user_id2(p_user_name nvarchar2, p_date date := sysdate) return number
is
  v_res number;
begin
  ------------------------------
  v_res := get_user_id2(p_user_name, p_date);
  ------------------------------
  if v_res is null
  then
    raise_exception(c_ora_user_not_found, c_msg_user_not_found || c_msg_delim01 || p_user_name || c_msg_delim02 || date_to_char(p_date));
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_user_name(p_user_id number, p_date date := sysdate) return varchar2
is
  v_res varchar2(100);
begin
  ------------------------------
  v_res := get_user_name(p_user_id, p_date);
  ------------------------------
  if v_res is null
  then
    raise_exception(c_ora_user_not_found, c_msg_user_not_found || c_msg_delim01 || p_user_id || c_msg_delim02 || date_to_char(p_date));
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_user_name2(p_user_id number, p_date date := sysdate) return nvarchar2
is
  v_res nvarchar2(100);
begin
  ------------------------------
  v_res := get_user_name2(p_user_id, p_date);
  ------------------------------
  if v_res is null
  then
    raise_exception(c_ora_user_not_found, c_msg_user_not_found || c_msg_delim01 || p_user_id || c_msg_delim02 || date_to_char(p_date));
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_id(p_user_name varchar2, p_date date := sysdate) return number
is
begin
  ------------------------------
  return install_loc_pkg.get_user_id(p_user_name, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_id2(p_user_name nvarchar2, p_date date := sysdate) return number
is
begin
  ------------------------------
  return install_loc_pkg.get_user_id2(p_user_name, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_name(p_user_id number, p_date date := sysdate) return varchar2
is
begin
  ------------------------------
  return install_loc_pkg.get_user_name(p_user_id, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_name2(p_user_id number, p_date date := sysdate) return nvarchar2
is
begin
  ------------------------------
  return install_loc_pkg.get_user_name2(p_user_id, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_! OBSOLETE
----------------------------------!---------------------------------------------
function check_tab(p_table_name varchar2) return number
is
begin
  ------------------------------
  return check_table(p_table_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_seq(p_sequence_name varchar2) return number
is
begin
  ------------------------------
  return check_sequence(p_sequence_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_mv(p_mview_name varchar2) return number
is
begin
  ------------------------------
  return check_mview(p_mview_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_mv_in_refresh(p_refresh_name varchar2, p_miew_name varchar2) return number
is
begin
  ------------------------------
  return check_refresh_children(p_refresh_name, p_miew_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_dblink(p_db_link varchar2) return number
is
begin
  ------------------------------
  return check_db_link(p_db_link);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! OBSOLETE
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function check_table(p_table_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_tables
    where 1 = 1
    and table_name = upper(p_table_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_index(p_index_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_indexes
    where 1 = 1
    and index_name = upper(p_index_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_index2(p_index_name varchar2, p_table_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_indexes
    where 1 = 1
    and index_name = upper(p_index_name)
    and table_name = upper(p_table_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_ind_column(p_index_name varchar2, p_column_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_ind_columns
    where 1 = 1
    and index_name = upper(p_index_name)
    and column_name = upper(p_column_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_ind_expression(p_index_name varchar2, p_column_position number) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_ind_expressions
    where 1 = 1
    and index_name = upper(p_index_name)
    and column_position = p_column_position
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_view(p_view_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_views
    where 1 = 1
    and view_name = upper(p_view_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_type(p_type_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_types
    where 1 = 1
    and type_name = upper(p_type_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_sequence(p_sequence_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_sequences
    where 1 = 1
    and sequence_name = upper(p_sequence_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_tab_column(p_table_name varchar2, p_column_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_tab_columns
    where 1 = 1
    and table_name = upper(p_table_name)
    and column_name = upper(p_column_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_constraint(p_constraint_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_constraints
    where 1 = 1
    and constraint_name = upper(p_constraint_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_constraint2(p_constraint_name varchar2, p_table_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1)
    into v_res
    from user_constraints
    where 1 = 1
    and constraint_name = upper(p_constraint_name)
    and table_name = upper(p_table_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_cons_column(p_constraint_name varchar2, p_column_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_cons_columns
    where 1 = 1
    and constraint_name = upper(p_constraint_name)
    and column_name = upper(p_column_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_trigger(p_trigger_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_triggers
    where 1 = 1
    and trigger_name = upper(p_trigger_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_mview_log(p_table_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_mview_logs
    where 1 = 1
    and master = upper(p_table_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_mview(p_mview_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count (1) into v_res
    from user_mviews
    where 1 = 1
    and mview_name = upper(p_mview_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_refresh(p_refresh_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count (1) into v_res
    from user_refresh
    where 1 = 1
    and rname = upper(p_refresh_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_refresh_children(p_refresh_name varchar2, p_miew_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count (1) into v_res
    from user_refresh_children
    where 1 = 1
    and name = upper(p_miew_name)
    and rname = upper(p_refresh_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_db_link(p_db_link varchar2) return number
is
  v_res number;
  v_def_domain varchar2(100);
begin
  ------------------------------
  select
    count (1) into v_res
    from user_db_links
    where 1 = 1
    and db_link = upper(p_db_link)
  ;
  ------------------------------
  if v_res = c_false
  then
    ------------------------------
    v_def_domain := get_def_domain();
    ------------------------------
    select
     count (1) into v_res
      from user_db_links
     where 1 = 1
       and db_link = upper(p_db_link || '.' || v_def_domain)
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_object(p_object_name varchar2, p_object_type varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count (1) into v_res
    from user_objects
    where 1 = 1
    and object_name = upper(p_object_name)
    and object_type = upper(p_object_type)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_package(p_package_name varchar2) return number
is
begin
  ------------------------------
  return check_object(p_package_name, c_objt_package);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_package_body(p_package_body_name varchar2) return number
is
begin
  ------------------------------
  return check_object(p_package_body_name, c_objt_package_body);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_function(p_function_name varchar2) return number
is
begin
  ------------------------------
  return check_object(p_function_name, c_objt_function);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_procedure(p_procedure_name varchar2) return number
is
begin
  ------------------------------
  return check_object(p_procedure_name, c_objt_procedure);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_synonym(p_synonym_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_synonyms
    where 1 = 1
    and synonym_name = upper(p_synonym_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_queue(p_queue_name varchar2) return number
is
begin
  ------------------------------
  return check_object(p_queue_name, c_objt_queue);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_queue_table(p_queue_table_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count (1) into v_res
    from user_queue_tables
    where 1 = 1
    and queue_table = upper(p_queue_table_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_queue_started(p_queue_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(*) into v_res
    from user_queues
    where 1 = 1
    and name = upper(p_queue_name)
    and c_yes2 in (
      upper(trim(enqueue_enabled)),
      upper(trim(dequeue_enabled))
    )
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_aq_subscrider(p_queue_name varchar2, p_consumer_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count (1) into v_res
    from user_queue_subscribers
    where 1 = 1
    and queue_name = upper(p_queue_name)
    and consumer_name = upper(p_consumer_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_part_table(p_table_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_part_tables
    where 1 = 1
    and table_name = upper(p_table_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_parameter_value(p_param_name varchar2) return varchar2
is
  v_str_res varchar2(256);
  v_int_res integer;
  v_param_type integer;
begin
  ------------------------------
  v_param_type := sys.dbms_utility.get_parameter_value
  (
    parnam => p_param_name,
    intval => v_int_res,
    strval => v_str_res
  );
  ------------------------------
  if v_param_type = 1
  then
    ------------------------------
    return v_str_res;
    ------------------------------
  else
    ------------------------------
    return util_pkg.number_to_char(v_int_res);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_def_domain return varchar2
is
begin
  ------------------------------
  return get_parameter_value(c_db_domain_param_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_column_nullable(p_table_name varchar2, p_column_name varchar2) return number
is
  v_res number;
  v_rec user_tab_columns%rowtype;
begin
  ------------------------------
  v_rec := get_tab_column(p_table_name, p_column_name);
  ------------------------------
  if v_rec.column_name is null
  then
    ------------------------------
    raise_exception(c_ora_x_common, 'Column '|| p_column_name ||' not exists in table ' || p_table_name);
    ------------------------------
  end if;
  ------------------------------
  v_res := c_false;
  ------------------------------
  if v_rec.nullable = c_yes
  then
    ------------------------------
    v_res := c_true;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function check_has_primary_key(p_table_name varchar2) return number
is
  v_res number;
begin
  ------------------------------
  select
    count(1) into v_res
    from user_constraints
    where 1 = 1
    and table_name = upper(p_table_name)
    and constraint_type = c_con_tp_primary_key
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_primary_key_name(p_table_name varchar2) return varchar2
is
  v_res varchar2(30);
begin
  ------------------------------
  select
    constraint_name into v_res
    from user_constraints
    where 1 = 1
    and table_name = upper(p_table_name)
    and constraint_type = c_con_tp_primary_key
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_tab_column(p_table_name varchar2, p_column_name varchar2) return user_tab_columns%rowtype
is
  v_res user_tab_columns%rowtype;
begin
  ------------------------------
  select
    * into v_res
    from user_tab_columns
    where 1 = 1
    and table_name = upper(p_table_name)
    and column_name = upper(p_column_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_sequence(p_sequence_name varchar2) return user_sequences%rowtype
is
  v_res user_sequences%rowtype;
begin
  ------------------------------
  select
    * into v_res
    from user_sequences
    where 1 = 1
    and sequence_name = upper(p_sequence_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_index(p_index_name varchar2) return user_indexes%rowtype
is
  v_res user_indexes%rowtype;
begin
  ------------------------------
  select
    * into v_res
    from user_indexes
    where 1 = 1
    and index_name = upper(p_index_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_mview_log(p_table_name varchar2) return user_mview_logs%rowtype
is
  v_res user_mview_logs%rowtype;
begin
  ------------------------------
  select
    * into v_res
    from user_mview_logs
    where 1 = 1
    and master = upper(p_table_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_mview(p_mview_name varchar2) return user_mviews%rowtype
is
  v_res user_mviews%rowtype;
begin
  ------------------------------
  select
    * into v_res
    from user_mviews
    where 1 = 1
    and mview_name = upper(p_mview_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_refresh_children(p_refresh_name varchar2, p_miew_name varchar2) return user_refresh_children%rowtype
is
  v_res user_refresh_children%rowtype;
begin
  ------------------------------
  select
    * into v_res
    from user_refresh_children
    where 1 = 1
    and name = upper(p_miew_name)
    and rname = upper(p_refresh_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_part_table(p_table_name varchar2) return user_part_tables%rowtype
is
  v_res user_part_tables%rowtype;
begin
  ------------------------------
  select
    * into v_res
    from user_part_tables
    where 1 = 1
    and table_name = upper(p_table_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_tab_partition(p_table_name varchar2, p_partition_name varchar2) return user_tab_partitions%rowtype
is
  v_res user_tab_partitions%rowtype;
begin
  ------------------------------
  select
    * into v_res
    from user_tab_partitions
    where 1 = 1
    and table_name = upper(p_table_name)
    and partition_name = upper(p_partition_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_tab_partition2(p_table_name varchar2, p_partition_position number) return user_tab_partitions%rowtype
is
  v_res user_tab_partitions%rowtype;
begin
  ------------------------------
  select
    * into v_res
    from user_tab_partitions
    where 1 = 1
    and table_name = upper(p_table_name)
    and partition_position = p_partition_position
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_tab_subpartition(p_table_name varchar2, p_partition_name varchar2, p_subpartition_name varchar2) return user_tab_subpartitions%rowtype
is
  v_res user_tab_subpartitions%rowtype;
begin
  ------------------------------
  select
    * into v_res
    from user_tab_subpartitions
    where 1 = 1
    and table_name = upper(p_table_name)
    and partition_name = upper(p_partition_name)
    and subpartition_name = upper(p_subpartition_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_tab_subpartition2(p_table_name varchar2, p_partition_name varchar2, p_subpartition_position number) return user_tab_subpartitions%rowtype
is
  v_res user_tab_subpartitions%rowtype;
begin
  ------------------------------
  select
    * into v_res
    from user_tab_subpartitions
    where 1 = 1
    and table_name = upper(p_table_name)
    and partition_name = upper(p_partition_name)
    and subpartition_position = p_subpartition_position
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_session(p_sid number) return v$session%rowtype
is
  v_res v$session%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_sid is null, 'p_sid');
  ------------------------------
  select
    * into v_res
    from v$session
    where 1 = 1
    and sid = p_sid
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_job_by_id(p_job number) return user_jobs%rowtype
is
  v_res user_jobs%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_job is null, 'p_job');
  ------------------------------
  select
    * into v_res
    from user_jobs
    where 1 = 1
    and job = p_job
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_job(p_what_label varchar2) return user_jobs%rowtype
is
  v_res user_jobs%rowtype;
begin
  ------------------------------
  select
    * into v_res
    from user_jobs
    where 1 = 1
    and upper(what) like upper('%' || p_what_label || '%')
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_job_running(p_job number) return dba_jobs_running%rowtype
is
  v_res dba_jobs_running%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_job is null, 'p_job');
  ------------------------------
  select
    * into v_res
    from dba_jobs_running
    where 1 = 1
    and job = p_job
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_job_running(p_job number) return number
is
  v_rec dba_jobs_running%rowtype;
begin
  ------------------------------
  v_rec := get_job_running(p_job);
  ------------------------------
  if v_rec.job is null
  then
    return c_false;
  end if;
  ------------------------------
  return c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_attr_val(p_xml xmltype, p_xpath varchar2) return clob
is
  v_res clob;
begin
  ------------------------------
  select extract(p_xml, p_xpath).getstringval()
    into v_res
    from dual
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_backup_table_name(p_table_name varchar2) return varchar2
is
  v_res varchar2(30);
  v_postfix varchar2(30):= to_char(sysdate, c_date_format_full_compact);
  v_prefix varchar2(30);
begin
  ------------------------------
  v_prefix := p_table_name;
  ------------------------------
  if length(v_prefix) > c_oracle_system_name_length - length(v_postfix)
  then
    v_prefix := substr(p_table_name, 1, c_oracle_system_name_length - length(v_postfix));
  end if;
  ------------------------------
  v_res := v_prefix || v_postfix;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_backup_table_name(p_table_name varchar2) return varchar2
is
begin
  ------------------------------
  return make_backup_table_name(p_table_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_store_priv_tab_pref(p_table_name varchar2) return varchar2
is
begin
  ------------------------------
  return substrc(c_store_priv_tab_pref || p_table_name, 1, c_oracle_system_name_length);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function backup_table(p_table_name varchar2, p_backup_tab_prefix varchar2) return varchar2
is
pragma autonomous_transaction;
  v_backup_table_name varchar2(30);
  v_sql clob := q'{create table :p_backup_table_name as select * from :p_src_table_name}';
begin
  ------------------------------
  v_backup_table_name := make_backup_table_name(nvl(p_backup_tab_prefix, p_table_name));
  ------------------------------
  v_sql := replace(v_sql, ':p_src_table_name', p_table_name);
  v_sql := replace(v_sql, ':p_backup_table_name', v_backup_table_name);
  ------------------------------
  execute immediate v_sql;
  ------------------------------
  commit;
  ------------------------------
  return v_backup_table_name;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function backup_table2(p_table_name varchar2) return varchar2
is
begin
  ------------------------------
  return backup_table(p_table_name, null);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function save_privs_i(p_owner varchar2, p_table_name varchar2, p_grantor varchar2, p_store_tab_prefix varchar2) return varchar2
is
pragma autonomous_transaction;
  v_store_table_name varchar2(30);
  --
  v_sql_create clob := q'{create table :p_store_table_name as select * from user_tab_privs z where 1 = 0}'
  ;
  v_sql_insert clob := q'{insert into :p_store_table_name
select
  *
  from user_tab_privs z
  where 1 = 1
  and owner = upper(:p_owner)
  and table_name = upper(:p_table_name)
  and grantor = upper(nvl(:p_grantor, grantor))
  order by owner, table_name, privilege, grantee
}'
  ;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_owner is null, 'p_owner');
  util_pkg.XCheck_Cond_Missing(p_table_name is null, 'p_table_name');
  --!_!util_pkg.XCheck_Cond_Missing(p_grantor is null, 'p_grantor');
  --!_!util_pkg.XCheck_Cond_Missing(p_store_tab_prefix is null, 'p_store_tab_prefix');
  ------------------------------
  v_store_table_name := make_backup_table_name(nvl(p_store_tab_prefix, p_table_name));
  ------------------------------
  v_sql_create := replace(v_sql_create, ':p_store_table_name', v_store_table_name);
  v_sql_insert := replace(v_sql_insert, ':p_store_table_name', v_store_table_name);
  ------------------------------
  execute immediate v_sql_create;
  ------------------------------
  execute immediate v_sql_insert using p_owner, p_table_name, p_grantor;
  ------------------------------
  commit;
  ------------------------------
  return v_store_table_name;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function save_privs(p_grantor varchar2, p_table_name varchar2, p_store_tab_prefix varchar2) return varchar2
is
begin
  ------------------------------
  return save_privs_i(get_this_ora_user_name, p_table_name, p_grantor, p_store_tab_prefix);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function save_privs2(p_grantor varchar2, p_table_name varchar2) return varchar2
is
begin
  ------------------------------
  return save_privs(p_grantor, p_table_name, make_store_priv_tab_pref(p_table_name));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function save_privs3(p_table_name varchar2) return varchar2
is
begin
  ------------------------------
  return save_privs2(NULL, p_table_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure restore_privs_i(p_owner varchar2, p_table_name varchar2, p_grantor varchar2, p_store_table_name varchar2, p_drop_store_table boolean)
is
  v_drop_store_table boolean := bool_to_bool_2val(p_drop_store_table);
  v_cursor sys_refcursor;
  v_str clob;
  --
  v_sql clob := q'{select
  'GRANT ' || privilege || ' ON ' || owner || '.' || table_name || ' TO ' || grantee
    || decode(grantable, 'YES', ' WITH GRANT OPTION', '') || decode(hierarchy, 'YES', ' WITH HIERARCHY OPTION', '') str_to_run
  from :p_store_table_name z
  where 1 = 1
  and owner = :p_owner
  and table_name = :p_table_name
  and grantor = nvl(:p_grantor, grantor)
  order by owner, table_name, privilege, grantee
}'
  ;
  --
begin
  ------------------------------
  v_sql := replace(v_sql, ':p_store_table_name', p_store_table_name);
  ------------------------------
  open v_cursor for v_sql using p_owner, p_table_name, p_grantor;
  ------------------------------
  loop
    ------------------------------
    fetch v_cursor into v_str;
    ------------------------------
    exit when v_cursor%notfound;
    ------------------------------
    execute immediate v_str;
    ------------------------------
  end loop;
  ------------------------------
  if v_drop_store_table
  then
    ------------------------------
    execute immediate 'drop table ' || p_store_table_name;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure restore_privs(p_grantor varchar2, p_table_name varchar2, p_store_table_name varchar2, p_drop_store_table boolean)
is
begin
  ------------------------------
  restore_privs_i(get_this_ora_user_name, p_table_name, p_grantor, p_store_table_name, p_drop_store_table);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure restore_privs2(p_grantor varchar2, p_table_name varchar2, p_store_table_name varchar2)
is
begin
  ------------------------------
  restore_privs(p_grantor, p_table_name, p_store_table_name, false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure restore_privs3(p_table_name varchar2, p_store_table_name varchar2)
is
begin
  ------------------------------
  restore_privs2(NULL, p_table_name, p_store_table_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure drop_ref_keys(p_table_name varchar2)
is
  v_sql clob;
begin
  ------------------------------
  for v_i in (
  select
    *
    from user_constraints
    where 1 = 1
    and constraint_type in (c_con_tp_foreign_key)
    and (r_owner, r_constraint_name) in
    (
    select
      owner, constraint_name
      from user_constraints
      where 1 = 1
      and table_name = upper(p_table_name)
      and constraint_type in (c_con_tp_primary_key, c_con_tp_unique_key)
    )
    order by owner, table_name, constraint_name
  ) loop
    ------------------------------
    v_sql := 'alter table ' || v_i.owner || '.' || v_i.table_name || ' drop constraint ' || v_i.constraint_name;
    ------------------------------
    execute immediate v_sql;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure drop_own_keys(p_table_name varchar2)
is
  v_sql clob;
begin
  ------------------------------
  for v_i in (
  select
    *
    from user_constraints
    where 1 = 1
    and table_name = upper(p_table_name)
    and constraint_type in (c_con_tp_primary_key, c_con_tp_unique_key, c_con_tp_foreign_key)
    order by owner, table_name, constraint_name
  ) loop
    ------------------------------
    v_sql := 'alter table ' || v_i.owner || '.' || v_i.table_name || ' drop constraint ' || v_i.constraint_name || ' keep index';
    ------------------------------
    execute immediate v_sql;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure rename_indexes(p_table_name varchar2, p_post_len number := c_default_post_len, p_only_xcheck boolean := false)
is
  v_cnt number;
  v_post_len number := nvl(p_post_len, c_default_post_len);
  v_only_xcheck boolean := bool_to_bool_2val(p_only_xcheck);
  v_pad_char varchar2(1) := '0';
  v_sql clob;
  v_index_name_new varchar2(30);
begin
  ------------------------------
  if v_post_len < 1
  then
    v_post_len := 1;
  end if;
  ------------------------------
  if v_post_len > c_oracle_system_name_length - 1
  then
    v_post_len := c_oracle_system_name_length - 1;
  end if;
  ------------------------------
  v_cnt := 0;
  ------------------------------
  for v_i in (
  select *
    from user_indexes
    where 1 = 1
    and table_name = upper(p_table_name)
    order by table_owner, table_name, index_name
  ) loop
    ------------------------------
    v_cnt := v_cnt + 1;
    ------------------------------
    v_index_name_new := rpad(v_i.index_name, c_oracle_system_name_length - v_post_len, v_pad_char) || lpad(v_cnt, v_post_len, v_pad_char);
    ------------------------------
    if v_only_xcheck
    then
      ------------------------------
      if check_index(v_index_name_new) > 0
      then
        raise_exception(c_ora_x_common, 'Next auto rename will failed on ' || c_msg_delim01 || v_i.index_name || c_msg_delim02 || v_index_name_new);
      end if;
      ------------------------------
    else
      ------------------------------
      v_sql := 'alter index ' || v_i.index_name || ' rename to ' || v_index_name_new;
      ------------------------------
      execute immediate v_sql;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_this_ora_user_name return varchar2
is
begin
  ------------------------------
  return get_sys_context_userenv_par(c_sysctx_par_session_user);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_scheme_name return varchar2
is
begin
  ------------------------------
  return get_this_ora_user_name;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_this_bg_job_id return number
is
begin
  ------------------------------
  return get_sys_context_userenv_par(c_sysctx_par_bg_job_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_sys_context_par(p_namespace varchar2, p_parameter varchar2, p_max_ret_val_length number) return varchar2
is
begin
  ------------------------------
  return sys_context(p_namespace, p_parameter, p_max_ret_val_length);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_sys_context_userenv_par(p_parameter varchar2, p_max_ret_val_length number) return varchar2
is
begin
  ------------------------------
  return get_sys_context_par(p_namespace => c_sysctx_ns_userenv, p_parameter => p_parameter, p_max_ret_val_length => p_max_ret_val_length);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_sys_context_userenv_par30(p_parameter varchar2) return varchar2
is
begin
  ------------------------------
  return get_sys_context_userenv_par(p_parameter => p_parameter, p_max_ret_val_length => c_oracle_system_name_length);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_sys_context_userenv_parnum(p_parameter varchar2) return number
is
begin
  ------------------------------
  return util_pkg.char_to_number(get_sys_context_userenv_par(p_parameter => p_parameter, p_max_ret_val_length => c_oracle_sys_context_def_len));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function sequence_currval(p_sequence_name varchar2) return number
is
  v_rec user_sequences%rowtype;
  v_currval number;
begin
  ------------------------------
  begin
    ------------------------------
    execute immediate 'select ' || p_sequence_name || '.currval from dual' into v_currval;
    ------------------------------
  exception
  when currval_exception then
    ------------------------------
    v_rec := get_sequence(p_sequence_name);
    ------------------------------
    v_currval := v_rec.last_number;
    ------------------------------
  end;
  ------------------------------
  return v_currval;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure shift_sequence(p_sequence_name varchar2, p_target number, p_threshold number := 1000000)
is
  v_currval number;
  v_str clob;
begin
  ------------------------------
  v_currval := sequence_currval(p_sequence_name);
  ------------------------------
  if p_target <= v_currval or p_target is null
  then
    return;
  end if;
  ------------------------------
  if p_target - v_currval > p_threshold
  then
    raise_exception(c_ora_x_common, 'Difference is too big between last_number and p_target with p_threshold' || c_msg_delim01 || p_sequence_name || c_msg_delim02 || v_currval || c_msg_delim02 || p_target || c_msg_delim02 || p_threshold);
  end if;
  ------------------------------
  v_str := q'{
begin
  loop
    exit when :p_sequence_name.nextval >= :p_target;
  end loop;
end;
}'
  ;
  ------------------------------
  v_str := replace(v_str, ':p_sequence_name', p_sequence_name);
  ------------------------------
  execute immediate v_str using p_target;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure shift_sequence_hard(p_sequence_name varchar2, p_target number)
is
  v_rec user_sequences%rowtype;
  v_currval number;
  v_diff number;
  v_dummy_num number;
begin
  ------------------------------
  v_rec := get_sequence(p_sequence_name);
  ------------------------------
  if v_rec.sequence_name is null
  then
    raise_exception(c_ora_x_common, 'Sequence is not found' || c_msg_delim01 || p_sequence_name);
  end if;
  ------------------------------
  if p_target < v_rec.min_value
  then
    raise_exception(c_ora_x_common, 'p_target is too small' || c_msg_delim01 || p_sequence_name || c_msg_delim02 || p_target || c_msg_delim02 || v_rec.min_value);
  end if;
  ------------------------------
  if p_target > v_rec.max_value
  then
    raise_exception(c_ora_x_common, 'p_target is too big' || c_msg_delim01 || p_sequence_name || c_msg_delim02 || p_target || c_msg_delim02 || v_rec.max_value);
  end if;
  ------------------------------
  execute immediate 'select ' || p_sequence_name || '.nextval from dual' into v_currval; --!_! magic; fix current value FOR US
  ------------------------------
  v_diff := p_target - v_currval;
  ------------------------------
  if v_diff = 0
  then
    return;
  end if;
  ------------------------------
  execute immediate 'alter sequence ' || p_sequence_name || ' increment by ' || to_char(v_diff);
  execute immediate 'select ' || p_sequence_name || '.nextval from dual' into v_dummy_num;
  execute immediate 'alter sequence ' || p_sequence_name || ' increment by ' || to_char(v_rec.increment_by);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_unique_incr(p_table_name varchar2, p_tab_column varchar2) return number
is
  v_str clob;
  v_max_num number;
begin
  ------------------------------
  v_str := q'{
  select max(to_number(:p_tab_column))
    from :p_table_name
   where translate(:p_tab_column, '_0123456789', '_') is null
  }';
  ------------------------------
  v_str := replace(v_str, ':p_table_name', p_table_name);
  v_str := replace(v_str, ':p_tab_column', p_tab_column);
  ------------------------------
  execute immediate v_str into v_max_num;
  ------------------------------
  return (nvl(v_max_num, 0) + 1);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure create_synonym(p_synonym_name varchar2, p_table_name varchar2, p_table_owner varchar2, p_db_link varchar2)
is
  v_str clob;
begin
  ------------------------------
  v_str := q'{create or replace synonym :p_synonym_name for :p_table_owner_val:p_table_name:p_db_link_val}';
  ------------------------------
  v_str := replace(v_str, ':p_synonym_name', p_synonym_name);
  v_str := replace(v_str, ':p_table_name', p_table_name);
  v_str := replace(v_str, ':p_table_owner_val', case when p_table_owner is null then '' else p_table_owner || '.' end);
  v_str := replace(v_str, ':p_db_link_val', case when p_db_link is null then '' else '@' || p_db_link end);
  ------------------------------
  execute immediate v_str;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure create_queue
(
  p_queue_name varchar2,
  p_queue_table_name varchar2,
  p_queue_payload_type varchar2,
  p_subscriber_name varchar2,
  p_queue_comment varchar2,
  p_max_retries number,
  p_retry_delay number,
  p_retention_time number,
  p_tablespace_t varchar2
)
is
  ------------------------------
  v_aq_agent sys.aq$_agent;
  ------------------------------
begin
  ------------------------------
  if 1 = 1
    and check_table(p_queue_table_name) > 0
    and check_queue_table(p_queue_table_name) = 0
  then
    ------------------------------
    raise_exception(c_ora_x_common, util_pkg.c_msg_object_wrong || c_msg_delim01 || p_queue_table_name);
    ------------------------------
  end if;
  ------------------------------
  if check_table(p_queue_table_name) = 0
  then
    ------------------------------
    dbms_aqadm.create_queue_table
    (
      queue_table => p_queue_table_name,
      queue_payload_type => p_queue_payload_type,
      multiple_consumers => TRUE,
      storage_clause => 'tablespace "' || p_tablespace_t || '"'
    );
    ------------------------------
    COMMIT;
    ------------------------------
  end if;
  ------------------------------
  if check_queue(p_queue_name) = 0
  then
    ------------------------------
    dbms_aqadm.create_queue
    (
      queue_name => p_queue_name,
      queue_table => p_queue_table_name,
      queue_type => dbms_aqadm.normal_queue,
      max_retries => p_max_retries,
      retry_delay => p_retry_delay,
      retention_time => p_retention_time,
      comment => p_queue_comment
    );
    ------------------------------
    COMMIT;
    ------------------------------
  end if;
  ------------------------------
  if check_queue_started(p_queue_name) = 0
  then
    ------------------------------
    dbms_aqadm.start_queue
    (
      queue_name => p_queue_name,
      enqueue => TRUE,
      dequeue => TRUE
    );
    ------------------------------
    COMMIT;
    ------------------------------
  end if;
  ------------------------------
  if check_aq_subscrider(p_queue_name, p_subscriber_name) = 0
  then
    ------------------------------
    v_aq_agent :=
      sys.aq$_agent
      (
        name => p_subscriber_name,
        address => NULL,
        protocol => NULL
      );
    ------------------------------
    dbms_aqadm.add_subscriber
    (
      queue_name => p_queue_name,
      subscriber => v_aq_agent
    );
    ------------------------------
    COMMIT;
    ------------------------------
  end if;
  ------------------------------
  COMMIT;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_empty_table(p_table_name varchar2) return number
is
  v_str clob;
  v_num number;
begin
  ------------------------------
  v_str := q'{select count(1) cnt
  from (
select /*+ full(z)*/
  1
  from :p_table_name z
  where 1 = 1
  and rownum = 1
  )
}'
  ;
  ------------------------------
  v_str := replace(v_str, ':p_table_name', p_table_name);
  ------------------------------
  execute immediate v_str into v_num;
  ------------------------------
  if v_num > 0
  then
    return c_false;
  end if;
  ------------------------------
  return c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_empty_partition(p_table_name varchar2, p_partition_name varchar2) return number
is
  v_str clob;
  v_num number;
begin
  ------------------------------
  v_str := q'{select count(1) cnt
  from (
select /*+ full(z)*/
  1
  from :p_table_name partition(:p_partition_name) z
  where 1 = 1
  and rownum = 1
  )
}'
  ;
  ------------------------------
  v_str := replace(v_str, ':p_table_name', p_table_name);
  v_str := replace(v_str, ':p_partition_name', p_partition_name);
  ------------------------------
  execute immediate v_str into v_num;
  ------------------------------
  if v_num > 0
  then
    return c_false;
  end if;
  ------------------------------
  return c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_empty_subpartition(p_table_name varchar2, p_subpartition_name varchar2) return number
is
  v_str clob;
  v_num number;
begin
  ------------------------------
  v_str := q'{select count(1) cnt
  from (
select /*+ full(z)*/
  1
  from :p_table_name subpartition(:p_subpartition_name) z
  where 1 = 1
  and rownum = 1
  )
}'
  ;
  ------------------------------
  v_str := replace(v_str, ':p_table_name', p_table_name);
  v_str := replace(v_str, ':p_subpartition_name', p_subpartition_name);
  ------------------------------
  execute immediate v_str into v_num;
  ------------------------------
  if v_num > 0
  then
    return c_false;
  end if;
  ------------------------------
  return c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function contains_nulls(p_table_name varchar2, p_tab_column varchar2) return number
is
  v_str clob;
  v_num number;
begin
  ------------------------------
  v_str := q'{select count(1) cnt
  from (
select /*+ full(z)*/
  1
  from :p_table_name z
  where 1 = 1
  and :p_tab_column is null
  )
}'
  ;
  ------------------------------
  v_str := replace(v_str, ':p_table_name', p_table_name);
  v_str := replace(v_str, ':p_tab_column', p_tab_column);
  ------------------------------
  execute immediate v_str into v_num;
  ------------------------------
  if v_num > 0
  then
    return c_true;
  end if;
  ------------------------------
  return c_false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure close_cursor(p_cr sys_refcursor)
is
begin
  ------------------------------
  if 1 = 1
    and p_cr is not null
    and p_cr%isopen
  then
    ------------------------------
    close p_cr;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function eval_as_str(v_expr varchar2) return varchar2
is
begin
  ------------------------------
  return v_expr;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function eval_as_nstr(v_expr varchar2) return nvarchar2
is
begin
  ------------------------------
  return util_pkg.char_to_nchar(v_expr);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function eval_as_number(v_expr varchar2) return number
is
  v_res number;
  v_str clob;
begin
  ------------------------------
  v_str := c_sql_eval_as;
  ------------------------------
  v_str := replace(v_str, ':p_type', 'number');
  v_str := replace(v_str, ':p_expr', v_expr);
  ------------------------------
  execute immediate v_str using out v_res;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function eval_as_date(v_expr varchar2) return date
is
  v_res date;
  v_str clob;
begin
  ------------------------------
  v_str := c_sql_eval_as;
  ------------------------------
  v_str := replace(v_str, ':p_type', 'date');
  v_str := replace(v_str, ':p_expr', v_expr);
  ------------------------------
  execute immediate v_str using out v_res;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure split_partition_down
(
  p_table_name varchar2,
  p_partition_name varchar2,
  p_bottom_partition_name varchar2,
  p_bottom_high_value_expr varchar2,
  p_rebuild_ind_partitions boolean := true
)
is
  v_str clob;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_table_name is null, 'p_table_name');
  util_pkg.XCheck_Cond_Missing(p_partition_name is null, 'p_partition_name');
  util_pkg.XCheck_Cond_Missing(p_bottom_high_value_expr is null, 'p_bottom_high_value_expr');
  util_pkg.XCheck_Cond_Missing(p_bottom_partition_name is null, 'p_bottom_partition_name');
  util_pkg.XCheck_Cond_Missing(p_rebuild_ind_partitions is null, 'p_rebuild_ind_partitions');
  ------------------------------
  v_str := q'{
alter table :p_table_name
  split partition :p_partition_name
  at (:p_bottom_high_value_expr)
  into (partition :p_bottom_partition_name, partition :p_partition_name)
}'
  ;
  ------------------------------
  v_str := replace(v_str, ':p_table_name', p_table_name);
  v_str := replace(v_str, ':p_partition_name', p_partition_name);
  v_str := replace(v_str, ':p_bottom_high_value_expr', p_bottom_high_value_expr);
  v_str := replace(v_str, ':p_bottom_partition_name', p_bottom_partition_name);
  ------------------------------
  execute immediate v_str;
  ------------------------------
  if p_rebuild_ind_partitions
  then
    ------------------------------
    rebuid_part_indexes(p_table_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure split_partition_down_date
(
  p_table_name varchar2,
  p_partition_name varchar2,
  p_bottom_high_value date,
  p_bottom_part_name_date_fmt varchar2 := 'yyyymmdd',
  p_rebuild_ind_partitions boolean := true
)
is
  v_str varchar2(32767);
begin
  ------------------------------
  v_str := q'{to_date(':p_high_value', ':p_date_format')}';
  ------------------------------
  v_str := replace(v_str, ':p_high_value', to_char(p_bottom_high_value, p_bottom_part_name_date_fmt));
  v_str := replace(v_str, ':p_date_format', p_bottom_part_name_date_fmt);
  ------------------------------
  split_partition_down
  (
    p_table_name => p_table_name,
    p_partition_name => p_partition_name,
    p_bottom_partition_name => p_partition_name || to_char(p_bottom_high_value, p_bottom_part_name_date_fmt),
    p_bottom_high_value_expr => v_str,
    p_rebuild_ind_partitions => p_rebuild_ind_partitions
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure rebuid_part_indexes(p_table_name varchar2)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_table_name is null, 'p_table_name');
  ------------------------------
  for v_i in (
    select *
      from user_part_indexes
      where 1 = 1
        and table_name = upper(p_table_name)
      order by index_name
  ) loop
    ------------------------------
    rebuid_ind_subpartitions(v_i.index_name);
    ------------------------------
    rebuid_ind_partitions(v_i.index_name);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure rebuid_ind_partitions(p_index_name varchar2)
is
  v_str clob;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_index_name is null, 'p_index_name');
  ------------------------------
  for v_i in (
    select *
      from user_ind_partitions
      where 1 = 1
        and index_name = upper(p_index_name)
        and status = c_ind_status_unusable
      order by partition_name, partition_position
  ) loop
    ------------------------------
    v_str := q'{alter index :p_index_name rebuild partition :p_partition_name}';
    ------------------------------
    v_str := replace(v_str, ':p_index_name', p_index_name);
    v_str := replace(v_str, ':p_partition_name', v_i.partition_name);
    ------------------------------
    execute immediate v_str;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure rebuid_ind_subpartitions(p_index_name varchar2)
is
  v_str clob;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_index_name is null, 'p_index_name');
  ------------------------------
  for v_i in (
    select *
      from user_ind_subpartitions
      where 1 = 1
        and index_name = upper(p_index_name)
        and status = c_ind_status_unusable
      order by partition_name, subpartition_position
  ) loop
    ------------------------------
    v_str := q'{alter index :p_index_name rebuild subpartition :p_subpartition_name}';
    ------------------------------
    v_str := replace(v_str, ':p_index_name', p_index_name);
    v_str := replace(v_str, ':p_subpartition_name', v_i.subpartition_name);
    ------------------------------
    execute immediate v_str;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
