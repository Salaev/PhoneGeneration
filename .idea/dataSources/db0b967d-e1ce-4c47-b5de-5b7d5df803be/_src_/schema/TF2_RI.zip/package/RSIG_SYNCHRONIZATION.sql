CREATE PACKAGE RSIG_SYNCHRONIZATION IS

  --C_USE_BRANCH_IF_LONG_PERIOD   CONSTANT CHAR(1) := 'N'; --if Y then GET_SYNCHRONIZATION_PACKET will use different logic depending on of when last synchronization was made
  --C_MAXIMUM_PERIOD_VALUE        CONSTANT NUMBER := 2; --in days

  C_SYNCH_STATUS_TYPE_REQUEST    CONSTANT CHAR(1) := 'R';
  C_SYNCH_STATUS_TYPE_TRANSFER   CONSTANT CHAR(1) := 'T';
  C_SYNCH_STATUS_TYPE_COMPLETION CONSTANT CHAR(1) := 'C';

  c_SYNCH_RI_REQ_OK         CONSTANT NUMBER := 1;
  c_SYNCH_RI_REQ_IN_PROCESS CONSTANT NUMBER := 11;
  c_SYNCH_RI_REQ_FAILED     CONSTANT NUMBER := -1;

  c_SYNCH_UPRS_REQ_OK         CONSTANT NUMBER := 2;
  c_SYNCH_UPRS_REQ_IN_PROCESS CONSTANT NUMBER := 12;
  c_SYNCH_UPRS_REQ_FAILED     CONSTANT NUMBER := -2;

  c_SYNCH_UPRS_TRAN_OK         CONSTANT NUMBER := 3;
  c_SYNCH_UPRS_TRAN_IN_PROCESS CONSTANT NUMBER := 13;
  c_SYNCH_UPRS_TRAN_FAILED     CONSTANT NUMBER := -3;

  c_SYNCH_UPRS_DONE_OK         CONSTANT NUMBER := 4;
  c_SYNCH_UPRS_DONE_IN_PROCESS CONSTANT NUMBER := 14;
  c_SYNCH_UPRS_DONE_FAILED     CONSTANT NUMBER := -4;

  c_SETTING_DEF_RO_CODE        CONSTANT VARCHAR2(50) := 'DEFAULT_RO_CODE';
  c_DEFAULT_RO_CODE            CONSTANT VARCHAR2(50) := '138020';

  c_SETTING_DEF_ASCODE         CONSTANT VARCHAR2(50) := 'ASCode/FORIS';
  c_DEFAULT_ASCODE             CONSTANT VARCHAR2(50) := '13802007';

  c_set_no_sync_msisdn_status_pt         CONSTANT VARCHAR2(50) := 'NO_SYNC_MSISDN_STATUS_PHONE_TYPE';
  c_def_no_sync_msisdn_status_pt         constant varchar2(50) := 'P2';

  c_locker_type_synch_sn       CONSTANT NUMBER := util_ri.c_locker_type_synch_sn;
  c_locker_type_sid            CONSTANT NUMBER := util_ri.c_locker_type_sid;

----------------------------------!---------------------------------------------
  procedure get_synchronization_packet_all
  (
    p_synchronization_sn in number,
    p_network_operator_id network_operator.network_operator_id%type,
    p_synchronization_type synchronization_history.synchronization_type%type,
    p_include_child synchronization_history.including_child%type,
    p_request_date synchronization_history.request_date%type,
    handle_tran char,
    p_raise_error char,
    p_synchronization_date out synchronization_history.request_date%type,
    error_code out number,
    error_message out varchar2,
    p_use_temporary_tab_result boolean := false
  );

----------------------------------!---------------------------------------------
  procedure set_synchronization_request
  (
    p_synchronization_sn number,
    p_network_operator_id number,
    p_synchronization_type char,
    p_including_child varchar2,
    p_status number,
    handle_tran char,
    p_raise_error char,
    error_code out number,
    error_message  out varchar2
  );

----------------------------------!---------------------------------------------
  procedure get_synchronization_packet_int
  (
    p_synchronization_sn number,
    p_network_operator_id table_of_number,
    p_synchronization_date synchronization_history.request_date%type,
    p_synchronization_type synchronization_history.synchronization_type%type,
    p_delete_temp char default 'Y',
    handle_tran char,
    p_raise_error char,
    error_code out number,
    error_message out varchar2,
    p_use_temporary_tab_result boolean := false
  );

----------------------------------!---------------------------------------------
  procedure set_synchronization_status
  (
    p_synchronization_sn synchronization_history.synchronization_sn%type,
    p_type char,
    p_result_code synchronization_history.request_result_code%type,
    p_result_date synchronization_history.request_date%type,
    handle_tran char,
    p_raise_error char,
    error_code out number,
    error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure delete_synch_data
  (
    p_synchronization_sn number,
    handle_tran char,
    p_raise_error char,
    error_code out number,
    error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure get_synchronization_data_2
  (
    p_uprs_member_code varchar2,
    p_synchronization_type synchronization_history.synchronization_type%type,
    p_synchronization_sn synchronization_history.synchronization_sn%type,
    p_synchronization_date synchronization_history.transfer_date%type,
    p_handle_tran char default rsig_utils.c_handle_tran_y,
    p_error_code out number,
    p_error_message out varchar2,
    result_list out sys_refcursor
  ) ;

----------------------------------!---------------------------------------------
  procedure set_transfer_status_complete
  (
    p_synchronization_sn synchronization_history.synchronization_sn%type,
    p_synchronization_date synchronization_history.transfer_date%type,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure get_pso_changes
  (
    p_start_date date,
    p_date date,
    p_ps_ids out ct_number,
    p_ps_start_dates out ct_date
  );

  procedure get_naap_changes
  (
    p_start_date date,
    p_date date,
    p_na_ids out ct_number,
    p_na_from_dates out ct_date
  );

  procedure get_appa_changes
  (
    p_start_date date,
    p_date date,
    p_ap_ids out ct_number,
    p_ap_from_dates out ct_date
  );

  procedure get_pah_changes
  (
    p_start_date date,
    p_date date,
    p_pas out ct_varchar_s,
    p_pa_start_dates out ct_date
  );

  procedure get_no_changes
  (
    p_start_date date,
    p_date date,
    p_na_no_ids out ct_number,
    p_na_no_start_dates out ct_date
  );

  procedure get_nash_changes
  (
    p_start_date date,
    p_date date,
    p_nash_ids out ct_number,
    p_nash_start_dates out ct_date
  );

  function get_phone_statuses_by_pso
  (
    p_network_operator_ids ct_number,
    p_date date,
    p_city_phone_type varchar2,
    p_ps_ids ct_number,
    p_ps_start_dates ct_date
  ) return ct_msisdn_status;

  function get_phone_statuses_by_naap
  (
    p_network_operator_ids ct_number,
    p_date date,
    p_city_phone_type varchar2,
    p_na_ids ct_number,
    p_na_from_dates ct_date
  ) return ct_msisdn_status;

  function get_phone_statuses_by_appa
  (
    p_network_operator_ids ct_number,
    p_date date,
    p_city_phone_type varchar2,
    p_ap_ids ct_number,
    p_ap_from_dates ct_date
  ) return ct_msisdn_status;

  function get_phone_statuses_by_pah
  (
    p_network_operator_ids ct_number,
    p_date date,
    p_city_phone_type varchar2,
    p_pas ct_varchar_s,
    p_pa_start_dates ct_date
  ) return ct_msisdn_status;

  function get_phone_statuses_by_po
  (
    p_network_operator_ids ct_number,
    p_date date,
    p_city_phone_type varchar2,
    p_na_no_ids ct_number,
    p_na_no_start_dates ct_date
  ) return ct_msisdn_status;

  function get_phone_statuses_by_nash
  (
    p_network_operator_ids ct_number,
    p_date date,
    p_city_phone_type varchar2,
    p_nash_ids ct_number,
    p_nash_start_dates ct_date
  ) return ct_msisdn_status;

----------------------------------!---------------------------------------------
  procedure get_msisdn_status_for_cust
  (
    p_start_date date,
    p_network_operator_id number,
    p_result_list out sys_refcursor
  );

  procedure delete_dup_naap_for_cust
  (
    p_date_from date,
    p_network_operator_id number
  );

----------------------------------!---------------------------------------------

END;
/
