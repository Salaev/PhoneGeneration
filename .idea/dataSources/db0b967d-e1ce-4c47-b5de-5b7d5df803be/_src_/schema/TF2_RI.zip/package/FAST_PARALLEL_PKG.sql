CREATE package fast_parallel_pkg is

----------------------------------!---------------------------------------------
  c_this_package_name            constant varchar2(30) := 'fast_parallel_pkg';

  c_agroup_id_fastp_flows        constant number := 1106;
  c_agroup_id_fastp_tasks        constant number := 1107;
  c_agroup_id_fastp_jobs         constant number := 1108;
  c_agroup_id_fastp_flow_types   constant number := 1109;
  c_agroup_id_fastp_log_flow     constant number := 1110;
  c_agroup_id_fastp_log_task     constant number := 1111;
  c_agroup_id_fastp_log_job      constant number := 1112;

  c_agroup_name_fastp_flows      constant nvarchar2(255) := 'FAST_PARALLEL_FLOWS';
  c_agroup_name_fastp_tasks      constant nvarchar2(255) := 'FAST_PARALLEL_TASKS';
  c_agroup_name_fastp_jobs       constant nvarchar2(255) := 'FAST_PARALLEL_JOBS';
  c_agroup_name_fastp_flow_types constant nvarchar2(255) := 'FAST_PARALLEL_FLOW_TYPES';
  c_agroup_name_fastp_log_flow   constant nvarchar2(255) := 'FAST_PARALLEL_LOG_FLOW';
  c_agroup_name_fastp_log_task   constant nvarchar2(255) := 'FAST_PARALLEL_LOG_TASK';
  c_agroup_name_fastp_log_job    constant nvarchar2(255) := 'FAST_PARALLEL_LOG_JOB';

  c_minus_100500                 constant number := -100500;

  c_frp_unq_mode                 constant integer := vp_agroup_data.c_unq_none;

  c_dummy_sys_job_id             constant number := c_minus_100500;

----------------------------------!---------------------------------------------
  c_jcmd_dummy_expiry            constant number := c_minus_100500;
  c_jcmd_empty                   constant number := vp_agroup_data.c_not_defined_id;
  c_jcmd_run                     constant number := 10;
  c_jcmd_commit                  constant number := 30;
  c_jcmd_cancel                  constant number := 40;
  c_jcmd_prepare_forward         constant number := 50;
  c_jcmd_prepare_backward        constant number := 60;

  c_stat_new                     constant number := 0;
  c_stat_waiting2run             constant number := 10;
  c_stat_running                 constant number := 20;
  c_stat_waiting2complete        constant number := 30;
  c_stat_cancelling              constant number := 40;
  --!_!final statuses below
  c_stat_cancelled               constant number := 88;
  c_stat_completed               constant number := 99;

  c_wait_result_ok               constant number := 0;
  c_wait_result_break            constant number := 1;
  c_wait_result_expiry           constant number := 2;

  c_exec_result_ok               constant number := 0;
  c_exec_result_error            constant number := 1;
  c_exec_result_pending          constant number := 2;

----------------------------------!---------------------------------------------
  --!_!completion rule
  c_cr_all                       constant number := 0;
  c_cr_one                       constant number := 1;
  --!_!c_cr_quorum                    constant number := 2;

  c_count_infinity               constant number := -1;
  c_count_zero                   constant number := 0;

  c_retry_count_infinity         constant number := c_count_infinity;
  c_retry_count_no_retry         constant number := c_count_zero;

  c_dummy_wait_lock_sec          constant number := 0;
  c_log_wait_lock_sec          constant number := 10;

----------------------------------!---------------------------------------------
  --!_!optp = option prefix
  c_opt_fastp_restrct_flow_cnt   constant varchar2(100) := 'FastParallel.RestrictiveFlowCount';
  c_optp_fastp_restrct_flow_cntt constant varchar2(100) := 'FastParallel.RestrictiveFlowCount.Type'; --!_!...Type123

  c_opt_fastp_srlz_delim         constant varchar2(100) := 'FastParallel.Serialization.Delimiter';
  c_opt_fastp_srlz_delim2        constant varchar2(100) := 'FastParallel.Serialization.Delimiter2';
  c_opt_fastp_srlz_delim_subst   constant varchar2(100) := 'FastParallel.Serialization.Delimiter.Substitution';
  c_opt_fastp_srlz_err_msg_len   constant varchar2(100) := 'FastParallel.Serialization.ErrorMessage.Length';

  c_opt_fastp_inspflow_delay_sec constant varchar2(100) := 'FastParallel.InspectFlows.DelaySeconds';
  c_opt_fastp_inspflow_chk_jobs  constant varchar2(100) := 'FastParallel.InspectFlows.CheckJobsRunning';

  c_opt_fastp_log_job_errors     constant varchar2(100) := 'FastParallel.Log.Job.Errors';
  c_opt_fastp_log_job_results    constant varchar2(100) := 'FastParallel.Log.Job.Results';
  c_opt_fastp_log_task_errors    constant varchar2(100) := 'FastParallel.Log.Task.Errors';
  c_opt_fastp_log_task_results   constant varchar2(100) := 'FastParallel.Log.Task.Results';
  c_opt_fastp_log_flow_errors    constant varchar2(100) := 'FastParallel.Log.Flow.Errors';
  c_opt_fastp_log_flow_results   constant varchar2(100) := 'FastParallel.Log.Flow.Results';

  c_opt_fastp_job_run_chk_job    constant varchar2(100) := 'FastParallel.JobRunner.CheckSystemJobId';
  c_opt_fastp_job_run_chk_job_x  constant varchar2(100) := 'FastParallel.JobRunner.CheckSystemJobId.RaiseException';

----------------------------------!---------------------------------------------
  c_def_fastp_restrct_flow_cnt   constant number := 10; --!_!c_count_infinity

  c_def_fastp_srlz_delim         constant varchar2(10) := '|';
  c_def_fastp_srlz_delim2        constant varchar2(10) := '#';
  c_def_fastp_srlz_delim_subst   constant varchar2(10) := '*';
  c_def_fastp_srlz_err_msg_len   constant number := 1000;
  c_srlz_delim_len               constant number := 10;

  c_def_fastp_inspflow_delay_sec constant number := 60;
  c_def_fastp_inspflow_chk_jobs  constant boolean := true;

  c_def_fastp_log_job_errors     constant boolean := true;
  c_def_fastp_log_job_results    constant boolean := false;
  c_def_fastp_log_task_errors    constant boolean := true;
  c_def_fastp_log_task_results   constant boolean := false;
  c_def_fastp_log_flow_errors    constant boolean := true;
  c_def_fastp_log_flow_results   constant boolean := false;

  c_def_fastp_job_run_chk_job    constant boolean := true;
  c_def_fastp_job_run_chk_job_x  constant boolean := true;

----------------------------------!---------------------------------------------
  --!_!parameter placeholder
  c_pph_job_id                   constant varchar2(31) := ':p_fastp_job_id';
  c_pph_direction_forward        constant varchar2(31) := ':p_fastp_direction_forward';

  c_job_text                     constant clob := q'{begin
  :p_this_package_name.job_runner
  (
    p_job_id => :p_job_id
  );
end;
}'
  ;

----------------------------------!---------------------------------------------
  type t_fast_parallel_params is record
  (
    block_count integer,
    job_count integer
  );

----------------------------------!---------------------------------------------
  --!_!serialization items

  c_srzi_job_job_id              constant integer := 1;
  c_srzi_job_parent_id           constant integer := 2;
  c_srzi_job_user_id             constant integer := 3;
  c_srzi_job_status_id           constant integer := 4;
  c_srzi_job_command_id          constant integer := 5;
  c_srzi_job_last_date           constant integer := 6;
  c_srzi_job_sys_job_id          constant integer := 7;
  c_srzi_job_retry_count         constant integer := 8;
  c_srzi_job_retry_interval_sec  constant integer := 9;
  c_srzi_job_idle_sleep_time_sec constant integer := 10;
  c_srzi_job_expired_timeout_sec constant integer := 11;
  c_srzi_job_wait_lock_sec       constant integer := 12;
  c_srzi_job_keepalive_sec       constant integer := 13;
  c_srzi_job_work_is_done        constant integer := 14;
  c_srzi_job_error_id            constant integer := 15;
  c_srzi_job_error_message       constant integer := 16;
  c_srzi_count_job               constant integer := c_srzi_job_error_message;
  c_srzi_job_job_text            constant integer := 17;
  --!_!c_srzi_job_context             constant integer := 18;

  type t_job is record
  (
    --!_!initial
    job_id number,
    parent_id number,
    user_id number,
    status_id number,
    command_id number,
    last_date date,
    --!_!submitted
    sys_job_id number,
    --!_!internal
    retry_count number,
    retry_interval_sec number,
    idle_sleep_time_sec number,
    expired_timeout_sec number,
    wait_lock_sec number,
    keepalive_sec number,
    work_is_done boolean, --!_!persistent status
    --!_!Need for determining real state in case of failed compensation (direction_forward = false), which began from status c_stat_completed.
    --!_!In case of job crash assigned status is c_stat_waiting2run (or c_stat_running, c_stat_waiting2complete, c_stat_cancelling)
    --!_!but REAL status must be c_stat_completed
    error_id number,
    error_message clob,
    job_text clob,
    context clob
  );

  type cit_job is table of t_job index by pls_integer;

  c_srzi_task_task_id            constant integer := 1;
  c_srzi_task_parent_id          constant integer := 2;
  c_srzi_task_user_id            constant integer := 3;
  c_srzi_task_status_id          constant integer := 4;
  c_srzi_task_completion_rule    constant integer := 5;
  c_srzi_task_last_date          constant integer := 6;
  c_srzi_task_retry_count        constant integer := 7;
  c_srzi_task_retry_interval_sec constant integer := 8;
  c_srzi_task_actual_try_count   constant integer := 9;
  c_srzi_task_wait_alljobs_compl constant integer := 10;
  c_srzi_task_sync_commit        constant integer := 11;
  c_srzi_task_sleep_time_sec     constant integer := 12;
  c_srzi_task_expiredtimeout_sec constant integer := 13;
  c_srzi_task_wait_lock_sec      constant integer := 14;
  c_srzi_task_work_is_done       constant integer := 15;
  c_srzi_task_error_id           constant integer := 16;
  c_srzi_task_error_message      constant integer := 17;
  c_srzi_count_task              constant integer := c_srzi_task_error_message;
  --!_!c_srzi_task_context            constant integer := 18;

  type t_task is record
  (
    task_id number,
    parent_id number,
    user_id number,
    status_id number,
    completion_rule number,
    last_date date,
    retry_count number,
    retry_interval_sec number, --!_!really not used
    actual_try_count number,
    wait_all_jobs_completion boolean,
    sync_commit boolean,
    idle_sleep_time_sec number,
    expired_timeout_sec number,
    wait_lock_sec number,
    work_is_done boolean, --!_!really not used
    error_id number,
    error_message clob,
    context clob,
    jobs cit_job
  );

  type cit_task is table of t_task index by pls_integer;

  c_srzi_flow_flow_id            constant integer := 1;
  c_srzi_flow_user_id            constant integer := 2;
  c_srzi_flow_status_id          constant integer := 3;
  c_srzi_flow_flow_type_id       constant integer := 4;
  c_srzi_flow_reversible         constant integer := 5;
  c_srzi_flow_direction_forward  constant integer := 6;
  c_srzi_flow_last_date          constant integer := 7;
  c_srzi_flow_retry_count        constant integer := 8;
  c_srzi_flow_retry_interval_sec constant integer := 9;
  c_srzi_flow_actual_try_count   constant integer := 10;
  c_srzi_flow_wait_lock_sec      constant integer := 11;
  c_srzi_flow_work_is_done       constant integer := 12;
  c_srzi_flow_error_id           constant integer := 13;
  c_srzi_flow_error_message      constant integer := 14;
  c_srzi_count_flow              constant integer := c_srzi_flow_error_message;
  --!_!c_srzi_flow_context            constant integer := 15;

  type t_flow is record
  (
    flow_id number,
    --!_!parent_id number,
    user_id number,
    status_id number,
    flow_type_id number,
    reversible boolean,
    direction_forward boolean,
    last_date date,
    retry_count number,
    retry_interval_sec number, --!_!really not used
    actual_try_count number,
    wait_lock_sec number,
    work_is_done boolean, --!_!really not used
    error_id number,
    error_message clob,
    context clob,
    tasks cit_task
  );

  type cit_flow is table of t_flow index by pls_integer;

----------------------------------!---------------------------------------------
  procedure sleep(p_seconds number);

  function is_job_running(p_sys_job_id number) return number;
  function is_job_running2(p_sys_job_id number) return boolean;
  function get_jobs_running(p_sys_job_ids ct_number) return ct_number;

----------------------------------!---------------------------------------------
  function try_count_init return number;
  procedure try_count_increase(p_try_count in out nocopy number);
  function try_count_is_exceeded(p_actual_try_count number, p_param_retry_count number) return boolean;

  procedure timer_init(p_timeout_sec number, p_out_timeout_sec out number, p_out_start out date);
  procedure timer_alter(p_timeout_sec in out nocopy number, p_start in out nocopy date);
  function timer_is_timed_out_or_sleep(p_timeout_sec number, p_start date, p_sleep_interval_sec number) return boolean;

----------------------------------!---------------------------------------------
  function get_count_cit_job(p_coll cit_job) return number;
  function get_count_cit_task(p_coll cit_task) return number;
  function get_count_cit_flow(p_coll cit_flow) return number;

  function cast_ct_row2type4job(p_coll vp_agroup_data.rct_agroup_data) return cit_job;
  function cast_ct_type2row4job(p_coll cit_job) return vp_agroup_data.rct_agroup_data;

  function cast_ct_row2type4task(p_coll vp_agroup_data.rct_agroup_data) return cit_task;
  function cast_ct_type2row4task(p_coll cit_task) return vp_agroup_data.rct_agroup_data;

  function cast_ct_row2type4flow(p_coll vp_agroup_data.rct_agroup_data) return cit_flow;
  function cast_ct_type2row4flow(p_coll cit_flow) return vp_agroup_data.rct_agroup_data;

  function extract_ids_cit_job(p_coll cit_job) return ct_number;
  function extract_status_ids_cit_job(p_coll cit_job) return ct_number;
  function extract_sys_job_ids_cit_job(p_coll cit_job) return ct_number;
  function extract_work_is_dones_cit_job(p_coll cit_job) return ct_number;

  function extract_ids_cit_task(p_coll cit_task) return ct_number;
  function extract_status_ids_cit_task(p_coll cit_task) return ct_number;

  function extract_ids_cit_flow(p_coll cit_flow) return ct_number;
  function extract_status_ids_cit_flow(p_coll cit_flow) return ct_number;
  function extract_type_ids_cit_flow(p_coll cit_flow) return ct_number;

----------------------------------!---------------------------------------------
  procedure xcheck_completion_rule(p_completion_rule number);
  procedure xcheck_command(p_command_id number);

  procedure xcheck_status4job(p_job_status_id number);
  procedure xcheck_status4task(p_task_status_id number);
  procedure xcheck_status4flow(p_flow_status_id number);

  procedure xcheck_statuses4job(p_job_status_ids ct_number, p_can_be_empty boolean);
  procedure xcheck_statuses4task(p_task_status_ids ct_number, p_can_be_empty boolean);
  procedure xcheck_statuses4flow(p_flow_status_ids ct_number, p_can_be_empty boolean);

  procedure xcheck_status_changeable4job(p_status_id_old number, p_status_id_new number);
  procedure xcheck_status_changeable4task(p_status_id_old number, p_status_id_new number);
  procedure xcheck_status_changeable4flow(p_status_id_old number, p_status_id_new number);

  function is_allowed_status_change4job(p_status_id_old number, p_status_id_new number) return boolean;
  function is_allowed_status_change4task(p_status_id_old number, p_status_id_new number) return boolean;
  function is_allowed_status_change4flow(p_status_id_old number, p_status_id_new number) return boolean;

  function is_final_status4job(p_job_status_id number) return boolean;
  function is_final_status4task(p_task_status_id number) return boolean;
  function is_final_status4flow(p_flow_status_id number) return boolean;

  function get_final_statuses4all return ct_number;
  function get_final_statuses4job return ct_number;
  function get_final_statuses4task return ct_number;
  function get_final_statuses4flow return ct_number;

  function get_interim_statuses4job return ct_number;
  function get_interim_statuses4task return ct_number;
  function get_interim_statuses4flow return ct_number;

  function get_all_statuses4job return ct_number;
  function get_all_statuses4task return ct_number;
  function get_all_statuses4flow return ct_number;

  function get_error_status4all_i(p_direction_forward boolean) return number;
  function get_error_status4job(p_direction_forward boolean) return number;
  function get_error_status4task(p_direction_forward boolean) return number;
  function get_error_status4flow(p_direction_forward boolean) return number;

  function get_cancel_status4job(p_direction_forward boolean) return number;

  function get_success_status4all_i(p_direction_forward boolean) return number;
  function get_success_status4job(p_direction_forward boolean) return number;
  function get_success_status4task(p_direction_forward boolean) return number;
  function get_success_status4flow(p_direction_forward boolean) return number;

  function get_break_statuses4job(p_direction_forward boolean) return ct_number;

  function get_all_completion_rules return ct_number;
  function get_all_commands4job return ct_number;

  function get_break_completion_rule(p_goal_completion_rule number) return number;

  function get_work_is_done(p_direction_forward boolean) return boolean;
  function is_work_needed(p_work_is_done boolean, p_direction_forward boolean) return boolean;

----------------------------------!---------------------------------------------
  procedure xcheck_t_job(p_obj t_job, p_check_parent boolean := true);
  procedure xcheck_t_task(p_obj t_task, p_check_parent boolean := true);
  procedure xcheck_t_flow(p_obj t_flow);

  procedure xcheck_cit_job(p_coll cit_job);

----------------------------------!---------------------------------------------
  function get_serialization_delim return varchar2;
  function get_serialization_delim2 return varchar2;
  function get_serialization_delim_subst return varchar2;
  function cut_message(p_text clob) return varchar2;
  function wrap_message(p_text clob) return varchar2;

----------------------------------!---------------------------------------------
  function job_serialize(p_obj t_job) return clob;
  function job_deserialize(p_str clob) return t_job;

  function task_serialize(p_obj t_task) return clob;
  function task_deserialize(p_str clob) return t_task;

  function flow_serialize(p_obj t_flow) return clob;
  function flow_deserialize(p_str clob) return t_flow;

----------------------------------!---------------------------------------------
  function job_serialize2(p_obj t_job) return varchar2;
  function job_deserialize2(p_str varchar2) return t_job;

  function task_serialize2(p_obj t_task) return varchar2;
  function task_deserialize2(p_str varchar2) return t_task;

  function flow_serialize2(p_obj t_flow) return varchar2;
  function flow_deserialize2(p_str varchar2) return t_flow;

----------------------------------!---------------------------------------------
  procedure frp_xcheck_data_consistency(p_row_template agroup_data%rowtype, p_row_result agroup_data%rowtype, p_check_parent boolean := true);

  function frp_type2row4context_i(p_context clob, p_row_template agroup_data%rowtype) return agroup_data%rowtype;
  function frp_row2type4context_i(p_row agroup_data%rowtype) return clob;

  function frp_type2row4log0_i(p_log_type_id number, p_log_object_id number, p_user_id number, p_result_id number, p_result_message clob) return agroup_data%rowtype;
  function frp_type2row4log_i(p_user_id number, p_result_id number, p_result_message clob, p_row_template agroup_data%rowtype) return agroup_data%rowtype;
  function frp_row2type4log_res_id_i(p_row agroup_data%rowtype) return number;
  function frp_row2type4log_res_msg_i(p_row agroup_data%rowtype) return clob;

  function frp_type2row4job0_i(p_obj t_job, p_row_template agroup_data%rowtype) return agroup_data%rowtype;
  function frp_type2row4job_i(p_obj t_job) return agroup_data%rowtype;
  function frp_row2type4job_i(p_row agroup_data%rowtype) return t_job;

  function frp_type2row4task0_i(p_obj t_task, p_row_template agroup_data%rowtype) return agroup_data%rowtype;
  function frp_type2row4task_i(p_obj t_task) return agroup_data%rowtype;
  function frp_row2type4task_i(p_row agroup_data%rowtype) return t_task;

  function frp_type2row4flow0_i(p_obj t_flow, p_row_template agroup_data%rowtype) return agroup_data%rowtype;
  function frp_type2row4flow_i(p_obj t_flow) return agroup_data%rowtype;
  function frp_row2type4flow_i(p_row agroup_data%rowtype) return t_flow;

----------------------------------!---------------------------------------------
  function make_t_job1
  (
    --!_!initial
    --!_!p_job_id number,
    --!_!p_parent_id number,
    p_user_id number,
    p_status_id number,
    p_command_id number,
    --!_!p_last_date date,
    --!_!submitted
    p_sys_job_id number,
    --!_!internal
    p_retry_count number,
    p_retry_interval_sec number,
    p_idle_sleep_time_sec number,
    p_expired_timeout_sec number,
    p_wait_lock_sec number,
    p_keepalive_sec number,
    --!_!p_error_id number,
    --!_!p_error_message clob,
    p_job_text clob,
    p_context clob
  ) return t_job;

  function make_t_job2
  (
    p_user_id number,
    p_retry_count number,
    p_retry_interval_sec number,
    p_idle_sleep_time_sec number,
    p_expired_timeout_sec number,
    p_wait_lock_sec number,
    p_keepalive_sec number,
    p_job_text clob,
    p_context clob
  ) return t_job;

  function make_t_task
  (
    --!_!p_parent_id number,
    p_user_id number,
    p_completion_rule number,
    p_retry_count number,
    p_retry_interval_sec number,
    p_wait_all_jobs_completion boolean,
    p_sync_commit boolean,
    p_idle_sleep_time_sec number,
    p_expired_timeout_sec number,
    p_wait_lock_sec number,
    p_context clob,
    p_jobs cit_job,
    p_set_childs_parent boolean
  ) return t_task;

  function make_t_flow
  (
    --!_!p_parent_id number,
    p_user_id number,
    p_flow_type_id number,
    p_reversible boolean,
    p_direction_forward boolean,
    p_retry_count number,
    p_retry_interval_sec number,
    p_wait_lock_sec number,
    p_context clob,
    p_tasks cit_task,
    p_set_childs_parent boolean
  ) return t_flow;

----------------------------------!---------------------------------------------
  --!_! frp - Flows Repository

----------------------------------!---------------------------------------------
  function frp_object_is_identified(p_row agroup_data%rowtype) return boolean;
  
  function frp_acquire_id return number;

  function frp_object_get_i(p_object_id number, p_date date, p_x_raise boolean, p_lock boolean, p_wait_lock_sec number) return agroup_data%rowtype;
  function frp_object_pget_id1_i(p_parent_id number, p_id1 number, p_date date, p_x_raise boolean, p_lock boolean, p_wait_lock_sec number) return agroup_data%rowtype;

  function frp_object_xget(p_object_id number, p_date date) return agroup_data%rowtype;
  function frp_object_xlock_xget(p_object_id number, p_wait_lock_sec number) return agroup_data%rowtype;
  function frp_object_lock_pget_id1(p_parent_id number, p_id1 number, p_wait_lock_sec number) return agroup_data%rowtype;

  procedure frp_object_set(p_row agroup_data%rowtype);
  function frp_object_create(p_row agroup_data%rowtype) return agroup_data%rowtype;
  procedure frp_object_create2(p_row agroup_data%rowtype);
  procedure frp_object_change(p_row agroup_data%rowtype);

  function frp_objects_count(p_objects vp_agroup_data.rct_agroup_data) return number;
  function frp_objects_get_by_type(p_type_id number, p_date date) return vp_agroup_data.rct_agroup_data;
  function frp_objects_get_by_id(p_type_id number, p_obj_ids ct_number, p_date date) return vp_agroup_data.rct_agroup_data;
  function frp_objects_get_by_parent(p_type_id number, p_parent_id number, p_date date) return vp_agroup_data.rct_agroup_data;
  function frp_objects_get_by_status(p_type_id number, p_status_ids ct_number, p_date date) return vp_agroup_data.rct_agroup_data;
  function frp_objects_get_by_status2(p_type_id number, p_status_id number, p_date date) return vp_agroup_data.rct_agroup_data;

----------------------------------!---------------------------------------------
  function frp_object_context_get(p_object_id number) return clob;
  procedure frp_object_context_set(p_object_id number, p_context clob, p_wait_lock_sec number);

----------------------------------!---------------------------------------------
  function frp_job_get(p_job_id number, p_date date) return t_job;
  function frp_job_get2(p_job_id number) return t_job;
  function frp_jobs_get_i(p_job_ids ct_number, p_date date) return cit_job;
  function frp_jobs_get2_i(p_job_ids ct_number) return cit_job;
  function frp_jobs_childs_get_i(p_jobs cit_job, p_date date) return cit_job;
  function frp_jobs_get(p_job_ids ct_number, p_date date) return cit_job;
  function frp_jobs_get2(p_job_ids ct_number) return cit_job;
  function frp_jobs_pget(p_task_id number, p_date date) return cit_job;
  function frp_jobs_pget2(p_task_id number) return cit_job;

  function frp_task_get(p_task_id number, p_date date) return t_task;
  function frp_task_get2(p_task_id number) return t_task;
  function frp_tasks_get_i(p_task_ids ct_number, p_date date) return cit_task;
  function frp_tasks_get2_i(p_task_ids ct_number) return cit_task;
  function frp_tasks_childs_get_i(p_tasks cit_task, p_date date) return cit_task;
  function frp_tasks_get(p_task_ids ct_number, p_date date) return cit_task;
  function frp_tasks_get2(p_task_ids ct_number) return cit_task;
  function frp_tasks_pget(p_flow_id number, p_date date) return cit_task;
  function frp_tasks_pget2(p_flow_id number) return cit_task;

  function frp_flow_get(p_flow_id number, p_date date) return t_flow;
  function frp_flow_get2(p_flow_id number) return t_flow;
  function frp_flows_get_i(p_flow_ids ct_number, p_date date) return cit_flow;
  function frp_flows_get2_i(p_flow_ids ct_number) return cit_flow;
  function frp_flows_childs_get_i(p_flows cit_flow, p_date date) return cit_flow;
  function frp_flows_get(p_flow_ids ct_number, p_date date) return cit_flow;
  function frp_flows_get2(p_flow_ids ct_number) return cit_flow;
  function frp_flows_pget(p_date date) return cit_flow;
  function frp_flows_pget2 return cit_flow;
  function frp_flows_pget_by_status(p_status_ids ct_number, p_date date) return cit_flow;
  function frp_flows_pget_by_status2(p_status_ids ct_number) return cit_flow;

----------------------------------!---------------------------------------------
  procedure frp_log(p_log_type_id number, p_log_object_id number, p_user_id number, p_result_id number, p_result_message clob);

  procedure frp_log_job(p_job_id number, p_user_id number, p_result_id number, p_result_message clob);
  procedure frp_log_job_smart(p_job_id number, p_user_id number, p_result_id number, p_result_message clob);

  procedure frp_log_task(p_task_id number, p_user_id number, p_result_id number, p_result_message clob);
  procedure frp_log_task_smart(p_task_id number, p_user_id number, p_result_id number, p_result_message clob);

  procedure frp_log_flow(p_flow_id number, p_user_id number, p_result_id number, p_result_message clob);
  procedure frp_log_flow_smart(p_flow_id number, p_user_id number, p_result_id number, p_result_message clob);

----------------------------------!---------------------------------------------
  procedure frp_job_set(p_obj t_job, p_force_status boolean);

  function frp_job_set_status(p_obj t_job, p_status_id number, p_force boolean) return t_job;
  function frp_job_set_status_ext(p_obj t_job, p_status_id number, p_error_id number, p_error_message clob, p_force boolean) return t_job;
  function frp_job_set_work_is_done(p_obj t_job, p_work_is_done boolean) return t_job;
  function frp_job_set_keepalive(p_obj t_job) return t_job;
  function frp_job_set_command(p_obj t_job, p_command_id number) return t_job;
  function frp_job_clear_command(p_obj t_job) return t_job;

  function frp_job_create_i(p_obj t_job) return t_job;
  procedure frp_job_create(p_obj t_job);

----------------------------------!---------------------------------------------
  procedure frp_task_set(p_obj t_task, p_force_status boolean);
  function frp_task_set_status(p_obj t_task, p_status_id number, p_force boolean) return t_task;
  function frp_task_set_status_ext(p_obj t_task, p_status_id number, p_error_id number, p_error_message clob, p_force boolean) return t_task;
  function frp_task_inc_actual_try_count(p_obj t_task, p_error_id number, p_error_message clob) return t_task;
  function jfrp_task_set_actual_try_count(p_obj t_task, p_actual_try_count number) return t_task;
  function ifrp_task_set_actual_try_count(p_obj t_task, p_actual_try_count number) return t_task;

  function frp_task_create_i(p_obj t_task) return t_task;
  procedure frp_task_create(p_obj t_task);

----------------------------------!---------------------------------------------
  procedure frp_flow_set(p_obj t_flow, p_force_status boolean);
  function frp_flow_set_status(p_obj t_flow, p_status_id number, p_force boolean) return t_flow;
  function frp_flow_set_status_ext(p_obj t_flow, p_status_id number, p_error_id number, p_error_message clob, p_force boolean) return t_flow;
  function frp_flow_set_direction_forward(p_obj t_flow, p_direction_forward boolean) return t_flow;
  function frp_flow_inc_actual_try_count(p_obj t_flow, p_error_id number, p_error_message clob) return t_flow;
  function jfrp_flow_set_actual_try_count(p_obj t_flow, p_actual_try_count number) return t_flow;
  function ifrp_flow_set_actual_try_count(p_obj t_flow, p_actual_try_count number) return t_flow;

  function frp_flow_create_i(p_obj t_flow) return t_flow;
  procedure frp_flow_create(p_obj t_flow);

----------------------------------!---------------------------------------------
  function job_submit(p_obj t_job) return t_job;
  function jobs_submit(p_objs cit_job) return cit_job;

  function job_set_parent(p_obj t_job, p_parent_id number) return t_job;
  function jobs_set_parent(p_objs cit_job, p_parent_id number) return cit_job;

----------------------------------!---------------------------------------------
  function task_set_parent(p_obj t_task, p_parent_id number) return t_task;
  function tasks_set_parent(p_objs cit_task, p_parent_id number) return cit_task;

----------------------------------!---------------------------------------------
  function make_job_text(p_job_id number) return clob;

----------------------------------!---------------------------------------------
  function job_wait_pickup_command
  (
    p_job_id number,
    p_expired_timeout_sec number,
    p_idle_sleep_time_sec number
  ) return number;

  function wait_jobs_running
  (
    p_job_ids ct_number,
    p_expired_timeout_sec number,
    p_idle_sleep_time_sec number,
    p_completion_rule number,
    p_for_running boolean
  ) return number;

  function wait_jobs_status
  (
    p_job_ids ct_number,
    p_expired_timeout_sec number,
    p_idle_sleep_time_sec number,
    p_goal_status_ids ct_number,
    p_break_status_ids ct_number,
    p_goal_completion_rule number,
    p_break_completion_rule number
  ) return number;

  function wait_jobs_status2
  (
    p_job_ids ct_number,
    p_expired_timeout_sec number,
    p_idle_sleep_time_sec number,
    p_goal_status_ids ct_number,
    p_break_status_ids ct_number,
    p_goal_completion_rule number
  ) return number;

  function wait_jobs_status3
  (
    p_job_ids ct_number,
    p_expired_timeout_sec number,
    p_idle_sleep_time_sec number,
    p_goal_status_id number,
    p_break_status_ids ct_number,
    p_goal_completion_rule number
  ) return number;

  function activate_jobs(p_jobs cit_job) return cit_job;

----------------------------------!---------------------------------------------
  function obj_has_value(p_obj_value number, p_goal_values ct_number, p_goal_can_be_empty boolean) return boolean;
  function objs_has_value_i(p_obj_values ct_number, p_goal_values ct_number, p_completion_rule number) return boolean;
  function objs_has_value2_i(p_obj_values ct_number, p_goal_value number, p_completion_rule number) return boolean;
  function cnt_objs_has_value_i(p_obj_values ct_number, p_goal_values ct_number) return number;
  function cnt_objs_has_value2_i(p_obj_values ct_number, p_goal_value number) return number;

  function job_has_status(p_job_status_id number, p_goal_status_ids ct_number) return boolean;
  function job_has_status2(p_job t_job, p_goal_status_ids ct_number) return boolean;
  function job_has_status3(p_job_id number, p_goal_status_ids ct_number) return boolean;

  function task_has_status(p_task_status_id number, p_goal_status_ids ct_number) return boolean;
  function task_has_status2(p_task t_task, p_goal_status_ids ct_number) return boolean;
  function task_has_status3(p_task_id number, p_goal_status_ids ct_number) return boolean;

  function flow_has_status(p_flow_status_id number, p_goal_status_ids ct_number) return boolean;
  function flow_has_status2(p_flow t_flow, p_goal_status_ids ct_number) return boolean;
  function flow_has_status3(p_flow_id number, p_goal_status_ids ct_number) return boolean;

  function jobs_has_status(p_job_ids ct_number, p_goal_status_ids ct_number, p_completion_rule number) return boolean;
  function jobs_has_status2(p_job_ids ct_number, p_goal_status_id number, p_completion_rule number) return boolean;
  function jobs_work_is_done2(p_job_ids ct_number, p_work_is_done boolean, p_completion_rule number) return boolean;

  function tasks_has_status(p_task_ids ct_number, p_goal_status_ids ct_number, p_completion_rule number) return boolean;
  function tasks_has_status2(p_task_ids ct_number, p_goal_status_id number, p_completion_rule number) return boolean;

  function flows_has_status(p_flow_ids ct_number, p_goal_status_ids ct_number, p_completion_rule number) return boolean;
  function flows_has_status2(p_flow_ids ct_number, p_goal_status_id number, p_completion_rule number) return boolean;

  function jobs_are_running(p_job_ids ct_number, p_completion_rule number, p_for_running boolean) return boolean;

----------------------------------!---------------------------------------------
  function object_context_get(p_object_id number) return clob;
  procedure object_context_set(p_object_id number, p_context clob, p_wait_lock_sec number);

  function job_get(p_job_id number) return t_job;
  function jobs_get(p_job_ids ct_number) return cit_job;

  function task_get(p_task_id number) return t_task;
  function tasks_get(p_task_ids ct_number) return cit_task;

  function flow_get(p_flow_id number) return t_flow;
  function flows_get(p_flow_ids ct_number) return cit_flow;
  function flows_pget_active return cit_flow;

  procedure save_flow(p_flow t_flow);

----------------------------------!---------------------------------------------
  procedure job_set_status(p_job_id number, p_status_id number);
  procedure job_set_status_ext(p_job_id number, p_status_id number, p_error_id number, p_error_message clob);
  procedure job_set_status_force(p_job_id number, p_status_id number);
  procedure job_set_status_ext_force(p_job_id number, p_status_id number, p_error_id number, p_error_message clob);
  procedure job_set_work_is_done(p_job_id number, p_work_is_done boolean);
  procedure job_set_keepalive(p_job_id number);
  procedure job_set_command(p_job_id number, p_command_id number);
  procedure jobs_set_command(p_job_ids ct_number, p_command_id number);
  procedure job_clear_command(p_job_id number);
  procedure jobs_clear_command(p_job_ids ct_number);

  procedure task_set_status(p_task_id number, p_status_id number);
  procedure task_set_status_ext(p_task_id number, p_status_id number, p_error_id number, p_error_message clob);
  procedure task_set_status_force(p_task_id number, p_status_id number);
  procedure task_set_status_ext_force(p_task_id number, p_status_id number, p_error_id number, p_error_message clob);
  procedure task_inc_actual_try_count(p_task_id number, p_error_id number, p_error_message clob);

  procedure flow_set_status(p_flow_id number, p_status_id number);
  procedure flow_set_status_ext(p_flow_id number, p_status_id number, p_error_id number, p_error_message clob);
  procedure flow_set_status_force(p_flow_id number, p_status_id number);
  procedure flow_set_status_ext_force(p_flow_id number, p_status_id number, p_error_id number, p_error_message clob);
  procedure flow_set_direction_forward(p_flow_id number, p_direction_forward boolean);
  procedure flow_inc_actual_try_count(p_flow_id number, p_error_id number, p_error_message clob);
  procedure iflow_set_actual_try_count(p_flow_id number, p_actual_try_count number);

----------------------------------!---------------------------------------------
  procedure at_job_set_status(p_job_id number, p_status_id number);
  procedure at_job_set_status_ext(p_job_id number, p_status_id number, p_error_id number, p_error_message clob);
  procedure at_job_set_status_force(p_job_id number, p_status_id number);
  procedure at_job_set_status_ext_force(p_job_id number, p_status_id number, p_error_id number, p_error_message clob);
  procedure at_job_set_work_is_done(p_job_id number, p_work_is_done boolean);
  procedure at_job_set_keepalive(p_job_id number);
  procedure at_job_set_command(p_job_id number, p_command_id number);
  procedure at_jobs_set_command(p_job_ids ct_number, p_command_id number);
  procedure at_job_clear_command(p_job_id number);
  procedure at_jobs_clear_command(p_job_ids ct_number);

  procedure at_task_set_status(p_task_id number, p_status_id number);
  procedure at_task_set_status_ext(p_task_id number, p_status_id number, p_error_id number, p_error_message clob);
  procedure at_task_set_status_force(p_task_id number, p_status_id number);
  procedure at_task_set_status_ext_force(p_task_id number, p_status_id number, p_error_id number, p_error_message clob);
  procedure at_task_inc_actual_try_count(p_task_id number, p_error_id number, p_error_message clob);

  procedure at_flow_set_status(p_flow_id number, p_status_id number);
  procedure at_flow_set_status_ext(p_flow_id number, p_status_id number, p_error_id number, p_error_message clob);
  procedure at_flow_set_status_force(p_flow_id number, p_status_id number);
  procedure at_flow_set_status_ext_force(p_flow_id number, p_status_id number, p_error_id number, p_error_message clob);
  procedure at_flow_set_direction_forward(p_flow_id number, p_direction_forward boolean);
  procedure at_flow_inc_actual_try_count(p_flow_id number, p_error_id number, p_error_message clob);
  procedure at_iflow_set_actual_try_count(p_flow_id number, p_actual_try_count number);

  function at_job_wait_pickup_command
  (
    p_job_id number,
    p_expired_timeout_sec number,
    p_idle_sleep_time_sec number
  ) return number;

  function at_activate_jobs(p_jobs cit_job) return cit_job;

----------------------------------!---------------------------------------------
  function get_first_task_index(p_tasks cit_task, p_goal_status_id number) return number;
  function get_last_task_index(p_tasks cit_task, p_goal_status_id number) return number;

  function task_jobs_are_running(p_task_id number, p_completion_rule number, p_for_running boolean) return boolean;
  function flow_jobs_are_running(p_flow_id number) return boolean;

----------------------------------!---------------------------------------------
  procedure job_runner(p_job_id number);

----------------------------------!---------------------------------------------
  function command_to_jobs_and_wait
  (
    p_job_ids ct_number,
    p_command_id number,
    p_goal_status_id number,
    p_completion_rule number,
    p_direction_forward boolean,
    p_wait_all_jobs_completion boolean,
    p_check_break_status boolean,
    p_idle_sleep_time_sec number,
    p_expired_timeout_sec number
  ) return number;

  function execute_task(p_task_id number, p_direction_forward boolean) return number;

  function execute_flow
  (
    p_flow_id number,
    p_force_status boolean,
    p_forced_direction_forward boolean --!_!not used with p_force_status => false
  ) return number;

  function make_opt_name_restrct_flow_typ(p_flow_type_id number) return varchar2;
  function need_to_restrict_flow(p_flow_type_id number, p_this_is_created boolean) return boolean;
  procedure xneed_to_restrict_flow(p_flow_type_id number, p_this_is_created boolean);
  procedure raise_exceeded(p_flow_type_id number);

----------------------------------!---------------------------------------------
  procedure at_save_flow(p_flow t_flow);

  function at_execute_flow
  (
    p_flow_id number,
    p_force_status boolean,
    p_forced_direction_forward boolean --!_!not used with p_force_status => false
  ) return number;

  procedure at_execute_flow2
  (
    p_flow_id number,
    p_force_status boolean,
    p_forced_direction_forward boolean --!_!not used with p_force_status => false
  );

  function at_execute_flow3
  (
    p_flow_id number
  ) return number;

  procedure at_execute_flow4
  (
    p_flow_id number
  );

  procedure get_flow_exact_error
  (
    p_flow_id number,
    p_error_id out number,
    p_error_message out varchar2,
    p_failed_task_id out number,
    p_failed_task_index out number,
    p_failed_job_id out number,
    p_failed_job_index out number
  );

----------------------------------!---------------------------------------------
  procedure at_inspect_flows;

  procedure at_flow_accomplish
  (
    p_flow_id number,
    p_force_status boolean,
    p_direction_forward boolean
  );

----------------------------------!---------------------------------------------

end;
/
