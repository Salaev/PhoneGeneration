CREATE package RSIG_PORTING is

  -- Public type declarations
  TYPE t_date IS TABLE OF DATE INDEX BY BINARY_INTEGER;
  TYPE T_MNP IS TABLE OF VARCHAR2(3) INDEX BY BINARY_INTEGER;
  TYPE T_lrn IS TABLE OF VARCHAR2(4) INDEX BY BINARY_INTEGER;
  TYPE t_TT_LRN_HIST IS TABLE OF TT_LRN_HIST%rowtype;

-----------------------------------------------------------------------------
  -- constants
  -----------------------------------------------------------------------------
  
  c_SETTING_NUMBER_PORTING_USER VARCHAR2(30) := 'NUMBER_PORTING_USER'; -- constant representing default user

PROCEDURE Save_Porting_History(
    p_msisdn_number           IN  COMMON.t_international_format,
    p_donor_telco_id          IN  T_MNP,
    p_recipient_telco_id      IN  T_MNP,
    p_routing_number          IN  T_lrn,
    p_port_time               IN  t_date,
    p_network_routing_number  IN  T_lrn,
    p_handle_tran               IN  CHAR,
    p_error_code              OUT NUMBER,
  p_error_message              OUT VARCHAR2
  );

PROCEDURE get_last_porting_date(
    p_msisdn                IN   VARCHAR2,
    p_cursor                OUT  SYS_REFCURSOR,
    p_error_code            OUT  NUMBER,
    p_error_message         OUT  VARCHAR2
);

PROCEDURE get_lrn_for_numbers(
  p_id                      IN   Common.t_number,
  p_msisdn                  IN   Common.t_international_format,
  p_port_time               IN   t_date,
  p_cursor                  OUT  SYS_REFCURSOR,
  p_error_code              OUT  NUMBER,
  p_error_message           OUT  VARCHAR2
  );

end;
/
