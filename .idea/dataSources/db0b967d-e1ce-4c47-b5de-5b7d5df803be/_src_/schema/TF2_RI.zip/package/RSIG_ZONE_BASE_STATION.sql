CREATE PACKAGE          "RSIG_ZONE_BASE_STATION" IS

TYPE t_BSC IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;
TYPE t_MSC IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
/****************************************************************************
<header>
  <name>             	package RSIG_ZONE_BASE_STATION
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>


  <version>           1.3.8     22.04.2010    Pavel Vasiliev
                      procedure	RSIG_ZONE_BASE_STATION.Get_Zone_Base_Station	updated

  <version>           1.3.7     12.03.2007    Roger Stockley
                      procedure Get_Zone_Base_Station updated
                      procedure Get_Zone_Base_Station_All updated
                      procedure Get_Zone_Base_Station_LAC updated
                      procedure Insert_LA_zone_intervals updated
  </version>
  <version>           1.3.6     12.01.2007    Petr Cepek
                      procedure Get_Zone_Base_Station_LAC updated
  </version>
  <version>           1.3.5     15.08.2006    Petr Cepek
                      procedure Get_Zone_Base_Station_LAC updated
  </version>
  <version>           1.3.4     3.8.2006      Petr Cepek
                      procedure Insert_Interval deleted
                      procedure Close_Interval deleted
                      procedure Get_One_Zone_Base_Station deleted
                      procedure Get_Zone_Base_Station updated
                      procedure Get_Zone_Base_Station_All updated
                      procedure Get_Zone_Base_Station_LAC updated
  </version>
  <version>           1.3.3     31.03.2006    Petr Cepek
                      procedure Get_Zone_Base_Station_LAC
  </version>
  <version>           1.3.2     20.2.2006     Martin Zabka
                      procedure Get_One_Zone_Base_Station and Get_Zone_Base_Station updated
  </version>
  <version>           1.3.1     6.2.2006     Petr Cepek
                      procedure Get_One_Zone_Base_Station and Get_Zone_Base_Station updated
  </version>
  <version>
                      1.3.0    25.01.2005    Petr Cepek
                      procedures Get_Zone_Base_Station, Get_One_Zone_Base_Station updated
  </version>
    <version>           1.2.0	15.12.2005 Radomir Lipka
                        procedure Get_Zone_Base_Station_All updated
    </version>
    <version>           1.1.19	14.12.2005 Radomir Lipka
                        procedure Get_Zone_Base_Station_All added
    </version>
    <version>           1.1.18	02.12.2005 Radomir
                        procedure Get_One_Zone_Base_Station updated
    </version>
    <version>           1.1.17	01.12.2005 Radomir
                        procedure Get_Zone_Base_Station updated
                        procedure Get_One_Zone_Base_Station added
    </version>
    <version>           1.1.16	03.02.2005 Jaroslav Holub
                        Get_Zone_Base_Station - optimized select
    </version>
    <version>           1.1.15	15.09.2004 Jaroslav Holub
							          Get_Zone_Base_Station - fixed for time difference between client and server,
							          date should be null and it means sysdate
							          Close_Interval - error with v_enddate - p_end_date check
    </version>
	  <version> 		        1.1.14   10.9.2004     Jaroslav Holub
                 			Insert_Interval, Close_Interval - fixed for time difference
							        between client and server, date should be null and it means sysdate
	  </version>
	  <version>       1.1.13	15.4.2004     Jaroslav Holub
							      change for TMP_BASE_STATION_CODE change ( proc Get_Zone_Base_Station)
    </version>
	<version>       1.1.12 	12.4.2004     Jaroslav Holub
							    changed for undelete ZONE
    </version>
	<version>       1.1.11   8.4.2004     Jaroslav Holub
                                changed for undelete
    </version>
    <version> 		1.1.10 	15.12.2003/12/15 10:21:16  prybicka
                      		*** empty log message ***

  	</version>
    <version> 		1.1.8  	15.12.2003/12/15 08:03:09  prybicka
                      		used constants c_DEBUG_TEXT_*
  	</version>
    <version> 		1.1.7  	15.12.2003/12/15 06:44:45  jstodulk
                      		Insert parameter RSIG_UTILS.c_MIN_DATE.
  	</version>
    <version> 		1.1.6  	15.12.2003/12/05 12:14:48  prybicka
                      		added parameter p_start_date
  	</version>
    <version> 		1.1.5  	15.12.2003/12/05 11:59:42  jstodulk
                      		Insert new procedure Get_Zone_Base_Station.
  	</version>
    <version> 		1.1.5  	1.0.1  	10.9.2003     Radek Hejduk
                            created first version
  	</version>

  <Description>      	package for table ZONE_BASE_STATION
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/

/****************************************************************************
  <header>
    <name>              procedure Get_Zone_Base_Station
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.1.1      12.03.2007       Roger Stockley
                        procedure now also returns results by zone type
    </version>
    <version>           1.1.0      08.08.2006       Petr Cepek
                        new functionality implemented - location area
                        can be added into some zone
    </version>
    <version>           1.0.9      20.02.2006       Martin Zabka
                        zone_code in output cursor is trimed
    </version>
    <version>           1.0.8      25.01.2006       Petr Cepek
                        selecting of time interval fixed,
                        column zone_id removed from result set
    </version>
	  <version>           1.0.7   01.12.2005     Radomir Lipka
                   		  replaced tmp table with asoc.array
  	</version>
    <version>           1.0.6	03.02.2005 Jaroslav Holub
                        Get_Zone_Base_Station - optimized select
    </version>
    <version>           1.0.5	15.09.2004 Jaroslav Holub
								        fixed for time difference between client and server,
								        date should be null and it means sysdate
    </version>
	  <version>       	1.0.4   15.4.2004     Jaroslav Holub
                      changed for undelete - changed temp table TMP_BASE_STATION_CODE,
									    so need to be changed proc.
    </version>
	  <version>       	1.0.3   8.4.2004     Jaroslav Holub
                                changed for undelete
    </version>
    <version>           1.0.2   29.12.2003   Lucie Sevcikova
                                bug fixed
    </version>
    <version>           1.0.1   4.12.2003     Jan Stodulka
                                created first version
    </version>

    <Description>     This procedure will return list of zones for given validity date (start_date and end_date).
                      Ref cursor contains columns: ZONE_CODE, ZONE_NAME, NETWORK_OPERATOR_NAME.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code            - Error code
                        p_start_date  	      - Start of data request period
                        p_end_date	          - End of data request period
                        p_batch_session_id	  - Session identification (for finding list of data)
                        p_result              - ref cursor (BASE_STATION_CODE, ZONE_CODE, START_DATE, END_DATE)
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Get_Zone_Base_Station(
    error_code            OUT  NUMBER,
    p_start_date  	      IN   DATE,
    p_end_date	          IN   DATE,
    p_bsc_list            IN   t_BSC,
    p_result              OUT  RSIG_UTILS.REF_CURSOR
  );


/****************************************************************************
  <header>
    <name>              procedure Get_Zone_Base_Station_All
    </name>

    <author>            Radomir Lipka
    </author>

    <version>           1.0.3    12.03.2007       Roger Stockley
                        procedure now also returns results by zone type
    </version>
    <version>           1.0.2    08.08.2006    Petr Cepek
                        new functionality implemented - location area
                        can be added into some zone
    </version>
    <version>           1.0.1   15.12.2005     Radomir Lipka
                                added JOIN ON ZONE, LOCATION_AREA
    </version>
    <version>           1.0.0   14.12.2005     Radomir Lipka
                                created first version
    </version>

    <Description>
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code            - Error code
                        p_result              - ref cursor (BASE_STATION_CODE, ZONE_CODE, START_DATE, END_DATE)
    </Parameters>

  </header>
/****************************************************************************/

PROCEDURE Get_Zone_Base_Station_All
(
  ERROR_CODE           OUT NUMBER,
  p_result             OUT RSIG_UTILS.REF_CURSOR
);

/****************************************************************************
  PROCEDURE

  %author           Petr Cepek
  %created          31.3.2006
  %version          1.0.2
  %application      Resource Inventory

  %usage            Procedure returns cursor of valid zones for
                    given base stations and location areas.

*/
/* {%skip}
  %version_log

  {*}1.0.4 - 12.03.2007 - Roger Stockley
             Procedure now also returns results by zone type.
  {*}1.0.3 - 12.01.2007 - Roger Stockley
             Addition of input parameter p_msc_list
             to return results for MSC, BSC and LAC.
  {*}1.0.2 - 15.08.2006 - Petr Cepek
             bugs fixed
  {*}1.0.1 - 08.08.2006 - Petr Cepek
             new functionality implemented - location area
             can be added into some zone
  {*}1.0.0 - 31.3.2006 - Petr Cepek
             created first version

****************************************************************************/
PROCEDURE Get_Zone_Base_Station_LAC(
  p_msc_list               IN  t_MSC,
  p_bsc_list               IN  t_BSC,
  p_lac_list               IN  t_BSC,
  p_start_date             IN  DATE,
  p_end_date               IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure Insert_LA_zone_intervals
  </name>

  <author>          Petr Cepek
  </author>

  <version>         1.0.1    12.03.2007       Roger Stockley
                    procedure now also queries by zone type
  </version>
  <version>
                    1.0.0  07.08.2006  -  created
  </version>

  <Description>     Procedure select general relations to zone for specific
                    location area in given time period.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Insert_LA_zone_intervals(
  p_location_area_id    IN  location_area.location_area_id%TYPE,
  p_base_station_id     IN  base_station.base_station_id%TYPE,
  p_zone_type_id        IN  zone_type.ZONE_TYPE_code%TYPE,
  p_start_date          IN  DATE,
  p_end_date            IN  DATE
);


END RSIG_ZONE_BASE_STATION;

/
