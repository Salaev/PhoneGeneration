CREATE PACKAGE BODY RSIG_USERS IS

---------------------------------------------
--     PROCEDURE Test_Row_For_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Row_For_Exist_And_Deleted(p_user_id IN USERS.USER_ID%TYPE) IS
  v_deleted USERS.DELETED%TYPE;

BEGIN

  select DELETED into v_deleted from users where USER_ID = p_user_id;

  IF v_deleted IS NOT NULL THEN
    IF v_deleted < sysdate THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
    END IF;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Test_Row_For_Exist_And_Deleted;

---------------------------------------------
--     PROCEDURE Insert_User
---------------------------------------------

PROCEDURE Insert_User
(
  handle_tran  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code   OUT NUMBER,
  p_user_name  IN USERS.USER_NAME%TYPE,
  p_login_name IN USERS.LOGIN_NAME%TYPE,
  p_user_id    OUT USERS.USER_ID%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_USERS.Insert_User';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint Insert_User_a;
  END IF;

  select s_users.nextval into p_user_id from DUAL;

  BEGIN
    INSERT INTO USERS
      (USER_ID,
       USER_NAME,
       LOGIN_NAME)
    VALUES
      (p_user_id,
       p_user_name,
       p_login_name);

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_USER_NAME then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_USER_NAME, '');
      else
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_USER_LOG_NAME, '');
      end if;
  END;
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint Insert_User_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Insert_User;

---------------------------------------------
--     PROCEDURE Delete_User
---------------------------------------------

PROCEDURE Delete_User
(
  handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code  OUT NUMBER,
  p_user_id   IN USERS.USER_ID%TYPE,
  p_deleted   IN USERS.DELETED%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_USERS.Delete_User';
  v_deleted      DATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint Delete_User_a;
  END IF;
  v_deleted := nvl(p_deleted, SYSDATE);
  /*   IF  p_deleted is null THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
    END IF;
  */
  Test_Row_For_Exist_And_Deleted(p_user_id);

  update USERS set DELETED = v_deleted where USER_ID = p_user_id;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint Delete_User_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Delete_User;


---------------------------------------------
--     PROCEDURE Update_User
---------------------------------------------

PROCEDURE Update_User
(
  handle_tran  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code   OUT NUMBER,
  p_user_id    IN USERS.USER_ID%TYPE,
  p_user_name  IN USERS.USER_NAME%TYPE,
  p_login_name IN USERS.LOGIN_NAME%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_USERS.Update_User';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint Update_User_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_user_id);

  BEGIN
    UPDATE USERS
       SET USER_NAME  = p_user_name,
           LOGIN_NAME = p_login_name
     WHERE USER_ID = p_user_id;

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_USER_NAME then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_USER_NAME, '');
      else
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_USER_LOG_NAME, '');
      end if;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint Update_User_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Update_User;

---------------------------------------------
--     PROCEDURE Get_User_Id
---------------------------------------------

PROCEDURE Get_User_Id
(
  error_code   OUT NUMBER,
  p_login_name IN USERS.LOGIN_NAME%TYPE,
  p_users_id   OUT USERS.USER_ID%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_USERS.Get_User_Id';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_login_name IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  begin
    select u.USER_ID
      into p_users_id
      from users u
     where upper(u.LOGIN_NAME) = upper(p_login_name)
       and (u.DELETED >= sysdate or u.DELETED is null);

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      p_users_id := c_NO_USER;
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_USER_NOT_FOUND, '');
  end;

  error_code := RSIG_UTILS.c_OK;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_User_Id;

---------------------------------------------
--     PROCEDURE Get_User_login
---------------------------------------------

PROCEDURE Get_User_login
(
  error_code   OUT NUMBER,
  p_users_id   IN USERS.USER_ID%TYPE,
  p_login_name OUT USERS.LOGIN_NAME%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_USERS.Get_User_login';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  --IF p_login_name IS NULL THEN
  --  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  --END IF;

  begin
    select u.login_name
      into p_login_name
      from users u
     where u.user_id = p_users_id
       and (u.DELETED >= sysdate or u.DELETED is null);

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_USER_NOT_FOUND, '');
  end;

  error_code := RSIG_UTILS.c_OK;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_User_login;

---------------------------------------------
--     PROCEDURE Get_user_id_by_login
---------------------------------------------
FUNCTION Get_user_id_by_login
(
  p_login_name  IN users.login_name%TYPE
) RETURN NUMBER IS
  v_user_id  NUMBER;
BEGIN
  IF p_login_name IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  BEGIN
    SELECT u.user_id INTO v_user_id
      FROM users u
     WHERE UPPER(u.login_name) = upper(p_login_name)
       AND (u.deleted >= SYSDATE OR u.deleted IS NULL);
    RETURN v_user_id;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_USER_NOT_FOUND, '');
  END;

END Get_user_id_by_login;

END RSIG_USERS;
/
