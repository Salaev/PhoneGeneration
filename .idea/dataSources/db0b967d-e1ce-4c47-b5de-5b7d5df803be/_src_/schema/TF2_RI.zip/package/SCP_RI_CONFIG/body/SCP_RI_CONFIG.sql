CREATE PACKAGE BODY SCP_RI_CONFIG IS

  FUNCTION GET_PARAMS
  ( in_parameter_name   IN VARCHAR2
  , in_default_value    IN VARCHAR2
  ) RETURN VARCHAR2
  AS
  BEGIN
    /* IS_HOST_PRESENT
       SYNCHRONIZATION_STATUS
    */
    RETURN install_pkg.get_option(in_parameter_name, in_default_value);
  END;

  PROCEDURE GET_VERSION
  ( out_last_synch       OUT DATE
  , out_foris_ri_version OUT VARCHAR2
  , out_scp_ri_version   OUT VARCHAR2
  , out_sync_state       OUT VARCHAR2
  , in_version_type      IN NUMBER
  )
  IS
  BEGIN
    util_loc_pkg.touch_number(in_version_type);
    out_last_synch := null;
    out_foris_ri_version := 'Foris_RI';
    out_scp_ri_version := 'N/A';
    out_sync_state := 'N/A';
  END;

END;
/
