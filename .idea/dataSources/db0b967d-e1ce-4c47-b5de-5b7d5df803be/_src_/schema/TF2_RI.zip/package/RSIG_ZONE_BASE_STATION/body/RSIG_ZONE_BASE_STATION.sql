CREATE PACKAGE BODY          "RSIG_ZONE_BASE_STATION" IS
---------------------------------------------
--     PROCEDURE Get_Zone_Base_Station
---------------------------------------------

PROCEDURE Get_Zone_Base_Station
(
  error_code         OUT NUMBER,
  p_start_date       IN DATE,
  p_end_date         IN DATE,
  p_bsc_list         IN t_BSC,
  p_result           OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_ZONE_BASE_STATION.Get_Zone_Base_Station';
  v_start_date   DATE;
  
  v_BSC_LAC_MSC_OBJ        t_BSC_LAC_MSC_obj:=t_BSC_LAC_MSC_obj(NULL,NULL,NULL);
  v_BSC_LAC_MSC_list			  t_BSC_LAC_MSC_obj_tab:= t_BSC_LAC_MSC_obj_tab();

  -- all individual relations to zones where also exist global relation to zone
  CURSOR c_bs IS
  SELECT zbs.base_station_id,
         zbs.zone_id,
         zbs.location_area_id,
         zt.zone_type_code,
         zbs.start_date,
         zbs.end_date
  FROM TABLE(CAST(v_BSC_LAC_MSC_list AS t_BSC_LAC_MSC_obj_tab))  tt
  JOIN base_station bs ON bs.base_station_code=tt.base_station_code
       AND (bs.deleted IS NULL OR bs.deleted>v_start_date)
  JOIN location_area la ON la.location_area_id=bs.location_area_id
       AND (la.deleted IS NULL OR la.deleted>v_start_date)
  JOIN zone_base_station zbs ON (zbs.base_station_id=bs.base_station_id
      AND zbs.msc_id IS NULL
      AND zbs.network_operator_id IS NULL)
  JOIN zone_type zt ON zt.ZONE_TYPE_code = zbs.zone_type_code
  WHERE (zbs.end_date>=v_start_date OR zbs.end_date IS NULL)
    AND (zbs.start_date<=p_end_date OR p_end_date IS NULL)
    AND (zt.DELETED IS NULL OR zt.deleted > v_start_date)
    AND EXISTS(SELECT 1
               FROM zone_base_station zbsl
               WHERE zbsl.location_area_id=zbs.location_area_id
                 AND zbsl.base_station_id IS NULL
                  AND zbsl.msc_id IS NULL
                  AND zbsl.network_operator_id IS NULL)
  ORDER BY zbs.base_station_id,zbs.start_date;

  v_last_row            c_bs%ROWTYPE;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_bsc_list IS NULL OR 
     p_bsc_list.COUNT = 0 OR
     (p_bsc_list.COUNT = 1 AND p_bsc_list(p_bsc_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF; 
  -- set current start date when p_start_date is null
  v_start_date := nvl(p_start_date, SYSDATE);

 --------------------------------------------------------------------------------------------------------------------------
  IF v_start_date > p_end_date THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_INTERVAL, '');
  END IF;

  IF v_start_date < RSIG_UTILS.c_MIN_DATE
     OR (p_end_date < RSIG_UTILS.c_MIN_DATE AND p_end_date IS NOT NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;

  DELETE FROM tt_zone_base_station;

  -- fill input data to temporary table
   FOR i IN nvl(p_bsc_list.FIRST, 1) .. nvl(p_bsc_list.LAST, 0)
  loop 
    v_BSC_LAC_MSC_OBJ:=t_BSC_LAC_MSC_obj(p_bsc_list(i),NULL,NULL);
    v_BSC_LAC_MSC_list.extend; 
    v_BSC_LAC_MSC_list(i):=v_BSC_LAC_MSC_OBJ; 
  end loop;

  -- insert individual intervals for base stations -------------------------------------------------
  INSERT INTO tt_zone_base_station(zone_id,base_station_id,start_date,end_date)
  SELECT /*+ ORDERED USE_NL(tt bs zbs la) */
         zbs.zone_id,
         zbs.base_station_id,
         zbs.start_date,
         zbs.end_date
  from TABLE(CAST(v_BSC_LAC_MSC_list AS t_BSC_LAC_MSC_obj_tab))  tt
  join BASE_STATION bs on bs.BASE_STATION_CODE = tt.base_station_code
  join ZONE_BASE_STATION zbs on (zbs.BASE_STATION_ID = bs.BASE_STATION_ID
                                  AND zbs.msc_id IS NULL
                                  AND zbs.network_operator_id IS NULL)
  JOIN location_area la ON la.location_area_id=bs.location_area_id
  JOIN ZONE z ON z.zone_id = zbs.zone_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code = z.zone_type_code
  WHERE (bs.DELETED is NULL OR bs.deleted > v_start_date)
       AND (z.deleted IS NULL OR z.deleted > v_start_date)
       AND (zbs.end_date>=v_start_date OR zbs.end_date IS NULL)
       AND (zbs.start_date<=p_end_date OR p_end_date IS NULL)
       AND (zt.DELETED IS NULL OR zt.deleted > v_start_date);


  -- insert global intervals for location areas where does not exist individual interval -----------
  INSERT INTO tt_zone_base_station(zone_id,base_station_id,start_date,end_date)
  SELECT /*+ ORDERED USE_NL(tt bs zbs la) */
         zbs.zone_id,
         bs.base_station_id,
         zbs.start_date,
         zbs.end_date
  FROM TABLE(CAST(v_BSC_LAC_MSC_list AS t_BSC_LAC_MSC_obj_tab))  tt
  JOIN base_station bs ON bs.base_station_code=tt.base_station_code
  JOIN location_area la ON la.location_area_id=bs.location_area_id
  JOIN zone_base_station zbs ON (zbs.location_area_id=la.location_area_id
                                  AND zbs.msc_id IS NULL
                                  AND zbs.network_operator_id IS NULL)
  JOIN ZONE z ON z.zone_id = zbs.zone_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code = z.zone_type_code
  WHERE zbs.base_station_id IS NULL
    AND (la.DELETED is NULL OR la.deleted > v_start_date)
    AND (bs.DELETED is NULL OR bs.deleted > v_start_date)
    AND (z.deleted IS NULL OR z.deleted > v_start_date)
    AND (zbs.end_date>=v_start_date OR zbs.end_date IS NULL)
    AND (zbs.start_date<=p_end_date OR p_end_date IS NULL)
    AND (zt.DELETED IS NULL OR zt.deleted > v_start_date)
    AND NOT EXISTS(SELECT 1
                   FROM zone_base_station zbsl
                   WHERE zbsl.base_station_id=bs.base_station_id
                    AND zbsl.msc_id IS NULL
                    AND zbsl.network_operator_id IS NULL);


  -- merge individual and global intervals --------------------------------------------------------
  FOR v_row IN c_bs LOOP
    IF v_row.base_station_id<>v_last_row.base_station_id OR v_last_row.base_station_id IS NULL THEN
    -- first loop for the base station
      -- fill location area intervals at the begining
      Insert_LA_zone_intervals(p_location_area_id => v_row.location_area_id,
                                 p_base_station_id => v_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => v_start_date,
                                 p_end_date => v_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE);

      IF v_last_row.end_date IS NOT NULL AND (v_last_row.end_date<p_end_date OR p_end_date IS NULL) THEN
        -- fill location area intervals at the end
        Insert_LA_zone_intervals(p_location_area_id => v_last_row.location_area_id,
                                 p_base_station_id => v_last_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                                 p_end_date => p_end_date);

      END IF;

    ELSE
      IF v_last_row.end_date + rsig_utils.c_INTERVAL_DIFFERENCE <> v_row.start_date  THEN
        Insert_LA_zone_intervals(p_location_area_id => v_row.location_area_id,
                                 p_base_station_id => v_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                                 p_end_date => v_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE);
      END IF;
    END IF;

    v_last_row:=v_row;

  END LOOP;

  IF v_last_row.end_date IS NOT NULL AND (v_last_row.end_date<p_end_date OR p_end_date IS NULL) THEN
    -- last interval
    Insert_LA_zone_intervals(p_location_area_id => v_last_row.location_area_id,
                             p_base_station_id => v_last_row.base_station_id,
                             p_zone_type_id => v_last_row.zone_type_code,
                             p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                             p_end_date => p_end_date);
  END IF;
  --------------------------------------------------------------------------------------------------


  OPEN p_result FOR
  SELECT bs.base_station_code,
         z.zone_code,
         t.start_date,
         t.end_date
  FROM tt_zone_base_station t
  JOIN base_station bs ON t.base_station_id=bs.base_station_id
  JOIN ZONE z ON z.zone_id=t.zone_id
  ORDER BY bs.base_station_code,t.start_date;

--------------------------------------------------------------------------------------------------------------------------
  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN p_result FOR
      select error_code from dual;
END Get_Zone_Base_Station;

---------------------------------------------
--     PROCEDURE Get_Zone_Base_Station_All
---------------------------------------------

PROCEDURE Get_Zone_Base_Station_All
(
  ERROR_CODE           OUT NUMBER,
  p_result             OUT RSIG_UTILS.REF_CURSOR
)
IS
  v_event_source       VARCHAR2(60) := 'RSIG_ZONE_BASE_STATION.Get_Zone_Base_Station_All';

  -- all individual relations to zones where also exist global relation to zone
  CURSOR c_bs IS
  SELECT zbs.base_station_id,
         zbs.zone_id,
         zbs.location_area_id,
         zt.ZONE_TYPE_code,
         zbs.start_date,
         zbs.end_date
  FROM zone_base_station zbs
  JOIN zone_type zt ON zt.ZONE_TYPE_code = zbs.zone_type_code
  WHERE zbs.base_station_id IS NOT NULL
    AND zbs.msc_id IS NULL
    AND zbs.network_operator_id IS NULL
    AND EXISTS(SELECT 1
               FROM zone_base_station zbsl
               WHERE zbsl.location_area_id=zbs.location_area_id
                 AND zbsl.base_station_id IS NULL
                 AND zbsl.msc_id IS NULL
                 AND zbsl.network_operator_id IS NULL)
  ORDER BY zbs.base_station_id,zbs.start_date;


  v_last_row            c_bs%ROWTYPE;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);


  DELETE FROM tt_zone_base_station;

  -- insert individual intervals for base stations -------------------------------------------------
  INSERT INTO tt_zone_base_station(zone_id,base_station_id,start_date,end_date)
  SELECT zbs.zone_id,
         zbs.base_station_id,
         zbs.start_date,
         zbs.end_date
  FROM zone_base_station zbs
  WHERE zbs.base_station_id IS NOT NULL
      AND zbs.msc_id IS NULL
      AND zbs.network_operator_id IS NULL;

  -- insert global intervals for location areas where does not exist individual interval -----------
  INSERT INTO tt_zone_base_station(zone_id,base_station_id,start_date,end_date)
  SELECT zbs.zone_id,
         bs.base_station_id,
         zbs.start_date,
         zbs.end_date
  FROM zone_base_station zbs
  JOIN base_station bs ON bs.location_area_id=zbs.location_area_id
  WHERE zbs.base_station_id IS NULL
      AND zbs.msc_id IS NULL
      AND zbs.network_operator_id IS NULL
    AND NOT EXISTS(SELECT 1
                   FROM zone_base_station zbsl
                   WHERE zbsl.base_station_id=bs.base_station_id
                      AND zbsl.msc_id IS NULL
                      AND zbsl.network_operator_id IS NULL);



  -- merge individual and global intervals --------------------------------------------------------
  FOR v_row IN c_bs LOOP
    IF v_row.base_station_id<>v_last_row.base_station_id OR v_last_row.base_station_id IS NULL THEN
    -- first loop for the base station
      -- fill location area intervals at the begining
      Insert_LA_zone_intervals(p_location_area_id => v_row.location_area_id,
                                 p_base_station_id => v_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => NULL,
                                 p_end_date => v_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE);

      IF v_last_row.end_date IS NOT NULL THEN
        -- fill location area intervals at the end
        Insert_LA_zone_intervals(p_location_area_id => v_last_row.location_area_id,
                                 p_base_station_id => v_last_row.base_station_id,
                                 p_zone_type_id => v_last_row.zone_type_code,
                                 p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                                 p_end_date => NULL);

      END IF;

    ELSE
      IF v_last_row.end_date + rsig_utils.c_INTERVAL_DIFFERENCE <> v_row.start_date  THEN
        Insert_LA_zone_intervals(p_location_area_id => v_row.location_area_id,
                                 p_base_station_id => v_row.base_station_id,
                                 p_zone_type_id => v_last_row.zone_type_code,
                                 p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                                 p_end_date => v_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE);
      END IF;
    END IF;

    v_last_row:=v_row;

  END LOOP;

  IF v_last_row.end_date IS NOT NULL THEN
    -- last interval
    Insert_LA_zone_intervals(p_location_area_id => v_last_row.location_area_id,
                             p_base_station_id => v_last_row.base_station_id,
                             p_zone_type_id => v_last_row.zone_type_code,
                             p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                             p_end_date => NULL);
  END IF;
  --------------------------------------------------------------------------------------------------

  OPEN p_result FOR
  SELECT bs.base_station_code,
         z.zone_id,
         t.start_date,
         t.end_date,
         z.zone_code,
         la.location_area_code
  FROM tt_zone_base_station t
  JOIN base_station bs ON t.base_station_id=bs.base_station_id
  JOIN location_area la ON la.location_area_id=bs.location_area_id
  JOIN ZONE z ON z.zone_id=t.zone_id
  ORDER BY t.base_station_id,t.start_date;

  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN p_result FOR
      SELECT ERROR_CODE FROM dual;
END Get_Zone_Base_Station_All;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Zone_Base_Station_LAC
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Zone_Base_Station_LAC(
  p_msc_list               IN  t_MSC,
  p_bsc_list               IN  t_BSC,
  p_lac_list               IN  t_BSC,
  p_start_date             IN  DATE,
  p_end_date               IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60);
  v_package_name          VARCHAR2(30) := 'RSIG_ZONE_BASE_STATION';
  v_procedure_name        VARCHAR2(30) := 'Get_Zone_Base_Station_LAC';
  v_message               VARCHAR2(32767);
  v_start_date             DATE;

  -- all individual relations to zones where also exist global relation to zone
  CURSOR c_bs IS
  SELECT /*+ ORDERED USE_NL(tt bs zbs la) */
         zbs.base_station_id,
         zbs.zone_id,
         zbs.location_area_id,
         zt.zone_type_code,
         zbs.start_date,
         zbs.end_date
  FROM tt_batch_base_station tt
  JOIN base_station bs ON bs.base_station_code LIKE tt.base_station_code
       AND (bs.deleted IS NULL OR bs.deleted>v_start_date)
  JOIN location_area la ON la.location_area_id=bs.location_area_id
       AND (la.deleted IS NULL OR la.deleted>v_start_date)
  JOIN zone_base_station zbs ON (zbs.base_station_id=bs.base_station_id
                                  AND zbs.msc_id IS NULL
                                  AND zbs.network_operator_id IS NULL)
  JOIN host h ON h.host_id=la.host_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code = zbs.zone_type_code
  WHERE la.location_area_code=tt.location_area_code
    AND h.host_code=tt.msc_code
    AND (zbs.end_date>=v_start_date OR zbs.end_date IS NULL)
    AND (zbs.start_date<=p_end_date OR p_end_date IS NULL)
    AND (zt.DELETED IS NULL OR zt.deleted > v_start_date)
    AND EXISTS(SELECT 1
               FROM zone_base_station zbsl
               WHERE zbsl.location_area_id=zbs.location_area_id
                 AND zbsl.zone_type_code = zbs.zone_type_code
                 AND zbsl.base_station_id IS NULL
                 AND zbsl.msc_id IS NULL
                 AND zbsl.network_operator_id IS NULL)
  ORDER BY zbs.base_station_id,zbs.start_date;

  v_last_row            c_bs%ROWTYPE;
BEGIN
	v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:'
                || chr(10) ||'p_msc_listm ' || p_msc_list.COUNT
                || chr(10) ||'p_bsc_list ' || p_bsc_list.COUNT
	|| chr(10) ||'p_lac_list ' || p_lac_list.COUNT;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  IF p_bsc_list IS NULL OR 
     p_bsc_list.COUNT = 0 OR
     (p_bsc_list.COUNT = 1 AND p_bsc_list(p_bsc_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF; 

  IF p_lac_list IS NULL OR 
     p_lac_list.COUNT = 0 OR
     (p_lac_list.COUNT = 1 AND p_lac_list(p_lac_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF; 

  IF p_msc_list IS NULL OR 
     p_msc_list.COUNT = 0 OR
     (p_msc_list.COUNT = 1 AND p_msc_list(p_msc_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF; 

  IF p_bsc_list.COUNT <> p_lac_list.COUNT AND 
     p_bsc_list.COUNT <> p_msc_list.COUNT
  THEN
   RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  v_start_date := nvl(p_start_date, SYSDATE);

  IF v_start_date > p_end_date THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_INTERVAL, '');
  END IF;

-- start of the procedure body --------------------------------------------------------------------------------------------------

  DELETE FROM tt_batch_base_station;
  DELETE FROM tt_zone_base_station;

  -- fill input data to temporary table
  FORALL i IN nvl(p_bsc_list.FIRST, 1) .. nvl(p_bsc_list.LAST, 0)
  INSERT INTO tt_batch_base_station(base_station_code,location_area_code,MSC_CODE)
  VALUES(p_bsc_list(i),p_lac_list(i),p_msc_list(i));

  -- insert individual intervals for base stations -------------------------------------------------
  INSERT INTO tt_zone_base_station(zone_id,base_station_id,start_date,end_date,zone_type_id)
  SELECT /*+ ORDERED USE_NL(tt bs zbs la) */
         zbs.zone_id,
         zbs.base_station_id,
         zbs.start_date,
         zbs.end_date,
         zbs.zone_type_code
  from tt_batch_base_station tt
  join BASE_STATION bs on bs.BASE_STATION_CODE LIKE tt.base_station_code
  join ZONE_BASE_STATION zbs on (zbs.BASE_STATION_ID = bs.BASE_STATION_ID
                                 AND zbs.msc_id IS NULL
                                 AND zbs.network_operator_id IS NULL)
  JOIN location_area la ON la.location_area_id=bs.location_area_id
  JOIN ZONE z ON z.zone_id = zbs.zone_id
  JOIN host h ON h.host_id=la.host_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code = zbs.zone_type_code
  WHERE la.location_area_code=tt.location_area_code
       AND h.host_code=tt.msc_code
       AND (bs.DELETED is NULL OR bs.deleted > v_start_date)
       AND (z.deleted IS NULL OR z.deleted > v_start_date)
       AND (zt.DELETED IS NULL OR zt.deleted > v_start_date)
       AND (zbs.end_date>=v_start_date OR zbs.end_date IS NULL)
       AND (zbs.start_date<=p_end_date OR p_end_date IS NULL);

  -- insert global intervals for location areas where does not exist individual interval -----------
  INSERT INTO tt_zone_base_station(zone_id,base_station_id,start_date,end_date,zone_type_id)
  SELECT /*+ ORDERED USE_NL(tt bs zbs la) */
         zbs.zone_id,
         bs.base_station_id,
         zbs.start_date,
         zbs.end_date,
         zbs.zone_type_code
  FROM tt_batch_base_station tt
  JOIN location_area la ON la.location_area_code=tt.location_area_code
  JOIN zone_base_station zbs ON (zbs.location_area_id=la.location_area_id
                                 AND zbs.msc_id IS NULL
                                 AND zbs.network_operator_id IS NULL)
  JOIN base_station bs ON bs.base_station_code LIKE tt.base_station_code
        AND bs.location_area_id=la.location_area_id
  JOIN ZONE z ON z.zone_id = zbs.zone_id
  JOIN host h ON h.host_id=la.host_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code = zbs.zone_type_code
  WHERE zbs.base_station_id IS NULL
    AND h.host_code=tt.msc_code
    AND (la.DELETED is NULL OR la.deleted > v_start_date)
    AND (z.deleted IS NULL OR z.deleted > v_start_date)
    AND (zt.DELETED IS NULL OR zt.deleted > v_start_date)
    AND (bs.deleted IS NULL OR bs.deleted > v_start_date)
    AND (zbs.end_date>=v_start_date OR zbs.end_date IS NULL)
    AND (zbs.start_date<=p_end_date OR p_end_date IS NULL)
    AND NOT EXISTS(SELECT 1
                   FROM zone_base_station zbsl
                   WHERE zbsl.base_station_id=bs.base_station_id
                     AND zbsl.zone_type_code = zbs.zone_type_code
                     AND (zbsl.end_date>=v_start_date OR zbsl.end_date IS NULL)
                     AND (zbsl.start_date<=p_end_date OR p_end_date IS NULL)
                     AND zbsl.msc_id IS NULL
                     AND zbsl.network_operator_id IS NULL);

  -- merge individual and global intervals --------------------------------------------------------
  FOR v_row IN c_bs LOOP
    IF v_row.base_station_id<>v_last_row.base_station_id OR v_last_row.base_station_id IS NULL THEN
    -- first loop for the base station
      -- fill location area intervals at the begining
      Insert_LA_zone_intervals(p_location_area_id => v_row.location_area_id,
                                 p_base_station_id => v_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => v_start_date,
                                 p_end_date => v_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE);

      IF v_last_row.end_date IS NOT NULL AND (v_last_row.end_date<p_end_date OR p_end_date IS NULL) THEN
        -- fill location area intervals at the end
        Insert_LA_zone_intervals(p_location_area_id => v_last_row.location_area_id,
                                 p_base_station_id => v_last_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                                 p_end_date => p_end_date);

      END IF;

    ELSE
      IF v_last_row.end_date + rsig_utils.c_INTERVAL_DIFFERENCE <> v_row.start_date  THEN
        Insert_LA_zone_intervals(p_location_area_id => v_row.location_area_id,
                                 p_base_station_id => v_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                                 p_end_date => v_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE);
      END IF;
    END IF;

    v_last_row:=v_row;

  END LOOP;

  IF v_last_row.end_date IS NOT NULL AND (v_last_row.end_date<p_end_date OR p_end_date IS NULL) THEN
    -- last interval
    Insert_LA_zone_intervals(p_location_area_id => v_last_row.location_area_id,
                             p_base_station_id => v_last_row.base_station_id,
                             p_zone_type_id => v_last_row.zone_type_code,
                             p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                             p_end_date => p_end_date);
  END IF;
  --------------------------------------------------------------------------------------------------


  OPEN result_list FOR
  SELECT h.host_code,
         la.location_area_code,
         bs.base_station_code,
         z.zone_code,
         zt.ZONE_TYPE_CODE,
         t.start_date,
         t.end_date
  FROM tt_zone_base_station t
  JOIN base_station bs ON t.base_station_id=bs.base_station_id
  JOIN location_area la ON la.location_area_id=bs.location_area_id
  JOIN ZONE z ON z.zone_id=t.zone_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code = t.zone_type_id
  JOIN host h ON h.host_id=la.host_id
  ORDER BY bs.base_station_code,t.start_date;


-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  p_error_code := RSIG_UTILS.c_OK;
-- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
  p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
  p_error_message := SQLERRM;
	 OPEN result_list FOR SELECT v_sqlcode,p_error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Zone_Base_Station_LAC;


-------------------------------------------------------------------------------------------------------
-- Insert_LA_zone_intervals
-------------------------------------------------------------------------------------------------------
PROCEDURE Insert_LA_zone_intervals(
  p_location_area_id    IN  location_area.location_area_id%TYPE,
  p_base_station_id     IN  base_station.base_station_id%TYPE,
  p_zone_type_id        IN  zone_type.ZONE_TYPE_code%TYPE,
  p_start_date          IN  DATE,
  p_end_date            IN  DATE
)
IS
BEGIN
INSERT INTO tt_zone_base_station(zone_id,base_station_id,start_date,end_date,zone_type_id)
  SELECT *
  FROM(SELECT zbs.zone_id,
              p_base_station_id base_station_id,
              CASE WHEN zbs.start_date<p_start_date THEN
                p_start_date ELSE zbs.start_date
              END start_date,
              CASE WHEN zbs.end_date>=p_end_date OR (p_end_date IS NOT NULL AND zbs.end_date IS NULL) THEN
                p_end_date ELSE zbs.end_date
              END end_date,
              zbs.zone_type_code
       FROM Zone_Base_Station zbs
       JOIN zone_type zt ON zt.ZONE_TYPE_code = zbs.zone_type_code
       WHERE zbs.location_area_id=p_location_area_id
         AND zt.zone_type_code = p_zone_type_id
         AND zbs.base_station_id IS NULL
         AND (zbs.end_date>=p_start_date OR zbs.end_date IS NULL OR p_start_date IS NULL)
         AND (zbs.start_date<=p_end_date OR p_end_date IS NULL)
         AND zbs.msc_id IS NULL
         AND zbs.network_operator_id IS NULL) l
  WHERE (l.end_date>l.start_date OR l.end_date IS NULL);

END Insert_LA_zone_intervals;

END RSIG_ZONE_BASE_STATION;
/
