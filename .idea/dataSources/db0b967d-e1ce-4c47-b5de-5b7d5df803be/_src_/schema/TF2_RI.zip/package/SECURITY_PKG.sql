CREATE PACKAGE SECURITY_PKG IS

  c_user_profile_id_empty        constant number := 0;

  c_ext_user_type_COMMON         constant number := 0;
  c_user_profile_id_COMMON       constant number := 0;

----------------------------------!---------------------------------------------
  type ctl_users is table of users%rowtype;

  type rt_user_info is record
  (
    user_name nvarchar2(2000),
    user_profile_id number,
    person_name nvarchar2(2000)
  );

  type ctl_user_info is table of rt_user_info;

----------------------------------!---------------------------------------------
  function get_user_names_i
  (
    p_date date,
    p_to_upper boolean,
    p_active boolean
  ) return ct_nvarchar;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function get_user_i
  (
    p_user_id users.user_id%type
  ) return ctl_users;

  function get_users_id_i
  (
    p_login_name ct_nvarchar
  ) return ct_number;

----------------------------------!---------------------------------------------
  function users_ins_ii
  (
      p_user_name users.login_name%type,
      p_name users.user_name%type
  ) return users.user_id%type;

  procedure users_upd_ii
  (
      p_user_id users.user_id%type,
      p_name users.user_name%type
  );

----------------------------------!---------------------------------------------
  procedure users_insert_i
  (
    p_execute_user_id number,
    p_user_name nvarchar2,
    p_user_profile_id number,
    p_name nvarchar2
  );

  procedure users_update_i
  (
    p_execute_user_id number,
    p_user_id number,
    p_user_profile_id number,
    p_name nvarchar2
  );

  procedure users_update_is_active_i
  (
    p_execute_user_id number,
    p_user_id number,
    p_is_active number
  );

----------------------------------!---------------------------------------------
  function make_as_null_user_profile_id(p_user_profile_id number) return number;

----------------------------------!---------------------------------------------
  function get_user_profile_id_common return number;

----------------------------------!---------------------------------------------
  function get_count_ctl_users(p_coll ctl_users) return number;

  function get_count_ctl_user_info(p_coll ctl_user_info) return number;

  function get_user
  (
    p_user_id number
  ) return ctl_users;

  function get_ctl_user_info(p_pivot_filter ct_number, p_map1 ct_number, p_map2 ct_number, p_user_types ct_number, p_user_names ct_nvarchar, p_person_names ct_nvarchar) return ctl_user_info;

  procedure filter_users(p_filter_type number, p_types ct_number, p_vals ct_nvarchar, p_pivot out ct_number, p_vals_out out ct_nvarchar);

  function get_utypes_i return ct_number;

  function get_profile_ids_i return ct_number;

  procedure prepare_users_i
  (
    p_user_types ct_number,
    p_user_names ct_nvarchar,
    p_map1 out ct_number,
    p_map2 out ct_number,
    p_unames_uni_other out ct_nvarchar,
    p_pivot_other out ct_number
  );

----------------------------------!---------------------------------------------
  procedure synchronize_users_i
  (
    p_execute_user_id users.user_id%type,
    p_user_types ct_number,
    p_user_names ct_nvarchar,
    p_person_names ct_nvarchar,
    p_new_users_pivot out ct_number,
    p_upd_users_pivot out ct_number,
    p_multiple_err_users_pivot out ct_number
  );

  PROCEDURE Synchronize_Users
  (
    p_execute_user varchar2,
    p_login_names util_pkg.cit_nvarchar,
    p_user_names util_pkg.cit_nvarchar,
    p_added out sys_refcursor,
    p_updated out sys_refcursor,
    p_errors out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure get_result_cursor001(p_user_ids ct_number, p_login_names ct_nvarchar, p_user_names ct_nvarchar, p_result out sys_refcursor);
  procedure get_err_result_cursor001(p_login_names ct_nvarchar, p_user_names ct_nvarchar, p_result out sys_refcursor);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

END;
/
