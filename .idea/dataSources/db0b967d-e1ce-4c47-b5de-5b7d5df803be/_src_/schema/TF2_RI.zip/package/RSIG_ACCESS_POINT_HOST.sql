CREATE PACKAGE RSIG_ACCESS_POINT_HOST IS
  /****************************************************************************
  <header>
    <name>            package RSIG_ACCESS_POINT_HOST
    </name>

    <author>          Radek Hejduk - GITUS
    </author>

    <version>         1.2.5    25.12.2008     Denis Kovalchuk
                      procedure Get_AP_Relations updated
    </version>

    <version>         1.2.4    15.11.2006     Petr Cepek
                      procedure Is_Access_Point_Deleted updated
    </version>

    <version>         1.2.4    15.11.2006     Petr Cepek
                      procedure Is_Access_Point_Deleted updated
    </version>
    <version>         1.2.3    28.08.2006     Petr Cepek
                      procedure Insert_Interval updated
    </version>
    <version>         1.2.2    13.06.2006    Petr Cepek
                      procedure Insert_Interval updated
    </version>
    <version>         1.2.1    10.04.2006    Petr Cepek
                      procedure Get_Host_Relations updated
    </version>
    <version>         1.2.0    29.03.2006    Petr Cepek
                      procedures Get_AP_Relations, Get_Host_Relations created
                      procedure Get_history removed
    </version>
    <version>         1.1.18   29.3.2005     Martin Zabka
					            procedure Get_history added
    </version>
    <version>         1.1.17   28.3.2005     Jaroslav holub
					            fixed procedure Insert_Interval
    </version>
    <version>         1.1.16   14.09.2004     Lucie Sevcikova
                      Procedure Is_Interval_Overlap was changed. One access
                      point can have relation to several hosts at once,
                      but these hosts have to be of different types.
    </version>

    <version>         1.1.15   14.09.2004     Jaroslav Holub
                      Close_Interval -  for diference of time on server and
                      client, p_end_date should be NULL, and it mean sysdate
    </version>
    <version>         1.1.14  03.08.2004     Jaroslav Holub
                      Insert_Interval - for diference of time on server and
                      client, p_start_date should be NULL, and it mean sysdate
    </version>
    <version>     1.1.13  15.12.2003      jstodulk
                          Insert debug constant.
    </version>
    <version>     1.1.12  15.12.2003      jstodulk
                            Insert parameter RSIG_UTILS.c_MIN_DATE.
    </version>
    <version>     1.1.11  5.12.2003       prybicka
                            added parameter p_start_date
    </version>
    <version>     1.1.10  5.12.2003       prybicka
                            added p_start_date parameter in Close_Interval
    </version>
    <version>     1.0.1   10.9.2003     Radek Hejduk
                              created first version
    </version>

    <Description>       Package contains procedure for managing relations of
                        access point to hosts.
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource inventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
  ****************************************************************************/
  /****************************************************************************
  <header>
    <name>              procedure Insert_Interval
    </name>

    <author>            Radek Hejduk - GITUS
    </author>

    <version>           1.0.4   28.08.2006     Petr Cepek
                        exchange ports excluded from checking of their relation
                        to host
    </version>
    <version>           1.0.3   13.06.2006     Cepek Petr
                        condition added: Relation to host can be created only
                        for those types, which are already set for all series
    </version>
    <version>           1.0.2   03.08.2004     Jaroslav Holub
                        for diference of time on server and client, p_start_date should be NULL, and it mean sysdate
    </version>
    <version>           1.0.1   10.9.2003     Radek Hejduk
                                  created first version
    </version>

    <Description>       Procedure first checks,  whether interval, that starts
                        with given start date, is overlapped with any existing
                        interval or not. If it is overlapped, procedure ends with
                        error c_DATE_OVERLAP.
                        If check passed successfully,  procedure inserts interval
                        given by access point id and host id.

    </Description>

    <Prerequisites>     PROCEDURE Debug_Rsi (
                          p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                          p_level         NUMBER,                       -- level of debuging
                          p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                          p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                        );
                        FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                        Exists variable:
                          RSIG_UTILS.c_DEBUG_LEVEL_0
                          RSIG_UTILS.c_DEBUG_LEVEL_1
                          RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                          RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                          RSIG_UTILS.c_DEBUG_TEXT_START
                          RSIG_UTILS.c_DEBUG_TEXT_END
                          RSIG_UTILS.c_MIN_DATE
    </Prerequisites>

    <Application>       Resource inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                    allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                     RSIG_UTILS.c_HANDLE_TRAN_Y
                                                     RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code - OUT - NUMBER
                        p_access_point_id - IN - value for ACCESS_POINT_ID
                        p_host_id - IN - value for HOST_ID
                        p_start_date - IN - value for START_DATE
                        p_end_date - IN - value for START_DATE
                        p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
    </Parameters>

  </header>
  ****************************************************************************/
  PROCEDURE Insert_Interval
  (
    handle_tran         CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code          OUT NUMBER,
    p_access_point_id   IN ACCESS_POINT_HOST.ACCESS_POINT_ID%TYPE,
    p_host_id           IN ACCESS_POINT_HOST.HOST_ID%TYPE,
    p_start_date        IN ACCESS_POINT_HOST.START_DATE%TYPE,
    p_end_date          IN ACCESS_POINT_HOST.END_DATE%TYPE DEFAULT NULL,
    p_user_id_of_change IN ACCESS_POINT_HOST.USER_ID_OF_CHANGE%TYPE
  );
  /****************************************************************************
  <header>
    <name>              procedure Close_Interval
    </name>

    <author>            Radek Hejduk - GITUS
    </author>

    <version>           1.0.3   14.09.2004     Jaroslav Holub
                   for diference of time on server and client,
                   p_end_date should be NULL, and it mean sysdate
    </version>
    <version>           1.0.2   5.12.2003     Pavel Rybicka
                                p_start_date added
    </version>
    <version>           1.0.1   10.9.2003     Radek Hejduk
                                created first version
    </version>

    <Description>       Procedure first checks,  whether the end date of the interval
                        being closed is null or not. If it is not null, the procedure
                        ends with error c_DELETED.
                        Further procedure checks,  whether p_end_date is greater
                        then start_date of given interval. If it is not greater, the procedure
                        ends with error c_DATE_OVERLAP.
                        If all checks passed successfully, then procedure sets end_date
                        of given interval to value given by p_end_date parameter.

    </Description>

    <Prerequisites>     PROCEDURE Debug_Rsi (
                          p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                          p_level         NUMBER,                       -- level of debuging
                          p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                          p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                        );
                        FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                        Exists variable:
                          RSIG_UTILS.c_DEBUG_LEVEL_0
                          RSIG_UTILS.c_DEBUG_LEVEL_1
                          RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                          RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                          RSIG_UTILS.c_DEBUG_TEXT_START
                          RSIG_UTILS.c_DEBUG_TEXT_END
                          RSIG_UTILS.c_MIN_DATE
    </Prerequisites>

    <Application>       Resource inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                    allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                     RSIG_UTILS.c_HANDLE_TRAN_Y
                                                     RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code - OUT - NUMBER
                        p_access_point_id - IN - value for identification updating row (ACCESS_POINT_ID)
                        p_host_id - IN - value for identification updating row (HOST_ID)
                        p_end_date - IN - value for set of the end (END_DATE)
                        p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
    </Parameters>

  </header>
  ****************************************************************************/
  PROCEDURE Close_Interval
  (
    handle_tran         CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code          OUT NUMBER,
    p_start_date        IN ACCESS_POINT_HOST.START_DATE%TYPE,
    p_access_point_id   IN ACCESS_POINT_HOST.ACCESS_POINT_ID%TYPE,
    p_host_id           IN ACCESS_POINT_HOST.HOST_ID%TYPE,
    p_end_date          IN ACCESS_POINT_HOST.END_DATE%TYPE,
    p_user_id_of_change IN ACCESS_POINT_HOST.USER_ID_OF_CHANGE%TYPE
  );

  PROCEDURE Is_Interval_Overlap
  (
    p_access_point_id IN ACCESS_POINT_HOST.ACCESS_POINT_ID%TYPE,
    p_host_id         IN HOST.HOST_ID%TYPE,
    p_start_date      IN ACCESS_POINT_HOST.START_DATE%TYPE DEFAULT NULL,
    p_end_date        IN ACCESS_POINT_HOST.END_DATE%TYPE DEFAULT NULL
  );

/****************************************************************************
<header>
  <name>            procedure Get_Host_Relations
  </name>

  <author>          Petr Cepek
  </author>

  <version>         1.1  10.04.2006    Petr Cepek
                    new table sim_card_host considered in procedure
  </version>
  <version>
                    1.0  14.3.2006  -  created
  </version>

  <Description>     Procedure return list of assigned ports
                    and sim cards to given host.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Host_Relations(
  p_host_id                IN  host.host_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure Get_AP_Relations
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.1  25.12.2008  -  Updated: instead of join with USERS
		    table used new function get_user_name
  </version>

  <version>
                    1.0  14.3.2006  -  created
  </version>

  <Description>     Procedure return list of assigned hosts
                    to given access point.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_AP_Relations(
  p_access_point_id        IN  access_point.access_point_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

END;
/
