CREATE PACKAGE          "RSIG_HOST_TYPE" IS
/****************************************************************************
<header>
  <name>             	packager RSIG_HOST_TYPE
  </name>

  <author>           	Jan Stodulka - GITUS
  </author>

  <version>           1.0.4     21.11.2006    Petr Cepek
                      procedure Insert_Host_Type deleted
                      procedure Update_Host_Type deleted
                      procedure Delete_Host_Type deleted
  </version>
  <version>				    1.0.3	    3.8.2004     Jaroslav Holub
								      Delete_Host_Type - fixed for time difference between client and server,
								      date should be null and it means sysdate
  </version>

  <version>          	1.0.2	24.5.2004    	Martin Zabka
                              	Get_Host_Type - only not deleted types are returned now
  </version>
  <version>          	1.0.1	15.9.2003    	jan Stodulka
                              	created fisrts version
  </version>

  <Description>         Package contains procedure for managing host types.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/


/****************************************************************************
  <header>
    <name>              procedure Get_Host_Type
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.0.2   24.5.2004     Martin Zabka
                                only not deleted types are returned now
    </version>
    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure for getting all host types.
                        Ref cursor contains columns: HOST_TYPE_CODE,
                        HOST_TYPE_NAME and DELETED

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code      - Error code
                        p_cur_host_type - cursor to retrieve all host types
                                          (HOST_TYPE_CODE, HOST_TYPE_NAME)
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Get_Host_Type(
    error_code          OUT  NUMBER,
    p_cur_host_type     OUT  RSIG_UTILS.REF_CURSOR
  );

END RSIG_HOST_TYPE;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_HOST_TYPE.pkg,v 1.15 2003/12/15 09:02:36 jstodulk Exp $

/
