CREATE PACKAGE BODY          "RSIG_COMPARE" IS

  /*    \****************************************************************************
    <header>
      <name>              procedure Get_tables_metadata
      </name>
  
      <author>            Jaroslav Holub
      </author>
  
      <version>           1.0.0   ??.6.2004  Jaroslav Holub
                                  created first version
      </version>
  
      <Description>       procedure ...
  
      </Description>
  
      <Prerequisites>
      </Prerequisites>
  
      <Application>       FORIS Resource inventory
      </Application>
  
      <Parameters>
                          ,
                          handle_tran       IN  CHAR,
                          p_raise_error     IN  CHAR,
                          error_code        OUT NUMBER,
                          error_message     OUT VARCHAR2
      </Parameters>
  
    </header>
  ****************************************************************************\
  
  ----------------------------------------------------------------------------
  --  Get_tables_metadata
  ----------------------------------------------------------------------------
  
  \****************************************************************************
    <header>
      <name>              procedure Get_PK_Collumns
      </name>
  
      <author>            Jaroslav Holub
      </author>
  
      <version>           1.0.0   ??.6.2004  Jaroslav Holub
                                  created first version
      </version>
  
      <Description>       procedure ...
  
      </Description>
  
      <Prerequisites>
      </Prerequisites>
  
      <Application>       FORIS Resource inventory
      </Application>
  
      <Parameters>
                          ,
                          handle_tran       IN  CHAR,
                          p_raise_error     IN  CHAR,
                          error_code        OUT NUMBER,
                          error_message     OUT VARCHAR2
      </Parameters>
  
    </header>
  ****************************************************************************\
  
  ----------------------------------------------------------------------------
  --  Get_PK_Collumns
  ----------------------------------------------------------------------------
  
  PROCEDURE Get_PK_Collumns(
                            
                            handle_tran   IN CHAR,
                            p_raise_error IN CHAR,
                            ERROR_CODE    OUT NUMBER,
                            error_message OUT VARCHAR2) IS
    v_sqlcode NUMBER;
  BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_PK_Collumns');
    -- check handle_tran parameter
    IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,
                              'Invalid HANDLE_TRAN parameter!');
    END IF;
  
    \* IF test input parameters THEN 
       RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
     END IF;
    *\
  
    -- set savepoint
    IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
      SAVEPOINT Get_PK_Collumns;
    END IF;
  
    -- procedure body here
  
    -- commit
    IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
      COMMIT;
    END IF;
  
    -- set error code to succesfully completed
    ERROR_CODE := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_PK_Collumns');
  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --   DBMS_OUTPUT.PUT_LINE(error_message);
      ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           'Get_PK_Collumns');
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT Get_PK_Collumns;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
      IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
        RAISE;
      END IF;
  END Get_PK_Collumns;
  
  \****************************************************************************
    <header>
      <name>              procedure Get_tables_FK_conected
      </name>
  
      <author>            Jaroslav Holub
      </author>
  
      <version>           1.0.0   ??.6.2004  Jaroslav Holub
                                  created first version
      </version>
  
      <Description>       procedure ...
  
      </Description>
  
      <Prerequisites>
      </Prerequisites>
  
      <Application>       FORIS Resource inventory
      </Application>
  
      <Parameters>
                          ,
                          handle_tran       IN  CHAR,
                          p_raise_error     IN  CHAR,
                          error_code        OUT NUMBER,
                          error_message     OUT VARCHAR2
      </Parameters>
  
    </header>
  ****************************************************************************\
  
  ----------------------------------------------------------------------------
  --  Get_tables_FK_conected
  ----------------------------------------------------------------------------
  
  PROCEDURE Get_tables_FK_conected(
                                   
                                   handle_tran   IN CHAR,
                                   p_raise_error IN CHAR,
                                   ERROR_CODE    OUT NUMBER,
                                   error_message OUT VARCHAR2) IS
    v_sqlcode NUMBER;
  BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_tables_FK_conected');
    -- check handle_tran parameter
    IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,
                              'Invalid HANDLE_TRAN parameter!');
    END IF;
  
    \* IF test input parameters THEN 
       RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
     END IF;
    *\
  
    -- set savepoint
    IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
      SAVEPOINT Get_tables_FK_conected;
    END IF;
  
    -- procedure body here
  
    -- commit
    IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
      COMMIT;
    END IF;
  
    -- set error code to succesfully completed
    ERROR_CODE := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_tables_FK_conected');
  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --   DBMS_OUTPUT.PUT_LINE(error_message);
      ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           'Get_tables_FK_conected');
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT Get_tables_FK_conected;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
      IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
        RAISE;
      END IF;
  END Get_tables_FK_conected;
  
  \****************************************************************************
    <header>
      <name>              procedure Get_collumns
      </name>
  
      <author>            Jaroslav Holub
      </author>
  
      <version>           1.0.0   ??.6.2004  Jaroslav Holub
                                  created first version
      </version>
  
      <Description>       procedure ...
  
      </Description>
  
      <Prerequisites>
      </Prerequisites>
  
      <Application>       FORIS Resource inventory
      </Application>
  
      <Parameters>
                          ,
                          handle_tran       IN  CHAR,
                          p_raise_error     IN  CHAR,
                          error_code        OUT NUMBER,
                          error_message     OUT VARCHAR2
      </Parameters>
  
    </header>
  ****************************************************************************\
  
  ----------------------------------------------------------------------------
  --  Get_collumns
  ----------------------------------------------------------------------------
  
  PROCEDURE Get_collumns(
                         
                         handle_tran   IN CHAR,
                         p_raise_error IN CHAR,
                         ERROR_CODE    OUT NUMBER,
                         error_message OUT VARCHAR2) IS
    v_sqlcode NUMBER;
  BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_collumns');
    -- check handle_tran parameter
    IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,
                              'Invalid HANDLE_TRAN parameter!');
    END IF;
  
    \* IF test input parameters THEN 
       RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
     END IF;
    *\
  
    -- set savepoint
    IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
      SAVEPOINT Get_collumns;
    END IF;
  
    -- procedure body here
  
    -- commit
    IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
      COMMIT;
    END IF;
  
    -- set error code to succesfully completed
    ERROR_CODE := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_collumns');
  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --   DBMS_OUTPUT.PUT_LINE(error_message);
      ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           'Get_collumns');
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT Get_collumns;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
      IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
        RAISE;
      END IF;
  END Get_collumns;
  
  
   
  
  
  \****************************************************************************
    <header>
      <name>              procedure Compare_tables_in_schema
      </name>
  
      <author>            Jaroslav Holub
      </author>
  
      <version>           1.0.0   ??.6.2004  Jaroslav Holub
                                  created first version
      </version>
  
      <Description>       procedure ...
  
      </Description>
  
      <Prerequisites>
      </Prerequisites>
  
      <Application>       FORIS Resource inventory
      </Application>
  
      <Parameters>
                          ,
                          handle_tran       IN  CHAR,
                          p_raise_error     IN  CHAR,
                          error_code        OUT NUMBER,
                          error_message     OUT VARCHAR2
      </Parameters>
  
    </header>
  ****************************************************************************\
  
  ----------------------------------------------------------------------------
  --  Compare_tables_in_schema
  ----------------------------------------------------------------------------
  
  PROCEDURE Compare_tables_in_schema
  (
    p_db_link     IN VARCHAR2,
    p_raise_error IN CHAR,
    ERROR_CODE    OUT NUMBER,
    error_message OUT VARCHAR2,
    result_list   OUT sys_refcursor
  ) IS
    v_sqlcode    NUMBER;
    v_sql_string VARCHAR2(4000);
  
  BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Compare_tables_in_schema');
    -- check handle_tran parameter
    IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,
                              'Invalid HANDLE_TRAN parameter!');
    END IF;
  
    IF p_db_link IS NULL THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER,
                              'Invalid input parameter');
    END IF;
  
    FOR c_s IN 
        (SELECT ut.TABLE_NAME 
        FROM USER_TABLES ut
        JOIN USER_TAB_COLS utc ON utc.TABLE_NAME = ut.TABLE_NAME 
            
        ORDER BY ut.TABLE_NAME)
    LOOP 
         FOR c_columns IN SELECT ut.
  
      SELECT  
    *\
  
    -- set savepoint
    IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
      SAVEPOINT Compare_tables_in_schema;
    END IF;
  
    -- procedure body here
  
    -- commit
    IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
      COMMIT;
    END IF;
  
    -- set error code to succesfully completed
    ERROR_CODE := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Compare_tables_in_schema');
  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --   DBMS_OUTPUT.PUT_LINE(error_message);
      ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           'Compare_tables_in_schema');
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT Compare_tables_in_schema;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
      IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
        RAISE;
      END IF;
  END Compare_tables_in_schema;*/

  /****************************************************************************
    <header>
      <name>              procedure LIST_DB_CHANGES
      </name>
  
      <author>            Jaroslav Holub
      </author>
  
      <version>           1.0.0   ??.6.2004 Jaroslav Holub
                                  created first version
      </version>
  
      <Description>       procedure ...
  
      </Description>
  
      <Prerequisites>
      </Prerequisites>
  
      <Application>       FORIS Resource inventory
      </Application>
  
      <Parameters>
                          ,
                          handle_tran       IN  CHAR,
                          p_raise_error     IN  CHAR,
                          error_code        OUT NUMBER,
                          error_message     OUT VARCHAR2
      </Parameters>
  
    </header>
  ****************************************************************************/

  ----------------------------------------------------------------------------
  --  LIST_DB_CHANGES
  ----------------------------------------------------------------------------

  PROCEDURE LIST_DB_CHANGES
  (
    p_db_link     IN VARCHAR2,
    p_raise_error IN CHAR,
    ERROR_CODE    OUT NUMBER,
    error_message OUT VARCHAR2,
    RESULT        OUT CLOB
  ) IS
    v_sqlcode NUMBER;
  BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'LIST_DB_CHANGES');
    -- check handle_tran parameter
  
    /*  IF test input parameters THEN 
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
      END IF;
    */
    /*
    SELECT 
           
           access_point, 
           
    
    
    access_point_host, 
    access_point_status, 
    access_point_status_history, 
    account_card, 
    account_card_serie, 
    account_card_type, 
    base_station, 
    channel, 
    channel_direction, 
    channel_group, 
    channel_type, 
    --db_parameters, 
    --db_version, 
    exchange, 
    exchange_kind, 
    exchange_port, 
    exchange_port_type, 
    exchange_type, 
    exchange_usage_type, 
    host, 
    host_type, 
    ip_address, 
    ip_address_serie, 
    ip_serie_operator, 
    location_area, 
    login_info, 
    network_address, 
    network_address_access_point, 
    network_address_counter_hist, 
    network_address_status, 
    network_address_status_history, 
    network_operator, 
    network_operator_type, 
    net_addr_acc_point_link_type, 
    net_addr_status_allow_changes, 
    payment_entrance, 
    pay_desk, 
    personal_account, 
    phone_number, 
    phone_number_salability_categ, 
    phone_number_series, 
    phone_number_type, 
    phone_operator, 
    phone_salability_category, 
    phone_series_operator, 
    prefix_replacement, 
    signaling_type, 
    sim_card, 
    sim_card_type, 
    sim_series, 
    sim_series_status, 
    sim_series_status_validity, 
    stats_host, 
    synchronization_history, 
    users, 
    zone, 
    zone_base_station
      
      */
  
    -- procedure body here
  
    -- commit
    -- set error code to succesfully completed
    ERROR_CODE := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'LIST_DB_CHANGES');
  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --    DBMS_OUTPUT.PUT_LINE(error_message);
      ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           'LIST_DB_CHANGES');
      IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
        RAISE;
      END IF;
  END LIST_DB_CHANGES;

  /***************************************************************************
    <header>
      <name>              procedure Get_minus_select
      </name>
  
      <author>            Jaroslav Holub
      </author>
  
      <version>           1.0.0   ??.6.2004 Jaroslav Holub
                                  created first version
      </version>
  
      <Description>       procedure ...
  
      </Description>
  
      <Prerequisites>
      </Prerequisites>
  
      <Application>       FORIS Resource inventory
      </Application>
  
      <Parameters>
                          a char, bchar,
                          handle_tran       IN  CHAR,
                          p_raise_error     IN  CHAR,
                          error_code        OUT NUMBER,
                          error_message     OUT VARCHAR2
      </Parameters>
  
    </header>
  ***************************************************************************/

  ----------------------------------------------------------------------------
  --  Get_minus_select
  ----------------------------------------------------------------------------

  PROCEDURE Get_minus_select
  (
    p_select_local  IN VARCHAR2,
    p_select_remote IN VARCHAR2,
    p_db_link       IN VARCHAR2,
    p_raise_error   IN CHAR,
    ERROR_CODE      OUT NUMBER,
    error_message   OUT VARCHAR2,
    result_list     OUT sys_refcursor
  ) IS
    v_sqlcode NUMBER;
    v_sql     VARCHAR2(32000);
    v_select1 VARCHAR2(32000);
    v_select2 VARCHAR2(32000);
    v_db_link VARCHAR2(300);
  BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_minus_select');
    -- check handle_tran parameter
  
    /*  IF test input parameters THEN 
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
      END IF;
    */
  
    v_select1 := TRIM(upper(p_select_local));
    v_select1 := REPLACE(v_select1,
                         'SELECT ',
                         '');
    v_select2 := TRIM(upper(p_select_remote));
    v_select2 := REPLACE(v_select2,
                         'SELECT ',
                         '');
    IF p_db_link IS NOT NULL THEN
      v_db_link := '@' || TRIM(p_db_link);
    ELSE
      v_db_link := NULL;
    END IF;
    v_sql := '(SELECT ''1'' ACTION,' || v_select1 || ' MINUS SELECT ''1'' ACTION,' || v_select2 || v_db_link || ' )' ||
             'UNION ALL (SELECT ''2'' ACTION,' || v_select2 || v_db_link || ' MINUS SELECT ''2'' ACTION,' || v_select1 || ')';
  
    OPEN result_list FOR v_sql;
    -- set error code to succesfully completed
    ERROR_CODE := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_minus_select');
  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --    DBMS_OUTPUT.PUT_LINE(error_message);
      ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           'Get_minus_select');
    
      IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
        RAISE;
      END IF;
  END Get_minus_select;

  /****************************************************************************
    <header>
      <name>              procedure Get_all_columns
      </name>
  
      <author>            Jaroslav Holub
      </author>
  
      <version>           1.0.0   ??.6.2004 Jaroslav Holub
                                  created first version
      </version>
  
      <Description>       procedure ...
  
      </Description>
  
      <Prerequisites>
      </Prerequisites>
  
      <Application>       FORIS Resource inventory
      </Application>
  
      <Parameters>
                          ,
                          handle_tran       IN  CHAR,
                          p_raise_error     IN  CHAR,
                          error_code        OUT NUMBER,
                          error_message     OUT VARCHAR2
      </Parameters>
  
    </header>
  ****************************************************************************/

  ----------------------------------------------------------------------------
  --  Get_all_columns
  ----------------------------------------------------------------------------

  PROCEDURE Get_all_columns
  (
    p_table_name  IN VARCHAR2,
    p_db_link     IN VARCHAR2,
    p_raise_error IN CHAR,
    ERROR_CODE    OUT NUMBER,
    error_message OUT VARCHAR2,
    result_list   OUT sys_refcursor
  ) IS
    v_sqlcode NUMBER;
    v_db_link VARCHAR2(50);
    v_sql     VARCHAR2(32000);
  BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_all_columns');
    -- check handle_tran parameter
  
    IF p_db_link IS NOT NULL
       AND instr(p_db_link,
                 '@') = 0 THEN
      v_db_link := '@' || TRIM(p_db_link);
    ELSE
      v_db_link := NULL;
    END IF;
  
    -- procedure body here
    v_sql := 'SELECT utc.COLUMN_NAME, utc.DATA_TYPE FROM USER_TAB_COLUMNS utc
    WHERE utc.TABLE_NAME = ''' || TRIM(upper(p_table_name)) || v_db_link || '''
    AND utc.COLUMN_NAME NOT IN (''USER_ID_OF_CHANGE'', ''DATE_OF_CHANGE'') 
    ORDER BY utc.COLUMN_NAME';
  
    OPEN result_list FOR v_sql;
  
    -- set error code to succesfully completed
    ERROR_CODE := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_all_columns');
  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --    DBMS_OUTPUT.PUT_LINE(error_message);
      ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           'Get_all_columns');
      IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
        RAISE;
      END IF;
  END Get_all_columns;

  /****************************************************************************
    <header>
      <name>              procedure Get_nonPK_columns
      </name>
  
      <author>            Jaroslav Holub
      </author>
  
      <version>           1.0.0   ??.6.2004 Jaroslav Holub
                                  created first version
      </version>
  
      <Description>       procedure ...
  
      </Description>
  
      <Prerequisites>
      </Prerequisites>
  
      <Application>       FORIS Resource inventory
      </Application>
  
      <Parameters>
                          ,
                          handle_tran       IN  CHAR,
                          p_raise_error     IN  CHAR,
                          error_code        OUT NUMBER,
                          error_message     OUT VARCHAR2
      </Parameters>
  
    </header>
  ****************************************************************************/

  ----------------------------------------------------------------------------
  --  Get_nonPK_columns
  ----------------------------------------------------------------------------

  PROCEDURE Get_nonPK_columns
  (
    p_table_name  IN VARCHAR2,
    p_db_link     IN VARCHAR2,
    p_raise_error IN CHAR,
    ERROR_CODE    OUT NUMBER,
    error_message OUT VARCHAR2,
    result_list   OUT sys_refcursor
  ) IS
    v_sqlcode NUMBER;
    v_sql     VARCHAR2(32000);
    v_db_link VARCHAR2(50);
  BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_nonPK_columns');
  
    IF p_db_link IS NOT NULL THEN
      v_db_link := '@' || TRIM(p_db_link);
    ELSE
      v_db_link := NULL;
    END IF;
  
    v_sql := 'SELECT utc.COLUMN_NAME,
             utc.DATA_TYPE
        FROM USER_TAB_COLUMNS' || v_db_link || ' utc
       WHERE utc.TABLE_NAME = ''' || upper(p_table_name) || ''' 
         AND utc.COLUMN_NAME NOT IN (''DATE_OF_CHANGE'', ''USER_ID_OF_CHANGE'')
         AND NOT EXISTS (SELECT 1
                FROM USER_CONSTRAINTS' || v_db_link || ' uc
                JOIN USER_CONS_COLUMNS' || v_db_link || ' ucc ON uc.CONSTRAINT_NAME = ucc.CONSTRAINT_NAME
               WHERE uc.TABLE_NAME = utc.TABLE_NAME
                 AND ucc.COLUMN_NAME = utc.COLUMN_NAME
                 AND uc.CONSTRAINT_TYPE = ''P'')
       ORDER BY utc.COLUMN_NAME';
    -- set error code to succesfully completed
  
    OPEN result_list FOR v_sql;
  
    ERROR_CODE := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_nonPK_columns');
  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --    DBMS_OUTPUT.PUT_LINE(error_message);
      ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           'Get_nonPK_columns');
      IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
        RAISE;
      END IF;
  END Get_nonPK_columns;

  /****************************************************************************
    <header>
      <name>              procedure Get_PK_columns
      </name>
  
      <author>            Jaroslav Holub
      </author>
  
      <version>           1.0.0   ??.6.2004 Jaroslav Holub
                                  created first version
      </version>
  
      <Description>       procedure ...
  
      </Description>
  
      <Prerequisites>
      </Prerequisites>
  
      <Application>       FORIS Resource inventory
      </Application>
  
      <Parameters>
                          ,
                          handle_tran       IN  CHAR,
                          p_raise_error     IN  CHAR,
                          error_code        OUT NUMBER,
                          error_message     OUT VARCHAR2
      </Parameters>
  
    </header>
  ****************************************************************************/

  ----------------------------------------------------------------------------
  --  Get_PK_columns
  ----------------------------------------------------------------------------

  PROCEDURE Get_PK_columns
  (
    p_table_name  IN VARCHAR2,
    p_db_link     IN VARCHAR2,
    p_raise_error IN CHAR,
    ERROR_CODE    OUT NUMBER,
    error_message OUT VARCHAR2,
    result_list   OUT sys_refcursor
  ) IS
    v_sqlcode NUMBER;
    v_db_link VARCHAR2(300);
    v_sql     VARCHAR2(32000);
  BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_PK_columns');
    -- check handle_tran parameter
  
    IF p_db_link IS NOT NULL
       AND instr(p_db_link,
                 '@') = 0 THEN
      v_db_link := '@' || TRIM(p_db_link);
    ELSE
      v_db_link := NULL;
    END IF;
  
    -- procedure body here
    v_sql := 'SELECT ucc.COLUMN_NAME, utc.DATA_TYPE
    FROM USER_CONS_COLUMNS' || v_db_link || ' ucc 
         JOIN USER_CONSTRAINTS' || v_db_link || ' uc ON uc.CONSTRAINT_NAME = ucc.CONSTRAINT_NAME
         JOIN USER_TAB_COLUMNS' || v_db_link || ' utc ON utc.TABLE_NAME = ucc.TABLE_NAME AND utc.COLUMN_NAME = ucc.COLUMN_NAME
    WHERE uc.CONSTRAINT_TYPE = ''P''
      AND uc.TABLE_NAME = ''' || upper(TRIM(p_table_name)) || '''
    ORDER BY utc.COLUMN_NAME';
  
    OPEN result_list FOR v_sql;
  
    -- set error code to succesfully completed
    ERROR_CODE := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Get_PK_columns');
  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --    DBMS_OUTPUT.PUT_LINE(error_message);
      ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           'Get_PK_columns');
      IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
        RAISE;
      END IF;
  END Get_PK_columns;

  /****************************************************************************
    <header>
      <name>              procedure Create_select_statement
      </name>
  
      <author>            Jaroslav Holub
      </author>
  
      <version>           1.0.0   ??.6.2004 Jaroslav Holub
                                  created first version
      </version>
  
      <Description>       procedure ...
  
      </Description>
  
      <Prerequisites>
      </Prerequisites>
  
      <Application>       FORIS Resource inventory
      </Application>
  
      <Parameters>
                          ,
                          handle_tran       IN  CHAR,
                          p_raise_error     IN  CHAR,
                          error_code        OUT NUMBER,
                          error_message     OUT VARCHAR2
      </Parameters>
  
    </header>
  ****************************************************************************/

  ----------------------------------------------------------------------------
  --  Create_select_statement
  ----------------------------------------------------------------------------

  PROCEDURE Create_select_statement(
                                    
                                    p_table_name  IN VARCHAR2,
                                    p_db_link     IN VARCHAR2,
                                    p_all_columns IN CHAR,
                                    p_raise_error IN CHAR,
                                    ERROR_CODE    OUT NUMBER,
                                    error_message OUT VARCHAR2,
                                    p_sql_string  OUT VARCHAR2) IS
    v_sqlcode NUMBER;
    c_cols    sys_refcursor;
    --    c_remote_cols sys_refcursor;
    v_sql   VARCHAR2(32000);
    coll    t_col_v2_50;
    coll_dt t_col_v2_50;
  BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Create_select_statement');
    -- check handle_tran parameter
    /*    IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
          RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,
                                  'Invalid HANDLE_TRAN parameter!');
        END IF;
    */
    /*  IF test input parameters THEN 
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
      END IF;
    */
  
    IF upper(p_all_columns) = 'Y' THEN
      Get_all_columns(p_table_name,
                      p_db_link,
                      'Y',
                      ERROR_CODE,
                      error_message,
                      c_cols);
    ELSIF upper(p_all_columns) = 'N' THEN
      Get_nonPK_columns(p_table_name,
                        p_db_link,
                        'Y',
                        ERROR_CODE,
                        error_message,
                        c_cols);
    ELSIF upper(p_all_columns) = 'P' THEN
      Get_PK_columns(p_table_name,
                     p_db_link,
                     'Y',
                     ERROR_CODE,
                     error_message,
                     c_cols);
    
    END IF;
  
    FETCH c_cols BULK COLLECT
      INTO coll, coll_dt;
  
    /*    IF coll.FIRST IS NULL THEN 
           RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,
                                         'Invalid HANDLE_TRAN parameter!');
    END IF;
    */
    v_sql := 'SELECT ';
  
    FOR i IN nvl(coll.FIRST,
                 1) .. nvl(coll.LAST,
                           0)
    LOOP
      v_sql := v_sql || coll(i);
      IF i <> coll.LAST THEN
        v_sql := v_sql || ', ';
      END IF;
    
    END LOOP;
  
    v_sql := v_sql || ' FROM ' || upper(p_table_name);
  
    p_sql_string := v_sql;
    -- set error code to succesfully completed
    ERROR_CODE := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         'Create_select_statement');
  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --    DBMS_OUTPUT.PUT_LINE(error_message);
      ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           'Create_select_statement');
      IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
        RAISE;
      END IF;
  END Create_select_statement;

END RSIG_COMPARE;
/
