CREATE package QUEUE_RI is

------------------------------!------------------------------
  c_Q_RES_RESERVATION       constant varchar2(100) := 'Q_RES_RESERVATION';
  c_Q_IMSI_MSISDN_BS_CHANGE constant varchar2(100) := 'Q_IMSI_MSISDN_BS_CHANGE';

------------------------------!------------------------------
  procedure set_ResReservationMsg
  (
    p_msisdn               varchar2,
    p_resource_param_code  varchar2,
    p_resource_param_value varchar2,
    p_event_date           date,
    p_event_type           number -- type of an event (exm. 0-false(unreservation), 1-true(reservation))
  );

  procedure get_ResReservationMsg
  (
    p_subscriber           varchar2,
    p_msisdn               out varchar2,
    p_resource_param_code  out varchar2,
    p_resource_param_value out varchar2,
    p_event_date           out date,
    p_event_type           out number, -- type of an event (exm. 0-false(unreservation), 1-true(reservation))
    p_ms_handle            out varchar2
  );

------------------------------!------------------------------
  -- Procedure enqueue change in balance storage to the Q_IMSI_MSISDN_BS_CHANGE queue.
  procedure set_bs_change_msg
  (
    p_imsi                 varchar2, -- IMSI
    p_msisdn               varchar2, -- MSISDN
    p_start_date_msisdn    date,     -- start date of link MSISDN with IMSI
    p_end_date_msisdn      date,     -- end date of link MISISDN with IMSI
    p_personal_account     number,   -- personal account
    p_balance_storage_type varchar2, -- balance storage type (ST,IN)
    p_balance_storage_code varchar2, -- code of balance storage
    p_start_date_bs        date,     -- start date of assigment balance storage to personal account
    p_end_date_bs          date,     -- end date of assigment balance storage to personal account
    p_operation_type       varchar2  -- operation type
  );

  -- Procedure dequeue change in balance storage from the Q_IMSI_MSISDN_BS_CHANGE queue.
  procedure get_bs_change_msg
  (
    p_subscriber           varchar2,     -- queue subscriber
    p_imsi                 out varchar2, -- IMSI
    p_msisdn               out varchar2, -- MSISDN
    p_start_date_msisdn    out date,     -- start date of link MSISDN with IMSI
    p_end_date_msisdn      out date,     -- end date of link MISISDN with IMSI
    p_personal_account     out number,   -- personal account
    p_balance_storage_type out varchar2, -- balance storage type (ST,IN)
    p_balance_storage_code out varchar2, -- code of balance storage
    p_start_date_bs        out date,     -- start date of assigment balance storage to personal account
    p_end_date_bs          out date,     -- end date of assigment balance storage to personal account
    p_operation_type       out varchar2, -- operation type
    p_ms_handle            out varchar2
  );

------------------------------!------------------------------
end;
/
