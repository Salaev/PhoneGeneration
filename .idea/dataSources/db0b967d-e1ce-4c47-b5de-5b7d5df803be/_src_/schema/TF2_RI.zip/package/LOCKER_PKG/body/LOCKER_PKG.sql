CREATE package body locker_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ct_locker_data_range(p_coll ct_locker_data_range) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_ct_locker_data_eq(p_coll ct_locker_data_eq) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_locker_data_range_val(p_coll in out nocopy ct_locker_data_range, p_val tt_locker_data_range%rowtype)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_locker_data_range();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_locker_data_eq_val(p_coll in out nocopy ct_locker_data_eq, p_val tt_locker_data_eq%rowtype)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_locker_data_eq();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_locker_data_range(p_coll in out nocopy ct_locker_data_range, p_coll_add ct_locker_data_range)
is
  v_count number;
begin
  ------------------------------
  if get_count_ct_locker_data_range(p_coll_add) = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_locker_data_range();
  end if;
  ------------------------------
  v_count := p_coll.count;
  ------------------------------
  p_coll.extend(p_coll_add.count);
  ------------------------------
  for v_i in p_coll_add.first..p_coll_add.last
  loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_locker_data_eq(p_coll in out nocopy ct_locker_data_eq, p_coll_add ct_locker_data_eq)
is
  v_count number;
begin
  ------------------------------
  if get_count_ct_locker_data_eq(p_coll_add) = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_locker_data_eq();
  end if;
  ------------------------------
  v_count := p_coll.count;
  ------------------------------
  p_coll.extend(p_coll_add.count);
  ------------------------------
  for v_i in p_coll_add.first..p_coll_add.last
  loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_tt_locker_data_range
(
  p_type_id number,
  p_sn_from nvarchar2,
  p_sn_to nvarchar2
)
return tt_locker_data_range%rowtype
is
  v_res tt_locker_data_range%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_type_id is null, 'p_type_id');
  util_pkg.XCheck_Cond_Missing(p_sn_from is null, 'p_sn_from');
  util_pkg.XCheck_Cond_Missing(p_sn_to is null, 'p_sn_to');
  ------------------------------
  v_res.type_id := p_type_id;
  v_res.sn_from := p_sn_from;
  v_res.sn_to := p_sn_to;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_tt_locker_data_eq
(
  p_type_id number,
  p_stock_id number
)
return tt_locker_data_eq%rowtype
is
  v_res tt_locker_data_eq%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_type_id is null, 'p_type_id');
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  ------------------------------
  v_res.type_id := p_type_id;
  v_res.stock_id := p_stock_id;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_locker_data_range
(
  p_type_id number,
  p_sn_from nvarchar2,
  p_sn_to nvarchar2
)
return ct_locker_data_range
is
  v_res ct_locker_data_range;
  v_row tt_locker_data_range%rowtype;
begin
  ------------------------------
  v_row := make_tt_locker_data_range
  (
    p_type_id => p_type_id,
    p_sn_from => p_sn_from,
    p_sn_to => p_sn_to
  );
  ------------------------------
  add_ct_locker_data_range_val(v_res, v_row);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_locker_data_eq
(
  p_type_id number,
  p_stock_id number
)
return ct_locker_data_eq
is
  v_res ct_locker_data_eq;
  v_row tt_locker_data_eq%rowtype;
begin
  ------------------------------
  v_row := make_tt_locker_data_eq
  (
    p_type_id => p_type_id,
    p_stock_id => p_stock_id
  );
  ------------------------------
  add_ct_locker_data_eq_val(v_res, v_row);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function GS_locker_expire_period_sec return number
is
begin
  ------------------------------
  return install_pkg.nnget_option_num(c_opt_locker_expire_period_sec, c_def_locker_expire_period_sec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GS_mutex_timeout_sec return number
is
begin
  ------------------------------
  return install_pkg.nnget_option_num(c_opt_mutex_timeout_sec, c_def_mutex_timeout_sec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GS_ignore_model_type return boolean
is
begin
  ------------------------------
  return install_pkg.nnget_option_bool(c_opt_ignore_model_type, c_def_ignore_model_type);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GS_max_size_split_range return number
is
begin
  ------------------------------
  return install_pkg.nnget_option_num(c_opt_max_size_split_range, c_def_max_size_split_range);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_long_range_data return ct_range
is
  v_res ct_range;
begin
  ------------------------------
  select /*+ full(z)*/
    ot_range
    (
      sn_from, --!_!val1
      sn_to, --!_!val2
      type_id, --!_!num1
      length(sn_from), --!_!num2
      null, --!_!num3
      null, --!_!dat1
      null --!_!num4
    )
    bulk collect into v_res
    from TT_LONG_RANGE_DATA z
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure clear_long_range_data
is
begin
  ------------------------------
  delete from TT_LONG_RANGE_DATA;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_long_range_data(p_range ct_range)
is
begin
  ------------------------------
  clear_long_range_data;
  ------------------------------
  insert into TT_LONG_RANGE_DATA
  (
    type_id,
    sn_from,
    sn_to,
    quantity
  )
  select
    num1,
    val1,
    val2,
    case
      when translate(val1, '_0123456789', '_') is not null then 1
      else to_number(val2) - to_number(val1) + 1
    end quantity
    from table(p_range)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function Get_Locker(p_locker_id number) return locker%rowtype
is
  v_locker_session locker%rowtype;
begin
  ------------------------------
  select /*+ index(l PK_LOCKER)*/
    l.* into v_locker_session
    from LOCKER l
    where id = p_locker_id
  ;
  ------------------------------
  return v_locker_session;
  ------------------------------
exception
when NO_DATA_FOUND then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function Create_Locker(p_locker_group_id number := null) return t_locker
is
  pragma autonomous_transaction;
  v_locker_session t_locker;
  v_date date := SYSDATE;
  v_check number;
begin
  ------------------------------
  Release_Expired_Lockers;
  ------------------------------
  if p_locker_group_id is null
  then
    ------------------------------
    v_locker_session.locker_group_id := s_locker_group.nextval;
    ------------------------------
  else
    ------------------------------
    v_check := Check_Locker_Group(p_locker_group_id);
    ------------------------------
    if v_check = 0
    then
      util_pkg.raise_exception(util_loc_pkg.c_ora_locker_session_not_fnd, util_loc_pkg.c_msg_locker_session_not_fnd);
    end if;
    ------------------------------
    v_locker_session.locker_group_id := p_locker_group_id;
    ------------------------------
  end if;
  ------------------------------
  v_locker_session.locker_id := S_LOCKER.NEXTVAL;
  ------------------------------
  insert into LOCKER(id, group_id, date_from, is_finished)
    values(v_locker_session.locker_id, v_locker_session.locker_group_id, v_date, 0)
  ;
  ------------------------------
  commit;
  ------------------------------
  return v_locker_session;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Set_Locker_Finished(p_locker_param t_locker_parameters)
is
begin
  ------------------------------
  update /*+ index(l PK_LOCKER)*/
    LOCKER l
    set is_finished = util_pkg.c_true
    where id = p_locker_param.locker.locker_id
  ;
  ------------------------------
  if sql%rowcount < 1
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_locker_session_not_fnd, util_loc_pkg.c_msg_locker_session_not_fnd);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Add_Mutex(p_mutex_id number)
is
  pragma autonomous_transaction;
begin
  ------------------------------
  insert into LOCKER_MUTEX(MUTEX_ID)
    values(p_mutex_id)
  ;
  ------------------------------
  commit;
  ------------------------------
exception
when dup_val_on_index then
  ------------------------------
  rollback;
  ------------------------------
when others then
  ------------------------------
  rollback;
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Switch_On_Mutex(p_mutex_id number)
is
  v_chk number;
  v_wait_sec number;
  v_sql_text varchar2(32767);
begin
  ------------------------------
  v_wait_sec := GS_mutex_timeout_sec;
  ------------------------------
  select /*+ index(lm I_LOCKER_MUTEX_TN)*/
    count(1) into v_chk
    from LOCKER_MUTEX lm
    where mutex_id = p_mutex_id
  ;
  ------------------------------
  if v_chk = 0
  then
    Add_Mutex(p_mutex_id);
  end if;
  ------------------------------
  v_sql_text := q'{select /*+ index(lm I_LOCKER_MUTEX_TN)*/
    mutex_id
    from LOCKER_MUTEX lm
    where 1 = 1
    and mutex_id = :p_mutex_id
    for update wait :p_wait_sec
}'
  ;
  ------------------------------
  v_sql_text := replace(v_sql_text, ':p_wait_sec', to_char(v_wait_sec));
  ------------------------------
  begin
    ------------------------------
    execute immediate v_sql_text into v_chk using p_mutex_id;
    ------------------------------
  exception
  when util_pkg.lock_wait_exception then
    ------------------------------
    util_pkg.raise_exception(util_loc_pkg.c_ora_mutex_timeout, util_loc_pkg.c_msg_mutex_timeout);
    ------------------------------
  end;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Handle_Wrong_Equipment(p_locker_error ct_locker_data_range, p_error_code number, p_error_message varchar2, p_label varchar2 := '')
is
  v_error_code number;
  v_error_message varchar2(32767);
begin
  ------------------------------
  if get_count_ct_locker_data_range(p_locker_error) = 0
  then
    return;
  end if;
  ------------------------------
  v_error_code := p_error_code;
  v_error_message := p_error_message;
  ------------------------------
  for i in p_locker_error.first..p_locker_error.last
  loop
    ------------------------------
    if length(v_error_message) <= util_pkg.c_max_error_message_length2
    then
      ------------------------------
      v_error_message := v_error_message || Handle_Wrong_Equipment_Str(p_locker_error(i).sn_from, p_locker_error(i).sn_to, p_locker_error(i).type_id, p_label);
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  util_pkg.raise_exception(v_error_code, v_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function Handle_Wrong_Equipment_Str(p_seria_start varchar2, p_seria_end varchar2, p_equipment_model_id varchar2, p_label varchar2) return varchar2
is
begin
  ------------------------------
  return '(' || p_seria_start || ',' || p_seria_end || ',' || p_equipment_model_id || case when p_label is null then '' else ',' || p_label end || ')' || ',';
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Insert_Locker_Data(p_locker_data ct_locker_data_range)
is
  pragma autonomous_transaction;
begin
  ------------------------------
  delete from TT_LOCKER_DATA_RANGE;
  ------------------------------
  if get_count_ct_locker_data_range(p_locker_data) > 0
  then
    forall i in p_locker_data.first..p_locker_data.last
      insert into TT_LOCKER_DATA_RANGE(TYPE_ID, SN_FROM, SN_TO)
        values (p_locker_data(i).TYPE_ID, p_locker_data(i).SN_FROM, p_locker_data(i).SN_TO)
    ;
  end if;
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Check_Locker_Data(p_allow_non_digit_sn boolean := false)
is
  v_locker_error ct_locker_data_range;
begin
  ------------------------------
  if (p_allow_non_digit_sn)
  then
    select distinct type_id, sn_from, sn_to
      bulk collect into v_locker_error
      from (
      select
        type_id,
        sn_from,
        sn_to,
        translate(sn_from, '_0123456789', '_') nl_from,
        translate(sn_to, '_0123456789', '_') nl_to
        from TT_LOCKER_DATA_RANGE tt
      ) t
      where 1 = 1
      and (1 = 0
        or (sn_from <> sn_to)
        or length(sn_from) <> length(sn_to)
      )
    ;
  else
    select distinct type_id, sn_from, sn_to
      bulk collect into v_locker_error
      from (
      select
        type_id,
        sn_from,
        sn_to,
        translate(sn_from, '_0123456789', '_') nl_from,
        translate(sn_to, '_0123456789', '_') nl_to
        from TT_LOCKER_DATA_RANGE tt
      ) t
      where 1 = 1
      and (1 = 0
        or nl_from is not null
        or nl_to is not null
        or (1 = 1
            and nl_from is null
            and nl_to is null
            and to_number(sn_from) > to_number(sn_to)
        )
        or length(sn_from) <> length(sn_to)
      )
    ;
  end if;
  ------------------------------
  Handle_Wrong_Equipment(v_locker_error, util_loc_pkg.c_ora_incorrect_sn, util_loc_pkg.c_msg_incorrect_sn);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Clear_Temporary_Tables
is
  pragma autonomous_transaction;
begin
  ------------------------------
  delete from TT_SINGLE_RANGE_DATA;
  delete from TT_SHORT_RANGE_DATA;
  delete from TT_LONG_RANGE_DATA;
  delete from TT_LOCKER_DATA_SR;
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Fill_Temporary_Tables(p_locker_param t_locker_parameters, p_allow_input_overlap boolean)
is
  pragma autonomous_transaction;
  v_default_data_type number;
begin
  ------------------------------
  v_default_data_type := c_def_data_type;
  util_loc_pkg.touch_number(v_default_data_type);
  ------------------------------
  insert first

  when quantity = 1
  then into
    TT_SINGLE_RANGE_DATA(type_id, sn)
    values (type_id, sn_from)

  when quantity between 2 and p_locker_param.split_batch_count_limit
  then into
    TT_SHORT_RANGE_DATA(type_id, sn_from, sn_to, quantity)
    values (type_id, sn_from, sn_to, quantity)

  when quantity > p_locker_param.split_batch_count_limit
  then into
    TT_LONG_RANGE_DATA(type_id, sn_from, sn_to, quantity)
    values (type_id, sn_from, sn_to, quantity)

  select
    case
      when p_locker_param.ignore_type = util_pkg.c_true
        then v_default_data_type
      else type_id
    end type_id,
    sn_from,
    sn_to,
    case
      when translate(sn_from, '_0123456789', '_') is not null then 1
      else to_number(sn_to) - to_number(sn_from) + 1
    end quantity
    from TT_LOCKER_DATA_RANGE tt
  ;
  ------------------------------
  if p_allow_input_overlap
  then
    Make_Uniq_TT_LONG_RANGE_DATA;
  else
    Check_TT_LONG_RANGE_DATA;
  end if;
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Make_Uniq_TT_LONG_RANGE_DATA
is
  v_range ct_range;
begin
  ------------------------------
  v_range := get_long_range_data;
  ------------------------------
  v_range := range_pkg.make_unique_ranges2(v_range);
  ------------------------------
  set_long_range_data(v_range);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!input data check
procedure Check_TT_LONG_RANGE_DATA
is
  v_locker_error ct_locker_data_range;
begin
  ------------------------------
  select /*+ ordered use_hash(tt tt1) full(tt) full(tt1)*/
    distinct tt.type_id, tt.sn_from, tt.sn_to
    bulk collect into v_locker_error
    from TT_LONG_RANGE_DATA tt
    join TT_LONG_RANGE_DATA tt1 ON tt1.rowid <> tt.rowid
    where 1 = 1
    and length(tt.sn_from) = length(tt1.sn_from)
    and tt.type_id = tt1.type_id --!_!already with ignore_type
    and (tt.sn_from between tt1.sn_from and tt1.sn_to
      or tt.sn_to between tt1.sn_from and tt1.sn_to
    )
  ;
  ------------------------------
  Handle_Wrong_Equipment(v_locker_error, util_loc_pkg.c_ora_ranges_intersection_lck, util_loc_pkg.c_msg_ranges_intersection_lck);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XL_Check_Locker_Data_SR
is
  v_locker_error ct_locker_data_range;
begin
  ------------------------------
  --!_!Check input short ranges on intersection with the existing long ranges
  select /*+ ordered use_hash(tt ldbr) full(tt) full(ldbr)*/
    distinct tt.type_id, tt.sn_from, tt.sn_to
    bulk collect into v_locker_error
    from TT_SHORT_RANGE_DATA tt, LOCKER_DATA_LR ldbr
    where 1 = 1
    and tt.type_id = ldbr.type_id --!_!already with ignore_type
    and length(tt.sn_from) = length(ldbr.sn_from)
    and (1 = 0
      or tt.sn_from between ldbr.sn_from and ldbr.sn_to
      or tt.sn_to between ldbr.sn_from and ldbr.sn_to
      or ldbr.sn_from between tt.sn_from and tt.sn_to
      or ldbr.sn_to between tt.sn_from and tt.sn_to
    )
  ;
  ------------------------------
  Handle_Wrong_Equipment(v_locker_error, util_pkg.c_ora_object_latched, util_pkg.c_msg_object_latched);
  ------------------------------
  --!_!Check input the single ranges on intersection with the existing long ranges
  select /*+ ordered use_hash(tt ldbr) full(tt) full(ldbr)*/
    distinct tt.type_id, tt.sn, tt.sn
    bulk collect into v_locker_error
    from TT_SINGLE_RANGE_DATA tt, LOCKER_DATA_LR ldbr
    where 1 = 1
    and tt.type_id = ldbr.type_id
    and length(tt.sn) = length(ldbr.sn_from)
    and tt.sn between ldbr.sn_from and ldbr.sn_to
  ;
  ------------------------------
  Handle_Wrong_Equipment(v_locker_error, util_pkg.c_ora_object_latched, util_pkg.c_msg_object_latched);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XL_Check_Locker_Data_LR(p_locker_param t_locker_parameters)
is
  v_locker_error ct_locker_data_range;
begin
  ------------------------------
  --!_!Check input long ranges on intersection with the existing single/short ranges
  select /*+ ordered use_nl(tt ld l) full(tt) index(ld I_LOCKER_DATA_SR_SN_TYPE) index(ld PK_LOCKER)*/
    distinct tt.type_id, tt.sn_from, tt.sn_to
    bulk collect into v_locker_error
    from TT_LONG_RANGE_DATA tt
    join LOCKER_DATA_SR ld on ld.sn between tt.sn_from and tt.sn_to
    join LOCKER l on l.id = ld.locker_id and (l.is_finished = util_pkg.c_true or l.id = p_locker_param.locker.locker_id)
    where 1 = 1
    and tt.type_id = ld.type_id
  ;
  ------------------------------
  Handle_Wrong_Equipment(v_locker_error, util_pkg.c_ora_object_latched, util_pkg.c_msg_object_latched);
  ------------------------------
  --!_!Check input long ranges on intersection with the existing long ranges
  select /*+ ordered use_hash(tt ldbr) full(tt) full(ldbr)*/
    distinct tt.type_id, tt.sn_from, tt.sn_to
    bulk collect into v_locker_error
    from TT_LONG_RANGE_DATA tt, LOCKER_DATA_LR ldbr
    where 1 = 1
    and tt.type_id = ldbr.type_id
    and length(tt.sn_from) = length(ldbr.sn_from)
    and (1 = 0
      or tt.sn_from between ldbr.sn_from and ldbr.sn_to
      or tt.sn_to between ldbr.sn_from and ldbr.sn_to
      or ldbr.sn_from between tt.sn_from and tt.sn_to
      or ldbr.sn_to between tt.sn_from and tt.sn_to
    )
  ;
  ------------------------------
  Handle_Wrong_Equipment(v_locker_error, util_pkg.c_ora_object_latched, util_pkg.c_msg_object_latched);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XL_Lock_Single_Short_Rg_Data(p_locker_param t_locker_parameters, p_allow_input_overlap boolean)
is
  pragma autonomous_transaction;
  v_max_delta number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_allow_input_overlap is null, 'p_allow_input_overlap');
  ------------------------------
  select nvl(max(tt.quantity), 1)
    into v_max_delta
    from TT_SHORT_RANGE_DATA tt
  ;
  ------------------------------
  insert into TT_LOCKER_DATA_SR(type_id, sn)
  select /*+ ordered use_nl(tt, z) full(tt) full(z)*/
    tt.type_id,
    lpad(to_char(to_number(tt.sn_from) + val - 1), length(tt.sn_from), '0') sn
    from TT_SHORT_RANGE_DATA tt, (select rownum val from dual connect by level <= v_max_delta) z
    where 1 = 1
    and tt.quantity >= z.val
  ;
  ------------------------------
  insert into TT_LOCKER_DATA_SR(type_id, sn)
  select /*+ full(tt)*/
    type_id, sn
    from TT_SINGLE_RANGE_DATA tt
  ;
  ------------------------------
  if p_allow_input_overlap
  then
    ------------------------------
    --!_!Insert only SINGLE_RANGE not overlapped with LONG_RANGE
    insert into LOCKER_DATA_SR(LOCKER_ID, TYPE_ID, SN)
    select /*+ ordered use_hash(tt1) full(tt) full(tt1)*/
      distinct
      p_locker_param.locker.locker_id locker_id,
      tt.type_id,
      tt.sn
      from TT_LOCKER_DATA_SR tt, TT_LONG_RANGE_DATA tt1
      where 1 = 1
      and tt1.type_id(+) = tt.type_id
      and length(tt1.sn_from(+)) = length(tt.sn)
      and tt.sn between tt1.sn_from(+) and tt1.sn_to(+)
      and tt1.sn_from is null
      order by sn
    ;
    ------------------------------
  else
    ------------------------------
    insert into LOCKER_DATA_SR(LOCKER_ID, TYPE_ID, SN)
    select /*+ full(tt)*/
      p_locker_param.locker.locker_id locker_id,
      type_id,
      sn
      from TT_LOCKER_DATA_SR tt
      order by sn
    ;
    ------------------------------
  end if;
  ------------------------------
  commit;
  ------------------------------
exception
when dup_val_on_index then
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_object_latched, util_pkg.c_msg_object_latched || util_pkg.c_msg_delim01 || util_pkg.get_err_msg);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XL_Lock_Big_Range_Data(p_locker_param t_locker_parameters)
is
  pragma autonomous_transaction;
begin
  ------------------------------
  Switch_On_Mutex(c_mutex_locker_data_lr);
  ------------------------------
  --!_!Check input the single/short ranges on intersection with the existing long ranges
  XL_Check_Locker_Data_SR;
  ------------------------------
  --!_!Check input long ranges on intersection
  XL_Check_Locker_Data_LR(p_locker_param);
  ------------------------------
  insert into LOCKER_DATA_LR(locker_id, type_id, sn_from, sn_to)
  select /*+ full(tt)*/
    p_locker_param.locker.locker_id,
    type_id,
    sn_from,
    sn_to
    from TT_LONG_RANGE_DATA tt
  ;
  ------------------------------
  commit;
  ------------------------------
exception
when dup_val_on_index then
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_object_latched, util_pkg.c_msg_object_latched || util_pkg.c_msg_delim01 || util_pkg.get_err_msg);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Insert_Locker_Data_Eq(p_locker_data_eq ct_locker_data_eq)
is
  pragma autonomous_transaction;
begin
  ------------------------------
  delete from tt_locker_data_eq;
  ------------------------------
  if get_count_ct_locker_data_eq(p_locker_data_eq) > 0
  then
    ------------------------------
    forall i in p_locker_data_eq.first..p_locker_data_eq.last
      insert into TT_LOCKER_DATA_EQ
        values p_locker_data_eq(i)
    ;
    ------------------------------
  end if;
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XL_Check_Locker_Eq_Data
is
begin
  ------------------------------
  null;
  ------------------------------
  --!_!util_pkg.raise_exception(util_pkg.c_ora_object_latched, util_pkg.c_msg_object_latched || util_pkg.c_msg_delim01 || util_pkg.get_err_msg);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XL_Lock_Equipment_Data(p_locker_param t_locker_parameters)
is
  pragma autonomous_transaction;
begin
  ------------------------------
  insert into LOCKER_DATA_EQ(locker_id, type_id, stock_id)
  select /*+ full(tt)*/
    p_locker_param.locker.locker_id locker_id,
    type_id,
    stock_id
    from TT_LOCKER_DATA_EQ tt
  ;
  ------------------------------
  commit;
  ------------------------------
exception
when dup_val_on_index then
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_object_latched, util_pkg.c_msg_object_latched || util_pkg.c_msg_delim01 || util_pkg.get_err_msg);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_!interface begin
----------------------------------!---------------------------------------------
procedure Release_Locker_Group(p_locker_group_id number)
is
  pragma autonomous_transaction;
begin
  ------------------------------
  delete /*+ ordered use_nl(ld) index(ld I_LOCKER_DATA_EQ_LCK_ID)*/
    from LOCKER_DATA_EQ ld
    where locker_id in (select /*+ index(l I_LOCKER_GROUP)*/l.id from LOCKER l where l.group_id = p_locker_group_id)
  ;
  ------------------------------
  delete /*+ ordered use_nl(lr) index(lr I_LOCKER_DATA_EQ_LCK_ID)*/
    from LOCKER_DATA_LR lr
    where locker_id in (select /*+ index(l I_LOCKER_GROUP)*/l.id from LOCKER l where l.group_id = p_locker_group_id)
  ;
  ------------------------------
  delete /*+ ordered use_nl(sr) index(sr I_LOCKER_DATA_EQ_LCK_ID)*/
    from LOCKER_DATA_SR sr
    where locker_id in (select /*+ index(l I_LOCKER_GROUP)*/l.id from LOCKER l where l.group_id = p_locker_group_id)
  ;
  ------------------------------
  delete /*+ index(l I_LOCKER_GROUP)*/
    from LOCKER l
    where group_id = p_locker_group_id
  ;
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Release_Locker(p_locker_id number)
is
  pragma autonomous_transaction;
begin
  ------------------------------
  delete /*+ index(lq I_LOCKER_DATA_EQ_LCK_ID)*/
    from LOCKER_DATA_EQ ld
    where locker_id = p_locker_id
  ;
  ------------------------------
  delete /*+ index(lr I_LOCKER_DATA_LR_LCK_ID)*/
    from LOCKER_DATA_LR lr
    where locker_id = p_locker_id
  ;
  ------------------------------
  delete /*+ index(sr I_LOCKER_DATA_SR_LCK_ID)*/
    from LOCKER_DATA_SR sr
    where locker_id = p_locker_id
  ;
  ------------------------------
  delete /*+ index(l PK_LOCKER)*/
    from LOCKER l
    where id = p_locker_id
  ;
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Release_Expired_Lockers
is
  pragma autonomous_transaction;
  v_expiration_date DATE;
  v_expire_period NUMBER;
  v_locker_group_ids ct_number;
begin
  ------------------------------
  v_expire_period := GS_locker_expire_period_sec;
  ------------------------------
  v_expiration_date := SYSDATE - v_expire_period * util_pkg.c_second;
  ------------------------------
  select /*+ index(l I_LOCKER_DF)*/
    distinct l.group_id
    bulk collect into v_locker_group_ids
    from locker l
    where 1 = 1
    and date_from <= v_expiration_date
    and not exists(select /*+ nl_aj index(m I_LOCKER_GROUP)*/1 from locker m where m.group_id = l.group_id and m.date_from > v_expiration_date)
  ;
  ------------------------------
  if util_pkg.get_count_ct_number(v_locker_group_ids) > 0 then
    ------------------------------
    for i in v_locker_group_ids.first..v_locker_group_ids.last
    loop
      ------------------------------
      Release_Locker_Group(v_locker_group_ids(i));
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function Check_Locker(p_locker_id number) return number
is
  pragma autonomous_transaction;
  v_res number;
begin
  ------------------------------
  select /*+ index(l PK_LOCKER)*/
    count(1) into v_res
    from LOCKER l
    where id = p_locker_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function Check_Locker_Group(p_locker_group_id number) return number
is
  v_count number;
begin
  ------------------------------
  select /*+ index(l I_LOCKER_GROUP)*/
    count(1) into v_count
    from LOCKER l
    where group_id = p_locker_group_id
  ;
  ------------------------------
  return v_count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_!serial equipment
function xl_latch_ranges
(
  p_locker_data ct_locker_data_range,
  p_locker_group_id number,
  p_allow_non_digit_sn boolean,
  p_allow_input_overlap boolean
) return t_locker
is
pragma autonomous_transaction;
  v_error_code number;
  v_error_message varchar2(30000);
  v_locker_param t_locker_parameters;
begin
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(p_locker_group_id is null, 'p_locker_group_id');
  util_pkg.XCheck_Cond_Missing(p_allow_non_digit_sn is null, 'p_allow_non_digit_sn');
  util_pkg.XCheck_Cond_Missing(p_allow_input_overlap is null, 'p_allow_input_overlap');
  ------------------------------
  v_locker_param.ignore_type := util_pkg.bool_to_int_2val(GS_ignore_model_type);
  ------------------------------
  v_locker_param.split_batch_count_limit := GS_max_size_split_range;
  ------------------------------
  v_locker_param.locker := Create_Locker(p_locker_group_id);
  ------------------------------
  Insert_Locker_Data(p_locker_data);
  ------------------------------
  Check_Locker_Data(p_allow_non_digit_sn);
  ------------------------------
  Clear_Temporary_Tables;
  ------------------------------
  Fill_Temporary_Tables(v_locker_param, p_allow_input_overlap);
  ------------------------------
  XL_Lock_Single_Short_Rg_Data(v_locker_param, p_allow_input_overlap);
  ------------------------------
  XL_Lock_Big_Range_Data(v_locker_param);
  ------------------------------
  Set_Locker_Finished(v_locker_param);
  ------------------------------
  commit;
  ------------------------------
  return v_locker_param.locker;
  ------------------------------
exception
when latch_exception then --!_!XL_
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
when others then
  ------------------------------
  util_pkg.set_error(v_error_code, v_error_message);
  ------------------------------
  rollback;
  ------------------------------
  Release_Locker(v_locker_param.locker.locker_id);
  ------------------------------
  util_pkg.raise_exception(v_error_code, v_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!serial equipment
function xl_latch_ranges2
(
  p_locker_data ct_locker_data_range
) return t_locker
is
begin
  ------------------------------
  return xl_latch_ranges
  (
    p_locker_data => p_locker_data,
    p_locker_group_id => NULL,
    p_allow_non_digit_sn => false,
    p_allow_input_overlap => false
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!serial equipment
function xl_latch_range
(
  p_type_id number,
  p_sn_from nvarchar2,
  p_sn_to nvarchar2,
  p_locker_group_id number,
  p_allow_non_digit_sn boolean,
  p_allow_input_overlap boolean
) return t_locker
is
  v_locker_data ct_locker_data_range;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_type_id is null, 'p_type_id');
  util_pkg.XCheck_Cond_Missing(p_sn_from is null, 'p_sn_from');
  util_pkg.XCheck_Cond_Missing(p_sn_to is null, 'p_sn_to');
  --!_!util_pkg.XCheck_Cond_Missing(p_locker_group_id is null, 'p_locker_group_id');
  util_pkg.XCheck_Cond_Missing(p_allow_non_digit_sn is null, 'p_allow_non_digit_sn');
  util_pkg.XCheck_Cond_Missing(p_allow_input_overlap is null, 'p_allow_input_overlap');
  ------------------------------
  v_locker_data := make_ct_locker_data_range
  (
    p_type_id => p_type_id,
    p_sn_from => p_sn_from,
    p_sn_to => p_sn_to
  );
  ------------------------------
  return xl_latch_ranges
  (
    p_locker_data => v_locker_data,
    p_locker_group_id => p_locker_group_id,
    p_allow_non_digit_sn => p_allow_non_digit_sn,
    p_allow_input_overlap => p_allow_input_overlap
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!serial equipment
function xl_latch_range2
(
  p_type_id number,
  p_sn_from nvarchar2,
  p_sn_to nvarchar2
) return t_locker
is
begin
  ------------------------------
  return xl_latch_range
  (
    p_type_id => p_type_id,
    p_sn_from => p_sn_from,
    p_sn_to => p_sn_to,
    p_locker_group_id => NULL,
    p_allow_non_digit_sn => false,
    p_allow_input_overlap => false
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!non-serial equipment
function xl_latch_types_on_stocks
(
  p_locker_data_eq ct_locker_data_eq,
  p_locker_group_id number
) return t_locker
is
pragma autonomous_transaction;
  v_error_code number;
  v_error_message varchar2(30000);
  v_locker_param t_locker_parameters;
begin
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(p_locker_group_id is null, 'p_locker_group_id');
  ------------------------------
  v_locker_param.ignore_type := util_pkg.bool_to_int_2val(GS_ignore_model_type);
  ------------------------------
  v_locker_param.split_batch_count_limit := GS_max_size_split_range;
  ------------------------------
  v_locker_param.locker := Create_Locker(p_locker_group_id);
  ------------------------------
  Insert_Locker_Data_Eq(p_locker_data_eq);
  ------------------------------
  XL_Check_Locker_Eq_Data;
  ------------------------------
  XL_Lock_Equipment_Data(v_locker_param);
  ------------------------------
  Set_Locker_Finished(v_locker_param);
  ------------------------------
  commit;
  ------------------------------
  return v_locker_param.locker;
  ------------------------------
exception
when latch_exception then --!_!XL_
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
when others then
  ------------------------------
  util_pkg.set_error(v_error_code, v_error_message);
  ------------------------------
  rollback;
  ------------------------------
  Release_Locker(v_locker_param.locker.locker_id);
  ------------------------------
  util_pkg.raise_exception(v_error_code, v_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!non-serial equipment
function xl_latch_types_on_stocks2
(
  p_locker_data_eq ct_locker_data_eq
) return t_locker
is
begin
  ------------------------------
  return xl_latch_types_on_stocks
  (
    p_locker_data_eq => p_locker_data_eq,
    p_locker_group_id => null
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!non-serial equipment
function xl_latch_type_on_stock
(
  p_type_id number,
  p_stock_id number,
  p_locker_group_id number
) return t_locker
is
  v_locker_data ct_locker_data_eq;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_type_id is null, 'p_type_id');
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_locker_group_id is null, 'p_locker_group_id');
  ------------------------------
  v_locker_data := make_ct_locker_data_eq
  (
    p_type_id => p_type_id,
    p_stock_id => p_stock_id
  );
  ------------------------------
  return xl_latch_types_on_stocks
  (
    p_locker_data_eq => v_locker_data,
    p_locker_group_id => p_locker_group_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!non-serial equipment
function xl_latch_type_on_stock2
(
  p_type_id number,
  p_stock_id number
) return t_locker
is
begin
  ------------------------------
  return xl_latch_type_on_stock
  (
    p_type_id => p_type_id,
    p_stock_id => p_stock_id,
    p_locker_group_id => NULL
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_locker_eq(p_type_id number, p_stock_id number) return t_locker
is
  v_res t_locker;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_type_id is null, 'p_type_id');
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  ------------------------------
  select /*+ ordered use_nl(eq l) index(eq I_LOCKER_DATA_EQ_TYPE_STOCK) index(l PK_LOCKER)*/
         l.group_id locker_group_id,
         l.id locker_id
    into v_res
    from locker_data_eq eq
    join locker l on l.id = eq.locker_id
   where 1 = 1
     and eq.type_id = p_type_id
     and eq.stock_id = p_stock_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_locker_data_sr4group(p_locker_group_id number) return ct_locker_data_range
is
  v_res ct_locker_data_range;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_locker_group_id is null, 'p_locker_group_id');
  ------------------------------
  select /*+ ordered use_nl(l z) index(l I_LOCKER_GROUP) index(z I_LOCKER_DATA_SR_LCK_ID)*/
         z.type_id,
         z.sn sn_from,
         z.sn sn_to
    bulk collect into v_res
    from locker l
    join locker_data_sr z on z.locker_id = l.id
   where 1 = 1
     and l.group_id = p_locker_group_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!interface end
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
