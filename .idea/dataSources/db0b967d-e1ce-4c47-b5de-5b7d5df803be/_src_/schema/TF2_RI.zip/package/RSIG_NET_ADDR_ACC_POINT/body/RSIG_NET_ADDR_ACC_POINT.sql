CREATE PACKAGE BODY "RSIG_NET_ADDR_ACC_POINT" IS

---------------------------------------------
--     PROCEDURE Exist_Link_Type_Code
---------------------------------------------

PROCEDURE Exist_Link_Type_Code(p_link_type_code IN NET_ADDR_ACC_POINT_LINK_TYPE.LINK_TYPE_CODE%TYPE) IS
  v_pom number;
BEGIN
  select 1 into v_pom from NET_ADDR_ACC_POINT_LINK_TYPE where TRIM(LINK_TYPE_CODE) = TRIM(p_link_type_code);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Exist_Link_Type_Code;


---------------------------------------------
--     PROCEDURE Is_Interval_Overlap
---------------------------------------------

PROCEDURE Is_Interval_Overlap
(
  p_access_point_id    IN NETWORK_ADDRESS_ACCESS_POINT.ACCESS_POINT_ID%TYPE,
  p_network_address_id IN NETWORK_ADDRESS_ACCESS_POINT.NETWORK_ADDRESS_ID%TYPE,
  p_from_date          IN NETWORK_ADDRESS_ACCESS_POINT.FROM_DATE%TYPE DEFAULT NULL,
  p_to_date            IN NETWORK_ADDRESS_ACCESS_POINT.TO_DATE%TYPE DEFAULT NULL
) IS
  v_from_date          DATE;
  v_count              INT;
BEGIN
  v_from_date := nvl(p_from_date, SYSDATE);
  IF v_from_date < RSIG_UTILS.c_MIN_DATE THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;

  IF p_to_date IS NOT NULL
     AND p_to_date < RSIG_UTILS.c_MIN_DATE
     AND p_to_date < v_from_date THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;

  SELECT COUNT(1)
  INTO v_count
  FROM network_address_access_point naap
  WHERE naap.network_address_id=p_network_address_id
    AND (v_from_date<=naap.to_date OR naap.to_date IS NULL)
    AND (p_to_date>=naap.from_date OR p_to_date IS NULL);


  IF v_count>0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DATE_OVERLAP, '');
  END IF;
  /*
  FOR c_intervals IN (select FROM_DATE,
                             TO_DATE
                        from NETWORK_ADDRESS_ACCESS_POINT
                       where ACCESS_POINT_ID = p_access_point_id
                         and NETWORK_ADDRESS_ID = p_network_address_id)
  LOOP
    IF c_intervals.TO_DATE IS NULL
       OR v_from_date < c_intervals.TO_DATE THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DATE_OVERLAP, '');
    END IF;
    IF p_to_date IS NOT NULL
       AND p_to_date < c_intervals.FROM_DATE THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DATE_OVERLAP, '');
    END IF;
  END LOOP;
  */
END Is_Interval_Overlap;

---------------------------------------------
--     PROCEDURE Insert_Interval
---------------------------------------------

PROCEDURE Insert_Interval
(
  handle_tran          CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code           OUT NUMBER,
  p_access_point_id    IN NETWORK_ADDRESS_ACCESS_POINT.ACCESS_POINT_ID%TYPE,
  p_network_address_id IN NETWORK_ADDRESS_ACCESS_POINT.NETWORK_ADDRESS_ID%TYPE,
  p_link_type_code     IN NETWORK_ADDRESS_ACCESS_POINT.LINK_TYPE_CODE%TYPE,
  p_from_date          IN NETWORK_ADDRESS_ACCESS_POINT.FROM_DATE%TYPE,
  p_to_date            IN NETWORK_ADDRESS_ACCESS_POINT.TO_DATE%TYPE DEFAULT NULL,
  p_user_id_of_change  IN NETWORK_ADDRESS_ACCESS_POINT.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NET_ADDR_ACC_POINT.Insert_Interval';
  v_from_date    DATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  v_from_date := nvl(p_from_date, SYSDATE);
  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint insert_interval_a;
  END IF;

  IF p_to_date IS NOT NULL
     AND v_from_date > p_to_date THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_INTERVAL, '');
  END IF;

  Is_Interval_Overlap(p_access_point_id, p_network_address_id, v_from_date, p_to_date);
  --Is_Access_Point_Deleted(p_access_point_id);

  insert into NETWORK_ADDRESS_ACCESS_POINT
    (ACCESS_POINT_ID,
     NETWORK_ADDRESS_ID,
     LINK_TYPE_CODE,
     FROM_DATE,
     TO_DATE,
     DATE_OF_CHANGE,
     USER_ID_OF_CHANGE)
  values
    (p_access_point_id,
     p_network_address_id,
     p_link_type_code,
     v_from_date,
     p_to_date,
     sysdate,
     p_user_id_of_change);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint insert_interval_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Insert_Interval;

---------------------------------------------
--     PROCEDURE Close_Interval
---------------------------------------------

PROCEDURE Close_Interval
(
  handle_tran          CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code           OUT NUMBER,
  p_from_date          IN NETWORK_ADDRESS_ACCESS_POINT.FROM_DATE%TYPE,
  p_access_point_id    IN NETWORK_ADDRESS_ACCESS_POINT.ACCESS_POINT_ID%TYPE,
  p_network_address_id IN NETWORK_ADDRESS_ACCESS_POINT.NETWORK_ADDRESS_ID%TYPE,
  p_to_date            IN NETWORK_ADDRESS_ACCESS_POINT.TO_DATE%TYPE,
  p_user_id_of_change  IN NETWORK_ADDRESS_ACCESS_POINT.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NET_ADDR_ACC_POINT.Close_Interval';
  v_to_date      DATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  v_to_date := nvl(p_to_date, SYSDATE);
  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint close_interval_a;
  END IF;

  /*Is_Interval_Overlap(p_access_point_id,
                        p_network_address_id,
                        null,
                        p_to_date);
  */
  DECLARE
    to_date_h NETWORK_ADDRESS_ACCESS_POINT.TO_DATE%TYPE;
  BEGIN
    select TO_DATE
      into to_date_h
      from NETWORK_ADDRESS_ACCESS_POINT
     where ACCESS_POINT_ID = p_access_point_id
       and NETWORK_ADDRESS_ID = p_network_address_id
       and FROM_DATE = p_from_date
       and TO_DATE is null;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
  END;

  update NETWORK_ADDRESS_ACCESS_POINT
     set TO_DATE           = v_to_date,
         DATE_OF_CHANGE    = sysdate,
         USER_ID_OF_CHANGE = p_user_id_of_change
   where ACCESS_POINT_ID = p_access_point_id
     and NETWORK_ADDRESS_ID = p_network_address_id
     and FROM_DATE = p_from_date
     and TO_DATE is null;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint close_interval_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Close_Interval;


END RSIG_NET_ADDR_ACC_POINT;
/
