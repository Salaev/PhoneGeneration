CREATE package body RSIG_PORTING is

---------------------------------------------
--     PROCEDURE Save_Porting_History
---------------------------------------------

PROCEDURE Save_Porting_History(
    p_msisdn_number           IN  COMMON.t_international_format,
    p_donor_telco_id          IN  T_MNP,
    p_recipient_telco_id      IN  T_MNP,
    p_routing_number          IN  T_lrn,
    p_port_time               IN  t_date,
    p_network_routing_number  IN  T_lrn,
    p_handle_tran             IN  CHAR,
    p_error_code              OUT NUMBER,
    p_error_message           OUT VARCHAR2
  ) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Save_Porting_History';
  v_TT_LRN_HIST t_TT_LRN_HIST;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(p_handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (p_handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
  END IF;

  -- set savepoint
  IF (upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Insert_Phone_Serie;
  END IF;

  -- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
    -- check input parameters
  IF p_msisdn_number.COUNT<>p_donor_telco_id.COUNT OR
     p_donor_telco_id.COUNT<>p_recipient_telco_id.COUNT OR
     p_recipient_telco_id.COUNT<>p_routing_number.COUNT OR
     p_routing_number.COUNT<>p_port_time.COUNT OR
     p_port_time.COUNT <> p_network_routing_number.COUNT
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;
     
  DELETE FROM TT_LRN_HIST;
---------------------------------------------------------------------------------------------------------
  FOR i IN p_msisdn_number.FIRST .. p_msisdn_number.LAST
    LOOP
      INSERT INTO TT_LRN_HIST(INTERNATIONAL_FORMAT,DONOR_MNP,RECIPIENT_MNP,ROUTING_NUMBER,PORT_DATE,NETWORK_ROUTING_NUMBER)
      VALUES (p_msisdn_number(i), p_donor_telco_id(i), p_recipient_telco_id(i), p_routing_number(i), p_port_time(i), p_network_routing_number(i));
    END LOOP;

  UPDATE /*+ ordered full(tt)*/ TT_LRN_HIST tt
     SET tt.network_routing_number = (select /*+ index(mnp I_NOMNP_LRN)*/
                                             distinct mnp.Network_RN 
                                        from network_operator_mnp mnp 
                                       where mnp.network_operator_lrn = tt.routing_number)
   WHERE tt.network_routing_number is null;

   INSERT INTO PHONE_PORTING_HISTORY(MSISDN,DONORMNPCODE,RECIPIENTMNPCODE,ROUTING_NUMBER,PORTDATE,NETWORK_ROUTING_NUMBER)
     SELECT international_format,donor_mnp,recipient_mnp,routing_number,port_date,network_routing_number
       FROM TT_LRN_HIST;
       
   select *
     bulk collect into v_TT_LRN_HIST
     from TT_LRN_HIST;
     
   forall i in nvl(v_TT_LRN_HIST.first,1)..nvl(v_TT_LRN_HIST.last,0)
     update /*+ index(ppc i_ppc_msisdn)*/phone_porting_current ppc
        set ppc.donormnpcode = v_TT_LRN_HIST(i).donor_mnp,
            ppc.recipientmnpcode = v_TT_LRN_HIST(i).recipient_mnp,
            ppc.routing_number = v_TT_LRN_HIST(i).routing_number,
            ppc.portdate = v_TT_LRN_HIST(i).port_date,
            ppc.network_routing_number = v_TT_LRN_HIST(i).network_routing_number
      where ppc.msisdn = v_TT_LRN_HIST(i).international_format
        and ppc.portdate <= v_TT_LRN_HIST(i).port_date;
        
   insert into phone_porting_current( msisdn, 
                                      donormnpcode, 
                                      recipientmnpcode, 
                                      routing_number, 
                                      portdate, 
                                      network_routing_number)
     select tt.international_format,tt.donor_mnp,tt.recipient_mnp,tt.routing_number,tt.port_date,tt.network_routing_number
       from TT_LRN_HIST tt
      where not exists (select 1 from phone_porting_current ppc where ppc.msisdn = tt.international_format);
-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------


  	-- commit
	IF upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
		p_error_message := sqlerrm;
    p_error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
     CASE p_handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Insert_Phone_Serie;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
    END CASE;
END Save_Porting_History;

---------------------------------------------
--     PROCEDURE get_last_porting_date
---------------------------------------------

PROCEDURE get_last_porting_date(
    p_msisdn                IN   VARCHAR2,
    p_cursor                OUT  SYS_REFCURSOR,
    p_error_code            OUT  NUMBER,
    p_error_message         OUT  VARCHAR2
) IS
  v_event_source           VARCHAR2(60) := 'get_last_porting_date';
  v_last_porting_date      DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_msisdn IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameter');
  END IF;

   SELECT MAX(PORTDATE) INTO v_last_porting_date 
     FROM PHONE_PORTING_HISTORY WHERE msisdn = p_msisdn;
     
   OPEN p_cursor FOR 
      SELECT pph.msisdn, pph.donormnpcode, pph.recipientmnpcode, pph.routing_number, pph.portdate, pph.network_routing_number FROM PHONE_PORTING_HISTORY pph
       WHERE pph.msisdn = p_msisdn 
         AND pph.PORTDATE = v_last_porting_date;

   p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

  EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      p_error_code    := RSIG_UTILS.Handle_Error(SQLCODE);
      p_error_message := sqlerrm;
      RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END get_last_porting_date;

PROCEDURE get_lrn_for_numbers(
  p_id                      IN   Common.t_number,
  p_msisdn                  IN   Common.t_international_format,
  p_port_time               IN   t_date,
  p_cursor                  OUT  SYS_REFCURSOR,
  p_error_code              OUT  NUMBER,
  p_error_message           OUT  VARCHAR2
  )IS
  v_event_source           VARCHAR2(60) := 'get_lrn_for_numbers';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_msisdn IS NULL OR p_id IS NULL OR p_port_time IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameter');
  END IF;
  
  
  IF p_msisdn.count <> p_id.count OR
     p_id.count <> p_port_time.count THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid parameter');
  END IF;
  
  DELETE FROM TT_LRN_HIST;
  
  FOR i IN p_msisdn.first..p_msisdn.last
  LOOP
    INSERT INTO TT_LRN_HIST(ID,INTERNATIONAL_FORMAT,PORT_DATE,ERROR_CODE)
      VALUES(p_id(i),p_msisdn(i),p_port_time(i), RSIG_UTILS.c_OK);
  END LOOP;
  
  UPDATE TT_LRN_HIST t
     SET t.PORT_DATE = (SELECT /*+ index(ph I_PPH_MSISDN_PORTDATE)*/ 
                               MAX(ph.portdate) 
                          FROM PHONE_PORTING_HISTORY ph 
                         WHERE ph.msisdn = t.international_format 
                           AND ph.portdate < t.port_date)
    WHERE t.port_date IS NOT NULL;
   
  OPEN p_cursor FOR 
    SELECT /*+ ordered use_nl(tt pph) index(ph I_PPH_MSISDN_PORTDATE)*/ 
    tt.id, pph.msisdn, pph.donormnpcode, pph.recipientmnpcode, pph.routing_number, pph.portdate, pph.network_routing_number 
     FROM TT_LRN_HIST tt 
     JOIN PHONE_PORTING_HISTORY pph ON pph.portdate = tt.port_date AND pph.msisdn = tt.international_format;
    
  
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
  
  EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      p_error_code    := RSIG_UTILS.Handle_Error(SQLCODE);
      p_error_message := sqlerrm;
      RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;

END get_lrn_for_numbers;

end;
/
