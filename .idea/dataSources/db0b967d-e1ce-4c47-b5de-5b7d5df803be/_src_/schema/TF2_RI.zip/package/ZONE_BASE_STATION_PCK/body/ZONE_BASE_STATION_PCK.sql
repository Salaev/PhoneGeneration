CREATE PACKAGE BODY ZONE_BASE_STATION_PCK IS

----------------------------------!---------------------------------------------
PROCEDURE Get_Zone_Base_Station
(
  error_code         OUT NUMBER,
  p_start_date       IN DATE,
  p_end_date         IN DATE,
  p_bsc_list         IN t_BSC,
  p_result           OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'ZONE_BASE_STATION_PCK.Get_Zone_Base_Station';
  v_start_date   DATE;

  -- all individual relations to zones where also exist global relation to zone
  CURSOR c_bs IS
  SELECT zbs.base_station_id,
         zbs.zone_id,
         zbs.location_area_id,
         zt.zone_type_code,
         zbs.start_date,
         zbs.end_date
  FROM tt_batch_base_station tt
  JOIN base_station bs ON bs.base_station_code=tt.base_station_code
       AND (bs.deleted IS NULL OR bs.deleted>v_start_date)
  JOIN location_area la ON la.location_area_id=bs.location_area_id
       AND (la.deleted IS NULL OR la.deleted>v_start_date)
  JOIN zone_base_station zbs ON (zbs.base_station_id=bs.base_station_id
      AND zbs.msc_id IS NULL
      AND zbs.network_operator_id IS NULL)
  JOIN zone_type zt ON zt.ZONE_TYPE_code = zbs.zone_type_code
  WHERE (zbs.end_date>=v_start_date OR zbs.end_date IS NULL)
    AND (zbs.start_date<=p_end_date OR p_end_date IS NULL)
    AND (zt.DELETED IS NULL OR zt.deleted > v_start_date)
    AND EXISTS(SELECT 1
               FROM zone_base_station zbsl
               WHERE zbsl.location_area_id=zbs.location_area_id
                 AND zbsl.base_station_id IS NULL
                  AND zbsl.msc_id IS NULL
                  AND zbsl.network_operator_id IS NULL)
  ORDER BY zbs.base_station_id,zbs.start_date;

  v_last_row            c_bs%ROWTYPE;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_bsc_list IS NULL OR 
     p_bsc_list.COUNT = 0 OR
     (p_bsc_list.COUNT = 1 AND p_bsc_list(p_bsc_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  -- set current start date when p_start_date is null
  v_start_date := nvl(p_start_date, SYSDATE);

 --------------------------------------------------------------------------------------------------------------------------
  IF v_start_date > p_end_date THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_INTERVAL, '');
  END IF;

  IF v_start_date < RSIG_UTILS.c_MIN_DATE
     OR (p_end_date < RSIG_UTILS.c_MIN_DATE AND p_end_date IS NOT NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;


  DELETE FROM tt_batch_base_station;
  DELETE FROM tt_zone_base_station;

  FORALL i IN nvl(p_bsc_list.FIRST, 1) .. nvl(p_bsc_list.LAST, 0)
  INSERT INTO tt_batch_base_station(base_station_code)
  VALUES(p_bsc_list(i));

  -- insert individual intervals for base stations -------------------------------------------------
  INSERT INTO tt_zone_base_station(zone_id,base_station_id,start_date,end_date)
  SELECT /*+ ORDERED USE_NL(tt bs zbs la) */
         zbs.zone_id,
         zbs.base_station_id,
         zbs.start_date,
         zbs.end_date
  from tt_batch_base_station tt
  join BASE_STATION bs on bs.BASE_STATION_CODE = tt.base_station_code
  join ZONE_BASE_STATION zbs on (zbs.BASE_STATION_ID = bs.BASE_STATION_ID
                                  AND zbs.msc_id IS NULL
                                  AND zbs.network_operator_id IS NULL)
  JOIN location_area la ON la.location_area_id=bs.location_area_id
  JOIN ZONE z ON z.zone_id = zbs.zone_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code = z.zone_type_code
  WHERE (bs.DELETED is NULL OR bs.deleted > v_start_date)
       AND (z.deleted IS NULL OR z.deleted > v_start_date)
       AND (zbs.end_date>=v_start_date OR zbs.end_date IS NULL)
       AND (zbs.start_date<=p_end_date OR p_end_date IS NULL)
       AND (zt.DELETED IS NULL OR zt.deleted > v_start_date);


  -- insert global intervals for location areas where does not exist individual interval -----------
  INSERT INTO tt_zone_base_station(zone_id,base_station_id,start_date,end_date)
  SELECT /*+ ORDERED USE_NL(tt bs zbs la) */
         zbs.zone_id,
         bs.base_station_id,
         zbs.start_date,
         zbs.end_date
  FROM tt_batch_base_station tt
  JOIN base_station bs ON bs.base_station_code=tt.base_station_code
  JOIN location_area la ON la.location_area_id=bs.location_area_id
  JOIN zone_base_station zbs ON (zbs.location_area_id=la.location_area_id
                                  AND zbs.msc_id IS NULL
                                  AND zbs.network_operator_id IS NULL)
  JOIN ZONE z ON z.zone_id = zbs.zone_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code = z.zone_type_code
  WHERE zbs.base_station_id IS NULL
    AND (la.DELETED is NULL OR la.deleted > v_start_date)
    AND (bs.DELETED is NULL OR bs.deleted > v_start_date)
    AND (z.deleted IS NULL OR z.deleted > v_start_date)
    AND (zbs.end_date>=v_start_date OR zbs.end_date IS NULL)
    AND (zbs.start_date<=p_end_date OR p_end_date IS NULL)
    AND (zt.DELETED IS NULL OR zt.deleted > v_start_date)
    AND NOT EXISTS(SELECT 1
                   FROM zone_base_station zbsl
                   WHERE zbsl.base_station_id=bs.base_station_id
                    AND zbsl.msc_id IS NULL
                    AND zbsl.network_operator_id IS NULL);


  -- merge individual and global intervals --------------------------------------------------------
  FOR v_row IN c_bs LOOP
    IF v_row.base_station_id<>v_last_row.base_station_id OR v_last_row.base_station_id IS NULL THEN
    -- first loop for the base station
      -- fill location area intervals at the begining
      Insert_LA_zone_intervals(p_location_area_id => v_row.location_area_id,
                                 p_base_station_id => v_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => v_start_date,
                                 p_end_date => v_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE);

      IF v_last_row.end_date IS NOT NULL AND (v_last_row.end_date<p_end_date OR p_end_date IS NULL) THEN
        -- fill location area intervals at the end
        Insert_LA_zone_intervals(p_location_area_id => v_last_row.location_area_id,
                                 p_base_station_id => v_last_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                                 p_end_date => p_end_date);

      END IF;

    ELSE
      IF v_last_row.end_date + rsig_utils.c_INTERVAL_DIFFERENCE <> v_row.start_date  THEN
        Insert_LA_zone_intervals(p_location_area_id => v_row.location_area_id,
                                 p_base_station_id => v_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                                 p_end_date => v_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE);
      END IF;
    END IF;

    v_last_row:=v_row;

  END LOOP;

  IF v_last_row.end_date IS NOT NULL AND (v_last_row.end_date<p_end_date OR p_end_date IS NULL) THEN
    -- last interval
    Insert_LA_zone_intervals(p_location_area_id => v_last_row.location_area_id,
                             p_base_station_id => v_last_row.base_station_id,
                             p_zone_type_id => v_last_row.zone_type_code,
                             p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                             p_end_date => p_end_date);
  END IF;
  --------------------------------------------------------------------------------------------------


  OPEN p_result FOR
  SELECT bs.base_station_code,
         z.zone_code,
         t.start_date,
         t.end_date
  FROM tt_zone_base_station t
  JOIN base_station bs ON t.base_station_id=bs.base_station_id
  JOIN ZONE z ON z.zone_id=t.zone_id
  ORDER BY bs.base_station_code,t.start_date;

--------------------------------------------------------------------------------------------------------------------------
  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN p_result FOR
      select error_code from dual;
END;

----------------------------------!---------------------------------------------
PROCEDURE Get_Zone_Base_Station_All
(
  ERROR_CODE           OUT NUMBER,
  p_result             OUT RSIG_UTILS.REF_CURSOR
)
IS
  v_event_source       VARCHAR2(60) := 'ZONE_BASE_STATION_PCK.Get_Zone_Base_Station_All';

  -- all individual relations to zones where also exist global relation to zone
  CURSOR c_bs IS
  SELECT zbs.base_station_id,
         zbs.zone_id,
         zbs.location_area_id,
         zt.ZONE_TYPE_code,
         zbs.start_date,
         zbs.end_date
  FROM zone_base_station zbs
  JOIN zone_type zt ON zt.ZONE_TYPE_code = zbs.zone_type_code
  WHERE zbs.base_station_id IS NOT NULL
    AND zbs.msc_id IS NULL
    AND zbs.network_operator_id IS NULL
    AND EXISTS(SELECT 1
               FROM zone_base_station zbsl
               WHERE zbsl.location_area_id=zbs.location_area_id
                 AND zbsl.base_station_id IS NULL
                 AND zbsl.msc_id IS NULL
                 AND zbsl.network_operator_id IS NULL)
  ORDER BY zbs.base_station_id,zbs.start_date;


  v_last_row            c_bs%ROWTYPE;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);


  DELETE FROM tt_zone_base_station;

  -- insert individual intervals for base stations -------------------------------------------------
  INSERT INTO tt_zone_base_station(zone_id,base_station_id,start_date,end_date)
  SELECT zbs.zone_id,
         zbs.base_station_id,
         zbs.start_date,
         zbs.end_date
  FROM zone_base_station zbs
  WHERE zbs.base_station_id IS NOT NULL
      AND zbs.msc_id IS NULL
      AND zbs.network_operator_id IS NULL;

  -- insert global intervals for location areas where does not exist individual interval -----------
  INSERT INTO tt_zone_base_station(zone_id,base_station_id,start_date,end_date)
  SELECT zbs.zone_id,
         bs.base_station_id,
         zbs.start_date,
         zbs.end_date
  FROM zone_base_station zbs
  JOIN base_station bs ON bs.location_area_id=zbs.location_area_id
  WHERE zbs.base_station_id IS NULL
      AND zbs.msc_id IS NULL
      AND zbs.network_operator_id IS NULL
    AND NOT EXISTS(SELECT 1
                   FROM zone_base_station zbsl
                   WHERE zbsl.base_station_id=bs.base_station_id
                      AND zbsl.msc_id IS NULL
                      AND zbsl.network_operator_id IS NULL);



  -- merge individual and global intervals --------------------------------------------------------
  FOR v_row IN c_bs LOOP
    IF v_row.base_station_id<>v_last_row.base_station_id OR v_last_row.base_station_id IS NULL THEN
    -- first loop for the base station
      -- fill location area intervals at the begining
      Insert_LA_zone_intervals(p_location_area_id => v_row.location_area_id,
                                 p_base_station_id => v_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => NULL,
                                 p_end_date => v_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE);

      IF v_last_row.end_date IS NOT NULL THEN
        -- fill location area intervals at the end
        Insert_LA_zone_intervals(p_location_area_id => v_last_row.location_area_id,
                                 p_base_station_id => v_last_row.base_station_id,
                                 p_zone_type_id => v_last_row.zone_type_code,
                                 p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                                 p_end_date => NULL);

      END IF;

    ELSE
      IF v_last_row.end_date + rsig_utils.c_INTERVAL_DIFFERENCE <> v_row.start_date  THEN
        Insert_LA_zone_intervals(p_location_area_id => v_row.location_area_id,
                                 p_base_station_id => v_row.base_station_id,
                                 p_zone_type_id => v_last_row.zone_type_code,
                                 p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                                 p_end_date => v_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE);
      END IF;
    END IF;

    v_last_row:=v_row;

  END LOOP;

  IF v_last_row.end_date IS NOT NULL THEN
    -- last interval
    Insert_LA_zone_intervals(p_location_area_id => v_last_row.location_area_id,
                             p_base_station_id => v_last_row.base_station_id,
                             p_zone_type_id => v_last_row.zone_type_code,
                             p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                             p_end_date => NULL);
  END IF;
  --------------------------------------------------------------------------------------------------

  OPEN p_result FOR
  SELECT bs.base_station_code,
         z.zone_id,
         t.start_date,
         t.end_date,
         z.zone_code,
         la.location_area_code
  FROM tt_zone_base_station t
  JOIN base_station bs ON t.base_station_id=bs.base_station_id
  JOIN location_area la ON la.location_area_id=bs.location_area_id
  JOIN ZONE z ON z.zone_id=t.zone_id
  ORDER BY t.base_station_id,t.start_date;

  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN p_result FOR
      SELECT ERROR_CODE FROM dual;
END;

----------------------------------!---------------------------------------------
PROCEDURE Get_Zone_Base_Station_LAC
(
  p_msc_list               IN  t_MSC,
  p_bsc_list               IN  t_BSC,
  p_lac_list               IN  t_BSC,
  p_start_date             IN  DATE,
  p_end_date               IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60);
  v_package_name          VARCHAR2(30) := 'ZONE_BASE_STATION_PCK';
  v_procedure_name        VARCHAR2(30) := 'Get_Zone_Base_Station_LAC';
  v_message               VARCHAR2(32767);
  v_start_date             DATE;
  
  v_BSC_LAC_MSC_OBJ        t_BSC_LAC_MSC_obj:=t_BSC_LAC_MSC_obj(NULL,NULL,NULL);
  v_BSC_LAC_MSC_list			  t_BSC_LAC_MSC_obj_tab:= t_BSC_LAC_MSC_obj_tab();

  -- all individual relations to zones where also exist global relation to zone
  CURSOR c_bs IS
  SELECT /*+ ORDERED USE_NL(tt bs zbs la) index(bs I_BASSTA_CODE)*/
         zbs.base_station_id,
         zbs.zone_id,
         zbs.location_area_id,
         zt.zone_type_code,
         zbs.start_date,
         zbs.end_date
  FROM TABLE(CAST(v_BSC_LAC_MSC_list AS t_BSC_LAC_MSC_obj_tab)) tt
  JOIN base_station bs ON bs.base_station_code = tt.base_station_code
       AND (bs.deleted IS NULL OR bs.deleted>v_start_date)
  JOIN location_area la ON la.location_area_id=bs.location_area_id
       AND (la.deleted IS NULL OR la.deleted>v_start_date)
  JOIN zone_base_station zbs ON (zbs.base_station_id=bs.base_station_id
                                  AND zbs.msc_id IS NULL
                                  AND zbs.network_operator_id IS NULL)
  JOIN host h ON h.host_id=la.host_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code = zbs.zone_type_code
  WHERE la.location_area_code=tt.location_area_code
    AND h.host_code=tt.msc_code
    AND (zbs.end_date>=v_start_date OR zbs.end_date IS NULL)
    AND (zbs.start_date<=p_end_date OR p_end_date IS NULL)
    AND (zt.DELETED IS NULL OR zt.deleted > v_start_date)
    AND EXISTS(SELECT 1
               FROM zone_base_station zbsl
               WHERE zbsl.location_area_id=zbs.location_area_id
                 AND zbsl.zone_type_code = zbs.zone_type_code
                 AND zbsl.base_station_id IS NULL
                 AND zbsl.msc_id IS NULL
                 AND zbsl.network_operator_id IS NULL)
  ORDER BY zbs.base_station_id,zbs.start_date;

  v_last_row            c_bs%ROWTYPE;
BEGIN
	v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:'
                || chr(10) ||'p_msc_listm ' || p_msc_list.COUNT
                || chr(10) ||'p_bsc_list ' || p_bsc_list.COUNT
		            || chr(10) ||'p_lac_list ' || p_lac_list.COUNT;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  IF p_bsc_list IS NULL OR 
     p_bsc_list.COUNT = 0 OR
     (p_bsc_list.COUNT = 1 AND p_bsc_list(p_bsc_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF; 

  IF p_lac_list IS NULL OR 
     p_lac_list.COUNT = 0 OR
     (p_lac_list.COUNT = 1 AND p_lac_list(p_lac_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF; 

  IF p_msc_list IS NULL OR 
     p_msc_list.COUNT = 0 OR
     (p_msc_list.COUNT = 1 AND p_msc_list(p_msc_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF; 

  IF p_bsc_list.COUNT <> p_lac_list.COUNT AND 
     p_bsc_list.COUNT <> p_msc_list.COUNT
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  v_start_date := nvl(p_start_date, SYSDATE);

  IF v_start_date > p_end_date THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_INTERVAL, '');
  END IF;

-- start of the procedure body --------------------------------------------------------------------------------------------------

  DELETE FROM tt_zone_base_station;

  -- fill input data to temporary table
   FOR i IN nvl(p_bsc_list.FIRST, 1) .. nvl(p_bsc_list.LAST, 0)
  loop 
    v_BSC_LAC_MSC_OBJ:=t_BSC_LAC_MSC_obj(p_bsc_list(i),p_lac_list(i),p_msc_list(i));
    v_BSC_LAC_MSC_list.extend; 
    v_BSC_LAC_MSC_list(i):=v_BSC_LAC_MSC_OBJ; 
  end loop;

  -- insert individual intervals for base stations -------------------------------------------------
  INSERT INTO tt_zone_base_station(zone_id,base_station_id,start_date,end_date,zone_type_id)
  SELECT /*+ ORDERED USE_NL(tt bs zbs la) index(bs I_BASSTA_CODE)*/
         zbs.zone_id,
         zbs.base_station_id,
         zbs.start_date,
         zbs.end_date,
         zbs.zone_type_code
  from TABLE(CAST(v_BSC_LAC_MSC_list AS t_BSC_LAC_MSC_obj_tab)) tt
  join BASE_STATION bs on bs.BASE_STATION_CODE = tt.base_station_code
  join ZONE_BASE_STATION zbs on (zbs.BASE_STATION_ID = bs.BASE_STATION_ID
                                 AND zbs.msc_id IS NULL
                                 AND zbs.network_operator_id IS NULL)
  JOIN location_area la ON la.location_area_id=bs.location_area_id
  JOIN ZONE z ON z.zone_id = zbs.zone_id
  JOIN host h ON h.host_id=la.host_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code = zbs.zone_type_code
  WHERE la.location_area_code=tt.location_area_code
       AND h.host_code=tt.msc_code
       AND (bs.DELETED is NULL OR bs.deleted > v_start_date)
       AND (z.deleted IS NULL OR z.deleted > v_start_date)
       AND (zt.DELETED IS NULL OR zt.deleted > v_start_date)
       AND (zbs.end_date>=v_start_date OR zbs.end_date IS NULL)
       AND (zbs.start_date<=p_end_date OR p_end_date IS NULL);

  -- insert global intervals for location areas where does not exist individual interval -----------
  INSERT INTO tt_zone_base_station(zone_id,base_station_id,start_date,end_date,zone_type_id)
  SELECT /*+ ORDERED USE_NL(TT BS LA ZBS) index(bs I_BASSTA_CODE) */
         zbs.zone_id,
         bs.base_station_id,
         zbs.start_date,
         zbs.end_date,
         zbs.zone_type_code
  FROM TABLE(CAST(v_BSC_LAC_MSC_list AS t_BSC_LAC_MSC_obj_tab)) tt
  JOIN location_area la ON la.location_area_code=tt.location_area_code
  JOIN zone_base_station zbs ON (zbs.location_area_id=la.location_area_id
                                 AND zbs.msc_id IS NULL
                                 AND zbs.network_operator_id IS NULL)
  JOIN base_station bs ON bs.base_station_code LIKE tt.base_station_code
        AND bs.location_area_id=la.location_area_id
  JOIN ZONE z ON z.zone_id = zbs.zone_id
  JOIN host h ON h.host_id=la.host_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code = zbs.zone_type_code
  WHERE zbs.base_station_id IS NULL
    AND h.host_code=tt.msc_code
    AND (la.DELETED is NULL OR la.deleted > v_start_date)
    AND (z.deleted IS NULL OR z.deleted > v_start_date)
    AND (zt.DELETED IS NULL OR zt.deleted > v_start_date)
    AND (bs.deleted IS NULL OR bs.deleted > v_start_date)
    AND (zbs.end_date>=v_start_date OR zbs.end_date IS NULL)
    AND (zbs.start_date<=p_end_date OR p_end_date IS NULL)
    AND NOT EXISTS(SELECT 1
                   FROM zone_base_station zbsl
                   WHERE zbsl.base_station_id=bs.base_station_id
                     AND zbsl.zone_type_code = zbs.zone_type_code
                     AND (zbsl.end_date>=v_start_date OR zbsl.end_date IS NULL)
                     AND (zbsl.start_date<=p_end_date OR p_end_date IS NULL)
                     AND zbsl.msc_id IS NULL
                     AND zbsl.network_operator_id IS NULL);

  -- merge individual and global intervals --------------------------------------------------------
  FOR v_row IN c_bs LOOP
    IF v_row.base_station_id<>v_last_row.base_station_id OR v_last_row.base_station_id IS NULL THEN
    -- first loop for the base station
      -- fill location area intervals at the begining
      Insert_LA_zone_intervals(p_location_area_id => v_row.location_area_id,
                                 p_base_station_id => v_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => v_start_date,
                                 p_end_date => v_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE);

      IF v_last_row.end_date IS NOT NULL AND (v_last_row.end_date<p_end_date OR p_end_date IS NULL) THEN
        -- fill location area intervals at the end
        Insert_LA_zone_intervals(p_location_area_id => v_last_row.location_area_id,
                                 p_base_station_id => v_last_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                                 p_end_date => p_end_date);

      END IF;

    ELSE
      IF v_last_row.end_date + rsig_utils.c_INTERVAL_DIFFERENCE <> v_row.start_date  THEN
        Insert_LA_zone_intervals(p_location_area_id => v_row.location_area_id,
                                 p_base_station_id => v_row.base_station_id,
                                 p_zone_type_id => v_row.zone_type_code,
                                 p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                                 p_end_date => v_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE);
      END IF;
    END IF;

    v_last_row:=v_row;

  END LOOP;

  IF v_last_row.end_date IS NOT NULL AND (v_last_row.end_date<p_end_date OR p_end_date IS NULL) THEN
    -- last interval
    Insert_LA_zone_intervals(p_location_area_id => v_last_row.location_area_id,
                             p_base_station_id => v_last_row.base_station_id,
                             p_zone_type_id => v_last_row.zone_type_code,
                             p_start_date => v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE,
                             p_end_date => p_end_date);
  END IF;
  --------------------------------------------------------------------------------------------------


  OPEN result_list FOR
  SELECT h.host_code,
         la.location_area_code,
         bs.base_station_code,
         z.zone_code,
         zt.ZONE_TYPE_CODE,
         t.start_date,
         t.end_date
  FROM tt_zone_base_station t
  JOIN base_station bs ON t.base_station_id=bs.base_station_id
  JOIN location_area la ON la.location_area_id=bs.location_area_id
  JOIN ZONE z ON z.zone_id=t.zone_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code = t.zone_type_id
  JOIN host h ON h.host_id=la.host_id
  ORDER BY bs.base_station_code,t.start_date;


-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  p_error_code := RSIG_UTILS.c_OK;
-- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
  p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
  p_error_message := SQLERRM;
	 OPEN result_list FOR SELECT v_sqlcode,p_error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END;

----------------------------------!---------------------------------------------
PROCEDURE Insert_LA_zone_intervals
(
  p_location_area_id    IN  location_area.location_area_id%TYPE,
  p_base_station_id     IN  base_station.base_station_id%TYPE,
  p_zone_type_id        IN  Zone_Base_Station.ZONE_TYPE_code%TYPE,
  p_start_date          IN  DATE,
  p_end_date            IN  DATE
)
IS
BEGIN
 INSERT INTO TT_ZONE_BASE_STATION (zone_id,base_station_id,location_area_id,start_date,end_date,zone_type_id)
  SELECT *
  FROM(SELECT zbs.zone_id,
              p_base_station_id base_station_id,
              p_location_area_id,
              CASE WHEN zbs.start_date<p_start_date THEN
                p_start_date ELSE zbs.start_date
              END start_date,
              CASE WHEN zbs.end_date>=p_end_date OR (p_end_date IS NOT NULL AND zbs.end_date IS NULL) THEN
                p_end_date ELSE zbs.end_date
              END end_date,
              zbs.zone_type_code
       FROM Zone_Base_Station zbs
       JOIN zone_type zt ON zt.ZONE_TYPE_code = zbs.zone_type_code
       WHERE zbs.location_area_id=p_location_area_id
         AND zt.zone_type_code = p_zone_type_id
         AND zbs.base_station_id IS NULL
         AND (zbs.end_date>=p_start_date OR zbs.end_date IS NULL OR p_start_date IS NULL)
         AND (zbs.start_date<=p_end_date OR p_end_date IS NULL)
         AND zbs.msc_id IS NULL
         AND zbs.network_operator_id IS NULL) l
  WHERE (l.end_date>l.start_date OR l.end_date IS NULL);


END;

----------------------------------!---------------------------------------------
PROCEDURE Insert_Zone_Base_Station
(
  p_location_area_id    IN  location_area.location_area_id%TYPE,
  p_base_station_id     IN  base_station.base_station_id%TYPE,
  p_zone_id             IN  zone.ZONE_ID%TYPE,
  p_start_date          IN  DATE,
  p_user_id_of_change   IN  NUMBER,
  p_handle_tran	        IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error         IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code          OUT NUMBER,
  p_error_message       OUT VARCHAR2
) IS
--v_zone_type_id          NUMBER;
v_zone_type_id          zone.ZONE_TYPE_CODE%TYPE;
v_event_source          varchar2(60);
v_package_name          VARCHAR2(30) := 'ZONE_BASE_STATION_PCK';
v_procedure_name        VARCHAR2(30) := 'Insert_zone_base_station';
v_start_date            DATE := NVL(p_start_date,SYSDATE);
BEGIN
v_event_source:=v_package_name || '.' || v_procedure_name;
RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
--------------------------------------------------------------------------------------------------
SELECT zone_type_code INTO v_zone_type_id
   FROM zone
  WHERE zone_id = p_zone_id;

 -- insert relation to zone
    INSERT INTO Zone_Base_Station
          (Zone_Base_Station_Id,
           Zone_Id,
           Location_Area_Id,
           Base_Station_Id,
           zone_type_code,
           Start_Date,
           End_Date,
           Date_Of_Change,
           User_Id_Of_Change,
           MSC_ID,
           Network_Operator_id)
    VALUES(s_zone_base_station.nextval,
           p_zone_id,
           p_location_area_id,
           p_base_station_id,
           v_zone_type_id,
           v_start_date,
           NULL,
           SYSDATE,
           p_user_id_of_change,
           NULL,
           NULL);


-- end of the procedure body ----------------------------------------------------------------------------------------------------
 IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

 p_ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    p_ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
    p_error_message := SQLERRM;
    RSIG_UTILS.Debug_Rsi(TO_CHAR(p_ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);

		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END;

----------------------------------!---------------------------------------------
PROCEDURE Close_Zone_Base_Station_Int
(
  p_zone_base_station_id  IN  zone.ZONE_ID%TYPE,
  p_user_id_of_change   IN  NUMBER,
  p_handle_tran	        IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error         IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code          OUT NUMBER,
  p_error_message       OUT VARCHAR2
) IS
v_event_source          varchar2(60);
v_package_name          VARCHAR2(30) := 'ZONE_BASE_STATION_PCK';
v_procedure_name        VARCHAR2(30) := 'Close_Zone_Base_Station_Int';
BEGIN
v_event_source:=v_package_name || '.' || v_procedure_name;
RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
--------------------------------------------------------------------------------------------------

UPDATE zone_base_station
  SET end_date = SYSDATE,
      date_of_change = SYSDATE,
      user_id_of_change = p_user_id_of_change
 WHERE zone_base_station_id = p_zone_base_station_id;


-- end of the procedure body ----------------------------------------------------------------------------------------------------
IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
END IF;

 p_ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    p_ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
    p_error_message := SQLERRM;
    RSIG_UTILS.Debug_Rsi(TO_CHAR(p_ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END;

----------------------------------!---------------------------------------------
PROCEDURE GetZonesForBaseStations_old1
(
  p_id_l util_pkg.cit_number,
  p_msc_l util_pkg.cit_varchar_s,
  p_lac_l util_pkg.cit_varchar_s,
  p_cellid_l util_pkg.cit_varchar_s,
  p_Validity_Date_l util_pkg.cit_date,
  p_raise_error CHAR DEFAULT rsig_utils.c_NO,
  p_error_code OUT NUMBER,
  p_error_message OUT VARCHAR2,
  p_result_list OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'ZONE_BASE_STATION_PCK';
  v_procedure_name        VARCHAR2(30) := 'GetZonesForBaseStations00';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(32767);
  v_id                    common.t_number;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_id_l: ' || p_msc_l.COUNT || chr(10) ||
              'p_msc_l: ' || p_msc_l.COUNT || chr(10) ||
              'p_lac_l: ' || p_lac_l.COUNT || chr(10) ||
              'p_cellid_l: ' || p_cellid_l.COUNT || chr(10) ||
              'p_Validity_Date_l: ' || p_Validity_Date_l.COUNT;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF p_id_l IS NULL OR 
     p_id_l.COUNT = 0 OR
     (p_id_l.COUNT = 1 AND p_id_l(p_id_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters');
  END IF; 
  
  IF p_msc_l IS NULL OR 
     p_msc_l.COUNT = 0 OR
     (p_msc_l.COUNT = 1 AND p_msc_l(p_msc_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters');
  END IF; 

  IF p_lac_l IS NULL OR 
     p_lac_l.COUNT = 0 OR
     (p_lac_l.COUNT = 1 AND p_lac_l(p_lac_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters');
  END IF; 

  IF p_cellid_l IS NULL OR 
     p_cellid_l.COUNT = 0 OR
     (p_cellid_l.COUNT = 1 AND p_cellid_l(p_cellid_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters');
  END IF; 
  
  IF p_Validity_Date_l IS NULL OR 
     p_Validity_Date_l.COUNT = 0 OR
     (p_Validity_Date_l.COUNT = 1 AND p_Validity_Date_l(p_Validity_Date_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters');
  END IF;   
  
  IF p_msc_l.COUNT <> p_lac_l.COUNT OR
     p_msc_l.COUNT <> p_cellid_l.COUNT OR
     p_msc_l.COUNT <> p_Validity_Date_l.COUNT OR
     p_msc_l.COUNT <> p_id_l.COUNT
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;
 
---------------------------------------------------------------------------------------------------------
  DELETE FROM tt_batch_base_station;

  -- row ID
  FOR i IN nvl(p_cellid_l.FIRST, 1) .. nvl(p_cellid_l.LAST, 0) LOOP
    v_id(i):=i;
  END LOOP;

  -- fill input data to temporary table
  FORALL i IN nvl(p_cellid_l.FIRST, 1) .. nvl(p_cellid_l.LAST, 0)
  INSERT INTO tt_batch_base_station(row_id,base_station_code,location_area_code,MSC_CODE,validity_date, id)
  VALUES(v_id(i),trim(p_cellid_l(i)),p_lac_l(i),trim(p_msc_l(i)),nvl(p_Validity_Date_l(i),SYSDATE), p_id_l(i));

  -- get host_ID
  UPDATE tt_batch_base_station t
  SET t.host_id=(SELECT h.host_id
                 FROM host h
                 WHERE h.host_code=t.msc_code
                   AND h.deleted IS NULL);

  -- get LAC ID of normal LAC
  UPDATE tt_batch_base_station t
  SET t.location_area_id=(SELECT la.location_area_id
                          FROM location_area PARTITION(N) la
                          WHERE la.deleted IS NULL
                            AND la.location_area_code=t.location_area_code
                            AND (la.host_id=t.host_id OR t.host_id IS NULL)
                            AND la.generalization='N'
                            AND rownum=1);

  -- get LAC ID of general LAC
  UPDATE tt_batch_base_station t
  SET t.location_area_id=(SELECT s.location_area_id
                          FROM(SELECT la.location_area_id,
                                      tt.ROWID ttrowid
                               FROM location_area PARTITION(Y) la
                               JOIN tt_batch_base_station tt ON tt.location_area_code LIKE la.location_area_code
                               WHERE la.deleted IS NULL
                                 AND tt.location_area_id IS NULL
                                 AND la.generalization='Y'
                                 AND (tt.host_id=la.host_id OR tt.host_id IS NULL)
                               ORDER BY la.host_id,
                                         length(la.location_area_code) DESC,
                                         (instr(la.location_area_code,'%')+instr(la.location_area_code,'_'))) s
                          WHERE s.ttrowid=t.ROWID
                            AND rownum=1)
   WHERE t.location_area_id IS NULL;


  -- get CELL ID of normal base station
  UPDATE tt_batch_base_station t
  SET t.base_station_id=(SELECT bs.base_station_id
                         FROM base_station PARTITION(N) bs
                         WHERE bs.deleted IS NULL
                           AND bs.base_station_code=t.base_station_code
                           AND (t.location_area_id=bs.location_area_id OR t.location_area_id IS NULL)
                           AND bs.generalization='N'
                           AND rownum=1);

  -- get CELL ID of general base station
  UPDATE tt_batch_base_station t
  SET t.base_station_id=(SELECT s.base_station_id
                         FROM(SELECT bs.base_station_id,
                                     tt.ROWID ttrowid
                              FROM base_station PARTITION(Y) bs
                              JOIN tt_batch_base_station tt ON tt.base_station_code LIKE bs.base_station_code
                              WHERE bs.deleted IS NULL
                                AND tt.base_station_id IS NULL
                                AND bs.generalization='Y'
                                AND (tt.location_area_id=bs.location_area_id OR tt.location_area_id IS NULL)
                              ORDER BY bs.location_area_id,
                                        length(bs.base_station_code) DESC,
                                        (instr(bs.base_station_code,'%')+instr(bs.base_station_code,'_'))) s
                         WHERE s.ttrowid=t.ROWID
                           AND rownum=1)
  WHERE t.base_station_id IS NULL;


  -- result set
  OPEN p_result_list FOR
  SELECT s.id,
         s.msc_code,
         s.location_area_code,
         s.base_station_code,
         s.validity_date,
         to_number(z.zone_code) as zone_code,
         zt.ZONE_TYPE_CODE
  FROM(
    SELECT t.id,
           t.msc_code, -- zone for location areas
           t.location_area_code,
           t.base_station_code,
           t.validity_date,
           t.row_id,
           decode(zbsb.zone_id,NULL,zbsl.zone_id,zbsb.zone_id) zone_id
    FROM tt_batch_base_station t
    LEFT JOIN zone_base_station zbsb ON (zbsb.base_station_id=t.base_station_id 
                                          AND zbsb.msc_id IS NULL
                                          AND zbsb.network_operator_id IS NULL)
        AND t.validity_date BETWEEN zbsb.start_date AND nvl(zbsb.end_date,t.validity_date)
    LEFT JOIN zone_base_station zbsl ON zbsl.location_area_id=t.location_area_id
        AND t.validity_date BETWEEN zbsl.start_date AND nvl(zbsl.end_date,t.validity_date)
        AND zbsl.base_station_id IS NULL
        AND zbsl.msc_id IS NULL
        AND zbsl.network_operator_id IS NULL
    WHERE t.base_station_code IS NOT NULL
    UNION ALL -- zone for location areas
    SELECT t.id,
           t.msc_code,
           t.location_area_code,
           t.base_station_code,
           t.validity_date,
           t.row_id,
           zbs.zone_id
    FROM tt_batch_base_station t
    JOIN zone_base_station zbs ON zbs.location_area_id=t.location_area_id
        AND t.validity_date BETWEEN zbs.start_date AND nvl(zbs.end_date,t.validity_date)
        AND zbs.base_station_id IS NULL
        AND zbs.msc_id IS NULL
        AND zbs.network_operator_id IS NULL
    WHERE t.base_station_code IS NULL) s
  JOIN ZONE z ON z.zone_id=s.zone_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code=z.zone_type_code
  ORDER BY s.row_id;

---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END;

----------------------------------!---------------------------------------------
PROCEDURE GetZonesForBaseStations_old2
(
  p_id_l util_pkg.cit_number,
  p_msc_l util_pkg.cit_varchar_s,
  p_lac_l util_pkg.cit_varchar_s,
  p_cellid_l util_pkg.cit_varchar_s,
  p_Validity_Date_l util_pkg.cit_date,
  p_raise_error CHAR DEFAULT rsig_utils.c_NO,
  p_error_code OUT NUMBER,
  p_error_message OUT VARCHAR2,
  p_result_list OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'ZONE_BASE_STATION_PCK';
  v_procedure_name        VARCHAR2(30) := 'GetZonesForBaseStations01';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(32767);
  v_id                    common.t_number;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_msc_l: ' || p_msc_l.COUNT || chr(10) ||
              'p_lac_l: ' || p_lac_l.COUNT || chr(10) ||
              'p_cellid_l: ' || p_cellid_l.COUNT || chr(10) ||
              'p_Validity_Date_l: ' || p_Validity_Date_l.COUNT;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF p_id_l IS NULL OR 
     p_id_l.COUNT = 0 OR
     (p_id_l.COUNT = 1 AND p_id_l(p_id_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters');
  END IF; 
  
  IF p_msc_l IS NULL OR 
     p_msc_l.COUNT = 0 OR
     (p_msc_l.COUNT = 1 AND p_msc_l(p_msc_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters');
  END IF; 

  IF p_lac_l IS NULL OR 
     p_lac_l.COUNT = 0 OR
     (p_lac_l.COUNT = 1 AND p_lac_l(p_lac_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters');
  END IF; 

  IF p_cellid_l IS NULL OR 
     p_cellid_l.COUNT = 0 OR
     (p_cellid_l.COUNT = 1 AND p_cellid_l(p_cellid_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters');
  END IF; 
  
  IF p_Validity_Date_l IS NULL OR 
     p_Validity_Date_l.COUNT = 0 OR
     (p_Validity_Date_l.COUNT = 1 AND p_Validity_Date_l(p_Validity_Date_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters');
  END IF;   
  
  IF p_msc_l.COUNT <> p_lac_l.COUNT OR
     p_msc_l.COUNT <> p_cellid_l.COUNT OR
     p_msc_l.COUNT <> p_Validity_Date_l.COUNT OR
     p_msc_l.COUNT <> p_id_l.COUNT           
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;
 
---------------------------------------------------------------------------------------------------------
  DELETE FROM tt_batch_base_station;

  -- row ID
  FOR i IN nvl(p_cellid_l.FIRST, 1) .. nvl(p_cellid_l.LAST, 0) LOOP
    v_id(i):=i;
  END LOOP;

  -- fill input data to temporary table
  FORALL i IN nvl(p_cellid_l.FIRST, 1) .. nvl(p_cellid_l.LAST, 0)
  INSERT INTO tt_batch_base_station(row_id,base_station_code,location_area_code,MSC_CODE,validity_date, id)
  VALUES(v_id(i),trim(p_cellid_l(i)),p_lac_l(i),trim(p_msc_l(i)),nvl(p_Validity_Date_l(i),SYSDATE), p_id_l(i));

  -- get host_ID
  UPDATE tt_batch_base_station t
  SET t.host_id=(SELECT h.host_id
                 FROM host h
                 WHERE h.host_code=t.msc_code
                   AND h.deleted IS NULL);

  -- get LAC ID of normal LAC
  UPDATE tt_batch_base_station t
  SET t.location_area_id=(SELECT la.location_area_id
                          FROM location_area PARTITION(N) la
                          WHERE la.deleted IS NULL
                            AND la.location_area_code=t.location_area_code
                            AND la.host_id=t.host_id
                            AND la.generalization='N'
                            AND rownum=1);

  -- get LAC ID of general LAC
  UPDATE tt_batch_base_station t
  SET t.location_area_id=(SELECT s.location_area_id
                          FROM(SELECT la.location_area_id,
                                      tt.ROWID ttrowid
                               FROM location_area PARTITION(Y) la
                               JOIN tt_batch_base_station tt ON tt.location_area_code LIKE la.location_area_code
                               WHERE la.deleted IS NULL
                                 AND tt.location_area_id IS NULL
                                 AND la.generalization='Y'
                                 AND tt.host_id=la.host_id
                               ORDER BY la.host_id,
                                         length(la.location_area_code) DESC,
                                         (instr(la.location_area_code,'%')+instr(la.location_area_code,'_'))) s
                          WHERE s.ttrowid=t.ROWID
                            AND rownum=1)
   WHERE t.location_area_id IS NULL;


  -- get CELL ID of normal base station
  UPDATE tt_batch_base_station t
  SET t.base_station_id=(SELECT bs.base_station_id
                         FROM base_station PARTITION(N) bs
                         WHERE bs.deleted IS NULL
                           AND bs.base_station_code=t.base_station_code
                           AND t.location_area_id=bs.location_area_id
                           AND bs.generalization='N'
                           AND rownum=1);

  -- get CELL ID of general base station
  UPDATE tt_batch_base_station t
  SET t.base_station_id=(SELECT s.base_station_id
                         FROM(SELECT bs.base_station_id,
                                     tt.ROWID ttrowid
                              FROM base_station PARTITION(Y) bs
                              JOIN tt_batch_base_station tt ON tt.base_station_code LIKE bs.base_station_code
                              WHERE bs.deleted IS NULL
                                AND tt.base_station_id IS NULL
                                AND bs.generalization='Y'
                                AND tt.location_area_id=bs.location_area_id
                              ORDER BY bs.location_area_id,
                                        length(bs.base_station_code) DESC,
                                        (instr(bs.base_station_code,'%')+instr(bs.base_station_code,'_'))) s
                         WHERE s.ttrowid=t.ROWID
                           AND rownum=1)
  WHERE t.base_station_id IS NULL;

  -- result set
  OPEN p_result_list FOR
  SELECT /*+ ordered use_nl(s, z, zt) index_asc(z, PK_ZONE) index_asc(zt, PK_ZONE_TYPE)*/
         s.id,
         s.msc_code,
         s.location_area_code,
         s.base_station_code,
         s.validity_date,
         to_number(z.zone_code) as zone_code,
         zt.ZONE_TYPE_CODE
  FROM(
    SELECT /*+ leading(t) use_nl(t, zbsb, zbsl) index_asc(zbsb, I_ZOBASTA_BASE_STAT_ID) index_asc(zbsl, UK_ZONE_BASE_STATION)*/
           distinct
           t.id,
           t.msc_code, -- zone for location areas
           t.location_area_code,
           t.base_station_code,
           t.validity_date,
           t.row_id,
           decode(zbsb.zone_id,NULL,zbsl.zone_id,zbsb.zone_id) zone_id
    FROM tt_batch_base_station t
    LEFT JOIN zone_base_station zbsb ON (zbsb.base_station_id=t.base_station_id 
                                          AND zbsb.msc_id IS NULL
                                          AND zbsb.network_operator_id IS NULL)
        AND t.validity_date BETWEEN zbsb.start_date AND nvl(zbsb.end_date,t.validity_date)
    LEFT JOIN zone_base_station zbsl ON zbsl.location_area_id=t.location_area_id
        AND t.validity_date BETWEEN zbsl.start_date AND nvl(zbsl.end_date,t.validity_date)
        AND zbsl.base_station_id IS NULL
        AND zbsl.msc_id IS NULL
        AND zbsl.network_operator_id IS NULL
    WHERE t.base_station_code IS NOT NULL
    UNION ALL -- zone for location areas
    SELECT /*+ leading(t) use_nl(t, zbs) index_asc(zbs, UK_ZONE_BASE_STATION)*/
           distinct
           t.id,
           t.msc_code,
           t.location_area_code,
           t.base_station_code,
           t.validity_date,
           t.row_id,
           zbs.zone_id
    FROM tt_batch_base_station t
    JOIN zone_base_station zbs ON zbs.location_area_id=t.location_area_id
        AND t.validity_date BETWEEN zbs.start_date AND nvl(zbs.end_date,t.validity_date)
        AND zbs.base_station_id IS NULL
        AND zbs.msc_id IS NULL
        AND zbs.network_operator_id IS NULL
    WHERE t.base_station_code IS NULL) s
  JOIN ZONE z ON z.zone_id=s.zone_id
  JOIN zone_type zt ON zt.ZONE_TYPE_code=z.zone_type_code
  ORDER BY s.row_id;

---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END;

----------------------------------!---------------------------------------------
PROCEDURE GetZonesForBaseStations_new
(
  p_id_l util_pkg.cit_number,
  p_msc_l util_pkg.cit_varchar_s,
  p_lac_l util_pkg.cit_varchar_s,
  p_cellid_l util_pkg.cit_varchar_s,
  p_Validity_Date_l util_pkg.cit_date,
  p_raise_error CHAR DEFAULT rsig_utils.c_NO,
  p_error_code OUT NUMBER,
  p_error_message OUT VARCHAR2,
  p_result_list OUT sys_refcursor
)
IS
  v_host_lac_bs ct_host_lac_bs;
  v_res_tmp1 ct_host_lac_bs;
BEGIN
  ------------------------------
  util_pkg.XCheckP_cit_number(p_id_l, 'p_id_l', true);
  util_pkg.XCheckP_cit_varchar_s(p_msc_l, 'p_msc_l', true);
  util_pkg.XCheckP_cit_varchar_s(p_lac_l, 'p_lac_l', true);
  util_pkg.XCheckP_cit_varchar_s(p_cellid_l, 'p_cellid_l', false);
  util_pkg.XCheckP_cit_date(p_Validity_Date_l, 'p_Validity_Date_l', true);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_id_l.count <> p_msc_l.count, 'p_id_l.count <> p_msc_l.count');
  util_pkg.XCheck_Cond_Invalid(p_id_l.count <> p_lac_l.count, 'p_id_l.count <> p_lac_l.count');
  util_pkg.XCheck_Cond_Invalid(p_id_l.count <> p_cellid_l.count, 'p_id_l.count <> p_cellid_l.count');
  util_pkg.XCheck_Cond_Invalid(p_id_l.count <> p_Validity_Date_l.count, 'p_id_l.count <> p_Validity_Date_l.count');
  ------------------------------
  v_host_lac_bs := ct_host_lac_bs();
  v_host_lac_bs.extend(p_id_l.count);
  for i in 1..p_id_l.count
  loop
    v_host_lac_bs(i) := ot_host_lac_bs(p_id_l(i), null, p_msc_l(i), null, null, p_lac_l(i), null, null, p_cellid_l(i), null, p_Validity_Date_l(i), null, null, null, null, i);
  end loop;
  ------------------------------
  v_res_tmp1 := hlb_pkg.get_host_for_host_lac_bs(v_host_lac_bs, true);
  ------------------------------
  v_res_tmp1 := hlb_pkg.get_la_for_host_lac_bs(v_res_tmp1, true);
  ------------------------------
  v_res_tmp1 := hlb_pkg.get_bs_for_host_lac_bs(v_res_tmp1, false);
  ------------------------------
  v_res_tmp1 := hlb_pkg.get_zbs_for_host_lac_bs(v_res_tmp1, true);
  ------------------------------
  v_res_tmp1 := hlb_pkg.get_zone_result(v_host_lac_bs, v_res_tmp1, true);
  ------------------------------
  get_result_cursor01(v_res_tmp1, p_result_list);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if upper(p_raise_error)=rsig_utils.c_yes then
    raise;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
PROCEDURE GetZonesForBaseStations
(
  p_id_l util_pkg.cit_number,
  p_msc_l util_pkg.cit_varchar_s,
  p_lac_l util_pkg.cit_varchar_s,
  p_cellid_l util_pkg.cit_varchar_s,
  p_Validity_Date_l util_pkg.cit_date,
  p_raise_error CHAR DEFAULT rsig_utils.c_NO,
  p_error_code OUT NUMBER,
  p_error_message OUT VARCHAR2,
  p_result_list OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'ZONE_BASE_STATION_PCK';
  v_procedure_name        VARCHAR2(30) := 'GetZonesForBaseStations';
  v_message               VARCHAR2(32767);
  v_num number;

BEGIN

  v_message:= 'Input parameters:' || chr(10) ||
              'p_msc_l: ' || p_msc_l.COUNT || chr(10) ||
              'p_lac_l: ' || p_lac_l.COUNT || chr(10) ||
              'p_cellid_l: ' || p_cellid_l.COUNT || chr(10) ||
              'p_Validity_Date_l: ' || p_Validity_Date_l.COUNT;

  begin
      v_num := nvl(to_number(RSIG_UTILS.get_ri_setting('GetZonesForBaseStations_Version', '0')), 0);
  exception
  when others then
      v_num := 0;
  end;

  if v_num = 1 then
    GetZonesForBaseStations_old1(
  p_id_l                   => p_id_l,
  p_msc_l                  => p_msc_l,
  p_lac_l                  => p_lac_l,
  p_cellid_l               => p_cellid_l,
  p_Validity_Date_l        => p_Validity_Date_l,
  p_raise_error            => p_raise_error,
  p_error_code             => p_error_code,
  p_error_message          => p_error_message,
  p_result_list            => p_result_list
    );
  elsif v_num = 2 then
    GetZonesForBaseStations_old2(
  p_id_l                   => p_id_l,
  p_msc_l                  => p_msc_l,
  p_lac_l                  => p_lac_l,
  p_cellid_l               => p_cellid_l,
  p_Validity_Date_l        => p_Validity_Date_l,
  p_raise_error            => p_raise_error,
  p_error_code             => p_error_code,
  p_error_message          => p_error_message,
  p_result_list            => p_result_list
    );
  else
    GetZonesForBaseStations_new(
  p_id_l                   => p_id_l,
  p_msc_l                  => p_msc_l,
  p_lac_l                  => p_lac_l,
  p_cellid_l               => p_cellid_l,
  p_Validity_Date_l        => p_Validity_Date_l,
  p_raise_error            => p_raise_error,
  p_error_code             => p_error_code,
  p_error_message          => p_error_message,
  p_result_list            => p_result_list
    );
  end if;

  commit;

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;
    
    rollback;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END;

----------------------------------!---------------------------------------------
PROCEDURE GetMSCLACCellZones
(
  p_ValidityStartDate      IN  DATE,
  p_ValidityEndDate        IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'ZONE_BASE_STATION_PCK';
  v_procedure_name        VARCHAR2(30) := 'GetMSCLACCellZones';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(3000);
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_ValidityStartDate: ' || p_ValidityStartDate || chr(10) ||
              'p_ValidityEndDate: ' || p_ValidityEndDate;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);



  -- check input parameters
  IF p_ValidityStartDate IS NULL OR p_ValidityEndDate IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;
---------------------------------------------------------------------------------------------------------
  open p_result_list for
    select /*+ ordered driving_site(zbs)
               use_hash(zbs z la h bs zt)
               full(zbs)*/
           h.host_code  as host_code,
           h.start_date as host_start_date,
           h.end_date as host_end_date,
           la.location_area_code as location_area_code,
           la.start_date as location_area_start_date,
           la.end_date as location_area_end_date,
           bs.base_station_code as base_station_code,
           greatest(nvl(bs.start_date, p_ValidityStartDate), zbs.start_date, z.start_date, zt.start_date) as bs_zbs_start_date,
           least(nvl(bs.end_date, p_ValidityEndDate), zbs.end_date, z.end_date, zt.end_date) as bs_zbs_end_date,
           zt.zone_type_code  as zone_type_code,
           to_number(z.zone_code) as zone_code
      from (select /*+ full(t0)*/
                zone_id,
                location_area_id,
                base_station_id,
                start_date,
                nvl(t0.end_date, p_ValidityEndDate) end_date
              from zone_base_station t0
              where 1 = 1
               and (start_date between p_ValidityStartDate and p_ValidityEndDate
                    or p_ValidityStartDate between start_date and nvl(end_date, p_ValidityStartDate))) zbs
      join (select /*+ full(t1)*/
                   zone_id,
                   zone_code,
                   zone_type_code,
                   nvl(lag(deleted + util_pkg.c_second) over (partition by zone_code order by nvl(deleted, p_ValidityEndDate)), p_ValidityStartDate) start_date,
                   nvl(deleted, p_ValidityEndDate) end_date
              from zone t1 where nvl(deleted, p_ValidityEndDate) >= p_ValidityStartDate) z on z.zone_id = zbs.zone_id
      join (select /*+ full(t2)*/
                   location_area_id,
                   location_area_code,
                   host_id,
                   nvl(lag(deleted + util_pkg.c_second) over (partition by location_area_code order by nvl(deleted, p_ValidityEndDate)), p_ValidityStartDate) start_date,
                   nvl(deleted, p_ValidityEndDate) end_date
              from location_area t2 where nvl(deleted, p_ValidityEndDate) >= p_ValidityStartDate) la on la.location_area_id = zbs.location_area_id
      join (select /*+ full(t3)*/
                   host_id,
                   host_code,
                   nvl(lag(deleted + util_pkg.c_second) over (partition by host_code order by nvl(deleted, p_ValidityEndDate)), p_ValidityStartDate) start_date,
                   nvl(deleted, p_ValidityEndDate) end_date
              from host t3 where nvl(deleted, p_ValidityEndDate) >= p_ValidityStartDate) h on h.host_id = la.host_id
      join (select /*+ full(t4)*/
                   zone_type_code,
                   nvl(lag(deleted + util_pkg.c_second) over (partition by zone_type_code order by nvl(deleted, p_ValidityEndDate)), p_ValidityStartDate) start_date,
                   nvl(deleted, p_ValidityEndDate) end_date
              from zone_type t4 where nvl(deleted, p_ValidityEndDate) >= p_ValidityStartDate) zt on zt.zone_type_code = z.zone_type_code
      left join (select /*+ full(t5)*/
                        base_station_id,
                        base_station_code,
                        location_area_id,
                        nvl(lag(deleted + util_pkg.c_second) over (partition by base_station_code order by nvl(deleted, p_ValidityEndDate)), p_ValidityStartDate) start_date,
                        nvl(deleted, p_ValidityEndDate) end_date
                   from base_station t5 where nvl(deleted, p_ValidityEndDate) >= p_ValidityStartDate) bs on bs.location_area_id = la.location_area_id and bs.base_station_id = zbs.base_station_id
     where 1 = 1
     and (bs.base_station_id = zbs.base_station_id or (bs.base_station_id is null and zbs.base_station_id is null))
     and greatest(h.start_date, la.start_date, nvl(bs.start_date, p_ValidityStartDate), zbs.start_date, z.end_date, zt.start_date) <= least(h.end_date, la.end_date, nvl(bs.end_date, p_ValidityEndDate), zbs.end_date, z.end_date, zt.end_date)
  ;

---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;


    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END;

----------------------------------!---------------------------------------------
PROCEDURE GetExternalZoneBaseStation
(
  p_validitydate           IN  DATE,
  p_msc_id                 IN NUMBER,
  p_network_operator_id    IN NUMBER,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'ZONE_BASE_STATION_PCK';
  v_procedure_name        VARCHAR2(30) := 'GetExternalZoneBaseStation';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(3000);
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_validitydate: ' || p_validitydate || chr(10) ||
              'p_msc_id: ' || p_msc_id || chr(10) ||
              'p_network_operator_id: ' || p_network_operator_id;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);



  -- check input parameters
  IF p_validitydate IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  --------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
  SELECT zbs.zone_base_station_id,
         z.zone_name,
         z.zone_code,
         zt.ZONE_TYPE_NAME,
         la.location_area_code,
         bs.base_station_code,
         h.host_code,
         zbs.start_date,
         zbs.end_date
  FROM ZONE_BASE_STATION zbs
  LEFT JOIN base_station bs ON bs.base_station_id = zbs.base_station_id
  LEFT JOIN location_area la ON la.location_area_id=zbs.location_area_id
  LEFT JOIN host h ON h.host_id=la.host_id
  LEFT JOIN ZONE z ON z.zone_id=zbs.zone_id
  LEFT JOIN Zone_Type zt ON zt.zone_type_code=z.zone_type_code
  WHERE (zbs.end_date IS NULL OR p_validitydate between zbs.start_date and zbs.end_date)
  AND (bs.deleted IS NULL OR bs.deleted > p_validitydate)
  AND (la.deleted IS NULL OR la.deleted > p_validitydate)
  AND (h.deleted IS NULL OR h.deleted > p_validitydate)
  AND (z.deleted IS NULL OR z.deleted > p_validitydate)
  AND (zbs.msc_id = p_msc_id OR (p_msc_id IS NULL AND zbs.msc_id IS NULL))
  AND (zbs.network_operator_id = p_network_operator_id OR (p_network_operator_id IS NULL AND zbs.network_operator_id IS NULL))
  ORDER BY h.host_code,la.location_area_code,bs.base_station_code,zbs.start_date;

---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;


    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END;

----------------------------------!---------------------------------------------
PROCEDURE UpdateExtZoneBaseStation
(
  p_zone_base_station_id   IN  NUMBER,
  p_msc_id                 IN NUMBER,
  p_network_operator_id    IN NUMBER,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_handle_tran            IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_user_id_of_change      IN NUMBER,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2
)
IS
  v_package_name          VARCHAR2(30) := 'ZONE_BASE_STATION_PCK';
  v_procedure_name        VARCHAR2(30) := 'UpdateExtZoneBaseStation';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(3000);
  v_cnt                   NUMBER;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_zone_base_station_id: ' || p_zone_base_station_id || chr(10) ||
              'p_msc_id: ' || p_msc_id || chr(10) ||
              'p_network_operator_id: ' || p_network_operator_id|| chr(10) ||
              'p_user_id_of_change: ' || p_user_id_of_change;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (p_handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (p_handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  -- check input parameters
  IF p_zone_base_station_id IS NULL OR p_user_id_of_change IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint UpdateZoneBaseStation_a;
  END IF;

  SELECT COUNT(1) INTO v_cnt
     FROM zone_base_station zbs
     WHERE zbs.zone_base_station_id = p_zone_base_station_id;
   
  IF v_cnt = 0
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NO_DATA_FOUND, 'No data found.');
  END IF;
  --------------------------------------------------------------------------------------------------

  UPDATE zone_base_station zbs
     SET zbs.msc_id = p_msc_id,
         zbs.network_operator_id = p_network_operator_id,
         zbs.date_of_change = SYSDATE,
         zbs.user_id_of_change = p_user_id_of_change
   WHERE zbs.zone_base_station_id = p_zone_base_station_id;

  ---------------------------------------------------------------------------------------------------------

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;
  
  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    CASE p_handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint UpdateZoneBaseStation_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
    END CASE;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_result_cursor01(p_zones ct_host_lac_bs, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
  select /*+ full(t)*/
    t.record_id,
    t.host_code,
    t.location_area_code,
    t.base_station_code,
    t.validity_date,
    t.value_code1 zone_code,
    t.value_code2 zone_type_code
  from ( select /*+ full(q)*/ q.* from table(p_zones) q) t
  where 1 = 1
  order by t.rnum
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
END;
/
