CREATE PACKAGE BODY RSIG_DST_RULE IS
---------------------------------------------
--     PROCEDURE Test_Row_For_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Row_For_Exist_And_Deleted(p_dst_rule_id IN HOST.HOST_ID%TYPE) IS
  v_id DST_RULE.DST_RULE_ID%TYPE;
BEGIN
  SELECT DST_RULE_ID INTO v_id FROM DST_RULE WHERE DST_RULE_ID = p_dst_rule_id;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Dst_rule not exists.');
END Test_Row_For_Exist_And_Deleted;

---------------------------------------------
--     PROCEDURE Check_Host_Referenced
---------------------------------------------

PROCEDURE Check_DST_Rule_Referenced(p_dst_rule_id IN DST_RULE.DST_RULE_ID%TYPE) IS
  v_referenced   NUMBER;
BEGIN

  v_referenced := NULL;

  SELECT count(1)
    INTO v_referenced
    FROM HOST h
   WHERE h.Dst_Rule_Id = p_dst_rule_id;

  IF v_referenced > 0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_REFERENCED, '');
  END IF;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    NULL;
END Check_DST_Rule_Referenced;
------------------------------------------------------------------------------------------------------------------------------
--  Get_DST_Rules_List
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_DST_Rules_List(
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
)
IS
  v_sqlcode          number;
  v_event_source     varchar2(60) :='RSIG_DST_RULE.Get_DST_Rules_List';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

-- start of the procedure body --------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
    SELECT dr.DST_RULE_ID,
           dr.COUNTRY_CODE,
           dr.DST_NAME,
           dr.DATE_START_RULE_MASK,
           dr.DATE_START,
           dr.DATE_END_RULE_MASK,
           dr.DATE_END
      FROM DST_RULE dr;

  COMMIT;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
    p_error_code := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
    WHEN OTHERS THEN
        v_sqlcode := sqlcode;
        p_error_message := sqlerrm;
--        DBMS_OUTPUT.PUT_LINE(p_error_message);
        p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
        RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
        OPEN p_result_list FOR SELECT v_sqlcode, p_error_message FROM dual;
END Get_DST_Rules_List;

------------------------------------------------------------------------------------------------------------------------------
--  Insert_DST_Rule
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_DST_Rule
(
  p_country_code          IN DST_RULE.COUNTRY_CODE%TYPE,
  p_DST_name              IN DST_RULE.DST_NAME%TYPE,
  p_date_start_rule_mask  IN DST_RULE.DATE_START_RULE_MASK%TYPE,
  p_date_start            IN DST_RULE.DATE_START%TYPE,
  p_date_end_rule_mask    IN DST_RULE.DATE_END_RULE_MASK%TYPE,
  p_date_end              IN DST_RULE.DATE_END%TYPE,
  p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_DST_rule_id           OUT HOST.HOST_ID%TYPE,
  p_error_code            OUT NUMBER
) IS
  v_check_exist           NUMBER;
  v_event_source          VARCHAR2(60) := 'RSIG_DST_RULE.Insert_DST_Rule';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (p_handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (p_handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  --check input parameters

  IF (p_DST_name IS NULL) OR (p_DST_name IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF (p_date_start_rule_mask IS NULL) OR (p_date_start_rule_mask IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF (p_date_start IS NULL) OR (p_date_start IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF (p_date_end_rule_mask IS NULL) OR (p_date_end_rule_mask IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF (p_date_end IS NULL) OR (p_date_end IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  --check exist of record

  SELECT COUNT (1)
  INTO v_check_exist
     FROM DST_RULE dr
    WHERE dr.COUNTRY_CODE = p_country_code
      AND dr.DST_NAME = p_DST_name
      AND dr.DATE_START_RULE_MASK = p_date_start_rule_mask
      AND dr.DATE_START = p_date_start
      AND dr.DATE_END_RULE_MASK = p_date_end_rule_mask
      AND dr.DATE_END = p_date_end;
  IF v_check_exist <> 0 THEN
    SELECT dr.DST_RULE_ID
    INTO p_DST_rule_id
       FROM DST_RULE dr
      WHERE dr.COUNTRY_CODE = p_country_code
        AND dr.DST_NAME = p_DST_name
        AND dr.DATE_START_RULE_MASK = p_date_start_rule_mask
        AND dr.DATE_START = p_date_start
        AND dr.DATE_END_RULE_MASK = p_date_end_rule_mask
        AND dr.DATE_END = p_date_end;
    p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
    RETURN;
  END IF;

  --set savepoint
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Insert_DST_Rule_a;
  END IF;

  SELECT s_DST_RULE.NEXTVAL INTO p_DST_rule_id FROM DUAL;

  BEGIN
    INSERT INTO DST_RULE
      (DST_RULE_ID,
       COUNTRY_CODE,
       DST_NAME,
       DATE_START_RULE_MASK,
       DATE_START,
       DATE_END_RULE_MASK,
       DATE_END )
    VALUES
      (p_DST_rule_id,
       p_country_code,
       p_DST_name,
       p_date_start_rule_mask,
       p_date_start,
       p_date_end_rule_mask,
       p_date_end
      );
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      IF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_HOST_CODE THEN
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_CODE, '');
      ELSE
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_NAME, '');
      END IF;
  END;

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      p_error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE p_handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT Insert_DST_Rule_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
    END;

END Insert_DST_Rule;

------------------------------------------------------------------------------------------------------------------------------
--  Delete_DST_Rule
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Delete_DST_Rule
(
  p_DST_Rule_id           IN DST_RULE.DST_RULE_ID%TYPE,
  p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_error_code            OUT NUMBER
) IS
  v_event_source VARCHAR2(60) := 'RSIG_DST_RULE.Delete_DST_Rule';
  v_check_exist  NUMBER;
  v_referenced   NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  SELECT COUNT (1)
  INTO v_check_exist
     FROM DST_RULE dr
    WHERE dr.DST_RULE_ID = p_DST_Rule_id;
  IF v_check_exist = 0 THEN
    p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
    RETURN;
  END IF;

  --check DST rule referenced

  v_referenced := 0;
  SELECT count(1)
    INTO v_referenced
    FROM HOST h
   WHERE h.DST_RULE_ID = p_DST_Rule_id;
  IF v_referenced > 0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_REFERENCED, '');
  END IF;

  --set save point

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Delete_DST_Rule_a;
  END IF;

  DELETE FROM DST_RULE dr
    WHERE dr.DST_RULE_ID = p_DST_Rule_id;

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      p_error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE p_handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT Insert_DST_Rule_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
    END;

END Delete_DST_Rule;

------------------------------------------------------------------------------------------------------------------------------
--  Update_DST_Rule
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Update_DST_Rule
(
  p_DST_Rule_id           IN DST_RULE.DST_RULE_ID%TYPE,
  p_country_code          IN DST_RULE.COUNTRY_CODE%TYPE,
  p_DST_name              IN DST_RULE.DST_NAME%TYPE,
  p_date_start_rule_mask  IN DST_RULE.DATE_START_RULE_MASK%TYPE,
  p_date_start            IN DST_RULE.DATE_START%TYPE,
  p_date_end_rule_mask    IN DST_RULE.DATE_END_RULE_MASK%TYPE,
  p_date_end              IN DST_RULE.DATE_END%TYPE,
  p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_error_code            OUT NUMBER
) IS
  v_check_exist           NUMBER;
  v_event_source          VARCHAR2(60) := 'RSIG_DST_RULE.Update_DST_Rule';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (p_handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (p_handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  --check input parameters

  IF (p_DST_name IS NULL) OR (p_DST_name IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF (p_date_start_rule_mask IS NULL) OR (p_date_start_rule_mask IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF (p_date_start IS NULL) OR (p_date_start IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF (p_date_end_rule_mask IS NULL) OR (p_date_end_rule_mask IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF (p_date_end IS NULL) OR (p_date_end IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  --check exist of record

  SELECT COUNT (1)
  INTO v_check_exist
     FROM DST_RULE dr
    WHERE dr.DST_RULE_ID = p_DST_Rule_id;
  IF v_check_exist = 0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'DST rule not exists.');
  END IF;

  --set save point

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_DST_Rule_a;
  END IF;

  BEGIN
    UPDATE DST_RULE
       SET COUNTRY_CODE           = p_country_code,
           DST_NAME               = p_DST_name,
           DATE_START_RULE_MASK   = p_date_start_rule_mask,
           DATE_START             = p_date_start,
           DATE_END_RULE_MASK     = p_date_end_rule_mask,
           DATE_END               = p_date_end
     WHERE DST_RULE_ID = p_DST_Rule_id;
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      IF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_HOST_CODE THEN
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_CODE, '');
      ELSE
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_NAME, '');
      END IF;
  END;

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      p_error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE p_handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT Update_DST_Rule_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
    END;

END Update_DST_Rule;

------------------------------------------------------------------------------------------------------------------------------
--  Get_DST_Rule_By_ID
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_DST_Rule_By_ID(
  p_DST_Rule_id      IN   DST_RULE.DST_RULE_ID%TYPE,
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
)
IS
  v_check_exist      NUMBER;
  v_sqlcode          NUMBER;
  v_event_source     VARCHAR2(60) :='RSIG_DST_RULE.Get_DST_Rule_By_ID';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  --check exist of record

  SELECT COUNT (1)
  INTO v_check_exist
     FROM DST_RULE dr
    WHERE dr.DST_RULE_ID = p_DST_Rule_id;
  IF v_check_exist = 0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'DST rule not exists.');
  END IF;

-- start of the procedure body --------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
    SELECT dr.DST_RULE_ID,
           dr.COUNTRY_CODE,
           dr.DST_NAME,
           dr.DATE_START_RULE_MASK,
           dr.DATE_START,
           dr.DATE_END_RULE_MASK,
           dr.DATE_END
      FROM DST_RULE dr
        WHERE dr.DST_RULE_ID = p_DST_Rule_id;

  COMMIT;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
    p_error_code := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
    WHEN OTHERS THEN
        v_sqlcode := sqlcode;
        p_error_message := sqlerrm;
--        DBMS_OUTPUT.PUT_LINE(p_error_message);
        p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
        RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
        OPEN p_result_list FOR SELECT v_sqlcode, p_error_message FROM dual;

END Get_DST_Rule_By_ID;

------------------------------------------------------------------------------------------------------------------------------
--  Get_DST_Rule_By_Name
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_DST_Rule_By_Name(
  p_DST_Name         IN   DST_RULE.DST_NAME%TYPE,
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
)
IS
  v_check_exist      NUMBER;
  v_sqlcode          NUMBER;
  v_event_source     VARCHAR2(60) :='RSIG_DST_RULE.Get_DST_Rule_By_Name';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  --check exist of record

  SELECT COUNT (1)
  INTO v_check_exist
     FROM DST_RULE dr
    WHERE dr.DST_NAME = p_DST_Name;
  IF v_check_exist = 0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'DST rule not exists.');
  END IF;

  IF v_check_exist > 1 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_TOO_MANY_ROWS_RETRIEVED, 'There are some rules DST with an identical name.');
  END IF;

-- start of the procedure body --------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
    SELECT dr.DST_RULE_ID,
           dr.COUNTRY_CODE,
           dr.DST_NAME,
           dr.DATE_START_RULE_MASK,
           dr.DATE_START,
           dr.DATE_END_RULE_MASK,
           dr.DATE_END
      FROM DST_RULE dr
        WHERE dr.DST_NAME = p_DST_Name;

  COMMIT;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
    p_error_code := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
    WHEN OTHERS THEN
        v_sqlcode := sqlcode;
        p_error_message := sqlerrm;
--        DBMS_OUTPUT.PUT_LINE(p_error_message);
        p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
        RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
        OPEN p_result_list FOR SELECT v_sqlcode, p_error_message FROM dual;

END Get_DST_Rule_By_Name;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Country_List
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Country_List(
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
)
IS
  v_sqlcode          number;
  v_event_source     varchar2(60) :='RSIG_DST_RULE.Get_Country_List';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

-- start of the procedure body --------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
    SELECT c.COUNTRY_ID,
           c.COUNTRY_CODE,
           c.COUNTRY_NAME
       FROM COUNTRY c
         WHERE c.DELETED IS NULL;

  COMMIT;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
    p_error_code := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
    WHEN OTHERS THEN
        v_sqlcode := sqlcode;
        p_error_message := sqlerrm;
--        DBMS_OUTPUT.PUT_LINE(p_error_message);
        p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
        RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
        OPEN p_result_list FOR SELECT v_sqlcode, p_error_message FROM dual;
END Get_Country_List;

----------------------------------!---------------------------------------------

END RSIG_DST_RULE;
/
