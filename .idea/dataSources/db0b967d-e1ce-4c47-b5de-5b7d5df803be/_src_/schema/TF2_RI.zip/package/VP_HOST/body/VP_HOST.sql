CREATE package body VP_HOST is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return host%rowtype
is
  v_res host%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, PK_HOST)*/
        * into v_res
        from host z
        where 1 = 1
        and host_id = p_id
        and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, PK_HOST)*/
        * into v_res
        from host z
        where 1 = 1
        and host_id = p_id
        and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, PK_HOST)*/
      * into v_res
      from host z
      where 1 = 1
      and host_id = p_id
      and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1(p_id integer, p_date date) return host%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get1_i(p_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get1(p_id integer, p_date date) return host%rowtype
is
  v_res host%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_i(p_id, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function find_i_id(p_rec host%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_cnt number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.host_id is null, 'p_rec.host_id');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  if p_check_only_other_ids
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
select /*+ index_asc(z, PK_HOST)*/
  count(1) cnt into v_cnt
  from host z
  where 1 = 1
  and host_id = p_rec.host_id
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  --!_!and (v_check_only_other_ids = util_pkg.c_false or host_id != p_rec.host_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_code(p_rec host%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
  v_date date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.host_id is null, 'p_rec.host_id');
  util_pkg.XCheck_Cond_Missing(p_rec.host_code is null, 'p_rec.host_code');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  v_date := util_ri.deleted2valid_date_to(p_rec.deleted);
  ------------------------------
select /*+ index_asc(z, UK_HOST_CODE)*/
  count(1) cnt into v_cnt
  from host z
  where 1 = 1
  and host_code = p_rec.host_code
  and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  and (v_check_only_other_ids = util_pkg.c_false or host_id != p_rec.host_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_name(p_rec host%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
  v_date date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.host_id is null, 'p_rec.host_id');
  util_pkg.XCheck_Cond_Missing(p_rec.host_name is null, 'p_rec.host_name');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  v_date := util_ri.deleted2valid_date_to(p_rec.deleted);
  ------------------------------
select /*+ index_asc(z, UK_HOST)*/
  count(1) cnt into v_cnt
  from host z
  where 1 = 1
  and host_name = p_rec.host_name
  and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  and (v_check_only_other_ids = util_pkg.c_false or host_id != p_rec.host_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i(p_rec host%rowtype, p_check_only_other_ids boolean) return boolean
is
begin
  ------------------------------
  if find_i_id(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_code(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_name(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xunique_i(p_rec host%rowtype, p_check_only_other_ids boolean)
is
begin
  ------------------------------
  if find_i_id(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    --!_!util_pkg.Raise_Obj_NotUniq_OnDate2(p_rec.host_id, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    util_pkg.Raise_Obj_NotUniq_ID2(p_rec.host_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_code(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_OnDate(p_rec.host_code, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_name(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_OnDate(p_rec.host_name, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_i(p_rec host%rowtype)
is
begin
  ------------------------------
  xunique_i(p_rec, FALSE);
  ------------------------------
  insert into host
  values p_rec;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure change_i(p_rec host%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xunique_i(p_rec, TRUE);
  ------------------------------
update /*+ index_asc(z, PK_HOST)*/
  host z
  set
    row = p_rec
  where 1 = 1
  and host_id = p_rec.host_id
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_ID2(p_rec.host_id, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_ID2(p_rec.host_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open(p_rec in out nocopy host%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  p_rec.host_id := nvl(p_rec.host_id, s_host.nextval);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change(p_rec in out nocopy host%rowtype, p_date_from_virt date := null)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_rec host%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.host_id is null, 'p_rec.host_id');
  ------------------------------
  v_date_from_new := nvl(p_date_from_virt, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  v_rec := xlock_get1(p_rec.host_id, v_date_to_prev);
  ------------------------------
  if v_rec.host_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_rec.host_id, v_date_to_prev, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  change_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close
(
    p_id integer,
    p_user_id integer,
    p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_rec host%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_date_from_new := nvl(p_date_from, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  v_rec := xlock_get1(p_id, v_date_to_prev);
  ------------------------------
  if v_rec.host_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, v_date_to_prev, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  v_rec.user_id_of_change := p_user_id;
  ------------------------------
  v_rec.date_of_change := v_sysdate;
  v_rec.deleted := util_ri.valid_date_to2deleted(v_date_to_prev);
  ------------------------------
  change_i(v_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open2
(
    p_rec in out nocopy host%rowtype,
    p_routing_number_id integer,
    p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_rec_ch routing_number_host%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  version_open(p_rec);
  ------------------------------
  if p_routing_number_id is not null
  then
    ------------------------------
    v_rec_ch := NULL;
    ------------------------------
    v_rec_ch.routing_number_id := p_routing_number_id;
    v_rec_ch.host_id := p_rec.host_id;
    v_rec_ch.date_from := p_date_from;
    v_rec_ch.date_to := util_ri.deleted2valid_date_to(p_rec.deleted);
    v_rec_ch.user_id_of_change := p_rec.user_id_of_change;
    ------------------------------
    vp_routing_number_host.version_open(v_rec_ch);
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change2
(
    p_rec in out nocopy host%rowtype,
    p_routing_number_id integer,
    p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_rec_ch routing_number_host%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  v_date_from_new := nvl(p_date_from, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  version_change(p_rec, v_date_from_new);
  ------------------------------
  v_rec_ch := vp_routing_number_host.get1(p_rec.host_id, v_date_to_prev);
  ------------------------------
  if v_rec_ch.host_id is not null
  then
    ------------------------------
    vp_routing_number_host.version_close
    (
      p_host_id => v_rec_ch.host_id,
      p_user_id => p_rec.user_id_of_change,
      p_date_from => v_date_from_new
    );
    ------------------------------
  end if;
  ------------------------------
  if p_routing_number_id is not null
  then
    ------------------------------
    v_rec_ch := NULL;
    ------------------------------
    v_rec_ch.routing_number_id := p_routing_number_id;
    v_rec_ch.host_id := p_rec.host_id;
    v_rec_ch.date_from := p_date_from;
    v_rec_ch.date_to := util_ri.deleted2valid_date_to(p_rec.deleted);
    v_rec_ch.user_id_of_change := p_rec.user_id_of_change;
    ------------------------------
    vp_routing_number_host.version_open(v_rec_ch);
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close2
(
    p_id integer,
    p_user_id integer,
    p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_rec_ch routing_number_host%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_date_from_new := nvl(p_date_from, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  v_rec_ch := vp_routing_number_host.get1(p_id, v_date_to_prev);
  ------------------------------
  if v_rec_ch.host_id is not null
  then
    ------------------------------
    vp_routing_number_host.version_close
    (
      p_host_id => v_rec_ch.host_id,
      p_user_id => p_user_id,
      p_date_from => v_date_from_new
    );
    ------------------------------
  end if;
  ------------------------------
  version_close
  (
    p_id => p_id,
    p_user_id => p_user_id,
    p_date_from => v_date_from_new
  );
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
