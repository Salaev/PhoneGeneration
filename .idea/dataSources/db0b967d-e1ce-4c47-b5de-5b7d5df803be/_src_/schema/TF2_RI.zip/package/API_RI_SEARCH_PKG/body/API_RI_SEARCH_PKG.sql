CREATE package body API_RI_SEARCH_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure GetPhonesByStatus3
(
    p_host_id                      varchar2,
    p_network_operator_id          number,
    p_phone_type                   varchar2,
    p_salability_category          util_pkg.cit_varchar_s,
    p_series_id                    number,
    p_mask                         varchar2,
    p_phone_number_status_code     varchar2,
    p_set_phone_number_status_code varchar2,
    p_StartingRow                  number,
    p_Phone_Number_Count           number,
    p_user_login                   varchar2,
    p_error_code                   out number,
    p_error_message                out varchar2,
    p_result_list                  out sys_refcursor
)
is
  v_date date;
  v_network_operator_code varchar2(10);
  --
  v_host_id util_pkg.cit_varchar_s;
  v_phone_status util_pkg.cit_varchar_s;
  --
  v_m_na_id ct_number;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_network_operator_id is null, 'p_network_operator_id');
  util_pkg.XCheck_Cond_Missing(p_phone_type is null, 'p_phone_type');
  util_pkg.XCheckP_cit_varchar_s(p_salability_category, 'p_salability_category');
  util_pkg.XCheck_Cond_Missing(p_phone_number_status_code is null, 'p_phone_number_status_code');
  util_pkg.XCheck_Cond_Missing(p_Phone_Number_Count is null, 'p_Phone_Number_Count');
  util_pkg.XCheck_Cond_Missing(p_user_login is null, 'p_user_login');
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  v_network_operator_code := util_ri.get_network_operator_code2(p_network_operator_id, v_date);
  util_pkg.XCheck_Cond_Invalid(v_network_operator_code is null, 'p_network_operator_id');
  ------------------------------
  v_host_id(util_ri.c_index_one) := p_host_id;
  v_phone_status(util_ri.c_index_one):= p_phone_number_status_code;
  ------------------------------
  search_pkg.GetPhonesByStatus2_i
  (
    p_host_id                      => v_host_id,
    p_network_operator_code        => v_network_operator_code,
    p_phone_type                   => p_phone_type,
    p_salability_category          => p_salability_category,
    p_series_id                    => p_series_id,
    p_mask                         => p_mask,
    p_use_linked                   => etc_pkg.c_use_linked_no,
    p_phone_number_status_code     => v_phone_status,
    p_set_phone_number_status_code => p_set_phone_number_status_code,
    p_StartingRow                  => p_StartingRow,
    p_Phone_Number_Count           => p_Phone_Number_Count,
    p_user_login                   => p_user_login,
    p_m_na_id                      => v_m_na_id
  );
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  search_pkg.get_result_cursor04(v_m_na_id, v_date, p_result_list);
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure GetPhonesByStatus2
(
    p_host_id                      util_pkg.cit_varchar_s,
    p_network_operator_code        varchar2,
    p_phone_type                   varchar2,
    p_salability_category          util_pkg.cit_varchar_s,
    p_series_id                    number,
    p_mask                         varchar2,
    p_use_linked                   number,
    p_phone_number_status_code     util_pkg.cit_varchar_s,
    p_set_phone_number_status_code varchar2,
    p_startingrow                  number,
    p_phone_number_count           number,
    p_user_login                   varchar2,
    p_error_code                   out number,
    p_error_message                out varchar2,
    p_result_list                  out sys_refcursor
)
is
  v_date date;
  --
  v_m_na_id ct_number;
  --
begin
  search_pkg.GetPhonesByStatus2_i
  (
    p_host_id => p_host_id,
    p_network_operator_code => p_network_operator_code,
    p_phone_type => p_phone_type,
    p_salability_category => p_salability_category,
    p_series_id => p_series_id,
    p_mask => p_mask,
    p_use_linked => p_use_linked,
    p_phone_number_status_code => p_phone_number_status_code,
    p_set_phone_number_status_code => p_set_phone_number_status_code,
    p_startingrow => p_startingrow,
    p_phone_number_count => p_phone_number_count,
    p_user_login => p_user_login,
    p_m_na_id => v_m_na_id
  );
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  search_pkg.get_result_cursor04(v_m_na_id, v_date, p_result_list);
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure GetPhonesByStatus22
(
    p_host_id                      util_pkg.cit_varchar_s,
    p_network_operator_code        varchar2,
    p_phone_type                   varchar2,
    p_salability_category          util_pkg.cit_varchar_s,
    p_series_id                    number,
    p_mask                         varchar2,
    p_use_linked                   number,
    p_phone_number_status_code     util_pkg.cit_varchar_s,
    p_set_phone_number_status_code varchar2,
    p_StartingRow                  number,
    p_Phone_Number_Count           number,
    p_user_login                   varchar2,
    p_error_code                   out number,
    p_error_message                out varchar2,
    p_result_list                  out sys_refcursor
)
is
  v_date date;
  --
  v_m_na_id ct_number;
  --
begin
  ------------------------------
  search_pkg.GetPhonesByStatus2_i
  (
    p_host_id => p_host_id,
    p_network_operator_code => p_network_operator_code,
    p_phone_type => p_phone_type,
    p_salability_category => p_salability_category,
    p_series_id => p_series_id,
    p_mask => p_mask,
    p_use_linked => p_use_linked,
    p_phone_number_status_code => p_phone_number_status_code,
    p_set_phone_number_status_code => p_set_phone_number_status_code,
    p_startingrow => p_startingrow,
    p_phone_number_count => p_phone_number_count,
    p_user_login => p_user_login,
    p_m_na_id => v_m_na_id
  );
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  search_pkg.get_result_cursor08(v_m_na_id, v_date, p_result_list);
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_phones_by_status_series
(
    p_host_id                  util_pkg.cit_varchar_s,
    p_salability_category      util_pkg.cit_varchar_s,
    p_series_id                phone_number_series.phone_number_series_id%type,
    p_mask                     varchar2,
    p_use_linked               number,
    p_phone_number_status_code util_pkg.cit_varchar_s,
    p_set_phone_number_status_code phone_number.net_address_status_code%type,
    p_startingrow              number,
    p_phone_number_count       number,
    p_user_login               varchar2,
    p_handle_tran              char := rsig_utils.c_HANDLE_TRAN_Y,
    p_raise_error              char := rsig_utils.c_NO,
    p_error_code               out number,
    p_error_message            out varchar2,
    p_result_list              out sys_refcursor
)
is
  ------------------------------
  v_date date;
  v_m_na_id ct_number;
  ------------------------------
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_salability_category is null, 'p_salability_category');
  util_pkg.XCheck_Cond_Missing(p_series_id is null, 'p_series_id');
  ------------------------------
  search_pkg.GetPhonesByStatus2_i
  (
    p_host_id => p_host_id,
    p_network_operator_code => NULL, --!_!
    p_is_netop_code_mandatory => util_pkg.C_FALSE, --!_!
    p_phone_type => NULL, --!_!
    p_is_phone_type_mandatory => util_pkg.C_FALSE, --!_!
    p_salability_category => p_salability_category,
    p_series_id => p_series_id,
    p_mask => p_mask,
    p_use_linked => p_use_linked,
    p_phone_number_status_code => p_phone_number_status_code,
    p_set_phone_number_status_code => p_set_phone_number_status_code,
    p_startingrow => p_startingrow,
    p_phone_number_count => p_phone_number_count,
    p_user_login => p_user_login,
    p_m_na_id => v_m_na_id
  );
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  search_pkg.get_result_cursor04(v_m_na_id, v_date, p_result_list);
  ------------------------------
  if p_handle_tran = rsig_utils.c_HANDLE_TRAN_Y
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;
  ------------------------------
  if p_handle_tran = rsig_utils.c_HANDLE_TRAN_Y
  then
    rollback;
  end if;
  ------------------------------
  if p_raise_error = rsig_utils.c_YES
  then
    raise;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Get_Free_Phones
(
    p_network_operator_id          number,
    p_salability_category          varchar2,
    p_phone_type                   varchar2,
    p_number_of_phones             number,
    p_reserve                      number,
    p_user_login                   varchar2,
    p_mask                         varchar2,
    p_error_code                   out number,
    p_error_message                out varchar2,
    p_cur_free_phones_history      out sys_refcursor
)
is
  --
  v_host_id util_pkg.cit_varchar_s;
  v_sal_cat util_pkg.cit_varchar_s;
  v_phone_status util_pkg.cit_varchar_s;
  --
  v_date date;
  v_network_operator_code varchar2(10);
  v_set_phone_number_status_code varchar2(2);
  --
  v_m_na_id ct_number;
  --
  v_reserve boolean;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_network_operator_id is null, 'p_network_operator_id');
  util_pkg.XCheck_Cond_Missing(p_salability_category is null, 'p_salability_category');
  util_pkg.XCheck_Cond_Missing(p_phone_type is null, 'p_phone_type');
  util_pkg.XCheck_Cond_Missing(p_reserve is null, 'p_reserve');
  util_pkg.XCheck_Cond_Missing(p_number_of_phones is null, 'p_number_of_phones');
  util_pkg.XCheck_Cond_Missing(p_user_login is null, 'p_user_login');
  ------------------------------
  v_reserve := util_pkg.int_to_bool_2val(p_reserve);
  ------------------------------
  v_date := sysdate;
  ------------------------------
  v_network_operator_code := util_ri.get_network_operator_code2(p_network_operator_id, v_date);
  util_pkg.XCheck_Cond_Invalid(v_network_operator_code is null, 'p_network_operator_id');
  ------------------------------
  v_host_id(util_ri.c_index_one) := util_ri.c_str_host_id_any;
  v_sal_cat(util_ri.c_index_one) := p_salability_category;
  v_phone_status(util_ri.c_index_one):= util_ri.c_NASH_CODE_FREE;
  ------------------------------
  v_set_phone_number_status_code := search_pkg.make_reserve_status_or_null(v_reserve);
  ------------------------------
  search_pkg.GetPhonesByStatus2_i
  (
    p_host_id                      => v_host_id,
    p_network_operator_code        => v_network_operator_code,
    p_phone_type                   => p_phone_type,
    p_salability_category          => v_sal_cat,
    p_series_id                    => null,
    p_mask                         => p_mask,
    p_use_linked                   => etc_pkg.c_use_linked_no,
    p_phone_number_status_code     => v_phone_status,
    p_set_phone_number_status_code => v_set_phone_number_status_code,
    p_StartingRow                  => null,
    p_Phone_Number_Count           => p_number_of_phones,
    p_user_login                   => p_user_login,
    p_m_na_id                      => v_m_na_id
  );
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  search_pkg.get_result_cursor05(v_m_na_id, v_date, p_cur_free_phones_history);
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_phone_numbers_2
(
    p_network_operator_id number,
    p_external_operator_id number,
    p_phone_number_series_id number,
    p_host_id varchar2,
    p_mask varchar2,
    p_status util_pkg.cit_varchar_s,
    p_category util_pkg.cit_varchar_s,
    p_phone_number_type varchar2,
    p_count number,
    p_linked_naap number,
    p_msisdn_lower_bound varchar2,
    p_cur_series out rsig_utils.ref_cursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_linked_naap boolean := util_pkg.int_to_bool_3val(p_linked_naap);
  v_na_id ct_number;
begin
  ------------------------------
  search_pkg.get_phone_numbers_i
  (
    p_network_operator_id => p_network_operator_id,
    p_external_operator_id => p_external_operator_id,
    p_phone_number_series_id => p_phone_number_series_id,
    p_host_id => p_host_id,
    p_mask => p_mask,
    p_status => p_status,
    p_category => p_category,
    p_phone_number_type => p_phone_number_type,
    p_count => p_count,
    p_linked_naap => v_linked_naap,
    p_msisdn_lower_bound => p_msisdn_lower_bound,
    p_na_id => v_na_id
  );
  ------------------------------
  search_pkg.get_result_cursor06(v_na_id, sysdate, p_cur_series);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Get_Phones
(
    p_host_id                      varchar2,
    p_network_operator_code        varchar2,
    p_phone_type                   varchar2,
    p_salability_category_l        util_pkg.cit_varchar_s,
    p_series_id                    number,
    p_mask                         varchar2,
    p_phone_number_status_code_l   util_pkg.cit_varchar_s,
    p_set_phone_number_status_code varchar2,
    p_StartingRow                  number,
    p_Phone_Number_Count           number,
    p_user_login                   varchar2,
    p_error_code                   out number,
    p_error_message                out varchar2,
    p_result_list                  out sys_refcursor
)
is
  v_date date;
  --
  v_host_id util_pkg.cit_varchar_s;
  --
  v_m_na_id ct_number;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_network_operator_code is null, 'p_network_operator_code');
  util_pkg.XCheck_Cond_Missing(p_phone_type is null, 'p_phone_type');
  util_pkg.XCheckP_cit_varchar_s(p_salability_category_l, 'p_salability_category_l');
  util_pkg.XCheck_Cond_Missing(p_phone_number_status_code_l is null, 'p_phone_number_status_code_l');
  util_pkg.XCheck_Cond_Missing(p_Phone_Number_Count is null, 'p_Phone_Number_Count');
  util_pkg.XCheck_Cond_Missing(p_user_login is null, 'p_user_login');
  ------------------------------
  v_host_id(util_ri.c_index_one) := p_host_id;
  ------------------------------
  search_pkg.GetPhonesByStatus2_i
  (
    p_host_id                      => v_host_id,
    p_network_operator_code        => p_network_operator_code,
    p_phone_type                   => p_phone_type,
    p_salability_category          => p_salability_category_l,
    p_series_id                    => p_series_id,
    p_mask                         => p_mask,
    p_use_linked                   => etc_pkg.c_use_linked_no,
    p_phone_number_status_code     => p_phone_number_status_code_l,
    p_set_phone_number_status_code => p_set_phone_number_status_code,
    p_StartingRow                  => p_StartingRow,
    p_Phone_Number_Count           => p_Phone_Number_Count,
    p_user_login                   => p_user_login,
    p_m_na_id                      => v_m_na_id
  );
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  search_pkg.get_result_cursor04(v_m_na_id, v_date, p_result_list);
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Get_Free_Phones_By_Host2
(
    p_host_id              varchar2,
    p_operator_id          number,
    p_phone_number_type    varchar2,
    p_salability_category  varchar2,
    p_series_id            number,
    p_mask                 varchar2,
    p_phone_number_count   number,
    p_starting_row         number,
    p_error_code           out number,
    p_error_message        out varchar2,
    p_result_list          out sys_refcursor
)
is
  --
  v_network_operator_code varchar2(10);
  v_date date;
  --
  v_m_na_id ct_number;
  --
  v_host_id util_pkg.cit_varchar_s;
  v_sal_cat util_pkg.cit_varchar_s;
  v_phone_status util_pkg.cit_varchar_s;
  --
  v_user_id number;
  --
begin
  ------------------------------
  -- !_! util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  -- !_! util_pkg.XCheck_Cond_Missing(p_series_id is null, 'p_series_id');
  -- !_! util_pkg.XCheck_Cond_Missing(p_phone_number_count is null, 'p_phone_number_count');
  util_pkg.XCheck_Cond_Missing(p_operator_id is null, 'p_operator_id');
  util_pkg.XCheck_Cond_Missing(p_phone_number_type is null, 'p_phone_number_type');
  util_pkg.XCheck_Cond_Missing(p_salability_category is null, 'p_salability_category');
  ------------------------------
  v_date := sysdate;
  ------------------------------
  v_network_operator_code := util_ri.get_network_operator_code2(p_operator_id, v_date);
  util_pkg.XCheck_Cond_Invalid(v_network_operator_code is null, 'p_operator_id');
  ------------------------------
  v_host_id(util_ri.c_index_one) := p_host_id;
  v_sal_cat(util_ri.c_index_one) := p_salability_category;
  v_phone_status(util_ri.c_index_one):= util_ri.c_NASH_CODE_FREE;
  ------------------------------
  v_user_id := util_ri.xget_default_user_id;
  ------------------------------
  search_pkg.GetPhonesByStatus2_ii
  (
    p_host_id                      => v_host_id,
    p_network_operator_code        => v_network_operator_code,
    p_phone_type                   => p_phone_number_type,
    p_salability_category          => v_sal_cat,
    p_series_id                    => p_series_id,
    p_mask                         => p_mask,
    p_use_linked                   => etc_pkg.c_use_linked_no,
    p_phone_number_status_code     => v_phone_status,
    p_set_phone_number_status_code => null,
    p_startingrow                  => p_starting_row,
    p_phone_number_count           => p_phone_number_count,
    p_user_id                      => v_user_id,
    p_m_na_id                      => v_m_na_id
  );
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  search_pkg.get_result_cursor07(v_m_na_id, v_date, p_result_list);
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_free_phones999
(
    p_host_codes util_pkg.cit_varchar_s,
    p_network_operator_code varchar2,
    p_network_operator_code_linked varchar2,
    p_phone_type_codes util_pkg.cit_varchar_s,
    p_salability_category_codes util_pkg.cit_varchar_s,
    p_mask varchar2,
    p_phone_number_status_codes util_pkg.cit_varchar_s,
    p_phone_number_count number,
    p_user_login varchar2,
    p_result_list out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
  v_search_type number;
  v_m_na_id ct_number;
  v_l_na_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_network_operator_code is null, 'p_network_operator_code');
  util_pkg.XCheckP_cit_varchar_s(p_phone_number_status_codes, 'p_phone_number_status_code');
  ------------------------------
  util_loc_pkg.touch_varchar(p_user_login);
  ------------------------------
  search_pkg.GetFreePhones_i
  (
    p_host_codes,
    p_network_operator_code,
    p_network_operator_code_linked,
    p_phone_type_codes,
    p_salability_category_codes,
    p_mask,
    p_phone_number_status_codes,
    p_phone_number_count,
    v_search_type,
    v_m_na_id,
    v_l_na_id
  );
  ------------------------------
  search_pkg.get_result_cursor03(v_m_na_id, v_l_na_id, v_date, v_search_type, p_result_list);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Find_Linked_Phones
(
    p_host_id                  varchar2,
    p_network_operator_code    varchar2,
    p_phone_number_series_id   number,
    p_linked_network_operator  varchar2,
    p_salability_cat_code_l    util_pkg.cit_varchar_s,
    p_phone_status_code_l      util_pkg.cit_varchar_s,
    p_mask                     varchar2,
    p_phone_count              number,
    p_set_phone_status_code    varchar2,
    p_user_login               varchar2,
    p_error_code               out number,
    p_error_message            out varchar2,
    p_result_list              out sys_refcursor
)
is
begin
  ------------------------------
  search_pkg.Find_Linked_Phones
  (
    p_host_id => p_host_id,
    p_network_operator_code => p_network_operator_code,
    p_phone_number_series_id => p_phone_number_series_id,
    p_linked_network_operator => p_linked_network_operator,
    p_salability_cat_code_l => p_salability_cat_code_l,
    p_phone_status_code_l => p_phone_status_code_l,
    p_mask => p_mask,
    p_phone_count => p_phone_count,
    p_set_phone_status_code => p_set_phone_status_code,
    p_user_login => p_user_login,
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_result_list => p_result_list
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Find_Linked_Phones_Ex
(
    p_host_id                  varchar2,
    p_network_operator_code    varchar2,
    p_phone_number_series_id   number,
    p_linked_network_operator  varchar2,
    p_salability_cat_code_l    util_pkg.cit_varchar_s,
    p_phone_status_code_l      util_pkg.cit_varchar_s,
    p_mask                     varchar2,
    p_phone_count              number,
    p_set_phone_status_code    varchar2,
    p_user_login               varchar2,
    p_link_status              number, --0 - all, 1 - free, 2 - linked
    p_error_code               out number,
    p_error_message            out varchar2,
    p_result_list              out sys_refcursor
)
is
begin
  ------------------------------
  search_pkg.Find_Linked_Phones_Ex
  (
    p_host_id => p_host_id,
    p_network_operator_code => p_network_operator_code,
    p_phone_number_series_id => p_phone_number_series_id,
    p_linked_network_operator => p_linked_network_operator,
    p_salability_cat_code_l => p_salability_cat_code_l,
    p_phone_status_code_l => p_phone_status_code_l,
    p_mask => p_mask,
    p_phone_count => p_phone_count,
    p_set_phone_status_code => p_set_phone_status_code,
    p_user_login => p_user_login,
    p_link_status => p_link_status,
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_result_list => p_result_list
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure GetFreePhonesToNewBatch
(
    p_host_codes                     util_pkg.cit_varchar_s,
    p_network_operator_code          varchar2,
    p_network_operator_code_linked   varchar2,
    p_phone_type                     util_pkg.cit_varchar_s,
    p_salability_categorys           util_pkg.cit_varchar_s,
    p_mask                           varchar2,
    p_phone_number_status_code       util_pkg.cit_varchar_s,
    p_phone_number_count             number,
    p_reserve_date                   date,
    p_reservation_period             number,
    p_user_login                     varchar2,
    p_batch_type                     number,
    p_error_code                     out number,
    p_error_message                  out varchar2,
    p_result_list                    out sys_refcursor,
    p_reserve_number                 out number
)
is
  v_sysdate date := sysdate;
  v_reserve_date date;
  --
  v_m_na_id ct_number;
  v_l_na_id ct_number;
  v_na_id ct_number;
  --
  v_user_id number;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_network_operator_code is null, 'p_network_operator_code');
  util_pkg.XCheckP_cit_varchar_s(p_phone_number_status_code, 'p_phone_number_status_code');
  util_pkg.XCheck_Cond_Missing(p_batch_type is null, 'p_batch_type');
  util_pkg.XCheck_Cond_Missing(p_reserve_date is null and p_reservation_period is null, 'p_reserve_date is null and p_reservation_period is null');
  ------------------------------
  batch_pkg.XCheck_na_res_batch_type(p_batch_type);
  ------------------------------
  v_user_id := util_ri.xget_user_id(p_user_login);
  ------------------------------
  if p_reserve_date is null
  then
    v_reserve_date := v_sysdate + p_reservation_period/24/60;
  else
    v_reserve_date := p_reserve_date;
  end if;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_reserve_date <= v_sysdate, 'v_reserve_date <= v_sysdate');
  ------------------------------
  search_pkg.GetFreePhonesAndReserve_i
  (
    p_host_codes => p_host_codes,
    p_network_operator_code => p_network_operator_code,
    p_network_operator_code_linked => p_network_operator_code_linked,
    p_phone_type => p_phone_type,
    p_salability_categorys => p_salability_categorys,
    p_mask => p_mask,
    p_phone_number_status_code => p_phone_number_status_code,
    p_phone_number_count => p_phone_number_count,
    p_user_login => p_user_login,
    p_result_list => p_result_list,
    p_m_na_id => v_m_na_id,
    p_l_na_id => v_l_na_id
  );
  ------------------------------
  p_reserve_number := batch_pkg.c_BATCH_ID_DUMMY;
  ------------------------------
  if util_pkg.CheckP_ct_number(v_m_na_id)
  then
    ------------------------------
    v_na_id := v_m_na_id;
    util_pkg.add_ct_number(v_na_id, v_l_na_id);
    ------------------------------
    p_reserve_number := batch_pkg.batch_ins(p_batch_type, v_sysdate, v_reserve_date, v_user_id);
    ------------------------------
    batch_pkg.na_res_batch_add_to(p_reserve_number, v_na_id, v_user_id);
    ------------------------------
  end if;
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure GetFreePhonesToExistBatch
(
    p_host_codes                     util_pkg.cit_varchar_s,
    p_network_operator_code          varchar2,
    p_phone_type                     varchar2,
    p_salability_categorys           util_pkg.cit_varchar_s,
    p_mask                           varchar2,
    p_phone_number_status_code       util_pkg.cit_varchar_s,
    p_phone_number_count             number,
    p_user_login                     varchar2,
    p_reserve_number                 number,
    p_error_code                     out number,
    p_error_message                  out varchar2,
    p_result_list                    out sys_refcursor
)
is
  v_sysdate date := sysdate;
  --
  v_phone_type util_pkg.cit_varchar_s;
  v_rec_batch batch%rowtype;
  --
  v_m_na_id ct_number;
  v_l_na_id ct_number;
  v_na_id ct_number;
  --
  v_user_id number;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_network_operator_code is null, 'p_network_operator_code');
  util_pkg.XCheckP_cit_varchar_s(p_phone_number_status_code, 'p_phone_number_status_code');
  util_pkg.XCheck_Cond_Missing(p_reserve_number is null, 'p_reserve_number');
  ------------------------------
  v_user_id := util_ri.xget_user_id(p_user_login);
  ------------------------------
  v_rec_batch := vp_batch.get1(p_reserve_number);
  ------------------------------
  if v_rec_batch.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_reserve_number));
  end if;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_rec_batch.batch_type not in (batch_pkg.c_BATCH_TYPE_NA_MNG), 'v_rec_batch.batch_type not in (batch_pkg.c_BATCH_TYPE_NA_MNG)');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_rec_batch.end_date <= v_sysdate, 'v_rec_batch.end_date <= v_sysdate');
  ------------------------------
  v_phone_type(util_ri.c_index_one) := p_phone_type;
  ------------------------------
  search_pkg.GetFreePhonesAndReserve_i
  (
    p_host_codes => p_host_codes,
    p_network_operator_code => p_network_operator_code,
    p_network_operator_code_linked => NULL,
    p_phone_type => v_phone_type,
    p_salability_categorys => p_salability_categorys,
    p_mask => p_mask,
    p_phone_number_status_code => p_phone_number_status_code,
    p_phone_number_count => p_phone_number_count,
    p_user_login => p_user_login,
    p_result_list => p_result_list,
    p_m_na_id => v_m_na_id,
    p_l_na_id => v_l_na_id
  );
  ------------------------------
  if util_pkg.CheckP_ct_number(v_m_na_id)
  then
    ------------------------------
    v_na_id := v_m_na_id;
    util_pkg.add_ct_number(v_na_id, v_l_na_id);
    ------------------------------
    batch_pkg.na_res_batch_add_to(p_reserve_number, v_na_id, v_user_id);
    ------------------------------
  end if;
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_! SPECIAL CASE is pn.date_of_status_change <= p_date_of_change
procedure GetPhonesByTypeAndStatus
(
  p_phone_type varchar2,
  p_phone_number_status_code varchar2,
  p_set_phone_number_status varchar2,
  p_phone_number_count number,
  p_network_operator_code varchar2,
  p_date_of_change date,
  p_user_login varchar2,
  p_error_code out number,
  p_error_message out varchar2,
  p_result out sys_refcursor
)
is
begin
  ------------------------------
  search_pkg.GetPhonesByTypeAndStatus
  (
    p_phone_type => p_phone_type,
    p_phone_number_status_code => p_phone_number_status_code,
    p_set_phone_number_status => p_set_phone_number_status,
    p_phone_number_count => p_phone_number_count,
    p_network_operator_code => p_network_operator_code,
    p_date_of_change => p_date_of_change,
    p_user_id => util_ri.xget_user_id(p_user_login),
    p_result => p_result
  );
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure reserve_phones4period
(
  p_msisdn_ml util_pkg.cit_varchar_s,
  p_reserve_period_minutes number,
  p_user_login varchar2,
  p_reserve_number out number,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  reservation_pkg.reserve_phones4period2
  (
    p_msisdn_ml => util_pkg.cast_cit2ct_varchar_s(p_msisdn_ml, true),
    p_reserve_period_minutes => p_reserve_period_minutes,
    p_user_id => util_ri.xget_user_id(p_user_login),
    p_reserve_number => p_reserve_number
  );
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
