CREATE PACKAGE RSIG_COMMON IS

  -- Author  : JHOLUB
  -- Created : 4.8.2004 16:37:13
  -- Purpose : common functions

TYPE table_of_string IS TABLE OF VARCHAR2(2000);

/****************************************************************************
<header>
  <name>             	GET_STRING_AS_TABLE
  </name>

  <author>           	LUCIE SEVCIKOVA
  </author>

  <version>          	1.0.0   27.5.2002
                      basic
  </version>

  <Description>      	Function returns table of one column named COLUMN_VALUE
                      containing fields from input string, which is delimited
                      by given delimiter.

                      Example:
                      statement
                      SELECT * FROM TABLE(get_string_as_table('1|82||378|a|5','|'))
                      will return:
   	                  COLUMN_VALUE
                      ------------
                      1
                      82

                      378
                      a
                      5

			Example of use in procedure:
                        OPEN P_CUR FOR
                          SELECT *
                            FROM TABLE(GET_STRING_AS_TABLE(CAST(P_STR AS VARCHAR2(2000) ),
                                                           CAST(P_DEL AS VARCHAR2(10) )
                                                          )
                                      );

                      CREATE OR REPLACE PROCEDURE TEST_GET_STRING_AS_TMP_TABLE(
		        P_STR    IN  VARCHAR2,
		        P_DEL    IN  VARCHAR2,
		        P_CUR    OUT SYS_REFCURSOR
		        )
		      IS
		        V_STRING VARCHAR2(255):= 'A|B|C';
		      BEGIN
		        OPEN P_CUR FOR
		          SELECT *
		            FROM TABLE(GET_STRING_AS_TABLE(CAST(P_STR AS VARCHAR2(2000)),CAST(P_DEL AS VARCHAR2(10))));

		      END TEST_GET_STRING_AS_TMP_TABLE;




  </Description>

  <Prerequisites>    	type table_of_string
                      (created by command:
                       CREATE OR REPLACE TYPE table_of_string AS TABLE OF VARCHAR2(2000)
                      )
  </Prerequisites>

  <Application>	      Common function.
  </Application>

  <Parameters>
                      p_string           VARCHAR2
                      p_delimiter        CHAR
                      return             table_of_string pipelined

  </Parameters>

</header>
****************************************************************************/
FUNCTION GET_STRING_AS_TABLE(in_string VARCHAR2, in_delimiter CHAR)
  RETURN table_of_string PIPELINED;

END RSIG_COMMON;
/
