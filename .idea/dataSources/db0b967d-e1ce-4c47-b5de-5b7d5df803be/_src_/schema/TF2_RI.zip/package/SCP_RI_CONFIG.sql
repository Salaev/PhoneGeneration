CREATE PACKAGE SCP_RI_CONFIG IS

  FUNCTION GET_PARAMS
  ( in_parameter_name   IN VARCHAR2
  , in_default_value    IN VARCHAR2
  ) RETURN VARCHAR2;

  PROCEDURE GET_VERSION
  ( out_last_synch       OUT DATE
  , out_foris_ri_version OUT VARCHAR2
  , out_scp_ri_version   OUT VARCHAR2
  , out_sync_state       OUT VARCHAR2
  , in_version_type      IN NUMBER
  );

END;
/
