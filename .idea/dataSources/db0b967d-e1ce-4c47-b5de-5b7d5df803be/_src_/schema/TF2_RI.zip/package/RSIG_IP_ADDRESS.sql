CREATE PACKAGE RSIG_IP_ADDRESS IS
/****************************************************************************
  <header>
    <name>              package RSIG_IP_ADDRESS
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.6         03.07.2006   Petr Cepek
                        procedure INSERT_IP_ADDRESS updated
                        procedure DELETE_IP_ADDRESS updated
    </version>
    <version>           1.0.5         1.12.2005    Petr Cepek
                        procedure Get_ip_address updated
    </version>

  	<version>			      1.0.4	        3.8.2004     Jaroslav Holub
								        Delete_IP_address - fixed for time difference between client and server,
								        date should be null and it means sysdate
	  </version>
    <version>           1.0.3   01.07.2004	Jaroslav Holub
             					  Get_ip_address - fix error when p_ip_number is not null and ip_version is null,
								        then get allways first n ip addres, now it is fixed
    </version>
    <version>           1.0.2   21.6.2004	Jaroslav Holub
                                Improved documentation of headers
    </version>
    <version>           1.0.1   16.6.2004	Jaroslav Holub
                                Test_IP_address_OK - > handle cases -> '::1' == '1::' , and handle wrong format '::8:0:7:' or ':8:0:7::'
    </version>
    <version>           1.0.0   28.5.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       package for handling IP addresses

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource Inventory
    </Application>

  </header>
****************************************************************************/
  -- Author  : JHOLUB
  -- Created : 25/5/2004 8:52:23
  -- Purpose : for handling ip address

	c_point						CONSTANT CHAR(1) := '.';
 	c_dpoint					CONSTANT CHAR(1) := ':';
	c_max_length_of_ip_address  CONSTANT NUMBER := 39;
	c_dword_count				CONSTANT NUMBER	:= 8;
	c_ipv4						CONSTANT NUMBER	:= 4;
	c_ipv6						CONSTANT NUMBER	:= 6;
	c_max_ipv4					CONSTANT NUMBER	:= 255;			-- max number in ip address for ipv4
	c_max_ipv6					CONSTANT NUMBER	:= 65535;		-- max number in ip address for ipv6
	c_SQLCODE_INVALID_NUMBER	CONSTANT NUMBER :=-1722;		--SQLCODE - for special handling
	c_SQLCODE_NUMERIC_ERROR		CONSTANT NUMBER :=-6502;		--SQLCODE - for special handling
	c_max_part_ipv4				CONSTANT NUMBER :=4;			-- max parts of ip_number v4 ddd.ddd.ddd.ddd
	c_max_part_ipv6				CONSTANT NUMBER :=8;			-- max parts of ip_number v6 XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX
	c_max_ip_number_ipv4		CONSTANT NUMBER :=4294967295;	-- maximal nuber (32 bit)
	c_max_ip_number_ipv6		CONSTANT NUMBER :=340282366920938463463374607431768211455; -- maximal nuber (128 bit)

/****************************************************************************
  <header>
    <name>              procedure Insert_IP_address
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.1    03.07.2006    Petr Cepek
                        columns from network_address moved to ip_address
    </version>
    <version>           1.0.0   28.5.2004	     Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure insert IP address into table

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource Inventory
    </Application>

    <Parameters>
                        p_ip_address		ip_address in string (
						formats like nnn.nnn.nnn.nnn are accepted where n is [0..9] for ipv4
						or hhhh:hhhh:hhhh:...:hhhh (8 times) or in simplified form exmp: 1::ffe or :: which is 0:0:0...
						where h is hexadecimal digit (0..9,A..F or a..f)
					  	p_ip_address_serie_id
  						p_user_id_of_change
  						p_network_address_id,
                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/

----------------------------------------------------------------------------
--  Insert_IP_address
----------------------------------------------------------------------------

PROCEDURE INSERT_IP_ADDRESS(
                                                                                                                                                                                            p_ip_address			IN	IP_ADDRESS.IP_ADDRESS%TYPE,
  p_ip_address_serie_id IN 	IP_ADDRESS.IP_ADDRESS_SERIE_ID%TYPE,
  p_user_id_of_change	IN	IP_ADDRESS.USER_ID_OF_CHANGE%TYPE,
  p_network_address_id	OUT IP_ADDRESS.NETWORK_ADDRESS_ID%TYPE,
  handle_tran       	IN  CHAR,
  p_raise_error     	IN  CHAR,
  error_code        	OUT NUMBER,
  error_message     	OUT VARCHAR2
);




/****************************************************************************
  <header>
    <name>              procedure Delete_IP_address
    </name>

    <author>            Jaroslav Holub
    </author>

  <version>             1.0.2     03.07.2006       Petr Cepek
                        columns from network_address moved to ip_address
  </version>
	<version>			1.0.1.	3.8.2004     Jaroslav Holub
								fixed for time difference between client and server,
								date should be null and it means sysdate
	</version>
    <version>           1.0.0   28.5.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure mark IP_address row as deleted

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource Inventory
    </Application>

    <Parameters>
		p_network_address_id	id of deleted IP_address
		p_deleted				date of deletion
		p_user_id_of_change		user id of change
				handle_tran       IN  CHAR,
                p_raise_error     IN  CHAR,
                error_code        OUT NUMBER,
                error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/

----------------------------------------------------------------------------
--  Delete_IP_address
----------------------------------------------------------------------------

procedure DELETE_IP_ADDRESS(
  p_network_address_id 	IN IP_ADDRESS.NETWORK_ADDRESS_ID%TYPE,
  p_deleted				IN DATE,
  p_user_id_of_change	IN NUMBER,
  handle_tran       	IN  CHAR,
  p_raise_error     	IN  CHAR,
  error_code        	OUT NUMBER,
  error_message     	OUT VARCHAR2
);


/****************************************************************************
  <header>
    <name>              procedure Test_IP_address_OK
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.1   16.6.2004	Jaroslav Holub
                                handle cases -> '::1' == '1::' , and handle wrong format '::8:0:7:' or ':8:0:7::'
    </version>
    <version>           1.0.0   8.6.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure test if is IP addres OK it is compatible with ipv4 and ipv6 address numbering
						Procedure accept addresses like this:
							ipv4: 1.2.4.3, 192.168.0.1, ...
							ipv6: 1:18::20, AA12:3214:7691:abcd:4444:0:0:1, 1::3ef, :: ....
						also procedure returns in output parameters full length of ip address (for ipv6 replace xxxx::xxxx whit xxxx:0:..:0:xxxx)
						and also computes next IP address (if it is impossble to compute next ip there is returned NULL)
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
		p_ip_address	ip address to test
		p_ip_version	version of IP address (allowed values are 4,6)
		p_ip_address_normalized	normalized IP_address if ip address is OK
		p_next_ip		next ip address (if exists) in normalized form

		handle_tran       IN  CHAR,
		p_raise_error     IN  CHAR,
		error_code        OUT NUMBER,
		error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
procedure TEST_IP_ADDRESS_OK(
	p_ip_address			IN	IP_ADDRESS.IP_ADDRESS%TYPE,
	p_ip_version			IN 	IP_ADDRESS_SERIE.IP_VERSION%TYPE,
	p_ip_address_normalized	OUT IP_ADDRESS.IP_ADDRESS%TYPE,
	p_next_ip				OUT IP_ADDRESS.IP_ADDRESS%TYPE,
	p_raise_error   		IN	CHAR,
	error_code      		OUT	NUMBER,
	error_message   		OUT	VARCHAR2
);


/*for testing only*/
/*FUNCTION IP_TO_NUMBER(

	p_str_num		  IN  VARCHAR2,
	p_ip_version	  IN  NUMBER,
	p_raise_error     IN  CHAR,
	error_code        OUT NUMBER,
	error_message     OUT VARCHAR2
) RETURN NUMBER;


FUNCTION IP_TO_CHAR(

	p_number		  IN NUMBER,
	p_ip_version	  IN NUMBER,
	p_raise_error     IN  CHAR,
	error_code        OUT NUMBER,
	error_message     OUT VARCHAR2
) RETURN VARCHAR2;

procedure IP_ADDRESS_TO_BIN(

	p_ip_address	IN IP_ADDRESS.IP_ADDRESS%TYPE,
	p_ip_version	IN IP_ADDRESS_SERIE.IP_VERSION%TYPE,
	p_ip_binary		OUT VARCHAR2,
	p_raise_error	IN  CHAR,
	error_code		OUT NUMBER,
	error_message	OUT VARCHAR2
);
*/

/****************************************************************************
  <header>
    <name>              procedure IP_ADDRESS_TO_NUMBER
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.0   18.6.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure converts IP-address to 32 or 128 bit number

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
                        p_ip_address	ip_address
						p_ip_version	version of IP protocol (4,6)
						p_ip_number	ip  returned number (for ipv4 procedure accepts 0 .. 4294967295,
											for ipv6 accepts 0 .. 340282366920938463463374607431768211455

                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/

procedure IP_ADDRESS_TO_NUMBER(

	p_ip_address	IN IP_ADDRESS.IP_ADDRESS%TYPE,
	p_ip_version	IN IP_ADDRESS_SERIE.IP_VERSION%TYPE,
	p_ip_number		OUT NUMBER,
	p_raise_error	IN  CHAR,
	error_code		OUT NUMBER,
	error_message	OUT VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure IP_NUMBER_TO_ADDRESS
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.0   14.6.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure converts number to IP address


    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
                        p_ip_number		ip adress as a number (for ipv4 procedure accepts 0 .. 4294967295,
											for ipv6 accepts 0 .. 340282366920938463463374607431768211455
						p_ip_version	version of IP protocol (4,6)
						p_ip_address	output -> IP_Address
                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/

procedure IP_NUMBER_TO_ADDRESS(

	p_ip_number		IN 	IP_ADDRESS.IP_NUMBER%TYPE,
	p_ip_version	IN 	IP_ADDRESS_SERIE.IP_VERSION%TYPE,
	p_ip_address	OUT IP_ADDRESS.IP_ADDRESS%TYPE,
	p_raise_error	IN  CHAR,
	error_code		OUT NUMBER,
	error_message	OUT VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Get_ip_address
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>
                        1.0.3   1.12.2005   Petr Cepek
                        ordering added
    </version>
    <version>           1.0.2   01.07.2004	Jaroslav Holub
             					fix error when p_ip_number is not null and ip_version is null,
								then get allways first n ip addres, now it is fixed
    </version>
    <version>           1.0.1   21.6.2004	Jaroslav Holub
             					fix to Get_IP_Address + documnetation
    </version>
    <version>           1.0.0   18.6.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure gets IP addressses

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
		p_ip_address_serie_id	id of IP_serie or null
		p_ip_address			IP_address	or null
		p_ip_version			IP version 	or null
		p_ip_number				ip_number 	- first ip number to get or null to get first
		p_mask					mask
		p_row_count				number of rows returned
		result_list				output cursor
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
procedure GET_IP_ADDRESS(
	p_ip_address_serie_id	IN 	IP_ADDRESS_SERIE.IP_ADDRESS_SERIE_ID%TYPE,
	p_ip_address			IN 	IP_ADDRESS.IP_ADDRESS%TYPE,
	p_ip_version			IN 	IP_ADDRESS_SERIE.IP_VERSION%TYPE,
	p_ip_number				IN  IP_ADDRESS.IP_NUMBER%TYPE,
	p_mask					IN 	IP_ADDRESS_SERIE.MASK%TYPE,
	p_row_count				IN 	NUMBER,
	result_list				OUT sys_refcursor,
	p_raise_error	IN  CHAR,
	error_code		OUT NUMBER,
	error_message	OUT VARCHAR2
);


/****************************************************************************
  <header>
    <name>              procedure IS_SAME_NETWORK
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.0   10.6.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure tests if ip_addresses are in same network
						defined by mask

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
		p_IP_Address_1	first
		p_IP_Address_2	 and second IP_address to test
		p_mask			mask - specifies network
		p_ip_version	version of IP
                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/

----------------------------------------------------------------------------
--  Test_IPs_and_mask
----------------------------------------------------------------------------

PROCEDURE IS_SAME_NETWORK(

	p_IP_Address_1	IN	IP_ADDRESS.IP_ADDRESS%TYPE,
	p_IP_Address_2	IN	IP_ADDRESS.IP_ADDRESS%TYPE,
	p_mask			IN 	IP_ADDRESS_SERIE.MASK%TYPE,
	p_ip_version	IN 	IP_ADDRESS_SERIE.IP_VERSION%TYPE,
	p_raise_error	IN	CHAR,
	error_code		OUT	NUMBER,
	error_message	OUT	VARCHAR2
);


end RSIG_IP_ADDRESS;
/
