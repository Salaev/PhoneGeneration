CREATE package mnp_pkg is

----------------------------------!---------------------------------------------
  c_mnpmode_normal               constant number := 0;
  c_mnpmode_old                  constant number := 1;
  c_mnpmode_old_hash             constant number := 2;
  c_mnpmode_old_hashparallel     constant number := 3;

  c_mnp_dummy_net_op             constant number := -999999;
  c_mnp_dummy_net_op_code        constant varchar2(10) := 'DUMMY_EXT';
  c_mnp_dummy_net_op_name        constant varchar2(255) := 'Dummy external network operator for MNP';
  c_mnp_dummy_net_op_type        constant varchar2(2) := util_ri.c_NOPT_CODE_EXTERNAL;

  c_ANY_VALUE_DUMMY_NULL         constant number := NULL; --!_!

  c_name_phone_number            constant varchar2(30) := 'PHONE_NUMBER';
  c_name_network_address         constant varchar2(30) := 'NETWORK_ADDRESS';
  c_name_access_point            constant varchar2(30) := 'ACCESS_POINT';
  c_delim_for                    constant varchar2(30) := ' for ';

----------------------------------!---------------------------------------------
  c_opt_rn_prefix_val            constant varchar2(100) := 'MNP_RN_Prefix_val';
  c_opt_rn_total_length          constant varchar2(100) := 'MNP_RN_Total_length';
  c_opt_fetch_first_netop_for_rn constant varchar2(100) := 'MNP_Fetch_First_Netop_For_rn'; -- allow for multiple {rn -> nop} and {rn -> host -> nop} chains
  c_opt_mnp_mode_goers           constant varchar2(100) := 'MNP_Mode_Goers';
  c_opt_mnp_mode_comers          constant varchar2(100) := 'MNP_Mode_Comers';
  c_opt_mnp_make_po_own2same     constant varchar2(100) := 'MNP_Make_Phone_Operator_For_Own_To_Same';
  c_opt_mnp_make_po_other2same   constant varchar2(100) := 'MNP_Make_Phone_Operator_For_Other_To_Same';

  c_opt_mnp_chnetop_change_host  constant varchar2(100) := 'MNP.ChangeMainNetworkOperatoForPhoneNumber.ChangeHostByTemplate';
  c_opt_mnp_chnetop_get_host_sim constant varchar2(100) := 'MNP.ChangeMainNetworkOperatoForPhoneNumber.GetHostBySimCard';

----------------------------------!---------------------------------------------
  --!_!c_def_rn_prefix_val            constant varchar2(4000) := 'D';
  --!_!c_def_rn_total_length          constant number := 5;
  c_def_fetch_first_netop_for_rn constant boolean := false;
  c_def_mnp_mode_goers           constant number := c_mnpmode_normal;
  c_def_mnp_mode_comers          constant number := c_mnpmode_normal;
  c_def_mnp_make_po_own2same     constant boolean := false;
  c_def_mnp_make_po_other2same   constant boolean := false;

  c_def_mnp_chnetop_change_host  constant boolean := true;
  c_def_mnp_chnetop_get_host_sim constant boolean := true;

----------------------------------!---------------------------------------------
  procedure XCheck_mnp_mode(p_mnp_mode number, p_label varchar2 := null);

----------------------------------!---------------------------------------------
  function xget_rn_prefix_val return varchar2;
  function xget_rn_total_length return number;

----------------------------------!---------------------------------------------
  procedure parse_network_number_i
  (
    p_nn varchar2,
    p_marker_rn varchar2,
    p_length_rn number,
    p_msisdn out varchar2,
    p_rn out varchar2
  );

  procedure parse_network_number
  (
    p_nn ct_varchar_s,
    p_msisdn out ct_varchar_s,
    p_rn out ct_varchar_s
  );

  procedure parse_network_number2
  (
    p_nn varchar2,
    p_msisdn out varchar2,
    p_rn out varchar2
  );

----------------------------------!---------------------------------------------
  function get_lsa_id(p_lsa_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_lsa_id2(p_lsa_code varchar2, p_date date) return number;
  function get_lsa_code(p_lsa_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_lsa_code2(p_lsa_id number, p_date date) return varchar2;

----------------------------------!---------------------------------------------
  function get_routing_number_id0(p_routing_number_code ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_routing_number_id(p_routing_number_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_routing_number_id2(p_routing_number_code varchar2, p_date date) return number;
  function get_routing_number_code0(p_routing_number_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_routing_number_code(p_routing_number_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_routing_number_code2(p_routing_number_id number, p_date date) return varchar2;

----------------------------------!---------------------------------------------
  function get_rn_id4host0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_rn_id4host(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_rn_id4host2(p_host_id number, p_date date) return number;

  procedure get_rn_id4host_all(p_date date, p_host_id out ct_number, p_routing_number_id out ct_number, p_xcheck_data boolean := true);

----------------------------------!---------------------------------------------
  function get_rn_id4no0(p_network_operator_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_rn_id4no(p_network_operator_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_rn_id4no2(p_network_operator_id number, p_date date) return number;

  procedure get_rn_id4no_all(p_date date, p_network_operator_id out ct_number, p_routing_number_id out ct_number, p_xcheck_data boolean := true);

----------------------------------!---------------------------------------------
  procedure get_no_by_rn0(p_rn_id ct_number, p_date ct_date, p_trim_empty boolean, p_rn_id2 out ct_number, p_network_operator_id out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := FALSE);
  procedure get_no_by_rn(p_rn_id ct_number, p_date date, p_trim_empty boolean, p_rn_id2 out ct_number, p_network_operator_id out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := FALSE);
  function get_no_by_rn2(p_rn_id number, p_date date) return ct_number;

  procedure get_host_by_rn0(p_rn_id ct_number, p_date ct_date, p_trim_empty boolean, p_rn_id2 out ct_number, p_host_ids out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := false);
  procedure get_host_by_rn(p_rn_id ct_number, p_date date, p_trim_empty boolean, p_rn_id2 out ct_number, p_host_ids out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := false);
  function get_host_by_rn2(p_rn_id number, p_date date) return ct_number;

----------------------------------!---------------------------------------------
  function get_rn_id4ap0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number;
  function get_rn_id4ap(p_ap_id ct_number, p_date date, p_trim_empty boolean) return ct_number;
  function get_rn_id4ap2(p_ap_id number, p_date date) return number;

  function get_rn_code4imsi(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean) return ct_varchar_s;
  function get_rn_code4iccid(p_iccid ct_varchar_s, p_date ct_date, p_trim_empty boolean) return ct_varchar_s;

  function get_rn_code4msisdn(p_msisdn ct_varchar_s, p_date ct_date, p_trim_empty boolean) return ct_varchar_s;

----------------------------------!---------------------------------------------
  procedure get_phone_number_with_rn_info
  (
    p_nn ct_varchar_s,
    p_date date,
    p_msisdns out ct_varchar_s,
    p_rns out ct_varchar_s,
    p_network_operator_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure get_phone_number_type_by_pa
  (
    p_personal_accounts ct_number,
    p_min_date_of_used date,
    p_only_main_msisdn boolean,
    p_out_personal_accounts out ct_number,
    p_out_phone_type out ct_varchar_s
  );

----------------------------------!---------------------------------------------
  procedure mnp_change_data_ii
  (
    p_na_ids ct_number,
    p_no_ids ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_na_status_target varchar2,
    p_na_stat_target_match_silent boolean,
    p_na_status_current_required varchar2,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure change_1phone_operator_i
  (
    p_na_id number,
    p_date date,
    p_user_id number,
    p_no_id_own number,
    p_no_id_requested number,
    p_no_type_own varchar2,
    p_no_type_requested varchar2,
    p_make_po_own2same boolean,
    p_make_po_other2same boolean,
    p_check_exist4close boolean
  );

  function det_phone_operator_type_i
  (
    p_no_id_own number,
    p_no_id_requested number,
    p_no_type_own varchar2,
    p_no_type_requested varchar2,
    p_make_po_own2same boolean,
    p_make_po_other2same boolean
  ) return number;

----------------------------------!---------------------------------------------
  procedure restore_phones_i
  (
    p_na_ids ct_number,
    p_msisdns ct_varchar_s,
    p_phone_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure add_phones_i
  (
    p_msisdns ct_varchar_s,
    p_phone_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_out_na_ids out ct_number,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure prepare_phones2port_in_i
  (
    p_msisdns ct_varchar_s,
    p_phone_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_out_na_ids out ct_number,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

----------------------------------!---------------------------------------------
  procedure mnp_port_in_ii
  (
    p_na_ids ct_number,
    p_no_ids ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure mnp_port_in_i
  (
    p_msisdns ct_varchar_s,
    p_ap_ids ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure mnp_port_in2_i
  (
    p_msisdn varchar2,
    p_ap_id number,
    p_date date,
    p_user_id number
  );

  procedure mnp_port_in
  (
    p_msisdns ct_varchar_s,
    p_iccids ct_varchar_s,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure mnp_port_in2
  (
    p_msisdn varchar2,
    p_iccid varchar2,
    p_date date,
    p_user_id number
  );

----------------------------------!---------------------------------------------
  procedure mnp_port_out_ii
  (
    p_na_ids ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure mnp_port_out_i
  (
    p_na_ids ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure mnp_port_out2_i
  (
    p_na_id number,
    p_date date,
    p_user_id number
  );

  procedure mnp_port_out
  (
    p_msisdns ct_varchar_s,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure mnp_port_out2
  (
    p_msisdn varchar2,
    p_date date,
    p_user_id number
  );

----------------------------------!---------------------------------------------
  procedure mnp_port_in_back_ii
  (
    p_na_ids ct_number,
    p_no_ids ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure mnp_port_in_back_i
  (
    p_na_ids ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure mnp_port_in_back
  (
    p_msisdns ct_varchar_s,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure mnp_port_in_back2
  (
    p_msisdn varchar2,
    p_date date,
    p_user_id number
  );

----------------------------------!---------------------------------------------
  procedure get_next_ready2return_phones
  (
    p_user_id number,
    p_batch_id out number,
    p_msisdns out ct_varchar_s,
    p_date_froms out ct_date
  );

  procedure confirm_return_phone_batch
  (
    p_batch_id number,
    p_user_id number
  );

----------------------------------!---------------------------------------------
  function get_goers_belarus_all
  (
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_goers_belarus4na_id
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_goers_belarus
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_goers_belarus_all2
  (
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_goers_belarus4na_id2
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_goers_belarus2
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_goers_belarus_all3
  (
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_goers_belarus4na_id3
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_goers_belarus3
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_comers_belarus_all
  (
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_comers_belarus4na_id
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_comers_belarus
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_comers_belarus_all2
  (
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_comers_belarus4na_id2
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_comers_belarus2
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_comers_belarus_all3
  (
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_comers_belarus4na_id3
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_comers_belarus3
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

----------------------------------!---------------------------------------------
  function get_goers_all
  (
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_goers4na_id
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_goers
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_comers_all
  (
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_comers4na_id
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

  function get_comers
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return ct_interval;

----------------------------------!---------------------------------------------
  function get_goers2
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return sys_refcursor;

  function get_comers2
  (
    p_na_ids ct_number,
    p_range_date_from date,
    p_range_date_to date
  ) return sys_refcursor;

----------------------------------!---------------------------------------------
  function get_no_po_i0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_no_po_i(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_no_po_i2(p_na_id number, p_date date) return number;

  function get_no_po_internal0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number;
  function get_no_po_internal(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number;
  function get_no_po_internal2(p_na_id number, p_date date) return number;

  function get_no_po_external0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number;
  function get_no_po_external(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number;
  function get_no_po_external2(p_na_id number, p_date date) return number;

  function get_no_po_any0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number;
  function get_no_po_any(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number;
  function get_no_po_any2(p_na_id number, p_date date) return number;

----------------------------------!---------------------------------------------
  function xdet_pns_id4msisdn2(p_msisdn varchar2, p_date date) return number;

  function xsplit_pns4msisdn
  (
    p_msisdn varchar2,
    p_date date,
    p_user_id number
  ) return number;

  procedure xcheck_pns_can_be_latched(p_pns_id number, p_date date);
  procedure xcheck_pns_can_be_latched2(p_msisdn varchar2, p_date date);

  --!_!both mnp and template belong to internal operators
  function xcheck_data_and_get_net_op
  (
    p_msisdn_mnp varchar2,
    p_msisdn_template varchar2,
    p_date date
  ) return number;

  function xget_host4pn(p_msisdn varchar2, p_date date) return number;
  function xget_host4sim(p_msisdn varchar2, p_date date) return number;

  --!_!both mnp and template belong to internal operators
  procedure change_main_net_op4phone_num
  (
    p_msisdn_mnp varchar2,
    p_msisdn_template varchar2,
    p_date date,
    p_user_id number
  );

  --!_!both mnp and template belong to internal operators
  procedure xcheck4change_main_net_op
  (
    p_msisdn_mnp varchar2,
    p_msisdn_template varchar2,
    p_date date
  );

----------------------------------!---------------------------------------------
  function get_no_own_internal0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number;
  function get_no_own_internal(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number;
  function get_no_own_internal2(p_na_id number, p_date date) return number;

  function get_no_own_external0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number;
  function get_no_own_external(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number;
  function get_no_own_external2(p_na_id number, p_date date) return number;

  function get_no_own_any0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number;
  function get_no_own_any(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number;
  function get_no_own_any2(p_na_id number, p_date date) return number;

  function get_no_current_any0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number;
  function get_no_current_any(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number;
  function get_no_current_any2(p_na_id number, p_date date) return number;

----------------------------------!---------------------------------------------
  --!_!call only after PortIn
  function xget_proper_hlr2(p_na_id number, p_date date) return number;

  function is_mnp_port_in_valid2
  (
    p_msisdn_mnp varchar2,
    p_msisdn_template varchar2,
    p_date date
  ) return boolean;

----------------------------------!---------------------------------------------
  function get_expired_phone_operator
  (
    p_expire_date date
  ) return sys_refcursor;

----------------------------------!---------------------------------------------
  procedure get_phone_info
  (
    p_msisdn ct_varchar_s,
    p_result out sys_refcursor
  );

  procedure get_main_host_by_iccid
  (
    p_iccid ct_varchar_s,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------

end;
/
