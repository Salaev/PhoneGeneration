CREATE package body vp_agroup is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return agroup%rowtype
is
  v_res agroup%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_AGROUP_ID)*/
        * into v_res
        from agroup z
        where 1 = 1
        and agroup_id = p_id
        and p_date between date_from and date_to
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_AGROUP_ID)*/
        * into v_res
        from agroup z
        where 1 = 1
        and agroup_id = p_id
        and p_date between date_from and date_to
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_AGROUP_ID)*/
      * into v_res
      from agroup z
      where 1 = 1
      and agroup_id = p_id
      and p_date between date_from and date_to
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1(p_id integer, p_date date) return agroup%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get1_i(p_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget1(p_id integer, p_date date) return agroup%rowtype
is
  v_res agroup%rowtype;
begin
  ------------------------------
  v_res := get1(p_id, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get1(p_id integer, p_date date) return agroup%rowtype
is
  v_res agroup%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_i(p_id, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_xget1(p_id integer, p_date date) return agroup%rowtype
is
  v_res agroup%rowtype;
begin
  ------------------------------
  v_res := xlock_get1(p_id, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xvalid_i(p_rec agroup%rowtype)
is
begin
  ------------------------------
  util_pkg.xcheck_version_dates(p_rec.date_from, p_rec.date_to);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function find_i_id(p_rec agroup%rowtype) return boolean
is
  v_cnt number;
begin
  ------------------------------
select /*+ index_asc(z, I_AGROUP_ID)*/
  count(1) cnt into v_cnt
  from agroup z
  where 1 = 1
  and agroup_id = p_rec.agroup_id
  and greatest(p_rec.date_from, date_from) <= least(p_rec.date_to, date_to)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_name(p_rec agroup%rowtype) return boolean
is
  v_cnt number;
begin
  ------------------------------
select /*+ index_asc(z, I_AGROUP_NAME)*/
  count(1) cnt into v_cnt
  from agroup z
  where 1 = 1
  and agroup_name = p_rec.agroup_name
  and greatest(p_rec.date_from, date_from) <= least(p_rec.date_to, date_to)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i(p_rec agroup%rowtype) return boolean
is
begin
  ------------------------------
  if find_i_id(p_rec)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_name(p_rec)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xunique_i(p_rec agroup%rowtype)
is
begin
  ------------------------------
  if find_i_id(p_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_Vers2(p_rec.agroup_id, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_name(p_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_Vers(util_pkg.nchar_to_char(p_rec.agroup_name), p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_i(p_rec agroup%rowtype)
is
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
  xunique_i(p_rec);
  ------------------------------
  insert into agroup
  values p_rec;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure close_i(p_rec agroup%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
update /*+ index_asc(z, I_AGROUP_ID)*/
  agroup z
  set
    date_to = p_rec.date_to,
    user_id = p_rec.user_id,
    change_date = p_rec.change_date
  where 1 = 1
  and agroup_id = p_rec.agroup_id
  and p_rec.date_to between date_from and date_to
  and date_from = p_rec.date_from
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_Vers2(p_rec.agroup_id, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_OnDate2(p_rec.agroup_id, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure delete_i(p_rec agroup%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
delete /*+ index_asc(z, I_AGROUP_ID)*/
  agroup z
  where 1 = 1
  and agroup_id = p_rec.agroup_id
  and p_rec.date_to between date_from and date_to
  and date_from = p_rec.date_from
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_Vers2(p_rec.agroup_id, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_OnDate2(p_rec.agroup_id, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_identified(p_rec agroup%rowtype) return boolean
is
begin
  ------------------------------
  return (p_rec.agroup_id is not null);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_exist(p_id number, p_date_from date, p_date_to date) return boolean
is
  v_rec agroup%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date_from is null, 'p_date_from');
  util_pkg.XCheck_Cond_Missing(p_date_to is null, 'p_date_to');
  ------------------------------
  v_rec.agroup_id := p_id;
  v_rec.date_from := p_date_from;
  v_rec.date_to := p_date_to;
  ------------------------------
  return find_i(v_rec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function acquire_id return number
is
begin
  ------------------------------
  return sq_agroup.nextval;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_open(p_rec in out nocopy agroup%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  p_rec.agroup_id := nvl(p_rec.agroup_id, acquire_id);
  ------------------------------
  p_rec.date_from := nvl(p_rec.date_from, v_sysdate);
  p_rec.date_to := nvl(p_rec.date_to, util_pkg.c_open_date_to);
  ------------------------------
  p_rec.change_date := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change(p_rec in out nocopy agroup%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_to_prev date;
  v_rec agroup%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.agroup_id is null, 'p_rec.agroup_id');
  ------------------------------
  p_rec.date_from := nvl(p_rec.date_from, v_sysdate);
  p_rec.date_to := nvl(p_rec.date_to, util_pkg.c_open_date_to);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(p_rec.date_from);
  ------------------------------
  v_rec := xlock_xget1(p_rec.agroup_id, v_date_to_prev);
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.user_id := p_rec.user_id;
  ------------------------------
  v_rec.change_date := v_sysdate;
  v_rec.date_to := v_date_to_prev;
  ------------------------------
  close_i(v_rec);
  ------------------------------
  p_rec.change_date := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close
(
  p_id integer,
  p_user_id integer,
  p_date_from date := null, --!_!for p_hard_delete: p_date_from = v_rec.date_from (p_id = v_rec.table_name_id)
  p_hard_delete boolean := false
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_to_prev date;
  v_rec agroup%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_hard_delete is null, 'p_hard_delete');
  util_pkg.XCheck_Cond_Missing(p_hard_delete and p_date_from is null, 'p_date_from');
  ------------------------------
  if p_hard_delete
  then
    ------------------------------
    v_date_to_prev := p_date_from;
    ------------------------------
  else
    ------------------------------
    v_date_to_prev := util_pkg.date_from2date_to_prev(nvl(p_date_from, v_sysdate));
    ------------------------------
  end if;
  ------------------------------
  v_rec := xlock_xget1(p_id, v_date_to_prev);
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.user_id := p_user_id;
  ------------------------------
  v_rec.change_date := v_sysdate;
  v_rec.date_to := v_date_to_prev;
  ------------------------------
  if p_hard_delete
  then
    delete_i(v_rec);
  else
    close_i(v_rec);
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
