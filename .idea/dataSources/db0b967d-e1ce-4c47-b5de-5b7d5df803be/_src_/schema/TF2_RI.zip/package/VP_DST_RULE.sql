CREATE package VP_DST_RULE is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'DST_RULE';

----------------------------------!---------------------------------------------
  function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return dst_rule%rowtype;

  function get1(p_id integer, p_date date) return dst_rule%rowtype;
  function xlock_get1(p_id integer, p_date date) return dst_rule%rowtype;

----------------------------------!---------------------------------------------
  function find_i_id(p_rec dst_rule%rowtype, p_check_only_other_ids boolean) return boolean;

  function find_i(p_rec dst_rule%rowtype, p_check_only_other_ids boolean) return boolean;
  procedure xunique_i(p_rec dst_rule%rowtype, p_check_only_other_ids boolean);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec dst_rule%rowtype);
  procedure change_i(p_rec dst_rule%rowtype);

  procedure close_i(p_rec dst_rule%rowtype); --!_!

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy dst_rule%rowtype);
  procedure version_change(p_rec in out nocopy dst_rule%rowtype, p_date_from_virt date := null);

  procedure version_close
  (
    p_id integer,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------

end;
/
