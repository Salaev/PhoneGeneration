CREATE PACKAGE          "RSIG_SIM_AUTH_TYPE" IS
/****************************************************************************
<header>
  <name>             	package RSIG_SIM_AUTH_TYPE
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>
  <version>          	1.0.1   22.06.2009     Radek Hejduk
                                created first version
  </version>

  <Description>      	package for table SIM_AUTH_TYPE
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/
/****************************************************************************
<header>
  <name>             	procedure Get_Sim_Auth_Types
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>          	1.0.1   22.06.2009     Radek Hejduk
                                created first version
  </version>

  <Description>      	procedure returns all sim authentication types as IN OUT ref cursor
  </Description>

  <Prerequisites>     PROCEDURE Get_Sim_Auth_Types (
                              error_code                 OUT    NUMBER,
                              p_cur_sim_auth_types       IN OUT RSIG_UTILS.REF_CURSOR
                      );
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        error_code - OUT - NUMBER
                      p_cur_sim_auth_types - IN OUT - ref cursor
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Get_Sim_Auth_Types (
    error_code                 OUT    NUMBER,
    p_cur_sim_auth_types       IN OUT RSIG_UTILS.REF_CURSOR
  );
END RSIG_SIM_AUTH_TYPE;


/
