CREATE package body VP_SIM_CARD is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return sim_card%rowtype
is
  v_res sim_card%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, PK_SIM_CARD)*/
        * into v_res
        from sim_card z
        where 1 = 1
        and access_point_id = p_id
        and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, PK_SIM_CARD)*/
        * into v_res
        from sim_card z
        where 1 = 1
        and access_point_id = p_id
        and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, PK_SIM_CARD)*/
      * into v_res
      from sim_card z
      where 1 = 1
      and access_point_id = p_id
      and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1(p_id integer, p_date date) return sim_card%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get1_i(p_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget1(p_id integer, p_date date) return sim_card%rowtype
is
  v_res sim_card%rowtype;
begin
  ------------------------------
  v_res := get1(p_id, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get1(p_id integer, p_date date) return sim_card%rowtype
is
  v_res sim_card%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_i(p_id, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_xget1(p_id integer, p_date date) return sim_card%rowtype
is
  v_res sim_card%rowtype;
begin
  ------------------------------
  v_res := xlock_get1(p_id, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xlock(p_id integer, p_date date)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(xlock_xget1(p_id, p_date).access_point_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function find_i_id(p_rec sim_card%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_cnt number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.access_point_id is null, 'p_rec.access_point_id');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  if p_check_only_other_ids
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
select /*+ index_asc(z, PK_SIM_CARD)*/
  count(1) cnt into v_cnt
  from sim_card z
  where 1 = 1
  and access_point_id = p_rec.access_point_id
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  --!_!and (v_check_only_other_ids = util_pkg.c_false or sim_card_id != p_rec.sim_card_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_imsi(p_rec sim_card%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
  --!_!v_date date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.access_point_id is null, 'p_rec.access_point_id');
  util_pkg.XCheck_Cond_Missing(p_rec.imsi is null, 'p_rec.imsi');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  --!_!v_date := util_ri.deleted2valid_date_to(p_rec.deleted);
  ------------------------------
select /*+ index_asc(z, UK_SIM_IMSI)*/
  count(1) cnt into v_cnt
  from sim_card z
  where 1 = 1
  and imsi = p_rec.imsi
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  and (v_check_only_other_ids = util_pkg.c_false or access_point_id != p_rec.access_point_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_iccid(p_rec sim_card%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
  --!_!v_date date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.access_point_id is null, 'p_rec.access_point_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_rec.sn is null, 'p_rec.sn');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  --!_!v_date := util_ri.deleted2valid_date_to(p_rec.deleted);
  ------------------------------
select /*+ index_asc(z, UK_SIM_SN)*/
  count(1) cnt into v_cnt
  from sim_card z
  where 1 = 1
  and sn = p_rec.sn
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  and (v_check_only_other_ids = util_pkg.c_false or access_point_id != p_rec.access_point_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_msisdn_bound(p_rec sim_card%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
  --!_!v_date date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.access_point_id is null, 'p_rec.access_point_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_rec.msisdn_bound is null, 'p_rec.msisdn_bound');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  --!_!v_date := util_ri.deleted2valid_date_to(p_rec.deleted);
  ------------------------------
select /*+ index_asc(z, UK_SIM_MSIDN_BOUND)*/
  count(1) cnt into v_cnt
  from sim_card z
  where 1 = 1
  and msisdn_bound = p_rec.msisdn_bound
  --and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  and (v_check_only_other_ids = util_pkg.c_false or access_point_id != p_rec.access_point_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i(p_rec sim_card%rowtype, p_check_only_other_ids boolean) return boolean
is
begin
  ------------------------------
  if find_i_id(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_imsi(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_iccid(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_msisdn_bound(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xunique_i(p_rec sim_card%rowtype, p_check_only_other_ids boolean)
is
begin
  ------------------------------
  if find_i_id(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    --!_!util_pkg.Raise_Obj_NotUniq_OnDate2(p_rec.access_point_id, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    util_pkg.Raise_Obj_NotUniq_ID2(p_rec.access_point_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_imsi(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    --!_!util_pkg.Raise_Obj_NotUniq_OnDate(p_rec.imsi, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    util_pkg.Raise_Obj_NotUniq_ID(p_rec.imsi, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_iccid(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    --!_!util_pkg.Raise_Obj_NotUniq_OnDate(p_rec.sn, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    util_pkg.Raise_Obj_NotUniq_ID(p_rec.sn, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_msisdn_bound(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    --!_!util_pkg.Raise_Obj_NotUniq_OnDate(p_rec.msisdn_bound, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    util_pkg.Raise_Obj_NotUniq_ID(p_rec.msisdn_bound, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_i(p_rec sim_card%rowtype)
is
begin
  ------------------------------
  xunique_i(p_rec, FALSE);
  ------------------------------
  insert into access_point ap(access_point_id)
  values (p_rec.access_point_id);
  ------------------------------
  insert into sim_card
  values p_rec;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure change_i(p_rec sim_card%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xunique_i(p_rec, TRUE);
  ------------------------------
update /*+ index_asc(z, PK_SIM_CARD)*/
  sim_card z
  set
    row = p_rec
  where 1 = 1
  and access_point_id = p_rec.access_point_id
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_ID2(p_rec.access_point_id, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_ID2(p_rec.access_point_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_identified(p_rec sim_card%rowtype) return boolean
is
begin
  ------------------------------
  return (p_rec.access_point_id is not null);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open(p_rec in out nocopy sim_card%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_si_rec sim_imsi%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  p_rec.access_point_id := nvl(p_rec.access_point_id, s_access_point.nextval);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
  v_si_rec := null;
  v_si_rec.imsi := p_rec.imsi;
  v_si_rec.access_point_id := p_rec.access_point_id;
  v_si_rec.sim_series_id := p_rec.sim_series_id;
  v_si_rec.imsi_type_code := vp_sim_imsi.get_imsi_type_main;
  ------------------------------
  vp_sim_imsi.version_open(v_si_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change(p_rec in out nocopy sim_card%rowtype, p_date_from_virt date := null)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_si_rec sim_imsi%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.access_point_id is null, 'p_rec.access_point_id');
  ------------------------------
  v_date_from_new := nvl(p_date_from_virt, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  xlock(p_rec.access_point_id, v_date_to_prev);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  change_i(p_rec);
  ------------------------------
  v_si_rec := vp_sim_imsi.xlock_xget1(p_rec.imsi, v_date_to_prev);
  ------------------------------
  v_si_rec.access_point_id := p_rec.access_point_id;
  v_si_rec.sim_series_id := p_rec.sim_series_id;
  v_si_rec.imsi_type_code := vp_sim_imsi.get_imsi_type_main;
  ------------------------------
  vp_sim_imsi.version_change(v_si_rec, v_date_from_new);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close
(
  p_id integer,
  p_user_id integer,
  p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_rec sim_card%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_date_from_new := nvl(p_date_from, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  v_rec := xlock_xget1(p_id, v_date_to_prev);
  ------------------------------
  v_rec.user_id_of_change := p_user_id;
  ------------------------------
  v_rec.date_of_change := v_sysdate;
  v_rec.deleted := util_ri.valid_date_to2deleted(v_date_to_prev);
  ------------------------------
  change_i(v_rec);
  ------------------------------
  vp_sim_imsi.version_close(v_rec.imsi, p_user_id, v_date_from_new);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open2(p_rec in out nocopy sim_card%rowtype, p_addition_imsi ct_varchar_s)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_si_rec sim_imsi%rowtype;
  v_count number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  p_rec.access_point_id := nvl(p_rec.access_point_id, s_access_point.nextval);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
  v_si_rec := null;
  v_si_rec.imsi := p_rec.imsi;
  v_si_rec.access_point_id := p_rec.access_point_id;
  v_si_rec.sim_series_id := p_rec.sim_series_id;
  v_si_rec.imsi_type_code := vp_sim_imsi.get_imsi_type_main;
  vp_sim_imsi.version_open(v_si_rec);
  ------------------------------
  v_count := util_pkg.get_count_ct_varchar_s(p_addition_imsi);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_si_rec := null;
    v_si_rec.imsi := p_addition_imsi(v_i);
    v_si_rec.access_point_id := p_rec.access_point_id;
    v_si_rec.sim_series_id := p_rec.sim_series_id;
    v_si_rec.imsi_type_code := vp_sim_imsi.make_imsi_add_type(p_imsi_add_order_num => v_i);
    ------------------------------
    vp_sim_imsi.version_open(v_si_rec);
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change2(p_rec in out nocopy sim_card%rowtype, p_addition_imsi ct_varchar_s, p_date_from_virt date := null)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_si_rec sim_imsi%rowtype;
  v_count number;
  v_addition_imsi_old vp_sim_imsi.rct_sim_imsi;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.access_point_id is null, 'p_rec.access_point_id');
  ------------------------------
  v_date_from_new := nvl(p_date_from_virt, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  xlock(p_rec.access_point_id, v_date_to_prev);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  change_i(p_rec);
  ------------------------------
  v_si_rec := vp_sim_imsi.xlock_xget1(p_rec.imsi, v_date_to_prev);
  ------------------------------
  v_si_rec.access_point_id := p_rec.access_point_id;
  v_si_rec.sim_series_id := p_rec.sim_series_id;
  v_si_rec.imsi_type_code := vp_sim_imsi.get_imsi_type_main;
  ------------------------------
  vp_sim_imsi.version_change(v_si_rec, v_date_from_new);
  ------------------------------
  v_addition_imsi_old := vp_sim_imsi.xlock_getN_ap_id(p_rec.access_point_id, v_date_to_prev);
  ------------------------------
  v_count := vp_sim_imsi.get_count_rct_sim_imsi(v_addition_imsi_old);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    vp_sim_imsi.version_close
    (
      p_id_imsi => v_addition_imsi_old(v_i).imsi,
      p_user_id => p_rec.user_id_of_change,
      p_date_from => v_date_from_new
    );
    ------------------------------
  end loop;
  ------------------------------
  v_count := util_pkg.get_count_ct_varchar_s(p_addition_imsi);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_si_rec := null;
    v_si_rec.imsi := p_addition_imsi(v_i);
    v_si_rec.access_point_id := p_rec.access_point_id;
    v_si_rec.sim_series_id := p_rec.sim_series_id;
    v_si_rec.imsi_type_code := vp_sim_imsi.make_imsi_add_type(p_imsi_add_order_num => v_i);
    ------------------------------
    vp_sim_imsi.version_open(v_si_rec);
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close2
(
  p_id integer,
  p_user_id integer,
  p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_rec sim_card%rowtype;
  v_count number;
  v_addition_imsi_old vp_sim_imsi.rct_sim_imsi;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_date_from_new := nvl(p_date_from, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  v_rec := xlock_xget1(p_id, v_date_to_prev);
  ------------------------------
  v_rec.user_id_of_change := p_user_id;
  ------------------------------
  v_rec.date_of_change := v_sysdate;
  v_rec.deleted := util_ri.valid_date_to2deleted(v_date_to_prev);
  ------------------------------
  change_i(v_rec);
  ------------------------------
  vp_sim_imsi.version_close(v_rec.imsi, p_user_id, v_date_from_new);
  ------------------------------
  v_addition_imsi_old := vp_sim_imsi.xlock_getN_ap_id(v_rec.access_point_id, v_date_to_prev);
  ------------------------------
  v_count := vp_sim_imsi.get_count_rct_sim_imsi(v_addition_imsi_old);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    vp_sim_imsi.version_close
    (
      p_id_imsi => v_addition_imsi_old(v_i).imsi,
      p_user_id => p_user_id,
      p_date_from => v_date_from_new
    );
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
