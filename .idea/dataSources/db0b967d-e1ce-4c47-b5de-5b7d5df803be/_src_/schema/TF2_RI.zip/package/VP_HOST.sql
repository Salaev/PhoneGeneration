CREATE package VP_HOST is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'HOST';

----------------------------------!---------------------------------------------
  function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return host%rowtype;

  function get1(p_id integer, p_date date) return host%rowtype;
  function xlock_get1(p_id integer, p_date date) return host%rowtype;

----------------------------------!---------------------------------------------
  function find_i_id(p_rec host%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_code(p_rec host%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_name(p_rec host%rowtype, p_check_only_other_ids boolean) return boolean;

  function find_i(p_rec host%rowtype, p_check_only_other_ids boolean) return boolean;
  procedure xunique_i(p_rec host%rowtype, p_check_only_other_ids boolean);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec host%rowtype);
  procedure change_i(p_rec host%rowtype);

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy host%rowtype);
  procedure version_change(p_rec in out nocopy host%rowtype, p_date_from_virt date := null);

  procedure version_close
  (
    p_id integer,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------
  procedure version_open2
  (
    p_rec in out nocopy host%rowtype,
    p_routing_number_id integer,
    p_date_from date := null
  );

  procedure version_change2
  (
    p_rec in out nocopy host%rowtype,
    p_routing_number_id integer,
    p_date_from date := null
  );

  procedure version_close2
  (
    p_id integer,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------

end;
/
