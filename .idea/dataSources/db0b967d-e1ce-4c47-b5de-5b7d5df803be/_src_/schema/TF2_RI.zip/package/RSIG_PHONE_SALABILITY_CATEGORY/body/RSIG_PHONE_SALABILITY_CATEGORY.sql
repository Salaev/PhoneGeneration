CREATE PACKAGE BODY RSIG_PHONE_SALABILITY_CATEGORY IS

---------------------------------------------
--     PROCEDURE Get_Salability_Categories
---------------------------------------------

PROCEDURE Get_Salability_Categories
(
  error_code       OUT NUMBER,
  p_cur_categories IN OUT RSIG_UTILS.REF_CURSOR -- cursor variable containing data about all salability categories
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PHONE_SALABILITY_CATEGORY.Get_Salability_Categories';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_categories FOR
    select PHONE_SALABILITY_CATEGORY_CODE SALABILITY_CATEGORY_CODE,
           PHONE_SALABILITY_CATEGORY_NAME SALABILITY_CATEGORY_NAME,
           DELETED
      from PHONE_SALABILITY_CATEGORY;

  error_code := RSIG_UTILS.c_OK;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(to_number(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_Salability_Categories;

---------------------------------------------
--     PROCEDURE Set_Masks
---------------------------------------------

PROCEDURE Set_Masks
(
  handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_user_id_of_change   IN NUMBER,
  p_salability_category IN VARCHAR2, -- Salability categories codes delimited by semicolon
  p_mask                IN VARCHAR2 -- Masks delimited by semicolon
  --    error_code            OUT NUMBER,
  --    error_text            OUT VARCHAR2
) IS
  v_event_source          VARCHAR2(60) := 'RSIG_PHONE_SALABILITY_CATEGORY.Set_Masks';
  var_salability_category table_of_string := table_of_string();
  var_mask                table_of_string := table_of_string();
  v_pos_act               NUMBER;
  v_pos_old               NUMBER;
  v_poc_f                 NUMBER;
  v_next_id               NUMBER;
  v_date                  DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF /*p_salability_category IS NULL
     OR p_mask IS NULL
     OR */p_user_id_of_change IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  v_date    := SYSDATE;
  v_poc_f   := 0;
  v_pos_act := 1;
  v_pos_old := 1;

  -- fill collect calability category
  WHILE nvl(v_pos_act, 0) <> 0
  LOOP
    v_pos_act := INSTR(p_salability_category, ';', v_pos_old);
    IF v_pos_act > 0 THEN
      v_poc_f := v_poc_f + 1;
      var_salability_category.EXTEND;
      var_salability_category(v_poc_f) := SUBSTR(p_salability_category, v_pos_old, v_pos_act - v_pos_old);
      v_pos_old := v_pos_act + 1;
    END IF;
  END LOOP;

  IF v_pos_old <= LENGTH(p_salability_category) THEN
    v_poc_f := v_poc_f + 1;
    var_salability_category.EXTEND;
    var_salability_category(v_poc_f) := SUBSTR(p_salability_category, v_pos_old);
  end if;

  v_poc_f   := 0;
  v_pos_act := 1;
  v_pos_old := 1;

  -- fill collect mask
  WHILE nvl(v_pos_act, 0) <> 0
  LOOP
    v_pos_act := INSTR(p_mask, ';', v_pos_old);
    IF v_pos_act > 0 THEN
      v_poc_f := v_poc_f + 1;
      var_mask.EXTEND;
      var_mask(v_poc_f) := SUBSTR(p_mask, v_pos_old, v_pos_act - v_pos_old);
      v_pos_old := v_pos_act + 1;
    END IF;
  END LOOP;

  IF v_pos_old <= LENGTH(p_mask) THEN
    v_poc_f := v_poc_f + 1;
    var_mask.EXTEND;
    var_mask(v_poc_f) := SUBSTR(p_mask, v_pos_old);
  end if;

  IF var_salability_category.LAST <> var_mask.LAST THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint update_salability_category_a;
  END IF;

  DELETE FROM salability_category_mask
   WHERE mask NOT IN (SELECT * FROM TABLE(CAST(var_mask AS table_of_string)) t);

  FOR I IN nvl(var_salability_category.FIRST, 1) .. nvl(var_salability_category.LAST, 0)
  LOOP
    v_poc_f := 0;
    SELECT COUNT(*) INTO v_poc_f FROM salability_category_mask WHERE mask = var_mask(I);

    IF v_poc_f = 0 THEN

      SELECT s_salability_category_mask.NEXTVAL INTO v_next_id FROM dual;

      INSERT INTO salability_category_mask
        (salability_category_mask_id,
         salability_category_code,
         mask,
         date_of_change,
         user_id_of_change)
      VALUES
        (v_next_id,
         var_salability_category(I),
         var_mask(I),
         v_date,
         p_user_id_of_change);
    ELSE
      UPDATE salability_category_mask
         SET salability_category_code = var_salability_category(I),
             date_of_change           = v_date,
             user_id_of_change        = p_user_id_of_change
       WHERE mask = var_mask(I)
         AND TRIM(salability_category_code) <> TRIM(var_salability_category(I));
    END IF;
  END LOOP;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  --    error_code := rsig_utils.c_OK;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      --        error_code := sqlcode;
      --        error_text := SQLERRM(sqlcode);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint update_salability_category_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Set_Masks;

---------------------------------------------
--     PROCEDURE Get_Masks
---------------------------------------------

PROCEDURE Get_Masks(result_list OUT RSIG_UTILS.REF_CURSOR) IS
  v_event_source VARCHAR2(60) := 'RSIG_PHONE_SALABILITY_CATEGORY.Get_Masks';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN result_list FOR
    SELECT scm.salability_category_mask_id,
           scm.salability_category_code,
           psc.phone_salability_category_name salability_category_name,
           psc.attractiveness_level,
           scm.mask,
           scm.date_of_change,
           scm.user_id_of_change,
           u.user_name
      FROM SALABILITY_CATEGORY_MASK scm
      JOIN PHONE_SALABILITY_CATEGORY psc ON TRIM(scm.salability_category_code) = TRIM(psc.phone_salability_category_code)
      LEFT JOIN USERS u ON scm.user_id_of_change = u.user_id;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

END Get_Masks;

END;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_PHONE_SALABILITY_CATEGORY.pkb,v 1.21 2003/12/22 10:54:25 rhejduk Exp $
/
