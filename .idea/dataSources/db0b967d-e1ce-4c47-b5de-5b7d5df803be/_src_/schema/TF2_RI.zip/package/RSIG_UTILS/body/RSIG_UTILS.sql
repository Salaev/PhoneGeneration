CREATE PACKAGE BODY RSIG_UTILS IS

--  v_last_error NUMBER; -- contain last error (from Handle_Error)

---------------------------------------------
--     FUNCTION Check_Interval_Overlapping
---------------------------------------------

FUNCTION Check_Interval_Overlapping
(
  ERROR_CODE   OUT NUMBER,
  p_start_date IN DATE, -- the starting date of an interval
  p_end_date   IN DATE DEFAULT NULL, -- the ending date of an interval
  p_table_name IN VARCHAR2 -- the name of the table containing the intervals we compare interval given in the first two parameters with
) RETURN NUMBER IS
  cur_overlapped RSIG_UTILS.REF_CURSOR; -- cursor containing records that overlap given date in given table
  v_overlapped   NUMBER DEFAULT RSIG_UTILS.c_FALSE; -- if true, then intervals overlap else they do not overlap
  v_start_date   DATE; -- starting date of the second interval
  v_end_date     DATE; -- ending date of the second interval
BEGIN
  IF p_start_date > p_end_date THEN
    RAISE_APPLICATION_ERROR(c_ORA_INVALID_INTERVAL, '');
  END IF;

  OPEN cur_overlapped FOR 'select START_DATE, END_DATE from ' || p_table_name;
  LOOP
    FETCH cur_overlapped
      INTO v_start_date, v_end_date;
    EXIT WHEN cur_overlapped%NOTFOUND;
    IF (p_end_date IS NOT NULL AND p_end_date < v_start_date)
       OR ((v_end_date IS NOT NULL AND v_end_date < p_start_date)) THEN
      v_overlapped := RSIG_UTILS.c_OK;
    ELSE
      v_overlapped := RSIG_UTILS.c_FALSE;
    END IF;

    IF v_overlapped = RSIG_UTILS.c_FALSE THEN
      EXIT;
    END IF;
  END LOOP;

  CLOSE cur_overlapped;

  RETURN v_overlapped;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RETURN RSIG_UTILS.c_ERROR;
    END;
END Check_Interval_Overlapping;

---------------------------------------------
--     FUNCTION Get_Constraint_Name
---------------------------------------------

FUNCTION Get_Constraint_Name(err_msg IN VARCHAR2) RETURN VARCHAR2 IS
  RESULT VARCHAR2(100);
  Count1 INTEGER := 0;
  Count2 INTEGER := 0;
BEGIN
  count1 := instr(err_msg, '.');
  count2 := instr(err_msg, ')');
  RESULT := substr(err_msg, count1 + 1, count2 - count1 - 1);
  RETURN(RESULT);
END Get_Constraint_Name;

---------------------------------------------
--     FUNCTION Handle_Error
---------------------------------------------

FUNCTION Handle_Error(p_ora_error_number NUMBER -- Oracle error code
                      ) RETURN NUMBER IS
  v_error_code NUMBER; -- variable containing error code generated according to ora error number
BEGIN

  IF (p_ora_error_number <= -20000) THEN
    v_error_code := p_ora_error_number + 20000;
  ELSE
    v_error_code := p_ora_error_number;
  END IF;
  --save error
  --v_last_error := p_ora_error_number;

  RETURN v_error_code;
END Handle_Error;

---------------------------------------------
--     PROCEDURE Set_Output
---------------------------------------------

PROCEDURE Set_Output(p_output VARCHAR2 -- where to send output from Rsi_Debug function
                     ) IS
BEGIN
  RSIG_UTILS.v_output := p_output;
END Set_Output;

---------------------------------------------
--     PROCEDURE Set_Level
---------------------------------------------

PROCEDURE Set_Level(p_level VARCHAR2 -- level of debugging
                    ) IS
BEGIN
  RSIG_UTILS.v_debug_level := p_level;
END Set_Level;

---------------------------------------------
--     PROCEDURE Debug_Rsi
---------------------------------------------

PROCEDURE Debug_Rsi
(
  p_text         LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
  p_level        NUMBER, -- level of debuging
  p_event_type   LOG_EVENT.EVENT_TYPE%TYPE, -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
  p_event_source LOG_EVENT.EVENT_SOURCE%TYPE -- name of the source where this calling is performed
) IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  v_user        LOG_EVENT.EVENT_USER%TYPE; -- name of the user who runs this procedure
  v_computer    LOG_EVENT.EVENT_COMPUTER%TYPE; -- name of the computer this procedure is run at
  v_file_handle UTL_FILE.FILE_TYPE; -- file handle of OS flat file
  v_text        VARCHAR2(400); -- text for c_DEBUG_TO_BUFFER or c_DEBUG_TO_FILE
  v_na_str      VARCHAR2(30) := 'N/A';
BEGIN

  -- do not debug when debugging level is higher than level set in db_parameters table
  IF p_level > RSIG_UTILS.v_debug_level THEN
    RETURN;
  END IF;

  --v_computer := substr(nvl(sys_context('userenv', 'terminal'), v_na_str), 1, 63);
  v_computer := substr(nvl(sys_context('userenv', 'host'), v_na_str), 1, 63);
  v_user     := substr(nvl(sys_context('userenv', 'os_user'), v_na_str), 1, 63);

  v_text := substr('Date: ' || to_char(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' User: ' || v_user || ' Computer: ' ||
            v_computer || ' Called in: ' || p_event_source || ' Text: ' || p_text, 1, 400);

  CASE RSIG_UTILS.v_output
  -- Log to buffer
    WHEN RSIG_UTILS.c_DEBUG_TO_BUFFER THEN
      DBMS_OUTPUT.PUT_LINE(substr(v_text, 1, 255));
      -- Log to file
    WHEN RSIG_UTILS.c_DEBUG_TO_FILE THEN
      BEGIN
        --append text to debug file
        --is debug file open - wait
        LOOP
          v_file_handle := UTL_FILE.FOPEN('RSIG_DEBUG', 'debug_' || lower(v_computer) || '.log', 'a');
          IF UTL_FILE.IS_OPEN(v_file_handle) THEN
            UTL_FILE.PUT_LINE(v_file_handle, substr(v_text, 1, 1022)); --MAX 1023 B
            UTL_FILE.FCLOSE(v_file_handle);
            EXIT;
          END IF;
        END LOOP;
      END;
      -- log to table
    WHEN RSIG_UTILS.c_DEBUG_TO_TABLE THEN
      BEGIN
        INSERT INTO LOG_EVENT
          (EVENT_ID,
           EVENT_TYPE,
           EVENT_SOURCE,
           EVENT_MESSAGE,
           EVENT_USER,
           EVENT_COMPUTER,
           EVENT_TIME)
        VALUES
          (S_LOG_EVENT.NEXTVAL,
           p_event_type,
           substr(p_event_source, 1, 63),
           substr(p_text, 1, 255),
           substr(v_user, 1, 63),
           substr(v_computer, 1, 63),
           SYSDATE);
      END;
  END CASE;

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    --DBMS_OUTPUT.put_line(SQLERRM);
    ROLLBACK;

    IF RSIG_UTILS.v_output = RSIG_UTILS.c_DEBUG_TO_FILE THEN
      IF UTL_FILE.IS_OPEN(v_file_handle) THEN
        UTL_FILE.FCLOSE(v_file_handle);
      END IF;
    END IF;

    RAISE;
END Debug_Rsi;

---------------------------------------------
--     FUNCTION Is_Serie_Between
---------------------------------------------

FUNCTION Is_Serie_Between
(
  ERROR_CODE               OUT NUMBER,
  p_phone_number_serie_id1 IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the first phone number serie
  p_phone_number_serie_id2 IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE -- id of the second phone number serie
) RETURN NUMBER IS
  v_serie1_starting_number PHONE_NUMBER_SERIES.LOCAL_NUMBER_START%TYPE; -- starting number of the first serie
  v_serie2_starting_number PHONE_NUMBER_SERIES.LOCAL_NUMBER_START%TYPE; -- starting number of the second serie
  v_serie1_area            PHONE_NUMBER_SERIES.AREA_CODE%TYPE;
  v_serie1_country         PHONE_NUMBER_SERIES.COUNTRY_CODE%TYPE;

  v_between NUMBER DEFAULT RSIG_UTILS.c_OK; -- if this variable is 1 then another serie exist between these two series
  CURSOR cur_between IS -- cursor retrieving 1 if there exists another phone number serie between given two series
    SELECT DISTINCT 1
      FROM phone_number_series pns
     WHERE local_number_start > v_serie1_starting_number
       AND local_number_start < v_serie2_starting_number
       AND pns.country_code = v_serie1_country
       AND pns.area_code = v_serie1_area
       AND pns.deleted is Null;
BEGIN
  SELECT LOCAL_NUMBER_START,
         pns.country_code,
         pns.area_code
    INTO v_serie1_starting_number,
         v_serie1_country,
         v_serie1_area
    FROM PHONE_NUMBER_SERIES pns
   WHERE PHONE_NUMBER_SERIES_ID = p_phone_number_serie_id1;

  BEGIN
    SELECT LOCAL_NUMBER_START
      INTO v_serie2_starting_number
      FROM PHONE_NUMBER_SERIES pns
     WHERE PHONE_NUMBER_SERIES_ID = p_phone_number_serie_id2
       AND pns.country_code = v_serie1_country
       AND pns.area_code = v_serie1_area;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_INTERVAL, 'Different area or code in series');
  END;
  IF v_serie1_starting_number > v_serie2_starting_number THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_INTERVAL, '');
  END IF;

  OPEN cur_between;
  FETCH cur_between
    INTO v_between;
  CLOSE cur_between;

  IF v_between = RSIG_UTILS.c_FALSE THEN
    RETURN RSIG_UTILS.c_FALSE;
  END IF;

  ERROR_CODE := RSIG_UTILS.c_OK;
  RETURN RSIG_UTILS.c_OK;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RETURN RSIG_UTILS.c_ERROR;
    END;
END Is_Serie_Between;

---------------------------------------------
--     FUNCTION Get_Packet_Of_Intervals
---------------------------------------------

FUNCTION Get_Packet_Of_Intervals
(
  Packet_Of_Val IN VARCHAR2,
  Table_Of_Val  OUT RSIG_UTILS.Type_Packet_Of_Intervals
) RETURN NUMBER IS
  v_start           NUMBER := 1;
  v_end             NUMBER := 0;
  v_start_posun     NUMBER := 0;
  v_end_posun       NUMBER := 0;
  v_member_of_table NUMBER;
  v_index_of_table  NUMBER := 0;
  v_exit            BOOLEAN := FALSE;
BEGIN
  IF Packet_Of_Val IS NULL THEN
    RETURN(RSIG_UTILS.c_FALSE);
  END IF;
  LOOP
    v_end := INSTR(Packet_Of_Val, ':', v_end + 1);
    IF v_end = 0 THEN
      v_end       := LENGTH(Packet_Of_Val);
      v_end_posun := 0;
      v_exit      := TRUE;
    END IF;
    IF v_end > (v_start + 1) THEN
      BEGIN
        v_member_of_table := TO_NUMBER(LTRIM(RTRIM(SUBSTR(Packet_Of_Val,
                                                          v_start + v_start_posun,
                                                          v_end - v_start - v_end_posun))));
        IF v_member_of_table IS NOT NULL THEN
          v_index_of_table := v_index_of_table + 1;
          Table_Of_Val(v_index_of_table) := v_member_of_table;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          RETURN(RSIG_UTILS.c_FALSE);
      END;
    END IF;
    v_start       := v_end;
    v_start_posun := 1;
    v_end_posun   := 1;
    EXIT WHEN v_exit;
  END LOOP;
  IF v_index_of_table = 0 THEN
    RETURN(RSIG_UTILS.c_FALSE);
  END IF;
  RETURN(RSIG_UTILS.c_OK);
END Get_Packet_Of_Intervals;

---------------------------------------------
--     FUNCTION Get_Packet_Of_Intervals_V
---------------------------------------------

FUNCTION Get_Packet_Of_Intervals_V
(
  Packet_Of_Val IN VARCHAR2,
  Table_Of_Val  OUT RSIG_UTILS.Type_Packet_Of_Intervals_V
) RETURN NUMBER IS
  v_start           NUMBER := 1;
  v_end             NUMBER := 0;
  v_start_posun     NUMBER := 0;
  v_end_posun       NUMBER := 0;
  v_member_of_table VARCHAR2(1023);
  v_index_of_table  NUMBER := 0;
  v_exit            BOOLEAN := FALSE;
BEGIN
  IF Packet_Of_Val IS NULL THEN
    RETURN(RSIG_UTILS.c_FALSE);
  END IF;
  LOOP
    v_end := INSTR(Packet_Of_Val, ':', v_end + 1);
    IF v_end = 0 THEN
      v_end       := LENGTH(Packet_Of_Val);
      v_end_posun := 0;
      v_exit      := TRUE;
    END IF;
    IF v_end > (v_start + 1) THEN
      BEGIN
        v_member_of_table := LTRIM(RTRIM(SUBSTR(Packet_Of_Val,
                                                v_start + v_start_posun,
                                                v_end - v_start - v_end_posun)));
        IF v_member_of_table IS NOT NULL THEN
          v_index_of_table := v_index_of_table + 1;
          Table_Of_Val(v_index_of_table) := v_member_of_table;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          RETURN(RSIG_UTILS.c_FALSE);
      END;
    END IF;
    v_start       := v_end;
    v_start_posun := 1;
    v_end_posun   := 1;
    EXIT WHEN v_exit;
  END LOOP;
  IF v_index_of_table = 0 THEN
    RETURN(RSIG_UTILS.c_FALSE);
  END IF;
  RETURN(RSIG_UTILS.c_OK);
END Get_Packet_Of_Intervals_V;


-------------------------------------------------------------------------------------------------------------
-- Fill_Na_Id_From_Int_Number
-------------------------------------------------------------------------------------------------------------
PROCEDURE Fill_Na_Id_From_Int_Number
IS
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, 'RSIG_UTIL.Fill_Na_Id_From_Int_Number');

  UPDATE TT_BATCH_NA_AP t
  SET t.NETWORK_ADDRESS_ID = (SELECT /*+ index (pn UK_PHONE_NUM_PHONE_NUMBER)*/
                                     pn.NETWORK_ADDRESS_ID
	     							          FROM PHONE_NUMBER pn
											        WHERE pn.INTERNATIONAL_FORMAT = t.international_format
                                AND (pn.deleted IS NULL OR pn.deleted>SYSDATE));


  UPDATE TT_BATCH_NA_AP t
  SET t.RESULT = c_PHONE_NUMBER_NOT_EXISTS
  WHERE t.network_address_id IS NULL;


  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, 'RSIG_UTIL.Fill_Na_Id_From_Int_Number');
EXCEPTION
  WHEN OTHERS THEN
    RSIG_UTILS.Debug_Rsi (TO_CHAR(SQLCODE), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, 'RSIG_UTIL.Fill_Na_Id_From_Int_Number');
		RAISE;
END Fill_Na_Id_From_Int_Number;

------------------------------------------------------------------------------------------------------
-- Fill_Ap_Id_From_Sn
-----------------------------------------------------------------------------------------------------
PROCEDURE Fill_Ap_Id_From_Sn
IS
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, 'RSIG_UTIL.Fill_Ap_Id_From_Sn');

  update TT_BATCH_NA_AP t
  set t.access_point_id = (select /*+ index(sc UK_SIM_SN) */
                                  sc.access_point_id
                           from SIM_CARD sc
                           where sc.sn = t.sn);


  update TT_BATCH_NA_AP t
  set t.RESULT = c_SIM_CARD_NOT_EXISTS
  where t.access_point_id IS NULL;

  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, 'RSIG_UTIL.Fill_Ap_Id_From_Sn');
EXCEPTION
  WHEN OTHERS THEN
    RSIG_UTILS.Debug_Rsi (TO_CHAR(Sqlcode), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, 'RSIG_UTIL.Fill_Ap_Id_From_Sn');
    RAISE;
END Fill_Ap_Id_From_Sn;

---------------------------------------------
--     FUNCTION Get_Handle_Tran_For_Call_Proc
---------------------------------------------

FUNCTION Get_Handle_Tran_For_Call_Proc(p_handle_tran IN VARCHAR2) RETURN VARCHAR2 IS
BEGIN
  IF p_handle_tran NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR p_handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;
  IF p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_N THEN
    RETURN(RSIG_UTILS.c_HANDLE_TRAN_N);
  ELSIF p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    RETURN(RSIG_UTILS.c_HANDLE_TRAN_S);
  ELSIF p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S THEN
    RETURN(RSIG_UTILS.c_HANDLE_TRAN_S);
  END IF;
  RETURN(NULL);
END Get_Handle_Tran_For_Call_Proc;

---------------------------------------------
--     PROCEDURE Check_connection
---------------------------------------------

PROCEDURE Check_connection IS
  v_event_source VARCHAR2(60) := 'RSIG_UTILS.Check_connection';
  v_sqlcode      NUMBER;
  v_ERROR_CODE   NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  -- set error code to succesfully completed
  v_sqlcode := 0;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    v_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(v_error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Check_connection;

---------------------------------------------
--     PROCEDURE Get_Normal_Sal_Cat_Code
---------------------------------------------

PROCEDURE Get_Normal_Sal_Cat_Code(p_normal_sal_cat_code OUT VARCHAR2) IS
  v_event_source VARCHAR2(60) := 'RSIG_UTILS.Get_Normal_Sal_Cat_Code';
  v_sqlcode      NUMBER;
  v_ERROR_CODE   NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  -- set error code to succesfully completed
  p_normal_sal_cat_code := rsig_utils.c_STANDARD_SAL_CATEGORY;
  v_sqlcode             := 0;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    v_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(v_error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Get_Normal_Sal_Cat_Code;

FUNCTION get_ri_setting(p_name VARCHAR2, p_default VARCHAR2 := NULL) RETURN VARCHAR2 IS
v_res VARCHAR2(4000);
BEGIN
    SELECT /*+ full(z)*/ --need func index lower(db_parameter_name)
        z.setting_value INTO v_res FROM ri_settings z
        WHERE lower(z.setting_name) = lower(p_name);
    RETURN v_res;
EXCEPTION
WHEN OTHERS THEN
    RETURN p_default;
END;

FUNCTION get_ri_setting_num(p_name VARCHAR2, p_default number := NULL) RETURN number IS
v_res number;
BEGIN
    v_res := to_number(get_ri_setting(p_name, to_char(p_default)));
    RETURN v_res;
EXCEPTION
WHEN OTHERS THEN
    RETURN p_default;
END;

----------------------------------------------------------------------------------------------------------------
-- init section
----------------------------------------------------------------------------------------------------------------
BEGIN
  BEGIN
    SELECT 1
      INTO v_exist_db_params
      FROM dual
     WHERE EXISTS (SELECT 1 FROM user_tables ut WHERE ut.table_name = 'DB_PARAMETERS');
    BEGIN
      SELECT dp.DB_PARAMETER_VALUE
        INTO v_output
        FROM DB_PARAMETERS dp
       WHERE upper(dp.DB_PARAMETER_NAME) = c_DB_PARAM_OUTPUT;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_output := c_DEBUG_TO_BUFFER;
    END;

    BEGIN
      SELECT dp.DB_PARAMETER_VALUE
        INTO v_debug_level
        FROM DB_PARAMETERS dp
       WHERE upper(dp.DB_PARAMETER_NAME) = c_DB_PARAM_DEBUG_LEVEL;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_debug_level := 0;
    END;

  EXCEPTION
    WHEN OTHERS THEN
      v_output      := c_DEBUG_TO_BUFFER;
      v_debug_level := 0;
  END;

END RSIG_UTILS;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_UTILS.pkb,v 1.86 2004/01/06 14:55:32 cfilip Exp $
/
