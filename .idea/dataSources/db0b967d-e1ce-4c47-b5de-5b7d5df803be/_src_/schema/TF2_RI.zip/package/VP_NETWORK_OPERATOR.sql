CREATE package VP_NETWORK_OPERATOR is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'NETWORK_OPERATOR';

  c_net_op_type_code_internal    constant varchar2(2) := 'IN';
  c_net_op_type_code_external    constant varchar2(2) := util_ri.c_NOPT_CODE_EXTERNAL;

----------------------------------!---------------------------------------------
  function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return network_operator%rowtype;

  function get1(p_id integer, p_date date) return network_operator%rowtype;
  function xget1(p_id integer, p_date date) return network_operator%rowtype;
  function xlock_get1(p_id integer, p_date date) return network_operator%rowtype;
  function xlock_xget1(p_id integer, p_date date) return network_operator%rowtype;
  procedure xlock(p_id integer, p_date date);

----------------------------------!---------------------------------------------
  function find_i_id(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_code(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_name(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean;

  function find_i_mcc_mnc(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_mcc_mnc1(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_mcc_mnc2(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean;

  function find_i(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean;
  procedure xunique_i(p_rec network_operator%rowtype, p_check_only_other_ids boolean);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec network_operator%rowtype);
  procedure change_i(p_rec network_operator%rowtype);

----------------------------------!---------------------------------------------
  function is_identified(p_rec network_operator%rowtype) return boolean;

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy network_operator%rowtype);
  procedure version_change(p_rec in out nocopy network_operator%rowtype, p_date_from_virt date := null);

  procedure version_close
  (
    p_id integer,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------
  procedure version_open2
  (
    p_rec in out nocopy network_operator%rowtype,
    p_routing_number_id integer,
    p_date_from date := null
  );

  procedure version_change2
  (
    p_rec in out nocopy network_operator%rowtype,
    p_routing_number_id integer,
    p_date_from date := null
  );

  procedure version_close2
  (
    p_id integer,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------
  procedure xcheck_network_operator_type(p_network_operator_type_code varchar2);

  function is_external(p_network_operator_type_code varchar2) return boolean;
  function is_external2(p_rec network_operator%rowtype) return boolean;
  function is_external3(p_network_operator_id number, p_date date) return boolean;

----------------------------------!---------------------------------------------

end;
/
