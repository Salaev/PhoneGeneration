CREATE PACKAGE PHONE_NUMBER_PCK IS

----------------------------------!---------------------------------------------
PROCEDURE Lock_Phones;
PROCEDURE Lock_Phones_by_ID;
PROCEDURE Lock_Phones(
  p_international_format  IN  phone_number.international_format%TYPE,
  p_network_address_id    OUT phone_number.network_address_id%TYPE,
  p_error                 OUT INT
);

----------------------------------!---------------------------------------------
PROCEDURE Salability_Cat_Recalculation(
  p_phone_number_series_id        IN  PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
  p_recalculate_all_status        IN  CHAR,
  p_recalculate_all_sc            IN  CHAR,
  p_start_date                    IN  DATE,
  p_user_id                       IN  NUMBER,
  p_handle_tran                      IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error                      IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                    OUT NUMBER,
  p_error_message                    OUT VARCHAR2
);

----------------------------------!---------------------------------------------
FUNCTION Is_Phone_Number_In_Mask
(
  p_phone_number IN VARCHAR2, -- actuall phone number
  p_mask         IN VARCHAR2 -- actuall mask
) RETURN INT;

----------------------------------!---------------------------------------------
PROCEDURE ImportPhoneLinks(
  p_linked_MSISDN_l       IN  common.t_international_format,
  p_main_MSISDN_l         IN  common.t_international_format,
  p_host_id_l             IN  common.t_number,
  p_network_operator_id   IN  network_operator.network_operator_id%TYPE,
  p_external_operator_id  IN  network_operator.network_operator_id%TYPE,
  p_user_id               IN  NUMBER,
  p_handle_tran              IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error              IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message            OUT VARCHAR2,
  p_error_list            OUT SYS_REFCURSOR
);

----------------------------------!---------------------------------------------
  procedure delete_last_open_previous
  (
    p_phone_list util_pkg.cit_varchar_s,
    p_user_login varchar2,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor
  );

  procedure delete_last_open_previous2
  (
    p_network_address_id number,
    p_user_id_of_change number,
    error_code out number,
    p_error_message out varchar2
  );

  procedure delete_last_open_previous_int
  (
    p_msisdn ct_varchar_s,
    p_user_id number
  );

----------------------------------!---------------------------------------------
procedure Get_phone_numbers_info
(
   p_Validity_Date     IN DATE,
   p_Phone_Number_List IN common.t_international_format,
   p_raise_error       IN CHAR,
   error_code          OUT NUMBER,
   error_message       OUT VARCHAR2,
   result_list         OUT SYS_REFCURSOR
);

procedure Get_linked_phone_numbers_info
(
  p_Validity_Date     IN DATE,
  p_Phone_Number_List IN common.t_international_format,
  p_raise_error       IN CHAR,
  error_code          OUT NUMBER,
  error_message       OUT VARCHAR2,
  result_list         OUT sys_refcursor
);

procedure Get_phone_numbers_info3
(
  p_Validity_Date     IN DATE,
  p_Phone_Number_List IN common.t_international_format,
  p_raise_error       IN CHAR,
  error_code          OUT NUMBER,
  error_message       OUT VARCHAR2,
  result_list         OUT sys_refcursor
);

----------------------------------!---------------------------------------------

END;
/
