CREATE PACKAGE BODY VPN IS

------------------------------------------------------------------------------------------------------------------------------
--  Get_VPN_Groups_of_Net_Op
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_VPN_Groups_of_Net_Op(
  p_Operator_UPRS_Code    IN   network_operator.uprs_member_code%TYPE,
  p_Host_ID               IN   host.host_id%TYPE,
  p_raise_error           IN   CHAR DEFAULT RSIG_UTILS.c_NO,
  p_error_code            OUT  NUMBER,
  p_result_list           OUT  sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'VPN';
  v_procedure_name        VARCHAR2(30) := 'Get_VPN_Groups_of_Net_Op';
  v_event_source          VARCHAR2(60);
  v_sysdate               DATE:=SYSDATE;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

---------------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
  SELECT n.uprs_member_code,
         h.host_id,
         vg.vpn_group_number_start,
         vg.vpn_group_number_end
  FROM vpn_group vg
  JOIN host h ON vg.host_id=h.host_id
  JOIN network_operator n ON n.network_operator_id=h.network_operator_id
  WHERE (vg.deleted IS NULL OR vg.deleted>v_sysdate)
    AND (h.host_id=p_Host_ID OR p_host_id IS NULL)
    AND (n.uprs_member_code=p_Operator_UPRS_Code OR p_Operator_UPRS_Code IS NULL);


---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,NULL,v_package_name,v_procedure_name);

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_VPN_Groups_of_Net_Op;

------------------------------------------------------------------------------------------------------------------------------
--  Insert_VPN_Group
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_VPN_Group(
  p_VPN_Group_Start       IN  vpn_group.vpn_group_number_start%TYPE,
  p_VPN_Group_End         IN  vpn_group.vpn_group_number_end%TYPE,
  p_host_id               IN  host.host_id%TYPE,
  p_user_id               IN  NUMBER,
  p_handle_tran           IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_raise_error           IN  CHAR DEFAULT RSIG_UTILS.c_NO,
  p_VPN_Group_ID          OUT NUMBER,
  p_error_code            OUT NUMBER
)
IS
  v_package_name          VARCHAR2(30) := 'VPN';
  v_procedure_name        VARCHAR2(30) := 'Insert_VPN_Group';
  v_event_source          VARCHAR2(60);
  v_sysdate               DATE:=SYSDATE;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check input parameters
  IF p_VPN_Group_Start IS NULL OR p_VPN_Group_End IS NULL OR p_host_id IS NULL OR p_user_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

--------------------------------------------------------------------------------------------------
  INSERT INTO vpn_group
         (vpn_group_id,
          vpn_group_number_start,
          vpn_group_number_end,
          host_id,
          date_of_change,
          user_id_of_change)
  VALUES(s_vpn_group.nextval,
         p_VPN_Group_Start,
         p_VPN_Group_End,
         p_host_id,
         v_sysdate,
         p_user_id)
  RETURNING vpn_group_id INTO p_VPN_Group_ID;

---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,p_handle_tran,v_package_name,v_procedure_name);

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Insert_VPN_Group;

------------------------------------------------------------------------------------------------------------------------------
--  Insert_VPN_Numbering_Plan
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_VPN_Numbering_Plan(
  p_phone_interval_start  IN  vpn_numbering_plan.phone_interval_start%TYPE,
  p_phone_interval_end    IN  vpn_numbering_plan.phone_interval_end%TYPE,
  p_vpn_group_id          IN  vpn_group.vpn_group_id%TYPE,
  p_user_id               IN  NUMBER,
  p_handle_tran           IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_raise_error           IN  CHAR DEFAULT RSIG_UTILS.c_NO,
  p_error_code            OUT NUMBER
)
IS
  v_package_name          VARCHAR2(30) := 'VPN';
  v_procedure_name        VARCHAR2(30) := 'Insert_VPN_Numbering_Plan';
  v_event_source          VARCHAR2(60);
  v_sysdate               DATE:=SYSDATE;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check input parameters
  IF p_phone_interval_start IS NULL OR p_phone_interval_end IS NULL OR p_vpn_group_id IS NULL OR
     p_user_id IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

--------------------------------------------------------------------------------------------------
  INSERT INTO vpn_numbering_plan
         (vpn_numbering_plan_id,
          phone_interval_start,
          phone_interval_end,
          vpn_group_id,
          date_of_change,
          user_id_of_change)
  VALUES(s_vpn_numbering_plan.nextval,
         p_phone_interval_start,
         p_phone_interval_end,
         p_vpn_group_id,
         v_sysdate,
         p_user_id);

---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,p_handle_tran,v_package_name,v_procedure_name);

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Insert_VPN_Numbering_Plan;

END;
/
