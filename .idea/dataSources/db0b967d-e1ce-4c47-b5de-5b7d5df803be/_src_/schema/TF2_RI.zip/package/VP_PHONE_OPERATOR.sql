CREATE package VP_PHONE_OPERATOR is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'PHONE_OPERATOR';

  c_potype_other2own             constant number := 0;
  c_potype_own2other             constant number := 1;
  c_potype_own2own               constant number := 2;
  c_potype_other2other           constant number := 3;
  --!_!c_potype_3rdsideother2own      constant number := 4; --!_!assumption for future; for rented phone number series (phone_link) and MNP

  c_date_to_act_active           constant date := util_pkg.c_open_date_to;

  c_def_date_to_act              constant date := c_date_to_act_active;
  c_def_potype                   constant number := c_potype_other2own;

----------------------------------!---------------------------------------------
  function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return phone_operator%rowtype;
  function get1(p_id integer, p_date date) return phone_operator%rowtype;
  function xlock_get1(p_id integer, p_date date) return phone_operator%rowtype;

----------------------------------!---------------------------------------------
  procedure xvalid_i(p_rec phone_operator%rowtype);

----------------------------------!---------------------------------------------
  function find_i_id(p_rec phone_operator%rowtype) return boolean;

  function find_i(p_rec phone_operator%rowtype) return boolean;
  procedure xunique(p_rec phone_operator%rowtype);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec phone_operator%rowtype);
  procedure close_i(p_rec phone_operator%rowtype);

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy phone_operator%rowtype);
  procedure version_change(p_rec in out nocopy phone_operator%rowtype);

  procedure version_close
  (
    p_id integer,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------
  --!_!date_to_act can move only downwards to date_to (end_date)
  procedure drop_date_to_act(p_id integer, p_date date);

----------------------------------!---------------------------------------------

end;
/
