CREATE package body VP_BATCH is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get1_i(p_id integer, p_lock boolean, p_wait boolean, p_is_locked out boolean) return batch%rowtype
is
  v_res batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, PK_BATCH)*/
        * into v_res
        from batch z
        where 1 = 1
        and batch_id = p_id
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, PK_BATCH)*/
        * into v_res
        from batch z
        where 1 = 1
        and batch_id = p_id
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, PK_BATCH)*/
      * into v_res
      from batch z
      where 1 = 1
      and batch_id = p_id
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1(p_id integer) return batch%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get1_i(p_id, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get1(p_id integer) return batch%rowtype
is
  v_res batch%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_i(p_id, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xvalid(p_rec batch%rowtype)
is
begin
  ------------------------------
  util_pkg.xcheck_version_dates(p_rec.start_date, p_rec.end_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_id(p_rec batch%rowtype) return boolean
is
  v_cnt number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.batch_id is null, 'p_rec.batch_id');
  ------------------------------
select /*+ index_asc(z, PK_BATCH)*/
  count(1) cnt into v_cnt
  from batch z
  where 1 = 1
  and batch_id = p_rec.batch_id
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  --!_!and (v_check_only_other_ids = util_pkg.c_false or batch_id != p_rec.batch_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i(p_rec batch%rowtype) return boolean
is
begin
  ------------------------------
  if find_i_id(p_rec)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xunique_i(p_rec batch%rowtype)
is
begin
  ------------------------------
  if find_i_id(p_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_ID2(p_rec.batch_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_i(p_rec batch%rowtype)
is
begin
  ------------------------------
  xvalid(p_rec);
  ------------------------------
  xunique_i(p_rec);
  ------------------------------
  insert into batch
  values p_rec;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure change_i(p_rec batch%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xvalid(p_rec);
  ------------------------------
update /*+ index_asc(z, PK_BATCH)*/
  batch z
  set
    row = p_rec
  where 1 = 1
  and batch_id = p_rec.batch_id
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_ID2(p_rec.batch_id, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_ID2(p_rec.batch_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure close_i(p_rec batch%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xvalid(p_rec);
  ------------------------------
delete /*+ index_asc(z, PK_BATCH)*/ from
  batch z
  where 1 = 1
  and batch_id = p_rec.batch_id
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_ID2(p_rec.batch_id, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_ID2(p_rec.batch_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open(p_rec in out nocopy batch%rowtype)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  p_rec.batch_id := nvl(p_rec.batch_id, s_batch_batch_id.nextval);
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change(p_rec in out nocopy batch%rowtype)
is
  v_sp_name varchar2(30);
  v_rec batch%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.batch_id is null, 'p_rec.batch_id');
  ------------------------------
  v_rec := xlock_get1(p_rec.batch_id);
  ------------------------------
  if v_rec.batch_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_ID2(p_rec.batch_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  xvalid(p_rec);
  ------------------------------
  change_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close(p_id integer)
is
  v_sp_name varchar2(30);
  v_rec batch%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  ------------------------------
  v_rec := xlock_get1(p_id);
  ------------------------------
  if v_rec.batch_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_ID2(p_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  --!_! v_rec.user_id_of_change := p_user_id;
  ------------------------------
  close_i(v_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
