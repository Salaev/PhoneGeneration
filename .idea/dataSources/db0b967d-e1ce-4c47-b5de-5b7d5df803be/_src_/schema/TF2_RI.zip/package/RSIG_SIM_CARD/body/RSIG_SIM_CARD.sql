CREATE PACKAGE BODY RSIG_SIM_CARD IS

  -------------------------------------------------------------------------------
  --      procedure Set_Sim_Card_Authent_Type
  -------------------------------------------------------------------------------

PROCEDURE Set_Sim_Card_Authent_Type(
  handle_tran          IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code           OUT NUMBER,
  p_sim_list           IN t_IMSI,
  p_authent_type       IN VARCHAR, -- authent type we want to set the SIM
  p_user_id_of_change  IN NUMBER   -- number of the user who performs this procedure
)
IS
  v_sysdate            DATE; -- variable containing the date when salability is being changed
  v_event_source       VARCHAR2(60) := 'RSIG_SIM_CARD.Set_Sim_Card_Authent_Type';
  v_char_length        NUMBER;

  BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);

   v_sysdate := SYSDATE;

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF p_user_id_of_change IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  -- check input parameters
  IF (p_sim_list.COUNT = 0) OR (p_sim_list.COUNT = 1 AND p_sim_list(1) IS NULL)  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  SELECT char_length
     INTO v_char_length
      FROM user_tab_columns
       WHERE table_name = 'SIM_CARD' AND column_name = 'AUTHENT_TYPE';

  IF LENGTH(p_authent_type) > v_char_length THEN
     RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_VERY_BIG_VALUE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Set_Sim_Card_Authent_Type;
  END IF;

  FOR i IN p_sim_list.FIRST .. p_sim_list.LAST
  LOOP
    UPDATE (SELECT sc.authent_type, sc.user_id_of_change, sc.date_of_change
             FROM sim_card sc
            WHERE sc.imsi = p_sim_list(i)) t
      SET t.authent_type = p_authent_type,
          t.user_id_of_change = p_user_id_of_change,
          t.date_of_change = v_sysdate;
  END LOOP;

  --FOR i IN p_sim_list.FIRST .. p_sim_list.LAST
  --LOOP
  --  UPDATE (SELECT sc.authent_type
  --           FROM sim_card sc
  --          WHERE sc.imsi = p_sim_list(i)) t
  --    SET t.authent_type = p_authent_type;
  --END LOOP;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        error_code := RSIG_UTILS.Handle_Error(SQLCODE);
        RSIG_UTILS.Debug_Rsi(to_number(error_code),
                             RSIG_UTILS.c_DEBUG_LEVEL_0,
                             RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                             v_event_source);
        CASE handle_tran
          WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
            ROLLBACK TO SAVEPOINT change_salability_category_a;
          WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
            ROLLBACK;
          ELSE
            NULL;
        END CASE;
      END;
END Set_Sim_Card_Authent_Type;

---------------------------------------------
--     PROCEDURE Get_Status_History
---------------------------------------------

PROCEDURE Get_Status_History
(
  error_code           OUT NUMBER,
  p_access_point_id    IN ACCESS_POINT_STATUS_HISTORY.ACCESS_POINT_ID%TYPE,
  p_cur_status_history IN OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_SIM_CARD.Get_Status_History';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_access_point_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_BEFORE_SELECT,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_status_history FOR
    select aps.ACCESS_POINT_STATUS_CODE,
           aps.ACCESS_POINT_STATUS_NAME,
           apsh.START_DATE,
           apsh.END_DATE,
           apsh.DATE_OF_CHANGE,
           apsh.USER_ID_OF_CHANGE,
           u.user_name,
           apsh.ap_trans_reason_code,
           atr.ap_trans_reason_name
      from ACCESS_POINT_STATUS aps
      join ACCESS_POINT_STATUS_HISTORY apsh on TRIM(aps.ACCESS_POINT_STATUS_CODE) = TRIM(apsh.ACCESS_POINT_STATUS_CODE)
      LEFT JOIN ap_trans_reason atr ON atr.ap_trans_reason_code=apsh.ap_trans_reason_code
      JOIN Users u ON u.user_id = apsh.user_id_of_change
     where apsh.ACCESS_POINT_ID = p_access_point_id;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_AFTER_SELECT,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Get_Status_History;

---------------------------------------------
--     PROCEDURE Get_Phone_History_By_Sim_Card
---------------------------------------------

PROCEDURE Get_Phone_History_By_Sim_Card
(
  error_code      OUT NUMBER,
  p_iccid         IN SIM_CARD.SN%TYPE,
  p_cur_statistic IN OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_SIM_CARD.Get_Phone_History_By_Sim_Card';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_iccid IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  OPEN p_cur_statistic FOR
    select pn.INTERNATIONAL_FORMAT,
           naap.FROM_DATE,
           naap.TO_DATE,
           u.user_name
      from sim_card sc
      join network_address_access_point naap on sc.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
      join phone_number pn on pn.NETWORK_ADDRESS_ID = naap.NETWORK_ADDRESS_ID
      JOIN users u ON u.user_id = naap.user_id_of_change
     where sc.SN = p_iccid
     order by pn.INTERNATIONAL_FORMAT,
              naap.FROM_DATE;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Get_Phone_History_By_Sim_Card;

---------------------------------------------
--     PROCEDURE Get_ICCID_By_Phone_List
---------------------------------------------

PROCEDURE Get_ICCID_By_Phone_List
(
  col_phone_numbers  IN T_PHONE_NUMBER,
  col_validity_dates IN T_DATES,
  result_list        OUT sys_refcursor,
  p_raise_error      IN CHAR,
  error_code         OUT NUMBER,
  error_message      OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_SIM_CARD.Get_ICCID_By_Phone_List';
  v_sqlcode      NUMBER;
  v_sysdate      DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  v_sysdate := SYSDATE;

  -- check input parameters
  IF (col_phone_numbers.COUNT = 0) OR (col_phone_numbers.COUNT = 1 AND col_phone_numbers(col_phone_numbers.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  --IF (col_validity_dates.COUNT = 0) OR (col_validity_dates.COUNT = 1 AND col_validity_dates(col_validity_dates.FIRST) IS NULL)
  --THEN
  --  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  --END IF;

  IF col_validity_dates.COUNT <> col_validity_dates.COUNT
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  IF nvl(col_phone_numbers.LAST, 0) <> nvl(col_validity_dates.LAST, 0) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  DELETE FROM TT_ICCID_BY_PHONE_LIST;

  FORALL i IN nvl(col_phone_numbers.FIRST, 1) .. nvl(col_phone_numbers.LAST, 0)
    INSERT INTO TT_ICCID_BY_PHONE_LIST t
      (INTERNATIONAL_FORMAT,
       NETWORK_ADDRESS_ID,
       ACCESS_POINT_ID,
       VALIDITY_DATE,
       ICCID,
       RESULT)
      SELECT col_phone_numbers(i),
             NULL,
             NULL,
             nvl(col_validity_dates(i), v_sysdate),
             NULL,
             RSIG_UTILS.c_ROW_NOT_FOUND
        FROM dual;

  UPDATE TT_ICCID_BY_PHONE_LIST t
     SET t.RESULT = RSIG_UTILS.c_NO_DATA_FOUND
   WHERE EXISTS (SELECT 1
            FROM PHONE_NUMBER pn
            WHERE 1 = 1
             AND pn.INTERNATIONAL_FORMAT = t.INTERNATIONAL_FORMAT
             AND (pn.deleted IS NULL OR pn.deleted>t.validity_date));

  UPDATE TT_ICCID_BY_PHONE_LIST t
     SET t.RESULT = RSIG_UTILS.c_TOO_MANY_ROWS_RETRIEVED
   WHERE EXISTS (SELECT 1
            FROM PHONE_NUMBER pn
            JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.network_address_id = pn.network_address_id
            JOIN SIM_CARD sc ON sc.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
           WHERE 1 = 1
             AND pn.INTERNATIONAL_FORMAT = t.INTERNATIONAL_FORMAT
             AND (pn.deleted IS NULL OR pn.deleted>t.validity_date)
             AND t.VALIDITY_DATE BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE, t.VALIDITY_DATE)
           GROUP BY pn.network_address_id
          HAVING COUNT(naap.network_address_id) > 1);

  UPDATE TT_ICCID_BY_PHONE_LIST t
     SET (t.NETWORK_ADDRESS_ID, t.ACCESS_POINT_ID, t.ICCID, t.RESULT) = (SELECT pn.NETWORK_ADDRESS_ID,
                                                                                sc.ACCESS_POINT_ID,
                                                                                sc.SN,
                                                                                RSIG_UTILS.c_OK
                                                                           FROM PHONE_NUMBER pn
                                                                           JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.network_address_id =
                                                                                                                     pn.network_address_id
                                                                           JOIN SIM_CARD sc ON sc.ACCESS_POINT_ID =
                                                                                               naap.ACCESS_POINT_ID
                                                                          WHERE 1 = 1
                                                                            AND pn.INTERNATIONAL_FORMAT =
                                                                                t.INTERNATIONAL_FORMAT
                                                                            AND t.VALIDITY_DATE BETWEEN
                                                                                naap.FROM_DATE AND
                                                                                nvl(naap.TO_DATE,
                                                                                    t.VALIDITY_DATE))
   WHERE t.result = RSIG_UTILS.c_NO_DATA_FOUND
     AND EXISTS
   (SELECT 1
            FROM PHONE_NUMBER pn
            JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.network_address_id = pn.network_address_id
            JOIN SIM_CARD sc ON sc.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
           WHERE 1 = 1
             AND pn.INTERNATIONAL_FORMAT = t.INTERNATIONAL_FORMAT
             AND t.VALIDITY_DATE BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE, t.VALIDITY_DATE));

  OPEN result_list FOR
    SELECT t.INTERNATIONAL_FORMAT,
           t.VALIDITY_DATE,
           t.ICCID,
           t.RESULT
      FROM TT_ICCID_BY_PHONE_LIST t
     ORDER BY t.INTERNATIONAL_FORMAT;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_ICCID_By_Phone_List;

---------------------------------------------
--     PROCEDURE Get_IMSI_By_MSISDN
---------------------------------------------

PROCEDURE Get_IMSI_By_MSISDN
(
  p_phone_number  IN PHONE_NUMBER.INTERNATIONAL_FORMAT%TYPE,
  p_validity_date IN DATE, -- Validity date and time
  p_result_list   OUT sys_refcursor
) IS
  v_event_source  VARCHAR2(60) := 'RSIG_SIM_CARD.Get_IMSI_By_MSISDN';
  v_validity_date DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_phone_number IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  v_validity_date := nvl(p_validity_date, SYSDATE);

  OPEN p_result_list FOR
  SELECT pn.international_format,
         sc.imsi,
         naap.link_type_code
  FROM phone_number pn
  JOIN network_address_access_point naap ON naap.network_address_id=pn.network_address_id
       AND v_validity_date BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE, v_validity_date)
  JOIN sim_card sc ON sc.access_point_id=naap.access_point_id
  WHERE pn.international_format = p_phone_number
    AND (pn.deleted IS NULL OR pn.deleted>v_validity_date);

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    RAISE;
END Get_IMSI_By_MSISDN;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Prod_Status_History
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Prod_Status_History(
  p_access_point_id        IN  access_point.access_point_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'RSIG_SIM_CARD';
  v_procedure_name        VARCHAR2(30) := 'Get_Prod_Status_History';
  v_event_source          VARCHAR2(60);

  CURSOR c_sim_aps IS
  SELECT apsh.access_point_id,
         apsh.ap_prod_status_code,
         apsh.start_date,
         apsh.end_date,
         apsh.user_id_of_change,
         apsh.date_of_change
  FROM ap_prod_status_hist apsh
  WHERE apsh.access_point_id=p_access_point_id
  ORDER BY apsh.start_date;


  v_aps_row          c_sim_aps%ROWTYPE;
  v_last_row         c_sim_aps%ROWTYPE;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF p_access_point_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  DELETE FROM tt_ap_prod_status_hist;
---------------------------------------------------------------------------------------------------------

  OPEN c_sim_aps;

  FETCH c_sim_aps INTO v_aps_row;

  IF c_sim_aps%NOTFOUND THEN
    -- only production status for series exist
    OPEN p_result_list FOR
    SELECT sssv.status_code ap_prod_status_code,
           aps.ap_prod_status_name,
           sssv.start_date,
           sssv.end_date,
           sssv.user_id_of_change,
           sssv.date_of_change,
           u.user_name
    FROM sim_card sc
    JOIN sim_series_status_validity sssv ON sc.sim_series_id=sssv.sim_series_id
    JOIN ap_prod_status aps ON aps.ap_prod_status_code=sssv.status_code
    JOIN users u ON u.user_id=sssv.user_id_of_change
    WHERE sc.access_point_id=p_access_point_id
    ORDER BY sssv.start_date;

  ELSE
    -- series rows and the begining of recordset
    INSERT INTO tt_ap_prod_status_hist
            (access_point_id,
             ap_prod_status_code,
             start_date,
             end_date,
             user_id_of_change,
             date_of_change)
    SELECT sc.access_point_id,
           sssv.status_code,
           sssv.start_date,
           CASE WHEN sssv.end_date>=v_aps_row.start_date OR sssv.end_date IS NULL THEN
                v_aps_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE
           ELSE sssv.end_date END,
           sssv.user_id_of_change,
           sssv.date_of_change
    FROM sim_card sc
    JOIN sim_series_status_validity sssv ON sc.sim_series_id=sssv.sim_series_id
    WHERE sc.access_point_id=p_access_point_id
      AND (sssv.start_date<=v_aps_row.start_date);


    LOOP
      INSERT INTO tt_ap_prod_status_hist
             (access_point_id,
              ap_prod_status_code,
              start_date,
              end_date,
              user_id_of_change,
              date_of_change)
      VALUES(v_aps_row.access_point_id,
             v_aps_row.ap_prod_status_code,
             v_aps_row.start_date,
             v_aps_row.end_date,
             v_aps_row.user_id_of_change,
             v_aps_row.date_of_change);

      v_last_row:=v_aps_row;

      FETCH c_sim_aps INTO v_aps_row;
      EXIT WHEN c_sim_aps%NOTFOUND;

      IF v_last_row.end_date+rsig_utils.c_INTERVAL_DIFFERENCE <> v_aps_row.start_date THEN
        -- series rows in the middle of recordset
        INSERT INTO tt_ap_prod_status_hist
                (access_point_id,
                 ap_prod_status_code,
                 start_date,
                 end_date,
                 user_id_of_change,
                 date_of_change)
        SELECT sc.access_point_id,
               sssv.status_code,
               CASE WHEN sssv.start_date<=v_last_row.end_date THEN
                    v_aps_row.start_date+rsig_utils.c_INTERVAL_DIFFERENCE
               ELSE sssv.start_date END,
               CASE WHEN sssv.end_date>=v_aps_row.start_date OR sssv.end_date IS NULL THEN
                    v_aps_row.start_date-rsig_utils.c_INTERVAL_DIFFERENCE
               ELSE sssv.end_date END,
               sssv.user_id_of_change,
               sssv.date_of_change
        FROM sim_card sc
        JOIN sim_series_status_validity sssv ON sc.sim_series_id=sssv.sim_series_id
        WHERE sc.access_point_id=p_access_point_id
          AND (sssv.start_date<=v_aps_row.start_date)
          AND (sssv.end_date>=v_last_row.end_date OR sssv.end_date IS NULL);

      END IF;

    END LOOP;

    OPEN p_result_list FOR
    SELECT t.ap_prod_status_code,
           aps.ap_prod_status_name,
           t.start_date,
           t.end_date,
           t.user_id_of_change,
           t.date_of_change,
           u.user_name
    FROM tt_ap_prod_status_hist t
    JOIN ap_prod_status aps ON aps.ap_prod_status_code=t.ap_prod_status_code
    JOIN users u ON u.user_id=t.user_id_of_change
    ORDER BY t.start_date;
  END IF;


  COMMIT;
---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    OPEN p_result_list FOR SELECT p_error_code FROM dual;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_Prod_Status_History;

------------------------------------------------
--  <version>           1.0.1   24.10.2008    Maxim Anoev
--                      columns KI,ADM1,access_control added to cursor
--  </version>
--  PROCEDURE Get_SIMCard_Details_By_IMSIList
------------------------------------------------
procedure get_simcard_detail_by_imsilist
(
  p_imsi_list util_pkg.cit_varchar_s,
  p_raise_error char default rsig_utils.c_no,
  p_result_list out sys_refcursor,
  p_addit_result out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
) is
  v_package_name varchar2(30) := 'RSIG_SIM_CARD';
  v_procedure_name varchar2(30) := 'Get_SIMCard_Detail_By_IMSIList';
  v_event_source varchar2(60);
  v_message varchar2(32767);
  v_sysdate date := sysdate;
  v_imsi ct_varchar_s;
  v_access_point_id ct_number;
begin
  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_imsi_list: ' || p_imsi_list.count;

  -- log start of procedure
  common.event_logger(rsig_utils.c_debug_text_start||' '||v_message,rsig_utils.c_debug_level_1,rsig_utils.c_debug_event_type_d,
                       v_event_source);

  -- check input parameters
  if (not util_pkg.CheckP_cit_varchar_s(p_imsi_list)) then
    raise_application_error(util_pkg.c_ora_missing_parameter, util_pkg.c_msg_missing_parameter);
  end if;

---------------------------------------------------------------------------------------------------------
  v_imsi := util_pkg.cast_cit2ct_varchar_s(p_imsi_list, true);

  select /*+ ordered use_nl(t si) full(t) index(si uk_sim_imsi_imsi)*/
         distinct si.access_point_id
    bulk collect into v_access_point_id
    from (select /*+ full(z)*/column_value imsi from table(cast(v_imsi as ct_varchar_s)) z) t
    join sim_imsi si on si.imsi = t.imsi
  ;

  open p_result_list for
  select /*+ ordered use_nl(t si sc ss sct appsh sssv) full(t) index(si uk_sim_imsi_imsi) index(sc pk_sim_card)
             index(ss pk_sim_series) index(appsh i_appsthi_access_point_id) index(sssv i_simsestava_sim_series_id)*/
         sc.sn,
         si.imsi,
         sc.pin,
         sc.puk,
         sc.pin2,
         sc.puk2,
         sct.sim_card_type_code,
         sct.sim_card_type_name,
         sc.ki ki,                 -- sc.ki,
         sc.adm1 adm1,               -- sc.adm1
         sc.access_control access_control,      -- sc.access_control
         sc.authent_type,
         nvl(appsh.ap_prod_status_code, sssv.status_code) ap_prod_status_code,
         substr(sc.sn, 1, length(sc.sn) - 1) serial_number,
         si.access_point_id
  from (select /*+ full(z)*/column_value imsi from table(cast(v_imsi as ct_varchar_s)) z) t
  join sim_imsi si on si.imsi = t.imsi
  join sim_card sc on sc.access_point_id = si.access_point_id
  join sim_series ss on ss.sim_series_id = si.sim_series_id
  join sim_card_type sct on trim(ss.sim_card_type_code) = trim(sct.sim_card_type_code)
  left join ap_prod_status_hist appsh
    on appsh.access_point_id = sc.access_point_id
    and v_sysdate between appsh.start_date and nvl(appsh.end_date,v_sysdate)
  left join sim_series_status_validity sssv
    on sssv.sim_series_id = ss.sim_series_id
    and v_sysdate between sssv.start_date and nvl(sssv.end_date, v_sysdate)
  where (sc.deleted is null or sc.deleted>v_sysdate)
  and (ss.deleted is null or ss.deleted>v_sysdate)
  ;

  open p_addit_result for
  select /*+ ordered use_nl(t si) full(t) index(si i_sim_imsi_access_point_imsi)*/
         si.access_point_id,
         si.imsi,
         si.imsi_type_code
    from (select /*+ full(z)*/column_value access_point_id from table(cast(v_access_point_id as ct_number)) z) t
    join sim_imsi si on si.access_point_id = t.access_point_id
    order by si.access_point_id, si.imsi_type_code
  ;
---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  common.event_logger(rsig_utils.c_debug_text_end,rsig_utils.c_debug_level_1,rsig_utils.c_debug_event_type_d,
                       v_event_source);

  p_error_code := util_pkg.c_ora_ok; -- succesfully completed
  p_error_message := util_pkg.c_msg_ok;
exception
when others then
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;

  if upper(p_raise_error)=rsig_utils.c_yes then
    raise;
  end if;
end;

------------------------------------------------------------------------------------------------------------------------------
--  Get_SIMCard_Det_By_IMSIList2 (Get_SIMCard_Detail_By_IMSIList2)
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_SIMCard_Det_By_IMSIList2 (
  p_imsi_list                  IN       common.t_IMSI,
  p_result_list                OUT      sys_refcursor,
  p_raise_error                IN       CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                 OUT      NUMBER,
  p_error_message              OUT      VARCHAR2
) IS
  v_package_name          VARCHAR2(30) := 'RSIG_SIM_CARD';
  v_procedure_name        VARCHAR2(30) := 'Get_SIMCard_Det_By_IMSIList2';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(32767);
  v_sysdate               DATE := SYSDATE;
BEGIN
  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_imsi_list: ' || p_imsi_list.COUNT;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  -- check input parameters
  IF (p_imsi_list.COUNT = 0) OR (p_imsi_list.COUNT = 1 AND p_imsi_list(1) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

---------------------------------------------------------------------------------------------------------
IF p_imsi_list.COUNT = 1 THEN

  OPEN p_result_list FOR
  SELECT sc.sn,
         si.imsi,
         sc.pin,
         sc.puk,
         sc.pin2,
         sc.puk2,
         sct.sim_card_type_code,
         sct.sim_card_type_name,
         sc.ki ki,                 -- sc.ki,
         sc.adm1 adm1,               -- sc.adm1
         sc.access_control access_control,      -- sc.access_control
         sc.authent_type
  FROM SIM_IMSI si
  JOIN SIM_CARD sc on sc.access_point_id = si.access_point_id
  join SIM_SERIES ss ON ss.sim_series_id = si.sim_series_id
  join SIM_CARD_TYPE sct ON TRIM(ss.sim_card_type_code) = TRIM(sct.sim_card_type_code)
  WHERE sc.imsi=p_imsi_list(1)
  AND (sc.deleted IS NULL OR sc.deleted>v_sysdate)
  AND (ss.deleted IS NULL OR ss.deleted>v_sysdate);

ELSE

 DELETE FROM tt_batch_na_ap;

  FORALL i IN nvl(p_imsi_list.FIRST, 1) .. nvl(p_imsi_list.LAST, 0)
  INSERT INTO tt_batch_na_ap(imsi,RESULT)
  VALUES(p_imsi_list(i),rsig_utils.c_OK);


  OPEN p_result_list FOR
  SELECT /*+ dynamic_sampling(t 1)*/
         sc.sn,
         si.imsi,
         sc.pin,
         sc.puk,
         sc.pin2,
         sc.puk2,
         sct.sim_card_type_code,
         sct.sim_card_type_name,
         sc.ki ki,                 -- sc.ki,
         sc.adm1 adm1,               -- sc.adm1
         sc.access_control access_control,      -- sc.access_control
         sc.authent_type
  FROM tt_batch_na_ap t
  join SIM_IMSI si ON si.imsi = t.imsi
  JOIN SIM_CARD sc on sc.access_point_id = si.access_point_id
  join SIM_SERIES ss ON ss.sim_series_id = si.sim_series_id
  join SIM_CARD_TYPE sct ON TRIM(ss.sim_card_type_code) = TRIM(sct.sim_card_type_code)
  WHERE (sc.deleted IS NULL OR sc.deleted>v_sysdate)
  AND (ss.deleted IS NULL OR ss.deleted>v_sysdate);

END IF;

COMMIT;
---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_SIMCard_Det_By_IMSIList2;

------------------------------------------------------------------------------------------------------------------------------
--  get_first_sim_of_msisdn
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE get_first_sim_of_msisdn (
   p_msisdn_list   IN       t_phone_number,
   p_result_list   OUT      sys_refcursor
)
IS
   v_event_source   VARCHAR2 (60)   := 'RSIG_SIM_CARD.get_first_sim_of_msisdn';
   v_sysdate        DATE;
   j                NUMBER;
   obj_col          t_v2_60_obj_tab := t_v2_60_obj_tab ();
BEGIN
   rsig_utils.debug_rsi (rsig_utils.c_debug_text_start,
                         rsig_utils.c_debug_level_1,
                         rsig_utils.c_debug_event_type_d,
                         v_event_source
                        );
   v_sysdate := SYSDATE;
   j := 1;

  -- check input parameters
  IF (p_msisdn_list.COUNT = 0) OR (p_msisdn_list.COUNT = 1 AND p_msisdn_list(1) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

   FOR i IN NVL (p_msisdn_list.FIRST, 1) .. NVL (p_msisdn_list.LAST, 0)
   LOOP
      obj_col.EXTEND;
      obj_col (j) := t_v2_60_obj (p_msisdn_list (i));
      j := j + 1;
   END LOOP;

   OPEN p_result_list FOR
      SELECT t.msisdn, t.iccid, t.imsi,
             DECODE (NVL (t.iccid, -1), -1, rsig_utils.c_row_not_found, rsig_utils.c_ok) ERROR_CODE
        FROM (SELECT   t_obj.v2_60 msisdn, sc.sn iccid, sc.imsi, naap.from_date,
                       ROW_NUMBER () OVER (PARTITION BY t_obj.v2_60 ORDER BY naap.from_date ASC) rn
                  FROM TABLE (CAST (obj_col AS t_v2_60_obj_tab)) t_obj LEFT JOIN phone_number pn
                       ON pn.international_format = t_obj.v2_60 AND (pn.deleted IS NULL OR pn.deleted > v_sysdate)
                       LEFT JOIN network_address_access_point naap ON naap.network_address_id = pn.network_address_id
                       LEFT JOIN sim_card sc ON sc.access_point_id = naap.access_point_id
              ORDER BY t_obj.v2_60, naap.from_date ASC) t
       WHERE t.rn = 1;
END;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  PROD_CheckSIMList
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE PROD_CheckSIMList
(
  p_Host_ID                NUMBER,
  p_Net_OP_ID              NUMBER,
  p_iccid                  RSIG_SIM_CARD.t_IMSI,
  p_result_list            OUT sys_refcursor,
  p_result_list_wrong      OUT sys_refcursor
)
-- v_cnt number := 10000;
IS
 j NUMBER;
 j1 NUMBER;
 obj_col t_v2_60_obj_tab := t_v2_60_obj_tab ();
 obj_col_err t_v2_60_obj_tab := t_v2_60_obj_tab ();
 v_iccid varchar(30);
begin
  /*
  j := 1;
  FOR i IN NVL (p_iccid.FIRST, 1) .. NVL (p_iccid.LAST, 0)
  LOOP
    if p_iccid(i) is not null then
      obj_col.EXTEND;
      obj_col (j) := t_v2_60_obj (p_iccid(i));
      j := j + 1;
    end if;
  END LOOP;

  delete tmp_simcard;
  insert into tmp_simcard(serial_number, iccid, imsi)
  select t_obj.v2_60, sc.sn, sc.imsi
  from sim_card sc
  join TABLE (CAST (obj_col AS t_v2_60_obj_tab)) t_obj
    on sc.sn like t_obj.v2_60 || '_';
  */

  j := 1;
  j1 := 1;
  FOR i IN NVL (p_iccid.FIRST, 1) .. NVL (p_iccid.LAST, 0)
  LOOP
    begin
      select sc.sn
      into v_iccid
      from sim_card sc
      where sc.sn between p_iccid(i) || '0' and p_iccid(i) || '9';
      if v_iccid is not null then
        obj_col.EXTEND;
        obj_col (j) := t_v2_60_obj (v_iccid);
        j := j + 1;
      else
        obj_col_err.EXTEND;
        obj_col_err (j1) := t_v2_60_obj (p_iccid(i));
        j1 := j1 + 1;
      end if;
      exception
      when NO_DATA_FOUND then
         obj_col_err.EXTEND;
         obj_col_err (j1) := t_v2_60_obj (p_iccid(i));
         j1 := j1 + 1;
    end;
  END LOOP;

  delete tmp_simcard;
  insert into tmp_simcard
         (serial_number,
         iccid,
         imsi,
         host_id,
         network_operator_id,
         status,
         linked_na_id,
         error_code)
  select
         substr(sc.sn, 1, length(sc.sn) - 1),
         sc.sn,
         sc.imsi,
         ss.host_id,
         ss.network_operator_id,
         apsh.access_point_status_code,
         naap.network_address_id,
         0
    from sim_card sc
    join sim_series ss on ss.sim_series_id = sc.sim_series_id
    left join access_point_status_history apsh
      on apsh.access_point_id = sc.access_point_id
     and sysdate between apsh.start_date and nvl(apsh.end_date, sysdate)
    left join network_address_access_point naap
      on naap.access_point_id = sc.access_point_id
     and sysdate between naap.from_date and nvl(naap.to_date, sysdate)
     and trim(naap.link_type_code) = RSIG_UTILS.c_MAIN_LINK_TYPE
    join TABLE (CAST (obj_col AS t_v2_60_obj_tab)) t_obj on sc.sn = t_obj.v2_60;

  insert into tmp_simcard
         (serial_number,
         error_code)
  select to_char(t_obj.v2_60) serial_number, RSIG_UTILS.c_SIM_CARD_NOT_EXISTS error_code
    from TABLE (CAST (obj_col_err AS t_v2_60_obj_tab)) t_obj;

  update tmp_simcard
     set error_code = RSIG_UTILS.c_SIM_INVALID_HOST
   where host_id <> p_Host_ID
     and error_code = 0;

  update tmp_simcard
     set error_code = RSIG_UTILS.c_SIM_INVALID_NET_OPER
   where network_operator_id <> p_Net_OP_ID
     and error_code = 0;

  update tmp_simcard
     set error_code = RSIG_UTILS.c_SIM_INVALID_STATUS
   where trim(status) <> 'N'
     and error_code = 0;

  update tmp_simcard
     set error_code = RSIG_UTILS.c_SIM_HAVE_PHONE_NUMBER
   where  linked_na_id is not null
     and error_code = 0;

  open p_result_list for
  select serial_number, iccid, imsi
  from tmp_simcard
  where error_code = 0;

  open p_result_list_wrong for
  select t.serial_number, t.error_code
  from tmp_simcard t
  where t.error_code <> 0;

end PROD_CheckSIMList;

------------------------------------------------
--  <version>           1.0.0   19.08.2011    Pavel Vasiliev
--  </version>
--  PROCEDURE subscriber_migrate
------------------------------------------------
PROCEDURE subscriber_migrate
(
  p_msisdn                     IN       VARCHAR2,
  p_phone_status_code          IN       VARCHAR2,
  p_user_nt_name               IN       VARCHAR2,
  p_date                       IN       DATE,
  p_set_empty_balance_storage  IN       NUMBER DEFAULT 0,
  p_error_code                 OUT      NUMBER,
  p_error_message              OUT      VARCHAR2
) IS
  v_package_name          VARCHAR2(30) := 'RSIG_SIM_CARD';
  v_procedure_name        VARCHAR2(30) := 'subscriber_migrate';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(32767);
  v_user_id               NUMBER;
  v_sysdate               DATE := nvl(p_date,SYSDATE);
  v_access_point_id       NUMBER;
  v_link_type             CHAR(2);
  --v_tmp                   NUMBER;
  --v_personal_account      NUMBER;
  --v_na_host_id            NUMBER;
  --v_PA_l                  common.t_number;
  --v_host_l                PERSONAL_ACCOUNT_PCK.t_host;
  v_na_id ct_number;
  v_res_set_na_status boolean;
  v_error_code ct_number;
  v_error_message ct_varchar;
BEGIN
  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_msisdn: ' || p_msisdn || chr(10) ||
              'p_phone_status_code: ' || p_phone_status_code || chr(10) ||
              'p_user_nt_name: ' || p_user_nt_name || chr(10) ||
              'p_date: ' || p_date || chr(10) ||
              'p_set_empty_balance_storage: ' || p_set_empty_balance_storage ;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF (p_msisdn IS NULL OR p_phone_status_code IS NULL OR p_user_nt_name IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  p_error_code := RSIG_UTILS.c_OK;

---------------------------------------------------------------------------------------------------------
  v_user_id := util_ri.xget_user_id(p_user_nt_name);

  BEGIN
    SELECT naap.access_point_id, naap.link_type_code INTO v_access_point_id,v_link_type
             FROM PHONE_NUMBER pn
             JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.network_address_id = pn.network_address_id
            WHERE 1 = 1
              AND pn.INTERNATIONAL_FORMAT = p_msisdn
              AND v_sysdate BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE, v_sysdate)
              AND pn.deleted IS NULL;
  EXCEPTION
     WHEN OTHERS THEN
     p_error_code := RSIG_UTILS.c_LINK_NA_AND_AP_NOT_EX;
     p_error_message := 'Phone number not linked.';
     RAISE;
  END;

  IF (v_link_type!= RSIG_UTILS.c_MAIN_LINK_TYPE)
  THEN
     p_error_code := RSIG_UTILS.c_ORA_MSISDN_ERROR;
     p_error_message := 'Not main link type.';
     RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MSISDN_ERROR, p_error_message);
  END IF;

  SELECT /*+index(naap I_NETADDRACCPO_ACCESS_POINT_ID) */
         naap.network_address_id
  bulk collect into v_na_id
  FROM network_address_access_point naap
  WHERE naap.access_point_id=v_access_point_id
       AND v_sysdate BETWEEN naap.from_date AND nvl(naap.to_date,v_sysdate)
       AND naap.link_type_code = RSIG_UTILS.c_MAIN_LINK_TYPE;

  v_res_set_na_status := util_ext_ri.set_na_status2
   (
     p_na_id => v_na_id,
     p_status => p_phone_status_code,
     p_date => v_sysdate,
     p_user_id => v_user_id,
     p_break_on_error => true,
     p_lock_pn => true,
     p_error_code => v_error_code,
     p_error_message => v_error_message
   );
   ------------------------------
   if not v_res_set_na_status
   then
     util_pkg.raise_exception(rsig_utils.c_ORA_OTHER_ERROR, 'Set phone status failed');
   end if;
   ------------------------------
---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    IF (p_error_code = RSIG_UTILS.c_OK)
    THEN
      p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
      p_error_message := sqlerrm;
    END IF;
END subscriber_migrate;

------------------------------------------------
--  <version>           1.0.0   19.08.2011    Pavel Vasiliev
--  </version>
--  PROCEDURE subscribers_migrate
------------------------------------------------
PROCEDURE subscribers_migrate
(
  p_msisdn                     IN       Common.t_international_format,
  p_phone_status_code          IN       Common.t_varchar2_10,
  p_date                       IN       DATE,
  p_user_nt_name               IN       VARCHAR2,
  p_set_empty_balance_storage  IN       Common.t_number,
  p_error_code                 OUT      NUMBER,
  p_error_message              OUT      VARCHAR2,
  p_result                     OUT      SYS_REFCURSOR
) IS

  v_package_name          VARCHAR2(30) := 'RSIG_SIM_CARD';
  v_procedure_name        VARCHAR2(30) := 'subscribers_deactivate';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(32767);
  v_sysdate               DATE := SYSDATE;
  v_error_code            NUMBER;
  v_error_message         VARCHAR2(3000);

  v_cnt                   NUMBER;
  v_na_host_id            NUMBER;
  v_user_id               NUMBER;

  v_arr_PA                common.t_number;
  v_arr_host_id           PERSONAL_ACCOUNT_PCK.t_host;--rsig_host.t_v2_60_tab;
  v_arr_access_point_id   common.t_number;
  v_arr_personal_account  common.t_number;

BEGIN
  v_error_code := util_pkg.c_ora_ok;
  v_error_message := util_pkg.c_msg_ok;

  BEGIN
    v_user_id := RSIG_USERS.Get_user_id_by_login(p_user_nt_name);
  EXCEPTION
    WHEN OTHERS THEN
         p_error_code := RSIG_UTILS.c_ORA_NO_DATA_FOUND;
         p_error_message := 'User not found.';
         RAISE;
  END;

  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_msisdn: ' || p_msisdn.count || chr(10) ||
              'p_phone_status_code: ' || p_phone_status_code.count || chr(10) ||
              'p_user_nt_name: ' || p_user_nt_name || chr(10) ||
              'p_date: ' || p_date || chr(10) ||
              'p_set_empty_balance_storage: ' || p_set_empty_balance_storage.count ;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF (p_msisdn IS NULL OR p_phone_status_code IS NULL OR p_user_nt_name IS NULL
       OR p_set_empty_balance_storage IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  IF p_msisdn.COUNT <> p_phone_status_code.COUNT OR
     p_phone_status_code.COUNT <> p_set_empty_balance_storage.COUNT
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

---------------------------------------------------------------------------------------------------------
  v_na_host_id := RSIG_UTILS.get_ri_setting('NA_HOST_ID', NULL);

  IF(v_na_host_id IS NOT NULL)THEN
     v_arr_host_id(1):= v_na_host_id;
  END IF;

  DELETE FROM TT_DEACT_SIM;

  FOR i IN p_msisdn.FIRST..p_msisdn.LAST
  LOOP
    INSERT INTO TT_DEACT_SIM(RN,
                             MSISDN,
                             PHONE_STATUS_CODE,
                             SET_EMPTY_BALANCE_STORAGE,
                             ERROR_CODE,
                             ERROR_MESSAGE)
                     VALUES (i,
                             p_msisdn(i),
                             p_phone_status_code(i),
                             p_set_empty_balance_storage(i),
                             v_error_code,
                             v_error_message);
  END LOOP;

  SELECT /*+ ORDERED use_nl(s pn) FULL(s) INDEX(pn UK_PHONE_NUM_PHONE_NUMBER) INDEX(naap I_NETADDRACCPO_NET_ADDRESS_ID2)*/
         naap.access_point_id
    BULK COLLECT INTO v_arr_access_point_id
    FROM TT_DEACT_SIM s JOIN
         PHONE_NUMBER pn ON(s.msisdn = pn.international_format)
         JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON(naap.network_address_id = pn.network_address_id)
   WHERE 1 = 1
     AND v_sysdate BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE, v_sysdate)
     AND pn.deleted IS NULL
   ORDER BY s.rn;

  SAVEPOINT s_subscribers_migrate;

  FOR k IN p_msisdn.FIRST..p_msisdn.LAST
  LOOP

    BEGIN
      subscriber_migrate( p_msisdn                    => p_msisdn(k),
                          p_phone_status_code         => p_phone_status_code(k),
                          p_user_nt_name              => p_user_nt_name,
                          p_date                      => p_date,
                          p_set_empty_balance_storage => p_set_empty_balance_storage(k),
                          p_error_code                => v_error_code,
                          p_error_message             => v_error_message);

      IF v_error_code <> util_pkg.c_ora_ok
      THEN
        ROLLBACK TO SAVEPOINT s_subscribers_migrate;
      END IF;

      -- Unlink sim and personal_account
      BEGIN
        SELECT COUNT(1)
          INTO v_cnt
          FROM sim_card sc
         WHERE sc.access_point_id = v_arr_access_point_id(k)
           AND sc.personal_account IS NULL;

        IF(v_cnt = 0)THEN

          SELECT sc.personal_account
            INTO v_arr_personal_account(k)
            FROM sim_card sc
           WHERE sc.access_point_id = v_arr_access_point_id(k);

          --close old interval
          UPDATE access_point_personal_account appa
             SET appa.to_date           = v_sysdate,
                 appa.date_of_change    = v_sysdate,
                 appa.user_id_of_change = v_user_id
           WHERE v_sysdate BETWEEN appa.from_date and nvl(appa.to_date,v_sysdate)
             AND appa.access_point_id = v_arr_access_point_id(k);
        END IF;

        -- set personal account
        UPDATE sim_card sc
        SET sc.personal_account  = NULL,
            sc.user_id_of_change = v_user_id,
            sc.date_of_change    = v_sysdate
        WHERE sc.access_point_id = v_arr_access_point_id(k);

      EXCEPTION
         WHEN OTHERS THEN
              v_error_code := util_pkg.get_err_code;
              v_error_message := util_pkg.get_err_msg;
              ROLLBACK TO SAVEPOINT s_subscribers_migrate;
      END;

      IF(p_set_empty_balance_storage(k) = 1 AND v_arr_personal_account(k) IS NOT NULL)
      THEN

        IF (v_na_host_id IS NULL)
        THEN
          p_error_code:= RSIG_UTILS.c_ORA_NO_DATA_FOUND;
          p_error_message := 'NA_HOST_ID not set.';
          RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NO_DATA_FOUND, p_error_message);
        END IF;

        v_arr_PA(1) := v_arr_personal_account(k);

        PERSONAL_ACCOUNT_PCK.Set_balance_storage(p_PA_l          => v_arr_PA,
                                                 p_host_l        => v_arr_host_id,
                                                 p_Start_Date    => v_sysdate,
                                                 p_user_login    => p_user_nt_name,
                                                 p_handle_tran   => 'N',
                                                 p_raise_error   => 'Y',
                                                 p_error_code    => p_error_code,
                                                 p_error_message => p_error_message);
        IF v_error_code <> util_pkg.c_ora_ok
        THEN
          ROLLBACK TO SAVEPOINT s_subscribers_migrate;
        END IF;

      END IF;

    EXCEPTION
     WHEN OTHERS THEN
      v_error_code := util_pkg.get_err_code;
      v_error_message := util_pkg.get_err_msg;
      ROLLBACK TO SAVEPOINT s_subscribers_migrate;

    END;

    UPDATE TT_DEACT_SIM t
       SET t.error_code    = v_error_code,
           t.error_message = v_error_message
     WHERE t.rn = k;--.rn;
  END LOOP;

  OPEN p_result FOR
    SELECT t.rn, t.msisdn,t.error_code,t.error_message
      FROM TT_DEACT_SIM t
     ORDER BY t.rn;
---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    IF (v_error_code = RSIG_UTILS.c_OK)
    THEN
      p_error_code := util_pkg.get_err_code;
      p_error_message := util_pkg.get_err_msg;
    ELSE
      p_error_code := v_error_code;
      p_error_message := v_error_message;
    END IF;

    ROLLBACK;
END subscribers_migrate;

END;
/
