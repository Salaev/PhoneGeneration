CREATE PACKAGE BODY          "RSIG_LOCATION_AREA" IS

---------------------------------------------
--     PROCEDURE Test_Row_For_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Row_For_Exist_And_Deleted(p_location_area_id IN LOCATION_AREA.LOCATION_AREA_ID%TYPE) IS
  v_deleted LOCATION_AREA.DELETED%TYPE;
BEGIN
  select DELETED into v_deleted from LOCATION_AREA where LOCATION_AREA_ID = p_location_area_id;

  IF v_deleted IS NOT NULL THEN
    IF v_deleted < sysdate THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
    END IF;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Test_Row_For_Exist_And_Deleted;

---------------------------------------------
--     PROCEDURE Insert_Location_Area
---------------------------------------------

PROCEDURE Insert_Location_Area
(
  handle_tran           IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_host_id             IN  LOCATION_AREA.HOST_ID%TYPE,
  p_location_area_code  IN  LOCATION_AREA.LOCATION_AREA_CODE%TYPE,
  p_location_area_name  IN  LOCATION_AREA.LOCATION_AREA_NAME%TYPE,
  p_user_id_of_change   IN  NUMBER,
  p_location_area_type  IN  location_area.location_area_type_code%TYPE
) IS
  v_event_source            VARCHAR2(60) := 'RSIG_LOCATION_AREA.Insert_Location_Area';
  v_location_area_id        location_area.location_area_id%TYPE;
  v_zone_type_id            ZONE_TYPE.ZONE_TYPE_code%TYPE;
  v_sysdate                 DATE := SYSDATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- test input parameters
  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF p_user_id_of_change IS NULL OR
     p_location_area_code IS NULL OR
     p_location_area_name IS NULL OR
     p_host_id IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint insert_location_area_a;
  END IF;

  BEGIN
    insert into LOCATION_AREA
      (LOCATION_AREA_ID,
       LOCATION_AREA_CODE,
       LOCATION_AREA_NAME,
       DELETED,
       HOST_ID,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE,
       location_area_type_code)
    values
      (S_LOCATION_AREA.NEXTVAL,
       p_location_area_code,
       p_location_area_NAME,
       null,
       p_host_id,
       sysdate,
       p_user_id_of_change,
       p_location_area_type)
    RETURNING location_area_id INTO v_location_area_id;

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_LOCATION_AREA then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_LOC_AREA_NAME, '');
      ELSIF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_LOCATION_AREA_CODE then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_LOC_AREA_CODE, '');
      ELSE
        RAISE;
      end if;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint insert_location_area_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Insert_Location_Area;

---------------------------------------------
--     PROCEDURE Update_Location_Area
---------------------------------------------

PROCEDURE Update_Location_Area
(
  handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_location_area_id    IN LOCATION_AREA.LOCATION_AREA_ID%TYPE,
  p_location_area_code  IN LOCATION_AREA.LOCATION_AREA_CODE%TYPE,
  p_host_id             IN LOCATION_AREA.HOST_ID%TYPE,
  p_location_area_name  IN LOCATION_AREA.LOCATION_AREA_NAME%TYPE,
  p_user_id_of_change   IN NUMBER,
  p_location_area_type  IN  location_area.location_area_type_code%TYPE
) IS
  v_event_source        VARCHAR2(60) := 'RSIG_LOCATION_AREA.Update_Location_Area';
  v_old_zone_id         ZONE.Zone_Id%TYPE;
  v_sysdate             DATE:=SYSDATE;
  v_zone_type_id        ZONE_TYPE.ZONE_TYPE_code%TYPE;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF p_user_id_of_change IS NULL OR
     p_location_area_id IS NULL OR
     p_location_area_code IS NULL OR
     p_location_area_name IS NULL OR
     p_host_id IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter 1');
	END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint update_location_area_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_location_area_id);

  BEGIN
    update LOCATION_AREA
       set LOCATION_AREA_CODE = p_location_area_code,
           LOCATION_AREA_NAME = p_location_area_name,
           HOST_ID            = p_host_id,
           DATE_OF_CHANGE     = v_sysdate,
           USER_ID_OF_CHANGE  = p_user_id_of_change,
           location_area_type_code = p_location_area_type
     where LOCATION_AREA_ID = p_location_area_id;

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_LOCATION_AREA then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_LOC_AREA_NAME, '2');
      ELSIF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_LOCATION_AREA_CODE then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_LOC_AREA_CODE, '3');
      ELSE
        RAISE;
      end if;
  END;

  BEGIN
    SELECT zbs.zone_id
    INTO v_old_zone_id
    FROM zone_base_station zbs
    WHERE zbs.location_area_id = p_location_area_id
      AND zbs.base_station_id IS NULL
      AND zbs.end_date IS NULL;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_old_zone_id:=NULL;
    WHEN TOO_MANY_ROWS THEN
      v_old_zone_id:=NULL;
  END;


  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint update_location_area_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Update_Location_Area;

---------------------------------------------
--     PROCEDURE Delete_Location_Area
---------------------------------------------

PROCEDURE Delete_Location_Area
(
  handle_tran         IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT NUMBER,
  p_location_area_id  IN LOCATION_AREA.LOCATION_AREA_ID%TYPE,
  p_deleted           IN LOCATION_AREA.DELETED%TYPE,
  p_user_id_of_change IN NUMBER
) IS
  v_event_source       VARCHAR2(60) := 'RSIG_LOCATION_AREA.Delete_Location_Area';
  v_base_station_exist NUMBER := 0;
  v_deleted            DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  v_deleted := nvl(p_deleted, SYSDATE);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint delete_location_area_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_location_area_id);

  BEGIN
    SELECT 1 /*+ FIRST_ROWS*/
      INTO v_base_station_exist
      FROM LOCATION_AREA la
      JOIN BASE_STATION bs ON bs.location_area_id = la.location_area_id
     WHERE la.LOCATION_AREA_ID = p_location_area_id
       AND (bs.deleted IS NULL OR bs.deleted >= v_deleted)
       AND rownum = 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_base_station_exist := 0;
  END;
  IF v_base_station_exist = 1 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_UNABLE_TO_DELETE,
                            'Can''t delete loacation area, beacause undeleted base_stations exist within!');
  END IF;

  -- set location area as deleted
  update LOCATION_AREA
     set DELETED           = v_deleted,
         DATE_OF_CHANGE    = sysdate,
         USER_ID_OF_CHANGE = p_user_id_of_change
   where LOCATION_AREA_ID = p_location_area_id;

  -- terminate relation to zone
  UPDATE zone_base_station zbs
     SET zbs.end_date=v_deleted,
         zbs.date_of_change = SYSDATE,
         zbs.user_id_of_change = p_user_id_of_change
   WHERE zbs.location_area_id = p_location_area_id
     AND zbs.base_station_id IS NULL
     AND zbs.end_date IS NULL;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint delete_location_area_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Delete_Location_Area;

---------------------------------------------
--     PROCEDURE Get_Location_Area_All
---------------------------------------------

PROCEDURE Get_Location_Area_All
(
  error_code            OUT NUMBER,
  p_host_id             IN LOCATION_AREA.HOST_ID%TYPE,
  p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_cur_location_area   OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source        VARCHAR2(60) := 'RSIG_LOCATION_AREA.Get_Location_Area_All';
  v_sysdate             DATE:=SYSDATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_network_operator_id IS NOT NULL THEN
    OPEN p_cur_location_area FOR
      select la.LOCATION_AREA_ID,
             la.LOCATION_AREA_CODE,
             la.LOCATION_AREA_NAME,
             la.HOST_ID,
             la.DATE_OF_CHANGE,
             u.user_name,
             la.deleted,
             la.LOCATION_AREA_TYPE_CODE,
             lat.LOCATION_AREA_TYPE_NAME
        from location_area la
        JOIN host h ON h.host_id=la.host_id
        JOIN users u ON u.user_id=la.User_Id_Of_Change
        LEFT JOIN location_area_type lat ON lat.LOCATION_AREA_TYPE_CODE=la.location_area_type_code
       where h.NETWORK_OPERATOR_ID = p_network_operator_id
         and (h.HOST_ID = p_host_id or p_host_id is null)
       ORDER BY la.location_area_name;
  ELSE
    OPEN p_cur_location_area FOR
      select /*+ ORDERED INDEX(LA I_LOCAREA_EXCHANGE_ID) use_nl(LA U LAT)*/
             la.LOCATION_AREA_ID,
             la.LOCATION_AREA_CODE,
             la.LOCATION_AREA_NAME,
             la.HOST_ID,
             la.DATE_OF_CHANGE,
             u.user_name,
             la.DELETED,
             la.LOCATION_AREA_TYPE_CODE,
             lat.LOCATION_AREA_TYPE_NAME
        from LOCATION_AREA la
        join USERS u on u.user_id = la.user_id_of_change
        LEFT JOIN location_area_type lat ON lat.LOCATION_AREA_TYPE_CODE=la.location_area_type_code
       where (HOST_ID = p_host_id or p_host_id is null)
       ORDER BY la.location_area_name;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_Location_Area_All;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Location_Area_Zone_History
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Location_Area_Zone_History(
  p_loc_area_id          IN  location_area.location_area_id%TYPE,
  p_start_date             IN  DATE,
  p_end_date               IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  result_list              OUT sys_refcursor
) IS
	v_sqlcode	               NUMBER;
  v_event_source           VARCHAR2(60);
  v_package_name           VARCHAR2(30) := 'RSIG_LOCATION_AREA';
  v_procedure_name         VARCHAR2(30) := 'Get_Location_Area_Zone_History';
  v_message                VARCHAR2(32767);
  v_start_date             DATE;
BEGIN
	v_event_source:=v_package_name || '.' || v_procedure_name;

  --v_message:= 'Input parameters:'
           --     || chr(10) ||'p_bsc_list ' || p_bsc_list.COUNT;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

/*	IF p_bsc_list.COUNT=0 THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
*/
  v_start_date := nvl(p_start_date, SYSDATE);

  IF v_start_date > p_end_date THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_INTERVAL, '');
  END IF;

-- start of the procedure body --------------------------------------------------------------
  OPEN result_list FOR
    SELECT z.zone_code,
           z.zone_name,
           zt.zone_type_code,
           zt.ZONE_TYPE_NAME,
           zbs.start_date,
           zbs.end_date,
           u.user_name,
           zbs.date_of_change,
           zbs.zone_base_station_id
    FROM location_area la
      JOIN zone_base_station zbs ON zbs.location_area_id = la.location_area_id
      JOIN zone z ON z.zone_id = zbs.zone_id
      JOIN zone_type zt ON zt.ZONE_TYPE_code = z.zone_type_code
      JOIN users u ON u.user_id = zbs.user_id_of_change
      WHERE la.location_area_id = p_loc_area_id
       AND  zbs.base_station_id IS NULL
       ORDER BY z.zone_code,zt.ZONE_TYPE_CODE, zbs.start_date;

-- end of the procedure body ------------------------------------------------------------------

-- set error code to succesfully completed
  p_error_code := RSIG_UTILS.c_OK;
-- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
  p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
  p_error_message := SQLERRM;
	 OPEN result_list FOR SELECT v_sqlcode,p_error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Location_Area_Zone_History;


------------------------------------------------------------------------------------------------------------------------------
--  Get_Location_Area_By_NetOP
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Location_Area_By_NetOP
(
  p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_cur_location_area   OUT RSIG_UTILS.REF_CURSOR,
  p_raise_error         IN CHAR,
  p_ERROR_CODE          OUT NUMBER,
  p_error_message       OUT VARCHAR2
) IS
  v_package_name          VARCHAR2(30) := 'RSIG_LOCATION_AREA';
  v_procedure_name        VARCHAR2(30) := 'Get_Location_Area_By_NetOP';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(32767);
  v_sysdate             DATE:=SYSDATE;
BEGIN
  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_network_operator_id: ' || p_network_operator_id;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF p_network_operator_id IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;
---------------------------------------------------------------------------------------------------------


    OPEN p_cur_location_area FOR
      select la.LOCATION_AREA_ID,
             la.LOCATION_AREA_CODE,
             la.LOCATION_AREA_NAME,
             la.HOST_ID,
             la.DATE_OF_CHANGE,
             u.user_name,
             la.deleted
        from location_area la
        JOIN host h ON h.host_id=la.host_id
        JOIN users u ON u.user_id=la.User_Id_Of_Change
       where h.NETWORK_OPERATOR_ID = p_network_operator_id
       ORDER BY la.location_area_name;


--------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_Location_Area_By_NetOP;

END RSIG_LOCATION_AREA;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_LOCATION_AREA.pkb,v 1.18 2003/12/22 11:20:22 rhejduk Exp $
/
