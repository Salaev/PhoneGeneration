CREATE package admin is

----------------------------------!---------------------------------------------
  c_sett_do_auto_na_stat_upd     constant varchar2(100) := 'DO_AUTO_NA_STATUS_UPDATE';
  c_sett_do_auto_sel_cat_upd     constant varchar2(100) := 'DO_AUTO_SALABILITY_CATEGORY_UPDATE';
  c_sett_do_auto_pn_naap_upd     constant varchar2(100) := 'DO_AUTO_PN_NAAP_UPDATE';
  c_sett_do_auto_res_bch_upd     constant varchar2(100) := 'DO_AUTO_RESERVATION_BATCH_UPDATE';
  c_sett_do_auto_ph_stat_upd     constant varchar2(100) := 'DO_AUTO_PHONE_STATUS_UPDATE';
  c_sett_do_auto_apoint_per_host constant varchar2(100) := 'DO_AUTO_APOINT_PER_HOST_STAT';
  c_sett_do_auto_mnp_prep_ph2ret constant varchar2(100) := 'DO_AUTO_MNP_PREPARE_PHONES_TO_RETURN';
  c_sett_do_auto_mnp_dlcmplbtch  constant varchar2(100) := 'DO_AUTO_MNP_DELETE_COMPLETED_BATCH';
  c_sett_do_auto_mnp_pr_po_exp   constant varchar2(100) := 'DO_AUTO_MNP_PROCESS_PHONE_OPERATOR_EXPIRED';
  c_sett_do_auto_split_po_parts  constant varchar2(100) := 'DO_AUTO_SPLIT_PHONE_OPERATOR_PARTITIONS';
  c_opt_do_auto_unreg_cache      constant varchar2(100) := 'DO_AUTO_CLOSE_ROAMING_CACHE_GROUP';
  c_opt_do_auto_rem_cache_group  constant varchar2(100) := 'DO_AUTO_REMOVE_ROAMING_CACHE_GROUP';
  c_sett_do_auto_inspect_flows   constant varchar2(100) := 'DO_AUTO_INSPECT_FLOWS';

  c_opt_use_job_long4insp_flows  constant varchar2(100) := 'Admin.UseJobLongProcessForInspectFlows';

  c_sett_host_ids_for_ap         constant varchar2(100) := 'HOST_IDS_FOR_ACCESS_POINT_HOST_STAT';

  c_sett_ph_st_up_batch_size     constant varchar2(100) := 'PHONE_STATUS_UPD_BATCH_SIZE';

  c_sett_mnp_ph_ret_batch_size   constant varchar2(100) := 'MNP_PHONE_RETURN_BATCH_SIZE';
  c_sett_mnp_ph_cnt_ret_per_job  constant varchar2(100) := 'MNP_PHONE_COUNT_RETURN_PER_JOB';
  c_sett_mnp_ph_return_delay     constant varchar2(100) := 'MNP_PHONE_RETURN_DELAY_PERIOD_SECS';
  c_sett_mnp_ph_batch_expire     constant varchar2(100) := 'MNP_PHONE_BATCH_EXPIRE_PERIOD_SECS';
  c_sett_mnp_keep_complete_batch constant varchar2(100) := 'MNP_KEEP_COMPLETED_PHONE_BATCH_SECS';
  c_sett_mnp_kp_cmplt_btch_piece constant varchar2(100) := 'MNP_KEEP_COMPLETED_PHONE_BATCH_PIECE_SIZE';
  c_sett_mnp_po_expired_sec      constant varchar2(100) := 'MNP_PHONE_OPERATOR_EXPIRED_SECS';
  c_sett_mnp_po_expired_piece    constant varchar2(100) := 'MNP_PHONE_OPERATOR_EXPIRED_PIECE_SIZE';

  c_opt_rc_group_expire          constant varchar2(100) := 'ROAMING_CACHE_GROUP_EXPIRE_PERIOD_SECS';
  c_opt_rc_del_group_delay       constant varchar2(100) := 'ROAMING_CACHE_DELETE_GROUP_DELAY_PERIOD_SECS';

  c_opt_part_po_use_srv_wnd      constant varchar2(100) := 'Partitioning.PHONE_OPERATOR.UseServiceWindow';
  c_opt_part_po_use_expird_width constant varchar2(100) := 'Partitioning.PHONE_OPERATOR.UseExpiredWidth';
  c_opt_part_po_arc_width_days   constant varchar2(100) := 'Partitioning.PHONE_OPERATOR.ArchivePartitionWidthDays';
  c_opt_part_po_stabl_width_days constant varchar2(100) := 'Partitioning.PHONE_OPERATOR.StablePartitionsWidthDays';
  c_opt_part_po_month_rnd_up     constant varchar2(100) := 'Partitioning.PHONE_OPERATOR.MonthRoundUp';
  c_opt_part_po_arc_init_date    constant varchar2(100) := 'Partitioning.PHONE_OPERATOR.ArchiveInitialDate';
  c_opt_part_po_part_name_fmt    constant varchar2(100) := 'Partitioning.PHONE_OPERATOR.PartitionNameDateFormat';
  c_opt_part_po_rebuild_inds     constant varchar2(100) := 'Partitioning.PHONE_OPERATOR.RebuildIndexPartitions';

  c_opt_srv_wnd_hour_from        constant varchar2(100) := 'ServiceWindow.HourFrom';
  c_opt_srv_wnd_hour_to_excl     constant varchar2(100) := 'ServiceWindow.HourToExcluding';

----------------------------------!---------------------------------------------
  c_def_do_auto_na_stat_upd      constant boolean := true;
  c_def_do_auto_sel_cat_upd      constant boolean := true;
  c_def_do_auto_pn_naap_upd      constant boolean := true;
  c_def_do_auto_res_bch_upd      constant boolean := true;
  c_def_do_auto_ph_stat_upd      constant boolean := FALSE;
  c_def_do_auto_apoint_per_host  constant boolean := true;
  c_def_do_auto_mnp_prep_ph2ret  constant boolean := FALSE;
  c_def_do_auto_mnp_dlcmplbtch   constant boolean := true;
  c_def_do_auto_mnp_pr_po_exp    constant boolean := true;
  c_def_do_auto_split_po_parts   constant boolean := true;
  c_def_do_auto_unreg_cache      constant boolean := true;
  c_def_do_auto_rem_cache_group  constant boolean := true;
  c_def_do_auto_inspect_flows    constant boolean := true;

  c_def_use_job_long4insp_flows  constant boolean := FALSE;

  c_def_host_ids_for_ap          constant varchar2(4000) := '-999999';

  c_def_ph_st_up_batch_size      constant number := 10000;

  c_def_mnp_ph_ret_batch_size    constant number := 1000;
  c_def_mnp_ph_cnt_ret_per_job   constant number := 1000;
  c_def_mnp_ph_return_delay      constant number := 15552000; --!_!seconds; 180 days
  c_def_mnp_ph_batch_expire      constant number := 18000; --!_!seconds; 5 hours
  c_def_mnp_keep_complete_batch  constant number := 2592000; --!_!seconds; 30 days
  c_def_mnp_kp_cmplt_btch_piece  constant number := 10000;
  c_def_mnp_po_expired_sec       constant number := 15552000; --!_!seconds; 180 days
  c_def_mnp_po_expired_piece     constant number := 10000;

  c_def_rc_group_expire          constant number := 10800; --!_!seconds; 3 hours --adroup_data.date1 update every start SUPS_TIMER_TASK RoamingTypeCachePatchTask(default every 5 minutes)
  c_def_rc_del_group_delay       constant number := 86400; --!_!seconds; 1 day --

  c_def_part_po_use_srv_wnd      constant boolean := true;
  c_def_part_po_use_expird_width constant boolean := true;
  c_def_part_po_arc_width_days   constant number := 90; --!_! 1Q = 3 months
  c_def_part_po_stabl_width_days constant number := 270; --!_! 180 + 90; days(c_def_mnp_po_expired_sec) (PO_ACTIVE) + c_def_part_po_arc_width_days (PO_NOTACTIVE)
  c_def_part_po_month_rnd_up     constant boolean := true;
  c_def_part_po_arc_init_date    constant date := util_pkg.char_to_date('01.01.2014 00:00:00');
  c_def_part_po_part_name_fmt    constant varchar2(100) := 'yyyymmdd';
  c_def_part_po_rebuild_inds     constant boolean := true;

  c_def_srv_wnd_hour_from        constant number := 23;
  c_def_srv_wnd_hour_to_excl     constant number := 8;


----------------------------------!---------------------------------------------
  c_all_apoint                   constant number := 0;
  c_min_count_of_apoint          constant number := 1;
  c_max_count_of_apoint          constant number := 2;

  c_admin_job_label              constant varchar2(100) := 'JOB_LABEL_Admin.JOB_UPDATE_397800A3-ECC0-4282-82D3-68A58ED89F0C';
  c_admin_job_sql                constant clob := q'{begin
--!!! DON''T REMOVE THIS LABEL
--JOB_LABEL_Admin.JOB_UPDATE_397800A3-ECC0-4282-82D3-68A58ED89F0C
admin.job_update;
end;
}'
  ;

  c_admin_job_long_process_label constant varchar2(100) := 'JOB_LABEL_Admin.JOB_UPDATE_LONG_PROCESS_A1FD9F81-4B98-4aba-BB43-D3316CBAF183';
  c_admin_job_long_process_sql   constant clob := q'{begin
--!!! DON''T REMOVE THIS LABEL
--JOB_LABEL_Admin.JOB_UPDATE_LONG_PROCESS_A1FD9F81-4B98-4aba-BB43-D3316CBAF183
admin.job_update_long_process;
end;
}'
  ;

----------------------------------!---------------------------------------------
  type t_HostTypeCode is table of host.host_type_code%type index by binary_integer;

----------------------------------!---------------------------------------------
  function is_in_hours_window
  (
    p_date date,
    p_hour_from number,
    p_hour_to_excl number
  ) return boolean;

  function is_in_service_window(p_date date) return boolean;

----------------------------------!---------------------------------------------
  procedure job_update;
  procedure job_update_long_process;

----------------------------------!---------------------------------------------
  procedure proc_changes_nash;
  procedure proc_changes_pnsc;
  procedure proc_changes_naap;

  procedure proc_inspect_flows;

----------------------------------!---------------------------------------------
  procedure update_network_address_status;
  procedure update_salability_category;

----------------------------------!---------------------------------------------
  procedure Reservation_Batch_Update;

  procedure reset_expired_res_batchs
  (
    p_batch_type varchar2,
    p_user_id number,
    p_date date
  );

----------------------------------!---------------------------------------------
  procedure Auto_Phone_Status_Update;

----------------------------------!---------------------------------------------
  procedure Access_Point_Per_Host(p_date date := sysdate);

  procedure Get_APoint_Per_Host_Stat
  (
    p_host_tcodes util_pkg.cit_varchar_s,
    p_src_date date := sysdate,
    p_src_option integer := c_all_apoint,
    p_error_code out number,
    p_error_message out varchar2,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure auto_mnp_prepare_phone2return;

----------------------------------!---------------------------------------------
  procedure auto_mnp_del_complete_batch;

----------------------------------!---------------------------------------------
  procedure auto_mnp_po_expired;

----------------------------------!---------------------------------------------
  procedure auto_unreg_roaming_cache_group;

----------------------------------!---------------------------------------------
  procedure auto_rem_roaming_cache_group;

----------------------------------!---------------------------------------------
  procedure auto_split_po_parts(p_date date);

----------------------------------!---------------------------------------------

end;
/
