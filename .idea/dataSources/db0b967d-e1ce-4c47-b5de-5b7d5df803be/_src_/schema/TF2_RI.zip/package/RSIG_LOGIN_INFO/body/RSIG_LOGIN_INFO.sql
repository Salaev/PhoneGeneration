CREATE PACKAGE BODY RSIG_LOGIN_INFO IS


---------------------------------------------
--     PROCEDURE Insert_Login_Info
---------------------------------------------

PROCEDURE Insert_Login_Info
(
  p_login                IN LOGIN_INFO.LOGIN%TYPE,
  p_password             IN LOGIN_INFO.PASSWORD%TYPE,
  p_user_status          IN LOGIN_INFO.USER_STATUS%TYPE,
  p_password_next_change IN LOGIN_INFO.PASSWORD_NEXT_CHANGE%TYPE,
  p_network_operator_id  IN LOGIN_INFO.NETWORK_OPERATOR_ID%TYPE,
  p_user_id_of_change    IN USERS.USER_ID%TYPE,
  p_login_info_id        OUT LOGIN_INFO.LOGIN_INFO_ID%TYPE,
  handle_tran            IN CHAR,
  p_raise_error          IN CHAR,
  error_code             OUT NUMBER,
  error_message          OUT VARCHAR2
) IS
  v_event_source       VARCHAR2(60) := 'RSIG_LOGIN_INFO.Insert_Login_Info';
  v_sqlcode            NUMBER;
  v_network_address_id NETWORK_ADDRESS.NETWORK_ADDRESS_ID%TYPE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;
  IF p_network_operator_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, '');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = 'S') THEN
    SAVEPOINT Insert_login_info;
  END IF;

  -- procedure body here
  INSERT INTO NETWORK_ADDRESS
    (NETWORK_ADDRESS_ID)
  VALUES
    (S_NETWORK_ADDRESS.NEXTVAL)
  RETURNING NETWORK_ADDRESS_ID INTO v_network_address_id;

  INSERT INTO LOGIN_INFO l
    (LOGIN_INFO_ID,
     NETWORK_ADDRESS_ID,
     LOGIN,
     PASSWORD,
     USER_STATUS,
     PASSWORD_NEXT_CHANGE,
     NETWORK_OPERATOR_ID,
     DATE_OF_CHANGE,
     USER_ID_OF_CHANGE,
     DELETED)
  VALUES
    (S_LOGIN_INFO.NEXTVAL,
     v_network_address_id,
     p_login,
     p_password,
     p_user_status,
     p_password_next_change,
     p_network_operator_id,
     SYSDATE,
     p_user_id_of_change,
     NULL)
  RETURNING LOGIN_INFO_ID INTO p_login_info_id;

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  error_code := 0;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint Insert_login_info;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
    IF upper(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE_APPLICATION_ERROR(v_sqlcode, error_message);
    END IF;

END Insert_login_info;

---------------------------------------------
--     PROCEDURE Update_Login_Info
---------------------------------------------

PROCEDURE Update_Login_Info
(
  p_password             IN LOGIN_INFO.PASSWORD%TYPE,
  p_user_status          IN LOGIN_INFO.USER_STATUS%TYPE,
  p_password_next_change IN LOGIN_INFO.PASSWORD_NEXT_CHANGE%TYPE,
  p_network_operator_id  IN LOGIN_INFO.NETWORK_OPERATOR_ID%TYPE,
  p_login_info_id        IN LOGIN_INFO.LOGIN_INFO_ID%TYPE,
  p_user_id_of_change    IN USERS.USER_ID%TYPE,
  handle_tran            IN CHAR,
  p_raise_error          IN CHAR,
  ERROR_CODE             OUT NUMBER,
  error_message          OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_LOGIN_INFO.Update_Login_Info';
  v_sqlcode      NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = 'S') THEN
    SAVEPOINT Update_login_info;
  END IF;

  -- procedure body here

  -- if p_password is null don't change it
  IF p_password IS NULL THEN
    UPDATE LOGIN_INFO l
       SET USER_STATUS          = p_user_status,
           PASSWORD_NEXT_CHANGE = p_password_next_change,
           NETWORK_OPERATOR_ID  = p_network_operator_id,
           DATE_OF_CHANGE       = SYSDATE,
           USER_ID_OF_CHANGE    = p_user_id_of_change
     WHERE LOGIN_INFO_ID = p_login_info_id;
  ELSE
    UPDATE LOGIN_INFO l
       SET PASSWORD             = p_password,
           USER_STATUS          = p_user_status,
           PASSWORD_NEXT_CHANGE = p_password_next_change,
           NETWORK_OPERATOR_ID  = p_network_operator_id,
           DATE_OF_CHANGE       = SYSDATE,
           USER_ID_OF_CHANGE    = p_user_id_of_change
     WHERE LOGIN_INFO_ID = p_login_info_id;
  END IF;

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  ERROR_CODE := 0;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    --    DBMS_OUTPUT.PUT_LINE(sqlerrm);
    error_message := SQLERRM;
    v_sqlcode     := SQLCODE;
    ERROR_CODE    := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Update_login_info;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF upper(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Update_login_info;

---------------------------------------------
--     PROCEDURE Delete_Login_Info
---------------------------------------------

PROCEDURE Delete_Login_Info
(
  p_login_info_id     IN LOGIN_INFO.LOGIN_INFO_ID%TYPE,
  p_date              IN DATE,
  p_user_id_of_change IN USERS.USER_ID%TYPE,
  handle_tran         IN CHAR,
  p_raise_error       IN CHAR,
  error_code          OUT NUMBER,
  error_message       OUT VARCHAR2
) IS
  v_event_source       VARCHAR2(60) := 'RSIG_LOGIN_INFO.Delete_Login_Info';
  v_sqlcode            NUMBER;
  v_date               DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  v_date := nvl(p_date, SYSDATE);

  -- set savepoint
  IF (upper(handle_tran) = 'S') THEN
    SAVEPOINT Delete_Login_Info;
  END IF;

  -- procedure body here
  UPDATE LOGIN_INFO li
     SET DELETED           = v_date,
         DATE_OF_CHANGE    = SYSDATE,
         USER_ID_OF_CHANGE = p_user_id_of_change
   WHERE li.LOGIN_INFO_ID = p_login_info_id;

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  error_code := 0;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_message := SQLERRM;
    v_sqlcode     := SQLCODE;
    --    DBMS_OUTPUT.PUT_LINE(sqlerrm);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint Delete_Login_Info;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
    IF upper(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Delete_Login_Info;

---------------------------------------------
--     PROCEDURE Get_Login_Info
---------------------------------------------

PROCEDURE Get_Login_Info
(
  p_network_address_id   IN LOGIN_INFO.NETWORK_ADDRESS_ID%TYPE,
  p_login_info_id        IN LOGIN_INFO.LOGIN_INFO_ID%TYPE,
  p_login                IN LOGIN_INFO.LOGIN%TYPE,
  p_user_status          IN LOGIN_INFO.USER_STATUS%TYPE,
  p_password_next_change IN LOGIN_INFO.PASSWORD_NEXT_CHANGE%TYPE,
  p_network_operator_id  IN LOGIN_INFO.NETWORK_OPERATOR_ID%TYPE,
  p_show_deleted         IN CHAR,
  p_raise_error          IN CHAR,
  error_code             OUT NUMBER,
  error_message          OUT VARCHAR2,
  result_list            OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_LOGIN_INFO.Get_Login_Info';
  v_sqlcode      NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- procedure body here
  OPEN result_list FOR
    SELECT NETWORK_ADDRESS_ID,
           LOGIN_INFO_ID,
           LOGIN,
           PASSWORD,
           USER_STATUS,
           PASSWORD_NEXT_CHANGE,
           NETWORK_OPERATOR_ID,
           DELETED,
           USER_ID_OF_CHANGE
      FROM LOGIN_INFO l
     WHERE 1 = 1
       AND (l.NETWORK_ADDRESS_ID = p_network_address_id OR p_network_address_id IS NULL)
       AND (l.LOGIN_INFO_ID = p_login_info_id OR p_login_info_id IS NULL)
       AND (l.LOGIN = p_login OR p_login IS NULL)
       AND (l.USER_STATUS = p_user_status OR p_user_status IS NULL)
       AND (l.PASSWORD_NEXT_CHANGE = p_password_next_change OR p_password_next_change IS NULL)
       AND (l.network_operator_id = p_network_operator_id OR p_network_operator_id IS NULL)
       AND (DELETED IS NULL OR DELETED > SYSDATE OR p_show_deleted = RSIG_UTILS.c_YES);

  -- set error code to succesfully completed
  error_code := 0;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_message := SQLERRM;
    v_sqlcode     := SQLCODE;
    --    DBMS_OUTPUT.PUT_LINE(sqlerrm);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF upper(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_Login_Info;

END RSIG_LOGIN_INFO;
/
