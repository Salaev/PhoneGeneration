CREATE package vp_agroup is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'AGROUP';

----------------------------------!---------------------------------------------
  function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return agroup%rowtype;
  function get1(p_id integer, p_date date) return agroup%rowtype;
  function xget1(p_id integer, p_date date) return agroup%rowtype;
  function xlock_get1(p_id integer, p_date date) return agroup%rowtype;
  function xlock_xget1(p_id integer, p_date date) return agroup%rowtype;

----------------------------------!---------------------------------------------
  procedure xvalid_i(p_rec agroup%rowtype);

----------------------------------!---------------------------------------------
  function find_i_id(p_rec agroup%rowtype) return boolean;
  function find_i_name(p_rec agroup%rowtype) return boolean;

  function find_i(p_rec agroup%rowtype) return boolean;
  procedure xunique_i(p_rec agroup%rowtype);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec agroup%rowtype);
  procedure close_i(p_rec agroup%rowtype);
  procedure delete_i(p_rec agroup%rowtype);

----------------------------------!---------------------------------------------
  function is_identified(p_rec agroup%rowtype) return boolean;

  function is_exist(p_id number, p_date_from date, p_date_to date) return boolean;

----------------------------------!---------------------------------------------
  function acquire_id return number;

  procedure version_open(p_rec in out nocopy agroup%rowtype);
  procedure version_change(p_rec in out nocopy agroup%rowtype);

  procedure version_close
  (
    p_id integer,
    p_user_id integer,
    p_date_from date := null, --!_!for p_hard_delete: p_date_from = v_rec.date_from (p_id = v_rec.table_name_id)
    p_hard_delete boolean := false
  );

----------------------------------!---------------------------------------------

end;
/
