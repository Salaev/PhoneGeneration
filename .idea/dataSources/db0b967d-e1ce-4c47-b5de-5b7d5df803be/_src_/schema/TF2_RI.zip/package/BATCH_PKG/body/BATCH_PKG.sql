CREATE package body batch_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_batch_details_i(p_batch_id number) return ct_number
is
  v_res ct_number;
  v_rec_batch batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  ------------------------------
  v_rec_batch := vp_batch.get1(p_batch_id);
  ------------------------------
  if v_rec_batch.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  select /*+ index_asc(z, I_BATCH_DETAILS_BATCH_ID)*/
    object_id
    bulk collect into v_res
    from batch_details z
    where 1 = 1
    and batch_id = p_batch_id
    order by object_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_batch_details_by_object_i(p_object_id ct_number, p_batch_type ct_number, p_trim_empty boolean, p_object_id2 out ct_number, p_batch_id out ct_number)
is
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_any number := util_pkg.c_false;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_object_id, 'p_object_id');
  --!_!util_pkg.XCheckP_ct_number(p_batch_type, 'p_batch_type');
  ------------------------------
  if p_batch_type is null
  then
    ------------------------------
    v_any := util_pkg.c_true;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_nl(q, bd, b) use_hash(q2) index_asc(bd, I_BATCH_DETAILS_OBJ_ID) index_asc(b, PK_BATCH)*/
  --!_!q.object_id, b.batch_id
  q.object_id, bd.batch_id
  bulk collect into p_object_id2, p_batch_id
  from
    (select column_value object_id, rownum rn from table(p_object_id)) q,
    batch_details bd,
    batch b,
    (select distinct column_value batch_type from table(p_batch_type)) q2
  where 1 = 1
  and bd.object_id(+) = q.object_id
  and b.batch_id(+) = bd.batch_id
  and q2.batch_type(+) = b.batch_type
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(bd.object_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  --!_!and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(b.batch_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_any,
    util_pkg.c_false, decode(q2.batch_type, null, util_pkg.c_false, util_pkg.c_true),
    util_pkg.c_true
  ) = util_pkg.c_true
  order by q.rn, bd.batch_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_batches_by_object_i(p_object_id ct_number, p_batch_type ct_number) return ct_number
is
  v_object_id ct_number;
  v_batch_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_object_id, 'p_object_id');
  --!_!util_pkg.XCheckP_ct_number(p_batch_type, 'p_batch_type');
  ------------------------------
  get_batch_details_by_object_i(p_object_id, p_batch_type, TRUE, v_object_id, v_batch_id);
  ------------------------------
  return util_pkg.unique_ct_number(v_batch_id, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_batches_by_object2_i(p_object_id number, p_batch_type ct_number) return ct_number
is
  v_object_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_object_id is null, 'p_object_id');
  --!_!util_pkg.XCheckP_ct_number(p_batch_type, 'p_batch_type');
  ------------------------------
  util_pkg.add_ct_number_val(v_object_id, p_object_id);
  ------------------------------
  return get_batches_by_object_i(v_object_id, p_batch_type);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure batch_upd_date_to_i(p_batch_id number, p_date_to date, p_user_id number)
is
  v_rec batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_date_to is null, 'p_date_to');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  v_rec.end_date := p_date_to;
  v_rec.user_id_of_change := p_user_id;
  ------------------------------
  vp_batch.version_change(v_rec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure batch_upd_status_i(p_batch_id number, p_status number, p_user_id number)
is
  v_rec batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  v_rec.batch_status := p_status;
  v_rec.start_date := sysdate;
  v_rec.user_id_of_change := p_user_id;
  ------------------------------
  vp_batch.version_change(v_rec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function batch_ins_i(p_batch_type number, p_date_from date, p_date_to date, p_user_id number, p_batch_status number) return number
is
  v_batch batch%rowtype;
begin
  ------------------------------
  v_batch := null;
  ------------------------------
  v_batch.start_date := p_date_from;
  v_batch.end_date := p_date_to;
  v_batch.batch_type := p_batch_type;
  v_batch.user_id_of_change := p_user_id;
  v_batch.batch_status := p_batch_status;
  ------------------------------
  vp_batch.version_open(v_batch);
  ------------------------------
  return v_batch.batch_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure batch_del_ii(p_batch_id number, p_user_id number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_loc_pkg.touch_number(p_user_id);
  ------------------------------
  vp_batch.version_close(p_batch_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure batch_del_i(p_batch_id number, p_user_id number, p_silent_not_empty boolean)
is
  v_sp_name varchar2(30);
  v_bd ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_silent_not_empty is null, 'p_silent_not_empty');
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  v_bd := get_batch_details(p_batch_id, TRUE);
  ------------------------------
  if util_pkg.get_count_ct_number(v_bd) > 0
  then
    ------------------------------
    util_sys_pkg.rollback_savepoint(v_sp_name);
    ------------------------------
    if p_silent_not_empty
    then
      ------------------------------
      RETURN;
      ------------------------------
    end if;
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_not_empty, util_pkg.c_msg_object_not_empty || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
    ------------------------------
  end if;
  ------------------------------
  batch_del_ii(p_batch_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure batches_del_i(p_batch_id ct_number, p_user_id number, p_silent_not_empty boolean)
is
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_batch_id, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_silent_not_empty is null, 'p_silent_not_empty');
  ------------------------------
  for v_i in p_batch_id.first..p_batch_id.last
  loop
    ------------------------------
    batch_del_i(p_batch_id(v_i), p_user_id, p_silent_not_empty);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure batch_del_full_i(p_batch_id number, p_user_id number)
is
  v_sp_name varchar2(30);
  v_bd ct_number;
  v_length number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_bd := get_batch_details(p_batch_id, TRUE);
  ------------------------------  
  v_length := util_pkg.get_count_ct_number(v_bd);
  ------------------------------
  if v_length > 0
  then
    ------------------------------
    for v_i in 1..v_length
    loop
      ------------------------------
      vp_batch_details.version_close(p_batch_id, v_bd(v_i));
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
  batch_del_ii(p_batch_id, p_user_id);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure batch_add_to_i(p_batch_id number, p_object_id ct_number, p_user_id number)
is
  v_length number;
  v_rec batch_details%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheckP_ct_number(p_object_id, 'p_object_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_length := util_pkg.get_count_ct_number(p_object_id);
  ------------------------------
  for v_i in 1..v_length
  loop
    ------------------------------
    v_rec := null;
    ------------------------------
    v_rec.object_id := p_object_id(v_i);
    v_rec.batch_id := p_batch_id;
    v_rec.user_id_of_change := p_user_id;
    ------------------------------
    vp_batch_details.version_open(v_rec);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure batch_remove_from_i(p_object_id ct_number, p_batch_type ct_number, p_user_id number)
is
  v_object_id ct_number;
  v_batch_id ct_number;
  v_length number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_object_id, 'p_object_id');
  util_pkg.XCheckP_ct_number(p_batch_type, 'p_batch_type');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_loc_pkg.touch_number(p_user_id);
  ------------------------------
  get_batch_details_by_object_i(util_pkg.unique_ct_number(p_object_id, false), util_pkg.unique_ct_number(p_batch_type, false), TRUE, v_object_id, v_batch_id);
  ------------------------------
  v_length := util_pkg.get_count_ct_number(v_object_id);
  ------------------------------
  if v_length > 0
  then
    ------------------------------
    for v_i in 1..v_length
    loop
      ------------------------------
      vp_batch_details.version_close(v_batch_id(v_i), v_object_id(v_i));
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function lock_1batch(p_id number, p_wait boolean) return boolean
is
  v_is_locked boolean;
  v_rec batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  v_rec := vp_batch.get1_i(p_id, TRUE, p_wait, v_is_locked);
  ------------------------------
  if (1 = 0
    or v_is_locked
    or v_rec.batch_id is null
  )
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_first_batch_by_status
(
    p_status number,
    p_type number,
    p_date date
) return number
is
  v_id number;
  v_res number;
  v_cursor sys_refcursor;
  v_lock_res boolean;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_type is null, 'p_type');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_res := null;
  ------------------------------
  open v_cursor for
select /*+ index(z I_BATCH_TYPE2)*/
    z.batch_id
  from batch z
  where 1 = 1
  and z.batch_status = p_status
  and z.batch_type = p_type
  and p_date between z.start_date and z.end_date
  ;
  ------------------------------
  loop
    ------------------------------
    fetch v_cursor into v_id;
    ------------------------------
    exit when v_cursor%notfound;
    ------------------------------
    v_lock_res := lock_1batch(v_id, FALSE);
    ------------------------------
    if NOT v_lock_res
    then
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    v_res := v_id;
    ------------------------------
    exit;
    ------------------------------
  end loop;
  ------------------------------
  if v_cursor%isopen
  then
    close v_cursor;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when others then
  ------------------------------
  if v_cursor%isopen
  then
    close v_cursor;
  end if;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_expired_batch_cursor
(
    p_status number,
    p_type number,
    p_date date
) return sys_refcursor
is
  v_cursor sys_refcursor;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_type is null, 'p_type');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open v_cursor for
select /*+ index(z I_BATCH_TYPE2)*/
    z.batch_id
  from batch z
  where 1 = 1
  and z.batch_status = p_status
  and z.batch_type = p_type
  and p_date > z.end_date
  ;
  ------------------------------
  return v_cursor;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_expired_batch_cursor2
(
    p_type number,
    p_date date
) return sys_refcursor
is
  v_status number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_type is null, 'p_type');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  case p_type
  when c_BATCH_TYPE_NA_UNMNG then
    v_status := c_bs_new;
  when c_BATCH_TYPE_NA_MNG then
    v_status := c_bs_new;
  when c_BATCH_TYPE_NA_MNP_RETURN then
    v_status := c_bs_complete;
  else util_pkg.Raise_Invalid_Param('p_type');
  end case;
  ------------------------------
  return get_expired_batch_cursor
  (
    p_status => v_status,
    p_type => p_type,
    p_date => p_date
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure batch_add_to(p_batch_id number, p_object_id ct_number, p_user_id number)
is
begin
  ------------------------------
  batch_add_to_i(p_batch_id, p_object_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure batch_remove_from(p_object_id ct_number, p_batch_type ct_number, p_user_id number)
is
begin
  ------------------------------
  batch_remove_from_i(p_object_id, p_batch_type, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function batch_ins(p_batch_type number, p_date_from date, p_date_to date, p_user_id number) return number
is
  v_batch_status number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_type is null, 'p_batch_type');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  case p_batch_type
  when c_BATCH_TYPE_NA_UNMNG then
    v_batch_status := c_bs_new;
  when c_BATCH_TYPE_NA_MNG then
    v_batch_status := c_bs_new;
  when c_BATCH_TYPE_NA_MNP_RETURN then
    v_batch_status := c_bs_new;
  else util_pkg.Raise_Invalid_Param('p_batch_type');
  end case;
  ------------------------------
  return batch_ins_i(p_batch_type, p_date_from, p_date_to, p_user_id, v_batch_status);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure batch_del(p_batch_id number, p_user_id number, p_silent_not_empty boolean)
is
begin
  ------------------------------
  batch_del_i(p_batch_id, p_user_id, p_silent_not_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure batch_del_full(p_batch_id number, p_user_id number)
is
begin
  ------------------------------
  batch_del_full_i(p_batch_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure batch_upd_date_to(p_batch_id number, p_date_to date, p_user_id number)
is
begin
  ------------------------------
  batch_upd_date_to_i(p_batch_id, p_date_to, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure move_batch_to_next_status(p_batch_id number, p_user_id number, p_lock boolean)
is
  v_rec batch%rowtype;
begin
  ------------------------------
  if p_lock
  then
    v_rec := vp_batch.xlock_get1(p_batch_id);
  else
    v_rec := vp_batch.get1(p_batch_id);
  end if;
  ------------------------------
  if v_rec.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  case v_rec.batch_type
  when c_BATCH_TYPE_NA_UNMNG then
    util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed);
  when c_BATCH_TYPE_NA_MNG then
    util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed);
  when c_BATCH_TYPE_NA_MNP_RETURN then
    begin
    ------------------------------
    case v_rec.batch_status
    when c_bs_new then batch_upd_status_i(v_rec.batch_id, c_bs_process, p_user_id);
    when c_bs_process then batch_upd_status_i(v_rec.batch_id, c_bs_complete, p_user_id);
    when c_bs_complete then util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed);
    else util_pkg.Raise_Invalid_Param('v_rec.batch_status');
    end case;
    ------------------------------
    end;
  else util_pkg.Raise_Invalid_Param('v_rec.batch_type');
  end case;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure reset_batch_status(p_batch_id number, p_user_id number, p_lock boolean)
is
  v_rec batch%rowtype;
begin
  ------------------------------
  if p_lock
  then
    v_rec := vp_batch.xlock_get1(p_batch_id);
  else
    v_rec := vp_batch.get1(p_batch_id);
  end if;
  ------------------------------
  if v_rec.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  case v_rec.batch_type
  when c_BATCH_TYPE_NA_UNMNG then
    util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed);
  when c_BATCH_TYPE_NA_MNG then
    util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed);
  when c_BATCH_TYPE_NA_MNP_RETURN then
    begin
    ------------------------------
    case v_rec.batch_status
    when c_bs_new then util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed);
    when c_bs_process then batch_upd_status_i(v_rec.batch_id, c_bs_new, p_user_id);
    when c_bs_complete then util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed);
    else util_pkg.Raise_Invalid_Param('v_rec.batch_status');
    end case;
    ------------------------------
    end;
  else util_pkg.Raise_Invalid_Param('v_rec.batch_type');
  end case;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure resize_t_batch(p_coll in out nocopy t_batch, p_size number)

is
  v_dif number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := t_batch();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_nbatches(p_ids ct_number, p_lock boolean, p_batchs out t_batch, p_error_codes out ct_number, p_error_message out ct_varchar) return boolean
is
  v_res boolean := true;
  v_is_locked boolean;
  v_i number;
  v_j number;
  v_cnt number;
begin
  ------------------------------
  v_cnt :=  util_pkg.get_count_ct_number(p_ids);
  ------------------------------
  if (v_cnt = 0)
  then
    return v_res;
  end if;
  ------------------------------
  resize_t_batch(p_batchs, v_cnt);
  util_pkg.resize_ct_number(p_error_codes, v_cnt);
  util_pkg.resize_ct_varchar(p_error_message, v_cnt);
  ------------------------------
  v_i := p_ids.first;
  v_j := 0;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_j := v_j + 1;
    ------------------------------
    p_error_codes(v_j) := util_pkg.c_ora_ok;
    p_error_message(v_j) := util_pkg.c_msg_ok;
    ------------------------------
    p_batchs(v_j) := vp_batch.get1_i(p_ids(v_i), p_lock, false, v_is_locked);
    ------------------------------
    if p_batchs(v_j).batch_id is null
    then
      ------------------------------
      v_res := false;
      ------------------------------
      if v_is_locked
      then
        ------------------------------
        p_error_codes(v_j) := util_pkg.c_ora_object_locked;
        p_error_message(v_j) := util_pkg.c_msg_object_locked;
        ------------------------------
      else
        ------------------------------
        p_error_codes(v_j) := util_pkg.c_ora_object_not_found;
        p_error_message(v_j) := util_pkg.c_msg_object_not_found;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    v_i := p_ids.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_batch_details(p_batch_id number, p_xlock_batch boolean) return ct_number
is
  v_batch batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_xlock_batch is null, 'p_xlock_batch');
  ------------------------------
  if p_xlock_batch
  then
    v_batch := vp_batch.xlock_get1(p_batch_id);
    util_loc_pkg.touch_number(v_batch.batch_id);
  end if;
  ------------------------------
  return get_batch_details_i(p_batch_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_na_res_batch_type(p_batch_type number)
is
  v_na_batch_types ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_type is null, 'p_batch_type');
  ------------------------------
  v_na_batch_types := get_na_res_batch_types;
  ------------------------------
  if util_pkg.index_of_ct_number(v_na_batch_types, p_batch_type) = util_pkg.c_index_not_found
  then
    ------------------------------
    util_pkg.Raise_Invalid_Param('p_batch_type');
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_res_batch_types return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_res, c_BATCH_TYPE_NA_UNMNG);
  util_pkg.add_ct_number_val(v_res, c_BATCH_TYPE_NA_MNG);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_na_res_batch_details_by_na(p_na_id ct_number, p_trim_empty boolean, p_na_id2 out ct_number, p_batch_id out ct_number)
is
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  ------------------------------
  get_batch_details_by_object_i(p_na_id, get_na_res_batch_types, p_trim_empty, p_na_id2, p_batch_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_res_batches_by_na(p_na_id ct_number) return ct_number
is
  v_na_id ct_number;
  v_batch_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  ------------------------------
  get_na_res_batch_details_by_na(p_na_id, TRUE, v_na_id, v_batch_id);
  ------------------------------
  return util_pkg.unique_ct_number(v_batch_id, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_res_batches_by_na2(p_na_id number) return ct_number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_na_res_batches_by_na(v_na_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_res_batch_msisdns(p_batch_id number, p_date date, p_xlock_batch boolean) return ct_varchar_s
is
  v_na_id ct_number;
  v_rec_batch batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_xlock_batch is null, 'p_xlock_batch');
  ------------------------------
  v_rec_batch := vp_batch.get1(p_batch_id);
  ------------------------------
  XCheck_na_res_batch_type(v_rec_batch.batch_type);
  ------------------------------
  v_na_id := get_batch_details(p_batch_id, p_xlock_batch);
  ------------------------------
  return util_ri.get_msisdn(v_na_id, p_date, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batch_del_i(p_batch_id number, p_user_id number, p_silent_not_empty boolean)
is
  v_rec_batch batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_silent_not_empty is null, 'p_silent_not_empty');
  ------------------------------
  v_rec_batch := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  if v_rec_batch.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_res_batch_type(v_rec_batch.batch_type);
  ------------------------------
  batch_del(p_batch_id, p_user_id, p_silent_not_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batch_del_plain(p_batch_id number, p_user_id number)
is
begin
  ------------------------------
  na_res_batch_del_i(p_batch_id, p_user_id, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batch_del_smart(p_batch_id number, p_user_id number)
is
begin
  ------------------------------
  na_res_batch_del_i(p_batch_id, p_user_id, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batches_del_i(p_batch_id ct_number, p_user_id number, p_silent_not_empty boolean)
is
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_batch_id, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_silent_not_empty is null, 'p_silent_not_empty');
  ------------------------------
  for v_i in p_batch_id.first..p_batch_id.last
  loop
    ------------------------------
    na_res_batch_del_i(p_batch_id(v_i), p_user_id, p_silent_not_empty);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batches_del2_i(p_batch_id number, p_user_id number, p_silent_not_empty boolean)
is
  v_batch_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_silent_not_empty is null, 'p_silent_not_empty');
  ------------------------------
  util_pkg.add_ct_number_val(v_batch_id, p_batch_id);
  ------------------------------
  na_res_batches_del_i(v_batch_id, p_user_id, p_silent_not_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batches_del_plain(p_batch_id ct_number, p_user_id number)
is
begin
  ------------------------------
  na_res_batches_del_i(p_batch_id, p_user_id, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batches_del_smart(p_batch_id ct_number, p_user_id number)
is
begin
  ------------------------------
  na_res_batches_del_i(p_batch_id, p_user_id, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batches_del2_plain(p_batch_id number, p_user_id number)
is
begin
  ------------------------------
  na_res_batches_del2_i(p_batch_id, p_user_id, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batches_del2_smart(p_batch_id number, p_user_id number)
is
begin
  ------------------------------
  na_res_batches_del2_i(p_batch_id, p_user_id, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batch_del_full_i(p_batch_id number, p_user_id number)
is
  v_rec_batch batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec_batch := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  if v_rec_batch.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_res_batch_type(v_rec_batch.batch_type);
  ------------------------------
  batch_del_full(p_batch_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batch_del_full(p_batch_id number, p_user_id number)
is
begin
  ------------------------------
  na_res_batch_del_full_i(p_batch_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batch_add_to(p_batch_id number, p_na_id ct_number, p_user_id number)
is
  v_rec batch%rowtype;
  v_batch_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  if v_rec.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_res_batch_type(v_rec.batch_type);
  ------------------------------
  v_batch_id := get_na_res_batches_by_na(p_na_id);
  ------------------------------
  if util_pkg.get_count_ct_number(v_batch_id) > 0
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_na_already_in_na_batch, util_loc_pkg.c_msg_na_already_in_na_batch || util_pkg.c_msg_delim01 || util_pkg.number_to_char(v_batch_id(v_batch_id.first)));
  end if;
  ------------------------------
  batch_add_to(v_rec.batch_id, p_na_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batch_add_to2(p_batch_id number, p_na_id number, p_user_id number)
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  na_res_batch_add_to(p_batch_id, v_na_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batch_remove_from(p_na_id ct_number, p_user_id number)
is
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  batch_remove_from(p_na_id, get_na_res_batch_types, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batch_remove_from2(p_na_id number, p_user_id number)
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  na_res_batch_remove_from(v_na_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function na_res_batch_get_details(p_batch_id number) return ct_number
is
  v_rec batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  ------------------------------
  v_rec := vp_batch.get1(p_batch_id);
  ------------------------------
  if v_rec.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_res_batch_type(v_rec.batch_type);
  ------------------------------
  return get_batch_details(v_rec.batch_id , FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batch_upd_date_to(p_batch_id number, p_date_to date, p_user_id number)
is
  v_rec batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_date_to is null, 'p_date_to');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  if v_rec.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_res_batch_type(v_rec.batch_type);
  ------------------------------
  batch_upd_date_to(v_rec.batch_id, p_date_to, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batch_to_next_status(p_batch_id number, p_user_id number)
is
  v_rec batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  if v_rec.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_res_batch_type(v_rec.batch_type);
  ------------------------------
  move_batch_to_next_status(v_rec.batch_id, p_user_id, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_res_batch_reset_status(p_batch_id number, p_user_id number)
is
  v_rec batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  if v_rec.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_res_batch_type(v_rec.batch_type);
  ------------------------------
  reset_batch_status(v_rec.batch_id, p_user_id, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_na_mnp_batch_type(p_batch_type number)
is
  v_na_batch_types ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_type is null, 'p_batch_type');
  ------------------------------
  v_na_batch_types := get_na_mnp_batch_types;
  ------------------------------
  if util_pkg.index_of_ct_number(v_na_batch_types, p_batch_type) = util_pkg.c_index_not_found
  then
    ------------------------------
    util_pkg.Raise_Invalid_Param('p_batch_type');
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_mnp_batch_types return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_res, c_BATCH_TYPE_NA_MNP_RETURN);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_na_mnp_batch_details_by_na(p_na_id ct_number, p_trim_empty boolean, p_na_id2 out ct_number, p_batch_id out ct_number)
is
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  ------------------------------
  get_batch_details_by_object_i(p_na_id, get_na_mnp_batch_types, p_trim_empty, p_na_id2, p_batch_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_mnp_batches_by_na(p_na_id ct_number) return ct_number
is
  v_na_id ct_number;
  v_batch_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  ------------------------------
  get_na_mnp_batch_details_by_na(p_na_id, TRUE, v_na_id, v_batch_id);
  ------------------------------
  return util_pkg.unique_ct_number(v_batch_id, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_mnp_batches_by_na2(p_na_id number) return ct_number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_na_mnp_batches_by_na(v_na_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_mnp_batch_nas(p_batch_id number, p_date date, p_xlock_batch boolean) return ct_number
is
  v_rec_batch batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_xlock_batch is null, 'p_xlock_batch');
  ------------------------------
  v_rec_batch := vp_batch.get1(p_batch_id);
  ------------------------------
  XCheck_na_mnp_batch_type(v_rec_batch.batch_type);
  ------------------------------
  return get_batch_details(p_batch_id, p_xlock_batch);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batch_del_i(p_batch_id number, p_user_id number, p_silent_not_empty boolean)
is
  v_rec_batch batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_silent_not_empty is null, 'p_silent_not_empty');
  ------------------------------
  v_rec_batch := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  if v_rec_batch.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_mnp_batch_type(v_rec_batch.batch_type);
  ------------------------------
  batch_del(p_batch_id, p_user_id, p_silent_not_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batch_del_plain(p_batch_id number, p_user_id number)
is
begin
  ------------------------------
  na_mnp_batch_del_i(p_batch_id, p_user_id, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batch_del_smart(p_batch_id number, p_user_id number)
is
begin
  ------------------------------
  na_mnp_batch_del_i(p_batch_id, p_user_id, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batches_del_i(p_batch_id ct_number, p_user_id number, p_silent_not_empty boolean)
is
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_batch_id, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_silent_not_empty is null, 'p_silent_not_empty');
  ------------------------------
  for v_i in p_batch_id.first..p_batch_id.last
  loop
    ------------------------------
    na_mnp_batch_del_i(p_batch_id(v_i), p_user_id, p_silent_not_empty);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batches_del2_i(p_batch_id number, p_user_id number, p_silent_not_empty boolean)
is
  v_batch_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_silent_not_empty is null, 'p_silent_not_empty');
  ------------------------------
  util_pkg.add_ct_number_val(v_batch_id, p_batch_id);
  ------------------------------
  na_mnp_batches_del_i(v_batch_id, p_user_id, p_silent_not_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batches_del_plain(p_batch_id ct_number, p_user_id number)
is
begin
  ------------------------------
  na_mnp_batches_del_i(p_batch_id, p_user_id, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batches_del_smart(p_batch_id ct_number, p_user_id number)
is
begin
  ------------------------------
  na_mnp_batches_del_i(p_batch_id, p_user_id, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batches_del2_plain(p_batch_id number, p_user_id number)
is
begin
  ------------------------------
  na_mnp_batches_del2_i(p_batch_id, p_user_id, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batches_del2_smart(p_batch_id number, p_user_id number)
is
begin
  ------------------------------
  na_mnp_batches_del2_i(p_batch_id, p_user_id, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batch_del_full_i(p_batch_id number, p_user_id number)
is
  v_rec_batch batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec_batch := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  if v_rec_batch.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_mnp_batch_type(v_rec_batch.batch_type);
  ------------------------------
  batch_del_full(p_batch_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batch_del_full(p_batch_id number, p_user_id number)
is
begin
  ------------------------------
  na_mnp_batch_del_full_i(p_batch_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batch_add_to(p_batch_id number, p_na_id ct_number, p_user_id number)
is
  v_rec batch%rowtype;
  v_batch_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  if v_rec.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_mnp_batch_type(v_rec.batch_type);
  ------------------------------
  v_batch_id := get_na_res_batches_by_na(p_na_id);
  ------------------------------
  if util_pkg.get_count_ct_number(v_batch_id) > 0
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_na_already_in_na_batch, util_loc_pkg.c_msg_na_already_in_na_batch || util_pkg.c_msg_delim01 || util_pkg.number_to_char(v_batch_id(v_batch_id.first)));
  end if;
  ------------------------------
  batch_add_to(v_rec.batch_id, p_na_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batch_add_to2(p_batch_id number, p_na_id number, p_user_id number)
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  na_mnp_batch_add_to(p_batch_id, v_na_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batch_remove_from(p_na_id ct_number, p_user_id number)
is
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  batch_remove_from(p_na_id, get_na_mnp_batch_types, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batch_remove_from2(p_na_id number, p_user_id number)
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  na_mnp_batch_remove_from(v_na_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function na_mnp_batch_get_details(p_batch_id number) return ct_number
is
  v_rec batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  ------------------------------
  v_rec := vp_batch.get1(p_batch_id);
  ------------------------------
  if v_rec.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_mnp_batch_type(v_rec.batch_type);
  ------------------------------
  return get_batch_details(v_rec.batch_id , FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batch_upd_date_to(p_batch_id number, p_date_to date, p_user_id number)
is
  v_rec batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_date_to is null, 'p_date_to');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  if v_rec.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_mnp_batch_type(v_rec.batch_type);
  ------------------------------
  batch_upd_date_to(v_rec.batch_id, p_date_to, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batch_to_next_status(p_batch_id number, p_user_id number)
is
  v_rec batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  if v_rec.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_mnp_batch_type(v_rec.batch_type);
  ------------------------------
  move_batch_to_next_status(v_rec.batch_id, p_user_id, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure na_mnp_batch_reset_status(p_batch_id number, p_user_id number)
is
  v_rec batch%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  if v_rec.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_batch_id));
  end if;
  ------------------------------
  XCheck_na_mnp_batch_type(v_rec.batch_type);
  ------------------------------
  reset_batch_status(v_rec.batch_id, p_user_id, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
end;
/
