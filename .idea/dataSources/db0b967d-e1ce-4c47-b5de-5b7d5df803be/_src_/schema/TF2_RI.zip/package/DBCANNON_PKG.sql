CREATE package DBCANNON_PKG is

----------------------------------!---------------------------------------------
  procedure GetHostByMsisdn(p_msisdns util_pkg.cit_varchar_s, p_error_code out number, p_error_message out varchar2, p_result out sys_refcursor);

----------------------------------!---------------------------------------------

end DBCANNON_PKG;
/
