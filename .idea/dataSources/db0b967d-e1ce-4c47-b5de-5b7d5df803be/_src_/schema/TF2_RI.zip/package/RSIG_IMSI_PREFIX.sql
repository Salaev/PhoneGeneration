CREATE PACKAGE RSIG_IMSI_PREFIX IS

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  c_roam_partner                 constant number := 0;
  c_not_roam_partner             constant number := 1;

----------------------------------!--------------------------------------------
----------------------------------!--------------------------------------------
  PROCEDURE Check_Interval_Overlap
  (
    p_IMSI_prefix_id      IN IMSI_PREFIX.IMSI_PREFIX_ID%TYPE,
    p_start_date          IN DATE,
    p_end_date            IN DATE
  );

  PROCEDURE Insert_IMSI_Prefix
  (
    p_IMSI_prefix       IN IMSI_PREFIX.IMSI_PREFIX%TYPE,
    handle_tran         IN CHAR,
    p_user_id_of_change IN NUMBER,
    p_raise_error       IN CHAR,
    ERROR_CODE          OUT NUMBER,
    error_message       OUT VARCHAR2,
    p_IMSI_prefix_id    OUT IMSI_PREFIX.IMSI_PREFIX_ID%TYPE
  );

  PROCEDURE Update_IMSI_Prefix
  (
    p_IMSI_prefix_id    IN IMSI_PREFIX.IMSI_PREFIX_ID%TYPE,
    p_new_IMSI_prefix   IN IMSI_PREFIX.IMSI_PREFIX%TYPE,
    p_user_id_of_change IN NUMBER,
    handle_tran         IN CHAR,
    p_raise_error       IN CHAR,
    ERROR_CODE          OUT NUMBER,
    error_message       OUT VARCHAR2
  );

  PROCEDURE Insert_interval
  (
    p_IMSI_prefix_id      IN IMSI_PREFIX.IMSI_PREFIX_ID%TYPE,
    p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_start_date          IN DATE,
    p_end_date            IN DATE,
    p_user_id_of_change   IN NUMBER,
    handle_tran           IN CHAR,
    p_raise_error         IN CHAR,
    ERROR_CODE            OUT NUMBER,
    error_message         OUT VARCHAR2
  );

  PROCEDURE Close_Interval
  (
    p_IMSI_prefix_id      IN IMSI_PREFIX.IMSI_PREFIX_ID%TYPE,
    p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_start_date          IN DATE,
    p_end_date            IN DATE,
    p_user_id_of_change   IN NUMBER,
    handle_tran           IN CHAR,
    p_raise_error         IN CHAR,
    ERROR_CODE            OUT NUMBER,
    error_message         OUT VARCHAR2
  );

  PROCEDURE Close_Insert_interval
  (
    p_IMSI_prefix_id          IN IMSI_PREFIX.IMSI_PREFIX_ID%TYPE,
    p_network_operator_id     IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_start_date              IN DATE,
    p_end_date                IN DATE,
    p_new_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_new_start_date          IN DATE,
    p_new_end_date            IN DATE,
    p_user_id_of_change       IN NUMBER,
    handle_tran               IN CHAR,
    p_raise_error             IN CHAR,
    ERROR_CODE                OUT NUMBER,
    error_message             OUT VARCHAR2
  );

  PROCEDURE Ins_IMSI_Prefix_and_Interval
  (
    p_IMSI_prefix         IN IMSI_PREFIX.IMSI_PREFIX%TYPE,
    p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_start_date          IN DATE,
    p_end_date            IN DATE,
    p_user_id_of_change   IN NUMBER,
    handle_tran           IN CHAR,
    p_raise_error         IN CHAR,
    ERROR_CODE            OUT NUMBER,
    error_message         OUT VARCHAR2
  );

  PROCEDURE Get_IMSI_Prefixes_By_Operator
  (
    p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_start_date          IN DATE,
    p_raise_error         IN CHAR,
    ERROR_CODE            OUT NUMBER,
    error_message         OUT VARCHAR2,
    result_list           OUT sys_refcursor
  );

  PROCEDURE Get_IMSI_Prefixes_By_Op_EX
  (
    p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_start_date          IN DATE,
    p_get_history         IN CHAR,
    p_raise_error         IN CHAR,
    ERROR_CODE            OUT NUMBER,
    error_message         OUT VARCHAR2,
    result_list           OUT sys_refcursor
  );

----------------------------------!---------------------------------------------
  function get_imsi_prefix_id0(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean) return ct_number;
  function get_imsi_prefix_id(p_imsi ct_varchar_s, p_date date, p_trim_empty boolean) return ct_number;
  function get_imsi_prefix_id2(p_imsi varchar2, p_date date) return number;

  function get_no4imsi_prefix_id0(p_imsi_prefix_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_no4imsi_prefix_id(p_imsi_prefix_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_no4imsi_prefix_id2(p_imsi_prefix_id number, p_date date) return number;

----------------------------------!---------------------------------------------
  procedure get_imsi_prefixes4imsi_list_i
  (
    p_imsi ct_varchar_s,
    p_date ct_date,
    p_imsi_prefix_id out ct_number
  );

----------------------------------!---------------------------------------------
  procedure get_imsi_prefixes_by_imsi_list
  (
    p_imsi_list util_pkg.cit_varchar_s,
    p_date_list util_pkg.cit_date,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure xcheck_roam_partner4imsi_list
  (
    p_imsi ct_varchar_s,
    p_date ct_date,
    p_roam_partner_flag out ct_number
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function get_result_cursor01(p_imsi ct_varchar_s, p_date ct_date, p_imsi_prefix_id ct_number) return sys_refcursor;
  function get_result_cursor02(p_imsi ct_varchar_s, p_roam_partner_flag ct_number) return sys_refcursor;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

END;
/
