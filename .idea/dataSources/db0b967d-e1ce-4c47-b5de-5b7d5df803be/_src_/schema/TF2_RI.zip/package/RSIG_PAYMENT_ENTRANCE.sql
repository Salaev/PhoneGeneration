CREATE PACKAGE RSIG_PAYMENT_ENTRANCE IS
/****************************************************************************
<header>
  <name>             	package RSIG_PAYMENT_ENTRANCE
  </name>

  <author>           	Martin Zabka
  </author>

  <version>          	1.0.3   14.09.2004     Jaroslav  Holub
                                Delete_Payment_Entrance - fix condition in UPDATE PAY_DESK statement, add brackets
  </version>
  <version>          	1.0.2   03.09.2004     Jaroslav  Holub
                                Delete_Payment_Entrance - changed for NULL date acceptance in start(end)date
                                - if NULL presented then sysdate is filled instead
  </version>
  <version>          	1.0.1   14.5.2004     Jaroslav Holub
                                Delete_Payment_Entrance - after delete of payement entrance -> delete child pay_desks
  </version>
  <version>				1.0.0	25.2.2004	Martin Zabka
  								created first version
  </version>

  <Description>      	package for table PAYMENT_ENTRANCE
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/


 /****************************************************************************
<header>
  <name>             	procedure Insert_Payment_Entrance
  </name>

  <author>           	Martin Zabka
  </author>

  <version>          	1.0.0   25.2.2004     Martin Zabka
                                created first version
  </version>

  <Description>      	procedure inserts a new payment entrance
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );

                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER

                      p_paydesk_entrance_name   IN - value for inserting row (PAYMENT_ENTRANCE_NAME)
                      p_network_operator_id IN - value for inserting row (NETWORK_OPERATOR_ID)
                      p_user_id_of_change   IN - value for inserting row (USER_ID_OF_CHANGE)
											p_payment_entrance_id					OUT - id inserting row (PAYMENT_ENTRANCE_ID)
 </Parameters>

</header>
****************************************************************************/

PROCEDURE Insert_Payment_Entrance (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                       OUT    NUMBER,
		p_payment_entrance_name						IN		 payment_entrance.payment_entrance_name%TYPE,
		p_network_operator_id             IN     payment_entrance.network_operator_id%TYPE,
		p_user_id_of_change               IN     payment_entrance.user_id_of_change%TYPE,
		p_payment_entrance_id							OUT 	 PAYMENT_ENTRANCE.PAYMENT_ENTRANCE_ID%TYPE
  );


/****************************************************************************
<header>
  <name>             	procedure Delete_Payment_Entrance
  </name>

  <author>           	Martin Zabka
  </author>

  <version>          	1.0.3   14.09.2004     Jaroslav  Holub
                                fix condition in UPDATE PAY_DESK statement, add brackets
  </version>
  <version>          	1.0.2   03.09.2004     Jaroslav  Holub
                                 changed for NULL date acceptance in start(end)date
                                - if NULL presented then sysdate is filled instead
  </version>
  <version>          	1.0.1   14.5.2004     Jaroslav Holub
                                after delete of payement entrance -> delete child pay_desks
  </version>
  <version>          	1.0.0   25.2.2004     Martin Zabka
                                created first version
  </version>

  <Description>      	Procedure sets column DELETED to value of parameter deleted in payment entrance given by payment entrance ID,
                      if given payment entrance is currently not deleted.
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_payment_entrance_id  - IN - value for identification of the updating row (PAYMENT_ENTRANCE_ID)
                      p_deleted      - IN - value for set attribute (DELETED)
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/

PROCEDURE Delete_Payment_Entrance (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_payment_entrance_id     IN     PAYMENT_ENTRANCE.PAYMENT_ENTRANCE_ID%TYPE,
    p_deleted                 IN     PAYMENT_ENTRANCE.DELETED%TYPE,
    p_user_id_of_change       IN     PAYMENT_ENTRANCE.USER_ID_OF_CHANGE%TYPE
  );

/****************************************************************************
<header>
  <name>             	procedure Update_Payment_Entrance
  </name>

  <author>           	Martin Zabka
  </author>

  <version>          	1.0.0   25.2.2004     Martin Zabka
                                created first version
  </version>

  <Description>      	Procedure changes name and network operator of given payment entrance
                      if given payment entrance is currently not deleted.
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
											p_payment_entrance_id		 	 		IN - value for idenstification row (PAYMENT_ENTRANCE_ID)
                      p_payment_entrance_name       IN - value for inserting row (PAYMENT_ENTRANCE_NAME)
                      p_network_operator_id IN - value for inserting row (NETWORK_OPERATOR_ID)
                      p_user_id_of_change   IN - value for inserting row (USER_ID_OF_CHANGE)

</Parameters>

</header>
****************************************************************************/

PROCEDURE Update_Payment_Entrance (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
		p_payment_entrance_id			IN		 payment_entrance.payment_entrance_id%TYPE,
		p_payment_entrance_name		IN		 payment_entrance.payment_entrance_name%TYPE,
		p_network_operator_id     IN     payment_entrance.network_operator_id%TYPE,
		p_user_id_of_change       IN     payment_entrance.user_id_of_change%TYPE
  );


  /****************************************************************************
  <header>
    <name>              procedure Get_Payment_Entrance
    </name>

    <author>            Martin Zabka
    </author>

    <version>           1.0.0   25.2.2004     Martin Zabka
                                created first version
    </version>

    <Description>     This procedure will return list of payment entrance for given network operator (network_operator_id).
											if p_all_rows = 'Y', ref cursor will be contains deleted rows too
                      Ref cursor contains columns: PAYMENT_ENTRANCE_ID,PAYMENT_ENTRANCE_NAME,NETWORK_OPERATOR_NAME.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code            - Error code
                        p_validity_date       - Date for that it will be finds all zones.
                        p_operator_id         - Network_operation_id for that we want finds all zones
                        p_resul               - ref cursor (PAYMENT_ENTRANCE_ID, PAYMENT_ENTRANCE_NAME, NETWORK_OPERATOR_NAME)
    </Parameters>

  </header>
/****************************************************************************/


PROCEDURE Get_Payment_Entrance(
    error_code            OUT  NUMBER,
    p_operator_id         IN   PAYMENT_ENTRANCE.NETWORK_OPERATOR_ID%TYPE,
		p_all_rows						IN   CHAR,
    p_result              OUT  RSIG_UTILS.REF_CURSOR
  );
END RSIG_PAYMENT_ENTRANCE;
/
