CREATE package body PRODUCTION_PKG is

------------------------------!------------------------------
------------------------------!------------------------------
procedure PROD_FindFreePhoneNumbers_i
(
  p_host_id host.host_id%type,
  p_msisdn_mask varchar2,
  p_msisdn_start varchar2,
  p_msisdn_end varchar2,
  p_network_operator_code varchar2,
  p_linked_network_operator_code varchar2,
  p_phone_status_code phone_number.net_address_status_code%type,
  p_phone_type_code phone_number_series.phone_number_type_code%type,
  p_quantity_limit number,
  p_salability_category varchar2,
  p_user_login users.login_name%type,
  p_error_code out number,
  p_error_message out varchar2,
  p_result_list out sys_refcursor,
  p_rejected_list out sys_refcursor
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.xcheck_cond_missing(p_host_id is null, 'p_host_id');
  util_pkg.xcheck_cond_missing(p_network_operator_code is null, 'p_network_operator_code');
  util_pkg.xcheck_cond_missing(p_phone_status_code is null, 'p_phone_status_code');
  util_pkg.xcheck_cond_missing(p_phone_type_code is null, 'p_phone_type_code');
  util_pkg.xcheck_cond_missing(p_salability_category is null, 'p_salability_category');
  ------------------------------
  open p_rejected_list for select * from dual where 1 = 0;
  ------------------------------
  if p_msisdn_start is not null and p_msisdn_end is not null
  then
    PROD_CheckPhonesByRange_2_i
    (
      p_msisdn_start => p_msisdn_start,
      p_msisdn_end => p_msisdn_end,
      p_host_id => p_host_id,
      p_network_operator_code => p_network_operator_code,
      p_linked_network_operator_code => p_linked_network_operator_code,
      p_phone_status_code => p_phone_status_code,
      p_phone_type_code => p_phone_type_code,
      p_salability_category => p_salability_category,
      p_user_login => p_user_login,
      p_RequestedCnt => p_quantity_limit,
      p_result_list => p_result_list,
      p_rejected_list => p_rejected_list
    );
  else
    if p_linked_network_operator_code is not null
    then
      PROD_GetLinkedPhonesAll_i
      (
        p_host_id => p_host_id,
        p_network_operator_code => p_network_operator_code,
        p_linked_network_operator_code => p_linked_network_operator_code,
        p_phone_type => p_phone_type_code,
        p_salability_category => p_salability_category,
        p_mask => p_msisdn_mask,
        p_phone_number_status_code => p_phone_status_code,
        p_set_phone_number_status_code => rsig_utils.c_RESERVE_PHONE_NUMBER_CODE,
        p_phone_number_count => p_quantity_limit,
        p_user_login => p_user_login,
        p_result_list => p_result_list
      );
    else
      PROD_GetNotLinkedPhones_2_i
      (
        p_host_id => p_host_id,
        p_network_operator_code => p_network_operator_code,
        p_phone_type => p_phone_type_code,
        p_salability_category => p_salability_category,
        p_mask => p_msisdn_mask,
        p_phone_number_status_code => p_phone_status_code,
        p_set_phone_number_status_code => rsig_utils.c_RESERVE_PHONE_NUMBER_CODE,
        p_phone_number_count => p_quantity_limit,
        p_user_login => p_user_login,
        p_result_list => p_result_list
      );
    end if;
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when OTHERS then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  open p_result_list for select p_error_code from dual;
  open p_rejected_list for select * from dual where 1 = 0;
  ------------------------------
end;

------------------------------!------------------------------
------------------------------!------------------------------
procedure PROD_CheckPhonesByRange_2_i
(
  p_msisdn_start varchar2,
  p_msisdn_end varchar2,
  p_host_id host.host_id%type,
  p_network_operator_code varchar2,
  p_linked_network_operator_code varchar2,
  p_phone_status_code phone_number.net_address_status_code%type,
  p_phone_type_code phone_number_series.phone_number_type_code%type,
  p_salability_category varchar2,
  p_user_login users.login_name%type,
  p_requestedcnt number,
  p_result_list out sys_refcursor,
  p_rejected_list out sys_refcursor
)
is
  ------------------------------
  v_network_operator_id number;
  v_linked_network_operator_id number;
  v_user_id number;
  v_sysdate date := sysdate;
  v_msisdn_m ct_varchar_s;
  c_lock_phones sys_refcursor;
  v_seria_length number;
  v_error_code ct_number;
  v_error_message ct_varchar;
  ------------------------------
  v_msisdns ct_varchar_s;
  v_error_codes ct_number;
  ------------------------------
begin
  ------------------------------
  util_pkg.xcheck_cond_missing(p_user_login is null, 'p_user_login');
  ------------------------------
  v_user_id := util_ri.xget_user_id(p_user_login);
  ------------------------------
  util_pkg.xcheck_cond_missing(p_host_id is null, 'p_host_id');
  util_pkg.xcheck_cond_missing(p_network_operator_code is null, 'p_network_operator_code');
  util_pkg.xcheck_cond_missing(p_phone_status_code is null, 'p_phone_status_code');
  util_pkg.xcheck_cond_missing(p_phone_type_code is null, 'p_phone_type_code');
  util_pkg.xcheck_cond_missing(p_salability_category is null, 'p_salability_category');
  ------------------------------
  --!_! util_pkg.xcheck_cond_missing(p_linked_network_operator_code is null, 'p_linked_network_operator_code');
  ------------------------------
  util_pkg.xcheck_cond_invalid(p_msisdn_start is null, 'p_msisdn_start is null');
  util_pkg.xcheck_cond_invalid(p_msisdn_end is null, 'p_msisdn_end is null');
  util_pkg.xcheck_cond_invalid(length(p_msisdn_start) <> length(p_msisdn_end), 'length(p_msisdn_start) <> length(p_msisdn_end)');
  util_pkg.xcheck_cond_invalid(p_msisdn_start > p_msisdn_end, 'p_msisdn_start > p_msisdn_end');
  ------------------------------
  v_network_operator_id := util_ri.xget_network_operator_id2(p_network_operator_code, sysdate);
  ------------------------------
  if p_linked_network_operator_code is not null
  then
    v_linked_network_operator_id := util_ri.xget_network_operator_id2(p_linked_network_operator_code, sysdate);
  end if;
  ------------------------------
  delete from tt_batch_na_ap;
  ------------------------------
  v_seria_length := to_number(p_MSISDN_end) - to_number(p_MSISDN_start) + 1;
  ------------------------------
  insert into tt_batch_na_ap(international_format, result)
  select
    to_char(to_number(p_MSISDN_start) + rownum - 1),
    util_pkg.c_ORA_OK
  from dual
  connect by level <= v_seria_length;
  ------------------------------
  rsig_utils.Fill_Na_Id_From_Int_Number;
  ------------------------------
  OPEN c_lock_phones FOR
  select pn.network_address_id
    from PHONE_NUMBER pn
   where pn.network_address_id IN
         (select t.network_address_id
            from tt_batch_na_ap t)
     FOR update OF NETWORK_ADDRESS_ID;

  --check HLR
  update tt_batch_na_ap t
     set t.result = rsig_utils.c_NOT_SAME_HOST_ID
   where t.result = util_pkg.c_ORA_OK
     and not exists(select 1
                      from PHONE_NUMBER pn
                      join PHONE_NUMBER_SERIES pns
                        on pns.phone_number_series_id = pn.phone_number_series_id
                     where pns.host_id = p_host_id
                       and pn.International_Format = t.International_Format);

  --check if main number belong to required operator
  update tt_batch_na_ap t set
    t.result = rsig_utils.c_SIM_INVALID_NET_OPER
  where t.result = util_pkg.c_ORA_OK
    and not exists(
      select 1
      from phone_number pnm
      left join phone_series_operator psom
        on psom.phone_number_series_id = pnm.phone_number_series_id
        and sysdate between psom.start_date and nvl(psom.end_date, sysdate)
      where pnm.international_format = t.International_Format
        and psom.network_operator_id = v_network_operator_id
    );

  --check main number status
  update tt_batch_na_ap t
     set t.result = rsig_utils.c_BAD_PHONE_STATUS
   where t.result = util_pkg.c_ORA_OK
     and not exists(select 1
                      from PHONE_NUMBER pn
                     where pn.net_address_status_code = p_phone_status_code
                       and pn.International_Format = t.International_Format);

  --check main number salability category
  update tt_batch_na_ap t
     set t.result = rsig_utils.c_PHONE_INVALID_SAL_CAT
   where t.result = util_pkg.c_ORA_OK
     and not exists(select 1
                      from PHONE_NUMBER pn
                     where pn.salability_category_code = p_salability_category
                       and pn.International_Format = t.International_Format);

  --check main number have no linked SIM-card
  update tt_batch_na_ap t
     set t.result = rsig_utils.c_SIM_HAVE_PHONE_NUMBER
   where t.result = util_pkg.c_ORA_OK
     and exists(select 1
                  from network_address_access_point naap
                 where naap.network_address_id = t.network_address_id
                   and v_sysdate between naap.from_date and nvl(naap.to_date,v_sysdate));

  update tt_batch_na_ap t
     set t.sn =
         (select pl.linked_msisdn
            from phone_link pl
           where pl.main_msisdn = t.international_format)
   where t.result = util_pkg.c_ORA_OK;
  ------------------------------
  if p_linked_network_operator_code is not null
  then
    --processing linked phones
    update tt_batch_na_ap t
       set t.result = rsig_utils.c_PHONE_HAVE_NO_LINKED
     where t.result = util_pkg.c_ORA_OK
       and t.sn is NULL;

    update tt_batch_na_ap t
       set t.result = rsig_utils.c_SIM_INVALID_NET_OPER
     where t.result = util_pkg.c_ORA_OK
       and not exists
           (select 1
              from PHONE_NUMBER pnl
              join PHONE_SERIES_OPERATOR  psol
                on psol.phone_number_series_id = pnl.phone_number_series_id
             where psol.network_operator_id = v_linked_network_operator_id
               and pnl.international_format = t.sn
               and v_sysdate between psol.start_date and NVL(psol.end_date,v_sysdate));

    --check linked number status
    update tt_batch_na_ap t
       set t.result = rsig_utils.c_BAD_PHONE_STATUS
     where t.result = util_pkg.c_ORA_OK
       and not exists(select 1
                        from PHONE_NUMBER pn
                       where pn.net_address_status_code = p_phone_status_code
                         and pn.International_Format = t.sn);

    --check linked number salability category
    update tt_batch_na_ap t
       set t.result = rsig_utils.c_PHONE_INVALID_SAL_CAT
     where t.result = util_pkg.c_ORA_OK
       and not exists(select 1
                        from PHONE_NUMBER pn
                       where pn.salability_category_code = p_salability_category
                         and pn.International_Format = t.sn);

    --check linked number have no linked SIM-card
    update tt_batch_na_ap t
       set t.result = rsig_utils.c_SIM_HAVE_PHONE_NUMBER
     where t.result = util_pkg.c_ORA_OK
       and exists(select 1
                    from phone_number pn
                    left join network_address_access_point naap
                      on naap.network_address_id = pn.network_address_id
                   where pn.international_format = t.sn
                     and v_sysdate between naap.from_date and nvl(naap.to_date,v_sysdate));

    --check if phone number have required type
    update tt_batch_na_ap t
       set t.result = rsig_utils.c_ORA_NOT_SAME_PHONE_TYPES
     where t.result = util_pkg.c_ORA_OK
       and not exists(select 1
                        from PHONE_NUMBER pn
                        join PHONE_NUMBER_SERIES pns
                          on pns.phone_number_series_id = pn.phone_number_series_id
                       where pns.phone_number_type_code = p_phone_type_code
                         and pn.International_Format = t.sn);
  ELSE
  --processing not linked phones
    update tt_batch_na_ap t
       set t.result = rsig_utils.c_ORA_NOT_SAME_PHONE_TYPES
     where t.result = util_pkg.c_ORA_OK
       and not exists(select 1
                        from PHONE_NUMBER pn
                        join PHONE_NUMBER_SERIES pns
                          on pns.phone_number_series_id = pn.phone_number_series_id
                         where pns.phone_number_type_code = p_phone_type_code
                           and pn.International_Format = t.international_format);

    update tt_batch_na_ap t
       set t.result = rsig_utils.c_PHONES_ALREADY_LINKED
     where t.result = util_pkg.c_ORA_OK
       and t.sn is not NULL;
  end if;
  ------------------------------
  delete from tt_processed_phones_sims;
  delete from tt_rejected_phones_sims;

  INSERT into tt_processed_phones_sims(MAIN_MSISDN,LINKED_MSISDN)
  select t.International_Format, t.sn
    from tt_batch_na_ap t
   where t.result = util_pkg.c_ORA_OK
     and rownum <= p_RequestedCnt;

  IF SQL%ROWCOUNT < p_RequestedCnt
  then
  --requested amount of phones found
    INSERT into tt_rejected_phones_sims(MAIN_MSISDN,LINKED_MSISDN,RESULT)
    select t.International_Format, t.sn, t.result
      from tt_batch_na_ap t
     where t.result <> util_pkg.c_ORA_OK;
  end if;

  select t.main_msisdn
    BULK COLLECT into v_msisdn_m
    from tt_processed_phones_sims t;

  if util_pkg.get_count_ct_varchar_s(v_msisdn_m) > 0
  then
    ------------------------------
    api_ri_pkg.Set_Phone_Status_i
    (
      p_msisdn => v_msisdn_m,
      p_set_phone_status => rsig_utils.c_RESERVE_PHONE_NUMBER_CODE,
      p_date => v_sysdate,
      p_user_id => v_user_id,
      p_break_on_error => false,
      p_lock_pn => true,
      p_error_code => v_error_code,
      p_error_message => v_error_message
    );
    ------------------------------
    select /*+ use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
        q1.msisdn, q2.error_code
      bulk collect into v_msisdns, v_error_codes
      from
        (select column_value msisdn, rownum rn from table(cast(v_msisdn_m as ct_varchar_s))) q1,
        (select column_value error_code, rownum rn from table(cast(v_error_code as ct_number))) q2,
        (select column_value error_message, rownum rn from table(cast(v_error_message as ct_varchar))) q3
      where 1 = 1
      and q2.rn = q1.rn
      and q3.rn = q1.rn
      and q2.error_code <> util_pkg.c_ORA_OK
      order by q1.rn
    ;
    ------------------------------
    delete tt_processed_phones_sims t
    where t.main_msisdn in(
      select column_value
      from table(cast(v_msisdns as ct_varchar_s))
    );
    ------------------------------
    insert into tt_rejected_phones_sims(main_msisdn, linked_msisdn, result)
      select /*+ use_hash(q1 q2) full(q1) full(q2) */
          q1.msisdn, null, q2.error_code
        from
          (select column_value msisdn, rownum rn from table(cast(v_msisdns as ct_varchar_s))) q1,
          (select column_value error_code, rownum rn from table(cast(v_error_codes as ct_number))) q2
        order by q1.rn
    ;
    ------------------------------
  end if;
  ------------------------------
  install_pkg.close_cursor(c_lock_phones);
  ------------------------------
  OPEN p_result_list FOR
    select t.main_msisdn,
           t.linked_msisdn
      from tt_processed_phones_sims t;
  ------------------------------
  OPEN p_rejected_list FOR
    select t.main_msisdn,
           t.linked_msisdn,
           t.result
      from tt_rejected_phones_sims t;
  ------------------------------
end;

------------------------------!------------------------------
procedure PROD_GetLinkedPhonesAll_i
(
  p_host_id host.host_id%type,
  p_network_operator_code network_operator.network_operator_code%type,
  p_linked_network_operator_code network_operator.network_operator_code%type,
  p_phone_type phone_number_series.phone_number_type_code%type,
  p_salability_category phone_number.salability_category_code%type,
  p_mask varchar2,
  p_phone_number_status_code phone_number.net_address_status_code%type,
  p_set_phone_number_status_code phone_number.net_address_status_code%type,
  p_phone_number_count number,
  p_user_login varchar2,
  p_result_list out sys_refcursor
)
is
  v_date date := sysdate;
  v_m_na_id ct_number;
  v_l_na_id ct_number;
  v_msisdn_m ct_varchar_s;
  v_msisdn_l ct_varchar_s;
begin
  ------------------------------
  util_pkg.xcheck_cond_missing(p_host_id is null, 'p_host_id');
  util_pkg.xcheck_cond_missing(p_network_operator_code is null, 'p_network_operator_code');
  util_pkg.xcheck_cond_missing(p_linked_network_operator_code is null, 'p_linked_network_operator_code');
  util_pkg.xcheck_cond_missing(p_salability_category is null, 'p_salability_category');
  util_pkg.xcheck_cond_missing(p_phone_type is null, 'p_phone_type');
  util_pkg.xcheck_cond_missing(p_phone_number_status_code is null, 'p_phone_number_status_code');
  util_pkg.xcheck_cond_missing(p_phone_number_count is null, 'p_phone_number_count');
  util_pkg.xcheck_cond_missing(p_user_login is null, 'p_user_login');
  ------------------------------
  --!_! delete from tt_batch_na_ap;
  delete from tt_processed_phones_sims;
  delete from tt_rejected_phones_sims;
  ------------------------------
  search_pkg.PROD_GetLinkedPhonesAll_i
  (
    p_host_id => p_host_id,
    p_network_operator_code => p_network_operator_code,
    p_linked_network_operator_code => p_linked_network_operator_code,
    p_phone_type => p_phone_type,
    p_salability_category => p_salability_category,
    p_mask => p_mask,
    p_phone_number_status_code => p_phone_number_status_code,
    p_set_phone_number_status_code => p_set_phone_number_status_code,
    p_phone_number_count => p_phone_number_count,
    p_user_login => p_user_login,
    p_m_na_id => v_m_na_id,
    p_l_na_id => v_l_na_id
  );
  ------------------------------
  v_msisdn_m := util_ri.get_msisdn(v_m_na_id, v_date, FALSE);
  v_msisdn_l := util_ri.get_msisdn(v_l_na_id, v_date, FALSE);
  ------------------------------
  insert into tt_processed_phones_sims(main_msisdn, linked_msisdn)
  select /*+ ordered use_hash(q1, q2)*/
    q1.msisdn,
    q2.msisdn
    from
      (select column_value msisdn, rownum rn from table(cast(v_msisdn_m as ct_varchar_s))) q1,
      (select column_value msisdn, rownum rn from table(cast(v_msisdn_l as ct_varchar_s))) q2
    where 1 = 1
    and q2.rn = q1.rn
    order by q1.msisdn, q2.msisdn
  ;
  ------------------------------
  open p_result_list for
    select
      t.main_msisdn,
      t.linked_msisdn
    from tt_processed_phones_sims t
    order by t.main_msisdn, t.linked_msisdn
  ;
  ------------------------------
end;

------------------------------!------------------------------
procedure PROD_GetNotLinkedPhones_2_i
(
  p_host_id host.host_id%type,
  p_network_operator_code network_operator.network_operator_code%type,
  p_phone_type phone_number_series.phone_number_type_code%type,
  p_salability_category phone_number.salability_category_code%type,
  p_mask varchar2,
  p_phone_number_status_code phone_number.net_address_status_code%type,
  p_set_phone_number_status_code phone_number.net_address_status_code%type,
  p_phone_number_count number,
  p_user_login varchar2,
  p_result_list out sys_refcursor
)
is
  v_date date;
  --
  v_host_id util_pkg.cit_varchar_s;
  v_sal_cat util_pkg.cit_varchar_s;
  v_phone_status util_pkg.cit_varchar_s;
  --
  v_m_na_id ct_number;
  --
begin
  ------------------------------
  util_pkg.xcheck_cond_missing(p_network_operator_code is null, 'p_network_operator_code');
  util_pkg.xcheck_cond_missing(p_phone_type is null, 'p_phone_type');
  util_pkg.xcheck_cond_missing(p_salability_category is null, 'p_salability_category');
  util_pkg.xcheck_cond_missing(p_phone_number_status_code is null, 'p_phone_number_status_code');
  util_pkg.xcheck_cond_missing(p_phone_number_count is null, 'p_phone_number_count');
  util_pkg.xcheck_cond_missing(p_user_login is null, 'p_user_login');
  ------------------------------
  delete from tt_processed_phones_sims;
  delete from tt_rejected_phones_sims;
  ------------------------------
  v_host_id(1) := p_host_id;
  v_sal_cat(1) := p_salability_category;
  v_phone_status(1) := p_phone_number_status_code;
  ------------------------------
  search_pkg.GetPhonesByStatus2_i
  (
    p_host_id => v_host_id,
    p_network_operator_code => p_network_operator_code,
    p_phone_type => p_phone_type,
    p_salability_category => v_sal_cat,
    p_series_id => NULL,
    p_mask => p_mask,
    p_use_linked => etc_pkg.c_USE_LINKED_NO,
    p_phone_number_status_code => v_phone_status,
    p_set_phone_number_status_code => p_set_phone_number_status_code,
    p_startingrow => 1,
    p_phone_number_count => p_phone_number_count,
    p_user_login => p_user_login,
    p_m_na_id => v_m_na_id
  );
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  insert into tt_processed_phones_sims
  (
    main_msisdn,
    linked_msisdn,
    iccid
  )
  select /*+ ordered use_nl(pn) index_asc(pn, PK_PHONE_NUMBER) */
    pn.international_format main_msisdn,
    null linked_msisdn,
    null iccid
  from
    (select column_value network_address_id, rownum rn from table(cast(v_m_na_id as ct_number))) q1,
    phone_number pn
  where 1 = 1
  and pn.network_address_id(+) = q1.network_address_id
  and nvl(pn.deleted(+), v_date + util_ri.c_DUMMY_DATE_SHIFT) > v_date
  order by q1.rn
  ;
  ------------------------------
  open p_result_list for
    select main_msisdn, linked_msisdn
    from tt_processed_phones_sims;
  ------------------------------
end;

------------------------------!------------------------------
------------------------------!------------------------------
end;
/
