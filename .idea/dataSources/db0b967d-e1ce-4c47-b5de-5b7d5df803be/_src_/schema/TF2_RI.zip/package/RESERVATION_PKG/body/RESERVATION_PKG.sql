CREATE package body RESERVATION_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure add_results_for_ids
(
    p_ids ct_number,
    p_error_code number,
    p_error_message varchar2,
    p_error_ids in out nocopy ct_number,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
)
is
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.resize_ct_number(v_error_codes, util_pkg.get_count_ct_number(p_ids));
  util_pkg.resize_ct_varchar(v_error_messages, util_pkg.get_count_ct_number(p_ids));
  util_pkg.fill_ct_number(v_error_codes, p_error_code);
  util_pkg.fill_ct_varchar(v_error_messages, p_error_message);
  ------------------------------
  util_pkg.add_ct_number(p_error_ids, p_ids);
  util_pkg.add_ct_number(p_error_codes, v_error_codes);
  util_pkg.add_ct_varchar(p_error_messages, v_error_messages);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function reserve_na_on_period_i
(
    p_na_id ct_number,
    p_date_reserved date,
    p_user_id number,
    p_reserve_number out number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_date date := sysdate;
  v_res_set_na_status boolean;
  --
  v_na_id ct_number;
  v_na_id_m ct_number;
  v_na_id_l ct_number;
begin
  ------------------------------
  v_na_id_m := util_ri.get_as_pnlnk_naid_m_fuzzy(p_na_id, v_date);
  v_na_id_l := util_ri.get_as_pnlnk_naid_l_fuzzy(p_na_id, v_date);
  ------------------------------
  v_res_set_na_status := util_ext_ri.set_na_status2
  (
    p_na_id => v_na_id_m,
    p_status => util_ri.c_NASH_CODE_RESERVE,
    p_date => v_date,
    p_user_id => p_user_id,
    p_break_on_error => TRUE,
    p_lock_pn => true,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if v_res_set_na_status
  then
    ------------------------------
    p_reserve_number := batch_pkg.c_BATCH_ID_DUMMY;
    ------------------------------
    if util_pkg.CheckP_ct_number(v_na_id_m)
    then
      ------------------------------
      v_na_id := v_na_id_m;
      util_pkg.add_ct_number(v_na_id, v_na_id_l);
      ------------------------------
      p_reserve_number := batch_pkg.batch_ins(batch_pkg.c_BATCH_TYPE_NA_MNG, v_date, p_date_reserved, p_user_id);
      batch_pkg.na_res_batch_add_to(p_reserve_number, v_na_id, p_user_id);
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    return false;
    ------------------------------
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function reserve_msisdns_on_period_i
(
    p_msisdns ct_varchar_s,
    p_date_reserved date,
    p_user_id number,
    p_reserve_number out number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_date date := sysdate;
  v_na_id ct_number;
begin
  ------------------------------
  v_na_id := util_ri.get_na_id(p_msisdns, v_date, false);
  ------------------------------
  util_pkg.xis_nulls_ct_number(v_na_id);
  ------------------------------
  return reserve_na_on_period_i(v_na_id, p_date_reserved, p_user_id, p_reserve_number, p_error_code, p_error_message);
  ------------------------------
end;
  
----------------------------------!---------------------------------------------
function change_reserve_period_i
(
    p_reserve_number_list ct_number,
    p_date_reserved date,
    p_user_id number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean;
  v_batches batch_pkg.t_batch;
begin
  ------------------------------
  v_res := batch_pkg.get_nbatches(p_reserve_number_list, true, v_batches, p_error_code, p_error_message);
  ------------------------------
  for v_i in v_batches.first..v_batches.last
  loop
    ------------------------------
    if 1 = 1
      and p_error_code(v_i) = util_pkg.c_ora_ok
      and v_batches(v_i).batch_id is not null
    then
      ------------------------------
      batch_pkg.na_res_batch_upd_date_to(v_batches(v_i).batch_id, p_date_reserved, p_user_id);
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;
  
----------------------------------!---------------------------------------------
function check_reserves_i
(
    p_reserve_number_list ct_number,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
) return boolean
is
  v_res boolean;
  v_date date :=  sysdate;
  v_batches batch_pkg.t_batch;
begin
  ------------------------------
  v_res := batch_pkg.get_nbatches(p_reserve_number_list, false, v_batches, p_error_codes, p_error_messages);
  ------------------------------
  for v_i in v_batches.first..v_batches.last
  loop
    ------------------------------
    if 1 = 1
      and p_error_codes(v_i) = util_pkg.c_ora_ok
      and v_batches(v_i).batch_id is not null
      and v_batches(v_i).end_date < v_date
    then
      ------------------------------
      v_res := false;
      p_error_codes(v_i) := util_pkg.c_ora_expired;
      p_error_messages(v_i) := util_pkg.c_msg_expired;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_by_msisdn
(
    p_ids ct_number,
    p_msisdns ct_varchar_s,
    p_date date,
    p_error_record_id in out nocopy ct_number,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
) return ct_number
is
  v_res ct_number;
  v_mark ct_number;
  v_error_rec_id ct_number;
begin
  ------------------------------
  v_res := util_ri.get_na_id(p_msisdns, p_date, false);
  ------------------------------
  v_mark := util_pkg.mark_val_ct_number(v_res, null, util_pkg.c_true, util_pkg.c_false);
  ------------------------------
  v_error_rec_id := util_pkg.filter_ct_number_1val(p_ids, v_mark, util_pkg.c_true, true);
  ------------------------------
  add_results_for_ids
  (
    v_error_rec_id,
    util_loc_pkg.c_ora_phone_not_found,
    util_loc_pkg.c_msg_phone_not_found,
    p_error_record_id,
    p_error_codes,
    p_error_messages
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ap_by_iccid_and_imsi
(
    p_ids ct_number,
    p_iccids ct_varchar_s,
    p_imsis ct_varchar_s,
    p_date date,
    p_error_record_id in out nocopy ct_number,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
) return ct_number
is
  v_res ct_number;
  v_ids ct_number;
  v_ap_id01 ct_number;
  v_ap_id02 ct_number;
  v_mark01 ct_number;
  v_mark02 ct_number;
  v_mark ct_number;
  v_ap_id01_01 ct_number;
  v_ap_id02_01 ct_number;
  v_cmp_res ct_number;
  v_error_rec_id ct_number;
begin
  ------------------------------
  v_ap_id01 := util_ri.get_ap_id(p_iccids, p_date, false);
  v_ap_id02 := util_ri.get_ap_id3(p_imsis, p_date, false);
  ------------------------------
  v_res := util_pkg.supplement_ct_number(v_ap_id01, v_ap_id02, false, null);
  ------------------------------
  v_mark01 := util_pkg.mark_val_ct_number(v_ap_id01, null, util_pkg.c_true, util_pkg.c_false);
  v_mark02 := util_pkg.mark_val_ct_number(v_ap_id02, null, util_pkg.c_true, util_pkg.c_false);
  ------------------------------
  v_mark := util_pkg.supplement_ct_number(v_mark01, v_mark02, false, util_pkg.c_true);
  ------------------------------
  v_error_rec_id := util_pkg.filter_ct_number_1val(p_ids, v_mark, util_pkg.c_false, false);
  ------------------------------
  add_results_for_ids
  (
    v_error_rec_id,
    util_loc_pkg.c_ora_sim_card_not_found,
    util_loc_pkg.c_msg_sim_card_not_found,
    p_error_record_id,
    p_error_codes,
    p_error_messages
  );
  ------------------------------
  v_mark := util_pkg.supplement_ct_number(v_mark01, v_mark02, false, util_pkg.c_false);
  ------------------------------
  v_ids := util_pkg.filter_ct_number_1val(p_ids, v_mark, util_pkg.c_false, true);
  v_ap_id01_01 := util_pkg.filter_ct_number_1val(v_ap_id01, v_mark, util_pkg.c_false, true);
  v_ap_id02_01 := util_pkg.filter_ct_number_1val(v_ap_id02, v_mark, util_pkg.c_false, true);
  ------------------------------
  v_cmp_res := util_pkg.cmp_ct_number(v_ap_id01_01, v_ap_id02_01, util_pkg.c_true, util_pkg.c_false);
  ------------------------------
  v_error_rec_id := util_pkg.filter_ct_number_1val(v_ids, v_cmp_res, util_pkg.c_true, false);
  ------------------------------
  add_results_for_ids
  (
    v_error_rec_id,
    util_loc_pkg.c_ora_imsi_not_corr_iccid,
    util_loc_pkg.c_msg_imsi_not_corr_iccid,
    p_error_record_id,
    p_error_codes,
    p_error_messages
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure check_ap_status
(
    p_ids ct_number,
    p_ap_ids ct_number,
    p_date date,
    p_statuses ct_varchar_s,
    p_error_record_id in out nocopy ct_number,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
)
is
  v_ap_status ct_varchar_s;
  v_cmp_res ct_number;
  v_error_rec_id ct_number;
begin
  ------------------------------
  v_ap_status := util_ri.get_ap_status(p_ap_ids, p_date, false);
  ------------------------------
  v_cmp_res := util_pkg.mark_ct_varchar_s(v_ap_status, p_statuses, util_pkg.c_true, util_pkg.c_false);
  ------------------------------
  v_error_rec_id := util_pkg.filter_ct_number_1val(p_ids, v_cmp_res, util_pkg.c_true, false);
  ------------------------------
  add_results_for_ids
  (
    v_error_rec_id,
    util_loc_pkg.c_ora_wrong_ap_status,
    util_loc_pkg.c_msg_wrong_ap_status,
    p_error_record_id,
    p_error_codes,
    p_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure check_na_status
(
    p_ids ct_number,
    p_na_ids ct_number,
    p_date date,
    p_statuses ct_varchar_s,
    p_error_record_id in out nocopy ct_number,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
)
is
  v_na_status ct_varchar_s;
  v_cmp_res ct_number;
  v_error_rec_id ct_number;
begin
  ------------------------------
  v_na_status := util_ri.get_na_status(p_na_ids, p_date, false);
  ------------------------------
  v_cmp_res := util_pkg.mark_ct_varchar_s(v_na_status, p_statuses, util_pkg.c_true, util_pkg.c_false);
  ------------------------------
  v_error_rec_id := util_pkg.filter_ct_number_1val(p_ids, v_cmp_res, util_pkg.c_true, false);
  ------------------------------
  add_results_for_ids
  (
    v_error_rec_id,
    util_loc_pkg.c_ora_wrong_na_status,
    util_loc_pkg.c_msg_wrong_na_status,
    p_error_record_id,
    p_error_codes,
    p_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure compare_na_ap_hosts
(
    p_ids ct_number,
    p_na_ids ct_number,
    p_ap_ids ct_number,
    p_error_record_id in out nocopy ct_number,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
)
is
  v_date date := sysdate;
  v_na_host_id ct_number;
  v_ap_host_id ct_number;
  v_cmp_res ct_number;
  v_error_rec_id ct_number;
begin
  ------------------------------
  v_na_host_id := util_ri.get_na_host_id(p_na_ids, v_date, false);
  v_ap_host_id := util_ri.get_ap_host_id(p_ap_ids, v_date, false);
  ------------------------------
  v_cmp_res := util_pkg.cmp_ct_number(v_na_host_id, v_ap_host_id, util_pkg.c_true, util_pkg.c_false);
  ------------------------------
  v_error_rec_id := util_pkg.filter_ct_number_1val(p_ids, v_cmp_res, util_pkg.c_true, false);
  ------------------------------
  add_results_for_ids
  (
    v_error_rec_id,
    util_loc_pkg.c_ora_not_same_host_na_and_ap,
    util_loc_pkg.c_msg_not_same_host_na_and_ap,
    p_error_record_id,
    p_error_codes,
    p_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure check_ap_host_belong_no
(
    p_ids ct_number,
    p_no_codes ct_varchar_s,
    p_ap_ids ct_number,
    p_date date,
    p_error_record_id in out nocopy ct_number,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
)
is
  v_date date := sysdate;
  v_no_id ct_number;
  v_host_no_id ct_number;
  v_ap_host_id ct_number;
  v_cmp_res ct_number;
  v_error_rec_id ct_number;
begin
  ------------------------------
  v_ap_host_id := util_ri.get_ap_host_id(p_ap_ids, v_date, false);
  ------------------------------
  v_no_id := util_ri.get_network_operator_id(p_no_codes, p_date, false);
  ------------------------------
  v_host_no_id := util_ri.get_host_network_operator(v_ap_host_id, p_date, false);
  ------------------------------
  v_cmp_res := util_ri.no_is_parent_no(v_host_no_id, v_no_id, p_date, true, util_pkg.c_true, util_pkg.c_false);
  ------------------------------
  v_error_rec_id := util_pkg.filter_ct_number_1val(p_ids, v_cmp_res, util_pkg.c_true, false);
  ------------------------------
  add_results_for_ids
  (
    v_error_rec_id,
    util_loc_pkg.c_ora_not_same_no,
    util_loc_pkg.c_msg_not_same_no,
    p_error_record_id,
    p_error_codes,
    p_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_na_ap_links
(
    p_ids ct_number,
    p_na_id ct_number,
    p_date date,
    p_error_record_id in out nocopy ct_number,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
) return ct_number
is
  v_res ct_number;
  v_cmp_res ct_number;
  v_error_rec_id ct_number;
begin
  ------------------------------
  v_res := util_ri.get_linked_ap_id(p_na_id, null, p_date, false);
  ------------------------------
  v_cmp_res := util_pkg.mark_val_ct_number(v_res, null, util_pkg.c_true, util_pkg.c_false);
  ------------------------------
  v_error_rec_id := util_pkg.filter_ct_number_1val(p_ids, v_cmp_res, util_pkg.c_true, true);
  ------------------------------
  add_results_for_ids
  (
    v_error_rec_id,
    util_loc_pkg.c_ora_na_not_linked,
    util_loc_pkg.c_msg_na_not_linked,
    p_error_record_id,
    p_error_codes,
    p_error_messages
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure compare_linked_ap
(
    p_ids ct_number,
    p_linked_ap_id ct_number,
    p_ap_ids ct_number,
    p_error_record_id in out nocopy ct_number,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
)
is
  v_linked_id ct_number;
  v_linked_ap_id ct_number;
  v_linked_testing_ap_id ct_number;
  v_cmp_res ct_number;
  v_error_rec_id ct_number;
begin
  ------------------------------
  v_cmp_res := util_pkg.mark_val_ct_number(p_linked_ap_id, null, util_pkg.c_true, util_pkg.c_false);
  ------------------------------
  v_linked_id := util_pkg.filter_ct_number_1val(p_ids, v_cmp_res, util_pkg.c_true, false);
  v_linked_ap_id := util_pkg.filter_ct_number_1val(p_linked_ap_id, v_cmp_res, util_pkg.c_true, false);
  v_linked_testing_ap_id := util_pkg.filter_ct_number_1val(p_ap_ids, v_cmp_res, util_pkg.c_true, false);
  ------------------------------
  v_cmp_res := util_pkg.cmp_ct_number(v_linked_ap_id, v_linked_testing_ap_id, util_pkg.c_true, util_pkg.c_false);
  ------------------------------
  v_error_rec_id := util_pkg.filter_ct_number_1val(v_linked_id, v_cmp_res, util_pkg.c_true, false);
  ------------------------------
  add_results_for_ids
  (
    v_error_rec_id,
    util_loc_pkg.c_ora_na_linked_to_other_ap,
    util_loc_pkg.c_msg_na_linked_to_other_ap,
    p_error_record_id,
    p_error_codes,
    p_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure check_sim_card_and_phone_i
(
    p_phone_sim_data t_phones_sims_container,
    p_check_option t_check_setting,
    p_is_linked_to_sim_card out ct_number,
    p_error_record_id out ct_number,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_date date := sysdate;
  --
  v_na_statuses ct_varchar_s;
  v_na_id ct_number;
  v_linked_ap_id ct_number;
  --
  v_ap_id ct_number;
  v_ap_statuses ct_varchar_s;
  --
  v_error_record_id ct_number;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  v_na_id := get_na_by_msisdn(p_phone_sim_data.rec_ids, p_phone_sim_data.msisdn, v_date, p_error_record_id, p_error_codes, p_error_messages);
  ------------------------------
  v_ap_id := get_ap_by_iccid_and_imsi(p_phone_sim_data.rec_ids, p_phone_sim_data.iccids, p_phone_sim_data.imsis, v_date, p_error_record_id, p_error_codes, p_error_messages);
  ------------------------------
  if p_check_option.check_sim_card_not_active
  then
    ------------------------------
    v_ap_statuses := ct_varchar_s();
    util_pkg.add_ct_varchar_s_val(v_ap_statuses, util_ri.c_APSH_CODE_NOT_ACTIVATED);
    ------------------------------
    check_ap_status(p_phone_sim_data.rec_ids, v_ap_id, v_date, v_ap_statuses, p_error_record_id, p_error_codes, p_error_messages);
    ------------------------------
  end if;
  ------------------------------
  if p_check_option.check_phone_free_or_int
  then
    ------------------------------
    v_na_statuses := ct_varchar_s();
    util_pkg.add_ct_varchar_s_val(v_na_statuses, util_ri.c_NASH_CODE_FREE);
    util_pkg.add_ct_varchar_s_val(v_na_statuses, util_ri.c_NASH_CODE_INTERNAL);
    ------------------------------
    check_na_status(p_phone_sim_data.rec_ids, v_na_id, v_date, v_na_statuses, p_error_record_id, p_error_codes, p_error_messages);
    ------------------------------
  end if;
  ------------------------------
  if p_check_option.check_sim_phone_host
  then
    ------------------------------
    compare_na_ap_hosts(p_phone_sim_data.rec_ids, v_na_id, v_ap_id, p_error_record_id, p_error_codes, p_error_messages);
    ------------------------------
  end if;
  ------------------------------
  if p_check_option.check_sim_host_belong_no
  then
    ------------------------------
    check_ap_host_belong_no(p_phone_sim_data.rec_ids, p_phone_sim_data.network_operator_codes, v_ap_id, v_date, p_error_record_id, p_error_codes, p_error_messages);
    ------------------------------
  end if;
  ------------------------------
  v_linked_ap_id := get_na_ap_links(p_phone_sim_data.rec_ids, v_na_id, v_date, v_error_record_id, v_error_codes, v_error_messages);
  ------------------------------
  p_is_linked_to_sim_card := util_pkg.mark_val_ct_number(v_linked_ap_id, null, util_pkg.c_false, util_pkg.c_true);
  ------------------------------
  if p_check_option.check_phone_sim_link
  then
    ------------------------------
    util_pkg.add_ct_number(p_error_record_id, v_error_record_id);
    util_pkg.add_ct_number(p_error_codes, v_error_codes);
    util_pkg.add_ct_varchar(p_error_messages, v_error_messages);
    ------------------------------
    compare_linked_ap(p_phone_sim_data.rec_ids, v_linked_ap_id, v_ap_id, p_error_record_id, p_error_codes, p_error_messages);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_reserved_msisdn_on_period
(
    p_msisdns util_pkg.cit_varchar_s,
    p_date_reserved date,
    p_user_login varchar2,
    p_commit number,
    p_reserve_number out number,
    p_result_list out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_user_id number;
  v_msisdns ct_varchar_s;
  v_res_reserve_phones boolean;
  v_error_codes ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheckP_cit_varchar_s(p_msisdns, 'p_msisdns');
  util_pkg.XCheck_Cond_Missing(p_date_reserved is null, 'p_date_reserved');
  util_pkg.XCheck_Cond_Missing(p_user_login is null, 'p_user_login');
  util_pkg.XCheck_Cond_Invalid(p_commit is null, 'p_commit is null');
  ------------------------------
  v_msisdns := util_pkg.cast_cit2ct_varchar_s(p_msisdns, true);
  ------------------------------
  v_user_id := install_pkg.get_user_id(p_user_login);
  ------------------------------
  v_res_reserve_phones := reserve_msisdns_on_period_i(v_msisdns, p_date_reserved, v_user_id, p_reserve_number, v_error_codes, v_error_message);
  ------------------------------
  get_result_cursor01(v_msisdns, v_error_codes, v_error_message, p_result_list);
  ------------------------------
  if not v_res_reserve_phones
  then
    util_pkg.raise_exception(util_pkg.c_ora_x_common, util_pkg.c_msg_x_common);
  end if;
  ------------------------------
  if p_commit = util_pkg.c_true
  then
    commit;
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if p_commit = util_pkg.c_true
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure change_reserve_period
(
    p_reserve_number_list util_pkg.cit_number,
    p_date_reserved date,
    p_user_login varchar2,
    p_commit number,
    p_result_list out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_user_id number;
  v_date date := sysdate;
  v_reserve_number_list ct_number;
  v_res_change_reserve_period boolean;
  v_error_codes ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheckP_cit_number(p_reserve_number_list, 'p_reserve_number_list');
  util_pkg.XCheck_Cond_Missing(p_date_reserved is null, 'p_date_reserved');
  util_pkg.XCheck_Cond_Missing(p_user_login is null, 'p_user_login');
  util_pkg.XCheck_Cond_Invalid(p_date_reserved <= v_date, 'p_date_reserved');
  util_pkg.XCheck_Cond_Invalid(p_commit is null, 'p_commit is null');
  ------------------------------
  v_reserve_number_list := util_pkg.cast_cit2ct_number(p_reserve_number_list, false);
  ------------------------------
  v_user_id := util_ri.xget_user_id(p_user_login);
  ------------------------------
  util_pkg.xis_nulls_ct_number(v_reserve_number_list);
  ------------------------------
  v_res_change_reserve_period := change_reserve_period_i(v_reserve_number_list, p_date_reserved, v_user_id, v_error_codes, v_error_message);
  ------------------------------
  get_result_cursor02(v_reserve_number_list, v_error_codes, v_error_message, p_result_list);
  ------------------------------
  if not v_res_change_reserve_period
  then
    util_pkg.raise_exception(util_pkg.c_ora_x_common, util_pkg.c_msg_x_common);
  end if;
  ------------------------------
  if p_commit = util_pkg.c_true
  then
    commit;
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if p_commit = util_pkg.c_true
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure check_reserves
(
    p_reserve_number_list util_pkg.cit_number,
    p_result_list out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_reserve_number_list ct_number;
  v_res_check_reserves boolean;
  v_error_codes ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheckP_cit_number(p_reserve_number_list, 'p_reserve_number_list');
  ------------------------------
  v_reserve_number_list := util_pkg.cast_cit2ct_number(p_reserve_number_list, false);
  ------------------------------
  util_pkg.xis_nulls_ct_number(v_reserve_number_list);
  ------------------------------
  v_res_check_reserves := check_reserves_i(v_reserve_number_list, v_error_codes, v_error_message);
  ------------------------------
  get_result_cursor02(v_reserve_number_list, v_error_codes, v_error_message, p_result_list);
  ------------------------------
  if not v_res_check_reserves
  then
    util_pkg.raise_exception(util_pkg.c_ora_x_common, util_pkg.c_msg_x_common);
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure check_sim_card_and_phone
(
    p_rec_id util_pkg.cit_number,
    p_iccids util_pkg.cit_varchar_s,
    p_imsis util_pkg.cit_varchar_s,
    p_msisdns util_pkg.cit_varchar_s,
    p_network_operator_codes util_pkg.cit_varchar_s,
    p_check_sim_card_not_active number,
    p_check_phone_free_or_int number,
    p_check_sim_phone_host number,
    p_check_sim_host_belong_no number,
    p_check_phone_sim_link number,
    p_result_list out sys_refcursor,
    p_error_list out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_count number;
  v_phones_sims t_phones_sims_container;
  v_check_options t_check_setting;
  v_is_linked_to_sim_card ct_number;
  v_error_rec_id ct_number;
  v_error_codes ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheckP_cit_number(p_rec_id, 'p_rec_id');
  util_pkg.XCheckP_cit_varchar_s(p_msisdns, 'p_msisdns');
  util_pkg.XCheck_Cond_Missing(p_check_sim_card_not_active is null,'p_check_sim_card_not_active is null');
  util_pkg.XCheck_Cond_Missing(p_check_phone_free_or_int is null,'p_check_phone_free_or_int is null');
  util_pkg.XCheck_Cond_Missing(p_check_sim_phone_host is null,'p_check_sim_phone_host is null');
  util_pkg.XCheck_Cond_Missing(p_check_sim_host_belong_no is null,'p_check_sim_host_belong_no is null');
  util_pkg.XCheck_Cond_Missing(p_check_phone_sim_link is null,'p_check_phone_sim_link is null');
  ------------------------------
  v_phones_sims.rec_ids := util_pkg.cast_cit2ct_number(p_rec_id, true);
  v_phones_sims.iccids := util_pkg.cast_cit2ct_varchar_s(p_iccids, false);
  v_phones_sims.imsis := util_pkg.cast_cit2ct_varchar_s(p_imsis, false);
  v_phones_sims.msisdn := util_pkg.cast_cit2ct_varchar_s(p_msisdns, false);
  v_phones_sims.network_operator_codes := util_pkg.cast_cit2ct_varchar_s(p_network_operator_codes, false);
  ------------------------------
  v_count := util_pkg.get_count_ct_number(v_phones_sims.rec_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_phones_sims.msisdn)!=v_count,'v_phones_sims.msisdn.count!=v_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_phones_sims.iccids)!=v_count,'v_phones_sims.iccids.count!=v_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_phones_sims.imsis)!=v_count,'v_phones_sims.imsis.count!=v_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_phones_sims.network_operator_codes)!=v_count,'v_phones_sims.network_operator_codes.count!=v_count');
  ------------------------------
  v_check_options.check_sim_card_not_active := util_pkg.int_to_bool(p_check_sim_card_not_active);
  v_check_options.check_phone_free_or_int := util_pkg.int_to_bool(p_check_phone_free_or_int);
  v_check_options.check_sim_phone_host := util_pkg.int_to_bool(p_check_sim_phone_host);
  v_check_options.check_sim_host_belong_no := util_pkg.int_to_bool(p_check_sim_host_belong_no);
  v_check_options.check_phone_sim_link := util_pkg.int_to_bool(p_check_phone_sim_link);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(
    not v_check_options.check_sim_card_not_active and
    not v_check_options.check_phone_free_or_int and
    not v_check_options.check_sim_phone_host and
    not v_check_options.check_sim_host_belong_no and
    not v_check_options.check_phone_sim_link,
    'No check options is set');
  ------------------------------
  check_sim_card_and_phone_i(v_phones_sims, v_check_options, v_is_linked_to_sim_card, v_error_rec_id, v_error_codes, v_error_message);
  ------------------------------
  get_result_cursor03(v_phones_sims, v_is_linked_to_sim_card, p_result_list);
  ------------------------------
  get_result_cursor04(v_error_rec_id, v_error_codes, v_error_message, p_error_list);
  ------------------------------
  util_ri.aggregate_results02(v_error_codes, p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  get_result_cursor03(v_phones_sims, v_is_linked_to_sim_card, p_result_list);
  ------------------------------
  get_result_cursor04(v_error_rec_id, v_error_codes, v_error_message, p_error_list);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_result_cursor01(p_msisdns ct_varchar_s, p_error_code ct_number, p_error_message ct_varchar, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
       q1.msisdn,
       q2.error_code,
       q3.error_message
  from
    (select column_value msisdn, rownum rn from table(p_msisdns)) q1,
    (select column_value error_code, rownum rn from table(p_error_code)) q2,
    (select column_value error_message, rownum rn from table(p_error_message)) q3
  where 1 = 1
  and q2.rn(+) = q1.rn
  and q3.rn(+) = q1.rn
  and nvl(q2.error_code, util_pkg.c_ora_x_common) <> util_pkg.c_ora_ok
  order by q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_ph_st_and_reset_reserve_ii
(
    p_na_id ct_number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_res boolean;
  v_tmp_batch_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_id) != v_main_count, 'p_na_id.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_codes, p_error_messages);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    begin
      ------------------------------
      v_sp_name := util_sys_pkg.make_savepoint;
      ------------------------------
      v_res := util_ext_ri.set_na_status3
      (
        p_na_id => p_na_id(v_i),
        p_status => p_status,
        p_date => p_date,
        p_user_id => p_user_id,
        p_lock_pn => TRUE,
        p_error_code => p_error_codes(v_i),
        p_error_message => p_error_messages(v_i)
      );
      ------------------------------
      if NOT v_res
      then
        ------------------------------
        util_pkg.raise_exception(p_error_codes(v_i), p_error_messages(v_i));
        ------------------------------
      end if;
      ------------------------------
      v_tmp_batch_ids := batch_pkg.get_na_res_batches_by_na2(p_na_id(v_i));
      ------------------------------
      batch_pkg.na_res_batch_remove_from2(p_na_id(v_i), p_user_id);
      ------------------------------
      if util_pkg.get_count_ct_number(v_tmp_batch_ids) > 0
      then
        ------------------------------
        batch_pkg.na_res_batches_del_smart(v_tmp_batch_ids, p_user_id);
        ------------------------------
      end if;
      ------------------------------
      util_pkg.set_ok(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
    exception
    when others then
      ------------------------------
      util_sys_pkg.rollback_savepoint(v_sp_name);
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        exit;
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_ph_st_and_reset_reserve_i
(
    p_msisdns ct_varchar_s,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
)
is
  v_main_count number;
  v_na_ids ct_number;
  v_na_status ct_varchar_s;
  --
  v_pivot ct_number;
  v_mark_err ct_number;
  v_tmp_na_id ct_number;
  v_tmp_map ct_number;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_codes, p_error_messages);
  ------------------------------
  v_na_ids := util_ri.get_na_id(p_msisdns, p_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_na_ids, null, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found, util_pkg.c_true, p_error_codes, p_error_messages);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_na_status := util_ri.get_na_status(v_na_ids, p_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_varchar_s(v_na_status, util_ri.c_NASH_CODE_RESERVE, util_pkg.c_false, util_pkg.c_true);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_wrong_na_status, util_loc_pkg.c_msg_wrong_na_status, util_pkg.c_true, p_error_codes, p_error_messages);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_tmp_na_id := util_pkg.get_by_pos_ct_number(v_na_ids, v_pivot, TRUE, NULL);
  v_tmp_map := util_pkg.get_by_pos_ct_number(v_pivot, v_pivot, TRUE, NULL);
  ------------------------------
  if util_pkg.get_count_ct_number(v_tmp_na_id) > 0
  then
    ------------------------------
    set_ph_st_and_reset_reserve_ii
    (
      p_na_id => v_tmp_na_id,
      p_status => p_status,
      p_date => p_date,
      p_user_id => p_user_id,
      p_break_on_error => p_break_on_error,
      p_error_codes => v_error_codes,
      p_error_messages => v_error_messages
    );
    --------------------------------
    util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes, v_tmp_map);
    util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages, v_tmp_map);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_ph_st_and_reset_reserve
(
    p_msisdns ct_varchar_s,
    p_status varchar2,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_date date := sysdate;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  ------------------------------
  set_ph_st_and_reset_reserve_i
  (
    p_msisdns => p_msisdns,
    p_status => p_status,
    p_date => v_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure reserve_phones4period
(
  p_na_id_ml ct_number,
  p_reserve_period_minutes number,
  p_user_id number,
  p_reserve_number out number
)
is
  lc_this_name constant varchar2(30) := 'NETWORK_ADDRESS';
  v_sp_name varchar2(30);
  v_date date;
  v_reserve_date date;
  v_marks ct_number;
  v_errors_str ct_varchar_s;
  v_errors_num ct_number;
  v_pos number;
  v_na_id_m ct_number;
  v_na_id_l ct_number; --!_!short
  v_na_id ct_number;
  v_na_status_m ct_varchar_s;
  v_na_status_l ct_varchar_s;
  v_statuses_allowed ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_na_id_ml);
  util_pkg.XCheck_Cond_Missing(p_reserve_period_minutes is null, 'p_reserve_period_minutes');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  ------------------------------
  v_date := sysdate;
  --!_!util_ri.prepare_as_pnlnk_exact(p_na_id_ml, v_date, v_na_id_m, v_na_id_l, v_msisdn_m, v_msisdn_l);
  util_ri.prepare_as_pnlnk2_fuzzy_fuzzy(p_na_id_ml, v_date, v_na_id_m, v_na_id_l);
  ------------------------------
  --!_!v_na_id_m is unique and SHORT: p_na_id_ml.count >= v_na_id_m.count
  --!_!v_na_id_l is unique and MORE SHORT: v_na_id_m.count >= v_na_id_l.count
  ------------------------------
  ------------------------------
  --!!!LOCK
  v_date := sysdate;
  v_na_status_m := util_ri.get_na_status_current1(v_na_id_m, v_date, FALSE);
  ------------------------------
  v_statuses_allowed := null;
  util_pkg.add_ct_varchar_s_val(v_statuses_allowed, util_ri.c_NASH_CODE_FREE);
  util_pkg.add_ct_varchar_s_val(v_statuses_allowed, util_ri.c_NASH_CODE_INTERNAL);
  ------------------------------
  v_marks := util_pkg.mark_ct_varchar_s(v_na_status_m, v_statuses_allowed, util_pkg.c_false, util_pkg.c_true);
  v_errors_str := util_pkg.get_marked_ct_varchar_s(v_na_status_m, v_marks, TRUE);
  v_errors_num := util_pkg.get_marked_ct_number(v_na_id_m, v_marks, TRUE);
  ------------------------------
  if util_pkg.get_count_ct_varchar_s(v_errors_str) > 0
  then
    ------------------------------
    util_pkg.raise_exception
    (
      util_loc_pkg.c_ora_wrong_na_status, util_loc_pkg.c_msg_wrong_na_status
        || util_pkg.c_msg_delim01 || lc_this_name
        || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_errors_num(util_ri.c_index_one))
        || util_pkg.c_msg_delim02 || v_errors_str(util_ri.c_index_one)
    );
    ------------------------------
  end if;
  ------------------------------
  if util_pkg.get_count_ct_number(v_na_id_l) > 0
  then
    ------------------------------
    v_date := sysdate;
    v_na_status_l := util_ri.get_na_status_current1(v_na_id_l, v_date, FALSE);
    ------------------------------
    v_marks := util_pkg.mark_ct_varchar_s(v_na_status_l, v_statuses_allowed, util_pkg.c_false, util_pkg.c_true);
    v_errors_str := util_pkg.get_marked_ct_varchar_s(v_na_status_l, v_marks, TRUE);
    v_errors_num := util_pkg.get_marked_ct_number(v_na_id_l, v_marks, TRUE);
    ------------------------------
    if util_pkg.get_count_ct_varchar_s(v_errors_str) > 0
    then
      ------------------------------
      util_pkg.raise_exception
      (
        util_loc_pkg.c_ora_wrong_na_status, util_loc_pkg.c_msg_wrong_na_status
          || util_pkg.c_msg_delim01 || lc_this_name
          || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_errors_num(util_ri.c_index_one))
          || util_pkg.c_msg_delim02 || v_errors_str(util_ri.c_index_one)
      );
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_date := sysdate;
  if not util_ext_ri.set_na_status2
  (
    p_na_id => v_na_id_m,
    p_status => util_ri.c_NASH_CODE_RESERVE,
    p_date => v_date,
    p_user_id => p_user_id,
    p_break_on_error => TRUE,
    p_lock_pn => TRUE,
    p_error_code => v_error_codes,
    p_error_message => v_error_messages
  )
  then
    ------------------------------
    v_pos := util_ext_ri.get_first_error_pos(v_error_codes);
    ------------------------------
    util_pkg.raise_exception
    (
      util_loc_pkg.c_ora_status_changing_failed, util_loc_pkg.c_msg_status_changing_failed
        || util_pkg.c_msg_delim01 || lc_this_name
        || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_na_id_m(v_pos))
        || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_error_codes(v_pos))
        || util_pkg.c_msg_delim02 || v_error_messages(v_pos)
    );
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_na_id := v_na_id_m;
  util_pkg.add_ct_number(v_na_id, v_na_id_l);
  ------------------------------
  v_date := sysdate;
  ------------------------------
  v_reserve_date := v_date + util_pkg.date_dif_from_minutes(p_reserve_period_minutes);
  ------------------------------
  p_reserve_number := batch_pkg.batch_ins(batch_pkg.c_BATCH_TYPE_NA_MNG, v_date, v_reserve_date, p_user_id);
  ------------------------------
  batch_pkg.na_res_batch_add_to(p_reserve_number, v_na_id, p_user_id);
  ------------------------------
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure reserve_phones4period2
(
  p_msisdn_ml ct_varchar_s,
  p_reserve_period_minutes number,
  p_user_id number,
  p_reserve_number out number
)
is
  lc_this_name constant varchar2(30) := 'NETWORK_ADDRESS';
  v_date date := sysdate;
  v_marks ct_number;
  v_errors_str ct_varchar_s;
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdn_ml);
  ------------------------------
  v_na_id := util_ri.get_na_id(p_msisdn_ml, v_date, FALSE);
  ------------------------------
  --!_!p_msisdn_ml.count = v_na_id.count
  v_marks := util_pkg.mark_val_ct_number(v_na_id, null);
  v_errors_str := util_pkg.get_marked_ct_varchar_s(p_msisdn_ml, v_marks, TRUE);
  ------------------------------
  if util_pkg.get_count_ct_varchar_s(v_errors_str) > 0
  then
    ------------------------------
    util_pkg.raise_exception
    (
      util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found
        || util_pkg.c_msg_delim01 || lc_this_name
        || util_pkg.c_msg_delim02 || v_errors_str(util_ri.c_index_one)
    );
    ------------------------------
  end if;
  ------------------------------
  reserve_phones4period
  (
    p_na_id_ml => v_na_id,
    p_reserve_period_minutes => p_reserve_period_minutes,
    p_user_id => p_user_id,
    p_reserve_number => p_reserve_number
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_result_cursor02(p_reserve_numbers ct_number, p_error_code ct_number, p_error_message ct_varchar, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
       q1.reserve_number,
       q2.error_code,
       q3.error_message
  from
    (select column_value reserve_number, rownum rn from table(p_reserve_numbers)) q1,
    (select column_value error_code, rownum rn from table(p_error_code)) q2,
    (select column_value error_message, rownum rn from table(p_error_message)) q3
  where 1 = 1
  and q2.rn(+) = q1.rn
  and q3.rn(+) = q1.rn
  and nvl(q2.error_code, util_pkg.c_ora_x_common) <> util_pkg.c_ora_ok
  order by q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor03(p_phone_sim_data t_phones_sims_container, p_is_linked_to_sim_card ct_number, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q1 q2 q3 q4 q5 q6) full(q1) full(q2) full(q3) full(q4) full(q5) full(q6)*/
       q1.record_id,
       q2.iccid,
       q3.imsi,
       q4.msisdn,
       q5.network_operator_code,
       q6.is_linked_to_sim_card
  from
    (select column_value record_id, rownum rn from table(p_phone_sim_data.rec_ids)) q1,
    (select column_value iccid, rownum rn from table(p_phone_sim_data.iccids)) q2,
    (select column_value imsi, rownum rn from table(p_phone_sim_data.imsis)) q3,
    (select column_value msisdn, rownum rn from table(p_phone_sim_data.msisdn)) q4,
    (select column_value network_operator_code, rownum rn from table(p_phone_sim_data.network_operator_codes)) q5,
    (select column_value is_linked_to_sim_card, rownum rn from table(p_is_linked_to_sim_card)) q6
  where 1 = 1
  and q2.rn(+) = q1.rn
  and q3.rn(+) = q1.rn
  and q4.rn(+) = q1.rn
  and q5.rn(+) = q1.rn
  and q6.rn(+) = q1.rn
  --!_!order by q1.rn
  order by q1.record_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor04(p_rec_ids ct_number, p_error_code ct_number, p_error_message ct_varchar, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
       q1.record_id,
       q2.error_code,
       q3.error_message
  from
    (select column_value record_id, rownum rn from table(p_rec_ids)) q1,
    (select column_value error_code, rownum rn from table(p_error_code)) q2,
    (select column_value error_message, rownum rn from table(p_error_message)) q3
  where 1 = 1
  and q2.rn(+) = q1.rn
  and q3.rn(+) = q1.rn
  and nvl(q2.error_code, util_pkg.c_ora_x_common) <> util_pkg.c_ora_ok
  --!_!order by q1.rn
  order by q1.record_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
end;
/
