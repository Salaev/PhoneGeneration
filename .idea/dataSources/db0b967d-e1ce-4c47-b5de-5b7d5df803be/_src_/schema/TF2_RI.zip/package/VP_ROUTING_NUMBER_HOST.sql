CREATE package vp_routing_number_host is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'ROUTING_NUMBER_HOST';

----------------------------------!---------------------------------------------
  function get1_i(p_host_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return routing_number_host%rowtype;
  function get1(p_host_id integer, p_date date) return routing_number_host%rowtype;
  function xlock_get1(p_host_id integer, p_date date) return routing_number_host%rowtype;

----------------------------------!---------------------------------------------
  procedure xvalid_i(p_rec routing_number_host%rowtype);

----------------------------------!---------------------------------------------
  function find_i_id(p_rec routing_number_host%rowtype) return boolean;

  function find_i(p_rec routing_number_host%rowtype) return boolean;
  procedure xunique_i(p_rec routing_number_host%rowtype);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec routing_number_host%rowtype);
  procedure close_i(p_rec routing_number_host%rowtype);

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy routing_number_host%rowtype);
  procedure version_change(p_rec in out nocopy routing_number_host%rowtype);

  procedure version_close
  (
    p_host_id integer,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------

end;
/
