CREATE PACKAGE RSIG_NETWORK_OPERATOR IS

  TYPE t_phone IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
  TYPE t_IMSI  IS TABLE OF VARCHAR2(20) INDEX BY BINARY_INTEGER;
  TYPE T_MSC IS TABLE OF VARCHAR2(15) INDEX BY BINARY_INTEGER;
  TYPE T_BSC IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;
  TYPE T_HNO IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
  TYPE t_date IS TABLE OF DATE INDEX BY BINARY_INTEGER;

  TYPE t_numbers IS TABLE OF number INDEX BY BINARY_INTEGER;
  TYPE t_varchar2 IS TABLE OF varchar2(30) INDEX BY BINARY_INTEGER;

  PROCEDURE Check_Net_Operator_Referenced(
    p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
  );

  PROCEDURE Test_Network_Operator_Deleted(
    p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
  );

  PROCEDURE Insert_Network_Operator(
    handle_tran                 IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                  OUT  NUMBER,
    p_network_operator_id_upper IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
    p_network_operator_code     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
    p_network_operator_name     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_NAME%TYPE,
    p_network_operator_type     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
    p_personal_account          IN   NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
    p_UPRS_Member_Code          IN   NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
    p_country                   IN  network_operator.country%TYPE,
    p_user_id_of_change         IN   NUMBER,
    p_network_operator_id       OUT  NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
  );

  PROCEDURE Update_Network_Operator(
    handle_tran                 IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                  OUT  NUMBER,
    p_network_operator_id       IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_network_operator_id_upper IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
    p_network_operator_code     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
    p_network_operator_name     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_NAME%TYPE,
    p_network_operator_type     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
    p_personal_account          IN   NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
    p_UPRS_Member_Code          IN   NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
    p_country                   IN  network_operator.country%TYPE,
    p_user_id_of_change         IN   NUMBER
  );

  PROCEDURE Delete_Network_Operator(
    handle_tran             IN    CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code              OUT   NUMBER,
    p_network_operator_id   IN    NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_deleted               IN    NETWORK_OPERATOR.DELETED%TYPE,
    p_user_id_of_change     IN    NUMBER
  );

  PROCEDURE Get_Network_Operator(
    error_code              OUT  NUMBER,
    p_external              IN   CHAR,
    p_network_operator_type IN   NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
    p_cur_network_operator  OUT  RSIG_UTILS.REF_CURSOR
  );

  PROCEDURE Get_Network_Operator_Detail(
    error_code              OUT  NUMBER,
    p_network_operator_id   IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
		p_cur_network_operator  OUT  RSIG_UTILS.REF_CURSOR
  );

  PROCEDURE Get_Network_Operator_All(
    error_code              OUT  NUMBER,
    p_external              IN   CHAR,
    p_network_operator_type IN   NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
    p_cur_network_operator  OUT  RSIG_UTILS.REF_CURSOR
  );

 PROCEDURE Get_Network_Operator_No_Child(
    error_code              OUT  NUMBER,
	p_network_operator_id   IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_external              IN   CHAR,
    p_network_operator_type IN   NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
	p_deleted				IN   CHAR DEFAULT 'N',
    p_cur_network_operator  OUT  RSIG_UTILS.REF_CURSOR
  );

  procedure Get_Network_Operator_Type(
	p_raise_error	IN  CHAR,
	error_code		OUT NUMBER,
	error_message	OUT VARCHAR2,
	result_list		OUT	sys_refcursor
  );

  procedure Get_NetOp_By_MSC_List(
	col_msc_list 	IN T_MSC,
	result_list		OUT sys_refcursor,
	p_raise_error	IN  CHAR,
	error_code		OUT NUMBER,
	error_message	OUT VARCHAR2
  );

  PROCEDURE Insert_Neighbour
  (
    p_network_operator_id number,
    p_neighbour_net_op_id number,
    p_roaming_type_code number,
    p_location_area_id number,
    p_base_station_id number,
    p_addit_roaming_rype_code util_pkg.cit_number,
    p_start_date date,
    p_user_id number,
    p_handle_tran char default rsig_utils.c_handle_tran_y,
    p_raise_error char,
    p_error_code out number,
    p_error_message out varchar2
  );

  PROCEDURE Update_Neighbour
  (
    p_roaming_definition_id number,
    p_network_operator_id number,
    p_roaming_type_code number,
    p_new_neighbour_net_op_id number,
    p_location_area_id number,
    p_base_station_id number,
    p_addit_roaming_rype_code util_pkg.cit_number,
    p_user_id number,
    p_start_date date,
    p_handle_tran char default rsig_utils.c_handle_tran_y,
    p_raise_error char,
    p_error_code out number,
    p_error_message out varchar2
  );

  PROCEDURE Addit_RT_Neighbour_Interval
  (
    p_roaming_definition_id IN network_operator_neighbours.roaming_definition_id%TYPE,
    p_raise_error           IN CHAR,
    p_result                OUT SYS_REFCURSOR,
    p_error_code            OUT NUMBER,
    p_error_message         OUT VARCHAR2
  );

  PROCEDURE Delete_Neighbour
  (
    p_network_operator    IN NETWORK_OPERATOR_NEIGHBOURS.NETWORK_OPERATOR_ID%TYPE,
    p_neighbour_net_op_id IN NETWORK_OPERATOR_NEIGHBOURS.NEIGHBOURING_OPERATOR_ID%TYPE,
    handle_tran           IN CHAR,
    p_raise_error         IN CHAR,
    ERROR_CODE            OUT NUMBER,
    error_message         OUT VARCHAR2
  );

  PROCEDURE Get_Net_Op_Neighbours
  (
    p_network_operator_id IN NETWORK_OPERATOR_NEIGHBOURS.NETWORK_OPERATOR_ID%TYPE,
    p_raise_error         IN CHAR,
    ERROR_CODE            OUT NUMBER,
    error_message         OUT VARCHAR2,
    result_list           OUT sys_refcursor
  );

  PROCEDURE Get_NO_with_linked_phones(
    p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
    p_error_code             OUT NUMBER,
    p_error_message          OUT VARCHAR2,
    p_result_list            OUT sys_refcursor
  );

  PROCEDURE Close_Neighbour_Interval (
    p_roaming_definition_id IN network_operator_neighbours.roaming_definition_id%TYPE,
    p_end_date              IN DATE,
    p_user_id               IN NUMBER,
    p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    p_raise_error           IN CHAR,
    p_error_code            OUT NUMBER,
    p_error_message         OUT VARCHAR2
  );

  PROCEDURE Get_Net_Op_Neighbours_BS_LOC
  (
    p_network_operator_id IN NETWORK_OPERATOR_NEIGHBOURS.NETWORK_OPERATOR_ID%TYPE,
    p_valid_date          IN DATE,
    p_raise_error         IN CHAR,
    p_ERROR_CODE          OUT NUMBER,
    p_error_message       OUT VARCHAR2,
    p_result_list         OUT sys_refcursor
  );

  PROCEDURE Get_Net_Op_Neighbours_BS_LOC2
  (
    p_network_operator_id         IN NUMBER,
    p_neigh_network_operator_name IN VARCHAR2,
    p_location_area_name          IN VARCHAR2,
    p_base_station_name           IN VARCHAR2,
    p_roaming_rype_code	          IN  T_HNO,
    p_valid_date_from             IN DATE,
    p_valid_date_to               IN DATE,
    p_raise_error                 IN CHAR,
    p_ERROR_CODE                  OUT NUMBER,
    p_error_message               OUT VARCHAR2,
    p_result_list                 OUT sys_refcursor
  );

  PROCEDURE Get_Roaming_Type
  (
    p_hno_id_l            IN t_hno,
    p_msc_l               IN t_MSC,
    p_lac_l               IN t_BSC,
    p_cellid_l            IN t_BSC,
    p_Validity_Date_l     IN  t_date,
    p_raise_error         IN CHAR,
    p_ERROR_CODE          OUT NUMBER,
    p_error_message       OUT VARCHAR2,
    p_result_list         OUT sys_refcursor
  );

  PROCEDURE GetRoamingCache(
    p_ValidityStartDate      IN  DATE,
    p_ValidityEndDate        IN  DATE,
    p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
    p_error_code             OUT NUMBER,
    p_error_message          OUT VARCHAR2,
    p_HostNOs                OUT SYS_REFCURSOR,
    p_RoamingTypes           OUT SYS_REFCURSOR,
    p_phones                 OUT SYS_REFCURSOR
  );

  PROCEDURE Get_Net_Op_Id_By_Code
  (
    p_Error_Code            OUT NUMBER,
    p_Error_Message         OUT VARCHAR2,
    p_Network_Operator_Code IN  NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,  
    p_Network_Operator_Id   OUT NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
  );

  procedure Update_Network_Operator_PA
  (
    p_network_operator_code varchar2,
    p_personal_account number,
    p_user_login varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  PROCEDURE Get_Country_ID_By_MCC
  (
    p_mcc                   IN VARCHAR2,
    error_code              OUT NUMBER,
    p_country_id            OUT VARCHAR2
  );

  PROCEDURE Insert_Network_Operator_1(
    handle_tran                 IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                  OUT  NUMBER,
    p_network_operator_id_upper IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
    p_network_operator_code     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
    p_network_operator_name     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_NAME%TYPE,
    p_network_operator_type     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
    p_personal_account          IN   NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
    p_UPRS_Member_Code          IN   NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
    p_country                   IN  network_operator.country%TYPE,
    p_user_id_of_change         IN   NUMBER,
    p_mcc                       IN   VARCHAR2,
    p_mnc                       IN   VARCHAR2,
    p_network_operator_id       OUT  NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
  );

  PROCEDURE Update_Network_Operator_1(
    handle_tran                 IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                  OUT  NUMBER,
    p_network_operator_id       IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_network_operator_id_upper IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
    p_network_operator_code     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
    p_network_operator_name     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_NAME%TYPE,
    p_network_operator_type     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
    p_personal_account          IN   NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
    p_UPRS_Member_Code          IN   NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
    p_country                   IN  network_operator.country%TYPE,
    p_user_id_of_change         IN   NUMBER,
    p_mcc                       IN   VARCHAR2,
    p_mnc                       IN   VARCHAR2
  );

  PROCEDURE Get_No_Code_By_IMSI_List(
    p_IMSI_list        IN   t_imsi,
    p_raise_error      IN   CHAR,
    p_error_code       OUT  NUMBER,
    p_error_message    OUT  VARCHAR2,
    p_result_list      OUT  SYS_REFCURSOR
  );

  PROCEDURE Get_No_Code_By_MSISDN_List(
    p_MSISDN_list      IN   t_phone,
    p_raise_error      IN   CHAR,
    p_error_code       OUT  NUMBER,
    p_error_message    OUT  VARCHAR2,
    p_result_list      OUT  SYS_REFCURSOR
  );

  PROCEDURE Insert_Network_Operator_2(
    handle_tran                 IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                  OUT  NUMBER,
    p_network_operator_id_upper IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
    p_network_operator_code     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
    p_network_operator_name     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_NAME%TYPE,
    p_network_operator_type     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
    p_personal_account          IN   NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
    p_UPRS_Member_Code          IN   NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
    p_country                   IN  network_operator.country%TYPE,
    p_user_id_of_change         IN   NUMBER,
    p_mcc                       IN   VARCHAR2,
    p_mnc                       IN   VARCHAR2,
    p_time_zone                 IN   NUMBER,
    p_DST_rule_id               IN   NUMBER,
    p_network_operator_id       OUT  NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
  );

  PROCEDURE Update_Network_Operator_2(
    handle_tran                 IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                  OUT  NUMBER,
    p_network_operator_id       IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_network_operator_id_upper IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
    p_network_operator_code     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
    p_network_operator_name     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_NAME%TYPE,
    p_network_operator_type     IN   NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
    p_personal_account          IN   NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
    p_UPRS_Member_Code          IN   NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
    p_country                   IN   network_operator.country%TYPE,
    p_user_id_of_change         IN   NUMBER,
    p_mcc                       IN   VARCHAR2,
    p_mnc                       IN   VARCHAR2,
    p_time_zone                 IN   NUMBER,
    p_DST_rule_id               IN   NUMBER    
  );

  PROCEDURE Update_Network_Operator_par(
    handle_tran                 IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                  OUT  NUMBER,
    p_network_operator_id       IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_network_operator_id_upper IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
    p_personal_account          IN   NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
    p_UPRS_Member_Code          IN   NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
    p_country                   IN   network_operator.country%TYPE,
    p_user_id_of_change         IN   NUMBER,
    p_mcc                       IN   VARCHAR2,
    p_mnc                       IN   VARCHAR2,
    p_time_zone                 IN   NUMBER,
    p_DST_rule_id               IN   NUMBER    
  );

  PROCEDURE Update_Network_Operator_par_1(
    handle_tran                 IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                  OUT  NUMBER,
    p_network_operator_id       IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_network_operator_id_upper IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
    p_personal_account          IN   NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
    p_UPRS_Member_Code          IN   NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
    p_country                   IN  network_operator.country%TYPE,
    p_user_id_of_change         IN   NUMBER,
    p_mcc                       IN   VARCHAR2,
    p_mnc                       IN   VARCHAR2
  );

  PROCEDURE Get_Owner_MNP_Code
  (
    error_code              OUT NUMBER,
    p_mnp_code              OUT VARCHAR2
  );

  PROCEDURE Get_Locations_Routing_Numbers
  (
    error_code              OUT NUMBER,
    p_cur_location_routing_numbers  OUT SYS_REFCURSOR
  );

  PROCEDURE Get_MNP_Code_For_Net_Op
  (
    p_network_operator_id   IN  NUMBER,
    p_error_code              OUT NUMBER,
    p_cur_network_operator  OUT SYS_REFCURSOR
  );

  PROCEDURE Delete_Net_Op_MNP
  (
    p_id                    IN  NUMBER,
    p_user_id_of_change     IN  NUMBER,
    p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    p_error_code            OUT NUMBER,
    p_error_message         OUT VARCHAR2
  );

  PROCEDURE Update_Net_Op_MNP
  (
    p_id                    IN  NUMBER,
    p_network_operator_id   IN  NUMBER,
    p_mnp_code              IN  VARCHAR2,
    p_LRN                   IN  VARCHAR2,
    p_LSA_Code              IN  VARCHAR2,
    p_Network_RN            IN  VARCHAR2,
    p_user_id_of_change     IN  NUMBER,
    p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    p_error_code            OUT NUMBER,
    p_error_message         OUT VARCHAR2
  );

  PROCEDURE Insert_Net_Op_MNP
  (
    p_network_operator_id   IN  NUMBER,
    p_mnp_code              IN  VARCHAR2,
    p_LRN                   IN  VARCHAR2,
    p_LSA_Code              IN  VARCHAR2,
    p_Network_RN            IN  VARCHAR2,
    p_user_id_of_change     IN  NUMBER,
    p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    p_error_code            OUT NUMBER,
    p_error_message         OUT VARCHAR2
  );

END;
/
