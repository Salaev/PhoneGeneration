CREATE PACKAGE          "LOGGING" IS
/****************************************************************************
  <header>
    <name>              package LOGGING
    </name>

    <author>            Petr Cepek
    </author>

    <version>           1.1.0     23.3.2006     Petr Cepek
                        procedure CLEAR_OLD_LOG_EVENTS  updated
    </version>
    <version>
                        1.0.0     19.7.2005     Petr Cepek
    </version>

    <Description>
    </Description>

    <Prerequisites>     Package contains procedures for logging.
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
/****************************************************************************/

/****************************************************************************
  <header>
    <name>              function Get_DBparam_Value_by_Name
    </name>

    <author>            Petr Cepek
    </author>

    <version>
                        1.0.0     19.7.2005     Petr Cepek

    </version>

    <Description>
			                  Function returns value for specified parameter from
			                  table db_parameters.
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
/****************************************************************************/
FUNCTION Get_DBparam_Value_by_Name(
  p_dbparam_name VARCHAR2
)
RETURN VARCHAR2;

/****************************************************************************
  <header>
    <name>              function CLEAR_OLD_LOG_EVENTS;
    </name>

    <author>            Petr Cepek
    </author>

    <version>           1.1.0     22.3.2006     Petr Cepek
                        number of days from table db_parameters converted to number
    </version>
    <version>
                        1.0.0     19.7.2005     Petr Cepek
    </version>

    <Description>
			                  Procedure delete records in table log_event
			                  according to parameters in table db_parameters.
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
/****************************************************************************/
PROCEDURE CLEAR_OLD_LOG_EVENTS;


END LOGGING;


/
