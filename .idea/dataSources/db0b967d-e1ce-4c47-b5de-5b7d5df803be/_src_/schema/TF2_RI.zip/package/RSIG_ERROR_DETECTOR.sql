CREATE PACKAGE          "RSIG_ERROR_DETECTOR" is

  -- Author  : JHOLUB
  -- Created : 5.8.2004 14:39:17
  -- Purpose : for detecting errors in db

  /*TYPE t_number IS TABLE OF NUMBER;
  TYPE t_string IS TABLE OF VARCHAR2(50);
*/


  /****************************************************************************
    <header>
      <name>              procedure Host_difference_SIM_Phone
      </name>

      <author>            Jaroslav Holub
      </author>

      <version>           1.0.0   5.8.2004 Jaroslav Holub
                                  created first version
      </version>

      <Description>       procedure returns in cursor all phone and sim which are connected,
            but are on different HOSTs

      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       FORIS Resource inventory
      </Application>

      <Parameters>
            result_list  OUT sys_refcursor,
     error_code  OUT NUMBER,
     error_message OUT VARCHAR2
      </Parameters>

    </header>
  ****************************************************************************/

  ----------------------------------------------------------------------------
  --  Host_difference_SIM_Phone
  ----------------------------------------------------------------------------

  procedure Host_difference_SIM_Phone(
   result_list  OUT sys_refcursor,
   error_code  OUT NUMBER,
   error_message OUT VARCHAR2
  );

  /****************************************************************************
    <header>
      <name>              procedure Incomplete_series
      </name>

      <author>            Jaroslav Holub
      </author>

      <version>           1.0.0   06.08.2004 Jaroslav Holub
                                  created first version
      </version>

      <Description>       procedure detect incomplete series(series which have
            less members then is normal

      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       FORIS Resource inventory
      </Application>

      <Parameters>
   p_phone_series  OUT sys_refcursor,
      p_sim_series OUT sys_refcursor,
     error_code  OUT NUMBER,
     error_message OUT VARCHAR2

      </Parameters>

    </header>
  ****************************************************************************/
   procedure Incomplete_series(
    p_phone_series  OUT sys_refcursor,
    p_sim_series OUT sys_refcursor,
   error_code  OUT NUMBER,
   error_message OUT VARCHAR2
  );

/****************************************************************************
    <header>
      <name>              procedure Wrongly_placed_phone_sims
      </name>

      <author>            Jaroslav Holub
      </author>

      <version>           1.0.0   06.08.2004 Jaroslav Holub
                                  created first version
      </version>

      <Description>       procedure detect sim cards and phone numbers which
            have wrong connection to its series. Its numbers
                            are outside of the range of serie.

      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       FORIS Resource inventory
      </Application>

      <Parameters>
   p_phones  OUT sys_refcursor,
      p_sims   OUT sys_refcursor,
      error_code  OUT NUMBER,
     error_message OUT VARCHAR2
      </Parameters>

    </header>
  ****************************************************************************/

  ----------------------------------------------------------------------------
  --  Wrongly_placed_phone_sims
  ----------------------------------------------------------------------------

  procedure Wrongly_placed_phone_sims(

    p_phones  OUT sys_refcursor,
    p_sims   OUT sys_refcursor,
    error_code  OUT NUMBER,
   error_message OUT VARCHAR2
  );

    /****************************************************************************
    <header>
      <name>              procedure SIM_SERIE_HLR_CONNECTION
      </name>

      <author>            Jaroslav Holub
      </author>

      <version>           1.0.0   ??.6.2004 Jaroslav Holub
                                  created first version
      </version>

      <Description>       procedure returns all series which have konnection
            on other hoste then HLR, or have no connectin on host

      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       FORIS Resource inventory
      </Application>

      <Parameters>
   p_sim_series  OUT sys_refcursor,
     error_code  OUT NUMBER,
     error_message OUT VARCHAR2
       </Parameters>

    </header>
  ****************************************************************************/

  ----------------------------------------------------------------------------
  --  SIM_SERIE_HLR_CONNECTION
  ----------------------------------------------------------------------------

  procedure SIM_SERIES_HLR_CONNECTION(
 p_sim_series  OUT sys_refcursor,
   error_code  OUT NUMBER,
   error_message OUT VARCHAR2
  );

   /****************************************************************************
   <header>
     <name>              procedure access_point_host_HLR
     </name>

     <author>            Jaroslav Holub
     </author>

     <version>           1.0.0   ??.6.2004 Jaroslav Holub
                                 created first version
     </version>

     <Description>       procedure returns all sims which have wronly set
           connection which have to be used for other
                            purposes (IN platform...)

     </Description>

     <Prerequisites>
     </Prerequisites>

     <Application>       FORIS Resource inventory
     </Application>

     <Parameters>
                         ,
                         handle_tran       IN  CHAR,
                         p_raise_error     IN  CHAR,
                         error_code        OUT NUMBER,
                         error_message     OUT VARCHAR2
     </Parameters>

   </header>
 ****************************************************************************/

 ----------------------------------------------------------------------------
 --  access_point_host_HLR
 ----------------------------------------------------------------------------

 procedure access_point_host_HLR(

 p_sim_card  OUT sys_refcursor,
  error_code  OUT NUMBER,
  error_message OUT VARCHAR2
 );


end RSIG_ERROR_DETECTOR;


/
