CREATE PACKAGE BODY PHONE_NUMBER_SERIES_EXT IS
------------------------------------------------------------------------------------------------------------------------------
--  Is_Net_Op_External
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Is_Net_Op_External(
  p_network_operator_id    IN   network_operator.network_operator_id%TYPE
)
IS
  v_type                   network_operator.network_operator_type%TYPE;
BEGIN

	IF p_network_operator_id IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


-- start of the procedure body --------------------------------------------------------------------------------------------------

  SELECT n.network_operator_type
  INTO v_type
  FROM network_operator n
	WHERE n.network_operator_id=p_network_operator_id;

  IF v_type IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NOT_EXT_OPERATOR, 'Operator is not external.');
  END IF;

-- end of the procedure body ----------------------------------------------------------------------------------------------------
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_operator_not_exist, 'Operator not exists.');
	WHEN OTHERS THEN
    RAISE;
END Is_Net_Op_External;

------------------------------------------------------------------------------------------------------------------------------
--  Insert_Phone_Series_For_Ext_op
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_Phone_Series_For_Ext_op
(
  handle_tran                IN     CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_phone_number_type_code   IN     PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE, -- phone number type code of the given serie of phone numbers
  p_country_code             IN     PHONE_NUMBER_SERIES.COUNTRY_CODE%TYPE, -- country code of given phone number serie
  p_area_code                IN     PHONE_NUMBER_SERIES.AREA_CODE%TYPE, -- area code of given phone number serie
  p_starting_local_number    IN     PHONE_NUMBER_SERIES.LOCAL_NUMBER_START%TYPE, -- starting local phone number of new phone number serie
  p_ending_local_number      IN     PHONE_NUMBER_SERIES.LOCAL_NUMBER_END%TYPE, -- ending local phone number of new phone number serie
  p_phone_number_status_code IN     PHONE_NUMBER.NET_ADDRESS_STATUS_CODE%TYPE, 
  p_network_operator_id      IN     NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE, -- id of the network operator who will own this new inserted serie
  p_start_date               IN     DATE, -- the date since when given network operator owns this new inserted serie
  p_user_id_of_change        IN     NUMBER, -- id of the user who insert this serie
  p_host_id                  IN     PHONE_NUMBER_SERIES.HOST_ID%TYPE,
  error_code                 OUT    NUMBER,
  p_phone_serie_id           OUT    PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE
)
IS
  v_sp_name varchar2(30);
  v_event_source            VARCHAR2(60) := 'PHONE_NUMBER_SERIES_EXT.Insert_Phone_Series_For_Ext_op';
  v_starting_local_number   VARCHAR2(20); -- starting local phone number of new phone number serie
  v_ending_local_number     VARCHAR2(20); -- ending local phone number of new phone number serie

  v_date                    DATE; -- date of performing changes in this procedure
  v_phone_number_ser_id     NUMBER;
  v_length                  NUMBER;
  v_start_date              DATE;
  v_serie_exist             INT :=0;
  a_PN                       Common.t_varchar2_255;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    v_sp_name := util_sys_pkg.make_savepoint;
  END IF;

  v_date:=SYSDATE;
  -- check if mandatory parameters exist
  IF (p_starting_local_number IS NULL)
     OR (p_ending_local_number IS NULL)
     OR (p_country_code IS NULL)
     OR (p_user_id_of_change IS NULL)
     OR (p_network_operator_id IS NULL)
     OR (p_phone_number_type_code IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;
  v_start_date := nvl(p_start_date, SYSDATE);

  Is_Net_Op_External(p_network_operator_id);

  -- replacing spaces from phone number
  v_starting_local_number:=REPLACE(p_starting_local_number, ' ');
  v_ending_local_number:=REPLACE(p_ending_local_number, ' ');
  -- find length of phone number without prefix
  v_length:=length(v_ending_local_number);

  -- Start number is longer than end number
  IF v_length < length(v_starting_local_number) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, '');
  END IF;
  -- complete start number to same length as end number
  v_starting_local_number:=lpad(v_starting_local_number,v_length,'0');

  -- start number is greater than  end number
  IF to_number(v_ending_local_number) < to_number(v_starting_local_number) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, '');
  END IF;

  -- test for overlaping of phone serie
  SELECT COUNT(1)
  INTO v_serie_exist
  FROM phone_number_series pns
  WHERE (pns.deleted>SYSDATE OR pns.deleted IS NULL)
    AND to_number(p_country_code || p_area_code || v_starting_local_number) <=
        to_number(pns.country_code || pns.area_code || pns.local_number_end)
    AND to_number(p_country_code || p_area_code || v_ending_local_number) >=
        to_number(pns.country_code || pns.area_code || pns.local_number_start);

  IF v_serie_exist > 0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INTERVAL_INTERFERES_D, '');
  END IF;

  --RSIG_PHONE_NUMBER_SERIES.Test_Phone_Number_Type_Deleted(p_phone_number_type_code);
  --RSIG_PHONE_NUMBER_SERIES.Test_Network_Operator_Deleted(p_network_operator_id);

  SELECT S_PHONE_NUMBER_SERIES.NEXTVAL INTO v_phone_number_ser_id FROM dual;

  -- inserting new phone number serie
  INSERT INTO PHONE_NUMBER_SERIES
    (PHONE_NUMBER_SERIES_ID,
     COUNTRY_CODE,
     AREA_CODE,
     LOCAL_NUMBER_START,
     LOCAL_NUMBER_END,
     PHONE_NUMBER_TYPE_CODE,
     DATE_OF_CHANGE,
     USER_ID_OF_CHANGE,
     HOST_ID)
  VALUES
    (v_phone_number_ser_id,
     p_country_code,
     p_area_code,
     v_starting_local_number,
     v_ending_local_number,
     p_phone_number_type_code,
     v_date,
     p_user_id_of_change,
     p_host_id);

  -- assign operator who owns the given serie to the given serie
  INSERT INTO PHONE_SERIES_OPERATOR
    (PHONE_NUMBER_SERIES_ID,
     NETWORK_OPERATOR_ID,
     START_DATE,
     END_DATE,
     DATE_OF_CHANGE,
     USER_ID_OF_CHANGE)
  VALUES
    (v_phone_number_ser_id,
     p_network_operator_id,
     v_start_date,
     NULL,
     v_date,
     p_user_id_of_change);

  IF (p_phone_number_status_code is not null) THEN
     DELETE FROM tt_batch_na_ap;

     -- generating phone numbers

    FOR v_cur_phone IN to_number(v_starting_local_number) .. to_number(v_ending_local_number) LOOP
      a_PN(a_PN.count):=p_country_code || p_area_code || lpad(v_cur_phone, v_length, '0');
    END LOOP;

    FORALL y IN a_PN.FIRST .. a_PN.LAST
    INSERT INTO tt_batch_na_ap(international_format)
    VALUES(a_PN(y));

    -- find already deleted phone numbers
    UPDATE tt_batch_na_ap t
    SET (t.network_address_id,t.RESULT)= (SELECT /*+ index(pn UK_PHONE_NUM_PHONE_NUMBER) */
                                                 pn.network_address_id,
                                                 rsig_utils.c_ORA_DELETED
                                          FROM phone_number pn
                                          WHERE pn.international_format=t.international_format);

    -- add new network address id for each new phone number
    UPDATE tt_batch_na_ap t
    SET t.network_address_id=s_network_address.NEXTVAL
    WHERE t.RESULT IS NULL;


    INSERT INTO network_address(network_address_id)
    SELECT t.network_address_id
    FROM tt_batch_na_ap t
    WHERE t.RESULT IS NULL;


      -- insert new phone numbers
    INSERT INTO phone_number(network_address_id,
                             phone_number_series_id,
                             international_format,
                             salability_category_code,
                             date_of_change,
                             user_id_of_change)
    SELECT t.network_address_id,
           v_phone_number_ser_id,
           t.international_format,
           rsig_utils.c_standard_sal_category,
           v_date,
           p_user_id_of_change
    FROM tt_batch_na_ap t
    WHERE t.RESULT IS NULL;


    -- update already deleted phone numbers
    UPDATE phone_number pn
    SET pn.phone_number_series_id=v_phone_number_ser_id,
        pn.deleted = NULL,
        pn.salability_category_code = rsig_utils.c_standard_sal_category
    WHERE EXISTS(SELECT 1
                 FROM tt_batch_na_ap t
                 WHERE t.network_address_id=pn.network_address_id
                   AND t.result=rsig_utils.c_ORA_DELETED);

    -- setting status for given phone number
    INSERT INTO NETWORK_ADDRESS_STATUS_HISTORY
      (NET_ADDRESS_STATUS_CODE,
       NETWORK_ADDRESS_ID,
       START_DATE,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE,
       END_DATE)
      SELECT /*+ index(pn I_PHONENUM_PHONE_NUM_SERIES_ID)*/
             p_phone_number_status_code,
             pn.network_address_id,
             v_start_date,
             v_date,
             p_user_id_of_change,
             NULL
        FROM phone_number pn
       WHERE pn.phone_number_series_id=v_phone_number_ser_id;
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code       := RSIG_UTILS.c_OK; -- succesfully completed
  p_phone_serie_id := v_phone_number_ser_id;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(to_number(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        util_sys_pkg.rollback_savepoint(v_sp_name);
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
END Insert_Phone_Series_For_Ext_op;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Phone_Series
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Phone_Series(
  p_network_operator_id    IN  network_operator.network_operator_id%TYPE,
  p_show_deleted           IN  CHAR DEFAULT rsig_utils.c_NO,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='PHONE_NUMBER_SERIES_EXT.Get_Phone_Series';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

/*	IF test input parameters THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
*/

-- start of the procedure body --------------------------------------------------------------------------------------------------
  Is_Net_Op_External(p_network_operator_id);

  OPEN result_list FOR
	SELECT pns.phone_number_series_id,
         pns.country_code,
         pns.area_code,
         pns.local_number_start,
         pns.local_number_end,
         pso.start_date,
         pso.end_date,
         pso.date_of_change,
         u.user_name,
         pns.phone_number_type_code
  FROM phone_number_series pns
  JOIN phone_series_operator pso ON pso.phone_number_series_id=pns.phone_number_series_id
       AND (SYSDATE BETWEEN pso.start_date AND nvl(pso.end_date,SYSDATE) OR p_show_deleted=rsig_utils.c_YES)
  JOIN users u on u.user_id=pns.user_id_of_change
  WHERE pso.network_operator_id=p_network_operator_id
    AND (pns.deleted IS NULL OR p_show_deleted=rsig_utils.c_YES);

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
	  v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Phone_Series;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Delete_Phone_Serie
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Delete_Phone_Serie(
  p_phone_serie_id      IN  phone_number_series.phone_number_series_id%TYPE,
  p_user_id_of_change   IN  NUMBER,
  handle_tran	          IN  CHAR,
  p_raise_error	        IN  CHAR,
  error_code            OUT NUMBER,
  error_message	        OUT VARCHAR2
)
IS
  v_sp_name varchar2(30);
	v_sqlcode	            number;
  v_event_source        varchar2(60) :='PHONE_NUMBER_SERIES_EXT.Delete_Phone_Serie';
  v_exist               INT :=0;
  v_sysdate             DATE;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

  IF p_phone_serie_id IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


	-- set savepoint
	IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
      v_sp_name := util_sys_pkg.make_savepoint;
	END IF;

  v_sysdate:=SYSDATE;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
  SELECT COUNT(*)
  INTO v_exist
  FROM phone_series_operator pso
  JOIN network_operator no ON no.network_operator_id=pso.network_operator_id
  WHERE pso.phone_number_series_id=p_phone_serie_id
    AND v_sysdate BETWEEN pso.start_date AND nvl(pso.end_date,v_sysdate)
    AND no.network_operator_type IS NOT NULL;

  IF v_exist = 0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NOT_EXT_OPERATOR, 'Operator is not external operator');
  END IF;

  SELECT COUNT(*)
  INTO v_exist
  FROM dual
  WHERE EXISTS(SELECT 1
               FROM phone_number pn
               WHERE pn.phone_number_series_id=p_phone_serie_id);

  IF v_exist = 1 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NOT_EXT_OPERATOR, 'Operator is not external operator');
  END IF;

  UPDATE phone_number_series pns
  SET pns.date_of_change=v_sysdate,
      pns.user_id_of_change=p_user_id_of_change,
      pns.deleted=v_sysdate
  WHERE pns.phone_number_series_id=p_phone_serie_id;

  UPDATE phone_series_operator pso
  SET pso.end_date=v_sysdate
  WHERE pso.phone_number_series_id=p_phone_serie_id
    AND v_sysdate BETWEEN pso.start_date AND nvl(pso.end_date,v_sysdate);


-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
              util_sys_pkg.rollback_savepoint(v_sp_name);
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Delete_Phone_Serie;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Delete_Phone_Serie
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Change_Network_Operator(
  p_phone_serie_id      IN  phone_number_series.phone_number_series_id%TYPE,
  p_new_operator_id     IN  network_operator.network_operator_id%TYPE,
  p_user_id_of_change   IN  NUMBER,
  handle_tran	          IN  CHAR,
  p_raise_error	        IN  CHAR,
  error_code            OUT NUMBER,
  error_message	        OUT VARCHAR2
)
IS
  v_sp_name varchar2(30);
	v_sqlcode	            number;
  v_event_source        varchar2(60) :='PHONE_NUMBER_SERIES_EXT.Change_Network_Operator';
  v_sysdate             DATE;
  v_old_operator_id     network_operator.network_operator_id%TYPE;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

  IF p_phone_serie_id IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


	-- set savepoint
	IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
      v_sp_name := util_sys_pkg.make_savepoint;
	END IF;

  v_sysdate:=SYSDATE;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
  -- check operators for external attribute
  Is_Net_Op_External(p_new_operator_id);

  BEGIN
    SELECT pso.network_operator_id
    INTO v_old_operator_id
    FROM phone_number_series pns
    JOIN phone_series_operator pso ON pns.phone_number_series_id=pso.phone_number_series_id
    WHERE pso.phone_number_series_id=p_phone_serie_id
      AND v_sysdate BETWEEN pso.start_date AND nvl(pso.end_date,v_sysdate)
      AND pns.deleted IS NULL;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Serie not exists.');
    WHEN TOO_MANY_ROWS THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INTERVAL_INTERFERES_D, 'Intervals overlaped');
  END;

  IF v_old_operator_id = p_new_operator_id THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_SAME_PHONE_OPERATOR, 'Same new operator like old operator.');
  END IF;

  -- terminate interval of previous operator
  UPDATE phone_series_operator pso
  SET pso.end_date=v_sysdate - rsig_utils.c_INTERVAL_DIFFERENCE,
      pso.date_of_change = SYSDATE,
      pso.user_id_of_change = p_user_id_of_change
  WHERE pso.phone_number_series_id=p_phone_serie_id
    AND v_sysdate BETWEEN pso.start_date AND nvl(pso.end_date,v_sysdate);


  -- insert interval for new operator
  INSERT INTO phone_series_operator(
    phone_number_series_id,
    network_operator_id,
    start_date,
    end_date,
    date_of_change,
    user_id_of_change)
  VALUES(p_phone_serie_id,
         p_new_operator_id,
         v_sysdate,
         NULL,
         SYSDATE,
         p_user_id_of_change);



-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
              util_sys_pkg.rollback_savepoint(v_sp_name);
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Change_Network_Operator;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Phone_Series_History
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Phone_Series_History(
  p_phone_series_id        IN  phone_number_series.phone_number_series_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='PHONE_NUMBER_SERIES_EXT.Get_Phone_Series_History';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

	IF p_phone_series_id IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


-- start of the procedure body --------------------------------------------------------------------------------------------------

  OPEN result_list FOR
	SELECT n.network_operator_name,
         pso.start_date,
         pso.end_date,
         pso.date_of_change,
         u.user_name
  FROM phone_series_operator pso
  JOIN network_operator n ON n.network_operator_id=pso.network_operator_id
  JOIN users u ON u.user_id=pso.user_id_of_change
  WHERE pso.phone_number_series_id=p_phone_series_id
  ORDER BY pso.start_date;


-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
	  v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Phone_Series_History;

END;
/
