CREATE PACKAGE BODY PERSONAL_ACCOUNT_PCK IS

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Set_balance_storage
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Set_balance_storage(
  p_PA_l                  IN  common.t_number,
  p_host_l                IN  t_host,
  p_Start_Date            IN  DATE,
  p_user_login            IN  VARCHAR2,
  p_handle_tran            IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message        OUT VARCHAR2
)
IS
  v_package_name          VARCHAR2(30) := 'PERSONAL_ACCOUNT_PCK';
  v_procedure_name        VARCHAR2(30) := 'Set_balance_storage';
  v_event_source          VARCHAR2(60);
  v_user_id               NUMBER;
  v_message               VARCHAR2(32767);
  v_start_date            DATE:=nvl(p_Start_Date,SYSDATE);

  v_sysdate               DATE:=SYSDATE;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_PA_l count: ' || p_PA_l.COUNT || chr(10) ||
              'p_host_l count: ' || p_host_l.COUNT || chr(10) ||
              'p_Start_Date: ' || p_Start_Date;


  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check existence of user
  v_user_id := Rsig_users.Get_user_id_by_login(p_user_login);

  -- check input parameters
  IF (p_PA_l.COUNT = 0) OR (p_PA_l.COUNT = 1 AND p_PA_l(p_PA_l.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  IF p_PA_l.COUNT <> p_host_l.COUNT THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

--------------------------------------------------------------------------------------------------
  DELETE FROM tt_batch_personal_account;

  FORALL i IN p_PA_l.FIRST .. p_PA_l.LAST
  INSERT INTO tt_batch_personal_account(personal_account,host_id,error_code)
  VALUES(p_PA_l(i),trim(p_host_l(i)),rsig_utils.c_OK);
  
  -- update current balance storage
  BEGIN
    -- close previous balance storage
    UPDATE /*+ dynamic_sampling(2) index(pah PK_PER_ACCOUNT_HISTORY) */
           personal_account_history pah
    SET pah.end_date=v_start_date-rsig_utils.c_INTERVAL_DIFFERENCE,
        pah.user_id_of_change=v_user_id,
        pah.date_of_changed=v_sysdate
    WHERE EXISTS(SELECT 1
                 FROM tt_batch_personal_account tt
                 WHERE tt.personal_account=pah.personal_account)
      AND pah.end_date IS NULL;
    
    -- insert new balance storage
    INSERT INTO personal_account_history
           (personal_account,
            start_date,
            end_date,
            balance_storage,
            user_id_of_change,
            date_of_changed)
    SELECT DISTINCT
           t.personal_account,
           v_start_date,
           NULL,
           t.host_id,
           v_user_id,
           SYSDATE
    FROM tt_batch_personal_account t
    WHERE t.HOST_ID IS NOT NULL;
                 
  EXCEPTION
    WHEN constants.E_PARENT_KEY_NOT_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_HOST_DELETED, 'Host does not exist.');
    WHEN DUP_VAL_ON_INDEX THEN
      RAISE_APPLICATION_ERROR(constants.c_ERR_BATCH_DUPLICITY, 'There are data duplicity in the batch.');
  END;

---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;


    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Set_balance_storage;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Set_Personal_Account_For_SIM
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Set_Personal_Account_For_SIM(
  p_sn_l                  IN  common.t_ICCID,
  p_PA_l                  IN  common.t_number,
  p_user_login            IN  VARCHAR2,
  p_handle_tran            IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list           OUT SYS_REFCURSOR
)
IS
  v_package_name          VARCHAR2(30) := '';
  v_procedure_name        VARCHAR2(30) := 'Set_Personal_Account_For_SIM';
  v_event_source          VARCHAR2(60);
  v_user_id               NUMBER;
  v_message               VARCHAR2(32767);
  v_sysdate               DATE:=SYSDATE;
  v_enddate               DATE:=v_sysdate-1/(24*60*60);
  v_tmp                   NUMBER;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_sn_l: ' || p_sn_l.COUNT || chr(10) ||
              'p_PA_l: ' || p_PA_l.COUNT;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check existence of user
  v_user_id := Rsig_users.Get_user_id_by_login(p_user_login);

  -- check input parameters
  IF (p_sn_l.COUNT = 0) OR (p_sn_l.COUNT = 1 AND p_sn_l(p_sn_l.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  IF p_sn_l.COUNT <> p_PA_l.COUNT THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  v_sysdate := sysdate;
--------------------------------------------------------------------------------------------------

  -- insert list of sim cards into the temporary table ----------------
  DELETE FROM tt_batch_na_ap;

  FORALL i IN nvl(p_sn_l.FIRST, 1) .. nvl(p_sn_l.LAST, 0)
    INSERT INTO tt_batch_na_ap(sn,personal_account,result)
    VALUES(p_sn_l(i),p_PA_l(i), rsig_utils.c_OK);

  RSIG_UTILS.Fill_AP_ID_From_SN;

  -- set history for personal account
  FOR i IN (SELECT *
              FROM tt_batch_na_ap tbna
             WHERE tbna.RESULT = RSIG_UTILS.c_OK) LOOP
    --check, if card hasn't already same personal account
    SELECT COUNT(1) INTO v_tmp
      FROM sim_card sc
     WHERE sc.access_point_id = i.access_point_id
       AND (sc.personal_account = i.personal_account);
    IF v_tmp = 0 THEN
      --close old interval
      UPDATE access_point_personal_account appa
         SET appa.to_date = v_enddate,
             appa.date_of_change = v_sysdate,
             appa.user_id_of_change = v_user_id
       WHERE appa.to_date IS NULL
         AND appa.access_point_id = i.access_point_id;
      --create new interval
      IF i.personal_account IS NOT NULL THEN
        INSERT INTO access_point_personal_account
          (access_point_id,
           personal_account,
           from_date,
           to_date,
           date_of_change,
           user_id_of_change)
        VALUES
          (i.access_point_id,
           i.personal_account,
           v_sysdate,
           NULL,
           SYSDATE,
           v_user_id);
      END IF;
    END IF;
  END LOOP;

  -- set personal account
  FORALL i IN p_sn_l.FIRST .. p_sn_l.LAST
  UPDATE sim_card sc
  SET sc.personal_account=p_PA_l(i),
      sc.User_Id_Of_Change=v_user_id,
      sc.date_of_change=v_sysdate
  WHERE sc.sn=p_sn_l(i);

  OPEN p_result_list FOR
  select SN,
         PERSONAL_ACCOUNT,
         RESULT
  from tt_batch_na_ap
  where RESULT != RSIG_UTILS.c_OK;

---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;


    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Set_Personal_Account_For_SIM;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  set_distribution_platform
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE set_distribution_platform(
  p_personal_accounts_list   IN  common.t_number,
  p_host_id                  IN  NUMBER,
  p_error_code               OUT NUMBER,
  p_error_message            OUT VARCHAR2
)
IS
  v_package_name          VARCHAR2(30) := 'PERSONAL_ACCOUNT_PCK';
  v_procedure_name        VARCHAR2(30) := 'set_distribution_platform';
  v_event_source          VARCHAR2(60);
  v_number                NUMBER;
  v_message               VARCHAR2(32767);
  v_start_date            DATE := SYSDATE;
BEGIN

  v_event_source := v_package_name || '.' || v_procedure_name;

  p_error_message := null;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

   -- check input parameters
  IF (p_personal_accounts_list IS NULL) OR
     (p_personal_accounts_list.COUNT = 0) OR
     (p_personal_accounts_list.COUNT = 1 AND p_personal_accounts_list(p_personal_accounts_list.FIRST) IS NULL)
  THEN
    p_error_code := RSIG_UTILS.c_ORA_MISSING_PARAMETER;
    p_error_message := 'Missing mandatory parameter (p_personal_accounts_list).';
    RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
  END IF;

  --Check HOST_ID
  IF p_host_id IS NOT NULL
  THEN
    --Check exist HOST_ID
    SELECT COUNT(1) INTO v_number FROM HOST WHERE host_id = p_host_id;
    IF v_number = 0
    THEN
      p_error_code := RSIG_UTILS.c_ORA_DP_HOST_NOT_FOUND;
      p_error_message := 'Host is not found.';
      RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
    END IF;
    --Check delete HOST_ID
    SELECT COUNT(1) INTO v_number FROM HOST WHERE host_id = p_host_id AND deleted IS NULL;
    IF v_number = 0
    THEN
      p_error_code := RSIG_UTILS.c_ORA_DP_HOST_DELETED;
      p_error_message := 'Host is deleted.';
      RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
    END IF;
  END IF;

  IF p_host_id IS NULL
  THEN
    FOR i IN p_personal_accounts_list.FIRST .. p_personal_accounts_list.LAST
    LOOP
      v_number := 0;
      SELECT COUNT(*) INTO v_number FROM distribution_platform dp
        WHERE dp.personal_account = p_personal_accounts_list(i);
      IF v_number = 0
      THEN
        -- Distribution platform is not found
        p_error_code := RSIG_UTILS.c_ORA_DP_NOT_FOUND;
        p_error_message := 'Distribution platform is not found.';
        RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
      END IF;

      SELECT COUNT(*) INTO v_number FROM distribution_platform dp
        WHERE dp.personal_account = p_personal_accounts_list(i)
          AND dp.end_date is null;
      IF v_number = 0
      THEN
        -- Distribution platform is deleted
        p_error_code := RSIG_UTILS.c_ORA_DP_DELETED;
        p_error_message := 'Distribution platform is deleted.';
        RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
      END IF;
      -- Delete distributijn platform
      UPDATE distribution_platform dp SET dp.end_date = SYSDATE
        WHERE dp.personal_account = p_personal_accounts_list(i)
          AND dp.end_date is null;
    END LOOP;
  ELSE
    FOR i IN p_personal_accounts_list.FIRST .. p_personal_accounts_list.LAST
    LOOP
      v_number := 0;
      SELECT COUNT(*) INTO v_number FROM distribution_platform dp
        WHERE dp.personal_account = p_personal_accounts_list(i)
          AND dp.end_date is null;
      IF v_number = 0
      THEN
        -- insert new distribution platform
        INSERT INTO distribution_platform dp
           (
             dp.personal_account,
             dp.host_id,
             dp.start_date,
             dp.end_date
           )
           VALUES
           (
             p_personal_accounts_list(i),
             p_host_id,
             v_start_date,
             NULL
           );
      --ELSE
      --  -- Distribution platform already exists
      --  p_error_code := RSIG_UTILS.c_ORA_DP_ALREADY_EXISTS;
      --  p_error_message := 'Distribution platform already exists.';
      --  RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
      END IF;
    END LOOP;
  END IF;

  COMMIT;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
  p_error_message := 'Succesfully completed.';

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE, SQLERRM, v_message, NULL, v_package_name, v_procedure_name);
    IF p_error_message IS NULL
    THEN
      p_error_message := sqlerrm;
    END IF;

END set_distribution_platform;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  get_distribution_platform
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE get_distribution_platform(
  p_personal_accounts_list    IN  common.t_number,
  p_date                      IN  DATE,
  p_cur_distribution_platform IN OUT RSIG_UTILS.REF_CURSOR,
  p_error_code                OUT NUMBER,
  p_error_message             OUT VARCHAR2
)
IS
  v_package_name          VARCHAR2(30) := 'PERSONAL_ACCOUNT_PCK';
  v_procedure_name        VARCHAR2(30) := 'get_distribution_platform';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(32767);
  v_date                  DATE := SYSDATE;

BEGIN

  v_event_source := v_package_name || '.' || v_procedure_name;

  p_error_message := null;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_date IS NULL
  THEN
    v_date := SYSDATE;
  ELSE
    v_date := p_date;
  END IF;

  -- check input parameters
  IF (p_personal_accounts_list IS NULL) OR
     (p_personal_accounts_list.COUNT = 0) OR
     (p_personal_accounts_list.COUNT = 1 AND p_personal_accounts_list(p_personal_accounts_list.FIRST) IS NULL)
  THEN
    p_error_code := RSIG_UTILS.c_ORA_MISSING_PARAMETER;
    p_error_message := 'Missing mandatory parameter (p_personal_accounts_list).';
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, p_error_message);
  END IF;

 DELETE FROM tt_batch_personal_account;

 FOR i IN p_personal_accounts_list.FIRST .. p_personal_accounts_list.LAST
 LOOP
   IF p_personal_accounts_list(i) is not null
   THEN
     INSERT INTO tt_batch_personal_account
     (
       personal_account,
       host_id,
       error_code
     )
     VALUES
     (
       p_personal_accounts_list(i),
       NULL,
       NULL
     );
   END IF;
 END LOOP;

 OPEN p_cur_distribution_platform FOR
        SELECT tt.personal_account as personal_account,
             dp.host_id as host_id,
             h.host_type_code as host_type,
             dp.start_date as start_date,
             dp.end_date as end_date
        FROM tt_batch_personal_account tt
        LEFT JOIN distribution_platform dp on tt.personal_account = dp.personal_account
        LEFT JOIN host h on h.host_id = dp.host_id
          WHERE dp.start_date <= v_date and
                (dp.end_date is null or dp.end_date >= v_date);

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
  p_error_message := 'Succesfully completed.';

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE, SQLERRM, v_message, NULL, v_package_name, v_procedure_name);
    IF p_error_message IS NULL
    THEN
      p_error_message := sqlerrm;
    END IF;

END get_distribution_platform;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  check_distribution_platform
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE check_distribution_platform(
  p_personal_account          IN  NUMBER,
  p_check_date                IN  DATE,
  p_check_result              OUT NUMBER,
  p_error_code                OUT NUMBER,
  p_error_message             OUT VARCHAR2
)
IS
  v_package_name          VARCHAR2(30) := 'PERSONAL_ACCOUNT_PCK';
  v_procedure_name        VARCHAR2(30) := 'check_distribution_platform';
  v_event_source          VARCHAR2(60);

BEGIN

  v_event_source := v_package_name || '.' || v_procedure_name;

  p_error_message := null;
  p_check_result := 0;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF p_personal_account IS NULL
  THEN
    p_error_code := RSIG_UTILS.c_ORA_MISSING_PARAMETER;
    p_error_message := 'Missing mandatory parameter (p_personal_accounts_list).';
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, p_error_message);
  END IF;

  SELECT COUNT(1) INTO p_check_result
      FROM distribution_platform dp
        WHERE dp.personal_account = p_personal_account
          AND (dp.end_date >= p_check_date OR dp.end_date IS NULL);

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
  p_error_message := 'Succesfully completed.';

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE, SQLERRM, NULL, NULL, v_package_name, v_procedure_name);
    IF p_error_message IS NULL
    THEN
      p_error_message := sqlerrm;
    END IF;

END check_distribution_platform;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  delete_balance_storage_for_pa
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE delete_balance_storage_for_pa(
  p_personal_accounts_list    IN  common.t_number,
  p_user_login                IN  VARCHAR2,
  p_date_of_operation         IN  DATE,
  p_handle_tran               IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error               IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                OUT NUMBER,
  p_error_message             OUT VARCHAR2
)
IS
  v_package_name          VARCHAR2(30) := 'PERSONAL_ACCOUNT_PCK';
  v_procedure_name        VARCHAR2(30) := 'delete_balance_storage_for_pa';
  v_event_source          VARCHAR2(60);
  v_user_id               NUMBER;
  v_count                 NUMBER;
  v_sysdate               DATE := SYSDATE;
  v_start_date            DATE;
  v_na_host_id            NUMBER;

BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);

  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check existence of user
  v_user_id := Rsig_users.Get_user_id_by_login(p_user_login);

  IF p_date_of_operation IS NULL
  THEN
    v_start_date := SYSDATE;
  ELSE
    v_start_date := p_date_of_operation;
  END IF;

  -- check input parameters
  IF (p_personal_accounts_list.COUNT = 0) OR (p_personal_accounts_list.COUNT = 1 AND p_personal_accounts_list(p_personal_accounts_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(util_pkg.c_ora_missing_parameter, util_pkg.c_msg_missing_parameter||'(p_personal_accounts_list).');
  END IF;

  v_na_host_id := util_ri.xget_not_available_host_id;

  SELECT COUNT(1)
    INTO v_count
    FROM host h
   WHERE H.HOST_ID = v_na_host_id;

  IF v_count = 0 THEN
    RAISE_APPLICATION_ERROR(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found||'(host_id =' || v_na_host_id || ')');
  END IF;

--------------------------------------------------------------------------------------------------

  DELETE FROM tt_batch_personal_account;

  FORALL i IN p_personal_accounts_list.FIRST .. p_personal_accounts_list.LAST
    INSERT INTO tt_batch_personal_account(personal_account, host_id, error_code)
         VALUES(p_personal_accounts_list(i), v_na_host_id, rsig_utils.c_OK);

  -- update current balance storage
  BEGIN
    -- close previous balance storage
    UPDATE /*+ dynamic_sampling(2) index(pah PK_PER_ACCOUNT_HISTORY) */
        personal_account_history pah
    SET pah.end_date = v_start_date - rsig_utils.c_INTERVAL_DIFFERENCE,
        pah.user_id_of_change = v_user_id,
        pah.date_of_changed = v_sysdate
    WHERE EXISTS(SELECT 1
                 FROM tt_batch_personal_account tt
                 WHERE tt.personal_account = pah.personal_account)
            AND pah.end_date IS NULL;

    -- insert new balance storage
    INSERT INTO personal_account_history
           (personal_account,
            start_date,
            end_date,
            balance_storage,
            user_id_of_change,
            date_of_changed)
    SELECT DISTINCT
           t.personal_account,
           v_start_date,
           NULL,
           t.host_id,
           v_user_id,
           SYSDATE
    FROM tt_batch_personal_account t
      WHERE t.HOST_ID IS NOT NULL;

  EXCEPTION
    WHEN constants.E_PARENT_KEY_NOT_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_HOST_DELETED, 'Host does not exist.');
    WHEN DUP_VAL_ON_INDEX THEN
      RAISE_APPLICATION_ERROR(constants.c_ERR_BATCH_DUPLICITY, 'There are data duplicity in the batch.');
  END;

---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);

  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := util_pkg.get_err_code;
    p_error_message := util_pkg.get_err_msg;

    IF upper(p_raise_error) = rsig_utils.c_YES THEN
      RAISE;
    END IF;

END delete_balance_storage_for_pa;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_Type_Host_By_PAList
-----------------------------------------------------------------------------------------------------------------------------------------------------
procedure Get_Type_Host_By_PAList(
    p_personal_account_numbers       in  common.t_number,
    p_hosts                          out sys_refcursor,
    p_error_code                     out number,
    p_error_message                  out varchar2
  )
  is
  v_sysdate  date := SYSDATE;

  begin
    delete tt_numbers;

    for i in nvl(p_personal_account_numbers.first, 1)..nvl( p_personal_account_numbers.last, 0)
    loop
      insert into tt_numbers(id,value)
        values (i, p_personal_account_numbers(i));
    end loop;

    open p_hosts for
      select /*+ ordered use_nl(pah h) full(tt) index(pah I_PA_PERSONAL_ACCOUNT_HISTORY) index(h PK_HOST)*/
             h.host_id,
             h.host_code,
             h.host_name,
             h.host_type_code
        from tt_numbers tt
             left join personal_account_history pah on (pah.personal_account = tt.value
                                                        and pah.end_date is null
                                                        and v_sysdate between pah.start_date and nvl(pah.end_date, v_sysdate)
                                                        )
             left join host h on h.host_id = pah.balance_storage
                   and (h.deleted is null or h.deleted > sysdate)
       order by tt.id;

    commit;
    p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
    p_error_message := 'Succesfully completed';
  exception
    when others then
      rollback;
      p_error_code := sqlcode;
      p_error_message := sqlerrm;
  end;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Balance_Storage_by_PA
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Balance_Storage_by_PA(
  p_PA_list                IN  t_personal_account,
  p_start_date             IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_personal_account     number;
  v_sqlcode              number;
  v_event_source         varchar2(60) := 'Get_Balance_Storage_by_PA';
  v_start_date           DATE:=nvl(p_start_date, SYSDATE);
  v_pa_host_obj          T_PA_HOST_OBJ := T_PA_HOST_OBJ(NULL, NULL);
  v_pa_list              T_PA_HOST_OBJ_TAB := T_PA_HOST_OBJ_TAB();

BEGIN
    RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
    -- check handle_tran parameter

    IF (p_PA_list.COUNT=0) OR (p_PA_list.COUNT = 1 AND p_PA_list(p_PA_list.FIRST) IS NULL) THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameter (p_PA_list)');
    END IF;

-- start of the procedure body --------------------------------------------------------------------------------------------------

  FOR i IN nvl(p_PA_list.FIRST, 1) .. nvl(p_PA_list.LAST, 0)
  loop
    v_personal_account := p_PA_list(i);
    v_pa_host_obj.personal_account := v_personal_account;
    v_pa_host_obj.host_id := null;
    v_pa_list.extend;
    v_pa_list(i) := v_pa_host_obj;
  end loop;

  OPEN p_result_list FOR
  SELECT /*+ index(pah PK_PER_ACCOUNT_HISTORY) index(h PK_HOST) use_nl(T SC PAH H)*/
         t.personal_account as personal_account,
         h.host_id as host_id,
         h.host_code as host_code,
         h.host_name as host_name,
         h.host_address as host_address,
         h.host_location as host_location,
         trim(h.host_type_code) as host_type_code,
         h.network_operator_id as network_operator_id,
         h.time_zone as time_zone,
         h.dst_rule_id as dst_rule_id,
         nvl(h.parent_host_id, h.host_id) parent_host_id
  FROM TABLE(CAST(v_pa_list AS T_PA_HOST_OBJ_TAB)) t
  LEFT JOIN personal_account_history pah ON pah.personal_account = t.personal_account
       AND v_start_date BETWEEN pah.start_date AND nvl(pah.end_date, v_start_date)
  LEFT JOIN host h ON h.host_id = pah.balance_storage;

  COMMIT;
-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  p_error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);

EXCEPTION
  WHEN OTHERS THEN
        v_sqlcode := sqlcode;
        p_error_message := sqlerrm;
        --DBMS_OUTPUT.PUT_LINE(error_message);
        p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
        RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, v_event_source);
        OPEN p_result_list FOR SELECT v_sqlcode, p_error_message FROM dual;
        IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
            RAISE;
        END IF;
END Get_Balance_Storage_by_PA;

END;
/
