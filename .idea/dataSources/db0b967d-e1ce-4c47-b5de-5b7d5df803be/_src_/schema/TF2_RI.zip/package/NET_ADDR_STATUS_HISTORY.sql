CREATE PACKAGE NET_ADDR_STATUS_HISTORY IS

----------------------------------!---------------------------------------------
FUNCTION Is_Status_Change_Allowed(
  p_network_address_id        IN   network_address.network_address_id%TYPE,
  p_new_status                IN   network_address_status_history.net_address_status_code%TYPE,
  p_IS_BP                     IN   VARCHAR2,
  p_date                      IN   DATE,
  p_internal_allowed          IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
)RETURN INT;

----------------------------------!---------------------------------------------
PROCEDURE Check_Phone_Status_Change(
  p_phone_status    IN  phone_number.net_address_status_code%TYPE,
  p_date            IN  DATE
);

----------------------------------!---------------------------------------------
PROCEDURE Exist_Status_Code(
  p_status_code IN network_address_status_history.net_address_status_code%TYPE
);

----------------------------------!---------------------------------------------
FUNCTION Lock_Phone(
  p_international_format  IN  phone_number.international_format%TYPE
) RETURN INT;

----------------------------------!---------------------------------------------
FUNCTION Fnc_Exist_Status_Code(
  p_status_code IN network_address_status_history.net_address_status_code%TYPE
) return INT;

----------------------------------!---------------------------------------------
FUNCTION F_Exist_Transition_Reason_Code(
  p_status             IN  network_address_status_history.net_address_status_code%TYPE,
  p_phone_Tran_Reason  IN  network_address_status_history.na_trans_reason_code%TYPE
) RETURN INT;

----------------------------------!---------------------------------------------
END;
/
