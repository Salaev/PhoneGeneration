CREATE package UTIL_SYS_PKG is

----------------------------------!---------------------------------------------
  c_savepoint_name_prefix        constant varchar2(2) := 'sp';

  c_max_sp_enumerator_length     constant number := 28; --!_! 28 of 9 is max value of sequence(nomaxvalue equivalent)

----------------------------------!---------------------------------------------
  function get_str_tail(p_val varchar2, p_length integer) return varchar2;
  function get_savepoint_enumerator return varchar2;
  function make_unique_savepoint_name return varchar2;
  function make_savepoint return varchar2;
  procedure rollback_savepoint(p_savepoint_name varchar2);

----------------------------------!---------------------------------------------
end;
/
