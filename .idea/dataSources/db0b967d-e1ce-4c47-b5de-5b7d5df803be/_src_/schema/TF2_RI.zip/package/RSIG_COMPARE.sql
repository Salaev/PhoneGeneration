CREATE PACKAGE          "RSIG_COMPARE" IS

  -- Author  : JAroslav Holub
  -- Created : 26.1.2005 14:56:53
  -- Purpose : package for comparing tables data in schemes on diferent database

  TYPE t_col_v2_50 IS TABLE OF VARCHAR2(50);

  PROCEDURE Get_minus_select
  (
    p_select_local  IN VARCHAR2,
    p_select_remote IN VARCHAR2,
    p_db_link       IN VARCHAR2,
    p_raise_error   IN CHAR,
    ERROR_CODE      OUT NUMBER,
    error_message   OUT VARCHAR2,
    result_list     OUT sys_refcursor
  );

  PROCEDURE Get_PK_columns
  (
    p_table_name  IN VARCHAR2,
    p_db_link     IN VARCHAR2,
    p_raise_error IN CHAR,
    ERROR_CODE    OUT NUMBER,
    error_message OUT VARCHAR2,
    result_list   OUT sys_refcursor
  );
  PROCEDURE Get_nonPK_columns
  (
    p_table_name  IN VARCHAR2,
    p_db_link     IN VARCHAR2,
    p_raise_error IN CHAR,
    ERROR_CODE    OUT NUMBER,
    error_message OUT VARCHAR2,
    result_list   OUT sys_refcursor
  );

  PROCEDURE Get_all_columns
  (
    p_table_name  IN VARCHAR2,
    p_db_link     IN VARCHAR2,
    p_raise_error IN CHAR,
    ERROR_CODE    OUT NUMBER,
    error_message OUT VARCHAR2,
    result_list   OUT sys_refcursor
  );

  PROCEDURE Create_select_statement(
                                    
                                    p_table_name  IN VARCHAR2,
                                    p_db_link     IN VARCHAR2,
                                    p_all_columns IN CHAR,
                                    p_raise_error IN CHAR,
                                    ERROR_CODE    OUT NUMBER,
                                    error_message OUT VARCHAR2,
                                    p_sql_string  OUT VARCHAR2);

END RSIG_COMPARE;


/
