CREATE package API_RI_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure Set_Phone_Status_i
  (
    p_msisdn ct_varchar_s,
    p_set_phone_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  );

  procedure Set_Phone_Status
  (
    p_msisdn util_pkg.cit_varchar_s,
    p_set_phone_status varchar2,
    p_date date,
    p_user_nt_name varchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure Get_Roaming_Type
  (
    p_id util_pkg.cit_number,
    p_msisdn util_pkg.cit_varchar_s,
    p_validity_date util_pkg.cit_date,
    p_msc util_pkg.cit_varchar_s,
    p_lac util_pkg.cit_varchar_s,
    p_cell util_pkg.cit_varchar_s,
    p_mcc util_pkg.cit_varchar_s,
    p_mnc util_pkg.cit_varchar_s,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure get_salability_cat_rules
  (
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure GetPhonesByStatusAndSimCard -- FindFreeMainNoPhoneLinkPhoneNumbersForSimCard
  (
    p_iccid varchar2,
    p_phone_type varchar2,
    p_salability_category util_pkg.cit_varchar_s,
    p_series_id number,
    p_mask varchar2,
    p_phone_number_count number,
    p_user_login varchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure GetSimCardStatusHistoryChanges
  (
    p_iccid varchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure get_rn_by_imsi
  (
    p_imsis util_pkg.cit_varchar_s,
    p_date util_pkg.cit_date,
    p_empty_date number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure get_rn_by_msisdn
  (
    p_msisdns util_pkg.cit_varchar_s,
    p_date util_pkg.cit_date,
    p_empty_date number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure get_rn_settings
  (
    rn_prefix_val out varchar2,
    rn_total_length out number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure delete_objects
  (
    p_ids util_pkg.cit_number,
    p_codes util_pkg.cit_varchar_s,
    p_extended_codes util_pkg.cit_varchar_s,
    p_type_codes util_pkg.cit_varchar_s,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure create_routing_number
  (
    p_rn_codes util_pkg.cit_varchar_s,
    p_rn_names util_pkg.cit_nvarchar,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure update_routing_number
  (
    p_rn_ids util_pkg.cit_number,
    p_rn_codes util_pkg.cit_varchar_s,
    p_rn_names util_pkg.cit_nvarchar,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure create_dst_rule
  (
    p_dst_rule_names util_pkg.cit_varchar,
    p_country_code util_pkg.cit_varchar_s,
    p_date_start_rule_masks util_pkg.cit_varchar_s,
    p_date_starts util_pkg.cit_varchar_s,
    p_date_end_rule_masks util_pkg.cit_varchar_s,
    p_date_ends util_pkg.cit_varchar_s,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure update_dst_rule
  (
    p_dst_rule_ids util_pkg.cit_number,
    p_dst_rule_names util_pkg.cit_varchar,
    p_country_code util_pkg.cit_varchar_s,
    p_date_start_rule_masks util_pkg.cit_varchar_s,
    p_date_starts util_pkg.cit_varchar_s,
    p_date_end_rule_masks util_pkg.cit_varchar_s,
    p_date_ends util_pkg.cit_varchar_s,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure create_network_operator
  (
    p_network_operator_codes util_pkg.cit_varchar_s,
    p_network_operator_names util_pkg.cit_varchar,
    p_network_operator_types util_pkg.cit_varchar_s,
    p_personal_account util_pkg.cit_varchar_s,
    p_uprs_member_codes util_pkg.cit_varchar_s,
    --!_!p_replicated_region_ids util_pkg.cit_number,
    p_country util_pkg.cit_number,
    p_mcc util_pkg.cit_varchar_s,
    p_mnc util_pkg.cit_varchar_s,
    p_time_zones util_pkg.cit_number,
    p_network_operator_id_uppers util_pkg.cit_number,
    p_dst_rule_ids util_pkg.cit_number,
    p_routing_number_ids util_pkg.cit_number,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure update_network_operator
  (
    p_network_operator_ids util_pkg.cit_number,
    p_network_operator_codes util_pkg.cit_varchar_s,
    p_network_operator_names util_pkg.cit_varchar,
    p_network_operator_types util_pkg.cit_varchar_s,
    p_personal_account util_pkg.cit_varchar_s,
    p_uprs_member_codes util_pkg.cit_varchar_s,
    --!_!p_replicated_region_ids util_pkg.cit_number,
    p_country util_pkg.cit_number,
    p_mcc util_pkg.cit_varchar_s,
    p_mnc util_pkg.cit_varchar_s,
    p_time_zones util_pkg.cit_number,
    p_network_operator_id_uppers util_pkg.cit_number,
    p_dst_rule_ids util_pkg.cit_number,
    p_routing_number_ids util_pkg.cit_number,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure create_zone
  (
    p_zone_codes util_pkg.cit_varchar_s,
    p_zone_names util_pkg.cit_varchar,
    p_zone_type_codes util_pkg.cit_varchar_s,
    p_network_operator_ids util_pkg.cit_number,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure update_zone
  (
    p_zone_ids util_pkg.cit_number,
    p_zone_codes util_pkg.cit_varchar_s,
    p_zone_names util_pkg.cit_varchar,
    p_zone_type_codes util_pkg.cit_varchar_s,
    p_network_operator_ids util_pkg.cit_number,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure create_host
  (
    p_host_codes util_pkg.cit_varchar_s,
    p_host_names util_pkg.cit_varchar,
    p_host_addresses util_pkg.cit_varchar,
    p_host_locations util_pkg.cit_varchar,
    p_host_type_codes util_pkg.cit_varchar_s,
    p_time_zones util_pkg.cit_number,
    p_network_operator_ids util_pkg.cit_number,
    p_dst_rule_ids util_pkg.cit_number,
    p_routing_number_ids util_pkg.cit_number,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure update_host
  (
    p_host_ids util_pkg.cit_number,
    p_host_codes util_pkg.cit_varchar_s,
    p_host_names util_pkg.cit_varchar,
    p_host_addresses util_pkg.cit_varchar,
    p_host_locations util_pkg.cit_varchar,
    p_host_type_codes util_pkg.cit_varchar_s,
    p_time_zones util_pkg.cit_number,
    p_network_operator_ids util_pkg.cit_number,
    p_dst_rule_ids util_pkg.cit_number,
    p_routing_number_ids util_pkg.cit_number,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure get_routing_number
  (
    p_empty_ids_codes number,
    p_ids util_pkg.cit_number,
    p_codes util_pkg.cit_varchar_s,
    p_date date,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure get_dst_rule
  (
    p_empty_ids_codes number,
    p_ids util_pkg.cit_number,
    p_codes util_pkg.cit_varchar_s,
    p_date date,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure get_network_operator
  (
    p_empty_ids_codes number,
    p_ids util_pkg.cit_number,
    p_codes util_pkg.cit_varchar_s,
    p_uprs_member_codes util_pkg.cit_varchar_s,
    p_date date,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure get_zone
  (
    p_empty_ids_codes number,
    p_ids util_pkg.cit_number,
    p_codes util_pkg.cit_varchar_s,
    p_date date,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure get_host
  (
    p_empty_ids_codes number,
    p_ids util_pkg.cit_number,
    p_codes util_pkg.cit_varchar_s,
    p_date date,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure get_all_def_abc_rule
  (
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure delete_def_abc_rule
  (
    p_ids util_pkg.cit_number,
    p_user_name varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure delete_def_abc_rule2
  (
    p_id number,
    p_user_name varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure create_def_abc_rule
  (
    p_defs util_pkg.cit_varchar_s,
    p_abcs util_pkg.cit_varchar_s,
    p_user_name varchar2,
    --!_!p_out_ids out ct_number,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure create_def_abc_rule2
  (
    p_def varchar2,
    p_abc varchar2,
    p_user_name varchar2,
    p_out_id out number,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure update_def_abc_rule
  (
    p_ids util_pkg.cit_number,
    p_defs util_pkg.cit_varchar_s,
    p_abcs util_pkg.cit_varchar_s,
    p_user_name varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure update_def_abc_rule2
  (
    p_id number,
    p_def varchar2,
    p_abc varchar2,
    p_user_name varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure get_phone_number_with_rn_info
  (
    p_nn util_pkg.cit_varchar_s,
    p_date date,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure get_phone_number_type_by_pa
 (
    p_personal_accounts util_pkg.cit_number,
    p_min_date_of_used date,
    p_only_main_msisdn number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure mnp_port_in
  (
    p_msisdn varchar2,
    p_iccid varchar2,
    p_user_name varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure mnp_port_out
  (
    p_msisdn varchar2,
    p_user_name varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  --!_!both mnp and template belong to internal operators
  procedure check4change_main_net_op
  (
    p_msisdn_mnp varchar2,
    p_msisdn_template varchar2,
    p_user_name varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  --!_!both mnp and template belong to internal operators
  procedure change_main_net_op4phone_num
  (
    p_msisdn_mnp varchar2,
    p_msisdn_template varchar2,
    p_user_name varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure get_proper_hlr2
  (
    p_msisdn varchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure is_mnp_port_in_valid2
  (
    p_msisdn_mnp varchar2,
    p_msisdn_template varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure get_phone_number_decomposition
  (
    p_pn_list util_pkg.cit_varchar_s,
    p_error_code out number,
    p_error_message out varchar2,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure create_virtual_sim_and_link_pa
  (
    p_msisdns util_pkg.cit_varchar_s,
    p_set_na_status util_pkg.cit_varchar_s,
    p_personal_accounts util_pkg.cit_number,
    p_user_name varchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure create_virtual_sim
  (
    p_msisdns util_pkg.cit_varchar_s,
    p_user_name varchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure mnp_phone_get_back_to_foris
  (
    p_msisdn varchar2,
    p_user_name varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure get_next_ready2return_phones
  (
    p_batch_id out number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure confirm_return_phone_batch
  (
    p_batch_id number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure set_ph_st_and_reset_reserve
  (
    p_msisdns util_pkg.cit_varchar_s,
    p_status varchar2,
    p_user_name varchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function ins_agroup_data
  (
    p_error_code out number,
    p_error_message out varchar2,
    p_commit number,
    p_agroup_id number,
    p_id1 number,
    p_id2 number,
    p_user_id number
  ) return number;

  procedure upd_agroup_data
  (
    p_error_code out number,
    p_error_message out varchar2,
    p_commit number,
    p_agroup_data_id number,
    p_agroup_id number,
    p_id1 number,
    p_id2 number,
    p_user_id number
  );

  procedure del_agroup_data
  (
    p_error_code out number,
    p_error_message out varchar2,
    p_commit number,
    p_agroup_data_id number,
    p_user_id number
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure get_phone_info
  (
    p_msisdn util_pkg.cit_varchar_s,
    p_result out sys_refcursor
  );

  procedure get_main_host_by_iccid
  (
    p_iccid util_pkg.cit_varchar_s,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure get_timer_manager_setting
  (
    p_task_list_id number,
    p_timer_period out number,
    p_timer_tasks out sys_refcursor
  );

  function get_ri_crm_task_list_id return number;
  function get_ri_sups_task_list_id return number;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure create_msisdn_by_number_for_ps
  (
    p_msisdns util_pkg.cit_varchar_s,
    p_date_reserved date,
    p_user_name varchar2,
    p_reserve_number out number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure open_network_operator_srvc
  (
    p_no_id number,
    p_svc_code varchar2,
    p_date_from date,
    p_date_to date,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure close_network_operator_srvc
  (
    p_no_id number,
    p_svc_code varchar2,
    p_old_date_from date,
    p_old_date_to date,
    p_date_from date,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure get_network_operator_srvc
  (
    p_no_id integer,
    p_date date,
    p_no_date number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure get_uprs_member_code_by_phone
  (
    p_msisdn varchar2,
    p_validity_date date,
    p_uprs_member_code out varchar2,
    p_net_operator_name out varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure create_sim_cards
  (
    p_msisdn_list util_pkg.cit_varchar_s,
    p_iccid_list util_pkg.cit_varchar_s,
    p_pin_list util_pkg.cit_varchar_s,
    p_pin2_list util_pkg.cit_varchar_s,
    p_puk_list util_pkg.cit_varchar_s,
    p_puk2_list util_pkg.cit_varchar_s,
    p_ki_list util_pkg.cit_nvarchar_s,
    p_auth_type_list util_pkg.cit_varchar_s,
    p_sim_card_type_code varchar2,
    p_user_nt_name varchar2,
    p_handle_tran char default util_ri.c_tran_yes,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor,
    p_error_list out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure cancel_param_sim_cards
  (
    p_iccid_list util_pkg.cit_varchar_s,
    p_user_nt_name varchar2,
    p_handle_tran char default util_ri.c_tran_yes,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure get_series_cont_free_phones3
  (
    p_host_id util_pkg.cit_number,
    p_host_empty number,
    p_network_operator_code varchar2,
    p_phone_number_type varchar2,
    p_salability_category util_pkg.cit_varchar_s,
    p_phone_number_status_code util_pkg.cit_varchar_s,
    p_link_status number,
    p_result_list out sys_refcursor
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure get_abc_rule_result
  (
    p_def_msisdn varchar2,
    p_abc_msisdn out varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure get_abc_rule_result_special
  (
    p_msisdn util_pkg.cit_varchar_s,
    p_result_list out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure get_phone_types
  (
    p_error_code out number,
    p_result_list out sys_refcursor
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure get_roaming_cache
  (
    p_cache_guid varchar2,
    p_range_date_from date,
    p_range_date_to date,
    p_error_code out number,
    p_error_message out varchar2,
    p_HostNOs out sys_refcursor,
    p_RoamingTypes out sys_refcursor,
    p_phones out sys_refcursor,
    p_MCCMNCNOs out sys_refcursor,
    p_gone_subscribers out sys_refcursor,
    p_come_in_subscribers out sys_refcursor
  );

  procedure unreg_roam_cache_subscr
  (
    p_cache_guid varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure get_roaming_cache_changes
  (
    p_cache_guid varchar2,
    p_range_date_from date,
    p_range_date_to date,
    p_error_code out number,
    p_error_message out varchar2,
    p_gone_subscribers out sys_refcursor,
    p_come_in_subscribers out sys_refcursor
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure get_imsi_host
  (
    p_imsis util_pkg.cit_varchar_s,
    p_host_type_code varchar2,
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_iccid_host_ex
  (
    p_iccids util_pkg.cit_varchar_s,
    p_host_type_code varchar2,
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_msisdn_host
  (
    p_msisdns util_pkg.cit_varchar_s,
    p_host_type_code varchar2,
    p_date date,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure get_cur_imsi_pahost
  (
    p_imsis util_pkg.cit_varchar_s,
    p_result out sys_refcursor
  );

  procedure get_cur_msisdn_pahost
  (
    p_msisdns util_pkg.cit_varchar_s,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure legacy_link_phone_sim
  (
    p_msisdns util_pkg.cit_varchar_s,
    p_iccids util_pkg.cit_varchar_s,
    p_link_type_code varchar2,
    p_date date,
    p_user_name varchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function get_result_cursor00(p_sys_items ct_sys_item) return sys_refcursor;

  function get_result_cursor98
  (
    p_sys_type_code varchar2,
    p_sys_error_codes ct_number,
    p_sys_error_messages ct_varchar,
    p_sys_ids ct_number,
    p_sys_codes ct_varchar_s
  ) return sys_refcursor;

  function get_result_cursor99
  (
    p_sys_type_codes ct_varchar_s,
    p_sys_error_codes ct_number,
    p_sys_error_messages ct_varchar,
    p_sys_ids ct_number,
    p_sys_codes ct_varchar_s
  ) return sys_refcursor;

----------------------------------!---------------------------------------------
  procedure get_result_cursor01
  (
    p_msisdn ct_varchar_s,
    p_result out sys_refcursor,
    p_error_code ct_number,
    p_error_message ct_varchar
  );

  procedure get_result_cursor02
  (
    p_id ct_number,
    p_roaming_type ct_number,
    p_network_operator_id ct_number,
    p_result out sys_refcursor,
    p_error_code ct_number,
    p_error_message ct_varchar
  );

  function get_result_cursor03
  (
    p_nn ct_varchar_s,
    p_msisdns ct_varchar_s,
    p_rns ct_varchar_s,
    p_network_operator_codes ct_varchar_s,
    p_error_codes ct_number,
    p_error_messages ct_varchar
  ) return sys_refcursor;

  function get_result_cursor04(p_personal_accounts ct_number, p_phone_type ct_varchar_s) return sys_refcursor;

  function get_result_cursor05(p_msisdns ct_varchar_s, p_error_codes ct_number, p_error_messages ct_varchar) return sys_refcursor;

  function get_result_cursor06
  (
    p_msisdns ct_varchar_s,
    p_country_code ct_varchar_s,
    p_area_code ct_varchar_s,
    p_local_phone ct_varchar_s,
    p_error_codes ct_number,
    p_error_messages ct_varchar
  ) return sys_refcursor;

  function get_result_cursor07
  (
    p_msisdns ct_varchar_s,
    p_iccids ct_varchar_s,
    p_imsis ct_varchar_s
  ) return sys_refcursor;

  function get_result_cursor08
  (
    p_msisdns ct_varchar_s,
    p_date_froms ct_date
  ) return sys_refcursor;

  function get_result_cursor10
  (
    p_msisdn_list ct_varchar_s,
    p_iccid_list ct_varchar_s,
    p_pin_list ct_varchar_s,
    p_pin2_list ct_varchar_s,
    p_puk_list ct_varchar_s,
    p_puk2_list ct_varchar_s,
    p_ki_list ct_nvarchar_s,
    p_auth_type_list ct_varchar_s,
    p_imsi ct_varchar_s
  ) return sys_refcursor;

  function get_result_cursor11
  (
    p_msisdn ct_varchar_s,
    p_iccid ct_varchar_s,
    p_error_codes ct_number,
    p_error_messages ct_varchar
  ) return sys_refcursor;

  function get_result_cursor12
  (
    p_iccid ct_varchar_s,
    p_error_codes ct_number,
    p_error_messages ct_varchar
  ) return sys_refcursor;

  function get_result_cursor14
  (
    p_ps_id ct_number,
    p_pn_count ct_number
  ) return sys_refcursor;

  function get_result_cursor15
  (
    p_msisdn ct_varchar_s,
    p_msisdn_abc ct_varchar_s,
    p_type_abc ct_varchar_s,
    p_type_def ct_varchar_s,
    p_error_codes ct_number,
    p_error_messages ct_varchar
  ) return sys_refcursor;


  function get_result_cursor20
  (
    p_id_str ct_varchar_s,
    p_host_id ct_number,
    p_subhost_id ct_number,
    p_date date
  ) return sys_refcursor;

  function get_result_cursor21
  (
    p_id_str ct_varchar_s,
    p_host_id ct_number,
    p_subhost_id ct_number,
    p_no_id ct_number,
    p_date date
  ) return sys_refcursor;

  function get_result_cursor22
  (
    p_id_str ct_varchar_s,
    p_host_id ct_number,
    p_date date
  ) return sys_refcursor;

  function get_result_cursor22_legacy
  (
    p_id_str ct_varchar_s,
    p_host_id ct_number,
    p_date date
  ) return sys_refcursor;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function get_cursor4ct_varchar_s(p_vals ct_varchar_s) return sys_refcursor;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
