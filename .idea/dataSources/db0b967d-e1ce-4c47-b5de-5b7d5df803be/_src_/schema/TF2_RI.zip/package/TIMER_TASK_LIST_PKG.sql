CREATE package TIMER_TASK_LIST_PKG is

----------------------------------!---------------------------------------------
  c_agroup_id_crm_timer_tasks    constant number := 1103;
  c_agroup_id_sups_timer_tasks   constant number := 1104;

  c_agroup_name_crm_timer_tasks  constant nvarchar2(255) := 'CRM_TIMER_TASK_LIST';
  c_agroup_name_sups_timer_tasks constant nvarchar2(255) := 'SUPS_TIMER_TASK_LIST';

----------------------------------!---------------------------------------------
  c_sett_timer_period_val        constant varchar2(100) := 'TIMER_TASK_MANAGER_CALLBACK_PERIOD';

----------------------------------!---------------------------------------------
  c_def_timer_period_val         constant integer := 60000; --!_! milliseconds

----------------------------------!---------------------------------------------
  function get_timer_period_val return number;

----------------------------------!---------------------------------------------
  procedure add_task
  (
    p_agroup_id number,
    p_task_name varchar2,
    p_period integer,
    p_delay_start boolean,
    p_user_id number
  );

  procedure del_task
  (
    p_agroup_id number,
    p_task_name varchar2,
    p_user_id number
  );

  procedure get_task_list
  (
    p_agroup_id number,
    p_date date,
    p_task_name out ct_varchar,
    p_period out ct_number,
    p_delay_start out ct_number
  );

  procedure get_task_list2
  (
    p_agroup_id number,
    p_task_name out ct_varchar,
    p_period out ct_number,
    p_delay_start out ct_number
  );

----------------------------------!---------------------------------------------
  function is_exist
  (
    p_agroup_id number,
    p_task_name varchar2,
    p_date date
  ) return boolean;

  function is_exist2
  (
    p_agroup_id number,
    p_task_name varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  procedure get_task_list_cursor
  (
    p_agroup_id number,
    p_timer_tasks out sys_refcursor
  );

----------------------------------!---------------------------------------------
  function get_result_cursor01
  (
    p_task_name ct_varchar,
    p_period ct_number,
    p_delay_start ct_number
  ) return sys_refcursor;

----------------------------------!---------------------------------------------

end;
/
