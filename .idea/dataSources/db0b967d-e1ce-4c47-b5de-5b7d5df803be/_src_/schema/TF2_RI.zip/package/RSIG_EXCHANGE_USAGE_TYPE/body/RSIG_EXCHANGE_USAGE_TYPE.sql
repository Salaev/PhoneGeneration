CREATE PACKAGE BODY          "RSIG_EXCHANGE_USAGE_TYPE" is

---------------------------------------------
--     PROCEDURE Get_Exchange_Usage_Type
---------------------------------------------

PROCEDURE Get_Exchange_Usage_Type
(
  error_code OUT NUMBER,
  p_result   OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE_USAGE_TYPE.Get_Exchange_Usage_Type';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_result FOR
    SELECT exchange_usage_type_code,
           exchange_usage_type_name
      FROM exchange_usage_type
     ORDER BY exchange_usage_type_name;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_result FOR
        select error_code from dual;
    END;

END Get_Exchange_usage_type;


PROCEDURE Get_Exchange_Usage_Type2
(
  p_host_type_code  IN  VARCHAR2,
  error_code        OUT NUMBER,
  p_result          OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE_USAGE_TYPE.Get_Exchange_Usage_Type';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_result FOR
    SELECT exchange_usage_type_code,
           exchange_usage_type_name
      FROM exchange_usage_type
     WHERE host_type = p_host_type_code OR host_type IS NULL
     ORDER BY exchange_usage_type_name;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_result FOR
        select error_code from dual;
    END;

END Get_Exchange_usage_type2;

end RSIG_EXCHANGE_USAGE_TYPE;
/
