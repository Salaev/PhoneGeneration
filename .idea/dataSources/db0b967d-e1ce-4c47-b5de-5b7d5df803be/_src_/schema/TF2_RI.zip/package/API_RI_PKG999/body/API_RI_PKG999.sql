CREATE package body API_RI_PKG999 is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Set_Phone_Status_i
(
    p_msisdn ct_varchar_s,
    p_set_phone_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
)
is
  v_res_set_na_status boolean;
  v_na_id ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
  v_mark_01 ct_number;
  v_found_na_id ct_number;
  v_map_01 ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_varchar_s(p_msisdn, 'p_msisdn');
  util_pkg.XCheck_Cond_Missing(p_set_phone_status is null, 'p_set_phone_status is null');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date is null');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id is null');
  ------------------------------
  util_ext_ri.setup_common_error(util_pkg.get_count_ct_varchar_s(p_msisdn), util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found, p_error_code, p_error_message);
  ------------------------------
  v_na_id := util_ri.get_na_id(p_msisdn, p_date, false, true);
  ------------------------------
  v_mark_01 := util_pkg.mark_val_ct_number(v_na_id, null, util_pkg.c_true, util_pkg.c_false);
  v_found_na_id := util_pkg.get_marked_ct_number(v_na_id, v_mark_01, true, util_pkg.c_false, null);
  ------------------------------
  v_map_01 := util_pkg.map_ct_number(v_found_na_id, v_na_id, TRUE, FALSE);
  ------------------------------
  v_res_set_na_status := util_ext_ri.set_na_status2
  (
    p_na_id => v_na_id,
    p_status => p_set_phone_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_pn => p_lock_pn,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  util_pkg.set_by_pos_ct_number(p_error_code, v_error_code, v_map_01);
  util_pkg.set_by_pos_ct_varchar(p_error_message, v_error_message, v_map_01);
  ------------------------------
  util_loc_pkg.touch_boolean(v_res_set_na_status);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Set_Phone_Status
(
    p_msisdn util_pkg.cit_varchar_s,
    p_set_phone_status varchar2,
    p_date date,
    p_user_nt_name varchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := nvl(p_date, sysdate);
  v_user_id number;
  v_msisdn ct_varchar_s;
  v_error_code ct_number;
  v_error_message ct_varchar;
  v_mark_01 ct_number;
begin
  ------------------------------
  util_pkg.xis_nulls_cit_varchar_s(p_msisdn, false);
  util_pkg.XCheck_Cond_Missing(p_set_phone_status is null, 'p_set_phone_status is null');
  ------------------------------
  v_user_id := util_ri.xget_user_id(p_user_nt_name);
  ------------------------------
  v_msisdn := util_pkg.cast_cit2ct_varchar_s(p_msisdn, false);
  ------------------------------
  Set_Phone_Status_i
  (
    p_msisdn => v_msisdn,
    p_set_phone_status => p_set_phone_status,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => false,
    p_lock_pn => true,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  v_mark_01 := util_pkg.mark_val_ct_number(v_error_code, util_pkg.c_ora_ok, util_pkg.c_true, util_pkg.c_false);
  ------------------------------
  v_msisdn := util_pkg.get_marked_ct_varchar_s(v_msisdn, v_mark_01, true, util_pkg.c_false, null);
  v_error_code := util_pkg.get_marked_ct_number(v_error_code, v_mark_01, true, util_pkg.c_false, null);
  v_error_message := util_pkg.get_marked_ct_varchar(v_error_message, v_mark_01, true, util_pkg.c_false, null);
  ------------------------------
  get_result_cursor01
  (
    p_msisdn => v_msisdn,
    p_result => p_result,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_salability_cat_rules
(
  p_result out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  api_ri_i_pkg.get_salability_cat_rules(p_result);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Get_Roaming_Type
(
    p_id util_pkg.cit_number,
    p_msisdn util_pkg.cit_varchar_s,
    p_validity_date util_pkg.cit_date,
    p_msc util_pkg.cit_varchar_s,
    p_lac util_pkg.cit_varchar_s,
    p_cell util_pkg.cit_varchar_s,
    p_mcc util_pkg.cit_varchar_s,
    p_mnc util_pkg.cit_varchar_s,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_id ct_number;
  v_msisdn ct_varchar_s;
  v_validity_date ct_date;
  v_msc ct_varchar_s;
  v_lac ct_varchar_s;
  v_cell ct_varchar_s;
  v_mcc ct_varchar_s;
  v_mnc ct_varchar_s;
  v_roaming_type ct_number;
  v_network_operator_id ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.xis_nulls_cit_number(p_id, false, 'p_id');
  util_pkg.xis_nulls_cit_varchar_s(p_msisdn, false, 'p_msisdn');
  util_pkg.xis_nulls_cit_date(p_validity_date, false, 'p_validity_date');
  util_pkg.xis_nulls_cit_varchar_s(p_msc, false, 'p_msc');
  ------------------------------
  v_id := util_pkg.cast_cit2ct_number(p_id, false);
  v_msisdn := util_pkg.cast_cit2ct_varchar_s(p_msisdn, false);
  v_validity_date := util_pkg.cast_cit2ct_date(p_validity_date, false);
  v_msc := util_pkg.cast_cit2ct_varchar_s(p_msc, false);
  v_lac := util_pkg.cast_cit2ct_varchar_s(p_lac, false);
  v_cell := util_pkg.cast_cit2ct_varchar_s(p_cell, false);
  v_mcc := util_pkg.cast_cit2ct_varchar_s(p_mcc, false);
  v_mnc := util_pkg.cast_cit2ct_varchar_s(p_mnc, false);
  ------------------------------
  hlb_pkg.Get_Roaming_Type_i
  (
    p_msisdn => v_msisdn,
    p_validity_date => v_validity_date,
    p_msc => v_msc,
    p_lac => v_lac,
    p_cell => v_cell,
    p_mcc => v_mcc,
    p_mnc => v_mnc,
    p_roaming_type => v_roaming_type,
    p_network_operator_id => v_network_operator_id,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  get_result_cursor02
  (
    p_id => v_id,
    p_roaming_type => v_roaming_type,
    p_network_operator_id => v_network_operator_id,
    p_result => p_result,
    p_error_code  => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure GetPhonesByStatusAndSimCard -- FindFreeMainNoPhoneLinkPhoneNumbersForSimCard
(
    p_iccid varchar2,
    p_phone_type varchar2,
    p_salability_category util_pkg.cit_varchar_s,
    p_series_id number,
    p_mask varchar2,
    p_phone_number_count number,
    p_user_login varchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date;
  --
  v_m_na_id ct_number;
  --
  v_ap_id number;
  v_ap_host_id number;
  v_host_network_operator_id number;
  v_host_id util_pkg.cit_varchar_s;
  v_l_na_id ct_number;
  v_network_operator_code varchar2(50);
  --
  v_use_linked number;
  v_phone_number_status_code util_pkg.cit_varchar_s;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_iccid is null, 'p_iccid');
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  v_use_linked := util_ri.c_link2_status_free;
  v_phone_number_status_code(util_ri.c_index_one) := util_ri.c_NASH_CODE_FREE;
  ------------------------------
  v_ap_id := util_ri.get_ap_id2(p_iccid, v_date);
  util_pkg.XCheck_Cond_Invalid(v_ap_id is null, 'v_ap_id');
  ------------------------------
  v_ap_host_id := util_ri.get_ap_host_id2(v_ap_id, v_date);
  util_pkg.XCheck_Cond_Invalid(v_ap_host_id is null, 'v_ap_host_id');
  ------------------------------
  v_host_id(1) := util_pkg.number_to_char(v_ap_host_id);
  ------------------------------
  v_host_network_operator_id := util_ri.get_host_network_operator2(v_ap_host_id, v_date);
  util_pkg.XCheck_Cond_Invalid(v_host_network_operator_id is null, 'v_host_network_operator_id');
  ------------------------------
  v_network_operator_code := util_ri.get_network_operator_code2(v_host_network_operator_id, v_date);
  util_pkg.XCheck_Cond_Invalid(v_network_operator_code is null, 'p_network_operator_id');
  ------------------------------
  search_pkg.GetPhonesByStatus2_i
  (
    p_host_id => v_host_id,
    p_network_operator_code => v_network_operator_code,
    p_phone_type => p_phone_type,
    p_salability_category => p_salability_category,
    p_series_id => p_series_id,
    p_mask => p_mask,
    p_use_linked => v_use_linked,
    p_phone_number_status_code => v_phone_number_status_code,
    p_set_phone_number_status_code => null,
    p_startingrow => null,
    p_phone_number_count => p_phone_number_count,
    p_user_login => p_user_login,
    p_m_na_id => v_m_na_id
  );
  ------------------------------
  search_pkg.get_result_cursor03(v_m_na_id, v_l_na_id, v_date, search_pkg.map_types_srch2tpns(search_pkg.c_srch_type_single), p_result);
  ------------------------------
  COMMIT;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;
  ------------------------------
  ROLLBACK;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure GetSimCardStatusHistoryChanges
(
    p_iccid varchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_iccid is null, 'p_iccid');
  ------------------------------
  api_ri_i_pkg.GetSimCardStatusHistChanges
  (
    p_iccid => p_iccid,
    p_result => p_result
  );
  ------------------------------
  COMMIT;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;
  ------------------------------
  ROLLBACK;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_rn_by_imsi
(
    p_imsis util_pkg.cit_varchar_s,
    p_date util_pkg.cit_date,
    p_empty_date number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_empty_date boolean;
  v_imsis ct_varchar_s;
  v_date ct_date;
  v_rn_codes ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheckP_cit_varchar_s(p_imsis, 'p_imsis', true);
  util_pkg.XCheck_Cond_Missing(p_empty_date is null, 'p_empty_date');
  ------------------------------
  v_empty_date := util_pkg.int_to_bool_2val(p_empty_date);
  ------------------------------
  v_imsis := util_pkg.cast_cit2ct_varchar_s(p_imsis, true);
  if v_empty_date
  then
    v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_varchar_s(v_imsis), NULL);
  else
    v_date := util_pkg.cast_cit2ct_date(p_date, false);
  end if;
  ------------------------------
  v_rn_codes := mnp_pkg.get_rn_code4imsi(v_imsis, v_date, FALSE);
  ------------------------------
  p_result := get_cursor4ct_varchar_s(v_rn_codes);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_rn_by_msisdn
(
    p_msisdns util_pkg.cit_varchar_s,
    p_date util_pkg.cit_date,
    p_empty_date number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_empty_date boolean := util_pkg.int_to_bool_2val(p_empty_date);
  v_msisdns ct_varchar_s;
  v_date ct_date;
  v_rn_codes ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheckP_cit_varchar_s(p_msisdns, 'p_msisdns', true);
  util_pkg.XCheck_Cond_Missing(p_empty_date is null, 'p_empty_date');
  ------------------------------
  v_empty_date := util_pkg.int_to_bool_2val(p_empty_date);
  ------------------------------
  v_msisdns := util_pkg.cast_cit2ct_varchar_s(p_msisdns, true);
  if v_empty_date
  then
    v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_varchar_s(v_msisdns), NULL);
  else
    v_date := util_pkg.cast_cit2ct_date(p_date, false);
  end if;
  ------------------------------
  v_rn_codes := mnp_pkg.get_rn_code4msisdn(v_msisdns, v_date, FALSE);
  ------------------------------
  p_result := get_cursor4ct_varchar_s(v_rn_codes);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_rn_settings
(
    rn_prefix_val out varchar2,
    rn_total_length out number,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  rn_prefix_val := mnp_pkg.xget_rn_prefix_val;
  ------------------------------
  rn_total_length := mnp_pkg.xget_rn_total_length;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure delete_objects
(
    p_ids util_pkg.cit_number,
    p_codes util_pkg.cit_varchar_s,
    p_extended_codes util_pkg.cit_varchar_s,
    p_type_codes util_pkg.cit_varchar_s,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
  v_date date := sysdate;
  --
  v_type_codes ct_varchar_s;
  --
  v_out_ids ct_number;
  v_out_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  v_type_codes := util_pkg.cast_cit2ct_varchar_s(p_type_codes, false);
  ------------------------------
  cocat_pkg.delete_objects
  (
    p_ids => util_pkg.cast_cit2ct_number(p_ids, false),
    p_codes => util_pkg.cast_cit2ct_varchar_s(p_codes, false),
    p_extended_codes => util_pkg.cast_cit2ct_varchar_s(p_extended_codes, false),
    p_type_codes => v_type_codes,
    p_date_from => util_pkg.make_ct_date(util_pkg.get_count_cit_number(p_ids), v_date),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_out_ids => v_out_ids,
    p_out_codes => v_out_codes,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor99
  (
    p_sys_type_codes => v_type_codes,
    p_sys_error_codes => v_error_codes,
    p_sys_error_messages => v_error_messages,
    p_sys_ids => v_out_ids,
    p_sys_codes => v_out_codes
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure create_routing_number
(
    p_rn_codes util_pkg.cit_varchar_s,
    p_rn_names util_pkg.cit_nvarchar,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
  v_date date := sysdate;
  --
  v_type_code varchar2(30) := VP_ROUTING_NUMBER.c_this_name;
  --
  v_out_ids ct_number;
  v_out_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  cocat_pkg.create_routing_number
  (
    p_rn_codes => util_pkg.cast_cit2ct_varchar_s(p_rn_codes, false),
    p_rn_names => util_pkg.cast_cit2ct_nvarchar(p_rn_names, false),
    p_date_from => util_pkg.make_ct_date(util_pkg.get_count_cit_varchar_s(p_rn_codes), v_date),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_out_ids => v_out_ids,
    p_out_codes => v_out_codes,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor98
  (
    p_sys_type_code => v_type_code,
    p_sys_error_codes => v_error_codes,
    p_sys_error_messages => v_error_messages,
    p_sys_ids => v_out_ids,
    p_sys_codes => v_out_codes
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_routing_number
(
    p_rn_ids util_pkg.cit_number,
    p_rn_codes util_pkg.cit_varchar_s,
    p_rn_names util_pkg.cit_nvarchar,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
  v_date date := sysdate;
  --
  v_type_code varchar2(30) := VP_ROUTING_NUMBER.c_this_name;
  --
  v_out_ids ct_number;
  v_out_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  cocat_pkg.update_routing_number
  (
    p_rn_ids => util_pkg.cast_cit2ct_number(p_rn_ids, false),
    p_rn_codes => util_pkg.cast_cit2ct_varchar_s(p_rn_codes, false),
    p_rn_names => util_pkg.cast_cit2ct_nvarchar(p_rn_names, false),
    p_date_from => util_pkg.make_ct_date(util_pkg.get_count_cit_number(p_rn_ids), v_date),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_out_ids => v_out_ids,
    p_out_codes => v_out_codes,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor98
  (
    p_sys_type_code => v_type_code,
    p_sys_error_codes => v_error_codes,
    p_sys_error_messages => v_error_messages,
    p_sys_ids => v_out_ids,
    p_sys_codes => v_out_codes
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_dst_rule
(
    p_dst_rule_names util_pkg.cit_varchar,
    p_country_code util_pkg.cit_varchar_s,
    p_date_start_rule_masks util_pkg.cit_varchar_s,
    p_date_starts util_pkg.cit_varchar_s,
    p_date_end_rule_masks util_pkg.cit_varchar_s,
    p_date_ends util_pkg.cit_varchar_s,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
  --
  v_type_code varchar2(30) := VP_DST_RULE.c_this_name;
  --
  v_out_ids ct_number;
  v_out_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  cocat_pkg.create_dst_rule
  (
    p_dst_rule_names => util_pkg.cast_cit2ct_varchar(p_dst_rule_names, false),
    p_country_code => util_pkg.cast_cit2ct_varchar_s(p_country_code, false),
    p_date_start_rule_masks => util_pkg.cast_cit2ct_varchar_s(p_date_start_rule_masks, false),
    p_date_starts => util_pkg.cast_cit2ct_varchar_s(p_date_starts, false),
    p_date_end_rule_masks => util_pkg.cast_cit2ct_varchar_s(p_date_end_rule_masks, false),
    p_date_ends => util_pkg.cast_cit2ct_varchar_s(p_date_ends, false),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_out_ids => v_out_ids,
    p_out_codes => v_out_codes,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor98
  (
    p_sys_type_code => v_type_code,
    p_sys_error_codes => v_error_codes,
    p_sys_error_messages => v_error_messages,
    p_sys_ids => v_out_ids,
    p_sys_codes => v_out_codes
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_dst_rule
(
    p_dst_rule_ids util_pkg.cit_number,
    p_dst_rule_names util_pkg.cit_varchar,
    p_country_code util_pkg.cit_varchar_s,
    p_date_start_rule_masks util_pkg.cit_varchar_s,
    p_date_starts util_pkg.cit_varchar_s,
    p_date_end_rule_masks util_pkg.cit_varchar_s,
    p_date_ends util_pkg.cit_varchar_s,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
  --
  v_type_code varchar2(30) := VP_DST_RULE.c_this_name;
  --
  v_out_ids ct_number;
  v_out_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  cocat_pkg.update_dst_rule
  (
    p_dst_rule_ids => util_pkg.cast_cit2ct_number(p_dst_rule_ids, false),
    p_dst_rule_names => util_pkg.cast_cit2ct_varchar(p_dst_rule_names, false),
    p_country_code => util_pkg.cast_cit2ct_varchar_s(p_country_code, false),
    p_date_start_rule_masks => util_pkg.cast_cit2ct_varchar_s(p_date_start_rule_masks, false),
    p_date_starts => util_pkg.cast_cit2ct_varchar_s(p_date_starts, false),
    p_date_end_rule_masks => util_pkg.cast_cit2ct_varchar_s(p_date_end_rule_masks, false),
    p_date_ends => util_pkg.cast_cit2ct_varchar_s(p_date_ends, false),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_out_ids => v_out_ids,
    p_out_codes => v_out_codes,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor98
  (
    p_sys_type_code => v_type_code,
    p_sys_error_codes => v_error_codes,
    p_sys_error_messages => v_error_messages,
    p_sys_ids => v_out_ids,
    p_sys_codes => v_out_codes
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_network_operator
(
    p_network_operator_codes util_pkg.cit_varchar_s,
    p_network_operator_names util_pkg.cit_varchar,
    p_network_operator_types util_pkg.cit_varchar_s,
    p_personal_account util_pkg.cit_varchar_s,
    p_uprs_member_codes util_pkg.cit_varchar_s,
    --!_!p_replicated_region_ids util_pkg.cit_number,
    p_country util_pkg.cit_number,
    p_mcc util_pkg.cit_varchar_s,
    p_mnc util_pkg.cit_varchar_s,
    p_time_zones util_pkg.cit_number,
    p_network_operator_id_uppers util_pkg.cit_number,
    p_dst_rule_ids util_pkg.cit_number,
    p_routing_number_ids util_pkg.cit_number,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
  --
  v_type_code varchar2(30) := VP_NETWORK_OPERATOR.c_this_name;
  --
  v_out_ids ct_number;
  v_out_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  cocat_pkg.create_network_operator
  (
    p_network_operator_codes => util_pkg.cast_cit2ct_varchar_s(p_network_operator_codes, false),
    p_network_operator_names => util_pkg.cast_cit2ct_varchar(p_network_operator_names, false),
    p_network_operator_types => util_pkg.cast_cit2ct_varchar_s(p_network_operator_types, false),
    p_personal_account => util_pkg.cast_cit2ct_varchar_s(p_personal_account, false),
    p_deleted => util_pkg.make_ct_date(util_pkg.get_count_cit_varchar_s(p_network_operator_codes), NULL),
    p_network_operator_id_uppers => util_pkg.cast_cit2ct_number(p_network_operator_id_uppers, false),
    p_uprs_member_codes => util_pkg.cast_cit2ct_varchar_s(p_uprs_member_codes, false),
    --!_!p_replicated_region_ids => util_pkg.cast_cit2ct_number(p_replicated_region_ids, false),
    p_country => util_pkg.cast_cit2ct_number(p_country, false),
    p_mcc => util_pkg.cast_cit2ct_varchar_s(p_mcc, false),
    p_mnc => util_pkg.cast_cit2ct_varchar_s(p_mnc, false),
    p_time_zones => util_pkg.cast_cit2ct_number(p_time_zones, false),
    p_dst_rule_ids => util_pkg.cast_cit2ct_number(p_dst_rule_ids, false),
    p_routing_number_ids => util_pkg.cast_cit2ct_number(p_routing_number_ids, false),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_out_ids => v_out_ids,
    p_out_codes => v_out_codes,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor98
  (
    p_sys_type_code => v_type_code,
    p_sys_error_codes => v_error_codes,
    p_sys_error_messages => v_error_messages,
    p_sys_ids => v_out_ids,
    p_sys_codes => v_out_codes
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_network_operator
(
    p_network_operator_ids util_pkg.cit_number,
    p_network_operator_codes util_pkg.cit_varchar_s,
    p_network_operator_names util_pkg.cit_varchar,
    p_network_operator_types util_pkg.cit_varchar_s,
    p_personal_account util_pkg.cit_varchar_s,
    p_uprs_member_codes util_pkg.cit_varchar_s,
    --!_!p_replicated_region_ids util_pkg.cit_number,
    p_country util_pkg.cit_number,
    p_mcc util_pkg.cit_varchar_s,
    p_mnc util_pkg.cit_varchar_s,
    p_time_zones util_pkg.cit_number,
    p_network_operator_id_uppers util_pkg.cit_number,
    p_dst_rule_ids util_pkg.cit_number,
    p_routing_number_ids util_pkg.cit_number,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
  --
  v_type_code varchar2(30) := VP_NETWORK_OPERATOR.c_this_name;
  --
  v_out_ids ct_number;
  v_out_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  cocat_pkg.update_network_operator
  (
    p_network_operator_ids  => util_pkg.cast_cit2ct_number(p_network_operator_ids, false),
    p_network_operator_codes => util_pkg.cast_cit2ct_varchar_s(p_network_operator_codes, false),
    p_network_operator_names => util_pkg.cast_cit2ct_varchar(p_network_operator_names, false),
    p_network_operator_types => util_pkg.cast_cit2ct_varchar_s(p_network_operator_types, false),
    p_personal_account => util_pkg.cast_cit2ct_varchar_s(p_personal_account, false),
    p_deleted => util_pkg.make_ct_date(util_pkg.get_count_cit_number(p_network_operator_ids), NULL),
    p_network_operator_id_uppers => util_pkg.cast_cit2ct_number(p_network_operator_id_uppers, false),
    p_uprs_member_codes => util_pkg.cast_cit2ct_varchar_s(p_uprs_member_codes, false),
    --!_!p_replicated_region_ids => util_pkg.cast_cit2ct_number(p_replicated_region_ids, false),
    p_country => util_pkg.cast_cit2ct_number(p_country, false),
    p_mcc => util_pkg.cast_cit2ct_varchar_s(p_mcc, false),
    p_mnc => util_pkg.cast_cit2ct_varchar_s(p_mnc, false),
    p_time_zones => util_pkg.cast_cit2ct_number(p_time_zones, false),
    p_dst_rule_ids => util_pkg.cast_cit2ct_number(p_dst_rule_ids, false),
    p_routing_number_ids => util_pkg.cast_cit2ct_number(p_routing_number_ids, false),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_out_ids => v_out_ids,
    p_out_codes => v_out_codes,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor98
  (
    p_sys_type_code => v_type_code,
    p_sys_error_codes => v_error_codes,
    p_sys_error_messages => v_error_messages,
    p_sys_ids => v_out_ids,
    p_sys_codes => v_out_codes
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_zone
(
    p_zone_codes util_pkg.cit_varchar_s,
    p_zone_names util_pkg.cit_varchar,
    p_zone_type_codes util_pkg.cit_varchar_s,
    p_network_operator_ids util_pkg.cit_number,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
  --
  v_type_code varchar2(30) := VP_ZONE.c_this_name;
  --
  v_out_ids ct_number;
  v_out_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  cocat_pkg.create_zone
  (
    p_zone_codes => util_pkg.cast_cit2ct_varchar_s(p_zone_codes, false),
    p_zone_names => util_pkg.cast_cit2ct_varchar(p_zone_names, false),
    p_network_operator_ids => util_pkg.cast_cit2ct_number(p_network_operator_ids, false),
    p_deleted => util_pkg.make_ct_date(util_pkg.get_count_cit_varchar_s(p_zone_codes), NULL),
    p_zone_type_codes => util_pkg.cast_cit2ct_varchar_s(p_zone_type_codes, false),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_out_ids => v_out_ids,
    p_out_codes => v_out_codes,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor98
  (
    p_sys_type_code => v_type_code,
    p_sys_error_codes => v_error_codes,
    p_sys_error_messages => v_error_messages,
    p_sys_ids => v_out_ids,
    p_sys_codes => v_out_codes
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_zone
(
    p_zone_ids util_pkg.cit_number,
    p_zone_codes util_pkg.cit_varchar_s,
    p_zone_names util_pkg.cit_varchar,
    p_zone_type_codes util_pkg.cit_varchar_s,
    p_network_operator_ids util_pkg.cit_number,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
  --
  v_type_code varchar2(30) := VP_ZONE.c_this_name;
  --
  v_out_ids ct_number;
  v_out_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  cocat_pkg.update_zone
  (
    p_zone_ids => util_pkg.cast_cit2ct_number(p_zone_ids, false),
    p_zone_codes => util_pkg.cast_cit2ct_varchar_s(p_zone_codes, false),
    p_zone_names => util_pkg.cast_cit2ct_varchar(p_zone_names, false),
    p_network_operator_ids => util_pkg.cast_cit2ct_number(p_network_operator_ids, false),
    p_deleted => util_pkg.make_ct_date(util_pkg.get_count_cit_number(p_zone_ids), NULL),
    p_zone_type_codes => util_pkg.cast_cit2ct_varchar_s(p_zone_type_codes, false),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_out_ids => v_out_ids,
    p_out_codes => v_out_codes,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor98
  (
    p_sys_type_code => v_type_code,
    p_sys_error_codes => v_error_codes,
    p_sys_error_messages => v_error_messages,
    p_sys_ids => v_out_ids,
    p_sys_codes => v_out_codes
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_host
(
    p_host_codes util_pkg.cit_varchar_s,
    p_host_names util_pkg.cit_varchar,
    p_host_addresses util_pkg.cit_varchar,
    p_host_locations util_pkg.cit_varchar,
    p_host_type_codes util_pkg.cit_varchar_s,
    p_time_zones util_pkg.cit_number,
    p_network_operator_ids util_pkg.cit_number,
    p_dst_rule_ids util_pkg.cit_number,
    p_routing_number_ids util_pkg.cit_number,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
  --
  v_type_code varchar2(30) := VP_HOST.c_this_name;
  --
  v_out_ids ct_number;
  v_out_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  cocat_pkg.create_host
  (
    p_host_codes => util_pkg.cast_cit2ct_varchar_s(p_host_codes, false),
    p_host_names => util_pkg.cast_cit2ct_varchar(p_host_names, false),
    p_host_addresses => util_pkg.cast_cit2ct_varchar(p_host_addresses, false),
    p_host_locations => util_pkg.cast_cit2ct_varchar(p_host_locations, false),
    p_deleted => util_pkg.make_ct_date(util_pkg.get_count_cit_varchar_s(p_host_codes), NULL),
    p_host_type_codes => util_pkg.cast_cit2ct_varchar_s(p_host_type_codes, false),
    p_network_operator_ids => util_pkg.cast_cit2ct_number(p_network_operator_ids, false),
    p_time_zones => util_pkg.cast_cit2ct_number(p_time_zones, false),
    p_dst_rule_ids => util_pkg.cast_cit2ct_number(p_dst_rule_ids, false),
    p_routing_number_ids => util_pkg.cast_cit2ct_number(p_routing_number_ids, false),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_out_ids => v_out_ids,
    p_out_codes => v_out_codes,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor98
  (
    p_sys_type_code => v_type_code,
    p_sys_error_codes => v_error_codes,
    p_sys_error_messages => v_error_messages,
    p_sys_ids => v_out_ids,
    p_sys_codes => v_out_codes
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_host
(
    p_host_ids util_pkg.cit_number,
    p_host_codes util_pkg.cit_varchar_s,
    p_host_names util_pkg.cit_varchar,
    p_host_addresses util_pkg.cit_varchar,
    p_host_locations util_pkg.cit_varchar,
    p_host_type_codes util_pkg.cit_varchar_s,
    p_time_zones util_pkg.cit_number,
    p_network_operator_ids util_pkg.cit_number,
    p_dst_rule_ids util_pkg.cit_number,
    p_routing_number_ids util_pkg.cit_number,
    p_user_name varchar2,
    p_commit number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
  --
  v_type_code varchar2(30) := VP_HOST.c_this_name;
  --
  v_out_ids ct_number;
  v_out_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  cocat_pkg.update_host
  (
    p_host_ids => util_pkg.cast_cit2ct_number(p_host_ids, false),
    p_host_codes => util_pkg.cast_cit2ct_varchar_s(p_host_codes, false),
    p_host_names => util_pkg.cast_cit2ct_varchar(p_host_names, false),
    p_host_addresses => util_pkg.cast_cit2ct_varchar(p_host_addresses, false),
    p_host_locations => util_pkg.cast_cit2ct_varchar(p_host_locations, false),
    p_deleted => util_pkg.make_ct_date(util_pkg.get_count_cit_number(p_host_ids), NULL),
    p_host_type_codes => util_pkg.cast_cit2ct_varchar_s(p_host_type_codes, false),
    p_network_operator_ids => util_pkg.cast_cit2ct_number(p_network_operator_ids, false),
    p_time_zones => util_pkg.cast_cit2ct_number(p_time_zones, false),
    p_dst_rule_ids => util_pkg.cast_cit2ct_number(p_dst_rule_ids, false),
    p_routing_number_ids => util_pkg.cast_cit2ct_number(p_routing_number_ids, false),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_out_ids => v_out_ids,
    p_out_codes => v_out_codes,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor98
  (
    p_sys_type_code => v_type_code,
    p_sys_error_codes => v_error_codes,
    p_sys_error_messages => v_error_messages,
    p_sys_ids => v_out_ids,
    p_sys_codes => v_out_codes
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_routing_number
(
    p_empty_ids_codes number,
    p_ids util_pkg.cit_number,
    p_codes util_pkg.cit_varchar_s,
    p_date date,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_empty_ids_codes boolean := util_pkg.int_to_bool_2val(p_empty_ids_codes);
  v_ids ct_number;
  v_codes ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_empty_ids_codes is null, 'p_empty_ids_codes');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_empty_ids_codes, 'p_empty_ids_codes');
  ------------------------------
  if NOT v_empty_ids_codes
  then
    ------------------------------
    v_ids := util_pkg.cast_cit2ct_number(p_ids, FALSE);
    v_codes := util_pkg.cast_cit2ct_varchar_s(p_codes, FALSE);
    ------------------------------
  end if;
  ------------------------------
  cocat_pkg.get_routing_number
  (
    p_ids => v_ids,
    p_codes => v_codes,
    p_date => p_date,
    p_result => p_result
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_dst_rule
(
    p_empty_ids_codes number,
    p_ids util_pkg.cit_number,
    p_codes util_pkg.cit_varchar_s,
    p_date date,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_empty_ids_codes boolean := util_pkg.int_to_bool_2val(p_empty_ids_codes);
  v_ids ct_number;
  v_codes ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_empty_ids_codes is null, 'p_empty_ids_codes');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_empty_ids_codes, 'p_empty_ids_codes');
  ------------------------------
  if NOT v_empty_ids_codes
  then
    ------------------------------
    v_ids := util_pkg.cast_cit2ct_number(p_ids, FALSE);
    v_codes := util_pkg.cast_cit2ct_varchar_s(p_codes, FALSE);
    ------------------------------
  end if;
  ------------------------------
  cocat_pkg.get_dst_rule
  (
    p_ids => v_ids,
    p_codes => v_codes,
    p_date => p_date,
    p_result => p_result
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_network_operator
(
    p_empty_ids_codes number,
    p_ids util_pkg.cit_number,
    p_codes util_pkg.cit_varchar_s,
    p_uprs_member_codes util_pkg.cit_varchar_s,
    p_date date,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_empty_ids_codes boolean := util_pkg.int_to_bool_2val(p_empty_ids_codes);
  v_ids ct_number;
  v_codes ct_varchar_s;
  v_uprs_member_codes ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_empty_ids_codes is null, 'p_empty_ids_codes');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_empty_ids_codes, 'p_empty_ids_codes');
  ------------------------------
  if NOT v_empty_ids_codes
  then
    ------------------------------
    v_ids := util_pkg.cast_cit2ct_number(p_ids, FALSE);
    v_codes := util_pkg.cast_cit2ct_varchar_s(p_codes, FALSE);
    v_uprs_member_codes := util_pkg.cast_cit2ct_varchar_s(p_uprs_member_codes, FALSE);
    ------------------------------
  end if;
  ------------------------------
  cocat_pkg.get_network_operator
  (
    p_ids => v_ids,
    p_codes => v_codes,
    p_uprs_member_codes => v_uprs_member_codes,
    p_date => p_date,
    p_result => p_result
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_zone
(
    p_empty_ids_codes number,
    p_ids util_pkg.cit_number,
    p_codes util_pkg.cit_varchar_s,
    p_date date,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_empty_ids_codes boolean := util_pkg.int_to_bool_2val(p_empty_ids_codes);
  v_ids ct_number;
  v_codes ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_empty_ids_codes is null, 'p_empty_ids_codes');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_empty_ids_codes, 'p_empty_ids_codes');
  ------------------------------
  if NOT v_empty_ids_codes
  then
    ------------------------------
    v_ids := util_pkg.cast_cit2ct_number(p_ids, FALSE);
    v_codes := util_pkg.cast_cit2ct_varchar_s(p_codes, FALSE);
    ------------------------------
  end if;
  ------------------------------
  cocat_pkg.get_zone
  (
    p_ids => v_ids,
    p_codes => v_codes,
    p_date => p_date,
    p_result => p_result
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_host
(
    p_empty_ids_codes number,
    p_ids util_pkg.cit_number,
    p_codes util_pkg.cit_varchar_s,
    p_date date,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_empty_ids_codes boolean := util_pkg.int_to_bool_2val(p_empty_ids_codes);
  v_ids ct_number;
  v_codes ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_empty_ids_codes is null, 'p_empty_ids_codes');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_empty_ids_codes, 'p_empty_ids_codes');
  ------------------------------
  if NOT v_empty_ids_codes
  then
    ------------------------------
    v_ids := util_pkg.cast_cit2ct_number(p_ids, FALSE);
    v_codes := util_pkg.cast_cit2ct_varchar_s(p_codes, FALSE);
    ------------------------------
  end if;
  ------------------------------
  cocat_pkg.get_host
  (
    p_ids => v_ids,
    p_codes => v_codes,
    p_date => p_date,
    p_result => p_result
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_all_def_abc_rule
(
  p_result out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  etc_pkg.get_all_def_abc_rule
  (
    p_date => SYSDATE,
    p_result => p_result
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure delete_def_abc_rule
(
  p_ids util_pkg.cit_number,
  p_user_name varchar2,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_date date := sysdate;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  etc_pkg.delete_def_abc_rule
  (
    p_ids => util_pkg.cast_cit2ct_number(p_ids, false),
    p_date_from => util_pkg.make_ct_date(util_pkg.get_count_cit_number(p_ids), v_date),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure delete_def_abc_rule2
(
  p_id number,
  p_user_name varchar2,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  etc_pkg.delete_def_abc_rule2
  (
    p_id => p_id,
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_def_abc_rule
(
  p_defs util_pkg.cit_varchar_s,
  p_abcs util_pkg.cit_varchar_s,
  p_user_name varchar2,
  --!_!p_out_ids out ct_number,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_out_ids ct_number; --!_!
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  etc_pkg.create_def_abc_rule
  (
    p_defs => util_pkg.cast_cit2ct_varchar_s(p_defs, false),
    p_abcs => util_pkg.cast_cit2ct_varchar_s(p_abcs, false),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_out_ids => v_out_ids, --!_!not used
    --!_!p_out_ids => p_out_ids,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_def_abc_rule2
(
  p_def varchar2,
  p_abc varchar2,
  p_user_name varchar2,
  p_out_id out number,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  etc_pkg.create_def_abc_rule2
  (
    p_def => p_def,
    p_abc => p_abc,
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_out_id => p_out_id,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_def_abc_rule
(
  p_ids util_pkg.cit_number,
  p_defs util_pkg.cit_varchar_s,
  p_abcs util_pkg.cit_varchar_s,
  p_user_name varchar2,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  etc_pkg.update_def_abc_rule
  (
    p_ids => util_pkg.cast_cit2ct_number(p_ids, false),
    p_defs => util_pkg.cast_cit2ct_varchar_s(p_defs, false),
    p_abcs => util_pkg.cast_cit2ct_varchar_s(p_abcs, false),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_def_abc_rule2
(
  p_id number,
  p_def varchar2,
  p_abc varchar2,
  p_user_name varchar2,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  etc_pkg.update_def_abc_rule2
  (
    p_id => p_id,
    p_def => p_def,
    p_abc => p_abc,
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_phone_number_with_rn_info
(
  p_nn util_pkg.cit_varchar_s,
  p_date date,
  p_result out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_nn ct_varchar_s;
  v_msisdns ct_varchar_s;
  v_rns ct_varchar_s;
  v_network_operator_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  v_nn := util_pkg.cast_cit2ct_varchar_s(p_nn, false);
  ------------------------------
  mnp_pkg.get_phone_number_with_rn_info
  (
    p_nn => v_nn,
    p_date => p_date,
    p_msisdns => v_msisdns,
    p_rns => v_rns,
    p_network_operator_codes => v_network_operator_codes,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor03(v_nn, v_msisdns, v_rns, v_network_operator_codes, v_error_codes, v_error_messages);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_phone_number_type_by_pa
(
  p_personal_accounts util_pkg.cit_number,
  p_min_date_of_used date,
  p_only_main_msisdn number,
  p_result out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_out_personal_accounts ct_number;
  v_out_phone_type ct_varchar_s;
begin
  ------------------------------
  mnp_pkg.get_phone_number_type_by_pa
  (
    p_personal_accounts => util_pkg.cast_cit2ct_number(p_personal_accounts, false),
    p_min_date_of_used => p_min_date_of_used,
    p_only_main_msisdn  => util_pkg.int_to_bool(p_only_main_msisdn),
    p_out_personal_accounts => v_out_personal_accounts,
    p_out_phone_type => v_out_phone_type
  );
  ------------------------------
  p_result := get_result_cursor04(v_out_personal_accounts, v_out_phone_type);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure mnp_port_in
(
  p_msisdn varchar2,
  p_iccid varchar2,
  p_user_name varchar2,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  mnp_pkg.mnp_port_in2
  (
    p_msisdn => p_msisdn,
    p_iccid => p_iccid,
    p_date => SYSDATE,
    p_user_id => util_ri.xget_user_id(p_user_name)
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure mnp_port_out
(
  p_msisdn varchar2,
  p_user_name varchar2,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  mnp_pkg.mnp_port_out2
  (
    p_msisdn => p_msisdn,
    p_date => SYSDATE,
    p_user_id => util_ri.xget_user_id(p_user_name)
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_!both mnp and template belong to internal operators
procedure check4change_main_net_op
(
  p_msisdn_mnp varchar2,
  p_msisdn_template varchar2,
  p_user_name varchar2,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  util_loc_pkg.touch_varchar(p_user_name);
  ------------------------------
  mnp_pkg.xcheck4change_main_net_op
  (
    p_msisdn_mnp => p_msisdn_mnp,
    p_msisdn_template => p_msisdn_template,
    p_date => sysdate
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!both mnp and template belong to internal operators
procedure change_main_net_op4phone_num
(
  p_msisdn_mnp varchar2,
  p_msisdn_template varchar2,
  p_user_name varchar2,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  mnp_pkg.change_main_net_op4phone_num
  (
    p_msisdn_mnp => p_msisdn_mnp,
    p_msisdn_template => p_msisdn_template,
    p_date => sysdate,
    p_user_id => util_ri.xget_user_id(p_user_name)
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_proper_hlr2
(
  p_msisdn varchar2,
  p_result out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_date date := sysdate;
  v_na_id number;
  v_host_id number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn is null, 'p_msisdn');
  ------------------------------
  v_na_id := util_ri.get_na_id2(p_msisdn => p_msisdn, p_date => v_date);
  ------------------------------
  v_host_id := mnp_pkg.xget_proper_hlr2(p_na_id => v_na_id, p_date => v_date);
  ------------------------------
  p_result := get_result_cursor22
  (
    p_id_str => util_pkg.make_ct_varchar_s(1, 'qwerty01'),
    p_host_id => util_pkg.make_ct_number(1, v_host_id),
    p_date => v_date
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure is_mnp_port_in_valid2
(
  p_msisdn_mnp varchar2,
  p_msisdn_template varchar2,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_date date := sysdate;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn_template is null, 'p_msisdn_template');
  util_pkg.XCheck_Cond_Missing(p_msisdn_mnp is null, 'p_msisdn_mnp');
  ------------------------------
  if mnp_pkg.is_mnp_port_in_valid2
  (
    p_msisdn_mnp => p_msisdn_mnp,
    p_msisdn_template => p_msisdn_template,
    p_date => v_date
  )
  then
    ------------------------------
    util_pkg.set_ok(p_error_code, p_error_message);
    ------------------------------
  else
    ------------------------------
    p_error_code := util_loc_pkg.c_ora_wrong_host;
    p_error_message := util_loc_pkg.c_msg_wrong_host;
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_phone_number_decomposition
(
  p_pn_list util_pkg.cit_varchar_s,
  p_error_code out number,
  p_error_message out varchar2,
  p_result out sys_refcursor
)
is
  v_msisdn ct_varchar_s;
  v_country_code ct_varchar_s;
  v_area_code ct_varchar_s;
  v_local_phone ct_varchar_s;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  v_msisdn := util_pkg.cast_cit2ct_varchar_s(p_pn_list, false);
  ------------------------------
  api_ri_i_pkg.get_phone_number_decomposition
  (
    p_msisdns => v_msisdn,
    p_country_code => v_country_code,
    p_area_code => v_area_code,
    p_local_phone => v_local_phone,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_result := get_result_cursor06(v_msisdn, v_country_code, v_area_code, v_local_phone, v_error_code, v_error_message);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  p_result := get_result_cursor06(v_msisdn, v_country_code, v_area_code, v_local_phone, v_error_code, v_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure create_virtual_sim
(
    p_msisdns util_pkg.cit_varchar_s,
    p_user_name varchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_msisdn ct_varchar_s;
  v_imsis ct_varchar_s;
  v_iccids ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  v_msisdn := util_pkg.cast_cit2ct_varchar_s(p_msisdns, false);
  ------------------------------
  virtual_sim_pkg.create_virtual_sim
  (
    p_msisdns => v_msisdn,
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_imsis => v_imsis,
    p_iccids => v_iccids,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor07(v_msisdn, v_iccids, v_imsis);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_virtual_sim_and_link_pa
(
    p_msisdns util_pkg.cit_varchar_s,
    p_set_na_status util_pkg.cit_varchar_s,
    p_personal_accounts util_pkg.cit_number,
    p_user_name varchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_msisdn ct_varchar_s;
  v_imsis ct_varchar_s;
  v_iccids ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  v_msisdn := util_pkg.cast_cit2ct_varchar_s(p_msisdns, false);
  ------------------------------
  virtual_sim_pkg.create_virtual_sim_and_link_pa
  (
    p_msisdns => v_msisdn,
    p_set_na_status => util_pkg.cast_cit2ct_varchar_s(p_set_na_status, false),
    p_personal_accounts => util_pkg.cast_cit2ct_number(p_personal_accounts, false),
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_imsis => v_imsis,
    p_iccids => v_iccids,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result := get_result_cursor07(v_msisdn, v_iccids, v_imsis);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure mnp_phone_get_back_to_foris
(
  p_msisdn varchar2,
  p_user_name varchar2,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  mnp_pkg.mnp_port_in_back2
  (
    p_msisdn => p_msisdn,
    p_date => SYSDATE,
    p_user_id => util_ri.xget_user_id(p_user_name)
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_next_ready2return_phones
(
  p_batch_id out number,
  p_result out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_msisdns ct_varchar_s;
  v_date_froms ct_date;
begin
  ------------------------------
  mnp_pkg.get_next_ready2return_phones
  (
    p_user_id => util_ri.xget_default_user_id,
    p_batch_id => p_batch_id,
    p_msisdns => v_msisdns,
    p_date_froms => v_date_froms
  );
  ------------------------------
  p_result := get_result_cursor08
  (
    p_msisdns => v_msisdns,
    p_date_froms => v_date_froms
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure confirm_return_phone_batch
(
  p_batch_id number,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  mnp_pkg.confirm_return_phone_batch
  (
    p_batch_id => p_batch_id,
    p_user_id => util_ri.xget_default_user_id
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_ph_st_and_reset_reserve
(
  p_msisdns util_pkg.cit_varchar_s,
  p_status varchar2,
  p_user_name varchar2,
  p_result out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_msisdn ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  v_msisdn := util_pkg.cast_cit2ct_varchar_s(p_msisdns, false);
  ------------------------------
  reservation_pkg.set_ph_st_and_reset_reserve
  (
    p_msisdns => v_msisdn,
    p_status => p_status,
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => FALSE,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  get_result_cursor01(v_msisdn, p_result, v_error_codes, v_error_messages);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function ins_agroup_data
(
    p_error_code out number,
    p_error_message out varchar2,
    p_commit number,
    p_agroup_id number,
    p_id1 number,
    p_id2 number,
    p_user_id number
) return number
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  v_rec := null;
  ------------------------------
  v_rec.agroup_id := p_agroup_id;
  v_rec.id1 := p_id1;
  v_rec.id2 := p_id2;
  v_rec.user_id := p_user_id;
  ------------------------------
  vp_agroup_data.version_open(v_rec, vp_agroup_data.c_unq_none);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
  return v_rec.agroup_data_id;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
  --!_!return null;
  return vp_agroup_data.c_not_defined_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_agroup_data
(
    p_error_code out number,
    p_error_message out varchar2,
    p_commit number,
    p_agroup_data_id number,
    p_agroup_id number,
    p_id1 number,
    p_id2 number,
    p_user_id number
)
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  v_rec := null;
  ------------------------------
  v_rec.agroup_data_id := p_agroup_data_id;
  v_rec.agroup_id := p_agroup_id;
  v_rec.id1 := p_id1;
  v_rec.id2 := p_id2;
  v_rec.user_id := p_user_id;
  ------------------------------
  vp_agroup_data.version_change(v_rec, vp_agroup_data.c_unq_none);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_agroup_data
(
    p_error_code out number,
    p_error_message out varchar2,
    p_commit number,
    p_agroup_data_id number,
    p_user_id number
)
is
  v_commit boolean := util_pkg.int_to_bool_2val(p_commit);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_commit is null, 'p_commit');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_commit, 'p_commit');
  ------------------------------
  vp_agroup_data.version_close
  (
    p_id => p_agroup_data_id,
    p_user_id => p_user_id
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_commit
  then
    rollback;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_phone_info
(
    p_msisdn util_pkg.cit_varchar_s,
    p_result out sys_refcursor
)
is
begin
  ------------------------------
  mnp_pkg.get_phone_info
  (
    p_msisdn => util_pkg.cast_cit2ct_varchar_s(p_msisdn, false),
    p_result => p_result
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_main_host_by_iccid
(
    p_iccid util_pkg.cit_varchar_s,
    p_result out sys_refcursor
)
is
begin
  ------------------------------
  mnp_pkg.get_main_host_by_iccid
  (
    p_iccid => util_pkg.cast_cit2ct_varchar_s(p_iccid, false),
    p_result => p_result
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_timer_manager_setting
(
    p_task_list_id number,
    p_timer_period out number,
    p_timer_tasks out sys_refcursor
)
is
begin
  ------------------------------
  p_timer_period := timer_task_list_pkg.get_timer_period_val;
  ------------------------------
  timer_task_list_pkg.get_task_list_cursor
  (
    p_agroup_id => p_task_list_id,
    p_timer_tasks => p_timer_tasks
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ri_crm_task_list_id return number
is
begin
  ------------------------------
  return timer_task_list_pkg.c_agroup_id_crm_timer_tasks;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ri_sups_task_list_id return number
is
begin
  ------------------------------
  return timer_task_list_pkg.c_agroup_id_sups_timer_tasks;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure create_msisdn_by_number_for_ps
(
  p_msisdns util_pkg.cit_varchar_s,
  p_date_reserved date,
  p_user_name varchar2,
  p_reserve_number out number,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_msisdn ct_varchar_s;
  v_date date := sysdate;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  v_msisdn := util_pkg.cast_cit2ct_varchar_s(p_msisdns, false);
  ------------------------------
  api_ri_i_pkg.create_msisdn_by_number_for_ps
  (
    p_msisdns => v_msisdn,
    p_date => v_date,
    p_date_reserved => p_date_reserved,
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_break_on_error => TRUE,
    p_reserve_number => p_reserve_number,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_network_operator_srvc
(
  p_no_id number,
  p_svc_code varchar2,
  p_date_from date,
  p_date_to date,
  p_user_id number,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_no_ids ct_number;
  v_svc_codes ct_varchar_s;
  v_date_from ct_date;
  v_date_to ct_date;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_no_ids, p_no_id);
  util_pkg.add_ct_varchar_s_val(v_svc_codes, p_svc_code);
  util_pkg.add_ct_date_val(v_date_from, p_date_from);
  util_pkg.add_ct_date_val(v_date_to, p_date_to);
  ------------------------------
  api_ri_i_pkg.open_network_operator_srvc
  (
    p_no_ids => v_no_ids,
    p_svc_codes => v_svc_codes,
    p_date_from => v_date_from,
    p_date_to => v_date_to,
    p_user_id => p_user_id,
    p_break_on_error => TRUE,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure close_network_operator_srvc
(
  p_no_id number,
  p_svc_code varchar2,
  p_old_date_from date,
  p_old_date_to date,
  p_date_from date,
  p_user_id number,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_no_ids ct_number;
  v_svc_codes ct_varchar_s;
  v_old_date_from ct_date;
  v_old_date_to ct_date;
  v_date_from ct_date;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_no_ids, p_no_id);
  util_pkg.add_ct_varchar_s_val(v_svc_codes, p_svc_code);
  util_pkg.add_ct_date_val(v_old_date_from, p_old_date_from);
  util_pkg.add_ct_date_val(v_old_date_to, p_old_date_to);
  util_pkg.add_ct_date_val(v_date_from, p_date_from);
  ------------------------------
  api_ri_i_pkg.close_network_operator_srvc
  (
    p_no_ids => v_no_ids,
    p_svc_codes => v_svc_codes,
    p_old_date_from => v_old_date_from,
    p_old_date_to => v_old_date_to,
    p_date_from => v_date_from,
    p_user_id => p_user_id,
    p_break_on_error => TRUE,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_network_operator_srvc
(
  p_no_id integer,
  p_date date,
  p_no_date number,
  p_result out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_no_date boolean := util_pkg.int_to_bool_2val(p_no_date);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_no_id is null, 'p_no_id');
  util_pkg.XCheck_Cond_Missing(p_no_date is null, 'p_no_date');
  util_pkg.XCheck_Num_As_Bool_Invalid(p_no_date, 'p_no_date');
  ------------------------------
  api_ri_i_pkg.get_network_operator_srvc
  (
    p_no_id => p_no_id,
    p_date => p_date,
    p_no_date => v_no_date,
    p_result => p_result
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure create_sim_cards
(
    p_msisdn_list util_pkg.cit_varchar_s,
    p_iccid_list util_pkg.cit_varchar_s,
    p_pin_list util_pkg.cit_varchar_s,
    p_pin2_list util_pkg.cit_varchar_s,
    p_puk_list util_pkg.cit_varchar_s,
    p_puk2_list util_pkg.cit_varchar_s,
    p_ki_list util_pkg.cit_nvarchar_s,
    p_auth_type_list util_pkg.cit_varchar_s,
    p_sim_card_type_code varchar2,
    p_user_nt_name varchar2,
    p_handle_tran char default util_ri.c_tran_yes,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor,
    p_error_list out sys_refcursor
)
is
  v_sp_name varchar2(30);
  v_msisdn_list ct_varchar_s;
  v_iccid_list ct_varchar_s;
  v_pin_list ct_varchar_s;
  v_pin2_list ct_varchar_s;
  v_puk_list ct_varchar_s;
  v_puk2_list ct_varchar_s;
  v_ki_list ct_nvarchar_s;
  v_auth_type_list ct_varchar_s;
  v_imsi ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
  v_mark_err ct_number;
  --
  v_msisdn_list2 ct_varchar_s;
  v_iccid_list2 ct_varchar_s;
  v_pin_list2 ct_varchar_s;
  v_pin2_list2 ct_varchar_s;
  v_puk_list2 ct_varchar_s;
  v_puk2_list2 ct_varchar_s;
  v_ki_list2 ct_nvarchar_s;
  v_auth_type_list2 ct_varchar_s;
  v_imsi2 ct_varchar_s;
  --
  v_msisdn_list3 ct_varchar_s;
  v_iccid_list3 ct_varchar_s;
  v_error_codes3 ct_number;
  v_error_messages3 ct_varchar;
begin
  ------------------------------
  if p_handle_tran = util_ri.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_msisdn_list := util_pkg.cast_cit2ct_varchar_s(p_msisdn_list, false);
  v_iccid_list := util_pkg.cast_cit2ct_varchar_s(p_iccid_list, false);
  v_pin_list := util_pkg.cast_cit2ct_varchar_s(p_pin_list, false);
  v_pin2_list := util_pkg.cast_cit2ct_varchar_s(p_pin2_list, false);
  v_puk_list := util_pkg.cast_cit2ct_varchar_s(p_puk_list, false);
  v_puk2_list := util_pkg.cast_cit2ct_varchar_s(p_puk2_list, false);
  v_ki_list := util_pkg.cast_cit2ct_nvarchar_s(p_ki_list, false);
  v_auth_type_list := util_pkg.cast_cit2ct_varchar_s(p_auth_type_list, false);
  ------------------------------
  api_ri_i_pkg.create_sim_cards
  (
    p_msisdn_list => v_msisdn_list,
    p_iccid_list => v_iccid_list,
    p_pin_list => v_pin_list,
    p_pin2_list => v_pin2_list,
    p_puk_list => v_puk_list,
    p_puk2_list => v_puk2_list,
    p_ki_list => v_ki_list,
    p_auth_type_list => v_auth_type_list,
    p_sim_card_type_code => p_sim_card_type_code,
    p_user_id => util_ri.xget_user_id(p_user_nt_name),
    p_imsi => v_imsi,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  --!_!util_ext_ri.xcheck_has_error(TRUE, v_error_codes, v_error_messages);
  ------------------------------
  if p_handle_tran = util_ri.c_tran_yes
  then
     commit;
  end if;
  ------------------------------
  v_mark_err := util_pkg.mark_val_ct_number(v_error_codes, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
  ------------------------------
  v_msisdn_list2 := util_pkg.get_marked_ct_varchar_s(v_msisdn_list, v_mark_err, TRUE, util_pkg.c_false);
  v_iccid_list2 := util_pkg.get_marked_ct_varchar_s(v_iccid_list, v_mark_err, TRUE, util_pkg.c_false);
  v_pin_list2 := util_pkg.get_marked_ct_varchar_s(v_pin_list, v_mark_err, TRUE, util_pkg.c_false);
  v_pin2_list2 := util_pkg.get_marked_ct_varchar_s(v_pin2_list, v_mark_err, TRUE, util_pkg.c_false);
  v_puk_list2 := util_pkg.get_marked_ct_varchar_s(v_puk_list, v_mark_err, TRUE, util_pkg.c_false);
  v_puk2_list2 := util_pkg.get_marked_ct_varchar_s(v_puk2_list, v_mark_err, TRUE, util_pkg.c_false);
  v_ki_list2 := util_pkg.get_marked_ct_nvarchar_s(v_ki_list, v_mark_err, TRUE, util_pkg.c_false);
  v_auth_type_list2 := util_pkg.get_marked_ct_varchar_s(v_auth_type_list, v_mark_err, TRUE, util_pkg.c_false);
  v_imsi2 := util_pkg.get_marked_ct_varchar_s(v_imsi, v_mark_err, TRUE, util_pkg.c_false);
  ------------------------------
  p_result_list := get_result_cursor10
  (
    p_msisdn_list => v_msisdn_list2,
    p_iccid_list => v_iccid_list2,
    p_pin_list => v_pin_list2,
    p_pin2_list => v_pin2_list2,
    p_puk_list => v_puk_list2,
    p_puk2_list => v_puk2_list2,
    p_ki_list => v_ki_list2,
    p_auth_type_list => v_auth_type_list2,
    p_imsi => v_imsi2
  );
  ------------------------------
  v_msisdn_list3 := util_pkg.get_marked_ct_varchar_s(v_msisdn_list, v_mark_err, TRUE, util_pkg.c_true);
  v_iccid_list3 := util_pkg.get_marked_ct_varchar_s(v_iccid_list, v_mark_err, TRUE, util_pkg.c_true);
  v_error_codes3 := util_pkg.get_marked_ct_number(v_error_codes, v_mark_err, TRUE, util_pkg.c_true);
  v_error_messages3 := util_pkg.get_marked_ct_varchar(v_error_messages, v_mark_err, TRUE, util_pkg.c_true);
  ------------------------------
  p_error_list := get_result_cursor11(v_msisdn_list3, v_iccid_list3, v_error_codes3, v_error_messages3);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if p_handle_tran = util_ri.c_tran_yes
  then
  rollback;
  elsif p_handle_tran = util_ri.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  -----------------------------
end;

----------------------------------!---------------------------------------------
procedure cancel_param_sim_cards
(
    p_iccid_list util_pkg.cit_varchar_s,
    p_user_nt_name varchar2,
    p_handle_tran char default util_ri.c_tran_yes,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor
)
is
  v_sp_name varchar2(30);
  v_iccid_list ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  if p_handle_tran = util_ri.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_iccid_list := util_pkg.cast_cit2ct_varchar_s(p_iccid_list, false);
  ------------------------------
  api_ri_i_pkg.cancel_param_sim_cards
  (
    p_iccid_list => v_iccid_list,
    p_user_id => util_ri.xget_user_id(p_user_nt_name),
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_ext_ri.xcheck_has_error(TRUE, v_error_codes, v_error_messages);
  ------------------------------
  if p_handle_tran = util_ri.c_tran_yes
  then
     commit;
  end if;
  ------------------------------
  p_result_list := get_result_cursor12(v_iccid_list, v_error_codes, v_error_messages);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if p_handle_tran = util_ri.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_ri.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  -----------------------------
  p_result_list := get_result_cursor12(v_iccid_list, v_error_codes, v_error_messages);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_uprs_member_code_by_phone
(
    p_msisdn varchar2,
    p_validity_date date,
    p_uprs_member_code out varchar2,
    p_net_operator_name out varchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  api_ri_i_pkg.get_uprs_member_code_by_phone
  (
    p_msisdn => p_msisdn,
    p_validity_date => p_validity_date,
    p_uprs_member_code => p_uprs_member_code,
    p_net_operator_name => p_net_operator_name,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_series_cont_free_phones1
(
    p_host_id number,
    p_host_empty number,
    p_network_operator_id number,
    p_phone_number_type varchar2,
    p_salability_category varchar2,
    p_phone_number_status_code util_pkg.cit_varchar_s,
    p_result_list out sys_refcursor
)
is
  v_host_id ct_number;
  v_salability_category ct_varchar_s;
  v_ps_id ct_number;
  v_pn_count ct_number;
begin
  -----------------------------
  if p_host_id is not null
  then
    util_pkg.add_ct_number_val(v_host_id, p_host_id);
  end if;
  -----------------------------
  util_pkg.add_ct_varchar_s_val(v_salability_category, p_salability_category);
  -----------------------------
  api_ri_i_pkg.get_series_cont_free_phones
  (
    p_host_id => v_host_id,
    p_host_empty => util_pkg.int_to_bool_3val(p_host_empty),
    p_network_operator_id => p_network_operator_id,
    p_phone_number_type => p_phone_number_type,
    p_salability_category => v_salability_category,
    p_phone_number_status_code => util_pkg.cast_cit2ct_varchar_s(p_phone_number_status_code, true),
    p_use_linked => null, --p_link_status = c_link2_status_all
    p_ps_id => v_ps_id,
    p_pn_count => v_pn_count
  );
  -----------------------------
  p_result_list := get_result_cursor13(v_ps_id, v_pn_count);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_series_cont_free_phones2
(
    p_host_id number,
    p_host_empty number,
    p_network_operator_code varchar2,
    p_phone_number_type varchar2,
    p_salability_category util_pkg.cit_varchar_s,
    p_phone_number_status_code util_pkg.cit_varchar_s,
    p_result_list out sys_refcursor
)
is
  v_host_id ct_number;
  v_ps_id ct_number;
  v_pn_count ct_number;
begin
  -----------------------------
  if p_host_id is not null
  then
    util_pkg.add_ct_number_val(v_host_id, p_host_id);
  end if;
  -----------------------------
  api_ri_i_pkg.get_series_cont_free_phones2
  (
    p_host_id => v_host_id,
    p_host_empty => util_pkg.int_to_bool_3val(p_host_empty),
    p_network_operator_code => p_network_operator_code,
    p_phone_number_type => p_phone_number_type,
    p_salability_category => util_pkg.cast_cit2ct_varchar_s(p_salability_category, true),
    p_phone_number_status_code => util_pkg.cast_cit2ct_varchar_s(p_phone_number_status_code, true),
    p_use_linked => null, --p_link_status = c_link2_status_all
    p_ps_id => v_ps_id,
    p_pn_count => v_pn_count
  );
  -----------------------------
  p_result_list := get_result_cursor14(v_ps_id, v_pn_count);
  -----------------------------
end;

----------------------------------!---------------------------------------------
procedure get_series_cont_free_phones3
(
    p_host_id util_pkg.cit_number,
    p_host_empty number,
    p_network_operator_code varchar2,
    p_phone_number_type varchar2,
    p_salability_category util_pkg.cit_varchar_s,
    p_phone_number_status_code util_pkg.cit_varchar_s,
    p_link_status number, -- 0 - free, 1- linked, null - all  -- old 0 - all, 1 - free, 2 - linked
    p_result_list out sys_refcursor
)
is
  v_ps_id ct_number;
  v_pn_count ct_number;
begin
  -----------------------------
  api_ri_i_pkg.get_series_cont_free_phones2
  (
    p_host_id => util_pkg.cast_cit2ct_number(p_host_id, true),
    p_host_empty => util_pkg.int_to_bool_3val(p_host_empty),
    p_network_operator_code => p_network_operator_code,
    p_phone_number_type => p_phone_number_type,
    p_salability_category => util_pkg.cast_cit2ct_varchar_s(p_salability_category, true),
    p_phone_number_status_code => util_pkg.cast_cit2ct_varchar_s(p_phone_number_status_code, true),
    p_use_linked => p_link_status,
    p_ps_id => v_ps_id,
    p_pn_count => v_pn_count
  );
  -----------------------------
  p_result_list := get_result_cursor14(v_ps_id, v_pn_count);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_abc_rule_result
(
  p_def_msisdn varchar2,
  p_abc_msisdn out varchar2,
  p_error_code out number,
  p_error_message out varchar2
)
is
begin
  ------------------------------
  util_pkg.xcheck_cond_missing(p_def_msisdn is null, 'p_def_msisdn');
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  p_abc_msisdn := etc_pkg.get_abc_rule_result(p_def_msisdn);
  ------------------------------
  if p_abc_msisdn is null
  then
    ------------------------------
    p_error_code := util_loc_pkg.c_ora_phone_not_found;
    p_error_message := util_loc_pkg.c_msg_phone_not_found;
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_abc_rule_result_special
(
  p_msisdn util_pkg.cit_varchar_s,
  p_result_list out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_msisdn ct_varchar_s;
  v_msisdn_abc ct_varchar_s;
  v_type_abc ct_varchar_s;
  v_type_def ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.XCheckP_FS_cit_varchar_s(p_msisdn, 'p_msisdn');
  ------------------------------
  v_msisdn := util_pkg.cast_cit2ct_varchar_s(p_msisdn, true);
  ------------------------------
  etc_pkg.get_abc_rule_result_special
  (
    p_msisdn => v_msisdn,
    p_msisdn_abc => v_msisdn_abc,
    p_type_abc => v_type_abc,
    p_type_def => v_type_def,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_result_list := get_result_cursor15(v_msisdn, v_msisdn_abc, v_type_abc, v_type_def, v_error_codes, v_error_messages);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_phone_types
(
  p_error_code out number,
  p_result_list out sys_refcursor
)
is
  v_error_message varchar2(4000);
begin
  ------------------------------
  open p_result_list for
  select
    phone_number_type_code,
    phone_number_type_name,
    deleted,
    check_relation_to_host
  from
    PHONE_NUMBER_TYPE
  ;
  ------------------------------
  util_pkg.set_ok(p_error_code, v_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, v_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_roaming_cache
(
  p_cache_guid varchar2,
  p_range_date_from date,
  p_range_date_to date,
  p_error_code out number,
  p_error_message out varchar2,
  p_HostNOs out sys_refcursor,
  p_RoamingTypes out sys_refcursor,
  p_phones out sys_refcursor,
  p_MCCMNCNOs out sys_refcursor,
  p_gone_subscribers out sys_refcursor,
  p_come_in_subscribers out sys_refcursor
)
is
begin
  ------------------------------
  roaming_cache_pkg.get_roaming_cache
  (
    p_cache_guid => p_cache_guid,
    p_range_date_from => p_range_date_from,
    p_range_date_to => p_range_date_to,
    p_HostNOs => p_HostNOs,
    p_RoamingTypes => p_RoamingTypes,
    p_phones => p_phones,
    p_MCCMNCNOs => p_MCCMNCNOs,
    p_gone_subscribers => p_gone_subscribers,
    p_come_in_subscribers => p_come_in_subscribers
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure unreg_roam_cache_subscr
(
    p_cache_guid varchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
  v_user_id number:= util_ri.xget_default_user_id;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_cache_guid is null, 'p_cache_guid');
  ------------------------------
  roaming_cache_pkg.unreg_roam_cache_subscr_i(p_cache_guid, v_date, v_user_id);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_roaming_cache_changes
(
  p_cache_guid varchar2,
  p_range_date_from date,
  p_range_date_to date,
  p_error_code out number,
  p_error_message out varchar2,
  p_gone_subscribers out sys_refcursor,
  p_come_in_subscribers out sys_refcursor
)
is
  v_date date := sysdate;
begin
  ------------------------------
  roaming_cache_pkg.get_roaming_cache_changes_i
  (
    p_cache_guid => p_cache_guid,
    p_range_date_from => p_range_date_from,
    p_range_date_to => p_range_date_to,
    p_date => v_date,
    p_user_id => util_ri.xget_default_user_id,
    p_goers => p_gone_subscribers,
    p_comers => p_come_in_subscribers
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_imsi_host
(
  p_imsis util_pkg.cit_varchar_s,
  p_host_type_code varchar2,
  p_date date,
  p_result out sys_refcursor
)
is
  v_imsis ct_varchar_s;
  v_host_ids ct_number;
  v_subhost_ids ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_imsis);
  util_pkg.XCheck_Cond_Missing(p_host_type_code is null, 'p_host_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_imsis := util_pkg.cast_cit2ct_varchar_s(p_imsis, true);
  ------------------------------
  api_ri_i_pkg.get_imsi_host_smart
  (
    p_imsis => v_imsis,
    p_host_type_code => p_host_type_code,
    p_date => p_date,
    p_get_subhosts => true,
    p_host_ids => v_host_ids,
    p_subhost_ids => v_subhost_ids
  );
  ------------------------------
  p_result := get_result_cursor20
  (
    p_id_str => v_imsis,
    p_host_id => v_host_ids,
    p_subhost_id => v_subhost_ids,
    p_date => p_date
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_iccid_host_ex
(
  p_iccids util_pkg.cit_varchar_s,
  p_host_type_code varchar2,
  p_date date,
  p_result out sys_refcursor
)
is
  v_iccids ct_varchar_s;
  v_host_ids ct_number;
  v_subhost_ids ct_number;
  v_no_ids ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_iccids);
  util_pkg.XCheck_Cond_Missing(p_host_type_code is null, 'p_host_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_iccids := util_pkg.cast_cit2ct_varchar_s(p_iccids, true);
  ------------------------------
  api_ri_i_pkg.get_iccid_host_smart_ex
  (
    p_iccids => v_iccids,
    p_host_type_code => p_host_type_code,
    p_date => p_date,
    p_get_subhosts => true,
    p_host_ids => v_host_ids,
    p_subhost_ids => v_subhost_ids,
    p_no_ids => v_no_ids
  );
  ------------------------------
  p_result := get_result_cursor21
  (
    p_id_str => v_iccids,
    p_host_id => v_host_ids,
    p_subhost_id => v_subhost_ids,
    p_no_id => v_no_ids,
    p_date => p_date
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_msisdn_host
(
  p_msisdns util_pkg.cit_varchar_s,
  p_host_type_code varchar2,
  p_date date,
  p_result out sys_refcursor
)
is
  v_msisdns ct_varchar_s;
  v_host_ids ct_number;
  v_subhost_ids ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_msisdns);
  util_pkg.XCheck_Cond_Missing(p_host_type_code is null, 'p_host_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_msisdns := util_pkg.cast_cit2ct_varchar_s(p_msisdns, true);
  ------------------------------
  api_ri_i_pkg.get_msisdn_host_smart
  (
    p_msisdns => v_msisdns,
    p_host_type_code => p_host_type_code,
    p_date => p_date,
    p_get_subhosts => true,
    p_host_ids => v_host_ids,
    p_subhost_ids => v_subhost_ids
  );
  ------------------------------
  p_result := get_result_cursor20
  (
    p_id_str => v_msisdns,
    p_host_id => v_host_ids,
    p_subhost_id => v_subhost_ids,
    p_date => p_date
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_cur_imsi_pahost
(
  p_imsis util_pkg.cit_varchar_s,
  p_result out sys_refcursor
)
is
  v_date date := sysdate;
  v_imsis ct_varchar_s;
  v_host_ids ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_imsis);
  ------------------------------
  v_imsis := util_pkg.cast_cit2ct_varchar_s(p_imsis, true);
  ------------------------------
  v_host_ids := api_ri_i_pkg.get_cur_imsi_pahost_smart
  (
    p_imsis => v_imsis
  );
  ------------------------------
  p_result := get_result_cursor22
  (
    p_id_str => v_imsis,
    p_host_id => v_host_ids,
    p_date => v_date
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_cur_msisdn_pahost
(
  p_msisdns util_pkg.cit_varchar_s,
  p_result out sys_refcursor
)
is
  v_date date := sysdate;
  v_msisdns ct_varchar_s;
  v_host_ids ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_msisdns);
  ------------------------------
  v_msisdns := util_pkg.cast_cit2ct_varchar_s(p_msisdns, true);
  ------------------------------
  v_host_ids := api_ri_i_pkg.get_cur_msisdn_pahost_smart
  (
    p_msisdns => v_msisdns
  );
  ------------------------------
  --!_!p_result := get_result_cursor22
  p_result := get_result_cursor22_legacy
  (
    p_id_str => v_msisdns,
    p_host_id => v_host_ids,
    p_date => v_date
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure legacy_link_phone_sim
(
  p_msisdns util_pkg.cit_varchar_s,
  p_iccids util_pkg.cit_varchar_s,
  p_link_type_code varchar2,
  p_date date,
  p_user_name varchar2,
  p_result out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_marks ct_number;
  v_msisdns ct_varchar_s;
  v_iccids ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  v_msisdns := util_pkg.cast_cit2ct_varchar_s(p_msisdns, true);
  v_iccids := util_pkg.cast_cit2ct_varchar_s(p_iccids, true);
  ------------------------------
  etc_pkg999.legacy_link_phone_sim
  (
    p_msisdns => v_msisdns,
    p_iccids => v_iccids,
    p_link_type_code => p_link_type_code,
    p_date => p_date,
    p_user_id => util_ri.xget_user_id(p_user_name),
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_error_codes, util_pkg.c_ora_ok); --!_!mark ok to get failed (unmarked)
  ------------------------------
  v_msisdns := util_coll_pkg.get_unmarked_ol_ct_varchar_s(v_msisdns, v_marks);
  v_iccids := util_coll_pkg.get_unmarked_ol_ct_varchar_s(v_iccids, v_marks);
  v_error_codes := util_coll_pkg.get_unmarked_ol_ct_number(v_error_codes, v_marks);
  v_error_messages := util_coll_pkg.get_unmarked_ol_ct_varchar(v_error_messages, v_marks);
  ------------------------------
  p_result := get_result_cursor11
  (
    p_msisdn => v_msisdns,
    p_iccid => v_iccids,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_result_cursor00(p_sys_items ct_sys_item) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
select /*+ full(q)*/
  sys_item_id,
  sys_type_code,
  sys_error_code,
  sys_error_message,
  sys_id,
  sys_code,
  sys_name
  from
    (select t.*, rownum rn from table(p_sys_items) t) q
  where 1 = 1
  order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor98
(
  p_sys_type_code varchar2,
  p_sys_error_codes ct_number,
  p_sys_error_messages ct_varchar,
  p_sys_ids ct_number,
  p_sys_codes ct_varchar_s
) return sys_refcursor
is
begin
  ------------------------------
  return get_result_cursor99
  (
    p_sys_type_codes => util_pkg.make_ct_varchar_s(util_pkg.get_count_ct_number(p_sys_ids), p_sys_type_code),
    p_sys_error_codes => p_sys_error_codes,
    p_sys_error_messages => p_sys_error_messages,
    p_sys_ids => p_sys_ids,
    p_sys_codes => p_sys_codes
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor99
(
  p_sys_type_codes ct_varchar_s,
  p_sys_error_codes ct_number,
  p_sys_error_messages ct_varchar,
  p_sys_ids ct_number,
  p_sys_codes ct_varchar_s
) return sys_refcursor
is
  v_sys_items ct_sys_item;
begin
  ------------------------------
  v_sys_items := util_ri.cast_ct_array2ct_sys_item12
  (
    p_sys_type_codes => p_sys_type_codes,
    p_sys_error_codes => p_sys_error_codes,
    p_sys_error_messages => p_sys_error_messages,
    p_sys_ids => p_sys_ids,
    p_sys_codes => p_sys_codes
  );
  ------------------------------
  return get_result_cursor00(v_sys_items);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_result_cursor01
(
  p_msisdn ct_varchar_s,
  p_result out sys_refcursor,
  p_error_code ct_number,
  p_error_message ct_varchar
)
is
begin
  ------------------------------
  open p_result for
  select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
      q1.msisdn, q2.error_code, q3.error_message
    from
      (select column_value msisdn, rownum rn from table(p_msisdn)) q1,
      (select column_value error_code, rownum rn from table(p_error_code)) q2,
      (select column_value error_message, rownum rn from table(p_error_message)) q3
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    order by q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor02
(
  p_id ct_number,
  p_roaming_type ct_number,
  p_network_operator_id ct_number,
  p_result out sys_refcursor,
  p_error_code ct_number,
  p_error_message ct_varchar
)
is
begin
  ------------------------------
  open p_result for
  select /*+ ordered use_hash(q1 q2 q3 q4 q5) full(q1) full(q2) full(q3) full(q4) full(q5)*/
      q1.id, q2.roaming_type_code, q3.network_operator_id, q4.error_code, q5.error_message
    from
      (select column_value id, rownum rn from table(p_id)) q1,
      (select column_value roaming_type_code, rownum rn from table(p_roaming_type)) q2,
      (select column_value network_operator_id, rownum rn from table(p_network_operator_id)) q3,
      (select column_value error_code, rownum rn from table(p_error_code)) q4,
      (select column_value error_message, rownum rn from table(p_error_message)) q5
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    and q4.rn(+) = q1.rn
    and q5.rn(+) = q1.rn
    order by q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor03
(
  p_nn ct_varchar_s,
  p_msisdns ct_varchar_s,
  p_rns ct_varchar_s,
  p_network_operator_codes ct_varchar_s,
  p_error_codes ct_number,
  p_error_messages ct_varchar
) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q1 q2 q3 q4 q5 q6) full(q1) full(q2) full(q3) full(q4) full(q5) full(q6)*/
      q1.phone_number_with_rn, q2.msisdn, q3.routing_number, q4.network_operator_code, q5.error_code, q6.error_message
    from
      (select column_value phone_number_with_rn, rownum rn from table(p_nn)) q1,
      (select column_value msisdn, rownum rn from table(p_msisdns)) q2,
      (select column_value routing_number, rownum rn from table(p_rns)) q3,
      (select column_value network_operator_code, rownum rn from table(p_network_operator_codes)) q4,
      (select column_value error_code, rownum rn from table(p_error_codes)) q5,
      (select column_value error_message, rownum rn from table(p_error_messages)) q6
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    and q4.rn(+) = q1.rn
    and q5.rn(+) = q1.rn
    and q6.rn(+) = q1.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor04(p_personal_accounts ct_number, p_phone_type ct_varchar_s) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q1 q2) full(q1) full(q2)*/
      q1.personal_account, q2.phone_type
    from
      (select column_value personal_account, rownum rn from table(p_personal_accounts)) q1,
      (select column_value phone_type, rownum rn from table(p_phone_type)) q2
    where 1 = 1
    and q2.rn(+) = q1.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor05(p_msisdns ct_varchar_s, p_error_codes ct_number, p_error_messages ct_varchar) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
      q1.msisdn, q2.error_code, q3.error_message
    from
      (select column_value msisdn, rownum rn from table(p_msisdns)) q1,
      (select column_value error_code, rownum rn from table(p_error_codes)) q2,
      (select column_value error_message, rownum rn from table(p_error_messages)) q3
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor06
(
  p_msisdns ct_varchar_s,
  p_country_code ct_varchar_s,
  p_area_code ct_varchar_s,
  p_local_phone ct_varchar_s,
  p_error_codes ct_number,
  p_error_messages ct_varchar
) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q1 q2 q3 q4 q5 q6) full(q1) full(q2) full(q3) full(q4) full(q5) full(q6)*/
      q1.phone_number, q2.country_code, q3.area_code, q4.local_number, q5.error_code, q6.error_message
    from
      (select column_value phone_number, rownum rn from table(p_msisdns)) q1,
      (select column_value country_code, rownum rn from table(p_country_code)) q2,
      (select column_value area_code, rownum rn from table(p_area_code)) q3,
      (select column_value local_number, rownum rn from table(p_local_phone)) q4,
      (select column_value error_code, rownum rn from table(p_error_codes)) q5,
      (select column_value error_message, rownum rn from table(p_error_messages)) q6
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    and q4.rn(+) = q1.rn
    and q5.rn(+) = q1.rn
    and q6.rn(+) = q1.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor07
(
  p_msisdns ct_varchar_s,
  p_iccids ct_varchar_s,
  p_imsis ct_varchar_s
) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
      q1.msisdn, q2.iccid, q3.imsi
    from
      (select column_value msisdn, rownum rn from table(p_msisdns)) q1,
      (select column_value iccid, rownum rn from table(p_iccids)) q2,
      (select column_value imsi, rownum rn from table(p_imsis)) q3
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor08
(
  p_msisdns ct_varchar_s,
  p_date_froms ct_date
) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q1 q2)*/
    q1.msisdn,
    q2.date_from
  from
    (select column_value msisdn, rownum rn from table(p_msisdns)) q1,
    (select column_value date_from, rownum rn from table(p_date_froms)) q2
  where 1 = 1
    and q2.rn(+) = q1.rn
  order by
    q1.rn,
    q2.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor10
(
  p_msisdn_list ct_varchar_s,
  p_iccid_list ct_varchar_s,
  p_pin_list ct_varchar_s,
  p_pin2_list ct_varchar_s,
  p_puk_list ct_varchar_s,
  p_puk2_list ct_varchar_s,
  p_ki_list ct_nvarchar_s,
  p_auth_type_list ct_varchar_s,
  p_imsi ct_varchar_s
) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q1 q2 q3 q4 q5 q6 q7 q8 q9)
       full(q1) full(q2) full(q3)
       full(q4) full(q5) full(q6)
       full(q7) full(q8) full(q9)*/
      q1.msisdn,
      q9.imsi,
      q2.sn,
      q3.pin,
      q5.puk,
      q4.pin2,
      q6.puk2,
      q7.ki,
      q8.authent_type
    from
      (select column_value msisdn, rownum rn from table(p_msisdn_list)) q1,
      (select column_value sn, rownum rn from table(p_iccid_list)) q2,
      (select column_value pin, rownum rn from table(p_pin_list)) q3,
      (select column_value pin2, rownum rn from table(p_pin2_list)) q4,
      (select column_value puk, rownum rn from table(p_puk_list)) q5,
      (select column_value puk2, rownum rn from table(p_puk2_list)) q6,
      (select column_value ki, rownum rn from table(p_ki_list)) q7,
      (select column_value authent_type, rownum rn from table(p_auth_type_list)) q8,
      (select column_value imsi, rownum rn from table(p_imsi)) q9
    where 1 = 1
    and q2.rn = q1.rn
    and q3.rn = q1.rn
    and q4.rn = q1.rn
    and q5.rn = q1.rn
    and q6.rn = q1.rn
    and q7.rn = q1.rn
    and q8.rn = q1.rn
    and q9.rn = q1.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor11
(
  p_msisdn ct_varchar_s,
  p_iccid ct_varchar_s,
  p_error_codes ct_number,
  p_error_messages ct_varchar
) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q1 q2 q3 q4) full(q1) full(q2) full(q3) full(q4)*/
    q1.msisdn,
    q2.iccid,
    q3.error_code,
    q4.error_message
  from
    (select column_value msisdn, rownum rn from table(p_msisdn)) q1,
    (select column_value iccid, rownum rn from table(p_iccid)) q2,
    (select column_value error_code, rownum rn from table(p_error_codes)) q3,
    (select column_value error_message, rownum rn from table(p_error_messages)) q4
  where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    and q4.rn(+) = q1.rn
  order by
    q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor12
(
  p_iccid ct_varchar_s,
  p_error_codes ct_number,
  p_error_messages ct_varchar
) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
    q1.iccid,
    q2.error_code,
    q3.error_message
  from
    (select column_value iccid, rownum rn from table(p_iccid)) q1,
    (select column_value error_code, rownum rn from table(p_error_codes)) q2,
    (select column_value error_message, rownum rn from table(p_error_messages)) q3
  where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
  order by
    q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor13
(
  p_ps_id ct_number,
  p_pn_count ct_number
) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q1 q2) use_nl(q3) full(q1) full(q2) index(q3 PK_PHONE_NUMBER_SERIES)*/
    q1.phone_number_series_id,
    q3.country_code,
    q3.area_code,
    q2.pocet
  from
    (select column_value phone_number_series_id, rownum rn from table(p_ps_id)) q1,
    (select column_value pocet, rownum rn from table(p_pn_count)) q2,
    phone_number_series q3
  where 1 = 1
    and q2.rn = q1.rn
    and q3.phone_number_series_id = q1.phone_number_series_id
    and q2.pocet > 0
  order by
    q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor14
(
  p_ps_id ct_number,
  p_pn_count ct_number
) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q1 q2) use_nl(q3) full(q1) full(q2) index(q3 PK_PHONE_NUMBER_SERIES)*/
         q1.phone_number_series_id,
         q3.country_code,
         q3.area_code,
         q2.pocet,
         (q3.country_code || q3.area_code || q3.local_number_start) start_seria,
         (q3.country_code || q3.area_code || q3.local_number_end) end_seria,
         q3.host_id
    from
      (select column_value phone_number_series_id, rownum rn from table(p_ps_id)) q1,
      (select column_value pocet, rownum rn from table(p_pn_count)) q2,
      phone_number_series q3
    where 1 = 1
    and q2.rn = q1.rn
    and q3.phone_number_series_id = q1.phone_number_series_id
    and q2.pocet > 0
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor15
(
  p_msisdn ct_varchar_s,
  p_msisdn_abc ct_varchar_s,
  p_type_abc ct_varchar_s,
  p_type_def ct_varchar_s,
  p_error_codes ct_number,
  p_error_messages ct_varchar
) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q0 q1 q2 q3 q4 q5) full(q0) full(q1) full(q2) full(q3) full(q4) full(q5)*/
         q0.msisdn,
         q1.msisdn_abc,
         q2.type_abc,
         q3.type_def,
         q4.error_code,
         q5.error_message
    from
      (select column_value msisdn, rownum rn from table(p_msisdn)) q0,
      (select column_value msisdn_abc, rownum rn from table(p_msisdn_abc)) q1,
      (select column_value type_abc, rownum rn from table(p_type_abc)) q2,
      (select column_value type_def, rownum rn from table(p_type_def)) q3,
      (select column_value error_code, rownum rn from table(p_error_codes)) q4,
      (select column_value error_message, rownum rn from table(p_error_messages)) q5
    where 1 = 1
    and q1.rn = q0.rn
    and q2.rn = q0.rn
    and q3.rn = q0.rn
    and q4.rn = q0.rn
    and q5.rn = q0.rn
    order by q0.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor20
(
  p_id_str ct_varchar_s,
  p_host_id ct_number,
  p_subhost_id ct_number,
  p_date date
) return sys_refcursor
is
  v_res sys_refcursor;
  v_host_code ct_varchar_s;
  v_host_name ct_varchar;
  v_host_type ct_varchar_s;
  v_host_address ct_varchar;
  v_subhost_code ct_varchar_s;
  v_subhost_name ct_varchar;
  v_subhost_type ct_varchar_s;
  v_subhost_address ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_host_code := util_ri.get_host_code(p_host_id, p_date, false);
  v_host_name := util_ri.get_host_name(p_host_id, p_date, false);
  v_host_type := util_ri.get_host_type(p_host_id, p_date, false);
  v_host_address := util_ri.get_host_address(p_host_id, p_date, false);
  ------------------------------
  v_subhost_code := util_ri.get_host_code(p_subhost_id, p_date, false);
  v_subhost_name := util_ri.get_host_name(p_subhost_id, p_date, false);
  v_subhost_type := util_ri.get_host_type(p_subhost_id, p_date, false);
  v_subhost_address := util_ri.get_host_address(p_subhost_id, p_date, false);
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q00 q01 q02 q03 q04 q05 q06 q07 q08 q09 q10)*/
      q00.id_str,
      q01.host_id,
      q02.host_code,
      q03.host_name,
      q04.host_type,
      q05.host_address,
      q06.subhost_id,
      q07.subhost_code,
      q08.subhost_name,
      q09.subhost_type,
      q10.subhost_address
    from
      (select column_value id_str, rownum rn from table(p_id_str)) q00,
      (select column_value host_id, rownum rn from table(p_host_id)) q01,
      (select column_value host_code, rownum rn from table(v_host_code)) q02,
      (select column_value host_name, rownum rn from table(v_host_name)) q03,
      (select column_value host_type, rownum rn from table(v_host_type)) q04,
      (select column_value host_address, rownum rn from table(v_host_address)) q05,
      (select column_value subhost_id, rownum rn from table(p_subhost_id)) q06,
      (select column_value subhost_code, rownum rn from table(v_subhost_code)) q07,
      (select column_value subhost_name, rownum rn from table(v_subhost_name)) q08,
      (select column_value subhost_type, rownum rn from table(v_subhost_type)) q09,
      (select column_value subhost_address, rownum rn from table(v_subhost_address)) q10
    where 1 = 1
      and q01.rn(+) = q00.rn
      and q02.rn(+) = q00.rn
      and q03.rn(+) = q00.rn
      and q04.rn(+) = q00.rn
      and q05.rn(+) = q00.rn
      and q06.rn(+) = q00.rn
      and q07.rn(+) = q00.rn
      and q08.rn(+) = q00.rn
      and q09.rn(+) = q00.rn
      and q10.rn(+) = q00.rn
    order by q00.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor21
(
  p_id_str ct_varchar_s,
  p_host_id ct_number,
  p_subhost_id ct_number,
  p_no_id ct_number,
  p_date date
) return sys_refcursor
is
  v_res sys_refcursor;
  v_host_code ct_varchar_s;
  v_host_name ct_varchar;
  v_host_type ct_varchar_s;
  v_host_address ct_varchar;
  v_subhost_code ct_varchar_s;
  v_subhost_name ct_varchar;
  v_subhost_type ct_varchar_s;
  v_subhost_address ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_host_code := util_ri.get_host_code(p_host_id, p_date, false);
  v_host_name := util_ri.get_host_name(p_host_id, p_date, false);
  v_host_type := util_ri.get_host_type(p_host_id, p_date, false);
  v_host_address := util_ri.get_host_address(p_host_id, p_date, false);
  ------------------------------
  v_subhost_code := util_ri.get_host_code(p_subhost_id, p_date, false);
  v_subhost_name := util_ri.get_host_name(p_subhost_id, p_date, false);
  v_subhost_type := util_ri.get_host_type(p_subhost_id, p_date, false);
  v_subhost_address := util_ri.get_host_address(p_subhost_id, p_date, false);
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q00 q01 q02 q03 q04 q05 q06 q07 q08 q09 q10, q11)*/
      q00.id_str,
      q01.host_id,
      q02.host_code,
      q03.host_name,
      q04.host_type,
      q05.host_address,
      q06.subhost_id,
      q07.subhost_code,
      q08.subhost_name,
      q09.subhost_type,
      q10.subhost_address,
      q11.network_operator_id
    from
      (select column_value id_str, rownum rn from table(p_id_str)) q00,
      (select column_value host_id, rownum rn from table(p_host_id)) q01,
      (select column_value host_code, rownum rn from table(v_host_code)) q02,
      (select column_value host_name, rownum rn from table(v_host_name)) q03,
      (select column_value host_type, rownum rn from table(v_host_type)) q04,
      (select column_value host_address, rownum rn from table(v_host_address)) q05,
      (select column_value subhost_id, rownum rn from table(p_subhost_id)) q06,
      (select column_value subhost_code, rownum rn from table(v_subhost_code)) q07,
      (select column_value subhost_name, rownum rn from table(v_subhost_name)) q08,
      (select column_value subhost_type, rownum rn from table(v_subhost_type)) q09,
      (select column_value subhost_address, rownum rn from table(v_subhost_address)) q10,
      (select column_value network_operator_id, rownum rn from table(p_no_id)) q11
    where 1 = 1
      and q01.rn(+) = q00.rn
      and q02.rn(+) = q00.rn
      and q03.rn(+) = q00.rn
      and q04.rn(+) = q00.rn
      and q05.rn(+) = q00.rn
      and q06.rn(+) = q00.rn
      and q07.rn(+) = q00.rn
      and q08.rn(+) = q00.rn
      and q09.rn(+) = q00.rn
      and q10.rn(+) = q00.rn
      and q11.rn(+) = q00.rn
    order by q00.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor22
(
  p_id_str ct_varchar_s,
  p_host_id ct_number,
  p_date date
) return sys_refcursor
is
  v_res sys_refcursor;
  v_host_code ct_varchar_s;
  v_host_name ct_varchar;
  v_host_type ct_varchar_s;
  v_host_address ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_host_code := util_ri.get_host_code(p_host_id, p_date, false);
  v_host_name := util_ri.get_host_name(p_host_id, p_date, false);
  v_host_type := util_ri.get_host_type(p_host_id, p_date, false);
  v_host_address := util_ri.get_host_address(p_host_id, p_date, false);
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q00 q01 q02 q03 q04 q05*/
      q00.id_str,
      q01.host_id,
      q02.host_code,
      q03.host_name,
      q04.host_type,
      q05.host_address
    from
      (select column_value id_str, rownum rn from table(p_id_str)) q00,
      (select column_value host_id, rownum rn from table(p_host_id)) q01,
      (select column_value host_code, rownum rn from table(v_host_code)) q02,
      (select column_value host_name, rownum rn from table(v_host_name)) q03,
      (select column_value host_type, rownum rn from table(v_host_type)) q04,
      (select column_value host_address, rownum rn from table(v_host_address)) q05
    where 1 = 1
      and q01.rn(+) = q00.rn
      and q02.rn(+) = q00.rn
      and q03.rn(+) = q00.rn
      and q04.rn(+) = q00.rn
      and q05.rn(+) = q00.rn
    order by q00.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!OpenGrok, /MAIN/Projects/ServiceSystems/MessagingGateway/Src/WcfPlugins/WcfAdapters/WCFAdapter/ResourceInventoryService/
--!_!MessagingGateway gets by position not by name
function get_result_cursor22_legacy
(
  p_id_str ct_varchar_s,
  p_host_id ct_number,
  p_date date
) return sys_refcursor
is
  v_res sys_refcursor;
  v_host_code ct_varchar_s;
  v_host_name ct_varchar;
  v_host_type ct_varchar_s;
  v_host_address ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_host_code := util_ri.get_host_code(p_host_id, p_date, false);
  v_host_name := util_ri.get_host_name(p_host_id, p_date, false);
  v_host_type := util_ri.get_host_type(p_host_id, p_date, false);
  v_host_address := util_ri.get_host_address(p_host_id, p_date, false);
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q00 q01 q02 q03 q04 q05*/
      q00.id_str legacy_id_str,
      q02.host_code legacy_host_code,
      q03.host_name legacy_host_name,
      q05.host_address legacy_host_address,
      q00.id_str,
      q01.host_id,
      q02.host_code,
      q03.host_name,
      q04.host_type,
      q05.host_address
    from
      (select column_value id_str, rownum rn from table(p_id_str)) q00,
      (select column_value host_id, rownum rn from table(p_host_id)) q01,
      (select column_value host_code, rownum rn from table(v_host_code)) q02,
      (select column_value host_name, rownum rn from table(v_host_name)) q03,
      (select column_value host_type, rownum rn from table(v_host_type)) q04,
      (select column_value host_address, rownum rn from table(v_host_address)) q05
    where 1 = 1
      and q01.rn(+) = q00.rn
      and q02.rn(+) = q00.rn
      and q03.rn(+) = q00.rn
      and q04.rn(+) = q00.rn
      and q05.rn(+) = q00.rn
    order by q00.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_cursor4ct_varchar_s(p_vals ct_varchar_s) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
select
  val
  from
    (select column_value val, rownum rn from table(p_vals)) q
  order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;

/
