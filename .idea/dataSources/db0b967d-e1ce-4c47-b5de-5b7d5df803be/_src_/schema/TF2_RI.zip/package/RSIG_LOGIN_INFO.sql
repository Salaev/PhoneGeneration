CREATE PACKAGE RSIG_LOGIN_INFO IS
/****************************************************************************
<header>
  <name>             	package RSIG_LOGIN_INFO
  </name>

  <author>           	Jaroslav Holub - STROM
  </author>
  <version>
  </version>

  <version>           1.0.7   31.07.2006    Petr Cepek
                      procedure Insert_Login_Info updated
                      procedure Delete_Login_Info updated
  </version>
  <version>          	1.0.6	  4.10.2005     Radomir Lipka
	                            Get_login_info - don't change password if p_pasword is null
  </version>
  <version>          	1.0.5	  21.6.2004     Jaroslav Holub
	                            Get_login_info - fix condition for show deleted rows
  </version>
  <version>          	1.0.4   18.6.2004     Jaroslav Holub
                                added columns deleted, user_id_of_change, and date_of_change
  </version>
  <version>          	1.0.3   28.5.2004     Jaroslav Holub
                                add handling for new column network_operator_id
  </version>
  <version>          	1.0.2   26.5.2004     Jaroslav Holub
                                improve documentation
  </version>
  <version>          	1.0.1   24.5.2004     Jaroslav Holub
                                created first version
  </version>

  <Description>      	Package contains procedure for managing Logins
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/
/****************************************************************************
  <header>
    <name>              procedure Insert_login_info
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.3   31.07.2006    Petr Cepek
                        columns from network_address moved to phone_number
    </version>

    <version>          	1.0.2   18.6.2004     Jaroslav Holub
                                added columns deleted, user_id_of_change, and date_of_change
   </version>
	 <version>           1.0.1	  28.5.2004     Jaroslav Holub
                                add handling for new column network_operator_id
    </version>
    <version>           1.0.0   24.5.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       Procedure inserts new login.

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Catalogues
    </Application>

    <Parameters>
                          p_network_address_id 		inpute prams
						  p_login
						  p_password
						  p_user_status
						  p_password_next_change
						  p_login_info_id
,
                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
procedure Insert_login_info(
  p_login 				IN	LOGIN_INFO.LOGIN%TYPE ,
  p_password 			IN	LOGIN_INFO.PASSWORD%TYPE ,
  p_user_status 		IN	LOGIN_INFO.USER_STATUS%TYPE ,
  p_password_next_change IN LOGIN_INFO.PASSWORD_NEXT_CHANGE%TYPE ,
  p_network_operator_id	IN 	LOGIN_INFO.NETWORK_OPERATOR_ID%TYPE,
  p_user_id_of_change	IN 	USERS.USER_ID%TYPE,
  p_login_info_id 		OUT	LOGIN_INFO.LOGIN_INFO_ID%TYPE ,
  handle_tran       	IN  CHAR,
  p_raise_error     	IN  CHAR,
  error_code        	OUT NUMBER,
  error_message     	OUT VARCHAR2
);


/****************************************************************************
  <header>
    <name>              procedure Update_login_info
    </name>

    <author>            Jaroslav Holub
    </author>

  <version>          	1.0.2   18.6.2004     Jaroslav Holub
                                added columns deleted, user_id_of_change, and date_of_change
  </version>
	<version>           1.0.1	28.5.2004     Jaroslav Holub
                                add handling for new column network_operator_id
    </version>
    <version>           1.0.0   24.5.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>     Procedure update login information.

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Catalogues
    </Application>

	<Parameters>		p_login  - id of row to change
						p_network_address_id 	new value
						p_password 			new value
						p_user_status 		new value
						p_password_next_change new value
						p_login_info_id 	   new value
                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
procedure Update_login_info(
  p_password 			IN	LOGIN_INFO.PASSWORD%TYPE ,
  p_user_status 		IN	LOGIN_INFO.USER_STATUS%TYPE ,
  p_password_next_change IN LOGIN_INFO.PASSWORD_NEXT_CHANGE%TYPE ,
  p_network_operator_id IN 	LOGIN_INFO.NETWORK_OPERATOR_ID%TYPE,
  p_login_info_id 		IN	LOGIN_INFO.LOGIN_INFO_ID%TYPE ,
  p_user_id_of_change	IN 	USERS.USER_ID%TYPE,
  handle_tran       	IN  CHAR,
  p_raise_error     	IN  CHAR,
  error_code        	OUT NUMBER,
  error_message     	OUT VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Delete_Login_Info
    </name>

    <author>            Jaroslav Holub
    </author>

  <version>            1.0.3   31.07.2006    Petr Cepek
                        columns from network_address moved to phone_number
  </version>
	<version>			        1.0.2	  3.8.2004     Jaroslav Holub
								        fixed for time difference between client and server,
								        date should be null and it means sysdate
	</version>
  	<version>          	1.0.1   18.6.2004     Jaroslav Holub
                                added columns deleted, user_id_of_change, and date_of_change
  	</version>
    <version>           1.0.0   24.5.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       Procedure set given login as deleted.

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Catalogues
    </Application>

    <Parameters>
                        p_login_info_id		- id of row to delete
                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
procedure Delete_Login_Info(
  p_login_info_id		IN 	LOGIN_INFO.LOGIN_INFO_ID%TYPE,
  p_date				IN	DATE,
  p_user_id_of_change	IN 	USERS.USER_ID%TYPE,
  handle_tran       IN  CHAR,
  p_raise_error     IN  CHAR,
  error_code        OUT NUMBER,
  error_message     OUT VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Get_login_info
    </name>

    <author>            Jaroslav Holub
    </author>

  	<version>          	1.0.3	21.6.2004     Jaroslav Holub
	                            fix condition for show deleted rows
  	</version>
  	<version>          	1.0.2	18.6.2004     Jaroslav Holub
	                            added columns deleted, user_id_of_change, and date_of_change
  	</version>
	<version>           1.0.1	28.5.2004     Jaroslav Holub
                                add handling for new column network_operator_id
    </version>
    <version>           1.0.0   24.5.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       Procedure returns logins for given network operator.

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Catalogues
    </Application>

    <Parameters>
                        p_network_address_id 	net addr id or NULL
                        p_login_info_id 	  	login info id or NULL
                        p_login 			   	login or NULL
                        p_user_status 		   	user status or null
                        p_password_next_change 	date of next change or null
                        handle_tran       		CHAR,
                        p_raise_error     		CHAR,
                        error_code        		NUMBER,
                        error_message     		VARCHAR2
						result_list 			output cursor
    </Parameters>

  </header>
****************************************************************************/
procedure Get_login_info(
  p_network_address_id 	IN	LOGIN_INFO.NETWORK_ADDRESS_ID%TYPE,
  p_login_info_id 		IN	LOGIN_INFO.LOGIN_INFO_ID%TYPE,
  p_login 				IN	LOGIN_INFO.LOGIN%TYPE,
  p_user_status 		IN	LOGIN_INFO.USER_STATUS%TYPE,
  p_password_next_change IN LOGIN_INFO.PASSWORD_NEXT_CHANGE%TYPE,
  p_network_operator_id	IN 	LOGIN_INFO.NETWORK_OPERATOR_ID%TYPE,
  p_show_deleted		IN 	CHAR,
  p_raise_error     	IN  CHAR,
  error_code        	OUT NUMBER,
  error_message     	OUT VARCHAR2,
  result_list 			OUT sys_refcursor
);



END RSIG_LOGIN_INFO;
/
