CREATE package body roaming_cache_pkg is
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_roaming_cache_i
(
  p_range_date_from date,
  p_range_date_to date,
  p_host_nos out sys_refcursor,
  p_roaming_types out sys_refcursor,
  p_phone_series out sys_refcursor,
  p_mcc_mnc_nos out sys_refcursor,
  p_goers out sys_refcursor,
  p_comers out sys_refcursor
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  open p_host_nos for
  select /*+ full(z)*/
    host_code,
    network_operator_id
  from host z
  where 1 = 1
    and deleted is null
  order by host_code
  ;
  ------------------------------
  open p_roaming_types for
  select /*+ ordered use_hash(none) use_nl(la, bs, h)
    full(non)
    full(none)
    index_asc(h PK_HOST)
    index_asc(la PK_LOCATION_AREA)
    index_asc(bs PK_BASE_STATION)
    */
    non.network_operator_id,
    non.neighbouring_operator_id,
    h.host_code,
    la.location_area_code,
    bs.base_station_code,
    non.roaming_type_code + nvl(none.ext_roaming_type_code, 0) roaming_type_code,
    non.start_date,
    non.end_date
  from
    network_operator_neighbours non,
    (
    select /*+ full(q)*/
      roaming_definition_id,
      SUM(ext_roaming_type_code) ext_roaming_type_code
      from network_operator_neighb_ext q
      group by roaming_definition_id
    ) none,
    location_area la,
    base_station bs,
    host h
  where 1 = 1
    and non.start_date <= p_range_date_to
    --!_!and nvl(non.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
    and nvl(non.end_date, util_pkg.c_plus_infinity) >= p_range_date_from
    and none.roaming_definition_id(+) = non.roaming_definition_id
    and la.location_area_id(+) = non.location_area_id
    and bs.base_station_id(+) = non.base_station_id
    and h.host_id(+) = la.host_id
  order by
    network_operator_id,
    neighbouring_operator_id,
    host_code,
    location_area_code,
    base_station_code,
    roaming_type_code,
    start_date,
    end_date
  ;
  ------------------------------
  open p_phone_series for
  select /*+ ordered use_nl(pso, n)
    full(pns)
    index_asc(pso I_PSO_PNS)
    index_asc(n PK_NETWORK_OPERATOR)
    */
    pns.country_code || pns.area_code || pns.local_number_start phone_number_start,
    pns.country_code || pns.area_code || pns.local_number_end phone_number_end,
    pso.network_operator_id,
    pso.start_date,
    --!_!pso.end_date
    nvl(pso.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) end_date
  from
    phone_number_series pns,
    phone_series_operator pso,
    network_operator n
  where 1 = 1
    and pns.deleted is null
    and pso.phone_number_series_id = pns.phone_number_series_id
    and pso.start_date <= p_range_date_to
    and nvl(pso.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
    --!_!and nvl(pso.end_date, util_pkg.c_plus_infinity) >= p_range_date_from
    and n.network_operator_id = pso.network_operator_id
    and n.network_operator_type is null --!_!only own, no EX
  order by
    --!_!phone_number_start,
    --!_!phone_number_end,
    TO_NUMBER(pns.country_code || pns.area_code || pns.local_number_start), --!_!VERY IMPORTANT; dataStorage.AlPhoneSeriesCache MUST BE ORDERD by StartNumber as decimal (not string)
    start_date,
    end_date,
    network_operator_id
  ;
  ------------------------------
  open p_mcc_mnc_nos for
  select /*+ full(z)*/
    mcc,
    mnc,
    network_operator_id
  from network_operator z
  where 1 = 1
    and deleted is null
  order by network_operator_id
  ;
  ------------------------------
  p_goers := mnp_pkg.get_goers2
  (
    p_na_ids => null,
    p_range_date_from => p_range_date_from,
    p_range_date_to => p_range_date_to
  );
  ------------------------------
  p_comers := mnp_pkg.get_comers2
  (
    p_na_ids => null,
    p_range_date_from => p_range_date_from,
    p_range_date_to => p_range_date_to
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_roaming_cache_changes_i
(
  p_cache_guid varchar2,
  p_range_date_from date,
  p_range_date_to date,
  p_date date,
  p_user_id number,
  p_goers out sys_refcursor,
  p_comers out sys_refcursor
)
is
  v_na_ids ct_number;
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_cache_guid is null, 'p_cache_guid');
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_agroup_data.xpget1_dsc_nocase(p_pid => c_agroup_id_roam_cache_list, p_dsc => p_cache_guid, p_date => p_date);
  ------------------------------
  vp_agroup_data.version_touch_date1
  (
    p_id => v_rec.agroup_data_id,
    p_user_id => p_user_id,
    p_date1 => SYSDATE,
    p_date => p_date
  );
  ------------------------------
  select
    id1
  bulk collect into
    v_na_ids
  from table(vp_agroup_data.getN(p_pid => v_rec.id1, p_date => p_date))
  ;
  ------------------------------
  p_goers := mnp_pkg.get_goers2
  (
    p_na_ids => v_na_ids,
    p_range_date_from => p_range_date_from,
    p_range_date_to => p_range_date_to
  );
  ------------------------------
  p_comers := mnp_pkg.get_comers2
  (
    p_na_ids => v_na_ids,
    p_range_date_from => p_range_date_from,
    p_range_date_to => p_range_date_to
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function gen_subscriber_group_i
(
  p_user_id number,
  p_date date
) return number
is
  v_rec agroup%rowtype := null;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_rec.agroup_id := vp_agroup.acquire_id;
  v_rec.agroup_name := c_agroup_name_subs_gen_prefix || util_pkg.char_to_nchar(util_pkg.number_to_char(v_rec.agroup_id)); --!_! uniq
  v_rec.user_id := p_user_id;
  v_rec.date_from := p_date;
  ------------------------------
  vp_agroup.version_open(p_rec => v_rec);
  ------------------------------
  return v_rec.agroup_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure reg_roam_cache_subscr_i
(
  p_cache_guid varchar2,
  p_date date,
  p_user_id number
)
is
  v_rec agroup_data%rowtype := null;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_cache_guid is null, 'p_cache_guid');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec.agroup_id := c_agroup_id_roam_cache_list;
  v_rec.id1 := gen_subscriber_group_i(p_user_id => p_user_id, p_date => p_date);
  v_rec.date_from := p_date;
  v_rec.dsc := p_cache_guid;
  v_rec.date1 := p_date;
  v_rec.user_id := p_user_id;
  ------------------------------
  vp_agroup_data.version_open(p_rec => v_rec, p_unq_mode => vp_agroup_data.c_unq_dsc_ic);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure unreg_roam_cache_subscr_i
(
  p_cache_guid varchar2,
  p_date date,
  p_user_id number
)
is
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_cache_guid is null, 'p_cache_guid');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_agroup_data.xpget1_dsc_nocase(p_pid => c_agroup_id_roam_cache_list, p_dsc => p_cache_guid, p_date => p_date);
  ------------------------------
  vp_agroup.version_close
  (
    p_id => v_rec.id1,
    p_user_id => p_user_id,
    p_date_from => p_date,
    p_hard_delete => FALSE
  );
  ------------------------------
  vp_agroup_data.version_close
  (
    p_id => v_rec.agroup_data_id,
    p_user_id => p_user_id,
    p_date_from => p_date,
    p_hard_delete => FALSE
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure remove_roam_cache_subscr_i
(
  p_cache_guid varchar2,
  p_date_from date,
  p_user_id number
)
is
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_cache_guid is null, 'p_cache_guid');
  util_pkg.XCheck_Cond_Missing(p_date_from is null, 'p_date_from');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_agroup_data.xpget1_dsc_nocase(p_pid => c_agroup_id_roam_cache_list, p_dsc => p_cache_guid, p_date => p_date_from);
  ------------------------------
  group_pkg.group_hard_del_all_items
  (
    p_group_id => v_rec.id1,
    p_user_id => p_user_id
  );
  ------------------------------
  vp_agroup.version_close
  (
    p_id => v_rec.id1,
    p_user_id => p_user_id,
    p_date_from => p_date_from,
    p_hard_delete => TRUE
  );
  ------------------------------
  vp_agroup_data.version_close
  (
    p_id => v_rec.agroup_data_id,
    p_user_id => p_user_id,
    p_date_from => p_date_from,
    p_hard_delete => TRUE
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_cache_groups_i(p_date date) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select
    id1
  bulk collect into
    v_res
  from table(vp_agroup_data.getN(p_pid => c_agroup_id_roam_cache_list, p_date => p_date))
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_cache_groups2_i return ct_number
is
begin
  ------------------------------
  return get_cache_groups_i(sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_roaming_cache
(
  p_cache_guid varchar2,
  p_range_date_from date,
  p_range_date_to date,
  p_HostNOs out sys_refcursor,
  p_RoamingTypes out sys_refcursor,
  p_phones out sys_refcursor,
  p_MCCMNCNOs out sys_refcursor,
  p_gone_subscribers out sys_refcursor,
  p_come_in_subscribers out sys_refcursor
)
is
  v_user_id number;
begin
  ------------------------------
  v_user_id := util_ri.xget_default_user_id;
  ------------------------------
  at_reg_roam_cache_subscr(p_cache_guid => p_cache_guid, p_user_id => v_user_id);
  ------------------------------
  get_roaming_cache_i
  (
    p_range_date_from => p_range_date_from,
    p_range_date_to => p_range_date_to,
    p_host_nos => p_HostNOs,
    p_roaming_types => p_RoamingTypes,
    p_phone_series => p_phones,
    p_mcc_mnc_nos => p_MCCMNCNOs,
    p_goers => p_gone_subscribers,
    p_comers => p_come_in_subscribers
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_reg_roam_cache_subscr
(
  p_cache_guid varchar2,
  p_user_id number
)
is
  pragma autonomous_transaction;
  v_date date := sysdate;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_cache_guid is null, 'p_cache_guid');
  ------------------------------
  reg_roam_cache_subscr_i(p_cache_guid, v_date, p_user_id);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_unreg_roam_cache_subscr
(
  p_cache_guid varchar2,
  p_user_id number
)
is
  pragma autonomous_transaction;
  v_date date := sysdate;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_cache_guid is null, 'p_cache_guid');
  ------------------------------
  unreg_roam_cache_subscr_i(p_cache_guid, v_date, p_user_id);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_remove_roam_cache_subscr
(
  p_cache_guid varchar2,
  p_date_from date,
  p_user_id number
)
is
  pragma autonomous_transaction;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_cache_guid is null, 'p_cache_guid');
  util_pkg.XCheck_Cond_Missing(p_date_from is null, 'p_date_from');
  ------------------------------
  remove_roam_cache_subscr_i(p_cache_guid, p_date_from, p_user_id);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ported_phones2group
(
  p_group_id number,
  p_id1 ct_number,
  p_id2 ct_number,
  p_date date,
  p_user_id number
)
is
  pragma autonomous_transaction;
begin
  ------------------------------
  group_pkg.group_add_items_id1_id2
  (
    p_group_id => p_group_id,
    p_unique => FALSE,
    p_id1 => p_id1,
    p_id2 => p_id2,
    p_date => p_date,
    p_user_id => p_user_id
  );
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ported_phones
(
  p_na_id ct_number,
  p_potype ct_number,
  p_user_id number,
  p_date date
)
is
  pragma autonomous_transaction;
  v_subs_ids ct_number;
  v_main_count number;
  v_subs_count number;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheckP_FS_ct_number(p_potype, 'p_na_ids');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_id) != v_main_count, 'p_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_potype) != v_main_count, 'p_potype.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    return;
  end if;
  ------------------------------
  v_subs_ids := get_cache_groups2_i;
  ------------------------------
  v_subs_count := util_pkg.get_count_ct_number(v_subs_ids);
  ------------------------------
  for v_i in 1..v_subs_count
  loop
    ------------------------------
    add_ported_phones2group
    (
      p_group_id => v_subs_ids(v_i),
      p_id1 => p_na_id,
      p_id2 => p_potype,
      p_date => p_date,
      p_user_id => p_user_id
    );
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  null; --!_!
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ported_phones2
(
  p_na_id number,
  p_potype number,
  p_user_id number,
  p_date date
)
is
  v_na_id ct_number;
  v_potype ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_potype is null, 'p_potype');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  util_pkg.add_ct_number_val(v_potype, p_potype);
  ------------------------------
  add_ported_phones
  (
    p_na_id => v_na_id,
    p_potype => v_potype,
    p_user_id => p_user_id,
    p_date =>p_date
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_cache_activity_date
(
  p_date date,
  p_dsc out ct_varchar,
  p_date1 out ct_date
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select
    dsc,
    date1
  bulk collect into
    p_dsc,
    p_date1
  from table(vp_agroup_data.getN(p_pid => c_agroup_id_roam_cache_list, p_date => p_date))
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_expired_cache
(
  p_date date,
  p_delay_date date,
  p_dsc out ct_varchar,
  p_date_to out ct_date
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_delay_date is null, 'p_delay_date');
  ------------------------------
  select
    date_to,
    dsc
  bulk collect into
    p_date_to,
    p_dsc
  from table(vp_agroup_data.getN_closed(p_pid => c_agroup_id_roam_cache_list, p_date => p_date, p_closed_on_date => p_delay_date))
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
