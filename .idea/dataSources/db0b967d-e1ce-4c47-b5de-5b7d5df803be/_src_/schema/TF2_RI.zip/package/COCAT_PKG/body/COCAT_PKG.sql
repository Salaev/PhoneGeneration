CREATE package body COCAT_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure correlate_ids_codes
(
    p_ids_in ct_number,
    p_codes_in ct_varchar_s,
    p_ids_real ct_number,
    p_codes_real ct_varchar_s,
    p_ids_out out ct_number,
    p_codes_out out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_main_count number;
  --
  v_pos_ids_null ct_number;
  v_pos_codes_null ct_number;
  v_pos_ids_codes_null ct_number;
  --
  v_pos_ids_not_found ct_number;
  v_pos_codes_not_found ct_number;
  --
  v_pos_ids_not_match ct_number;
  --!_!v_pos_codes_not_match ct_number;
  --
  v_ids_tmp1 ct_number;
  v_ids_tmp2 ct_number;
  --
  v_codes_tmp1 ct_varchar_s;
  --!_!v_codes_tmp2 ct_varchar_s;
  --
begin
  ------------------------------
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids_in);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids_in) != v_main_count, 'p_ids_in.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_codes_in) != v_main_count, 'p_codes_in.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids_real) != v_main_count, 'p_ids_real.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_codes_real) != v_main_count, 'p_codes_real.count != v_main_count');
  ------------------------------
  --!_!create [erros] in [OK] state
  p_error_codes := util_pkg.make_ct_number(v_main_count, util_pkg.c_ora_ok); --!_!
  p_error_messages := util_pkg.make_ct_varchar(v_main_count, util_pkg.c_msg_ok); --!_!
  ------------------------------
  --!_! significant order of set_val_by_pos2_ct_number(p_error_codes)
  --!_! later steps can rewrite same p_error_codes
  ------------------------------
  ------------------------------
  --!_! 1
  ------------------------------
  v_pos_ids_null := util_pkg.mark2pos(util_pkg.mark_val_ct_number(p_ids_in, NULL), TRUE);
  v_pos_codes_null := util_pkg.mark2pos(util_pkg.mark_val_ct_varchar_s(p_codes_in, NULL), TRUE);
  ------------------------------
  v_pos_ids_codes_null := util_pkg.filter_val_ct_number(v_pos_ids_null, v_pos_codes_null, TRUE);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_pkg.c_ora_object_empty, v_pos_ids_codes_null);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_pkg.c_msg_object_empty, v_pos_ids_codes_null);
  ------------------------------
  ------------------------------
  --!_! 2.1
  ------------------------------
  v_codes_tmp1 := p_codes_real;
  util_pkg.set_val_by_pos2_ct_varchar_s(v_codes_tmp1, util_pkg.c_no_value_not_null_varchar_s, v_pos_ids_null); --!_! makes NOT null for input nulls
  ------------------------------
  v_pos_ids_not_found := util_pkg.mark2pos(util_pkg.mark_val_ct_varchar_s(v_codes_tmp1, NULL), TRUE);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_pkg.c_ora_object_not_found, v_pos_ids_not_found);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_pkg.c_msg_object_not_found, v_pos_ids_not_found);
  ------------------------------
  ------------------------------
  --!_! 2.2
  ------------------------------
  v_ids_tmp1 := p_ids_real;
  util_pkg.set_val_by_pos2_ct_number(v_ids_tmp1, util_pkg.c_no_value_not_null_number, v_pos_codes_null); --!_! makes NOT null for input nulls
  ------------------------------
  v_pos_codes_not_found := util_pkg.mark2pos(util_pkg.mark_val_ct_number(v_ids_tmp1, NULL), TRUE);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_pkg.c_ora_object_not_found, v_pos_codes_not_found);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_pkg.c_msg_object_not_found, v_pos_codes_not_found);
  ------------------------------
  ------------------------------
  --!_! 3.1
  ------------------------------
  v_ids_tmp1 := p_ids_in;
  util_pkg.set_val_by_pos2_ct_number(v_ids_tmp1, NULL, v_pos_codes_null);
  util_pkg.set_val_by_pos2_ct_number(v_ids_tmp1, NULL, v_pos_ids_not_found);
  ------------------------------
  v_ids_tmp2 := p_ids_real;
  util_pkg.set_val_by_pos2_ct_number(v_ids_tmp2, NULL, v_pos_ids_null);
  util_pkg.set_val_by_pos2_ct_number(v_ids_tmp2, NULL, v_pos_codes_not_found);
  ------------------------------
  v_pos_ids_not_match := util_pkg.mark2pos(util_pkg.cmp_ct_number(v_ids_tmp1, v_ids_tmp2), TRUE, util_pkg.C_FALSE);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_pkg.c_ora_object_wrong, v_pos_ids_not_match);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_pkg.c_msg_object_wrong, v_pos_ids_not_match);
  ------------------------------
  ------------------------------
  --!_!--!_! 3.2 same result as 3.1
  --!_!------------------------------
  --!_!v_codes_tmp1 := p_codes_in;
  --!_!util_pkg.set_val_by_pos2_ct_varchar_s(v_codes_tmp1, NULL, v_pos_ids_null);
  --!_!util_pkg.set_val_by_pos2_ct_varchar_s(v_codes_tmp1, NULL, v_pos_codes_not_found);
  --!_!------------------------------
  --!_!v_codes_tmp2 := p_codes_real;
  --!_!util_pkg.set_val_by_pos2_ct_varchar_s(v_codes_tmp2, NULL, v_pos_codes_null);
  --!_!util_pkg.set_val_by_pos2_ct_varchar_s(v_codes_tmp2, NULL, v_pos_ids_not_found);
  --!_!------------------------------
  --!_!v_pos_codes_not_match := util_pkg.mark2pos(util_pkg.cmp_ct_varchar_s(v_codes_tmp1, v_codes_tmp2), TRUE, util_pkg.C_FALSE);
  --!_!------------------------------
  --!_!util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_pkg.c_ora_object_wrong, v_pos_codes_not_match);
  --!_!util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_pkg.c_msg_object_wrong, v_pos_codes_not_match);
  ------------------------------
  ------------------------------
  p_ids_out := util_pkg.supplement_ct_number(p_ids_in, p_ids_real, FALSE);
  p_codes_out := util_pkg.supplement_ct_varchar_s(p_codes_in, p_codes_real, FALSE);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure correlate_ids
(
    p_ids_in ct_number,
    p_codes_real ct_varchar_s,
    p_ids_out out ct_number,
    p_codes_out out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_main_count number;
  --
  v_codes_in ct_varchar_s;
  v_ids_real ct_number;
  --
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids_in);
  ------------------------------
  v_codes_in := util_pkg.make_ct_varchar_s(v_main_count, NULL);
  v_ids_real := util_pkg.make_ct_number(v_main_count, NULL);
  ------------------------------
  correlate_ids_codes
  (
    p_ids_in => p_ids_in,
    p_codes_in => v_codes_in,
    p_ids_real => v_ids_real,
    p_codes_real => p_codes_real,
    p_ids_out => p_ids_out,
    p_codes_out => p_codes_out,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure correlate_codes
(
    p_codes_in ct_varchar_s,
    p_ids_real ct_number,
    p_ids_out out ct_number,
    p_codes_out out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_main_count number;
  --
  v_ids_in ct_number;
  v_codes_real ct_varchar_s;
  --
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_codes_in);
  ------------------------------
  v_ids_in := util_pkg.make_ct_number(v_main_count, NULL);
  v_codes_real := util_pkg.make_ct_varchar_s(v_main_count, NULL);
  ------------------------------
  correlate_ids_codes
  (
    p_ids_in => v_ids_in,
    p_codes_in => p_codes_in,
    p_ids_real => p_ids_real,
    p_codes_real => v_codes_real,
    p_ids_out => p_ids_out,
    p_codes_out => p_codes_out,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xget_type_pos
(
    p_type_code varchar2,
    p_type_codes ct_varchar_s,
    p_transparent boolean,
    p_main_count_opaque number,
    p_trim_empty boolean := TRUE
) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  if p_transparent
  then
    ------------------------------
    util_pkg.XCheck_Cond_Missing(p_type_code is null, 'p_type_code');
    --!_!util_pkg.XCheckP_FS_ct_varchar_s(p_type_codes, 'p_type_codes');
    util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
    ------------------------------
    v_res := util_pkg.mark2pos(util_pkg.mark_val_ct_varchar_s(p_type_codes, p_type_code), p_trim_empty); --!_! can trim size
    ------------------------------
    return v_res;
    ------------------------------
  else
    ------------------------------
    --!_! here p_type_code and p_type_codes is not used
    ------------------------------
    v_res := util_pkg.make_pivot_or_empty(p_main_count_opaque);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!p_type_code and p_type_codes is not used if NOT p_transparent
--!_!initialize [error status] with [OK] state
------------------------------
function xprepare_ids_part1a
(
    p_transparent boolean,
    p_type_code varchar2,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_dates ct_date,
    p_main_count out number,
    p_poses_o out ct_number,
    p_ids_o out ct_number,
    p_codes_o out ct_varchar_s,
    p_dates_o out ct_date,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_transparent is null, 'p_transparent');
  --!_!util_pkg.XCheck_Cond_Missing(p_type_code is null, 'p_type_code');
  ------------------------------
  p_main_count := util_pkg.get_count_ct_number(p_ids);
  util_pkg.XCheck_Cond_Invalid(p_transparent AND util_pkg.get_count_ct_varchar_s(p_type_codes) != p_main_count, 'p_type_codes.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != p_main_count, 'p_ids.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_codes) != p_main_count, 'p_codes.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_dates) != p_main_count, 'p_dates.count != p_main_count');
  ------------------------------
  p_poses_o := xget_type_pos(p_type_code, p_type_codes, p_transparent, p_main_count);
  ------------------------------
  if util_pkg.get_count_ct_number(p_poses_o) = 0
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
  if p_transparent
  then
    ------------------------------
    util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_error_codes_io) != p_main_count, 'p_error_codes_io.count != p_main_count');
    util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_error_messages_io) != p_main_count, 'p_error_messages_io.count != p_main_count');
    ------------------------------
  else
    ------------------------------
    p_error_codes_io := util_pkg.make_ct_number(p_main_count, NULL);
    p_error_messages_io := util_pkg.make_ct_varchar(p_main_count, NULL);
    ------------------------------
  end if;
  ------------------------------
  util_pkg.set_val_by_pos_ct_number(p_error_codes_io, util_pkg.c_ora_ok, p_poses_o); --!_!
  util_pkg.set_val_by_pos_ct_varchar(p_error_messages_io, util_pkg.c_msg_ok, p_poses_o); --!_!
  ------------------------------
  p_ids_o := util_pkg.get_by_pos_ct_number(p_ids, p_poses_o, TRUE);
  p_codes_o := util_pkg.get_by_pos_ct_varchar_s(p_codes, p_poses_o, TRUE);
  p_dates_o := util_pkg.get_by_pos_ct_date(p_dates, p_poses_o, TRUE);
  ------------------------------
  return TRUE;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xprepare_ids_part1b
(
    p_transparent boolean,
    p_type_code varchar2,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_extended_codes ct_varchar_s,
    p_dates ct_date,
    p_main_count out number,
    p_poses_o out ct_number,
    p_ids_o out ct_number,
    p_codes_o out ct_varchar_s,
    p_extended_codes_o out ct_varchar_s,
    p_dates_o out ct_date,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
) return boolean
is
begin
  ------------------------------
  if NOT
    xprepare_ids_part1a
    (
      p_transparent => p_transparent,
      p_type_code => p_type_code,
      p_type_codes => p_type_codes,
      p_ids => p_ids,
      p_codes => p_codes,
      p_dates => p_dates,
      p_main_count => p_main_count,
      p_poses_o => p_poses_o,
      p_ids_o => p_ids_o,
      p_codes_o => p_codes_o,
      p_dates_o => p_dates_o,
      p_error_codes_io => p_error_codes_io,
      p_error_messages_io => p_error_messages_io
    )
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_extended_codes) != p_main_count, 'p_extended_codes.count != p_main_count');
  ------------------------------
  p_extended_codes_o := util_pkg.get_by_pos_ct_varchar_s(p_extended_codes, p_poses_o, TRUE);
  ------------------------------
  return TRUE;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_ids_part2
(
    p_correlate_ids_codes boolean,
    p_ids_in ct_number,
    p_codes_in ct_varchar_s,
    p_ids_real ct_number,
    p_codes_real ct_varchar_s,
    p_ids_out out ct_number,
    p_codes_out out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_correlate_ids_codes is null, 'p_correlate_ids_codes');
  ------------------------------
  if p_correlate_ids_codes
  then
    ------------------------------
    correlate_ids_codes(p_ids_in, p_codes_in, p_ids_real, p_codes_real, p_ids_out, p_codes_out, p_error_codes, p_error_messages);
    ------------------------------
  else
    ------------------------------
    correlate_ids(p_ids_in, p_codes_real, p_ids_out, p_codes_out, p_error_codes, p_error_messages);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! p_main_count_opaque != p_poses.count
--!_! p_poses.count = p_ids.count
------------------------------
procedure prepare_ids_part3
(
    p_transparent boolean,
    p_main_count_opaque number,
    p_poses ct_number,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_error_codes ct_number,
    p_error_messages ct_varchar,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
)
is
  v_code_pivot ct_number;
  v_msg_pivot ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_transparent is null, 'p_transparent');
  util_pkg.XCheck_Cond_Missing(NOT p_transparent AND p_main_count_opaque is null, 'p_main_count_opaque');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(NOT p_transparent AND p_main_count_opaque < 0, 'p_main_count_opaque < 0');
  ------------------------------
  if NOT p_transparent
  then
    ------------------------------
    p_ids_io := util_pkg.make_ct_number(p_main_count_opaque, NULL);
    p_codes_io := util_pkg.make_ct_varchar_s(p_main_count_opaque, NULL);
    ------------------------------
  end if;
  ------------------------------
  util_pkg.set_by_pos_ct_number(p_ids_io, p_ids, p_poses);
  util_pkg.set_by_pos_ct_varchar_s(p_codes_io, p_codes, p_poses);
  ------------------------------
  --!_![error status] are created in [xprepare_ids_part1]
  --!_!supplement only [OK] state
  v_code_pivot := util_pkg.make_ct_number(p_main_count_opaque, NULL);
  util_pkg.set_by_pos_ct_number(v_code_pivot, p_error_codes, p_poses);
  p_error_codes_io := util_pkg.supplement_ct_number(p_error_codes_io, v_code_pivot, false, util_pkg.c_ora_ok);
  ------------------------------
  v_msg_pivot := util_pkg.make_ct_varchar(p_main_count_opaque, NULL);
  util_pkg.set_by_pos_ct_varchar(v_msg_pivot, p_error_messages, p_poses);
  p_error_messages_io := util_pkg.supplement_ct_varchar(p_error_messages_io, v_msg_pivot, false, util_pkg.c_msg_ok);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_ids_parts23
(
    p_transparent boolean,
    p_correlate_ids_codes boolean,
    p_main_count_opaque number,
    p_poses ct_number,
    p_ids_in ct_number,
    p_codes_in ct_varchar_s,
    p_ids_real ct_number,
    p_codes_real ct_varchar_s,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
)
is
  v_ids ct_number;
  v_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_transparent is null, 'p_transparent');
  util_pkg.XCheck_Cond_Missing(p_correlate_ids_codes is null, 'p_correlate_ids_codes');
  ------------------------------
  prepare_ids_part2(p_correlate_ids_codes, p_ids_in, p_codes_in, p_ids_real, p_codes_real, v_ids, v_codes, v_error_codes, v_error_messages);
  ------------------------------
  prepare_ids_part3(p_transparent, p_main_count_opaque, p_poses, v_ids, v_codes, v_error_codes, v_error_messages, p_ids_io, p_codes_io, p_error_codes_io, p_error_messages_io);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure prepare_ids_transparent
(
    p_correlate_ids_codes boolean,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_extended_codes ct_varchar_s,
    p_dates ct_date,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
)
is
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_correlate_ids_codes is null, 'p_correlate_ids_codes');
  util_pkg.XCheckP_FS_ct_varchar_s(p_type_codes, 'p_type_codes');
  util_pkg.XCheckP_ct_number(p_ids, 'p_ids');
  util_pkg.XCheckP_ct_varchar_s(p_codes, 'p_codes');
  util_pkg.XCheckP_ct_date(p_dates, 'p_dates');
  util_pkg.XCheckP_FS_ct_date(p_dates, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_type_codes);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_type_codes) != v_main_count, 'p_type_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != v_main_count, 'p_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_codes) != v_main_count, 'p_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_dates) != v_main_count, 'p_dates.count != v_main_count');
  ------------------------------
  p_ids_io := util_pkg.make_ct_number(v_main_count, NULL);
  p_codes_io := util_pkg.make_ct_varchar_s(v_main_count, NULL);
  ------------------------------
  --!_!set all [error status] to [ERROR] state - will be reset to [OK] state in [prepare_ids_<entity>] procedure
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong, p_error_codes_io, p_error_messages_io);
  ------------------------------
  prepare_ids_routing_number(TRUE, p_correlate_ids_codes, p_type_codes, p_ids, p_codes, p_dates, p_ids_io, p_codes_io, p_error_codes_io, p_error_messages_io);
  prepare_ids_dst_rule(TRUE, p_correlate_ids_codes, p_type_codes, p_ids, p_codes, p_dates, p_ids_io, p_codes_io, p_error_codes_io, p_error_messages_io);
  prepare_ids_network_operator(TRUE, p_correlate_ids_codes, p_type_codes, p_ids, p_codes, p_extended_codes, p_dates, p_ids_io, p_codes_io, p_error_codes_io, p_error_messages_io);
  prepare_ids_zone(TRUE, p_correlate_ids_codes, p_type_codes, p_ids, p_codes, p_dates, p_ids_io, p_codes_io, p_error_codes_io, p_error_messages_io);
  prepare_ids_host(TRUE, p_correlate_ids_codes, p_type_codes, p_ids, p_codes, p_dates, p_ids_io, p_codes_io, p_error_codes_io, p_error_messages_io);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure prepare_ids_routing_number
(
    p_transparent boolean,
    p_correlate_ids_codes boolean,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_dates ct_date,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
)
is
  v_main_count_opaque number;
  v_poses ct_number;
  --
  v_ids ct_number;
  v_codes ct_varchar_s;
  v_dates ct_date;
  --
  v_ids2 ct_number := NULL;
  v_codes2 ct_varchar_s;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_transparent is null, 'p_transparent');
  util_pkg.XCheck_Cond_Missing(p_correlate_ids_codes is null, 'p_correlate_ids_codes');
  ------------------------------
  if NOT xprepare_ids_part1a(p_transparent, VP_ROUTING_NUMBER.c_this_name, p_type_codes, p_ids, p_codes, p_dates, v_main_count_opaque, v_poses, v_ids, v_codes, v_dates, p_error_codes_io, p_error_messages_io)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  v_codes2 := mnp_pkg.get_routing_number_code0(v_ids, v_dates, FALSE);
  ------------------------------
  if p_correlate_ids_codes
  then
    ------------------------------
    v_ids2 := mnp_pkg.get_routing_number_id0(v_codes, v_dates, FALSE);
    ------------------------------
  end if;
  ------------------------------
  prepare_ids_parts23(p_transparent, p_correlate_ids_codes, v_main_count_opaque, v_poses, v_ids, v_codes, v_ids2, v_codes2, p_ids_io, p_codes_io, p_error_codes_io, p_error_messages_io);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_ids_dst_rule
(
    p_transparent boolean,
    p_correlate_ids_codes boolean,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_dates ct_date,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
)
is
  v_main_count_opaque number;
  v_poses ct_number;
  --
  v_ids ct_number;
  v_codes ct_varchar_s;
  v_dates ct_date;
  --
  v_ids2 ct_number := NULL;
  v_codes2 ct_varchar_s;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_transparent is null, 'p_transparent');
  util_pkg.XCheck_Cond_Missing(p_correlate_ids_codes is null, 'p_correlate_ids_codes');
  ------------------------------
  if NOT xprepare_ids_part1a(p_transparent, VP_DST_RULE.c_this_name, p_type_codes, p_ids, p_codes, p_dates, v_main_count_opaque, v_poses, v_ids, v_codes, v_dates, p_error_codes_io, p_error_messages_io)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  --!_!v_codes2 := util_ri.get_dst_rule_code0(v_ids, v_dates, FALSE);
  v_codes2 := util_pkg.cast_ct_number2ct_varchar_s(util_ri.check_dst_rule_id0(v_ids, v_dates, FALSE, FALSE)); --!_! dst_rule; pseudo codes
  ------------------------------
  if p_correlate_ids_codes
  then
    ------------------------------
    --!_!v_ids2 := util_ri.get_dst_rule_id0(v_codes, v_dates, FALSE);
    v_ids2 := util_pkg.make_ct_number(util_pkg.get_count_ct_number(v_ids), NULL); --!_! dst_rule; v_ids2 is list of nulls; if there are not only nulls in v_codes - then later they will be marked as wrong
    ------------------------------
  end if;
  ------------------------------
  prepare_ids_parts23(p_transparent, p_correlate_ids_codes, v_main_count_opaque, v_poses, v_ids, v_codes, v_ids2, v_codes2, p_ids_io, p_codes_io, p_error_codes_io, p_error_messages_io);
  ------------------------------
  util_pkg.set_by_pos_ct_varchar_s(p_codes_io, v_codes, v_poses); --!_! dst_rule
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure apply_extended_codes_to_netop
(
  p_poses ct_number,
  p_extended_codes ct_varchar_s, --!_!uprsc
  p_dates ct_date,
  p_ids_io in out nocopy ct_number
)
is
  v_main_count number;
  v_all_uprsc_codes ct_varchar_s;
  v_marks ct_number;
  v_pos_uprsc_not_null ct_number;
  v_uprsc_not_null ct_varchar_s;
  v_ids_uprsc ct_number;
  v_ids_io ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_poses);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_poses) != v_main_count, 'p_poses.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_extended_codes) != v_main_count, 'p_extended_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_dates) != v_main_count, 'p_dates.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids_io) != v_main_count, 'p_ids_io.count != v_main_count');
  ------------------------------
  --!_! 1.1 список [uprsc] по окну переданных позиций
  v_all_uprsc_codes := util_pkg.get_by_pos_ct_varchar_s(p_extended_codes, p_poses, FALSE);
  v_marks := util_pkg.mark_val_ct_varchar_s(v_all_uprsc_codes, null, util_pkg.c_false, util_pkg.c_true);
  ------------------------------
  --!_! 2. ищем заполненные [uprsc] в пределах позиций про [network_operator]
  --!_! 2.1 - позиции
  v_pos_uprsc_not_null := util_pkg.get_marked_ct_number(p_poses, v_marks, TRUE);
  ------------------------------
  if util_pkg.get_count_ct_number(v_pos_uprsc_not_null) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  --!_! 2.2 - значения
  v_uprsc_not_null := util_pkg.get_by_pos_ct_varchar_s(p_extended_codes, v_pos_uprsc_not_null, FALSE);
  ------------------------------
  --!_! 3. пытаемся получить идентификатор [network_operator_id] для заполненных [uprsc]
  v_ids_uprsc := util_ri.get_no_by_uprsc0(v_uprsc_not_null, util_pkg.get_by_pos_ct_date(p_dates, v_pos_uprsc_not_null, FALSE), FALSE);
  ------------------------------
  --!_! 4. отражаем найденные [network_operator_id] на входные [ids]; НЕ пытаемся коррелировать (сравнивать) НЕПУСТЫЕ с обеих сторон
  v_ids_io := p_ids_io;
  util_pkg.set_by_pos_ct_number(v_ids_io, v_ids_uprsc, v_pos_uprsc_not_null);
  ------------------------------
  --!_! 5. перезатираем любые или только ПУСТЫЕ входные [ids] найденными [network_operator_id]
  if install_pkg.nnget_option_bool(c_opt_cocat_no_extcode_imprtnt, c_def_cocat_no_extcode_imprtnt)
  then
    ------------------------------
    p_ids_io := v_ids_io;
    ------------------------------
  else
    ------------------------------
    p_ids_io := util_pkg.supplement_ct_number(p_vals => p_ids_io, p_supplement => v_ids_io, p_trim_empty => false);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_ids_network_operator
(
    p_transparent boolean,
    p_correlate_ids_codes boolean,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_extended_codes ct_varchar_s, --!_!uprsc
    p_dates ct_date,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
)
is
  --
  v_main_count_opaque number;
  --
  v_poses ct_number;
  --
  v_ids ct_number;
  v_codes ct_varchar_s;
  v_extended_codes ct_varchar_s;
  v_dates ct_date;
  --
  v_ids2 ct_number := NULL;
  v_codes2 ct_varchar_s;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_transparent is null, 'p_transparent');
  util_pkg.XCheck_Cond_Missing(p_correlate_ids_codes is null, 'p_correlate_ids_codes');
  ------------------------------
  if NOT xprepare_ids_part1b(p_transparent, vp_network_operator.c_this_name, p_type_codes, p_ids, p_codes, p_extended_codes, p_dates, v_main_count_opaque, v_poses, v_ids, v_codes, v_extended_codes, v_dates, p_error_codes_io, p_error_messages_io)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  apply_extended_codes_to_netop(v_poses, v_extended_codes, p_dates, v_ids);
  ------------------------------
  v_codes2 := util_ri.get_network_operator_code0(v_ids, v_dates, FALSE);
  ------------------------------
  if p_correlate_ids_codes
  then
    ------------------------------
    v_ids2 := util_ri.get_network_operator_id0(v_codes, v_dates, FALSE);
    ------------------------------
  end if;
  ------------------------------
  prepare_ids_parts23(p_transparent, p_correlate_ids_codes, v_main_count_opaque, v_poses, v_ids, v_codes, v_ids2, v_codes2, p_ids_io, p_codes_io, p_error_codes_io, p_error_messages_io);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_ids_zone
(
    p_transparent boolean,
    p_correlate_ids_codes boolean,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_dates ct_date,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
)
is
  v_main_count_opaque number;
  v_poses ct_number;
  --
  v_ids ct_number;
  v_codes ct_varchar_s;
  v_dates ct_date;
  --
  v_ids2 ct_number := NULL;
  v_codes2 ct_varchar_s;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_transparent is null, 'p_transparent');
  util_pkg.XCheck_Cond_Missing(p_correlate_ids_codes is null, 'p_correlate_ids_codes');
  ------------------------------
  if NOT xprepare_ids_part1a(p_transparent, VP_ZONE.c_this_name, p_type_codes, p_ids, p_codes, p_dates, v_main_count_opaque, v_poses, v_ids, v_codes, v_dates, p_error_codes_io, p_error_messages_io)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  v_codes2 := util_ri.get_zone_code0(v_ids, v_dates, FALSE);
  ------------------------------
  if p_correlate_ids_codes
  then
    ------------------------------
    v_ids2 := util_ri.get_zone_id0(v_codes, v_dates, FALSE);
    ------------------------------
  end if;
  ------------------------------
  prepare_ids_parts23(p_transparent, p_correlate_ids_codes, v_main_count_opaque, v_poses, v_ids, v_codes, v_ids2, v_codes2, p_ids_io, p_codes_io, p_error_codes_io, p_error_messages_io);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_ids_host
(
    p_transparent boolean,
    p_correlate_ids_codes boolean,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_dates ct_date,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
)
is
  v_main_count_opaque number;
  v_poses ct_number;
  --
  v_ids ct_number;
  v_codes ct_varchar_s;
  v_dates ct_date;
  --
  v_ids2 ct_number := NULL;
  v_codes2 ct_varchar_s;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_transparent is null, 'p_transparent');
  util_pkg.XCheck_Cond_Missing(p_correlate_ids_codes is null, 'p_correlate_ids_codes');
  ------------------------------
  if NOT xprepare_ids_part1a(p_transparent, VP_HOST.c_this_name, p_type_codes, p_ids, p_codes, p_dates, v_main_count_opaque, v_poses, v_ids, v_codes, v_dates, p_error_codes_io, p_error_messages_io)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  v_codes2 := util_ri.get_host_code0(v_ids, v_dates, FALSE);
  ------------------------------
  if p_correlate_ids_codes
  then
    ------------------------------
    v_ids2 := util_ri.get_host_id0(v_codes, v_dates, FALSE);
    ------------------------------
  end if;
  ------------------------------
  prepare_ids_parts23(p_transparent, p_correlate_ids_codes, v_main_count_opaque, v_poses, v_ids, v_codes, v_ids2, v_codes2, p_ids_io, p_codes_io, p_error_codes_io, p_error_messages_io);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure delete_objects
(
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_extended_codes ct_varchar_s,
    p_type_codes ct_varchar_s,
    p_date_from ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids in out nocopy ct_number,
    p_out_codes in out nocopy ct_varchar_s,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_err_idx number;
  v_opt_cocat_delobj_corr_idcode boolean;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  --!_! util_pkg.XCheckP_FS_ct_number(p_ids, 'p_rn_ids');
  util_pkg.XCheckP_FS_ct_varchar_s(p_type_codes, 'p_type_codes');
  util_pkg.XCheckP_FS_ct_date(p_date_from, 'p_date_from');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != v_main_count, 'p_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_codes) != v_main_count, 'p_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_extended_codes) != v_main_count, 'p_extended_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_type_codes) != v_main_count, 'p_type_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date_from) != v_main_count, 'p_date_from.count != v_main_count');
  ------------------------------
  v_opt_cocat_delobj_corr_idcode := install_pkg.nnget_option_bool(c_opt_cocat_delobj_corr_idcode, c_def_cocat_delobj_corr_idcode);
  ------------------------------
  prepare_ids_transparent(v_opt_cocat_delobj_corr_idcode, p_type_codes, p_ids, p_codes, p_extended_codes, p_date_from, p_out_ids, p_out_codes, p_error_codes, p_error_messages);
  ------------------------------
  if p_break_on_error
  then
    ------------------------------
    v_err_idx := util_ext_ri.get_first_error_pos(p_error_codes);
    ------------------------------
    if v_err_idx is not null
    then
      ------------------------------
      util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message(p_out_ids(v_err_idx), v_err_idx, p_error_codes(v_err_idx), p_error_messages(v_err_idx)));
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if util_pkg.is_error(p_error_codes(v_i))
    then
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    begin
      ------------------------------
      delete_object_i
      (
        p_id => p_out_ids(v_i),
        p_type_code => p_type_codes(v_i),
        p_user_id => p_user_id,
        p_date_from => p_date_from(v_i)
      );
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message(p_out_ids(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure delete_object_i
(
    p_id number,
    p_type_code varchar2,
    p_user_id number,
    p_date_from date
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_type_code is null, 'p_type_code');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date_from is null, 'p_date_from');
  ------------------------------
  case p_type_code
    ------------------------------
  when vp_routing_number.c_this_name
  then
    ------------------------------
    vp_routing_number.version_close
    (
      p_id => p_id,
      p_user_id => p_user_id,
      p_date_from => p_date_from
    );
    ------------------------------
    ------------------------------
  when vp_dst_rule.c_this_name
  then
    ------------------------------
    vp_dst_rule.version_close
    (
      p_id => p_id,
      p_user_id => p_user_id,
      p_date_from => p_date_from
    );
    ------------------------------
    ------------------------------
  when vp_network_operator.c_this_name
  then
    ------------------------------
    vp_network_operator.version_close2
    (
      p_id => p_id,
      p_user_id => p_user_id,
      p_date_from => p_date_from
    );
    ------------------------------
    ------------------------------
  when vp_zone.c_this_name
  then
    ------------------------------
    vp_zone.version_close
    (
      p_id => p_id,
      p_user_id => p_user_id,
      p_date_from => p_date_from
    );
    ------------------------------
    ------------------------------
  when vp_host.c_this_name
  then
    ------------------------------
    vp_host.version_close2
    (
      p_id => p_id,
      p_user_id => p_user_id,
      p_date_from => p_date_from
    );
    ------------------------------
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong);
    ------------------------------
  end case;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure create_routing_number
(
    p_rn_codes ct_varchar_s,
    p_rn_names ct_nvarchar,
    p_date_from ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_rec routing_number%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_rn_codes, 'p_rn_codes');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_rn_codes);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_rn_codes) != v_main_count, 'p_rn_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar(p_rn_names) != v_main_count, 'p_rn_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date_from) != v_main_count, 'p_date_from.count != v_main_count');
  ------------------------------
  p_out_ids := util_pkg.make_ct_number(v_main_count, NULL);
  p_out_codes := util_pkg.make_ct_varchar_s(v_main_count, NULL);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    begin
      ------------------------------
      p_out_ids(v_i) := NULL;
      p_out_codes(v_i) := p_rn_codes(v_i);
      ------------------------------
      v_rec := NULL;
      ------------------------------
      v_rec.routing_number_code := p_rn_codes(v_i);
      v_rec.routing_number_name := p_rn_names(v_i);
      v_rec.date_from := p_date_from(v_i);
      v_rec.user_id_of_change := p_user_id;
      ------------------------------
      vp_routing_number.version_open(v_rec);
      ------------------------------
      p_out_ids(v_i) := v_rec.routing_number_id;
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message2(p_out_ids(v_i), p_out_codes(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_routing_number
(
    p_rn_ids ct_number,
    p_rn_codes ct_varchar_s,
    p_rn_names ct_nvarchar,
    p_date_from ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_date date := sysdate;
  v_main_count number;
  v_rec routing_number%rowtype;
  v_err_idx number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_rn_ids, 'p_rn_ids');
  --!_!util_pkg.XCheckP_FS_ct_varchar_s(p_rn_codes, 'p_rn_codes');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_rn_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_rn_ids) != v_main_count, 'p_rn_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_rn_codes) != v_main_count, 'p_rn_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar(p_rn_names) != v_main_count, 'p_rn_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date_from) != v_main_count, 'p_date_from.count != v_main_count');
  ------------------------------
  prepare_ids_routing_number(FALSE, FALSE, NULL, p_rn_ids, p_rn_codes, util_pkg.make_ct_date(v_main_count, v_date), p_out_ids, p_out_codes, p_error_codes, p_error_messages);
  ------------------------------
  if p_break_on_error
  then
    ------------------------------
    v_err_idx := util_ext_ri.get_first_error_pos(p_error_codes);
    ------------------------------
    if v_err_idx is not null
    then
      ------------------------------
      util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message(p_out_ids(v_err_idx), v_err_idx, p_error_codes(v_err_idx), p_error_messages(v_err_idx)));
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if util_pkg.is_error(p_error_codes(v_i))
    then
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    begin
      ------------------------------
      v_rec := NULL;
      ------------------------------
      v_rec.routing_number_id := p_out_ids(v_i);
      v_rec.routing_number_code := p_rn_codes(v_i);
      v_rec.routing_number_name := p_rn_names(v_i);
      v_rec.date_from := p_date_from(v_i);
      v_rec.user_id_of_change := p_user_id;
      ------------------------------
      vp_routing_number.version_change(v_rec);
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message2(p_out_ids(v_i), p_out_codes(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_dst_rule
(
    p_dst_rule_names ct_varchar,
    p_country_code ct_varchar_s,
    p_date_start_rule_masks ct_varchar_s,
    p_date_starts ct_varchar_s,
    p_date_end_rule_masks ct_varchar_s,
    p_date_ends ct_varchar_s,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_rec dst_rule%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar(p_dst_rule_names, 'p_dst_rule_names');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar(p_dst_rule_names);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_dst_rule_names) != v_main_count, 'p_dst_rule_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_country_code) != v_main_count, 'p_country_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_date_start_rule_masks) != v_main_count, 'p_date_start_rule_masks.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_date_starts) != v_main_count, 'p_date_starts.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_date_end_rule_masks) != v_main_count, 'p_date_end_rule_masks.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_date_ends) != v_main_count, 'p_date_ends.count != v_main_count');
  ------------------------------
  p_out_ids := util_pkg.make_ct_number(v_main_count, NULL);
  p_out_codes := util_pkg.make_ct_varchar_s(v_main_count, NULL);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    begin
      ------------------------------
      p_out_ids(v_i) := NULL;
      p_out_codes(v_i) := NULL;
      ------------------------------
      v_rec := NULL;
      ------------------------------
      v_rec.country_code := p_country_code(v_i);
      v_rec.dst_name := p_dst_rule_names(v_i);
      v_rec.date_start_rule_mask := p_date_start_rule_masks(v_i);
      v_rec.date_start := p_date_starts(v_i);
      v_rec.date_end_rule_mask := p_date_end_rule_masks(v_i);
      v_rec.date_end := p_date_ends(v_i);
      ------------------------------
      vp_dst_rule.version_open(v_rec);
      ------------------------------
      p_out_ids(v_i) := v_rec.dst_rule_id;
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message2(p_out_ids(v_i), p_out_codes(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_dst_rule
(
    p_dst_rule_ids ct_number,
    p_dst_rule_names ct_varchar,
    p_country_code ct_varchar_s,
    p_date_start_rule_masks ct_varchar_s,
    p_date_starts ct_varchar_s,
    p_date_end_rule_masks ct_varchar_s,
    p_date_ends ct_varchar_s,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_date date := sysdate;
  v_main_count number;
  v_rec dst_rule%rowtype;
  v_err_idx number;
  --
  v_dst_rule_codes ct_varchar_s;
  --
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_dst_rule_ids, 'p_dst_rule_ids');
  --!_!util_pkg.XCheckP_FS_ct_varchar(p_dst_rule_names, 'p_dst_rule_names');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_dst_rule_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_dst_rule_ids) != v_main_count, 'p_dst_rule_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_dst_rule_names) != v_main_count, 'p_dst_rule_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_country_code) != v_main_count, 'p_country_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_date_start_rule_masks) != v_main_count, 'p_date_start_rule_masks.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_date_starts) != v_main_count, 'p_date_starts.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_date_end_rule_masks) != v_main_count, 'p_date_end_rule_masks.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_date_ends) != v_main_count, 'p_date_ends.count != v_main_count');
  ------------------------------
  --!_!
  v_dst_rule_codes := util_pkg.make_ct_varchar_s(v_main_count, NULL);
  ------------------------------
  prepare_ids_dst_rule(FALSE, FALSE, NULL, p_dst_rule_ids, v_dst_rule_codes, util_pkg.make_ct_date(v_main_count, v_date), p_out_ids, p_out_codes, p_error_codes, p_error_messages);
  ------------------------------
  if p_break_on_error
  then
    ------------------------------
    v_err_idx := util_ext_ri.get_first_error_pos(p_error_codes);
    ------------------------------
    if v_err_idx is not null
    then
      ------------------------------
      util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message(p_out_ids(v_err_idx), v_err_idx, p_error_codes(v_err_idx), p_error_messages(v_err_idx)));
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if util_pkg.is_error(p_error_codes(v_i))
    then
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    begin
      ------------------------------
      v_rec := NULL;
      ------------------------------
      v_rec.dst_rule_id := p_out_ids(v_i);
      v_rec.country_code := p_country_code(v_i);
      v_rec.dst_name := p_dst_rule_names(v_i);
      v_rec.date_start_rule_mask := p_date_start_rule_masks(v_i);
      v_rec.date_start := p_date_starts(v_i);
      v_rec.date_end_rule_mask := p_date_end_rule_masks(v_i);
      v_rec.date_end := p_date_ends(v_i);
      ------------------------------
      vp_dst_rule.version_change(v_rec);
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message2(p_out_ids(v_i), p_out_codes(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_network_operator
(
    p_network_operator_codes ct_varchar_s,
    p_network_operator_names ct_varchar,
    p_network_operator_types ct_varchar_s,
    p_personal_account ct_varchar_s,
    p_deleted ct_date,
    p_network_operator_id_uppers ct_number,
    p_uprs_member_codes ct_varchar_s,
    --!_! p_replicated_region_ids ct_number,
    p_country ct_number,
    p_mcc ct_varchar_s,
    p_mnc ct_varchar_s,
    p_time_zones ct_number,
    p_dst_rule_ids ct_number,
    p_routing_number_ids ct_number,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_rec network_operator%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_network_operator_codes, 'p_network_operator_codes');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_network_operator_codes);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_network_operator_codes) != v_main_count, 'p_network_operator_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_network_operator_names) != v_main_count, 'p_network_operator_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_network_operator_types) != v_main_count, 'p_network_operator_types.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_personal_account) != v_main_count, 'p_personal_account.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_deleted) != v_main_count, 'p_deleted.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_network_operator_id_uppers) != v_main_count, 'p_network_operator_id_uppers.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_uprs_member_codes) != v_main_count, 'p_uprs_member_codes.count != v_main_count');
  --!_!util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_replicated_region_ids) != v_main_count, 'p_replicated_region_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_country) != v_main_count, 'p_country.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_mcc) != v_main_count, 'p_mcc.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_mnc) != v_main_count, 'p_mnc.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_time_zones) != v_main_count, 'p_time_zones.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_dst_rule_ids) != v_main_count, 'p_dst_rule_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_routing_number_ids) != v_main_count, 'p_routing_number_ids.count != v_main_count');
  ------------------------------
  p_out_ids := util_pkg.make_ct_number(v_main_count, NULL);
  p_out_codes := util_pkg.make_ct_varchar_s(v_main_count, NULL);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    begin
      ------------------------------
      p_out_ids(v_i) := NULL;
      p_out_codes(v_i) := p_network_operator_codes(v_i);
      ------------------------------
      v_rec := NULL;
      ------------------------------
      v_rec.network_operator_code := p_network_operator_codes(v_i);
      v_rec.network_operator_name := p_network_operator_names(v_i);
      v_rec.network_operator_type := p_network_operator_types(v_i);
      v_rec.personal_account := p_personal_account(v_i);
      v_rec.user_id_of_change := p_user_id;
      v_rec.deleted := p_deleted(v_i);
      v_rec.network_operator_id_upper := p_network_operator_id_uppers(v_i);
      v_rec.uprs_member_code := p_uprs_member_codes(v_i);
      --!_!v_rec.replicated_region_id := p_replicated_region_ids(v_i);
      v_rec.country := p_country(v_i);
      v_rec.mcc := p_mcc(v_i);
      v_rec.mnc := p_mnc(v_i);
      v_rec.time_zone := p_time_zones(v_i);
      v_rec.dst_rule_id := p_dst_rule_ids(v_i);
      ------------------------------
      vp_network_operator.version_open2
      (
        p_rec => v_rec,
        p_routing_number_id => p_routing_number_ids(v_i)
      );
      ------------------------------
      p_out_ids(v_i) := v_rec.network_operator_id;
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message2(p_out_ids(v_i), p_out_codes(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_network_operator
(
    p_network_operator_ids ct_number,
    p_network_operator_codes ct_varchar_s,
    p_network_operator_names ct_varchar,
    p_network_operator_types ct_varchar_s,
    p_personal_account ct_varchar_s,
    p_deleted ct_date,
    p_network_operator_id_uppers ct_number,
    p_uprs_member_codes ct_varchar_s,
    --!_! p_replicated_region_ids ct_number,
    p_country ct_number,
    p_mcc ct_varchar_s,
    p_mnc ct_varchar_s,
    p_time_zones ct_number,
    p_dst_rule_ids ct_number,
    p_routing_number_ids ct_number,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_date date := sysdate;
  v_main_count number;
  v_rec network_operator%rowtype;
  v_err_idx number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_network_operator_ids, 'p_network_operator_ids');
  --!_!util_pkg.XCheckP_FS_ct_varchar_s(p_network_operator_codes, 'p_network_operator_codes');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_network_operator_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_network_operator_ids) != v_main_count, 'p_network_operator_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_network_operator_codes) != v_main_count, 'p_network_operator_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_network_operator_names) != v_main_count, 'p_network_operator_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_network_operator_types) != v_main_count, 'p_network_operator_types.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_personal_account) != v_main_count, 'p_personal_account.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_deleted) != v_main_count, 'p_deleted.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_network_operator_id_uppers) != v_main_count, 'p_network_operator_id_uppers.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_uprs_member_codes) != v_main_count, 'p_uprs_member_codes.count != v_main_count');
  --!_!util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_replicated_region_ids) != v_main_count, 'p_replicated_region_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_country) != v_main_count, 'p_country.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_mcc) != v_main_count, 'p_mcc.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_mnc) != v_main_count, 'p_mnc.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_time_zones) != v_main_count, 'p_time_zones.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_dst_rule_ids) != v_main_count, 'p_dst_rule_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_routing_number_ids) != v_main_count, 'p_routing_number_ids.count != v_main_count');
  ------------------------------
  prepare_ids_network_operator(FALSE, FALSE, NULL, p_network_operator_ids, p_network_operator_codes, p_uprs_member_codes, util_pkg.make_ct_date(v_main_count, v_date), p_out_ids, p_out_codes, p_error_codes, p_error_messages);
  ------------------------------
  if p_break_on_error
  then
    ------------------------------
    v_err_idx := util_ext_ri.get_first_error_pos(p_error_codes);
    ------------------------------
    if v_err_idx is not null
    then
      ------------------------------
      util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message(p_out_ids(v_err_idx), v_err_idx, p_error_codes(v_err_idx), p_error_messages(v_err_idx)));
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if util_pkg.is_error(p_error_codes(v_i))
    then
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    begin
      ------------------------------
      v_rec := NULL;
      ------------------------------
      v_rec.network_operator_id := p_out_ids(v_i);
      v_rec.network_operator_code := p_network_operator_codes(v_i);
      v_rec.network_operator_name := p_network_operator_names(v_i);
      v_rec.network_operator_type := p_network_operator_types(v_i);
      v_rec.personal_account := p_personal_account(v_i);
      v_rec.user_id_of_change := p_user_id;
      v_rec.deleted := p_deleted(v_i);
      v_rec.network_operator_id_upper := p_network_operator_id_uppers(v_i);
      v_rec.uprs_member_code := p_uprs_member_codes(v_i);
      --!_!v_rec.replicated_region_id := p_replicated_region_ids(v_i);
      v_rec.country := p_country(v_i);
      v_rec.mcc := p_mcc(v_i);
      v_rec.mnc := p_mnc(v_i);
      v_rec.time_zone := p_time_zones(v_i);
      v_rec.dst_rule_id := p_dst_rule_ids(v_i);
      ------------------------------
      vp_network_operator.version_change2
      (
        p_rec => v_rec,
        p_routing_number_id => p_routing_number_ids(v_i)
      );
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message2(p_out_ids(v_i), p_out_codes(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_zone
(
    p_zone_codes ct_varchar_s,
    p_zone_names ct_varchar,
    p_network_operator_ids ct_number,
    p_deleted ct_date,
    p_zone_type_codes ct_varchar_s,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_rec zone%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_zone_codes, 'p_zone_codes');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_zone_codes);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_zone_codes) != v_main_count, 'p_zone_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_zone_names) != v_main_count, 'p_zone_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_network_operator_ids) != v_main_count, 'p_network_operator_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_deleted) != v_main_count, 'p_deleted.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_zone_type_codes) != v_main_count, 'p_zone_type_codes.count != v_main_count');
  ------------------------------
  p_out_ids := util_pkg.make_ct_number(v_main_count, NULL);
  p_out_codes := util_pkg.make_ct_varchar_s(v_main_count, NULL);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    begin
      ------------------------------
      p_out_ids(v_i) := NULL;
      p_out_codes(v_i) := p_zone_codes(v_i);
      ------------------------------
      v_rec := NULL;
      ------------------------------
      v_rec.zone_code := p_zone_codes(v_i);
      v_rec.zone_name := p_zone_names(v_i);
      v_rec.network_operator_id := p_network_operator_ids(v_i);
      v_rec.user_id_of_change := p_user_id;
      v_rec.deleted := p_deleted(v_i);
      v_rec.zone_type_code := p_zone_type_codes(v_i);
      ------------------------------
      vp_zone.version_open(v_rec);
      ------------------------------
      p_out_ids(v_i) := v_rec.zone_id;
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message2(p_out_ids(v_i), p_out_codes(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_zone
(
    p_zone_ids ct_number,
    p_zone_codes ct_varchar_s,
    p_zone_names ct_varchar,
    p_network_operator_ids ct_number,
    p_deleted ct_date,
    p_zone_type_codes ct_varchar_s,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_date date := sysdate;
  v_main_count number;
  v_rec zone%rowtype;
  v_err_idx number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_zone_ids, 'p_zone_ids');
  --!_!util_pkg.XCheckP_FS_ct_varchar_s(p_zone_codes, 'p_zone_codes');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_zone_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_zone_ids) != v_main_count, 'p_zone_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_zone_codes) != v_main_count, 'p_zone_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_zone_names) != v_main_count, 'p_zone_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_network_operator_ids) != v_main_count, 'p_network_operator_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_deleted) != v_main_count, 'p_deleted.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_zone_type_codes) != v_main_count, 'p_zone_type_codes.count != v_main_count');
  ------------------------------
  prepare_ids_zone(FALSE, FALSE, NULL, p_zone_ids, p_zone_codes, util_pkg.make_ct_date(v_main_count, v_date), p_out_ids, p_out_codes, p_error_codes, p_error_messages);
  ------------------------------
  if p_break_on_error
  then
    ------------------------------
    v_err_idx := util_ext_ri.get_first_error_pos(p_error_codes);
    ------------------------------
    if v_err_idx is not null
    then
      ------------------------------
      util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message(p_out_ids(v_err_idx), v_err_idx, p_error_codes(v_err_idx), p_error_messages(v_err_idx)));
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if util_pkg.is_error(p_error_codes(v_i))
    then
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    begin
      ------------------------------
      v_rec := NULL;
      ------------------------------
      v_rec.zone_id := p_out_ids(v_i);
      v_rec.zone_code := p_zone_codes(v_i);
      v_rec.zone_name := p_zone_names(v_i);
      v_rec.network_operator_id := p_network_operator_ids(v_i);
      v_rec.user_id_of_change := p_user_id;
      v_rec.deleted := p_deleted(v_i);
      v_rec.zone_type_code := p_zone_type_codes(v_i);
      ------------------------------
      vp_zone.version_change(v_rec);
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message2(p_out_ids(v_i), p_out_codes(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_host
(
    p_host_codes ct_varchar_s,
    p_host_names ct_varchar,
    p_host_addresses ct_varchar,
    p_host_locations ct_varchar,
    p_deleted ct_date,
    p_host_type_codes ct_varchar_s,
    p_network_operator_ids ct_number,
    p_time_zones ct_number,
    p_dst_rule_ids ct_number,
    p_routing_number_ids ct_number,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_rec host%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_host_codes, 'p_host_codes');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_host_codes);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_host_codes) != v_main_count, 'p_host_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_host_names) != v_main_count, 'p_host_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_host_addresses) != v_main_count, 'p_host_addresses.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_host_locations) != v_main_count, 'p_host_locations.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_deleted) != v_main_count, 'p_deleted.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_host_type_codes) != v_main_count, 'p_host_type_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_network_operator_ids) != v_main_count, 'p_network_operator_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_time_zones) != v_main_count, 'p_time_zones.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_dst_rule_ids) != v_main_count, 'p_dst_rule_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_routing_number_ids) != v_main_count, 'p_routing_number_ids.count != v_main_count');
  ------------------------------
  p_out_ids := util_pkg.make_ct_number(v_main_count, NULL);
  p_out_codes := util_pkg.make_ct_varchar_s(v_main_count, NULL);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    begin
      ------------------------------
      p_out_ids(v_i) := NULL;
      p_out_codes(v_i) := p_host_codes(v_i);
      ------------------------------
      v_rec := NULL;
      ------------------------------
      v_rec.host_code := p_host_codes(v_i);
      v_rec.host_name := p_host_names(v_i);
      v_rec.host_address := p_host_addresses(v_i);
      v_rec.host_location := p_host_locations(v_i);
      v_rec.user_id_of_change := p_user_id;
      v_rec.deleted := p_deleted(v_i);
      v_rec.host_type_code := p_host_type_codes(v_i);
      v_rec.network_operator_id := p_network_operator_ids(v_i);
      v_rec.time_zone := p_time_zones(v_i);
      v_rec.dst_rule_id := p_dst_rule_ids(v_i);
      ------------------------------
      vp_host.version_open2
      (
        p_rec => v_rec,
        p_routing_number_id => p_routing_number_ids(v_i)
      );
      ------------------------------
      p_out_ids(v_i) := v_rec.host_id;
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message2(p_out_ids(v_i), p_out_codes(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_host
(
    p_host_ids ct_number,
    p_host_codes ct_varchar_s,
    p_host_names ct_varchar,
    p_host_addresses ct_varchar,
    p_host_locations ct_varchar,
    p_deleted ct_date,
    p_host_type_codes ct_varchar_s,
    p_network_operator_ids ct_number,
    p_time_zones ct_number,
    p_dst_rule_ids ct_number,
    p_routing_number_ids ct_number,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_date date := sysdate;
  v_main_count number;
  v_rec host%rowtype;
  v_err_idx number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_host_ids, 'p_host_ids');
  --!_!util_pkg.XCheckP_FS_ct_varchar_s(p_host_codes, 'p_host_codes');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_host_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_host_ids) != v_main_count, 'p_host_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_host_codes) != v_main_count, 'p_host_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_host_names) != v_main_count, 'p_host_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_host_addresses) != v_main_count, 'p_host_addresses.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_host_locations) != v_main_count, 'p_host_locations.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_deleted) != v_main_count, 'p_deleted.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_host_type_codes) != v_main_count, 'p_host_type_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_network_operator_ids) != v_main_count, 'p_network_operator_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_time_zones) != v_main_count, 'p_time_zones.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_dst_rule_ids) != v_main_count, 'p_dst_rule_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_routing_number_ids) != v_main_count, 'p_routing_number_ids.count != v_main_count');
  ------------------------------
  prepare_ids_host(FALSE, FALSE, NULL, p_host_ids, p_host_codes, util_pkg.make_ct_date(v_main_count, v_date), p_out_ids, p_out_codes, p_error_codes, p_error_messages);
  ------------------------------
  if p_break_on_error
  then
    ------------------------------
    v_err_idx := util_ext_ri.get_first_error_pos(p_error_codes);
    ------------------------------
    if v_err_idx is not null
    then
      ------------------------------
      util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message(p_out_ids(v_err_idx), v_err_idx, p_error_codes(v_err_idx), p_error_messages(v_err_idx)));
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if util_pkg.is_error(p_error_codes(v_i))
    then
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    begin
      ------------------------------
      v_rec := NULL;
      ------------------------------
      v_rec.host_id := p_out_ids(v_i);
      v_rec.host_code := p_host_codes(v_i);
      v_rec.host_name := p_host_names(v_i);
      v_rec.host_address := p_host_addresses(v_i);
      v_rec.host_location := p_host_locations(v_i);
      v_rec.user_id_of_change := p_user_id;
      v_rec.deleted := p_deleted(v_i);
      v_rec.host_type_code := p_host_type_codes(v_i);
      v_rec.network_operator_id := p_network_operator_ids(v_i);
      v_rec.time_zone := p_time_zones(v_i);
      v_rec.dst_rule_id := p_dst_rule_ids(v_i);
      ------------------------------
      vp_host.version_change2
      (
        p_rec => v_rec,
        p_routing_number_id => p_routing_number_ids(v_i)
      );
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message2(p_out_ids(v_i), p_out_codes(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_routing_number_by_ids
(
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
)
is
  v_type_code varchar2(30) := VP_ROUTING_NUMBER.c_this_name;
  v_main_count number;
  v_ids ct_number;
  v_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != v_main_count, 'p_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_codes) != v_main_count, 'p_codes.count != v_main_count');
  ------------------------------
  prepare_ids_routing_number(FALSE, TRUE, NULL, p_ids, p_codes, util_pkg.make_ct_date(v_main_count, p_date), v_ids, v_codes, v_error_codes, v_error_messages);
  ------------------------------
  open p_result for
select /*+ ordered use_nl(z) index(z I_ROUTING_NUMBER_ID)*/
  q.sys_item_id,
  q.sys_type_code,
  decode(q.sys_error_code, util_pkg.c_ora_ok, decode(z.routing_number_id, null, util_pkg.c_ora_object_not_found, util_pkg.c_ora_ok), q.sys_error_code) sys_error_code,
  decode(q.sys_error_code, util_pkg.c_ora_ok, decode(z.routing_number_id, null, util_pkg.c_msg_object_not_found, util_pkg.c_msg_ok), q.sys_error_message) sys_error_message,
  q.sys_id,
  q.sys_code,
  z.routing_number_name sys_name,
  z.*
  from
    (select q0.*, rownum rn from table(util_ri.cast_ct_array2ct_sys_item31(v_type_code, v_error_codes, v_error_messages, v_ids, v_codes)) q0) q,
    routing_number z
  where 1 = 1
  and z.routing_number_id(+) = decode(q.sys_error_code, util_pkg.c_ora_ok, q.sys_id, null)
  and p_date between z.date_from(+) and z.date_to(+)
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_routing_number_all
(
    p_date date,
    p_result out sys_refcursor
)
is
  v_type_code varchar2(30) := VP_ROUTING_NUMBER.c_this_name;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ full(z)*/
  row_number() over(order by z.routing_number_id) sys_item_id,
  v_type_code sys_type_code,
  util_pkg.c_ora_ok sys_error_code,
  util_pkg.c_msg_ok sys_error_message,
  z.routing_number_id sys_id,
  z.routing_number_code sys_code,
  z.routing_number_name sys_name,
  z.*
  from routing_number z
  where 1 = 1
  and p_date between date_from and date_to
  order by sys_item_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_routing_number
(
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
)
is
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  ------------------------------
  if v_main_count > 0
  then
    ------------------------------
    get_routing_number_by_ids
    (
      p_ids => p_ids,
      p_codes => p_codes,
      p_date => p_date,
      p_result => p_result
    );
    ------------------------------
  else
    ------------------------------
    get_routing_number_all
    (
      p_date => p_date,
      p_result => p_result
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_dst_rule_by_ids
(
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
)
is
  v_type_code varchar2(30) := VP_DST_RULE.c_this_name;
  v_main_count number;
  v_ids ct_number;
  v_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != v_main_count, 'p_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_codes) != v_main_count, 'p_codes.count != v_main_count');
  ------------------------------
  prepare_ids_dst_rule(FALSE, TRUE, NULL, p_ids, p_codes, util_pkg.make_ct_date(v_main_count, p_date), v_ids, v_codes, v_error_codes, v_error_messages);
  ------------------------------
  open p_result for
select /*+ ordered use_nl(z) index(z PK_DST_RULE)*/
  q.sys_item_id,
  q.sys_type_code,
  decode(q.sys_error_code, util_pkg.c_ora_ok, decode(z.dst_rule_id, null, util_pkg.c_ora_object_not_found, util_pkg.c_ora_ok), q.sys_error_code) sys_error_code,
  decode(q.sys_error_code, util_pkg.c_ora_ok, decode(z.dst_rule_id, null, util_pkg.c_msg_object_not_found, util_pkg.c_msg_ok), q.sys_error_message) sys_error_message,
  q.sys_id,
  q.sys_code,
  z.dst_name sys_name,
  z.*
  from
    (select q0.*, rownum rn from table(util_ri.cast_ct_array2ct_sys_item31(v_type_code, v_error_codes, v_error_messages, v_ids, v_codes)) q0) q,
    dst_rule z
  where 1 = 1
  and z.dst_rule_id(+) = decode(q.sys_error_code, util_pkg.c_ora_ok, q.sys_id, null)
  --and nvl(z.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_dst_rule_all
(
    p_date date,
    p_result out sys_refcursor
)
is
  v_type_code varchar2(30) := VP_DST_RULE.c_this_name;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ full(z)*/
  row_number() over(order by z.dst_rule_id) sys_item_id,
  v_type_code sys_type_code,
  util_pkg.c_ora_ok sys_error_code,
  util_pkg.c_msg_ok sys_error_message,
  z.dst_rule_id sys_id,
  NULL sys_code,
  z.dst_name sys_name,
  z.*
  from dst_rule z
  where 1 = 1
  --and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
  order by sys_item_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_dst_rule
(
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
)
is
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  ------------------------------
  if v_main_count > 0
  then
    ------------------------------
    get_dst_rule_by_ids
    (
      p_ids => p_ids,
      p_codes => p_codes,
      p_date => p_date,
      p_result => p_result
    );
    ------------------------------
  else
    ------------------------------
    get_dst_rule_all
    (
      p_date => p_date,
      p_result => p_result
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_network_operator_by_ids
(
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_uprs_member_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
)
is
  v_type_code varchar2(30) := VP_NETWORK_OPERATOR.c_this_name;
  v_main_count number;
  v_ids ct_number;
  v_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  v_ids2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != v_main_count, 'p_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_codes) != v_main_count, 'p_codes.count != v_main_count');
  ------------------------------
  prepare_ids_network_operator(FALSE, TRUE, NULL, p_ids, p_codes, p_uprs_member_codes, util_pkg.make_ct_date(v_main_count, p_date), v_ids, v_codes, v_error_codes, v_error_messages);
  ------------------------------
  v_ids2 := mnp_pkg.get_rn_id4no(v_ids, p_date, FALSE);
  ------------------------------
  open p_result for
select /*+ ordered use_nl(z) use_hash(q2) index(z PK_NETWORK_OPERATOR)*/
  q.sys_item_id,
  q.sys_type_code,
  decode(q.sys_error_code, util_pkg.c_ora_ok, decode(z.network_operator_id, null, util_pkg.c_ora_object_not_found, util_pkg.c_ora_ok), q.sys_error_code) sys_error_code,
  decode(q.sys_error_code, util_pkg.c_ora_ok, decode(z.network_operator_id, null, util_pkg.c_msg_object_not_found, util_pkg.c_msg_ok), q.sys_error_message) sys_error_message,
  q.sys_id,
  q.sys_code,
  z.network_operator_name sys_name,
  z.*,
  q2.routing_number_id
  from
    (select q0.*, rownum rn from table(util_ri.cast_ct_array2ct_sys_item31(v_type_code, v_error_codes, v_error_messages, v_ids, v_codes)) q0) q,
    network_operator z,
    (select column_value routing_number_id, rownum rn from table(v_ids2)) q2
  where 1 = 1
  and z.network_operator_id(+) = decode(q.sys_error_code, util_pkg.c_ora_ok, q.sys_id, null)
  and nvl(z.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and q2.rn(+) = q.rn
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_network_operator_all
(
    p_date date,
    p_result out sys_refcursor
)
is
  v_type_code varchar2(30) := VP_NETWORK_OPERATOR.c_this_name;
  v_ids ct_number;
  v_ids2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  mnp_pkg.get_rn_id4no_all(p_date, v_ids, v_ids2);
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q, q2) full(z)*/
  row_number() over(order by z.network_operator_id) sys_item_id,
  v_type_code sys_type_code,
  util_pkg.c_ora_ok sys_error_code,
  util_pkg.c_msg_ok sys_error_message,
  z.network_operator_id sys_id,
  z.network_operator_code sys_code,
  z.network_operator_name sys_name,
  z.*,
  q2.routing_number_id
  from
    network_operator z,
    (select column_value network_operator_id, rownum rn from table(v_ids)) q,
    (select column_value routing_number_id, rownum rn from table(v_ids2)) q2
  where 1 = 1
  and nvl(z.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
  and q.network_operator_id(+) = z.network_operator_id
  and q2.rn(+) = q.rn
  order by sys_item_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_network_operator
(
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_uprs_member_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
)
is
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  ------------------------------
  if v_main_count > 0
  then
    ------------------------------
    get_network_operator_by_ids
    (
      p_ids => p_ids,
      p_codes => p_codes,
      p_uprs_member_codes => p_uprs_member_codes,
      p_date => p_date,
      p_result => p_result
    );
    ------------------------------
  else
    ------------------------------
    get_network_operator_all
    (
      p_date => p_date,
      p_result => p_result
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_zone_by_ids
(
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
)
is
  v_type_code varchar2(30) := VP_ZONE.c_this_name;
  v_main_count number;
  v_ids ct_number;
  v_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != v_main_count, 'p_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_codes) != v_main_count, 'p_codes.count != v_main_count');
  ------------------------------
  prepare_ids_zone(FALSE, TRUE, NULL, p_ids, p_codes, util_pkg.make_ct_date(v_main_count, p_date), v_ids, v_codes, v_error_codes, v_error_messages);
  ------------------------------
  open p_result for
select /*+ ordered use_nl(z) index(z PK_ZONE)*/
  q.sys_item_id,
  q.sys_type_code,
  decode(q.sys_error_code, util_pkg.c_ora_ok, decode(z.zone_id, null, util_pkg.c_ora_object_not_found, util_pkg.c_ora_ok), q.sys_error_code) sys_error_code,
  decode(q.sys_error_code, util_pkg.c_ora_ok, decode(z.zone_id, null, util_pkg.c_msg_object_not_found, util_pkg.c_msg_ok), q.sys_error_message) sys_error_message,
  q.sys_id,
  q.sys_code,
  z.zone_name sys_name,
  z.*
  from
    (select q0.*, rownum rn from table(util_ri.cast_ct_array2ct_sys_item31(v_type_code, v_error_codes, v_error_messages, v_ids, v_codes)) q0) q,
    zone z
  where 1 = 1
  and z.zone_id(+) = decode(q.sys_error_code, util_pkg.c_ora_ok, q.sys_id, null)
  and nvl(z.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_zone_all
(
    p_date date,
    p_result out sys_refcursor
)
is
  v_type_code varchar2(30) := VP_ZONE.c_this_name;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ full(z)*/
  row_number() over(order by z.zone_id) sys_item_id,
  v_type_code sys_type_code,
  util_pkg.c_ora_ok sys_error_code,
  util_pkg.c_msg_ok sys_error_message,
  z.zone_id sys_id,
  z.zone_code sys_code,
  z.zone_name sys_name,
  z.*
  from zone z
  where 1 = 1
  and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
  order by sys_item_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_zone
(
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
)
is
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  ------------------------------
  if v_main_count > 0
  then
    ------------------------------
    get_zone_by_ids
    (
      p_ids => p_ids,
      p_codes => p_codes,
      p_date => p_date,
      p_result => p_result
    );
    ------------------------------
  else
    ------------------------------
    get_zone_all
    (
      p_date => p_date,
      p_result => p_result
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_host_by_ids
(
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
)
is
  v_type_code varchar2(30) := VP_HOST.c_this_name;
  v_main_count number;
  v_ids ct_number;
  v_codes ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  v_ids2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != v_main_count, 'p_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_codes) != v_main_count, 'p_codes.count != v_main_count');
  ------------------------------
  prepare_ids_host(FALSE, TRUE, NULL, p_ids, p_codes, util_pkg.make_ct_date(v_main_count, p_date), v_ids, v_codes, v_error_codes, v_error_messages);
  ------------------------------
  v_ids2 := mnp_pkg.get_rn_id4host(v_ids, p_date, FALSE);
  ------------------------------
  open p_result for
select /*+ ordered use_nl(z) use_hash(q2) index(z PK_HOST)*/
  q.sys_item_id,
  q.sys_type_code,
  decode(q.sys_error_code, util_pkg.c_ora_ok, decode(z.host_id, null, util_pkg.c_ora_object_not_found, util_pkg.c_ora_ok), q.sys_error_code) sys_error_code,
  decode(q.sys_error_code, util_pkg.c_ora_ok, decode(z.host_id, null, util_pkg.c_msg_object_not_found, util_pkg.c_msg_ok), q.sys_error_message) sys_error_message,
  q.sys_id,
  q.sys_code,
  z.host_name sys_name,
  z.*,
  q2.routing_number_id
  from
    (select q0.*, rownum rn from table(util_ri.cast_ct_array2ct_sys_item31(v_type_code, v_error_codes, v_error_messages, v_ids, v_codes)) q0) q,
    host z,
    (select column_value routing_number_id, rownum rn from table(v_ids2)) q2
  where 1 = 1
  and z.host_id(+) = decode(q.sys_error_code, util_pkg.c_ora_ok, q.sys_id, null)
  and nvl(z.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and q2.rn(+) = q.rn
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_host_all
(
    p_date date,
    p_result out sys_refcursor
)
is
  v_type_code varchar2(30) := VP_HOST.c_this_name;
  v_ids ct_number;
  v_ids2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  mnp_pkg.get_rn_id4host_all(p_date, v_ids, v_ids2);
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q, q2) full(z)*/
  row_number() over(order by z.host_id) sys_item_id,
  v_type_code sys_type_code,
  util_pkg.c_ora_ok sys_error_code,
  util_pkg.c_msg_ok sys_error_message,
  z.host_id sys_id,
  z.host_code sys_code,
  z.host_name sys_name,
  z.*,
  q2.routing_number_id
  from
    host z,
    (select column_value host_id, rownum rn from table(v_ids)) q,
    (select column_value routing_number_id, rownum rn from table(v_ids2)) q2
  where 1 = 1
  and nvl(z.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
  and q.host_id(+) = z.host_id
  and q2.rn(+) = q.rn
  order by sys_item_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_host
(
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
)
is
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  ------------------------------
  if v_main_count > 0
  then
    ------------------------------
    get_host_by_ids
    (
      p_ids => p_ids,
      p_codes => p_codes,
      p_date => p_date,
      p_result => p_result
    );
    ------------------------------
  else
    ------------------------------
    get_host_all
    (
      p_date => p_date,
      p_result => p_result
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
