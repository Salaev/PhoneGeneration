CREATE PACKAGE RSIG_PHONE_NUMBER999 IS
  /****************************************************************************
    <header>
      <name>              package RSIG_PHONE_NUMBER
      </name>

      <author>            Petr Kout - GITUS
      </author>

      <version>           1.7.8     14.09.2010     Sergey Ermakov
                          procedure Get_phone_numbers_info_ex updated
      </version>

      <version>           1.7.7     10.09.2010     Denis Kovalchuk
                          procedure PROD_CheckPhones-ByList_2 renamed to PROD_CheckPhonesByList2
      </version>

      <version>           1.7.6     09.09.2010     Denis Kovalchuk
                          procedure PROD_CheckPhonesByList updated
                          procedure PROD_CheckPhonesByList2 updated
                          procedure PROD_GetNotLinked-Phones updated
                          procedure PROD_GetLinked-Phones updated
                          procedure PROD_CheckPhones-ByList_2 updated
                          procedure PROD_CheckPhones-ByRange_2 updated
      </version>
      <version>           1.7.5     04.09.2010     Denis Kovalchuk
                          procedure PROD_FindFreePhoneNumbers updated
      </version>
      <version>           1.7.4     03.09.2010     Denis Kovalchuk
                          procedure PROD_CheckPhones-ByRange_2 added
                          procedure PROD_FindFreePhoneNumbers updated
      </version>
      <version>           1.7.3     30.08.2010     Pavel Vasiliev
                          procedure PROD_GetLinked-Phones updated
      </version>
      <version>           1.7.2     27.08.2010     Pavel Vasiliev
                          procedure PROD_CheckPhonesByList2 created
      </version>
      <version>           1.7.2     06.08.2010    Pavel Vasiliev
                          procedure GetBalanceStorageByPAMSISDN is created
      </version>
      <version>           1.7.2     06.08.2010     Katerina Cerna
                          procedure Set_Phone_Number_Host_Relation is created
                          procedure Get_Pnum_Relation_to_Host is created
      </version>

      <version>           1.7.1     05.08.2010     Pavel Vasiliev
                          procedure PROD_FindFreePhoneNumbers updated
                          procedure PROD_CheckPhonesByList updated
                          procedure PROD_GetNotLinked-Phones updated
                          procedure PROD_GetLinked-Phones updated
      </version>

      <version>           1.7.0     16.07.2010     Denis Kovalchuk
                          procedure PROD_FindFreePhoneNumbers updated
                          procedure PROD_GetNotLinked-Phones created
                          procedure PROD_GetLinked-Phones created
      </version>
      <version>           1.6.6     20.02.2010     Olga Orlenko, Denis Kovalchuk
                          procedure GetPhonesByStatus2 updated
      </version>
      <version>           1.6.5     06.10.2009     Olga Orlenko
                          procedure Get_Phone_Numbers_by_ICCID updated
      </version>
      <version>           1.6.4     17.09.2009     Pavel Vasiliev
                          procedure GetPhonesByStatus2 updated
      </version>
      <version>           1.6.3     26.08.2009     Denis Kovalchuk
                          procedure GetPhonesByStatus2 updated
                          procedure GetPhonesByStatus3 updated
      </version>
      <version>           1.6.2     18.08.2009     Denis Kovalchuk
                          procedure Get_Phone_Numbers_by_ICCID added
      </version>
      <version>           1.6.1     13.08.2009     Victor Smirnov
                          procedure GetPhonesByStatus22 added
      </version>
      <version>           1.6.0     06.07.2009     Denis Kovalchuk
                          procedure Get_Phone_Salability_History updated
      </version>
      <version>           1.5.9     17.02.2009     Josef Hartman
                          procedure Get_Free_Phones updated
                          procedure Get_Free_Phones_By_Exchange updated
                          procedure Get_Free_Phones_by_port_type updated
                          procedure Get_Free_Phones_By_SIM_List updated
                          procedure getphonesbystatus updated
                          procedure getphonesbystatus2 updated
                          procedure getphonesbystatus2 added
      </version>
      <version>           1.5.8     14.11.2008     Josef Hartman
                          procedure getphonesbystatus2 updated
      </version>
      <version>           1.5.7     24.10.2008     Maxim Anoev
                          procedure getphonesbystatus2 created
      </version>
      <version>           1.5.6     19.02.2008     Petr Cepek
                          procedure GetPhonesByStatus updated
      </version>
      <version>           1.5.5     28.12.2007     Roger Stockley
                          procedure Get_Phone_Status_History updated
      </version>
      <version>           1.5.4     22.11.2007     Petr Cepek
                          procedure GetPhonesByStatus updated
      </version>
      <version>           1.5.3     27.9.2007     Petr Cepek
                          procedure Get_FreePhones_By_Host2 updated
      </version>
      <version>           1.5.2.3   4.7.2007     Petr Cepek
                          procedure GetPhonesByStatus created
      </version>
      <version>           1.5.2.2   24.04.2007     Petr Cepek
                          procedure Get_phone_numbers_info updated
      </version>
      <version>           1.5.2.1   19.4.2007      Petr Cepek
                          procedure Get_Free_Phones_By_Host2 updated
      </version>
      <version>           1.5.2     22.11.2006     Petr Cepek
                          procedure Get_Another_Phones_Used_By_Me deleted
                          procedure Get_My_Phones_Used_By_Another deleted
                          procedure Get_Phone_Numbers deleted
                          procedure Get_Phone_Number_Operator deleted
                          procedure Get_Sim_Card_History_By_Phone deleted
                          function Is_Phone_Free deleted
      </version>
      <version>           1.5.1     31.10.2006     Petr Cepek
                          procedure Get_Free_Phones updated
                          procedure Get_Free_Phones_By_SIM_List updated
                          procedure Get_Free_Phones_By_Host2 updated
                          procedure Get_Free_Phones_By_Exchange updated
      </version>
      <version>           1.5.0     11.10.2006     Petr Cepek
                          procedure Get_Free_Phones updated
                          procedure Get_Free_Phones_By_SIM_List updated
                          procedure Get_Free_Phones_By_Host2 updated
                          procedure Get_Phone_Status_History updated
      </version>
      <version>           1.4.8     05.10.2006     Petr Cepek
                          procedure Is_It_My_Phone deleted
                          procedure Get_All_Free_Phones_By_Exch_Ex deleted
                          procedure Get_Phone_Status_History updated
      </version>
      <version>           1.4.7     29.08.2006     Petr Cepek
                          procedure Get_phone_numbers_info updated
      </version>
      <version>           1.4.6     31.07.2006     Petr Cepek
                          procedure Get_Free_Phones_By_SIM_List updated
      </version>
      <version>           1.4.5     18.07.2006     Petr Cepek
                          procedure Insert_Phone_Number updated
                          procedure Get_Free_Phones updated
                          procedure Get_Free_Phones_By_SIM_List updated
                          procedure Get_Phone_Number_Decomposition updated
                          procedure Get_Network_Operator_By_Phone updated
                          procedure Get_All_Free_Phones_By_Exch updated
                          procedure Get_All_Free_Phones_By_Exch_Ex updated
                          procedure Get_phone_numbers_info updated
                          procedure Get_Our_Net_Op_By_Phone updated
                          procedure Get_Free_Phones_By_Exchange updated
                          procedure Get_Phone_Number_by_ICCID updated
                          procedure Get_Free_Phones_By_Host2 updated
                          procedure Get_Net_Op_and_Status_By_Phone updated
                          procedure Is_Phone_Free updated
      </version>
      <version>           1.4.4     04.07.2006     Petr Cepek
                          procedure Get_Free_Phones_By_Host2 updated
      </version>
      <version>           1.4.3     28.06.2006     Petr Cepek
                          procedure Get_Free_Phones_By_Host2 updated
      </version>
      <version>           1.4.2     30.05.2006     Petr Cepek
                          function Is_Phone_Number_In_Mask updated
                          procedure Mark_Gold_Phone_Numbers updated
                          procedure Get_Free_Phones updated
      </version>
      <version>           1.4.1     28.06.2006     Petr Cepek
                          procedure Get_Free_Phones_By_SIM_List updated
      </version>
      <version>           1.4.0     18.04.2006     Petr Cepek
                          procedure Get_Net_Op_and_Status_By_Phone created,
                          procedure Get_Phone_Number_info updated,
                          procedure Get_Free_Phones updated
      </version>
      <version>           1.3.9     10.03.2006     Petr Cepek
                          procedure Get_Free_Phones_By_SIM_List updated
      </version>
      <version>           1.3.8     24.01.2006     Petr Cepek
                          procedure Get_Free_Phones_By_SIM_List updated
      </version>
      <version>           1.3.7     10.01.2006     Petr Cepek
                          procedure Is_Phone_Free updated
      </version>
      <version>           1.3.6     24.11.2005     Petr Cepek
                          procedure Get_Free_Phones_By_SIM_List rewritten with associative arrays
      </version>
      <version>           1.3.5     16.11.2005     Petr Cepek
                          procedure Mark_Gold_Phone_Numbers updated
      </version>
      <version>           1.3.4     28.10.2005   Cepek Petr
                          procedures Get_Free_Phones, Get_Free_Phones_By_Exchange,
                          Get_Free_Phones_By_SIM_List updated
      </version>
      <version>           1.3.3     21.10.2005   Cepek Petr
                          procedures Get_Free_Phones, Get_Free_Phones_By_Exchange,
                          Get_Free_Phones_By_SIM_List updated
      </version>
      <version>           1.3.2     17.10.2005     Petr Cepek
                          some constant c_ORA_NOT_FREE_PHONES changed to c_NOT_FREE_PHONES
      </version>
      <version>
                          1.3.1     13.10.2005   Radomir Lipka
                          procedure Get_Free_Phones_By_SIM_List chnge cursor v_get_free_phone
      </version>
      <version>
                          1.3.0     7.10.2005   Radomir Lipka
                          procedure Get_phone_numbers_info modify add output columns
                          pns.phone_number_type_code,
                          pnsc.salability_category_code
      </version>
      <version>
                          1.2.9     6.10.2005   Radomir Lipka
                          procedure Get_Free_Phones_By_Host2 created
      </version>
      <version>
                          1.2.8     18.8.2005   Petr Cepek
                          procedure Get_Free_Phones_By_Exchange_O and Get_Free_Phones_By_Exchange_T updated
      </version>
      <version>
                          1.2.7     04.08.2005  Petr Cepek
                          procedure Mark_Gold_Phone_Numbers updated
      </version>
      <version>           1.2.6     18.07.2005 Petr Cepek
                        procedure Get_Free_Phones_By_SIM_List updated
      </version>
      <version>
                          1.2.5     07.07.2005    Petr Cepek
                          procedures Renumbering, Insert_Phone_Serie, Insert_Phone_Number added
      </version>

      <version>
                          1.2.4     06.06.2005    Petr Cepek
                                    procedures Get_All_Free_Phones_By_Exch_Ex,
                                    Get_Free_Phones_by_port_type updated, c_ORA_NOT_FREE_PHONES
      </version>

      <version>           1.2.3     30.05.2005    Radomir Lipka
                          procedure Get_Free_Phones_by_port_type
                          change type variable col_EPN_LIST from NUMBER to VARCHAR2
      </version>
      <version>           1.2.2     24.05.2005    Radomir Lipka
                          Mark_Gold_Phone_Numbers
                          added more salability categories and masks
      </version>
      <version>
                          1.2.1     20.05.2005  Radomir Lipka
                          Add procedure Mark_Gold_Num_for_New_Serie from
                          package RSIG_PHONE_NUMBER_SERIES and rename it on
                          Mark_Gold_Phone_Numbers.
      </version>

      <version>
                          1.2.0     10.05.2005  Petr Cepek
                          Procedure Get_Phone_Number_by_ICCID created.
      </version>

      <version>       1.0.1   10.9.2003     Petr Kout
                          created first version
      </version>

      <Description>       package provides set of usefull procedures and functions
                          performing various checks during run of the program
      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>
      </Parameters>
    </header>
  /****************************************************************************/

  TYPE t_phone_number_col IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
  TYPE t_SN IS TABLE OF VARCHAR2(60) INDEX BY BINARY_INTEGER;
  TYPE t_date IS TABLE OF DATE INDEX BY BINARY_INTEGER;

  TYPE t_varchar_2 IS TABLE OF VARCHAR2(2) INDEX BY BINARY_INTEGER;

  TYPE t_host_id IS TABLE OF VARCHAR2(60) INDEX BY BINARY_INTEGER;
  TYPE t_sal_cat IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;
  TYPE t_phone_status IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;
  type t_int_num is table of tt_batch_na_ap%rowtype;
  type t_TT_FOUND_PHONE_NUMBERS is table of TT_FOUND_PHONE_NUMBERS%rowtype;
  type t_batch_details is table of batch_details%rowtype;

  c_TURKMEN CONSTANT VARCHAR2(255) := 'TURKMEN';

  c_Max_Date         constant date := to_date('31.12.9999','dd.mm.syyyy');

  /****************************************************************************
    <header>
      <name>              procedure Change_Salability_Category
      </name>

      <author>            Petr Kout - GITUS
      </author>

      <version>           1.0.1   11.9.2003     Petr Kout
                                  created first version
      </version>

      <Description>       Procedure first checks, whether p_start_date is greater
                          than start date of the last interval for given phone number
                          salability category. If it is not, then procedure ends with
                          error c_DATE_OVERLAP.
                          If check passed successfully, procedure inserts new interval
                          for phone number salability category given by salability category
                          code and consequently closes last interval (end_date is set to
                          value of parameter start date).

      </Description>

      <Prerequisites>
                        Exists function:
                          RSIG_UTILS.Debug_Rsi
                          RSIG_UTILS.Handle_Error
                        Exists variable:
                          RSIG_UTILS.c_HANDLE_TRAN_S
                          RSIG_UTILS.c_HANDLE_TRAN_Y
                          RSIG_UTILS.c_HANDLE_TRAN_N
                          RSIG_UTILS.c_ORA_INVALID_HANDLE
                          RSIG_UTILS.c_OK
                          RSIG_UTILS.c_DEBUG_TEXT_START
                          RSIG_UTILS.c_DEBUG_TEXT_END
                          RSIG_UTILS.c_DEBUG_LEVEL_0
                          RSIG_UTILS.c_DEBUG_LEVEL_1
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                    allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                     RSIG_UTILS.c_HANDLE_TRAN_Y
                                                     RSIG_UTILS.c_HANDLE_TRAN_N
                          error_code - OUT - NUMBER
                          p_nework_address_id - network id address of the
                            phone number we want to change the salability of
                          p_salability_code - salability we want to set
                            the phone number to
      </Parameters>
    </header>
  /****************************************************************************/

  PROCEDURE Change_Salability_Category
  (
    handle_tran                IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                 OUT NUMBER,
    p_network_address_id       IN NUMBER, -- network ID of the phone number that we change the salability of
    p_salability_category_code IN VARCHAR2, -- salability we want to set the phone number to
    p_start_date               IN DATE, -- date since the salability change is valid
    p_user_id_of_change        IN NUMBER -- number of the user who performs this procedure
  );

  /****************************************************************************
    <header>
      <name>              procedure Get_Phone_Status_History
      </name>

      <author>            Petr Kout - GITUS
      </author>

      <version>           1.0.3     28.12.2007    Roger Stockley
                          column user_id added to cursor
      </version>
      <version>           1.0.2     05.10.2006    Petr Cepek
                          column na_trans_reason_code added to cursor
      </version>
      <version>           1.0.1   18.9.2003     Petr Kout
                          created first version
      </version>

      <Description>       Procedure provides IN OUT cursor parameter containing
                          data about given phone status history (start_date,
                          net_address_status_code).
      </Description>

      <Prerequisites>
                        Exists function:
                          RSIG_UTILS.Debug_Rsi
                          RSIG_UTILS.Handle_Error
                        Exists variable:
                          RSIG_UTILS.c_OK
                          RSIG_UTILS.c_DEBUG_TEXT_START
                          RSIG_UTILS.c_DEBUG_TEXT_END
                          RSIG_UTILS.c_DEBUG_LEVEL_0
                          RSIG_UTILS.c_DEBUG_LEVEL_1
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        error_code - OUT - NUMBER
                          p_nework_address_id - network id address of the
                            phone number we want to get status history of
                          p_cur_phone_status_history - the cursor that retrieved rows will
                            be stored in (start_date, net_address_status_code)
      </Parameters>
    </header>
  /****************************************************************************/
PROCEDURE Get_Phone_Status_History(
  p_network_address_id     IN  PHONE_NUMBER.NETWORK_ADDRESS_ID%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);

  /****************************************************************************
    <header>
      <name>              procedure Get_Phone_Operator_History
      </name>

      <author>            Petr Kout - GITUS
      </author>

      <version>           1.0.1   15.9.2003     Petr Kout
                                  created first version
      </version>

      <Description>       Procedure provides IN OUT cursor parameter containing
                          data about given phone operator history (network_address_id,
                          start_date and end_date)
      </Description>

      <Prerequisites                      Exists function:
                          RSIG_UTILS.Debug_Rsi
                          RSIG_UTILS.Handle_Error
                        Exists variable:
                          RSIG_UTILS.c_OK
                          RSIG_UTILS.c_DEBUG_TEXT_START
                          RSIG_UTILS.c_DEBUG_TEXT_END
                          RSIG_UTILS.c_DEBUG_LEVEL_0
                          RSIG_UTILS.c_DEBUG_LEVEL_1
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        error_code - OUT - NUMBER
                          p_nework_address_id - network id address of the
                            phone number we want to get operator history of
                          p_cur_phone_operator_history - cursor that given phone
                            operator history (network_address_id, start_date,
                            end_date) will be stored in
      </Parameters>
    </header>
  /****************************************************************************/

  PROCEDURE Get_Phone_Operator_History
  (
    error_code                   OUT NUMBER,
    p_network_address_id         IN PHONE_NUMBER.NETWORK_ADDRESS_ID%TYPE, -- id of the phone number we are getting the status history for
    p_cur_phone_operator_history IN OUT RSIG_UTILS.REF_CURSOR -- cursor that given phone operator history (network_address_id, start_date, end_date) will be stored in
  );

  /****************************************************************************
    <header>
      <name>              PROCEDURE Get_Free_Phones_By_SIM_List
      </name>

      <author>            Pavel Stengl
      </author>

      <version>           1.2.8  17.02.2009  Josef Hartman
                          Parameter p_user_id_of_change changed to p_user_login
      </version>
      <version>           1.2.7     31.10.2006     Petr Cepek
                          condition added: only phone numbers not present in the
                          table phone_link are considered
      </version>
      <version>           1.2.6       11.10.2006   Petr Cepek
                          optimalization
      </version>
      <version>           1.2.5       31.07.2006   Petr Cepek
                          check for already linked sim card of single type definitely removed
      </version>
      <version>           1.2.4       18.07.2006   Petr Cepek
                          partitioning of table phone_number used
      </version>
      <version>           1.2.3       28.06.2006   Petr Cepek
                          fixed check for already linked sim card of single type
      </version>
      <version>           1.2.2      10.03.2006    Petr Cepek
                          check for already linked sim cards of single type added
      </version>
      <version>           1.2.1      24.01.2006    Petr Cepek
                          check for already linked sim cards of single type deleted
      </version>
      <version>           1.2.0      24.11.2005    Petr Cepek
                          procedure rewritten with associative arrays
      </version>
      <version>
                          1.1.0      21.10.2005    Petr Cepek
                          procedure rewritten using new columns
                          NET_ADDRESS_STATUS_CODE and SALABILITY_CATEGORY_CODE
                          in the table PHONE_NUMBER
      </version>
      <version>
                        1.0.5    18.7.2005   Petr Cepek
                        consideration of network operator added
      </version>

      <version>           1.0.4   10.3.2005     Jaroslav Holub
                          fix output cursor - to not join SIM_CARDS - if sim card
                          doesnt exists it cause error - SIM do not apear in cursor.
      </version>
      <version>           1.0.3   13.2.2004     Pavel Stengl
                  use INTERNATIONAL FORMAT instead of local phone number
      </version>
      <version>           1.0.2 10.2.2004     Pavel Stengl
                  change INPUT parameters
      </version>
      <version>           1.0.1   28.1.2004     Pavel Stengl
                                  created first version
      </version>

      <Description>

               Procedure assigns free phone number to Sim card. The procedure has three possible states.
               1. If input parameters P_RESERVE <> 'Y' and P_JOIN <> 'Y' then procedure find free phone
                number to sim card (access_point_id). Ref cursor contains number of sim card (network_address_id)
                and it associated phone nuber (access_point_desc). (IMSI,NETWORK_ADDRESS_ID, ACCESS_POINT_DESC)
               2. If input parameter P_RESERVE = 'Y' then procedure find free phone number to sim card
                and these phone numbers are set like RESERVERED in table NETWORK_ADDRESS_STATUS_HISTORY.
                Ref cursor contains SN, NETWORK_ADDRESS_ID, ACCESS_POINT_DESC, RESULT
               3. If input parameter P_JOIN = 'Y' then procedure find free phone number to sim card.
                If sim card had not assign phone number, Link type code is set value 'M' - MAIN link type
                otherwise is set 'S' - SECOND link type
                These phone numbers are  associated to sim card in table NETWORK_ADDRESS_ACCESS_POINT.
                Ref cursor contains SN, NETWORK_ADDRESS_ID, ACCESS_POINT_DESC, RESULT.

      </Description>

      <Prerequisites>
                        Exists function:
                          RSIG_UTILS.Debug_Rsi
                          RSIG_UTILS.Handle_Error
                        Exists variable:
                          RSIG_UTILS.c_OK
                          RSIG_UTILS.c_DEBUG_TEXT_START
                          RSIG_UTILS.c_DEBUG_TEXT_END
                          RSIG_UTILS.c_DEBUG_LEVEL_0
                          RSIG_UTILS.c_DEBUG_LEVEL_1
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>
                          handle_tran            IN
                          p_batch_session_id     IN   Session identification (for finding list of data)
                          p_salability_category  IN   code of the required salability category
                          p_phone_type           IN   code of the required phone type
                          p_reserve              IN   set RESERVE
                          p_join                 IN   associate phone number to sim card
                          p_user_id_of_change    IN   user id of change (USER_ID_OF_CHANGE)
                          error_code             OUT  NUMBER,
                          result_list            OUT  sys_refcursor (SN,NETWORK_ADDRESS_ID, ACCESS_POINT_DESC, RESULT)
      </Parameters>
    </header>
  ****************************************************************************/

PROCEDURE Get_Free_Phones_By_SIM_List(
  p_SN_list                  IN  t_SN, -- list of sim cards
  p_salability_category      IN  phone_number.salability_category_code%TYPE, -- code of the required salability category
  p_phone_type               IN  PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE, -- code of the required phone type
  p_reserve                  IN  CHAR,
  p_join                     IN  CHAR,
  p_user_login               IN  VARCHAR2,
  handle_tran                IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                 OUT NUMBER,
  error_message              OUT VARCHAR2,
  result_list                OUT sys_refcursor
);

  /****************************************************************************
    <header>
      <name>              PROCEDURE Get_Network_Operator_By_Phone
      </name>

      <author>            Petr Kout - GITUS
      </author>

      <version>           1.0.3     18.07.2006    Petr Cepek
                          columns from network_address moved to phone_number
      </version>
      <version>           1.0.2   20.2.2004   Jaroslav Holub - STROM
                          changed for international format
      </version>
      <version>           1.0.1   18.2.2004     Pavel Stengl - STROM
                          created first version
      </version>

      <Description>       Procedure returns value UPRS members code for given phone number in INTERNATIONAL FORMAT at given date

      </Description>

      <Prerequisites>
                        Exists function:
                          RSIG_UTILS.Debug_Rsi
                          RSIG_UTILS.Handle_Error
                        Exists variable:
                          RSIG_UTILS.c_OK
                          RSIG_UTILS.c_IT_IS_MY_PHONE;
                          RSIG_UTILS.c_IT_IS_NOT_MY_PHONE;
                          RSIG_UTILS.c_DEBUG_TEXT_START
                          RSIG_UTILS.c_DEBUG_TEXT_END
                          RSIG_UTILS.c_DEBUG_LEVEL_0
                          RSIG_UTILS.c_DEBUG_LEVEL_1
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        error_code - OUT - NUMBER
                          p_phone_number - phone number in INTERNATIONAL FORMAT
                          p_validity_date - validity date
                          p_uprs_member_code OUT

      </Parameters>
    </header>
  /****************************************************************************/

  PROCEDURE Get_Network_Operator_By_Phone
  (
    error_code         OUT NUMBER,
    p_phone_number     IN VARCHAR2, -- phone number in INTERNATIONAL FORMAT
    p_validity_date    IN DATE,
    p_uprs_member_code OUT NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE
  );

 /****************************************************************************
    <header>
      <name>              Get_Phones_By_ICCID_list
      </name>

      <author>            Lucie Sevcikova
      </author>

      <version            1.1.0          30.09.2005   Petr Cepek
                          procedure rewritten with associative arrays
      </version>
      <version>           1.0.2          1.4.2004     Pavel Stengl
                          changen IMSI by ICCID in the table TMP_BATCH_NET_ADDR_ACC_POINT
      </version>
      <version>           1.0.1        18.2.2004      Lucie Sevcikova
                          optimized
      </version>
      <version>           1.0.0        29.12.2003     Lucie Sevcikova
                          created first version
      </version>

      <Description>       Procedure returns phone numbers in international format
                          valid at date for list of ICCIDs.
      </Description>

      <Prerequisites>
                        Exists function:
                          RSIG_UTILS.Debug_Rsi
                          RSIG_UTILS.Handle_Error
                        Exists variable:
                          RSIG_UTILS.c_OK
                          RSIG_UTILS.c_DEBUG_LEVEL_0
                          RSIG_UTILS.c_DEBUG_LEVEL_1
                          RSIG_UTILS.c_DEBUG_LEVEL_2
                          RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                          RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                          RSIG_UTILS.c_DEBUG_TEXT_START
                          RSIG_UTILS.c_DEBUG_TEXT_END
                          RSIG_UTILS.c_DEBUG_TEXT_BEFORE_SELECT
                          RSIG_UTILS.c_DEBUG_TEXT_AFTER_SELECT
                          RSIG_UTILS.c_DEBUG_TEXT_BEFORE_LOOP
                          RSIG_UTILS.c_DEBUG_TEXT_IN_LOOP
                          RSIG_UTILS.c_DEBUG_TEXT_AFTER_LOOP
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>
         p_ICCID_list         list of ICCIDs
         p_date_list          list of validity dates
         p_raise_error             Y - raise error
         error_code                error code
         error_message             error message
         result_list               recordset
      </Parameters>

    </header>
  ****************************************************************************/
PROCEDURE Get_Phones_By_ICCID_list(
  p_ICCID_list       IN   t_SN,
  p_date_list        IN   t_date,
  p_raise_error      IN   CHAR,
  error_code         OUT  NUMBER,
  error_message      OUT  VARCHAR2,
  result_list        OUT  SYS_REFCURSOR
);


  /****************************************************************************
    <header>
      <name>              procedure Get_Access_Point_Hist_By_Phone
      </name>

      <author>            Jaroslav Holub - STROM
      </author>

      <version>           1.0.3   24.08.2004     Jaroslav Holub
                                  added 2 collumns into output cursor, IMSI and user_id_of_change
      </version>
      <version>           1.0.2   01.07.2004     Jaroslav Holub
                                  fix error with ports - where condition missing
      </version>
      <version>           1.0.1   12.5.2004     Jaroslav Holub
                                  created first version
      </version>

      <Description>       Procedure returns history of access point by
                given phone number (NETWORK_ADDRES_ID) - history type is showed in record_type column
              ('S' simcard, 'P' port)

      </Description>

      <Prerequisites>
                        Exists function:
                          RSIG_UTILS.Debug_Rsi
                          RSIG_UTILS.Handle_Error
                        Exists variable:
                          RSIG_UTILS.c_OK
                          RSIG_UTILS.c_DEBUG_TEXT_START
                          RSIG_UTILS.c_DEBUG_TEXT_END
                          RSIG_UTILS.c_DEBUG_LEVEL_0
                          RSIG_UTILS.c_DEBUG_LEVEL_1
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        error_code        - OUT - NUMBER
                          p_network_address_id  - IN
                          p_cur_phone_status_history - the cursor that retrieved rows will
                            be stored in (record_type (S - simcard, P - port), ID (ICCID in case of simcard, port number in case of port), FROM_DATE, TO_DATE)
      </Parameters>
    </header>
  /****************************************************************************/
  PROCEDURE Get_Access_Point_Hist_By_Phone
  (
    error_code                 OUT NUMBER,
    p_network_address_id       IN PHONE_NUMBER.NETWORK_ADDRESS_ID%TYPE,
    p_cur_phone_status_history IN OUT RSIG_UTILS.REF_CURSOR
  );

  /****************************************************************************
    <header>
      <name>              procedure Get_Phone_Status_History
      </name>

      <author>            Pavel Stengl - STROM
      </author>

      <version>           1.0.1   26.3.2004     Pavel Stengl
                                  created first version
      </version>

      <Description>       Procedure provides IN OUT cursor parameter containing
                          data about given phone salability history (SALABILITY_CATEGORY_NAME,
                          START_DATE, END_DATE, DATE_OF_CHANGE, USER_ID_OF_CHANGE).
      </Description>

      <Prerequisites>
                        Exists function:
                          RSIG_UTILS.Debug_Rsi
                          RSIG_UTILS.Handle_Error
                        Exists variable:
                          RSIG_UTILS.c_OK
                          RSIG_UTILS.c_DEBUG_TEXT_START
                          RSIG_UTILS.c_DEBUG_TEXT_END
                          RSIG_UTILS.c_DEBUG_LEVEL_0
                          RSIG_UTILS.c_DEBUG_LEVEL_1
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        error_code - OUT - NUMBER
                          p_nework_address_id - network id address of the
                            phone number we want to get status history of
                          p_cur_phone_status_history - the cursor that retrieved rows will
                            be stored in (SALABILITY_CATEGORY_NAME, START_DATE, END_DATE,
                        DATE_OF_CHANGE, USER_ID_OF_CHANGE)
      </Parameters>
    </header>
  /****************************************************************************/

  PROCEDURE Get_Phone_Salability_History
  (
    error_code              OUT NUMBER,
    p_network_address_id    IN PHONE_NUMBER.NETWORK_ADDRESS_ID%TYPE, -- id of the phone number we are getting the status history for
    p_cur_phone_sal_history IN OUT RSIG_UTILS.REF_CURSOR
  );

 /****************************************************************************
    <header>
      <name>              procedure Get_phone_numbers_info
      </name>

      <author>            Jaroslav Holub
      </author>

      <version>           1.0.3.1  24.04.2007    Petr Cepek
                          output cursor extended by column network_operator_type
      </version>
      <version>           1.0.3    29.08.2006    Petr Cepek
                          hint added
      </version>
      <version>           1.0.2    19.07.2006    Petr Cepek
                          columns from network_address moved to phone_number
      </version>
      <version>           1.0.1    2.5.2006   Petr Cepek
                          hint for I_NETADSTAHI_NETWORK_ADDRES_ID index added,
                          when parameter p_validity_date is null, then tables
                          network_address_status_history and phone_number_salability_categ
                          are not used
      </version>
      <version>           1.0.0   01.09.2004  Jaroslav Holub
                                  created first version
      </version>

      <Description>       procedure returns information about phone numners,
                when found then resul is RSIG_UTILS.c_OK, when not
                          result is RSIG_UTILS.c_ROW_NOT_FOUND

      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       FORIS Resource inventory
      </Application>

      <Parameters>
                          p_Validity_Date   date of validity
              p_Phone_Number_List  - associative array of
                              international format of phone number
                          p_raise_error     IN  CHAR,
                          error_code        OUT NUMBER,
                          error_message     OUT VARCHAR2
      </Parameters>

    </header>
  ****************************************************************************/
 procedure Get_phone_numbers_info(
   p_Validity_Date     IN DATE,
   p_Phone_Number_List IN t_phone_number_col,
   p_raise_error       IN CHAR,
   error_code          OUT NUMBER,
   error_message       OUT VARCHAR2,
   result_list         OUT SYS_REFCURSOR
 );

  /****************************************************************************
    <header>
      <name>            PROCEDURE Get_Our_Net_Op_By_Phone
      </name>

      <author>          Lucie Sevcikova
      </author>

      <version>         1.0.1   20.07.2006   Petr Cepek
                        columns from network_address moved to phone_number
      </version>
      <version>         1.0.0   21.10.2004
                                created first version
      </version>

      <Description>     Procedure returns value UPRS members code and network
                        operator name for given phone number in INTERNATIONAL
                        FORMAT at given date, if this phone number has not
                        status "Other billing"
      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>
      </Parameters>
    </header>
  /****************************************************************************/

  PROCEDURE Get_Our_Net_Op_By_Phone
  (
    error_code         OUT NUMBER,
    p_phone_number     IN VARCHAR2, -- phone number in INTERNATIONAL FORMAT
    p_validity_date    IN DATE,
    p_uprs_member_code OUT NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
    p_operator_name    OUT network_operator.network_operator_name%TYPE
  );


/****************************************************************************
  <header>
    <name>              procedure Get_Phone_Number_by_ICCID
    </name>

    <author>            Petr Cepek
    </author>

    <version>           1.0.2     20.07.2006   Petr Cepek
                        columns from network_address moved to phone_number
    </version>
    <version>           1.0.1     30.11.2005   Petr Cepek
                        set default value for p_validity_date as sysdate
    </version>
    <version>           1.0.0   12.5.2005 Petr Cepek
                                created first version
    </version>

    <Description>       Procedure returns phone numbers, its types and type of link for
                        all phone numbers connected with given SIM card at given date and time.

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Get_Phone_Number_by_ICCID(
  p_ICCID          IN sim_card.sn%TYPE,
  p_validity_date  IN DATE,
  p_raise_error    IN CHAR,
  error_code       OUT NUMBER,
  error_message    OUT VARCHAR2,
  result_list      OUT SYS_REFCURSOR
);

  /****************************************************************************
    <header>
      <name>              function Is_Phone_Number_In_Mask
      </name>

      <author>            Radomir Lipka - STROM
      </author>

      <version>           1.0.2   30.05.2006   Petr Cepek
                          Function changed to return INT type.

      </version>
      <version>           1.0.1   25.5.2005     Radomir Lipka
                                  created first version
      </version>

      <Description>
                          Function return 1 when phone number match the mask, 0 when
                          phone number does not match the mask.
      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>
              p_phone_number  -- actuall phone number
              p_mask          -- actuall mask
      </Parameters>

    </header>
  ****************************************************************************/
  FUNCTION Is_Phone_Number_In_Mask
  (
    p_phone_number IN VARCHAR2, -- actuall phone number
    p_mask         IN VARCHAR2 -- actuall mask
  ) RETURN INT;

  /****************************************************************************
    <header>
      <name>              procedure Mark_Gold_Phone_Numbers
      </name>

      <author>            Jaroslav Holub - STROM
      </author>

      <version>
      </vesion>           1.0.8    30.05.2006   Petr Cepek
                          procedure optimized to be processed in single SQL statements
      <version>           1.0.7    16.11.2005   Petr Cepek
                          CURSOR cur4 optimized
      </version>
      <verison>
                          1.0.6    4.8.2005      Petr Cepek
                          when no mask exist, all phone numbres are treated as standard
      </version>
      <version>           1.0.5    25.05.2005    Jaroslav Holub
                          Beutifired
      </version>
      <version>           1.0.4    24.05.2005    Radomir Lipka
                          added more salability categories and masks
      </version>
      <version>           1.0.3    07.03.2005    Jaroslav Holub
                          added p_set_gold - if RSIG_UTILS.c_YES - then test and set gold numbers,
                                if others then set all numbers as normal
      </version>
      <version>           1.0.2   09.09.2004    Jaroslav Holub
                          changed for accept date with NULL - sysdate
      </version>
      <version>           1.0.1   28.1.2004     Jaroslav Holub
                                  created first version
      </version>

      <Description>       Procedure set appropriate salability category for all phone numbers
                          in given phone series according to salability category masks.
      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>
      </Parameters>

    </header>
  ****************************************************************************/
PROCEDURE Mark_Gold_Phone_Numbers(
  handle_tran                     IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_start_date                    IN  DATE, -- Validity start date and time (if null, then current date and time is considered)
  p_phone_number_series_id        IN  PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
  p_user_id_of_change             IN  NUMBER, -- id of the user who insert this serie
  p_set_gold                      IN  CHAR, -- "Y" means, that salability category should be set according to set masks, "N" means, that salability category should be set to "standard
  p_leave_marked_unchanged        IN  CHAR, -- "N" means, that salability category should be set for all phone numbers in series, "Y" means, that salability category should be set for "standard" phone numbers only
  p_raise_error                   IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code                      OUT NUMBER
);

  /****************************************************************************
  <header>
    <name>            procedure Renumbering
    </name>

    <author>          Petr Cepek
    </author>

    <version>
                      1.0  21.6.2005 12:46:40  -  created
    </version>

    <Description>     Procedure renumbers appropriate range of phone numbers, creates for them new series
                      and connects them to appropriate access point.
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>      Resource Inventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
  ******************************************************************************/
  PROCEDURE Renumbering(
    p_Old_Series_Start    IN  phone_number.international_format%TYPE,
    p_New_Country_Code    IN  phone_number_series.country_code%TYPE,
    p_New_Area_Code       IN  phone_number_series.area_code%TYPE,
    p_New_Local_Start     IN  phone_number_series.local_number_start%TYPE,
    p_Number_of_Phones    IN  INT,
    p_Start_Date          IN  DATE,
    p_user_id_of_change   IN  NUMBER,
    p_date_of_change      IN  DATE,
    handle_tran            IN  CHAR,
    p_raise_error          IN  CHAR,
    error_code            OUT NUMBER,
    error_message          OUT VARCHAR2
  );

/****************************************************************************
  <header>
    <name>            procedure Insert_Phone_Serie
    </name>

    <author>          Petr Cepek
    </author>

    <version>
                      1.0  21.6.2005 12:46:40  -  created
    </version>

    <Description>     Procedure inserts new phone serie for appropriate range of
                      phone numbers. If there are any existing series, then only
                      empty spaces are filled.
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>      Resource Inventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
  ******************************************************************************/
PROCEDURE Insert_Phone_Serie(
  p_Country_Code        IN  phone_number_series.country_code%TYPE,
  p_Area_Code           IN  phone_number_series.area_code%TYPE,
  p_Local_Start         IN  phone_number_series.local_number_start%TYPE,
  p_Local_End           IN  phone_number_series.local_number_end%TYPE,
  p_Host_Id             IN  host.host_id%TYPE,
  p_Network_Operator_id IN  phone_series_operator.network_operator_id%TYPE,
  p_PN_type_code        IN  phone_number_series.phone_number_type_code%TYPE,
  p_Start_Date          IN  DATE,
  p_user_id_of_change   IN  NUMBER,
  p_date_of_change      IN  DATE,
  handle_tran            IN  CHAR,
  p_raise_error          IN  CHAR,
  error_code            OUT NUMBER,
  error_message          OUT VARCHAR2
);

/****************************************************************************
  <header>
    <name>            procedure Insert_Phone_Number
    </name>

    <author>          Petr Cepek
    </author>

    <version>         1.1  18.07.2006     Petr Cepek
                      columns from network_address moved to phone_number
    </version>
    <version>
                      1.0  21.6.2005 12:46:40  -  created
    </version>

    <Description>     Procedure inserts new phone number. If same phone number exist
                      then all parameters are changed according to imput parameters.
                      If existing phone number is already
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>      Resource Inventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
  ******************************************************************************/
PROCEDURE Insert_Phone_Number(
  p_international_format IN  phone_number.international_format%TYPE,
  p_NA_status_code       IN  network_address_status_history.net_address_status_code%TYPE,
  p_SC_code              IN  phone_number_salability_categ.salability_category_code%TYPE,
  p_access_point_id      IN  access_point.access_point_id%TYPE,
  p_link_type_code       IN  network_address_access_point.link_type_code%TYPE,
  p_Start_Date           IN  DATE,
  p_user_id_of_change    IN  NUMBER,
  p_date_of_change       IN  DATE,
  handle_tran             IN  CHAR,
  p_raise_error           IN  CHAR,
  error_code             OUT NUMBER,
  error_message           OUT VARCHAR2
);

/****************************************************************************
<header>
  <name>            procedure Get_Net_Op_and_Status_By_Phone
  </name>

  <author>          Petr Cepek
  </author>

  <version>         1.0.1     20.07.2006    Petr Cepek
                    columns from network_address moved to phone_number
  </version>
  <version>
                    1.0.0     12.4.2006  -  created
  </version>

  <Description>     Procedure returns UPRS member code and phone status for given
                    phone number.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Net_Op_and_Status_By_Phone(
  p_phone_number           IN  phone_number.international_format%TYPE,
  p_validity_date          IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  p_other_billing          OUT CHAR,
  p_uprs_member_code       OUT NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE
);

/****************************************************************************
<header>
  <name>            procedure GetPhonesByStatus
  </name>

  <author>          Petr Cepek
  </author>

  <version>         1.0.3  17.02.2009  Josef Hartman
                    Parameter p_user_id changed to p_user_login
  </version>
  <version>
                    1.0.2     19.2.2008  -  procedure extended
                    parameter p_StartingRow added
  </version>
  <version>
                    1.0.1     22.11.2007  -  bug fixed
                    only when some phone number is found then status is changed
  </version>
  <version>
                    1.0.0     04.07.2007  -  created
  </version>

  <Description>     Procedure returns phone numbers according to input parameters.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
procedure GetPhonesByStatus(
  p_host_id                      IN  VARCHAR2,
  p_network_operator_id          IN  network_operator.network_operator_id%TYPE,
  p_phone_type                   IN  phone_number_series.phone_number_type_code%TYPE,
  p_salability_category          IN  phone_number.salability_category_code%TYPE,
  p_series_id                    IN  phone_number_series.phone_number_series_id%TYPE,
  p_mask                         IN  VARCHAR2,
  p_phone_number_status_code     IN  phone_number.net_address_status_code%TYPE,
  p_set_phone_number_status_code IN  phone_number.net_address_status_code%TYPE,
  p_StartingRow                  IN  NUMBER,
  p_Phone_Number_Count           IN  NUMBER,
  p_user_login                   IN  VARCHAR2,
  p_handle_tran                  IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error                  IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                   OUT NUMBER,
  p_error_message                OUT VARCHAR2,
  p_result_list                  OUT SYS_REFCURSOR
);

/****************************************************************************
  <header>
    <name>              procedure Get_Phone_Numbers_by_ICCID
    </name>

    <author>            Petr Cepek
    </author>

    <version>           1.0.0   18.8.2009 Petr Cepek
                                created first version
    </version>

    <Description>       Procedure returns phone numbers, its types and type of link for
                        all phone numbers connected with given SIM card at given date and time.

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
******************************************************************************/
procedure Get_Phone_Numbers_by_ICCID
(
  p_ICCID_list    IN common.t_ICCID,
  p_raise_error   IN CHAR,
  error_code      OUT NUMBER,
  error_message   OUT VARCHAR2,
  result_list     OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure PROD_FindFreePhoneNumbers
  </name>

  <author>          Pavel Vasiliev
  </author>

  <version>
                    1.0.0  14.05.2010  -  created
  </version>

  <Description>     Procedure finds phone numbers according to input parameters
                    (HLR code, phone status,phone type, MSISDN mask,p_salability_category)
                    and returns phone numbers. When parameter p_quantity_limit
                    is specified then only less or max. same number of phone numbers
                    will be returned. When parameters p_MSISDN_start and p_MSISDN_end
                    are specified then only phone numbers in this range
                    will be returned.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>      Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
procedure PROD_FindFreePhoneNumbers(
  p_host_id host.host_id%type,
  p_msisdn_mask varchar2,
  p_msisdn_start varchar2,
  p_msisdn_end varchar2,
  p_service_provider_code varchar2,
  p_linked_service_provider_code varchar2,
  p_phone_status_code phone_number.net_address_status_code%type,
  p_phone_type_code phone_number_series.phone_number_type_code%type,
  p_quantity_limit number,
  p_salability_category varchar2,
  p_user_login users.login_name%type,
  p_handle_tran char default rsig_utils.c_handle_tran_y,
  p_raise_error char default rsig_utils.c_no,
  p_error_code out number,
  p_error_message out varchar2,
  p_result_list out sys_refcursor,
  p_rejected_list out sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure PROD_CheckPhonesByList
  </name>

  <author>          Pavel Vasiliev
  </author>

  <version>
                    1.0.0  14.05.2010  -  created
  </version>

  <Description>
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>      Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
procedure PROD_CheckPhonesByList(
  p_phone_list             IN  t_phone_number_col,
  p_host_id               IN  host.host_id%TYPE,
  p_service_provider_code  IN  VARCHAR2,
  p_linked_service_provider_code  IN  VARCHAR2,
  p_phone_status_code      IN  phone_number.net_address_status_code%TYPE,
  p_phone_type_code        IN  phone_number_series.phone_number_type_code%TYPE,
  p_salability_category    IN  VARCHAR2,
  p_user_login             IN  users.login_name%type,
  p_handle_tran             IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor,
  p_rejected_list          OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure Set_Phone_Number_Host_Relation
  </name>

  <author>          Katerina Cerna
  </author>

  <version>
                    1.0  05.8.2010   -  created
  </version>

  <Description>     Procedure insert new relation between phone number and some host.
                    Old relation for same host type is terminated. When new host is
                    same as old host error is raised.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/


PROCEDURE Set_Phone_Number_Host_Relation(
  p_pnum_series_id        IN  phone_number_series_host.phone_number_series_id%TYPE,
  p_host_id               IN  host.host_id%TYPE,
  p_start_date            IN  DATE,
  p_end_date              IN  DATE,
  p_user_id_of_change     IN  NUMBER,
  handle_tran             IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error           IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code              OUT NUMBER,
  error_message           OUT VARCHAR2
);

/****************************************************************************
<header>
  <name>            procedure Get_Pnum_Relation_to_Host
  </name>

  <author>          Katerina Cerna
  </author>

  <version>
                    1.0  05.8.2010  -  created
  </version>

  <Description>     Procedure returns in cursor data about relation
                    of given phone number and hosts.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/

PROCEDURE Get_Pnum_Relation_to_Host(
  p_pnum_series_id         IN  phone_number_series_host.phone_number_series_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure GetBalanceStorageByPAMSISDN
  </name>

  <author>          Pavel Vasiliev
  </author>

  <version>
                    1.0  20.08.2010  -  created
  </version>

  <Description>     Procedure returns in cursor data about host
                    by given phone number and personal account number.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/

PROCEDURE GetBalanceStorageByPAMSISDN(
  p_international_format   IN  phone_number.international_format%TYPE,
  p_personal_account       IN  personal_account_history.personal_account%TYPE,
  p_validity_date          IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure GetBalanceStorageByPNList
  </name>

  <author>          Oleg Afanasev
  </author>

  <version>
                    1.0  25.04.2012  -  created
  </version>

  <Description>     Procedure returns in cursor data about balance storage
                    by given phone number list.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/

PROCEDURE GetBalanceStorageByPNList(
  p_PN_list                IN   t_phone_number_col,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

PROCEDURE PROD_CheckPhonesByList2(
  p_phone_list             IN  t_phone_number_col,
  p_host_id               IN  host.host_id%TYPE,
  p_service_provider_code  IN  VARCHAR2,
  p_linked_service_provider_code  IN  VARCHAR2,
  p_phone_status_code      IN  phone_number.net_address_status_code%TYPE,
  p_phone_type_code        IN  phone_number_series.phone_number_type_code%TYPE,
  p_salability_category    IN  VARCHAR2,
  p_allowed_salability_category              IN t_sal_cat,
  p_user_login             IN  users.login_name%type,
  p_handle_tran             IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor,
  p_rejected_list          OUT sys_refcursor
);

/****************************************************************************
  PROCEDURE

  %author            Pavel Vasiliev
  %created           04.07.2011
  %version           1.0.0

  %param             p_error_code             OUT   NUMBER - error code

  %expected_error_codes
  0 - successful completion
*/
/* {%skip}

  %version_log


****************************************************************************/

PROCEDURE Add_External_Phone
(
  p_international_format          IN  VARCHAR2,
  p_user_nt_name                  IN  VARCHAR2,
  p_handle_tran                     IN  CHAR,
  p_raise_error                     IN  CHAR,
  p_error_code                     OUT NUMBER,
  p_error_message                  OUT VARCHAR2
);

/****************************************************************************
  PROCEDURE

  %author            Pavel Vasiliev
  %created           04.07.2011
  %version           1.0.0

  %param             p_error_code             OUT   NUMBER - error code

  %expected_error_codes
  0 - successful completion
*/
/* {%skip}

  %version_log


****************************************************************************/
PROCEDURE Add_External_Phones
(
  p_international_format                IN  t_phone_number_col,
  p_user_nt_name                        IN  VARCHAR2,
  p_handle_tran                           IN  CHAR,
  p_raise_error                         IN  CHAR,
  p_cursor                              OUT SYS_REFCURSOR,
  p_error_code                          OUT NUMBER,
  p_error_message                       OUT VARCHAR2
);

----------------------------------!---------------------------------------------
  procedure ChangeReservePhoneList
  (
    p_reserve_number number,
    p_select_msisdn_list util_pkg.cit_varchar_s,
    p_remove_msisdn_list util_pkg.cit_varchar_s,
    p_user_login varchar2,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor
  );

  procedure change_reserve_i
  (
    p_reserve_number number,
    p_na_ids ct_number,
    p_remove boolean,
    p_date date,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2,
    p_error_na_ids out ct_number,
    p_error_code_det out ct_number,
    p_error_message_det out ct_varchar
  );

----------------------------------!---------------------------------------------
/****************************************************************************
  PROCEDURE ResetPhoneNumberReserve

  %author            Pavel Vasiliev
  %created           28.09.2011
  %version           1.0.0
****************************************************************************/
PROCEDURE ResetPhoneNumberReserve(
  p_user_login                   IN  VARCHAR2,
  p_reserve_number               IN  NUMBER,
  p_handle_tran                   IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error                   IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                   OUT NUMBER,
  p_error_message                 OUT VARCHAR2,
  p_result_list                  OUT SYS_REFCURSOR
);

/****************************************************************************
  PROCEDURE ResetPhoneNumberReserve

  %author            Pavel Vasiliev
  %created           28.09.2011
  %version           1.0.0
****************************************************************************/
PROCEDURE ResetPhoneNumberReserveInt(
  p_user_id                      IN  NUMBER,
  p_reserve_number               IN  NUMBER
);

/****************************************************************************
  PROCEDURE ResetPhoneNumberReserves

  %author            Pavel Vasiliev
  %created           06.02.2012
  %version           1.0.0
****************************************************************************/
PROCEDURE ResetPhoneNumberReserves(
  p_user_login                   IN  VARCHAR2,
  p_reserve_numbers              IN  common.t_number,
  p_error_code                   OUT NUMBER,
  p_error_message                 OUT VARCHAR2,
  p_result_list                  OUT SYS_REFCURSOR
);

/****************************************************************************
  PROCEDURE ReservePhoneResetPeriodReserve

  %author            Pavel Vasiliev
  %created           06.02.2012
  %version           1.0.0
****************************************************************************/
PROCEDURE ReservePhoneResetPeriodReserve(
  p_reserve_numbers              IN  util_pkg.cit_number,
  p_error_code                   OUT NUMBER,
  p_error_message                 OUT VARCHAR2,
  p_result_list                  OUT SYS_REFCURSOR
);
/****************************************************************************
  PROCEDURE SetPhoneStatusWithCheck

  %author            Pavel Vasiliev
  %created           10.11.2011
  %version           1.0.0
****************************************************************************/
procedure SetPhoneStatusWithCheck(
  p_msisdn_list              Common.t_international_format,
  p_start_date               date,
  p_phone_number_status_code varchar2,
  p_set_phone_number_status  varchar2,
  p_user_login               varchar2,
  p_error_code               out number,
  p_error_message             out varchar2,
  p_result                   out sys_refcursor
  );

-- -------------------------------------------------------------------------
PROCEDURE Insert_RIF_Phones(
  p_first_num          IN  VARCHAR2,
  p_last_num           IN  VARCHAR2,
  p_operator_code      IN  network_operator.network_operator_code%TYPE,
  p_pn_type_code       IN  phone_number_series.phone_number_type_code%TYPE,
  p_handle_tran        IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error        IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code         OUT NUMBER,
  p_error_message      OUT VARCHAR2);

-- -------------------------------------------------------------------------
END;

/
