CREATE package body API_SIM_CARD_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure import_sim_card_2
(
  p_sim_list util_pkg.cit_varchar_s,
  p_sn_list util_pkg.cit_varchar_s,
  p_pin_list util_pkg.cit_varchar_s,
  p_pin2_list util_pkg.cit_varchar_s,
  p_puk_list util_pkg.cit_varchar_s,
  p_puk2_list util_pkg.cit_varchar_s,
  p_ki_list util_pkg.cit_nvarchar_s,
  p_adm1_list util_pkg.cit_nvarchar_s,
  p_access_control_list util_pkg.cit_nvarchar_s,
  p_authent_type_list util_pkg.cit_varchar_s,
  p_main_imsi_index util_pkg.cit_number,
  p_addition_imsi util_pkg.cit_varchar_s,
  p_user_id_of_change number,
  p_error_code out number,
  p_error_message out varchar2,
  p_result_list out sys_refcursor
)
is
  v_sim_list ct_varchar_s;
  v_mark_err ct_number;
  v_err_count number;
  v_error_code ct_number;
  v_error_message ct_varchar;
  v_sim_list_err ct_varchar_s;
  v_error_code_err ct_number;
  v_error_message_err ct_varchar;
begin
  ------------------------------
  v_sim_list := util_pkg.cast_cit2ct_varchar_s(p_sim_list, FAlSE);
  ------------------------------
  api_sim_card_i_pkg.import_sim_card_i
  (
    p_sim_list => v_sim_list,
    p_sn_list => util_pkg.cast_cit2ct_varchar_s(p_sn_list, FAlSE),
    p_pin_list => util_pkg.cast_cit2ct_varchar_s(p_pin_list, FAlSE),
    p_pin2_list => util_pkg.cast_cit2ct_varchar_s(p_pin2_list, FAlSE),
    p_puk_list => util_pkg.cast_cit2ct_varchar_s(p_puk_list, FAlSE),
    p_puk2_list => util_pkg.cast_cit2ct_varchar_s(p_puk2_list, FAlSE),
    p_ki_list => util_pkg.cast_cit2ct_nvarchar_s(p_ki_list, FAlSE),
    p_adm1_list => util_pkg.cast_cit2ct_nvarchar_s(p_adm1_list, FAlSE),
    p_access_control_list => util_pkg.cast_cit2ct_nvarchar_s(p_access_control_list, FAlSE),
    p_authent_type_list => util_pkg.cast_cit2ct_varchar_s(p_authent_type_list, FAlSE),
    p_main_imsi_index => util_pkg.cast_cit2ct_number(p_main_imsi_index, TRUE),
    p_addition_imsi => util_pkg.cast_cit2ct_varchar_s(p_addition_imsi, TRUE),
    p_user_id => p_user_id_of_change,
    p_break_on_error => FALSE,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  v_mark_err := util_pkg.mark_val_ct_number(v_error_code, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
  v_err_count := util_pkg.get_count_ct_number(util_pkg.filter_val_ct_number_1val(v_mark_err, util_pkg.c_true, TRUE));
  if v_err_count = 0
  then
    ------------------------------
    commit;
    ------------------------------
  else
    ------------------------------
    rollback;
    ------------------------------
  end if;
  ------------------------------
  v_sim_list_err := util_pkg.get_marked_ct_varchar_s(v_sim_list, v_mark_err, TRUE);
  v_error_code_err := util_pkg.get_marked_ct_number(v_error_code, v_mark_err, TRUE);
  v_error_message_err := util_pkg.get_marked_ct_varchar(v_error_message, v_mark_err, TRUE);
  ------------------------------
  get_result_cursor01
  (
    p_imsi => v_sim_list_err,
    p_result => p_result_list,
    p_error_code => v_error_code_err,
    p_error_message => v_error_message_err
  );
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_result_cursor01
(
  p_imsi ct_varchar_s,
  p_result out sys_refcursor,
  p_error_code ct_number,
  p_error_message ct_varchar
)
is
begin
  ------------------------------
  open p_result for
  select /*+ use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
      q1.imsi, q2.error_code, q3.error_message
    from
      (select column_value imsi, rownum rn from table(p_imsi)) q1,
      (select column_value error_code, rownum rn from table(p_error_code)) q2,
      (select column_value error_message, rownum rn from table(p_error_message)) q3
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    order by q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
