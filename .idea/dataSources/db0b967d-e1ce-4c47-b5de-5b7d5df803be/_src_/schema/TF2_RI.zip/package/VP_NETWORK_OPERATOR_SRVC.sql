CREATE package vp_network_operator_srvc is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'NETWORK_OPERATOR_SRVC';

----------------------------------!---------------------------------------------
  function get1_i(p_no_id integer, p_svc_code varchar2, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return network_operator_srvc%rowtype;
  function get1(p_no_id integer, p_svc_code varchar2, p_date date) return network_operator_srvc%rowtype;
  function xlock_get1(p_no_id integer, p_svc_code varchar2, p_date date) return network_operator_srvc%rowtype;

----------------------------------!---------------------------------------------
  procedure xvalid_i(p_rec network_operator_srvc%rowtype);

----------------------------------!---------------------------------------------
  function find_i_id_code(p_rec network_operator_srvc%rowtype) return boolean;

  function find_i(p_rec network_operator_srvc%rowtype) return boolean;
  procedure xunique_i(p_rec network_operator_srvc%rowtype);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec network_operator_srvc%rowtype);
  procedure close_i(p_rec network_operator_srvc%rowtype);

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy network_operator_srvc%rowtype);
  procedure version_change(p_rec in out nocopy network_operator_srvc%rowtype);

  procedure version_close
  (
    p_no_id integer,
    p_svc_code varchar2,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------

end;
/
