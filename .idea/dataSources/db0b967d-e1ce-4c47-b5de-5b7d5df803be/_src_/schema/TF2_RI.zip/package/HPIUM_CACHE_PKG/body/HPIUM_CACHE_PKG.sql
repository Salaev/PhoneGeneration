CREATE package body HPIUM_CACHE_PKG is
------------------------------!------------------------------
cursor cr_bs_cache_hpium_insert(p_personal_account personal_account_history.personal_account%type)
is
  select
    sc.imsi,
    pn.international_format,
    naap.from_date,
    naap.to_date
  from sim_card sc
  join network_address_access_point naap
    on naap.access_point_id = sc.access_point_id
    and sysdate between naap.from_date and nvl(naap.to_date, sysdate)
  join phone_number pn
    on pn.network_address_id = naap.network_address_id
  where sc.personal_account = p_personal_account
;
------------------------------
cursor cr_bs_cache_hpium_update(p_personal_account personal_account_history.personal_account%type)
is
  select
    sc.imsi,
    naap.from_date
  from sim_card sc
  join network_address_access_point naap
    on naap.access_point_id = sc.access_point_id
    and naap.to_date is null
  where sc.personal_account = p_personal_account
;
------------------------------
cursor cr_msisdn_imsi_cache_hpium(p_access_point_id sim_card.access_point_id%type)
is
  select
    sc.imsi,
    pah.personal_account,
    pah.start_date,
    pah.end_date,
    h.host_code,
    h.host_type_code
  from sim_card sc
  join personal_account_history pah
    on pah.personal_account = sc.personal_account
    and sysdate between pah.start_date and nvl(pah.end_date, sysdate)
  join host h
    on h.host_id = pah.balance_storage
  where sc.access_point_id = p_access_point_id
;
------------------------------
cursor cr_pa_cache_hpium_phone(p_access_point access_point.access_point_id%type)
is
  select
    naap.from_date,
    pn.international_format
  from network_address_access_point naap
  join phone_number pn
    on pn.network_address_id = naap.network_address_id
  where naap.access_point_id = p_access_point
    and naap.to_date is null
;
------------------------------
cursor cr_pa_cache_hpium_bs(p_personal_account personal_account_history.personal_account%type)
is
  select
    pah.start_date,
    pah.end_date,
    h.host_code,
    h.host_type_code
  from personal_account_history pah
  join host h
    on h.host_id = pah.balance_storage
  where pah.end_date is null
    and pah.personal_account = p_personal_account
;
------------------------------!------------------------------
procedure bs_cache_hpium_ins
(
  v_old personal_account_history%rowtype,
  v_new personal_account_history%rowtype
)
as
  v_balance_storage_code host.host_code%type;
  v_balance_storage_type host.host_type_code%type;
begin
  ------------------------------
  util_loc_pkg.touch_boolean(v_old.personal_account is null);
  ------------------------------
  select h.host_code, h.host_type_code
  into v_balance_storage_code, v_balance_storage_type
  from host h
  where h.host_id = v_new.balance_storage;
  ------------------------------
  -- for all sim cards with given personal account
  for v_row in cr_bs_cache_hpium_insert(v_new.personal_account)
  loop
    queue_ri.set_bs_change_msg
    (
      p_imsi => v_row.imsi,
      p_msisdn => v_row.international_format,
      p_start_date_msisdn => v_row.from_date,
      p_end_date_msisdn => v_row.to_date,
      p_personal_account => v_new.personal_account,
      p_balance_storage_type => v_balance_storage_type,
      p_balance_storage_code => v_balance_storage_code,
      p_start_date_bs => v_new.start_date,
      p_end_date_bs => v_new.end_date,
      p_operation_type => 1
    );
  end loop;
  ------------------------------
end;
------------------------------!------------------------------
procedure bs_cache_hpium_upd
(
  v_old personal_account_history%rowtype,
  v_new personal_account_history%rowtype
)
as
begin
  ------------------------------
  util_loc_pkg.touch_boolean(v_old.personal_account is null);
  ------------------------------
  -- for all sim cards with given personal account
  for v_row in cr_bs_cache_hpium_update(v_new.personal_account)
  loop
    queue_ri.set_bs_change_msg
    (
      p_imsi => v_row.imsi,
      p_msisdn => null,
      p_start_date_msisdn => v_row.from_date,
      p_end_date_msisdn => null,
      p_personal_account => null,
      p_balance_storage_type => null,
      p_balance_storage_code => null,
      p_start_date_bs => v_new.start_date,
      p_end_date_bs => v_new.end_date,
      p_operation_type => 3
    );
  end loop;
  ------------------------------
end;
------------------------------!------------------------------
procedure msisdn_imsi_cache_hpium_ins
(
  v_old network_address_access_point%rowtype,
  v_new network_address_access_point%rowtype
)
as
  ------------------------------
  v_data cr_msisdn_imsi_cache_hpium%rowtype;
  v_msisdn phone_number.international_format%type;
  ------------------------------
begin
  ------------------------------
  util_loc_pkg.touch_boolean(v_old.user_id_of_change is null);
  ------------------------------
  open cr_msisdn_imsi_cache_hpium(v_new.access_point_id);
  fetch cr_msisdn_imsi_cache_hpium into v_data;
  ------------------------------
  if cr_msisdn_imsi_cache_hpium%found
  then
    ------------------------------
    select pn.international_format
    into v_msisdn
    from phone_number pn
    where pn.network_address_id = v_new.network_address_id
    ;
    ------------------------------
    queue_ri.set_bs_change_msg
    (
      p_imsi => v_data.imsi,
      p_msisdn => v_msisdn,
      p_start_date_msisdn => v_new.from_date,
      p_end_date_msisdn => v_new.to_date,
      p_personal_account => v_data.personal_account,
      p_balance_storage_type => v_data.host_type_code,
      p_balance_storage_code => v_data.host_code,
      p_start_date_bs => v_data.start_date,
      p_end_date_bs => v_data.end_date,
      p_operation_type => 1
    );
    ------------------------------
  end if;
  ------------------------------
  close cr_msisdn_imsi_cache_hpium;
  ------------------------------
end;
------------------------------!------------------------------
procedure msisdn_imsi_cache_hpium_upd
(
  v_old network_address_access_point%rowtype,
  v_new network_address_access_point%rowtype
)
as
  ------------------------------
  v_data cr_msisdn_imsi_cache_hpium%rowtype;
  v_msisdn phone_number.international_format%type;
  ------------------------------
begin
  ------------------------------
  util_loc_pkg.touch_boolean(v_old.user_id_of_change is null);
  ------------------------------
  open cr_msisdn_imsi_cache_hpium(v_new.access_point_id);
  fetch cr_msisdn_imsi_cache_hpium into v_data;
  ------------------------------
  if cr_msisdn_imsi_cache_hpium%found
  then
    ------------------------------
    select pn.international_format
    into v_msisdn
    from phone_number pn
    where pn.network_address_id = v_new.network_address_id
    ;
    ------------------------------
    queue_ri.set_bs_change_msg
    (
      p_imsi => v_data.imsi,
      p_msisdn => v_msisdn,
      p_start_date_msisdn => v_new.from_date,
      p_end_date_msisdn => v_new.to_date,
      p_personal_account => null,
      p_balance_storage_type => null,
      p_balance_storage_code => null,
      p_start_date_bs => v_data.start_date,
      p_end_date_bs => null,
      p_operation_type => 2
    );
    ------------------------------
  end if;
  ------------------------------
  close cr_msisdn_imsi_cache_hpium;
  ------------------------------
end;
------------------------------!------------------------------
procedure pa_cache_hpium_upd
(
  v_old sim_card%rowtype,
  v_new sim_card%rowtype
)
as
  ------------------------------
  v_bs_row cr_pa_cache_hpium_bs%rowtype;
  ------------------------------
begin
  ------------------------------
  -- on personal_account change
  if v_old.personal_account <> v_new.personal_account or
    (v_old.personal_account is null and v_new.personal_account is not null) or
    (v_old.personal_account is not null and v_new.personal_account is null)
  then
    ------------------------------
    open cr_pa_cache_hpium_bs(v_new.personal_account);
    fetch cr_pa_cache_hpium_bs into v_bs_row;
    ------------------------------
    if cr_pa_cache_hpium_bs%found
    then
      ------------------------------
      -- for all phone numbers linked to this sim card
      for v_row in cr_pa_cache_hpium_phone(v_new.access_point_id)
      loop
        queue_ri.set_bs_change_msg
        (
          p_imsi => v_new.imsi,
          p_msisdn => v_row.international_format,
          p_start_date_msisdn => v_row.from_date,
          p_end_date_msisdn => null,
          p_personal_account => v_new.personal_account,
          p_balance_storage_type => v_bs_row.host_type_code,
          p_balance_storage_code => v_bs_row.host_code,
          p_start_date_bs => v_bs_row.start_date,
          p_end_date_bs => v_bs_row.end_date,
          p_operation_type => 1
        );
      end loop;
      ------------------------------
    end if;
    ------------------------------
    close cr_pa_cache_hpium_bs;
    ------------------------------
  end if;
  ------------------------------
end;
------------------------------!------------------------------
end;
/
