CREATE PACKAGE BODY RSIG_PHONE_NUMBER IS
  -------------------------------------------------------------------------------
  --      procedure Is_Phone_Salab_Cat_Deleted
  -------------------------------------------------------------------------------

  PROCEDURE Is_Phone_Salab_Cat_Deleted(p_salability_category_code IN VARCHAR2) IS
    v_pom NUMBER;
  BEGIN
    SELECT 1
      INTO v_pom
      FROM PHONE_SALABILITY_CATEGORY
     WHERE TRIM(PHONE_SALABILITY_CATEGORY_CODE) = TRIM(p_salability_category_code)
       AND DELETED IS NOT NULL;
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      NULL;
  END Is_Phone_Salab_Cat_Deleted;

  -------------------------------------------------------------------------------
  --      procedure Is_Interval_Overlap
  -------------------------------------------------------------------------------
  PROCEDURE Is_Interval_Overlap
  (
    p_network_address_id    IN PHONE_NUMBER.NETWORK_ADDRESS_ID%TYPE,
    p_salability_categ_code IN PHONE_NUMBER_SALABILITY_CATEG.SALABILITY_CATEGORY_CODE%TYPE,
    p_start_date            IN PHONE_NUMBER_SALABILITY_CATEG.START_DATE%TYPE
  ) IS

    v_start_date            DATE;
    v_salability_categ_code PHONE_NUMBER_SALABILITY_CATEG.SALABILITY_CATEGORY_CODE%TYPE;
    v_st_date               DATE;
  BEGIN

    -- NOT NULL test of input parameters
    IF p_salability_categ_code IS NULL
       OR p_network_address_id IS NULL THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
    END IF;
    v_st_date := nvl(p_start_date, SYSDATE);
    -- test start date
    IF v_st_date < RSIG_UTILS.c_MIN_DATE THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
    END IF;

    -- get info about last period
    SELECT START_DATE,
           SALABILITY_CATEGORY_CODE
      INTO v_start_date,
           v_salability_categ_code
      FROM (SELECT START_DATE,
                   SALABILITY_CATEGORY_CODE
              FROM PHONE_NUMBER_SALABILITY_CATEG
             WHERE NETWORK_ADDRESS_ID = p_network_address_id
             ORDER BY START_DATE DESC)
     WHERE rownum = 1;

    -- if some period is overlapped with new one
    IF v_st_date <= v_start_date THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DATE_OVERLAP, '');
    END IF;

    -- previous period can't have the same salability_category_code
    IF v_salability_categ_code = p_salability_categ_code THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_SAME_SALABILITY_CODE, '');
    END IF;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      NULL;
  END Is_Interval_Overlap;

  -------------------------------------------------------------------------------
  --      procedure Change_Salability_Category
  -------------------------------------------------------------------------------

  PROCEDURE Change_Salability_Category
  (
    handle_tran                IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                 OUT NUMBER,
    p_network_address_id       IN NUMBER, -- network ID of the phone number that we change the salability of
    p_salability_category_code IN VARCHAR2, -- salability we want to set the phone number to
    p_start_date               IN DATE, -- date since the salability change is valid
    p_user_id_of_change        IN NUMBER -- number of the user who performs this procedure
  ) IS

    v_date            DATE; -- variable containing the date when salability is being changed
    v_start_date      DATE;
    v_event_source    VARCHAR2(60) := 'RSIG_PHONE_NUMBER.Change_Salability_Category';
  BEGIN
    RSIG_UTILS.Debug_Rsi('sStart',
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);

    IF (handle_tran NOT IN
       (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
       (handle_tran IS NULL)) THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
    END IF;

    Is_Phone_Salab_Cat_Deleted(p_salability_category_code);
    v_start_date := nvl(p_start_date, SYSDATE);
    -- p_network_address_id, p_salability_category_code, p_start_date are checked in Is_Interval_Overlap(..)
    IF p_user_id_of_change IS NULL THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
    END IF;

    IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
      SAVEPOINT change_salability_category_a;
    END IF;

    -- Checking of intervals overlapping. If some interval is overlapped by this one, exception will be generated.
    Is_Interval_Overlap(p_network_address_id, p_salability_category_code, v_start_date);

    SELECT SYSDATE INTO v_date FROM DUAL;

    -- close previous interval
    UPDATE PHONE_NUMBER_SALABILITY_CATEG
       SET END_DATE          = v_start_date - RSIG_UTILS.c_INTERVAL_DIFFERENCE,
           DATE_OF_CHANGE    = v_date,
           USER_ID_OF_CHANGE = p_user_id_of_change
     WHERE NETWORK_ADDRESS_ID = p_network_address_id
       AND END_DATE IS NULL;

    -- making new interval
    INSERT INTO PHONE_NUMBER_SALABILITY_CATEG
      (SALABILITY_CATEGORY_CODE,
       NETWORK_ADDRESS_ID,
       START_DATE,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE)
    VALUES
      (p_salability_category_code,
       p_network_address_id,
       v_start_date,
       v_date,
       p_user_id_of_change);

    IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
      COMMIT;
    END IF;

    error_code := util_pkg.c_ora_ok;

    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        error_code := util_pkg.get_err_code;
        RSIG_UTILS.Debug_Rsi(error_code,
                             RSIG_UTILS.c_DEBUG_LEVEL_0,
                             RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                             v_event_source);
        CASE handle_tran
          WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
            ROLLBACK TO SAVEPOINT change_salability_category_a;
          WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
            ROLLBACK;
          ELSE
            NULL;
        END CASE;
      END;
  END Change_Salability_Category;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Phone_Status_History
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Phone_Status_History(
  p_network_address_id     IN  PHONE_NUMBER.NETWORK_ADDRESS_ID%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := '';
  v_procedure_name        VARCHAR2(30) := 'Get_Phone_Status_History';
  v_event_source          VARCHAR2(60);
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF p_network_address_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;
---------------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
  SELECT nas.NET_ADDRESS_STATUS_NAME,
         nash.START_DATE,
         nash.END_DATE,
         nash.na_trans_reason_code,
         u.user_name
  FROM PHONE_NUMBER pn
  JOIN NETWORK_ADDRESS_STATUS_HISTORY nash ON pn.NETWORK_ADDRESS_ID = nash.NETWORK_ADDRESS_ID
  JOIN NETWORK_ADDRESS_STATUS nas ON nas.NET_ADDRESS_STATUS_CODE = TRIM(nash.NET_ADDRESS_STATUS_CODE)
  JOIN USERS u ON u.user_id = nash.user_id_of_change
  WHERE pn.NETWORK_ADDRESS_ID = p_network_address_id
  ORDER BY nash.START_DATE DESC;
---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;

EXCEPTION
WHEN OTHERS THEN
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;

  OPEN p_result_list FOR SELECT p_error_code FROM dual;

  IF upper(p_raise_error)=rsig_utils.c_YES THEN
    RAISE;
  END IF;
END Get_Phone_Status_History;

  -------------------------------------------------------------------------------
  --      procedure Get_Phone_Operator_History
  -------------------------------------------------------------------------------

  PROCEDURE Get_Phone_Operator_History
  (
    error_code                   OUT NUMBER,
    p_network_address_id         IN PHONE_NUMBER.NETWORK_ADDRESS_ID%TYPE, -- id of the phone number we are getting the status history for
    p_cur_phone_operator_history IN OUT RSIG_UTILS.REF_CURSOR -- cursor that given phone operator history (network_address_id, start_date, end_date) will be stored in
  ) IS
    v_event_source VARCHAR2(60) := 'RSIG_PHONE_NUMBER.Get_Phone_Operator_History';
  BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);
    IF p_network_address_id IS NULL THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
    END IF;
    OPEN p_cur_phone_operator_history FOR
      SELECT *
        FROM (SELECT n.NETWORK_OPERATOR_NAME,
                     po.START_DATE,
                     po.END_DATE
                FROM PHONE_OPERATOR po
                JOIN NETWORK_OPERATOR n ON n.NETWORK_OPERATOR_ID = po.NETWORK_OPERATOR_ID
               WHERE po.NETWORK_ADDRESS_ID = p_network_address_id
              UNION
              SELECT n.NETWORK_OPERATOR_NAME,
                     po.START_DATE,
                     po.END_DATE
                FROM PHONE_SERIES_OPERATOR po
                JOIN NETWORK_OPERATOR n ON po.NETWORK_OPERATOR_ID = n.NETWORK_OPERATOR_ID
                JOIN PHONE_NUMBER_SERIES pns ON po.PHONE_NUMBER_SERIES_ID = pns.PHONE_NUMBER_SERIES_ID
                JOIN PHONE_NUMBER pn ON pns.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
               WHERE pn.NETWORK_ADDRESS_ID = p_network_address_id)
       ORDER BY start_date DESC;
    error_code := util_pkg.c_ora_ok;

    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        error_code := util_pkg.get_err_code;
        RSIG_UTILS.Debug_Rsi(error_code,
                             RSIG_UTILS.c_DEBUG_LEVEL_0,
                             RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                             v_event_source);
      END;
  END Get_Phone_Operator_History;

----------------------------------------------------------------------------------------------------------
--  procedure Get_Free_Phones_By_SIM_List
----------------------------------------------------------------------------------------------------------
PROCEDURE Get_Free_Phones_By_SIM_List(
  p_SN_list                  IN  t_SN, -- list of sim cards
  p_salability_category      IN  phone_number.salability_category_code%TYPE, -- code of the required salability category
  p_phone_type               IN  PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE, -- code of the required phone type
  p_reserve                  IN  CHAR,
  p_join                     IN  CHAR,
  p_user_login               IN  VARCHAR2,
  handle_tran                IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                 OUT NUMBER,
  error_message              OUT VARCHAR2,
  result_list                OUT sys_refcursor
)
IS
  v_event_source             VARCHAR2(60) := 'RSIG_PHONE_NUMBER.Get_Free_Phones_By_SIM_List';
  v_user_id                  NUMBER;

  v_network_address_id       NETWORK_ADDRESS_STATUS_HISTORY.NETWORK_ADDRESS_ID%TYPE;
  v_phone_number             phone_number.international_format%TYPE;
  v_cur_host_id              HOST.HOST_ID%TYPE;
  v_cur_net_op_id            network_operator.network_operator_id%TYPE;

  v_operator_start_date      PHONE_SERIES_OPERATOR.START_DATE%TYPE;
  v_operator_end_date        PHONE_SERIES_OPERATOR.END_DATE%TYPE;

  v_error_code               NUMBER;
  v_can_use_phone_number     NUMBER;
  v_host_id                  host.host_id%TYPE;
  v_network_operator_id      network_operator.network_operator_id%TYPE;
  v_sysdate                  DATE:=SYSDATE;
  s                          NUMBER;
  v_access_point_id          access_point.access_point_id%TYPE;

  -- set of unique hosts for SIM cards
  CURSOR cur_data IS
    SELECT DISTINCT ss.HOST_ID,ss.network_operator_id
      FROM tt_batch_na_ap t
      JOIN SIM_CARD sc ON sc.ACCESS_POINT_ID = t.ACCESS_POINT_ID
      JOIN SIM_SERIES ss ON ss.SIM_SERIES_ID = sc.SIM_SERIES_ID
     WHERE t.result=util_pkg.c_ora_ok;

  -- set of free phone numbers
  CURSOR v_get_free_phone(p_salability_category VARCHAR2,
                          p_phone_type VARCHAR2,
                          v_cur_host_id NUMBER,
                          c_nework_operator_id NUMBER) IS
  SELECT network_address_id,
         international_format AS PHONE_NUMBER,
         START_DATE AS OPERATOR_START_DATE,
         END_DATE AS OPERATOR_END_DATE
  FROM(SELECT /*+  INDEX(PN I_PHONENUM_PHONE_NUM_SERIES_ID) index(naap I_NETADDRACCPO_NET_ADDRESS_ID) */
              pn.network_address_id,
              pn.international_format,
              k.start_date,
              k.end_date,
              naap.network_address_id naap_id
       FROM (SELECT pns.phone_number_series_id,
                    pso.START_DATE,
                    pso.end_date
             FROM phone_number_series pns
             JOIN phone_series_operator pso ON pso.phone_number_series_id = pns.phone_number_series_id
                  AND (v_sysdate BETWEEN pso.start_date AND NVL(pso.end_date, v_sysdate))
             WHERE pns.host_id = v_cur_host_id
               AND TRIM(pns.phone_number_type_code) = TRIM(p_phone_type)
               AND pso.network_operator_id = c_nework_operator_id) k
       JOIN phone_number pn ON pn.phone_number_series_id = k.phone_number_series_id
       LEFT JOIN network_address_access_point naap ON naap.network_address_id = pn.network_address_id
            AND v_sysdate BETWEEN naap.from_date AND NVL(naap.TO_DATE,v_sysdate)
       WHERE pn.salability_category_code = p_salability_category
         AND (pn.deleted IS NULL OR pn.deleted>v_sysdate)
         AND pn.net_address_status_code = rsig_utils.c_free_phone_number_code
         AND NOT EXISTS(SELECT 1
                        FROM phone_link pl
                        WHERE pl.main_msisdn=pn.international_format))
  where naap_id is NULL;

  CURSOR cur_AP IS
    SELECT t.NETWORK_ADDRESS_ID,
           t.international_format
      FROM tt_batch_na_ap t
     WHERE t.access_point_id > 0
       AND t.result=util_pkg.c_ora_ok
       AND EXISTS (SELECT 1
                   FROM SIM_CARD   sc,
                        SIM_SERIES ss
                   WHERE sc.ACCESS_POINT_ID = t.ACCESS_POINT_ID
                     AND ss.SIM_SERIES_ID = sc.SIM_SERIES_ID
                     AND ss.HOST_ID = v_cur_host_id
                     AND ss.network_operator_id = v_cur_net_op_id)
       FOR UPDATE OF t.network_address_id, t.international_format;

BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  error_code := util_pkg.c_ora_ok;

  -- check existence of user
  v_user_id := Rsig_users.Get_user_id_by_login(p_user_login);

  -- check input parameters
  IF (p_SN_list.COUNT = 0) OR (p_SN_list.COUNT = 1 AND p_SN_list(1) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT get_free_phones_by_sim_list_a;
  END IF;

  DELETE FROM tt_batch_na_ap;

  IF p_SN_list.COUNT=1 THEN -- just for one sim card

    s:=p_SN_list.FIRST;

    BEGIN
      SELECT ss.host_id,ss.network_operator_id,sc.access_point_id
      INTO v_host_id,v_network_operator_id,v_access_point_id
      FROM sim_card sc
      JOIN sim_series ss ON ss.sim_series_id=sc.sim_series_id
      WHERE sc.sn=p_SN_list(s);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_SIM_CARD_NOT_EXISTS, '');
    END;

    INSERT INTO tt_batch_na_ap(access_point_id,sn,network_address_id,international_format,RESULT)
    select v_access_point_id,p_SN_list(s),network_address_id,international_format,util_pkg.c_ora_ok
    FROM(SELECT /*+  INDEX(PN I_PHONENUM_PHONE_NUM_SERIES_ID) index(naap I_NETADDRACCPO_NET_ADDRESS_ID)*/
                pn.network_address_id,
                pn.international_format,
                naap.network_address_id naap_id
         FROM (SELECT pns.phone_number_series_id
               FROM phone_number_series pns
               JOIN phone_series_operator pso ON pso.phone_number_series_id = pns.phone_number_series_id
                    AND (v_sysdate BETWEEN pso.start_date AND NVL(pso.end_date, v_sysdate))
               WHERE pns.host_id = v_host_id
                 AND TRIM(pns.phone_number_type_code) = TRIM(p_phone_type)
                 AND pso.network_operator_id = v_network_operator_id) k
         JOIN phone_number pn ON pn.phone_number_series_id = k.phone_number_series_id
         LEFT JOIN network_address_access_point naap ON naap.network_address_id = pn.network_address_id
              AND v_sysdate BETWEEN naap.from_date AND NVL(naap.TO_DATE,v_sysdate)
         WHERE pn.salability_category_code = p_salability_category
           AND pn.net_address_status_code = rsig_utils.c_free_phone_number_code
           AND NOT EXISTS(SELECT 1
                        FROM phone_link pl
                        WHERE pl.main_msisdn=pn.international_format))
    where naap_id is null
      and rownum <= 1;

  ELSE -- for more then one sim card

    -- insert list of sim cards into the temporary table ----------------
    FORALL i IN nvl(p_SN_list.FIRST, 1) .. nvl(p_SN_list.LAST, 0)
      INSERT INTO tt_batch_na_ap(sn,result)
      VALUES(p_SN_list(i),util_pkg.c_ora_ok);


    RSIG_UTILS.Fill_AP_ID_From_SN;


    FOR v_cur_host IN cur_data
    LOOP
      -- getting of current host

      v_cur_host_id := v_cur_host.host_id;
      v_cur_net_op_id := v_cur_host.network_operator_id;

      v_sysdate:=SYSDATE;

      OPEN v_get_free_phone(p_salability_category,
                            p_phone_type,
                            v_cur_host_id,
                            v_cur_net_op_id); -- getting free phone numbers for current host

      FOR v_cur_AP IN cur_AP
      LOOP
        -- getting free phone number for each access point
        BEGIN

          v_can_use_phone_number := 0;

          WHILE v_can_use_phone_number <> 1
          LOOP

            FETCH v_get_free_phone
            INTO v_network_address_id, v_phone_number,
                 v_operator_start_date, v_operator_end_date;

            IF v_get_free_phone%NOTFOUND THEN
              RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NOT_FREE_PHONES, '');
            END IF;

            -- in previous versions this check was used in SQL of getting free phone numbers,
            -- but it slowed down execution of this SQL
            IF (v_sysdate BETWEEN v_operator_start_date AND nvl(v_operator_end_date, v_sysdate)) THEN
              v_can_use_phone_number := 1;
            END IF;

          END LOOP;

          UPDATE tt_batch_na_ap t
             SET t.NETWORK_ADDRESS_ID=v_network_address_id,
                 t.international_format=v_phone_number
           WHERE CURRENT OF cur_AP;

        EXCEPTION
          WHEN OTHERS THEN
            error_code := util_pkg.get_err_code;
            error_message := util_pkg.get_err_msg;
            UPDATE tt_batch_na_ap t
               SET t.RESULT = RSIG_UTILS.c_NOT_FREE_PHONES -- error_code
             WHERE EXISTS (SELECT 1
                           FROM SIM_CARD   sc,
                                SIM_SERIES ss
                           WHERE sc.ACCESS_POINT_ID = t.ACCESS_POINT_ID
                             AND ss.SIM_SERIES_ID = sc.SIM_SERIES_ID
                             AND ss.HOST_ID = v_cur_host_id)
               AND t.NETWORK_ADDRESS_ID IS NULL;

            EXIT;
        END;
      END LOOP;

      CLOSE v_get_free_phone;

    END LOOP;
  END IF;

  -- reserving of free phone numbers and/or joining them with SIM cards
  IF p_reserve = 'Y'
     OR p_join = 'Y' THEN

    FOR v_cur_AP IN (SELECT tbnaap.NETWORK_ADDRESS_ID,
                            tbnaap.ACCESS_POINT_ID
                       FROM tt_batch_na_ap tbnaap
                      WHERE tbnaap.NETWORK_ADDRESS_ID IS NOT NULL)
    LOOP
      BEGIN

        SAVEPOINT reserve_join_a;

        IF p_reserve = 'Y' THEN
          rsig_net_addr_status_history.insert_interval(RSIG_UTILS.c_HANDLE_TRAN_N,
                                                       v_error_code,
                                                       rsig_utils.c_RESERVE_PHONE_NUMBER_CODE,
                                                       v_cur_AP.NETWORK_ADDRESS_ID,
                                                       SYSDATE,
                                                       v_user_id);

          IF v_error_code <> util_pkg.c_ora_ok THEN
            RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INSERT_INTERVAL_ERROR, '');
          END IF;
        END IF;

        IF p_join = 'Y' THEN

          rsig_net_addr_acc_point.insert_interval(RSIG_UTILS.c_HANDLE_TRAN_N,
                                                  v_error_code,
                                                  v_cur_AP.ACCESS_POINT_ID,
                                                  v_cur_AP.NETWORK_ADDRESS_ID,
                                                  rsig_utils.C_MAIN_LINK_TYPE,
                                                  SYSDATE,
                                                  NULL,
                                                  v_user_id);

          IF v_error_code <> util_pkg.c_ora_ok THEN
            RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INSERT_INTERVAL_ERROR, '');
          END IF;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          error_code := util_pkg.get_err_code;
          ROLLBACK TO SAVEPOINT reserve_join_a;
          UPDATE tt_batch_na_ap
             SET RESULT = error_code
           WHERE NETWORK_ADDRESS_ID = v_cur_AP.NETWORK_ADDRESS_ID;
      END;
    END LOOP;

  END IF;

  error_code := util_pkg.c_ora_ok; -- succesfully completed

  OPEN Result_list FOR
    SELECT tbnaap.sn,
           tbnaap.network_address_id,
           tbnaap.international_format,
           tbnaap.RESULT
      FROM tt_batch_na_ap tbnaap;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    error_code := util_pkg.get_err_code;
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN Result_list FOR
      SELECT error_code FROM dual;
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT get_free_phones_by_sim_list_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
END Get_Free_Phones_By_SIM_List;

  -------------------------------------------------------------------------------
  --      procedure Get_Network_Operator_By_Phone
  -------------------------------------------------------------------------------

  PROCEDURE Get_Network_Operator_By_Phone
  (
    error_code         OUT NUMBER,
    p_phone_number     IN VARCHAR2, -- phone number in INTERNATIONAL FORMAT
    p_validity_date    IN DATE,
    p_uprs_member_code OUT NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE
  ) IS
    v_event_source VARCHAR2(60) := 'RSIG_PHONE_NUMBER.Get_Network_Operator_By_Phone';

    v_count         NUMBER;
    v_validity_date DATE;
  BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);
    v_validity_date := nvl(p_validity_date, SYSDATE);
    -- check if given phone number have reference in phone oprator table at given date
    SELECT COUNT(*)
      INTO v_count
      FROM phone_number pn
      JOIN PHONE_OPERATOR po ON pn.NETWORK_ADDRESS_ID = po.NETWORK_ADDRESS_ID
     WHERE v_validity_date BETWEEN po.START_DATE AND nvl(po.END_DATE, v_validity_date)
       AND (pn.deleted IS NULL OR pn.deleted>SYSDATE)
       AND pn.international_format = p_phone_number;

    IF v_count <> 0 THEN
      -- reference exist - phone number was assigned different operator than phone series owens
      SELECT n.UPRS_MEMBER_CODE
        INTO p_uprs_member_code
        FROM phone_number pn
        JOIN PHONE_OPERATOR po ON pn.NETWORK_ADDRESS_ID = po.NETWORK_ADDRESS_ID
        JOIN NETWORK_OPERATOR n ON po.NETWORK_OPERATOR_ID = n.NETWORK_OPERATOR_ID
       WHERE v_validity_date BETWEEN po.START_DATE AND nvl(po.END_DATE, v_validity_date)
         AND (pn.deleted IS NULL OR pn.deleted>SYSDATE)
         AND pn.international_format = p_phone_number;
    ELSE
      BEGIN
        SELECT n.UPRS_MEMBER_CODE
          INTO p_uprs_member_code
          FROM phone_number pn
          JOIN PHONE_SERIES_OPERATOR pso ON pn.PHONE_NUMBER_SERIES_ID = pso.PHONE_NUMBER_SERIES_ID
          JOIN NETWORK_OPERATOR n ON pso.NETWORK_OPERATOR_ID = n.NETWORK_OPERATOR_ID
         WHERE v_validity_date BETWEEN pso.START_DATE AND nvl(pso.END_DATE, v_validity_date)
           AND (pn.deleted IS NULL OR pn.deleted>SYSDATE)
           AND pn.international_format = p_phone_number;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          raise_application_error(rsig_utils.c_ORA_RECORD_NOT_FOUND, '');
      END;
    END IF;

    error_code := util_pkg.c_ora_ok;

    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      raise_application_error(rsig_utils.c_ORA_NO_DATA_FOUND, '');
    WHEN OTHERS THEN
      BEGIN
        error_code := util_pkg.get_err_code;
        RSIG_UTILS.Debug_Rsi(error_code,
                             RSIG_UTILS.c_DEBUG_LEVEL_0,
                             RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                             v_event_source);
      END;
  END Get_Network_Operator_By_Phone;

  -------------------------------------------------------------------------------
  --      procedure Get_Access_Point_Hist_By_Phone
  -------------------------------------------------------------------------------
  PROCEDURE Get_Access_Point_Hist_By_Phone
  (
    error_code                 OUT NUMBER,
    p_network_address_id       IN PHONE_NUMBER.NETWORK_ADDRESS_ID%TYPE,
    p_cur_phone_status_history IN OUT RSIG_UTILS.REF_CURSOR
  ) IS
    v_event_source VARCHAR2(60) := 'RSIG_PHONE_NUMBER.Get_Access_Point_Hist_By_Phone';
  BEGIN
    IF p_network_address_id IS NULL THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
    END IF;
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);

    OPEN p_cur_phone_status_history FOR
      SELECT *
        FROM (SELECT RSIG_UTILS.c_SIMCARD_TYPE AS RECORD_TYPE,
                     to_char(sc.SN) AS ID,
                     naap.FROM_DATE,
                     naap.TO_DATE,
                     sc.imsi,
                     u.user_name u
                FROM phone_number pn
                JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON pn.NETWORK_ADDRESS_ID = naap.NETWORK_ADDRESS_ID
                JOIN SIM_CARD sc ON naap.ACCESS_POINT_ID = sc.ACCESS_POINT_ID
                JOIN users u ON u.user_id = naap.user_id_of_change
               WHERE pn.NETWORK_ADDRESS_ID = p_network_address_id
              UNION
              SELECT RSIG_UTILS.c_PORT_TYPE AS RECORD_TYPE,
                     ep.exchange_port_number,
                     naap.FROM_DATE,
                     naap.TO_DATE,
                     '',
                     u.user_name u
                FROM phone_number pn
                JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON pn.NETWORK_ADDRESS_ID = naap.NETWORK_ADDRESS_ID
                JOIN exchange_port ep ON ep.access_point_id = naap.access_point_id
                JOIN users u ON u.user_id = naap.user_id_of_change
               WHERE pn.NETWORK_ADDRESS_ID = p_network_address_id)
       ORDER BY FROM_DATE;

    error_code := util_pkg.c_ora_ok;

    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        error_code := util_pkg.get_err_code;
        RSIG_UTILS.Debug_Rsi(error_code,
                             RSIG_UTILS.c_DEBUG_LEVEL_0,
                             RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                             v_event_source);
      END;
  END Get_Access_Point_Hist_By_Phone;

  -------------------------------------------------------------------------------
  --      procedure Get_Phone_Salability_History
  -------------------------------------------------------------------------------

PROCEDURE Get_Phone_Salability_History
(
  error_code              OUT NUMBER,
  p_network_address_id    IN PHONE_NUMBER.NETWORK_ADDRESS_ID%TYPE, -- id of the phone number we are getting the status history for
  p_cur_phone_sal_history IN OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PHONE_NUMBER.Get_Phone_Salability_History';
BEGIN
  IF p_network_address_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_phone_sal_history FOR
    SELECT psc.PHONE_SALABILITY_CATEGORY_NAME SALABILITY_CATEGORY_NAME,
           pnsc.START_DATE,
           pnsc.END_DATE,
           pnsc.DATE_OF_CHANGE,
           pnsc.USER_ID_OF_CHANGE,
           uu.USER_NAME
      FROM PHONE_NUMBER pn
      JOIN PHONE_NUMBER_SALABILITY_CATEG pnsc ON pnsc.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
      JOIN PHONE_SALABILITY_CATEGORY psc ON TRIM(psc.PHONE_SALABILITY_CATEGORY_CODE) = TRIM(pnsc.SALABILITY_CATEGORY_CODE)
      JOIN USERS UU ON UU.USER_ID = pnsc.USER_ID_OF_CHANGE
     WHERE pn.NETWORK_ADDRESS_ID = p_network_address_id
     ORDER BY pnsc.START_DATE DESC;

  error_code := util_pkg.c_ora_ok;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := util_pkg.get_err_code;
      RSIG_UTILS.Debug_Rsi(error_code,
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_Phone_Salability_History;

----------------------------------------------------------------------------
--  Get_phone_numbers_info
----------------------------------------------------------------------------

procedure Get_phone_numbers_info
(
  p_Validity_Date     IN DATE,
  p_Phone_Number_List IN t_phone_number_col,
  p_raise_error       IN CHAR,
  error_code          OUT NUMBER,
  error_message       OUT VARCHAR2,
  result_list         OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PHONE_NUMBER.Get_phone_numbers_info';
  i               NUMBER;
  j               NUMBER;
  obj             t_v2_60_obj := t_v2_60_obj(NULL);
  obj_col         t_v2_60_obj_tab := t_v2_60_obj_tab();
  v_Validity_Date DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF (p_Phone_Number_List.COUNT = 0) OR (p_Phone_Number_List.COUNT = 1 AND p_Phone_Number_List(1) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- procedure body here
  j               := 1;
  v_Validity_Date := nvl(p_Validity_Date, SYSDATE);
  FOR i IN nvl(p_Phone_Number_List.FIRST, 1) .. nvl(p_Phone_Number_List.LAST, 0)
  LOOP
    -- for all members of input associative array
    obj := t_v2_60_obj(p_Phone_Number_List(i)); -- ccreate object
    obj_col.EXTEND; -- grow
    obj_col(j) := obj; -- insert into collection
    j := j + 1;
  END LOOP;

  IF p_Validity_Date IS NULL THEN
    OPEN result_list FOR
    SELECT k.PHONE_NUMBER,
           k.NETWORK_OPERATOR_ID,
           k.PHONE_NUMBER_STATUS,
           k.ERROR_CODE,
           k.phone_number_type_code,
           TRIM(k.salability_category_code) as salability_category_code,
           n.network_operator_type
    FROM(
      SELECT /*+ FIRST_ROWS*/
             t_obj.v2_60 PHONE_NUMBER,
             nvl(po.NETWORK_OPERATOR_ID, pso.NETWORK_OPERATOR_ID) NETWORK_OPERATOR_ID,
             pn.NET_ADDRESS_STATUS_CODE PHONE_NUMBER_STATUS,
             decode(nvl(pn.NETWORK_ADDRESS_ID, -1), -1, RSIG_UTILS.c_ROW_NOT_FOUND, util_pkg.c_ora_ok) ERROR_CODE,
             pns.phone_number_type_code,
             pn.salability_category_code
        FROM TABLE(CAST(obj_col AS t_v2_60_obj_tab)) t_obj
        LEFT JOIN PHONE_NUMBER pn ON pn.INTERNATIONAL_FORMAT = t_obj.v2_60
             AND (pn.deleted IS NULL OR pn.deleted>SYSDATE)
        LEFT JOIN PHONE_NUMBER_SERIES pns ON (pns.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND (pns.deleted > v_Validity_Date OR pns.deleted IS NULL))
        LEFT JOIN PHONE_OPERATOR po ON po.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN po.start_date AND nvl(po.end_date, v_Validity_Date)
        LEFT JOIN PHONE_SERIES_OPERATOR pso ON pso.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND v_Validity_Date BETWEEN pso.START_DATE AND nvl(pso.END_DATE, v_Validity_Date)) k
    LEFT JOIN network_operator n ON n.network_operator_id=k.NETWORK_OPERATOR_ID;
  ELSE
    OPEN result_list FOR
    SELECT k.PHONE_NUMBER,
           k.NETWORK_OPERATOR_ID,
           k.PHONE_NUMBER_STATUS,
           k.ERROR_CODE,
           k.phone_number_type_code,
           TRIM(k.salability_category_code) as salability_category_code,
           n.network_operator_type
    FROM(
      SELECT /*+ index(nash I_NETADSTAHI_NETWORK_ADDRES_ID) FIRST_ROWS*/
             t_obj.v2_60 PHONE_NUMBER,
             nvl(po.NETWORK_OPERATOR_ID, pso.NETWORK_OPERATOR_ID) NETWORK_OPERATOR_ID,
             nash.NET_ADDRESS_STATUS_CODE PHONE_NUMBER_STATUS,
             decode(nvl(pn.NETWORK_ADDRESS_ID, -1), -1, RSIG_UTILS.c_ROW_NOT_FOUND, util_pkg.c_ora_ok) ERROR_CODE,
             pns.phone_number_type_code,
             pnsc.salability_category_code
        FROM TABLE(CAST(obj_col AS t_v2_60_obj_tab)) t_obj
        LEFT JOIN PHONE_NUMBER pn ON pn.INTERNATIONAL_FORMAT = t_obj.v2_60
             AND (pn.deleted IS NULL OR pn.deleted>SYSDATE)
        LEFT JOIN NETWORK_ADDRESS_STATUS_HISTORY nash ON (nash.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID AND
                                                         (v_Validity_Date BETWEEN nash.START_DATE AND
                                                         nvl(nash.END_DATE, v_Validity_Date)))
        LEFT JOIN PHONE_NUMBER_SERIES pns ON (pns.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID AND
                                             (pns.deleted > v_Validity_Date OR pns.deleted IS NULL))
        LEFT JOIN PHONE_OPERATOR po ON (po.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID AND
                                       v_Validity_Date BETWEEN po.start_date AND
                                       nvl(po.end_date, v_Validity_Date))
        LEFT JOIN PHONE_SERIES_OPERATOR pso ON (pso.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID AND
                                               (v_Validity_Date BETWEEN pso.START_DATE AND
                                               nvl(pso.END_DATE, v_Validity_Date)))
        LEFT JOIN PHONE_NUMBER_SALABILITY_CATEG pnsc ON pn.NETWORK_ADDRESS_ID = pnsc.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN pnsc.start_date AND nvl(pnsc.end_date,v_Validity_Date)) k
        LEFT JOIN network_operator n ON n.network_operator_id=k.NETWORK_OPERATOR_ID;
  END IF;

  error_code := util_pkg.c_ora_ok;
  error_message := util_pkg.c_msg_ok;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
WHEN OTHERS THEN
  error_code := util_pkg.get_err_code;
  error_message := util_pkg.get_err_msg;

  RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                       RSIG_UTILS.c_DEBUG_LEVEL_0,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                       v_event_source);

  IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
    RAISE;
  END IF;

  OPEN result_list FOR
    SELECT error_code FROM dual;

END Get_phone_numbers_info;

-------------------------------------------------------------------------------
--      procedure Get_Our_Net_Op_By_Phone
-------------------------------------------------------------------------------

PROCEDURE Get_Our_Net_Op_By_Phone
(
  error_code         OUT NUMBER,
  p_phone_number     IN VARCHAR2, -- phone number in INTERNATIONAL FORMAT
  p_validity_date    IN DATE,
  p_uprs_member_code OUT NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
  p_operator_name    OUT network_operator.network_operator_name%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PHONE_NUMBER.Get_Our_Net_Op_By_Phone';
  v_status        VARCHAR2(200);
  v_validity_date DATE;
BEGIN
  -- debug start
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- set date
  v_validity_date := nvl(p_validity_date, SYSDATE);

  -- find operator
  BEGIN
    SELECT NO.Uprs_Member_Code,
           trim(nash.net_address_status_code),
           no.network_operator_name
      INTO p_uprs_member_code,
           v_status,
           p_operator_name
      FROM network_operator NO
      JOIN phone_series_operator pso ON pso.network_operator_id = NO.NETWORK_OPERATOR_ID
      JOIN phone_number_series pns ON pns.phone_number_series_id = pso.phone_number_series_id
      JOIN phone_number pn ON pn.phone_number_series_id = pns.phone_number_series_id
      JOIN Network_Address_Status_History nash ON nash.network_address_id = pn.network_address_id
     WHERE v_validity_date BETWEEN pso.start_date AND nvl(pso.end_date, v_validity_date)
       AND p_phone_number BETWEEN trim(pns.country_code || pns.area_code || pns.local_number_start) AND
           trim(pns.country_code || pns.area_code || pns.local_number_end)
       AND v_validity_date BETWEEN nash.start_date AND nvl(nash.end_date, v_validity_date)
       AND pn.international_format = p_phone_number
       AND (pn.deleted IS NULL OR pn.deleted>SYSDATE);
  EXCEPTION
    WHEN no_data_found THEN
      v_status           := NULL;
      p_uprs_member_code := NULL;
  END;

  -- check status
  IF v_status IS NULL
     AND p_uprs_member_code IS NULL THEN
    p_uprs_member_code := rsig_utils.c_ORA_NO_DATA_FOUND;
  ELSE
    IF v_status = rsig_utils.c_OTHER_PHONE_NUMBER_CODE THEN
      p_uprs_member_code := rsig_utils.c_PHONE_NUMBER_NOT_EXISTS;
    END IF;
  END IF;

  -- set error code
  error_code := util_pkg.c_ora_ok;

  -- debug end
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
WHEN OTHERS THEN
  error_code := util_pkg.get_err_code;
  RSIG_UTILS.Debug_Rsi(error_code || ' ' || util_pkg.get_err_msg,
                       RSIG_UTILS.c_DEBUG_LEVEL_0,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                       v_event_source);
END Get_Our_Net_Op_By_Phone;

-------------------------------------------------------------------------------
--      FUNCTION Is_Phone_Number_In_Mask
-------------------------------------------------------------------------------

FUNCTION Is_Phone_Number_In_Mask
(
  p_phone_number IN VARCHAR2, -- actuall phone number
  p_mask         IN VARCHAR2 -- actuall mask
) RETURN INT IS

  v_char      CHAR(1);
  v_char_pn   CHAR(1);
  v_is_char   INT;

BEGIN
  v_is_char := 0;
  IF LENGTH(p_phone_number) > 0
     AND LENGTH(p_mask) > 0 THEN
    v_is_char := 1;
    FOR a IN REVERSE 1 .. LENGTH(p_mask)
    LOOP
      IF v_is_char=1 THEN
        v_char := UPPER(SUBSTR(p_mask, a, 1));
        IF v_char >= '0'
           AND v_char <= '9' THEN
          IF SUBSTR(p_phone_number, LENGTH(p_phone_number) - (LENGTH(p_mask) - a), 1) <> v_char THEN
            v_is_char := 0;
          END IF;
        END IF;
        IF v_char >= 'A'
           AND v_char <= 'Z' THEN
          v_char_pn := SUBSTR(p_phone_number, LENGTH(p_phone_number) - (LENGTH(p_mask) - a), 1);
          FOR b IN REVERSE 1 .. (a - 1)
          LOOP
            IF UPPER(SUBSTR(p_mask, b, 1)) = v_char THEN
              IF SUBSTR(p_phone_number, LENGTH(p_phone_number) - (LENGTH(p_mask) - b), 1) <> v_char_pn THEN
                v_is_char := 0;
              END IF;
            END IF;
          END LOOP;
        END IF;
      END IF;
    END LOOP;
  END IF;
  RETURN v_is_char;
END Is_Phone_Number_In_Mask;

----------------------------------------------------------------------------
--  PROCEDURE Mark_Gold_Phone_Numbers
----------------------------------------------------------------------------
PROCEDURE Mark_Gold_Phone_Numbers(
  handle_tran                     IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_start_date                    IN  DATE, -- Validity start date and time (if null, then current date and time is considered)
  p_phone_number_series_id        IN  PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
  p_user_id_of_change             IN  NUMBER, -- id of the user who insert this serie
  p_set_gold                      IN  CHAR, -- "Y" means, that salability category should be set according to set masks, "N" means, that salability category should be set to "standard
  p_leave_marked_unchanged        IN  CHAR, -- "N" means, that salability category should be set for all phone numbers in series, "Y" means, that salability category should be set for "standard" phone numbers only
  p_raise_error                   IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code                      OUT NUMBER
) IS
  v_event_source                  VARCHAR2(60) := 'RSIG_PHONE_NUMBER.Mark_Gold_Phone_Numbers';
  v_start_date                    DATE;
  v_set_gold                      CHAR(1);
  v_leave_marked_unchanged        CHAR(1);
  v_sysdate                       DATE;

  CURSOR c_lock_phone_all IS
    SELECT network_address_id
      FROM phone_number
     WHERE phone_number_series_id = p_phone_number_series_id
       FOR UPDATE NOWAIT;

  CURSOR c_lock_phon_std IS
    SELECT network_address_id
      FROM phone_number
     WHERE phone_number_series_id = p_phone_number_series_id
       AND salability_category_code=trim(RSIG_UTILS.C_STANDARD_SAL_CATEGORY)
       FOR UPDATE NOWAIT;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF p_phone_number_series_id IS NULL
     OR p_user_id_of_change IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  v_start_date             := nvl(p_start_date, SYSDATE);
  v_set_gold               := nvl(UPPER(p_set_gold),rsig_utils.c_NO);
  v_leave_marked_unchanged := nvl(UPPER(p_leave_marked_unchanged),rsig_utils.c_NO);
  v_sysdate                := SYSDATE;

  IF (v_set_gold NOT IN (rsig_utils.c_YES, rsig_utils.c_NO))
     OR (v_leave_marked_unchanged NOT IN (rsig_utils.c_YES, rsig_utils.c_NO)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_PARAMETER, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Mark_Gold_Phone_Numbers_a;
  END IF;
---------------------------------------------------------------------------------------------------
  IF upper(trim(v_leave_marked_unchanged)) = rsig_utils.c_NO THEN
  -- set salability category for all phone numbers
  BEGIN
    OPEN c_lock_phone_all;
    CLOSE c_lock_phone_all;
  EXCEPTION
    WHEN RSIG_UTILS.RESOURCE_BUSY THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_RESOURCE_BUSY, 'Resource is busy');
  END;
    -- close old salability category ---
    UPDATE(SELECT /*+ ORDERED USE_NL(pn pnsc) index(pnsc I_PHONUSALCA_NET_ADDRESS_ID) index(pn I_PHONENUM_PHONE_NUM_SERIES_ID)*/
                  pnsc.date_of_change,
                  pnsc.user_id_of_change,
                  pnsc.end_date
           FROM phone_number pn
           JOIN phone_number_salability_categ pnsc ON pnsc.network_address_id=pn.network_address_id
                AND v_start_date BETWEEN pnsc.start_date AND nvl(pnsc.end_date,v_start_date)
           WHERE pn.phone_number_series_id=p_phone_number_series_id) k
    SET k.date_of_change=v_sysdate,
        k.user_id_of_change=p_user_id_of_change,
        k.end_date = v_start_date - Rsig_Utils.c_INTERVAL_DIFFERENCE;


    IF upper(trim(v_set_gold)) = rsig_utils.c_NO THEN
    -- set only standard salability category
      INSERT INTO phone_number_salability_categ
        (salability_category_code,
         network_address_id,
         start_date,
         date_of_change,
         user_id_of_change,
         end_date)
      SELECT /*+ index(pn I_PHONENUM_PHONE_NUM_SERIES_ID)*/
         RSIG_UTILS.C_STANDARD_SAL_CATEGORY,
         pn.network_address_id,
         v_start_date,
         v_sysdate,
         p_user_id_of_change,
         NULL
      FROM phone_number pn
      WHERE pn.phone_number_series_id=p_phone_number_series_id;
    ELSE
    -- set salability category according to masks
      INSERT INTO phone_number_salability_categ
         (salability_category_code,
          network_address_id,
          start_date,
          date_of_change,
          user_id_of_change,
          end_date)
      SELECT CASE WHEN k.salability_category_code IS NULL
                THEN RSIG_UTILS.C_STANDARD_SAL_CATEGORY
                ELSE k.salability_category_code
             END salability_category_code,
             k.network_address_id,
             v_start_date,
             v_sysdate,
             p_user_id_of_change,
             NULL
      FROM (select /*+ index(pn I_PHONENUM_PHONE_NUM_SERIES_ID) */
            pn.network_address_id,
            scm.salability_category_code,
            row_number() over
              (partition BY pn.international_format order BY psc.ATTRACTIVENESS_LEVEL) ord
            from phone_number pn
            LEFT JOIN salability_category_mask scm ON (RSIG_PHONE_NUMBER.Is_Phone_Number_In_Mask(pn.international_format,scm.mask)=1)
            LEFT JOIN phone_salability_category psc ON trim(psc.PHONE_SALABILITY_CATEGORY_CODE)=trim(scm.salability_category_code)
            WHERE pn.phone_number_series_id=p_phone_number_series_id) k
      WHERE k.ord=1;

    END IF;
  ELSE
  -- set salability category for only standard phone numbers
  BEGIN
    OPEN c_lock_phon_std;
    CLOSE c_lock_phon_std;
  EXCEPTION
    WHEN RSIG_UTILS.RESOURCE_BUSY THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_RESOURCE_BUSY, 'Resource is busy');
  END;

    IF upper(trim(v_set_gold)) = rsig_utils.c_Yes THEN

      -- close old salability category ---
      UPDATE(SELECT /*+ ORDERED USE_NL(pn pnsc) index(pnsc I_PHONUSALCA_NET_ADDRESS_ID) index(pn I_PHONENUM_PHONE_NUM_SERIES_ID)*/
                    pnsc.date_of_change,
                    pnsc.user_id_of_change,
                    pnsc.end_date
             FROM phone_number pn
             JOIN phone_number_salability_categ pnsc ON pnsc.network_address_id=pn.network_address_id
                  AND v_start_date BETWEEN pnsc.start_date AND nvl(pnsc.end_date,v_start_date)
             WHERE pn.phone_number_series_id=p_phone_number_series_id
               AND pnsc.salability_category_code=RSIG_UTILS.C_STANDARD_SAL_CATEGORY) k
      SET k.date_of_change=v_sysdate,
          k.user_id_of_change=p_user_id_of_change,
          k.end_date = v_start_date - Rsig_Utils.c_INTERVAL_DIFFERENCE;

      -- insert new salability category
      INSERT INTO phone_number_salability_categ
         (salability_category_code,
          network_address_id,
          start_date,
          date_of_change,
          user_id_of_change,
          end_date)
      SELECT CASE WHEN k.salability_category_code IS NULL
                THEN RSIG_UTILS.C_STANDARD_SAL_CATEGORY
                ELSE k.salability_category_code
             END salability_category_code,
             k.network_address_id,
             v_start_date,
             SYSDATE,
             p_user_id_of_change,
             NULL
      FROM (select /*+ index(pn I_PHONENUM_PHONE_NUM_SERIES_ID) */
            pn.network_address_id,
            scm.salability_category_code,
            row_number() over
              (partition BY pn.international_format order BY psc.ATTRACTIVENESS_LEVEL) ord
            from phone_number pn
            LEFT JOIN salability_category_mask scm ON (RSIG_PHONE_NUMBER.Is_Phone_Number_In_Mask(pn.international_format,scm.mask)=1)
            LEFT JOIN phone_salability_category psc ON trim(psc.PHONE_SALABILITY_CATEGORY_CODE)=trim(scm.salability_category_code)
            WHERE pn.phone_number_series_id=p_phone_number_series_id
              AND pn.salability_category_code=trim(RSIG_UTILS.C_STANDARD_SAL_CATEGORY)) k
      WHERE k.ord=1;
    END IF;
  END IF;
--------------------------------------------------------------------------------------------------
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := util_pkg.c_ora_ok; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := util_pkg.get_err_code;
    RSIG_UTILS.Debug_Rsi(error_code,RSIG_UTILS.c_DEBUG_LEVEL_0,RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);

    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Mark_Gold_Phone_Numbers_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;

    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Mark_Gold_Phone_Numbers;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Net_Op_and_Status_By_Phone
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Net_Op_and_Status_By_Phone(
  p_phone_number           IN  phone_number.international_format%TYPE,
  p_validity_date          IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  p_other_billing          OUT CHAR,
  p_uprs_member_code       OUT NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE
)
IS
  v_event_source           varchar2(60) :='RSIG_PHONE_NUMBER.Get_Net_Op_and_Status_By_Phone';
  v_validity_date          DATE;
  v_exists                 INT;
  v_status                 CHAR(1);
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
  -- check handle_tran parameter

  IF p_phone_number IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  v_validity_date:=nvl(p_validity_date,SYSDATE);
-- start of the procedure body --------------------------------------------------------------------------------------------------

  -- check if given phone number have reference in phone oprator table at given date
  SELECT COUNT(1)
  INTO v_exists
  FROM dual
  WHERE exists(SELECT 1
               FROM phone_number pn
               JOIN PHONE_OPERATOR po ON pn.NETWORK_ADDRESS_ID = po.NETWORK_ADDRESS_ID
               WHERE v_validity_date BETWEEN po.START_DATE AND nvl(po.END_DATE, v_validity_date)
                 AND pn.international_format = p_phone_number
                 AND (pn.deleted IS NULL OR pn.deleted>v_validity_date));


  IF v_exists=1 THEN
  -- reference exist - phone number was assigned different operator than phone series owner
    BEGIN
      SELECT n.UPRS_MEMBER_CODE,
             pn.net_address_status_code
      INTO p_uprs_member_code,
           v_status
      FROM phone_number pn
      JOIN PHONE_OPERATOR po ON pn.NETWORK_ADDRESS_ID = po.NETWORK_ADDRESS_ID
      JOIN NETWORK_OPERATOR n ON po.NETWORK_OPERATOR_ID = n.NETWORK_OPERATOR_ID
      WHERE v_validity_date BETWEEN po.START_DATE AND nvl(po.END_DATE, v_validity_date)
        AND pn.international_format = p_phone_number
        AND (pn.deleted IS NULL OR pn.deleted>v_validity_date);

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      raise_application_error(rsig_utils.c_ORA_PHONE_NUMBER_NOT_EXISTS,'Phone number does not exists.');
    END;
  ELSE
    BEGIN
      SELECT n.UPRS_MEMBER_CODE,
             pn.net_address_status_code
      INTO p_uprs_member_code,
           v_status
      FROM phone_number pn
      JOIN PHONE_SERIES_OPERATOR pso ON pn.PHONE_NUMBER_SERIES_ID = pso.PHONE_NUMBER_SERIES_ID
      JOIN NETWORK_OPERATOR n ON pso.NETWORK_OPERATOR_ID = n.NETWORK_OPERATOR_ID
      WHERE v_validity_date BETWEEN pso.START_DATE AND nvl(pso.END_DATE, v_validity_date)
        AND pn.international_format = p_phone_number
        AND (pn.deleted IS NULL OR pn.deleted>v_validity_date);

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      raise_application_error(rsig_utils.c_ORA_PHONE_NUMBER_NOT_EXISTS,'Phone number does not exists.');
    END;
  END IF;

  IF upper(trim(v_status)) = rsig_utils.c_OTHER_PHONE_NUMBER_CODE THEN
    p_other_billing:=rsig_utils.c_YES;
  ELSE
    p_other_billing:=rsig_utils.c_NO;
  END IF;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  error_code := util_pkg.c_ora_ok;
  error_message := util_pkg.c_msg_ok;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
WHEN OTHERS THEN
  error_code := util_pkg.get_err_code;
  error_message := util_pkg.get_err_msg;

  RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                       RSIG_UTILS.c_DEBUG_LEVEL_0,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                       v_event_source);

  IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
    RAISE;
  END IF;

END Get_Net_Op_and_Status_By_Phone;

----------------------------------------------------------------------------
--  PROCEDURE Get_Phone_Numbers_by_ICCID
----------------------------------------------------------------------------
procedure Get_Phone_Numbers_by_ICCID
(
  p_ICCID_list    IN common.t_ICCID,
  p_raise_error   IN CHAR,
  error_code      OUT NUMBER,
  error_message   OUT VARCHAR2,
  result_list     OUT sys_refcursor
) IS
  v_event_source  VARCHAR2(60) := 'RSIG_PHONE_NUMBER.Get_Phone_Number_by_ICCID';
  obj             t_v2_60_obj := t_v2_60_obj(NULL);
  obj_col         t_v2_60_obj_tab := t_v2_60_obj_tab();
  j               NUMBER;
  i               NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (p_ICCID_list IS NULL) OR
     (p_ICCID_list.COUNT = 0) OR
     (p_ICCID_list.COUNT = 1 AND p_ICCID_list(p_ICCID_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  -- procedure body here

  j := 1;
  FOR i IN nvl(p_ICCID_List.FIRST, 1) .. nvl(p_ICCID_List.LAST, 0)
  LOOP
    -- for all members of input associative array
    obj := t_v2_60_obj(p_ICCID_list(i));
    obj_col.EXTEND; -- grow
    obj_col(j) := obj; -- insert into collection
    j := j + 1;
  END LOOP;


    OPEN result_list FOR
    SELECT
        t1.ICCID,
        t1.INTERNATIONAL_FORMAT,
        t1.NETWORK_OPERATOR_CODE,
        t1.NET_ADDRESS_STATUS_CODE,
        t1.PHONE_NUMBER_TYPE_CODE,
        t1.SALABILITY_CATEGORY_CODE,
        t1.LINK_TYPE_CODE,
        uu.USER_NAME,
        uu.LOGIN_NAME,
        t1.DATE_OF_CHANGE,
        t1.ERROR_CODE
    FROM
        (SELECT
               t.ICCID,
               pn.INTERNATIONAL_FORMAT,
               pn.NET_ADDRESS_STATUS_CODE,
               pn.SALABILITY_CATEGORY_CODE,
               n.NETWORK_OPERATOR_CODE,
               t.ERROR_CODE,
               t.LINK_TYPE_CODE,
               t.USER_ID_OF_CHANGE,
               t.DATE_OF_CHANGE,
               pns.PHONE_NUMBER_TYPE_CODE,
               row_number() over(partition by t.ICCID, pn.INTERNATIONAL_FORMAT order by t.ICCID, pn.INTERNATIONAL_FORMAT, DECODE(n.network_operator_type, rsig_utils.c_External_Net_Operator, 1, 0) desc) id
        FROM(
           SELECT
                 t_obj.v2_60 ICCID,
                 decode(nvl(sc.ACCESS_POINT_ID, -1), -1, RSIG_UTILS.c_ROW_NOT_FOUND, util_pkg.c_ora_ok) ERROR_CODE,
                 trim(naap.LINK_TYPE_CODE) LINK_TYPE_CODE,
                 naap.NETWORK_ADDRESS_ID,
                 naap.USER_ID_OF_CHANGE,
                 naap.DATE_OF_CHANGE
            FROM TABLE(CAST(obj_col AS t_v2_60_obj_tab)) t_obj
            LEFT JOIN SIM_CARD sc ON sc.SN = t_obj.v2_60
                 AND (sc.deleted IS NULL OR sc.deleted > SYSDATE)
            LEFT JOIN network_address_access_point naap ON naap.ACCESS_POINT_ID = sc.ACCESS_POINT_ID
                 AND (naap.TO_DATE is NULL or naap.TO_DATE > SYSDATE)
      ) t
        LEFT JOIN PHONE_NUMBER pn ON pn.NETWORK_ADDRESS_ID = t.NETWORK_ADDRESS_ID
            AND (pn.deleted IS NULL OR pn.deleted>SYSDATE)
        LEFT JOIN PHONE_NUMBER_SERIES pns ON (pns.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
            AND (pns.deleted IS NULL or pns.deleted > SYSDATE))
        LEFT JOIN PHONE_OPERATOR po ON po.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
            AND (po.end_date IS NULL OR po.end_date > SYSDATE)
        LEFT JOIN PHONE_SERIES_OPERATOR pso ON pso.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
            AND (pso.end_date IS NULL OR pso.end_date > SYSDATE)
        LEFT JOIN network_operator n ON n.network_operator_id = nvl(po.NETWORK_OPERATOR_ID, pso.NETWORK_OPERATOR_ID)
    ) t1
    LEFT JOIN USERS uu on uu.USER_ID = t1.USER_ID_OF_CHANGE
  WHERE t1.id = 1;

  error_code := util_pkg.c_ora_ok;
  error_message := util_pkg.c_msg_ok;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
WHEN OTHERS THEN
  error_code := util_pkg.get_err_code;
  error_message := util_pkg.get_err_msg;

  RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                       RSIG_UTILS.c_DEBUG_LEVEL_0,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                       v_event_source);

  OPEN result_list FOR
    SELECT error_code, error_message FROM dual;

  IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
    RAISE;
  END IF;

END Get_Phone_Numbers_by_ICCID;

-----------------------------------------------------------------------------------------------------------------------------------------------------
procedure PROD_FindFreePhoneNumbers
(
  p_host_id host.host_id%type,
  p_msisdn_mask varchar2,
  p_msisdn_start varchar2,
  p_msisdn_end varchar2,
  p_service_provider_code varchar2,
  p_linked_service_provider_code varchar2,
  p_phone_status_code phone_number.net_address_status_code%type,
  p_phone_type_code phone_number_series.phone_number_type_code%type,
  p_quantity_limit number,
  p_salability_category varchar2,
  p_user_login users.login_name%type,
  p_handle_tran char default rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error char default rsig_utils.c_NO,
  p_error_code out number,
  p_error_message out varchar2,
  p_result_list out sys_refcursor,
  p_rejected_list out sys_refcursor
)
is
begin
  ------------------------------
  legacy_pkg.xcheck_handle_tran(p_handle_tran);
  legacy_pkg.xcheck_yes_no(p_raise_error, 'p_raise_error');
  ------------------------------
  if legacy_pkg.xis_tran_s(p_handle_tran)
  then
    savepoint A;
  end if;
  ------------------------------
  PRODUCTION_PKG.PROD_FindFreePhoneNumbers_i
  (
    p_host_id => p_host_id,
    p_msisdn_mask => p_msisdn_mask,
    p_msisdn_start => p_msisdn_start,
    p_msisdn_end => p_msisdn_end,
    p_network_operator_code => p_service_provider_code,
    p_linked_network_operator_code => p_linked_service_provider_code,
    p_phone_status_code => p_phone_status_code,
    p_phone_type_code => p_phone_type_code,
    p_quantity_limit => p_quantity_limit,
    p_salability_category => p_salability_category,
    p_user_login => p_user_login,
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_result_list => p_result_list,
    p_rejected_list => p_rejected_list
  );
  ------------------------------
  if util_pkg.is_ok(p_error_code)
  then
    ------------------------------
    if legacy_pkg.xis_tran_yes(p_handle_tran)
    then
      commit;
    end if;
    ------------------------------
  else
    ------------------------------
    if legacy_pkg.xis_tran_yes(p_handle_tran)
    then
      rollback;
    elsif legacy_pkg.xis_tran_s(p_handle_tran)
    then
      rollback to A;
    end if;
    ------------------------------
    if legacy_pkg.xis_yes(p_raise_error, 'p_raise_error')
    then
      util_pkg.raise_exception(p_error_code, p_error_message);
    end if;
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  if legacy_pkg.xis_tran_yes(p_handle_tran)
  then
    rollback;
  elsif legacy_pkg.xis_tran_s(p_handle_tran)
  then
    rollback to A;
  end if;
  ------------------------------
  if legacy_pkg.xis_yes(p_raise_error, 'p_raise_error')
  then
    util_pkg.reraise_exception;
  end if;
  ------------------------------
end;

-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE PROD_CheckPhonesByList(
  p_phone_list             IN  t_phone_number_col,
  p_host_id               IN  host.host_id%TYPE,
  p_service_provider_code  IN  VARCHAR2,
  p_linked_service_provider_code  IN  VARCHAR2,
  p_phone_status_code      IN  phone_number.net_address_status_code%TYPE,
  p_phone_type_code        IN  phone_number_series.phone_number_type_code%TYPE,
  p_salability_category    IN  VARCHAR2,
  p_user_login             IN  users.login_name%type,
  p_handle_tran             IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor,
  p_rejected_list          OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'RSIG_PHONE_NUMBER';
  v_procedure_name        VARCHAR2(30) := 'PROD_CheckPhonesByList';
  v_event_source          VARCHAR2(60);
  v_service_provider_id   NUMBER;
  v_linked_service_provider_id   NUMBER;
  v_user_id                  NUMBER;
  v_sysdate                  DATE:=SYSDATE;
  v_exists                       INT;
BEGIN

   v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);


  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);


  -- check existence of user
  v_user_id := Rsig_users.Get_user_id_by_login(p_user_login);

  -- check input parameters
  IF p_host_id IS NULL OR p_phone_status_code IS NULL OR p_phone_type_code IS NULL OR p_salability_category IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF p_phone_list IS NULL OR
     p_phone_list.COUNT = 0 OR
     (p_phone_list.COUNT = 1 AND p_phone_list(p_phone_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF (p_service_provider_code IS NOT NULL)
    THEN
      SELECT no.network_operator_id
        INTO v_service_provider_id
        FROM NETWORK_OPERATOR no
        WHERE no.network_operator_code = p_service_provider_code;
    END IF;

  IF (p_linked_service_provider_code IS NOT NULL)
    THEN
      SELECT no.network_operator_id
        INTO v_linked_service_provider_id
        FROM NETWORK_OPERATOR no
        WHERE no.network_operator_code = p_linked_service_provider_code;
    END IF;

  --------------------------------------------------------------------------------------------------
  DELETE FROM tt_batch_na_ap;

  FORALL i IN nvl(p_phone_list.FIRST, 1) .. nvl(p_phone_list.LAST, 0)
    INSERT INTO tt_batch_na_ap(INTERNATIONAL_FORMAT,result)
    VALUES(p_phone_list(i),util_pkg.c_ora_ok);

  RSIG_UTILS.Fill_Na_Id_From_Int_Number;

  UPDATE tt_batch_na_ap t
     SET t.result=RSIG_UTILS.c_NOT_SAME_HOST_ID
   WHERE t.result = util_pkg.c_ora_ok
   AND NOT EXISTS(SELECT 1
                    FROM PHONE_NUMBER pn
                    JOIN PHONE_NUMBER_SERIES pns ON pns.phone_number_series_id = pn.phone_number_series_id
                    WHERE pns.host_id=p_host_id
                      AND pn.International_Format=t.International_Format);

  UPDATE tt_batch_na_ap t
     SET t.result=RSIG_UTILS.c_SIM_INVALID_NET_OPER
   WHERE t.result = util_pkg.c_ora_ok
     AND (NOT EXISTS(SELECT 1
                    FROM phone_number pnm
                    LEFT JOIN phone_series_operator psom ON psom.phone_number_series_id=pnm.phone_number_series_id
                               AND SYSDATE BETWEEN psom.start_date AND nvl(psom.end_date,SYSDATE)
                    WHERE pnm.international_format = t.International_Format
                       AND ((psom.network_operator_id=v_service_provider_id AND v_service_provider_id IS NOT NULL)
                                                                             OR p_service_provider_code IS NULL))
      OR p_service_provider_code IS NULL);
 /*
UPDATE tt_batch_na_ap t
     SET t.result=RSIG_UTILS.c_SIM_INVALID_NET_OPER
   WHERE t.result = util_pkg.c_ora_ok
     AND (NOT EXISTS(SELECT 1
                    FROM phone_number pnm
                    LEFT JOIN phone_link pl ON pl.main_msisdn=pnm.international_format
                    LEFT JOIN phone_number pnl ON pl.linked_msisdn=pnl.international_format
                    LEFT JOIN phone_series_operator psol ON psol.phone_number_series_id=pnl.phone_number_series_id
                               AND SYSDATE BETWEEN psol.start_date AND nvl(psol.end_date,SYSDATE)
                     WHERE pnm.international_format = t.International_Format
                       AND ((psol.network_operator_id=v_linked_service_provider_id AND v_linked_service_provider_id IS NOT NULL)
                                                                                    OR p_linked_service_provider_code IS NULL))
      OR p_linked_service_provider_code IS NULL);
*/

  UPDATE tt_batch_na_ap t
     SET t.result=RSIG_UTILS.c_ORA_NOT_SAME_PHONE_TYPES
   WHERE t.result = util_pkg.c_ora_ok
   AND NOT EXISTS(SELECT 1
                    FROM PHONE_NUMBER pn
                    JOIN PHONE_NUMBER_SERIES pns ON pns.phone_number_series_id = pn.phone_number_series_id
                    WHERE pns.phone_number_type_code=p_phone_type_code
                      AND pn.International_Format=t.International_Format);

  UPDATE tt_batch_na_ap t
     SET t.result=RSIG_UTILS.c_BAD_PHONE_STATUS
   WHERE t.result = util_pkg.c_ora_ok
   AND NOT EXISTS(SELECT 1
                    FROM PHONE_NUMBER pn
                    WHERE pn.net_address_status_code=p_phone_status_code
                      AND pn.International_Format=t.International_Format);

  UPDATE tt_batch_na_ap t
     SET t.result=RSIG_UTILS.c_PHONE_INVALID_SAL_CAT
   WHERE t.result = util_pkg.c_ora_ok
   AND NOT EXISTS(SELECT 1
                    FROM PHONE_NUMBER pn
                    WHERE pn.salability_category_code=p_salability_category
                      AND pn.International_Format=t.International_Format);

  UPDATE tt_batch_na_ap t
     SET t.result=RSIG_UTILS.c_SIM_HAVE_PHONE_NUMBER
   WHERE t.result = util_pkg.c_ora_ok
     AND EXISTS(SELECT 1
                    FROM network_address_access_point naap
                    WHERE naap.network_address_id=t.network_address_id
                      AND SYSDATE BETWEEN naap.from_date AND nvl(naap.to_date,SYSDATE));

  DELETE FROM tt_processed_phones_sims;
  DELETE FROM tt_rejected_phones_sims;

  INSERT INTO tt_processed_phones_sims(MAIN_MSISDN,LINKED_MSISDN)
    SELECT t.International_Format,
           pl.linked_msisdn
      FROM tt_batch_na_ap t
      LEFT JOIN phone_link pl ON pl.main_msisdn=t.international_format
      WHERE t.result = util_pkg.c_ora_ok;

  INSERT INTO tt_rejected_phones_sims(MAIN_MSISDN,LINKED_MSISDN,RESULT)
    SELECT t.International_Format, pl.linked_msisdn, t.result
        FROM tt_batch_na_ap t
        LEFT JOIN phone_link pl ON pl.main_msisdn=t.international_format
        WHERE t.result <> util_pkg.c_ora_ok;

  OPEN p_result_list FOR
    SELECT t.International_Format,
           pl.linked_msisdn
      FROM tt_batch_na_ap t
      LEFT JOIN phone_link pl ON pl.main_msisdn=t.international_format
      WHERE t.result = util_pkg.c_ora_ok;

  OPEN p_rejected_list FOR
    SELECT t.International_Format, t.result,
           pl.linked_msisdn
      FROM tt_batch_na_ap t
      LEFT JOIN phone_link pl ON pl.main_msisdn=t.international_format
      WHERE t.result <> util_pkg.c_ora_ok;



  SELECT COUNT(1)
  INTO v_exists
  FROM dual
  WHERE EXISTS(SELECT 1
               FROM tt_batch_na_ap t
               WHERE t.result=util_pkg.c_ora_ok
                AND NET_ADDR_STATUS_HISTORY.Is_Status_Change_Allowed
                          (t.network_address_id,
                           RSIG_UTILS.c_RESERVE_PHONE_NUMBER_CODE,
                           RSIG_UTILS.c_YES,
                           v_sysdate,
                           RSIG_UTILS.c_YES)<>util_pkg.c_ora_ok);

  IF v_exists>0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_CHANGE_PH_STATUS_NOT_ALW, 'Change phone status is not allowed.');
  END IF;

  DELETE  /*+ ordered use_nl(bd) index(bd I_BATCH_DETAILS_OBJ_ID)*/ FROM batch_details bd
   WHERE 1 = 1
     AND (bd.object_id, bd.batch_id) IN (select /*+ ordered use_nl(t tbd tb) full(t) index(tbd I_BATCH_DETAILS_OBJ_ID) index(tb PK_BATCH)*/
                                                tbd.object_id,tbd.batch_id
                                           from tt_batch_na_ap t
                                           join batch_details tbd on tbd.object_id = t.network_address_id
                                           join batch tb on tb.batch_id = tbd.batch_id and tb.batch_type = batch_pkg.c_BATCH_TYPE_NA_MNG
                                          where t.result = util_pkg.c_ora_ok);
   -- close previous interval -------------------------------------------------------------------
  UPDATE /*+ index(nash I_NETADSTAHI_NETWORK_ADDRES_ID)*/
  network_address_status_history nash
  SET nash.end_date = v_sysdate - RSIG_UTILS.c_INTERVAL_DIFFERENCE,
      nash.date_of_change = sysdate,
      nash.user_id_of_change = v_user_id
  WHERE v_sysdate BETWEEN nash.start_date AND nvl(nash.end_date,v_sysdate)
    AND EXISTS(SELECT /*+ use_nl(t nash) */ 1
                FROM tt_batch_na_ap t
               WHERE t.network_address_id=nash.network_address_id
                 AND t.result=util_pkg.c_ora_ok);

  -- insert new interval -----------------------------------------------------------------------
  insert into NETWORK_ADDRESS_STATUS_HISTORY
        (NET_ADDRESS_STATUS_CODE,
         NETWORK_ADDRESS_ID,
         START_DATE,
         DATE_OF_CHANGE,
         USER_ID_OF_CHANGE)
   SELECT RSIG_UTILS.c_RESERVE_PHONE_NUMBER_CODE,
          t.network_address_id,
          v_sysdate,
          sysdate,
          v_user_id
    FROM tt_batch_na_ap t
    WHERE t.result = util_pkg.c_ora_ok;

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  ---------------------------------------------------------------------------------------------------------
  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;

  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);

EXCEPTION
WHEN OTHERS THEN
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;

  OPEN p_result_list FOR SELECT p_error_code FROM dual;

  IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
    RAISE;
  END IF;

END PROD_CheckPhonesByList;

-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Set_Phone_Number_Host_Relation(
  p_pnum_series_id        IN  phone_number_series_host.phone_number_series_id%TYPE,
  p_host_id               IN  host.host_id%TYPE,
  p_start_date            IN  DATE,
  p_end_date              IN  DATE,
  p_user_id_of_change     IN  NUMBER,
  handle_tran             IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error           IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code              OUT NUMBER,
  error_message           OUT VARCHAR2
)
IS
  v_event_source          varchar2(60) :='RSIG_PHONE_NUMBER.Set_Phone_Number_Host_Relation';
  v_host_type_code        host.host_type_code%TYPE;
  v_start_date            DATE;
  v_last_host             host.host_id%TYPE;

BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
  END IF;

  IF p_host_id IS NULL OR  p_pnum_series_id IS NULL OR p_user_id_of_change IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;


  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Set_Pnum_Host_Relation_a;
  END IF;

  v_start_date:=nvl(p_start_date,SYSDATE);

  -- start of the procedure body
  -- find type of host for host
  BEGIN
    SELECT h.host_type_code
    INTO v_host_type_code
    FROM host h
    WHERE h.host_id=p_host_id
      AND (h.deleted IS NULL OR h.deleted>nvl(p_end_date,h.deleted));

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_HOST_DELETED, 'Host does not exist.');
  END;

  -- delete future intervals
  DELETE FROM phone_number_series_host pnsh
  WHERE pnsh.phone_number_series_id = p_pnum_series_id
    AND pnsh.host_type_code = v_host_type_code
    AND pnsh.start_date > v_start_date;

  -- terminate last interval
  UPDATE phone_number_series_host pnsh
  SET pnsh.end_date = v_start_date - RSIG_UTILS.c_INTERVAL_DIFFERENCE,
      pnsh.user_id_of_change = p_user_id_of_change,
      pnsh.date_of_change = SYSDATE
  WHERE pnsh.phone_number_series_id = p_pnum_series_id
    AND pnsh.host_type_code = v_host_type_code
    AND (v_start_date <= pnsh.end_date OR pnsh.end_date IS NULL)
    AND (p_end_date >= pnsh.start_date OR p_end_date IS NULL)
  RETURNING pnsh.host_id INTO v_last_host;

  IF v_last_host = p_host_id THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_SAME_HOST_SIM_SERIES, 'Same host as previous.');
  END IF;

  INSERT INTO phone_number_series_host
    (phone_number_series_id,
     host_type_code,
     host_id,
     start_date,
     end_date,
     date_of_change,
     user_id_of_change)
  VALUES
    (p_pnum_series_id,
     v_host_type_code,
     p_host_id,
     v_start_date,
     p_end_date,
     SYSDATE,
     p_user_id_of_change);


  -- end of the procedure body

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  error_code := util_pkg.c_ora_ok;
  error_message := util_pkg.c_msg_ok;

  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);

EXCEPTION
WHEN OTHERS THEN
  error_code := util_pkg.get_err_code;
  error_message := util_pkg.get_err_msg;

  RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, v_event_source);

  CASE handle_tran
    WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Set_Pnum_Host_Relation_a;
    WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
    ELSE NULL;
  END CASE;

  IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
    RAISE;
  END IF;

END Set_Phone_Number_Host_Relation;

------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Pnum_Relation_to_Host(
  p_pnum_series_id         IN  phone_number_series_host.phone_number_series_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
IS
  v_event_source            varchar2(60) :='RSIG_PHONE_NUMBER.Get_Pnum_Relation_to_Host';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1,
  RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  -- check handle_tran parameter
  IF p_pnum_series_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- start of the procedure body
  OPEN result_list FOR
  SELECT pnsh.host_id,
         h.host_name,
         h.host_code,
         ht.HOST_TYPE_NAME,
         h.host_type_code,
         pnsh.start_date,
         pnsh.end_date,
         u.user_name,
         u.login_name,
         pnsh.date_of_change
  FROM phone_number_series_host pnsh
  JOIN host h ON h.host_id = pnsh.host_id
  JOIN host_type ht ON ht.HOST_TYPE_CODE = pnsh.host_type_code
  JOIN users u ON u.user_id = pnsh.user_id_of_change
  WHERE pnsh.phone_number_series_id = p_pnum_series_id
  ORDER BY pnsh.host_type_code,pnsh.start_date;

  -- end of the procedure body

  error_code := util_pkg.c_ora_ok;
  error_message := util_pkg.c_msg_ok;

  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);

EXCEPTION
WHEN OTHERS THEN
  error_code := util_pkg.get_err_code;
  error_message := util_pkg.get_err_msg;

  RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, v_event_source);

  OPEN result_list FOR SELECT error_code, error_message FROM dual;

  IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
    RAISE;
  END IF;

END Get_Pnum_Relation_to_Host;

------------------------------------------------------------------------------------------------------------------------------
PROCEDURE GetBalanceStorageByPAMSISDN(
  p_international_format   IN  phone_number.international_format%TYPE,
  p_personal_account       IN  personal_account_history.personal_account%TYPE,
  p_validity_date          IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
IS
  v_event_source            varchar2(60) :='RSIG_PHONE_NUMBER.GetBalanceStorageByPAMSISDN';
  v_count                   number;
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1,
  RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  -- check input parameter
  IF p_international_format IS NULL OR p_personal_account IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- start of the procedure body
  SELECT COUNT(1) INTO v_count
    FROM personal_account_history pah
     WHERE pah.personal_account = p_personal_account
       AND nvl(p_validity_date,sysdate) BETWEEN pah.start_date and nvl(pah.end_date, sysdate);

  IF v_count IS NOT NULL AND v_count>0
    THEN
      OPEN result_list FOR
        SELECT pah.balance_storage as host_id,
               h.host_code,
               h.host_name,
               h.host_type_code
          FROM personal_account_history pah
          LEFT JOIN host h ON h.host_id = pah.balance_storage
         WHERE pah.personal_account = p_personal_account
           AND nvl(p_validity_date,sysdate) BETWEEN pah.start_date and nvl(pah.end_date, sysdate);
    ELSE
      v_count:=0;
      SELECT COUNT(1) INTO v_count
        FROM phone_number pn
         WHERE pn.international_format = p_international_format
           AND (pn.deleted IS NULL OR pn.deleted> p_validity_date);

      IF v_count IS NULL OR v_count=0
        THEN
          RAISE_APPLICATION_ERROR(RSIG_UTILS.c_PHONE_NUMBER_NOT_EXISTS, 'Phone number not exist.');
        END IF;

    /*  SELECT pn.phone_number_series_id INTO v_phone_number_series_id
        FROM phone_number pn
         WHERE pn.international_format = p_international_format
           AND (pn.deleted IS NULL OR pn.deleted> p_validity_date);*/

      OPEN result_list FOR
      SELECT pnsh.host_id,
             h.host_name,
             h.host_code,
             h.host_type_code
        FROM phone_number pn
        JOIN phone_number_series_host pnsh on pnsh.phone_number_series_id = pn.phone_number_series_id
        JOIN host h ON h.host_id = pnsh.host_id
        JOIN host_type ht ON ht.HOST_TYPE_CODE = pnsh.host_type_code
        JOIN users u ON u.user_id = pnsh.user_id_of_change
        WHERE pn.international_format = p_international_format
           AND (pn.deleted IS NULL OR pn.deleted> p_validity_date);

    END IF;

  -- end of the procedure body

  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;

  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);

EXCEPTION
WHEN OTHERS THEN
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;

  OPEN result_list FOR SELECT p_error_code, p_error_message FROM dual;

  IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
    RAISE;
  END IF;

END GetBalanceStorageByPAMSISDN;

------------------------------------------------------------------------------------------------------------------------------
PROCEDURE GetBalanceStorageByPNList(
  p_PN_list         IN   t_phone_number_col,
  p_raise_error     IN   CHAR DEFAULT rsig_utils.c_NO,
  p_error_code      OUT  NUMBER,
  p_error_message   OUT  VARCHAR2,
  result_list       OUT  sys_refcursor
)
IS
  v_event_source         VARCHAR2(60) :='RSIG_PHONE_NUMBER.GetBalanceStorageByPNList';
  v_validity_date        DATE;

BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1,
  RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  v_validity_date := SYSDATE;

  -- check input parameters
  IF (p_PN_list.COUNT = 0) OR (p_PN_list.COUNT = 1 AND p_PN_list(1) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  DELETE FROM tt_batch_na_ap;

  -- start of the procedure body
  FORALL i IN nvl(p_PN_list.FIRST, 1) .. nvl(p_PN_list.LAST, 0)
    INSERT INTO tt_batch_na_ap(international_format)
    VALUES(p_PN_list(i));

      OPEN result_list FOR
      SELECT /*+ ordered use_nl(tt, pn, pnsh, h) index_asc(pn UK_PHONE_NUM_PHONE_NUMBER) index_asc(pnsh I_PNUM_PNUM_ID) index_asc(h PK_HOST) */
             tt.international_format,
             pn.phone_number_series_id,
             pnsh.host_id,
             h.host_code,
             h.host_name,
             h.host_type_code
        FROM tt_batch_na_ap tt
        LEFT JOIN phone_number pn ON pn.international_format = tt.international_format
             AND (pn.deleted IS NULL OR pn.deleted > v_validity_date)
        LEFT JOIN phone_number_series_host pnsh ON pnsh.phone_number_series_id = pn.phone_number_series_id
             AND v_validity_date BETWEEN pnsh.start_date AND nvl(pnsh.end_date,v_validity_date)
        LEFT JOIN host h ON h.host_id = pnsh.host_id
             AND (h.deleted IS NULL OR h.deleted > v_validity_date);
  -- end of the procedure body

  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;

  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);

EXCEPTION
WHEN OTHERS THEN
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;

  OPEN result_list FOR SELECT p_error_code, p_error_message FROM dual;

  IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
    RAISE;
  END IF;

END GetBalanceStorageByPNList;

------------------------------------------------------------------------------------------------------------------------------
PROCEDURE PROD_CheckPhonesByList2(
  p_phone_list             IN  t_phone_number_col,
  p_host_id               IN  host.host_id%TYPE,
  p_service_provider_code  IN  VARCHAR2,
  p_linked_service_provider_code  IN  VARCHAR2,
  p_phone_status_code      IN  phone_number.net_address_status_code%TYPE,
  p_phone_type_code        IN  phone_number_series.phone_number_type_code%TYPE,
  p_salability_category    IN  VARCHAR2,
  p_allowed_salability_category              IN t_sal_cat,
  p_user_login             IN  users.login_name%type,
  p_handle_tran             IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor,
  p_rejected_list          OUT sys_refcursor
)
IS
  v_package_name                 VARCHAR2(30) := 'RSIG_PHONE_NUMBER';
  v_procedure_name               VARCHAR2(30) := 'PROD_CheckPhonesByList';
  v_event_source                 VARCHAR2(60);
  v_service_provider_id          NUMBER;
  v_linked_service_provider_id   NUMBER;
  v_user_id                      NUMBER;
  v_sysdate                      DATE:=SYSDATE;
  v_obj                          t_v2_60_obj := t_v2_60_obj(NULL);
  v_allowed_sal_cat              t_v2_60_obj_tab := t_v2_60_obj_tab();
  v_PN_l                         ct_varchar_s;
  c_lock_phones                  SYS_REFCURSOR;
  j                              NUMBER;

  v_error_code ct_number;
  v_error_message ct_varchar;
BEGIN

   v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);


  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);


  -- check existence of user
  v_user_id := util_ri.xget_user_id(p_user_login);

  -- check input parameters
  IF v_user_id IS NULL OR p_host_id IS NULL OR p_phone_status_code IS NULL OR p_phone_type_code IS NULL --OR p_salability_category IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF p_phone_list IS NULL OR
     p_phone_list.COUNT = 0 OR
     (p_phone_list.COUNT = 1 AND p_phone_list(p_phone_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF (p_salability_category IS NULL AND
     (p_allowed_salability_category IS NULL OR
      p_allowed_salability_category.COUNT = 0 OR
      (p_allowed_salability_category.COUNT = 1 AND p_allowed_salability_category(p_allowed_salability_category.FIRST) IS NULL)))
  THEN
     RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter(p_salability_category).');
  END IF;

  IF (p_service_provider_code IS NOT NULL)
    THEN
      SELECT no.network_operator_id
        INTO v_service_provider_id
        FROM NETWORK_OPERATOR no
        WHERE no.network_operator_code = p_service_provider_code;
    END IF;

  IF (p_linked_service_provider_code IS NOT NULL)
    THEN
      SELECT no.network_operator_id
        INTO v_linked_service_provider_id
        FROM NETWORK_OPERATOR no
        WHERE no.network_operator_code = p_linked_service_provider_code;
    END IF;

  --------------------------------------------------------------------------------------------------
  DELETE FROM tt_batch_na_ap;

  FORALL i IN nvl(p_phone_list.FIRST, 1) .. nvl(p_phone_list.LAST, 0)
    INSERT INTO tt_batch_na_ap(INTERNATIONAL_FORMAT,result)
    VALUES(p_phone_list(i),util_pkg.c_ora_ok);

  RSIG_UTILS.Fill_Na_Id_From_Int_Number;

  OPEN c_lock_phones FOR
  SELECT pn.network_address_id
    FROM PHONE_NUMBER pn
   WHERE pn.network_address_id IN
         (SELECT t.network_address_id
            FROM tt_batch_na_ap t)
     FOR UPDATE OF NETWORK_ADDRESS_ID;

  --check HLR
  UPDATE tt_batch_na_ap t
     SET t.result=RSIG_UTILS.c_NOT_SAME_HOST_ID
   WHERE t.result = util_pkg.c_ora_ok
     AND NOT EXISTS(SELECT 1
                      FROM PHONE_NUMBER pn
                      JOIN PHONE_NUMBER_SERIES pns
                        ON pns.phone_number_series_id = pn.phone_number_series_id
                     WHERE pns.host_id=p_host_id
                       AND pn.International_Format=t.International_Format);

  --check if main number belong to required operator
  UPDATE tt_batch_na_ap t
     SET t.result=RSIG_UTILS.c_SIM_INVALID_NET_OPER
   WHERE t.result = util_pkg.c_ora_ok
     AND (NOT EXISTS(SELECT 1
                       FROM phone_number pnm
                       LEFT JOIN phone_series_operator psom ON psom.phone_number_series_id=pnm.phone_number_series_id
                        AND SYSDATE BETWEEN psom.start_date AND nvl(psom.end_date,SYSDATE)
                      WHERE pnm.international_format = t.International_Format
                        AND ((psom.network_operator_id=v_service_provider_id
                        AND v_service_provider_id IS NOT NULL)
                         OR p_service_provider_code IS NULL))
          OR p_service_provider_code IS NULL);

  --check main number status
  UPDATE tt_batch_na_ap t
     SET t.result=RSIG_UTILS.c_BAD_PHONE_STATUS
   WHERE t.result = util_pkg.c_ora_ok
     AND NOT EXISTS(SELECT 1
                      FROM PHONE_NUMBER pn
                     WHERE pn.net_address_status_code=p_phone_status_code
                       AND pn.International_Format=t.International_Format);

  --check main number salability category
  IF p_salability_category IS NOT NULL THEN
    UPDATE tt_batch_na_ap t
       SET t.result=RSIG_UTILS.c_PHONE_INVALID_SAL_CAT
     WHERE t.result = util_pkg.c_ora_ok
       AND NOT EXISTS(SELECT 1
                        FROM PHONE_NUMBER pn
                       WHERE pn.salability_category_code=p_salability_category
                         AND pn.International_Format=t.International_Format);
  ELSE
    j := 1;
    FOR i IN nvl(p_allowed_salability_category.FIRST, 1) .. nvl(p_allowed_salability_category.LAST, 0)
    LOOP
      -- for all members of input associative array
      v_obj := t_v2_60_obj(p_allowed_salability_category(i)); -- ccreate object
      v_allowed_sal_cat.EXTEND; -- grow
      v_allowed_sal_cat(j) := v_obj; -- insert into collection
      j := j + 1;
    END LOOP;

    UPDATE tt_batch_na_ap t
       SET t.result=RSIG_UTILS.c_PHONE_INVALID_SAL_CAT
     WHERE t.result = util_pkg.c_ora_ok
       AND NOT EXISTS
           (SELECT 1
              FROM PHONE_NUMBER pn
              JOIN TABLE(CAST(v_allowed_sal_cat AS t_v2_60_obj_tab)) tsc
                ON tsc.v2_60 = pn.salability_category_code
             WHERE pn.International_Format=t.International_Format);
  END IF;
  --check main number have no linked SIM-card
  UPDATE tt_batch_na_ap t
     SET t.result=RSIG_UTILS.c_SIM_HAVE_PHONE_NUMBER
   WHERE t.result = util_pkg.c_ora_ok
     AND EXISTS(SELECT 1
                  FROM network_address_access_point naap
                 WHERE naap.network_address_id=t.network_address_id
                   AND v_SYSDATE BETWEEN naap.from_date AND nvl(naap.to_date,v_SYSDATE));

  UPDATE tt_batch_na_ap t
     SET t.sn =
         (SELECT pl.linked_msisdn
            FROM phone_link pl
           WHERE pl.main_msisdn=t.international_format)
   WHERE t.result = util_pkg.c_ora_ok;

  IF (p_linked_service_provider_code IS NOT NULL) THEN
  --processing linked phones
    UPDATE tt_batch_na_ap t
       SET t.result=RSIG_UTILS.c_PHONE_HAVE_NO_LINKED
     WHERE t.result = util_pkg.c_ora_ok
       AND t.sn IS NULL;

    UPDATE tt_batch_na_ap t
       SET t.result = RSIG_UTILS.c_SIM_INVALID_NET_OPER
     WHERE t.result = util_pkg.c_ora_ok
       AND NOT EXISTS
           (SELECT 1
              FROM PHONE_NUMBER pnl
              JOIN PHONE_SERIES_OPERATOR  psol
                ON psol.phone_number_series_id = pnl.phone_number_series_id
             WHERE psol.network_operator_id = v_linked_service_provider_id
               AND pnl.international_format = t.sn
               AND v_sysdate BETWEEN psol.start_date AND NVL(psol.end_date,v_sysdate));

    --check linked number status
    UPDATE tt_batch_na_ap t
       SET t.result=RSIG_UTILS.c_BAD_PHONE_STATUS
     WHERE t.result = util_pkg.c_ora_ok
       AND NOT EXISTS(SELECT 1
                        FROM PHONE_NUMBER pn
                       WHERE pn.net_address_status_code=p_phone_status_code
                         AND pn.International_Format=t.sn);

    --check linked number salability category
    IF p_salability_category IS NOT NULL THEN
      UPDATE tt_batch_na_ap t
         SET t.result=RSIG_UTILS.c_PHONE_INVALID_SAL_CAT
       WHERE t.result = util_pkg.c_ora_ok
         AND NOT EXISTS(SELECT 1
                          FROM PHONE_NUMBER pn
                         WHERE pn.salability_category_code=p_salability_category
                           AND pn.International_Format=t.sn);

    ELSE
      UPDATE tt_batch_na_ap t
         SET t.result=RSIG_UTILS.c_PHONE_INVALID_SAL_CAT
       WHERE t.result = util_pkg.c_ora_ok
         AND NOT EXISTS
             (SELECT 1
                FROM PHONE_NUMBER pn
                JOIN TABLE(CAST(v_allowed_sal_cat AS t_v2_60_obj_tab)) tsc
                  ON tsc.v2_60 = pn.salability_category_code
               WHERE pn.International_Format=t.sn);

    END IF;

    --check linked number have no linked SIM-card
    UPDATE tt_batch_na_ap t
       SET t.result=RSIG_UTILS.c_SIM_HAVE_PHONE_NUMBER
     WHERE t.result = util_pkg.c_ora_ok
       AND EXISTS(SELECT 1
                    FROM phone_number pn
                    LEFT JOIN network_address_access_point naap
                      ON naap.network_address_id=pn.network_address_id
                   WHERE pn.international_format = t.sn
                     AND v_SYSDATE BETWEEN naap.from_date AND nvl(naap.to_date,v_SYSDATE));

  ELSE
  --processing not linked phones
    --check if phone number have required type
    UPDATE tt_batch_na_ap t
       SET t.result=RSIG_UTILS.c_ORA_NOT_SAME_PHONE_TYPES
     WHERE t.result = util_pkg.c_ora_ok
       AND NOT EXISTS(SELECT 1
                        FROM PHONE_NUMBER pn
                        JOIN PHONE_NUMBER_SERIES pns ON pns.phone_number_series_id = pn.phone_number_series_id
                       WHERE pns.phone_number_type_code=p_phone_type_code
                         AND pn.International_Format=t.International_Format);

    UPDATE tt_batch_na_ap t
       SET t.result=RSIG_UTILS.c_PHONES_ALREADY_LINKED
     WHERE t.result = util_pkg.c_ora_ok
       AND t.sn IS NOT NULL;
  END IF;


  DELETE FROM tt_processed_phones_sims;
  DELETE FROM tt_rejected_phones_sims;

  INSERT INTO tt_processed_phones_sims(MAIN_MSISDN,LINKED_MSISDN)
  SELECT t.International_Format, t.sn
    FROM tt_batch_na_ap t
   WHERE t.result = util_pkg.c_ora_ok;

  INSERT INTO tt_rejected_phones_sims(MAIN_MSISDN,LINKED_MSISDN,RESULT)
  SELECT t.International_Format, t.sn, t.result
    FROM tt_batch_na_ap t
   WHERE t.result <> util_pkg.c_ora_ok;

  SELECT t.international_format
    BULK COLLECT INTO v_PN_l
    FROM tt_batch_na_ap t
   WHERE t.result = util_pkg.c_ora_ok;

  if v_pn_l.count <> 0
  then
    ------------------------------
    api_ri_pkg.Set_Phone_Status_i
    (
      p_msisdn => v_PN_l,
      p_set_phone_status => rsig_utils.c_RESERVE_PHONE_NUMBER_CODE,
      p_date => v_sysdate,
      p_user_id => v_user_id,
      p_break_on_error => false,
      p_lock_pn => true,
      p_error_code => v_error_code,
      p_error_message => v_error_message
    );
    ------------------------------
    delete tt_processed_phones_sims t
    where t.main_msisdn in
      (
      select /*+ use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
          q1.msisdn
        from
          (select column_value msisdn, rownum rn from table(cast(v_PN_l as ct_varchar_s))) q1,
          (select column_value error_code, rownum rn from table(cast(v_error_code as ct_number))) q2,
          (select column_value error_message, rownum rn from table(cast(v_error_message as ct_varchar))) q3
        where 1 = 1
        and q2.rn = q1.rn
        and q3.rn = q1.rn
        and q2.error_code <> util_pkg.c_ora_ok
      )
    ;
    ------------------------------
    INSERT INTO tt_rejected_phones_sims(MAIN_MSISDN,LINKED_MSISDN,RESULT)
      select /*+ use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
          q1.msisdn, null, q2.error_code
        from
          (select column_value msisdn, rownum rn from table(cast(v_PN_l as ct_varchar_s))) q1,
          (select column_value error_code, rownum rn from table(cast(v_error_code as ct_number))) q2,
          (select column_value error_message, rownum rn from table(cast(v_error_message as ct_varchar))) q3
        where 1 = 1
        and q2.rn = q1.rn
        and q3.rn = q1.rn
        and q2.error_code <> util_pkg.c_ora_ok
        order by q1.rn
    ;
    ------------------------------
  end if;

  CLOSE c_lock_phones;


  OPEN p_result_list FOR
    SELECT t.main_msisdn,
           t.linked_msisdn
      FROM tt_processed_phones_sims t;

  OPEN p_rejected_list FOR
    SELECT t.main_msisdn,
           t.linked_msisdn,
           t.result
      FROM tt_rejected_phones_sims t;

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  ---------------------------------------------------------------------------------------------------------
  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;

  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);

EXCEPTION
WHEN OTHERS THEN
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;

  OPEN p_result_list FOR SELECT p_error_code FROM dual;

  IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
    RAISE;
  END IF;

END PROD_CheckPhonesByList2;

-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Add_External_Phone
(
  p_international_format                IN  VARCHAR2,
  p_user_nt_name                        IN  VARCHAR2,
  p_handle_tran                         IN  CHAR,
  p_raise_error                         IN  CHAR,
  p_error_code                          OUT NUMBER,
  p_error_message                       OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PHONE_NUMBER.Add_External_Phone';
  v_PN_Serie_id           phone_number_series.phone_number_series_id%TYPE;
  v_network_adress_id     network_address.network_address_id%TYPE;
  v_counter               NUMBER;
  v_status_code           network_address_status_history.net_address_status_code%TYPE;
  v_NA_status_code        network_address_status_history.net_address_status_code%TYPE;
  v_SC_code               phone_number_salability_categ.salability_category_code%TYPE;
  v_Start_Date            DATE;
  v_date_of_change        DATE;

  v_host_id                 NUMBER;
  v_country_code            VARCHAR2(30);
  v_area_code               VARCHAR2(30);
  v_local_number_start      VARCHAR2(30);
  v_local_number_end        VARCHAR2(30);
  v_phone_number_type_code  VARCHAR2(30);
  v_user_id_of_change       NUMBER;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check handle_tran parameter
  IF (upper(p_handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (p_handle_tran IS NULL)) THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
  END IF;

  SELECT u.user_id INTO v_user_id_of_change
    FROM USERS u WHERE UPPER(u.login_name) = UPPER(p_user_nt_name);

  -- set savepoint
  IF (upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
      SAVEPOINT Add_External_Phone;
  END IF;

  -----------------------------------------------------------------------------------------------------------------------------------------------------
  v_SC_code := rsig_utils.c_STANDARD_SAL_CATEGORY;         --N - normal salability category
  v_Start_Date := SYSDATE;
  v_date_of_change := SYSDATE;

  BEGIN
    -- get phone number serie for current phone number
    SELECT pns.phone_number_series_id,
           pns.country_code,
           pns.area_code,
           pns.local_number_start,
           pns.local_number_end,
           trim(pns.phone_number_type_code),
           pns.host_id
    INTO v_PN_Serie_id,
         v_country_code,
         v_area_code,
         v_local_number_start,
         v_local_number_end,
         v_phone_number_type_code,
         v_host_id
    FROM phone_number_series pns
    WHERE p_international_format BETWEEN
          to_number(pns.country_code || pns.area_code || pns.local_number_start) AND
          to_number(pns.country_code || pns.area_code || pns.local_number_end)
      AND length(TRIM(pns.country_code || pns.area_code || pns.local_number_start)) =
          length(TRIM(p_international_format))
      AND pns.phone_number_type_code = rsig_utils.c_PHONE_TYPE_EXTERNAL
      AND pns.deleted IS NULL;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(rsig_utils.c_ORA_Phone_Serie_NOT_Exists,'Phone serie was not found.');
    WHEN TOO_MANY_ROWS THEN
      RAISE_APPLICATION_ERROR(rsig_utils.c_ORA_INTERVAL_INTERFERES_A,'Phone series are overlaped.');
  END;

  BEGIN
    -- find out if phone number already exist - its status code and network address id
    SELECT nash.net_address_status_code,
           pn.network_address_id
    INTO v_status_code,
         v_network_adress_id
    FROM phone_number pn
    JOIN network_address_status_history nash ON nash.network_address_id = pn.network_address_id
         AND v_Start_Date >= nash.start_date AND (v_Start_Date <= nash.end_date OR nash.end_date IS NULL)
    WHERE pn.international_format = p_international_format;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
    v_counter:=0;
  END;

  IF v_counter = 0 THEN
    -- Phone number not exist
    -- insert new phone number when it does not exist
    INSERT INTO network_address
           (network_address_id)
    VALUES(s_network_address.NEXTVAL)
    RETURNING network_address_id INTO v_network_adress_id;

    INSERT INTO phone_number
          (network_address_id,
           phone_number_series_id,
           international_format,
           date_of_change,
           user_id_of_change,
           deleted)
    VALUES(v_network_adress_id,
           v_PN_Serie_id,
           p_international_format,
           v_date_of_change,
           v_user_id_of_change,
           NULL);

    -- set new salability category
    INSERT INTO phone_number_salability_categ
          (salability_category_code,
           network_address_id,
           start_date,
           date_of_change,
           user_id_of_change,
           end_date)
    VALUES(v_SC_code,
           v_network_adress_id,
           v_Start_Date,
           v_date_of_change,
           v_user_id_of_change,
           NULL);

    --v_NA_status_code := rsig_utils.c_USED_PHONE_NUMBER_CODE;
    v_NA_status_code := rsig_utils.c_PHONE_STATUS_E;  --E - number is at external operator (network address status code)
    -- set new status history
    INSERT INTO network_address_status_history
          (net_address_status_code,
           network_address_id,
           start_date,
           date_of_change,
           user_id_of_change,
           end_date)
    VALUES(v_NA_status_code,
           v_network_adress_id,
           v_Start_Date,
           v_date_of_change,
           v_user_id_of_change,
           NULL);

 /* ELSE
    -- phone number already exist
    IF (TRIM(v_status_code) NOT IN (rsig_utils.c_PHONE_STATUS_E)) THEN
      -- phone number is not external
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_BAD_PHONE_STATUS,'Bad phone status.');
    ELSE
      -- terminate old status
      UPDATE network_address_status_history nash
      SET nash.end_date = v_Start_Date - rsig_utils.c_INTERVAL_DIFFERENCE
      WHERE nash.network_address_id = v_network_adress_id
        AND v_Start_Date >= nash.start_date AND (v_Start_Date <= nash.end_date OR nash.end_date IS NULL);

    v_NA_status_code := rsig_utils.c_USED_PHONE_NUMBER_CODE;
    END IF;*/

  END IF; /*

    v_NA_status_code := rsig_utils.c_USED_PHONE_NUMBER_CODE;
  -- set new status history
  INSERT INTO network_address_status_history
        (net_address_status_code,
         network_address_id,
         start_date,
         date_of_change,
         user_id_of_change,
         end_date)
  VALUES(v_NA_status_code,
         v_network_adress_id,
         v_Start_Date,
         v_date_of_change,
         p_user_id_of_change,
         NULL);*/

 /* v_last_6_symbol := substr(p_international_format, 7, 6);

  if v_local_number_start <> v_last_6_symbol
  then
      -- Call the procedure
      rsig_phone_number_series.split_phone_number_series(handle_tran             => RSIG_UTILS.c_NO,
                                                         error_code              => p_error_code,
                                                         p_phone_number_serie_id => v_PN_Serie_id,
                                                         p_start_phone_number    => p_international_format,
                                                         p_user_id_of_change     => p_user_id_of_change);
      -- Get new phone number series
      SELECT pn.phone_number_series_id
         INTO v_PN_Serie_id
          FROM phone_number pn
        WHERE 1 = 1
          AND pn.international_format = p_international_format
          AND pn.deleted IS NULL;
  End If;

  if v_local_number_end <> v_last_6_symbol
  then
      rsig_phone_number_series.split_phone_number_series(handle_tran             => RSIG_UTILS.c_NO,
                                                         error_code              => p_error_code,
                                                         p_phone_number_serie_id => v_PN_Serie_id,
                                                         p_start_phone_number    => to_char(to_number(p_international_format) + 1),
                                                         p_user_id_of_change     => p_user_id_of_change);
  End if;*/

  --UPDATE phone_number_series pns
  --   SET pns.host_id = v_host_id,
   --      pns.phone_number_type_code = rsig_utils.c_PHONE_TYPE_EXTERNAL
  -- WHERE pns.phone_number_series_id = v_PN_Serie_id;

  --UPDATE phone_series_operator pso
    -- SET pso.network_operator_id = v_network_operator_id
  --WHERE pso.phone_number_series_id = v_PN_Serie_id;

  -----------------------------------------------------------------------------------------------------------------------------------------------------
  IF upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;

  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);

EXCEPTION
WHEN OTHERS THEN
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;

  RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, v_event_source);

  CASE p_handle_tran
          WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Add_External_Phone;
          WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
          ELSE NULL;
  END CASE;

  IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
    RAISE;
  END IF;

END Add_External_Phone;

-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Add_External_Phones
(
  p_international_format                IN  t_phone_number_col,
  p_user_nt_name                        IN  VARCHAR2,
  p_handle_tran                           IN  CHAR,
  p_raise_error                         IN  CHAR,
  p_cursor                              OUT SYS_REFCURSOR,
  p_error_code                          OUT NUMBER,
  p_error_message                       OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PHONE_NUMBER.Add_External_Phones';

  v_error_code                NUMBER;
  v_error_message             VARCHAR2(1000);
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

-- check handle_tran parameter
    IF (upper(p_handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (p_handle_tran IS NULL)) THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
    END IF;

    -- set savepoint
    IF (upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
        SAVEPOINT Add_External_Phones;
    END IF;

  DELETE FROM TT_EXT_PHONE;

  IF (p_international_format.COUNT > 0)
  THEN
    FOR i IN p_international_format.first..p_international_format.last
    LOOP
      IF (p_international_format(i) IS NOT NULL)
      THEN
        v_error_code:= util_pkg.c_ora_ok;
        v_error_message:='';
        Add_External_Phone(p_international_format => p_international_format(i),
                            p_user_nt_name => p_user_nt_name,
                            p_handle_tran => RSIG_UTILS.c_HANDLE_TRAN_S,
                            p_raise_error => RSIG_UTILS.c_NO,
                            p_error_code => v_error_code,
                            p_error_message => v_error_message);

        INSERT INTO TT_EXT_PHONE(INTERNATIONAL_FORMAT,ERROR_CODE,ERROR_MESSAGE)
               VALUES(p_international_format(i),v_error_code,v_error_message);
      END IF;
    END LOOP;
  END IF;

  OPEN p_cursor FOR SELECT INTERNATIONAL_FORMAT,ERROR_CODE,ERROR_MESSAGE FROM TT_EXT_PHONE;

  -- commit
  IF upper(p_handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;

  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);

EXCEPTION
WHEN OTHERS THEN
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;

  RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, v_event_source);

  CASE p_handle_tran
          WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Add_External_Phones;
          WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
          ELSE NULL;
  END CASE;

  IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
    RAISE;
  END IF;

END Add_External_Phones;

-----------------------------------------------------------------------------------------------------------------------------------------------------
function Get_Network_Operatoe_By_Code(p_network_operator_code        IN  network_operator.network_operator_code%TYPE)
  return number
is
  v_cnt number;
  v_network_operator_id number;
begin
  SELECT COUNT(1) INTO v_cnt
    FROM NETWORK_OPERATOR no WHERE no.network_operator_code = TRIM(p_network_operator_code);

  v_network_operator_id:= NULL;
  IF (p_network_operator_code IS NOT NULL AND v_cnt = 0)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NET_OPERATOR_NOT_EXIST, 'Invalid network operator('''|| p_network_operator_code ||''').');
  END IF;

  IF v_cnt <> 0
  THEN
    SELECT no.network_operator_id INTO v_network_operator_id
      FROM NETWORK_OPERATOR no WHERE no.network_operator_code = TRIM(p_network_operator_code);
  END IF;

  return v_network_operator_id;

end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure ChangeReservePhoneList
(
    p_reserve_number number,
    p_select_msisdn_list util_pkg.cit_varchar_s,
    p_remove_msisdn_list util_pkg.cit_varchar_s,
    p_user_login varchar2,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor
)
is
  lc_no_value constant number := NULL;
  v_date date := sysdate;
  v_user_id number;
  v_remove boolean;
  --
  v_msisdns ct_varchar_s;
  v_na_ids ct_number;
  --
  v_msisdns_err ct_varchar_s;
  v_na_ids_err ct_number;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
  v_marks ct_number;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_reserve_number is null, 'p_reserve_number');
  util_pkg.XCheck_Cond_Missing(NOT util_pkg.CheckP_cit_varchar_s(p_select_msisdn_list, true) and NOT util_pkg.CheckP_cit_varchar_s(p_remove_msisdn_list, true), 'empty p_select_msisdn_list and empty p_remove_msisdn_list');
  util_pkg.XCheck_Cond_Missing(p_user_login is null, 'p_user_login');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.CheckP_cit_varchar_s(p_select_msisdn_list, true) and util_pkg.CheckP_cit_varchar_s(p_remove_msisdn_list, true), 'NOT empty p_select_msisdn_list and NOT empty p_remove_msisdn_list');
  ------------------------------
  v_user_id := util_ri.xget_user_id(p_user_login);
  ------------------------------
  v_remove := false;
  v_msisdns := util_pkg.cast_cit2ct_varchar_s(p_select_msisdn_list, true);
  ------------------------------
  if util_pkg.get_count_ct_varchar_s(v_msisdns) = 0
  then
    ------------------------------
    v_remove := true;
    v_msisdns := util_pkg.cast_cit2ct_varchar_s(p_remove_msisdn_list, true);
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FSU_ct_varchar_s(v_msisdns, 'v_msisdns');
  ------------------------------
  v_na_ids := util_ri.get_na_id(v_msisdns, v_date, FALSE);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_na_ids, lc_no_value);
  ------------------------------
  --!_!--!_!v_na_ids_err := util_pkg.get_marked_ct_number(v_na_ids, v_marks, TRUE);
  v_msisdns_err := util_pkg.get_marked_ct_varchar_s(v_msisdns, v_marks, TRUE);
  ------------------------------
  --!_!--!_!if util_pkg.get_count_ct_number(v_na_ids_err) > 0
  if util_pkg.get_count_ct_varchar_s(v_msisdns_err) > 0
  then
    ------------------------------
    --!_!--!_!v_msisdns_err := util_pkg.get_marked_ct_varchar_s(v_msisdns, v_marks, TRUE);
    --!_!v_na_ids_err := util_pkg.get_marked_ct_number(v_na_ids, v_marks, TRUE); --!_!same as next resize_ct_number + fill_ct_number(, lc_no_value) but implicit
    util_pkg.resize_ct_number(v_na_ids_err, util_pkg.get_count_ct_varchar_s(v_msisdns_err));
    util_pkg.fill_ct_number(v_na_ids_err, lc_no_value);
    --!_! It's ok, because the class FORIS.ResourceInventory.DataInterfaces.ResultList has no room for network address, only MSISDN.
    ------------------------------
    util_ext_ri.setup_common_error(util_pkg.get_count_ct_number(v_na_ids_err), util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found, v_error_codes, v_error_messages);
    ------------------------------
    util_pkg.raise_exception(util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found);
    ------------------------------
  end if;
  ------------------------------
  change_reserve_i
  (
    p_reserve_number => p_reserve_number,
    p_na_ids => v_na_ids,
    p_remove => v_remove,
    p_date => v_date,
    p_user_id => v_user_id,
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_error_na_ids => v_na_ids_err,
    p_error_code_det => v_error_codes,
    p_error_message_det => v_error_messages
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    ------------------------------
    v_msisdns_err := util_ri.get_msisdn(v_na_ids_err, v_date, false);
    ------------------------------
    util_pkg.raise_exception(p_error_code, p_error_message);
    ------------------------------
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
  open p_result_list for
  select /*+ ordered use_hash(q0, q1, q2, q3)*/
    q0.network_address_id, q1.msisdn, q2.error_code, q3.error_message
    from
      (select column_value network_address_id, rownum rn from table(v_na_ids_err)) q0,
      (select column_value msisdn, rownum rn from table(v_msisdns_err)) q1,
      (select column_value error_code, rownum rn from table(v_error_codes)) q2,
      (select column_value error_message, rownum rn from table(v_error_messages)) q3
    where 1 = 1
    and q1.rn(+) = q0.rn
    and q2.rn(+) = q0.rn
    and q3.rn(+) = q0.rn
    order by q0.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure change_reserve_i
(
    p_reserve_number number,
    p_na_ids ct_number,
    p_remove boolean,
    p_date date,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2,
    p_error_na_ids out ct_number,
    p_error_code_det out ct_number,
    p_error_message_det out ct_varchar
)
is
  v_batch batch%rowtype;
  v_na_ids ct_number;
  v_na_ids_rem ct_number;
  v_na_statuses ct_varchar_s;
  v_marks ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_reserve_number is null, 'p_reserve_number');
  --!_!util_pkg.XCheckP_ct_number(p_na_ids, 'p_na_ids');
  util_pkg.XCheckP_FSU_ct_number(p_na_ids, 'p_na_ids');
  util_pkg.XCheck_Cond_Missing(p_remove is null, 'p_remove');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_ri.xcheck_user_id(p_user_id);
  ------------------------------
  v_na_ids := util_ri.get_as_pnlnk_naid_fuzzy(p_na_ids, p_date);
  ------------------------------
  p_error_na_ids := util_ri.get_pnlnk_not_found2(p_na_ids, v_na_ids);
  ------------------------------
  if util_pkg.get_count_ct_number(p_error_na_ids) > 0
  then
    ------------------------------
    util_ext_ri.setup_common_error(util_pkg.get_count_ct_number(p_error_na_ids), util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found, p_error_code_det, p_error_message_det);
    ------------------------------
    p_error_code := util_loc_pkg.c_ora_phone_not_found;
    p_error_message := util_loc_pkg.c_msg_phone_not_found;
    ------------------------------
    RETURN;
    ------------------------------
  end if;
  ------------------------------
  v_batch := vp_batch.xlock_get1(p_reserve_number); --!_! lock batch
  ------------------------------
  if v_batch.batch_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_reserve_number));
  end if;
  ------------------------------
  if p_remove
  then
    ------------------------------
    v_na_ids_rem := v_na_ids;
    ------------------------------
  else
    ------------------------------
    v_na_ids_rem := batch_pkg.get_batch_details(p_reserve_number, FALSE);  --!_! not lock batch - already locked
    ------------------------------
    v_na_ids_rem := util_pkg.filter_val_ct_number(v_na_ids_rem, v_na_ids, FALSE);
    ------------------------------
    p_error_na_ids := util_ri.check_na_id(v_na_ids_rem, p_date, TRUE, TRUE);
    ------------------------------
    if util_pkg.get_count_ct_number(p_error_na_ids) > 0
    then
      ------------------------------
      util_ext_ri.setup_common_error(util_pkg.get_count_ct_number(p_error_na_ids), util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found, p_error_code_det, p_error_message_det);
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_phone_not_found;
      p_error_message := util_loc_pkg.c_msg_phone_not_found;
      ------------------------------
      RETURN;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  if util_pkg.get_count_ct_number(v_na_ids_rem) > 0
  then
    ------------------------------
    v_na_statuses := util_ri.get_na_status(v_na_ids_rem, p_date, false);
    ------------------------------
    v_marks := util_pkg.mark_val_ct_varchar_s(v_na_statuses, util_ri.c_NASH_CODE_RESERVE, util_pkg.C_FALSE, util_pkg.C_TRUE); --!_! reverse marking
    ------------------------------
    p_error_na_ids := util_pkg.get_marked_ct_number(v_na_ids_rem, v_marks, TRUE);
    ------------------------------
    if util_pkg.get_count_ct_number(p_error_na_ids) > 0
    then
      ------------------------------
      util_ext_ri.setup_common_error(util_pkg.get_count_ct_number(p_error_na_ids), util_loc_pkg.c_ora_wrong_na_status, util_loc_pkg.c_msg_wrong_na_status, p_error_code_det, p_error_message_det);
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_wrong_na_status;
      p_error_message := util_loc_pkg.c_msg_wrong_na_status;
      ------------------------------
      RETURN;
      ------------------------------
    end if;
    ------------------------------
    if NOT util_ext_ri.del_na_status2
    (
      p_na_id => v_na_ids_rem,
      p_date => p_date,
      p_user_id => p_user_id,
      p_break_on_error => TRUE,
      p_lock_pn => TRUE,
      p_silent_prev_lack => FALSE,
      p_error_code => p_error_code_det,
      p_error_message => p_error_message_det
    )
    then
      ------------------------------
      p_error_na_ids := v_na_ids_rem;
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_status_changing_failed;
      p_error_message := util_loc_pkg.c_msg_status_changing_failed;
      ------------------------------
    end if;
    ------------------------------
    batch_pkg.na_res_batch_remove_from(v_na_ids_rem, p_user_id);
    ------------------------------
  end if;
  ------------------------------
  batch_pkg.na_res_batch_del_smart(p_reserve_number, p_user_id);
  ------------------------------
  --!_!util_ext_ri.setup_common_error(util_pkg.get_count_ct_number(p_na_ids), util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_code_det, p_error_message_det);
  p_error_code_det := null;
  p_error_message_det := null;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  RETURN;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE ResetPhoneNumberReserve(
  p_user_login                   IN  VARCHAR2,
  p_reserve_number               IN  NUMBER,
  p_handle_tran                   IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error                   IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                   OUT NUMBER,
  p_error_message                 OUT VARCHAR2,
  p_result_list                  OUT SYS_REFCURSOR
)
IS
  v_package_name                 VARCHAR2(30) := 'RSIG_PHONE_NUMBER';
  v_procedure_name               VARCHAR2(30) := 'ResetPhoneNumberReserve';
  v_event_source                 VARCHAR2(60);
  v_message                      VARCHAR2(32767);

  v_user_id number;
  v_batch batch%rowtype;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check existence of user
  v_user_id := Rsig_users.Get_user_id_by_login(p_user_login);

  -- check input parameters
  IF p_reserve_number IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters(p_reserve_number).');
  END IF;

  v_batch := vp_batch.get1(p_reserve_number);

  IF (v_batch.batch_id is null)THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid parameter(p_reserve_number).');
  END IF;

  batch_pkg.XCheck_na_res_batch_type(v_batch.batch_type);
  -----------------------------------------------------------------------------------------------------------------------------------------------------
  ResetPhoneNumberReserveInt(v_user_id, p_reserve_number);

  -- result set
  OPEN p_result_list FOR
  SELECT t.network_address_id,
         t.msisdn,
         t.error_code,
         t.error_message
  FROM TT_FOUND_PHONE_NUMBERS t;

  -----------------------------------------------------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);

EXCEPTION
WHEN OTHERS THEN
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  IF p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    rollback;
  END IF;

  IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
    RAISE;
  END IF;

END ResetPhoneNumberReserve;
-----------------------------------------------------------------------------------------------------------------------------------------------------

PROCEDURE ResetPhoneNumberReserveInt(
  p_user_id                      IN  NUMBER,
  p_reserve_number               IN  NUMBER
)
IS
  v_pn_l                         ct_varchar_s;
  v_NA_l                         ct_number;

  v_tmp_object_id ct_number;
  v_length number;
BEGIN
  ------------------------------
  v_NA_l := batch_pkg.get_batch_details(p_reserve_number, TRUE);
  ------------------------------
  DELETE FROM TT_FOUND_PHONE_NUMBERS;
  ------------------------------
  if v_NA_l.count > 0
  then
    FOR i IN v_NA_l.first..v_NA_l.last
    LOOP
      INSERT INTO TT_FOUND_PHONE_NUMBERS(NETWORK_ADDRESS_ID, ERROR_CODE)
           VALUES(v_NA_l(i), util_pkg.c_ora_ok);
    END LOOP;
  end if;
  ------------------------------
  UPDATE TT_FOUND_PHONE_NUMBERS tt
     SET (tt.msisdn,
          tt.salability_category_code,
          tt.net_address_status_code) = (SELECT /*+ index(pn PK_PHONE_NUMBER)*/
                                                pn.international_format as msisdn,
                                                pn.salability_category_code,
                                                pn.net_address_status_code
                                           FROM PHONE_NUMBER pn
                                          WHERE pn.network_address_id = tt.network_address_id);

  UPDATE TT_FOUND_PHONE_NUMBERS tt
     SET tt.error_code = RSIG_UTILS.c_ORA_PHONE_NUMBER_NOT_EXISTS,
         tt.error_message = 'Phone number not exist'
   WHERE tt.msisdn IS NULL AND tt.error_code = util_pkg.c_ora_ok;

  UPDATE TT_FOUND_PHONE_NUMBERS tt
     SET tt.error_code = RSIG_UTILS.c_ORA_WRONG_PH_STATUS,
         tt.error_message = 'Invalid network address status'
   WHERE tt.net_address_status_code <> RSIG_UTILS.c_RESERVE_PHONE_NUMBER_CODE AND tt.error_code = util_pkg.c_ora_ok;

  SELECT /*+ordered use_nl(tt pn) full(tt) index(pn PK_PHONE_NUMBER)*/
         pn.international_format
    BULK COLLECT INTO v_pn_l
    FROM TT_FOUND_PHONE_NUMBERS tt
    JOIN PHONE_NUMBER pn ON pn.network_address_id = tt.network_address_id
   WHERE tt.error_code = util_pkg.c_ora_ok
    FOR UPDATE OF pn.NETWORK_ADDRESS_ID NOWAIT;

  ------------------------------
  ------------------------------
  v_tmp_object_id := batch_pkg.get_batch_details(p_reserve_number, TRUE);
  ------------------------------
  v_length := util_pkg.get_count_ct_number(v_tmp_object_id);
  ------------------------------
  if v_length > 0
  then
    ------------------------------
    batch_pkg.na_res_batch_remove_from(v_tmp_object_id, p_user_id);
    ------------------------------
  end if;
  ------------------------------
  batch_pkg.na_res_batches_del2_plain(p_reserve_number, p_user_id);
  ------------------------------
  ------------------------------
  delete from tt_batch_na_ap;
  ------------------------------
  if util_pkg.get_count_ct_varchar_s(v_pn_l) > 0
  then
    ------------------------------
    Phone_Number_Pck.delete_last_open_previous_int
    (
      p_msisdn => v_pn_l,
      p_user_id => p_user_id
    );
    ------------------------------
  end if;
  ------------------------------
  ------------------------------

  UPDATE TT_FOUND_PHONE_NUMBERS tt
     SET (tt.error_code , tt.error_message) = (SELECT t.result, 'Unable to change network address status'
                                                 FROM tt_batch_na_ap t
                                                WHERE t.international_format = tt.msisdn AND
                                                      t.result<>util_pkg.c_ora_ok)
   WHERE EXISTS(SELECT * FROM tt_batch_na_ap t1 WHERE t1.international_format = tt.msisdn AND t1.result<>util_pkg.c_ora_ok);

END;
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE ResetPhoneNumberReserves(
  p_user_login                   IN  VARCHAR2,
  p_reserve_numbers              IN  common.t_number,
  p_error_code                   OUT NUMBER,
  p_error_message                 OUT VARCHAR2,
  p_result_list                  OUT SYS_REFCURSOR
)
IS
  v_package_name                 VARCHAR2(30) := 'RSIG_PHONE_NUMBER';
  v_procedure_name               VARCHAR2(30) := 'ResetPhoneNumberReserve';
  v_event_source                 VARCHAR2(60);
  v_message                      VARCHAR2(32767);
  v_result_list                  SYS_REFCURSOR;

  v_error_code                   number;
  v_error_message                VARCHAR2(1000);
begin

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF p_reserve_numbers IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters(p_reserve_number).');
  END IF;

  -----------------------------------------------------------------------------------------------------------------------------------------------------
  delete from tt_reserve_batch;

  for i in nvl(p_reserve_numbers.first,1)..nvl(p_reserve_numbers.last,0)
  loop
    savepoint sp_resetphonenumberreserves;

    ResetPhoneNumberReserve(p_user_login => p_user_login,
                            p_reserve_number => p_reserve_numbers(i),
                            p_handle_tran => rsig_utils.c_NO,
                            p_raise_error => rsig_utils.c_NO,
                            p_error_code => v_error_code,
                            p_error_message => v_error_message,
                            p_result_list => v_result_list);

    if (v_result_list%isopen)
    then
       CLOSE v_result_list;
    end if;

    if (v_error_code <> util_pkg.c_ora_ok) then
      rollback to savepoint sp_resetphonenumberreserves;
    end if;

    insert into tt_reserve_batch(batch_id,error_code,error_message)
      values (p_reserve_numbers(i), v_error_code, v_error_message);
  end loop;

  open p_result_list for
    select /*+ full(tt)*/
           tt.batch_id,
           tt.error_code,
           tt.error_message
      from tt_reserve_batch tt
     where tt.error_code <> util_pkg.c_ora_ok;

  -----------------------------------------------------------------------------------------------------------------------------------------------------
  COMMIT;

  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;

  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);

EXCEPTION
WHEN OTHERS THEN
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;

  rollback;

end;

-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE ReservePhoneResetPeriodReserve(
  p_reserve_numbers              IN  util_pkg.cit_number,
  p_error_code                   OUT NUMBER,
  p_error_message                OUT VARCHAR2,
  p_result_list                  OUT SYS_REFCURSOR
)
IS
  v_user_id number;
  v_main_length number;
  v_batch_id ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_reserve_numbers is null, 'p_reserve_numbers');
  ------------------------------
  v_batch_id := util_pkg.cast_cit2ct_number(p_reserve_numbers, FALSE);
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(v_batch_id, 'v_batch_id');
  ------------------------------
  v_main_length := util_pkg.get_count_ct_number(v_batch_id);
  util_pkg.resize_ct_number(v_error_code, v_main_length);
  util_pkg.resize_ct_varchar(v_error_message, v_main_length);
  ------------------------------
  v_user_id := util_ri.xget_default_user_id; --!_!
  ------------------------------
  for v_i in 1..v_main_length
  loop
    savepoint sp_resetphonenumberreserves;
    ------------------------------
    util_pkg.set_ok(v_error_code(v_i), v_error_message(v_i));
    ------------------------------
    begin
      ------------------------------
      batch_pkg.na_res_batch_upd_date_to(v_batch_id(v_i), util_pkg.c_plus_infinity, v_user_id);
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(v_error_code(v_i), v_error_message(v_i));
      ------------------------------
    end;
    ------------------------------
    if (v_error_code(v_i) <> util_pkg.c_ora_ok) then
      rollback to savepoint sp_resetphonenumberreserves;
    end if;
    ------------------------------
  end loop;
  ------------------------------
  open p_result_list for
    select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
           q1.batch_id,
           q2.error_code,
           q3.error_message
      from
        (select column_value batch_id, rownum rn from table(v_batch_id)) q1,
        (select column_value error_code, rownum rn from table(v_error_code)) q2,
        (select column_value error_message, rownum rn from table(v_error_message)) q3
      where 1 = 1
      and q2.rn = q1.rn
      and q3.rn = q1.rn
      and q2.error_code <> util_pkg.c_ora_ok
      order by q1.rn
  ;
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

-----------------------------------------------------------------------------------------------------------------------------------------------------
procedure SetPhoneStatusWithCheck(
  p_msisdn_list              Common.t_international_format,
  p_start_date               date,
  p_phone_number_status_code varchar2,
  p_set_phone_number_status  varchar2,
  p_user_login               varchar2,
  p_error_code               out number,
  p_error_message             out varchar2,
  p_result                   out sys_refcursor
  )
  is
  v_package_name                 VARCHAR2(30) := 'RSIG_PHONE_NUMBER';
  v_procedure_name               VARCHAR2(30) := 'SetPhoneStatusWithCheck';
  v_event_source                 VARCHAR2(60);
  v_message                      VARCHAR2(32767);
  v_phone_list                   ct_varchar_s;

  v_user_id number;
  v_error_code ct_number;
  v_error_message ct_varchar;
  begin

    v_event_source:=v_package_name || '.' || v_procedure_name;

    -- log start of procedure
    Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);


    v_user_id := util_ri.xget_user_id(p_user_login);

    delete from tt_found_phone_numbers;

    forall i in nvl(p_msisdn_list.first,1)..nvl(p_msisdn_list.last,0)
      insert into tt_found_phone_numbers(msisdn,error_code, error_message)
        values(p_msisdn_list(i), rsig_utils.c_PHONE_NUMBER_NOT_EXISTS, 'Phone number not exist');

    update tt_found_phone_numbers tt
      set (tt.network_address_id, tt.salability_category_code,tt.net_address_status_code) =
        (select /*+ index(pn UK_PHONE_NUM_PHONE_NUMBER)*/
                pn.network_address_id, pn.salability_category_code, pn.net_address_status_code
           from phone_number pn
          where pn.international_format = tt.msisdn
            and pn.deleted is null);

    update tt_found_phone_numbers tt
       set tt.error_code = util_pkg.c_ora_ok
     where tt.network_address_id is not null;

    update tt_found_phone_numbers tt
       set tt.error_code = rsig_utils.c_ORA_NOT_VALID_STATUS,
           tt.error_message = 'Not valid status'
     where 1 = 1
       and tt.error_code = util_pkg.c_ora_ok
       and (tt.net_address_status_code is null or p_phone_number_status_code is null or tt.net_address_status_code <> p_phone_number_status_code);

    select tt.msisdn
      bulk collect into v_phone_list
      from tt_found_phone_numbers tt
     where 1 = 1
       and tt.error_code = util_pkg.c_ora_ok;

    if (v_phone_list.count > 0)
    then
      ------------------------------
      api_ri_pkg.Set_Phone_Status_i
      (
        p_msisdn => v_phone_list,
        p_set_phone_status => p_set_phone_number_status,
        p_date => p_start_date,
        p_user_id => v_user_id,
        p_break_on_error => false,
        p_lock_pn => true,
        p_error_code => v_error_code,
        p_error_message => v_error_message
      );
      ------------------------------
      update /*+ index(tt i_tt_fpn_msisdn)*/ tt_found_phone_numbers tt
         set (tt.error_code, tt.error_message) =
              (
                select /*+ use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
                    q2.error_code, q3.error_message
                  from
                    (select column_value msisdn, rownum rn from table(cast(v_phone_list as ct_varchar_s))) q1,
                    (select column_value error_code, rownum rn from table(cast(v_error_code as ct_number))) q2,
                    (select column_value error_message, rownum rn from table(cast(v_error_message as ct_varchar))) q3
                  where 1 = 1
                  and q2.rn = q1.rn
                  and q3.rn = q1.rn
                  and q1.msisdn = tt.msisdn
              )
       where tt.msisdn in (
                    select /*+ use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
                        q1.msisdn
                      from
                        (select column_value msisdn, rownum rn from table(cast(v_phone_list as ct_varchar_s))) q1,
                        (select column_value error_code, rownum rn from table(cast(v_error_code as ct_number))) q2,
                        (select column_value error_message, rownum rn from table(cast(v_error_message as ct_varchar))) q3
                      where 1 = 1
                      and q2.rn = q1.rn
                      and q3.rn = q1.rn
                   )
         and tt.error_code = util_pkg.c_ora_ok;
      ------------------------------
    end if;

    open p_result for
      select tt.msisdn,
             case
               when tt.error_code = util_pkg.c_ora_ok then
                 0
               else
                 -1
             end result
        from tt_found_phone_numbers tt;

    commit;

    p_error_code := util_pkg.c_ora_ok;
    p_error_message := util_pkg.c_msg_ok;

  exception
  when others then
    p_error_code := util_pkg.get_err_code;
    p_error_message := util_pkg.get_err_msg;

    select tt.msisdn
      bulk collect into v_phone_list
      from tt_found_phone_numbers tt;

    rollback;

    forall i in nvl(v_phone_list.first,1)..nvl(v_phone_list.last,0)
      insert into tt_found_phone_numbers(msisdn)
        values(v_phone_list(i));

    open p_result for
      select tt.msisdn,
             -1 result
        from tt_found_phone_numbers tt;
  end;



----------------------------------------------------------------------------------------------------------------------------------------------------
--  Insert_RIF_Phones LT 462456
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_RIF_Phones(p_first_num          IN  VARCHAR2,
                            p_last_num           IN  VARCHAR2,
                            p_operator_code      IN  network_operator.network_operator_code%TYPE,
                            p_pn_type_code       IN  phone_number_series.phone_number_type_code%TYPE,
                            p_handle_tran        IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
                            p_raise_error        IN  CHAR DEFAULT rsig_utils.c_NO,
                            p_error_code         OUT NUMBER,
                            p_error_message      OUT VARCHAR2)
IS
  c_rus_country_code    CONSTANT VARCHAR2(1) := '7';
  c_ri_setting_name     CONSTANT ri_settings.setting_name%TYPE := 'INSERT_RIF_PHONE_SERIE_TO_RI';

  v_package_name        varchar2(30) := 'RSIG_PHONE_NUMBER' ;
  v_procedure_name      varchar2(30) := 'Insert_RIF_Phones';
  v_event_source        varchar2(60) := v_package_name||'.'||v_procedure_name;

  v_message             varchar2(32767);
  v_pn_serie_id         phone_number_series.phone_number_series_id%TYPE;
  v_country_code        phone_number_series.country_code%TYPE;
  v_area_code           phone_number_series.area_code%TYPE;
  v_local_start         phone_number_series.local_number_start%TYPE;
  v_local_end           phone_number_series.local_number_end%TYPE;
  v_network_operator_id network_operator.network_operator_id%TYPE;
  v_set_salability      varchar2(1);
  v_date                date    := SYSDATE;
  v_user_id             integer := 1;
BEGIN

  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF NOT(INSTALL_PKG.GET_OPTION_BOOL(p_option_name => c_ri_setting_name, p_default => TRUE))THEN
     RETURN;
  END IF;

  -- V- Numbers of virtual phone number capacity, mask - 70BBBXXXXXX, where: 7–country code (RF),
  --                                                                  0–constant,
  --                                                                  BBB – region code,
  --                                                                  XXXXXX
  -- Fx- Numbers of fix phone number capacity, mask - 7ABC, where: 7–country code (RF),
  --                                                         ABC– national destination code + phone number, 10 chars
  IF(length(p_first_num)!= 11
     OR length(p_last_num)!= 11
     OR substr(p_first_num, 1, 1) != c_rus_country_code
     OR substr(p_last_num, 1, 1) != c_rus_country_code
     OR Trim(p_operator_code) IS NULL
     OR Trim(p_pn_type_code) IS NULL
     OR Upper(p_pn_type_code) NOT IN('FX', 'V')
    )
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  v_country_code := substr(p_first_num, 1, 1);

  CASE Upper(p_pn_type_code)
    WHEN 'V' THEN
         v_area_code := substr(p_first_num, 2, 4);
         v_local_start := substr(p_first_num, 6, 6);
         v_local_end := substr(p_last_num, 6, 6);
         v_set_salability := 'N';

    WHEN 'FX' THEN
         v_area_code := substr(p_first_num, 2, 3);
         v_local_start := substr(p_first_num, 5, 7);
         v_local_end := substr(p_last_num, 5, 7);
         v_set_salability := 'Y';
  ELSE
     RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END CASE;

  RSIG_NETWORK_OPERATOR.Get_Net_Op_Id_By_Code(
    p_Error_Code            => p_error_code,
    p_Error_Message         => p_error_message,
    p_Network_Operator_Id   => v_network_operator_id,
    p_Network_Operator_Code => p_operator_code
  );

  IF p_error_code != util_pkg.c_ora_ok THEN--'Error in call RSIG_NETWORK_OPERATOR.Get_Net_Op_Code_By_Id',
    UTIL_PKG.RAISE_EXCEPTION( rsig_utils.c_ORA_operator_not_exist, p_error_code || util_pkg.c_msg_delim01|| p_error_message);
  END IF;

  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;

  RSIG_PHONE_NUMBER_SERIES.Insert_Phone_Number_Series( p_phone_number_type_code  => p_pn_type_code,                        -- phone number type code of the given serie of phone numbers
                                                       p_phone_num_status_code   => RSIG_UTILS.c_FREE_PHONE_NUMBER_CODE,
                                                       p_country_code            => v_country_code,                        -- country code of given phone number serie
                                                       p_area_code               => v_area_code,                           -- area code of given phone number serie
                                                       p_starting_local_number   => v_local_start,                         -- starting local phone number of new phone number serie
                                                       p_ending_local_number     => v_local_end,                           -- ending local phone number of new phone number serie
                                                       p_network_operator_id     => v_network_operator_id,                 -- id of the network operator who will own this new inserted serie
                                                       p_start_date              => v_date,                                -- the date since when given network operator owns this new inserted serie
                                                       p_host_id                 => NULL,
                                                       p_subhost_id              => NULL,
                                                       p_set_gold                => v_set_salability,                      -- "Y" means, that salability category should be set according to set masks, "N" means, that salability category should be set to "standard
                                                       p_create_phones           => util_pkg.c_true,
                                                       p_user_id                 => v_user_id,
                                                       p_handle_tran             => RSIG_UTILS.c_HANDLE_TRAN_N,
                                                       p_raise_error             => RSIG_UTILS.c_YES,
                                                       p_phone_serie_id          => v_pn_serie_id,
                                                       p_error_code              => p_error_code,
                                                       p_error_message           => p_error_message
                                                      );

  IF(p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
WHEN OTHERS THEN
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;

  IF(p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y)THEN
    ROLLBACK;
  END IF;

  IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
    RAISE;
  END IF;

END Insert_RIF_Phones;

END;
/
