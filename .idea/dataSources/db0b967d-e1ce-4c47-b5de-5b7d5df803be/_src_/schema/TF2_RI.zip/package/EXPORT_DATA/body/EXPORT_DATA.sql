CREATE PACKAGE BODY          "EXPORT_DATA" AS

----------------------------------------------------------------------------
--  Auxiliary function enwrap_text
----------------------------------------------------------------------------

FUNCTION enwrap_text (p_original_text  VARCHAR2)
  RETURN VARCHAR2
IS
BEGIN
  RETURN('''''''''||'||'REPLACE('||p_original_text||','''''''','''''''''''')'||'||''''''''');
END enwrap_text;

----------------------------------------------------------------------------
--  Auxiliary function enwrap_date
----------------------------------------------------------------------------

FUNCTION enwrap_date (p_original_text  VARCHAR2)
  RETURN VARCHAR2
IS
BEGIN
  RETURN('REPLACE(''to_date(''''''||to_char('||p_original_text||',''DD/MM/YYYY HH24:MI:SS'')||'''''',''''DD/MM/YYYY HH24:MI:SS'''')'',''to_date('''''''',''''DD/MM/YYYY HH24:MI:SS'''')'','''''''''''')' );
END enwrap_date;


----------------------------------------------------------------------------
--  Auxiliary function Export_Data
----------------------------------------------------------------------------

PROCEDURE Export_Data(
  p_table_name    IN  VARCHAR2,
  p_join          IN  VARCHAR2,
  p_where         IN  VARCHAR2,
  p_result        OUT CLOB
  )
IS
  CURSOR columns_cursor(TABLE_NAME VARCHAR2) IS
    SELECT column_name,
           data_type
      FROM user_tab_columns
      WHERE user_tab_columns.table_name = columns_cursor.TABLE_NAME;

  -- variables
  v_column_list              VARCHAR2(20000);
  v_select_columns           VARCHAR2(20000);
  v_insert_statement         VARCHAR2(20000);
  v_select                   VARCHAR2(20000);
  v_current_schema           VARCHAR2(2000);
  v_current_db               VARCHAR2(2000);
  v_current_user             VARCHAR2(2000);
  v_create_insert_statement  sys_refcursor;

BEGIN
    v_column_list := NULL;
    v_select_columns := NULL;
    FOR v_col IN columns_cursor(p_table_name) LOOP
      v_column_list := v_column_list||','||v_col.column_name;
      v_select_columns := v_select_columns||'||'',''||'||
                          CASE v_col.column_name
--                            WHEN p_table_name||'_ID' THEN '''S_'||p_table_name||'.NEXTVAL'''  !!! it not works for depent catalogues
                            WHEN 'USER_ID_OF_CHANGE' THEN c_user_id_of_change
                            WHEN 'DATE_OF_CHANGE' THEN '''SYSDATE'''
                            ELSE CASE v_col.data_type
                                   WHEN 'DATE' THEN enwrap_date(p_original_text=>p_table_name||'.'||v_col.column_name)
                                   ELSE             enwrap_text(p_original_text=>p_table_name||'.'||v_col.column_name)
                                 END
                          END
                          ;
    END LOOP;
    v_insert_statement := '''insert into '
                          ||p_table_name
                          ||'('
                          ||substr(v_column_list,2)
                          ||') values (''||'
                          ;
    v_select := 'select '
                ||v_insert_statement
                ||substr(v_select_columns,8)
                ||'||'')'''
                ||' from '
                ||p_table_name
                ||' '
                ||p_join
                ||' '
                ||' where '
                ||nvl(p_where,'1=1');

    OPEN v_create_insert_statement FOR v_select;
    LOOP
      FETCH v_create_insert_statement INTO v_insert_statement;
      EXIT WHEN v_create_insert_statement%NOTFOUND;
      p_result := p_result
                 ||CHR(10)
                 ||v_insert_statement
                 ||CHR(10)
                 ||'/';
    END LOOP;
    p_result := p_result||CHR(10);

  select SYS_CONTEXT('userenv', 'CURRENT_SCHEMA'), SYS_CONTEXT('userenv', 'DB_NAME'), SYS_CONTEXT('userenv', 'OS_USER')
    INTO v_current_schema, v_current_db, v_current_user
    from dual;

  p_result := '--Export of table '||p_table_name||' from '
              ||v_current_schema
              ||' on database '
              ||v_current_db
              ||' made by '
              ||v_current_user
              ||' at '
              ||to_char(SYSDATE,'DD/MM/YYYY HH24:MI:SS')
              ||chr(10)
              ||p_result
              ||chr(10);

END Export_Data;

----------------------------------------------------------------------------
--  export_sim_series
----------------------------------------------------------------------------

PROCEDURE export_sim_series (
  p_sim_series       IN  INT,
  p_result_script    OUT CLOB
  )
IS
  v_procedure_output   CLOB := NULL;
BEGIN
  IF p_sim_series IS NULL THEN
    raise_application_error(rsig_utils.c_ORA_MISSING_PARAMETER,'SIM series id must to be specified!');
  END IF;
  -- export of sim_series table
  export_data(p_table_name => 'SIM_SERIES',
              p_join => NULL,
              p_where => 'SIM_SERIES_ID = '||p_sim_series,
              p_result => v_procedure_output);
  p_result_script := p_result_script||v_procedure_output;
  -- export of sim_series_status_validity
  export_data(p_table_name => 'SIM_SERIES_STATUS_VALIDITY',
              p_join => NULL,
              p_where => 'SIM_SERIES_ID = '||p_sim_series,
              p_result => v_procedure_output);
  p_result_script := p_result_script||v_procedure_output;
  -- export of access_point
  export_data(p_table_name => 'ACCESS_POINT',
              p_join => 'JOIN SIM_CARD ON SIM_CARD.ACCESS_POINT_ID = ACCESS_POINT.ACCESS_POINT_ID',
              p_where => 'SIM_CARD.SIM_SERIES_ID = '||p_sim_series,
              p_result => v_procedure_output);
  p_result_script := p_result_script||v_procedure_output;
  -- export of access_point
  export_data(p_table_name => 'ACCESS_POINT_STATUS_HISTORY',
              p_join => 'JOIN SIM_CARD ON SIM_CARD.ACCESS_POINT_ID = ACCESS_POINT_STATUS_HISTORY.ACCESS_POINT_ID',
              p_where => 'SIM_CARD.SIM_SERIES_ID = '||p_sim_series,
              p_result => v_procedure_output);
  p_result_script := p_result_script||v_procedure_output;
  -- export of sim_cards
  export_data(p_table_name => 'SIM_CARD',
              p_join => NULL,
              p_where => 'SIM_SERIES_ID = '||p_sim_series,
              p_result => v_procedure_output);
  p_result_script := p_result_script||v_procedure_output;
END;

END EXPORT_DATA;
/
