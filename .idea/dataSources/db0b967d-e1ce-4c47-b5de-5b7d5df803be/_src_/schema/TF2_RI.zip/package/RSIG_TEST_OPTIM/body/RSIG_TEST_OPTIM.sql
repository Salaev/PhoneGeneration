CREATE PACKAGE BODY          "RSIG_TEST_OPTIM" is

PROCEDURE Get_Phones_By_SIM_list (
 p_ACCESS_POINT_DESC  IN T_VAR2_255,
 p_DATE_TIME    IN T_DATE,
-- p_NETWORK_ADDRESS_DESC IN T_VAR2_255,
 result_list             OUT sys_refcursor,
 error_code              OUT NUMBER
)
IS
BEGIN

  RSIG_UTILS.Debug_Rsi (p_Text => RSIG_UTILS.c_DEBUG_TEXT_START,
                        p_Level => RSIG_UTILS.c_DEBUG_LEVEL_1,
                        p_Event_Type => RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                        p_Event_Source => 'INTERFACE_FOR_SUPS.Get_Phones_For_SIM_list'
                       );

  error_code := rsig_utils.c_ok;
--dodelat test zda jsou stejne velka vstupni collections
---  Exist_Batch_Session_Id(p_batch_session_id);
 DELETE tt_interface_for_sups_NA_AP;

    dbms_output.put_line('Start for all: '||to_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI:SS'));
   FORALL i IN nvl(p_ACCESS_POINT_DESC.FIRST,1) .. nvl(p_ACCESS_POINT_DESC.LAST,0)
    INSERT INTO tt_interface_for_sups_NA_AP(ACCESS_POINT_DESC,DATE_TIME,NETWORK_ADDRESS_DESC)
     SELECT p_ACCESS_POINT_DESC(i),nvl(p_DATE_TIME(i),sysdate),NULL
     FROM dual;
 dbms_output.put_line('Start of update: '||to_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI:SS'));

 UPDATE tt_interface_for_sups_NA_AP tt
  SET (tt.network_address_desc/*,tt.date_time*/) =
  (SELECT p.international_format/*,nvl(tt.date_time,SYSDATE)*/
   FROM SIM_CARD sc
   JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON sc.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
   JOIN PHONE_NUMBER p ON naap.NETWORK_ADDRESS_ID = p.NETWORK_ADDRESS_ID
   WHERE 1=1
      AND sc.IMSI = tt.ACCESS_POINT_DESC
         AND nvl(tt.date_time,SYSDATE) BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE,nvl(tt.date_time,SYSDATE))
   AND naap.LINK_TYPE_CODE = c_MAIN_LINK_TYPE);



/*  INSERT INTO tt_interface_for_sups_NA_AP(ACCESS_POINT_DESC,DATE_TIME,NETWORK_ADDRESS_DESC)
    SELECT t.ACCESS_POINT_DESC,t.DATE_TIME, p.INTERNATIONAL_FORMAT  --p.COUNTRY_CODE||p.AREA_CODE||p.LOCAL_NUMBER
      FROM TMP_BATCH_NET_ADDR_ACC_POINT t
           JOIN SIM_CARD sc ON sc.IMSI = t.ACCESS_POINT_DESC
           JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON sc.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
           JOIN PHONE_NUMBER p ON naap.NETWORK_ADDRESS_ID = p.NETWORK_ADDRESS_ID
      WHERE t.date_time BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE,t.date_time)
        AND naap.LINK_TYPE_CODE = c_MAIN_LINK_TYPE
        AND t.BATCH_SESSION_ID = p_batch_session_id;*/

 dbms_output.put_line('Start of open cursor: '||to_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI:SS'));
   OPEN result_list FOR
     SELECT  ACCESS_POINT_DESC,DATE_TIME,NETWORK_ADDRESS_DESC
       FROM tt_interface_for_sups_NA_AP tt;


/*    UNION
    (
    SELECT ACCESS_POINT_DESC,DATE_TIME,NULL
      FROM TMP_BATCH_NET_ADDR_ACC_POINT t
      WHERE t.BATCH_SESSION_ID = p_batch_session_id
    MINUS
    SELECT  ACCESS_POINT_DESC,DATE_TIME,NULL
      FROM tt_interface_for_sups_NA_AP tt
    )*/


EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi (p_Text => TO_CHAR(error_code),
                          p_Level => RSIG_UTILS.c_DEBUG_LEVEL_0,
                          p_Event_Type => RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                          p_Event_Source => 'INTERFACE_FOR_SUPS.Get_Phones_For_SIM_list');
    OPEN Result_list FOR
      SELECT error_code
        FROM dual;
END Get_Phones_By_SIM_list;

PROCEDURE Get_Phones_By_SIM_list2 (
 p_ACCESS_POINT_DESC  IN T_VAR2_255,
 p_DATE_TIME    IN T_DATE,
-- p_NETWORK_ADDRESS_DESC IN T_VAR2_255,
 result_list             OUT sys_refcursor,
 error_code              OUT NUMBER
)
IS
BEGIN

  RSIG_UTILS.Debug_Rsi (p_Text => RSIG_UTILS.c_DEBUG_TEXT_START,
                        p_Level => RSIG_UTILS.c_DEBUG_LEVEL_1,
                        p_Event_Type => RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                        p_Event_Source => 'INTERFACE_FOR_SUPS.Get_Phones_For_SIM_list'
                       );

  error_code := rsig_utils.c_ok;
--dodelat test zda jsou stejne velka vstupni collections
---  Exist_Batch_Session_Id(p_batch_session_id);
 DELETE FROM TT_BATCH_NET_ADDR_ACC_POINT;

 dbms_output.put_line('Start for all: '||to_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI:SS'));
   FORALL i IN nvl(p_ACCESS_POINT_DESC.FIRST,1) .. nvl(p_ACCESS_POINT_DESC.LAST,0)
  INSERT INTO TT_BATCH_NET_ADDR_ACC_POINT(ACCESS_POINT_DESC,DATE_TIME)
        SELECT p_ACCESS_POINT_DESC(i),nvl(p_DATE_TIME(i),SYSDATE) FROM dual;

/*    INSERT INTO tt_interface_for_sups_NA_AP(ACCESS_POINT_DESC,DATE_TIME,NETWORK_ADDRESS_DESC)
     SELECT p_ACCESS_POINT_DESC(i),nvl(p_DATE_TIME(i),SYSDATE),p.international_format
     FROM dual
        LEFT JOIN SIM_CARD sc ON sc.IMSI = p_ACCESS_POINT_DESC(i)
  LEFT JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON sc.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
  LEFT JOIN PHONE_NUMBER p ON naap.NETWORK_ADDRESS_ID = p.NETWORK_ADDRESS_ID
  WHERE 1=1
--      AND sc.IMSI = tt.ACCESS_POINT_DESC
         AND nvl(p_DATE_TIME(i),SYSDATE) BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE,nvl(p_DATE_TIME(i),SYSDATE))
   AND naap.LINK_TYPE_CODE = c_MAIN_LINK_TYPE;
*/
 dbms_output.put_line('Start of insert: '||to_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI:SS'));

 --JHO - optimized for international format - add hint for UNIQUE index on internatioan_format
 INSERT INTO tt_interface_for_sups_NA_AP(ACCESS_POINT_DESC,DATE_TIME,NETWORK_ADDRESS_DESC)
    SELECT t.ACCESS_POINT_DESC,t.DATE_TIME, p.INTERNATIONAL_FORMAT  /*p.COUNTRY_CODE||p.AREA_CODE||p.LOCAL_NUMBER*/
      FROM TT_BATCH_NET_ADDR_ACC_POINT t
           JOIN SIM_CARD sc ON sc.IMSI = t.ACCESS_POINT_DESC
           JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON sc.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
           JOIN PHONE_NUMBER p ON naap.NETWORK_ADDRESS_ID = p.NETWORK_ADDRESS_ID
      WHERE t.date_time BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE,t.date_time)
        AND naap.LINK_TYPE_CODE = c_MAIN_LINK_TYPE;

dbms_output.put_line('Start of open cursor: '||to_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI:SS'));
  OPEN result_list FOR
    SELECT  ACCESS_POINT_DESC,DATE_TIME,NETWORK_ADDRESS_DESC
      FROM tt_interface_for_sups_NA_AP tt
    UNION
    (
    SELECT ACCESS_POINT_DESC,DATE_TIME,NULL
      FROM TT_BATCH_NET_ADDR_ACC_POINT t
    MINUS
    SELECT  ACCESS_POINT_DESC,DATE_TIME,NULL
      FROM tt_interface_for_sups_NA_AP tt
    );

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi (p_Text => TO_CHAR(error_code),
                          p_Level => RSIG_UTILS.c_DEBUG_LEVEL_0,
                          p_Event_Type => RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                          p_Event_Source => 'INTERFACE_FOR_SUPS.Get_Phones_For_SIM_list');
    OPEN Result_list FOR
      SELECT error_code
        FROM dual;
END Get_Phones_By_SIM_list2;


end RSIG_TEST_OPTIM;
/
