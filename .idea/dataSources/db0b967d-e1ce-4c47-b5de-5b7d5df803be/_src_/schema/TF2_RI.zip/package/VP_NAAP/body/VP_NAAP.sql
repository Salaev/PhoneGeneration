CREATE package body VP_NAAP is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_rct_this(p_coll rct_this) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_rct_this(p_coll in out nocopy rct_this, p_size number)
is
  v_dif number;
begin
  ------------------------------
  util_pkg.XCheck_size0(p_size, 'p_size');
  ------------------------------
  if p_coll is null
  then
    p_coll := rct_this();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return network_address_access_point%rowtype
is
  v_res network_address_access_point%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_NETADDRACCPO_NET_ADDRESS_ID2)*/
        * into v_res
      from network_address_access_point z
      where 1 = 1
        and network_address_id = p_id
        and p_date between from_date and nvl(to_date, to_date('01.01.4000','dd.mm.yyyy'))
      for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_NETADDRACCPO_NET_ADDRESS_ID2)*/
        * into v_res
      from network_address_access_point z
      where 1 = 1
        and network_address_id = p_id
        and p_date between from_date and nvl(to_date, to_date('01.01.4000','dd.mm.yyyy'))
      for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_NETADDRACCPO_NET_ADDRESS_ID2)*/
      * into v_res
    from network_address_access_point z
    where 1 = 1
      and network_address_id = p_id
      and p_date between from_date and nvl(to_date, to_date('01.01.4000','dd.mm.yyyy'))
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1(p_id integer, p_date date) return network_address_access_point%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get1_i(p_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget1(p_id integer, p_date date) return network_address_access_point%rowtype
is
  v_res network_address_access_point%rowtype;
begin
  ------------------------------
  v_res := get1(p_id, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get1(p_id integer, p_date date) return network_address_access_point%rowtype
is
  v_res network_address_access_point%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_i(p_id, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_xget1(p_id integer, p_date date) return network_address_access_point%rowtype
is
  v_res network_address_access_point%rowtype;
begin
  ------------------------------
  v_res := xlock_get1(p_id, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xlock(p_id integer, p_date date)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(xlock_xget1(p_id, p_date).network_address_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function getN_i(p_id_weak number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return rct_this
is
  v_res rct_this;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id_weak is null, 'p_id_weak');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_NAAP_AP)*/
        * bulk collect into v_res
      from network_address_access_point z
      where 1 = 1
        and access_point_id = p_id_weak
        and p_date between from_date and nvl(to_date, to_date('01.01.4000','dd.mm.yyyy'))
      order by access_point_id, network_address_id
      for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_NAAP_AP)*/
        * bulk collect into v_res
      from network_address_access_point z
      where 1 = 1
        and access_point_id = p_id_weak
        and p_date between from_date and nvl(to_date, to_date('01.01.4000','dd.mm.yyyy'))
      order by access_point_id, network_address_id
      for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_NAAP_AP)*/
      * bulk collect into v_res
    from network_address_access_point z
    where 1 = 1
      and access_point_id = p_id_weak
      and p_date between from_date and nvl(to_date, to_date('01.01.4000','dd.mm.yyyy'))
    order by access_point_id, network_address_id
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function getN(p_id_weak number, p_date date) return rct_this
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return getN_i(p_id_weak, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_getN(p_id_weak number, p_date date) return rct_this
is
  v_res rct_this;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := getN_i(p_id_weak, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xvalid_i(p_rec network_address_access_point%rowtype)
is
begin
  ------------------------------
  util_pkg.xcheck_version_dates(p_rec.from_date, nvl(p_rec.to_date, to_date('01.01.4000','dd.mm.yyyy')));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function find_i_id(p_rec network_address_access_point%rowtype) return boolean
is
  v_cnt number;
begin
  ------------------------------
  select /*+ index_asc(z, I_NETADDRACCPO_NET_ADDRESS_ID2)*/
    count(1) cnt into v_cnt
  from network_address_access_point z
  where 1 = 1
    and network_address_id = p_rec.network_address_id
    and greatest(p_rec.from_date, from_date) <= least(p_rec.to_date, nvl(to_date, to_date('01.01.4000','dd.mm.yyyy')))
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_spec01(p_rec network_address_access_point%rowtype) return boolean
is
  v_cnt number;
begin
  ------------------------------
  --!_!network_address_access_point.link_type_code%type; fucking char
  ------------------------------
  if util_ri.valid_code2(p_rec.link_type_code) != util_ri.c_NAAP_LINK_TYPE_CODE_MAIN
  then
    ------------------------------
    return false; --!_!other than M can be multiple
    ------------------------------
  end if;
  ------------------------------
  select /*+ index_asc(z, I_NAAP_AP)*/
    count(1) cnt into v_cnt
  from network_address_access_point z
  where 1 = 1
    and access_point_id = p_rec.access_point_id
    and greatest(p_rec.from_date, from_date) <= least(p_rec.to_date, nvl(to_date, to_date('01.01.4000','dd.mm.yyyy')))
    and link_type_code = p_rec.link_type_code
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i(p_rec network_address_access_point%rowtype) return boolean
is
begin
  ------------------------------
  if find_i_id(p_rec)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_spec01(p_rec)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xunique(p_rec network_address_access_point%rowtype)
is
begin
  ------------------------------
  if find_i_id(p_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_Vers2(p_rec.network_address_id, p_rec.from_date, p_rec.to_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_spec01(p_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_Vers3(p_rec.access_point_id, p_rec.link_type_code, p_rec.from_date, p_rec.to_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_i(p_rec network_address_access_point%rowtype)
is
  v_rec network_address_access_point%rowtype;
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
  xunique(p_rec);
  ------------------------------
  v_rec := p_rec;
  v_rec.to_date := util_ri.valid_date_to2invalid_date_to(p_rec.to_date);
  ------------------------------
  insert into network_address_access_point
  values v_rec;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure close_i(p_rec network_address_access_point%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
  update /*+ index_asc(z, I_NETADDRACCPO_NET_ADDRESS_ID2)*/
    network_address_access_point z
  set
    to_date = p_rec.to_date,
    user_id_of_change = p_rec.user_id_of_change,
    date_of_change = p_rec.date_of_change
  where 1 = 1
    and network_address_id = p_rec.network_address_id
    and p_rec.to_date between from_date and nvl(to_date, to_date('01.01.4000','dd.mm.yyyy'))
    and from_date = p_rec.from_date
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_Vers2(p_rec.network_address_id, p_rec.from_date, p_rec.to_date, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_OnDate2(p_rec.network_address_id, p_rec.to_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_identified(p_rec network_address_access_point%rowtype) return boolean
is
begin
  ------------------------------
  --!_!return (p_rec.network_address_id is not null and p_rec.access_point_id is not null);
  return (p_rec.network_address_id is not null);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open(p_rec in out nocopy network_address_access_point%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  --!_!p_rec.network_address_access_point_id := sq_network_address_access_point.nextval;
  --!_!p_rec.network_address_id := sq_network_address.nextval;
  --!_!p_rec.access_point_id := sq_access_point.nextval;
  ------------------------------
  p_rec.from_date := nvl(p_rec.from_date, v_sysdate);
  p_rec.to_date := nvl(p_rec.to_date, util_pkg.c_open_date_to);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change(p_rec in out nocopy network_address_access_point%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_to_prev date;
  v_rec network_address_access_point%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.network_address_id is null, 'p_rec.network_address_id');
  util_pkg.XCheck_Cond_Missing(p_rec.access_point_id is null, 'p_rec.access_point_id');
  util_pkg.XCheck_Cond_Missing(p_rec.link_type_code is null, 'p_rec.link_type_code');
  ------------------------------
  util_ri.XCheck_naap_link_type_code(util_ri.valid_code2(p_rec.link_type_code), 'p_rec.link_type_code');
  ------------------------------
  p_rec.from_date := nvl(p_rec.from_date, v_sysdate);
  p_rec.to_date := nvl(p_rec.to_date, util_pkg.c_open_date_to);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(p_rec.from_date);
  ------------------------------
  v_rec := xlock_get1(p_rec.network_address_id, v_date_to_prev);
  ------------------------------
  if not is_identified(v_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_rec.network_address_id, v_date_to_prev, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.user_id_of_change := p_rec.user_id_of_change;
  ------------------------------
  v_rec.date_of_change := v_sysdate;
  v_rec.to_date := v_date_to_prev;
  ------------------------------
  close_i(v_rec);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close
(
  p_id integer,
  p_user_id integer,
  p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_to_prev date;
  v_rec network_address_access_point%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(nvl(p_date_from, v_sysdate));
  ------------------------------
  v_rec := xlock_get1(p_id, v_date_to_prev);
  ------------------------------
  if not is_identified(v_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, v_date_to_prev, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.user_id_of_change := p_user_id;
  ------------------------------
  v_rec.date_of_change := v_sysdate;
  v_rec.to_date := v_date_to_prev;
  ------------------------------
  close_i(v_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open2
(
  p_na_id number,
  p_ap_id number,
  p_link_type_code varchar2,
  p_date date,
  p_user_id number,
  p_silent_proper_state boolean,
  p_explicit_intention boolean
)
is
  v_rec network_address_access_point%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  util_pkg.XCheck_Cond_Missing(p_link_type_code is null, 'p_link_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_state is null, 'p_silent_proper_state');
  util_pkg.XCheck_Cond_Missing(p_explicit_intention is null, 'p_explicit_intention');
  ------------------------------
  --!_!v_rec := xlock_get1(p_na_id, p_date); --!_!no need
  v_rec := get1(p_na_id, p_date); --!_!no transaction if not found
  ------------------------------
  if is_identified(v_rec)
  then
    ------------------------------
    if 1 = 1
      and p_silent_proper_state
      and v_rec.access_point_id = p_ap_id
    then
      ------------------------------
      if 1 = 1
        and util_ri.valid_code2(v_rec.link_type_code) != p_link_type_code
        and p_explicit_intention
      then
        ------------------------------
        if util_ri.xis_main_link(util_ri.valid_code2(v_rec.link_type_code))
        then
          ------------------------------
          util_pkg.Raise_Obj_NotUniq_OnDate2(p_na_id, p_date, c_this_name);
          ------------------------------
        else
          ------------------------------
          v_rec.link_type_code := p_link_type_code;
          v_rec.from_date := p_date;
          v_rec.user_id_of_change := p_user_id;
          ------------------------------
          version_change(v_rec);
          ------------------------------
        end if;
        ------------------------------
      else
        ------------------------------
        NULL; --!_!
        ------------------------------
      end if;
      ------------------------------
    else
      ------------------------------
      util_pkg.Raise_Obj_NotUniq_OnDate2(p_na_id, p_date, c_this_name);
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    v_rec := null;
    ------------------------------
    v_rec.access_point_id := p_ap_id;
    v_rec.network_address_id := p_na_id;
    v_rec.link_type_code := p_link_type_code;
    v_rec.from_date := p_date;
    v_rec.user_id_of_change := p_user_id;
    ------------------------------
    version_open(v_rec);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close2
(
  p_na_id number,
  p_date date,
  p_user_id number,
  p_silent_proper_state boolean
)
is
  v_rec network_address_access_point%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_state is null, 'p_silent_proper_state');
  ------------------------------
  v_rec := xlock_get1(p_na_id, p_date);
  ------------------------------
  if not is_identified(v_rec)
  then
    ------------------------------
    if not p_silent_proper_state
    then
      ------------------------------
      util_pkg.Raise_Obj_NotFound_OnDate2(p_na_id, p_date, c_this_name);
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    version_close
    (
      p_id => p_na_id,
      p_user_id => p_user_id,
      p_date_from => p_date
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
