CREATE PACKAGE VPN IS

PROCEDURE Get_VPN_Groups_of_Net_Op(
  p_Operator_UPRS_Code    IN   network_operator.uprs_member_code%TYPE,
  p_Host_ID               IN   host.host_id%TYPE,
  p_raise_error           IN   CHAR DEFAULT RSIG_UTILS.c_NO,
  p_error_code            OUT  NUMBER,
  p_result_list           OUT  sys_refcursor
);

PROCEDURE Insert_VPN_Group(
  p_VPN_Group_Start       IN  vpn_group.vpn_group_number_start%TYPE,
  p_VPN_Group_End         IN  vpn_group.vpn_group_number_end%TYPE,
  p_host_id               IN  host.host_id%TYPE,
  p_user_id               IN  NUMBER,
  p_handle_tran           IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_raise_error           IN  CHAR DEFAULT RSIG_UTILS.c_NO,
  p_VPN_Group_ID          OUT NUMBER,
  p_error_code            OUT NUMBER
);

PROCEDURE Insert_VPN_Numbering_Plan(
  p_phone_interval_start  IN  vpn_numbering_plan.phone_interval_start%TYPE,
  p_phone_interval_end    IN  vpn_numbering_plan.phone_interval_end%TYPE,
  p_vpn_group_id          IN  vpn_group.vpn_group_id%TYPE,
  p_user_id               IN  NUMBER,
  p_handle_tran           IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_raise_error           IN  CHAR DEFAULT RSIG_UTILS.c_NO,
  p_error_code            OUT NUMBER
);
END;
/
