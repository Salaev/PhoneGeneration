CREATE package etc_pkg is

----------------------------------!---------------------------------------------
  c_agroup_id_roaming_partner    constant number := 1;
  c_agroup_name_roaming_partner  constant nvarchar2(255) := 'Группа ROAMING_PARTNER';

  c_use_linked_no                constant number := 0;
  c_use_linked_yes               constant number := 1;
  c_use_linked_dontcare          constant number := 2;

----------------------------------!---------------------------------------------
  c_sett_agroup_roaming_partner  constant varchar2(100) := 'AGROUP_ROAMING_PARTNER';
  c_sett_ztc_roaming_partner     constant varchar2(100) := 'ZONE_TYPE_CODE_ROAMING_PARTNER';

  c_sett_msisdn_digits_srch      constant varchar2(100) := 'MSISDN_DIGITS_TO_SEARCH';
  c_sett_msisdn_digits_srch_wfs  constant varchar2(100) := 'MSISDN_DIGITS_TO_SEARCH_WITH_FULL_SCAN';

  c_opt_city_type                constant varchar2(100) := 'CITY_PHONE_TYPE_CODE';

  c_opt_def_abc_use_phone_link   constant varchar2(100) := 'DEF_ABC_USE_PHONE_LINK';

  c_opt_check_same_no_naap       constant varchar2(100) := 'Common.LinkNetworkAddressAccessPoint.CheckSameNetworkOperator4NetworkAddressAndAccessPoint';
  c_opt_check_relation2host      constant varchar2(100) := 'Common.LinkNetworkAddressAccessPoint.CheckRelationToHost';
  c_opt_check_excl_na_diff_no    constant varchar2(100) := 'Common.LinkNetworkAddressAccessPoint.ExcludeCheckRelToHost4NetworkAddressWithDiffCurAndOwnNetOp';
  c_opt_leg_map_error_link_p_s   constant varchar2(100) := 'Legacy.MapError.legacy_link_phone_sim';

----------------------------------!---------------------------------------------
  c_def_agroup_roaming_partner   constant number := c_agroup_id_roaming_partner;
  --!_!c_def_ztc_roaming_partner      constant varchar2(10) := '';

  c_def_msisdn_digits_srch       constant number := -1;
  c_def_msisdn_digits_srch_wfs   constant number := -1;

  --!_!c_def_city_type                constant varchar2(15) := '';

  c_def_def_abc_use_phone_link   constant boolean := true;

  c_def_check_same_no_naap       constant boolean := true;
  c_def_check_relation2host      constant boolean := true;
  c_def_check_excl_na_diff_no    constant boolean := true;
  c_def_leg_map_error_link_p_s   constant boolean := false;

----------------------------------!---------------------------------------------
  function xget_roam_part_agroup_id return number;

  function get_roam_part_zone_field return varchar2;
  function get_roam_part_id_field return varchar2;

  procedure get_roaming_partner
  (
    p_result_list out sys_refcursor,
    p_network_operator_id number,
    p_date date := null
  );

  procedure get_avail_roaming_zones
  (
    p_result_list out sys_refcursor,
    p_network_operator_id number,
    p_date date := null
  );

  function geto_msisdn_digits_at_begin return number;
  function geto_msisdn_digits_at_middle return number;
  function get_msisdn_digits_at_begin(p_mask varchar2) return number;
  function get_msisdn_digits_at_middle(p_mask varchar2) return number;

----------------------------------!---------------------------------------------
  function get_abc_rule_result(p_def_msisdn varchar2) return varchar2;

  procedure get_abc_rule_result_special
  (
    p_msisdn ct_varchar_s,
    p_msisdn_abc out ct_varchar_s,
    p_type_abc out ct_varchar_s,
    p_type_def out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure get_all_def_abc_rule
  (
    p_date date,
    p_result out sys_refcursor
  );

  procedure delete_def_abc_rule
  (
    p_ids ct_number,
    p_date_from ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure delete_def_abc_rule2
  (
    p_id number,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure create_def_abc_rule
  (
    p_defs ct_varchar_s,
    p_abcs ct_varchar_s,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure create_def_abc_rule2
  (
    p_def varchar2,
    p_abc varchar2,
    p_user_id number,
    p_out_id out number,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure update_def_abc_rule
  (
    p_ids ct_number,
    p_defs ct_varchar_s,
    p_abcs ct_varchar_s,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure update_def_abc_rule2
  (
    p_id number,
    p_def varchar2,
    p_abc varchar2,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  function get_pnt_check_rel_to_host(p_pnt_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_pnt_check_rel_to_host2(p_pnt_code varchar2, p_date date) return varchar2;

----------------------------------!---------------------------------------------
  procedure link_na_ap_i
  (
    p_na_ids ct_number,
    p_ap_ids ct_number,
    p_main_link4main_na boolean,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_silent_already_linked_same boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure link_phone_sim_i
  (
    p_msisdns ct_varchar_s,
    p_iccids ct_varchar_s,
    p_main_link4main_na boolean,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_silent_already_linked_same boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure legacy_link_phone_sim
  (
    p_msisdns ct_varchar_s,
    p_iccids ct_varchar_s,
    p_main_link4main_na boolean,
    p_date date,
    p_user_id number,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  function legacy_link_phone_sim_map_err(p_error_codes ct_number) return ct_number;
  function legacy_link_phone_sim_map_err(p_error_code number) return number;

----------------------------------!---------------------------------------------

end;
/
