CREATE PACKAGE BODY RSIG_HOST IS

---------------------------------------------
--     PROCEDURE Is_Host_Type_Deleted
---------------------------------------------

PROCEDURE Is_Host_Type_Deleted(p_host_type_code IN HOST_TYPE.HOST_TYPE_CODE%TYPE) IS
  v_pom NUMBER;
BEGIN
  SELECT 1
    INTO v_pom
    FROM HOST_TYPE
   WHERE TRIM(HOST_TYPE_CODE) = TRIM(p_host_type_code)
     AND DELETED IS NOT NULL
     AND DELETED < SYSDATE;
  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    NULL;
END Is_Host_Type_Deleted;

---------------------------------------------
--     PROCEDURE Test_Row_For_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Row_For_Exist_And_Deleted(p_host_id IN HOST.HOST_ID%TYPE) IS
  v_deleted HOST.DELETED%TYPE;
BEGIN
  SELECT DELETED INTO v_deleted FROM HOST WHERE HOST_ID = p_host_id;

  IF v_deleted IS NOT NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, 'Host is deleted.');
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Host not exists.');
END Test_Row_For_Exist_And_Deleted;

---------------------------------------------
--     PROCEDURE Test_Network_Operator_Deleted
---------------------------------------------

PROCEDURE Test_Network_Operator_Deleted(p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE) IS
  v_s VARCHAR2(1);
BEGIN
  SELECT 'X'
    INTO v_s
    FROM NETWORK_OPERATOR
   WHERE network_operator_id = p_network_operator_id
     AND deleted IS NOT NULL;

  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    NULL;
END Test_Network_Operator_Deleted;

---------------------------------------------
--     PROCEDURE Insert_Host
---------------------------------------------

PROCEDURE Insert_Host
(
  handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_host_code           IN HOST.HOST_CODE%TYPE,
  p_host_name           IN HOST.HOST_NAME%TYPE,
  p_host_address        IN HOST.HOST_ADDRESS%TYPE,
  p_host_location       IN HOST.HOST_LOCATION%TYPE,
  p_host_type_code      IN HOST.HOST_TYPE_CODE%TYPE,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_user_id_of_change   IN NUMBER,
  p_host_id             OUT HOST.HOST_ID%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Insert_Host';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT insert_host_a;
  END IF;

  Test_Network_Operator_Deleted(p_network_operator_id);
  Is_Host_Type_Deleted(p_host_type_code);
  IF TRIM(p_host_type_code) = TRIM(RSIG_UTILS.c_HOST_TYPE_CODE_EX) THEN
    IF p_host_code IS NULL THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
    END IF;
  END IF;
  SELECT s_host.NEXTVAL INTO p_host_id FROM DUAL;

  BEGIN
    INSERT INTO HOST
      (HOST_ID,
       HOST_CODE,
       HOST_NAME,
       HOST_ADDRESS,
       HOST_LOCATION,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE,
       DELETED,
       NETWORK_OPERATOR_ID,
       HOST_TYPE_CODE)
    VALUES
      (p_host_id,
       p_host_code,
       p_host_name,
       p_host_address,
       p_host_location,
       SYSDATE,
       p_user_id_of_change,
       NULL,
       p_network_operator_id,
       p_host_type_code);

  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      IF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_HOST_CODE THEN
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_CODE, '');
      ELSE
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_NAME, '');
      END IF;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT insert_host_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
    END;
END Insert_Host;

---------------------------------------------
--     PROCEDURE Update_Host
---------------------------------------------

PROCEDURE Update_Host
(
  handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_host_id             IN HOST.HOST_ID%TYPE,
  p_host_code           IN HOST.HOST_CODE%TYPE,
  p_host_name           IN HOST.HOST_NAME%TYPE,
  p_host_address        IN HOST.HOST_ADDRESS%TYPE,
  p_host_location       IN HOST.HOST_LOCATION%TYPE,
  p_host_type_code      IN HOST.HOST_TYPE_CODE%TYPE,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_user_id_of_change   IN NUMBER
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Update_Host';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT update_host_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_host_id);
  Test_Network_Operator_Deleted(p_network_operator_id);
  Is_Host_Type_Deleted(p_host_type_code);

  BEGIN
    UPDATE HOST
       SET HOST_CODE           = p_host_code,
           HOST_NAME           = p_host_name,
           HOST_ADDRESS        = p_host_address,
           HOST_LOCATION       = p_host_location,
           DATE_OF_CHANGE      = SYSDATE,
           USER_ID_OF_CHANGE   = p_user_id_of_change,
           NETWORK_OPERATOR_ID = p_network_operator_id,
           HOST_TYPE_CODE      = p_host_type_code
     WHERE HOST_ID = p_host_id;

  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      IF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_HOST_CODE THEN
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_CODE, '');
      ELSE
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_NAME, '');
      END IF;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT update_host_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
    END;
END Update_Host;

---------------------------------------------
--     PROCEDURE Check_Host_Referenced
---------------------------------------------

PROCEDURE Check_Host_Referenced(p_host_id IN HOST.HOST_ID%TYPE) IS
  v_referenced   NUMBER;
BEGIN

  v_referenced := NULL;

  SELECT 1
    INTO v_referenced
    FROM DUAL
   WHERE EXISTS (SELECT 1 FROM ACCESS_POINT_HOST aph WHERE aph.HOST_ID = p_host_id)
        /*  or exists (select 1 from EXCHANGE ex
                          where ex.HOST_ID = p_host_id) */
      OR EXISTS (SELECT 1
            FROM PHONE_NUMBER_SERIES pns
             WHERE pns.HOST_ID = p_host_id
              AND pns.DELETED IS NULL)
      OR EXISTS (SELECT 1
            FROM PREFIX_REPLACEMENT_GROUPS prg
            JOIN PREFIX_REPLACEMENT_NET_EL prne ON prne.group_id = prg.group_id
             WHERE prne.HOST_ID = p_host_id
              AND (prg.DELETED IS NULL AND (prg.end_date IS NULL OR prg.end_date>SYSDATE)))
      OR EXISTS (SELECT 1
            FROM SIM_SERIES sim
             WHERE sim.HOST_ID = p_host_id
              AND sim.DELETED IS NULL)
      OR EXISTS(SELECT 1
            FROM exchange_port ep
             WHERE ep.host_id = p_host_id
              AND ep.DELETED IS NULL)
      OR EXISTS(SELECT 1
            FROM location_area la
             WHERE la.host_id = p_host_id
              AND la.DELETED IS NULL)
      OR EXISTS(SELECT 1
            FROM channel c
             WHERE c.host_id_placed_on = p_host_id
              AND c.DELETED IS NULL);

  IF v_referenced = 1 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_REFERENCED, '');
  END IF;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    NULL;
END Check_Host_Referenced;

---------------------------------------------
--     PROCEDURE Delete_Host
---------------------------------------------

PROCEDURE Delete_Host
(
  handle_tran         IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT NUMBER,
  p_host_id           IN HOST.HOST_ID%TYPE,
  p_deleted           IN HOST.DELETED%TYPE,
  p_user_id_of_change IN NUMBER
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Delete_Host';
  v_deleted      DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  v_deleted := nvl(p_deleted, SYSDATE);
  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT delete_host_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_host_id);

  Check_Host_Referenced(p_host_id);

  UPDATE HOST
     SET --DELETED = p_deleted,
                  DELETED = v_deleted, --- jho 040803 her was hardcoded sysdate, changed to v_deleted
         DATE_OF_CHANGE    = SYSDATE,
         USER_ID_OF_CHANGE = p_user_id_of_change
   WHERE HOST_ID = p_host_id;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT delete_host_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
    END;
END Delete_Host;

---------------------------------------------
--     PROCEDURE Get_Host
---------------------------------------------
PROCEDURE Get_Host
(
  error_code            OUT NUMBER,
  p_host_type_code      IN HOST.HOST_TYPE_CODE%TYPE,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_cur_host            OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Get_Host';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_network_operator_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  OPEN p_cur_host FOR
  SELECT HOST_ID,
         HOST_CODE,
         HOST_NAME,
         HOST_ADDRESS,
         HOST_LOCATION,
         DATE_OF_CHANGE,
         USER_ID_OF_CHANGE,
         DELETED,
         h.HOST_TYPE_CODE,
         h.NETWORK_OPERATOR_ID,
         h.TIME_ZONE,
         h.DST_RULE_ID
    FROM HOST h
   WHERE (TRIM(HOST_TYPE_CODE) = TRIM(p_host_type_code) OR p_host_type_code IS NULL)
     AND (DELETED IS NULL OR DELETED >= SYSDATE)
     AND NETWORK_OPERATOR_ID = p_network_operator_id;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_cur_host FOR
        SELECT error_code FROM dual;
    END;
END Get_Host;

---------------------------------------------
--     PROCEDURE Get_host_by_date
---------------------------------------------
PROCEDURE Get_host_by_date
(
  error_code               OUT NUMBER,
  p_host_type_code         IN HOST.HOST_TYPE_CODE%TYPE,
  p_network_operator_code  IN NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
  p_validity_date          IN DATE,
  p_cur_host               OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source         VARCHAR2(60) := 'RSIG_HOST.Get_Host_by_date';
  v_network_operator_id  NUMBER;
  v_validity_date        DATE := NVL(p_validity_date,SYSDATE);
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  BEGIN
    SELECT network_operator_id INTO v_network_operator_id
      FROM network_operator
     WHERE network_operator_code = p_network_operator_code
       AND (deleted is null OR deleted > v_validity_date);
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_operator_not_exist, '');
  END;

  OPEN p_cur_host FOR
    SELECT h.host_id,
           h.host_code,
           h.host_name,
           h.host_address,
           h.host_location,
           h.date_of_change,
           h.user_id_of_change,
           h.deleted,
           ht.host_type_code,
           ht.host_type_name,
           h.network_operator_id,
           p_network_operator_code AS network_operator_code,
           h.time_zone,
           h.DST_RULE_ID
      FROM host h
      JOIN host_type ht ON ht.host_type_code = h.host_type_code
     WHERE (TRIM(ht.host_type_code) = TRIM(p_host_type_code) OR p_host_type_code IS NULL)
       AND h.network_operator_id = v_network_operator_id
       AND (h.deleted IS NULL OR h.deleted > v_validity_date);

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_cur_host FOR
        SELECT error_code FROM dual;
    END;
END Get_host_by_date;

---------------------------------------------
--     PROCEDURE Get_Host_All
---------------------------------------------

PROCEDURE Get_Host_All
(
  error_code            OUT NUMBER,
  p_host_type_code      IN HOST.HOST_TYPE_CODE%TYPE,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_cur_host            OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Get_Host_All';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_network_operator_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;


  OPEN p_cur_host FOR
    SELECT h.HOST_ID,
           h.HOST_CODE,
           h.HOST_NAME,
           h.HOST_ADDRESS,
           h.HOST_LOCATION,
           h.DATE_OF_CHANGE,
           h.USER_ID_OF_CHANGE,
           h.DELETED,
           h.host_type_code,
           ht.host_type_name,
           h.TIME_ZONE,
           h.DST_RULE_ID,
           ht.IS_EXCHANGE,
           et.EXCHANGE_TYPE_CODE,
           e.exchange_usage_type_code
      FROM HOST h
      JOIN host_type ht on TRIM(ht.host_type_code) = TRIM(h.host_type_code)
      LEFT JOIN exchange e on e.host_id = h.host_id
      LEFT JOIN exchange_type et on et.EXCHANGE_TYPE_ID = e.exchange_type_id
     WHERE (TRIM(h.HOST_TYPE_CODE) = TRIM(p_host_type_code) OR p_host_type_code IS NULL)
       AND h.NETWORK_OPERATOR_ID = p_network_operator_id;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_cur_host FOR
        SELECT error_code FROM dual;
    END;
END Get_Host_All;

---------------------------------------------
--     PROCEDURE Get_Host_Statistic
---------------------------------------------

PROCEDURE Get_Host_Statistic
(
  error_code            OUT NUMBER,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_cur_host_statistic  OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Get_Host_Statistic';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_network_operator_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  OPEN p_cur_host_statistic FOR
    SELECT h.HOST_ID,
           COUNT(aph.ACCESS_POINT_ID) ACCES_POINT_COUNT
      FROM HOST h
      JOIN ACCESS_POINT_HOST aph ON h.HOST_ID = aph.HOST_ID
     WHERE h.NETWORK_OPERATOR_ID = p_network_operator_id
       AND h.DELETED IS NULL
       AND aph.END_DATE IS NOT NULL
     GROUP BY h.NETWORK_OPERATOR_ID,
              h.HOST_ID;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_Host_Statistic;

---------------------------------------------
--     PROCEDURE Get_Network_Operator_By_MSC
---------------------------------------------

PROCEDURE Get_Network_Operator_By_MSC
(
  error_code              OUT  NUMBER,
  p_host_code             IN   HOST.HOST_CODE%TYPE,
  p_network_operator_id   OUT  NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Get_Network_Operator_By_MSC';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_host_code IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  SELECT NETWORK_OPERATOR_ID
  INTO p_network_operator_id
  FROM HOST
  WHERE HOST_CODE = p_host_code
    AND (deleted IS NULL OR deleted>SYSDATE)
  AND rownum=1;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    p_network_operator_id := RSIG_UTILS.c_NO_DATA_FOUND;
    error_code            := RSIG_UTILS.c_NO_DATA_FOUND;
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_Network_Operator_By_MSC;

---------------------------------------------
--     PROCEDURE Get_Host_Parent_Operator
---------------------------------------------

PROCEDURE Get_Host_Parent_Operator
(
  error_code            OUT NUMBER,
  p_host_type_code      IN HOST.HOST_TYPE_CODE%TYPE,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_show_deleted        IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_N,
  p_cur_host            OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Get_Host_Parent_Operator';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_network_operator_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  OPEN p_cur_host FOR
    SELECT h.HOST_ID,
           h.HOST_CODE,
           h.HOST_NAME,
           h.HOST_ADDRESS,
           h.HOST_LOCATION,
           h.DATE_OF_CHANGE,
           h.USER_ID_OF_CHANGE,
           h.DELETED,
           h.TIME_ZONE
      FROM HOST h
     WHERE (TRIM(HOST_TYPE_CODE) = TRIM(p_host_type_code) OR p_host_type_code IS NULL)
       AND (h.deleted IS NULL OR p_show_deleted = RSIG_UTILS.c_HANDLE_TRAN_Y)
       AND EXISTS (SELECT 'x'
              FROM NETWORK_OPERATOR n
             WHERE h.NETWORK_OPERATOR_ID = n.NETWORK_OPERATOR_ID
            CONNECT BY PRIOR n.NETWORK_OPERATOR_ID_UPPER = n.NETWORK_OPERATOR_ID
             START WITH n.NETWORK_OPERATOR_ID = p_network_operator_id);

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_cur_host FOR
        SELECT error_code FROM dual;
    END;
END Get_Host_Parent_Operator;

---------------------------------------------
--     PROCEDURE Get_Host_Extended
---------------------------------------------

PROCEDURE Get_Host_Extended
(
  ERROR_CODE            OUT NUMBER,
  p_host_type_code      IN HOST.HOST_TYPE_CODE%TYPE,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_validity_date       IN DATE,
  p_include_child       IN CHAR, --  network operator and all of its children
  p_include_parent      IN CHAR, --  network operator and its entire parent
  p_cur_host            OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source  VARCHAR2(60) := 'RSIG_HOST.Get_Host_Extended';
  v_validity_date DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  v_validity_date := nvl(p_validity_date, SYSDATE);
  IF p_network_operator_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF upper(p_include_child) = 'Y' THEN
    OPEN p_cur_host FOR
      SELECT h.HOST_CODE,
             h.HOST_NAME,
             h.HOST_ADDRESS,
             h.HOST_LOCATION,
             h.NETWORK_OPERATOR_ID,
             n.NETWORK_OPERATOR_NAME,
             h.TIME_ZONE
        FROM HOST h
        JOIN NETWORK_OPERATOR n ON n.NETWORK_OPERATOR_ID = h.NETWORK_OPERATOR_ID
       WHERE (TRIM(h.HOST_TYPE_CODE) = TRIM(p_host_type_code) OR p_host_type_code IS NULL)
         AND (h.DELETED IS NULL OR h.DELETED >= v_validity_date)
         AND EXISTS (SELECT 'x'
                FROM NETWORK_OPERATOR n
               WHERE h.NETWORK_OPERATOR_ID = n.NETWORK_OPERATOR_ID
              CONNECT BY PRIOR n.NETWORK_OPERATOR_ID = n.NETWORK_OPERATOR_ID_UPPER
               START WITH n.NETWORK_OPERATOR_ID = p_network_operator_id);

  ELSIF upper(p_include_parent) = 'Y' THEN
    OPEN p_cur_host FOR
      SELECT h.HOST_CODE,
             h.HOST_NAME,
             h.HOST_ADDRESS,
             h.HOST_LOCATION,
             h.NETWORK_OPERATOR_ID,
             n.NETWORK_OPERATOR_NAME,
             h.TIME_ZONE
        FROM HOST h
        JOIN NETWORK_OPERATOR n ON n.NETWORK_OPERATOR_ID = h.NETWORK_OPERATOR_ID
       WHERE (TRIM(h.HOST_TYPE_CODE) = TRIM(p_host_type_code) OR p_host_type_code IS NULL)
         AND (h.DELETED IS NULL OR h.DELETED >= v_validity_date)
         AND EXISTS (SELECT 'x'
                FROM NETWORK_OPERATOR n
               WHERE h.NETWORK_OPERATOR_ID = n.NETWORK_OPERATOR_ID
              CONNECT BY PRIOR n.NETWORK_OPERATOR_ID_UPPER = n.NETWORK_OPERATOR_ID
               START WITH n.NETWORK_OPERATOR_ID = p_network_operator_id);
  ELSE
    OPEN p_cur_host FOR
      SELECT h.HOST_CODE,
             h.HOST_NAME,
             h.HOST_ADDRESS,
             h.HOST_LOCATION,
             h.NETWORK_OPERATOR_ID,
             n.NETWORK_OPERATOR_NAME,
             h.TIME_ZONE
        FROM HOST h
        JOIN NETWORK_OPERATOR n ON n.NETWORK_OPERATOR_ID = h.NETWORK_OPERATOR_ID
       WHERE (TRIM(h.HOST_TYPE_CODE) = TRIM(p_host_type_code) OR p_host_type_code IS NULL)
         AND (h.DELETED IS NULL OR h.DELETED >= v_validity_date)
         AND h.NETWORK_OPERATOR_ID = p_network_operator_id;
  END IF;

  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_cur_host FOR
        SELECT ERROR_CODE FROM dual;
    END;
END Get_Host_Extended;

---------------------------------------------
--     PROCEDURE Get_Host_By_ICCID_List
---------------------------------------------

PROCEDURE Get_Host_By_ICCID_List
(
  col_iccid       IN t_v2_60_tab,
  p_host_type     IN HOST_TYPE.HOST_TYPE_CODE%TYPE,
  p_validity_date IN DATE,
  p_raise_error   IN CHAR,
  ERROR_CODE      OUT NUMBER,
  error_message   OUT VARCHAR2,
  result_list     OUT sys_refcursor
) IS
  v_event_source  VARCHAR2(60) := 'RSIG_HOST.Get_Host_By_ICCID_List';
  v_sqlcode       NUMBER;
  v_validity_date DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  IF p_host_type IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  IF (col_iccid.COUNT = 0) OR (col_iccid.COUNT = 1 AND col_iccid(col_iccid.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  v_validity_date := nvl(p_validity_date,SYSDATE);

  DELETE FROM tt_batch_NA_AP;

  FORALL i IN nvl(col_iccid.FIRST, 1) .. nvl(col_iccid.LAST, 0)
    INSERT INTO tt_batch_NA_AP(Sn)
    VALUES(col_iccid(i));


  IF TRIM(p_host_type) = rsig_utils.c_HOST_TYPE_CODE_HLR THEN
  -- variant for HLR type of host
    OPEN result_list FOR
    SELECT /*+ use_nl(t sc ss h) */
           t.sn,
           h.host_id,
           h.host_name,
           h.time_zone,
           ss.network_operator_id,
		   h.host_code
    FROM tt_batch_na_ap t
    LEFT JOIN sim_card sc ON sc.sn=t.sn
    LEFT JOIN sim_series ss ON ss.sim_series_id=sc.sim_series_id
         AND (ss.DELETED > v_validity_date OR ss.DELETED IS NULL)
    LEFT JOIN host h ON h.host_id=ss.host_id
         AND TRIM(h.HOST_TYPE_CODE) = rsig_utils.c_HOST_TYPE_CODE_HLR;

  ELSE
  -- variant for other types of host
    OPEN result_list FOR
    SELECT /*+ use_nl(t sc ss aph h) */
           t.sn,
           h.host_id,
           h.host_name,
           h.time_zone,
           ss.network_operator_id,
		   h.host_code
    FROM tt_batch_na_ap t
    LEFT JOIN sim_card sc ON sc.sn=t.sn
    LEFT JOIN sim_series ss ON ss.sim_series_id=sc.sim_series_id
         AND (ss.DELETED IS NULL OR ss.DELETED < v_validity_date)
    LEFT JOIN sim_series_host ssh ON ssh.sim_series_id=ss.sim_series_id
         AND v_validity_date BETWEEN ssh.start_date AND nvl(ssh.end_date,v_validity_date)
         AND ssh.host_type_code=TRIM(p_host_type)
    LEFT JOIN access_point_host aph ON aph.access_point_id=sc.access_point_id
         AND v_validity_date BETWEEN aph.start_date AND nvl(aph.end_date,v_validity_date)
         AND aph.host_id IN (SELECT hh.host_id
                             FROM host hh
                             WHERE TRIM(hh.HOST_TYPE_CODE) = TRIM(p_host_type))
    LEFT JOIN host h ON (aph.host_id IS NULL AND h.host_id=ssh.host_id) OR (aph.host_id IS NOT NULL AND h.host_id=aph.host_id);

  END IF;


  COMMIT;


  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_Host_By_ICCID_List;

---------------------------------------------
--     PROCEDURE Get_Host_And_Net_Op
---------------------------------------------

PROCEDURE Get_Host_And_Net_Op
(
  ERROR_CODE       OUT NUMBER,
  p_host_type_code IN HOST.HOST_TYPE_CODE%TYPE,
  p_cur_host       OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Get_Host_And_Net_Op';
BEGIN
  -- debug start
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_host FOR
    SELECT h.HOST_CODE,
           h.network_operator_id,
           h.TIME_ZONE,
           h.DST_RULE_ID
      FROM HOST h
     WHERE (TRIM(HOST_TYPE_CODE) = TRIM(p_host_type_code) OR p_host_type_code IS NULL)
       AND (DELETED IS NULL OR DELETED >= SYSDATE);

  -- set error code
  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  -- debug end
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE) || ' ' || SQLERRM,
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_cur_host FOR
        SELECT ERROR_CODE FROM dual;
    END;
END Get_Host_and_Net_Op;

---------------------------------------------
--     PROCEDURE Get_Host_Time_Zone
---------------------------------------------

PROCEDURE Get_Host_Time_Zone
(
  p_host_col    IN t_number_tab,
  p_raise_error IN CHAR,
  ERROR_CODE    OUT NUMBER,
  error_message OUT VARCHAR2,
  result_list   OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Get_Host_Time_Zone';
  i              NUMBER;
  j              NUMBER;
  obj            t_pa_host_obj := t_pa_host_obj(NULL, NULL);
  obj_col        t_pa_host_obj_tab := t_pa_host_obj_tab();
  v_sqlcode      NUMBER;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  --check p_host_col parameter
  IF (p_host_col.COUNT = 0) OR (p_host_col.COUNT = 1 AND p_host_col(p_host_col.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  j := 1;
  FOR i IN nvl(p_host_col.FIRST, 1) .. nvl(p_host_col.LAST, 0)
  LOOP
    -- for all members of input associative array
    obj := t_pa_host_obj(NULL, p_host_col(i)); -- ccreate object
    obj_col.EXTEND; -- grow
    obj_col(j) := obj; -- insert into collection
    j := j + 1;
  END LOOP;

  OPEN result_list FOR
    SELECT t.HOST_ID,
           h.TIME_ZONE,
           h.HOST_CODE,
           h.HOST_NAME,
           h.HOST_TYPE_CODE,
           CASE
             WHEN nvl(h.HOST_ID, -1) = -1 THEN
              RSIG_UTILS.c_ROW_NOT_FOUND
             ELSE
              RSIG_UTILS.c_OK
           END
      FROM TABLE(CAST(obj_col AS t_pa_host_obj_tab)) t -- cast an mak it table to join
      LEFT JOIN HOST h ON h.HOST_ID = t.HOST_ID;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_HOST_TIME_ZONE;

---------------------------------------------
--     PROCEDURE Get_Type_Host_By_Host_Id
---------------------------------------------

PROCEDURE Get_Type_Host_By_Host_Id
(
  p_col_host_id    IN t_number_tab,
  p_raise_error    IN CHAR,
  p_error_code     OUT NUMBER,
  p_error_message  OUT VARCHAR2,
  result_list      OUT SYS_REFCURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Get_Type_Host_By_Host_Id';
  i              NUMBER;
  j              NUMBER;
  obj            t_pa_host_obj := t_pa_host_obj(NULL, NULL);
  obj_col        t_pa_host_obj_tab := t_pa_host_obj_tab();
  v_sqlcode      NUMBER;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  --check p_col_host_id parameter
  IF (p_col_host_id.COUNT = 0) OR (p_col_host_id.COUNT = 1 AND p_col_host_id(p_col_host_id.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  j := 1;
  FOR i IN nvl(p_col_host_id.FIRST, 1) .. nvl(p_col_host_id.LAST, 0)
  LOOP
    -- for all members of input associative array
    obj := t_pa_host_obj(NULL, p_col_host_id(i)); -- ccreate object
    obj_col.EXTEND; -- grow
    obj_col(j) := obj; -- insert into collection
    j := j + 1;
  END LOOP;

  OPEN result_list FOR
    SELECT t.HOST_ID,
           h.HOST_CODE,
           h.HOST_NAME,
           h.HOST_TYPE_CODE,
           nvl(h.PARENT_HOST_ID, h.HOST_ID) PARENT_HOST_ID
      FROM TABLE(CAST(obj_col AS t_pa_host_obj_tab)) t -- cast an mak it table to join
      JOIN HOST h ON h.HOST_ID = t.HOST_ID;

  -- set error code to succesfully completed
  p_error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    p_error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_Type_Host_By_Host_Id;

---------------------------------------------
--     PROCEDURE Get_Type_Host_By_PA
---------------------------------------------

PROCEDURE Get_Type_Host_By_PA
(
  p_col_pa         IN t_number_tab,
  p_validity_date  IN DATE,
  p_raise_error    IN CHAR,
  error_code       OUT NUMBER,
  error_message    OUT VARCHAR2,
  result_list      OUT SYS_REFCURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Get_Type_Host_By_PA';
  i              NUMBER;
  j              NUMBER;
  obj            t_pa_host_obj := t_pa_host_obj(NULL, NULL);
  obj_col        t_pa_host_obj_tab := t_pa_host_obj_tab();
  v_sqlcode      NUMBER;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  --check p_col_pa parameter
  IF (p_col_pa.COUNT = 0) OR (p_col_pa.COUNT = 1 AND p_col_pa(p_col_pa.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  j := 1;
  FOR i IN nvl(p_col_pa.FIRST, 1) .. nvl(p_col_pa.LAST, 0)
  LOOP
    -- for all members of input associative array
    obj := t_pa_host_obj(p_col_pa(i), NULL); -- ccreate object
    obj_col.EXTEND; -- grow
    obj_col(j) := obj; -- insert into collection
    j := j + 1;
  END LOOP;

  OPEN result_list FOR
    SELECT /*+ INDEX (pah I_PA_PERSONAL_ACCOUNT_HISTORY)
               INDEX (h PK_HOST)*/
           pah.personal_account,
           h.HOST_ID,
           h.HOST_CODE,
           h.HOST_NAME,
           h.HOST_TYPE_CODE
      FROM TABLE(CAST(obj_col AS t_pa_host_obj_tab)) t
      JOIN personal_account_history pah
        ON pah.personal_account = t.personal_account
       AND p_validity_date BETWEEN pah.start_date AND NVL(pah.end_date,p_validity_date)
      JOIN host h ON h.host_id = pah.balance_storage;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_Type_Host_By_PA;

---------------------------------------------
--     PROCEDURE Insert_Host2
---------------------------------------------

PROCEDURE Insert_Host2
(
  handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_host_code           IN HOST.HOST_CODE%TYPE,
  p_host_name           IN HOST.HOST_NAME%TYPE,
  p_host_address        IN HOST.HOST_ADDRESS%TYPE,
  p_host_location       IN HOST.HOST_LOCATION%TYPE,
  p_host_type_code      IN HOST.HOST_TYPE_CODE%TYPE,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_user_id_of_change   IN NUMBER,
  p_time_zone           IN NUMBER,
  p_dst_rule_id         IN   NUMBER,
  p_host_id             OUT HOST.HOST_ID%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Insert_Host2';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT insert_host_a2;
  END IF;

  Test_Network_Operator_Deleted(p_network_operator_id);
  Is_Host_Type_Deleted(p_host_type_code);
  IF TRIM(p_host_type_code) = TRIM(RSIG_UTILS.c_HOST_TYPE_CODE_EX) THEN
    IF p_host_code IS NULL THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
    END IF;
  END IF;
  SELECT s_host.NEXTVAL INTO p_host_id FROM DUAL;

  BEGIN
    INSERT INTO HOST
      (HOST_ID,
       HOST_CODE,
       HOST_NAME,
       HOST_ADDRESS,
       HOST_LOCATION,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE,
       DELETED,
       NETWORK_OPERATOR_ID,
       HOST_TYPE_CODE,
       TIME_ZONE,
       DST_RULE_ID)
    VALUES
      (p_host_id,
       p_host_code,
       p_host_name,
       p_host_address,
       p_host_location,
       SYSDATE,
       p_user_id_of_change,
       NULL,
       p_network_operator_id,
       p_host_type_code,
       p_time_zone,
       p_dst_rule_id);

  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      IF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_HOST_CODE THEN
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_CODE, '');
      ELSE
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_NAME, '');
      END IF;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT insert_host_a2;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
    END;
END Insert_Host2;

---------------------------------------------
--     PROCEDURE Update_Host2
---------------------------------------------

PROCEDURE Update_Host2
(
  handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_host_id             IN HOST.HOST_ID%TYPE,
  p_host_code           IN HOST.HOST_CODE%TYPE,
  p_host_name           IN HOST.HOST_NAME%TYPE,
  p_host_address        IN HOST.HOST_ADDRESS%TYPE,
  p_host_location       IN HOST.HOST_LOCATION%TYPE,
  p_host_type_code      IN HOST.HOST_TYPE_CODE%TYPE,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_user_id_of_change   IN NUMBER,
  p_time_zone           IN NUMBER,
  p_dst_rule_id         IN NUMBER
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Update_Host2';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT update_host_a2;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_host_id);
  Test_Network_Operator_Deleted(p_network_operator_id);
  Is_Host_Type_Deleted(p_host_type_code);

  BEGIN
    UPDATE HOST
       SET HOST_CODE           = p_host_code,
           HOST_NAME           = p_host_name,
           HOST_ADDRESS        = p_host_address,
           HOST_LOCATION       = p_host_location,
           DATE_OF_CHANGE      = SYSDATE,
           USER_ID_OF_CHANGE   = p_user_id_of_change,
           NETWORK_OPERATOR_ID = p_network_operator_id,
           HOST_TYPE_CODE      = p_host_type_code,
           TIME_ZONE           = p_time_zone,
           DST_RULE_ID         = p_dst_rule_id
     WHERE HOST_ID = p_host_id;

  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      IF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_HOST_CODE THEN
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_CODE, '');
      ELSE
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_NAME, '');
      END IF;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT update_host_a2;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
    END;
END Update_Host2;

---------------------------------------------
--     PROCEDURE Get_Hosts_By_Host_Type
---------------------------------------------

PROCEDURE Get_Hosts_By_Host_Type
(
  p_host_type_code IN HOST.HOST_TYPE_CODE%TYPE,
  p_raise_error    IN CHAR,
  ERROR_CODE       OUT NUMBER,
  error_message    OUT VARCHAR2,
  result_list      OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Get_Hosts_By_Host_Type';
  v_sqlcode      NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- procedure body here
  OPEN result_list FOR
    SELECT h.HOST_ID,
           h.HOST_CODE,
           h.TIME_ZONE,
           h.NETWORK_OPERATOR_ID,
           no.NETWORK_OPERATOR_CODE,
           (SELECT NO1.NETWORK_OPERATOR_ID
              FROM NETWORK_OPERATOR NO1
             WHERE NO1.NETWORK_OPERATOR_ID_UPPER IS NULL
             START WITH NO1.NETWORK_OPERATOR_ID = h.NETWORK_OPERATOR_ID
            CONNECT BY PRIOR NO1.NETWORK_OPERATOR_ID_UPPER = NO1.NETWORK_OPERATOR_ID) TOP_PARENT_OP_ID
      FROM HOST h
      JOIN NETWORK_OPERATOR no ON no.NETWORK_OPERATOR_ID = h.NETWORK_OPERATOR_ID
     WHERE (TRIM(h.HOST_TYPE_CODE) = TRIM(p_host_type_code) OR p_host_type_code IS NULL)
       AND (h.DELETED IS NULL OR h.DELETED > SYSDATE)
     ORDER BY HOST_CODE;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_Hosts_by_host_type;

--------------------------------------------------------------------------------------------------------------
--     PROCEDURE Get_Host_By_MSISDN
--------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Host_By_MSISDN
(
  p_phone_number   IN  PHONE_NUMBER.INTERNATIONAL_FORMAT%TYPE,
  p_host_type      IN  HOST.HOST_TYPE_CODE%TYPE,
  p_validity_date  IN  DATE,
  p_raise_error    IN  CHAR,
  p_error_code     OUT NUMBER,
  p_error_message  OUT VARCHAR2,
  p_cur_host       OUT sys_refcursor
)
IS
  v_event_source  VARCHAR2(60) := 'RSIG_HOST.Get_Host_By_MSISDN';
  v_validity_date DATE;
  v_phone_number_type   VARCHAR2(10);
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_phone_number IS NULL
     OR p_host_type IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  v_validity_date := nvl(p_validity_date, SYSDATE);

  SELECT pns.phone_number_type_code INTO v_phone_number_type
        FROM phone_number pn
        JOIN phone_number_series pns ON pns.phone_number_series_id=pn.phone_number_series_id
       WHERE pn.international_format = p_phone_number;

  IF TRIM(p_host_type) = TRIM(rsig_utils.c_HOST_TYPE_CODE_HLR) AND TRIM(UPPER(v_phone_number_type)) NOT IN ('E') THEN

    OPEN p_cur_host FOR
      SELECT pn.international_format,
             h.host_code,
             h.host_name,
             h.host_address,
             h.host_id
        FROM phone_number pn
        JOIN phone_number_series pns ON pns.phone_number_series_id=pn.phone_number_series_id
        JOIN host h ON h.host_id=pns.host_id
       WHERE pn.international_format = p_phone_number
         AND TRIM(h.host_type_code) = TRIM(p_host_type);

  ELSE

    OPEN p_cur_host FOR
      SELECT pn.international_format,
             h.host_code,
             h.host_name,
             h.host_address,
             h.host_id
        FROM phone_number pn
        JOIN network_address_access_point naap ON naap.network_address_id=pn.network_address_id
             AND v_validity_date BETWEEN naap.From_Date AND nvl(naap.To_Date,v_validity_date)
        JOIN sim_card sc ON sc.access_point_id=naap.access_point_id
        JOIN sim_series_host ssh ON ssh.sim_series_id=sc.sim_series_id
             AND v_validity_date BETWEEN ssh.start_date AND nvl(ssh.end_date,v_validity_date)
             AND ssh.host_type_code=TRIM(p_host_type)
        LEFT JOIN ACCESS_POINT_HOST aph ON aph.access_point_id=sc.access_point_id
             AND v_validity_date BETWEEN aph.start_date AND nvl(aph.end_date,v_validity_date)
             AND aph.host_id IN (SELECT hh.host_id FROM host hh WHERE trim(hh.host_type_code)=trim(p_host_type))
        JOIN host h ON (aph.host_id IS NULL AND h.host_id=ssh.host_id) OR (aph.host_id IS NOT NULL AND aph.host_id=h.host_id)
       WHERE pn.international_format = p_phone_number;

  END IF;

  p_error_code:=rsig_utils.c_OK;

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := RSIG_UTILS.Handle_Error(Sqlcode);
    p_error_message:=SQLERRM;

		RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN p_cur_host FOR SELECT p_cur_host,p_error_message FROM dual;

		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Host_By_MSISDN;


------------------------------------------------------------------------------------------------------------------------------
--  Search_Hosts
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Search_Hosts(
  p_network_operator_id    IN  network_operator.network_operator_id%TYPE,
  p_host_code              IN  host.host_code%TYPE,
  p_host_name              IN  host.host_name%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_show_deleted           IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_N,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'RSIG_HOST';
  v_procedure_name        VARCHAR2(30) := 'Searche_Hosts';
  v_event_source          VARCHAR2(60);
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

---------------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
  SELECT n.network_operator_code,
         n.network_operator_name,
         h.host_code,
         h.host_name,
         ht.HOST_TYPE_NAME,
         h.host_location,
         h.deleted
  FROM host h
  JOIN network_operator n ON n.network_operator_id=h.network_operator_id
  JOIN host_type ht ON ht.HOST_TYPE_CODE=h.host_type_code
  WHERE (h.network_operator_id=p_network_operator_id OR p_network_operator_id IS NULL)
    AND (h.host_code LIKE p_host_code OR p_host_code IS NULL)
    AND (h.host_name LIKE p_host_name OR p_host_name IS NULL)
    AND (h.deleted IS NULL OR p_show_deleted = RSIG_UTILS.c_YES);

---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    OPEN p_result_list FOR SELECT p_error_code FROM dual;
    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Search_Hosts;

---------------------------------------------
--     PROCEDURE Get_Hosts
---------------------------------------------

PROCEDURE Get_Hosts
(
  error_code            OUT NUMBER,
  p_host_type_code      IN HOST.HOST_TYPE_CODE%TYPE,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_show_deleted        IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_N,
  p_cur_host            OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Get_Hosts';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_host FOR
    SELECT h.HOST_ID,
           h.HOST_CODE,
           h.HOST_NAME,
           h.NETWORK_OPERATOR_ID,
           h.USER_ID_OF_CHANGE,
           h.DELETED
      FROM HOST h
     WHERE (TRIM(HOST_TYPE_CODE) = TRIM(p_host_type_code) OR p_host_type_code IS NULL)
       AND (h.deleted IS NULL OR p_show_deleted = RSIG_UTILS.c_HANDLE_TRAN_Y)
       AND (h.NETWORK_OPERATOR_ID = p_network_operator_id OR p_network_operator_id IS NULL);

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_cur_host FOR
        SELECT error_code FROM dual;
    END;
END Get_Hosts;

---------------------------------------------
--     PROCEDURE Get_Hosts_By_Host_Type_Codes
---------------------------------------------

PROCEDURE Get_Hosts_By_Host_Type_Codes
(
  p_host_type_codes  IN t_v2_60_tab,
  p_raise_error      IN CHAR,
  p_error_code       OUT NUMBER,
  p_error_message    OUT VARCHAR2,
  p_result_list      OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST.Get_Hosts_By_Host_Type_Codes';
  v_sqlcode      NUMBER;
  v_host_type_code   t_v2_60_obj := t_v2_60_obj(NULL);
  v_host_type_codes  t_v2_60_obj_tab := t_v2_60_obj_tab();
  v_count        NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

   -- check input parameters
  IF p_host_type_codes.COUNT = 0 OR (p_host_type_codes.COUNT = 1 AND p_host_type_codes(p_host_type_codes.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'p_host_type_code');
  END IF;

  v_count:=0;
  FOR i IN nvl(p_host_type_codes.FIRST, 1) .. nvl(p_host_type_codes.LAST, 0)
  LOOP
    v_count := v_count + 1;
    v_host_type_code := t_v2_60_obj(p_host_type_codes(i));
    v_host_type_codes.EXTEND;
    v_host_type_codes(v_count) := v_host_type_code;
  END LOOP;

  -- procedure body here
  OPEN p_result_list FOR
    SELECT h.host_id,
           h.host_code,
           h.host_name,
           h.host_type_code
      FROM HOST h
      JOIN TABLE(CAST(v_host_type_codes as t_v2_60_obj_tab)) htc on TRIM(htc.v2_60) = TRIM(h.host_type_code)
     WHERE (h.deleted IS NULL OR h.deleted > SYSDATE)
     ORDER BY h.host_type_code;

  -- set error code to succesfully completed
  p_error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    p_error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_Hosts_By_Host_Type_Codes;

END;
/
