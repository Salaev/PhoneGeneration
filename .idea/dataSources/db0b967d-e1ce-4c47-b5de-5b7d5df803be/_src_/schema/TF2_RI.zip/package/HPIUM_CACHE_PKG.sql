CREATE package HPIUM_CACHE_PKG is
------------------------------!------------------------------
procedure bs_cache_hpium_ins
(
  v_old personal_account_history%rowtype,
  v_new personal_account_history%rowtype
);
procedure bs_cache_hpium_upd
(
  v_old personal_account_history%rowtype,
  v_new personal_account_history%rowtype
);
------------------------------!------------------------------
procedure msisdn_imsi_cache_hpium_ins
(
  v_old network_address_access_point%rowtype,
  v_new network_address_access_point%rowtype
);
procedure msisdn_imsi_cache_hpium_upd
(
  v_old network_address_access_point%rowtype,
  v_new network_address_access_point%rowtype
);
------------------------------!------------------------------
procedure pa_cache_hpium_upd
(
  v_old sim_card%rowtype,
  v_new sim_card%rowtype
);
------------------------------!------------------------------
end;
/
