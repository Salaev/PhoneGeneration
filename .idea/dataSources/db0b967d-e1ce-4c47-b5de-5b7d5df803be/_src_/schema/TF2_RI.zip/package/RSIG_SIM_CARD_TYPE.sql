CREATE PACKAGE RSIG_SIM_CARD_TYPE IS
/****************************************************************************
<header>
  <name>             	package RSIG_SIM_CARD_TYPE
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>
  <version>           1.0.3     22.11.2006    Petr Cepek
                      procedure Delete_Sim_Card_Type deleted
                      procedure Insert_Sim_Card_Type deleted
                      procedure Update_Sim_Card_Type deleted
  </version>
  <version>           	1.0.2   10.9.2004     Jaroslav Holub
                 				Delete_Sim_Card_Type - fixed for time difference
								        between client and server, date should be null
								        and it means sysdate
  </version>
  <version>          	1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	Package contains procedures for managing sim card types.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/

/****************************************************************************
<header>
  <name>             	procedure Get_Sim_Card_Types
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>          	1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	procedure returns all sim card types as IN OUT ref cursor
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_TEXT_BEFORE_SELECT
                      RSIG_UTILS.c_DEBUG_TEXT_AFTER_SELECT
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
                      RSIG_UTILS.c_DEBUG_LEVEL_2
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        error_code - OUT - NUMBER
                      p_cur_sim_card_types - IN OUT - ref cursor
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Get_Sim_Card_Types (
    error_code                 OUT    NUMBER,
    p_cur_sim_card_types       IN OUT RSIG_UTILS.REF_CURSOR
  );
END RSIG_SIM_CARD_TYPE;
/
