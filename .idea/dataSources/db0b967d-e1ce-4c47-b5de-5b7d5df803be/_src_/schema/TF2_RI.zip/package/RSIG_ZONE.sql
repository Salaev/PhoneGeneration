CREATE PACKAGE RSIG_ZONE IS
/****************************************************************************
<header>
  <name>             	package RSIG_ZONE
  </name>

  <author>           	Jan Stodulka - GITUS
  </author>
  <version>           1.2.2 - 18.03.2011 - Pavel Vasiliev
                      procedure Create_Zones is added
                      procedure Update_Zones is added
                      procedure Delete_Zones is added
  </version>
  <version>           1.2.1      5.6.2007     Petr Cepek
                      procedure Get_Zone_of_Type updated
  </version>
  <version>           1.2.0      14.3.2007     Petr Cepek
                      procedure Get_Zone_Type created
                      procedure Get_Zone_of_Type created
  </version>
  <version>           1.1.10     12.03.2007    Roger Stockley
                      procedure Insert_Zone updated
                      procedure Get_Zone_All updated
  </version>
  <version>           1.1.9     10.04.2006    Petr Cepek
                      procedures Insert_Zone and Update_Zone updated
  </version>
  <version>           1.1.8   	10.9.2004     Jaroslav Holub
              			  Get_All_Zones,Delete_Zone - fixed for time difference
						          between client and server, date should be null
						          and it means sysdate
  </version>
  <version>           1.1.7   13.4.2004     Jaroslav Holub
						          undelete ZONE
  </version>

  <version>           1.1.6   13.4.2004     Pavel Stengl
                      Delete_Zone - add delete dependet on rows in ZONE_BASE_STATION table
  </version>

    <version>         1.1.5  15.12.2003			prybicka
                      *** empty log message ***

  	</version>
    <version>         1.1.3  15.12.2003			prybicka
                      used constants c_DEBUG_TEXT_*

  	</version>
    <version>         1.1.2  15.12.2003			jstodulk
                      Insert parameter RSIG_UTILS.c_MIN_DATE.

  	</version>
    <version>         1.1.1  8.12.2003			jstodulk
                      Created package

  	</version>

  <Description>      	package for table ZONE
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/

/****************************************************************************
  <header>
    <name>              procedure Test_Row_For_Exist_And_Deleted
    </name>

    <author>
    </author>

    <version>
    </version>

    <Description>
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
/****************************************************************************/

PROCEDURE Test_Row_For_Exist_And_Deleted(p_zone_id IN ZONE.ZONE_ID%TYPE);

/****************************************************************************
  <header>
    <name>              procedure Get_All_Zones
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

  	<version>   		1.2.2   10.9.2004     Jaroslav Holub
              					fixed for time difference
								between client and server, date should be null
								and it means sysdate
	</version>
    <version>           1.2.1   13.4.2004      Jaroslav Holub
                                undelete ZONE
    </version>
    <version>           1.2     3.2.2004      Lucie Sevcikova
                                bug fixed
    </version>
    <version>           1.1     15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>     This procedure will return list of zones for given validity date (start_date and end_date).
                      Ref cursor contains columns: ZONE_CODE, ZONE_NAME, NETWORK_OPERATOR_NAME.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code            - Error code
                        p_validity_date       - Date for that it will be finds all zones.
                        p_resul               - ref cursor (ZONE_CODE, ZONE_NAME, NETWORK_OPERATOR_NAME)
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Get_All_Zones(
    error_code            OUT  NUMBER,
    p_validity_date       IN   ZONE_BASE_STATION.START_DATE%TYPE,
    p_result              OUT  RSIG_UTILS.REF_CURSOR
  );

  /****************************************************************************
  <header>
    <name>              procedure Get_Zones
    </name>

    <author>            Pavel Stengl
    </author>

    <version>           1.0.2    13.4.2004      Jaroslav Holub
                                undelete ZONE
    </version>
    <version>           1.0.1   19.1.2004     Pavel Stengl
                                created first version
    </version>

    <Description>     This procedure will return list of zones for given validity date (start_date and end_date)
                      and network operator (network_operator_id).
                      Ref cursor contains columns: ZONE_CODE, ZONE_NAME, NETWORK_OPERATOR_NAME.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code            - Error code
                        p_validity_date       - Date for that it will be finds all zones.
                        p_operator_id         - Network_operation_id for that we want finds all zones
                        p_resul               - ref cursor (ZONE_CODE, ZONE_NAME, NETWORK_OPERATOR_NAME)
    </Parameters>

  </header>
/****************************************************************************/


PROCEDURE Get_Zones(
    error_code            OUT  NUMBER,
    p_operator_id         IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_result              OUT  RSIG_UTILS.REF_CURSOR
  );

 /****************************************************************************
<header>
  <name>             	procedure Insert_Zone
  </name>

  <author>           	Pavel Stengl
  </author>

  <version>           1.0.4   12.03.2007     Roger Stockley
                      parameter p_zone_type_id added.
  </version>
  <version>           1.0.3   10.04.2006     Petr Cepek
                      error messages fixed
  </version>
  <version>           1.0.2   13.4.2004      Jaroslav Holub
                                undelete ZONE
  </version>
  <version>          	1.0.1   21.1.2004     Pavel Stengl
                                created first version
  </version>

  <Description>      	procedure inserts a new zone
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );

                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_zone_code           IN - value for inserting row (ZONE_CODE)
                      p_zone_name           IN - value for inserting row (ZONE_NAME)
                      p_network_operator_id IN - value for inserting row (NETWORK_OPERATOR_ID)
                      p_user_id_of_change   IN - value for inserting row (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/

PROCEDURE Insert_Zone (
    handle_tran               CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_zone_code               IN     zone.zone_code%TYPE,
    p_zone_name               IN     zone.zone_name%TYPE,
    p_zone_type_id            IN     zone.zone_type_code%TYPE,
    p_network_operator_id     IN     zone.network_operator_id%TYPE,
    p_user_id_of_change       IN     zone.user_id_of_change%TYPE
  );

/****************************************************************************
<header>
  <name>             	procedure Delete_Zone
  </name>

  <author>           	Pavel Stengl
  </author>
  <version>   			1.2.2   10.9.2004     Jaroslav Holub
              					fixed for time difference
								between client and server, date should be null
								and it means sysdate
  </version>
  <version>           	1.2.1   13.4.2004      Jaroslav Holub
                                undelete ZONE
  </version>

  <version>          	1.0.2   13.4.2004     Pavel Stengl
                                add delete dependet on rows in ZONE_BASE_STATION table
  </version>
  <version>          	1.0.1   21.1.2004     Pavel Stengl
                                created first version
  </version>

  <Description>      	Procedure sets column DELETED to value of parameter deleted in zone given by zone code,
                      if given zone is currently not deleted.
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_zone_id - IN - value for identification of the updating row (ZONE_ID)
                      p_deleted - IN - value for set attribute (DELETED)
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/

PROCEDURE Delete_Zone (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_zone_id  		          IN     ZONE.ZONE_ID%TYPE,
    p_deleted                 IN     ZONE.DELETED%TYPE,
    p_user_id_of_change       IN     ZONE.USER_ID_OF_CHANGE%TYPE
  );

/****************************************************************************
<header>
  <name>             	procedure Update_Zone
  </name>

  <author>           	Pavel Stengl
  </author>

  <version>          	1.0.2   13.4.2004     Jaroslav Holub
                                undelete ZONE
  </version>

  <version>          	1.0.1   21.1.2004     Pavel Stengl
                                created first version
  </version>

  <Description>      	Procedure changes name and network operator of given zone
                      if given zone is currently not deleted.
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_zone_id             IN - value for inserting row (ZONE_ID)
                      p_zone_code           IN - value for inserting row (ZONE_CODE)
                      p_zone_name           IN - value for inserting row (ZONE_NAME)
                      p_network_operator_id IN - value for inserting row (NETWORK_OPERATOR_ID)
                      p_user_id_of_change   IN - value for inserting row (USER_ID_OF_CHANGE)

</Parameters>

</header>
****************************************************************************/


PROCEDURE Update_Zone (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_zone_id                 IN     zone.zone_id%TYPE,
    p_zone_code               IN     zone.zone_code%TYPE,
    p_zone_name               IN     zone.zone_name%TYPE,
    p_network_operator_id     IN     zone.network_operator_id%TYPE,
    p_user_id_of_change       IN     zone.user_id_of_change%TYPE
  );

 /****************************************************************************
  <header>
    <name>              procedure Get_Zone_All
    </name>

    <author>            Pavel Stengl
    </author>

    <version>           1.0.4   12.03.2007     Roger Stockley
                        cursor now returns additional columns:
                        ZONE_TYPE_CODE,
                        ZONE_TYPE_NAME
    </version>
    <version>           1.0.3   10.04.2006     Petr Cepek
                        error messages fixed
    </version>
    <version>          	1.0.2   13.4.2004     Jaroslav Holub
                                undelete ZONE
    </version>

    <version>           1.0.1   3.2.2004     Pavel Stengl
                                created first version
    </version>

    <Description>     This procedure will return list of all zones (deleted zone too)
											for given network operator (network_operator_id).
                      Ref cursor contains columns: ZONE_CODE, ZONE_NAME, NETWORK_OPERATOR_NAME, DELETED.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code            - Error code
                        p_validity_date       - Date for that it will be finds all zones.
                        p_operator_id         - Network_operation_id for that we want finds all zones
                        p_resul               - ref cursor (ZONE_CODE, ZONE_NAME, NETWORK_OPERATOR_NAME)
    </Parameters>

  </header>
/****************************************************************************/

PROCEDURE Get_Zone_All(
    error_code            OUT  NUMBER,
    p_operator_id         IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_result              OUT  RSIG_UTILS.REF_CURSOR
  );

/****************************************************************************
<header>
  <name>            procedure Get_Zone_Type
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  14.03.2007  -  created
  </version>

  <Description>     Procedure returns zone types which are not yet used for
                    given location area or base station.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Zone_Type(
  p_LA_ID                  IN  location_area.location_area_id%TYPE,
  p_BS_ID                  IN  base_station.base_station_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure Get_Zone_of_Type
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  14.03.2007  -  created
  </version>
  <version>
                    1.0.1  5.6.2007 - Petr Cepek
                    procedure returns zones of specific type for current operators
                    and all its parents
  </version>

  <Description>     Procedure returns zones of some given type.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Zone_of_Type(
  p_zone_type_id           IN  ZONE.ZONE_TYPE_code%TYPE,
  p_NO_id                  IN  network_operator.network_operator_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);


----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
END RSIG_ZONE;
-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_ZONE.pkg,v 1.5 2003/12/15 10:21:13 prybicka Exp $
/
