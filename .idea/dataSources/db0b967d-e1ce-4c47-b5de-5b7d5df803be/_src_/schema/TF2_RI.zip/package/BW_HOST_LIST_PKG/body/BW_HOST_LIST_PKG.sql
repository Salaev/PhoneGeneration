CREATE package body BW_HOST_LIST_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure add_host2black_list(p_host_id ct_number, p_date date, p_user_id number)
is
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_host_id, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  group_pkg.group_add_items_id1
  (
    p_group_id => c_agroup_id_black_host_list,
    p_unique => true,
    p_id1 => p_host_id,
    p_date => p_date,
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_host2black_list2(p_host_id ct_number, p_user_id number)
is
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_host_id, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  add_host2black_list
  (
    p_host_id => p_host_id,
    p_date => sysdate,
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_host2black_list3(p_host_id number, p_user_id number)
is
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  add_host2black_list2
  (
    p_host_id => v_host_id,
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_host2black_list(p_host_id ct_number, p_date date, p_user_id number)
is
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_host_id, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  group_pkg.group_del_items_id1
  (
    p_group_id => c_agroup_id_black_host_list,
    p_id1 => p_host_id,
    p_date => p_date,
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_host2black_list2(p_host_id ct_number, p_user_id number)
is
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_host_id, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  del_host2black_list
  (
    p_host_id => p_host_id,
    p_date => sysdate,
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_host2black_list3(p_host_id number, p_user_id number)
is
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  del_host2black_list2
  (
    p_host_id => v_host_id,
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_black_list(p_date date) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  select
    id1
  bulk collect into
    v_res
  from table(vp_agroup_data.getN(c_agroup_id_black_host_list, p_date))
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_black_list2 return ct_number
is
begin
  ------------------------------
  return get_black_list(p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure add_host2white_list(p_host_id ct_number, p_date date, p_user_id number)
is
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_host_id, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  group_pkg.group_add_items_id1
  (
    p_group_id => c_agroup_id_white_host_list,
    p_unique => true,
    p_id1 => p_host_id,
    p_date => p_date,
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_host2white_list2(p_host_id ct_number, p_user_id number)
is
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_host_id, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  add_host2white_list
  (
    p_host_id => p_host_id,
    p_date => sysdate,
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_host2white_list3(p_host_id number, p_user_id number)
is
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  add_host2white_list2
  (
    p_host_id => v_host_id,
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_host2white_list(p_host_id ct_number, p_date date, p_user_id number)
is
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_host_id, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  group_pkg.group_del_items_id1
  (
    p_group_id => c_agroup_id_white_host_list,
    p_id1 => p_host_id,
    p_date => p_date,
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_host2white_list2(p_host_id ct_number, p_user_id number)
is
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_host_id, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  del_host2white_list
  (
    p_host_id => p_host_id,
    p_date => sysdate,
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_host2white_list3(p_host_id number, p_user_id number)
is
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  del_host2white_list2
  (
    p_host_id => v_host_id,
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_white_list(p_date date) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  select
    id1
  bulk collect into
    v_res
  from table(vp_agroup_data.getN(c_agroup_id_white_host_list, p_date))
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_white_list2 return ct_number
is
begin
  ------------------------------
  return get_white_list(p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
end;
/
