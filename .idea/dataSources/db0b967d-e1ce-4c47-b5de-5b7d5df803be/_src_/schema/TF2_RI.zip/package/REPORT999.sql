CREATE package REPORT999 is

----------------------------------!---------------------------------------------
  c_roaming_neighbour_regions    constant number := 16;
  c_roaming_federal_districts    constant number := 32;

  c_not_active                   constant number := 0;
  c_active                       constant number := 1;

----------------------------------!---------------------------------------------
  function get_length_without_mask(p_str varchar2) return number;
  function get_entry_count(p_str varchar2, p_val varchar2) return number;
  function is_2_consume_1
  (
    p_significant_symbol_count_1 number,
    p_underline_count_1 number,
    p_percent_count_1 number,
    p_significant_symbol_count_2 number,
    p_underline_count_2 number,
    p_percent_count_2 number
  ) return number;

----------------------------------!---------------------------------------------
  procedure get_net_op_neighbours_ii
  (
    p_network_operator_ids ct_number,
    p_date date,
    p_roaming_definition_ids out ct_number
  );

  procedure get_no_neigh_rules_relations_i
  (
    p_roaming_definition_ids ct_number,
    p_out_roaming_definition_id out ct_number,
    p_consume_roaming_definition out ct_number
  );

  procedure get_valuable_no_neigh_rules_i
  (
    p_roaming_definition_id ct_number,
    p_out_roaming_definition_id out ct_number,
    p_roaming_type_code out ct_number,
    p_act out ct_number
  );

  procedure get_net_op_neighbours_i
  (
    p_network_operator_codes ct_varchar_s,
    p_date date, p_out_roaming_definition_id out ct_number,
    p_roaming_type_code out ct_number,
    p_act out ct_number
  );

----------------------------------!---------------------------------------------
  procedure get_net_op_neighbours
  (
    p_network_operator_codes ct_varchar_s,
    p_date date,
    p_result_list out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure reports_get_phones
  (
    p_host_id number,
    p_network_operator_id number,
    p_phone_type varchar2,
    p_salability_category_l ct_varchar_s,
    p_phone_number_status_code ct_varchar_s,
    p_search_date date,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure get_result_cursor01
  (
    p_roaming_definition_id ct_number,
    p_roaming_type_code ct_number,
    p_act ct_number,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------

end;

/
