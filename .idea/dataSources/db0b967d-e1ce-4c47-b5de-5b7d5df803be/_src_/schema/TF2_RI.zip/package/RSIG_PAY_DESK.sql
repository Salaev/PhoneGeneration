CREATE PACKAGE RSIG_PAY_DESK IS
/****************************************************************************
<header>
  <name>             	package RSIG_PAY_DESK
  </name>

  <author>           	Pavel Stengl
  </author>
  <version>          	1.1.2   03.09.2004     Jaroslav  Holub
                                 Delete_Pay_Desk - changed for NULL date acceptance in start(end)date
                                - if NULL presented then sysdate is filled instead
  </version>
  <version>          1.1.1   30.3.2004     Pavel Stengl
                             procedure Insert_Pay_Desk and  -  	add check exception - PAY_DESK_NAME
							 procedure Update_Pay_Desk		-	add check exception - PAY_DESK_NAME
  </version>
  <version>			 1.1.0  29.1.2004		pstengl
                      		Created package
  </version>

  <Description>      	package for table PAY_DESK
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/


 /****************************************************************************
<header>
  <name>             	procedure Insert_Pay_Desk
  </name>

  <author>           	Pavel Stengl
  </author>

  <version>          	1.0.2   30.3.2004     Pavel Stengl
                                add check exception - PAY_DESK_NAME
  </version>
  <version>          	1.0.1   21.1.2004     Pavel Stengl
                                created first version
  </version>

  <Description>      	procedure inserts a new pay desk
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );

                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER

					 p_pay_desk_sn 	 	 	  IN - value for insertinq row (PAY_DESK_SN)
					 p_pay_desk_code       IN - value for inserting row (PAY_DESK_CODE)
                     p_pay_desk_name       IN - value for inserting row (PAY_DESK_NAME)
                     p_network_operator_id IN - value for inserting row (NETWORK_OPERATOR_ID)
                     p_user_id_of_change   IN - value for inserting row (USER_ID_OF_CHANGE)
					 p_pay_desk_id					OUT - id inserting row (PAY_DESK_ID)
 </Parameters>

</header>
****************************************************************************/

PROCEDURE Insert_Pay_Desk (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
		p_pay_desk_sn							IN		 pay_desk.pay_desk_sn%TYPE,
		p_pay_desk_code						IN		 pay_desk.pay_desk_code%TYPE,
		P_pay_desk_name						IN		 pay_desk.pay_desk_name%TYPE,
		p_payment_entrance_id     IN     pay_desk.payment_entrance_id%TYPE,
		p_user_id_of_change       IN     pay_desk.user_id_of_change%TYPE,
		p_pay_desk_id							OUT 	 PAY_DESK.PAY_DESK_ID%TYPE
  );


/****************************************************************************
<header>
  <name>             	procedure Delete_Pay_Desk
  </name>

  <author>           	Pavel Stengl
  </author>

  <version>          	1.0.2   03.09.2004     Jaroslav  Holub
                                 changed for NULL date acceptance in start(end)date
                                - if NULL presented then sysdate is filled instead
  </version>
  <version>          	1.0.1   30.1.2004     Pavel Stengl
                                created first version
  </version>

  <Description>      	Procedure sets column DELETED to value of parameter deleted in pay desk given by pay desk code,
                      if given pay desk is currently not deleted.
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_pay_desk_id  - IN - value for identification of the updating row (PAY_DESK_ID)
                      p_deleted      - IN - value for set attribute (DELETED)
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/

PROCEDURE Delete_Pay_Desk (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_pay_desk_id             IN     PAY_DESK.PAY_DESK_ID%TYPE,
    p_deleted                 IN     PAY_DESK.DELETED%TYPE,
    p_user_id_of_change       IN     PAY_DESK.USER_ID_OF_CHANGE%TYPE
  );

/****************************************************************************
<header>
  <name>             	procedure Update_Pay_Desk
  </name>

  <author>           	Pavel Stengl
  </author>

  <version>          	1.0.2   30.3.2004     Pavel Stengl
                                add check exception - PAY_DESK_NAME
  </version>
  <version>          	1.0.1   30.1.2004     Pavel Stengl
                                created first version
  </version>

  <Description>      	Procedure changes serial number, code, name and network operator of given pay desk
                      if given pay desk is currently not deleted.
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
											p_pay_desk_id		 	 		IN - value for idenstification row (PAY_DESK_ID)
											p_pay_desk_sn				  IN - value for insertinq row (PAY_DESK_SN)
                      p_pay_desk_code       IN - value for inserting row (PAY_DESK_CODE)
                      p_pay_desk_name       IN - value for inserting row (PAY_DESK_NAME)
                      p_network_operator_id IN - value for inserting row (NETWORK_OPERATOR_ID)
                      p_user_id_of_change   IN - value for inserting row (USER_ID_OF_CHANGE)

</Parameters>

</header>
****************************************************************************/

PROCEDURE Update_Pay_Desk (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
		p_pay_desk_id							IN		 pay_desk.pay_desk_id%TYPE,
		p_pay_desk_sn						  IN		 pay_desk.pay_desk_sn%TYPE,
		p_pay_desk_code						IN		 pay_desk.pay_desk_code%TYPE,
		p_pay_desk_name						IN		 pay_desk.pay_desk_name%TYPE,
		p_payment_entrance_id     IN     pay_desk.payment_entrance_id%TYPE,
		p_user_id_of_change       IN     pay_desk.user_id_of_change%TYPE
  );


  /****************************************************************************
  <header>
    <name>              procedure Get_Pay_Desk
    </name>

    <author>            Pavel Stengl
    </author>

    <version>           1.0.1   19.1.2004     Pavel Stengl
                                created first version
    </version>

    <Description>     This procedure will return list of pay desk for given network operator (network_operator_id).
											if p_all_rows = 'Y', ref cursor will be contains deleted rows too
                      Ref cursor contains columns: PAY_DESK_ID, SERIAL_NUMBER, PAY_DESK_CODE,
																 									 PAY_DESK_NAME, NETWORK_OPERATOR_NAME.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code            - Error code
                        p_validity_date       - Date for that it will be finds all zones.
                        p_operator_id         - Network_operation_id for that we want finds all zones
                        p_resul               - ref cursor (PAY_DESK_ID, SERIAL_NUMBER,
																													  PAY_DESK_CODE, PAY_DESK_NAME, NETWORK_OPERATOR_NAME)
    </Parameters>

  </header>
/****************************************************************************/


PROCEDURE Get_Pay_Desk(
    error_code            OUT  NUMBER,
    p_payment_entrance_id IN   PAY_DESK.PAYMENT_ENTRANCE_ID%TYPE,
		p_all_rows						IN   CHAR,
    p_result              OUT  RSIG_UTILS.REF_CURSOR
  );
END RSIG_PAY_DESK;
/
