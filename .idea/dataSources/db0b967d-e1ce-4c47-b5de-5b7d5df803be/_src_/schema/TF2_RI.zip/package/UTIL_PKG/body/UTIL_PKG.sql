CREATE package body util_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function date_from2date_to_prev(p_date date) return date
is
begin
  ------------------------------
  return (p_date - c_dt_dif);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function date_to2date_from_next(p_date date) return date
is
begin
  ------------------------------
  return (p_date + c_dt_dif);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure raise_exception(p_code number, p_message varchar2)
is
  v_code number;
  v_message varchar2(2048);
begin
  ------------------------------
  if p_code between c_ora_x_user_min and c_ora_x_user_max
  then
    v_code := p_code;
  else
    v_code := c_ora_x_user_max;
  end if;
  ------------------------------
  v_message := substr(p_message, 1, c_max_error_message_length2);
  ------------------------------
  raise_application_error(v_code, v_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure raise_label_exception(p_label varchar2, p_code number, p_message varchar2)
is
begin
  ------------------------------
  raise_exception(c_ora_x_common, p_label || c_msg_delim01 || p_code || c_msg_delim02 || p_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure reraise_exception
is
begin
  ------------------------------
  raise_exception(get_err_code, get_err_msg);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--make sure for dbms_utility.format_error_backtrace
----------------------------------!---------------------------------------------
function cut_err_msg(p_str varchar2) return varchar2
is
begin
  ------------------------------
  return substr(p_str, 1, c_max_error_message_length);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_err_msg return varchar2
is
begin
  ------------------------------
  return cut_err_msg('Error stack:' || chr(10) || dbms_utility.format_error_stack || 'Error backtrace:' || chr(10) || dbms_utility.format_error_backtrace);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_err_code return number
is
begin
  ------------------------------
  return sqlcode;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_error(p_err_code number) return boolean
is
begin
  ------------------------------
  if p_err_code = c_ora_ok
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_ok(p_err_code number) return boolean
is
begin
  ------------------------------
  return not is_error(p_err_code);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_error(p_code out number, p_message out varchar2)
is
begin
  ------------------------------
  p_code := get_err_code;
  ------------------------------
  p_message := get_err_msg;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_ok(p_code out number, p_message out varchar2)
is
begin
  ------------------------------
  p_code := c_ora_ok;
  ------------------------------
  p_message := c_msg_ok;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_clear(p_code out number, p_message out varchar2)
is
begin
  ------------------------------
  p_code := NULL;
  ------------------------------
  p_message := NULL;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_err_msg_ondate(p_id_str varchar2, p_date date) return varchar2
is
begin
  ------------------------------
  return cut_err_msg(p_id_str || c_msg_delim02 || date_to_char(p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_err_msg_ondate2(p_id1_str varchar2, p_id2_str varchar2, p_date date) return varchar2
is
begin
  ------------------------------
  return cut_err_msg(p_id1_str || c_msg_delim02 || p_id2_str || c_msg_delim02 || date_to_char(p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_err_msg_ondate3(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_date date) return varchar2
is
begin
  ------------------------------
  return cut_err_msg(p_id1_str || c_msg_delim02 || p_id2_str || c_msg_delim02 || p_id3_str || c_msg_delim02 || date_to_char(p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_err_msg_vers(p_id_str varchar2, p_date_from date, p_date_to date) return varchar2
is
begin
  ------------------------------
  return cut_err_msg(p_id_str || c_msg_delim02 || date_to_char(p_date_from) || c_msg_delim02 || date_to_char(p_date_to));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_err_msg_vers2(p_id1_str varchar2, p_id2_str varchar2, p_date_from date, p_date_to date) return varchar2
is
begin
  ------------------------------
  return cut_err_msg(p_id1_str || c_msg_delim02 || p_id2_str || c_msg_delim02 || date_to_char(p_date_from) || c_msg_delim02 || date_to_char(p_date_to));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_err_msg_vers3(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_date_from date, p_date_to date) return varchar2
is
begin
  ------------------------------
  return cut_err_msg(p_id1_str || c_msg_delim02 || p_id2_str || c_msg_delim02 || p_id3_str || c_msg_delim02 || date_to_char(p_date_from) || c_msg_delim02 || date_to_char(p_date_to));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function date_to_char(p_val date) return varchar2
is
begin
  ------------------------------
  return to_char(p_val, c_date_format_full);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function char_to_date(p_val varchar2) return date
is
begin
  ------------------------------
  return to_date(p_val, c_date_format_full);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function date_to_char_full_compact(p_val date) return varchar2
is
begin
  ------------------------------
  return to_char(p_val, c_date_format_full_compact);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function char_to_date_full_compact(p_val varchar2) return date
is
begin
  ------------------------------
  return to_date(p_val, c_date_format_full_compact);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function number_to_char(p_val number) return varchar2
is
begin
  ------------------------------
  return to_char(p_val, c_number_format1, c_number_nlsparam);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function char_to_number(p_val varchar2) return number
is
begin
  ------------------------------
  return to_number(p_val, c_number_format2, c_number_nlsparam);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function nchar_to_char(p_val nvarchar2) return varchar2
is
begin
  ------------------------------
  return to_char(p_val);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function char_to_nchar(p_val varchar2) return nvarchar2
is
begin
  ------------------------------
  return to_nchar(p_val);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function bool_to_char(p_val boolean) return varchar2
is
begin
  ------------------------------
  if p_val
  then
    return c_true_str;
  elsif not p_val
  then
    return c_false_str;
  else
    return null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function char_to_bool(p_val varchar2) return boolean
is
begin
  ------------------------------
  if lower(trim(p_val)) = c_true_str
  then
    return true;
  elsif lower(trim(p_val)) = c_false_str
  then
    return false;
  elsif trim(p_val) is null
  then
    return null;
  else
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || p_val);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function bool_to_int(p_val boolean) return number
is
begin
  ------------------------------
  return sys.diutil.bool_to_int(p_val);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function bool_to_int_2val(p_val boolean) return number
is
begin
  ------------------------------
  return bool_to_int(nvl(p_val, false));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function bool_to_int_3val(p_val boolean) return number
is
begin
  ------------------------------
  return bool_to_int(p_val);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function int_to_bool(p_val number) return boolean
is
begin
  ------------------------------
  return sys.diutil.int_to_bool(p_val);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function int_to_bool_2val(p_val number) return boolean
is
begin
  ------------------------------
  return nvl(int_to_bool(p_val), false);
  ------------------------------
exception
when others then
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function int_to_bool_3val(p_val number) return boolean
is
begin
  ------------------------------
  return int_to_bool(int_to_int_3val(p_val));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function bool_to_bool_2val(p_val boolean) return boolean
is
begin
  ------------------------------
  return int_to_bool_2val(bool_to_int_2val(p_val));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function int_to_int_2val(p_val number) return number
is
begin
  ------------------------------
  return bool_to_int_2val(int_to_bool_2val(p_val));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function int_to_int_3val(p_val number) return number
is
begin
  ------------------------------
  if p_val is null
  then
    return null;
  elsif p_val = 0
  then
    return c_false;
  else
    return c_true;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function date_dif_from_days(p_val number) return number
is
begin
  ------------------------------
  return p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function date_dif_from_hours(p_val number) return number
is
begin
  ------------------------------
  return p_val*c_hour;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function date_dif_from_minutes(p_val number) return number
is
begin
  ------------------------------
  return p_val*c_minute;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function date_dif_from_seconds(p_val number) return number
is
begin
  ------------------------------
  return p_val*c_second;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function days_from_date_dif(p_val number) return number
is
begin
  ------------------------------
  return p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function hours_from_date_dif(p_val number) return number
is
begin
  ------------------------------
  return p_val/c_hour;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function minutes_from_date_dif(p_val number) return number
is
begin
  ------------------------------
  return p_val/c_minute;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function seconds_from_date_dif(p_val number) return number
is
begin
  ------------------------------
  return p_val/c_second;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function month_begin(p_val date) return date
is
begin
  ------------------------------
  return trunc(p_val, 'mm');
  ------------------------------
end;

----------------------------------!---------------------------------------------
function month_end(p_val date) return date
is
begin
  ------------------------------
  return trunc(add_months(p_val, 1), 'mm') - c_second;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function month_next_begin(p_val date) return date
is
begin
  ------------------------------
  return month_begin(add_months(p_val, 1));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function year_begin(p_val date) return date
is
begin
  ------------------------------
  return trunc(p_val, 'yyyy');
  ------------------------------
end;

----------------------------------!---------------------------------------------
function year_end(p_val date) return date
is
begin
  ------------------------------
  return year_begin(add_months(p_val, 12)) - c_second;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function year_next_begin(p_val date) return date
is
begin
  ------------------------------
  return year_begin(add_months(p_val, 12));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_year(p_val date) return number
is
begin
  ------------------------------
  return char_to_number(to_char(p_val, 'syyyy'));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_month(p_val date) return number
is
begin
  ------------------------------
  return char_to_number(to_char(p_val, 'mm'));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_day(p_val date) return number
is
begin
  ------------------------------
  return char_to_number(to_char(p_val, 'dd'));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_hour(p_val date) return number
is
begin
  ------------------------------
  return char_to_number(to_char(p_val, 'hh24'));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_minute(p_val date) return number
is
begin
  ------------------------------
  return char_to_number(to_char(p_val, 'mi'));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_second(p_val date) return number
is
begin
  ------------------------------
  return char_to_number(to_char(p_val, 'ss'));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function wrap_date_part(p_val number, p_max_len number) return varchar2
is
  lc_zero varchar2(1) := '0';
  v_val varchar2(100);
begin
  ------------------------------
  XCheck_Cond_Missing(p_val is null, 'p_val');
  XCheck_Cond_Missing(p_max_len is null, 'p_max_len');
  ------------------------------
  XCheck_Cond_Invalid(p_max_len <= 0, 'p_max_len <= 0');
  ------------------------------
  v_val := number_to_char(p_val);
  ------------------------------
  XCheck_Cond_Invalid(str_length(v_val) > p_max_len, 'str_length(v_val) > p_max_len');
  ------------------------------
  return lpad(v_val, p_max_len, lc_zero);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_date
(
  p_year number,
  p_month number,
  p_day number,
  p_hour number,
  p_minute number,
  p_second number
) return date
is
begin
  ------------------------------
  return char_to_date_full_compact
  (
       wrap_date_part(p_year, 4)
    || wrap_date_part(p_month, 2)
    || wrap_date_part(p_day, 2)
    || wrap_date_part(p_hour, 2)
    || wrap_date_part(p_minute, 2)
    || wrap_date_part(p_second, 2)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function change_date_year(p_date date, p_year number) return date
is
begin
  ------------------------------
  return make_date
  (
    p_year => p_year,
    p_month => get_month(p_date),
    p_day => get_day(p_date),
    p_hour => get_hour(p_date),
    p_minute => get_minute(p_date),
    p_second => get_second(p_date)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function change_date_month(p_date date, p_month number) return date
is
begin
  ------------------------------
  return make_date
  (
    p_year => get_year(p_date),
    p_month => p_month,
    p_day => get_day(p_date),
    p_hour => get_hour(p_date),
    p_minute => get_minute(p_date),
    p_second => get_second(p_date)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function change_date_day(p_date date, p_day number) return date
is
begin
  ------------------------------
  return make_date
  (
    p_year => get_year(p_date),
    p_month => get_month(p_date),
    p_day => p_day,
    p_hour => get_hour(p_date),
    p_minute => get_minute(p_date),
    p_second => get_second(p_date)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function change_date_hour(p_date date, p_hour number) return date
is
begin
  ------------------------------
  return make_date
  (
    p_year => get_year(p_date),
    p_month => get_month(p_date),
    p_day => get_day(p_date),
    p_hour => p_hour,
    p_minute => get_minute(p_date),
    p_second => get_second(p_date)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function change_date_minute(p_date date, p_minute number) return date
is
begin
  ------------------------------
  return make_date
  (
    p_year => get_year(p_date),
    p_month => get_month(p_date),
    p_day => get_day(p_date),
    p_hour => get_hour(p_date),
    p_minute => p_minute,
    p_second => get_second(p_date)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function change_date_second(p_date date, p_second number) return date
is
begin
  ------------------------------
  return make_date
  (
    p_year => get_year(p_date),
    p_month => get_month(p_date),
    p_day => get_day(p_date),
    p_hour => get_hour(p_date),
    p_minute => get_minute(p_date),
    p_second => p_second
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function empty_cit_number return cit_number
is
  v_res cit_number;
begin
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct2cit_number(p_coll ct_number) return cit_number
is
  v_res cit_number;
begin
  ------------------------------
  if not CheckP_ct_number(p_coll)
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit2ct_number(p_coll cit_number, p_smart_cit boolean) return ct_number
is
  v_res ct_number;
  v_smart_cit boolean := bool_to_bool_2val(p_smart_cit);
  v_i number;
  v_j number;
begin
  ------------------------------
  if not CheckP_cit_number(p_coll, v_smart_cit)
  then
    return v_res;
  end if;
  ------------------------------
  resize_ct_number(v_res, p_coll.count);
  ------------------------------
  v_i := p_coll.first;
  v_j := 0;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_j := v_j + 1;
    v_res(v_j) := p_coll(v_i);
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_equal_ct_number(p_coll1 ct_number, p_coll2 ct_number, p_only_len boolean) return boolean
is
  v_res boolean;
  v_len1 number;
  v_len2 number;
  v_exists1 boolean;
  v_exists2 boolean;
begin
  ------------------------------
  if p_coll1 is null or p_coll1.count = 0
  then
    v_len1 := 0;
  else
    v_len1 := p_coll1.count;
  end if;
  ------------------------------
  if p_coll2 is null or p_coll2.count = 0
  then
    v_len2 := 0;
  else
    v_len2 := p_coll2.count;
  end if;
  ------------------------------
  if v_len1 != v_len2
  then
    return false;
  end if;
  ------------------------------
  if v_len1 = 0 and v_len2 = 0
  then
    return true;
  end if;
  ------------------------------
  if nvl(p_only_len, false)
  then
    return true;
  end if;
  ------------------------------
  v_res := true;
  ------------------------------
  for v_i in p_coll1.first..p_coll2.last
  loop
    ------------------------------
    v_exists1 := p_coll1.exists(v_i);
    v_exists2 := p_coll2.exists(v_i);
    ------------------------------
    if v_exists1 != v_exists2 then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if NOT v_exists1 and NOT v_exists2
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null and p_coll2(v_i) is null
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null or p_coll2(v_i) is null
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) != p_coll2(v_i)
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_equal_cit_number(p_coll1 cit_number, p_coll2 cit_number, p_only_len boolean) return boolean
is
  v_res boolean;
  v_len1 number;
  v_len2 number;
  v_i number;
  v_j number;
begin
  ------------------------------
  if p_coll1 is null or p_coll1.count = 0
  then
    v_len1 := 0;
  else
    v_len1 := p_coll1.count;
  end if;
  ------------------------------
  if p_coll2 is null or p_coll2.count = 0
  then
    v_len2 := 0;
  else
    v_len2 := p_coll2.count;
  end if;
  ------------------------------
  if v_len1 != v_len2
  then
    return false;
  end if;
  ------------------------------
  if v_len1 = 0 and v_len2 = 0
  then
    return true;
  end if;
  ------------------------------
  if nvl(p_only_len, false)
  then
    return true;
  end if;
  ------------------------------
  v_res := true;
  v_i := p_coll1.first;
  v_j := p_coll2.first;
  ------------------------------
  while v_i is not null or v_j is not null
  loop
    ------------------------------
    if v_i is null or v_j is null
    then
      ------------------------------
      if v_i is not null or v_j is not null
      then
        v_res := false;
      end if;
      ------------------------------
      exit;
      ------------------------------
    end if;
    ------------------------------
    if v_i != v_j
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) is null and p_coll2(v_i) is null
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null or p_coll2(v_i) is null
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) != p_coll2(v_i)
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    v_i := p_coll1.next(v_i);
    v_j := p_coll2.next(v_j);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function empty_cit_date return cit_date
is
  v_res cit_date;
begin
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct2cit_date(p_coll ct_date) return cit_date
is
  v_res cit_date;
begin
  ------------------------------
  if not CheckP_ct_date(p_coll)
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit2ct_date(p_coll cit_date, p_smart_cit boolean) return ct_date
is
  v_res ct_date;
  v_smart_cit boolean := bool_to_bool_2val(p_smart_cit);
  v_i number;
  v_j number;
begin
  ------------------------------
  if not CheckP_cit_date(p_coll, v_smart_cit)
  then
    return v_res;
  end if;
  ------------------------------
  resize_ct_date(v_res, p_coll.count);
  ------------------------------
  v_i := p_coll.first;
  v_j := 0;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_j := v_j + 1;
    v_res(v_j) := p_coll(v_i);
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_equal_ct_date(p_coll1 ct_date, p_coll2 ct_date, p_only_len boolean) return boolean
is
  v_res boolean;
  v_len1 number;
  v_len2 number;
  v_exists1 boolean;
  v_exists2 boolean;
begin
  ------------------------------
  if p_coll1 is null or p_coll1.count = 0
  then
    v_len1 := 0;
  else
    v_len1 := p_coll1.count;
  end if;
  ------------------------------
  if p_coll2 is null or p_coll2.count = 0
  then
    v_len2 := 0;
  else
    v_len2 := p_coll2.count;
  end if;
  ------------------------------
  if v_len1 != v_len2
  then
    return false;
  end if;
  ------------------------------
  if v_len1 = 0 and v_len2 = 0
  then
    return true;
  end if;
  ------------------------------
  if nvl(p_only_len, false)
  then
    return true;
  end if;
  ------------------------------
  v_res := true;
  ------------------------------
  for v_i in p_coll1.first..p_coll2.last
  loop
    ------------------------------
    v_exists1 := p_coll1.exists(v_i);
    v_exists2 := p_coll2.exists(v_i);
    ------------------------------
    if v_exists1 != v_exists2 then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if NOT v_exists1 and NOT v_exists2
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null and p_coll2(v_i) is null
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null or p_coll2(v_i) is null
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) != p_coll2(v_i)
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_equal_cit_date(p_coll1 cit_date, p_coll2 cit_date, p_only_len boolean) return boolean
is
  v_res boolean;
  v_len1 number;
  v_len2 number;
  v_i number;
  v_j number;
begin
  ------------------------------
  if p_coll1 is null or p_coll1.count = 0
  then
    v_len1 := 0;
  else
    v_len1 := p_coll1.count;
  end if;
  ------------------------------
  if p_coll2 is null or p_coll2.count = 0
  then
    v_len2 := 0;
  else
    v_len2 := p_coll2.count;
  end if;
  ------------------------------
  if v_len1 != v_len2
  then
    return false;
  end if;
  ------------------------------
  if v_len1 = 0 and v_len2 = 0
  then
    return true;
  end if;
  ------------------------------
  if nvl(p_only_len, false)
  then
    return true;
  end if;
  ------------------------------
  v_res := true;
  v_i := p_coll1.first;
  v_j := p_coll2.first;
  ------------------------------
  while v_i is not null or v_j is not null
  loop
    ------------------------------
    if v_i is null or v_j is null
    then
      ------------------------------
      if v_i is not null or v_j is not null
      then
        v_res := false;
      end if;
      ------------------------------
      exit;
      ------------------------------
    end if;
    ------------------------------
    if v_i != v_j
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) is null and p_coll2(v_i) is null
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null or p_coll2(v_i) is null
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) != p_coll2(v_i)
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    v_i := p_coll1.next(v_i);
    v_j := p_coll2.next(v_j);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function empty_cit_varchar_s return cit_varchar_s
is
  v_res cit_varchar_s;
begin
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct2cit_varchar_s(p_coll ct_varchar_s) return cit_varchar_s
is
  v_res cit_varchar_s;
begin
  ------------------------------
  if not CheckP_ct_varchar_s(p_coll)
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit2ct_varchar_s(p_coll cit_varchar_s, p_smart_cit boolean) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_smart_cit boolean := bool_to_bool_2val(p_smart_cit);
  v_i number;
  v_j number;
begin
  ------------------------------
  if not CheckP_cit_varchar_s(p_coll, v_smart_cit)
  then
    return v_res;
  end if;
  ------------------------------
  resize_ct_varchar_s(v_res, p_coll.count);
  ------------------------------
  v_i := p_coll.first;
  v_j := 0;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_j := v_j + 1;
    v_res(v_j) := p_coll(v_i);
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_equal_ct_varchar_s(p_coll1 ct_varchar_s, p_coll2 ct_varchar_s, p_only_len boolean) return boolean
is
  v_res boolean;
  v_len1 number;
  v_len2 number;
  v_exists1 boolean;
  v_exists2 boolean;
begin
  ------------------------------
  if p_coll1 is null or p_coll1.count = 0
  then
    v_len1 := 0;
  else
    v_len1 := p_coll1.count;
  end if;
  ------------------------------
  if p_coll2 is null or p_coll2.count = 0
  then
    v_len2 := 0;
  else
    v_len2 := p_coll2.count;
  end if;
  ------------------------------
  if v_len1 != v_len2
  then
    return false;
  end if;
  ------------------------------
  if v_len1 = 0 and v_len2 = 0
  then
    return true;
  end if;
  ------------------------------
  if nvl(p_only_len, false)
  then
    return true;
  end if;
  ------------------------------
  v_res := true;
  ------------------------------
  for v_i in p_coll1.first..p_coll2.last
  loop
    ------------------------------
    v_exists1 := p_coll1.exists(v_i);
    v_exists2 := p_coll2.exists(v_i);
    ------------------------------
    if v_exists1 != v_exists2 then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if NOT v_exists1 and NOT v_exists2
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null and p_coll2(v_i) is null
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null or p_coll2(v_i) is null
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) != p_coll2(v_i)
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_equal_cit_varchar_s(p_coll1 cit_varchar_s, p_coll2 cit_varchar_s, p_only_len boolean) return boolean
is
  v_res boolean;
  v_len1 number;
  v_len2 number;
  v_i number;
  v_j number;
begin
  ------------------------------
  if p_coll1 is null or p_coll1.count = 0
  then
    v_len1 := 0;
  else
    v_len1 := p_coll1.count;
  end if;
  ------------------------------
  if p_coll2 is null or p_coll2.count = 0
  then
    v_len2 := 0;
  else
    v_len2 := p_coll2.count;
  end if;
  ------------------------------
  if v_len1 != v_len2
  then
    return false;
  end if;
  ------------------------------
  if v_len1 = 0 and v_len2 = 0
  then
    return true;
  end if;
  ------------------------------
  if nvl(p_only_len, false)
  then
    return true;
  end if;
  ------------------------------
  v_res := true;
  v_i := p_coll1.first;
  v_j := p_coll2.first;
  ------------------------------
  while v_i is not null or v_j is not null
  loop
    ------------------------------
    if v_i is null or v_j is null
    then
      ------------------------------
      if v_i is not null or v_j is not null
      then
        v_res := false;
      end if;
      ------------------------------
      exit;
      ------------------------------
    end if;
    ------------------------------
    if v_i != v_j
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) is null and p_coll2(v_i) is null
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null or p_coll2(v_i) is null
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) != p_coll2(v_i)
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    v_i := p_coll1.next(v_i);
    v_j := p_coll2.next(v_j);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function empty_cit_varchar return cit_varchar
is
  v_res cit_varchar;
begin
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct2cit_varchar(p_coll ct_varchar) return cit_varchar
is
  v_res cit_varchar;
begin
  ------------------------------
  if not CheckP_ct_varchar(p_coll)
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit2ct_varchar(p_coll cit_varchar, p_smart_cit boolean) return ct_varchar
is
  v_res ct_varchar;
  v_smart_cit boolean := bool_to_bool_2val(p_smart_cit);
  v_i number;
  v_j number;
begin
  ------------------------------
  if not CheckP_cit_varchar(p_coll, v_smart_cit)
  then
    return v_res;
  end if;
  ------------------------------
  resize_ct_varchar(v_res, p_coll.count);
  ------------------------------
  v_i := p_coll.first;
  v_j := 0;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_j := v_j + 1;
    v_res(v_j) := p_coll(v_i);
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_equal_ct_varchar(p_coll1 ct_varchar, p_coll2 ct_varchar, p_only_len boolean) return boolean
is
  v_res boolean;
  v_len1 number;
  v_len2 number;
  v_exists1 boolean;
  v_exists2 boolean;
begin
  ------------------------------
  if p_coll1 is null or p_coll1.count = 0
  then
    v_len1 := 0;
  else
    v_len1 := p_coll1.count;
  end if;
  ------------------------------
  if p_coll2 is null or p_coll2.count = 0
  then
    v_len2 := 0;
  else
    v_len2 := p_coll2.count;
  end if;
  ------------------------------
  if v_len1 != v_len2
  then
    return false;
  end if;
  ------------------------------
  if v_len1 = 0 and v_len2 = 0
  then
    return true;
  end if;
  ------------------------------
  if nvl(p_only_len, false)
  then
    return true;
  end if;
  ------------------------------
  v_res := true;
  ------------------------------
  for v_i in p_coll1.first..p_coll2.last
  loop
    ------------------------------
    v_exists1 := p_coll1.exists(v_i);
    v_exists2 := p_coll2.exists(v_i);
    ------------------------------
    if v_exists1 != v_exists2 then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if NOT v_exists1 and NOT v_exists2
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null and p_coll2(v_i) is null
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null or p_coll2(v_i) is null
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) != p_coll2(v_i)
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_equal_cit_varchar(p_coll1 cit_varchar, p_coll2 cit_varchar, p_only_len boolean) return boolean
is
  v_res boolean;
  v_len1 number;
  v_len2 number;
  v_i number;
  v_j number;
begin
  ------------------------------
  if p_coll1 is null or p_coll1.count = 0
  then
    v_len1 := 0;
  else
    v_len1 := p_coll1.count;
  end if;
  ------------------------------
  if p_coll2 is null or p_coll2.count = 0
  then
    v_len2 := 0;
  else
    v_len2 := p_coll2.count;
  end if;
  ------------------------------
  if v_len1 != v_len2
  then
    return false;
  end if;
  ------------------------------
  if v_len1 = 0 and v_len2 = 0
  then
    return true;
  end if;
  ------------------------------
  if nvl(p_only_len, false)
  then
    return true;
  end if;
  ------------------------------
  v_res := true;
  v_i := p_coll1.first;
  v_j := p_coll2.first;
  ------------------------------
  while v_i is not null or v_j is not null
  loop
    ------------------------------
    if v_i is null or v_j is null
    then
      ------------------------------
      if v_i is not null or v_j is not null
      then
        v_res := false;
      end if;
      ------------------------------
      exit;
      ------------------------------
    end if;
    ------------------------------
    if v_i != v_j
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) is null and p_coll2(v_i) is null
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null or p_coll2(v_i) is null
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) != p_coll2(v_i)
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    v_i := p_coll1.next(v_i);
    v_j := p_coll2.next(v_j);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function empty_cit_nvarchar_s return cit_nvarchar_s
is
  v_res cit_nvarchar_s;
begin
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct2cit_nvarchar_s(p_coll ct_nvarchar_s) return cit_nvarchar_s
is
  v_res cit_nvarchar_s;
begin
  ------------------------------
  if not CheckP_ct_nvarchar_s(p_coll)
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit2ct_nvarchar_s(p_coll cit_nvarchar_s, p_smart_cit boolean) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_smart_cit boolean := bool_to_bool_2val(p_smart_cit);
  v_i number;
  v_j number;
begin
  ------------------------------
  if not CheckP_cit_nvarchar_s(p_coll, v_smart_cit)
  then
    return v_res;
  end if;
  ------------------------------
  resize_ct_nvarchar_s(v_res, p_coll.count);
  ------------------------------
  v_i := p_coll.first;
  v_j := 0;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_j := v_j + 1;
    v_res(v_j) := p_coll(v_i);
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_equal_ct_nvarchar_s(p_coll1 ct_nvarchar_s, p_coll2 ct_nvarchar_s, p_only_len boolean) return boolean
is
  v_res boolean;
  v_len1 number;
  v_len2 number;
  v_exists1 boolean;
  v_exists2 boolean;
begin
  ------------------------------
  if p_coll1 is null or p_coll1.count = 0
  then
    v_len1 := 0;
  else
    v_len1 := p_coll1.count;
  end if;
  ------------------------------
  if p_coll2 is null or p_coll2.count = 0
  then
    v_len2 := 0;
  else
    v_len2 := p_coll2.count;
  end if;
  ------------------------------
  if v_len1 != v_len2
  then
    return false;
  end if;
  ------------------------------
  if v_len1 = 0 and v_len2 = 0
  then
    return true;
  end if;
  ------------------------------
  if nvl(p_only_len, false)
  then
    return true;
  end if;
  ------------------------------
  v_res := true;
  ------------------------------
  for v_i in p_coll1.first..p_coll2.last
  loop
    ------------------------------
    v_exists1 := p_coll1.exists(v_i);
    v_exists2 := p_coll2.exists(v_i);
    ------------------------------
    if v_exists1 != v_exists2 then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if NOT v_exists1 and NOT v_exists2
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null and p_coll2(v_i) is null
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null or p_coll2(v_i) is null
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) != p_coll2(v_i)
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_equal_cit_nvarchar_s(p_coll1 cit_nvarchar_s, p_coll2 cit_nvarchar_s, p_only_len boolean) return boolean
is
  v_res boolean;
  v_len1 number;
  v_len2 number;
  v_i number;
  v_j number;
begin
  ------------------------------
  if p_coll1 is null or p_coll1.count = 0
  then
    v_len1 := 0;
  else
    v_len1 := p_coll1.count;
  end if;
  ------------------------------
  if p_coll2 is null or p_coll2.count = 0
  then
    v_len2 := 0;
  else
    v_len2 := p_coll2.count;
  end if;
  ------------------------------
  if v_len1 != v_len2
  then
    return false;
  end if;
  ------------------------------
  if v_len1 = 0 and v_len2 = 0
  then
    return true;
  end if;
  ------------------------------
  if nvl(p_only_len, false)
  then
    return true;
  end if;
  ------------------------------
  v_res := true;
  v_i := p_coll1.first;
  v_j := p_coll2.first;
  ------------------------------
  while v_i is not null or v_j is not null
  loop
    ------------------------------
    if v_i is null or v_j is null
    then
      ------------------------------
      if v_i is not null or v_j is not null
      then
        v_res := false;
      end if;
      ------------------------------
      exit;
      ------------------------------
    end if;
    ------------------------------
    if v_i != v_j
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) is null and p_coll2(v_i) is null
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null or p_coll2(v_i) is null
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) != p_coll2(v_i)
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    v_i := p_coll1.next(v_i);
    v_j := p_coll2.next(v_j);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function empty_cit_nvarchar return cit_nvarchar
is
  v_res cit_nvarchar;
begin
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct2cit_nvarchar(p_coll ct_nvarchar) return cit_nvarchar
is
  v_res cit_nvarchar;
begin
  ------------------------------
  if not CheckP_ct_nvarchar(p_coll)
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit2ct_nvarchar(p_coll cit_nvarchar, p_smart_cit boolean) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_smart_cit boolean := bool_to_bool_2val(p_smart_cit);
  v_i number;
  v_j number;
begin
  ------------------------------
  if not CheckP_cit_nvarchar(p_coll, v_smart_cit)
  then
    return v_res;
  end if;
  ------------------------------
  resize_ct_nvarchar(v_res, p_coll.count);
  ------------------------------
  v_i := p_coll.first;
  v_j := 0;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_j := v_j + 1;
    v_res(v_j) := p_coll(v_i);
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_equal_ct_nvarchar(p_coll1 ct_nvarchar, p_coll2 ct_nvarchar, p_only_len boolean) return boolean
is
  v_res boolean;
  v_len1 number;
  v_len2 number;
  v_exists1 boolean;
  v_exists2 boolean;
begin
  ------------------------------
  if p_coll1 is null or p_coll1.count = 0
  then
    v_len1 := 0;
  else
    v_len1 := p_coll1.count;
  end if;
  ------------------------------
  if p_coll2 is null or p_coll2.count = 0
  then
    v_len2 := 0;
  else
    v_len2 := p_coll2.count;
  end if;
  ------------------------------
  if v_len1 != v_len2
  then
    return false;
  end if;
  ------------------------------
  if v_len1 = 0 and v_len2 = 0
  then
    return true;
  end if;
  ------------------------------
  if nvl(p_only_len, false)
  then
    return true;
  end if;
  ------------------------------
  v_res := true;
  ------------------------------
  for v_i in p_coll1.first..p_coll2.last
  loop
    ------------------------------
    v_exists1 := p_coll1.exists(v_i);
    v_exists2 := p_coll2.exists(v_i);
    ------------------------------
    if v_exists1 != v_exists2 then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if NOT v_exists1 and NOT v_exists2
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null and p_coll2(v_i) is null
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null or p_coll2(v_i) is null
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) != p_coll2(v_i)
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_equal_cit_nvarchar(p_coll1 cit_nvarchar, p_coll2 cit_nvarchar, p_only_len boolean) return boolean
is
  v_res boolean;
  v_len1 number;
  v_len2 number;
  v_i number;
  v_j number;
begin
  ------------------------------
  if p_coll1 is null or p_coll1.count = 0
  then
    v_len1 := 0;
  else
    v_len1 := p_coll1.count;
  end if;
  ------------------------------
  if p_coll2 is null or p_coll2.count = 0
  then
    v_len2 := 0;
  else
    v_len2 := p_coll2.count;
  end if;
  ------------------------------
  if v_len1 != v_len2
  then
    return false;
  end if;
  ------------------------------
  if v_len1 = 0 and v_len2 = 0
  then
    return true;
  end if;
  ------------------------------
  if nvl(p_only_len, false)
  then
    return true;
  end if;
  ------------------------------
  v_res := true;
  v_i := p_coll1.first;
  v_j := p_coll2.first;
  ------------------------------
  while v_i is not null or v_j is not null
  loop
    ------------------------------
    if v_i is null or v_j is null
    then
      ------------------------------
      if v_i is not null or v_j is not null
      then
        v_res := false;
      end if;
      ------------------------------
      exit;
      ------------------------------
    end if;
    ------------------------------
    if v_i != v_j
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) is null and p_coll2(v_i) is null
    then
      continue;
    end if;
    ------------------------------
    if p_coll1(v_i) is null or p_coll2(v_i) is null
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    if p_coll1(v_i) != p_coll2(v_i)
    then
      v_res := false;
      exit;
    end if;
    ------------------------------
    v_i := p_coll1.next(v_i);
    v_j := p_coll2.next(v_j);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function cast_ct_varchar_s2varchar(p_coll ct_varchar_s) return ct_varchar
is
  v_res ct_varchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_varchar();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_nvarchar_s2nvarchar(p_coll ct_nvarchar_s) return ct_nvarchar
is
  v_res ct_nvarchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_nvarchar();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_varchar2varchar_s(p_coll ct_varchar, p_raise boolean) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_raise boolean := bool_to_bool_2val(p_raise);
  v_length number := c_varchar_s_length;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_varchar_s();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    if v_raise and nvl(length(p_coll(v_i)), 0) > v_length
    then
      raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || p_coll(v_i));
    end if;
    ------------------------------
    v_res(v_i) := substr(p_coll(v_i), 1, v_length);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_nvarchar2nvarchar_s(p_coll ct_nvarchar, p_raise boolean) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_raise boolean := bool_to_bool_2val(p_raise);
  v_length number := c_nvarchar_s_length;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_nvarchar_s();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    if v_raise and nvl(length(p_coll(v_i)), 0) > v_length
    then
      raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || p_coll(v_i));
    end if;
    ------------------------------
    v_res(v_i) := substr(p_coll(v_i), 1, v_length);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_varchar_s2varchar(p_coll cit_varchar_s) return cit_varchar
is
  v_res cit_varchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_nvarchar_s2nvarchar(p_coll cit_nvarchar_s) return cit_nvarchar
is
  v_res cit_nvarchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_varchar2varchar_s(p_coll cit_varchar, p_raise boolean) return cit_varchar_s
is
  v_res cit_varchar_s;
  v_raise boolean := bool_to_bool_2val(p_raise);
  v_length number := c_varchar_s_length;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    if v_raise and nvl(length(p_coll(v_i)), 0) > v_length
    then
      raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || p_coll(v_i));
    end if;
    ------------------------------
    v_res(v_i) := substr(p_coll(v_i), 1, v_length);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_nvarchar2nvarchar_s(p_coll cit_nvarchar, p_raise boolean) return cit_nvarchar_s
is
  v_res cit_nvarchar_s;
  v_raise boolean := bool_to_bool_2val(p_raise);
  v_length number := c_nvarchar_s_length;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    if v_raise and nvl(length(p_coll(v_i)), 0) > v_length
    then
      raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || p_coll(v_i));
    end if;
    ------------------------------
    v_res(v_i) := substr(p_coll(v_i), 1, v_length);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function cast_ct_varchar_s2nvarchar_s(p_coll ct_varchar_s) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_nvarchar_s();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := char_to_nchar(p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_varchar2nvarchar(p_coll ct_varchar) return ct_nvarchar
is
  v_res ct_nvarchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_nvarchar();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := char_to_nchar(p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_nvarchar_s2varchar_s(p_coll ct_nvarchar_s) return ct_varchar_s
is
  v_res ct_varchar_s;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_varchar_s();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := nchar_to_char(p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_nvarchar2varchar(p_coll ct_nvarchar) return ct_varchar
is
  v_res ct_varchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_varchar();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := nchar_to_char(p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_varchar_s2nvarchar_s(p_coll cit_varchar_s) return cit_nvarchar_s
is
  v_res cit_nvarchar_s;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := char_to_nchar(p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_varchar2nvarchar(p_coll cit_varchar) return cit_nvarchar
is
  v_res cit_nvarchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := char_to_nchar(p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_nvarchar_s2varchar_s(p_coll cit_nvarchar_s) return cit_varchar_s
is
  v_res cit_varchar_s;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := nchar_to_char(p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_nvarchar2varchar(p_coll cit_nvarchar) return cit_varchar
is
  v_res cit_varchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := nchar_to_char(p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function cast_ct_varchar_s2ct_number(p_coll ct_varchar_s, p_raise boolean) return ct_number
is
  v_res ct_number;
  v_raise boolean := bool_to_bool_2val(p_raise);
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_number();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    begin
      ------------------------------
      v_res(v_i) := char_to_number(p_coll(v_i));
      ------------------------------
    exception
    when others then
      if v_raise
      then
        raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || p_coll(v_i) || c_msg_delim02 || get_err_msg);
      end if;
    end;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_varchar2ct_number(p_coll ct_varchar, p_raise boolean) return ct_number
is
  v_res ct_number;
  v_raise boolean := bool_to_bool_2val(p_raise);
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_number();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    begin
      ------------------------------
      v_res(v_i) := char_to_number(p_coll(v_i));
      ------------------------------
    exception
    when others then
      if v_raise
      then
        raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || p_coll(v_i) || c_msg_delim02 || get_err_msg);
      end if;
    end;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_nvarchar_s2ct_number(p_coll ct_nvarchar_s, p_raise boolean) return ct_number
is
  v_res ct_number;
  v_raise boolean := bool_to_bool_2val(p_raise);
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_number();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    begin
      ------------------------------
      v_res(v_i) := char_to_number(nchar_to_char(p_coll(v_i)));
      ------------------------------
    exception
    when others then
      if v_raise
      then
        raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || p_coll(v_i) || c_msg_delim02 || get_err_msg);
      end if;
    end;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_nvarchar2ct_number(p_coll ct_nvarchar, p_raise boolean) return ct_number
is
  v_res ct_number;
  v_raise boolean := bool_to_bool_2val(p_raise);
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_number();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    begin
      ------------------------------
      v_res(v_i) := char_to_number(nchar_to_char(p_coll(v_i)));
      ------------------------------
    exception
    when others then
      if v_raise
      then
        raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || p_coll(v_i) || c_msg_delim02 || get_err_msg);
      end if;
    end;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_number2ct_varchar_s(p_coll ct_number) return ct_varchar_s
is
  v_res ct_varchar_s;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_varchar_s();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    v_res(v_i) := number_to_char(p_coll(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_number2ct_varchar(p_coll ct_number) return ct_varchar
is
  v_res ct_varchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_varchar();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    v_res(v_i) := number_to_char(p_coll(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_number2ct_nvarchar_s(p_coll ct_number) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_nvarchar_s();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    v_res(v_i) := char_to_nchar(number_to_char(p_coll(v_i)));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_number2ct_nvarchar(p_coll ct_number) return ct_nvarchar
is
  v_res ct_nvarchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_res := ct_nvarchar();
  v_res.extend(p_coll.count);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    v_res(v_i) := char_to_nchar(number_to_char(p_coll(v_i)));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure fill_ct_number(p_coll in out nocopy ct_number, p_val number)
is
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    p_coll(v_i) := p_val;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_ct_date(p_coll in out nocopy ct_date, p_val date)
is
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    p_coll(v_i) := p_val;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_val varchar2)
is
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    p_coll(v_i) := p_val;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_ct_varchar(p_coll in out nocopy ct_varchar, p_val varchar2)
is
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    p_coll(v_i) := p_val;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_val nvarchar2)
is
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    p_coll(v_i) := p_val;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_val nvarchar2)
is
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    p_coll(v_i) := p_val;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_cit_number(p_coll in out nocopy cit_number, p_val number)
is
  v_i number;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null loop
    ------------------------------
    p_coll(v_i) := p_val;
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_cit_date(p_coll in out nocopy cit_date, p_val date)
is
  v_i number;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null loop
    ------------------------------
    p_coll(v_i) := p_val;
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_cit_varchar_s(p_coll in out nocopy cit_varchar_s, p_val varchar2)
is
  v_i number;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null loop
    ------------------------------
    p_coll(v_i) := p_val;
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_cit_varchar(p_coll in out nocopy cit_varchar, p_val varchar2)
is
  v_i number;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null loop
    ------------------------------
    p_coll(v_i) := p_val;
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_cit_nvarchar_s(p_coll in out nocopy cit_nvarchar_s, p_val nvarchar2)
is
  v_i number;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null loop
    ------------------------------
    p_coll(v_i) := p_val;
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_cit_nvarchar(p_coll in out nocopy cit_nvarchar, p_val nvarchar2)
is
  v_i number;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null loop
    ------------------------------
    p_coll(v_i) := p_val;
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_ct_number(p_count number, p_val number) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  resize_ct_number(v_res, p_count);
  fill_ct_number(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_date(p_count number, p_val date) return ct_date
is
  v_res ct_date;
begin
  ------------------------------
  resize_ct_date(v_res, p_count);
  fill_ct_date(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_varchar_s(p_count number, p_val varchar2) return ct_varchar_s
is
  v_res ct_varchar_s;
begin
  ------------------------------
  resize_ct_varchar_s(v_res, p_count);
  fill_ct_varchar_s(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_varchar(p_count number, p_val varchar2) return ct_varchar
is
  v_res ct_varchar;
begin
  ------------------------------
  resize_ct_varchar(v_res, p_count);
  fill_ct_varchar(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_nvarchar_s(p_count number, p_val nvarchar2) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  resize_ct_nvarchar_s(v_res, p_count);
  fill_ct_nvarchar_s(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_nvarchar(p_count number, p_val nvarchar2) return ct_nvarchar
is
  v_res ct_nvarchar;
begin
  ------------------------------
  resize_ct_nvarchar(v_res, p_count);
  fill_ct_nvarchar(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_cit_number(p_count number, p_val number) return cit_number
is
  v_res cit_number;
begin
  ------------------------------
  resize_cit_number(v_res, p_count);
  fill_cit_number(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_cit_date(p_count number, p_val date) return cit_date
is
  v_res cit_date;
begin
  ------------------------------
  resize_cit_date(v_res, p_count);
  fill_cit_date(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_cit_varchar_s(p_count number, p_val varchar2) return cit_varchar_s
is
  v_res cit_varchar_s;
begin
  ------------------------------
  resize_cit_varchar_s(v_res, p_count);
  fill_cit_varchar_s(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_cit_varchar(p_count number, p_val varchar2) return cit_varchar
is
  v_res cit_varchar;
begin
  ------------------------------
  resize_cit_varchar(v_res, p_count);
  fill_cit_varchar(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_cit_nvarchar_s(p_count number, p_val nvarchar2) return cit_nvarchar_s
is
  v_res cit_nvarchar_s;
begin
  ------------------------------
  resize_cit_nvarchar_s(v_res, p_count);
  fill_cit_nvarchar_s(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_cit_nvarchar(p_count number, p_val nvarchar2) return cit_nvarchar
is
  v_res cit_nvarchar;
begin
  ------------------------------
  resize_cit_nvarchar(v_res, p_count);
  fill_cit_nvarchar(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure add_ct_number_val(p_coll in out nocopy ct_number, p_val number)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_number();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_date_val(p_coll in out nocopy ct_date, p_val date)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_date();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_varchar_s_val(p_coll in out nocopy ct_varchar_s, p_val varchar2)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_varchar_s();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_varchar_val(p_coll in out nocopy ct_varchar, p_val varchar2)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_varchar();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_nvarchar_s_val(p_coll in out nocopy ct_nvarchar_s, p_val nvarchar2)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_nvarchar_s();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_nvarchar_val(p_coll in out nocopy ct_nvarchar, p_val nvarchar2)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_nvarchar();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure add_ct_number(p_coll in out nocopy ct_number, p_coll_add ct_number)
is
  v_count number;
begin
  ------------------------------
  if p_coll_add is null or p_coll_add.count = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_number();
  end if;
  ------------------------------
  v_count := p_coll.count;
  ------------------------------
  p_coll.extend(p_coll_add.count);
  ------------------------------
  for v_i in p_coll_add.first..p_coll_add.last
  loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_date(p_coll in out nocopy ct_date, p_coll_add ct_date)
is
  v_count number;
begin
  ------------------------------
  if p_coll_add is null or p_coll_add.count = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_date();
  end if;
  ------------------------------
  v_count := p_coll.count;
  ------------------------------
  p_coll.extend(p_coll_add.count);
  ------------------------------
  for v_i in p_coll_add.first..p_coll_add.last
  loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_coll_add ct_varchar_s)
is
  v_count number;
begin
  ------------------------------
  if p_coll_add is null or p_coll_add.count = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_varchar_s();
  end if;
  ------------------------------
  v_count := p_coll.count;
  ------------------------------
  p_coll.extend(p_coll_add.count);
  ------------------------------
  for v_i in p_coll_add.first..p_coll_add.last
  loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_varchar(p_coll in out nocopy ct_varchar, p_coll_add ct_varchar)
is
  v_count number;
begin
  ------------------------------
  if p_coll_add is null or p_coll_add.count = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_varchar();
  end if;
  ------------------------------
  v_count := p_coll.count;
  ------------------------------
  p_coll.extend(p_coll_add.count);
  ------------------------------
  for v_i in p_coll_add.first..p_coll_add.last
  loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_coll_add ct_nvarchar_s)
is
  v_count number;
begin
  ------------------------------
  if p_coll_add is null or p_coll_add.count = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_nvarchar_s();
  end if;
  ------------------------------
  v_count := p_coll.count;
  ------------------------------
  p_coll.extend(p_coll_add.count);
  ------------------------------
  for v_i in p_coll_add.first..p_coll_add.last
  loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_coll_add ct_nvarchar)
is
  v_count number;
begin
  ------------------------------
  if p_coll_add is null or p_coll_add.count = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_nvarchar();
  end if;
  ------------------------------
  v_count := p_coll.count;
  ------------------------------
  p_coll.extend(p_coll_add.count);
  ------------------------------
  for v_i in p_coll_add.first..p_coll_add.last
  loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_cit_number(p_coll in out nocopy cit_number, p_coll_add cit_number)
is
  v_count number;
  v_i number;
begin
  ------------------------------
  if p_coll_add is null or p_coll_add.count = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := empty_cit_number;
  end if;
  ------------------------------
  v_i := p_coll_add.first;
  v_count := nvl(p_coll.last, 0);
  ------------------------------
  while v_i is not null loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    v_i := p_coll_add.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_cit_date(p_coll in out nocopy cit_date, p_coll_add cit_date)
is
  v_count number;
  v_i number;
begin
  ------------------------------
  if p_coll_add is null or p_coll_add.count = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := empty_cit_date;
  end if;
  ------------------------------
  v_i := p_coll_add.first;
  v_count := nvl(p_coll.last, 0);
  ------------------------------
  while v_i is not null loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    v_i := p_coll_add.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_cit_varchar_s(p_coll in out nocopy cit_varchar_s, p_coll_add cit_varchar_s)
is
  v_count number;
  v_i number;
begin
  ------------------------------
  if p_coll_add is null or p_coll_add.count = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := empty_cit_varchar_s;
  end if;
  ------------------------------
  v_i := p_coll_add.first;
  v_count := nvl(p_coll.last, 0);
  ------------------------------
  while v_i is not null loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    v_i := p_coll_add.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_cit_varchar(p_coll in out nocopy cit_varchar, p_coll_add cit_varchar)
is
  v_count number;
  v_i number;
begin
  ------------------------------
  if p_coll_add is null or p_coll_add.count = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := empty_cit_varchar;
  end if;
  ------------------------------
  v_i := p_coll_add.first;
  v_count := nvl(p_coll.last, 0);
  ------------------------------
  while v_i is not null loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    v_i := p_coll_add.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_cit_nvarchar_s(p_coll in out nocopy cit_nvarchar_s, p_coll_add cit_nvarchar_s)
is
  v_count number;
  v_i number;
begin
  ------------------------------
  if p_coll_add is null or p_coll_add.count = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := empty_cit_nvarchar_s;
  end if;
  ------------------------------
  v_i := p_coll_add.first;
  v_count := nvl(p_coll.last, 0);
  ------------------------------
  while v_i is not null loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    v_i := p_coll_add.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_cit_nvarchar(p_coll in out nocopy cit_nvarchar, p_coll_add cit_nvarchar)
is
  v_count number;
  v_i number;
begin
  ------------------------------
  if p_coll_add is null or p_coll_add.count = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := empty_cit_nvarchar;
  end if;
  ------------------------------
  v_i := p_coll_add.first;
  v_count := nvl(p_coll.last, 0);
  ------------------------------
  while v_i is not null loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    v_i := p_coll_add.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure resize_ct_number(p_coll in out nocopy ct_number, p_size number)
is
  v_dif number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_number();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_ct_date(p_coll in out nocopy ct_date, p_size number)
is
  v_dif number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_date();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_size number)
is
  v_dif number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_varchar_s();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_ct_varchar(p_coll in out nocopy ct_varchar, p_size number)
is
  v_dif number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_varchar();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_size number)
is
  v_dif number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_nvarchar_s();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_size number)
is
  v_dif number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_nvarchar();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_cit_number(p_coll in out nocopy cit_number, p_size number)
is
  v_dif number;
  v_index number;
  v_index2 number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := empty_cit_number;
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    ------------------------------
    v_index := nvl(p_coll.last, 0);
    ------------------------------
    for v_i in 1..v_dif
    loop
      ------------------------------
      p_coll(v_index + v_i) := null;
      ------------------------------
    end loop;
    ------------------------------
  elsif v_dif < 0
  then
    ------------------------------
    v_index2 := nvl(p_coll.last, 0);
    v_index := v_index2;
    ------------------------------
    for v_i in 1..-v_dif - 1
    loop
      ------------------------------
      v_index := p_coll.prior(v_index);
      ------------------------------
    end loop;
    ------------------------------
    p_coll.delete(v_index, v_index2);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_cit_date(p_coll in out nocopy cit_date, p_size number)
is
  v_dif number;
  v_index number;
  v_index2 number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := empty_cit_date;
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    ------------------------------
    v_index := nvl(p_coll.last, 0);
    ------------------------------
    for v_i in 1..v_dif
    loop
      ------------------------------
      p_coll(v_index + v_i) := null;
      ------------------------------
    end loop;
    ------------------------------
  elsif v_dif < 0
  then
    ------------------------------
    v_index2 := nvl(p_coll.last, 0);
    v_index := v_index2;
    ------------------------------
    for v_i in 1..-v_dif - 1
    loop
      ------------------------------
      v_index := p_coll.prior(v_index);
      ------------------------------
    end loop;
    ------------------------------
    p_coll.delete(v_index, v_index2);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_cit_varchar_s(p_coll in out nocopy cit_varchar_s, p_size number)
is
  v_dif number;
  v_index number;
  v_index2 number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := empty_cit_varchar_s;
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    ------------------------------
    v_index := nvl(p_coll.last, 0);
    ------------------------------
    for v_i in 1..v_dif
    loop
      ------------------------------
      p_coll(v_index + v_i) := null;
      ------------------------------
    end loop;
    ------------------------------
  elsif v_dif < 0
  then
    ------------------------------
    v_index2 := nvl(p_coll.last, 0);
    v_index := v_index2;
    ------------------------------
    for v_i in 1..-v_dif - 1
    loop
      ------------------------------
      v_index := p_coll.prior(v_index);
      ------------------------------
    end loop;
    ------------------------------
    p_coll.delete(v_index, v_index2);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_cit_varchar(p_coll in out nocopy cit_varchar, p_size number)
is
  v_dif number;
  v_index number;
  v_index2 number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := empty_cit_varchar;
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    ------------------------------
    v_index := nvl(p_coll.last, 0);
    ------------------------------
    for v_i in 1..v_dif
    loop
      ------------------------------
      p_coll(v_index + v_i) := null;
      ------------------------------
    end loop;
    ------------------------------
  elsif v_dif < 0
  then
    ------------------------------
    v_index2 := nvl(p_coll.last, 0);
    v_index := v_index2;
    ------------------------------
    for v_i in 1..-v_dif - 1
    loop
      ------------------------------
      v_index := p_coll.prior(v_index);
      ------------------------------
    end loop;
    ------------------------------
    p_coll.delete(v_index, v_index2);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_cit_nvarchar_s(p_coll in out nocopy cit_nvarchar_s, p_size number)
is
  v_dif number;
  v_index number;
  v_index2 number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := empty_cit_nvarchar_s;
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    ------------------------------
    v_index := nvl(p_coll.last, 0);
    ------------------------------
    for v_i in 1..v_dif
    loop
      ------------------------------
      p_coll(v_index + v_i) := null;
      ------------------------------
    end loop;
    ------------------------------
  elsif v_dif < 0
  then
    ------------------------------
    v_index2 := nvl(p_coll.last, 0);
    v_index := v_index2;
    ------------------------------
    for v_i in 1..-v_dif - 1
    loop
      ------------------------------
      v_index := p_coll.prior(v_index);
      ------------------------------
    end loop;
    ------------------------------
    p_coll.delete(v_index, v_index2);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_cit_nvarchar(p_coll in out nocopy cit_nvarchar, p_size number)
is
  v_dif number;
  v_index number;
  v_index2 number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := empty_cit_nvarchar;
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    ------------------------------
    v_index := nvl(p_coll.last, 0);
    ------------------------------
    for v_i in 1..v_dif
    loop
      ------------------------------
      p_coll(v_index + v_i) := null;
      ------------------------------
    end loop;
    ------------------------------
  elsif v_dif < 0
  then
    ------------------------------
    v_index2 := nvl(p_coll.last, 0);
    v_index := v_index2;
    ------------------------------
    for v_i in 1..-v_dif - 1
    loop
      ------------------------------
      v_index := p_coll.prior(v_index);
      ------------------------------
    end loop;
    ------------------------------
    p_coll.delete(v_index, v_index2);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function cut_ct_number(p_coll ct_number, p_count number, p_start_pos number := 1) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_count is null, 'p_count');
  XCheck_Cond_Missing(p_start_pos is null, 'p_start_pos');
  ------------------------------
select
  val
  bulk collect into v_res
  from (select column_value val, rownum rn from table(p_coll)) q
  where 1 = 1
  and rn between p_start_pos and p_count + p_start_pos - 1
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cut_ct_date(p_coll ct_date, p_count number, p_start_pos number := 1) return ct_date
is
  v_res ct_date;
begin
  ------------------------------
  XCheck_Cond_Missing(p_count is null, 'p_count');
  XCheck_Cond_Missing(p_start_pos is null, 'p_start_pos');
  ------------------------------
select
  val
  bulk collect into v_res
  from (select column_value val, rownum rn from table(p_coll)) q
  where 1 = 1
  and rn between p_start_pos and p_count + p_start_pos - 1
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cut_ct_varchar_s(p_coll ct_varchar_s, p_count number, p_start_pos number := 1) return ct_varchar_s
is
  v_res ct_varchar_s;
begin
  ------------------------------
  XCheck_Cond_Missing(p_count is null, 'p_count');
  XCheck_Cond_Missing(p_start_pos is null, 'p_start_pos');
  ------------------------------
select
  val
  bulk collect into v_res
  from (select column_value val, rownum rn from table(p_coll)) q
  where 1 = 1
  and rn between p_start_pos and p_count + p_start_pos - 1
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cut_ct_varchar(p_coll ct_varchar, p_count number, p_start_pos number := 1) return ct_varchar
is
  v_res ct_varchar;
begin
  ------------------------------
  XCheck_Cond_Missing(p_count is null, 'p_count');
  XCheck_Cond_Missing(p_start_pos is null, 'p_start_pos');
  ------------------------------
select
  val
  bulk collect into v_res
  from (select column_value val, rownum rn from table(p_coll)) q
  where 1 = 1
  and rn between p_start_pos and p_count + p_start_pos - 1
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cut_ct_nvarchar_s(p_coll ct_nvarchar_s, p_count number, p_start_pos number := 1) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  XCheck_Cond_Missing(p_count is null, 'p_count');
  XCheck_Cond_Missing(p_start_pos is null, 'p_start_pos');
  ------------------------------
select
  val
  bulk collect into v_res
  from (select column_value val, rownum rn from table(p_coll)) q
  where 1 = 1
  and rn between p_start_pos and p_count + p_start_pos - 1
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cut_ct_nvarchar(p_coll ct_nvarchar, p_count number, p_start_pos number := 1) return ct_nvarchar
is
  v_res ct_nvarchar;
begin
  ------------------------------
  XCheck_Cond_Missing(p_count is null, 'p_count');
  XCheck_Cond_Missing(p_start_pos is null, 'p_start_pos');
  ------------------------------
select
  val
  bulk collect into v_res
  from (select column_value val, rownum rn from table(p_coll)) q
  where 1 = 1
  and rn between p_start_pos and p_count + p_start_pos - 1
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function unique_ct_number(p_coll ct_number, p_save_order boolean, p_trim_empty boolean := true, p_empty_val number := null) return ct_number
is
  v_res ct_number;
  v_save_order number := bool_to_int_2val(p_save_order);
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  select
  decode(rn2, 1, val, p_empty_val) val
  bulk collect into v_res
  from
    (select column_value val, rownum rn, row_number() over(partition by column_value order by rownum) rn2 from table(p_coll)) q
  where 1 = 1
  and (v_trim_empty = c_false or rn2 = 1)
  order by decode(v_save_order, c_true, rn, 0), val
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_ct_date(p_coll ct_date, p_save_order boolean, p_trim_empty boolean := true, p_empty_val date := null) return ct_date
is
  v_res ct_date;
  v_save_order number := bool_to_int_2val(p_save_order);
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  select
  decode(rn2, 1, val, p_empty_val) val
  bulk collect into v_res
  from
    (select column_value val, rownum rn, row_number() over(partition by column_value order by rownum) rn2 from table(p_coll)) q
  where 1 = 1
  and (v_trim_empty = c_false or rn2 = 1)
  order by decode(v_save_order, c_true, rn, 0), val
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_ct_varchar_s(p_coll ct_varchar_s, p_save_order boolean, p_trim_empty boolean := true, p_empty_val varchar2 := null) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_save_order number := bool_to_int_2val(p_save_order);
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  select
  decode(rn2, 1, val, p_empty_val) val
  bulk collect into v_res
  from
    (select column_value val, rownum rn, row_number() over(partition by column_value order by rownum) rn2 from table(p_coll)) q
  where 1 = 1
  and (v_trim_empty = c_false or rn2 = 1)
  order by decode(v_save_order, c_true, rn, 0), val
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_ct_varchar(p_coll ct_varchar, p_save_order boolean, p_trim_empty boolean := true, p_empty_val varchar2 := null) return ct_varchar
is
  v_res ct_varchar;
  v_save_order number := bool_to_int_2val(p_save_order);
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  select
  decode(rn2, 1, val, p_empty_val) val
  bulk collect into v_res
  from
    (select column_value val, rownum rn, row_number() over(partition by column_value order by rownum) rn2 from table(p_coll)) q
  where 1 = 1
  and (v_trim_empty = c_false or rn2 = 1)
  order by decode(v_save_order, c_true, rn, 0), val
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_ct_nvarchar_s(p_coll ct_nvarchar_s, p_save_order boolean, p_trim_empty boolean := true, p_empty_val nvarchar2 := null) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_save_order number := bool_to_int_2val(p_save_order);
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  select
  decode(rn2, 1, val, p_empty_val) val
  bulk collect into v_res
  from
    (select column_value val, rownum rn, row_number() over(partition by column_value order by rownum) rn2 from table(p_coll)) q
  where 1 = 1
  and (v_trim_empty = c_false or rn2 = 1)
  order by decode(v_save_order, c_true, rn, 0), val
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_ct_nvarchar(p_coll ct_nvarchar, p_save_order boolean, p_trim_empty boolean := true, p_empty_val nvarchar2 := null) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_save_order number := bool_to_int_2val(p_save_order);
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  select
  decode(rn2, 1, val, p_empty_val) val
  bulk collect into v_res
  from
    (select column_value val, rownum rn, row_number() over(partition by column_value order by rownum) rn2 from table(p_coll)) q
  where 1 = 1
  and (v_trim_empty = c_false or rn2 = 1)
  order by decode(v_save_order, c_true, rn, 0), val
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_cit_number(p_coll cit_number, p_save_order boolean, p_trim_empty boolean := true, p_empty_val number := null) return cit_number
is
  v_coll ct_number;
begin
  ------------------------------
  v_coll := cast_cit2ct_number(p_coll, false);
  ------------------------------
  return cast_ct2cit_number(unique_ct_number(v_coll, p_save_order, p_trim_empty, p_empty_val));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_cit_date(p_coll cit_date, p_save_order boolean, p_trim_empty boolean := true, p_empty_val date := null) return cit_date
is
  v_coll ct_date;
begin
  ------------------------------
  v_coll := cast_cit2ct_date(p_coll, false);
  ------------------------------
  return cast_ct2cit_date(unique_ct_date(v_coll, p_save_order, p_trim_empty, p_empty_val));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_cit_varchar_s(p_coll cit_varchar_s, p_save_order boolean, p_trim_empty boolean := true, p_empty_val varchar2 := null) return cit_varchar_s
is
  v_coll ct_varchar_s;
begin
  ------------------------------
  v_coll := cast_cit2ct_varchar_s(p_coll, false);
  ------------------------------
  return cast_ct2cit_varchar_s(unique_ct_varchar_s(v_coll, p_save_order, p_trim_empty, p_empty_val));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_cit_varchar(p_coll cit_varchar, p_save_order boolean, p_trim_empty boolean := true, p_empty_val varchar2 := null) return cit_varchar
is
  v_coll ct_varchar;
begin
  ------------------------------
  v_coll := cast_cit2ct_varchar(p_coll, false);
  ------------------------------
  return cast_ct2cit_varchar(unique_ct_varchar(v_coll, p_save_order, p_trim_empty, p_empty_val));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_cit_nvarchar_s(p_coll cit_nvarchar_s, p_save_order boolean, p_trim_empty boolean := true, p_empty_val nvarchar2 := null) return cit_nvarchar_s
is
  v_coll ct_nvarchar_s;
begin
  ------------------------------
  v_coll := cast_cit2ct_nvarchar_s(p_coll, false);
  ------------------------------
  return cast_ct2cit_nvarchar_s(unique_ct_nvarchar_s(v_coll, p_save_order, p_trim_empty, p_empty_val));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_cit_nvarchar(p_coll cit_nvarchar, p_save_order boolean, p_trim_empty boolean := true, p_empty_val nvarchar2 := null) return cit_nvarchar
is
  v_coll ct_nvarchar;
begin
  ------------------------------
  v_coll := cast_cit2ct_nvarchar(p_coll, false);
  ------------------------------
  return cast_ct2cit_nvarchar(unique_ct_nvarchar(v_coll, p_save_order, p_trim_empty, p_empty_val));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function join2pivot_ct_number(p_vals ct_number, p_ids_pivot_main ct_number, p_ids_pivot_for_vals ct_number) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  if p_ids_pivot_main is null or p_ids_pivot_main.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q3.val
    bulk collect into v_res
    from
      (select column_value id, rownum rn from table(cast(p_ids_pivot_main as ct_number))) q1,
      (select column_value id, rownum rn from table(cast(p_ids_pivot_for_vals as ct_number))) q2,
      (select column_value val, rownum rn from table(cast(p_vals as ct_number))) q3
    where 1 = 1
    and q2.id(+) = q1.id
    and q3.rn(+) = q2.rn
    order by q1.rn, q2.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function join2pivot_ct_date(p_vals ct_date, p_ids_pivot_main ct_number, p_ids_pivot_for_vals ct_number) return ct_date
is
  v_res ct_date;
begin
  ------------------------------
  if p_ids_pivot_main is null or p_ids_pivot_main.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q3.val
    bulk collect into v_res
    from
      (select column_value id, rownum rn from table(cast(p_ids_pivot_main as ct_number))) q1,
      (select column_value id, rownum rn from table(cast(p_ids_pivot_for_vals as ct_number))) q2,
      (select column_value val, rownum rn from table(cast(p_vals as ct_date))) q3
    where 1 = 1
    and q2.id(+) = q1.id
    and q3.rn(+) = q2.rn
    order by q1.rn, q2.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function join2pivot_ct_varchar_s(p_vals ct_varchar_s, p_ids_pivot_main ct_number, p_ids_pivot_for_vals ct_number) return ct_varchar_s
is
  v_res ct_varchar_s;
begin
  ------------------------------
  if p_ids_pivot_main is null or p_ids_pivot_main.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q3.val
    bulk collect into v_res
    from
      (select column_value id, rownum rn from table(cast(p_ids_pivot_main as ct_number))) q1,
      (select column_value id, rownum rn from table(cast(p_ids_pivot_for_vals as ct_number))) q2,
      (select column_value val, rownum rn from table(cast(p_vals as ct_varchar_s))) q3
    where 1 = 1
    and q2.id(+) = q1.id
    and q3.rn(+) = q2.rn
    order by q1.rn, q2.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function join2pivot_ct_varchar(p_vals ct_varchar, p_ids_pivot_main ct_number, p_ids_pivot_for_vals ct_number) return ct_varchar
is
  v_res ct_varchar;
begin
  ------------------------------
  if p_ids_pivot_main is null or p_ids_pivot_main.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q3.val
    bulk collect into v_res
    from
      (select column_value id, rownum rn from table(cast(p_ids_pivot_main as ct_number))) q1,
      (select column_value id, rownum rn from table(cast(p_ids_pivot_for_vals as ct_number))) q2,
      (select column_value val, rownum rn from table(cast(p_vals as ct_varchar))) q3
    where 1 = 1
    and q2.id(+) = q1.id
    and q3.rn(+) = q2.rn
    order by q1.rn, q2.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function join2pivot_ct_nvarchar_s(p_vals ct_nvarchar_s, p_ids_pivot_main ct_number, p_ids_pivot_for_vals ct_number) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  if p_ids_pivot_main is null or p_ids_pivot_main.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q3.val
    bulk collect into v_res
    from
      (select column_value id, rownum rn from table(cast(p_ids_pivot_main as ct_number))) q1,
      (select column_value id, rownum rn from table(cast(p_ids_pivot_for_vals as ct_number))) q2,
      (select column_value val, rownum rn from table(cast(p_vals as ct_nvarchar_s))) q3
    where 1 = 1
    and q2.id(+) = q1.id
    and q3.rn(+) = q2.rn
    order by q1.rn, q2.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function join2pivot_ct_nvarchar(p_vals ct_nvarchar, p_ids_pivot_main ct_number, p_ids_pivot_for_vals ct_number) return ct_nvarchar
is
  v_res ct_nvarchar;
begin
  ------------------------------
  if p_ids_pivot_main is null or p_ids_pivot_main.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q3.val
    bulk collect into v_res
    from
      (select column_value id, rownum rn from table(cast(p_ids_pivot_main as ct_number))) q1,
      (select column_value id, rownum rn from table(cast(p_ids_pivot_for_vals as ct_number))) q2,
      (select column_value val, rownum rn from table(cast(p_vals as ct_nvarchar))) q3
    where 1 = 1
    and q2.id(+) = q1.id
    and q3.rn(+) = q2.rn
    order by q1.rn, q2.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function filter_ct_number(p_vals ct_number, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_number
is
  v_res ct_number;
  v_include_by_filter number := bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if p_vals is null or p_vals.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  if p_ids_pivot is null or p_ids_pivot.count != p_vals.count
  then
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || 'p_ids_pivot');
  end if;
  ------------------------------
  if p_ids_filter is null or p_ids_filter.count = 0
  then
    if v_include_by_filter = c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q1.val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(cast(p_vals as ct_number))) q1,
      (select column_value id, rownum rn from table(cast(p_ids_pivot as ct_number))) q2,
      (select column_value id from table(cast(p_ids_filter as ct_number))) q3
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.id(+) = q2.id
    and decode(q3.id, null, c_false, c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_date(p_vals ct_date, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_date
is
  v_res ct_date;
  v_include_by_filter number := bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if p_vals is null or p_vals.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  if p_ids_pivot is null or p_ids_pivot.count != p_vals.count
  then
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || 'p_ids_pivot');
  end if;
  ------------------------------
  if p_ids_filter is null or p_ids_filter.count = 0
  then
    if v_include_by_filter = c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q1.val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(cast(p_vals as ct_date))) q1,
      (select column_value id, rownum rn from table(cast(p_ids_pivot as ct_number))) q2,
      (select column_value id from table(cast(p_ids_filter as ct_number))) q3
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.id(+) = q2.id
    and decode(q3.id, null, c_false, c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_varchar_s(p_vals ct_varchar_s, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_include_by_filter number := bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if p_vals is null or p_vals.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  if p_ids_pivot is null or p_ids_pivot.count != p_vals.count
  then
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || 'p_ids_pivot');
  end if;
  ------------------------------
  if p_ids_filter is null or p_ids_filter.count = 0
  then
    if v_include_by_filter = c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q1.val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(cast(p_vals as ct_varchar_s))) q1,
      (select column_value id, rownum rn from table(cast(p_ids_pivot as ct_number))) q2,
      (select column_value id from table(cast(p_ids_filter as ct_number))) q3
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.id(+) = q2.id
    and decode(q3.id, null, c_false, c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_varchar(p_vals ct_varchar, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_varchar
is
  v_res ct_varchar;
  v_include_by_filter number := bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if p_vals is null or p_vals.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  if p_ids_pivot is null or p_ids_pivot.count != p_vals.count
  then
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || 'p_ids_pivot');
  end if;
  ------------------------------
  if p_ids_filter is null or p_ids_filter.count = 0
  then
    if v_include_by_filter = c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q1.val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(cast(p_vals as ct_varchar))) q1,
      (select column_value id, rownum rn from table(cast(p_ids_pivot as ct_number))) q2,
      (select column_value id from table(cast(p_ids_filter as ct_number))) q3
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.id(+) = q2.id
    and decode(q3.id, null, c_false, c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_nvarchar_s(p_vals ct_nvarchar_s, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_include_by_filter number := bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if p_vals is null or p_vals.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  if p_ids_pivot is null or p_ids_pivot.count != p_vals.count
  then
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || 'p_ids_pivot');
  end if;
  ------------------------------
  if p_ids_filter is null or p_ids_filter.count = 0
  then
    if v_include_by_filter = c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q1.val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(cast(p_vals as ct_nvarchar_s))) q1,
      (select column_value id, rownum rn from table(cast(p_ids_pivot as ct_number))) q2,
      (select column_value id from table(cast(p_ids_filter as ct_number))) q3
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.id(+) = q2.id
    and decode(q3.id, null, c_false, c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_nvarchar(p_vals ct_nvarchar, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_include_by_filter number := bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if p_vals is null or p_vals.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  if p_ids_pivot is null or p_ids_pivot.count != p_vals.count
  then
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || 'p_ids_pivot');
  end if;
  ------------------------------
  if p_ids_filter is null or p_ids_filter.count = 0
  then
    if v_include_by_filter = c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q1.val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(cast(p_vals as ct_nvarchar))) q1,
      (select column_value id, rownum rn from table(cast(p_ids_pivot as ct_number))) q2,
      (select column_value id from table(cast(p_ids_filter as ct_number))) q3
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.id(+) = q2.id
    and decode(q3.id, null, c_false, c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_number_1val(p_vals ct_number, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_number
is
  v_coll ct_number;
begin
  ------------------------------
  add_ct_number_val(v_coll, p_id_filter_val);
  ------------------------------
  return filter_ct_number(p_vals, p_ids_pivot, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_date_1val(p_vals ct_date, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_date
is
  v_coll ct_number;
begin
  ------------------------------
  add_ct_number_val(v_coll, p_id_filter_val);
  ------------------------------
  return filter_ct_date(p_vals, p_ids_pivot, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_varchar_s_1val(p_vals ct_varchar_s, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_varchar_s
is
  v_coll ct_number;
begin
  ------------------------------
  add_ct_number_val(v_coll, p_id_filter_val);
  ------------------------------
  return filter_ct_varchar_s(p_vals, p_ids_pivot, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_varchar_1val(p_vals ct_varchar, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_varchar
is
  v_coll ct_number;
begin
  ------------------------------
  add_ct_number_val(v_coll, p_id_filter_val);
  ------------------------------
  return filter_ct_varchar(p_vals, p_ids_pivot, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_nvarchar_s_1val(p_vals ct_nvarchar_s, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_nvarchar_s
is
  v_coll ct_number;
begin
  ------------------------------
  add_ct_number_val(v_coll, p_id_filter_val);
  ------------------------------
  return filter_ct_nvarchar_s(p_vals, p_ids_pivot, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_nvarchar_1val(p_vals ct_nvarchar, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_nvarchar
is
  v_coll ct_number;
begin
  ------------------------------
  add_ct_number_val(v_coll, p_id_filter_val);
  ------------------------------
  return filter_ct_nvarchar(p_vals, p_ids_pivot, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function filter_val_ct_number(p_vals ct_number, p_filter_vals ct_number, p_include_by_filter boolean) return ct_number
is
  v_res ct_number;
  v_include_by_filter number := bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if p_vals is null or p_vals.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  if p_filter_vals is null or p_filter_vals.count = 0
  then
    if v_include_by_filter = c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q1.val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(cast(p_vals as ct_number))) q1,
      (select column_value val, rownum rn from table(cast(p_filter_vals as ct_number))) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_number) = nvl(q1.val, c_no_value_not_null_number)
    and decode(q2.rn, null, c_false, c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_date(p_vals ct_date, p_filter_vals ct_date, p_include_by_filter boolean) return ct_date
is
  v_res ct_date;
  v_include_by_filter number := bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if p_vals is null or p_vals.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  if p_filter_vals is null or p_filter_vals.count = 0
  then
    if v_include_by_filter = c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q1.val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(cast(p_vals as ct_date))) q1,
      (select column_value val, rownum rn from table(cast(p_filter_vals as ct_date))) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_date) = nvl(q1.val, c_no_value_not_null_date)
    and decode(q2.rn, null, c_false, c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_varchar_s(p_vals ct_varchar_s, p_filter_vals ct_varchar_s, p_include_by_filter boolean) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_include_by_filter number := bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if p_vals is null or p_vals.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  if p_filter_vals is null or p_filter_vals.count = 0
  then
    if v_include_by_filter = c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q1.val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(cast(p_vals as ct_varchar_s))) q1,
      (select column_value val, rownum rn from table(cast(p_filter_vals as ct_varchar_s))) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_varchar_s) = nvl(q1.val, c_no_value_not_null_varchar_s)
    and decode(q2.rn, null, c_false, c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_varchar(p_vals ct_varchar, p_filter_vals ct_varchar, p_include_by_filter boolean) return ct_varchar
is
  v_res ct_varchar;
  v_include_by_filter number := bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if p_vals is null or p_vals.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  if p_filter_vals is null or p_filter_vals.count = 0
  then
    if v_include_by_filter = c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q1.val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(cast(p_vals as ct_varchar))) q1,
      (select column_value val, rownum rn from table(cast(p_filter_vals as ct_varchar))) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_varchar) = nvl(q1.val, c_no_value_not_null_varchar)
    and decode(q2.rn, null, c_false, c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_nvarchar_s(p_vals ct_nvarchar_s, p_filter_vals ct_nvarchar_s, p_include_by_filter boolean) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_include_by_filter number := bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if p_vals is null or p_vals.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  if p_filter_vals is null or p_filter_vals.count = 0
  then
    if v_include_by_filter = c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q1.val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(cast(p_vals as ct_nvarchar_s))) q1,
      (select column_value val, rownum rn from table(cast(p_filter_vals as ct_nvarchar_s))) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_nvarchar_s) = nvl(q1.val, c_no_value_not_null_nvarchar_s)
    and decode(q2.rn, null, c_false, c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_nvarchar(p_vals ct_nvarchar, p_filter_vals ct_nvarchar, p_include_by_filter boolean) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_include_by_filter number := bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if p_vals is null or p_vals.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  if p_filter_vals is null or p_filter_vals.count = 0
  then
    if v_include_by_filter = c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q1.val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(cast(p_vals as ct_nvarchar))) q1,
      (select column_value val, rownum rn from table(cast(p_filter_vals as ct_nvarchar))) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_nvarchar) = nvl(q1.val, c_no_value_not_null_nvarchar)
    and decode(q2.rn, null, c_false, c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_number_1val(p_vals ct_number, p_filter_val number, p_include_by_filter boolean) return ct_number
is
  v_coll ct_number;
begin
  ------------------------------
  add_ct_number_val(v_coll, p_filter_val);
  ------------------------------
  return filter_val_ct_number(p_vals, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_date_1val(p_vals ct_date, p_filter_val date, p_include_by_filter boolean) return ct_date
is
  v_coll ct_date;
begin
  ------------------------------
  add_ct_date_val(v_coll, p_filter_val);
  ------------------------------
  return filter_val_ct_date(p_vals, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_varchar_s_1val(p_vals ct_varchar_s, p_filter_val varchar2, p_include_by_filter boolean) return ct_varchar_s
is
  v_coll ct_varchar_s;
begin
  ------------------------------
  add_ct_varchar_s_val(v_coll, p_filter_val);
  ------------------------------
  return filter_val_ct_varchar_s(p_vals, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_varchar_1val(p_vals ct_varchar, p_filter_val varchar2, p_include_by_filter boolean) return ct_varchar
is
  v_coll ct_varchar;
begin
  ------------------------------
  add_ct_varchar_val(v_coll, p_filter_val);
  ------------------------------
  return filter_val_ct_varchar(p_vals, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_nvarchar_s_1val(p_vals ct_nvarchar_s, p_filter_val nvarchar2, p_include_by_filter boolean) return ct_nvarchar_s
is
  v_coll ct_nvarchar_s;
begin
  ------------------------------
  add_ct_nvarchar_s_val(v_coll, p_filter_val);
  ------------------------------
  return filter_val_ct_nvarchar_s(p_vals, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_nvarchar_1val(p_vals ct_nvarchar, p_filter_val nvarchar2, p_include_by_filter boolean) return ct_nvarchar
is
  v_coll ct_nvarchar;
begin
  ------------------------------
  add_ct_nvarchar_val(v_coll, p_filter_val);
  ------------------------------
  return filter_val_ct_nvarchar(p_vals, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function mark_ct_number(p_vals ct_number, p_marker_vals ct_number, p_mark_value number := c_true, p_unmark_value number := c_false, p_x_marker_vals_not_unique boolean := false) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_p_marker_vals_count number;
  v_marker_vals ct_number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_x_marker_vals_not_unique is null, 'p_x_marker_vals_not_unique');
  ------------------------------
  v_main_count := get_count_ct_number(p_vals);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_p_marker_vals_count := get_count_ct_number(p_marker_vals);
  ------------------------------
  if v_p_marker_vals_count = 0
  then
    ------------------------------
    v_res := make_ct_number(v_main_count, p_unmark_value);
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_marker_vals := unique_ct_number(p_marker_vals, false, TRUE);
  ------------------------------
  XCheck_Cond_Invalid(p_x_marker_vals_not_unique and v_p_marker_vals_count > get_count_ct_number(v_marker_vals), c_msg_object_not_unique || c_msg_delim01 || 'p_marker_vals');
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_unmark_value, p_mark_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value val, rownum rn from table(v_marker_vals)) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_number) = nvl(q1.val, c_no_value_not_null_number)
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_ct_date(p_vals ct_date, p_marker_vals ct_date, p_mark_value number := c_true, p_unmark_value number := c_false, p_x_marker_vals_not_unique boolean := false) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_p_marker_vals_count number;
  v_marker_vals ct_date;
begin
  ------------------------------
  XCheck_Cond_Missing(p_x_marker_vals_not_unique is null, 'p_x_marker_vals_not_unique');
  ------------------------------
  v_main_count := get_count_ct_date(p_vals);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_p_marker_vals_count := get_count_ct_date(p_marker_vals);
  ------------------------------
  if v_p_marker_vals_count = 0
  then
    ------------------------------
    v_res := make_ct_number(v_main_count, p_unmark_value);
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_marker_vals := unique_ct_date(p_marker_vals, false, TRUE);
  ------------------------------
  XCheck_Cond_Invalid(p_x_marker_vals_not_unique and v_p_marker_vals_count > get_count_ct_date(v_marker_vals), c_msg_object_not_unique || c_msg_delim01 || 'p_marker_vals');
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_unmark_value, p_mark_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value val, rownum rn from table(v_marker_vals)) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_date) = nvl(q1.val, c_no_value_not_null_date)
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_ct_varchar_s(p_vals ct_varchar_s, p_marker_vals ct_varchar_s, p_mark_value number := c_true, p_unmark_value number := c_false, p_x_marker_vals_not_unique boolean := false) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_p_marker_vals_count number;
  v_marker_vals ct_varchar_s;
begin
  ------------------------------
  XCheck_Cond_Missing(p_x_marker_vals_not_unique is null, 'p_x_marker_vals_not_unique');
  ------------------------------
  v_main_count := get_count_ct_varchar_s(p_vals);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_p_marker_vals_count := get_count_ct_varchar_s(p_marker_vals);
  ------------------------------
  if v_p_marker_vals_count = 0
  then
    ------------------------------
    v_res := make_ct_number(v_main_count, p_unmark_value);
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_marker_vals := unique_ct_varchar_s(p_marker_vals, false, TRUE);
  ------------------------------
  XCheck_Cond_Invalid(p_x_marker_vals_not_unique and v_p_marker_vals_count > get_count_ct_varchar_s(v_marker_vals), c_msg_object_not_unique || c_msg_delim01 || 'p_marker_vals');
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_unmark_value, p_mark_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value val, rownum rn from table(v_marker_vals)) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_varchar_s) = nvl(q1.val, c_no_value_not_null_varchar_s)
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_ct_varchar(p_vals ct_varchar, p_marker_vals ct_varchar, p_mark_value number := c_true, p_unmark_value number := c_false, p_x_marker_vals_not_unique boolean := false) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_p_marker_vals_count number;
  v_marker_vals ct_varchar;
begin
  ------------------------------
  XCheck_Cond_Missing(p_x_marker_vals_not_unique is null, 'p_x_marker_vals_not_unique');
  ------------------------------
  v_main_count := get_count_ct_varchar(p_vals);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_p_marker_vals_count := get_count_ct_varchar(p_marker_vals);
  ------------------------------
  if v_p_marker_vals_count = 0
  then
    ------------------------------
    v_res := make_ct_number(v_main_count, p_unmark_value);
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_marker_vals := unique_ct_varchar(p_marker_vals, false, TRUE);
  ------------------------------
  XCheck_Cond_Invalid(p_x_marker_vals_not_unique and v_p_marker_vals_count > get_count_ct_varchar(v_marker_vals), c_msg_object_not_unique || c_msg_delim01 || 'p_marker_vals');
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_unmark_value, p_mark_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value val, rownum rn from table(v_marker_vals)) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_varchar) = nvl(q1.val, c_no_value_not_null_varchar)
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marker_vals ct_nvarchar_s, p_mark_value number := c_true, p_unmark_value number := c_false, p_x_marker_vals_not_unique boolean := false) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_p_marker_vals_count number;
  v_marker_vals ct_nvarchar_s;
begin
  ------------------------------
  XCheck_Cond_Missing(p_x_marker_vals_not_unique is null, 'p_x_marker_vals_not_unique');
  ------------------------------
  v_main_count := get_count_ct_nvarchar_s(p_vals);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_p_marker_vals_count := get_count_ct_nvarchar_s(p_marker_vals);
  ------------------------------
  if v_p_marker_vals_count = 0
  then
    ------------------------------
    v_res := make_ct_number(v_main_count, p_unmark_value);
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_marker_vals := unique_ct_nvarchar_s(p_marker_vals, false, TRUE);
  ------------------------------
  XCheck_Cond_Invalid(p_x_marker_vals_not_unique and v_p_marker_vals_count > get_count_ct_nvarchar_s(v_marker_vals), c_msg_object_not_unique || c_msg_delim01 || 'p_marker_vals');
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_unmark_value, p_mark_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value val, rownum rn from table(v_marker_vals)) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_nvarchar_s) = nvl(q1.val, c_no_value_not_null_nvarchar_s)
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_ct_nvarchar(p_vals ct_nvarchar, p_marker_vals ct_nvarchar, p_mark_value number := c_true, p_unmark_value number := c_false, p_x_marker_vals_not_unique boolean := false) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_p_marker_vals_count number;
  v_marker_vals ct_nvarchar;
begin
  ------------------------------
  XCheck_Cond_Missing(p_x_marker_vals_not_unique is null, 'p_x_marker_vals_not_unique');
  ------------------------------
  v_main_count := get_count_ct_nvarchar(p_vals);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_p_marker_vals_count := get_count_ct_nvarchar(p_marker_vals);
  ------------------------------
  if v_p_marker_vals_count = 0
  then
    ------------------------------
    v_res := make_ct_number(v_main_count, p_unmark_value);
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_marker_vals := unique_ct_nvarchar(p_marker_vals, false, TRUE);
  ------------------------------
  XCheck_Cond_Invalid(p_x_marker_vals_not_unique and v_p_marker_vals_count > get_count_ct_nvarchar(v_marker_vals), c_msg_object_not_unique || c_msg_delim01 || 'p_marker_vals');
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_unmark_value, p_mark_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value val, rownum rn from table(v_marker_vals)) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_nvarchar) = nvl(q1.val, c_no_value_not_null_nvarchar)
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function mark_val_ct_number(p_vals ct_number, p_marker_val number, p_mark_value number := c_true, p_unmark_value number := c_false) return ct_number
is
  v_marker_vals ct_number;
begin
  ------------------------------
  add_ct_number_val(v_marker_vals, p_marker_val);
  ------------------------------
  return mark_ct_number(p_vals, v_marker_vals, p_mark_value, p_unmark_value);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_val_ct_date(p_vals ct_date, p_marker_val date, p_mark_value number := c_true, p_unmark_value number := c_false) return ct_number
is
  v_marker_vals ct_date;
begin
  ------------------------------
  add_ct_date_val(v_marker_vals, p_marker_val);
  ------------------------------
  return mark_ct_date(p_vals, v_marker_vals, p_mark_value, p_unmark_value);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_val_ct_varchar_s(p_vals ct_varchar_s, p_marker_val varchar2, p_mark_value number := c_true, p_unmark_value number := c_false) return ct_number
is
  v_marker_vals ct_varchar_s;
begin
  ------------------------------
  add_ct_varchar_s_val(v_marker_vals, p_marker_val);
  ------------------------------
  return mark_ct_varchar_s(p_vals, v_marker_vals, p_mark_value, p_unmark_value);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_val_ct_varchar(p_vals ct_varchar, p_marker_val varchar2, p_mark_value number := c_true, p_unmark_value number := c_false) return ct_number
is
  v_marker_vals ct_varchar;
begin
  ------------------------------
  add_ct_varchar_val(v_marker_vals, p_marker_val);
  ------------------------------
  return mark_ct_varchar(p_vals, v_marker_vals, p_mark_value, p_unmark_value);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_val_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marker_val nvarchar2, p_mark_value number := c_true, p_unmark_value number := c_false) return ct_number
is
  v_marker_vals ct_nvarchar_s;
begin
  ------------------------------
  add_ct_nvarchar_s_val(v_marker_vals, p_marker_val);
  ------------------------------
  return mark_ct_nvarchar_s(p_vals, v_marker_vals, p_mark_value, p_unmark_value);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_val_ct_nvarchar(p_vals ct_nvarchar, p_marker_val nvarchar2, p_mark_value number := c_true, p_unmark_value number := c_false) return ct_number
is
  v_marker_vals ct_nvarchar;
begin
  ------------------------------
  add_ct_nvarchar_val(v_marker_vals, p_marker_val);
  ------------------------------
  return mark_ct_nvarchar(p_vals, v_marker_vals, p_mark_value, p_unmark_value);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_marked_ct_number(p_vals ct_number, p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_value number := null) return ct_number
is
  v_res ct_number;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
  v_main_count number;
begin
  ------------------------------
  v_main_count := get_count_ct_number(p_vals);
  XCheck_Cond_Invalid(get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(decode(q2.mark, p_mark_value, q1.val, p_no_value), p_no_value, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ct_date(p_vals ct_date, p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_value date := null) return ct_date
is
  v_res ct_date;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
  v_main_count number;
begin
  ------------------------------
  v_main_count := get_count_ct_date(p_vals);
  XCheck_Cond_Invalid(get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(decode(q2.mark, p_mark_value, q1.val, p_no_value), p_no_value, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ct_varchar_s(p_vals ct_varchar_s, p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_value varchar2 := null) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
  v_main_count number;
begin
  ------------------------------
  v_main_count := get_count_ct_varchar_s(p_vals);
  XCheck_Cond_Invalid(get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(decode(q2.mark, p_mark_value, q1.val, p_no_value), p_no_value, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ct_varchar(p_vals ct_varchar, p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_value varchar2 := null) return ct_varchar
is
  v_res ct_varchar;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
  v_main_count number;
begin
  ------------------------------
  v_main_count := get_count_ct_varchar(p_vals);
  XCheck_Cond_Invalid(get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(decode(q2.mark, p_mark_value, q1.val, p_no_value), p_no_value, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_value nvarchar2 := null) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
  v_main_count number;
begin
  ------------------------------
  v_main_count := get_count_ct_nvarchar_s(p_vals);
  XCheck_Cond_Invalid(get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(decode(q2.mark, p_mark_value, q1.val, p_no_value), p_no_value, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ct_nvarchar(p_vals ct_nvarchar, p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_value nvarchar2 := null) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
  v_main_count number;
begin
  ------------------------------
  v_main_count := get_count_ct_nvarchar(p_vals);
  XCheck_Cond_Invalid(get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(decode(q2.mark, p_mark_value, q1.val, p_no_value), p_no_value, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function mark2pos(p_marks ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_no_mark_pos number := null) return ct_number
is
  v_res ct_number;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  select
    decode(mark, p_mark_value, rn, p_no_mark_pos) val
    bulk collect into v_res
    from
      (select column_value mark, rownum rn from table(p_marks)) q
    where 1 = 1
    and decode(v_trim_empty, c_false, c_true, decode(mark, p_mark_value, c_true, c_false)) = c_true
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function pos2mark(p_positions ct_number, p_trim_empty boolean, p_mark_value number := c_true, p_unmark_value number := c_false, p_no_mark_pos number := null) return ct_number
is
  v_res ct_number;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  select
    decode(pos, p_no_mark_pos, p_unmark_value, p_mark_value) val
    bulk collect into v_res
    from
      (select column_value pos, rownum rn from table(p_positions)) q
    where 1 = 1
    and decode(v_trim_empty, c_false, c_true, decode(pos, p_no_mark_pos, c_false, c_true)) = c_true
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function map_ct_number(p_vals1 ct_number, p_vals2 ct_number, p_trim_empty boolean, p_reverse boolean := false, p_no_value_rn number := null) return ct_number
is
  v_res ct_number;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
  v_reverse number := bool_to_int_2val(p_reverse);
begin
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value_rn, decode(v_reverse, c_false, q2.rn, q1.rn)) rn
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals1)) q1,
      (select column_value val, rownum rn from table(p_vals2)) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_number) = nvl(q1.val, c_no_value_not_null_number)
    and decode(v_trim_empty, c_false, c_true, decode(q2.rn, null, c_false, c_true)) = c_true
    order by q1.rn, q2.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function map_ct_date(p_vals1 ct_date, p_vals2 ct_date, p_trim_empty boolean, p_reverse boolean := false, p_no_value_rn number := null) return ct_number
is
  v_res ct_number;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
  v_reverse number := bool_to_int_2val(p_reverse);
begin
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value_rn, decode(v_reverse, c_false, q2.rn, q1.rn)) rn
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals1)) q1,
      (select column_value val, rownum rn from table(p_vals2)) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_date) = nvl(q1.val, c_no_value_not_null_date)
    and decode(v_trim_empty, c_false, c_true, decode(q2.rn, null, c_false, c_true)) = c_true
    order by q1.rn, q2.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function map_ct_varchar_s(p_vals1 ct_varchar_s, p_vals2 ct_varchar_s, p_trim_empty boolean, p_reverse boolean := false, p_no_value_rn number := null) return ct_number
is
  v_res ct_number;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
  v_reverse number := bool_to_int_2val(p_reverse);
begin
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value_rn, decode(v_reverse, c_false, q2.rn, q1.rn)) rn
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals1)) q1,
      (select column_value val, rownum rn from table(p_vals2)) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_varchar_s) = nvl(q1.val, c_no_value_not_null_varchar_s)
    and decode(v_trim_empty, c_false, c_true, decode(q2.rn, null, c_false, c_true)) = c_true
    order by q1.rn, q2.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function map_ct_varchar(p_vals1 ct_varchar, p_vals2 ct_varchar, p_trim_empty boolean, p_reverse boolean := false, p_no_value_rn number := null) return ct_number
is
  v_res ct_number;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
  v_reverse number := bool_to_int_2val(p_reverse);
begin
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value_rn, decode(v_reverse, c_false, q2.rn, q1.rn)) rn
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals1)) q1,
      (select column_value val, rownum rn from table(p_vals2)) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_varchar) = nvl(q1.val, c_no_value_not_null_varchar)
    and decode(v_trim_empty, c_false, c_true, decode(q2.rn, null, c_false, c_true)) = c_true
    order by q1.rn, q2.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function map_ct_nvarchar_s(p_vals1 ct_nvarchar_s, p_vals2 ct_nvarchar_s, p_trim_empty boolean, p_reverse boolean := false, p_no_value_rn number := null) return ct_number
is
  v_res ct_number;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
  v_reverse number := bool_to_int_2val(p_reverse);
begin
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value_rn, decode(v_reverse, c_false, q2.rn, q1.rn)) rn
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals1)) q1,
      (select column_value val, rownum rn from table(p_vals2)) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_nvarchar_s) = nvl(q1.val, c_no_value_not_null_nvarchar_s)
    and decode(v_trim_empty, c_false, c_true, decode(q2.rn, null, c_false, c_true)) = c_true
    order by q1.rn, q2.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function map_ct_nvarchar(p_vals1 ct_nvarchar, p_vals2 ct_nvarchar, p_trim_empty boolean, p_reverse boolean := false, p_no_value_rn number := null) return ct_number
is
  v_res ct_number;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
  v_reverse number := bool_to_int_2val(p_reverse);
begin
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value_rn, decode(v_reverse, c_false, q2.rn, q1.rn)) rn
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals1)) q1,
      (select column_value val, rownum rn from table(p_vals2)) q2
    where 1 = 1
    and nvl2(q2.val(+), c_false, c_true) = nvl2(q1.val, c_false, c_true)
    and nvl(q2.val(+), c_no_value_not_null_nvarchar) = nvl(q1.val, c_no_value_not_null_nvarchar)
    and decode(v_trim_empty, c_false, c_true, decode(q2.rn, null, c_false, c_true)) = c_true
    order by q1.rn, q2.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_by_pos_ct_number(p_vals ct_number, p_positions ct_number, p_trim_empty boolean, p_no_value number := null) return ct_number
is
  v_res ct_number;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value, q2.val) val
    bulk collect into v_res
    from
      (select column_value pos, rownum rn from table(p_positions)) q1,
      (select column_value val, rownum rn from table(p_vals)) q2
    where 1 = 1
    and q2.rn(+) = q1.pos
    and decode(v_trim_empty, c_false, c_true, decode(q2.rn, null, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ct_date(p_vals ct_date, p_positions ct_number, p_trim_empty boolean, p_no_value date := null) return ct_date
is
  v_res ct_date;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value, q2.val) val
    bulk collect into v_res
    from
      (select column_value pos, rownum rn from table(p_positions)) q1,
      (select column_value val, rownum rn from table(p_vals)) q2
    where 1 = 1
    and q2.rn(+) = q1.pos
    and decode(v_trim_empty, c_false, c_true, decode(q2.rn, null, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ct_varchar_s(p_vals ct_varchar_s, p_positions ct_number, p_trim_empty boolean, p_no_value varchar2 := null) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value, q2.val) val
    bulk collect into v_res
    from
      (select column_value pos, rownum rn from table(p_positions)) q1,
      (select column_value val, rownum rn from table(p_vals)) q2
    where 1 = 1
    and q2.rn(+) = q1.pos
    and decode(v_trim_empty, c_false, c_true, decode(q2.rn, null, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ct_varchar(p_vals ct_varchar, p_positions ct_number, p_trim_empty boolean, p_no_value varchar2 := null) return ct_varchar
is
  v_res ct_varchar;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value, q2.val) val
    bulk collect into v_res
    from
      (select column_value pos, rownum rn from table(p_positions)) q1,
      (select column_value val, rownum rn from table(p_vals)) q2
    where 1 = 1
    and q2.rn(+) = q1.pos
    and decode(v_trim_empty, c_false, c_true, decode(q2.rn, null, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ct_nvarchar_s(p_vals ct_nvarchar_s, p_positions ct_number, p_trim_empty boolean, p_no_value nvarchar2 := null) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value, q2.val) val
    bulk collect into v_res
    from
      (select column_value pos, rownum rn from table(p_positions)) q1,
      (select column_value val, rownum rn from table(p_vals)) q2
    where 1 = 1
    and q2.rn(+) = q1.pos
    and decode(v_trim_empty, c_false, c_true, decode(q2.rn, null, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ct_nvarchar(p_vals ct_nvarchar, p_positions ct_number, p_trim_empty boolean, p_no_value nvarchar2 := null) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value, q2.val) val
    bulk collect into v_res
    from
      (select column_value pos, rownum rn from table(p_positions)) q1,
      (select column_value val, rownum rn from table(p_vals)) q2
    where 1 = 1
    and q2.rn(+) = q1.pos
    and decode(v_trim_empty, c_false, c_true, decode(q2.rn, null, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_by_pos2_ct_number(p_vals ct_number, p_positions ct_number, p_trim_empty boolean, p_no_value number := null) return ct_number
is
  v_res ct_number;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    if NOT p_trim_empty
    then
      ------------------------------
      v_res := make_ct_number(get_count_ct_number(p_vals), p_no_value);
      ------------------------------
    end if;
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.pos, null, p_no_value, q1.val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value pos, rownum rn from table(p_positions)) q2
    where 1 = 1
    and q2.pos(+) = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(q2.pos, null, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos2_ct_date(p_vals ct_date, p_positions ct_number, p_trim_empty boolean, p_no_value date := null) return ct_date
is
  v_res ct_date;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    if NOT p_trim_empty
    then
      ------------------------------
      v_res := make_ct_date(get_count_ct_date(p_vals), p_no_value);
      ------------------------------
    end if;
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.pos, null, p_no_value, q1.val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value pos, rownum rn from table(p_positions)) q2
    where 1 = 1
    and q2.pos(+) = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(q2.pos, null, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos2_ct_varchar_s(p_vals ct_varchar_s, p_positions ct_number, p_trim_empty boolean, p_no_value varchar2 := null) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    if NOT p_trim_empty
    then
      ------------------------------
      v_res := make_ct_varchar_s(get_count_ct_varchar_s(p_vals), p_no_value);
      ------------------------------
    end if;
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.pos, null, p_no_value, q1.val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value pos, rownum rn from table(p_positions)) q2
    where 1 = 1
    and q2.pos(+) = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(q2.pos, null, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos2_ct_varchar(p_vals ct_varchar, p_positions ct_number, p_trim_empty boolean, p_no_value varchar2 := null) return ct_varchar
is
  v_res ct_varchar;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    if NOT p_trim_empty
    then
      ------------------------------
      v_res := make_ct_varchar(get_count_ct_varchar(p_vals), p_no_value);
      ------------------------------
    end if;
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.pos, null, p_no_value, q1.val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value pos, rownum rn from table(p_positions)) q2
    where 1 = 1
    and q2.pos(+) = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(q2.pos, null, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos2_ct_nvarchar_s(p_vals ct_nvarchar_s, p_positions ct_number, p_trim_empty boolean, p_no_value nvarchar2 := null) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    if NOT p_trim_empty
    then
      ------------------------------
      v_res := make_ct_nvarchar_s(get_count_ct_nvarchar_s(p_vals), p_no_value);
      ------------------------------
    end if;
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.pos, null, p_no_value, q1.val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value pos, rownum rn from table(p_positions)) q2
    where 1 = 1
    and q2.pos(+) = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(q2.pos, null, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos2_ct_nvarchar(p_vals ct_nvarchar, p_positions ct_number, p_trim_empty boolean, p_no_value nvarchar2 := null) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    if NOT p_trim_empty
    then
      ------------------------------
      v_res := make_ct_nvarchar(get_count_ct_nvarchar(p_vals), p_no_value);
      ------------------------------
    end if;
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.pos, null, p_no_value, q1.val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value pos, rownum rn from table(p_positions)) q2
    where 1 = 1
    and q2.pos(+) = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(q2.pos, null, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_by_pos_ct_number(p_coll in out nocopy ct_number, p_vals ct_number, p_positions ct_number, p_ignore_lack boolean := false)
is
  v_main_count number;
begin
  ------------------------------
  XCheckP_ct_number(p_vals, 'p_vals');
  XCheckP_ct_number(p_positions, 'p_positions');
  XCheck_Cond_Missing(p_ignore_lack is null, 'p_ignore_lack');
  ------------------------------
  v_main_count := get_count_ct_number(p_positions);
  XCheck_Cond_Invalid(get_count_ct_number(p_positions) != v_main_count, 'p_positions.count != v_main_count');
  XCheck_Cond_Invalid(get_count_ct_number(p_vals) != v_main_count, 'p_vals.count != v_main_count');
  ------------------------------
  v_main_count := get_count_ct_number(p_coll); --!_!
  ------------------------------
  for v_i in p_positions.first..p_positions.last loop
    ------------------------------
    if 1 = 1
      and p_positions(v_i) is not null
      and p_positions(v_i) between 1 and v_main_count
    then
      ------------------------------
      p_coll(p_positions(v_i)) := p_vals(v_i);
      ------------------------------
    elsif not p_ignore_lack
    then
      ------------------------------
      raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter
        || c_msg_delim01 || 'v_i,p_positions(v_i),v_main_count'
        || c_msg_delim02 || number_to_char(v_i)
        || c_msg_delim02 || number_to_char(p_positions(v_i))
        || c_msg_delim02 || number_to_char(v_main_count)
      );
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_by_pos_ct_date(p_coll in out nocopy ct_date, p_vals ct_date, p_positions ct_number, p_ignore_lack boolean := false)
is
  v_main_count number;
begin
  ------------------------------
  XCheckP_ct_date(p_vals, 'p_vals');
  XCheckP_ct_number(p_positions, 'p_positions');
  XCheck_Cond_Missing(p_ignore_lack is null, 'p_ignore_lack');
  ------------------------------
  v_main_count := get_count_ct_number(p_positions);
  XCheck_Cond_Invalid(get_count_ct_number(p_positions) != v_main_count, 'p_positions.count != v_main_count');
  XCheck_Cond_Invalid(get_count_ct_date(p_vals) != v_main_count, 'p_vals.count != v_main_count');
  ------------------------------
  v_main_count := get_count_ct_date(p_coll); --!_!
  ------------------------------
  for v_i in p_positions.first..p_positions.last loop
    ------------------------------
    if 1 = 1
      and p_positions(v_i) is not null
      and p_positions(v_i) between 1 and v_main_count
    then
      ------------------------------
      p_coll(p_positions(v_i)) := p_vals(v_i);
      ------------------------------
    elsif not p_ignore_lack
    then
      ------------------------------
      raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter
        || c_msg_delim01 || 'v_i,p_positions(v_i),v_main_count'
        || c_msg_delim02 || number_to_char(v_i)
        || c_msg_delim02 || number_to_char(p_positions(v_i))
        || c_msg_delim02 || number_to_char(v_main_count)
      );
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_by_pos_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_vals ct_varchar_s, p_positions ct_number, p_ignore_lack boolean := false)
is
  v_main_count number;
begin
  ------------------------------
  XCheckP_ct_varchar_s(p_vals, 'p_vals');
  XCheckP_ct_number(p_positions, 'p_positions');
  XCheck_Cond_Missing(p_ignore_lack is null, 'p_ignore_lack');
  ------------------------------
  v_main_count := get_count_ct_number(p_positions);
  XCheck_Cond_Invalid(get_count_ct_number(p_positions) != v_main_count, 'p_positions.count != v_main_count');
  XCheck_Cond_Invalid(get_count_ct_varchar_s(p_vals) != v_main_count, 'p_vals.count != v_main_count');
  ------------------------------
  v_main_count := get_count_ct_varchar_s(p_coll); --!_!
  ------------------------------
  for v_i in p_positions.first..p_positions.last loop
    ------------------------------
    if 1 = 1
      and p_positions(v_i) is not null
      and p_positions(v_i) between 1 and v_main_count
    then
      ------------------------------
      p_coll(p_positions(v_i)) := p_vals(v_i);
      ------------------------------
    elsif not p_ignore_lack
    then
      ------------------------------
      raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter
        || c_msg_delim01 || 'v_i,p_positions(v_i),v_main_count'
        || c_msg_delim02 || number_to_char(v_i)
        || c_msg_delim02 || number_to_char(p_positions(v_i))
        || c_msg_delim02 || number_to_char(v_main_count)
      );
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_by_pos_ct_varchar(p_coll in out nocopy ct_varchar, p_vals ct_varchar, p_positions ct_number, p_ignore_lack boolean := false)
is
  v_main_count number;
begin
  ------------------------------
  XCheckP_ct_varchar(p_vals, 'p_vals');
  XCheckP_ct_number(p_positions, 'p_positions');
  XCheck_Cond_Missing(p_ignore_lack is null, 'p_ignore_lack');
  ------------------------------
  v_main_count := get_count_ct_number(p_positions);
  XCheck_Cond_Invalid(get_count_ct_number(p_positions) != v_main_count, 'p_positions.count != v_main_count');
  XCheck_Cond_Invalid(get_count_ct_varchar(p_vals) != v_main_count, 'p_vals.count != v_main_count');
  ------------------------------
  v_main_count := get_count_ct_varchar(p_coll); --!_!
  ------------------------------
  for v_i in p_positions.first..p_positions.last loop
    ------------------------------
    if 1 = 1
      and p_positions(v_i) is not null
      and p_positions(v_i) between 1 and v_main_count
    then
      ------------------------------
      p_coll(p_positions(v_i)) := p_vals(v_i);
      ------------------------------
    elsif not p_ignore_lack
    then
      ------------------------------
      raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter
        || c_msg_delim01 || 'v_i,p_positions(v_i),v_main_count'
        || c_msg_delim02 || number_to_char(v_i)
        || c_msg_delim02 || number_to_char(p_positions(v_i))
        || c_msg_delim02 || number_to_char(v_main_count)
      );
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_by_pos_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_vals ct_nvarchar_s, p_positions ct_number, p_ignore_lack boolean := false)
is
  v_main_count number;
begin
  ------------------------------
  XCheckP_ct_nvarchar_s(p_vals, 'p_vals');
  XCheckP_ct_number(p_positions, 'p_positions');
  XCheck_Cond_Missing(p_ignore_lack is null, 'p_ignore_lack');
  ------------------------------
  v_main_count := get_count_ct_number(p_positions);
  XCheck_Cond_Invalid(get_count_ct_number(p_positions) != v_main_count, 'p_positions.count != v_main_count');
  XCheck_Cond_Invalid(get_count_ct_nvarchar_s(p_vals) != v_main_count, 'p_vals.count != v_main_count');
  ------------------------------
  v_main_count := get_count_ct_nvarchar_s(p_coll); --!_!
  ------------------------------
  for v_i in p_positions.first..p_positions.last loop
    ------------------------------
    if 1 = 1
      and p_positions(v_i) is not null
      and p_positions(v_i) between 1 and v_main_count
    then
      ------------------------------
      p_coll(p_positions(v_i)) := p_vals(v_i);
      ------------------------------
    elsif not p_ignore_lack
    then
      ------------------------------
      raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter
        || c_msg_delim01 || 'v_i,p_positions(v_i),v_main_count'
        || c_msg_delim02 || number_to_char(v_i)
        || c_msg_delim02 || number_to_char(p_positions(v_i))
        || c_msg_delim02 || number_to_char(v_main_count)
      );
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_by_pos_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_vals ct_nvarchar, p_positions ct_number, p_ignore_lack boolean := false)
is
  v_main_count number;
begin
  ------------------------------
  XCheckP_ct_nvarchar(p_vals, 'p_vals');
  XCheckP_ct_number(p_positions, 'p_positions');
  XCheck_Cond_Missing(p_ignore_lack is null, 'p_ignore_lack');
  ------------------------------
  v_main_count := get_count_ct_number(p_positions);
  XCheck_Cond_Invalid(get_count_ct_number(p_positions) != v_main_count, 'p_positions.count != v_main_count');
  XCheck_Cond_Invalid(get_count_ct_nvarchar(p_vals) != v_main_count, 'p_vals.count != v_main_count');
  ------------------------------
  v_main_count := get_count_ct_nvarchar(p_coll); --!_!
  ------------------------------
  for v_i in p_positions.first..p_positions.last loop
    ------------------------------
    if 1 = 1
      and p_positions(v_i) is not null
      and p_positions(v_i) between 1 and v_main_count
    then
      ------------------------------
      p_coll(p_positions(v_i)) := p_vals(v_i);
      ------------------------------
    elsif not p_ignore_lack
    then
      ------------------------------
      raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter
        || c_msg_delim01 || 'v_i,p_positions(v_i),v_main_count'
        || c_msg_delim02 || number_to_char(v_i)
        || c_msg_delim02 || number_to_char(p_positions(v_i))
        || c_msg_delim02 || number_to_char(v_main_count)
      );
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_by_pos2_ct_number(p_coll in out nocopy ct_number, p_vals ct_number, p_positions ct_number, p_ignore_lack boolean := false)
is
begin
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  set_by_pos_ct_number(p_coll, p_vals, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_by_pos2_ct_date(p_coll in out nocopy ct_date, p_vals ct_date, p_positions ct_number, p_ignore_lack boolean := false)
is
begin
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  set_by_pos_ct_date(p_coll, p_vals, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_by_pos2_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_vals ct_varchar_s, p_positions ct_number, p_ignore_lack boolean := false)
is
begin
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  set_by_pos_ct_varchar_s(p_coll, p_vals, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_by_pos2_ct_varchar(p_coll in out nocopy ct_varchar, p_vals ct_varchar, p_positions ct_number, p_ignore_lack boolean := false)
is
begin
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  set_by_pos_ct_varchar(p_coll, p_vals, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_by_pos2_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_vals ct_nvarchar_s, p_positions ct_number, p_ignore_lack boolean := false)
is
begin
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  set_by_pos_ct_nvarchar_s(p_coll, p_vals, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_by_pos2_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_vals ct_nvarchar, p_positions ct_number, p_ignore_lack boolean := false)
is
begin
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  set_by_pos_ct_nvarchar(p_coll, p_vals, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_val_by_pos_ct_number(p_coll in out nocopy ct_number, p_val number, p_positions ct_number, p_ignore_lack boolean := false)
is
  v_vals ct_number;
begin
  ------------------------------
  XCheckP_ct_number(p_positions, 'p_positions');
  XCheck_Cond_Missing(p_ignore_lack is null, 'p_ignore_lack');
  ------------------------------
  resize_ct_number(v_vals, get_count_ct_number(p_positions));
  fill_ct_number(v_vals, p_val);
  ------------------------------
  set_by_pos_ct_number(p_coll, v_vals, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_val_by_pos_ct_date(p_coll in out nocopy ct_date, p_val date, p_positions ct_number, p_ignore_lack boolean := false)
is
  v_vals ct_date;
begin
  ------------------------------
  XCheckP_ct_number(p_positions, 'p_positions');
  XCheck_Cond_Missing(p_ignore_lack is null, 'p_ignore_lack');
  ------------------------------
  resize_ct_date(v_vals, get_count_ct_number(p_positions));
  fill_ct_date(v_vals, p_val);
  ------------------------------
  set_by_pos_ct_date(p_coll, v_vals, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_val_by_pos_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_val varchar2, p_positions ct_number, p_ignore_lack boolean := false)
is
  v_vals ct_varchar_s;
begin
  ------------------------------
  XCheckP_ct_number(p_positions, 'p_positions');
  XCheck_Cond_Missing(p_ignore_lack is null, 'p_ignore_lack');
  ------------------------------
  resize_ct_varchar_s(v_vals, get_count_ct_number(p_positions));
  fill_ct_varchar_s(v_vals, p_val);
  ------------------------------
  set_by_pos_ct_varchar_s(p_coll, v_vals, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_val_by_pos_ct_varchar(p_coll in out nocopy ct_varchar, p_val varchar2, p_positions ct_number, p_ignore_lack boolean := false)
is
  v_vals ct_varchar;
begin
  ------------------------------
  XCheckP_ct_number(p_positions, 'p_positions');
  XCheck_Cond_Missing(p_ignore_lack is null, 'p_ignore_lack');
  ------------------------------
  resize_ct_varchar(v_vals, get_count_ct_number(p_positions));
  fill_ct_varchar(v_vals, p_val);
  ------------------------------
  set_by_pos_ct_varchar(p_coll, v_vals, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_val_by_pos_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_val nvarchar2, p_positions ct_number, p_ignore_lack boolean := false)
is
  v_vals ct_nvarchar_s;
begin
  ------------------------------
  XCheckP_ct_number(p_positions, 'p_positions');
  XCheck_Cond_Missing(p_ignore_lack is null, 'p_ignore_lack');
  ------------------------------
  resize_ct_nvarchar_s(v_vals, get_count_ct_number(p_positions));
  fill_ct_nvarchar_s(v_vals, p_val);
  ------------------------------
  set_by_pos_ct_nvarchar_s(p_coll, v_vals, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_val_by_pos_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_val nvarchar2, p_positions ct_number, p_ignore_lack boolean := false)
is
  v_vals ct_nvarchar;
begin
  ------------------------------
  XCheckP_ct_number(p_positions, 'p_positions');
  XCheck_Cond_Missing(p_ignore_lack is null, 'p_ignore_lack');
  ------------------------------
  resize_ct_nvarchar(v_vals, get_count_ct_number(p_positions));
  fill_ct_nvarchar(v_vals, p_val);
  ------------------------------
  set_by_pos_ct_nvarchar(p_coll, v_vals, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_val_by_pos2_ct_number(p_coll in out nocopy ct_number, p_val number, p_positions ct_number, p_ignore_lack boolean := false)
is
begin
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  set_val_by_pos_ct_number(p_coll, p_val, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_val_by_pos2_ct_date(p_coll in out nocopy ct_date, p_val date, p_positions ct_number, p_ignore_lack boolean := false)
is
begin
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  set_val_by_pos_ct_date(p_coll, p_val, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_val_by_pos2_ct_varchar_s(p_coll in out nocopy ct_varchar_s, p_val varchar2, p_positions ct_number, p_ignore_lack boolean := false)
is
begin
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  set_val_by_pos_ct_varchar_s(p_coll, p_val, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_val_by_pos2_ct_varchar(p_coll in out nocopy ct_varchar, p_val varchar2, p_positions ct_number, p_ignore_lack boolean := false)
is
begin
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  set_val_by_pos_ct_varchar(p_coll, p_val, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_val_by_pos2_ct_nvarchar_s(p_coll in out nocopy ct_nvarchar_s, p_val nvarchar2, p_positions ct_number, p_ignore_lack boolean := false)
is
begin
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  set_val_by_pos_ct_nvarchar_s(p_coll, p_val, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_val_by_pos2_ct_nvarchar(p_coll in out nocopy ct_nvarchar, p_val nvarchar2, p_positions ct_number, p_ignore_lack boolean := false)
is
begin
  ------------------------------
  if get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  set_val_by_pos_ct_nvarchar(p_coll, p_val, p_positions, p_ignore_lack);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function supplement_ct_number(p_vals ct_number, p_supplement ct_number, p_trim_empty boolean, p_no_value number := null) return ct_number
is
  v_res ct_number;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  if not CheckP_ct_number(p_vals) and not CheckP_ct_number(p_supplement)
  then
    return v_res;
  end if;
  ------------------------------
  if (1 = 0
    or (CheckP_ct_number(p_vals) and not CheckP_ct_number(p_supplement))
    or (not CheckP_ct_number(p_vals) and CheckP_ct_number(p_supplement))
  )
  then
    ------------------------------
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || 'p_vals, p_supplement');
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q1.val, p_no_value, q2.supplement, q1.val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value supplement, rownum rn from table(p_supplement)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(decode(q1.val, p_no_value, q2.supplement, q1.val), p_no_value, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function supplement_ct_date(p_vals ct_date, p_supplement ct_date, p_trim_empty boolean, p_no_value date := null) return ct_date
is
  v_res ct_date;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  if not CheckP_ct_date(p_vals) and not CheckP_ct_date(p_supplement)
  then
    return v_res;
  end if;
  ------------------------------
  if (1 = 0
    or (CheckP_ct_date(p_vals) and not CheckP_ct_date(p_supplement))
    or (not CheckP_ct_date(p_vals) and CheckP_ct_date(p_supplement))
  )
  then
    ------------------------------
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || 'p_vals, p_supplement');
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q1.val, p_no_value, q2.supplement, q1.val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value supplement, rownum rn from table(p_supplement)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(decode(q1.val, p_no_value, q2.supplement, q1.val), p_no_value, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function supplement_ct_varchar_s(p_vals ct_varchar_s, p_supplement ct_varchar_s, p_trim_empty boolean, p_no_value varchar2 := null) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  if not CheckP_ct_varchar_s(p_vals) and not CheckP_ct_varchar_s(p_supplement)
  then
    return v_res;
  end if;
  ------------------------------
  if (1 = 0
    or (CheckP_ct_varchar_s(p_vals) and not CheckP_ct_varchar_s(p_supplement))
    or (not CheckP_ct_varchar_s(p_vals) and CheckP_ct_varchar_s(p_supplement))
  )
  then
    ------------------------------
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || 'p_vals, p_supplement');
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q1.val, p_no_value, q2.supplement, q1.val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value supplement, rownum rn from table(p_supplement)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(decode(q1.val, p_no_value, q2.supplement, q1.val), p_no_value, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function supplement_ct_varchar(p_vals ct_varchar, p_supplement ct_varchar, p_trim_empty boolean, p_no_value varchar2 := null) return ct_varchar
is
  v_res ct_varchar;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  if not CheckP_ct_varchar(p_vals) and not CheckP_ct_varchar(p_supplement)
  then
    return v_res;
  end if;
  ------------------------------
  if (1 = 0
    or (CheckP_ct_varchar(p_vals) and not CheckP_ct_varchar(p_supplement))
    or (not CheckP_ct_varchar(p_vals) and CheckP_ct_varchar(p_supplement))
  )
  then
    ------------------------------
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || 'p_vals, p_supplement');
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q1.val, p_no_value, q2.supplement, q1.val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value supplement, rownum rn from table(p_supplement)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(decode(q1.val, p_no_value, q2.supplement, q1.val), p_no_value, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function supplement_ct_nvarchar_s(p_vals ct_nvarchar_s, p_supplement ct_nvarchar_s, p_trim_empty boolean, p_no_value nvarchar2 := null) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  if not CheckP_ct_nvarchar_s(p_vals) and not CheckP_ct_nvarchar_s(p_supplement)
  then
    return v_res;
  end if;
  ------------------------------
  if (1 = 0
    or (CheckP_ct_nvarchar_s(p_vals) and not CheckP_ct_nvarchar_s(p_supplement))
    or (not CheckP_ct_nvarchar_s(p_vals) and CheckP_ct_nvarchar_s(p_supplement))
  )
  then
    ------------------------------
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || 'p_vals, p_supplement');
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q1.val, p_no_value, q2.supplement, q1.val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value supplement, rownum rn from table(p_supplement)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(decode(q1.val, p_no_value, q2.supplement, q1.val), p_no_value, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function supplement_ct_nvarchar(p_vals ct_nvarchar, p_supplement ct_nvarchar, p_trim_empty boolean, p_no_value nvarchar2 := null) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_trim_empty number := bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  if not CheckP_ct_nvarchar(p_vals) and not CheckP_ct_nvarchar(p_supplement)
  then
    return v_res;
  end if;
  ------------------------------
  if (1 = 0
    or (CheckP_ct_nvarchar(p_vals) and not CheckP_ct_nvarchar(p_supplement))
    or (not CheckP_ct_nvarchar(p_vals) and CheckP_ct_nvarchar(p_supplement))
  )
  then
    ------------------------------
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || 'p_vals, p_supplement');
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q1.val, p_no_value, q2.supplement, q1.val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value supplement, rownum rn from table(p_supplement)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, c_false, c_true, decode(decode(q1.val, p_no_value, q2.supplement, q1.val), p_no_value, c_false, c_true)) = c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function lower_ct_varchar_s(p_vals ct_varchar_s) return ct_varchar_s
is
  v_res ct_varchar_s;
begin
  ------------------------------
  select
    lower(val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lower_ct_varchar(p_vals ct_varchar) return ct_varchar
is
  v_res ct_varchar;
begin
  ------------------------------
  select
    lower(val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lower_ct_nvarchar_s(p_vals ct_nvarchar_s) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  select
    lower(val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lower_ct_nvarchar(p_vals ct_nvarchar) return ct_nvarchar
is
  v_res ct_nvarchar;
begin
  ------------------------------
  select
    lower(val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function upper_ct_varchar_s(p_vals ct_varchar_s) return ct_varchar_s
is
  v_res ct_varchar_s;
begin
  ------------------------------
  select
    upper(val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function upper_ct_varchar(p_vals ct_varchar) return ct_varchar
is
  v_res ct_varchar;
begin
  ------------------------------
  select
    upper(val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function upper_ct_nvarchar_s(p_vals ct_nvarchar_s) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  select
    upper(val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function upper_ct_nvarchar(p_vals ct_nvarchar) return ct_nvarchar
is
  v_res ct_nvarchar;
begin
  ------------------------------
  select
    upper(val) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_nulls_ct_number(p_vals ct_number) return boolean
is
  v_coll ct_number;
begin
  ------------------------------
  add_ct_number_val(v_coll, null);
  ------------------------------
  v_coll := filter_val_ct_number(p_vals, v_coll, true);
  ------------------------------
  return CheckP_ct_number(v_coll);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_nulls_ct_date(p_vals ct_date) return boolean
is
  v_coll ct_date;
begin
  ------------------------------
  add_ct_date_val(v_coll, null);
  ------------------------------
  v_coll := filter_val_ct_date(p_vals, v_coll, true);
  ------------------------------
  return CheckP_ct_date(v_coll);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_nulls_ct_varchar_s(p_vals ct_varchar_s) return boolean
is
  v_coll ct_varchar_s;
begin
  ------------------------------
  add_ct_varchar_s_val(v_coll, null);
  ------------------------------
  v_coll := filter_val_ct_varchar_s(p_vals, v_coll, true);
  ------------------------------
  return CheckP_ct_varchar_s(v_coll);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_nulls_ct_varchar(p_vals ct_varchar) return boolean
is
  v_coll ct_varchar;
begin
  ------------------------------
  add_ct_varchar_val(v_coll, null);
  ------------------------------
  v_coll := filter_val_ct_varchar(p_vals, v_coll, true);
  ------------------------------
  return CheckP_ct_varchar(v_coll);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_nulls_ct_nvarchar_s(p_vals ct_nvarchar_s) return boolean
is
  v_coll ct_nvarchar_s;
begin
  ------------------------------
  add_ct_nvarchar_s_val(v_coll, null);
  ------------------------------
  v_coll := filter_val_ct_nvarchar_s(p_vals, v_coll, true);
  ------------------------------
  return CheckP_ct_nvarchar_s(v_coll);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_nulls_ct_nvarchar(p_vals ct_nvarchar) return boolean
is
  v_coll ct_nvarchar;
begin
  ------------------------------
  add_ct_nvarchar_val(v_coll, null);
  ------------------------------
  v_coll := filter_val_ct_nvarchar(p_vals, v_coll, true);
  ------------------------------
  return CheckP_ct_nvarchar(v_coll);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_nulls_cit_number(p_vals cit_number, p_smart_cit boolean) return boolean
is
begin
  ------------------------------
  return is_nulls_ct_number(cast_cit2ct_number(p_vals, p_smart_cit));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_nulls_cit_date(p_vals cit_date, p_smart_cit boolean) return boolean
is
begin
  ------------------------------
  return is_nulls_ct_date(cast_cit2ct_date(p_vals, p_smart_cit));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_nulls_cit_varchar_s(p_vals cit_varchar_s, p_smart_cit boolean) return boolean
is
begin
  ------------------------------
  return is_nulls_ct_varchar_s(cast_cit2ct_varchar_s(p_vals, p_smart_cit));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_nulls_cit_varchar(p_vals cit_varchar, p_smart_cit boolean) return boolean
is
begin
  ------------------------------
  return is_nulls_ct_varchar(cast_cit2ct_varchar(p_vals, p_smart_cit));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_nulls_cit_nvarchar_s(p_vals cit_nvarchar_s, p_smart_cit boolean) return boolean
is
begin
  ------------------------------
  return is_nulls_ct_nvarchar_s(cast_cit2ct_nvarchar_s(p_vals, p_smart_cit));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_nulls_cit_nvarchar(p_vals cit_nvarchar, p_smart_cit boolean) return boolean
is
begin
  ------------------------------
  return is_nulls_ct_nvarchar(cast_cit2ct_nvarchar(p_vals, p_smart_cit));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xis_nulls_ct_number(p_vals ct_number, p_label varchar2 := null)
is
begin
  ------------------------------
  if is_nulls_ct_number(p_vals)
  then
    ------------------------------
    raise_exception(c_ora_object_empty, c_msg_object_empty || c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_nulls_ct_date(p_vals ct_date, p_label varchar2 := null)
is
begin
  ------------------------------
  if is_nulls_ct_date(p_vals)
  then
    ------------------------------
    raise_exception(c_ora_object_empty, c_msg_object_empty || c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_nulls_ct_varchar_s(p_vals ct_varchar_s, p_label varchar2 := null)
is
begin
  ------------------------------
  if is_nulls_ct_varchar_s(p_vals)
  then
    ------------------------------
    raise_exception(c_ora_object_empty, c_msg_object_empty || c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_nulls_ct_varchar(p_vals ct_varchar, p_label varchar2 := null)
is
begin
  ------------------------------
  if is_nulls_ct_varchar(p_vals)
  then
    ------------------------------
    raise_exception(c_ora_object_empty, c_msg_object_empty || c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_nulls_ct_nvarchar_s(p_vals ct_nvarchar_s, p_label varchar2 := null)
is
begin
  ------------------------------
  if is_nulls_ct_nvarchar_s(p_vals)
  then
    ------------------------------
    raise_exception(c_ora_object_empty, c_msg_object_empty || c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_nulls_ct_nvarchar(p_vals ct_nvarchar, p_label varchar2 := null)
is
begin
  ------------------------------
  if is_nulls_ct_nvarchar(p_vals)
  then
    ------------------------------
    raise_exception(c_ora_object_empty, c_msg_object_empty || c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_nulls_cit_number(p_vals cit_number, p_smart_cit boolean, p_label varchar2 := null)
is
begin
  ------------------------------
  xis_nulls_ct_number(cast_cit2ct_number(p_vals, p_smart_cit), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_nulls_cit_date(p_vals cit_date, p_smart_cit boolean, p_label varchar2 := null)
is
begin
  ------------------------------
  xis_nulls_ct_date(cast_cit2ct_date(p_vals, p_smart_cit), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_nulls_cit_varchar_s(p_vals cit_varchar_s, p_smart_cit boolean, p_label varchar2 := null)
is
begin
  ------------------------------
  xis_nulls_ct_varchar_s(cast_cit2ct_varchar_s(p_vals, p_smart_cit), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_nulls_cit_varchar(p_vals cit_varchar, p_smart_cit boolean, p_label varchar2 := null)
is
begin
  ------------------------------
  xis_nulls_ct_varchar(cast_cit2ct_varchar(p_vals, p_smart_cit), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_nulls_cit_nvarchar_s(p_vals cit_nvarchar_s, p_smart_cit boolean, p_label varchar2 := null)
is
begin
  ------------------------------
  xis_nulls_ct_nvarchar_s(cast_cit2ct_nvarchar_s(p_vals, p_smart_cit), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_nulls_cit_nvarchar(p_vals cit_nvarchar, p_smart_cit boolean, p_label varchar2 := null)
is
begin
  ------------------------------
  xis_nulls_ct_nvarchar(cast_cit2ct_nvarchar(p_vals, p_smart_cit), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_unique_ct_number(p_vals ct_number) return boolean
is
begin
  ------------------------------
  return get_count_ct_number(p_vals) = get_count_ct_number(unique_ct_number(p_vals, true));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_unique_ct_date(p_vals ct_date) return boolean
is
begin
  ------------------------------
  return get_count_ct_date(p_vals) = get_count_ct_date(unique_ct_date(p_vals, true));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_unique_ct_varchar_s(p_vals ct_varchar_s) return boolean
is
begin
  ------------------------------
  return get_count_ct_varchar_s(p_vals) = get_count_ct_varchar_s(unique_ct_varchar_s(p_vals, true));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_unique_ct_varchar(p_vals ct_varchar) return boolean
is
begin
  ------------------------------
  return get_count_ct_varchar(p_vals) = get_count_ct_varchar(unique_ct_varchar(p_vals, true));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_unique_ct_nvarchar_s(p_vals ct_nvarchar_s) return boolean
is
begin
  ------------------------------
  return get_count_ct_nvarchar_s(p_vals) = get_count_ct_nvarchar_s(unique_ct_nvarchar_s(p_vals, true));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_unique_ct_nvarchar(p_vals ct_nvarchar) return boolean
is
begin
  ------------------------------
  return get_count_ct_nvarchar(p_vals) = get_count_ct_nvarchar(unique_ct_nvarchar(p_vals, true));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_unique_cit_number(p_vals cit_number) return boolean
is
begin
  ------------------------------
  return is_unique_ct_number(cast_cit2ct_number(p_vals, false));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_unique_cit_date(p_vals cit_date) return boolean
is
begin
  ------------------------------
  return is_unique_ct_date(cast_cit2ct_date(p_vals, false));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_unique_cit_varchar_s(p_vals cit_varchar_s) return boolean
is
begin
  ------------------------------
  return is_unique_ct_varchar_s(cast_cit2ct_varchar_s(p_vals, false));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_unique_cit_varchar(p_vals cit_varchar) return boolean
is
begin
  ------------------------------
  return is_unique_ct_varchar(cast_cit2ct_varchar(p_vals, false));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_unique_cit_nvarchar_s(p_vals cit_nvarchar_s) return boolean
is
begin
  ------------------------------
  return is_unique_ct_nvarchar_s(cast_cit2ct_nvarchar_s(p_vals, false));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_unique_cit_nvarchar(p_vals cit_nvarchar) return boolean
is
begin
  ------------------------------
  return is_unique_ct_nvarchar(cast_cit2ct_nvarchar(p_vals, false));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xis_unique_ct_number(p_vals ct_number, p_label varchar2 := null)
is
begin
  ------------------------------
  if NOT is_unique_ct_number(p_vals)
  then
    ------------------------------
    raise_exception(c_ora_object_not_unique, c_msg_object_not_unique || c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_unique_ct_date(p_vals ct_date, p_label varchar2 := null)
is
begin
  ------------------------------
  if NOT is_unique_ct_date(p_vals)
  then
    ------------------------------
    raise_exception(c_ora_object_not_unique, c_msg_object_not_unique || c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_unique_ct_varchar_s(p_vals ct_varchar_s, p_label varchar2 := null)
is
begin
  ------------------------------
  if NOT is_unique_ct_varchar_s(p_vals)
  then
    ------------------------------
    raise_exception(c_ora_object_not_unique, c_msg_object_not_unique || c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_unique_ct_varchar(p_vals ct_varchar, p_label varchar2 := null)
is
begin
  ------------------------------
  if NOT is_unique_ct_varchar(p_vals)
  then
    ------------------------------
    raise_exception(c_ora_object_not_unique, c_msg_object_not_unique || c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_unique_ct_nvarchar_s(p_vals ct_nvarchar_s, p_label varchar2 := null)
is
begin
  ------------------------------
  if NOT is_unique_ct_nvarchar_s(p_vals)
  then
    ------------------------------
    raise_exception(c_ora_object_not_unique, c_msg_object_not_unique || c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_unique_ct_nvarchar(p_vals ct_nvarchar, p_label varchar2 := null)
is
begin
  ------------------------------
  if NOT is_unique_ct_nvarchar(p_vals)
  then
    ------------------------------
    raise_exception(c_ora_object_not_unique, c_msg_object_not_unique || c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_unique_cit_number(p_vals cit_number, p_label varchar2 := null)
is
begin
  ------------------------------
  xis_unique_ct_number(cast_cit2ct_number(p_vals, false), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_unique_cit_date(p_vals cit_date, p_label varchar2 := null)
is
begin
  ------------------------------
  xis_unique_ct_date(cast_cit2ct_date(p_vals, false), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_unique_cit_varchar_s(p_vals cit_varchar_s, p_label varchar2 := null)
is
begin
  ------------------------------
  xis_unique_ct_varchar_s(cast_cit2ct_varchar_s(p_vals, false), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_unique_cit_varchar(p_vals cit_varchar, p_label varchar2 := null)
is
begin
  ------------------------------
  xis_unique_ct_varchar(cast_cit2ct_varchar(p_vals, false), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_unique_cit_nvarchar_s(p_vals cit_nvarchar_s, p_label varchar2 := null)
is
begin
  ------------------------------
  xis_unique_ct_nvarchar_s(cast_cit2ct_nvarchar_s(p_vals, false), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_unique_cit_nvarchar(p_vals cit_nvarchar, p_label varchar2 := null)
is
begin
  ------------------------------
  xis_unique_ct_nvarchar(cast_cit2ct_nvarchar(p_vals, false), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function index_of_ct_number(p_coll ct_number, p_val number, p_occurence number := 1, p_equality number := c_true) return number
is
  v_res number := c_index_not_found;
  v_equality boolean := int_to_bool_2val(p_equality);
  v_occurence number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_occurence is null, 'p_occurence');
  XCheck_Cond_Invalid(p_occurence <= 0, 'p_occurence <= 0');
  XCheck_Cond_Invalid(floor(p_occurence) != p_occurence, 'floor(p_occurence) != p_occurence');
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_occurence := p_occurence;
  ------------------------------
  for v_i in p_coll.first..p_coll.last loop
    ------------------------------
    if v_equality = is_eq_null_vals_number(p_coll(v_i), p_val)
    then
      ------------------------------
      v_occurence := v_occurence - 1;
      ------------------------------
      if v_occurence <= 0
      then
        ------------------------------
        v_res := v_i;
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function index_of_ct_date(p_coll ct_date, p_val date, p_occurence number := 1, p_equality number := c_true) return number
is
  v_res number := c_index_not_found;
  v_equality boolean := int_to_bool_2val(p_equality);
  v_occurence number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_occurence is null, 'p_occurence');
  XCheck_Cond_Invalid(p_occurence <= 0, 'p_occurence <= 0');
  XCheck_Cond_Invalid(floor(p_occurence) != p_occurence, 'floor(p_occurence) != p_occurence');
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_occurence := p_occurence;
  ------------------------------
  for v_i in p_coll.first..p_coll.last loop
    ------------------------------
    if v_equality = is_eq_null_vals_date(p_coll(v_i), p_val)
    then
      ------------------------------
      v_occurence := v_occurence - 1;
      ------------------------------
      if v_occurence <= 0
      then
        ------------------------------
        v_res := v_i;
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function index_of_ct_varchar_s(p_coll ct_varchar_s, p_val varchar2, p_occurence number := 1, p_equality number := c_true) return number
is
  v_res number := c_index_not_found;
  v_equality boolean := int_to_bool_2val(p_equality);
  v_occurence number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_occurence is null, 'p_occurence');
  XCheck_Cond_Invalid(p_occurence <= 0, 'p_occurence <= 0');
  XCheck_Cond_Invalid(floor(p_occurence) != p_occurence, 'floor(p_occurence) != p_occurence');
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_occurence := p_occurence;
  ------------------------------
  for v_i in p_coll.first..p_coll.last loop
    ------------------------------
    if v_equality = is_eq_null_vals_varchar(p_coll(v_i), p_val)
    then
      ------------------------------
      v_occurence := v_occurence - 1;
      ------------------------------
      if v_occurence <= 0
      then
        ------------------------------
        v_res := v_i;
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function index_of_ct_varchar(p_coll ct_varchar, p_val varchar2, p_occurence number := 1, p_equality number := c_true) return number
is
  v_res number := c_index_not_found;
  v_equality boolean := int_to_bool_2val(p_equality);
  v_occurence number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_occurence is null, 'p_occurence');
  XCheck_Cond_Invalid(p_occurence <= 0, 'p_occurence <= 0');
  XCheck_Cond_Invalid(floor(p_occurence) != p_occurence, 'floor(p_occurence) != p_occurence');
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_occurence := p_occurence;
  ------------------------------
  for v_i in p_coll.first..p_coll.last loop
    ------------------------------
    if v_equality = is_eq_null_vals_varchar(p_coll(v_i), p_val)
    then
      ------------------------------
      v_occurence := v_occurence - 1;
      ------------------------------
      if v_occurence <= 0
      then
        ------------------------------
        v_res := v_i;
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function index_of_ct_nvarchar_s(p_coll ct_nvarchar_s, p_val nvarchar2, p_occurence number := 1, p_equality number := c_true) return number
is
  v_res number := c_index_not_found;
  v_equality boolean := int_to_bool_2val(p_equality);
  v_occurence number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_occurence is null, 'p_occurence');
  XCheck_Cond_Invalid(p_occurence <= 0, 'p_occurence <= 0');
  XCheck_Cond_Invalid(floor(p_occurence) != p_occurence, 'floor(p_occurence) != p_occurence');
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_occurence := p_occurence;
  ------------------------------
  for v_i in p_coll.first..p_coll.last loop
    ------------------------------
    if v_equality = is_eq_null_vals_nvarchar(p_coll(v_i), p_val)
    then
      ------------------------------
      v_occurence := v_occurence - 1;
      ------------------------------
      if v_occurence <= 0
      then
        ------------------------------
        v_res := v_i;
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function index_of_ct_nvarchar(p_coll ct_nvarchar, p_val nvarchar2, p_occurence number := 1, p_equality number := c_true) return number
is
  v_res number := c_index_not_found;
  v_equality boolean := int_to_bool_2val(p_equality);
  v_occurence number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_occurence is null, 'p_occurence');
  XCheck_Cond_Invalid(p_occurence <= 0, 'p_occurence <= 0');
  XCheck_Cond_Invalid(floor(p_occurence) != p_occurence, 'floor(p_occurence) != p_occurence');
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_occurence := p_occurence;
  ------------------------------
  for v_i in p_coll.first..p_coll.last loop
    ------------------------------
    if v_equality = is_eq_null_vals_nvarchar(p_coll(v_i), p_val)
    then
      ------------------------------
      v_occurence := v_occurence - 1;
      ------------------------------
      if v_occurence <= 0
      then
        ------------------------------
        v_res := v_i;
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function index_of_cit_number(p_coll cit_number, p_val number, p_occurence number := 1, p_equality number := c_true) return number
is
  v_res number := c_index_not_found;
  v_equality boolean := int_to_bool_2val(p_equality);
  v_occurence number;
  v_i number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_occurence is null, 'p_occurence');
  XCheck_Cond_Invalid(p_occurence <= 0, 'p_occurence <= 0');
  XCheck_Cond_Invalid(floor(p_occurence) != p_occurence, 'floor(p_occurence) != p_occurence');
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_occurence := p_occurence;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    if v_equality = is_eq_null_vals_number(p_coll(v_i), p_val)
    then
      ------------------------------
      v_occurence := v_occurence - 1;
      ------------------------------
      if v_occurence <= 0
      then
        ------------------------------
        v_res := v_i;
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function index_of_cit_date(p_coll cit_date, p_val date, p_occurence number := 1, p_equality number := c_true) return number
is
  v_res number := c_index_not_found;
  v_equality boolean := int_to_bool_2val(p_equality);
  v_occurence number;
  v_i number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_occurence is null, 'p_occurence');
  XCheck_Cond_Invalid(p_occurence <= 0, 'p_occurence <= 0');
  XCheck_Cond_Invalid(floor(p_occurence) != p_occurence, 'floor(p_occurence) != p_occurence');
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_occurence := p_occurence;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    if v_equality = is_eq_null_vals_date(p_coll(v_i), p_val)
    then
      ------------------------------
      v_occurence := v_occurence - 1;
      ------------------------------
      if v_occurence <= 0
      then
        ------------------------------
        v_res := v_i;
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function index_of_cit_varchar_s(p_coll cit_varchar_s, p_val varchar2, p_occurence number := 1, p_equality number := c_true) return number
is
  v_res number := c_index_not_found;
  v_equality boolean := int_to_bool_2val(p_equality);
  v_occurence number;
  v_i number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_occurence is null, 'p_occurence');
  XCheck_Cond_Invalid(p_occurence <= 0, 'p_occurence <= 0');
  XCheck_Cond_Invalid(floor(p_occurence) != p_occurence, 'floor(p_occurence) != p_occurence');
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_occurence := p_occurence;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    if v_equality = is_eq_null_vals_varchar(p_coll(v_i), p_val)
    then
      ------------------------------
      v_occurence := v_occurence - 1;
      ------------------------------
      if v_occurence <= 0
      then
        ------------------------------
        v_res := v_i;
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function index_of_cit_varchar(p_coll cit_varchar, p_val varchar2, p_occurence number := 1, p_equality number := c_true) return number
is
  v_res number := c_index_not_found;
  v_equality boolean := int_to_bool_2val(p_equality);
  v_occurence number;
  v_i number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_occurence is null, 'p_occurence');
  XCheck_Cond_Invalid(p_occurence <= 0, 'p_occurence <= 0');
  XCheck_Cond_Invalid(floor(p_occurence) != p_occurence, 'floor(p_occurence) != p_occurence');
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_occurence := p_occurence;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    if v_equality = is_eq_null_vals_varchar(p_coll(v_i), p_val)
    then
      ------------------------------
      v_occurence := v_occurence - 1;
      ------------------------------
      if v_occurence <= 0
      then
        ------------------------------
        v_res := v_i;
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function index_of_cit_nvarchar_s(p_coll cit_nvarchar_s, p_val nvarchar2, p_occurence number := 1, p_equality number := c_true) return number
is
  v_res number := c_index_not_found;
  v_equality boolean := int_to_bool_2val(p_equality);
  v_occurence number;
  v_i number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_occurence is null, 'p_occurence');
  XCheck_Cond_Invalid(p_occurence <= 0, 'p_occurence <= 0');
  XCheck_Cond_Invalid(floor(p_occurence) != p_occurence, 'floor(p_occurence) != p_occurence');
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_occurence := p_occurence;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    if v_equality = is_eq_null_vals_nvarchar(p_coll(v_i), p_val)
    then
      ------------------------------
      v_occurence := v_occurence - 1;
      ------------------------------
      if v_occurence <= 0
      then
        ------------------------------
        v_res := v_i;
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function index_of_cit_nvarchar(p_coll cit_nvarchar, p_val nvarchar2, p_occurence number := 1, p_equality number := c_true) return number
is
  v_res number := c_index_not_found;
  v_equality boolean := int_to_bool_2val(p_equality);
  v_occurence number;
  v_i number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_occurence is null, 'p_occurence');
  XCheck_Cond_Invalid(p_occurence <= 0, 'p_occurence <= 0');
  XCheck_Cond_Invalid(floor(p_occurence) != p_occurence, 'floor(p_occurence) != p_occurence');
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_occurence := p_occurence;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    if v_equality = is_eq_null_vals_nvarchar(p_coll(v_i), p_val)
    then
      ------------------------------
      v_occurence := v_occurence - 1;
      ------------------------------
      if v_occurence <= 0
      then
        ------------------------------
        v_res := v_i;
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_!SYS_OP_MAP_NONNULL(p_val1) = SYS_OP_MAP_NONNULL(p_val2);
----------------------------------!---------------------------------------------
function is_eq_null_vals_number(p_val1 number, p_val2 number) return boolean
is
begin
  ------------------------------
  if (p_val1 = p_val2 or (p_val1 is null and p_val2 is null))
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_eq_null_vals_date(p_val1 date, p_val2 date) return boolean
is
begin
  ------------------------------
  if (p_val1 = p_val2 or (p_val1 is null and p_val2 is null))
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_eq_null_vals_varchar(p_val1 varchar2, p_val2 varchar2) return boolean
is
begin
  ------------------------------
  if (p_val1 = p_val2 or (p_val1 is null and p_val2 is null))
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_eq_null_vals_nvarchar(p_val1 nvarchar2, p_val2 nvarchar2) return boolean
is
begin
  ------------------------------
  if (p_val1 = p_val2 or (p_val1 is null and p_val2 is null))
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_eq_null_vals_boolean(p_val1 boolean, p_val2 boolean) return boolean
is
begin
  ------------------------------
  if (p_val1 = p_val2 or (p_val1 is null and p_val2 is null))
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function cmp_ct_number(p_vals1 ct_number, p_vals2 ct_number, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  if get_count_ct_number(p_vals1) <> get_count_ct_number(p_vals2)
  then
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter);
  end if;
  ------------------------------
  if get_count_ct_number(p_vals1) = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    case when q1.val is null and q2.val is null then p_eql_value when q1.val = q2.val then p_eql_value else p_noteql_value end val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals1)) q1,
      (select column_value val, rownum rn from table(p_vals2)) q2
    where 1 = 1
    and q1.rn = q2.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cmp_ct_date(p_vals1 ct_date, p_vals2 ct_date, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  if get_count_ct_date(p_vals1) <> get_count_ct_date(p_vals2)
  then
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter);
  end if;
  ------------------------------
  if get_count_ct_date(p_vals1) = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    case when q1.val is null and q2.val is null then p_eql_value when q1.val = q2.val then p_eql_value else p_noteql_value end val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals1)) q1,
      (select column_value val, rownum rn from table(p_vals2)) q2
    where 1 = 1
    and q1.rn = q2.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cmp_ct_varchar_s(p_vals1 ct_varchar_s, p_vals2 ct_varchar_s, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  if get_count_ct_varchar_s(p_vals1) <> get_count_ct_varchar_s(p_vals2)
  then
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter);
  end if;
  ------------------------------
  if get_count_ct_varchar_s(p_vals1) = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    case when q1.val is null and q2.val is null then p_eql_value when q1.val = q2.val then p_eql_value else p_noteql_value end val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals1)) q1,
      (select column_value val, rownum rn from table(p_vals2)) q2
    where 1 = 1
    and q1.rn = q2.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cmp_ct_varchar(p_vals1 ct_varchar, p_vals2 ct_varchar, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  if get_count_ct_varchar(p_vals1) <> get_count_ct_varchar(p_vals2)
  then
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter);
  end if;
  ------------------------------
  if get_count_ct_varchar(p_vals1) = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    case when q1.val is null and q2.val is null then p_eql_value when q1.val = q2.val then p_eql_value else p_noteql_value end val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals1)) q1,
      (select column_value val, rownum rn from table(p_vals2)) q2
    where 1 = 1
    and q1.rn = q2.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cmp_ct_nvarchar_s(p_vals1 ct_nvarchar_s, p_vals2 ct_nvarchar_s, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  if get_count_ct_nvarchar_s(p_vals1) <> get_count_ct_nvarchar_s(p_vals2)
  then
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter);
  end if;
  ------------------------------
  if get_count_ct_nvarchar_s(p_vals1) = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    case when q1.val is null and q2.val is null then p_eql_value when q1.val = q2.val then p_eql_value else p_noteql_value end val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals1)) q1,
      (select column_value val, rownum rn from table(p_vals2)) q2
    where 1 = 1
    and q1.rn = q2.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cmp_ct_nvarchar(p_vals1 ct_nvarchar, p_vals2 ct_nvarchar, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  if get_count_ct_nvarchar(p_vals1) <> get_count_ct_nvarchar(p_vals2)
  then
    raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter);
  end if;
  ------------------------------
  if get_count_ct_nvarchar(p_vals1) = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    case when q1.val is null and q2.val is null then p_eql_value when q1.val = q2.val then p_eql_value else p_noteql_value end val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals1)) q1,
      (select column_value val, rownum rn from table(p_vals2)) q2
    where 1 = 1
    and q1.rn = q2.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cmp_cit_number(p_vals1 cit_number, p_vals2 cit_number, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number
is
  v_vals1 ct_number;
  v_vals2 ct_number;
begin
  ------------------------------
  v_vals1 := cast_cit2ct_number(p_vals1, false);
  v_vals2 := cast_cit2ct_number(p_vals2, false);
  ------------------------------
  return cmp_ct_number(v_vals1, v_vals2, p_eql_value, p_noteql_value);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cmp_cit_date(p_vals1 cit_date, p_vals2 cit_date, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number
is
  v_vals1 ct_date;
  v_vals2 ct_date;
begin
  ------------------------------
  v_vals1 := cast_cit2ct_date(p_vals1, false);
  v_vals2 := cast_cit2ct_date(p_vals2, false);
  ------------------------------
  return cmp_ct_date(v_vals1, v_vals2, p_eql_value, p_noteql_value);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cmp_cit_varchar_s(p_vals1 cit_varchar_s, p_vals2 cit_varchar_s, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number
is
  v_vals1 ct_varchar_s;
  v_vals2 ct_varchar_s;
begin
  ------------------------------
  v_vals1 := cast_cit2ct_varchar_s(p_vals1, false);
  v_vals2 := cast_cit2ct_varchar_s(p_vals2, false);
  ------------------------------
  return cmp_ct_varchar_s(v_vals1, v_vals2, p_eql_value, p_noteql_value);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cmp_cit_varchar(p_vals1 cit_varchar, p_vals2 cit_varchar, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number
is
  v_vals1 ct_varchar;
  v_vals2 ct_varchar;
begin
  ------------------------------
  v_vals1 := cast_cit2ct_varchar(p_vals1, false);
  v_vals2 := cast_cit2ct_varchar(p_vals2, false);
  ------------------------------
  return cmp_ct_varchar(v_vals1, v_vals2, p_eql_value, p_noteql_value);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cmp_cit_nvarchar_s(p_vals1 cit_nvarchar_s, p_vals2 cit_nvarchar_s, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number
is
  v_vals1 ct_nvarchar_s;
  v_vals2 ct_nvarchar_s;
begin
  ------------------------------
  v_vals1 := cast_cit2ct_nvarchar_s(p_vals1, false);
  v_vals2 := cast_cit2ct_nvarchar_s(p_vals2, false);
  ------------------------------
  return cmp_ct_nvarchar_s(v_vals1, v_vals2, p_eql_value, p_noteql_value);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cmp_cit_nvarchar(p_vals1 cit_nvarchar, p_vals2 cit_nvarchar, p_eql_value number := c_true, p_noteql_value number := c_false) return ct_number
is
  v_vals1 ct_nvarchar;
  v_vals2 ct_nvarchar;
begin
  ------------------------------
  v_vals1 := cast_cit2ct_nvarchar(p_vals1, false);
  v_vals2 := cast_cit2ct_nvarchar(p_vals2, false);
  ------------------------------
  return cmp_ct_nvarchar(v_vals1, v_vals2, p_eql_value, p_noteql_value);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ct_number(p_coll ct_number) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_ct_date(p_coll ct_date) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_ct_varchar_s(p_coll ct_varchar_s) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_ct_varchar(p_coll ct_varchar) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_ct_nvarchar_s(p_coll ct_nvarchar_s) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_ct_nvarchar(p_coll ct_nvarchar) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_cit_number(p_coll cit_number) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_cit_date(p_coll cit_date) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_cit_varchar_s(p_coll cit_varchar_s) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_cit_varchar(p_coll cit_varchar) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_cit_nvarchar_s(p_coll cit_nvarchar_s) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_cit_nvarchar(p_coll cit_nvarchar) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure dbg_ct_number(p_coll ct_number, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(c_msg_v_i || v_i || c_msg_delim02 || number_to_char(p_coll(v_i)));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_ct_date(p_coll ct_date, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(c_msg_v_i || v_i || c_msg_delim02 || date_to_char(p_coll(v_i)));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_ct_varchar_s(p_coll ct_varchar_s, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(c_msg_v_i || v_i || c_msg_delim02 || p_coll(v_i));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_ct_varchar(p_coll ct_varchar, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(c_msg_v_i || v_i || c_msg_delim02 || p_coll(v_i));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_ct_nvarchar_s(p_coll ct_nvarchar_s, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(c_msg_v_i || v_i || c_msg_delim02 || nchar_to_char(p_coll(v_i)));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_ct_nvarchar(p_coll ct_nvarchar, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(c_msg_v_i || v_i || c_msg_delim02 || nchar_to_char(p_coll(v_i)));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_cit_number(p_coll cit_number, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(c_msg_v_i || v_i || c_msg_delim02 || number_to_char(p_coll(v_i)));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_cit_date(p_coll cit_date, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(c_msg_v_i || v_i || c_msg_delim02 || date_to_char(p_coll(v_i)));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_cit_varchar_s(p_coll cit_varchar_s, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(c_msg_v_i || v_i || c_msg_delim02 || p_coll(v_i));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_cit_varchar(p_coll cit_varchar, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(c_msg_v_i || v_i || c_msg_delim02 || p_coll(v_i));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_cit_nvarchar_s(p_coll cit_nvarchar_s, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(c_msg_v_i || v_i || c_msg_delim02 || nchar_to_char(p_coll(v_i)));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_cit_nvarchar(p_coll cit_nvarchar, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(c_msg_v_i || v_i || c_msg_delim02 || nchar_to_char(p_coll(v_i)));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function smart_label0(p_label varchar2) return varchar2
is
begin
  ------------------------------
  return (case when p_label is not null then p_label || c_msg_delim02 else null end);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function smart_label1(p_label varchar2, p_label_def varchar2) return varchar2
is
begin
  ------------------------------
  return nvl(p_label, p_label_def);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function smart_label2(p_label varchar2, p_label_def varchar2, p_label_main varchar2) return varchar2
is
begin
  ------------------------------
  return (case when p_label is not null then p_label else p_label_def end || p_label_main);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Miss_Param(p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_exception(c_ora_missing_parameter, c_msg_missing_parameter || c_msg_delim01 || p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Invalid_Param(p_label varchar2 := null, p_val varchar2 := null)
is
begin
  ------------------------------
  Raise_exception(c_ora_invalid_parameter, c_msg_invalid_parameter || c_msg_delim01 || p_label || c_msg_delim02 || p_val);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotFound(p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_exception(c_ora_object_not_found, c_msg_object_not_found || c_msg_delim01 || p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotUniq(p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_exception(c_ora_object_not_unique, c_msg_object_not_unique || c_msg_delim01 || p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotFound_ID(p_id_str varchar2, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotFound(smart_label0(p_label) || p_id_str);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotFound_ID2(p_id_num number, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotFound_ID(number_to_char(p_id_num), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotUniq_ID(p_id_str varchar2, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotUniq(smart_label0(p_label) || p_id_str);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotUniq_ID2(p_id_num number, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotUniq_ID(number_to_char(p_id_num), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotFound_ID(p_id1_str varchar2, p_id2_str varchar2, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotFound(smart_label0(p_label) || p_id1_str || c_msg_delim02 || p_id2_str);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotFound_ID2(p_id1_num number, p_id2_num number, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj2_NotFound_ID(number_to_char(p_id1_num), number_to_char(p_id2_num), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotFound_ID3(p_id1_num number, p_id2_str varchar2, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj2_NotFound_ID(number_to_char(p_id1_num), p_id2_str, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotUniq_ID(p_id1_str varchar2, p_id2_str varchar2, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotUniq(smart_label0(p_label) || p_id1_str || c_msg_delim02 || p_id2_str);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotUniq_ID2(p_id1_num number, p_id2_num number, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj2_NotUniq_ID(number_to_char(p_id1_num), number_to_char(p_id2_num), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotUniq_ID3(p_id1_num number, p_id2_str varchar2, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj2_NotUniq_ID(number_to_char(p_id1_num), p_id2_str, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj3_NotFound_ID(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotFound(smart_label0(p_label) || p_id1_str || c_msg_delim02 || p_id2_str || c_msg_delim02 || p_id3_str);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj3_NotFound_ID2(p_id1_num number, p_id2_num number, p_id3_num number, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj3_NotFound_ID(number_to_char(p_id1_num), number_to_char(p_id2_num), number_to_char(p_id3_num), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj3_NotUniq_ID(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotUniq(smart_label0(p_label) || p_id1_str || c_msg_delim02 || p_id2_str || c_msg_delim02 || p_id3_str);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj3_NotUniq_ID2(p_id1_num number, p_id2_num number, p_id3_num number, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj3_NotUniq_ID(number_to_char(p_id1_num), number_to_char(p_id2_num), number_to_char(p_id3_num), p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotFound_OnDate(p_id_str varchar2, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotFound(smart_label0(p_label) || get_err_msg_ondate(p_id_str, p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotFound_OnDate2(p_id_num number, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotFound_OnDate(number_to_char(p_id_num), p_date, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotFound_Vers(p_id_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotFound(smart_label0(p_label) || get_err_msg_vers(p_id_str, p_date_from, p_date_to));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotFound_Vers2(p_id_num number, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotFound_Vers(number_to_char(p_id_num), p_date_from, p_date_to, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotUniq_OnDate(p_id_str varchar2, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotUniq(smart_label0(p_label) || get_err_msg_ondate(p_id_str, p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotUniq_OnDate2(p_id_num number, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotUniq_OnDate(number_to_char(p_id_num), p_date, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotUniq_Vers(p_id_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotUniq(smart_label0(p_label) || get_err_msg_vers(p_id_str, p_date_from, p_date_to));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj_NotUniq_Vers2(p_id_num number, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotUniq_Vers(number_to_char(p_id_num), p_date_from, p_date_to, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotFound_OnDate(p_id1_str varchar2, p_id2_str varchar2, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotFound(smart_label0(p_label) || get_err_msg_ondate2(p_id1_str, p_id2_str, p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotFound_OnDate2(p_id1_num number, p_id2_num number, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj2_NotFound_OnDate(number_to_char(p_id1_num), number_to_char(p_id2_num), p_date, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotFound_OnDate3(p_id1_num number, p_id2_str varchar2, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj2_NotFound_OnDate(number_to_char(p_id1_num), p_id2_str, p_date, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotFound_Vers(p_id1_str varchar2, p_id2_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotFound(smart_label0(p_label) || get_err_msg_vers2(p_id1_str, p_id2_str, p_date_from, p_date_to));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotFound_Vers2(p_id1_num number, p_id2_num number, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj2_NotFound_Vers(number_to_char(p_id1_num), number_to_char(p_id2_num), p_date_from, p_date_to, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotFound_Vers3(p_id1_num number, p_id2_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj2_NotFound_Vers(number_to_char(p_id1_num), p_id2_str, p_date_from, p_date_to, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotUniq_OnDate(p_id1_str varchar2, p_id2_str varchar2, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotUniq(smart_label0(p_label) || get_err_msg_ondate2(p_id1_str, p_id2_str, p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotUniq_OnDate2(p_id1_num number, p_id2_num number, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj2_NotUniq_OnDate(number_to_char(p_id1_num), number_to_char(p_id2_num), p_date, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotUniq_OnDate3(p_id1_num number, p_id2_str varchar2, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj2_NotUniq_OnDate(number_to_char(p_id1_num), p_id2_str, p_date, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotUniq_Vers(p_id1_str varchar2, p_id2_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotUniq(smart_label0(p_label) || get_err_msg_vers2(p_id1_str, p_id2_str, p_date_from, p_date_to));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotUniq_Vers2(p_id1_num number, p_id2_num number, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj2_NotUniq_Vers(number_to_char(p_id1_num), number_to_char(p_id2_num), p_date_from, p_date_to, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj2_NotUniq_Vers3(p_id1_num number, p_id2_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj2_NotUniq_Vers(number_to_char(p_id1_num), p_id2_str, p_date_from, p_date_to, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj3_NotFound_OnDate(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotFound(smart_label0(p_label) || get_err_msg_ondate3(p_id1_str, p_id2_str, p_id3_str, p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj3_NotFound_OnDate2(p_id1_num number, p_id2_num number, p_id3_num number, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj3_NotFound_OnDate(number_to_char(p_id1_num), number_to_char(p_id2_num), number_to_char(p_id3_num), p_date, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj3_NotFound_Vers(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotFound(smart_label0(p_label) || get_err_msg_vers3(p_id1_str, p_id2_str, p_id3_str, p_date_from, p_date_to));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj3_NotFound_Vers2(p_id1_num number, p_id2_num number, p_id3_num number, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj3_NotFound_Vers(number_to_char(p_id1_num), number_to_char(p_id2_num), number_to_char(p_id3_num), p_date_from, p_date_to, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj3_NotUniq_OnDate(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotUniq(smart_label0(p_label) || get_err_msg_ondate3(p_id1_str, p_id2_str, p_id3_str, p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj3_NotUniq_OnDate2(p_id1_num number, p_id2_num number, p_id3_num number, p_date date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj3_NotUniq_OnDate(number_to_char(p_id1_num), number_to_char(p_id2_num), number_to_char(p_id3_num), p_date, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj3_NotUniq_Vers(p_id1_str varchar2, p_id2_str varchar2, p_id3_str varchar2, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj_NotUniq(smart_label0(p_label) || get_err_msg_vers3(p_id1_str, p_id2_str, p_id3_str, p_date_from, p_date_to));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Raise_Obj3_NotUniq_Vers2(p_id1_num number, p_id2_num number, p_id3_num number, p_date_from date, p_date_to date, p_label varchar2 := null)
is
begin
  ------------------------------
  Raise_Obj3_NotUniq_Vers(number_to_char(p_id1_num), number_to_char(p_id2_num), number_to_char(p_id3_num), p_date_from, p_date_to, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheckP_ct_number(p_param ct_number, p_label varchar2 := null) is
begin
  ------------------------------
  if p_param is null or p_param.count = 0
  then
    Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_ct_date(p_param ct_date, p_label varchar2 := null) is
begin
  ------------------------------
  if p_param is null or p_param.count = 0
  then
    Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_ct_varchar_s(p_param ct_varchar_s, p_label varchar2 := null) is
begin
  ------------------------------
  if p_param is null or p_param.count = 0
  then
    Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_ct_varchar(p_param ct_varchar, p_label varchar2 := null) is
begin
  ------------------------------
  if p_param is null or p_param.count = 0
  then
    Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_ct_nvarchar_s(p_param ct_nvarchar_s, p_label varchar2 := null) is
begin
  ------------------------------
  if p_param is null or p_param.count = 0
  then
    Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_ct_nvarchar(p_param ct_nvarchar, p_label varchar2 := null) is
begin
  ------------------------------
  if p_param is null or p_param.count = 0
  then
    Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_cit_number(p_param cit_number, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  if not CheckP_cit_number(p_param, p_smart_cit)
  then
    Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_cit_date(p_param cit_date, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  if not CheckP_cit_date(p_param, p_smart_cit)
  then
    Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_cit_varchar_s(p_param cit_varchar_s, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  if not CheckP_cit_varchar_s(p_param, p_smart_cit)
  then
    Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_cit_varchar(p_param cit_varchar, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  if not CheckP_cit_varchar(p_param, p_smart_cit)
  then
    Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_cit_nvarchar_s(p_param cit_nvarchar_s, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  if not CheckP_cit_nvarchar_s(p_param, p_smart_cit)
  then
    Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_cit_nvarchar(p_param cit_nvarchar, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  if not CheckP_cit_nvarchar(p_param, p_smart_cit)
  then
    Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function CheckP_ct_number(p_param ct_number) return boolean
is
begin
  ------------------------------
  if p_param is null or p_param.count = 0
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_ct_date(p_param ct_date) return boolean
is
begin
  ------------------------------
  if p_param is null or p_param.count = 0
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_ct_varchar_s(p_param ct_varchar_s) return boolean
is
begin
  ------------------------------
  if p_param is null or p_param.count = 0
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_ct_varchar(p_param ct_varchar) return boolean
is
begin
  ------------------------------
  if p_param is null or p_param.count = 0
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_ct_nvarchar_s(p_param ct_nvarchar_s) return boolean
is
begin
  ------------------------------
  if p_param is null or p_param.count = 0
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_ct_nvarchar(p_param ct_nvarchar) return boolean
is
begin
  ------------------------------
  if p_param is null or p_param.count = 0
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_cit_number(p_param cit_number, p_smart_cit boolean := true) return boolean
is
  v_smart_cit boolean := bool_to_bool_2val(p_smart_cit);
begin
  ------------------------------
  if p_param is null or p_param.count = 0 or (v_smart_cit and p_param.count = 1 and p_param(p_param.first) is null)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_cit_date(p_param cit_date, p_smart_cit boolean := true) return boolean
is
  v_smart_cit boolean := bool_to_bool_2val(p_smart_cit);
begin
  ------------------------------
  if p_param is null or p_param.count = 0 or (v_smart_cit and p_param.count = 1 and p_param(p_param.first) is null)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_cit_varchar_s(p_param cit_varchar_s, p_smart_cit boolean := true) return boolean
is
  v_smart_cit boolean := bool_to_bool_2val(p_smart_cit);
begin
  ------------------------------
  if p_param is null or p_param.count = 0 or (v_smart_cit and p_param.count = 1 and p_param(p_param.first) is null)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_cit_varchar(p_param cit_varchar, p_smart_cit boolean := true) return boolean
is
  v_smart_cit boolean := bool_to_bool_2val(p_smart_cit);
begin
  ------------------------------
  if p_param is null or p_param.count = 0 or (v_smart_cit and p_param.count = 1 and p_param(p_param.first) is null)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_cit_nvarchar_s(p_param cit_nvarchar_s, p_smart_cit boolean := true) return boolean
is
  v_smart_cit boolean := bool_to_bool_2val(p_smart_cit);
begin
  ------------------------------
  if p_param is null or p_param.count = 0 or (v_smart_cit and p_param.count = 1 and p_param(p_param.first) is null)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_cit_nvarchar(p_param cit_nvarchar, p_smart_cit boolean := true) return boolean
is
  v_smart_cit boolean := bool_to_bool_2val(p_smart_cit);
begin
  ------------------------------
  if p_param is null or p_param.count = 0 or (v_smart_cit and p_param.count = 1 and p_param(p_param.first) is null)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_Cond_Missing(p_raise_condition boolean, p_label varchar2 := null)
is
begin
  ------------------------------
  if p_raise_condition
  then
    Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_Cond_Invalid(p_raise_condition boolean, p_label varchar2 := null)
is
begin
  ------------------------------
  if p_raise_condition
  then
    Raise_Invalid_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_Num_As_Bool_Invalid(p_value number, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheck_Cond_Invalid(p_value not in (c_false, c_true), smart_label2(p_label, 'p_value', ' not in (0, 1)'));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_index(p_index integer, p_count integer, p_label varchar2, p_base integer := 1)
is
begin
  ------------------------------
  XCheck_index2(p_index, p_label, p_base);
  XCheck_size(p_count, 'p_count');
  ------------------------------
  XCheck_Cond_Invalid(p_index not between p_base and p_base - 1 + p_count, p_label || ' not between ' || number_to_char(p_base) || ' and ' || number_to_char(p_base - 1 + p_count));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_index2(p_index integer, p_label varchar2, p_base integer := 1)
is
begin
  ------------------------------
  XCheck_Cond_Missing(p_label is null, 'p_label');
  XCheck_Cond_Missing(p_index is null, p_index);
  XCheck_Cond_Missing(p_base is null, p_base);
  ------------------------------
  --!_!XCheck_Cond_Invalid(p_base <= 0, ' p_base <= 0');
  XCheck_Cond_Invalid(p_index <= p_base - 1, p_label || ' <= ' || number_to_char(p_base - 1));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_size(p_size number, p_label varchar2)
is
begin
  ------------------------------
  XCheck_Cond_Missing(p_label is null, 'p_label');
  XCheck_Cond_Missing(p_size is null, p_label);
  ------------------------------
  XCheck_Cond_Invalid(p_size <= 0, p_label || ' <= 0');
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_size0(p_size number, p_label varchar2)
is
begin
  ------------------------------
  XCheck_Cond_Missing(p_label is null, 'p_label');
  XCheck_Cond_Missing(p_size is null, p_label);
  ------------------------------
  XCheck_Cond_Invalid(p_size < 0, p_label || ' < 0');
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_!FS = Filled Solid
----------------------------------!---------------------------------------------
procedure XCheckP_FS_ct_number(p_param ct_number, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_ct_number(p_param, p_label);
  ------------------------------
  xis_nulls_ct_number(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FS_ct_date(p_param ct_date, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_ct_date(p_param, p_label);
  ------------------------------
  xis_nulls_ct_date(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FS_ct_varchar_s(p_param ct_varchar_s, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_ct_varchar_s(p_param, p_label);
  ------------------------------
  xis_nulls_ct_varchar_s(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FS_ct_varchar(p_param ct_varchar, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_ct_varchar(p_param, p_label);
  ------------------------------
  xis_nulls_ct_varchar(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FS_ct_nvarchar_s(p_param ct_nvarchar_s, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_ct_nvarchar_s(p_param, p_label);
  ------------------------------
  xis_nulls_ct_nvarchar_s(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FS_ct_nvarchar(p_param ct_nvarchar, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_ct_nvarchar(p_param, p_label);
  ------------------------------
  xis_nulls_ct_nvarchar(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FS_cit_number(p_param cit_number, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  XCheckP_cit_number(p_param, p_label, p_smart_cit);
  ------------------------------
  xis_nulls_cit_number(p_param, p_smart_cit, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FS_cit_date(p_param cit_date, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  XCheckP_cit_date(p_param, p_label, p_smart_cit);
  ------------------------------
  xis_nulls_cit_date(p_param, p_smart_cit, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FS_cit_varchar_s(p_param cit_varchar_s, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  XCheckP_cit_varchar_s(p_param, p_label, p_smart_cit);
  ------------------------------
  xis_nulls_cit_varchar_s(p_param, p_smart_cit, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FS_cit_varchar(p_param cit_varchar, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  XCheckP_cit_varchar(p_param, p_label, p_smart_cit);
  ------------------------------
  xis_nulls_cit_varchar(p_param, p_smart_cit, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FS_cit_nvarchar_s(p_param cit_nvarchar_s, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  XCheckP_cit_nvarchar_s(p_param, p_label, p_smart_cit);
  ------------------------------
  xis_nulls_cit_nvarchar_s(p_param, p_smart_cit, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FS_cit_nvarchar(p_param cit_nvarchar, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  XCheckP_cit_nvarchar(p_param, p_label, p_smart_cit);
  ------------------------------
  xis_nulls_cit_nvarchar(p_param, p_smart_cit, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function CheckP_FS_ct_number(p_param ct_number) return boolean
is
begin
  ------------------------------
  if not CheckP_ct_number(p_param)
  then
    return false;
  end if;
  ------------------------------
  if is_nulls_ct_number(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FS_ct_date(p_param ct_date) return boolean
is
begin
  ------------------------------
  if not CheckP_ct_date(p_param)
  then
    return false;
  end if;
  ------------------------------
  if is_nulls_ct_date(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FS_ct_varchar_s(p_param ct_varchar_s) return boolean
is
begin
  ------------------------------
  if not CheckP_ct_varchar_s(p_param)
  then
    return false;
  end if;
  ------------------------------
  if is_nulls_ct_varchar_s(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FS_ct_varchar(p_param ct_varchar) return boolean
is
begin
  ------------------------------
  if not CheckP_ct_varchar(p_param)
  then
    return false;
  end if;
  ------------------------------
  if is_nulls_ct_varchar(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FS_ct_nvarchar_s(p_param ct_nvarchar_s) return boolean
is
begin
  ------------------------------
  if not CheckP_ct_nvarchar_s(p_param)
  then
    return false;
  end if;
  ------------------------------
  if is_nulls_ct_nvarchar_s(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FS_ct_nvarchar(p_param ct_nvarchar) return boolean
is
begin
  ------------------------------
  if not CheckP_ct_nvarchar(p_param)
  then
    return false;
  end if;
  ------------------------------
  if is_nulls_ct_nvarchar(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FS_cit_number(p_param cit_number, p_smart_cit boolean := true) return boolean
is
begin
  ------------------------------
  if not CheckP_cit_number(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  if is_nulls_cit_number(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FS_cit_date(p_param cit_date, p_smart_cit boolean := true) return boolean
is
begin
  ------------------------------
  if not CheckP_cit_date(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  if is_nulls_cit_date(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FS_cit_varchar_s(p_param cit_varchar_s, p_smart_cit boolean := true) return boolean
is
begin
  ------------------------------
  if not CheckP_cit_varchar_s(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  if is_nulls_cit_varchar_s(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FS_cit_varchar(p_param cit_varchar, p_smart_cit boolean := true) return boolean
is
begin
  ------------------------------
  if not CheckP_cit_varchar(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  if is_nulls_cit_varchar(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FS_cit_nvarchar_s(p_param cit_nvarchar_s, p_smart_cit boolean := true) return boolean
is
begin
  ------------------------------
  if not CheckP_cit_nvarchar_s(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  if is_nulls_cit_nvarchar_s(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FS_cit_nvarchar(p_param cit_nvarchar, p_smart_cit boolean := true) return boolean
is
begin
  ------------------------------
  if not CheckP_cit_nvarchar(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  if is_nulls_cit_nvarchar(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_!FSU = Filled Solid Unique
----------------------------------!---------------------------------------------
procedure XCheckP_FSU_ct_number(p_param ct_number, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_FS_ct_number(p_param, p_label);
  ------------------------------
  xis_unique_ct_number(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FSU_ct_date(p_param ct_date, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_FS_ct_date(p_param, p_label);
  ------------------------------
  xis_unique_ct_date(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FSU_ct_varchar_s(p_param ct_varchar_s, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_FS_ct_varchar_s(p_param, p_label);
  ------------------------------
  xis_unique_ct_varchar_s(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FSU_ct_varchar(p_param ct_varchar, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_FS_ct_varchar(p_param, p_label);
  ------------------------------
  xis_unique_ct_varchar(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FSU_ct_nvarchar_s(p_param ct_nvarchar_s, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_FS_ct_nvarchar_s(p_param, p_label);
  ------------------------------
  xis_unique_ct_nvarchar_s(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FSU_ct_nvarchar(p_param ct_nvarchar, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_FS_ct_nvarchar(p_param, p_label);
  ------------------------------
  xis_unique_ct_nvarchar(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FSU_cit_number(p_param cit_number, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  XCheckP_FS_cit_number(p_param, p_label, p_smart_cit);
  ------------------------------
  xis_unique_cit_number(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FSU_cit_date(p_param cit_date, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  XCheckP_FS_cit_date(p_param, p_label, p_smart_cit);
  ------------------------------
  xis_unique_cit_date(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FSU_cit_varchar_s(p_param cit_varchar_s, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  XCheckP_FS_cit_varchar_s(p_param, p_label, p_smart_cit);
  ------------------------------
  xis_unique_cit_varchar_s(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FSU_cit_varchar(p_param cit_varchar, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  XCheckP_FS_cit_varchar(p_param, p_label, p_smart_cit);
  ------------------------------
  xis_unique_cit_varchar(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FSU_cit_nvarchar_s(p_param cit_nvarchar_s, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  XCheckP_FS_cit_nvarchar_s(p_param, p_label, p_smart_cit);
  ------------------------------
  xis_unique_cit_nvarchar_s(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FSU_cit_nvarchar(p_param cit_nvarchar, p_label varchar2 := null, p_smart_cit boolean := true)
is
begin
  ------------------------------
  XCheckP_FS_cit_nvarchar(p_param, p_label, p_smart_cit);
  ------------------------------
  xis_unique_cit_nvarchar(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function CheckP_FSU_ct_number(p_param ct_number) return boolean
is
begin
  ------------------------------
  if not CheckP_FS_ct_number(p_param)
  then
    return false;
  end if;
  ------------------------------
  if NOT is_unique_ct_number(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FSU_ct_date(p_param ct_date) return boolean
is
begin
  ------------------------------
  if not CheckP_FS_ct_date(p_param)
  then
    return false;
  end if;
  ------------------------------
  if NOT is_unique_ct_date(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FSU_ct_varchar_s(p_param ct_varchar_s) return boolean
is
begin
  ------------------------------
  if not CheckP_FS_ct_varchar_s(p_param)
  then
    return false;
  end if;
  ------------------------------
  if NOT is_unique_ct_varchar_s(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FSU_ct_varchar(p_param ct_varchar) return boolean
is
begin
  ------------------------------
  if not CheckP_FS_ct_varchar(p_param)
  then
    return false;
  end if;
  ------------------------------
  if NOT is_unique_ct_varchar(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FSU_ct_nvarchar_s(p_param ct_nvarchar_s) return boolean
is
begin
  ------------------------------
  if not CheckP_FS_ct_nvarchar_s(p_param)
  then
    return false;
  end if;
  ------------------------------
  if NOT is_unique_ct_nvarchar_s(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FSU_ct_nvarchar(p_param ct_nvarchar) return boolean
is
begin
  ------------------------------
  if not CheckP_FS_ct_nvarchar(p_param)
  then
    return false;
  end if;
  ------------------------------
  if NOT is_unique_ct_nvarchar(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FSU_cit_number(p_param cit_number, p_smart_cit boolean := true) return boolean
is
begin
  ------------------------------
  if not CheckP_FS_cit_number(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  if NOT is_unique_cit_number(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FSU_cit_date(p_param cit_date, p_smart_cit boolean := true) return boolean
is
begin
  ------------------------------
  if not CheckP_FS_cit_date(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  if NOT is_unique_cit_date(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FSU_cit_varchar_s(p_param cit_varchar_s, p_smart_cit boolean := true) return boolean
is
begin
  ------------------------------
  if not CheckP_FS_cit_varchar_s(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  if NOT is_unique_cit_varchar_s(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FSU_cit_varchar(p_param cit_varchar, p_smart_cit boolean := true) return boolean
is
begin
  ------------------------------
  if not CheckP_FS_cit_varchar(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  if NOT is_unique_cit_varchar(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FSU_cit_nvarchar_s(p_param cit_nvarchar_s, p_smart_cit boolean := true) return boolean
is
begin
  ------------------------------
  if not CheckP_FS_cit_nvarchar_s(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  if NOT is_unique_cit_nvarchar_s(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_FSU_cit_nvarchar(p_param cit_nvarchar, p_smart_cit boolean := true) return boolean
is
begin
  ------------------------------
  if not CheckP_FS_cit_nvarchar(p_param, p_smart_cit)
  then
    return false;
  end if;
  ------------------------------
  if NOT is_unique_cit_nvarchar(p_param)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xcheck_version_dates(p_date_from date, p_date_to date)
is
begin
  ------------------------------
  if p_date_from is null or p_date_to is null or p_date_from > p_date_to
  then
    Raise_Invalid_Param(cut_err_msg('Dates' || c_msg_delim01 || date_to_char(p_date_from) || c_msg_delim02 || date_to_char(p_date_to)));
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function check_bit_mask(p_active_bits number, p_mask_bits number) return number
is
begin
  ------------------------------
  if bitand(p_active_bits, p_mask_bits) = p_mask_bits
  then
    return c_true;
  end if;
  ------------------------------
  return c_false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_bit_mask2(p_active_bits number, p_mask_bits number) return boolean
is
begin
  ------------------------------
  return int_to_bool_2val(check_bit_mask(p_active_bits, p_mask_bits));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_page_start(p_page_number number, p_page_size number, p_base number := 1) return number
is
begin
  ------------------------------
  XCheck_Cond_Missing(p_page_number is null, 'p_page_number');
  XCheck_Cond_Missing(p_page_size is null, 'p_page_size');
  XCheck_Cond_Missing(p_base is null, 'p_base');
  ------------------------------
  XCheck_Cond_Invalid(p_page_number < p_base, 'p_page_number < p_base');
  XCheck_Cond_Invalid(p_page_size <= 0, 'p_page_size <= 0');
  ------------------------------
  return (p_page_number - p_base) * p_page_size + p_base;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_page_end(p_page_number number, p_page_size number, p_base number := 1) return number
is
begin
  ------------------------------
  XCheck_Cond_Missing(p_page_number is null, 'p_page_number');
  XCheck_Cond_Missing(p_page_size is null, 'p_page_size');
  XCheck_Cond_Missing(p_base is null, 'p_base');
  ------------------------------
  XCheck_Cond_Invalid(p_page_number < p_base, 'p_page_number < p_base');
  XCheck_Cond_Invalid(p_page_size <= 0, 'p_page_size <= 0');
  ------------------------------
  return (p_page_number - p_base + 1) * p_page_size;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_index_on_page(p_common_index number, p_page_size number, p_base_index number := 1, p_base_index_on_page number := 1) return number
is
begin
  ------------------------------
  XCheck_Cond_Missing(p_common_index is null, 'p_common_index');
  XCheck_Cond_Missing(p_page_size is null, 'p_page_size');
  XCheck_Cond_Missing(p_base_index is null, 'p_base_index');
  XCheck_Cond_Missing(p_base_index_on_page is null, 'p_base_index_on_page');
  ------------------------------
  XCheck_Cond_Invalid(p_common_index < p_base_index, 'p_common_index < p_base_index');
  XCheck_Cond_Invalid(p_page_size <= 0, 'p_page_size <= 0');
  ------------------------------
  return mod(p_common_index - p_base_index, p_page_size) + p_base_index_on_page;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_page_number(p_common_index number, p_page_size number, p_base_index number := 1, p_base_page number := 1) return number
is
begin
  ------------------------------
  XCheck_Cond_Missing(p_common_index is null, 'p_common_index');
  XCheck_Cond_Missing(p_page_size is null, 'p_page_size');
  XCheck_Cond_Missing(p_base_index is null, 'p_base_index');
  XCheck_Cond_Missing(p_base_page is null, 'p_base_page');
  ------------------------------
  XCheck_Cond_Invalid(p_common_index < p_base_index, 'p_common_index < p_base_index');
  XCheck_Cond_Invalid(p_page_size <= 0, 'p_page_size <= 0');
  ------------------------------
  return floor((p_common_index - p_base_index)/p_page_size) + p_base_page;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_page_count(p_total_count number, p_page_size number, p_always_have_first_page boolean) return number
is
  v_add number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_total_count is null, 'p_total_count');
  XCheck_Cond_Missing(p_page_size is null, 'p_page_size');
  XCheck_Cond_Missing(p_always_have_first_page is null, 'p_always_have_first_page');
  ------------------------------
  XCheck_Cond_Invalid(p_total_count < 0, 'p_total_count < 0');
  XCheck_Cond_Invalid(p_page_size <= 0, 'p_page_size <= 0');
  ------------------------------
  v_add := mod(p_total_count, p_page_size);
  ------------------------------
  if 1 = 0
    or (p_always_have_first_page and p_total_count = 0)
    or v_add > 0
  then
    v_add := 1;
  end if;
  ------------------------------
  return floor(p_total_count/p_page_size) + v_add;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_page_count_i(p_total_count number, p_page_size number, p_always_have_first_page number) return number
is
begin
  ------------------------------
  return get_page_count(p_total_count, p_page_size, int_to_bool(p_always_have_first_page));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_page_size(p_total_count number, p_page_count number, p_always_have_nonempty_page boolean) return number
is
begin
  ------------------------------
  return get_page_count(p_total_count => p_total_count, p_page_size => p_page_count, p_always_have_first_page => p_always_have_nonempty_page);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_page_size_i(p_total_count number, p_page_count number, p_always_have_nonempty_page number) return number
is
begin
  ------------------------------
  return get_page_size(p_total_count, p_page_count, int_to_bool(p_always_have_nonempty_page));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_sum_ct_number(p_coll ct_number) return number
is
  v_res number;
begin
  ------------------------------
  select nvl(sum(column_value), 0) into v_res from table(p_coll);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function split_string(p_str varchar2, p_delim varchar2, p_trimed_chars varchar2 := null) return ct_varchar
is
  v_res ct_varchar;
  v_cnt number;
  v_pos number;
  v_tmp_pos number;
  v_len number;
  v_strlen number := nvl(length(p_str), 0);
  v_delimlen number := nvl(length(p_delim), 0);
begin
  ------------------------------
  v_cnt := 0;
  v_pos := 1;
  ------------------------------
  v_res := ct_varchar();
  ------------------------------
  loop
    ------------------------------
    v_tmp_pos := instr(p_str, p_delim, v_pos, 1);
    ------------------------------
    if v_tmp_pos is null or v_tmp_pos = 0
    then
      v_tmp_pos := v_strlen + 1;
    end if;
    ------------------------------
    v_len := v_tmp_pos - v_pos;
    ------------------------------
    v_cnt := v_cnt + 1;
    v_res.extend;
    if p_trimed_chars is not null
    then
      v_res(v_cnt) := ltrim(rtrim(substr(p_str, v_pos, v_len), p_trimed_chars), p_trimed_chars);
    else
      v_res(v_cnt) := substr(p_str, v_pos, v_len);
    end if;
    ------------------------------
    exit when v_tmp_pos > v_strlen;
    ------------------------------
    v_pos := v_tmp_pos + v_delimlen;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function split_nstring(p_str nvarchar2, p_delim nvarchar2, p_trimed_chars nvarchar2 := null) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_cnt number;
  v_pos number;
  v_tmp_pos number;
  v_len number;
  v_strlen number := nvl(length(p_str), 0);
  v_delimlen number := nvl(length(p_delim), 0);
begin
  ------------------------------
  v_cnt := 0;
  v_pos := 1;
  ------------------------------
  v_res := ct_nvarchar();
  ------------------------------
  loop
    ------------------------------
    v_tmp_pos := instr(p_str, p_delim, v_pos, 1);
    ------------------------------
    if v_tmp_pos is null or v_tmp_pos = 0
    then
      v_tmp_pos := v_strlen + 1;
    end if;
    ------------------------------
    v_len := v_tmp_pos - v_pos;
    ------------------------------
    v_cnt := v_cnt + 1;
    v_res.extend;
    if p_trimed_chars is not null
    then
      v_res(v_cnt) := ltrim(rtrim(substr(p_str, v_pos, v_len), p_trimed_chars), p_trimed_chars);
    else
      v_res(v_cnt) := substr(p_str, v_pos, v_len);
    end if;
    ------------------------------
    exit when v_tmp_pos > v_strlen;
    ------------------------------
    v_pos := v_tmp_pos + v_delimlen;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function merge_string(p_coll ct_varchar, p_delim varchar2, p_prefix varchar2 := '', p_postfix varchar2 := '') return varchar2
is
  v_res varchar2(32767);
  v_cnt number := 0;
begin
  ------------------------------
  v_res := '';
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last loop
    ------------------------------
    if v_cnt > 0
    then
      v_res := v_res || p_delim;
    end if;
    ------------------------------
    --if p_coll.exists(v_i) then
    v_res := v_res || p_prefix || p_coll(v_i) || p_postfix;
    --end if;
    ------------------------------
    v_cnt := v_cnt + 1;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function merge_nstring(p_coll ct_nvarchar, p_delim nvarchar2, p_prefix nvarchar2 := '', p_postfix nvarchar2 := '') return nvarchar2
is
  v_res nvarchar2(32767);
  v_cnt number := 0;
begin
  ------------------------------
  v_res := '';
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last loop
    ------------------------------
    if v_cnt > 0
    then
      v_res := v_res || p_delim;
    end if;
    ------------------------------
    --if p_coll.exists(v_i) then
    v_res := v_res || p_prefix || p_coll(v_i) || p_postfix;
    --end if;
    ------------------------------
    v_cnt := v_cnt + 1;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function str_length(p_value varchar2) return integer
is
begin
  ------------------------------
  return nvl(length(p_value), 0);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function nstr_length(p_value nvarchar2) return integer
is
begin
  ------------------------------
  return nvl(length(p_value), 0);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure str_split2(p_value varchar2, p_length1 integer, p_value1 out varchar2, p_value2 out varchar2)
is
begin
  ------------------------------
  XCheck_Cond_Missing(p_length1 is null, 'p_length1');
  ------------------------------
  XCheck_Cond_Invalid(p_length1 < 0, 'p_length1 < 0');
  ------------------------------
  if p_length1 >= str_length(p_value)
  then
    ------------------------------
    p_value1 := p_value;
    ------------------------------
    p_value2 := NULL;
    ------------------------------
  else
    ------------------------------
    p_value1 := substr(p_value, 1, p_length1);
    ------------------------------
    p_value2 := substr(p_value, p_length1 + 1);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure nstr_split2(p_value nvarchar2, p_length1 integer, p_value1 out nvarchar2, p_value2 out nvarchar2)
is
begin
  ------------------------------
  XCheck_Cond_Missing(p_length1 is null, 'p_length1');
  ------------------------------
  XCheck_Cond_Invalid(p_length1 < 0, 'p_length1 < 0');
  ------------------------------
  if p_length1 >= nstr_length(p_value)
  then
    ------------------------------
    p_value1 := p_value;
    ------------------------------
    p_value2 := NULL;
    ------------------------------
  else
    ------------------------------
    p_value1 := substr(p_value, 1, p_length1);
    ------------------------------
    p_value2 := substr(p_value, p_length1 + 1);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_mask_digits_at_begin(p_mask varchar2) return number
is
  v_res number;
begin
  ------------------------------
  --count of pure numeric chars (from start of p_mask)
  ------------------------------
  v_res := nvl(-1 + instr(p_mask, substr(translate(p_mask, 'w0123456789', 'w'), 1, 1)), nvl(length(p_mask), 0));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_mask_digits_at_middle(p_mask varchar2) return number
is
  v_res number;
begin
  ------------------------------
  --count of pure numeric chars (from start of p_mask)
  ------------------------------
  v_res := nvl(length(p_mask), 0) - nvl(length(translate(p_mask, 'w0123456789', 'w')), 0);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_pivot(p_count number, p_start number := 1) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_count is null, 'p_count');
  XCheck_Cond_Missing(p_start is null, 'p_start');
  ------------------------------
  XCheck_Cond_Invalid(p_count <= 0, 'p_count <= 0');
  ------------------------------
  select rownum + p_start - 1 val bulk collect into v_res from dual connect by level <= p_count order by val
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_pivot_or_empty(p_count number, p_start number := 1) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  XCheck_Cond_Missing(p_count is null, 'p_count');
  XCheck_Cond_Missing(p_start is null, 'p_start');
  ------------------------------
  XCheck_Cond_Invalid(p_count < 0, 'p_count < 0');
  ------------------------------
  if p_count > 0
  then
    ------------------------------
    v_res := make_pivot(p_count, p_start);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function split_str_list(p_str_list varchar2, p_delim varchar2, p_null_str_is_empty_list boolean) return ct_varchar_s
is
begin
  ------------------------------
  return cast_ct_varchar2varchar_s(split_str_list2(p_str_list, p_delim, p_null_str_is_empty_list), true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function split_str_list2(p_str_list varchar2, p_delim varchar2, p_null_str_is_empty_list boolean) return ct_varchar
is
begin
  ------------------------------
  XCheck_Cond_Missing(p_null_str_is_empty_list is null, 'p_null_str_is_empty_list');
  ------------------------------
  if 1 = 1
    and p_null_str_is_empty_list
    and p_str_list is null
  then
    ------------------------------
    return NULL;
    ------------------------------
  end if;
  ------------------------------
  return split_string(p_str_list, p_delim, c_def_trimed_chars);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function split_nstr_list(p_str_list nvarchar2, p_delim nvarchar2, p_null_str_is_empty_list boolean) return ct_nvarchar_s
is
begin
  ------------------------------
  return cast_ct_nvarchar2nvarchar_s(split_nstr_list2(p_str_list, p_delim, p_null_str_is_empty_list), true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function split_nstr_list2(p_str_list nvarchar2, p_delim nvarchar2, p_null_str_is_empty_list boolean) return ct_nvarchar
is
begin
  ------------------------------
  XCheck_Cond_Missing(p_null_str_is_empty_list is null, 'p_null_str_is_empty_list');
  ------------------------------
  if 1 = 1
    and p_null_str_is_empty_list
    and p_str_list is null
  then
    ------------------------------
    return NULL;
    ------------------------------
  end if;
  ------------------------------
  return split_nstring(p_str_list, p_delim, c_def_trimed_nchars);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function merge_str_list(p_coll ct_varchar_s, p_delim varchar2) return varchar2
is
begin
  ------------------------------
  return merge_str_list2(cast_ct_varchar_s2varchar(p_coll), p_delim);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function merge_str_list2(p_coll ct_varchar, p_delim varchar2) return varchar2
is
begin
  ------------------------------
  return merge_string(p_coll, p_delim);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function merge_nstr_list(p_coll ct_nvarchar_s, p_delim nvarchar2) return nvarchar2
is
begin
  ------------------------------
  return merge_nstr_list2(cast_ct_nvarchar_s2nvarchar(p_coll), p_delim);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function merge_nstr_list2(p_coll ct_nvarchar, p_delim nvarchar2) return nvarchar2
is
begin
  ------------------------------
  return merge_nstring(p_coll, p_delim);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xor(p_value1 boolean, p_value2 boolean) return boolean
is
begin
  ------------------------------
  XCheck_Cond_Missing(p_value1 is null, 'p_value1');
  XCheck_Cond_Missing(p_value2 is null, 'p_value2');
  ------------------------------
  return (p_value1 and not p_value2) or (not p_value1 and p_value2);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xor_int_bool(p_value1 number, p_value2 number) return number
is
begin
  ------------------------------
  XCheck_Cond_Missing(p_value1 is null, 'p_value1');
  XCheck_Cond_Missing(p_value2 is null, 'p_value2');
  ------------------------------
  return bool_to_int_2val(xor(int_to_bool_2val(p_value1), int_to_bool_2val(p_value2)));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
end;
/
