CREATE package body fast_parallel_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure sleep(p_seconds number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_seconds is null, 'p_seconds');
  ------------------------------
  dbms_lock.sleep(seconds => p_seconds);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_job_running(p_sys_job_id number) return number
is
begin
  ------------------------------
  return install_pkg.is_job_running(p_job => p_sys_job_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_job_running2(p_sys_job_id number) return boolean
is
begin
  ------------------------------
  return util_pkg.int_to_bool_2val(is_job_running(p_sys_job_id => p_sys_job_id));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_jobs_running(p_sys_job_ids ct_number) return ct_number
is
  v_res ct_number;
  v_count number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_sys_job_ids, 'p_sys_job_ids');
  ------------------------------
  v_count := util_pkg.get_count_ct_number(p_sys_job_ids);
  ------------------------------
  util_pkg.resize_ct_number(v_res, v_count);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_res(v_i) := is_job_running(nvl(p_sys_job_ids(v_i), c_dummy_sys_job_id)); --!_!
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function try_count_init return number
is
begin
  ------------------------------
  return c_count_zero;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure try_count_increase(p_try_count in out nocopy number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_try_count is null, 'p_try_count');
  ------------------------------
  p_try_count := p_try_count + 1;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function try_count_is_exceeded(p_actual_try_count number, p_param_retry_count number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_actual_try_count is null, 'p_actual_try_count');
  util_pkg.XCheck_Cond_Missing(p_param_retry_count is null, 'p_param_retry_count');
  ------------------------------
  if p_param_retry_count = c_retry_count_infinity
  then
    ------------------------------
    return false;
    ------------------------------
  end if;
  ------------------------------
  if p_actual_try_count > p_param_retry_count
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure timer_init(p_timeout_sec number, p_out_timeout_sec out number, p_out_start out date)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_timeout_sec is null, 'p_timeout_sec');
  ------------------------------
  p_out_timeout_sec := p_timeout_sec;
  p_out_start := sysdate;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure timer_alter(p_timeout_sec in out nocopy number, p_start in out nocopy date)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_timeout_sec is null, 'p_timeout_sec');
  util_pkg.XCheck_Cond_Missing(p_start is null, 'p_start');
  ------------------------------
  p_timeout_sec := greatest(0, p_timeout_sec - util_pkg.seconds_from_date_dif(sysdate - p_start));
  p_start := sysdate;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function timer_is_timed_out_or_sleep(p_timeout_sec number, p_start date, p_sleep_interval_sec number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_timeout_sec is null, 'p_timeout_sec');
  util_pkg.XCheck_Cond_Missing(p_start is null, 'p_start');
  util_pkg.XCheck_Cond_Missing(p_sleep_interval_sec is null, 'p_sleep_interval_sec');
  ------------------------------
  if p_sleep_interval_sec + util_pkg.seconds_from_date_dif(sysdate - p_start) > p_timeout_sec
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  sleep(p_seconds => p_sleep_interval_sec);
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_cit_job(p_coll cit_job) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_cit_task(p_coll cit_task) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_cit_flow(p_coll cit_flow) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_row2type4job(p_coll vp_agroup_data.rct_agroup_data) return cit_job
is
  v_res cit_job;
  v_count number;
begin
  ------------------------------
  v_count := frp_objects_count(p_coll);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_res(v_i) := frp_row2type4job_i(p_coll(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_type2row4job(p_coll cit_job) return vp_agroup_data.rct_agroup_data
is
  v_res vp_agroup_data.rct_agroup_data;
  v_count number;
begin
  ------------------------------
  v_count := get_count_cit_job(p_coll);
  ------------------------------
  vp_agroup_data.resize_rct_agroup_data(v_res, v_count);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_res(v_i) := frp_type2row4job_i(p_coll(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_row2type4task(p_coll vp_agroup_data.rct_agroup_data) return cit_task
is
  v_res cit_task;
  v_count number;
begin
  ------------------------------
  v_count := frp_objects_count(p_coll);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_res(v_i) := frp_row2type4task_i(p_coll(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_type2row4task(p_coll cit_task) return vp_agroup_data.rct_agroup_data
is
  v_res vp_agroup_data.rct_agroup_data;
  v_count number;
begin
  ------------------------------
  v_count := get_count_cit_task(p_coll);
  ------------------------------
  vp_agroup_data.resize_rct_agroup_data(v_res, v_count);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_res(v_i) := frp_type2row4task_i(p_coll(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_row2type4flow(p_coll vp_agroup_data.rct_agroup_data) return cit_flow
is
  v_res cit_flow;
  v_count number;
begin
  ------------------------------
  v_count := frp_objects_count(p_coll);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_res(v_i) := frp_row2type4flow_i(p_coll(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_type2row4flow(p_coll cit_flow) return vp_agroup_data.rct_agroup_data
is
  v_res vp_agroup_data.rct_agroup_data;
  v_count number;
begin
  ------------------------------
  v_count := get_count_cit_flow(p_coll);
  ------------------------------
  vp_agroup_data.resize_rct_agroup_data(v_res, v_count);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_res(v_i) := frp_type2row4flow_i(p_coll(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function extract_ids_cit_job(p_coll cit_job) return ct_number
is
  v_res ct_number;
  v_i number;
  v_j number;
begin
  ------------------------------
  util_pkg.resize_ct_number(v_res, get_count_cit_job(p_coll));
  ------------------------------
  v_i := p_coll.first;
  v_j := 1;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_res(v_j) := p_coll(v_i).job_id;
    ------------------------------
    v_i := p_coll.next(v_i);
    v_j := v_j + 1;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function extract_status_ids_cit_job(p_coll cit_job) return ct_number
is
  v_res ct_number;
  v_i number;
  v_j number;
begin
  ------------------------------
  util_pkg.resize_ct_number(v_res, get_count_cit_job(p_coll));
  ------------------------------
  v_i := p_coll.first;
  v_j := 1;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_res(v_j) := p_coll(v_i).status_id;
    ------------------------------
    v_i := p_coll.next(v_i);
    v_j := v_j + 1;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function extract_sys_job_ids_cit_job(p_coll cit_job) return ct_number
is
  v_res ct_number;
  v_i number;
  v_j number;
begin
  ------------------------------
  util_pkg.resize_ct_number(v_res, get_count_cit_job(p_coll));
  ------------------------------
  v_i := p_coll.first;
  v_j := 1;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_res(v_j) := p_coll(v_i).sys_job_id;
    ------------------------------
    v_i := p_coll.next(v_i);
    v_j := v_j + 1;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function extract_work_is_dones_cit_job(p_coll cit_job) return ct_number
is
  v_res ct_number;
  v_i number;
  v_j number;
begin
  ------------------------------
  util_pkg.resize_ct_number(v_res, get_count_cit_job(p_coll));
  ------------------------------
  v_i := p_coll.first;
  v_j := 1;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_res(v_j) := util_pkg.bool_to_int_2val(p_coll(v_i).work_is_done);
    ------------------------------
    v_i := p_coll.next(v_i);
    v_j := v_j + 1;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function extract_ids_cit_task(p_coll cit_task) return ct_number
is
  v_res ct_number;
  v_i number;
  v_j number;
begin
  ------------------------------
  util_pkg.resize_ct_number(v_res, get_count_cit_task(p_coll));
  ------------------------------
  v_i := p_coll.first;
  v_j := 1;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_res(v_j) := p_coll(v_i).task_id;
    ------------------------------
    v_i := p_coll.next(v_i);
    v_j := v_j + 1;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function extract_status_ids_cit_task(p_coll cit_task) return ct_number
is
  v_res ct_number;
  v_i number;
  v_j number;
begin
  ------------------------------
  util_pkg.resize_ct_number(v_res, get_count_cit_task(p_coll));
  ------------------------------
  v_i := p_coll.first;
  v_j := 1;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_res(v_j) := p_coll(v_i).status_id;
    ------------------------------
    v_i := p_coll.next(v_i);
    v_j := v_j + 1;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function extract_ids_cit_flow(p_coll cit_flow) return ct_number
is
  v_res ct_number;
  v_i number;
  v_j number;
begin
  ------------------------------
  util_pkg.resize_ct_number(v_res, get_count_cit_flow(p_coll));
  ------------------------------
  v_i := p_coll.first;
  v_j := 1;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_res(v_j) := p_coll(v_i).flow_id;
    ------------------------------
    v_i := p_coll.next(v_i);
    v_j := v_j + 1;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function extract_status_ids_cit_flow(p_coll cit_flow) return ct_number
is
  v_res ct_number;
  v_i number;
  v_j number;
begin
  ------------------------------
  util_pkg.resize_ct_number(v_res, get_count_cit_flow(p_coll));
  ------------------------------
  v_i := p_coll.first;
  v_j := 1;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_res(v_j) := p_coll(v_i).status_id;
    ------------------------------
    v_i := p_coll.next(v_i);
    v_j := v_j + 1;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function extract_type_ids_cit_flow(p_coll cit_flow) return ct_number
is
  v_res ct_number;
  v_i number;
  v_j number;
begin
  ------------------------------
  util_pkg.resize_ct_number(v_res, get_count_cit_flow(p_coll));
  ------------------------------
  v_i := p_coll.first;
  v_j := 1;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_res(v_j) := p_coll(v_i).flow_type_id;
    ------------------------------
    v_i := p_coll.next(v_i);
    v_j := v_j + 1;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xcheck_completion_rule(p_completion_rule number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_completion_rule is null, 'p_completion_rule');
  ------------------------------
  if obj_has_value(p_obj_value => p_completion_rule, p_goal_values => get_all_completion_rules, p_goal_can_be_empty => false)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'completion_rule' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_completion_rule));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_command(p_command_id number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_command_id is null, 'p_command_id');
  ------------------------------
  if obj_has_value(p_obj_value => p_command_id, p_goal_values => get_all_commands4job, p_goal_can_be_empty => false)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'command_id' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_command_id));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_status4job(p_job_status_id number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_job_status_id is null, 'p_job_status_id');
  ------------------------------
  if obj_has_value(p_obj_value => p_job_status_id, p_goal_values => get_all_statuses4job, p_goal_can_be_empty => false)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'job_status_id' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_job_status_id));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_status4task(p_task_status_id number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_task_status_id is null, 'p_task_status_id');
  ------------------------------
  if obj_has_value(p_obj_value => p_task_status_id, p_goal_values => get_all_statuses4task, p_goal_can_be_empty => false)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'task_status_id' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_task_status_id));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_status4flow(p_flow_status_id number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_flow_status_id is null, 'p_flow_status_id');
  ------------------------------
  if obj_has_value(p_obj_value => p_flow_status_id, p_goal_values => get_all_statuses4flow, p_goal_can_be_empty => false)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'flow_status_id' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_flow_status_id));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_statuses4job(p_job_status_ids ct_number, p_can_be_empty boolean)
is
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_can_be_empty is null, 'p_can_be_empty');
  ------------------------------
  if not p_can_be_empty
  then
    ------------------------------
    util_pkg.XCheckP_ct_number(p_job_status_ids, 'p_job_status_ids');
    ------------------------------
  end if;
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_job_status_ids);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    xcheck_status4job(p_job_status_id => p_job_status_ids(v_i));
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_statuses4task(p_task_status_ids ct_number, p_can_be_empty boolean)
is
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_can_be_empty is null, 'p_can_be_empty');
  ------------------------------
  if not p_can_be_empty
  then
    ------------------------------
    util_pkg.XCheckP_ct_number(p_task_status_ids, 'p_task_status_ids');
    ------------------------------
  end if;
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_task_status_ids);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    xcheck_status4task(p_task_status_id => p_task_status_ids(v_i));
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_statuses4flow(p_flow_status_ids ct_number, p_can_be_empty boolean)
is
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_can_be_empty is null, 'p_can_be_empty');
  ------------------------------
  if not p_can_be_empty
  then
    ------------------------------
    util_pkg.XCheckP_ct_number(p_flow_status_ids, 'p_flow_status_ids');
    ------------------------------
  end if;
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_flow_status_ids);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    xcheck_status4flow(p_flow_status_id => p_flow_status_ids(v_i));
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_status_changeable4job(p_status_id_old number, p_status_id_new number)
is
begin
  ------------------------------
  if is_allowed_status_change4job(p_status_id_old, p_status_id_new)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_status_id_old) || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_status_id_new));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_status_changeable4task(p_status_id_old number, p_status_id_new number)
is
begin
  ------------------------------
  if is_allowed_status_change4task(p_status_id_old, p_status_id_new)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_status_id_old) || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_status_id_new));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_status_changeable4flow(p_status_id_old number, p_status_id_new number)
is
begin
  ------------------------------
  if is_allowed_status_change4flow(p_status_id_old, p_status_id_new)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_status_id_old) || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_status_id_new));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_allowed_status_change4job(p_status_id_old number, p_status_id_new number) return boolean
is
begin
  ------------------------------
  xcheck_status4job(p_job_status_id => p_status_id_old);
  xcheck_status4job(p_job_status_id => p_status_id_new);
  ------------------------------
  if 1 = 0
    or p_status_id_old = p_status_id_new
    or p_status_id_new = c_stat_cancelling --!_!
  then
    ------------------------------
    return TRUE;
    ------------------------------
  end if;
  ------------------------------
  if 1 = 0
    or is_final_status4job(p_job_status_id => p_status_id_old)
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
  if p_status_id_old = c_stat_new
  then
    ------------------------------
    return (p_status_id_new in (c_stat_waiting2run));
    ------------------------------
  elsif p_status_id_old = c_stat_waiting2run
  then
    ------------------------------
    return (p_status_id_new in (c_stat_running));
    ------------------------------
  elsif p_status_id_old = c_stat_running
  then
    ------------------------------
    return (p_status_id_new in (c_stat_waiting2complete));
    ------------------------------
  elsif p_status_id_old = c_stat_waiting2complete
  then
    ------------------------------
    return (p_status_id_new in (c_stat_running, c_stat_cancelling, c_stat_cancelled, c_stat_completed));
    ------------------------------
  elsif p_status_id_old = c_stat_cancelling
  then
    ------------------------------
    return (p_status_id_new in (c_stat_cancelled));
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'status_id_old' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_status_id_old));
    ------------------------------
  end if;
  ------------------------------
  return FALSE;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_allowed_status_change4task(p_status_id_old number, p_status_id_new number) return boolean
is
begin
  ------------------------------
  xcheck_status4task(p_task_status_id => p_status_id_old);
  xcheck_status4task(p_task_status_id => p_status_id_new);
  ------------------------------
  if 1 = 0
    or p_status_id_old = p_status_id_new
    --!_!or p_status_id_new = c_stat_cancelling --!_!
  then
    ------------------------------
    return TRUE;
    ------------------------------
  end if;
  ------------------------------
  if 1 = 0
    or is_final_status4task(p_task_status_id => p_status_id_old)
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
  if p_status_id_old = c_stat_new
  then
    ------------------------------
    return (p_status_id_new in (c_stat_running));
    ------------------------------
  elsif p_status_id_old = c_stat_running
  then
    ------------------------------
    return (p_status_id_new in (c_stat_cancelled, c_stat_completed));
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'status_id_old' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_status_id_old));
    ------------------------------
  end if;
  ------------------------------
  return FALSE;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_allowed_status_change4flow(p_status_id_old number, p_status_id_new number) return boolean
is
begin
  ------------------------------
  xcheck_status4flow(p_flow_status_id => p_status_id_old);
  xcheck_status4flow(p_flow_status_id => p_status_id_new);
  ------------------------------
  if 1 = 0
    or p_status_id_old = p_status_id_new
    --!_!or p_status_id_new = c_stat_cancelling --!_!
  then
    ------------------------------
    return TRUE;
    ------------------------------
  end if;
  ------------------------------
  if 1 = 0
    or is_final_status4flow(p_flow_status_id => p_status_id_old)
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
  if p_status_id_old = c_stat_new
  then
    ------------------------------
    return (p_status_id_new in (c_stat_running));
    ------------------------------
  elsif p_status_id_old = c_stat_running
  then
    ------------------------------
    return (p_status_id_new in (c_stat_cancelled, c_stat_completed));
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'status_id_old' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_status_id_old));
    ------------------------------
  end if;
  ------------------------------
  return FALSE;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_final_status4job(p_job_status_id number) return boolean
is
begin
  ------------------------------
  xcheck_status4job(p_job_status_id => p_job_status_id);
  ------------------------------
  return obj_has_value(p_obj_value => p_job_status_id, p_goal_values => get_final_statuses4job, p_goal_can_be_empty => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_final_status4task(p_task_status_id number) return boolean
is
begin
  ------------------------------
  xcheck_status4task(p_task_status_id => p_task_status_id);
  ------------------------------
  return obj_has_value(p_obj_value => p_task_status_id, p_goal_values => get_final_statuses4task, p_goal_can_be_empty => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_final_status4flow(p_flow_status_id number) return boolean
is
begin
  ------------------------------
  xcheck_status4flow(p_flow_status_id => p_flow_status_id);
  ------------------------------
  return obj_has_value(p_obj_value => p_flow_status_id, p_goal_values => get_final_statuses4flow, p_goal_can_be_empty => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_final_statuses4all return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_res, c_stat_cancelled);
  util_pkg.add_ct_number_val(v_res, c_stat_completed);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_final_statuses4job return ct_number
is
begin
  ------------------------------
  return get_final_statuses4all;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_final_statuses4task return ct_number
is
begin
  ------------------------------
  return get_final_statuses4all;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_final_statuses4flow return ct_number
is
begin
  ------------------------------
  return get_final_statuses4all;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_interim_statuses4job return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_res, c_stat_new);
  util_pkg.add_ct_number_val(v_res, c_stat_waiting2run);
  util_pkg.add_ct_number_val(v_res, c_stat_running);
  util_pkg.add_ct_number_val(v_res, c_stat_waiting2complete);
  util_pkg.add_ct_number_val(v_res, c_stat_cancelling);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_interim_statuses4task return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_res, c_stat_new);
  util_pkg.add_ct_number_val(v_res, c_stat_running);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_interim_statuses4flow return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_res, c_stat_new);
  util_pkg.add_ct_number_val(v_res, c_stat_running);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_all_statuses4job return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  v_res := get_final_statuses4job;
  util_pkg.add_ct_number(v_res, get_interim_statuses4job);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_all_statuses4task return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  v_res := get_final_statuses4task;
  util_pkg.add_ct_number(v_res, get_interim_statuses4task);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_all_statuses4flow return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  v_res := get_final_statuses4flow;
  util_pkg.add_ct_number(v_res, get_interim_statuses4flow);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_error_status4all_i(p_direction_forward boolean) return number
is
  v_res number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_direction_forward is null, 'p_direction_forward');
  ------------------------------
  if p_direction_forward
  then
    ------------------------------
    v_res := c_stat_cancelled;
    ------------------------------
  else
    ------------------------------
    v_res := c_stat_completed;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_error_status4job(p_direction_forward boolean) return number
is
begin
  ------------------------------
  return get_error_status4all_i(p_direction_forward => p_direction_forward);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_error_status4task(p_direction_forward boolean) return number
is
begin
  ------------------------------
  return get_error_status4all_i(p_direction_forward => p_direction_forward);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_error_status4flow(p_direction_forward boolean) return number
is
begin
  ------------------------------
  return get_error_status4all_i(p_direction_forward => p_direction_forward);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_cancel_status4job(p_direction_forward boolean) return number
is
begin
  ------------------------------
  return get_error_status4job(p_direction_forward => p_direction_forward); --!_!cancel is same as error
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_success_status4all_i(p_direction_forward boolean) return number
is
  v_res number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_direction_forward is null, 'p_direction_forward');
  ------------------------------
  if p_direction_forward
  then
    ------------------------------
    v_res := c_stat_completed;
    ------------------------------
  else
    ------------------------------
    v_res := c_stat_cancelled;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_success_status4job(p_direction_forward boolean) return number
is
begin
  ------------------------------
  return get_success_status4all_i(p_direction_forward => p_direction_forward);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_success_status4task(p_direction_forward boolean) return number
is
begin
  ------------------------------
  return get_success_status4all_i(p_direction_forward => p_direction_forward);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_success_status4flow(p_direction_forward boolean) return number
is
begin
  ------------------------------
  return get_success_status4all_i(p_direction_forward => p_direction_forward);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_break_statuses4job(p_direction_forward boolean) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_direction_forward is null, 'p_direction_forward');
  ------------------------------
  --!_!just one
  util_pkg.add_ct_number_val(v_res, get_error_status4job(p_direction_forward => p_direction_forward));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_all_completion_rules return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_res, c_cr_all);
  util_pkg.add_ct_number_val(v_res, c_cr_one);
  --!_!util_pkg.add_ct_number_val(v_res, c_cr_quorum);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_all_commands4job return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_res, c_jcmd_empty);
  util_pkg.add_ct_number_val(v_res, c_jcmd_run);
  util_pkg.add_ct_number_val(v_res, c_jcmd_commit);
  util_pkg.add_ct_number_val(v_res, c_jcmd_cancel);
  util_pkg.add_ct_number_val(v_res, c_jcmd_prepare_forward);
  util_pkg.add_ct_number_val(v_res, c_jcmd_prepare_backward);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_break_completion_rule(p_goal_completion_rule number) return number
is
begin
  ------------------------------
  xcheck_completion_rule(p_goal_completion_rule);
  ------------------------------
  if p_goal_completion_rule = c_cr_all
  then
    ------------------------------
    return c_cr_one;
    ------------------------------
  else --!_!c_cr_one
    ------------------------------
    return c_cr_all;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_work_is_done(p_direction_forward boolean) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_direction_forward is null, 'p_direction_forward');
  ------------------------------
  return p_direction_forward;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_work_needed(p_work_is_done boolean, p_direction_forward boolean) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_work_is_done is null, 'p_work_is_done');
  util_pkg.XCheck_Cond_Missing(p_direction_forward is null, 'p_direction_forward');
  ------------------------------
  return (p_work_is_done != get_work_is_done(p_direction_forward => p_direction_forward));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xcheck_t_job(p_obj t_job, p_check_parent boolean)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_parent is null, 'p_check_parent');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_obj.job_id is null, 'job_id');
  util_pkg.XCheck_Cond_Missing(p_check_parent and p_obj.parent_id is null, 'parent_id');
  util_pkg.XCheck_Cond_Missing(p_obj.user_id is null, 'user_id');
  xcheck_status4job(p_job_status_id => p_obj.status_id);
  xcheck_command(p_obj.command_id);
  util_pkg.XCheck_Cond_Missing(p_obj.last_date is null, 'last_date');
  --!_!util_pkg.XCheck_Cond_Missing(p_obj.sys_job_id is null, 'sys_job_id');
  util_pkg.XCheck_Cond_Missing(p_obj.retry_count is null, 'retry_count');
  util_pkg.XCheck_Cond_Missing(p_obj.retry_interval_sec is null, 'retry_interval_sec');
  util_pkg.XCheck_Cond_Missing(p_obj.idle_sleep_time_sec is null, 'idle_sleep_time_sec');
  util_pkg.XCheck_Cond_Missing(p_obj.expired_timeout_sec is null, 'expired_timeout_sec');
  util_pkg.XCheck_Cond_Missing(p_obj.wait_lock_sec is null, 'wait_lock_sec');
  util_pkg.XCheck_Cond_Missing(p_obj.keepalive_sec is null, 'keepalive_sec');
  util_pkg.XCheck_Cond_Missing(p_obj.work_is_done is null, 'work_is_done');
  util_pkg.XCheck_Cond_Missing(p_obj.error_id is null, 'error_id');
  util_pkg.XCheck_Cond_Missing(p_obj.error_message is null, 'error_message');
  util_pkg.XCheck_Cond_Missing(p_obj.job_text is null, 'job_text');
  --!_!util_pkg.XCheck_Cond_Missing(p_obj.context is null, 'context');
  ------------------------------
end;


----------------------------------!---------------------------------------------
procedure xcheck_t_task(p_obj t_task, p_check_parent boolean)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_parent is null, 'p_check_parent');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_obj.task_id is null, 'task_id');
  util_pkg.XCheck_Cond_Missing(p_check_parent and p_obj.parent_id is null, 'parent_id');
  util_pkg.XCheck_Cond_Missing(p_obj.user_id is null, 'user_id');
  xcheck_status4task(p_task_status_id => p_obj.status_id);
  xcheck_completion_rule(p_obj.completion_rule);
  util_pkg.XCheck_Cond_Missing(p_obj.last_date is null, 'last_date');
  util_pkg.XCheck_Cond_Missing(p_obj.retry_count is null, 'retry_count');
  util_pkg.XCheck_Cond_Missing(p_obj.retry_interval_sec is null, 'retry_interval_sec');
  util_pkg.XCheck_Cond_Missing(p_obj.actual_try_count is null, 'actual_try_count');
  util_pkg.XCheck_Cond_Missing(p_obj.wait_all_jobs_completion is null, 'wait_all_jobs_completion');
  util_pkg.XCheck_Cond_Missing(p_obj.sync_commit is null, 'sync_commit');
  util_pkg.XCheck_Cond_Missing(p_obj.idle_sleep_time_sec is null, 'idle_sleep_time_sec');
  util_pkg.XCheck_Cond_Missing(p_obj.expired_timeout_sec is null, 'expired_timeout_sec');
  util_pkg.XCheck_Cond_Missing(p_obj.wait_lock_sec is null, 'wait_lock_sec');
  util_pkg.XCheck_Cond_Missing(p_obj.work_is_done is null, 'work_is_done');
  util_pkg.XCheck_Cond_Missing(p_obj.error_id is null, 'error_id');
  util_pkg.XCheck_Cond_Missing(p_obj.error_message is null, 'error_message');
  --!_!util_pkg.XCheck_Cond_Missing(p_obj.context is null, 'context');
  --!_!xcheck_cit_job(p_jobs);
  --!_!util_pkg.XCheck_Cond_Missing(get_count_cit_job(p_obj.jobs) = 0, 'p_obj.jobs.count = 0');
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_t_flow(p_obj t_flow)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_obj.flow_id is null, 'flow_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_obj.parent_id is null, 'parent_id');
  util_pkg.XCheck_Cond_Missing(p_obj.user_id is null, 'user_id');
  xcheck_status4flow(p_flow_status_id => p_obj.status_id);
  util_pkg.XCheck_Cond_Missing(p_obj.flow_type_id is null, 'flow_type_id');
  util_pkg.XCheck_Cond_Missing(p_obj.reversible is null, 'reversible');
  util_pkg.XCheck_Cond_Missing(p_obj.direction_forward is null, 'direction_forward');
  util_pkg.XCheck_Cond_Missing(p_obj.last_date is null, 'last_date');
  util_pkg.XCheck_Cond_Missing(p_obj.retry_count is null, 'retry_count');
  util_pkg.XCheck_Cond_Missing(p_obj.retry_interval_sec is null, 'retry_interval_sec');
  util_pkg.XCheck_Cond_Missing(p_obj.actual_try_count is null, 'actual_try_count');
  util_pkg.XCheck_Cond_Missing(p_obj.wait_lock_sec is null, 'wait_lock_sec');
  util_pkg.XCheck_Cond_Missing(p_obj.work_is_done is null, 'work_is_done');
  util_pkg.XCheck_Cond_Missing(p_obj.error_id is null, 'error_id');
  util_pkg.XCheck_Cond_Missing(p_obj.error_message is null, 'error_message');
  --!_!util_pkg.XCheck_Cond_Missing(p_obj.context is null, 'context');
  --!_!xcheck_cit_task(p_tasks);
  --!_!util_pkg.XCheck_Cond_Missing(get_count_cit_task(p_obj.tasks) = 0, 'p_obj.tasks.count = 0');
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_cit_job(p_coll cit_job)
is
  v_i number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(get_count_cit_job(p_coll) = 0, 'p_coll.count = 0');
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    xcheck_t_job(p_coll(v_i));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_serialization_delim return varchar2
is
begin
  ------------------------------
  return install_pkg.nnget_option_str(c_opt_fastp_srlz_delim, c_srlz_delim_len, c_def_fastp_srlz_delim);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_serialization_delim2 return varchar2
is
begin
  ------------------------------
  return install_pkg.nnget_option_str(c_opt_fastp_srlz_delim2, c_srlz_delim_len, c_def_fastp_srlz_delim2);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_serialization_delim_subst return varchar2
is
begin
  ------------------------------
  return install_pkg.nnget_option_str(c_opt_fastp_srlz_delim_subst, c_srlz_delim_len, c_def_fastp_srlz_delim_subst);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cut_message(p_text clob) return varchar2
is
begin
  ------------------------------
  return substr(p_text, 1, install_pkg.nnget_option_num(c_opt_fastp_srlz_err_msg_len, c_def_fastp_srlz_err_msg_len));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function wrap_message(p_text clob) return varchar2
is
begin
  ------------------------------
  return replace(cut_message(p_text), get_serialization_delim, get_serialization_delim_subst);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function job_serialize(p_obj t_job) return clob
is
  v_res clob;
  v_delim varchar2(10);
  v_coll ct_varchar;
begin
  ------------------------------
  v_delim := get_serialization_delim;
  ------------------------------
  --!_!initial
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.job_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.parent_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.user_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.status_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.command_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.date_to_char(p_obj.last_date));
  --!_!submitted
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.sys_job_id));
  --!_!internal
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.retry_count));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.retry_interval_sec));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.idle_sleep_time_sec));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.expired_timeout_sec));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.wait_lock_sec));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.keepalive_sec));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.bool_to_char(p_obj.work_is_done));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.error_id));
  util_pkg.add_ct_varchar_val(v_coll, wrap_message(p_obj.error_message));
  --!_!util_pkg.add_ct_varchar_val(v_coll, p_obj.job_text);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) != c_srzi_count_job, 'Wrong format 001');
  ------------------------------
  --!_!out of place
  v_res := to_clob(util_pkg.merge_string(v_coll, v_delim)) || v_delim || p_obj.job_text; --!_!c_srzi_job_text
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function job_deserialize(p_str clob) return t_job
is
  v_res t_job;
  v_delim varchar2(10);
  v_real_clob_delim_pos number;
  v_str varchar2(4000);
  v_coll ct_varchar;
begin
  ------------------------------
  v_delim := get_serialization_delim;
  ------------------------------
  v_real_clob_delim_pos := nvl(instr(p_str, v_delim, 1, c_srzi_count_job), 0); --!_!before last element (before job_text)
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_real_clob_delim_pos = 0, 'Wrong format 002');
  ------------------------------
  v_str := substr(p_str, 1, v_real_clob_delim_pos - 1);
  ------------------------------
  v_coll := util_pkg.split_string(v_str, v_delim);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) < c_srzi_count_job, 'Wrong format 001');
  ------------------------------
  --!_!initial
  v_res.job_id := util_pkg.char_to_number(v_coll(c_srzi_job_job_id));
  v_res.parent_id := util_pkg.char_to_number(v_coll(c_srzi_job_parent_id));
  v_res.user_id := util_pkg.char_to_number(v_coll(c_srzi_job_user_id));
  v_res.status_id := util_pkg.char_to_number(v_coll(c_srzi_job_status_id));
  v_res.command_id := util_pkg.char_to_number(v_coll(c_srzi_job_command_id));
  v_res.last_date := util_pkg.char_to_date(v_coll(c_srzi_job_last_date));
  --!_!submitted
  v_res.sys_job_id := util_pkg.char_to_number(v_coll(c_srzi_job_sys_job_id));
  --!_!internal
  v_res.retry_count := util_pkg.char_to_number(v_coll(c_srzi_job_retry_count));
  v_res.retry_interval_sec := util_pkg.char_to_number(v_coll(c_srzi_job_retry_interval_sec));
  v_res.idle_sleep_time_sec := util_pkg.char_to_number(v_coll(c_srzi_job_idle_sleep_time_sec));
  v_res.expired_timeout_sec := util_pkg.char_to_number(v_coll(c_srzi_job_expired_timeout_sec));
  v_res.wait_lock_sec := util_pkg.char_to_number(v_coll(c_srzi_job_wait_lock_sec));
  v_res.keepalive_sec := util_pkg.char_to_number(v_coll(c_srzi_job_keepalive_sec));
  v_res.work_is_done := util_pkg.char_to_bool(v_coll(c_srzi_job_work_is_done));
  v_res.error_id := util_pkg.char_to_number(v_coll(c_srzi_job_error_id));
  v_res.error_message := v_coll(c_srzi_job_error_message); --!_!no wrap
  --!_!v_res.job_text := v_coll(c_srzi_job_job_text);
  --!_!out of place
  v_res.job_text := substr(p_str, v_real_clob_delim_pos + 1); --!_!c_srzi_job_job_text
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function task_serialize(p_obj t_task) return clob
is
  v_res clob;
  v_delim varchar2(10);
  v_coll ct_varchar;
begin
  ------------------------------
  v_delim := get_serialization_delim;
  ------------------------------
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.task_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.parent_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.user_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.status_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.completion_rule));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.date_to_char(p_obj.last_date));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.retry_count));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.retry_interval_sec));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.actual_try_count));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.bool_to_char(p_obj.wait_all_jobs_completion));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.bool_to_char(p_obj.sync_commit));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.idle_sleep_time_sec));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.expired_timeout_sec));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.wait_lock_sec));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.bool_to_char(p_obj.work_is_done));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.error_id));
  util_pkg.add_ct_varchar_val(v_coll, wrap_message(p_obj.error_message));
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) != c_srzi_count_task, 'Wrong format 001');
  ------------------------------
  v_res := to_clob(util_pkg.merge_string(v_coll, v_delim));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function task_deserialize(p_str clob) return t_task
is
  v_res t_task;
  v_delim varchar2(10);
  v_coll ct_varchar;
begin
  ------------------------------
  v_delim := get_serialization_delim;
  ------------------------------
  v_coll := util_pkg.split_string(p_str, v_delim); --!_!clob to varchar2(???)
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) < c_srzi_count_task, 'Wrong format 001');
  ------------------------------
  v_res.task_id := util_pkg.char_to_number(v_coll(c_srzi_task_task_id));
  v_res.parent_id := util_pkg.char_to_number(v_coll(c_srzi_task_parent_id));
  v_res.user_id := util_pkg.char_to_number(v_coll(c_srzi_task_user_id));
  v_res.status_id := util_pkg.char_to_number(v_coll(c_srzi_task_status_id));
  v_res.completion_rule := util_pkg.char_to_number(v_coll(c_srzi_task_completion_rule));
  v_res.last_date := util_pkg.char_to_date(v_coll(c_srzi_task_last_date));
  v_res.retry_count := util_pkg.char_to_number(v_coll(c_srzi_task_retry_count));
  v_res.retry_interval_sec := util_pkg.char_to_number(v_coll(c_srzi_task_retry_interval_sec));
  v_res.actual_try_count := util_pkg.char_to_number(v_coll(c_srzi_task_actual_try_count));
  v_res.wait_all_jobs_completion := util_pkg.char_to_bool(v_coll(c_srzi_task_wait_alljobs_compl));
  v_res.sync_commit := util_pkg.char_to_bool(v_coll(c_srzi_task_sync_commit));
  v_res.idle_sleep_time_sec := util_pkg.char_to_number(v_coll(c_srzi_task_sleep_time_sec));
  v_res.expired_timeout_sec := util_pkg.char_to_number(v_coll(c_srzi_task_expiredtimeout_sec));
  v_res.wait_lock_sec := util_pkg.char_to_number(v_coll(c_srzi_task_wait_lock_sec));
  v_res.work_is_done := util_pkg.char_to_bool(v_coll(c_srzi_task_work_is_done));
  v_res.error_id := util_pkg.char_to_number(v_coll(c_srzi_task_error_id));
  v_res.error_message := v_coll(c_srzi_task_error_message); --!_!no wrap
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function flow_serialize(p_obj t_flow) return clob
is
  v_res clob;
  v_delim varchar2(10);
  v_coll ct_varchar;
begin
  ------------------------------
  v_delim := get_serialization_delim;
  ------------------------------
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.flow_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.user_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.status_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.flow_type_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.bool_to_char(p_obj.reversible));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.bool_to_char(p_obj.direction_forward));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.date_to_char(p_obj.last_date));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.retry_count));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.retry_interval_sec));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.actual_try_count));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.wait_lock_sec));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.bool_to_char(p_obj.work_is_done));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.error_id));
  util_pkg.add_ct_varchar_val(v_coll, wrap_message(p_obj.error_message));
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) != c_srzi_count_flow, 'Wrong format 001');
  ------------------------------
  v_res := to_clob(util_pkg.merge_string(v_coll, v_delim));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function flow_deserialize(p_str clob) return t_flow
is
  v_res t_flow;
  v_delim varchar2(10);
  v_coll ct_varchar;
begin
  ------------------------------
  v_delim := get_serialization_delim;
  ------------------------------
  v_coll := util_pkg.split_string(p_str, v_delim); --!_!clob to varchar2(???)
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) < c_srzi_count_flow, 'Wrong format 001');
  ------------------------------
  v_res.flow_id := util_pkg.char_to_number(v_coll(c_srzi_flow_flow_id));
  v_res.user_id := util_pkg.char_to_number(v_coll(c_srzi_flow_user_id));
  v_res.status_id := util_pkg.char_to_number(v_coll(c_srzi_flow_status_id));
  v_res.flow_type_id := util_pkg.char_to_number(v_coll(c_srzi_flow_flow_type_id));
  v_res.reversible := util_pkg.char_to_bool(v_coll(c_srzi_flow_reversible));
  v_res.direction_forward := util_pkg.char_to_bool(v_coll(c_srzi_flow_direction_forward));
  v_res.last_date := util_pkg.char_to_date(v_coll(c_srzi_flow_last_date));
  v_res.retry_count := util_pkg.char_to_number(v_coll(c_srzi_flow_retry_count));
  v_res.retry_interval_sec := util_pkg.char_to_number(v_coll(c_srzi_flow_retry_interval_sec));
  v_res.actual_try_count := util_pkg.char_to_number(v_coll(c_srzi_flow_actual_try_count));
  v_res.wait_lock_sec := util_pkg.char_to_number(v_coll(c_srzi_flow_wait_lock_sec));
  v_res.work_is_done := util_pkg.char_to_bool(v_coll(c_srzi_flow_work_is_done));
  v_res.error_id := util_pkg.char_to_number(v_coll(c_srzi_flow_error_id));
  v_res.error_message := v_coll(c_srzi_flow_error_message); --!_!no wrap
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function job_serialize2(p_obj t_job) return varchar2
is
  lc_max_varchar2_length constant integer := util_pkg.c_varchar_length;
  v_clob clob;
begin
  ------------------------------
  v_clob := job_serialize(p_obj);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(nvl(length(v_clob), 0) > lc_max_varchar2_length, 'Job data is too long');
  ------------------------------
  return v_clob;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function job_deserialize2(p_str varchar2) return t_job
is
begin
  ------------------------------
  return job_deserialize(p_str);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function task_serialize2(p_obj t_task) return varchar2
is
  lc_max_varchar2_length constant integer := util_pkg.c_varchar_length;
  v_clob clob;
begin
  ------------------------------
  v_clob := task_serialize(p_obj);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(nvl(length(v_clob), 0) > lc_max_varchar2_length, 'Job data is too long');
  ------------------------------
  return v_clob;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function task_deserialize2(p_str varchar2) return t_task
is
begin
  ------------------------------
  return task_deserialize(p_str);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function flow_serialize2(p_obj t_flow) return varchar2
is
  lc_max_varchar2_length constant integer := util_pkg.c_varchar_length;
  v_clob clob;
begin
  ------------------------------
  v_clob := flow_serialize(p_obj);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(nvl(length(v_clob), 0) > lc_max_varchar2_length, 'Job data is too long');
  ------------------------------
  return v_clob;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function flow_deserialize2(p_str varchar2) return t_flow
is
begin
  ------------------------------
  return flow_deserialize(p_str);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure frp_xcheck_data_consistency(p_row_template agroup_data%rowtype, p_row_result agroup_data%rowtype, p_check_parent boolean)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_parent is null, 'p_check_parent');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_row_result.agroup_data_id is null, 'p_row_result.agroup_data_id');
  util_pkg.XCheck_Cond_Missing(p_row_result.agroup_id is null, 'p_row_result.agroup_id');
  util_pkg.XCheck_Cond_Missing(p_check_parent and p_row_result.id1 is null, 'p_row_result.id1');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_row_template.agroup_data_id is not null and p_row_template.agroup_data_id != p_row_result.agroup_data_id, 'Inconsistent data 001:agroup_data_id:object_id');
  util_pkg.XCheck_Cond_Invalid(p_row_template.agroup_id is not null and p_row_template.agroup_id != p_row_result.agroup_id, 'Inconsistent data 002:agroup_id:group_id');
  util_pkg.XCheck_Cond_Invalid(p_check_parent and p_row_template.id1 is not null and p_row_template.id1 != p_row_result.id1, 'Inconsistent data 003:id1:parent_id');
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_type2row4context_i(p_context clob, p_row_template agroup_data%rowtype) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  v_res := p_row_template;
  ------------------------------
  --!_!v_res.str2 := cut_message(p_context);
  v_res.str2 := p_context;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_row2type4context_i(p_row agroup_data%rowtype) return clob
is
begin
  ------------------------------
  return p_row.str2;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_type2row4log0_i(p_log_type_id number, p_log_object_id number, p_user_id number, p_result_id number, p_result_message clob) return agroup_data%rowtype
is
  v_row agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_log_type_id is null, 'p_log_type_id');
  util_pkg.XCheck_Cond_Missing(p_log_object_id is null, 'p_log_object_id');
  ------------------------------
  v_row := null;
  ------------------------------
  v_row.agroup_id := p_log_type_id;
  v_row.id1 := p_log_object_id;
  ------------------------------
  return frp_type2row4log_i(p_user_id => p_user_id, p_result_id => p_result_id, p_result_message => p_result_message, p_row_template => v_row);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_type2row4log_i(p_user_id number, p_result_id number, p_result_message clob, p_row_template agroup_data%rowtype) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_res := p_row_template;
  ------------------------------
  v_res.date_from := null; --!_!
  v_res.date_to := null; --!_!
  v_res.user_id := p_user_id;
  v_res.id2 := p_result_id;
  v_res.dsc := cut_message(p_result_message);
  v_res.str2 := p_result_message;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_row2type4log_res_id_i(p_row agroup_data%rowtype) return number
is
begin
  ------------------------------
  return p_row.id2;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_row2type4log_res_msg_i(p_row agroup_data%rowtype) return clob
is
begin
  ------------------------------
  return p_row.str2;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_type2row4job0_i(p_obj t_job, p_row_template agroup_data%rowtype) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  xcheck_t_job(p_obj);
  ------------------------------
  v_res := p_row_template;
  ------------------------------
  v_res.agroup_data_id := p_obj.job_id;
  v_res.agroup_id := c_agroup_id_fastp_jobs;
  v_res.id1 := p_obj.parent_id; --!_!no change parent now
  ------------------------------
  frp_xcheck_data_consistency(p_row_template => p_row_template, p_row_result => v_res);
  ------------------------------
  v_res.id2 := p_obj.status_id;
  v_res.num3 := p_obj.command_id;
  ------------------------------
  v_res.date1 := sysdate; --!_!p_obj.last_date
  v_res.user_id := p_obj.user_id;
  ------------------------------
  v_res.dsc := job_serialize2(p_obj);
  ------------------------------
  --!_!v_res.str2 := cut_message(p_obj.context);
  v_res.str2 := p_obj.context;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_type2row4job_i(p_obj t_job) return agroup_data%rowtype
is
begin
  ------------------------------
  return frp_type2row4job0_i(p_obj => p_obj, p_row_template => NULL);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_row2type4job_i(p_row agroup_data%rowtype) return t_job
is
  v_res t_job;
begin
  ------------------------------
  v_res := job_deserialize2(p_row.dsc);
  ------------------------------
  xcheck_t_job(v_res);
  ------------------------------
  v_res.job_id := p_row.agroup_data_id;
  --!_!c_agroup_id_fastp_jobs := v_res.agroup_id;
  v_res.parent_id := p_row.id1;
  ------------------------------
  v_res.status_id := p_row.id2;
  v_res.command_id := p_row.num3;
  ------------------------------
  v_res.last_date := p_row.date1; --!_!
  --!_!v_res.user_id := p_row.user_id; --!_!use user_id from p_row.dsc
  ------------------------------
  v_res.context := p_row.str2;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_type2row4task0_i(p_obj t_task, p_row_template agroup_data%rowtype) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  xcheck_t_task(p_obj);
  ------------------------------
  v_res := p_row_template;
  ------------------------------
  v_res.agroup_data_id := p_obj.task_id;
  v_res.agroup_id := c_agroup_id_fastp_tasks;
  v_res.id1 := p_obj.parent_id; --!_!no change parent now
  ------------------------------
  frp_xcheck_data_consistency(p_row_template => p_row_template, p_row_result => v_res);
  ------------------------------
  v_res.id2 := p_obj.status_id;
  --!_!v_res.num3 := ;
  ------------------------------
  v_res.date1 := sysdate; --!_!p_obj.last_date
  v_res.user_id := p_obj.user_id;
  ------------------------------
  --!_! := p_obj.jobs;
  ------------------------------
  v_res.dsc := task_serialize2(p_obj);
  ------------------------------
  --!_!v_res.str2 := cut_message(p_obj.context);
  v_res.str2 := p_obj.context;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_type2row4task_i(p_obj t_task) return agroup_data%rowtype
is
begin
  ------------------------------
  return frp_type2row4task0_i(p_obj, NULL);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_row2type4task_i(p_row agroup_data%rowtype) return t_task
is
  v_res t_task;
begin
  ------------------------------
  v_res := task_deserialize2(p_row.dsc);
  ------------------------------
  xcheck_t_task(v_res);
  ------------------------------
  v_res.task_id := p_row.agroup_data_id;
  --!_!c_agroup_id_fastp_tasks := v_res.agroup_id;
  v_res.parent_id := p_row.id1;
  ------------------------------
  v_res.status_id := p_row.id2;
  --!_!v_res. := p_row.num3;
  ------------------------------
  v_res.last_date := p_row.date1; --!_!
  --!_!v_res.user_id := p_row.user_id; --!_!use user_id from p_row.dsc
  ------------------------------
  v_res.context := p_row.str2;
  ------------------------------
  --!_!v_res.jobs := ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_type2row4flow0_i(p_obj t_flow, p_row_template agroup_data%rowtype) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  xcheck_t_flow(p_obj);
  ------------------------------
  v_res := p_row_template;
  ------------------------------
  v_res.agroup_data_id := p_obj.flow_id;
  v_res.agroup_id := c_agroup_id_fastp_flows;
  --!_!v_res.id1 := p_obj.parent_id; --!_!no change parent now
  ------------------------------
  frp_xcheck_data_consistency(p_row_template => p_row_template, p_row_result => v_res, p_check_parent => FALSE);
  ------------------------------
  v_res.id2 := p_obj.status_id;
  v_res.num3 := p_obj.flow_type_id;
  ------------------------------
  v_res.date1 := sysdate; --!_!p_obj.last_date
  v_res.user_id := p_obj.user_id;
  ------------------------------
  --!_! := p_obj.tasks;
  ------------------------------
  v_res.dsc := flow_serialize2(p_obj);
  ------------------------------
  --!_!v_res.str2 := cut_message(p_obj.context);
  v_res.str2 := p_obj.context;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_type2row4flow_i(p_obj t_flow) return agroup_data%rowtype
is
begin
  ------------------------------
  return frp_type2row4flow0_i(p_obj, NULL);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_row2type4flow_i(p_row agroup_data%rowtype) return t_flow
is
  v_res t_flow;
begin
  ------------------------------
  v_res := flow_deserialize2(p_row.dsc);
  ------------------------------
  xcheck_t_flow(v_res);
  ------------------------------
  v_res.flow_id := p_row.agroup_data_id;
  --!_!c_agroup_id_fastp_flows := v_res.agroup_id;
  --!_!v_res.parent_id := p_row.id1;
  ------------------------------
  v_res.status_id := p_row.id2;
  v_res.flow_type_id := p_row.num3;
  ------------------------------
  v_res.last_date := p_row.date1; --!_!
  --!_!v_res.user_id := p_row.user_id; --!_!use user_id from p_row.dsc
  ------------------------------
  v_res.context := p_row.str2;
  ------------------------------
  --!_!v_res.tasks := ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_t_job1
(
  --!_!initial
  --!_!p_job_id number,
  --!_!p_parent_id number,
  p_user_id number,
  p_status_id number,
  p_command_id number,
  --!_!p_last_date date,
  --!_!submitted
  p_sys_job_id number,
  --!_!internal
  p_retry_count number,
  p_retry_interval_sec number,
  p_idle_sleep_time_sec number,
  p_expired_timeout_sec number,
  p_wait_lock_sec number,
  p_keepalive_sec number,
  --!_!p_error_id number,
  --!_!p_error_message clob,
  p_job_text clob,
  p_context clob
) return t_job
is
  v_res t_job;
begin
  ------------------------------
  --!_!initial
  v_res.job_id := frp_acquire_id;
  v_res.parent_id := NULL; --!_!p_parent_id
  v_res.user_id := p_user_id;
  v_res.status_id := p_status_id;
  v_res.command_id := p_command_id;
  v_res.last_date := sysdate; --!_!p_last_date
  --!_!submitted
  v_res.sys_job_id := p_sys_job_id;
  --!_!internal
  v_res.retry_count := p_retry_count;
  v_res.retry_interval_sec := p_retry_interval_sec;
  v_res.idle_sleep_time_sec := p_idle_sleep_time_sec;
  v_res.expired_timeout_sec := p_expired_timeout_sec;
  v_res.wait_lock_sec := p_wait_lock_sec;
  v_res.keepalive_sec := p_keepalive_sec;
  v_res.work_is_done := false;
  util_pkg.set_ok(v_res.error_id, v_res.error_message);
  v_res.job_text := p_job_text;
  v_res.context := p_context;
  ------------------------------
  xcheck_t_job(p_obj => v_res, p_check_parent => FALSE);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_t_job2
(
  p_user_id number,
  p_retry_count number,
  p_retry_interval_sec number,
  p_idle_sleep_time_sec number,
  p_expired_timeout_sec number,
  p_wait_lock_sec number,
  p_keepalive_sec number,
  p_job_text clob,
  p_context clob
) return t_job
is
begin
  ------------------------------
  return make_t_job1
  (
    p_user_id => p_user_id,
    p_status_id => c_stat_new,
    p_command_id => c_jcmd_empty,
    p_sys_job_id => NULL,
    p_retry_count => p_retry_count,
    p_retry_interval_sec => p_retry_interval_sec,
    p_idle_sleep_time_sec => p_idle_sleep_time_sec,
    p_expired_timeout_sec => p_expired_timeout_sec,
    p_wait_lock_sec => p_wait_lock_sec,
    p_keepalive_sec => p_keepalive_sec,
    p_job_text => p_job_text,
    p_context => p_context
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_t_task
(
  --!_!p_task_id number,
  --!_!p_parent_id number,
  p_user_id number,
  p_completion_rule number,
  p_retry_count number,
  p_retry_interval_sec number,
  p_wait_all_jobs_completion boolean,
  p_sync_commit boolean,
  p_idle_sleep_time_sec number,
  p_expired_timeout_sec number,
  p_wait_lock_sec number,
  p_context clob,
  p_jobs cit_job,
  p_set_childs_parent boolean
) return t_task
is
  v_res t_task;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_set_childs_parent is null, 'p_set_childs_parent');
  ------------------------------
  v_res.task_id := frp_acquire_id;
  v_res.parent_id := NULL; --!_!p_parent_id
  v_res.user_id := p_user_id;
  v_res.status_id := c_stat_new;
  v_res.completion_rule := p_completion_rule;
  v_res.last_date := sysdate; --!_!p_last_date
  v_res.retry_count := p_retry_count;
  v_res.retry_interval_sec := p_retry_interval_sec;
  v_res.actual_try_count := try_count_init;
  v_res.wait_all_jobs_completion := p_wait_all_jobs_completion;
  v_res.sync_commit := p_sync_commit;
  v_res.idle_sleep_time_sec := p_idle_sleep_time_sec;
  v_res.expired_timeout_sec := p_expired_timeout_sec;
  v_res.wait_lock_sec := p_wait_lock_sec;
  v_res.work_is_done := false;
  util_pkg.set_ok(v_res.error_id, v_res.error_message);
  v_res.context := p_context;
  v_res.jobs := p_jobs;
  ------------------------------
  if p_set_childs_parent
  then
    ------------------------------
    v_res.jobs := jobs_set_parent(p_objs => v_res.jobs, p_parent_id => v_res.task_id);
    ------------------------------
  end if;
  ------------------------------
  xcheck_t_task(p_obj => v_res, p_check_parent => FALSE);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_t_flow
(
  --!_!p_flow_id number,
  --!_!p_parent_id number,
  p_user_id number,
  p_flow_type_id number,
  p_reversible boolean,
  p_direction_forward boolean,
  p_retry_count number,
  p_retry_interval_sec number,
  p_wait_lock_sec number,
  p_context clob,
  p_tasks cit_task,
  p_set_childs_parent boolean
) return t_flow
is
  v_res t_flow;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_set_childs_parent is null, 'p_set_childs_parent');
  ------------------------------
  v_res.flow_id := frp_acquire_id;
  --!_!v_res.parent_id := NULL; --!_!p_parent_id
  v_res.user_id := p_user_id;
  v_res.status_id := c_stat_new;
  v_res.flow_type_id := p_flow_type_id;
  v_res.reversible := p_reversible;
  v_res.direction_forward := p_direction_forward;
  v_res.last_date := sysdate; --!_!p_last_date
  v_res.retry_count := p_retry_count;
  v_res.retry_interval_sec := p_retry_interval_sec;
  v_res.actual_try_count := try_count_init;
  v_res.wait_lock_sec := p_wait_lock_sec;
  v_res.work_is_done := false;
  util_pkg.set_ok(v_res.error_id, v_res.error_message);
  v_res.context := p_context;
  v_res.tasks := p_tasks;
  ------------------------------
  if p_set_childs_parent
  then
    ------------------------------
    v_res.tasks := tasks_set_parent(p_objs => v_res.tasks, p_parent_id => v_res.flow_id);
    ------------------------------
  end if;
  ------------------------------
  xcheck_t_flow(p_obj => v_res);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function frp_object_is_identified(p_row agroup_data%rowtype) return boolean
is
begin
  ------------------------------
  return vp_agroup_data.is_identified(p_rec => p_row);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_acquire_id return number
is
begin
  ------------------------------
  return vp_agroup_data.acquire_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_object_get_i(p_object_id number, p_date date, p_x_raise boolean, p_lock boolean, p_wait_lock_sec number) return agroup_data%rowtype
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_object_id is null, 'p_object_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_x_raise is null, 'p_x_raise');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait_lock_sec is null, 'p_wait_lock_sec');
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_x_raise
    then
      ------------------------------
      return vp_agroup_data.xlock_wait_xget1(p_id => p_object_id, p_date => p_date, p_wait_sec => p_wait_lock_sec);
      ------------------------------
    else
      ------------------------------
      return vp_agroup_data.xlock_wait_get1(p_id => p_object_id, p_date => p_date, p_wait_sec => p_wait_lock_sec);
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    if p_x_raise
    then
      ------------------------------
      return vp_agroup_data.xget1(p_id => p_object_id, p_date => p_date);
      ------------------------------
    else
      ------------------------------
      return vp_agroup_data.get1(p_id => p_object_id, p_date => p_date);
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_object_pget_id1_i(p_parent_id number, p_id1 number, p_date date, p_x_raise boolean, p_lock boolean, p_wait_lock_sec number) return agroup_data%rowtype
is
  v_row agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_parent_id is null, 'p_parent_id');
  util_pkg.XCheck_Cond_Missing(p_id1 is null, 'p_id1');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_x_raise is null, 'p_x_raise');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait_lock_sec is null, 'p_wait_lock_sec');
  ------------------------------
  if p_x_raise
  then
    ------------------------------
    v_row := vp_agroup_data.xpget1_id1(p_pid => p_parent_id, p_id1 => p_id1, p_date => p_date);
    ------------------------------
  else
    ------------------------------
    v_row := vp_agroup_data.pget1_id1(p_pid => p_parent_id, p_id1 => p_id1, p_date => p_date);
    ------------------------------
    if not vp_agroup_data.is_identified(v_row)
    then
      ------------------------------
      return null;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  if not p_lock
  then
    ------------------------------
    return v_row;
    ------------------------------
  end if;
  ------------------------------
  return frp_object_get_i(p_object_id => v_row.agroup_data_id, p_date => p_date, p_x_raise => p_x_raise, p_lock => TRUE, p_wait_lock_sec => p_wait_lock_sec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_object_xget(p_object_id number, p_date date) return agroup_data%rowtype
is
begin
  ------------------------------
  return frp_object_get_i(p_object_id => p_object_id, p_date => p_date, p_x_raise => TRUE, p_lock => FALSE, p_wait_lock_sec => c_dummy_wait_lock_sec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_object_xlock_xget(p_object_id number, p_wait_lock_sec number) return agroup_data%rowtype
is
begin
  ------------------------------
  return frp_object_get_i(p_object_id => p_object_id, p_date => sysdate, p_x_raise => TRUE, p_lock => TRUE, p_wait_lock_sec => p_wait_lock_sec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_object_lock_pget_id1(p_parent_id number, p_id1 number, p_wait_lock_sec number) return agroup_data%rowtype
is
begin
  ------------------------------
  return frp_object_pget_id1_i(p_parent_id => p_parent_id, p_id1 => p_id1, p_x_raise => FALSE, p_date => sysdate, p_lock => TRUE, p_wait_lock_sec => p_wait_lock_sec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure frp_object_set(p_row agroup_data%rowtype)
is
  v_row agroup_data%rowtype;
begin
  ------------------------------
  v_row := p_row;
  ------------------------------
  vp_agroup_data.version_touch(p_rec => v_row, p_unq_mode => c_frp_unq_mode);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_object_create(p_row agroup_data%rowtype) return agroup_data%rowtype
is
  v_res agroup_data%rowtype;
begin
  ------------------------------
  v_res := p_row;
  ------------------------------
  vp_agroup_data.version_open(p_rec => v_res, p_unq_mode => c_frp_unq_mode);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure frp_object_create2(p_row agroup_data%rowtype)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_object_create(p_row => p_row).agroup_data_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure frp_object_change(p_row agroup_data%rowtype)
is
  v_row agroup_data%rowtype;
begin
  ------------------------------
  v_row := p_row;
  ------------------------------
  vp_agroup_data.version_change(p_rec => v_row, p_unq_mode => c_frp_unq_mode);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_objects_count(p_objects vp_agroup_data.rct_agroup_data) return number
is
begin
  ------------------------------
  return vp_agroup_data.get_count_rct_agroup_data(p_objects);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_objects_get_by_type(p_type_id number, p_date date) return vp_agroup_data.rct_agroup_data
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_type_id is null, 'p_type_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  return vp_agroup_data.cast_ct2rct_agroup_data(vp_agroup_data.getN(p_pid => p_type_id, p_date => p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_objects_get_by_id(p_type_id number, p_obj_ids ct_number, p_date date) return vp_agroup_data.rct_agroup_data
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_type_id is null, 'p_type_id');
  util_pkg.XCheckP_FS_ct_number(p_obj_ids, 'p_obj_ids');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  return vp_agroup_data.cast_ct2rct_agroup_data(vp_agroup_data.xgetN_id(p_pid => p_type_id, p_id => p_obj_ids, p_date => p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_objects_get_by_parent(p_type_id number, p_parent_id number, p_date date) return vp_agroup_data.rct_agroup_data
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_type_id is null, 'p_type_id');
  util_pkg.XCheck_Cond_Missing(p_parent_id is null, 'p_parent_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  return vp_agroup_data.cast_ct2rct_agroup_data(vp_agroup_data.xgetN2_id1(p_pid => p_type_id, p_id1 => p_parent_id, p_date => p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_objects_get_by_status(p_type_id number, p_status_ids ct_number, p_date date) return vp_agroup_data.rct_agroup_data
is
  v_res ct_agroup_data;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_type_id is null, 'p_type_id');
  util_pkg.XCheckP_FS_ct_number(p_status_ids, 'p_status_ids');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select
    ot_agroup_data
    (
      agroup_data_id => agroup_data_id,
      agroup_id => agroup_id,
      id1 => id1,
      id2 => id2,
      date_from => date_from,
      date_to => date_to,
      user_id => user_id,
      change_date => change_date,
      dsc => dsc,
      date1 => date1,
      num3 => num3,
      str2 => str2
    ) val
  bulk collect into
    v_res
  from table(vp_agroup_data.xgetN1_id2(p_pid => p_type_id, p_id2 => p_status_ids, p_date => p_date))
  where 1 = 1
    and agroup_data_id is not null
  order by agroup_data_id, date_from
  ;
  ------------------------------
  return vp_agroup_data.cast_ct2rct_agroup_data(v_res);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_objects_get_by_status2(p_type_id number, p_status_id number, p_date date) return vp_agroup_data.rct_agroup_data
is
  v_status_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_status_id is null, 'p_status_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_status_ids, p_status_id);
  ------------------------------
  return frp_objects_get_by_status(p_type_id => p_type_id, p_status_ids => v_status_ids, p_date => p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function frp_object_context_get(p_object_id number) return clob
is
begin
  ------------------------------
  return frp_row2type4context_i(frp_object_xget(p_object_id => p_object_id, p_date => sysdate));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure frp_object_context_set(p_object_id number, p_context clob, p_wait_lock_sec number)
is
  v_row agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_object_id is null, 'p_object_id');
  ------------------------------
  v_row := frp_object_xlock_xget(p_object_id => p_object_id, p_wait_lock_sec => p_wait_lock_sec);
  ------------------------------
  frp_object_set(p_row => frp_type2row4context_i(p_context => p_context, p_row_template => v_row));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function frp_job_get(p_job_id number, p_date date) return t_job
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_job_id is null, 'p_job_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  return frp_row2type4job_i(frp_object_xget(p_object_id => p_job_id, p_date => p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_job_get2(p_job_id number) return t_job
is
begin
  ------------------------------
  return frp_job_get(p_job_id => p_job_id, p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_jobs_get_i(p_job_ids ct_number, p_date date) return cit_job
is
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_job_ids, 'p_job_ids');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  return cast_ct_row2type4job(frp_objects_get_by_id(p_type_id => c_agroup_id_fastp_jobs, p_obj_ids => p_job_ids, p_date => p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_jobs_get2_i(p_job_ids ct_number) return cit_job
is
begin
  ------------------------------
  return frp_jobs_get_i(p_job_ids => p_job_ids, p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_jobs_childs_get_i(p_jobs cit_job, p_date date) return cit_job
is
begin
  ------------------------------
  util_loc_pkg.touch_date(p_date);
  ------------------------------
  return p_jobs;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_jobs_get(p_job_ids ct_number, p_date date) return cit_job
is
begin
  ------------------------------
  return frp_jobs_childs_get_i(p_jobs => frp_jobs_get_i(p_job_ids => p_job_ids, p_date => p_date), p_date => p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_jobs_get2(p_job_ids ct_number) return cit_job
is
begin
  ------------------------------
  return frp_jobs_get(p_job_ids => p_job_ids, p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_jobs_pget(p_task_id number, p_date date) return cit_job
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_task_id is null, 'p_task_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  return frp_jobs_childs_get_i(p_jobs => cast_ct_row2type4job(frp_objects_get_by_parent(p_type_id => c_agroup_id_fastp_jobs, p_parent_id => p_task_id, p_date => p_date)), p_date => p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_jobs_pget2(p_task_id number) return cit_job
is
begin
  ------------------------------
  return frp_jobs_pget(p_task_id => p_task_id, p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_task_get(p_task_id number, p_date date) return t_task
is
  v_res t_task;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_task_id is null, 'p_task_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_res := frp_row2type4task_i(frp_object_xget(p_object_id => p_task_id, p_date => p_date));
  ------------------------------
  v_res.jobs := frp_jobs_pget(p_task_id => p_task_id, p_date => p_date);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_task_get2(p_task_id number) return t_task
is
begin
  ------------------------------
  return frp_task_get(p_task_id => p_task_id, p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_tasks_get_i(p_task_ids ct_number, p_date date) return cit_task
is
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_task_ids, 'p_task_ids');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  return cast_ct_row2type4task(frp_objects_get_by_id(p_type_id => c_agroup_id_fastp_tasks, p_obj_ids => p_task_ids, p_date => p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_tasks_get2_i(p_task_ids ct_number) return cit_task
is
begin
  ------------------------------
  return frp_tasks_get_i(p_task_ids => p_task_ids, p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_tasks_childs_get_i(p_tasks cit_task, p_date date) return cit_task
is
  v_res cit_task;
  v_count number;
begin
  ------------------------------
  v_res := p_tasks;
  ------------------------------
  v_count := get_count_cit_task(p_tasks);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_res(v_i).jobs := frp_jobs_pget(p_task_id => p_tasks(v_i).task_id, p_date => p_date);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_tasks_get(p_task_ids ct_number, p_date date) return cit_task
is
begin
  ------------------------------
  return frp_tasks_childs_get_i(p_tasks => frp_tasks_get_i(p_task_ids => p_task_ids, p_date => p_date), p_date => p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_tasks_get2(p_task_ids ct_number) return cit_task
is
begin
  ------------------------------
  return frp_tasks_get(p_task_ids => p_task_ids, p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_tasks_pget(p_flow_id number, p_date date) return cit_task
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_flow_id is null, 'p_flow_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  return frp_tasks_childs_get_i(p_tasks => cast_ct_row2type4task(frp_objects_get_by_parent(p_type_id => c_agroup_id_fastp_tasks, p_parent_id => p_flow_id, p_date => p_date)), p_date => p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_tasks_pget2(p_flow_id number) return cit_task
is
begin
  ------------------------------
  return frp_tasks_pget(p_flow_id => p_flow_id, p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flow_get(p_flow_id number, p_date date) return t_flow
is
  v_res t_flow;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_flow_id is null, 'p_flow_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_res := frp_row2type4flow_i(frp_object_xget(p_object_id => p_flow_id, p_date => p_date));
  ------------------------------
  v_res.tasks := frp_tasks_pget(p_flow_id => p_flow_id, p_date => p_date);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flow_get2(p_flow_id number) return t_flow
is
begin
  ------------------------------
  return frp_flow_get(p_flow_id => p_flow_id, p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flows_get_i(p_flow_ids ct_number, p_date date) return cit_flow
is
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_flow_ids, 'p_flow_ids');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  return cast_ct_row2type4flow(frp_objects_get_by_id(p_type_id => c_agroup_id_fastp_flows, p_obj_ids => p_flow_ids, p_date => p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flows_get2_i(p_flow_ids ct_number) return cit_flow
is
begin
  ------------------------------
  return frp_flows_get_i(p_flow_ids => p_flow_ids, p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flows_childs_get_i(p_flows cit_flow, p_date date) return cit_flow
is
  v_res cit_flow;
  v_count number;
begin
  ------------------------------
  v_res := p_flows;
  ------------------------------
  v_count := get_count_cit_flow(p_flows);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_res(v_i).tasks := frp_tasks_pget(p_flow_id => p_flows(v_i).flow_id, p_date => p_date);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flows_get(p_flow_ids ct_number, p_date date) return cit_flow
is
begin
  ------------------------------
  return frp_flows_childs_get_i(p_flows => frp_flows_get_i(p_flow_ids => p_flow_ids, p_date => p_date), p_date => p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flows_get2(p_flow_ids ct_number) return cit_flow
is
begin
  ------------------------------
  return frp_flows_get(p_flow_ids => p_flow_ids, p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flows_pget(p_date date) return cit_flow
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  return frp_flows_childs_get_i(p_flows => cast_ct_row2type4flow(frp_objects_get_by_type(p_type_id => c_agroup_id_fastp_flows, p_date => p_date)), p_date => p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flows_pget2 return cit_flow
is
begin
  ------------------------------
  return frp_flows_pget(p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flows_pget_by_status(p_status_ids ct_number, p_date date) return cit_flow
is
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_status_ids, 'p_status_ids');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  return frp_flows_childs_get_i(p_flows => cast_ct_row2type4flow(frp_objects_get_by_status(p_type_id => c_agroup_id_fastp_flows, p_status_ids => p_status_ids, p_date => p_date)), p_date => p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flows_pget_by_status2(p_status_ids ct_number) return cit_flow
is
begin
  ------------------------------
  return frp_flows_pget_by_status(p_status_ids => p_status_ids, p_date => sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure frp_log(p_log_type_id number, p_log_object_id number, p_user_id number, p_result_id number, p_result_message clob)
is
  v_row agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_log_type_id is null, 'p_log_type_id');
  util_pkg.XCheck_Cond_Missing(p_log_object_id is null, 'p_log_object_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_row := frp_object_lock_pget_id1(p_parent_id => p_log_type_id, p_id1 => p_log_object_id, p_wait_lock_sec => c_log_wait_lock_sec);
  ------------------------------
  if frp_object_is_identified(p_row => v_row)
  then
    ------------------------------
    v_row := frp_type2row4log_i(p_user_id => p_user_id, p_result_id => p_result_id, p_result_message => p_result_message, p_row_template => v_row);
    ------------------------------
    frp_object_change(p_row => v_row);
    ------------------------------
  else
    ------------------------------
    v_row := frp_type2row4log0_i(p_log_type_id => p_log_type_id, p_log_object_id => p_log_object_id, p_user_id => p_user_id, p_result_id => p_result_id, p_result_message => p_result_message);
    ------------------------------
    frp_object_create2(p_row => v_row);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure frp_log_job(p_job_id number, p_user_id number, p_result_id number, p_result_message clob)
is
begin
  ------------------------------
  frp_log(p_log_type_id => c_agroup_id_fastp_log_job, p_log_object_id => p_job_id, p_user_id => p_user_id, p_result_id => p_result_id, p_result_message => p_result_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure frp_log_job_smart(p_job_id number, p_user_id number, p_result_id number, p_result_message clob)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_result_id is null, 'p_result_id');
  ------------------------------
  if 1 = 0
    or (1 = 1
      and util_pkg.is_error(p_result_id)
      and install_pkg.nnget_option_bool(c_opt_fastp_log_job_errors, c_def_fastp_log_job_errors)
    )
    or install_pkg.nnget_option_bool(c_opt_fastp_log_job_results, c_def_fastp_log_job_results)
  then
    ------------------------------
    frp_log_job(p_job_id => p_job_id, p_user_id => p_user_id, p_result_id => p_result_id, p_result_message => p_result_message);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure frp_log_task(p_task_id number, p_user_id number, p_result_id number, p_result_message clob)
is
begin
  ------------------------------
  frp_log(p_log_type_id => c_agroup_id_fastp_log_task, p_log_object_id => p_task_id, p_user_id => p_user_id, p_result_id => p_result_id, p_result_message => p_result_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure frp_log_task_smart(p_task_id number, p_user_id number, p_result_id number, p_result_message clob)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_result_id is null, 'p_result_id');
  ------------------------------
  if 1 = 0
    or (1 = 1
      and util_pkg.is_error(p_result_id)
      and install_pkg.nnget_option_bool(c_opt_fastp_log_task_errors, c_def_fastp_log_task_errors)
    )
    or install_pkg.nnget_option_bool(c_opt_fastp_log_task_results, c_def_fastp_log_task_results)
  then
    ------------------------------
    frp_log_task(p_task_id => p_task_id, p_user_id => p_user_id, p_result_id => p_result_id, p_result_message => p_result_message);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure frp_log_flow(p_flow_id number, p_user_id number, p_result_id number, p_result_message clob)
is
begin
  ------------------------------
  frp_log(p_log_type_id => c_agroup_id_fastp_log_flow, p_log_object_id => p_flow_id, p_user_id => p_user_id, p_result_id => p_result_id, p_result_message => p_result_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure frp_log_flow_smart(p_flow_id number, p_user_id number, p_result_id number, p_result_message clob)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_result_id is null, 'p_result_id');
  ------------------------------
  if 1 = 0
    or (1 = 1
      and util_pkg.is_error(p_result_id)
      and install_pkg.nnget_option_bool(c_opt_fastp_log_flow_errors, c_def_fastp_log_flow_errors)
    )
    or install_pkg.nnget_option_bool(c_opt_fastp_log_flow_results, c_def_fastp_log_flow_results)
  then
    ------------------------------
    frp_log_flow(p_flow_id => p_flow_id, p_user_id => p_user_id, p_result_id => p_result_id, p_result_message => p_result_message);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure frp_job_set(p_obj t_job, p_force_status boolean)
is
  v_row agroup_data%rowtype;
begin
  ------------------------------
  xcheck_t_job(p_obj);
  util_pkg.XCheck_Cond_Missing(p_force_status is null, 'p_force_status');
  ------------------------------
  v_row := frp_object_xlock_xget(p_object_id => p_obj.job_id, p_wait_lock_sec => p_obj.wait_lock_sec);
  ------------------------------
  if not p_force_status
  then
    ------------------------------
    xcheck_status_changeable4job(p_status_id_old => frp_row2type4job_i(v_row).status_id, p_status_id_new => p_obj.status_id);
    ------------------------------
  end if;
  ------------------------------
  v_row := frp_type2row4job0_i(p_obj => p_obj, p_row_template => v_row);
  ------------------------------
  frp_object_set(p_row => v_row);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_job_set_status(p_obj t_job, p_status_id number, p_force boolean) return t_job
is
  v_res t_job;
begin
  ------------------------------
  xcheck_status4job(p_job_status_id => p_status_id);
  ------------------------------
  v_res := p_obj;
  ------------------------------
  v_res.status_id := p_status_id;
  ------------------------------
  frp_job_set(p_obj => v_res, p_force_status => p_force);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_job_set_status_ext(p_obj t_job, p_status_id number, p_error_id number, p_error_message clob, p_force boolean) return t_job
is
  v_res t_job;
begin
  ------------------------------
  xcheck_status4job(p_job_status_id => p_status_id);
  util_pkg.XCheck_Cond_Missing(p_error_id is null, 'p_error_id');
  util_pkg.XCheck_Cond_Missing(p_error_message is null, 'p_error_message');
  ------------------------------
  v_res := p_obj;
  ------------------------------
  v_res.status_id := p_status_id;
  v_res.error_id := p_error_id;
  v_res.error_message := p_error_message;
  ------------------------------
  frp_job_set(p_obj => v_res, p_force_status => p_force);
  ------------------------------
  frp_log_job_smart(p_job_id => p_obj.job_id, p_user_id => p_obj.user_id, p_result_id => p_error_id, p_result_message => p_error_message);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_job_set_work_is_done(p_obj t_job, p_work_is_done boolean) return t_job
is
  v_res t_job;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_work_is_done is null, 'p_work_is_done');
  ------------------------------
  v_res := p_obj;
  ------------------------------
  v_res.work_is_done := p_work_is_done;
  ------------------------------
  frp_job_set(p_obj => v_res, p_force_status => false);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_job_set_keepalive(p_obj t_job) return t_job
is
  v_res t_job;
begin
  ------------------------------
  v_res := p_obj;
  ------------------------------
  frp_job_set(p_obj => v_res, p_force_status => false);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_job_set_command(p_obj t_job, p_command_id number) return t_job
is
  v_res t_job;
begin
  ------------------------------
  xcheck_command(p_command_id);
  ------------------------------
  v_res := p_obj;
  ------------------------------
  v_res.command_id := p_command_id;
  ------------------------------
  frp_job_set(p_obj => v_res, p_force_status => false);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_job_clear_command(p_obj t_job) return t_job
is
begin
  ------------------------------
  return frp_job_set_command(p_obj => p_obj, p_command_id => c_jcmd_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_job_create_i(p_obj t_job) return t_job
is
begin
  ------------------------------
  xcheck_t_job(p_obj);
  ------------------------------
  return frp_row2type4job_i(frp_object_create(p_row => frp_type2row4job_i(p_obj)));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure frp_job_create(p_obj t_job)
is
  v_job t_job;
begin
  ------------------------------
  v_job := frp_job_create_i(p_obj);
  ------------------------------
  util_loc_pkg.touch_number(v_job.job_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure frp_task_set(p_obj t_task, p_force_status boolean)
is
  v_row agroup_data%rowtype;
begin
  ------------------------------
  xcheck_t_task(p_obj);
  util_pkg.XCheck_Cond_Missing(p_force_status is null, 'p_force_status');
  ------------------------------
  v_row := frp_object_xlock_xget(p_object_id => p_obj.task_id, p_wait_lock_sec => p_obj.wait_lock_sec);
  ------------------------------
  if not p_force_status
  then
    ------------------------------
    xcheck_status_changeable4task(p_status_id_old => frp_row2type4task_i(v_row).status_id, p_status_id_new => p_obj.status_id);
    ------------------------------
  end if;
  ------------------------------
  v_row := frp_type2row4task0_i(p_obj => p_obj, p_row_template => v_row);
  ------------------------------
  frp_object_set(p_row => v_row);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_task_set_status(p_obj t_task, p_status_id number, p_force boolean) return t_task
is
  v_res t_task;
begin
  ------------------------------
  xcheck_status4task(p_task_status_id => p_status_id);
  ------------------------------
  v_res := p_obj;
  ------------------------------
  v_res.status_id := p_status_id;
  ------------------------------
  frp_task_set(p_obj => v_res, p_force_status => p_force);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_task_set_status_ext(p_obj t_task, p_status_id number, p_error_id number, p_error_message clob, p_force boolean) return t_task
is
  v_res t_task;
begin
  ------------------------------
  xcheck_status4task(p_task_status_id => p_status_id);
  util_pkg.XCheck_Cond_Missing(p_error_id is null, 'p_error_id');
  util_pkg.XCheck_Cond_Missing(p_error_message is null, 'p_error_message');
  ------------------------------
  v_res := p_obj;
  ------------------------------
  v_res.status_id := p_status_id;
  v_res.error_id := p_error_id;
  v_res.error_message := p_error_message;
  ------------------------------
  frp_task_set(p_obj => v_res, p_force_status => p_force);
  ------------------------------
  frp_log_task_smart(p_task_id => p_obj.task_id, p_user_id => p_obj.user_id, p_result_id => p_error_id, p_result_message => p_error_message);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_task_inc_actual_try_count(p_obj t_task, p_error_id number, p_error_message clob) return t_task
is
  v_res t_task;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_error_id is null, 'p_error_id');
  util_pkg.XCheck_Cond_Missing(p_error_message is null, 'p_error_message');
  ------------------------------
  v_res := p_obj;
  ------------------------------
  try_count_increase(p_try_count => v_res.actual_try_count);
  v_res.error_id := p_error_id;
  v_res.error_message := p_error_message;
  ------------------------------
  frp_task_set(p_obj => v_res, p_force_status => false);
  ------------------------------
  frp_log_task_smart(p_task_id => p_obj.task_id, p_user_id => p_obj.user_id, p_result_id => p_error_id, p_result_message => p_error_message);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function jfrp_task_set_actual_try_count(p_obj t_task, p_actual_try_count number) return t_task
is
  v_res t_task;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_actual_try_count is null, 'p_actual_try_count');
  ------------------------------
  v_res := p_obj;
  ------------------------------
  v_res.actual_try_count := p_actual_try_count;
  ------------------------------
  frp_task_set(p_obj => v_res, p_force_status => false);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function ifrp_task_set_actual_try_count(p_obj t_task, p_actual_try_count number) return t_task
is
  v_task t_task;
  --!_!v_job_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_actual_try_count is null, 'p_actual_try_count');
  ------------------------------
  v_task := jfrp_task_set_actual_try_count(p_obj => p_obj, p_actual_try_count => p_actual_try_count);
  --!_!------------------------------
  --!_!v_task.jobs := p_obj.jobs; --!_!childs are not deserialized
  --!_!------------------------------
  --!_!v_job_count := get_count_cit_job(v_task.jobs);
  --!_!------------------------------
  --!_!for v_i in 1..v_job_count
  --!_!loop
  --!_!  ------------------------------
  --!_!  v_task.jobs(v_i) := ifrp_job_set_actual_try_count(p_obj => v_task.jobs(v_i), p_actual_try_count => p_actual_try_count);
  --!_!  ------------------------------
  --!_!end loop;
  ------------------------------
  return v_task;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_task_create_i(p_obj t_task) return t_task
is
begin
  ------------------------------
  xcheck_t_task(p_obj);
  ------------------------------
  return frp_row2type4task_i(frp_object_create(p_row => frp_type2row4task_i(p_obj)));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure frp_task_create(p_obj t_task)
is
  v_task t_task;
  v_job_count number;
begin
  ------------------------------
  v_task := frp_task_create_i(p_obj);
  ------------------------------
  v_task.jobs := p_obj.jobs; --!_!childs are not deserialized in frp_XXX_create_i
  ------------------------------
  v_job_count := get_count_cit_job(v_task.jobs);
  ------------------------------
  for v_i in 1..v_job_count
  loop
    ------------------------------
    frp_job_create(v_task.jobs(v_i));
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure frp_flow_set(p_obj t_flow, p_force_status boolean)
is
  v_row agroup_data%rowtype;
begin
  ------------------------------
  xcheck_t_flow(p_obj);
  util_pkg.XCheck_Cond_Missing(p_force_status is null, 'p_force_status');
  ------------------------------
  v_row := frp_object_xlock_xget(p_object_id => p_obj.flow_id, p_wait_lock_sec => p_obj.wait_lock_sec);
  ------------------------------
  if not p_force_status
  then
    ------------------------------
    xcheck_status_changeable4flow(p_status_id_old => frp_row2type4flow_i(v_row).status_id, p_status_id_new => p_obj.status_id);
    ------------------------------
  end if;
  ------------------------------
  v_row := frp_type2row4flow0_i(p_obj => p_obj, p_row_template => v_row);
  ------------------------------
  frp_object_set(p_row => v_row);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flow_set_status(p_obj t_flow, p_status_id number, p_force boolean) return t_flow
is
  v_res t_flow;
begin
  ------------------------------
  xcheck_status4flow(p_flow_status_id => p_status_id);
  ------------------------------
  v_res := p_obj;
  ------------------------------
  v_res.status_id := p_status_id;
  ------------------------------
  frp_flow_set(p_obj => v_res, p_force_status => p_force);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flow_set_status_ext(p_obj t_flow, p_status_id number, p_error_id number, p_error_message clob, p_force boolean) return t_flow
is
  v_res t_flow;
begin
  ------------------------------
  xcheck_status4flow(p_flow_status_id => p_status_id);
  util_pkg.XCheck_Cond_Missing(p_error_id is null, 'p_error_id');
  util_pkg.XCheck_Cond_Missing(p_error_message is null, 'p_error_message');
  ------------------------------
  v_res := p_obj;
  ------------------------------
  v_res.status_id := p_status_id;
  v_res.error_id := p_error_id;
  v_res.error_message := p_error_message;
  ------------------------------
  frp_flow_set(p_obj => v_res, p_force_status => p_force);
  ------------------------------
  frp_log_flow_smart(p_flow_id => p_obj.flow_id, p_user_id => p_obj.user_id, p_result_id => p_error_id, p_result_message => p_error_message);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flow_set_direction_forward(p_obj t_flow, p_direction_forward boolean) return t_flow
is
  v_res t_flow;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_direction_forward is null, 'p_direction_forward');
  ------------------------------
  v_res := p_obj;
  ------------------------------
  v_res.direction_forward := p_direction_forward;
  ------------------------------
  frp_flow_set(p_obj => v_res, p_force_status => false);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flow_inc_actual_try_count(p_obj t_flow, p_error_id number, p_error_message clob) return t_flow
is
  v_res t_flow;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_error_id is null, 'p_error_id');
  util_pkg.XCheck_Cond_Missing(p_error_message is null, 'p_error_message');
  ------------------------------
  v_res := p_obj;
  ------------------------------
  try_count_increase(p_try_count => v_res.actual_try_count);
  v_res.error_id := p_error_id;
  v_res.error_message := p_error_message;
  ------------------------------
  frp_flow_set(p_obj => v_res, p_force_status => false);
  ------------------------------
  frp_log_flow_smart(p_flow_id => p_obj.flow_id, p_user_id => p_obj.user_id, p_result_id => p_error_id, p_result_message => p_error_message);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function jfrp_flow_set_actual_try_count(p_obj t_flow, p_actual_try_count number) return t_flow
is
  v_res t_flow;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_actual_try_count is null, 'p_actual_try_count');
  ------------------------------
  v_res := p_obj;
  ------------------------------
  v_res.actual_try_count := p_actual_try_count;
  ------------------------------
  frp_flow_set(p_obj => v_res, p_force_status => false);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function ifrp_flow_set_actual_try_count(p_obj t_flow, p_actual_try_count number) return t_flow
is
  v_flow t_flow;
  v_task_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_actual_try_count is null, 'p_actual_try_count');
  ------------------------------
  v_flow := jfrp_flow_set_actual_try_count(p_obj => p_obj, p_actual_try_count => p_actual_try_count);
  ------------------------------
  v_flow.tasks := p_obj.tasks; --!_!childs are not deserialized
  ------------------------------
  v_task_count := get_count_cit_task(v_flow.tasks);
  ------------------------------
  for v_i in 1..v_task_count
  loop
    ------------------------------
    v_flow.tasks(v_i) := ifrp_task_set_actual_try_count(p_obj => v_flow.tasks(v_i), p_actual_try_count => p_actual_try_count);
    ------------------------------
  end loop;
  ------------------------------
  return v_flow;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function frp_flow_create_i(p_obj t_flow) return t_flow
is
begin
  ------------------------------
  xcheck_t_flow(p_obj);
  ------------------------------
  return frp_row2type4flow_i(frp_object_create(p_row => frp_type2row4flow_i(p_obj)));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure frp_flow_create(p_obj t_flow)
is
  v_flow t_flow;
  v_task_count number;
begin
  ------------------------------
  v_flow := frp_flow_create_i(p_obj);
  ------------------------------
  v_flow.tasks := p_obj.tasks; --!_!childs are not deserialized in frp_XXX_create_i
  ------------------------------
  v_task_count := get_count_cit_task(v_flow.tasks);
  ------------------------------
  for v_i in 1..v_task_count
  loop
    ------------------------------
    frp_task_create(v_flow.tasks(v_i));
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function job_submit(p_obj t_job) return t_job
is
  v_res t_job;
  v_job_text clob;
  v_sys_job_id number;
begin
  ------------------------------
  xcheck_t_job(p_obj);
  ------------------------------
  v_job_text := make_job_text(p_job_id => p_obj.job_id);
  ------------------------------
  dbms_job.submit
  (
    job => v_sys_job_id,
    what => v_job_text--!_!,
    --!_!next_date => util_pkg.c_plus_infinity --!_!job don't start when created
  );
  ------------------------------
  v_res := p_obj;
  v_res.sys_job_id := v_sys_job_id;
  ------------------------------
  frp_job_set(p_obj => v_res, p_force_status => false);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function jobs_submit(p_objs cit_job) return cit_job
is
  v_res cit_job;
  v_i number;
begin
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(get_count_cit_job(p_objs) = 0, 'p_objs.count = 0');
  ------------------------------
  v_i := p_objs.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_res(v_i) := job_submit(p_objs(v_i));
    ------------------------------
    v_i := p_objs.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function job_set_parent(p_obj t_job, p_parent_id number) return t_job
is
  v_res t_job;
begin
  ------------------------------
  --!_!xcheck_t_job(p_obj);
  util_pkg.XCheck_Cond_Missing(p_parent_id is null, 'p_parent_id');
  ------------------------------
  v_res := p_obj;
  ------------------------------
  v_res.parent_id := p_parent_id;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function jobs_set_parent(p_objs cit_job, p_parent_id number) return cit_job
is
  v_res cit_job;
  v_i number;
begin
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(get_count_cit_job(p_objs) = 0, 'p_objs.count = 0');
  util_pkg.XCheck_Cond_Missing(p_parent_id is null, 'p_parent_id');
  ------------------------------
  v_i := p_objs.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_res(v_i) := job_set_parent(p_obj => p_objs(v_i), p_parent_id => p_parent_id);
    ------------------------------
    v_i := p_objs.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function task_set_parent(p_obj t_task, p_parent_id number) return t_task
is
  v_res t_task;
begin
  ------------------------------
  --!_!xcheck_t_task(p_obj);
  util_pkg.XCheck_Cond_Missing(p_parent_id is null, 'p_parent_id');
  ------------------------------
  v_res := p_obj;
  ------------------------------
  v_res.parent_id := p_parent_id;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function tasks_set_parent(p_objs cit_task, p_parent_id number) return cit_task
is
  v_res cit_task;
  v_i number;
begin
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(get_count_cit_task(p_objs) = 0, 'p_objs.count = 0');
  util_pkg.XCheck_Cond_Missing(p_parent_id is null, 'p_parent_id');
  ------------------------------
  v_i := p_objs.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_res(v_i) := task_set_parent(p_obj => p_objs(v_i), p_parent_id => p_parent_id);
    ------------------------------
    v_i := p_objs.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_job_text(p_job_id number) return clob
is
  v_res clob;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_job_id is null, 'p_job_id');
  ------------------------------
  v_res := c_job_text;
  ------------------------------
  v_res := replace(v_res, ':p_this_package_name', c_this_package_name);
  v_res := replace(v_res, ':p_job_id', util_loc_pkg.wrap_number(p_job_id));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function job_wait_pickup_command
(
  p_job_id number,
  p_expired_timeout_sec number,
  p_idle_sleep_time_sec number
) return number
is
  v_res number := c_jcmd_empty;
  v_wait_start date;
  v_wait_start_keepalive date;
  v_job t_job;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_job_id is null, 'p_job_id');
  util_pkg.XCheck_Cond_Missing(p_expired_timeout_sec is null, 'p_expired_timeout_sec');
  util_pkg.XCheck_Cond_Missing(p_idle_sleep_time_sec is null, 'p_idle_sleep_time_sec');
  ------------------------------
  v_wait_start := sysdate;
  v_wait_start_keepalive := sysdate;
  ------------------------------
  loop
    ------------------------------
    v_job := job_get(p_job_id => p_job_id);
    ------------------------------
    xcheck_t_job(v_job);
    ------------------------------
    if v_job.command_id != c_jcmd_empty
    then
      ------------------------------
      v_res := v_job.command_id;
      ------------------------------
      at_job_clear_command(p_job_id => p_job_id);
      ------------------------------
      EXIT;
      ------------------------------
    end if;
    ------------------------------
    if util_pkg.seconds_from_date_dif(sysdate - v_wait_start_keepalive) > v_job.keepalive_sec
    then
      ------------------------------
      at_job_set_keepalive(p_job_id => p_job_id);
      ------------------------------
      v_wait_start_keepalive := sysdate;
      ------------------------------
    end if;
    ------------------------------
    if timer_is_timed_out_or_sleep(p_timeout_sec => p_expired_timeout_sec, p_start => v_wait_start, p_sleep_interval_sec => p_idle_sleep_time_sec)
    then
      ------------------------------
      v_res := c_jcmd_dummy_expiry;
      ------------------------------
      EXIT;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function wait_jobs_running
(
  p_job_ids ct_number,
  p_expired_timeout_sec number,
  p_idle_sleep_time_sec number,
  p_completion_rule number,
  p_for_running boolean
) return number
is
  v_res number := c_wait_result_ok;
  v_wait_start date;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_job_ids, 'p_job_ids');
  util_pkg.XCheck_Cond_Missing(p_expired_timeout_sec is null, 'p_expired_timeout_sec');
  util_pkg.XCheck_Cond_Missing(p_idle_sleep_time_sec is null, 'p_idle_sleep_time_sec');
  xcheck_completion_rule(p_completion_rule);
  util_pkg.XCheck_Cond_Missing(p_for_running is null, 'p_for_running');
  ------------------------------
  v_wait_start := sysdate;
  ------------------------------
  loop
    ------------------------------
    if jobs_are_running(p_job_ids => p_job_ids, p_completion_rule => p_completion_rule, p_for_running => p_for_running)
    then
      ------------------------------
      v_res := c_wait_result_ok;
      ------------------------------
      EXIT;
      ------------------------------
    end if;
    ------------------------------
    --!_!if !_!v_res := c_wait_result_break;
    ------------------------------
    if timer_is_timed_out_or_sleep(p_timeout_sec => p_expired_timeout_sec, p_start => v_wait_start, p_sleep_interval_sec => p_idle_sleep_time_sec)
    then
      ------------------------------
      v_res := c_wait_result_expiry;
      ------------------------------
      EXIT;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function wait_jobs_status
(
  p_job_ids ct_number,
  p_expired_timeout_sec number,
  p_idle_sleep_time_sec number,
  p_goal_status_ids ct_number,
  p_break_status_ids ct_number,
  p_goal_completion_rule number,
  p_break_completion_rule number
) return number
is
  v_res number := c_wait_result_ok;
  v_wait_start date;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_job_ids, 'p_job_ids');
  util_pkg.XCheck_Cond_Missing(p_expired_timeout_sec is null, 'p_expired_timeout_sec');
  util_pkg.XCheck_Cond_Missing(p_idle_sleep_time_sec is null, 'p_idle_sleep_time_sec');
  xcheck_statuses4job(p_job_status_ids => p_goal_status_ids, p_can_be_empty => false);
  xcheck_statuses4job(p_job_status_ids => p_break_status_ids, p_can_be_empty => true); --!_!
  xcheck_completion_rule(p_goal_completion_rule);
  xcheck_completion_rule(p_break_completion_rule);
  ------------------------------
  v_wait_start := sysdate;
  ------------------------------
  loop
    ------------------------------
    if jobs_has_status(p_job_ids, p_goal_status_ids, p_goal_completion_rule)
    then
      ------------------------------
      v_res := c_wait_result_ok;
      ------------------------------
      EXIT;
      ------------------------------
    end if;
    ------------------------------
    if 1 = 1
      and util_pkg.get_count_ct_number(p_break_status_ids) > 0
      and jobs_has_status(p_job_ids, p_break_status_ids, p_break_completion_rule)
    then
      ------------------------------
      v_res := c_wait_result_break;
      ------------------------------
      EXIT;
      ------------------------------
    end if;
    ------------------------------
    if timer_is_timed_out_or_sleep(p_timeout_sec => p_expired_timeout_sec, p_start => v_wait_start, p_sleep_interval_sec => p_idle_sleep_time_sec)
    then
      ------------------------------
      v_res := c_wait_result_expiry;
      ------------------------------
      EXIT;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function wait_jobs_status2
(
  p_job_ids ct_number,
  p_expired_timeout_sec number,
  p_idle_sleep_time_sec number,
  p_goal_status_ids ct_number,
  p_break_status_ids ct_number,
  p_goal_completion_rule number
) return number
is
begin
  ------------------------------
  return wait_jobs_status
  (
    p_job_ids => p_job_ids,
    p_expired_timeout_sec => p_expired_timeout_sec,
    p_idle_sleep_time_sec => p_idle_sleep_time_sec,
    p_goal_status_ids => p_goal_status_ids,
    p_break_status_ids => p_break_status_ids,
    p_goal_completion_rule => p_goal_completion_rule,
    p_break_completion_rule => get_break_completion_rule(p_goal_completion_rule => p_goal_completion_rule)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function wait_jobs_status3
(
  p_job_ids ct_number,
  p_expired_timeout_sec number,
  p_idle_sleep_time_sec number,
  p_goal_status_id number,
  p_break_status_ids ct_number,
  p_goal_completion_rule number
) return number
is
  v_goal_status_ids ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_goal_status_ids, p_goal_status_id);
  ------------------------------
  return wait_jobs_status2
  (
    p_job_ids => p_job_ids,
    p_expired_timeout_sec => p_expired_timeout_sec,
    p_idle_sleep_time_sec => p_idle_sleep_time_sec,
    p_goal_status_ids => v_goal_status_ids,
    p_break_status_ids => p_break_status_ids,
    p_goal_completion_rule => p_goal_completion_rule
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function activate_jobs(p_jobs cit_job) return cit_job
is
  v_res cit_job;
begin
  ------------------------------
  v_res := jobs_submit(p_jobs);
  ------------------------------
  xcheck_cit_job(v_res); --!_!trivial check
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function obj_has_value(p_obj_value number, p_goal_values ct_number, p_goal_can_be_empty boolean) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_goal_can_be_empty is null, 'p_goal_can_be_empty');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_obj_value is null, 'p_obj_value');
  ------------------------------
  if not p_goal_can_be_empty
  then
    ------------------------------
    util_pkg.XCheckP_ct_number(p_goal_values, 'p_goal_values');
    ------------------------------
  end if;
  ------------------------------
  return (util_pkg.index_of_ct_number(p_goal_values, p_obj_value) != util_pkg.c_index_not_found);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function objs_has_value_i(p_obj_values ct_number, p_goal_values ct_number, p_completion_rule number) return boolean
is
  v_res boolean;
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_obj_values, 'p_obj_values');
  util_pkg.XCheckP_FS_ct_number(p_goal_values, 'p_goal_values');
  xcheck_completion_rule(p_completion_rule);
  ------------------------------
  if p_completion_rule = c_cr_all
  then
    ------------------------------
    v_res := true;
    ------------------------------
  elsif p_completion_rule = c_cr_one
  then
    ------------------------------
    v_res := false;
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'completion_rule' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_completion_rule));
    ------------------------------
  end if;
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_obj_values);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if p_completion_rule = c_cr_all
    then
      ------------------------------
      if NOT obj_has_value(p_obj_value => p_obj_values(v_i), p_goal_values => p_goal_values, p_goal_can_be_empty => false)
      then
        ------------------------------
        v_res := FALSE;
        ------------------------------
        exit;
        ------------------------------
      end if;
      ------------------------------
    elsif p_completion_rule = c_cr_one
    then
      ------------------------------
      if obj_has_value(p_obj_value => p_obj_values(v_i), p_goal_values => p_goal_values, p_goal_can_be_empty => false)
      then
        ------------------------------
        v_res := TRUE;
        ------------------------------
        exit;
        ------------------------------
      end if;
      ------------------------------
    else
      ------------------------------
      util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'completion_rule' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_completion_rule));
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function objs_has_value2_i(p_obj_values ct_number, p_goal_value number, p_completion_rule number) return boolean
is
  v_goal_values ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_goal_value is null, 'p_goal_value');
  ------------------------------
  util_pkg.add_ct_number_val(v_goal_values, p_goal_value);
  ------------------------------
  return objs_has_value_i(p_obj_values => p_obj_values, p_goal_values => v_goal_values, p_completion_rule => p_completion_rule);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cnt_objs_has_value_i(p_obj_values ct_number, p_goal_values ct_number) return number
is
  v_res number;
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_obj_values, 'p_obj_values');
  util_pkg.XCheckP_FS_ct_number(p_goal_values, 'p_goal_values');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_obj_values);
  ------------------------------
  v_res := 0;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if obj_has_value(p_obj_value => p_obj_values(v_i), p_goal_values => p_goal_values, p_goal_can_be_empty => TRUE)
    then
      ------------------------------
      v_res := v_res + 1;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cnt_objs_has_value2_i(p_obj_values ct_number, p_goal_value number) return number
is
  v_goal_values ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_goal_value is null, 'p_goal_value');
  ------------------------------
  util_pkg.add_ct_number_val(v_goal_values, p_goal_value);
  ------------------------------
  return cnt_objs_has_value_i(p_obj_values => p_obj_values, p_goal_values => v_goal_values);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function job_has_status(p_job_status_id number, p_goal_status_ids ct_number) return boolean
is
begin
  ------------------------------
  xcheck_status4job(p_job_status_id => p_job_status_id);
  xcheck_statuses4job(p_job_status_ids => p_goal_status_ids, p_can_be_empty => false);
  ------------------------------
  return obj_has_value(p_obj_value => p_job_status_id, p_goal_values => p_goal_status_ids, p_goal_can_be_empty => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function job_has_status2(p_job t_job, p_goal_status_ids ct_number) return boolean
is
begin
  ------------------------------
  xcheck_t_job(p_obj => p_job);
  ------------------------------
  return job_has_status(p_job_status_id => p_job.status_id, p_goal_status_ids => p_goal_status_ids);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function job_has_status3(p_job_id number, p_goal_status_ids ct_number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_job_id is null, 'p_job_id');
  ------------------------------
  return job_has_status2(p_job => job_get(p_job_id => p_job_id), p_goal_status_ids => p_goal_status_ids);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function task_has_status(p_task_status_id number, p_goal_status_ids ct_number) return boolean
is
begin
  ------------------------------
  xcheck_status4task(p_task_status_id => p_task_status_id);
  xcheck_statuses4task(p_task_status_ids => p_goal_status_ids, p_can_be_empty => false);
  ------------------------------
  return obj_has_value(p_obj_value => p_task_status_id, p_goal_values => p_goal_status_ids, p_goal_can_be_empty => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function task_has_status2(p_task t_task, p_goal_status_ids ct_number) return boolean
is
begin
  ------------------------------
  xcheck_t_task(p_obj => p_task);
  ------------------------------
  return task_has_status(p_task_status_id => p_task.status_id, p_goal_status_ids => p_goal_status_ids);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function task_has_status3(p_task_id number, p_goal_status_ids ct_number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_task_id is null, 'p_task_id');
  ------------------------------
  return task_has_status2(p_task => task_get(p_task_id => p_task_id), p_goal_status_ids => p_goal_status_ids);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function flow_has_status(p_flow_status_id number, p_goal_status_ids ct_number) return boolean
is
begin
  ------------------------------
  xcheck_status4flow(p_flow_status_id => p_flow_status_id);
  xcheck_statuses4flow(p_flow_status_ids => p_goal_status_ids, p_can_be_empty => false);
  ------------------------------
  return obj_has_value(p_obj_value => p_flow_status_id, p_goal_values => p_goal_status_ids, p_goal_can_be_empty => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function flow_has_status2(p_flow t_flow, p_goal_status_ids ct_number) return boolean
is
begin
  ------------------------------
  xcheck_t_flow(p_obj => p_flow);
  ------------------------------
  return flow_has_status(p_flow_status_id => p_flow.status_id, p_goal_status_ids => p_goal_status_ids);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function flow_has_status3(p_flow_id number, p_goal_status_ids ct_number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_flow_id is null, 'p_flow_id');
  ------------------------------
  return flow_has_status2(p_flow => flow_get(p_flow_id => p_flow_id), p_goal_status_ids => p_goal_status_ids);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function jobs_has_status(p_job_ids ct_number, p_goal_status_ids ct_number, p_completion_rule number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_job_ids, 'p_job_ids');
  xcheck_statuses4job(p_job_status_ids => p_goal_status_ids, p_can_be_empty => false);
  xcheck_completion_rule(p_completion_rule);
  ------------------------------
  return objs_has_value_i(p_obj_values => extract_status_ids_cit_job(frp_jobs_get2_i(p_job_ids => p_job_ids)), p_goal_values => p_goal_status_ids, p_completion_rule => p_completion_rule);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function jobs_has_status2(p_job_ids ct_number, p_goal_status_id number, p_completion_rule number) return boolean
is
  v_goal_status_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_goal_status_id is null, 'p_goal_status_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_goal_status_ids, p_goal_status_id);
  ------------------------------
  return jobs_has_status(p_job_ids => p_job_ids, p_goal_status_ids => v_goal_status_ids, p_completion_rule => p_completion_rule);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function jobs_work_is_done2(p_job_ids ct_number, p_work_is_done boolean, p_completion_rule number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_job_ids, 'p_job_ids');
  util_pkg.XCheck_Cond_Missing(p_work_is_done is null, 'p_work_is_done');
  xcheck_completion_rule(p_completion_rule);
  ------------------------------
  return objs_has_value2_i(p_obj_values => extract_work_is_dones_cit_job(frp_jobs_get2_i(p_job_ids => p_job_ids)), p_goal_value => util_pkg.bool_to_int_2val(p_work_is_done), p_completion_rule => p_completion_rule);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function tasks_has_status(p_task_ids ct_number, p_goal_status_ids ct_number, p_completion_rule number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_task_ids, 'p_task_ids');
  xcheck_statuses4task(p_task_status_ids => p_goal_status_ids, p_can_be_empty => false);
  xcheck_completion_rule(p_completion_rule);
  ------------------------------
  return objs_has_value_i(p_obj_values => extract_status_ids_cit_task(frp_tasks_get2_i(p_task_ids => p_task_ids)), p_goal_values => p_goal_status_ids, p_completion_rule => p_completion_rule);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function tasks_has_status2(p_task_ids ct_number, p_goal_status_id number, p_completion_rule number) return boolean
is
  v_goal_status_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_goal_status_id is null, 'p_goal_status_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_goal_status_ids, p_goal_status_id);
  ------------------------------
  return tasks_has_status(p_task_ids => p_task_ids, p_goal_status_ids => v_goal_status_ids, p_completion_rule => p_completion_rule);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function flows_has_status(p_flow_ids ct_number, p_goal_status_ids ct_number, p_completion_rule number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_flow_ids, 'p_flow_ids');
  xcheck_statuses4flow(p_flow_status_ids => p_goal_status_ids, p_can_be_empty => false);
  xcheck_completion_rule(p_completion_rule);
  ------------------------------
  return objs_has_value_i(p_obj_values => extract_status_ids_cit_flow(frp_flows_get2_i(p_flow_ids => p_flow_ids)), p_goal_values => p_goal_status_ids, p_completion_rule => p_completion_rule);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function flows_has_status2(p_flow_ids ct_number, p_goal_status_id number, p_completion_rule number) return boolean
is
  v_goal_status_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_goal_status_id is null, 'p_goal_status_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_goal_status_ids, p_goal_status_id);
  ------------------------------
  return flows_has_status(p_flow_ids => p_flow_ids, p_goal_status_ids => v_goal_status_ids, p_completion_rule => p_completion_rule);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function jobs_are_running(p_job_ids ct_number, p_completion_rule number, p_for_running boolean) return boolean
is
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_job_ids, 'p_job_ids');
  xcheck_completion_rule(p_completion_rule);
  util_pkg.XCheck_Cond_Missing(p_for_running is null, 'p_for_running');
  ------------------------------
  return objs_has_value2_i
  (
    p_obj_values => get_jobs_running(p_sys_job_ids => extract_sys_job_ids_cit_job(frp_jobs_get2_i(p_job_ids => p_job_ids))),
    p_goal_value => util_pkg.bool_to_int_2val(p_for_running),
    p_completion_rule => p_completion_rule
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function object_context_get(p_object_id number) return clob
is
begin
  ------------------------------
  return frp_object_context_get(p_object_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure object_context_set(p_object_id number, p_context clob, p_wait_lock_sec number)
is
begin
  ------------------------------
  frp_object_context_set(p_object_id, p_context, p_wait_lock_sec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function job_get(p_job_id number) return t_job
is
begin
  ------------------------------
  return frp_job_get2(p_job_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function jobs_get(p_job_ids ct_number) return cit_job
is
begin
  ------------------------------
  return frp_jobs_get2(p_job_ids => p_job_ids);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function task_get(p_task_id number) return t_task
is
begin
  ------------------------------
  return frp_task_get2(p_task_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function tasks_get(p_task_ids ct_number) return cit_task
is
begin
  ------------------------------
  return frp_tasks_get2(p_task_ids => p_task_ids);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function flow_get(p_flow_id number) return t_flow
is
begin
  ------------------------------
  return frp_flow_get2(p_flow_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function flows_get(p_flow_ids ct_number) return cit_flow
is
begin
  ------------------------------
  return frp_flows_get2(p_flow_ids => p_flow_ids);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function flows_pget_active return cit_flow
is
begin
  ------------------------------
  return frp_flows_pget_by_status2(p_status_ids => get_interim_statuses4flow);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure save_flow(p_flow t_flow)
is
begin
  ------------------------------
  frp_flow_create(p_obj => p_flow);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure job_set_status(p_job_id number, p_status_id number)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_job_set_status(p_obj => job_get(p_job_id => p_job_id), p_status_id => p_status_id, p_force => false).job_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure job_set_status_ext(p_job_id number, p_status_id number, p_error_id number, p_error_message clob)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_job_set_status_ext(p_obj => job_get(p_job_id => p_job_id), p_status_id => p_status_id, p_error_id => p_error_id, p_error_message => p_error_message, p_force => false).job_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure job_set_status_force(p_job_id number, p_status_id number)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_job_set_status(p_obj => job_get(p_job_id => p_job_id), p_status_id => p_status_id, p_force => true).job_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure job_set_status_ext_force(p_job_id number, p_status_id number, p_error_id number, p_error_message clob)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_job_set_status_ext(p_obj => job_get(p_job_id => p_job_id), p_status_id => p_status_id, p_error_id => p_error_id, p_error_message => p_error_message, p_force => true).job_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure job_set_work_is_done(p_job_id number, p_work_is_done boolean)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_job_set_work_is_done(p_obj => job_get(p_job_id => p_job_id), p_work_is_done => p_work_is_done).job_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure job_set_keepalive(p_job_id number)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_job_set_keepalive(p_obj => job_get(p_job_id => p_job_id)).job_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure job_set_command(p_job_id number, p_command_id number)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_job_set_command(p_obj => job_get(p_job_id => p_job_id), p_command_id => p_command_id).job_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure jobs_set_command(p_job_ids ct_number, p_command_id number)
is
  v_count number;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_job_ids, 'p_job_ids');
  xcheck_command(p_command_id);
  ------------------------------
  v_count := util_pkg.get_count_ct_number(p_job_ids);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    util_loc_pkg.touch_number(frp_job_set_command(p_obj => job_get(p_job_id => p_job_ids(v_i)), p_command_id => p_command_id).job_id);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure job_clear_command(p_job_id number)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_job_clear_command(p_obj => job_get(p_job_id => p_job_id)).job_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure jobs_clear_command(p_job_ids ct_number)
is
  v_count number;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_job_ids, 'p_job_ids');
  ------------------------------
  v_count := util_pkg.get_count_ct_number(p_job_ids);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    job_clear_command(p_job_id => p_job_ids(v_i));
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure task_set_status(p_task_id number, p_status_id number)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_task_set_status(p_obj => task_get(p_task_id => p_task_id), p_status_id => p_status_id, p_force => false).task_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure task_set_status_ext(p_task_id number, p_status_id number, p_error_id number, p_error_message clob)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_task_set_status_ext(p_obj => task_get(p_task_id => p_task_id), p_status_id => p_status_id, p_error_id => p_error_id, p_error_message => p_error_message, p_force => false).task_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure task_set_status_force(p_task_id number, p_status_id number)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_task_set_status(p_obj => task_get(p_task_id => p_task_id), p_status_id => p_status_id, p_force => true).task_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure task_set_status_ext_force(p_task_id number, p_status_id number, p_error_id number, p_error_message clob)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_task_set_status_ext(p_obj => task_get(p_task_id => p_task_id), p_status_id => p_status_id, p_error_id => p_error_id, p_error_message => p_error_message, p_force => true).task_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure task_inc_actual_try_count(p_task_id number, p_error_id number, p_error_message clob)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_task_inc_actual_try_count(p_obj => task_get(p_task_id => p_task_id), p_error_id => p_error_id, p_error_message => p_error_message).task_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure flow_set_status(p_flow_id number, p_status_id number)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_flow_set_status(p_obj => flow_get(p_flow_id => p_flow_id), p_status_id => p_status_id, p_force => false).flow_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure flow_set_status_ext(p_flow_id number, p_status_id number, p_error_id number, p_error_message clob)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_flow_set_status_ext(p_obj => flow_get(p_flow_id => p_flow_id), p_status_id => p_status_id, p_error_id => p_error_id, p_error_message => p_error_message, p_force => false).flow_id);
  ------------------------------
end;


----------------------------------!---------------------------------------------
procedure flow_set_status_force(p_flow_id number, p_status_id number)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_flow_set_status(p_obj => flow_get(p_flow_id => p_flow_id), p_status_id => p_status_id, p_force => true).flow_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure flow_set_status_ext_force(p_flow_id number, p_status_id number, p_error_id number, p_error_message clob)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_flow_set_status_ext(p_obj => flow_get(p_flow_id => p_flow_id), p_status_id => p_status_id, p_error_id => p_error_id, p_error_message => p_error_message, p_force => true).flow_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure flow_set_direction_forward(p_flow_id number, p_direction_forward boolean)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_flow_set_direction_forward(p_obj => flow_get(p_flow_id => p_flow_id), p_direction_forward => p_direction_forward).flow_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure flow_inc_actual_try_count(p_flow_id number, p_error_id number, p_error_message clob)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(frp_flow_inc_actual_try_count(p_obj => flow_get(p_flow_id => p_flow_id), p_error_id => p_error_id, p_error_message => p_error_message).flow_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure iflow_set_actual_try_count(p_flow_id number, p_actual_try_count number)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(ifrp_flow_set_actual_try_count(p_obj => flow_get(p_flow_id => p_flow_id), p_actual_try_count => p_actual_try_count).flow_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure at_job_set_status(p_job_id number, p_status_id number)
is
pragma autonomous_transaction;
begin
  ------------------------------
  job_set_status(p_job_id => p_job_id, p_status_id => p_status_id);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_job_set_status_ext(p_job_id number, p_status_id number, p_error_id number, p_error_message clob)
is
pragma autonomous_transaction;
begin
  ------------------------------
  job_set_status_ext(p_job_id => p_job_id, p_status_id => p_status_id, p_error_id => p_error_id, p_error_message => p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_job_set_status_force(p_job_id number, p_status_id number)
is
pragma autonomous_transaction;
begin
  ------------------------------
  job_set_status_force(p_job_id => p_job_id, p_status_id => p_status_id);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_job_set_status_ext_force(p_job_id number, p_status_id number, p_error_id number, p_error_message clob)
is
pragma autonomous_transaction;
begin
  ------------------------------
  job_set_status_ext_force(p_job_id => p_job_id, p_status_id => p_status_id, p_error_id => p_error_id, p_error_message => p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_job_set_work_is_done(p_job_id number, p_work_is_done boolean)
is
pragma autonomous_transaction;
begin
  ------------------------------
  job_set_work_is_done(p_job_id => p_job_id, p_work_is_done => p_work_is_done);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_job_set_keepalive(p_job_id number)
is
pragma autonomous_transaction;
begin
  ------------------------------
  job_set_keepalive(p_job_id => p_job_id);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_job_set_command(p_job_id number, p_command_id number)
is
pragma autonomous_transaction;
begin
  ------------------------------
  job_set_command(p_job_id => p_job_id, p_command_id => p_command_id);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_jobs_set_command(p_job_ids ct_number, p_command_id number)
is
pragma autonomous_transaction;
begin
  ------------------------------
  jobs_set_command(p_job_ids => p_job_ids, p_command_id => p_command_id);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_job_clear_command(p_job_id number)
is
pragma autonomous_transaction;
begin
  ------------------------------
  job_clear_command(p_job_id => p_job_id);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_jobs_clear_command(p_job_ids ct_number)
is
pragma autonomous_transaction;
begin
  ------------------------------
  jobs_clear_command(p_job_ids => p_job_ids);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_task_set_status(p_task_id number, p_status_id number)
is
pragma autonomous_transaction;
begin
  ------------------------------
  task_set_status(p_task_id => p_task_id, p_status_id => p_status_id);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_task_set_status_ext(p_task_id number, p_status_id number, p_error_id number, p_error_message clob)
is
pragma autonomous_transaction;
begin
  ------------------------------
  task_set_status_ext(p_task_id => p_task_id, p_status_id => p_status_id, p_error_id => p_error_id, p_error_message => p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_task_set_status_force(p_task_id number, p_status_id number)
is
pragma autonomous_transaction;
begin
  ------------------------------
  task_set_status_force(p_task_id => p_task_id, p_status_id => p_status_id);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_task_set_status_ext_force(p_task_id number, p_status_id number, p_error_id number, p_error_message clob)
is
pragma autonomous_transaction;
begin
  ------------------------------
  task_set_status_ext_force(p_task_id => p_task_id, p_status_id => p_status_id, p_error_id => p_error_id, p_error_message => p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_task_inc_actual_try_count(p_task_id number, p_error_id number, p_error_message clob)
is
pragma autonomous_transaction;
begin
  ------------------------------
  task_inc_actual_try_count(p_task_id => p_task_id, p_error_id => p_error_id, p_error_message => p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_flow_set_status(p_flow_id number, p_status_id number)
is
pragma autonomous_transaction;
begin
  ------------------------------
  flow_set_status(p_flow_id => p_flow_id, p_status_id => p_status_id);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_flow_set_status_ext(p_flow_id number, p_status_id number, p_error_id number, p_error_message clob)
is
pragma autonomous_transaction;
begin
  ------------------------------
  flow_set_status_ext(p_flow_id => p_flow_id, p_status_id => p_status_id, p_error_id => p_error_id, p_error_message => p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_flow_set_status_force(p_flow_id number, p_status_id number)
is
pragma autonomous_transaction;
begin
  ------------------------------
  flow_set_status_force(p_flow_id => p_flow_id, p_status_id => p_status_id);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_flow_set_status_ext_force(p_flow_id number, p_status_id number, p_error_id number, p_error_message clob)
is
pragma autonomous_transaction;
begin
  ------------------------------
  flow_set_status_ext_force(p_flow_id => p_flow_id, p_status_id => p_status_id, p_error_id => p_error_id, p_error_message => p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_flow_set_direction_forward(p_flow_id number, p_direction_forward boolean)
is
pragma autonomous_transaction;
begin
  ------------------------------
  flow_set_direction_forward(p_flow_id => p_flow_id, p_direction_forward => p_direction_forward);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_flow_inc_actual_try_count(p_flow_id number, p_error_id number, p_error_message clob)
is
pragma autonomous_transaction;
begin
  ------------------------------
  flow_inc_actual_try_count(p_flow_id => p_flow_id, p_error_id => p_error_id, p_error_message => p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_iflow_set_actual_try_count(p_flow_id number, p_actual_try_count number)
is
pragma autonomous_transaction;
begin
  ------------------------------
  iflow_set_actual_try_count(p_flow_id => p_flow_id, p_actual_try_count => p_actual_try_count);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function at_job_wait_pickup_command
(
  p_job_id number,
  p_expired_timeout_sec number,
  p_idle_sleep_time_sec number
) return number
is
pragma autonomous_transaction;
  v_res number;
begin
  ------------------------------
  v_res := job_wait_pickup_command
  (
    p_job_id => p_job_id,
    p_expired_timeout_sec => p_expired_timeout_sec,
    p_idle_sleep_time_sec => p_idle_sleep_time_sec
  );
  ------------------------------
  commit;
  ------------------------------
  return v_res;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function at_activate_jobs(p_jobs cit_job) return cit_job
is
pragma autonomous_transaction;
  v_res cit_job;
begin
  ------------------------------
  v_res := activate_jobs(p_jobs => p_jobs);
  ------------------------------
  commit;
  ------------------------------
  return v_res;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_first_task_index(p_tasks cit_task, p_goal_status_id number) return number
is
  v_res number := NULL;
  v_count number;
begin
  ------------------------------
  xcheck_status4task(p_task_status_id => p_goal_status_id);
  ------------------------------
  v_count := get_count_cit_task(p_tasks);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    if p_tasks(v_i).status_id != p_goal_status_id
    then
      ------------------------------
      v_res := v_i;
      ------------------------------
      exit;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_last_task_index(p_tasks cit_task, p_goal_status_id number) return number
is
  v_res number := NULL;
  v_count number;
begin
  ------------------------------
  xcheck_status4task(p_task_status_id => p_goal_status_id);
  ------------------------------
  v_count := get_count_cit_task(p_tasks);
  ------------------------------
  for v_i in reverse 1..v_count
  loop
    ------------------------------
    if p_tasks(v_i).status_id != p_goal_status_id
    then
      ------------------------------
      v_res := v_i;
      ------------------------------
      exit;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function task_jobs_are_running(p_task_id number, p_completion_rule number, p_for_running boolean) return boolean
is
  v_task t_task;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_task_id is null, 'p_task_id');
  xcheck_completion_rule(p_completion_rule);
  util_pkg.XCheck_Cond_Missing(p_for_running is null, 'p_for_running');
  ------------------------------
  v_task := task_get(p_task_id => p_task_id);
  ------------------------------
  xcheck_t_task(p_obj => v_task);
  ------------------------------
  return jobs_are_running(p_job_ids => extract_ids_cit_job(v_task.jobs), p_completion_rule => p_completion_rule, p_for_running => p_for_running);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function flow_jobs_are_running(p_flow_id number) return boolean
is
  v_flow t_flow;
  v_task_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_flow_id is null, 'p_flow_id');
  ------------------------------
  v_flow := flow_get(p_flow_id => p_flow_id);
  ------------------------------
  xcheck_t_flow(p_obj => v_flow);
  ------------------------------
  v_task_count := get_count_cit_task(v_flow.tasks);
  ------------------------------
  for v_i in 1..v_task_count
  loop
    ------------------------------
    if task_jobs_are_running(p_task_id => v_flow.tasks(v_i).task_id, p_completion_rule => c_cr_one, p_for_running => true)
    then
      ------------------------------
      return true;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure job_runner(p_job_id number)
is
  v_x_cancel exception;
  v_wait_start date;
  v_expired_timeout_sec number;
  v_job t_job;
  v_sys_job_id number;
  v_command_id number;
  v_direction_forward boolean := NULL; --!_!
  v_shadow_job_text clob;
  v_task t_task;
  v_try_count number;
  v_error_id number;
  v_error_message clob;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_job_id is null, 'p_job_id');
  ------------------------------
  v_job := job_get(p_job_id => p_job_id);
  ------------------------------
  xcheck_t_job(p_obj => v_job, p_check_parent => true);
  ------------------------------
  if install_pkg.nnget_option_bool(c_opt_fastp_job_run_chk_job, c_def_fastp_job_run_chk_job)
  then
    ------------------------------
    v_sys_job_id := install_pkg.get_this_bg_job_id;
    ------------------------------
    if 1 = 1
      and v_sys_job_id is not null
      and v_sys_job_id != v_job.sys_job_id
    then
      ------------------------------
      if install_pkg.nnget_option_bool(c_opt_fastp_job_run_chk_job_x, c_def_fastp_job_run_chk_job_x)
      then
        ------------------------------
        util_pkg.raise_exception
        (
          util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong
          || util_pkg.c_msg_delim_semicolon || 'this sys_job_id'
          || util_pkg.c_msg_delim_colon || util_pkg.number_to_char(v_sys_job_id)
          || util_pkg.c_msg_delim_semicolon || 'expected sys_job_id'
          || util_pkg.c_msg_delim_colon || util_pkg.number_to_char(v_job.sys_job_id)
        );
        ------------------------------
      else
        ------------------------------
        return;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  --!_!v_direction_forward for job is not available on this step; it depends from task command
  --!_!without command job dont't know yet where to go
  --!_!
  --!_!if v_job.status_id = get_success_status4job(p_direction_forward => v_direction_forward)
  --!_!then
  --!_!  ------------------------------
  --!_!  return c_exec_result_ok;
  --!_!  ------------------------------
  --!_!end if;
  ------------------------------
  util_pkg.set_ok(v_error_id, v_error_message);
  ------------------------------
  --!_!force because allowance depends from status_id and p_direction_forward; conditional allowance is not implemented now
  at_job_set_status_ext_force(p_job_id => p_job_id, p_status_id => c_stat_new, p_error_id => v_error_id, p_error_message => v_error_message);
  ------------------------------
  v_try_count := try_count_init;
  timer_init(p_timeout_sec => v_job.expired_timeout_sec, p_out_timeout_sec => v_expired_timeout_sec, p_out_start => v_wait_start);
  ------------------------------
  ------------------------------
  timer_alter(p_timeout_sec => v_expired_timeout_sec, p_start => v_wait_start);
  v_command_id := at_job_wait_pickup_command
  (
    p_job_id => p_job_id,
    p_expired_timeout_sec => v_expired_timeout_sec,
    p_idle_sleep_time_sec => v_job.idle_sleep_time_sec
  );
  ------------------------------
  if v_command_id = c_jcmd_prepare_forward
  then
    ------------------------------
    v_direction_forward := true;
    ------------------------------
  elsif v_command_id = c_jcmd_prepare_backward
  then
    ------------------------------
    v_direction_forward := false;
    ------------------------------
  elsif v_command_id in (c_jcmd_dummy_expiry, c_jcmd_cancel)
  then
    ------------------------------
    at_job_set_status(p_job_id => p_job_id, p_status_id => c_stat_cancelling);
    ------------------------------
    raise v_x_cancel;
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed || util_pkg.c_msg_delim01 || 'COMMAND_ID 001' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_command_id));
    ------------------------------
  end if;
  ------------------------------
  at_job_set_status(p_job_id => p_job_id, p_status_id => c_stat_waiting2run);
  ------------------------------
  ------------------------------
  timer_alter(p_timeout_sec => v_expired_timeout_sec, p_start => v_wait_start);
  v_command_id := at_job_wait_pickup_command
  (
    p_job_id => p_job_id,
    p_expired_timeout_sec => v_expired_timeout_sec,
    p_idle_sleep_time_sec => v_job.idle_sleep_time_sec
  );
  ------------------------------
  if v_command_id = c_jcmd_run
  then
    ------------------------------
    NULL;
    ------------------------------
  elsif v_command_id in (c_jcmd_dummy_expiry, c_jcmd_cancel)
  then
    ------------------------------
    at_job_set_status(p_job_id => p_job_id, p_status_id => c_stat_cancelling);
    ------------------------------
    raise v_x_cancel;
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed || util_pkg.c_msg_delim01 || 'COMMAND_ID 002' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_command_id));
    ------------------------------
  end if;
  ------------------------------
  v_shadow_job_text := v_job.job_text;
  ------------------------------
  v_shadow_job_text := replace(v_shadow_job_text, c_pph_job_id, util_loc_pkg.wrap_number(p_job_id));
  v_shadow_job_text := replace(v_shadow_job_text, c_pph_direction_forward, util_loc_pkg.wrap_boolean(v_direction_forward));
  ------------------------------
  v_task := task_get(p_task_id => v_job.parent_id);
  ------------------------------
  util_pkg.set_ok(v_error_id, v_error_message);
  v_command_id := NULL; --!_!
  ------------------------------
  ------------------------------
  loop
    ------------------------------
    --!_!v_error_id, v_error_message saved from "when others"
    at_job_set_status_ext(p_job_id => p_job_id, p_status_id => c_stat_running, p_error_id => v_error_id, p_error_message => v_error_message);
    ------------------------------
    begin
      ------------------------------
      --!_!timer_alter(p_timeout_sec => v_expired_timeout_sec, p_start => v_wait_start);
      ------------------------------
       --!_!make real action only if it's needed; SKIP it otherwise
      if is_work_needed(p_work_is_done => v_job.work_is_done, p_direction_forward => v_direction_forward)
      then
        ------------------------------
        execute immediate v_shadow_job_text; --!_!NO COMMIT INSIDE
        ------------------------------
      end if;
      ------------------------------
      at_job_set_status(p_job_id => p_job_id, p_status_id => c_stat_waiting2complete);
      ------------------------------
      if 1 = 1
        and v_task.sync_commit
        and v_command_id is NULL --!_!bypass wait for already received command
      then
        ------------------------------
        ------------------------------
        timer_alter(p_timeout_sec => v_expired_timeout_sec, p_start => v_wait_start);
        v_command_id := at_job_wait_pickup_command
        (
          p_job_id => p_job_id,
          p_expired_timeout_sec => v_expired_timeout_sec,
          p_idle_sleep_time_sec => v_job.idle_sleep_time_sec
        );
        ------------------------------
        if v_command_id = c_jcmd_commit
        then
          ------------------------------
          NULL; --!_!
          ------------------------------
        elsif v_command_id in (c_jcmd_dummy_expiry, c_jcmd_cancel)
        then
          ------------------------------
          at_job_set_status(p_job_id => p_job_id, p_status_id => c_stat_cancelling); --!_!AT
          ------------------------------
          raise v_x_cancel; --!_!REraise below
          ------------------------------
        else
          ------------------------------
          util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed || util_pkg.c_msg_delim01 || 'COMMAND_ID 003' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_command_id));
          ------------------------------
        end if;
        ------------------------------
        ------------------------------
      end if;
      ------------------------------
      util_pkg.set_ok(v_error_id, v_error_message);
      ------------------------------
      job_set_status_ext(p_job_id => p_job_id, p_status_id => get_success_status4job(v_direction_forward), p_error_id => v_error_id, p_error_message => v_error_message); --!_!NOT AT
      job_set_work_is_done(p_job_id => p_job_id, p_work_is_done => get_work_is_done(p_direction_forward => v_direction_forward)); --!_!NOT AT
      ------------------------------
      COMMIT;
      ------------------------------
      exit;
      ------------------------------
    exception
    when v_x_cancel then
      ------------------------------
      raise v_x_cancel;
      ------------------------------
    when others then
      ------------------------------
      util_pkg.set_error(v_error_id, v_error_message);
      ------------------------------
      try_count_increase(p_try_count => v_try_count);
      ------------------------------
      if (1 = 0
        or try_count_is_exceeded(p_actual_try_count => v_try_count, p_param_retry_count => v_job.retry_count)
        or timer_is_timed_out_or_SLEEP(p_timeout_sec => v_expired_timeout_sec, p_start => v_wait_start, p_sleep_interval_sec => v_job.idle_sleep_time_sec)
      )
      then
        ------------------------------
        util_pkg.reraise_exception; --!_!not expiry - error!
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when v_x_cancel then
  ------------------------------
  ROLLBACK;
  ------------------------------
  if v_direction_forward is null
  then
    ------------------------------
    at_job_set_status_force(p_job_id => p_job_id, p_status_id => v_job.status_id);
    ------------------------------
  else
    ------------------------------
    at_job_set_status(p_job_id => p_job_id, p_status_id => get_cancel_status4job(v_direction_forward));
    ------------------------------
  end if;
  ------------------------------
when others then
  ------------------------------
  ROLLBACK;
  ------------------------------
  if v_job.job_id is null
  then
    ------------------------------
    util_pkg.reraise_exception; --!_!no logging here
    ------------------------------
  end if;
  ------------------------------
  util_pkg.set_error(v_error_id, v_error_message);
  ------------------------------
  if v_direction_forward is null
  then
    ------------------------------
    at_job_set_status_ext_force(p_job_id => p_job_id, p_status_id => v_job.status_id, p_error_id => v_error_id, p_error_message => v_error_message);
    ------------------------------
  else
    ------------------------------
    at_job_set_status_ext_force(p_job_id => p_job_id, p_status_id => get_error_status4job(v_direction_forward), p_error_id => v_error_id, p_error_message => v_error_message);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function command_to_jobs_and_wait
(
  p_job_ids ct_number,
  p_command_id number,
  p_goal_status_id number,
  p_completion_rule number,
  p_direction_forward boolean,
  p_wait_all_jobs_completion boolean,
  p_check_break_status boolean,
  p_idle_sleep_time_sec number,
  p_expired_timeout_sec number
) return number
is
  v_res number;
  v_expired_timeout_sec number;
  v_wait_start date;
  v_wait_result_tmp number;
  v_break_status_ids ct_number := null; --!_!
  v_wait_all_goal_status_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_job_ids, 'p_job_ids');
  xcheck_command(p_command_id);
  xcheck_status4job(p_job_status_id => p_goal_status_id);
  xcheck_completion_rule(p_completion_rule);
  util_pkg.XCheck_Cond_Missing(p_direction_forward is null, 'p_direction_forward');
  util_pkg.XCheck_Cond_Missing(p_check_break_status is null, 'p_check_break_status');
  util_pkg.XCheck_Cond_Missing(p_wait_all_jobs_completion is null, 'p_wait_all_jobs_completion');
  util_pkg.XCheck_Cond_Missing(p_idle_sleep_time_sec is null, 'p_idle_sleep_time_sec');
  util_pkg.XCheck_Cond_Missing(p_expired_timeout_sec is null, 'p_expired_timeout_sec');
  ------------------------------
  if p_check_break_status
  then
    ------------------------------
    v_break_status_ids := get_break_statuses4job(p_direction_forward => p_direction_forward);
    ------------------------------
  end if;
  ------------------------------
  v_wait_all_goal_status_ids := get_final_statuses4job;
  util_pkg.add_ct_number_val(v_wait_all_goal_status_ids, p_goal_status_id);
  ------------------------------
  at_jobs_set_command(p_job_ids => p_job_ids, p_command_id => p_command_id);
  ------------------------------
  timer_init(p_timeout_sec => p_expired_timeout_sec, p_out_timeout_sec => v_expired_timeout_sec, p_out_start => v_wait_start);
  ------------------------------
  timer_alter(p_timeout_sec => v_expired_timeout_sec, p_start => v_wait_start);
  v_res := wait_jobs_status3
  (
    p_job_ids => p_job_ids,
    p_expired_timeout_sec => v_expired_timeout_sec,
    p_idle_sleep_time_sec => p_idle_sleep_time_sec,
    p_goal_status_id => p_goal_status_id,
    p_break_status_ids => v_break_status_ids,
    p_goal_completion_rule => p_completion_rule
  );
  ------------------------------
  if p_wait_all_jobs_completion
  then
    ------------------------------
    timer_alter(p_timeout_sec => v_expired_timeout_sec, p_start => v_wait_start);
    v_wait_result_tmp := wait_jobs_status2
    (
      p_job_ids => p_job_ids,
      p_expired_timeout_sec => v_expired_timeout_sec,
      p_idle_sleep_time_sec => p_idle_sleep_time_sec,
      p_goal_status_ids => v_wait_all_goal_status_ids, --!_!
      p_break_status_ids => v_break_status_ids,
      p_goal_completion_rule => c_cr_all
    );
    ------------------------------
    util_loc_pkg.touch_number(v_wait_result_tmp);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function execute_task(p_task_id number, p_direction_forward boolean) return number
is
  v_x_complete exception;
  v_x_expiry exception;
  v_x_error exception;
  v_goal_status_id number;
  v_command_id number;
  v_task t_task;
  v_jobs cit_job;
  v_wait_result number;
  v_expired_timeout_sec number;
  v_wait_start date;
  v_error_id number;
  v_error_message clob;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_task_id is null, 'p_task_id');
  util_pkg.XCheck_Cond_Missing(p_direction_forward is null, 'p_direction_forward');
  ------------------------------
  v_task := task_get(p_task_id => p_task_id);
  ------------------------------
  xcheck_t_task(p_obj => v_task);
  ------------------------------
  --!_!if is_final_status4task(p_task_status_id => v_task.status_id)
  if v_task.status_id = get_success_status4task(p_direction_forward => p_direction_forward)
  then
    ------------------------------
    return c_exec_result_ok; --!_!
    ------------------------------
  end if;
  ------------------------------
  if try_count_is_exceeded(p_actual_try_count => v_task.actual_try_count, p_param_retry_count => v_task.retry_count)
  then
    ------------------------------
    raise v_x_error; --!_!found lost try mark
    ------------------------------
  end if;
  ------------------------------
  util_pkg.set_ok(v_error_id, v_error_message);
  ------------------------------
  timer_init(p_timeout_sec => v_task.expired_timeout_sec, p_out_timeout_sec => v_expired_timeout_sec, p_out_start => v_wait_start);
  ------------------------------
  --!_!force because allowance depends from status_id and p_direction_forward; conditional allowance is not implemented now
  at_task_set_status_ext_force(p_task_id => p_task_id, p_status_id => c_stat_running, p_error_id => v_error_id, p_error_message => v_error_message);
  ------------------------------
  timer_alter(p_timeout_sec => v_expired_timeout_sec, p_start => v_wait_start);
  v_wait_result := wait_jobs_running
  (
    p_job_ids => extract_ids_cit_job(v_task.jobs),
    p_expired_timeout_sec => v_expired_timeout_sec,
    p_idle_sleep_time_sec => v_task.idle_sleep_time_sec,
    p_completion_rule => c_cr_all, --!_!
    p_for_running => FALSE --!_!
  );
  ------------------------------
  if v_wait_result = c_wait_result_ok
  then
    ------------------------------
    --!_!raise v_x_complete;
    null;
    ------------------------------
  elsif v_wait_result = c_wait_result_expiry
  then
    ------------------------------
    raise v_x_expiry;
    ------------------------------
  elsif v_wait_result = c_wait_result_break --!_!not used in wait_jobs_running
  then
    ------------------------------
    raise v_x_expiry; --!_!v_x_error
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'WAIT RESULT 010' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_wait_result));
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  at_jobs_clear_command(p_job_ids => extract_ids_cit_job(v_task.jobs));
  ------------------------------
  v_jobs := at_activate_jobs(p_jobs => v_task.jobs);
  ------------------------------
  --!_!v_command_id
  v_goal_status_id := c_stat_new;
  ------------------------------
  timer_alter(p_timeout_sec => v_expired_timeout_sec, p_start => v_wait_start);
  v_wait_result := wait_jobs_status3
  (
    p_job_ids => extract_ids_cit_job(v_task.jobs),
    p_expired_timeout_sec => v_expired_timeout_sec,
    p_idle_sleep_time_sec => v_task.idle_sleep_time_sec,
    p_goal_status_id => v_goal_status_id,
    p_break_status_ids => NULL, --!_!
    p_goal_completion_rule => c_cr_all --!_!
  );
  ------------------------------
  if v_wait_result = c_wait_result_ok
  then
    ------------------------------
    --!_!raise v_x_complete;
    null;
    ------------------------------
  elsif v_wait_result = c_wait_result_expiry
  then
    ------------------------------
    raise v_x_expiry;
    ------------------------------
  elsif v_wait_result = c_wait_result_break
  then
    ------------------------------
    raise v_x_expiry; --!_!v_x_error
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'WAIT RESULT 020' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_wait_result));
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_command_id := case when p_direction_forward then c_jcmd_prepare_forward else c_jcmd_prepare_backward end;
  ------------------------------
  v_goal_status_id := c_stat_waiting2run;
  ------------------------------
  timer_alter(p_timeout_sec => v_expired_timeout_sec, p_start => v_wait_start);
  v_wait_result := command_to_jobs_and_wait
  (
    p_job_ids => extract_ids_cit_job(v_jobs),
    p_command_id => v_command_id,
    p_goal_status_id => v_goal_status_id,
    p_completion_rule => v_task.completion_rule,
    p_direction_forward => p_direction_forward,
    p_wait_all_jobs_completion => v_task.wait_all_jobs_completion,
    p_check_break_status => FALSE,
    p_idle_sleep_time_sec => v_task.idle_sleep_time_sec,
    p_expired_timeout_sec => v_expired_timeout_sec
  );
  ------------------------------
  if v_wait_result = c_wait_result_ok
  then
    ------------------------------
    --!_!raise v_x_complete;
    null;
    ------------------------------
  elsif v_wait_result = c_wait_result_expiry
  then
    ------------------------------
    raise v_x_expiry;
    ------------------------------
  elsif v_wait_result = c_wait_result_break
  then
    ------------------------------
    raise v_x_expiry; --!_!v_x_error
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'WAIT RESULT 030' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_wait_result));
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_command_id := c_jcmd_run;
  ------------------------------
  if v_task.sync_commit
  then
    ------------------------------
    v_goal_status_id := c_stat_waiting2complete;
    ------------------------------
  else
    ------------------------------
    v_goal_status_id := get_success_status4job(p_direction_forward);
    ------------------------------
  end if;
  ------------------------------
  timer_alter(p_timeout_sec => v_expired_timeout_sec, p_start => v_wait_start);
  v_wait_result := command_to_jobs_and_wait
  (
    p_job_ids => extract_ids_cit_job(v_jobs),
    p_command_id => v_command_id,
    p_goal_status_id => v_goal_status_id,
    p_completion_rule => v_task.completion_rule,
    p_direction_forward => p_direction_forward,
    p_wait_all_jobs_completion => v_task.wait_all_jobs_completion,
    p_check_break_status => FALSE,
    p_idle_sleep_time_sec => v_task.idle_sleep_time_sec,
    p_expired_timeout_sec => v_expired_timeout_sec
  );
  ------------------------------
  if v_wait_result = c_wait_result_ok
  then
    ------------------------------
    if v_task.sync_commit
    then
      ------------------------------
      --!_!raise v_x_complete;
      null;
      ------------------------------
    else
      ------------------------------
      raise v_x_complete;
      ------------------------------
    end if;
    ------------------------------
  elsif v_wait_result = c_wait_result_expiry
  then
    ------------------------------
    raise v_x_expiry;
    ------------------------------
  elsif v_wait_result = c_wait_result_break
  then
    ------------------------------
    raise v_x_expiry; --!_!v_x_error
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'WAIT RESULT 040' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_wait_result));
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_command_id := c_jcmd_commit;
  ------------------------------
  v_goal_status_id := get_success_status4job(p_direction_forward);
  ------------------------------
  timer_alter(p_timeout_sec => v_expired_timeout_sec, p_start => v_wait_start);
  v_wait_result := command_to_jobs_and_wait
  (
    p_job_ids => extract_ids_cit_job(v_jobs),
    p_command_id => v_command_id,
    p_goal_status_id => v_goal_status_id,
    p_completion_rule => v_task.completion_rule,
    p_direction_forward => p_direction_forward,
    p_wait_all_jobs_completion => v_task.wait_all_jobs_completion,
    p_check_break_status => FALSE,
    p_idle_sleep_time_sec => v_task.idle_sleep_time_sec,
    p_expired_timeout_sec => v_expired_timeout_sec
  );
  ------------------------------
  if v_wait_result = c_wait_result_ok
  then
    ------------------------------
    raise v_x_complete;
    ------------------------------
  elsif v_wait_result = c_wait_result_expiry
  then
    ------------------------------
    raise v_x_expiry;
    ------------------------------
  elsif v_wait_result = c_wait_result_break
  then
    ------------------------------
    raise v_x_expiry; --!_!v_x_error
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'WAIT RESULT 050' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_wait_result));
    ------------------------------
  end if;
  ------------------------------
  return c_exec_result_pending; --!_!fictitious
  ------------------------------
exception
when v_x_complete then
  ------------------------------
  util_pkg.set_ok(v_error_id, v_error_message);
  ------------------------------
  at_task_set_status_ext(p_task_id => p_task_id, p_status_id => get_success_status4task(p_direction_forward), p_error_id => v_error_id, p_error_message => v_error_message);
  ------------------------------
  return c_exec_result_ok;
  ------------------------------
when v_x_expiry then
  ------------------------------
  v_error_id := util_pkg.c_ora_expired;
  v_error_message := util_pkg.c_msg_expired;
  ------------------------------
  at_task_inc_actual_try_count(p_task_id => p_task_id, p_error_id => v_error_id, p_error_message => v_error_message);
  --!_!try mark can be lost and don't affect status through app crash
  ------------------------------
  v_task := task_get(p_task_id => p_task_id);
  ------------------------------
  xcheck_t_task(p_obj => v_task);
  ------------------------------
  if try_count_is_exceeded(p_actual_try_count => v_task.actual_try_count, p_param_retry_count => v_task.retry_count)
  then
    ------------------------------
    ------------------------------
    --!_!c_jcmd_cancel
    if get_count_cit_job(v_task.jobs) > 0
    then
      ------------------------------
      at_jobs_set_command(p_job_ids => extract_ids_cit_job(v_task.jobs), p_command_id => c_jcmd_cancel);
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    at_task_set_status_ext_force(p_task_id => p_task_id, p_status_id => get_error_status4task(p_direction_forward), p_error_id => v_error_id, p_error_message => v_error_message);
    ------------------------------
    return c_exec_result_error; --!_!
    ------------------------------
  end if;
  ------------------------------
  return c_exec_result_pending; --!_!
  ------------------------------
when v_x_error then
  ------------------------------
  v_error_id := util_pkg.c_ora_execution_error;
  v_error_message := util_pkg.c_msg_execution_error;
  ------------------------------
  --!_!found lost try mark
  if try_count_is_exceeded(p_actual_try_count => v_task.actual_try_count, p_param_retry_count => v_task.retry_count)
  then
    ------------------------------
    at_task_set_status_force(p_task_id => p_task_id, p_status_id => get_error_status4task(p_direction_forward));
    ------------------------------
    return c_exec_result_error; --!_!
    ------------------------------
  end if;
  ------------------------------
  at_task_inc_actual_try_count(p_task_id => p_task_id, p_error_id => v_error_id, p_error_message => v_error_message);
  --!_!try mark can be lost and don't affect status through app crash
  ------------------------------
  v_task := task_get(p_task_id => p_task_id);
  ------------------------------
  xcheck_t_task(p_obj => v_task);
  ------------------------------
  if try_count_is_exceeded(p_actual_try_count => v_task.actual_try_count, p_param_retry_count => v_task.retry_count)
  then
    ------------------------------
    ------------------------------
    --!_!c_jcmd_cancel
    if get_count_cit_job(v_task.jobs) > 0
    then
      ------------------------------
      at_jobs_set_command(p_job_ids => extract_ids_cit_job(v_task.jobs), p_command_id => c_jcmd_cancel);
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    at_task_set_status_ext_force(p_task_id => p_task_id, p_status_id => get_error_status4task(p_direction_forward), p_error_id => v_error_id, p_error_message => v_error_message);
    ------------------------------
    return c_exec_result_error; --!_!
    ------------------------------
  end if;
  ------------------------------
  return c_exec_result_pending; --!_!
  ------------------------------
when others then
  ------------------------------
  util_pkg.set_error(v_error_id, v_error_message);
  ------------------------------
  if 1 = 0
    or v_task.task_id is null
    --!_!or p_direction_forward is null
  then
    ------------------------------
    util_pkg.reraise_exception; --!_!no logging here
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  --!_!c_jcmd_cancel
  if get_count_cit_job(v_task.jobs) > 0
  then
    ------------------------------
    at_jobs_set_command(p_job_ids => extract_ids_cit_job(v_task.jobs), p_command_id => c_jcmd_cancel);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  at_task_set_status_ext_force(p_task_id => p_task_id, p_status_id => get_error_status4task(p_direction_forward), p_error_id => v_error_id, p_error_message => v_error_message);
  ------------------------------
  return c_exec_result_error;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function execute_flow
(
  p_flow_id number,
  p_force_status boolean,
  p_forced_direction_forward boolean --!_!not used with p_force_status => false
) return number
is
  v_x_pending exception;
  v_x_exceeded exception;
  v_direction_forward boolean;
  v_i number;
  v_flow t_flow;
  v_tasks cit_task;
  v_task t_task;
  v_exec_result number;
  v_goal_status_id number;
  v_error_id number;
  v_error_message clob;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_flow_id is null, 'p_flow_id');
  util_pkg.XCheck_Cond_Missing(p_force_status is null, 'p_force_status');
  util_pkg.XCheck_Cond_Missing(p_forced_direction_forward is null, 'p_forced_direction_forward');
  ------------------------------
  v_flow := flow_get(p_flow_id => p_flow_id);
  ------------------------------
  xcheck_t_flow(p_obj => v_flow);
  ------------------------------
  if 1 = 1
    and not p_force_status
    and need_to_restrict_flow(p_flow_type_id => v_flow.flow_type_id, p_this_is_created => true)
  then
    ------------------------------
    raise v_x_exceeded;
    ------------------------------
  end if;
  ------------------------------
  --!_!if v_flow.status_id = get_success_status4flow(p_direction_forward => v_direction_forward)
  if is_final_status4flow(p_flow_status_id => v_flow.status_id)
  then
    ------------------------------
    if p_force_status
    then
      ------------------------------
      flow_set_direction_forward(p_flow_id => p_flow_id, p_direction_forward => p_forced_direction_forward);
      iflow_set_actual_try_count(p_flow_id => p_flow_id, p_actual_try_count => c_count_zero); --!_!flow with tasks
      ------------------------------
      v_flow := flow_get(p_flow_id => p_flow_id); --!_!reread
      ------------------------------
      xcheck_t_flow(p_obj => v_flow);
      ------------------------------
    else
      ------------------------------
      return c_exec_result_ok; --!_!
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  v_direction_forward := v_flow.direction_forward;
  ------------------------------
  if try_count_is_exceeded(p_actual_try_count => v_flow.actual_try_count, p_param_retry_count => v_flow.retry_count)
  then
    ------------------------------
    raise v_x_pending; --!_!found lost try mark
    ------------------------------
  end if;
  ------------------------------
  util_pkg.set_ok(v_error_id, v_error_message);
  ------------------------------
  at_flow_set_status_ext(p_flow_id => p_flow_id, p_status_id => c_stat_running, p_error_id => v_error_id, p_error_message => v_error_message);
  ------------------------------
  v_tasks := v_flow.tasks;
  ------------------------------
  --!_!v_i := v_tasks.first;
  ------------------------------
  v_goal_status_id := get_success_status4task(p_direction_forward => v_direction_forward);
  ------------------------------
  if v_direction_forward
  then
    ------------------------------
    v_i := get_first_task_index(p_tasks => v_tasks, p_goal_status_id => v_goal_status_id);
    ------------------------------
  else
    ------------------------------
    v_i := get_last_task_index(p_tasks => v_tasks, p_goal_status_id => v_goal_status_id);
    ------------------------------
  end if;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    v_task := v_tasks(v_i);
    ------------------------------
    v_exec_result := execute_task(p_task_id => v_task.task_id, p_direction_forward => v_direction_forward);
    ------------------------------
    if v_exec_result = c_exec_result_ok
    then
      ------------------------------
      if v_direction_forward
      then
        ------------------------------
        v_i := v_tasks.next(v_i);
        ------------------------------
      else
        ------------------------------
        v_i := v_tasks.prior(v_i);
        ------------------------------
      end if;
      ------------------------------
    elsif v_exec_result = c_exec_result_pending
    then
      ------------------------------
      raise v_x_pending;
      ------------------------------
    elsif v_exec_result = c_exec_result_error
    then
      ------------------------------
      if 1 = 1
        and v_flow.reversible
        and v_direction_forward
      then
        ------------------------------
        v_direction_forward := false;
        ------------------------------
        at_flow_set_direction_forward(p_flow_id => p_flow_id, p_direction_forward => v_direction_forward);
        ------------------------------
      else
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_execution_error, util_pkg.c_msg_execution_error || util_pkg.c_msg_delim01 || 'FLOW STEP' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_i));
        ------------------------------
      end if;
      ------------------------------
    else
      ------------------------------
      util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'EXEC RESULT 001' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_exec_result));
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  util_pkg.set_ok(v_error_id, v_error_message);
  ------------------------------
  at_flow_set_status_ext(p_flow_id => p_flow_id, p_status_id => get_success_status4flow(v_direction_forward), p_error_id => v_error_id, p_error_message => v_error_message);
  ------------------------------
  --!_!COMMIT
  ------------------------------
  return c_exec_result_ok;
  ------------------------------
exception
when v_x_exceeded then
  ------------------------------
  --!_!ROLLBACK;
  ------------------------------
  raise_exceeded(p_flow_type_id => v_flow.flow_type_id);
  ------------------------------
when v_x_pending then
  ------------------------------
  --!_!ROLLBACK;
  ------------------------------
  v_error_id := util_pkg.c_ora_execution_error;
  v_error_message := util_pkg.c_msg_execution_error || util_pkg.c_msg_delim01 || 'FLOW STEP' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_i);
  ------------------------------
  --!_!found lost try mark
  if try_count_is_exceeded(p_actual_try_count => v_flow.actual_try_count, p_param_retry_count => v_flow.retry_count)
  then
    ------------------------------
    at_flow_set_status_force(p_flow_id => p_flow_id, p_status_id => get_error_status4flow(v_direction_forward));
    ------------------------------
    return c_exec_result_error;
    ------------------------------
  end if;
  ------------------------------
  at_flow_inc_actual_try_count(p_flow_id => p_flow_id, p_error_id => v_error_id, p_error_message => v_error_message);
  ------------------------------
  v_flow := flow_get(p_flow_id => p_flow_id);
  ------------------------------
  xcheck_t_flow(p_obj => v_flow);
  ------------------------------
  if try_count_is_exceeded(p_actual_try_count => v_flow.actual_try_count, p_param_retry_count => v_flow.retry_count)
  then
    ------------------------------
    at_flow_set_status_ext_force(p_flow_id => p_flow_id, p_status_id => get_error_status4flow(v_direction_forward), p_error_id => v_error_id, p_error_message => v_error_message);
    ------------------------------
    return c_exec_result_error;
    ------------------------------
  end if;
  ------------------------------
  return c_exec_result_pending;
  ------------------------------
when others then
  ------------------------------
  --!_!ROLLBACK;
  ------------------------------
  util_pkg.set_error(v_error_id, v_error_message);
  ------------------------------
  if 1 = 1
    and v_flow.flow_id is not null
    and v_direction_forward is not null
  then
    ------------------------------
    at_flow_set_status_ext_force(p_flow_id => p_flow_id, p_status_id => get_error_status4flow(v_direction_forward), p_error_id => v_error_id, p_error_message => v_error_message);
    ------------------------------
    return c_exec_result_error;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.reraise_exception; --!_!no logging here
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_opt_name_restrct_flow_typ(p_flow_type_id number) return varchar2
is
begin
  ------------------------------
  return c_optp_fastp_restrct_flow_cntt || util_pkg.number_to_char(p_flow_type_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function need_to_restrict_flow(p_flow_type_id number, p_this_is_created boolean) return boolean
is
  v_flows cit_flow;
  v_max_count number;
  v_count number;
  v_nums ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_flow_type_id is null, 'p_flow_type_id');
  util_pkg.XCheck_Cond_Missing(p_this_is_created is null, 'p_this_is_created');
  ------------------------------
  v_flows := flows_pget_active;
  ------------------------------
  v_count := get_count_cit_flow(v_flows);
  ------------------------------
  if p_this_is_created
  then
    ------------------------------
    v_count := v_count - 1;
    ------------------------------
  end if;
  ------------------------------
  v_max_count := install_pkg.nnget_option_num(c_opt_fastp_restrct_flow_cnt, c_def_fastp_restrct_flow_cnt);
  ------------------------------
  if 1 = 1
    and v_max_count != c_count_infinity
    and v_count >= v_max_count
  then
    ------------------------------
    return TRUE;
    ------------------------------
  end if;
  ------------------------------
  if install_pkg.is_exist_option(make_opt_name_restrct_flow_typ(p_flow_type_id => p_flow_type_id))
  then
    ------------------------------
    v_nums := extract_type_ids_cit_flow(v_flows);
    ------------------------------
    v_count := cnt_objs_has_value2_i(p_obj_values => v_nums, p_goal_value => p_flow_type_id);
    ------------------------------
    if p_this_is_created
    then
      ------------------------------
      v_count := v_count - 1;
      ------------------------------
    end if;
    ------------------------------
    v_max_count := install_pkg.nnget_option_num(make_opt_name_restrct_flow_typ(p_flow_type_id => p_flow_type_id), c_count_infinity);
    ------------------------------
    if 1 = 1
      and v_max_count != c_count_infinity
      and v_count >= v_max_count
    then
      ------------------------------
      return TRUE;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  return FALSE;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xneed_to_restrict_flow(p_flow_type_id number, p_this_is_created boolean)
is
begin
  ------------------------------
  if need_to_restrict_flow(p_flow_type_id => p_flow_type_id, p_this_is_created => p_this_is_created)
  then
    ------------------------------
    raise_exceeded(p_flow_type_id => p_flow_type_id);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure raise_exceeded(p_flow_type_id number)
is
begin
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_exceeded, util_pkg.c_msg_exceeded || util_pkg.c_msg_delim01 || 'max count for flows or for flow_type_id' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_flow_type_id));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure at_save_flow(p_flow t_flow)
is
pragma autonomous_transaction;
begin
  ------------------------------
  save_flow(p_flow => p_flow);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function at_execute_flow
(
  p_flow_id number,
  p_force_status boolean,
  p_forced_direction_forward boolean --!_!not used with p_force_status => false
) return number
is
pragma autonomous_transaction;
  v_res number;
begin
  ------------------------------
  v_res := execute_flow(p_flow_id => p_flow_id, p_force_status => p_force_status, p_forced_direction_forward => p_forced_direction_forward);
  ------------------------------
  commit;
  ------------------------------
  return v_res;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_execute_flow2
(
  p_flow_id number,
  p_force_status boolean,
  p_forced_direction_forward boolean --!_!not used with p_force_status => false
)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(at_execute_flow(p_flow_id => p_flow_id, p_force_status => p_force_status, p_forced_direction_forward => p_forced_direction_forward));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function at_execute_flow3
(
  p_flow_id number
) return number
is
begin
  ------------------------------
  return at_execute_flow
  (
    p_flow_id => p_flow_id,
    p_force_status => false,
    p_forced_direction_forward => true --!_!not used with p_force_status => false
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_execute_flow4
(
  p_flow_id number
)
is
begin
  ------------------------------
  at_execute_flow2
  (
    p_flow_id => p_flow_id,
    p_force_status => false,
    p_forced_direction_forward => true --!_!not used with p_force_status => false
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_flow_exact_error
(
  p_flow_id number,
  p_error_id out number,
  p_error_message out varchar2,
  p_failed_task_id out number,
  p_failed_task_index out number,
  p_failed_job_id out number,
  p_failed_job_index out number
)
is
  v_flow t_flow;
  v_task t_task;
  v_job t_job;
  v_task_count number;
  v_job_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_flow_id is null, 'p_flow_id');
  ------------------------------
  util_pkg.set_ok(p_error_id, p_error_message);
  p_failed_task_id := null;
  p_failed_task_index := null;
  p_failed_job_id := null;
  p_failed_job_index := null;
  ------------------------------
  v_flow := flow_get(p_flow_id => p_flow_id);
  ------------------------------
  if v_flow.status_id = c_stat_completed
  then
    ------------------------------
    RETURN;
    ------------------------------
  end if;
  ------------------------------
  v_task_count := get_count_cit_task(v_flow.tasks);
  ------------------------------
  for v_i in 1..v_task_count
  loop
    ------------------------------
    v_task := v_flow.tasks(v_i);
    ------------------------------
    if v_task.status_id = c_stat_completed
    then
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    v_job_count := get_count_cit_job(v_task.jobs);
    ------------------------------
    for v_j in 1..v_job_count
    loop
      ------------------------------
      v_job := v_task.jobs(v_j);
      ------------------------------
      if v_job.status_id = c_stat_completed
      then
        ------------------------------
        continue;
        ------------------------------
      end if;
      ------------------------------
      p_error_id := v_job.error_id;
      p_error_message := v_job.error_message;
      p_failed_task_id := v_task.task_id;
      p_failed_task_index := v_i;
      p_failed_job_id := v_job.job_id;
      p_failed_job_index := v_j;
      ------------------------------
      RETURN;
      ------------------------------
    end loop;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure at_inspect_flows
is
  v_flows cit_flow;
  v_count number;
  v_delay_sec number;
begin
  ------------------------------
  v_delay_sec := install_pkg.nnget_option_num(c_opt_fastp_inspflow_delay_sec, c_def_fastp_inspflow_delay_sec);
  ------------------------------
  v_flows := flows_pget_active;
  ------------------------------
  v_count := get_count_cit_flow(v_flows);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    begin
      ------------------------------
      if 1 = 1
        and util_pkg.seconds_from_date_dif(sysdate - v_flows(v_i).last_date) > v_delay_sec
        and (1 = 0
          or not install_pkg.nnget_option_bool(c_opt_fastp_inspflow_chk_jobs, c_def_fastp_inspflow_chk_jobs)
          or not flow_jobs_are_running(p_flow_id => v_flows(v_i).flow_id)
        )
      then
        ------------------------------
        at_execute_flow4(p_flow_id => v_flows(v_i).flow_id);
        ------------------------------
      end if;
      ------------------------------
    exception
    when others then
      ------------------------------
      NULL; --!_!don't fall; but NO LOGGING in execute_flow for this exception
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure at_flow_accomplish
(
  p_flow_id number,
  p_force_status boolean,
  p_direction_forward boolean
)
is
begin
  ------------------------------
  --!!!it will be handy to release broken locker programmatically; not implemented now
  at_execute_flow2(p_flow_id => p_flow_id, p_force_status => p_force_status, p_forced_direction_forward => p_direction_forward);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
