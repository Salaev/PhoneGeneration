CREATE package body REPORT999 is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_length_without_mask(p_str varchar2) return number
is
begin
  ------------------------------
  if p_str is null
  then
    return null;
  end if;
  ------------------------------
  return nvl(length(translate(p_str, '#%_', '#')), 0);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_entry_count(p_str varchar2, p_val varchar2) return number
is
begin
  ------------------------------
  if p_str is null
  then
    return null;
  end if;
  ------------------------------
  return nvl(length(p_str), 0) - nvl(length(replace(p_str, p_val, '')), 0);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_2_consume_1
(
  p_significant_symbol_count_1 number,
  p_underline_count_1 number,
  p_percent_count_1 number,
  p_significant_symbol_count_2 number,
  p_underline_count_2 number,
  p_percent_count_2 number
) return number
is
begin
  ------------------------------
  --Если у масок разное количество значимых символов первой располалагается та у которой значимых символов больше
  if p_significant_symbol_count_1 > p_significant_symbol_count_2
  then
    return util_pkg.c_true;
  end if;
  ------------------------------
  --Если у масок разное количество символов "_" первой располалагается та у которой символов "_" больше
  if p_underline_count_1 > p_underline_count_2
  then
    return util_pkg.c_true;
  end if;
  ------------------------------
  --Если у масок разное количество символов "%" первой располалагается та у которой символов "%" меньше
  if p_percent_count_1 < p_percent_count_2
  then
    return util_pkg.c_true;
  end if;
  ------------------------------
  return util_pkg.c_false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_net_op_neighbours_ii
(
  p_network_operator_ids ct_number,
  p_date date,
  p_roaming_definition_ids out ct_number
)
is
begin
  ------------------------------
  if util_pkg.get_count_ct_number(p_network_operator_ids) = 0
  then
    ------------------------------
    select /*+ ordered use_nl(non) full(non)*/
           non.roaming_definition_id
      bulk collect into p_roaming_definition_ids
      from network_operator_neighbours non
     where 1 = 1
       and p_date between non.start_date and nvl(non.end_date, util_pkg.c_plus_infinity)
    ;
    ------------------------------
  else
    ------------------------------
    select /*+ ordered use_nl(z non) full(z) index(non UK_NETWORK_OPERATOR_NEIGHBOURS)*/
           non.roaming_definition_id
      bulk collect into p_roaming_definition_ids
      from (select column_value network_operator_id from table(p_network_operator_ids)) z, network_operator_neighbours non
     where 1 = 1
       and z.network_operator_id = non.network_operator_id
       and p_date between non.start_date and nvl(non.end_date, util_pkg.c_plus_infinity)
    ;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_no_neigh_rules_relations_i
(
  p_roaming_definition_ids ct_number,
  p_out_roaming_definition_id out ct_number,
  p_consume_roaming_definition out ct_number
)
is
  v_roaming_definition_id ct_number;
  v_home_network_operator ct_number;
  v_neighbour_network_operator ct_number;
  v_location_area_codes ct_varchar_s;
  v_base_station_codes ct_varchar_s;
  --
  v_lac_significant_symbol_count ct_number;
  v_lac_underline_count ct_number;
  v_lac_percent_count ct_number;
  v_bsc_significant_symbol_count ct_number;
  v_bsc_underline_count ct_number;
  v_bsc_percent_count ct_number;
begin
  ------------------------------
  select /*+ ordered use_nl(z non la bs) full(z) index(non PK_NETWORK_OPERATOR_NEIGHBOURS) index(la PK_LOCATION_AREA) index(bs PK_BASE_STATION)*/
         non.roaming_definition_id,
         non.network_operator_id,
         non.neighbouring_operator_id,
         la.location_area_code,
         bs.base_station_code,
         nvl(get_length_without_mask(la.location_area_code), -1) lac_significant_symbol_count,
         nvl(get_entry_count(la.location_area_code, '_'), -1) lac_underline_count,
         nvl(get_entry_count(la.location_area_code, '%'), 100500) lac_percent_count,
         nvl(get_length_without_mask(bs.base_station_code), -1) bsc_significant_symbol_count,
         nvl(get_entry_count(bs.base_station_code, '_'), -1) bsc_underline_count,
         nvl(get_entry_count(bs.base_station_code, '%'), 100500) bsc_percent_count
    bulk collect into v_roaming_definition_id,
                      v_home_network_operator,
                      v_neighbour_network_operator,
                      v_location_area_codes,
                      v_base_station_codes,
                      v_lac_significant_symbol_count,
                      v_lac_underline_count,
                      v_lac_percent_count,
                      v_bsc_significant_symbol_count,
                      v_bsc_underline_count,
                      v_bsc_percent_count
    from (select column_value roaming_definition_id from table(p_roaming_definition_ids)) z, network_operator_neighbours non, location_area la, base_station bs
   where 1 = 1
     and non.roaming_definition_id = z.roaming_definition_id
     and la.location_area_id(+) = non.location_area_id
     and bs.base_station_id(+) = non.base_station_id
    ;
  ------------------------------
  with rules as
  (select /*+ ordered use_hash(q1 q2 q3 q4 q5) full(q1) full(q2) full(q3) full(q4) full(q5)*/
          q1.roaming_definition_id,
          q2.home_network_operator_id,
          q3.neighbouring_operator_id,
          q4.location_area_code,
          q5.base_station_code,
          q6.lac_significant_symbol_count,
          q7.lac_underline_count,
          q8.lac_percent_count,
          q9.bsc_significant_symbol_count,
          q10.bsc_underline_count,
          q11.bsc_percent_count
     from
       (select column_value roaming_definition_id, rownum rn from table(v_roaming_definition_id)) q1,
       (select column_value home_network_operator_id, rownum rn from table(v_home_network_operator)) q2,
       (select column_value neighbouring_operator_id, rownum rn from table(v_neighbour_network_operator)) q3,
       (select column_value location_area_code, rownum rn from table(v_location_area_codes)) q4,
       (select column_value base_station_code, rownum rn from table(v_base_station_codes)) q5,
       (select column_value lac_significant_symbol_count, rownum rn from table(v_lac_significant_symbol_count)) q6,
       (select column_value lac_underline_count, rownum rn from table(v_lac_underline_count)) q7,
       (select column_value lac_percent_count, rownum rn from table(v_lac_percent_count)) q8,
       (select column_value bsc_significant_symbol_count, rownum rn from table(v_bsc_significant_symbol_count)) q9,
       (select column_value bsc_underline_count, rownum rn from table(v_bsc_underline_count)) q10,
       (select column_value bsc_percent_count, rownum rn from table(v_bsc_percent_count)) q11
     where 1 = 1
     and q2.rn = q1.rn
     and q3.rn = q1.rn
     and q4.rn = q1.rn
     and q5.rn = q1.rn
     and q6.rn = q1.rn
     and q7.rn = q1.rn
     and q8.rn = q1.rn
     and q9.rn = q1.rn
     and q10.rn = q1.rn
     and q11.rn = q1.rn
     order by lac_significant_symbol_count desc, lac_underline_count desc, lac_percent_count asc, bsc_significant_symbol_count desc, bsc_underline_count desc, bsc_percent_count asc
  )
  select r.roaming_definition_id,
         (select r2.roaming_definition_id from rules r2
                 where 1 = 1
                 and rownum = 1
                 and r2.roaming_definition_id <> r.roaming_definition_id
                 and r2.home_network_operator_id = r.home_network_operator_id
                 and r2.neighbouring_operator_id = r.neighbouring_operator_id
                 and r.location_area_code like nvl(r2.location_area_code, '%')
                 and r.base_station_code like nvl(r2.base_station_code, '%')
                 and (util_pkg.int_to_int_2val(is_2_consume_1(r.bsc_significant_symbol_count, r.bsc_underline_count, r.bsc_percent_count, r2.bsc_significant_symbol_count, r2.bsc_underline_count, r2.bsc_percent_count)) = util_pkg.c_true
                   or util_pkg.int_to_int_2val(is_2_consume_1(r.lac_significant_symbol_count, r.lac_underline_count, r.lac_percent_count, r2.lac_significant_symbol_count, r2.lac_underline_count, r2.lac_percent_count)) = util_pkg.c_true)
         ) consumer_roaming_definition_id
    bulk collect into p_out_roaming_definition_id, p_consume_roaming_definition
    from rules r
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_valuable_no_neigh_rules_i
(
  p_roaming_definition_id ct_number,
  p_out_roaming_definition_id out ct_number,
  p_roaming_type_code out ct_number,
  p_act out ct_number
)
is
  v_roaming_definition_id_0 ct_number;
  v_consume_roaming_definition_0 ct_number;
  --
  v_roaming_definition_id ct_number;
  v_consume_roaming_definition ct_number;
  v_roaming_type_code ct_number;
  v_act ct_number;
begin
  ------------------------------
  get_no_neigh_rules_relations_i
  (
    p_roaming_definition_ids => p_roaming_definition_id,
    p_out_roaming_definition_id => v_roaming_definition_id_0,
    p_consume_roaming_definition => v_consume_roaming_definition_0
  );
  ------------------------------
  with roaming_rules as
  (select q1.roaming_definition_id, q2.consume_roaming_definition
    from (select column_value roaming_definition_id, rownum rn from table(v_roaming_definition_id_0)) q1,
         (select column_value consume_roaming_definition, rownum rn from table(v_consume_roaming_definition_0)) q2
    where 1 = 1
    and q2.rn = q1.rn
    order by q1.rn),
    ert as
  (select rr.roaming_definition_id, rr.consume_roaming_definition, q3.roaming_type_code
    from roaming_rules rr,
         (select c_roaming_neighbour_regions roaming_type_code from dual
          union
          select c_roaming_federal_districts roaming_type_code from dual) q3
    where 1 = 1)
  select roaming_definition_id, consume_roaming_definition, roaming_type_code, act
    bulk collect into v_roaming_definition_id, v_consume_roaming_definition, v_roaming_type_code , v_act
    from(
          select /*+ use_nl(t none) full(t) index(none UI_NO_NEIGH_RD_ID_ROAM_TYPE)*/
                 t.roaming_definition_id, t.consume_roaming_definition, t.roaming_type_code, decode(none.ext_roaming_type_code, t.roaming_type_code, c_active, c_not_active) act
            from ert t,
                 network_operator_neighb_ext none
           where 1 = 1
             and none.roaming_definition_id(+) = t.roaming_definition_id
             and none.ext_roaming_type_code(+) = t.roaming_type_code
           union all
          select /*+ use_nl(r none) full(r) index(non PK_NETWORK_OPERATOR_NEIGHBOURS)*/
                 r.roaming_definition_id, r.consume_roaming_definition, non.roaming_type_code roaming_type_code, c_active act
            from roaming_rules r,
                 network_operator_neighbours non
           where 1 = 1
           and non.roaming_definition_id = r.roaming_definition_id
        )
  ;
  ------------------------------
  with ert as
  (select q1.roaming_definition_id, q2.consume_roaming_definition, q3.roaming_type_code, q4.act
    from (select column_value roaming_definition_id, rownum rn from table(v_roaming_definition_id)) q1,
         (select column_value consume_roaming_definition, rownum rn from table(v_consume_roaming_definition)) q2,
         (select column_value roaming_type_code, rownum rn from table(v_roaming_type_code)) q3,
         (select column_value act, rownum rn from table(v_act)) q4
    where 1 = 1
    and q2.rn = q1.rn
    and q3.rn = q1.rn
    and q4.rn = q1.rn
    order by q1.rn)
    select distinct roaming_definition_id, roaming_type_code, act
    bulk collect into p_out_roaming_definition_id, p_roaming_type_code, p_act
    from (select t.roaming_definition_id,
               t.consume_roaming_definition,
               t.roaming_type_code,
               t.act,
               replace(sys_connect_by_path(decode(t.act, c_not_active, null, '1'),','),',','') valuable
          from ert t
       connect by prior t.roaming_definition_id = t.consume_roaming_definition and prior t.roaming_type_code = t.roaming_type_code
       start with t.consume_roaming_definition is null)
   where 1 = 1
     and valuable is not null
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_net_op_neighbours_i
(
  p_network_operator_codes ct_varchar_s,
  p_date date,
  p_out_roaming_definition_id out ct_number,
  p_roaming_type_code out ct_number,
  p_act out ct_number
)
is
  v_network_operator_ids ct_number;
  v_roaming_definition_id01 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date is null');
  ------------------------------
  v_network_operator_ids := util_ri.get_network_operator_id(p_network_operator_codes, p_date, false);
  ------------------------------
  util_pkg.xis_nulls_ct_number(v_network_operator_ids);
  ------------------------------
  get_net_op_neighbours_ii
  (
    p_network_operator_ids => v_network_operator_ids,
    p_date => p_date,
    p_roaming_definition_ids => v_roaming_definition_id01
  );
  ------------------------------
  get_valuable_no_neigh_rules_i
  (
    p_roaming_definition_id => v_roaming_definition_id01,
    p_out_roaming_definition_id => p_out_roaming_definition_id,
    p_roaming_type_code => p_roaming_type_code,
    p_act => p_act
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_net_op_neighbours
(
  p_network_operator_codes ct_varchar_s,
  p_date date,
  p_result_list out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_roaming_definition_id ct_number;
  v_roaming_type_code ct_number;
  v_act ct_number;
begin
  ------------------------------
  get_net_op_neighbours_i
  (
    p_network_operator_codes => p_network_operator_codes,
    p_date => p_date,
    p_out_roaming_definition_id => v_roaming_definition_id,
    p_roaming_type_code => v_roaming_type_code,
    p_act => v_act
  );
  ------------------------------
  get_result_cursor01
  (
    p_roaming_definition_id => v_roaming_definition_id,
    p_roaming_type_code => v_roaming_type_code,
    p_act => v_act,
    p_result => p_result_list
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure reports_get_phones
(
  p_host_id number,
  p_network_operator_id number,
  p_phone_type varchar2,
  p_salability_category_l ct_varchar_s,
  p_phone_number_status_code ct_varchar_s,
  p_search_date date,
  p_error_code out number,
  p_error_message out varchar2,
  p_result_list out sys_refcursor
)
is
  v_phone_type varchar2(2) := trim(p_phone_type);
  v_date date := nvl(p_search_date, sysdate);
  v_nas_count number;
  v_sc_count number;
  v_sql_text varchar2(32767);
  v_net_addr_stat_code varchar2(32767);
  v_sel_cat_code varchar2(32767);
begin
  ------------------------------
  v_nas_count := util_pkg.get_count_ct_varchar_s(p_phone_number_status_code);
  v_net_addr_stat_code := util_pkg.merge_string(util_pkg.cast_ct_varchar_s2varchar(util_coll_pkg.trim_ct_varchar_s(p_phone_number_status_code)), util_pkg.c_msg_delim_comma, util_pkg.c_quote, util_pkg.c_quote);
  ------------------------------
  v_sc_count := util_pkg.get_count_ct_varchar_s(p_salability_category_l);
  v_sel_cat_code := util_pkg.merge_string(util_pkg.cast_ct_varchar_s2varchar(util_coll_pkg.trim_ct_varchar_s(p_salability_category_l)), util_pkg.c_msg_delim_comma, util_pkg.c_quote, util_pkg.c_quote);
  ------------------------------
  delete from tt_net_operator;
  ------------------------------
  insert into tt_net_operator
  (
    network_operator_id,
    network_operator_code,
    network_operator_name,
    network_operator_type,
    country,
    error_code
  )
  select /*+ ordered use_nl(no, pso, pns) use_hash(pnt)
    index_asc(no, PK_NETWORK_OPERATOR)
    index_asc(pso, I_PHOSEOPER_NET_OPERATOR_ID)
    index_asc(pns, PK_PHONE_NUMBER_SERIES)
    full(pnt)
    vsmirnov*/
    no.network_operator_id,
    no.network_operator_code,
    pnt.phone_number_type_name network_operator_name,
    pns.phone_number_type_code network_operator_type,
    pns.host_id country,
    pns.phone_number_series_id error_code
    from network_operator no, phone_series_operator pso, phone_number_series pns, phone_number_type pnt
    where 1 = 1
    and no.network_operator_id = p_network_operator_id
    and pso.network_operator_id = no.network_operator_id
    and pns.phone_number_series_id = pso.phone_number_series_id
    and trim(pnt.phone_number_type_code) = trim(pns.phone_number_type_code)
    --
    and (v_phone_type is null or pns.phone_number_type_code = v_phone_type)
    and (p_host_id is null or pns.host_id = p_host_id)
    --
    and nvl(no.deleted, v_date + 123) > v_date
    and v_date between pso.start_date and nvl(pso.end_date, v_date)
    and nvl(pns.deleted, v_date + 123) > v_date
    and nvl(pnt.deleted, v_date + 123) > v_date
    --
    order by pns.phone_number_series_id
  ;
  ------------------------------
  ------------------------------
  if p_search_date is null
  then
    ------------------------------
    v_sql_text := q'{select /*+ driving_site(nopns) ordered use_hash(nopns, pn, naap, nas)
  full(nopns)
  full(pn)
  full(naap)
  full(nas)
  vsmirnov*/
  pn.international_format msisdn,
  nopns.country host_id,
  nopns.network_operator_type phone_number_type_code,
  pn.salability_category_code,
  nas.net_address_status_name,
  pn.date_of_status_change start_date,
  nopns.network_operator_code,
  nopns.network_operator_name phone_number_type_name
  from tt_net_operator nopns,
      phone_number pn,
      network_address_access_point naap,
      network_address_status nas
  where 1 = 1
  and pn.phone_number_series_id = nopns.error_code
  --
  and (:v_sc_count = 0 or pn.salability_category_code in (:p_sel_cat_code))
  and (:v_nas_count = 0 or pn.net_address_status_code in (:p_net_addr_stat_code))
  --
  and naap.network_address_id(+) = pn.network_address_id
  and naap.network_address_id is null
  --
  and nas.net_address_status_code = pn.net_address_status_code
  --
  and nvl(pn.deleted, :v_date + 123) > :v_date
  and :v_date between naap.from_date(+) and nvl(naap.to_date(+), to_date('01.01.4000', 'dd.mm.yyyy'))
}'
    ;
    ------------------------------
    v_sql_text := replace(v_sql_text, ':p_net_addr_stat_code', nvl(v_net_addr_stat_code, 'null'));
    v_sql_text := replace(v_sql_text, ':p_sel_cat_code', nvl(v_sel_cat_code, 'null'));
    ------------------------------
    open p_result_list for v_sql_text using
      v_sc_count,
      v_nas_count,
      v_date,
      v_date, v_date
    ;
    ------------------------------
  else
    ------------------------------
    v_sql_text := q'{select /*+ driving_site(no) ordered use_nl(nopns, pn, naap, pnsc, nash) use_hash(nas)
  full(nopns)
  index_asc(pn, I_PHONENUM_PHONE_NUM_SERIES_ID)
  index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID2)
  index_asc(pnsc, I_PHONUSALCA_NET_ADDRESS_ID)
  index_asc(nash, I_NETADSTAHI_NETWORK_ADDRES_ID)
  full(nas)
  vsmirnov*/
  pn.international_format msisdn,
  nopns.country host_id,
  nopns.network_operator_type phone_number_type_code,
  pnsc.salability_category_code,
  nas.net_address_status_name,
  nash.start_date,
  nopns.network_operator_code,
  nopns.network_operator_name phone_number_type_name
  from tt_net_operator nopns,
      phone_number pn,
      network_address_access_point naap,
      phone_number_salability_categ pnsc,
      network_address_status_history nash,
      network_address_status nas
  where 1 = 1
  and pn.phone_number_series_id = nopns.error_code
  --
  and naap.network_address_id(+) = pn.network_address_id
  and naap.network_address_id is null
  --
  and pnsc.network_address_id = pn.network_address_id
  and (:v_sc_count = 0 or pnsc.salability_category_code in (:p_sel_cat_code))
  and nash.network_address_id = pn.network_address_id
  and (:v_nas_count = 0 or nash.net_address_status_code in (:p_net_addr_stat_code))
  --
  and nas.net_address_status_code = trim(nash.net_address_status_code)
  --
  and nvl(pn.deleted, :v_date + 123) > :v_date
  and :v_date between naap.from_date(+) and nvl(naap.to_date(+), to_date('01.01.4000', 'dd.mm.yyyy'))
  and :v_date between pnsc.start_date and nvl(pnsc.end_date, :v_date)
  and :v_date between nash.start_date and nvl(nash.end_date, :v_date)
}'
    ;
    ------------------------------
    v_sql_text := replace(v_sql_text, ':p_net_addr_stat_code', nvl(v_net_addr_stat_code, 'null'));
    v_sql_text := replace(v_sql_text, ':p_sel_cat_code', nvl(v_sel_cat_code, 'null'));
    ------------------------------
    open p_result_list for v_sql_text using
      v_sc_count,
      v_nas_count,
      v_date, v_date,
      v_date,
      v_date, v_date,
      v_date, v_date
    ;
    ------------------------------
  end if;
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_result_cursor01
(
  p_roaming_definition_id ct_number,
  p_roaming_type_code ct_number,
  p_act ct_number,
  p_result out sys_refcursor
)
is
begin
  ------------------------------
  open p_result for
with ert as
( select a.roaming_definition_id, b.roaming_type_code, c.act
    from (select column_value roaming_definition_id, rownum rn from table(p_roaming_definition_id)) a,
         (select column_value roaming_type_code, rownum rn from table(p_roaming_type_code)) b,
         (select column_value act, rownum rn from table(p_act)) c
   where 1 = 1
     and b.rn = a.rn
     and c.rn = a.rn
)
select /*+ ordered use_nl(q1 non hno no la bs h) use_hash(rt)
       full(q1)
       index(non PK_NETWORK_OPERATOR_NEIGHBOURS)
       index(hno PK_NETWORK_OPERATOR)
       index(no PK_NETWORK_OPERATOR)
       index(la PK_LOCATION_AREA)
       index(bs PK_BASE_STATION)
       index(h PK_HOST)
       full(rt)*/
  distinct
       hno.network_operator_name home_network_operator,
       q1.roaming_type_code roaming_type,
       rt.roaming_type_name,
       no.network_operator_name neighbour_network_operator,
       h.host_name,
       la.location_area_code,
       bs.base_station_code,
       q1.act
  from ert q1,
       network_operator_neighbours non,
       network_operator hno,
       network_operator no,
       location_area la,
       base_station bs,
       host h,
       roaming_type rt
  where 1 = 1
  and non.roaming_definition_id = q1.roaming_definition_id
  and hno.network_operator_id = non.network_operator_id
  and no.network_operator_id = non.neighbouring_operator_id
  and la.location_area_id(+) = non.location_area_id
  and h.host_id(+) = la.host_id
  and bs.base_station_id(+) = non.base_station_id
  and rt.roaming_type_code(+) = q1.roaming_type_code
  order by hno.network_operator_name, q1.roaming_type_code, no.network_operator_name, h.host_name, la.location_area_code, bs.base_station_code
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
end;

/
