CREATE package LEGACY_PKG is

------------------------------!------------------------------
  function xis_tran_yes(p_handle_tran varchar2, p_label varchar2 := null) return boolean;
  function xis_tran_no(p_handle_tran varchar2, p_label varchar2 := null) return boolean;
  function xis_tran_s(p_handle_tran varchar2, p_label varchar2 := null) return boolean;

------------------------------!------------------------------
  function xis_yes(p_yes_no varchar2, p_label varchar2 := null) return boolean;
  function xis_no(p_yes_no varchar2, p_label varchar2 := null) return boolean;

------------------------------!------------------------------
  procedure xcheck_handle_tran(p_handle_tran varchar2, p_label varchar2 := null);
  procedure xcheck_yes_no(p_yes_no varchar2, p_label varchar2 := null);

------------------------------!------------------------------
end;
/
