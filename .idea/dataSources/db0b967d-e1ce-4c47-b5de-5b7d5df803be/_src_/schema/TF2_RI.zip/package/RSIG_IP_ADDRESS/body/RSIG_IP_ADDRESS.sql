CREATE PACKAGE BODY RSIG_IP_ADDRESS IS

---------------------------------------------
--     FUNCTION Ip_To_Number
---------------------------------------------

FUNCTION Ip_To_Number
(
  p_str_num     IN VARCHAR2,
  p_ip_version  IN NUMBER,
  p_raise_error IN CHAR,
  error_code    OUT NUMBER,
  error_message OUT VARCHAR2
) RETURN NUMBER IS
  v_event_source VARCHAR2(60) := 'RSIG_IP_ADDRESS.Ip_To_Number';
  v_sqlcode      NUMBER;
  v_number       NUMBER;
  v_str_num      VARCHAR2(4);
  --  v_num   NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  v_number := 0;

  IF p_str_num IS NULL
     OR p_ip_version NOT IN (c_ipv4, c_ipv6)
     OR length(trim(p_str_num)) > 4
     OR (length(trim(p_str_num)) > 3 AND p_ip_version = c_ipv4) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  v_str_num := TRIM(p_str_num); --remove white chars

  IF p_ip_version = c_ipv4 THEN
    BEGIN
      v_number := to_number(v_str_num);
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE = c_SQLCODE_INVALID_NUMBER
           OR SQLCODE = c_SQLCODE_NUMERIC_ERROR THEN
          -- for erreo in conversion
          RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Numeric or conversion error!');
        ELSE
          RAISE;
        END IF;
    END;
    IF v_number > c_max_ipv4 THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Too large number.');
    END IF;
  ELSE
    FOR i IN 1 .. length(v_str_num)
    LOOP
      --for all hex-digits
      v_number := v_number * 16;
      IF substr(v_str_num, i, 1) IN ('1', '2', '3', '4', '5', '6', '7', '8', '9', '0') THEN
        v_number := v_number + to_number(substr(v_str_num, i, 1));
      ELSIF upper(substr(v_str_num, i, 1)) IN ('A', 'B', 'C', 'D', 'E', 'F') THEN
        v_number := v_number + (ASCII(upper(substr(v_str_num, i, 1))) - ASCII('A') + 10);
      ELSE
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Disallowed char detected!');
      END IF;
    END LOOP;
    IF v_number > c_max_ipv6 THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Too large number.');
    END IF;

  END IF;

  RETURN v_number;
  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END IP_TO_NUMBER;

---------------------------------------------
--     FUNCTION Ip_To_Char
---------------------------------------------

FUNCTION Ip_To_Char
(
  p_number      IN NUMBER,
  p_ip_version  IN NUMBER,
  p_raise_error IN CHAR,
  error_code    OUT NUMBER,
  error_message OUT VARCHAR2
) RETURN VARCHAR2 IS
  v_event_source VARCHAR2(60) := 'RSIG_IP_ADDRESS.Ip_To_Char';
  v_number       NUMBER;
  v_mod          NUMBER;
  v_sqlcode      NUMBER;
  v_varchar      VARCHAR2(4);
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  IF p_number IS NULL
     OR p_ip_version NOT IN (c_ipv4, c_ipv6)
     OR p_number < 0
     OR p_number > c_max_ipv6
     OR (p_number > c_max_ipv4 AND p_ip_version = c_ipv4) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  IF p_ip_version = c_ipv4
     OR p_number = 0 THEN
    --special handling for 0
    v_varchar := TO_CHAR(p_number);
  ELSE
    v_number := p_number;
    WHILE v_number > 0
    LOOP
      -- while we have to do
      v_mod := MOD(v_number, 16); -- get  v number mod 16

      IF v_mod < 10 THEN
        -- get hexa digit from mod
        v_varchar := to_char(v_mod) || v_varchar;
      ELSE
        v_varchar := CHR(ASCII('A') + (v_mod - 10)) || v_varchar;
      END IF;
      v_number := v_number - v_mod; --substract
      v_number := v_number / 16; --rsh 4 - for get next hexa digit
    END LOOP;
    -- p_varchar := lpad(p_varchar,4,'0');
  END IF;
  RETURN v_varchar;
  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
    RETURN NULL;
END IP_TO_CHAR;

---------------------------------------------
--     PROCEDURE Ip_Address_To_Bin
---------------------------------------------

PROCEDURE Ip_Address_To_Bin
(
  p_ip_address  IN IP_ADDRESS.IP_ADDRESS%TYPE,
  p_ip_version  IN IP_ADDRESS_SERIE.IP_VERSION%TYPE,
  p_ip_binary   OUT VARCHAR2,
  p_raise_error IN CHAR,
  error_code    OUT NUMBER,
  error_message OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IP_ADDRESS.Ip_Address_To_Bin';
  TYPE t_number IS TABLE OF NUMBER;
  var_IP_num t_number;
  v_sqlcode  NUMBER;
  v_ip_norm  VARCHAR2(40);
  v_ip_next  IP_ADDRESS.IP_ADDRESS%TYPE;
  v_cnt      NUMBER;
  v_delim    CHAR(1);
  v_part_bin VARCHAR2(16);
  v_num      NUMBER;
  v_bit      NUMBER;
  v_wide     NUMBER;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  var_IP_num := t_number();

  IF p_ip_address IS NULL
     OR p_ip_version IS NULL
     OR p_ip_version NOT IN (4, 6) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- procedure body here
  Test_IP_address_OK(p_ip_address,
                     p_ip_version,
                     v_ip_norm,
                     v_ip_next,
                     RSIG_UTILS.c_YES,
                     error_code,
                     error_message);

  IF p_ip_version = 4 THEN
    v_cnt     := c_max_part_ipv4;
    v_delim   := c_point;
    v_ip_norm := v_ip_norm || c_point;
    v_wide    := 8;
  ELSE
    v_cnt     := c_max_part_ipv6;
    v_delim   := c_dpoint;
    v_ip_norm := v_ip_norm || c_dpoint;
    v_wide    := 16;
  END IF;

  var_IP_num.EXTEND(v_cnt);
  FOR i IN 1 .. v_cnt
  LOOP
    v_num      := ip_to_number(substr(v_ip_norm, 1, instr(v_ip_norm, v_delim, 1, 1) - 1),
                               p_ip_version,
                               RSIG_UTILS.c_YES,
                               error_code,
                               error_message);
    v_part_bin := '';
    v_bit      := 1;
    FOR j IN 1 .. v_wide
    LOOP
      IF BITAND(v_num, v_bit) > 0 THEN
        v_part_bin := '1' || v_part_bin;
      ELSE
        v_part_bin := '0' || v_part_bin;
      END IF;
      v_bit := v_bit * 2;
    END LOOP;
    p_ip_binary := p_ip_binary || v_part_bin;
    v_ip_norm   := substr(v_ip_norm, instr(v_ip_norm, v_delim, 1, 1) + 1);
  END LOOP;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END IP_Address_to_bin;


---------------------------------------------
--     PROCEDURE Ip_Address_To_Number
---------------------------------------------

PROCEDURE Ip_Address_To_Number
(
  p_ip_address  IN IP_ADDRESS.IP_ADDRESS%TYPE,
  p_ip_version  IN IP_ADDRESS_SERIE.IP_VERSION%TYPE,
  p_ip_number   OUT NUMBER,
  p_raise_error IN CHAR,
  error_code    OUT NUMBER,
  error_message OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IP_ADDRESS.Ip_Address_To_Number';
  TYPE t_number IS TABLE OF NUMBER;
  var_IP_num t_number;
  v_sqlcode  NUMBER;
  v_ip_norm  VARCHAR2(40);
  v_ip_next  IP_ADDRESS.IP_ADDRESS%TYPE;
  v_cnt      NUMBER;
  v_delim    CHAR(1);
  v_num      NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  var_IP_num := t_number();
  -- check handle_tran parameter
  IF p_ip_address IS NULL
     OR p_ip_version IS NULL
     OR p_ip_version NOT IN (4, 6) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- procedure body here
  Test_IP_address_OK(p_ip_address,
                     p_ip_version,
                     v_ip_norm,
                     v_ip_next,
                     RSIG_UTILS.c_YES,
                     error_code,
                     error_message);

  IF p_ip_version = 4 THEN
    v_cnt     := c_max_part_ipv4;
    v_delim   := c_point;
    v_ip_norm := v_ip_norm || c_point;
  ELSE
    v_cnt     := c_max_part_ipv6;
    v_delim   := c_dpoint;
    v_ip_norm := v_ip_norm || c_dpoint;
  END IF;

  var_IP_num.EXTEND(v_cnt);
  p_ip_number := 0;
  FOR i IN 1 .. v_cnt
  LOOP
    v_num := ip_to_number(substr(v_ip_norm, 1, instr(v_ip_norm, v_delim, 1, 1) - 1),
                          p_ip_version,
                          RSIG_UTILS.c_YES,
                          error_code,
                          error_message);
    IF p_ip_version = c_ipv4 THEN
      p_ip_number := p_ip_number * (c_max_ipv4 + 1);
      p_ip_number := p_ip_number + v_num;
    ELSE
      p_ip_number := p_ip_number * (c_max_ipv6 + 1);
      p_ip_number := p_ip_number + v_num;
    END IF;
    v_ip_norm := substr(v_ip_norm, instr(v_ip_norm, v_delim, 1, 1) + 1);
  END LOOP;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END IP_ADDRESS_TO_NUMBER;


---------------------------------------------
--     PROCEDURE Ip_Number_To_Address
---------------------------------------------

PROCEDURE Ip_Number_To_Address
(
  p_ip_number   IN IP_ADDRESS.IP_NUMBER%TYPE,
  p_ip_version  IN IP_ADDRESS_SERIE.IP_VERSION%TYPE,
  p_ip_address  OUT IP_ADDRESS.IP_ADDRESS%TYPE,
  p_raise_error IN CHAR,
  error_code    OUT NUMBER,
  error_message OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IP_ADDRESS.Ip_Number_To_Address';
  v_sqlcode      NUMBER;
  v_work_number  NUMBER;
  v_ip_address   varchar2(40); --IP_ADDRESS.IP_ADDRESS%TYPE;
  v_mod          NUMBER;
  v_mod_number   NUMBER;
  v_IP_part      VARCHAR2(4);
  v_run          NUMBER(1);
  v_max_run      NUMBER;
  v_delim        CHAR(1);
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  IF p_ip_number IS NULL
     OR p_ip_version IS NULL
     OR p_ip_version NOT IN (c_ipv4, c_ipv6) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- procedure body here
  IF p_ip_version = c_ipv4 THEN
    -- set params for ipv4
    v_mod     := c_max_ipv4 + 1; -- modus
    v_max_run := c_max_part_ipv4; -- max parts of IP_address
    v_delim   := c_point; -- delimeter
    IF p_ip_number > c_max_ip_number_ipv4 THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER,
                              'Invalid input parameter, maximum IP number excceded.');
    END IF;
  ELSE
    v_mod     := c_max_ipv6 + 1; -- modus
    v_max_run := c_max_part_ipv6; -- max parts of IP_address
    v_delim   := c_dpoint; -- delimeter
    IF p_ip_number > c_max_ip_number_ipv6 THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER,
                              'Invalid input parameter, maximum IP number excceded.');
    END IF;
  END IF;

  v_run         := 0; -- detection of number of cycles
  v_work_number := p_ip_number;
  WHILE v_work_number > 0
        OR v_run < v_max_run
  LOOP
    v_mod_number  := MOD(v_work_number, v_mod); -- get modus
    v_work_number := (v_work_number - v_mod_number) / v_mod; -- calculate remaining number
    v_IP_part     := IP_TO_CHAR(v_mod_number, p_ip_version, RSIG_UTILS.c_YES, error_code, error_message); -- get char reprezentation of modus
    IF v_run = 0 THEN
      -- first time
      v_ip_address := v_IP_part; -- do not insert delimeter at the end
    ELSE
      v_ip_address := v_IP_part || v_delim || v_ip_address; --concatenation
    END IF;
    v_run := v_run + 1; --next run
  END LOOP;

  p_ip_address := v_ip_address;
  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END IP_NUMBER_TO_ADDRESS;

---------------------------------------------
--     PROCEDURE Test_Ip_Address_Ok
---------------------------------------------

PROCEDURE Test_Ip_Address_Ok
(
  p_ip_address            IN IP_ADDRESS.IP_ADDRESS%TYPE,
  p_ip_version            IN IP_ADDRESS_SERIE.IP_VERSION%TYPE,
  p_ip_address_normalized OUT IP_ADDRESS.IP_ADDRESS%TYPE,
  p_next_ip               OUT IP_ADDRESS.IP_ADDRESS%TYPE,
  p_raise_error           IN CHAR,
  error_code              OUT NUMBER,
  error_message           OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IP_ADDRESS.Test_Ip_Address_Ok';
  TYPE t_var_arr IS VARRAY(8) OF VARCHAR2(4); -- type specification
  v_sqlcode     NUMBER;
  var_IP        t_var_arr; -- array of varchars (max 4 digits (ipv6) long, decimal or hexadecimal digits alowed
  v_ip_version  NUMBER; -- ip version -> c_ipv6, or c_ipv4
  v_ip_address  IP_ADDRESS.IP_ADDRESS%TYPE;
  v_arr_pos     NUMBER; -- position in array
  v_char        CHAR(1);
  dd            NUMBER; --delimiter monitor
  nn            NUMBER; --number monitor
  v_last_nnull  NUMBER; --index of last not null part of ipv6
  v_shift       NUMBER; --shift for make normalized ipv6
  v_dd_detected NUMBER; --for detecting number of occurence :: (in ipv6 specification is allowed only one ocuurence)
  v_carry       NUMBER; -- carry flag for transfer overflow of lower number to higher
  v_number      NUMBER; -- temp variable
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  v_ip_version := p_ip_version;
  IF p_ip_address IS NULL
     OR (p_ip_version IS NOT NULL AND p_ip_version NOT IN (4, 6))
     OR length(TRIM(p_ip_address)) > c_max_length_of_ip_address THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Wrong input format of some parameter');
  END IF;

  -- initialize array

  var_IP        := t_var_arr('', '', '', '', '', '', '', ''); -- initialization of array
  v_arr_pos     := 1;
  v_ip_address  := TRIM(p_ip_address); -- cut off leeadin and trailing zeros
  dd            := 0; -- set detector to non-excited state ;-)
  nn            := 0; --
  v_dd_detected := 0;

  -- chceck version of ip address
  IF v_ip_version IS NULL THEN
    IF instr(p_ip_address, c_dpoint) <> 0
       AND instr(p_ip_address, c_point) = 0 THEN
      v_ip_version := c_ipv6;
    ELSIF instr(p_ip_address, c_point) <> 0
          AND instr(p_ip_address, c_dpoint) = 0 THEN
      v_ip_version := c_ipv4;
    ELSE
      v_ip_version := NULL;
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER,
                              'Wrong format of ip address, mixed `.` and `:`!');
    END IF;
  END IF;

  IF v_ip_version = c_ipv6
     AND v_ip_address = '::' THEN
    --special case of ipv6 address and means unspecified address
    v_ip_address := '0::'; -- transform it for future processing
  END IF;

  IF v_ip_version = c_ipv6 THEN
    IF instr(v_ip_address, '::', 1) = 1 THEN
      v_ip_address := REPLACE(v_ip_address, '::', '0::');
    ELSIF instr(v_ip_address, '::', 1) = length(v_ip_address) - 1 THEN
      v_ip_address := REPLACE(v_ip_address, '::', '::0');
    ELSIF instr(v_ip_address, ':', 1) = 1
          OR instr(v_ip_address, ':', -1) = length(v_ip_address) THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER,
                              'Wrong format of ip address, : at the begining or end of IP!');
    END IF;
  END IF;

  --detecting leeding and trailing delimeters
  IF substr(v_ip_address, 1, 1) IN (c_point)
     OR substr(v_ip_address, -1, 1) IN (c_point) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Leading or trailing ');
  END IF;

  -- for all chars in ip_address
  FOR i IN 1 .. length(v_ip_address)
  LOOP
    v_char := substr(v_ip_address, i, 1); --fetch char
    IF v_char IN (c_point, c_dpoint) THEN
      -- if it is delimiter (. for ipv4, : for ipv6)
      v_arr_pos := v_arr_pos + 1; -- so we go for fill next field in array
      nn        := 0;
      IF ((dd < 1 AND v_ip_version = c_ipv4) OR --for ipv4 is not allowed 2 and more following delimeters -> '123..35'
         (dd < 2 AND v_ip_version = c_ipv6)) --for ipv6 is not allowed 3 and more  following delimeters -> 'A123:::FF35'
       THEN
        dd := dd + 1; -- increment detector
        IF dd = 2 THEN
          v_dd_detected := v_dd_detected + 1; -- count how much times we detect '::'
        END IF;
        IF v_dd_detected = 2 THEN
          -- if we detect '::' more then once it is wrong ip address v6
          RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, ''); -- detected '::' twice
        END IF;
      ELSE
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, ''); -- detected :::       -- for all other cases ... raise error
      END IF;
    ELSIF INSTR('0123456789abcdefABCDEF', v_char) <> 0
          AND v_ip_version = c_ipv6
          AND nn < 4 THEN
      --if it is hexa-number for ipv6
      var_IP(v_arr_pos) := var_IP(v_arr_pos) || v_char; --store them
      nn := nn + 1;
      dd := 0; -- set detector to non-excited state ;-)
    ELSIF INSTR('0123456789', v_char) <> 0
          AND v_ip_version = c_ipv4
          AND nn < 3 THEN
      --if it is decimal number for ipv4
      var_IP(v_arr_pos) := var_IP(v_arr_pos) || v_char; --store them
      nn := nn + 1;
      dd := 0; -- set detector to non-excited state ;-)
    ELSE
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, ''); --otherwise raise error
    END IF;
  END LOOP;

  IF v_ip_version = c_ipv4
     AND v_arr_pos <> 4 THEN
    -- test for ipv4 that we have 4 numbers, for ipv6 should have less for shortened ip address
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Wrong number of ip address parts for ipv4.');
  END IF;

  IF v_ip_version = c_ipv4 THEN
    p_ip_address_normalized := v_ip_address;
  ELSIF v_ip_version = c_ipv6 THEN
    IF var_IP(c_max_part_ipv6) IS NULL THEN
      -- only if we have shortened ipv6 address
      v_last_nnull := NULL;
      -- find boundaries for shift , and space between fills with 0 (example: 'ffe0::3' -> 'ffe0:0:0:0:0:0:0:3'
      FOR i IN REVERSE 1 .. c_max_part_ipv6
      LOOP
        -- for all parts countdown
        IF var_IP(i) IS NOT NULL THEN
          -- IF we found  not null part
          v_last_nnull := i; -- store index of last not null
          v_shift      := c_max_part_ipv6 - v_last_nnull;
          EXIT;
        END IF;
        var_IP(i) := '0'; -- set NULL to '0'
      END LOOP;

      FOR j IN REVERSE 1 .. v_last_nnull
      LOOP
        IF var_IP(j) IS NULL THEN
          var_IP(j) := '0';
          EXIT;
        END IF;
        var_IP(j + v_shift) := var_IP(j); -- move last not nulls  at the end of array
        var_IP(j) := '0'; -- and place 0 instead of moved value
      END LOOP;
    END IF;
    p_ip_address_normalized := lpad(nvl(var_IP(1), '0'), 4, '0') || ':' || lpad(nvl(var_IP(2), '0'), 4, '0') || ':' ||
                               lpad(nvl(var_IP(3), '0'), 4, '0') || ':' || lpad(nvl(var_IP(4), '0'), 4, '0') || ':' ||
                               lpad(nvl(var_IP(5), '0'), 4, '0') || ':' || lpad(nvl(var_IP(6), '0'), 4, '0') || ':' ||
                               lpad(nvl(var_IP(7), '0'), 4, '0') || ':' || lpad(nvl(var_IP(8), '0'), 4, '0');
    p_ip_address_normalized := upper(p_ip_address_normalized);
  ELSE
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'dete');
  END IF;

  BEGIN
    IF v_ip_version = c_ipv4 THEN
      -- set bounds for processing (ipv4 - 4 decimal numbers, ipv6 - 8 hexadecimal numbers
      v_last_nnull := c_max_part_ipv4;
    ELSE
      v_last_nnull := c_max_part_ipv6;
    END IF;
    v_carry := 1; -- ve looking for next ip, then we set carry to 1 (it force adding for last ip number)
    FOR k IN REVERSE 1 .. v_last_nnull
    LOOP
      --for all numbers in ip addres
      v_number := IP_TO_NUMBER(nvl(var_IP(k), '0'), v_ip_version, 'Y', error_code, error_message); -- convert string to number
      v_number := v_number + v_carry; -- apply carry from last loop
      IF (v_number = (c_max_ipv4 + 1) AND v_ip_version = c_ipv4)
         OR v_number = (c_max_ipv6 + 1) THEN
        -- if overflow
        v_number := 0; --set number to zero
        v_carry  := 1; --and set carry flag to higher numbers
      ELSE
        v_carry := 0; -- if carry is consumed in this loop, we sat it to zero
      END IF;
      var_IP(k) := IP_TO_CHAR(v_number, v_ip_version, RSIG_UTILS.c_YES, error_code, error_message); -- transform  number back to string form
    END LOOP;
    IF v_carry = 1 THEN
      -- if detect overflow on the highest level
      p_next_ip := ''; -- set next_ip to NULL
    ELSE
      -- else we complete whole IP address
      IF v_ip_version = c_ipv4 THEN
        p_next_ip := nvl(var_IP(1), '0') || ':' || nvl(var_IP(2), '0') || ':' || nvl(var_IP(3), '0') || ':' ||
                     nvl(var_IP(4), '0');
      ELSE
        p_next_ip := upper(lpad(nvl(var_IP(1), '0'), 4, '0') || ':' || lpad(nvl(var_IP(2), '0'), 4, '0') || ':' ||
                           lpad(nvl(var_IP(3), '0'), 4, '0') || ':' || lpad(nvl(var_IP(4), '0'), 4, '0') || ':' ||
                           lpad(nvl(var_IP(5), '0'), 4, '0') || ':' || lpad(nvl(var_IP(6), '0'), 4, '0') || ':' ||
                           lpad(nvl(var_IP(7), '0'), 4, '0') || ':' || lpad(nvl(var_IP(8), '0'), 4, '0'));
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      -- if there is some error, report it but not crash
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --    DBMS_OUTPUT.PUT_LINE(error_message);
      error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           'RSIG_SIM_SERIES.Insert_Sim_Series');
      p_next_ip := '';
  END;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Test_IP_address_OK;

---------------------------------------------
--     PROCEDURE Is_Same_Network
---------------------------------------------

PROCEDURE Is_Same_Network
(
  p_IP_Address_1 IN IP_ADDRESS.IP_ADDRESS%TYPE,
  p_IP_Address_2 IN IP_ADDRESS.IP_ADDRESS%TYPE,
  p_mask         IN IP_ADDRESS_SERIE.MASK%TYPE,
  p_ip_version   IN IP_ADDRESS_SERIE.IP_VERSION%TYPE,
  p_raise_error  IN CHAR,
  error_code     OUT NUMBER,
  error_message  OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IP_ADDRESS.Is_Same_Network';
  v_sqlcode      number;
  v_IP_bin1      VARCHAR2(128);
  v_IP_bin2      VARCHAR2(128);
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  IF p_IP_Address_1 IS NULL
     OR p_IP_Address_2 IS NULL
     OR p_mask IS NULL
     OR p_ip_version IS NULL
     OR p_ip_version NOT IN (4, 6)
     OR p_mask > 128
     OR (p_mask > 30 AND p_ip_version = c_ipv4) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  IP_Address_to_bin(p_ip_address_1, p_ip_version, v_IP_bin1, RSIG_UTILS.c_YES, error_code, error_message);
  IP_Address_to_bin(p_ip_address_2, p_ip_version, v_IP_bin2, RSIG_UTILS.c_YES, error_code, error_message);

  v_IP_bin1 := substr(v_IP_bin1, 1, p_mask);
  v_IP_bin2 := substr(v_IP_bin2, 1, p_mask);

  IF v_IP_bin1 <> v_IP_bin2 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NOT_SAME_IP_NETWORK, 'IP addresses is not on same network!');
  END IF;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END IS_SAME_NETWORK;

---------------------------------------------
--     PROCEDURE Get_Next_Ip
---------------------------------------------

PROCEDURE Get_Next_Ip
(
  p_ip_address      IN IP_ADDRESS.IP_ADDRESS_SERIE_ID%TYPE,
  p_mask            IN IP_ADDRESS_SERIE.MASK%TYPE,
  p_ip_version      IN IP_ADDRESS_SERIE.IP_VERSION%TYPE,
  p_ip_address_next OUT IP_ADDRESS.IP_ADDRESS_SERIE_ID%TYPE,
  p_raise_error     IN CHAR,
  error_code        OUT NUMBER,
  error_message     OUT VARCHAR2
) IS
  v_event_source    VARCHAR2(60) := 'RSIG_IP_ADDRESS.Get_Next_Ip';
  v_sqlcode         NUMBER;
  v_ip_address_norm IP_ADDRESS.IP_ADDRESS_SERIE_ID%TYPE;
  v_next_ip         IP_ADDRESS.IP_ADDRESS%TYPE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  Test_IP_address_OK(p_ip_address,
                     p_ip_version,
                     v_ip_address_norm,
                     v_next_ip,
                     RSIG_UTILS.c_YES,
                     error_code,
                     error_message);

  IF v_next_ip IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_UNABLE_TO_GET_NEXT_IP, 'Can''t get next IP address!');
  END IF;
  IS_SAME_NETWORK(v_ip_address_norm,
                  v_next_ip,
                  p_mask,
                  p_ip_version,
                  RSIG_UTILS.c_YES,
                  error_code,
                  error_message);

  p_ip_address_next := v_next_ip;
  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_next_IP;


---------------------------------------------
--     PROCEDURE Insert_Ip_Address
---------------------------------------------

PROCEDURE Insert_Ip_Address
(
  p_ip_address          IN IP_ADDRESS.IP_ADDRESS%TYPE,
  p_ip_address_serie_id IN IP_ADDRESS.IP_ADDRESS_SERIE_ID%TYPE,
  p_user_id_of_change   IN IP_ADDRESS.USER_ID_OF_CHANGE%TYPE,
  p_network_address_id  OUT IP_ADDRESS.NETWORK_ADDRESS_ID%TYPE,
  handle_tran           IN CHAR,
  p_raise_error         IN CHAR,
  error_code            OUT NUMBER,
  error_message         OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IP_ADDRESS.Insert_Ip_Address';
  v_sqlcode      NUMBER;
  v_ip_version   IP_ADDRESS_SERIE.IP_VERSION%TYPE;
  v_ip_number    IP_ADDRESS.IP_NUMBER%TYPE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  IF p_ip_address IS NULL
     OR p_ip_address_serie_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, '');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Insert_IP_address;
  END IF;

  -- get ip version number
  SELECT IP_VERSION
    INTO v_ip_version
    FROM IP_ADDRESS_SERIE ias
   WHERE ias.ip_address_serie_id = p_ip_address_serie_id;

  -- compute IP_NUMBER (and also test if IP_address is OK)
  IP_ADDRESS_TO_NUMBER(p_ip_address, v_ip_version, v_ip_number, RSIG_UTILS.c_YES, error_code, error_message);

  INSERT INTO NETWORK_ADDRESS
    (NETWORK_ADDRESS_ID)
  VALUES
    (S_NETWORK_ADDRESS.NEXTVAL)
  RETURNING NETWORK_ADDRESS_ID INTO p_network_address_id;

  INSERT INTO IP_ADDRESS
    (IP_ADDRESS_SERIE_ID,
     NETWORK_ADDRESS_ID,
     IP_ADDRESS,
     USER_ID_OF_CHANGE,
     DATE_OF_CHANGE,
     DELETED,
     IP_NUMBER)
  VALUES
    (p_ip_address_serie_id,
     p_network_address_id,
     p_ip_address,
     p_user_id_of_change,
     SYSDATE,
     NULL,
     v_ip_number);

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  error_code := 0;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Insert_IP_address;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Insert_IP_address;


---------------------------------------------
--     PROCEDURE Delete_Ip_Address
---------------------------------------------

PROCEDURE Delete_Ip_Address
(
  p_network_address_id IN IP_ADDRESS.NETWORK_ADDRESS_ID%TYPE,
  p_deleted            IN DATE,
  p_user_id_of_change  IN NUMBER,
  handle_tran          IN CHAR,
  p_raise_error        IN CHAR,
  error_code           OUT NUMBER,
  error_message        OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IP_ADDRESS.Delete_Ip_Address';
  v_sqlcode      NUMBER;
  v_sysdate      DATE;
  v_deleted      DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  v_deleted := nvl(p_deleted, SYSDATE);

  IF p_network_address_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, '');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Delete_IP_address;
  END IF;

  v_sysdate := SYSDATE;
  -- procedure body here
  UPDATE IP_ADDRESS ia
     SET USER_ID_OF_CHANGE = p_user_id_of_change,
         DATE_OF_CHANGE    = v_sysdate,
         DELETED           = v_deleted
   WHERE ia.NETWORK_ADDRESS_ID = p_network_address_id;

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  error_code := 0;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Delete_IP_address;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Delete_IP_address;

---------------------------------------------
--     PROCEDURE Get_Ip_Address
---------------------------------------------

PROCEDURE Get_Ip_Address
(
  p_ip_address_serie_id IN IP_ADDRESS_SERIE.IP_ADDRESS_SERIE_ID%TYPE,
  p_ip_address          IN IP_ADDRESS.IP_ADDRESS%TYPE,
  p_ip_version          IN IP_ADDRESS_SERIE.IP_VERSION%TYPE,
  p_ip_number           IN IP_ADDRESS.IP_NUMBER%TYPE,
  p_mask                IN IP_ADDRESS_SERIE.MASK%TYPE,
  p_row_count           IN NUMBER,
  result_list           OUT sys_refcursor,
  p_raise_error         IN CHAR,
  error_code            OUT NUMBER,
  error_message         OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IP_ADDRESS.Get_Ip_Address';
  v_sqlcode      NUMBER;
  v_ip_number    NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  IF p_ip_version IS NOT NULL THEN
    IF p_ip_address IS NOT NULL THEN
      IP_ADDRESS_TO_NUMBER(p_ip_address,
                           p_ip_version,
                           v_ip_number,
                           RSIG_UTILS.c_YES,
                           error_code,
                           error_message);
      IF p_ip_number IS NOT NULL
         AND p_ip_number <> v_ip_number THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
      END IF;
    ELSE
      v_ip_number := p_ip_number;
    END IF;
  ELSE
    v_ip_number := p_ip_number;
  END IF;

  IF p_ip_address_serie_id IS NULL THEN

    OPEN result_list FOR
    SELECT /*+ index(I_IP_SERIES)*/
           ia.IP_ADDRESS_SERIE_ID,
           ia.NETWORK_ADDRESS_ID,
           ia.IP_ADDRESS,
           ia.USER_ID_OF_CHANGE,
           ia.DATE_OF_CHANGE,
           ia.DELETED,
           ia.IP_NUMBER,
           ias.IP_VERSION,
           ias.MASK
      FROM IP_ADDRESS ia
      JOIN IP_ADDRESS_SERIE ias ON ias.ip_address_serie_id = ia.ip_address_serie_id
     WHERE 1 = 1
       AND (ia.ip_number > v_ip_number OR v_ip_number IS NULL)
       AND (ias.ip_version = p_ip_version OR p_ip_version IS NULL)
       AND (ias.mask = p_mask OR p_mask IS NULL)
       AND (ROWNUM <= p_row_count OR p_row_count IS NULL)
     ORDER BY ias.ip_number_start,ias.deleted,ia.ip_number NULLS LAST;

  ELSE
    OPEN result_list FOR
    SELECT /*+ index(I_IP_SERIES)*/
           ia.IP_ADDRESS_SERIE_ID,
           ia.NETWORK_ADDRESS_ID,
           ia.IP_ADDRESS,
           ia.USER_ID_OF_CHANGE,
           ia.DATE_OF_CHANGE,
           ia.DELETED,
           ia.IP_NUMBER,
           ias.IP_VERSION,
           ias.MASK
      FROM IP_ADDRESS ia
      JOIN IP_ADDRESS_SERIE ias ON ias.ip_address_serie_id = ia.ip_address_serie_id
     WHERE 1 = 1
       AND (ia.ip_number > v_ip_number OR v_ip_number IS NULL)
       AND (ias.ip_version = p_ip_version OR p_ip_version IS NULL)
       AND ia.ip_address_serie_id = p_ip_address_serie_id
       AND (ias.mask = p_mask OR p_mask IS NULL)
       AND (ROWNUM <= p_row_count OR p_row_count IS NULL)
     ORDER BY ias.ip_number_start,ias.deleted,ia.ip_number NULLS LAST;

  END IF;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_ip_address;


END RSIG_IP_ADDRESS;
/
