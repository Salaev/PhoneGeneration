CREATE package body mnp_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_mnp_mode(p_mnp_mode number, p_label varchar2 := null)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_mnp_mode is null, util_pkg.smart_label1(p_label, 'p_mnp_mode'));
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_mnp_mode not in (c_mnpmode_normal, c_mnpmode_old, c_mnpmode_old_hash, c_mnpmode_old_hashparallel),
    util_pkg.smart_label2(p_label, 'p_mnp_mode', ' not in (c_mnpmode_normal, c_mnpmode_old, c_mnpmode_old_hash, c_mnpmode_old_hashparallel)'));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xget_rn_prefix_val return varchar2
is
begin
  ------------------------------
  return install_pkg.xget_option_str(c_opt_rn_prefix_val, NULL);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_rn_total_length return number
is
begin
  ------------------------------
  return install_pkg.xget_option_num(c_opt_rn_total_length);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure parse_network_number_i
(
  p_nn varchar2,
  p_marker_rn varchar2,
  p_length_rn number,
  p_msisdn out varchar2,
  p_rn out varchar2
)
is
  v_coll ct_varchar;
  v_msisdn varchar2(100);
  v_rn varchar2(100);
begin
  ------------------------------
  ------------------------------
  --!_!<network number> = <country code><RN><federal number>
  ------------------------------
  --!_!<RN> = DYYXX (earlier it was DYYXXZ)
  --!_!D - non-numeric char
  --!_!YY - code of subject of the Russian Federation with leading zero
  --!_!XX - MNC (Mobile Network Code) of network operator
  --!_!
  --!_!Z - digit of 1-9, HLR number in operator's network
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_nn is null, 'p_nn');
  util_pkg.XCheck_Cond_Missing(p_marker_rn is null, 'p_marker_rn');
  util_pkg.XCheck_Cond_Missing(p_length_rn is null, 'p_length_rn');
  ------------------------------
  ------------------------------
  p_msisdn := p_nn;
  p_rn := NULL;
  ------------------------------
  ------------------------------
  v_coll := util_pkg.split_string(p_nn, p_marker_rn);
  ------------------------------
  if util_pkg.get_count_ct_varchar(v_coll) != 2
  then
    ------------------------------
    RETURN;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  util_pkg.str_split2(p_marker_rn || v_coll(2), p_length_rn, v_rn, v_msisdn);
  ------------------------------
  if util_pkg.str_length(v_rn) = p_length_rn
  then
    ------------------------------
    p_msisdn := v_coll(1) || v_msisdn;
    p_rn := v_rn;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure parse_network_number
(
  p_nn ct_varchar_s,
  p_msisdn out ct_varchar_s,
  p_rn out ct_varchar_s
)
is
  v_main_count number;
  v_marker_rn varchar2(100);
  v_length_rn number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_nn);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    RETURN;
    ------------------------------
  end if;
  ------------------------------
  v_marker_rn := xget_rn_prefix_val;
  ------------------------------
  v_length_rn := xget_rn_total_length;
  ------------------------------
  util_pkg.resize_ct_varchar_s(p_msisdn, v_main_count);
  util_pkg.resize_ct_varchar_s(p_rn, v_main_count);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    parse_network_number_i
    (
      p_nn => p_nn(v_i),
      p_marker_rn => v_marker_rn,
      p_length_rn => v_length_rn,
      p_msisdn => p_msisdn(v_i),
      p_rn => p_rn(v_i)
    );
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure parse_network_number2
(
  p_nn varchar2,
  p_msisdn out varchar2,
  p_rn out varchar2
)
is
  v_nn ct_varchar_s;
  v_msisdn ct_varchar_s;
  v_rn ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_nn, p_nn);
  ------------------------------
  parse_network_number
  (
    p_nn => v_nn,
    p_msisdn => v_msisdn,
    p_rn => v_rn
  );
  ------------------------------
  p_msisdn := v_msisdn(util_ri.c_index_one);
  p_rn := v_rn(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_lsa_id(p_lsa_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
select /*+ driving_site(q) ordered use_nl(z) index_asc(z, UK_LSA_CODE)*/
  z.lsa_id, q.rn
  bulk collect into v_res, v_rn
  from (select column_value lsa_code, rownum rn from table(p_lsa_code)) q, lsa z
  where 1 = 1
  and z.lsa_code(+) = q.lsa_code
  and nvl(z.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.lsa_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'lsa');
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_lsa_id2(p_lsa_code varchar2, p_date date) return number
is
  v_lsa_code ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_lsa_code is null, 'p_lsa_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_lsa_code, p_lsa_code);
  ------------------------------
  return get_lsa_id(v_lsa_code, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_lsa_code(p_lsa_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
select /*+ driving_site(q) ordered use_nl(z) index_asc(z, PK_LSA_ID)*/
  z.lsa_code, q.rn
  bulk collect into v_res, v_rn
  from (select column_value lsa_id, rownum rn from table(p_lsa_id)) q, lsa z
  where 1 = 1
  and z.lsa_id(+) = q.lsa_id
  and nvl(z.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.lsa_code, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'lsa');
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_lsa_code2(p_lsa_id number, p_date date) return varchar2
is
  v_lsa_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_lsa_id is null, 'p_lsa_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  util_pkg.add_ct_number_val(v_lsa_id, p_lsa_id);
  ------------------------------
  return get_lsa_code(v_lsa_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_routing_number_id0(p_routing_number_code ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_routing_number_code);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_routing_number_code) != v_main_count, 'p_routing_number_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) full(q) full(q2) index_asc(z, I_ROUTING_NUMBER_CODE)*/
  z.routing_number_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value routing_number_code, rownum rn from table(p_routing_number_code)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    routing_number z
  where 1 = 1
  and q2.rn = q.rn
  and z.routing_number_code = q.routing_number_code
  and q2.validity_date between z.date_from and z.date_to
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'routing_number');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_routing_number_id(p_routing_number_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_varchar_s(p_routing_number_code), p_date);
  ------------------------------
  return get_routing_number_id0(p_routing_number_code, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_routing_number_id2(p_routing_number_code varchar2, p_date date) return number
is
  v_routing_number_code ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_routing_number_code, p_routing_number_code);
  ------------------------------
  return get_routing_number_id(v_routing_number_code, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_routing_number_code0(p_routing_number_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_routing_number_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_routing_number_id) != v_main_count, 'p_routing_number_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) full(q) full(q2) index_asc(z, I_ROUTING_NUMBER_ID)*/
  z.routing_number_code, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value routing_number_id, rownum rn from table(p_routing_number_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    routing_number z
  where 1 = 1
  and q2.rn = q.rn
  and z.routing_number_id = q.routing_number_id
  and q2.validity_date between z.date_from and z.date_to
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'routing_number');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_routing_number_code(p_routing_number_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_routing_number_id), p_date);
  ------------------------------
  return get_routing_number_code0(p_routing_number_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_routing_number_code2(p_routing_number_id number, p_date date) return varchar2
is
  v_routing_number_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_routing_number_id, p_routing_number_id);
  ------------------------------
  return get_routing_number_code(v_routing_number_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_rn_id4host0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_host_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_host_id) != v_main_count, 'p_host_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, I_ROUTING_NUMBER_HOST_HOST_ID)*/
  z.routing_number_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value host_id, rownum rn from table(p_host_id)) q,
    (select column_value q_date, rownum rn from table(p_date)) q2,
    routing_number_host z
  where 1 = 1
  and q2.rn = q.rn
  and z.host_id = q.host_id
  and q2.q_date between z.date_from and z.date_to
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'routing_number_host');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_rn_id4host(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_host_id), p_date);
  ------------------------------
  return get_rn_id4host0(p_host_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_rn_id4host2(p_host_id number, p_date date) return number
is
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  return get_rn_id4host(v_host_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_rn_id4host_all(p_date date, p_host_id out ct_number, p_routing_number_id out ct_number, p_xcheck_data boolean := true)
is
  v_rn ct_number;
  v_rn2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
select /*+ full(z)*/
  host_id,
  routing_number_id,
  row_number() over(partition by host_id order by routing_number_id) rn,
  row_number() over(partition by routing_number_id order by host_id) rn2
  bulk collect into p_host_id, p_routing_number_id, v_rn, v_rn2
  from
    routing_number_host z
  where 1 = 1
  and p_date between date_from and date_to
  order by host_id, routing_number_id
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    v_rn := util_pkg.filter_val_ct_number_1val(v_rn, util_ri.c_index_one, FALSE);
    ------------------------------
    if util_pkg.get_count_ct_number(v_rn) > 0
    then
      ------------------------------
      util_pkg.Raise_Obj_NotUniq('routing_number_host - host_id');
      ------------------------------
    end if;
    ------------------------------
    v_rn2 := util_pkg.filter_val_ct_number_1val(v_rn2, util_ri.c_index_one, FALSE);
    ------------------------------
    if util_pkg.get_count_ct_number(v_rn2) > 0
    then
      ------------------------------
      util_pkg.Raise_Obj_NotUniq('routing_number_host - routing_number_id');
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_rn_id4no0(p_network_operator_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_network_operator_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_network_operator_id) != v_main_count, 'p_network_operator_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, I_ROUTING_NUMBER_NO_NO_ID)*/
  z.routing_number_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value network_operator_id, rownum rn from table(p_network_operator_id)) q,
    (select column_value q_date, rownum rn from table(p_date)) q2,
    routing_number_no z
  where 1 = 1
  and q2.rn = q.rn
  and z.network_operator_id = q.network_operator_id
  and q2.q_date between z.date_from and z.date_to
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'routing_number_host');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_rn_id4no(p_network_operator_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_network_operator_id), p_date);
  ------------------------------
  return get_rn_id4no0(p_network_operator_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_rn_id4no2(p_network_operator_id number, p_date date) return number
is
  v_network_operator_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_network_operator_id, p_network_operator_id);
  ------------------------------
  return get_rn_id4no(v_network_operator_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_rn_id4no_all(p_date date, p_network_operator_id out ct_number, p_routing_number_id out ct_number, p_xcheck_data boolean := true)
is
  v_rn ct_number;
  v_rn2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
select /*+ full(z)*/
  network_operator_id,
  routing_number_id,
  row_number() over(partition by network_operator_id order by routing_number_id) rn,
  row_number() over(partition by routing_number_id order by network_operator_id) rn2
  bulk collect into p_network_operator_id, p_routing_number_id, v_rn, v_rn2
  from
    routing_number_no z
  where 1 = 1
  and p_date between date_from and date_to
  order by network_operator_id, routing_number_id
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    v_rn := util_pkg.filter_val_ct_number_1val(v_rn, util_ri.c_index_one, FALSE);
    ------------------------------
    if util_pkg.get_count_ct_number(v_rn) > 0
    then
      ------------------------------
      util_pkg.Raise_Obj_NotUniq('routing_number_no - network_operator_id');
      ------------------------------
    end if;
    ------------------------------
    v_rn2 := util_pkg.filter_val_ct_number_1val(v_rn2, util_ri.c_index_one, FALSE);
    ------------------------------
    if util_pkg.get_count_ct_number(v_rn2) > 0
    then
      ------------------------------
      util_pkg.Raise_Obj_NotUniq('routing_number_no - routing_number_id');
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function smart_get_rn_id4host0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_no_id ct_number;
  v_host_rn_id ct_number;
  v_no_rn_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_host_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_host_id) != v_main_count, 'p_host_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_host_rn_id := get_rn_id4host0(p_host_id, p_date, FALSE);
  v_no_id := util_ri.get_host_network_operator0(p_host_id, p_date, FALSE);
  v_no_rn_id := get_rn_id4no0(v_no_id, p_date, FALSE);
  v_res := util_pkg.supplement_ct_number(v_host_rn_id, v_no_rn_id, FALSE, NULL);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function smart_get_rn_id4host(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_host_id), p_date);
  ------------------------------
  return smart_get_rn_id4host0(p_host_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function smart_get_rn_id4host2(p_host_id number, p_date date) return number
is
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  return smart_get_rn_id4host(v_host_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_no_by_rn0(p_rn_id ct_number, p_date ct_date, p_trim_empty boolean, p_rn_id2 out ct_number, p_network_operator_id out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := FALSE)
is
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_rn_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_rn_id) != v_main_count, 'p_rn_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  util_loc_pkg.touch_boolean(p_xcheck_data); --!_! no check
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) full(q) full(q2) use_nl(z1) index_asc(z1 I_ROUTING_NUMBER_NO_RN_ID)*/
  z1.network_operator_id, z1.routing_number_id, q.rn
  bulk collect into p_network_operator_id, p_rn_id2, v_rn
  from
    (select column_value routing_number_id, rownum rn from table(p_rn_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    routing_number_no z1
  where 1 = 1
  and q2.rn = q.rn
  and z1.routing_number_id = q.routing_number_id
  and q2.validity_date between z1.date_from and z1.date_to
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_unique_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'routing_number_no');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    p_network_operator_id := util_pkg.join2pivot_ct_number(p_network_operator_id, v_tmp_rn, v_rn);
    p_rn_id2 := util_pkg.join2pivot_ct_number(p_rn_id2, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_no_by_rn(p_rn_id ct_number, p_date date, p_trim_empty boolean, p_rn_id2 out ct_number, p_network_operator_id out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := FALSE)
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_rn_id), p_date);
  ------------------------------
  get_no_by_rn0(p_rn_id, v_date, p_trim_empty, p_rn_id2, p_network_operator_id, p_xcheck_data, p_xcheck_unique_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_by_rn2(p_rn_id number, p_date date) return ct_number
is
  v_rn_id ct_number;
  v_rn_id2 ct_number;
  v_network_operator_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_rn_id, p_rn_id);
  ------------------------------
  get_no_by_rn(v_rn_id, p_date, FALSE, v_rn_id2, v_network_operator_id);
  ------------------------------
  return v_network_operator_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_host_by_rn0(p_rn_id ct_number, p_date ct_date, p_trim_empty boolean, p_rn_id2 out ct_number, p_host_ids out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := false)
is
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  util_pkg.XCheck_Cond_Missing(p_xcheck_unique_data is null, 'p_xcheck_unique_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_rn_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_rn_id) != v_main_count, 'p_rn_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  util_loc_pkg.touch_boolean(p_xcheck_data); --!_! no check
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q2) full(q) full(q2) use_nl(z1) index_asc(z1 I_ROUTING_NUMBER_ID)*/
  z1.host_id, z1.routing_number_id, q.rn
  bulk collect into p_host_ids, p_rn_id2, v_rn
  from
    (select column_value routing_number_id, rownum rn from table(p_rn_id)) q,
    (select column_value validity_date, rownum rn from table(p_date)) q2,
    routing_number_host z1
  where 1 = 1
  and q2.rn = q.rn
  and z1.routing_number_id = q.routing_number_id
  and q2.validity_date between z1.date_from and z1.date_to
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_unique_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'routing_number_host');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    p_host_ids := util_pkg.join2pivot_ct_number(p_host_ids, v_tmp_rn, v_rn);
    p_rn_id2 := util_pkg.join2pivot_ct_number(p_rn_id2, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_host_by_rn(p_rn_id ct_number, p_date date, p_trim_empty boolean, p_rn_id2 out ct_number, p_host_ids out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := false)
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  util_pkg.XCheck_Cond_Missing(p_xcheck_unique_data is null, 'p_xcheck_unique_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_rn_id), p_date);
  ------------------------------
  get_host_by_rn0(p_rn_id, v_date, p_trim_empty, p_rn_id2, p_host_ids, p_xcheck_data, p_xcheck_unique_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_host_by_rn2(p_rn_id number, p_date date) return ct_number
is
  v_rn_id ct_number;
  v_rn_id2 ct_number;
  v_host_ids ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_rn_id, p_rn_id);
  ------------------------------
  get_host_by_rn(v_rn_id, p_date, FALSE, v_rn_id2, v_host_ids);
  ------------------------------
  return v_host_ids;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_rn_id4ap0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number
is
  v_main_count number;
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ap_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ap_id) != v_main_count, 'p_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  v_host_id := util_ri.get_ap_host_id0(p_ap_id, p_date, FALSE, TRUE);
  ------------------------------
  return smart_get_rn_id4host0(v_host_id, p_date, p_trim_empty, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_rn_id4ap(p_ap_id ct_number, p_date date, p_trim_empty boolean) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_ap_id), p_date);
  ------------------------------
  return get_rn_id4ap0(p_ap_id, v_date, p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_rn_id4ap2(p_ap_id number, p_date date) return number
is
  v_ap_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  return get_rn_id4ap(v_ap_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_rn_code4imsi(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean) return ct_varchar_s
is
  v_main_count number;
  v_date ct_date;
  v_ap_id ct_number;
  v_rn_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_imsi) != v_main_count, 'p_imsi.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  v_date := util_pkg.supplement_ct_date(p_date, util_pkg.make_ct_date(v_main_count, sysdate), FALSE);
  ------------------------------
  v_ap_id := util_ri.get_ap_id03(p_imsi, v_date, FALSE, TRUE);
  ------------------------------
  v_rn_id := get_rn_id4ap0(v_ap_id, v_date, FALSE);
  ------------------------------
  return get_routing_number_code0(v_rn_id, v_date, p_trim_empty, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_rn_code4iccid(p_iccid ct_varchar_s, p_date ct_date, p_trim_empty boolean) return ct_varchar_s
is
  v_main_count number;
  v_date ct_date;
  v_ap_id ct_number;
  v_rn_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_iccid);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_iccid) != v_main_count, 'p_iccid.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  v_date := util_pkg.supplement_ct_date(p_date, util_pkg.make_ct_date(v_main_count, sysdate), FALSE);
  ------------------------------
  v_ap_id := util_ri.get_ap_id0(p_iccid, v_date, FALSE, TRUE);
  ------------------------------
  v_rn_id := get_rn_id4ap0(v_ap_id, v_date, FALSE);
  ------------------------------
  return get_routing_number_code0(v_rn_id, v_date, p_trim_empty, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_rn_code4msisdn(p_msisdn ct_varchar_s, p_date ct_date, p_trim_empty boolean) return ct_varchar_s
is
  v_main_count number;
  v_na_id ct_number;
  v_date ct_date;
  v_ap_id ct_number;
  v_rn_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdn);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdn) != v_main_count, 'p_msisdn.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  v_date := util_pkg.supplement_ct_date(p_date, util_pkg.make_ct_date(v_main_count, sysdate), FALSE);
  ------------------------------
  v_na_id := util_ri.get_na_id0(p_msisdn, v_date, FALSE, TRUE);
  ------------------------------
  v_ap_id := util_ri.get_linked_ap_id0(v_na_id, util_ri.c_NAAP_LINK_TYPE_CODE_ANYDUMMY, v_date, FALSE, TRUE);
  ------------------------------
  v_rn_id := get_rn_id4ap0(v_ap_id, v_date, FALSE);
  ------------------------------
  return get_routing_number_code0(v_rn_id, v_date, p_trim_empty, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_phone_number_with_rn_info
(
  p_nn ct_varchar_s,
  p_date date,
  p_msisdns out ct_varchar_s,
  p_rns out ct_varchar_s,
  p_network_operator_codes out ct_varchar_s,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  lc_first_row constant number := 1;
  lc_distinct_netop_count constant number := 1;
  ------------------------------
  v_main_count number;
  v_host_ids ct_number;
  v_host_network_operator_ids ct_number;
  v_rn_network_operator_ids ct_number;
  v_rn_ids ct_number;
  v_mark ct_number;
  v_mark2 ct_number;
  v_pos ct_number;
  v_rn_ids_host ct_number;
  v_rn_ids_no ct_number;
  v_rn_ids_summary ct_number;
  v_no_ids_summary ct_number;
  v_rn_ids_error ct_number;
  v_network_operator_ids ct_number;
  v_tmp_error_codes ct_number;
  v_tmp_error_messages ct_varchar;
  v_no_count ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_nn, 'p_nn');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_nn);
  ------------------------------
  util_pkg.resize_ct_varchar_s(p_msisdns, v_main_count);
  util_pkg.resize_ct_varchar_s(p_rns, v_main_count);
  util_pkg.resize_ct_varchar_s(p_network_operator_codes, v_main_count);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  parse_network_number
  (
    p_nn => p_nn,
    p_msisdn => p_msisdns,
    p_rn => p_rns
  );
  ------------------------------
  v_mark := util_pkg.mark_val_ct_varchar_s(p_rns, NULL);
  util_ext_ri.setup_error_by_marks(v_mark, util_loc_pkg.c_ora_wrong_network_number_rn, util_loc_pkg.c_msg_wrong_network_number_rn, util_pkg.c_true, p_error_codes, p_error_messages);
  ------------------------------
  v_rn_ids := get_routing_number_id(p_rns, p_date, FALSE);
  ------------------------------
  v_mark := util_pkg.mark_val_ct_number(v_rn_ids, NULL);
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, v_tmp_error_codes, v_tmp_error_messages);
  util_ext_ri.setup_error_by_marks(v_mark, util_loc_pkg.c_ora_routing_number_not_found, util_loc_pkg.c_msg_routing_number_not_found, util_pkg.c_true, v_tmp_error_codes, v_tmp_error_messages);
  p_error_codes := util_pkg.supplement_ct_number(p_error_codes, v_tmp_error_codes, FALSE, util_pkg.c_ora_ok);
  p_error_messages := util_pkg.supplement_ct_varchar(p_error_messages, v_tmp_error_messages, FALSE, util_pkg.c_msg_ok);
  ------------------------------
  get_host_by_rn(v_rn_ids, p_date, FALSE, v_rn_ids_host, v_host_ids);
  v_host_network_operator_ids := util_ri.get_host_network_operator(v_host_ids, p_date, FALSE);
  get_no_by_rn(v_rn_ids, p_date, FALSE, v_rn_ids_no, v_rn_network_operator_ids);
  ------------------------------
  with union_data as
  (
    select /*+ ordered use_hash(rn_ids no_ids) */
      rn_ids.rn_id, no_ids.no_id
    from
      (select column_value rn_id, rownum rn from table(v_rn_ids_host)) rn_ids,
      (select column_value no_id, rownum rn from table(v_host_network_operator_ids)) no_ids
    where rn_ids.rn = no_ids.rn

    UNION -- !_!

    select /*+ ordered use_hash(rn_ids no_ids) */
      rn_ids.rn_id, no_ids.no_id
    from
      (select column_value rn_id, rownum rn from table(v_rn_ids_no)) rn_ids,
      (select column_value no_id, rownum rn from table(v_rn_network_operator_ids)) no_ids
    where rn_ids.rn = no_ids.rn
  )
  select
    t.rn_id,
    t.no_id,
    t.no_count
  bulk collect into v_rn_ids_summary, v_no_ids_summary, v_no_count
  from
  (
    select
      ref.rn_id,
      ref.no_id,
      row_number() over(partition by ref.rn_id order by ref.no_id asc) rn,
      row_number() over(partition by ref.rn_id order by ref.no_id desc) no_count
    from union_data ref
  ) t
  where t.rn = lc_first_row
  ;
  ------------------------------
  v_mark2 := util_pkg.mark_val_ct_number(v_no_count, lc_distinct_netop_count);
  v_rn_ids_error := util_pkg.get_marked_ct_number
  (
    p_vals => v_rn_ids_summary,
    p_marks => v_mark2,
    p_trim_empty => true,
    p_mark_value => util_pkg.c_false
  );
  ------------------------------
  if not install_pkg.nnget_option_bool(c_opt_fetch_first_netop_for_rn, c_def_fetch_first_netop_for_rn)
    and util_pkg.get_count_ct_number(v_rn_ids_error) > 0
  then
    ------------------------------
    v_mark := util_pkg.mark_ct_number(v_rn_ids, v_rn_ids_error);
    util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, v_tmp_error_codes, v_tmp_error_messages);
    util_ext_ri.setup_error_by_marks(v_mark, util_loc_pkg.c_ora_net_op_multiple, util_loc_pkg.c_msg_net_op_multiple, util_pkg.c_true, v_tmp_error_codes, v_tmp_error_messages);
    p_error_codes := util_pkg.supplement_ct_number(p_error_codes, v_tmp_error_codes, FALSE, util_pkg.c_ora_ok);
    p_error_messages := util_pkg.supplement_ct_varchar(p_error_messages, v_tmp_error_messages, FALSE, util_pkg.c_msg_ok);
    ------------------------------
    v_pos := util_pkg.mark2pos
    (
      p_marks => v_mark2,
      p_trim_empty => true,
      p_mark_value => util_pkg.c_false
    );
    ------------------------------
    util_pkg.set_val_by_pos_ct_number
    (
      p_coll => v_no_ids_summary,
      p_val => NULL,  -- !_!
      p_positions => v_pos
    );
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(ref t) */
    t.no_id
  bulk collect into v_network_operator_ids
  from
    (select column_value rn_id, rownum rn from table(v_rn_ids)) ref,
    (
      select /*+ ordered use_hash(rn_ids no_ids) */
        rn_ids.rn_id, no_ids.no_id
      from
        (select column_value rn_id, rownum rn from table(v_rn_ids_summary)) rn_ids,
        (select column_value no_id, rownum rn from table(v_no_ids_summary)) no_ids
      where no_ids.rn = rn_ids.rn
    ) t
  where t.rn_id(+) = ref.rn_id
  order by ref.rn
  ;
  ------------------------------
  p_network_operator_codes := util_ri.get_network_operator_code(v_network_operator_ids, p_date, FALSE);
  ------------------------------
  v_mark := util_pkg.mark_val_ct_varchar_s(p_network_operator_codes, NULL);
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, v_tmp_error_codes, v_tmp_error_messages);
  util_ext_ri.setup_error_by_marks(v_mark, util_loc_pkg.c_ora_net_op_not_found, util_loc_pkg.c_msg_net_op_not_found, util_pkg.c_true, v_tmp_error_codes, v_tmp_error_messages);
  p_error_codes := util_pkg.supplement_ct_number(p_error_codes, v_tmp_error_codes, FALSE, util_pkg.c_ora_ok);
  p_error_messages := util_pkg.supplement_ct_varchar(p_error_messages, v_tmp_error_messages, FALSE, util_pkg.c_msg_ok);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_phone_number_type_by_pa
(
  p_personal_accounts ct_number,
  p_min_date_of_used date,
  p_only_main_msisdn boolean,
  p_out_personal_accounts out ct_number,
  p_out_phone_type out ct_varchar_s
)
is
  v_link_type_code varchar2(50);
  --
  v_date date := sysdate;
  v_pa_id ct_number;
  v_pa_id2 ct_number;
  v_pa_id3 ct_number;
  v_ap_id ct_number;
  v_ap_id2 ct_number;
  v_na_id ct_number;
  v_na_status ct_varchar_s;
  v_phone_type ct_varchar_s;
  v_date_of_status_change ct_date;
  --
  v_pa_id4 ct_number;
  v_phone_type2 ct_varchar_s;
  --
  v_map ct_number;
  v_tmp_map ct_number;
  v_mark ct_number;
  v_mark2 ct_number;
  --
  v_length number;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_personal_accounts);
  --util_pkg.XCheck_Cond_Missing(p_min_date_of_used is null, 'p_min_date_of_used');
  util_pkg.XCheck_Cond_Missing(p_only_main_msisdn is null, 'p_only_main_msisdn');
  ------------------------------
  if p_only_main_msisdn
  then
    v_link_type_code := util_ri.c_NAAP_LINK_TYPE_CODE_MAIN;
  else
    v_link_type_code := NULL;
  end if;
  ------------------------------
  v_pa_id := util_pkg.unique_ct_number(p_personal_accounts, FALSE);
  ------------------------------
  util_ri.get_pa_linked_ap_id(v_pa_id, v_date, FALSE, v_pa_id2, v_ap_id);
  v_map := util_pkg.map_ct_number(v_pa_id2, v_pa_id, FALSE);
  ------------------------------
  util_ri.get_linked_na_id(v_ap_id, v_link_type_code, v_date, FALSE, v_ap_id2, v_na_id);
  v_tmp_map := util_pkg.map_ct_number(v_ap_id2, v_ap_id, FALSE);
  v_map := util_pkg.get_by_pos_ct_number(v_map, v_tmp_map, FALSE);
  ------------------------------
  if p_min_date_of_used is not null
  then
    ------------------------------
    util_ri.get_na_status_current(v_na_id, v_date, FALSE, v_na_status, v_date_of_status_change);
    ------------------------------
    v_length := util_pkg.get_count_ct_date(v_date_of_status_change);
    ------------------------------
    v_mark := util_pkg.mark_val_ct_varchar_s(v_na_status, util_ri.c_NASH_CODE_USED, util_pkg.c_true, util_pkg.c_false);
    ------------------------------
    for v_i in 1..v_length
    loop
      ------------------------------
      if v_mark(v_i) = util_pkg.c_true
       and v_date_of_status_change(v_i) is not null
       and v_date_of_status_change(v_i) < p_min_date_of_used
      then
        ------------------------------
        v_mark(v_i) := util_pkg.c_false;
        ------------------------------
      end if;
      ------------------------------
    end loop;
    ------------------------------
    v_na_id := util_pkg.get_marked_ct_number(v_na_id, v_mark, FALSE, util_pkg.c_true, NULL);
    ------------------------------
  end if;
  ------------------------------
  v_pa_id3 := util_pkg.get_by_pos_ct_number(v_pa_id, v_map, FALSE);
  v_phone_type := util_ri.get_na_type(v_na_id, v_date, FALSE);
  ------------------------------
  v_mark2 := util_pkg.mark_val_ct_varchar_s(v_phone_type, NULL, util_pkg.c_false, util_pkg.c_true);
  ------------------------------
  v_pa_id4 := util_pkg.get_marked_ct_number(v_pa_id3, v_mark2, TRUE, util_pkg.c_true, NULL);
  v_phone_type2 := util_pkg.get_marked_ct_varchar_s(v_phone_type, v_mark2, TRUE, util_pkg.c_true, NULL);
  ------------------------------
  select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
      distinct q1.personal_account, q3.phone_type
    bulk collect into p_out_personal_accounts, p_out_phone_type
    from
      (select column_value personal_account, rownum rn from table(p_personal_accounts)) q1,
      (select column_value personal_account, rownum rn from table(v_pa_id4)) q2,
      (select column_value phone_type, rownum rn from table(v_phone_type2)) q3
    where 1 = 1
    and q2.personal_account(+) = q1.personal_account
    and q3.rn(+) = q2.rn
    --!_!order by q1.rn, q3.phone_type
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure mnp_change_data_ii
(
  p_na_ids ct_number,
  p_no_ids ct_number,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_na_status_target varchar2,
  p_na_stat_target_match_silent boolean,
  p_na_status_current_required varchar2,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_sp_name2 varchar2(30);
  --
  v_main_count number;
  v_pivot ct_number;
  v_marks ct_number;
  v_positions ct_number;
  --
  v_msisdns ct_varchar_s;
  v_na_ids ct_number;
  v_no_ids ct_number;
  v_no_codes ct_varchar_s;
  v_ap_ids ct_number;
  v_na_status ct_varchar_s;
  v_no_types2 ct_varchar_s;
  --
  v_na_no_ids ct_number;
  v_na_no_ids2 ct_number;
  v_na_no_types ct_varchar_s;
  v_na_no_types2 ct_varchar_s;
  --
  v_make_po_own2same boolean;
  v_make_po_other2same boolean;
  --
  v_bool boolean;
  --
  v_error_codes ct_number;
  --
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_na_status_target is null, 'p_na_status_target');
  util_pkg.XCheck_Cond_Missing(p_na_stat_target_match_silent is null, 'p_na_stat_target_match_silent');
  --!_!util_pkg.XCheck_Cond_Missing(p_na_status_current_required is null, 'p_na_status_current_required');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_ids) != v_main_count, 'p_na_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_no_ids) != v_main_count, 'p_no_ids.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_na_ids);
  util_pkg.XCheckP_FS_ct_number(p_no_ids);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  v_error_codes := util_pkg.make_ct_number(v_main_count, util_pkg.c_ora_ok);
  ------------------------------
  ------------------------------
  v_msisdns := util_ri.get_msisdn(p_na_ids, p_date, false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_varchar_s(v_msisdns, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_phone_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_phone_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_no_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_no_ids, v_pivot);
  ------------------------------
  v_no_codes := util_ri.get_network_operator_code(v_no_ids, p_date, false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_varchar_s(v_no_codes, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_net_op_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_net_op_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_na_ids, v_pivot);
  ------------------------------
  v_ap_ids := util_ri.get_linked_ap_id(v_na_ids, util_ri.c_NAAP_LINK_TYPE_CODE_ANYDUMMY, p_date, FALSE);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_ap_ids, null, util_pkg.c_false, util_pkg.c_true); --!_!
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_na_still_linked_to_ap, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_na_still_linked_to_ap, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_na_ids, v_pivot);
  ------------------------------
  if 1 = 0
    or p_na_stat_target_match_silent
    or p_na_status_current_required is not null
  then
    ------------------------------
    v_na_status := util_ri.get_na_status(v_na_ids, p_date, false);
    ------------------------------
  end if;
  ------------------------------
  if p_na_status_current_required is not null
  then
    ------------------------------
    v_marks := util_pkg.mark_val_ct_varchar_s(v_na_status, p_na_status_current_required, util_pkg.c_false, util_pkg.c_true); --!_!
    v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
    ------------------------------
    util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_wrong_na_status, v_positions);
    util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_wrong_na_status, v_positions);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
  elsif p_na_stat_target_match_silent
  then
    ------------------------------
    v_marks := util_pkg.mark_val_ct_varchar_s(v_na_status, p_na_status_target);
    v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
    ------------------------------
    --!_!util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_pkg.c_ora_ok, v_positions);
    --!_!util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_pkg.c_msg_ok, v_positions);
    --!_!util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
    util_pkg.set_val_by_pos2_ct_number(v_error_codes, util_pkg.c_ora_no_action_required, v_positions);
    ------------------------------
  else
    ------------------------------
    v_marks := util_pkg.make_ct_number(util_pkg.get_count_ct_number(v_pivot), util_pkg.c_false);
    ------------------------------
  end if;
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_na_ids, v_pivot);
  ------------------------------
  v_na_no_ids := get_no_own_any(p_na_id => v_na_ids, p_date => p_date, p_trim_empty => false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_na_no_ids, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_net_op_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_net_op_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_na_no_ids := util_coll_pkg.get_unmarked_ol_ct_number(v_na_no_ids, v_marks); --!_!v_na_no_ids.count <= v_main_count
  ------------------------------
  v_na_no_types := util_ri.get_network_operator_type_x(v_na_no_ids, p_date, false);
  ------------------------------
  ------------------------------
  v_na_no_ids2 := util_pkg.make_ct_number(v_main_count, null);
  util_pkg.set_by_pos2_ct_number(v_na_no_ids2, v_na_no_ids, v_pivot);
  ------------------------------
  v_na_no_types2 := util_pkg.make_ct_varchar_s(v_main_count, null);
  util_pkg.set_by_pos2_ct_varchar_s(v_na_no_types2, v_na_no_types, v_pivot);
  ------------------------------
  v_no_types2 := util_ri.get_network_operator_type_x(p_no_ids, p_date, false);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_na_no_ids2) != v_main_count, 'v_na_no_ids2.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_na_no_types2) != v_main_count, 'v_na_no_types2.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_no_types2) != v_main_count, 'v_no_types2.count != v_main_count');
  ------------------------------
  ------------------------------
  v_make_po_own2same := install_pkg.nnget_option_bool(c_opt_mnp_make_po_own2same, c_def_mnp_make_po_own2same);
  v_make_po_other2same := install_pkg.nnget_option_bool(c_opt_mnp_make_po_other2same, c_def_mnp_make_po_other2same);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    begin
      ------------------------------
      v_sp_name2 := util_sys_pkg.make_savepoint;
      ------------------------------
      if 1 = 0
        or util_pkg.is_error(p_error_codes(v_i))
        or v_error_codes(v_i) = util_pkg.c_ora_no_action_required
      then
        ------------------------------
        continue;
        ------------------------------
      end if;
      ------------------------------
      v_bool := util_ext_ri.set_na_status3
      (
        p_na_id => p_na_ids(v_i),
        p_status => p_na_status_target,
        p_date => p_date,
        p_user_id => p_user_id,
        p_lock_pn => TRUE,
        p_error_code => p_error_codes(v_i),
        p_error_message => p_error_messages(v_i)
      );
      ------------------------------
      if not v_bool
      then
        ------------------------------
        util_pkg.raise_exception(p_error_codes(v_i), p_error_messages(v_i));
        ------------------------------
      end if;
      ------------------------------
      change_1phone_operator_i
      (
        p_na_id => p_na_ids(v_i),
        p_date => p_date,
        p_user_id => p_user_id,
        p_no_id_own => v_na_no_ids2(v_i),
        p_no_id_requested => p_no_ids(v_i),
        p_no_type_own => v_na_no_types2(v_i),
        p_no_type_requested => v_no_types2(v_i),
        p_make_po_own2same => v_make_po_own2same,
        p_make_po_other2same => v_make_po_other2same,
        p_check_exist4close => TRUE --!_! may be extended for complex analysis
      );
      ------------------------------
    exception
    when others then
      ------------------------------
      util_sys_pkg.rollback_savepoint(v_sp_name2);
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_error_message4val_num2(p_na_ids(v_i), p_no_ids(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure change_1phone_operator_i
(
  p_na_id number,
  p_date date,
  p_user_id number,
  p_no_id_own number,
  p_no_id_requested number,
  p_no_type_own varchar2,
  p_no_type_requested varchar2,
  p_make_po_own2same boolean,
  p_make_po_other2same boolean,
  p_check_exist4close boolean
)
is
  v_potype number;
  v_rec phone_operator%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_no_id_own is null, 'p_no_id_own');
  util_pkg.XCheck_Cond_Missing(p_no_id_requested is null, 'p_no_id_requested');
  util_pkg.XCheck_Cond_Missing(p_no_type_own is null, 'p_no_type_own');
  util_pkg.XCheck_Cond_Missing(p_no_type_requested is null, 'p_no_type_requested');
  util_pkg.XCheck_Cond_Missing(p_make_po_own2same is null, 'p_make_po_own2same');
  util_pkg.XCheck_Cond_Missing(p_make_po_other2same is null, 'p_make_po_other2same');
  util_pkg.XCheck_Cond_Missing(p_check_exist4close is null, 'p_check_exist4close');
  ------------------------------
  if 1 = 0
    or NOT p_check_exist4close
    or vp_phone_operator.get1(p_na_id, p_date).network_address_id is not null
  then
    ------------------------------
    vp_phone_operator.version_close
    (
      p_id => p_na_id,
      p_user_id => p_user_id,
      p_date_from => p_date
    );
    ------------------------------
  end if;
  ------------------------------
  v_potype := det_phone_operator_type_i
  (
    p_no_id_own => p_no_id_own,
    p_no_id_requested => p_no_id_requested,
    p_no_type_own => p_no_type_own,
    p_no_type_requested => p_no_type_requested,
    p_make_po_own2same => p_make_po_own2same,
    p_make_po_other2same => p_make_po_other2same
  );
  ------------------------------
  if v_potype is NULL
  then
    ------------------------------
    RETURN;
    ------------------------------
  end if;
  ------------------------------
  v_rec := NULL;
  ------------------------------
  v_rec.network_operator_id := p_no_id_requested;
  v_rec.network_address_id := p_na_id;
  v_rec.start_date := p_date;
  v_rec.user_id_of_change := p_user_id;
  v_rec.type := v_potype;
  ------------------------------
  vp_phone_operator.version_open(v_rec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function det_phone_operator_type_i
(
  p_no_id_own number,
  p_no_id_requested number,
  p_no_type_own varchar2,
  p_no_type_requested varchar2,
  p_make_po_own2same boolean,
  p_make_po_other2same boolean
) return number
is
  lc_potype_skip constant number := NULL;
  v_res number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_no_id_own is null, 'p_no_id_own');
  util_pkg.XCheck_Cond_Missing(p_no_id_requested is null, 'p_no_id_requested');
  util_pkg.XCheck_Cond_Missing(p_no_type_own is null, 'p_no_type_own');
  util_pkg.XCheck_Cond_Missing(p_no_type_requested is null, 'p_no_type_requested');
  util_pkg.XCheck_Cond_Missing(p_make_po_own2same is null, 'p_make_po_own2same');
  util_pkg.XCheck_Cond_Missing(p_make_po_other2same is null, 'p_make_po_other2same');
  ------------------------------
  if p_no_type_own = util_ri.c_NOPT_CODE_EXTERNAL --!_!external phone
  then
    ------------------------------
    if p_no_type_requested = util_ri.c_NOPT_CODE_EXTERNAL --!_!to external operator
    then
      ------------------------------
      if 1 = 1
        and p_no_id_own = p_no_id_requested
        and NOT p_make_po_other2same
      then
        ------------------------------
        v_res := lc_potype_skip;
        ------------------------------
      else
        ------------------------------
        v_res := vp_phone_operator.c_potype_other2other;
        ------------------------------
      end if;
      ------------------------------
    else --!_!to own operator
      ------------------------------
      v_res := vp_phone_operator.c_potype_other2own;
      ------------------------------
    end if;
    ------------------------------
  else --!_!own phone
    ------------------------------
    if p_no_type_requested = util_ri.c_NOPT_CODE_EXTERNAL --!_!to external operator
    then
      ------------------------------
      v_res := vp_phone_operator.c_potype_own2other;
      ------------------------------
    else --!_!to own operator
      ------------------------------
      if 1 = 1
        and p_no_id_own = p_no_id_requested
        and NOT p_make_po_own2same
      then
        ------------------------------
        v_res := lc_potype_skip;
        ------------------------------
      else
        ------------------------------
        v_res := vp_phone_operator.c_potype_own2own;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure restore_phones_i
(
  p_na_ids ct_number,
  p_msisdns ct_varchar_s,
  p_phone_status varchar2,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  --
  v_main_count number;
  v_pivot ct_number;
  v_marks ct_number;
  v_positions ct_number;
  --
  v_pns_ids ct_number;
  v_na_ids ct_number;
  --
  v_bool boolean;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_phone_status is null, 'p_phone_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_ids) != v_main_count, 'p_na_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_na_ids);
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  ------------------------------
  v_pns_ids := util_ri.det_pns_id4msisdn(p_msisdns, p_date, false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_pns_ids, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_phone_serie_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_phone_serie_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_na_ids, v_pivot);
  v_pns_ids := util_coll_pkg.get_by_pos_ol_ct_number(v_pns_ids, v_pivot); --!_!v_pns_ids.count = v_main_count
  ------------------------------
  if util_pkg.get_count_ct_number(v_pivot) > 0
  then
    ------------------------------
    v_bool := util_ext_ri.restore_phone2
    (
      p_na_ids => v_na_ids,
      p_pns_ids => v_pns_ids,
      p_status => p_phone_status,
      p_sal_cat => util_ri.c_SC_CODE_NORMAL,
      p_date => p_date,
      p_user_id => p_user_id,
      p_break_on_error => p_break_on_error,
      p_lock_pn => TRUE,
      p_error_code => v_error_codes,
      p_error_message => v_error_messages
    );
    ------------------------------
    util_loc_pkg.touch_boolean(v_bool);
    ------------------------------
    util_pkg.set_by_pos2_ct_number(p_error_codes, v_error_codes, v_pivot);
    util_pkg.set_by_pos2_ct_varchar(p_error_messages, v_error_messages, v_pivot);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_phones_i
(
  p_msisdns ct_varchar_s,
  p_phone_status varchar2,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_out_na_ids out ct_number,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  --
  v_main_count number;
  v_pivot ct_number;
  v_marks ct_number;
  v_positions ct_number;
  --
  v_pns_ids ct_number;
  v_msisdns ct_varchar_s;
  v_na_ids ct_number;
  --
  v_bool boolean;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_phone_status is null, 'p_phone_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  ------------------------------
  v_pns_ids := util_ri.det_pns_id4msisdn(p_msisdns, p_date, false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_pns_ids, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_phone_serie_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_phone_serie_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_msisdns := util_coll_pkg.get_by_pos_ol_ct_varchar_s(p_msisdns, v_pivot);
  v_pns_ids := util_coll_pkg.get_by_pos_ol_ct_number(v_pns_ids, v_pivot); --!_!v_pns_ids.count = v_main_count
  ------------------------------
  if util_pkg.get_count_ct_number(v_pivot) > 0
  then
    ------------------------------
    v_bool := util_ext_ri.ins_phone2
    (
      p_msisdns => v_msisdns,
      p_pns_ids => v_pns_ids,
      p_status => p_phone_status,
      p_sal_cat => util_ri.c_SC_CODE_NORMAL,
      p_date => p_date,
      p_user_id => p_user_id,
      p_break_on_error => p_break_on_error,
      p_na_ids => v_na_ids,
      p_error_code => v_error_codes,
      p_error_message => v_error_messages
    );
    ------------------------------
    util_loc_pkg.touch_boolean(v_bool);
    ------------------------------
    util_pkg.set_by_pos2_ct_number(p_error_codes, v_error_codes, v_pivot);
    util_pkg.set_by_pos2_ct_varchar(p_error_messages, v_error_messages, v_pivot);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  p_out_na_ids := util_pkg.make_ct_number(v_main_count, null);
  util_pkg.set_by_pos2_ct_number(p_out_na_ids, v_na_ids, v_pivot);
  ------------------------------
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_phones2port_in_i
(
  p_msisdns ct_varchar_s,
  p_phone_status varchar2,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_out_na_ids out ct_number,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  --
  v_main_count number;
  v_pivot ct_number;
  v_pivot2 ct_number;
  v_marks ct_number;
  v_positions ct_number;
  --
  v_msisdns ct_varchar_s;
  v_na_ids ct_number;
  v_na_stats ct_varchar_s;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_phone_status is null, 'p_phone_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  ------------------------------
  p_out_na_ids := util_ri.get_na_id(p_msisdns, p_date, false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_out_na_ids, null);
  v_pivot2 := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  if util_pkg.get_count_ct_number(v_pivot2) > 0 --!_!msisdn has no na_id
  then
    ------------------------------
    v_msisdns := util_coll_pkg.get_by_pos_ol_ct_varchar_s(p_msisdns, v_pivot2);
    ------------------------------
    v_na_ids := util_ri.qwerty_get_na_id_last(p_msisdn => v_msisdns, p_view_date => p_date, p_trim_empty => false);
    ------------------------------
    v_marks := util_pkg.mark_val_ct_number(v_na_ids, null, util_pkg.c_false, util_pkg.c_true); --!_!
    v_pivot2 := util_coll_pkg.get_marked_ol_ct_number(v_pivot2, v_marks);
    ------------------------------
    if util_pkg.get_count_ct_number(v_pivot2) > 0 --!_!but msisdn had na_id previously
    then
      ------------------------------
      v_na_ids := util_coll_pkg.get_marked_ol_ct_number(v_na_ids, v_marks);
      v_msisdns := util_coll_pkg.get_marked_ol_ct_varchar_s(v_msisdns, v_marks);
      ------------------------------
      restore_phones_i
      (
        p_na_ids => v_na_ids,
        p_msisdns => v_msisdns,
        p_phone_status => p_phone_status,
        p_date => util_pkg.date_from2date_to_prev(p_date),
        p_user_id => p_user_id,
        p_break_on_error => p_break_on_error,
        p_error_codes => v_error_codes,
        p_error_messages => v_error_messages
      );
      ------------------------------
      util_pkg.set_by_pos2_ct_number(p_error_codes, v_error_codes, v_pivot2);
      util_pkg.set_by_pos2_ct_varchar(p_error_messages, v_error_messages, v_pivot2);
      util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
      ------------------------------
      util_pkg.set_by_pos2_ct_number(p_out_na_ids, v_na_ids, v_pivot2); --!_!setup previous na_ids
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_out_na_ids, null);
  v_pivot2 := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  if util_pkg.get_count_ct_number(v_pivot2) > 0 --!_!msisdn has no na_id as before (again)
  then
    ------------------------------
    v_msisdns := util_coll_pkg.get_by_pos_ol_ct_varchar_s(p_msisdns, v_pivot2);
    ------------------------------
    add_phones_i
    (
      p_msisdns => v_msisdns,
      p_phone_status => p_phone_status,
      p_date => util_pkg.date_from2date_to_prev(p_date),
      p_user_id => p_user_id,
      p_break_on_error => p_break_on_error,
      p_out_na_ids => v_na_ids, --!_!
      p_error_codes => v_error_codes,
      p_error_messages => v_error_messages
    );
    ------------------------------
    util_pkg.set_by_pos2_ct_number(p_error_codes, v_error_codes, v_pivot2);
    util_pkg.set_by_pos2_ct_varchar(p_error_messages, v_error_messages, v_pivot2);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
    util_pkg.set_by_pos2_ct_number(p_out_na_ids, v_na_ids, v_pivot2); --!_!setup new na_ids
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_out_na_ids, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  v_error_codes := util_coll_pkg.get_by_pos_ol_ct_number(p_error_codes, v_positions);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_error_codes, util_pkg.c_ora_ok);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_positions, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_pkg.c_ora_object_wrong, v_positions); --!_!change c_ora_ok to c_msg_object_wrong
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_pkg.c_msg_object_wrong, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_error_codes, util_pkg.c_ora_ok);
  ------------------------------
  v_pivot := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks); --!_!
  ------------------------------
  ------------------------------
  v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_out_na_ids, v_pivot);
  ------------------------------
  v_na_stats := util_ri.get_na_status(v_na_ids, p_date, false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_varchar_s(v_na_stats, p_phone_status);
  v_positions := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_wrong_na_status, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_wrong_na_status, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_out_na_ids, NULL, v_positions); --!_!clear problem na_ids
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure mnp_port_in_ii
(
  p_na_ids ct_number,
  p_no_ids ct_number,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
begin
  ------------------------------
  mnp_change_data_ii
  (
    p_na_ids => p_na_ids,
    p_no_ids => p_no_ids,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_na_status_target => util_ri.c_NASH_CODE_RESERVE,
    p_na_stat_target_match_silent => FALSE,
    p_na_status_current_required => util_ri.c_NASH_CODE_EXTERNAL,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure mnp_port_in_i
(
  p_msisdns ct_varchar_s,
  p_ap_ids ct_number,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  --
  v_main_count number;
  v_pivot ct_number;
  v_marks ct_number;
  v_positions ct_number;
  --
  v_na_ids ct_number;
  v_no_ids ct_number;
  v_msisdns ct_varchar_s;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ap_ids) != v_main_count, 'p_ap_ids.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns);
  util_pkg.XCheckP_FS_ct_number(p_ap_ids);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  ------------------------------
  v_no_ids := util_ri.get_no_by_ap(p_ap_ids, p_date, false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_no_ids, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_net_op_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_net_op_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_msisdns := util_coll_pkg.get_by_pos_ol_ct_varchar_s(p_msisdns, v_pivot);
  ------------------------------
  prepare_phones2port_in_i
  (
    p_msisdns => v_msisdns,
    p_phone_status => util_ri.c_NASH_CODE_EXTERNAL,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_out_na_ids => v_na_ids,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_by_pos2_ct_number(p_error_codes, v_error_codes, v_pivot);
  util_pkg.set_by_pos2_ct_varchar(p_error_messages, v_error_messages, v_pivot);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_error_codes, util_pkg.c_ora_ok);
  v_pivot := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_na_ids := util_coll_pkg.get_marked_ol_ct_number(v_na_ids, v_marks);
  v_no_ids := util_coll_pkg.get_by_pos_ol_ct_number(v_no_ids, v_pivot); --!_!v_no_ids.count = v_main_count
  ------------------------------
  mnp_port_in_ii
  (
    p_na_ids => v_na_ids,
    p_no_ids => v_no_ids,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_by_pos2_ct_number(p_error_codes, v_error_codes, v_pivot);
  util_pkg.set_by_pos2_ct_varchar(p_error_messages, v_error_messages, v_pivot);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure mnp_port_in2_i
(
  p_msisdn varchar2,
  p_ap_id number,
  p_date date,
  p_user_id number
)
is
  v_msisdns ct_varchar_s;
  v_ap_ids ct_number;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn is null, 'p_msisdn');
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_msisdns, p_msisdn);
  util_pkg.add_ct_number_val(v_ap_ids, p_ap_id);
  ------------------------------
  mnp_port_in_i
  (
    p_msisdns => v_msisdns,
    p_ap_ids => v_ap_ids,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => TRUE,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure mnp_port_in
(
  p_msisdns ct_varchar_s,
  p_iccids ct_varchar_s,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_main_count number;
  v_pivot ct_number;
  v_marks ct_number;
  v_positions ct_number;
  --
  v_ap_ids ct_number;
  v_msisdns ct_varchar_s;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns);
  util_pkg.XCheckP_FS_ct_varchar_s(p_iccids);
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_iccids) != v_main_count, 'p_iccids.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  ------------------------------
  v_ap_ids := util_ri.get_ap_id(p_iccids, p_date, false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_ap_ids, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_sim_card_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_sim_card_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_msisdns := util_coll_pkg.get_by_pos_ol_ct_varchar_s(p_msisdns, v_pivot);
  v_ap_ids := util_coll_pkg.get_by_pos_ol_ct_number(v_ap_ids, v_pivot); --!_!v_ap_ids.count = v_main_count
  ------------------------------
  mnp_port_in_i
  (
    p_msisdns => v_msisdns,
    p_ap_ids => v_ap_ids,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_by_pos2_ct_number(p_error_codes, v_error_codes, v_pivot);
  util_pkg.set_by_pos2_ct_varchar(p_error_messages, v_error_messages, v_pivot);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure mnp_port_in2
(
  p_msisdn varchar2,
  p_iccid varchar2,
  p_date date,
  p_user_id number
)
is
  v_msisdns ct_varchar_s;
  v_iccids ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_msisdns, p_msisdn);
  util_pkg.add_ct_varchar_s_val(v_iccids, p_iccid);
  ------------------------------
  mnp_port_in
  (
    p_msisdns => v_msisdns,
    p_iccids => v_iccids,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => TRUE,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure mnp_port_out_ii
(
  p_na_ids ct_number,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_main_count number;
  v_no_ids ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_ids);
  ------------------------------
  if v_main_count > 0
  then
    ------------------------------
    v_no_ids := util_pkg.make_ct_number(v_main_count, c_mnp_dummy_net_op);
    ------------------------------
  end if;
  ------------------------------
  mnp_change_data_ii
  (
    p_na_ids => p_na_ids,
    p_no_ids => v_no_ids,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_na_status_target => util_ri.c_NASH_CODE_EXTERNAL,
    p_na_stat_target_match_silent => TRUE, --!_!already E - it's ok, then make only phone_operator's action
    p_na_status_current_required => NULL,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure mnp_port_out_i
(
  p_na_ids ct_number,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_na_ids);
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  mnp_port_out_ii
  (
    p_na_ids => p_na_ids,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure mnp_port_out2_i
(
  p_na_id number,
  p_date date,
  p_user_id number
)
is
  v_na_ids ct_number;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_na_ids, p_na_id);
  ------------------------------
  mnp_port_out_i
  (
    p_na_ids => v_na_ids,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => TRUE,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure mnp_port_out
(
  p_msisdns ct_varchar_s,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_main_count number;
  v_pivot ct_number;
  v_marks ct_number;
  v_positions ct_number;
  --
  v_na_ids ct_number;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  ------------------------------
  v_na_ids := util_ri.get_na_id(p_msisdns, p_date, false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_na_ids, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_phone_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_phone_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(v_na_ids, v_pivot); --!_!v_na_ids.count = v_main_count
  ------------------------------
  mnp_port_out_i
  (
    p_na_ids => v_na_ids,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_by_pos2_ct_number(p_error_codes, v_error_codes, v_pivot);
  util_pkg.set_by_pos2_ct_varchar(p_error_messages, v_error_messages, v_pivot);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure mnp_port_out2
(
  p_msisdn varchar2,
  p_date date,
  p_user_id number
)
is
  v_msisdns ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_msisdns, p_msisdn);
  ------------------------------
  mnp_port_out
  (
    p_msisdns => v_msisdns,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => TRUE,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure mnp_port_in_back_ii
(
  p_na_ids ct_number,
  p_no_ids ct_number,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
begin
  ------------------------------
  mnp_change_data_ii
  (
    p_na_ids => p_na_ids,
    p_no_ids => p_no_ids,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_na_status_target => util_ri.c_NASH_CODE_NOT_USED,
    p_na_stat_target_match_silent => FALSE,
    p_na_status_current_required => util_ri.c_NASH_CODE_EXTERNAL,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure mnp_port_in_back_i
(
  p_na_ids ct_number,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  --
  v_main_count number;
  v_pivot ct_number;
  v_marks ct_number;
  v_positions ct_number;
  --
  v_na_ids ct_number;
  v_no_ids ct_number;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_ids) != v_main_count, 'p_na_ids.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_na_ids);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  ------------------------------
  v_no_ids := get_no_own_internal(p_na_id => p_na_ids, p_date => p_date, p_trim_empty => false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_no_ids, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_net_op_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_net_op_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_na_ids, v_pivot);
  v_no_ids := util_coll_pkg.get_by_pos_ol_ct_number(v_no_ids, v_pivot);
  ------------------------------
  mnp_port_in_back_ii
  (
    p_na_ids => v_na_ids,
    p_no_ids => v_no_ids,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_by_pos2_ct_number(p_error_codes, v_error_codes, v_pivot);
  util_pkg.set_by_pos2_ct_varchar(p_error_messages, v_error_messages, v_pivot);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure mnp_port_in_back
(
  p_msisdns ct_varchar_s,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_main_count number;
  v_pivot ct_number;
  v_marks ct_number;
  v_positions ct_number;
  --
  v_na_ids ct_number;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  ------------------------------
  --!_!if v_main_count = 0
  --!_!then
  --!_!  ------------------------------
  --!_!  return;
  --!_!  ------------------------------
  --!_!end if;
  --!_!------------------------------
  --!_!util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  ------------------------------
  v_na_ids := util_ri.get_na_id(p_msisdns, p_date, false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_na_ids, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_phone_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_phone_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(v_na_ids, v_pivot); --!_!v_na_ids.count = v_main_count
  ------------------------------
  mnp_port_in_back_i
  (
    p_na_ids => v_na_ids,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_by_pos2_ct_number(p_error_codes, v_error_codes, v_pivot);
  util_pkg.set_by_pos2_ct_varchar(p_error_messages, v_error_messages, v_pivot);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure mnp_port_in_back2
(
  p_msisdn varchar2,
  p_date date,
  p_user_id number
)
is
  v_msisdns ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn is null, 'p_msisdn');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_msisdns, p_msisdn);
  ------------------------------
  mnp_port_in_back
  (
    p_msisdns => v_msisdns,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => TRUE,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_next_ready2return_phones
(
  p_user_id number,
  p_batch_id out number,
  p_msisdns out ct_varchar_s,
  p_date_froms out ct_date
)
is
  v_sp_name varchar2(30);
  v_date date := sysdate;
  v_na_ids ct_number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  p_batch_id := null;
  p_msisdns := null;
  p_date_froms := null;
  ------------------------------
  p_batch_id := batch_pkg.get_first_batch_by_status
  (
    p_status => batch_pkg.c_bs_new,
    p_type => batch_pkg.c_BATCH_TYPE_NA_MNP_RETURN,
    p_date => v_date
  );
  ------------------------------
  if p_batch_id is not null
  then
    ------------------------------
    batch_pkg.na_mnp_batch_to_next_status(p_batch_id => p_batch_id, p_user_id => p_user_id);
    ------------------------------
    v_na_ids := batch_pkg.get_mnp_batch_nas(p_batch_id => p_batch_id, p_date => v_date, p_xlock_batch => FALSE);
    ------------------------------
    p_msisdns := util_ri.get_msisdn(p_na_id => v_na_ids, p_date => v_date, p_trim_empty => false);
    ------------------------------
    p_date_froms := util_ri.get_na_status_max_date_from(p_na_id => v_na_ids, p_status => util_ri.c_NASH_CODE_CLOSE, p_trim_empty => false);
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure confirm_return_phone_batch
(
  p_batch_id number,
  p_user_id number
)
is
  v_sp_name varchar2(30);
  v_rec batch%rowtype;
  v_date date := sysdate;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rec := vp_batch.xlock_get1(p_batch_id);
  ------------------------------
  if v_rec.batch_status <> batch_pkg.c_bs_process
  or v_rec.batch_type <> batch_pkg.c_BATCH_TYPE_NA_MNP_RETURN
  then
    ------------------------------
    util_pkg.Raise_Invalid_Param('p_batch_id');
    ------------------------------
  end if;
  ------------------------------
  batch_pkg.na_mnp_batch_to_next_status(p_batch_id, p_user_id);
  batch_pkg.na_mnp_batch_upd_date_to(p_batch_id, v_date, p_user_id);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_goers_belarus_all
(
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into v_res
    from
    (
    select
        network_address_id interval_id,
        min(date_from) date_from,
        max(date_to) date_to,
        msisdn str1,
        null num1
      from
      (
      select
          --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
          sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
          q2.*
        from
        (
        select
            --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
            decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
            q.*
          from
          (
          select /*+ ordered use_nl(nash pn pns)
            index(nash I_NETADSTAHI_NT_ADDR_STAT_CODE)
            index(pn I_PHONENUM_NA_MSISDN)
            index(pns I_PHONUMSE_PNSID_EXT)
            */
              nash.network_address_id,
              nash.start_date date_from,
              nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')) date_to,
              pn.international_format msisdn
            from
              network_address_status_history nash,
              phone_number pn,
              phone_number_series pns
            where 1 = 1
              and nash.net_address_status_code = util_ri.c_NASHZ_CODE_EXTERNAL
              and nash.start_date <= p_range_date_to
              and nvl(nash.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and pn.network_address_id = nash.network_address_id
              --!_!and nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > nvl(nash.end_date, SYSDATE)
              and pns.phone_number_series_id = pn.phone_number_series_id
              and pns.phone_number_type_code != util_ri.c_PNT_CODE_EXTERNAL
              order by nash.network_address_id, date_from
          ) q
        ) q2
      ) q3
      group by
        network_address_id,
        msisdn,
        range_number
    )
    order by
      interval_id,
      date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_goers_belarus4na_id
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  util_pkg.XCheck_Cond_Missing(p_na_ids is null, 'p_na_ids');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into v_res
    from
    (
    select
        network_address_id interval_id,
        min(date_from) date_from,
        max(date_to) date_to,
        msisdn str1,
        null num1
      from
      (
      select
          --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
          sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
          q2.*
        from
        (
        select
            --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
            decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
            q.*
          from
          (
          select /*+ ordered use_nl(nash pn pns)
            full(z)
            index(nash I_NETADSTAHI_NETWORK_ADDRES_I2)
            index(pn I_PHONENUM_NA_MSISDN)
            index(pns I_PHONUMSE_PNSID_EXT)
            */
              nash.network_address_id,
              nash.start_date date_from,
              nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')) date_to,
              pn.international_format msisdn
            from
              (select column_value network_address_id from table(p_na_ids)) z,
              network_address_status_history nash,
              phone_number pn,
              phone_number_series pns
            where 1 = 1
              and nash.network_address_id = z.network_address_id
              and nash.net_address_status_code = util_ri.c_NASHZ_CODE_EXTERNAL
              and nash.start_date <= p_range_date_to
              and nvl(nash.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and pn.network_address_id = nash.network_address_id
              --!_!and nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > nvl(nash.end_date, SYSDATE)
              and pns.phone_number_series_id = pn.phone_number_series_id
              and pns.phone_number_type_code != util_ri.c_PNT_CODE_EXTERNAL
              order by nash.network_address_id, date_from
          ) q
        ) q2
      ) q3
      group by
        network_address_id,
        msisdn,
        range_number
    )
    order by
      interval_id,
      date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_goers_belarus
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  if p_na_ids is null
  then
    ------------------------------
    v_res := get_goers_belarus_all
    (
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  else
    ------------------------------
    v_res := get_goers_belarus4na_id
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_goers_belarus_all2
(
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into v_res
    from
    (
    select
        network_address_id interval_id,
        min(date_from) date_from,
        max(date_to) date_to,
        msisdn str1,
        null num1
      from
      (
      select
          --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
          sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
          q2.*
        from
        (
        select
            --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
            decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
            q.*
          from
          (
          select /*+ ordered use_hash(nash pn pns)
            full(nash)
            full(pn)
            full(pns)
            */
              nash.network_address_id,
              nash.start_date date_from,
              nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')) date_to,
              pn.international_format msisdn
            from
              network_address_status_history nash,
              phone_number pn,
              phone_number_series pns
            where 1 = 1
              and nash.net_address_status_code = util_ri.c_NASHZ_CODE_EXTERNAL
              and nash.start_date <= p_range_date_to
              and nvl(nash.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and pn.network_address_id = nash.network_address_id
              --!_!and nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > nvl(nash.end_date, SYSDATE)
              and pns.phone_number_series_id = pn.phone_number_series_id
              and pns.phone_number_type_code != util_ri.c_PNT_CODE_EXTERNAL
              order by nash.network_address_id, date_from
          ) q
        ) q2
      ) q3
      group by
        network_address_id,
        msisdn,
        range_number
    )
    order by
      interval_id,
      date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_goers_belarus4na_id2
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  util_pkg.XCheck_Cond_Missing(p_na_ids is null, 'p_na_ids');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into v_res
    from
    (
    select
        network_address_id interval_id,
        min(date_from) date_from,
        max(date_to) date_to,
        msisdn str1,
        null num1
      from
      (
      select
          --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
          sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
          q2.*
        from
        (
        select
            --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
            decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
            q.*
          from
          (
          select /*+ ordered use_hash(z nash pn pns)
            full(z)
            full(nash)
            full(pn)
            full(pns)
            */
              nash.network_address_id,
              nash.start_date date_from,
              nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')) date_to,
              pn.international_format msisdn
            from
              (select column_value network_address_id from table(p_na_ids)) z,
              network_address_status_history nash,
              phone_number pn,
              phone_number_series pns
            where 1 = 1
              and nash.network_address_id = z.network_address_id
              and nash.net_address_status_code = util_ri.c_NASHZ_CODE_EXTERNAL
              and nash.start_date <= p_range_date_to
              and nvl(nash.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and pn.network_address_id = nash.network_address_id
              --!_!and nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > nvl(nash.end_date, SYSDATE)
              and pns.phone_number_series_id = pn.phone_number_series_id
              and pns.phone_number_type_code != util_ri.c_PNT_CODE_EXTERNAL
              order by nash.network_address_id, date_from
          ) q
        ) q2
      ) q3
      group by
        network_address_id,
        msisdn,
        range_number
    )
    order by
      interval_id,
      date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_goers_belarus2
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  if p_na_ids is null
  then
    ------------------------------
    v_res := get_goers_belarus_all2
    (
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  else
    ------------------------------
    v_res := get_goers_belarus4na_id2
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_goers_belarus_all3
(
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into v_res
    from
    (
    select
        network_address_id interval_id,
        min(date_from) date_from,
        max(date_to) date_to,
        msisdn str1,
        null num1
      from
      (
      select
          --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
          sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
          q2.*
        from
        (
        select
            --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
            decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
            q.*
          from
          (
          select /*+ ordered use_hash(nash pn pns)
            full(nash)
            full(pn)
            full(pns)
            parallel(nash 4)
            parallel(pn 4)
            parallel(pns 4)
            */
              nash.network_address_id,
              nash.start_date date_from,
              nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')) date_to,
              pn.international_format msisdn
            from
              network_address_status_history nash,
              phone_number pn,
              phone_number_series pns
            where 1 = 1
              and nash.net_address_status_code = util_ri.c_NASHZ_CODE_EXTERNAL
              and nash.start_date <= p_range_date_to
              and nvl(nash.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and pn.network_address_id = nash.network_address_id
              --!_!and nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > nvl(nash.end_date, SYSDATE)
              and pns.phone_number_series_id = pn.phone_number_series_id
              and pns.phone_number_type_code != util_ri.c_PNT_CODE_EXTERNAL
              order by nash.network_address_id, date_from
          ) q
        ) q2
      ) q3
      group by
        network_address_id,
        msisdn,
        range_number
    )
    order by
      interval_id,
      date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_goers_belarus4na_id3
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  util_pkg.XCheck_Cond_Missing(p_na_ids is null, 'p_na_ids');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into v_res
    from
    (
    select
        network_address_id interval_id,
        min(date_from) date_from,
        max(date_to) date_to,
        msisdn str1,
        null num1
      from
      (
      select
          --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
          sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
          q2.*
        from
        (
        select
            --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
            decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
            q.*
          from
          (
          select /*+ ordered use_hash(z nash pn pns)
            full(z)
            full(nash)
            full(pn)
            full(pns)
            parallel(z 4)
            parallel(nash 4)
            parallel(pn 4)
            parallel(pns 4)
            */
              nash.network_address_id,
              nash.start_date date_from,
              nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')) date_to,
              pn.international_format msisdn
            from
              (select column_value network_address_id from table(p_na_ids)) z,
              network_address_status_history nash,
              phone_number pn,
              phone_number_series pns
            where 1 = 1
              and nash.network_address_id = z.network_address_id
              and nash.net_address_status_code = util_ri.c_NASHZ_CODE_EXTERNAL
              and nash.start_date <= p_range_date_to
              and nvl(nash.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and pn.network_address_id = nash.network_address_id
              --!_!and nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > nvl(nash.end_date, SYSDATE)
              and pns.phone_number_series_id = pn.phone_number_series_id
              and pns.phone_number_type_code != util_ri.c_PNT_CODE_EXTERNAL
              order by nash.network_address_id, date_from
          ) q
        ) q2
      ) q3
      group by
        network_address_id,
        msisdn,
        range_number
    )
    order by
      interval_id,
      date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_goers_belarus3
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  if p_na_ids is null
  then
    ------------------------------
    v_res := get_goers_belarus_all3
    (
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  else
    ------------------------------
    v_res := get_goers_belarus4na_id3
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_comers_belarus_all
(
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into v_res
    from
    (
    select
        network_address_id interval_id,
        min(date_from) date_from,
        max(date_to) date_to,
        msisdn str1,
        network_operator_id num1
      from
      (
      select
          --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
          sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
          q2.*
        from
        (
        select
            --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
            decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
            q.*
          from
          (
          select /*+ ordered use_nl(pns pn nash naap sc ss)
            index(pns I_PHONUMSE_PHONE_NUM_TYPE_CODE)
            index(pn I_PHONENUM_PNS_ID_EXT)
            index(nash I_NETADSTAHI_NETWORK_ADDRES_I2)
            index(naap I_NETADDRACCPO_NET_ADDRESS_ID2)
            index(sc I_SIMCARD_AP_EXT)
            index(ss I_SIMSERIES_SSID_EXT)
            */
              pn.network_address_id,
              greatest(nash.start_date, naap.from_date) date_from,
              least(nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')), nvl(naap.to_date, to_date('01.01.4000','dd.mm.yyyy'))) date_to,
              pn.international_format msisdn,
              ss.network_operator_id
            from
              phone_number_series pns,
              phone_number pn,
              network_address_status_history nash,
              network_address_access_point naap,
              sim_card sc,
              sim_series ss
            where 1 = 1
              and pns.phone_number_type_code = util_ri.c_PNT_CODE_EXTERNAL
              and pn.phone_number_series_id = pns.phone_number_series_id
              and nash.network_address_id = pn.network_address_id
              and nash.start_date <= p_range_date_to
              and nvl(nash.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and nash.net_address_status_code != util_ri.c_NASHZ_CODE_EXTERNAL --!_! nash char(2)
              and naap.network_address_id = pn.network_address_id
              and greatest(nash.start_date, naap.from_date) <= least(nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')), nvl(naap.to_date, to_date('01.01.4000','dd.mm.yyyy')))
              and naap.from_date <= p_range_date_to
              and nvl(naap.to_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and sc.access_point_id = naap.access_point_id
              and ss.sim_series_id = sc.sim_series_id
              order by pn.network_address_id, date_from
          ) q
        ) q2
      ) q3
      group by
        network_address_id,
        msisdn,
        range_number,
        network_operator_id
    )
    order by
      interval_id,
      date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_comers_belarus4na_id
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  util_pkg.XCheck_Cond_Missing(p_na_ids is null, 'p_na_ids');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into v_res
    from
    (
    select
        network_address_id interval_id,
        min(date_from) date_from,
        max(date_to) date_to,
        msisdn str1,
        network_operator_id num1
      from
      (
      select
          --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
          sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
          q2.*
        from
        (
        select
            --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
            decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
            q.*
          from
          (
          select /*+ ordered use_nl(pn pns nash naap sc ss)
            full(z)
            index(pn I_PHONENUM_NA_MSISDN)
            index(pns I_PHONUMSE_PHONE_NUM_TYPE_CODE)
            index(nash I_NETADSTAHI_NETWORK_ADDRES_I2)
            index(naap I_NETADDRACCPO_NET_ADDRESS_ID2)
            index(sc I_SIMCARD_AP_EXT)
            index(ss I_SIMSERIES_SSID_EXT)
            */
              pn.network_address_id,
              greatest(nash.start_date, naap.from_date) date_from,
              least(nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')), nvl(naap.to_date, to_date('01.01.4000','dd.mm.yyyy'))) date_to,
              pn.international_format msisdn,
              ss.network_operator_id
            from
              (select column_value network_address_id from table(p_na_ids)) z,
              phone_number pn,
              phone_number_series pns,
              network_address_status_history nash,
              network_address_access_point naap,
              sim_card sc,
              sim_series ss
            where 1 = 1
              and pn.network_address_id = z.network_address_id
              and pns.phone_number_series_id = pn.phone_number_series_id
              and pns.phone_number_type_code = util_ri.c_PNT_CODE_EXTERNAL
              and nash.network_address_id = pn.network_address_id
              and nash.start_date <= p_range_date_to
              and nvl(nash.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and nash.net_address_status_code != util_ri.c_NASHZ_CODE_EXTERNAL --!_! nash char(2)
              and naap.network_address_id = pn.network_address_id
              and greatest(nash.start_date, naap.from_date) <= least(nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')), nvl(naap.to_date, to_date('01.01.4000','dd.mm.yyyy')))
              and naap.from_date <= p_range_date_to
              and nvl(naap.to_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and sc.access_point_id = naap.access_point_id
              and ss.sim_series_id = sc.sim_series_id
              order by pn.network_address_id, date_from
          ) q
        ) q2
      ) q3
      group by
        network_address_id,
        msisdn,
        range_number,
        network_operator_id
    )
    order by
      interval_id,
      date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_comers_belarus
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  if p_na_ids is null
  then
    ------------------------------
    v_res := get_comers_belarus_all
    (
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  else
    ------------------------------
    v_res := get_comers_belarus4na_id
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_comers_belarus_all2
(
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into v_res
    from
    (
    select
        network_address_id interval_id,
        min(date_from) date_from,
        max(date_to) date_to,
        msisdn str1,
        network_operator_id num1
      from
      (
      select
          --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
          sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
          q2.*
        from
        (
        select
            --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
            decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
            q.*
          from
          (
          select /*+ ordered use_hash(pns pn nash naap sc ss)
            full(pns)
            full(pn)
            full(nash)
            full(naap)
            full(sc)
            full(ss)
            */
              pn.network_address_id,
              greatest(nash.start_date, naap.from_date) date_from,
              least(nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')), nvl(naap.to_date, to_date('01.01.4000','dd.mm.yyyy'))) date_to,
              pn.international_format msisdn,
              ss.network_operator_id
            from
              phone_number_series pns,
              phone_number pn,
              network_address_status_history nash,
              network_address_access_point naap,
              sim_card sc,
              sim_series ss
            where 1 = 1
              and pns.phone_number_type_code = util_ri.c_PNT_CODE_EXTERNAL
              and pn.phone_number_series_id = pns.phone_number_series_id
              and nash.network_address_id = pn.network_address_id
              and nash.start_date <= p_range_date_to
              and nvl(nash.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and nash.net_address_status_code != util_ri.c_NASHZ_CODE_EXTERNAL --!_! nash char(2)
              and naap.network_address_id = pn.network_address_id
              and greatest(nash.start_date, naap.from_date) <= least(nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')), nvl(naap.to_date, to_date('01.01.4000','dd.mm.yyyy')))
              and naap.from_date <= p_range_date_to
              and nvl(naap.to_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and sc.access_point_id = naap.access_point_id
              and ss.sim_series_id = sc.sim_series_id
              order by pn.network_address_id, date_from
          ) q
        ) q2
      ) q3
      group by
        network_address_id,
        msisdn,
        range_number,
        network_operator_id
    )
    order by
      interval_id,
      date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_comers_belarus4na_id2
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  util_pkg.XCheck_Cond_Missing(p_na_ids is null, 'p_na_ids');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into v_res
    from
    (
    select
        network_address_id interval_id,
        min(date_from) date_from,
        max(date_to) date_to,
        msisdn str1,
        network_operator_id num1
      from
      (
      select
          --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
          sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
          q2.*
        from
        (
        select
            --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
            decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
            q.*
          from
          (
          select /*+ ordered use_hash(pn pns nash naap sc ss)
            full(z)
            full(pn)
            full(pns)
            full(nash)
            full(naap)
            full(sc)
            full(ss)
            */
              pn.network_address_id,
              greatest(nash.start_date, naap.from_date) date_from,
              least(nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')), nvl(naap.to_date, to_date('01.01.4000','dd.mm.yyyy'))) date_to,
              pn.international_format msisdn,
              ss.network_operator_id
            from
              (select column_value network_address_id from table(p_na_ids)) z,
              phone_number pn,
              phone_number_series pns,
              network_address_status_history nash,
              network_address_access_point naap,
              sim_card sc,
              sim_series ss
            where 1 = 1
              and pn.network_address_id = z.network_address_id
              and pns.phone_number_series_id = pn.phone_number_series_id
              and pns.phone_number_type_code = util_ri.c_PNT_CODE_EXTERNAL
              and nash.network_address_id = pn.network_address_id
              and nash.start_date <= p_range_date_to
              and nvl(nash.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and nash.net_address_status_code != util_ri.c_NASHZ_CODE_EXTERNAL --!_! nash char(2)
              and naap.network_address_id = pn.network_address_id
              and greatest(nash.start_date, naap.from_date) <= least(nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')), nvl(naap.to_date, to_date('01.01.4000','dd.mm.yyyy')))
              and naap.from_date <= p_range_date_to
              and nvl(naap.to_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and sc.access_point_id = naap.access_point_id
              and ss.sim_series_id = sc.sim_series_id
              order by pn.network_address_id, date_from
          ) q
        ) q2
      ) q3
      group by
        network_address_id,
        msisdn,
        range_number,
        network_operator_id
    )
    order by
      interval_id,
      date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_comers_belarus2
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  if p_na_ids is null
  then
    ------------------------------
    v_res := get_comers_belarus_all2
    (
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  else
    ------------------------------
    v_res := get_comers_belarus4na_id2
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_comers_belarus_all3
(
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into v_res
    from
    (
    select
        network_address_id interval_id,
        min(date_from) date_from,
        max(date_to) date_to,
        msisdn str1,
        network_operator_id num1
      from
      (
      select
          --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
          sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
          q2.*
        from
        (
        select
            --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
            decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
            q.*
          from
          (
          select /*+ ordered use_hash(pns pn nash naap sc ss)
            full(pns)
            full(pn)
            full(nash)
            full(naap)
            full(sc)
            full(ss)
            parallel(pns 4)
            parallel(pn 4)
            parallel(nash 4)
            parallel(naap 4)
            parallel(sc 4)
            parallel(ss 4)
            */
              pn.network_address_id,
              greatest(nash.start_date, naap.from_date) date_from,
              least(nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')), nvl(naap.to_date, to_date('01.01.4000','dd.mm.yyyy'))) date_to,
              pn.international_format msisdn,
              ss.network_operator_id
            from
              phone_number_series pns,
              phone_number pn,
              network_address_status_history nash,
              network_address_access_point naap,
              sim_card sc,
              sim_series ss
            where 1 = 1
              and pns.phone_number_type_code = util_ri.c_PNT_CODE_EXTERNAL
              and pn.phone_number_series_id = pns.phone_number_series_id
              and nash.network_address_id = pn.network_address_id
              and nash.start_date <= p_range_date_to
              and nvl(nash.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and nash.net_address_status_code != util_ri.c_NASHZ_CODE_EXTERNAL --!_! nash char(2)
              and naap.network_address_id = pn.network_address_id
              and greatest(nash.start_date, naap.from_date) <= least(nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')), nvl(naap.to_date, to_date('01.01.4000','dd.mm.yyyy')))
              and naap.from_date <= p_range_date_to
              and nvl(naap.to_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and sc.access_point_id = naap.access_point_id
              and ss.sim_series_id = sc.sim_series_id
              order by pn.network_address_id, date_from
          ) q
        ) q2
      ) q3
      group by
        network_address_id,
        msisdn,
        range_number,
        network_operator_id
    )
    order by
      interval_id,
      date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_comers_belarus4na_id3
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  util_pkg.XCheck_Cond_Missing(p_na_ids is null, 'p_na_ids');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into v_res
    from
    (
    select
        network_address_id interval_id,
        min(date_from) date_from,
        max(date_to) date_to,
        msisdn str1,
        network_operator_id num1
      from
      (
      select
          --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
          sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
          q2.*
        from
        (
        select
            --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
            decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
            q.*
          from
          (
          select /*+ ordered use_hash(z pn pns nash naap sc ss)
            full(z)
            full(pn)
            full(pns)
            full(nash)
            full(naap)
            full(sc)
            full(ss)
            parallel(z 4)
            parallel(pn 4)
            parallel(pns 4)
            parallel(nash 4)
            parallel(naap 4)
            parallel(sc 4)
            parallel(ss 4)
            */
              pn.network_address_id,
              greatest(nash.start_date, naap.from_date) date_from,
              least(nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')), nvl(naap.to_date, to_date('01.01.4000','dd.mm.yyyy'))) date_to,
              pn.international_format msisdn,
              ss.network_operator_id
            from
              (select column_value network_address_id from table(p_na_ids)) z,
              phone_number pn,
              phone_number_series pns,
              network_address_status_history nash,
              network_address_access_point naap,
              sim_card sc,
              sim_series ss
            where 1 = 1
              and pn.network_address_id = z.network_address_id
              and pns.phone_number_series_id = pn.phone_number_series_id
              and pns.phone_number_type_code = util_ri.c_PNT_CODE_EXTERNAL
              and nash.network_address_id = pn.network_address_id
              and nash.start_date <= p_range_date_to
              and nvl(nash.end_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and nash.net_address_status_code != util_ri.c_NASHZ_CODE_EXTERNAL --!_! nash char(2)
              and naap.network_address_id = pn.network_address_id
              and greatest(nash.start_date, naap.from_date) <= least(nvl(nash.end_date, to_date('01.01.4000','dd.mm.yyyy')), nvl(naap.to_date, to_date('01.01.4000','dd.mm.yyyy')))
              and naap.from_date <= p_range_date_to
              and nvl(naap.to_date, to_date('01.01.4000', 'dd.mm.yyyy')) >= p_range_date_from
              and sc.access_point_id = naap.access_point_id
              and ss.sim_series_id = sc.sim_series_id
              order by pn.network_address_id, date_from
          ) q
        ) q2
      ) q3
      group by
        network_address_id,
        msisdn,
        range_number,
        network_operator_id
    )
    order by
      interval_id,
      date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_comers_belarus3
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  if p_na_ids is null
  then
    ------------------------------
    v_res := get_comers_belarus_all3
    (
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  else
    ------------------------------
    v_res := get_comers_belarus4na_id3
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_goers_all
(
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into
    v_res
  from
    (
    select
      network_address_id interval_id,
      min(date_from) date_from,
      max(date_to) date_to,
      msisdn str1,
      null num1
    from
      (
      select
        --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
        sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
        q2.*
      from
        (
        select
          --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
          decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
          q.*
        from
          (
          select /*+ ordered use_nl(pn)
            full(po)
            index(pn I_PHONENUM_NA_MSISDN)
            */
            po.network_address_id,
            po.start_date date_from,
            po.end_date date_to,
            pn.international_format msisdn
          from
            phone_operator po,
            phone_number pn
          where 1 = 1
            and po.date_to_act = vp_phone_operator.c_date_to_act_active --!_!part
            and po.type in (vp_phone_operator.c_potype_own2other, vp_phone_operator.c_potype_own2own) --!_!subpart
            and po.start_date <= p_range_date_to
            and po.end_date >= p_range_date_from
            and pn.network_address_id = po.network_address_id
          order by
            po.network_address_id,
            date_from
          ) q
        ) q2
      ) q3
    group by
      network_address_id,
      msisdn,
      range_number
    )
  order by
    interval_id,
    date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_goers4na_id
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  util_pkg.XCheck_Cond_Missing(p_na_ids is null, 'p_na_ids');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into
    v_res
  from
    (
    select
      network_address_id interval_id,
      min(date_from) date_from,
      max(date_to) date_to,
      msisdn str1,
      null num1
    from
      (
      select
        --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
        sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
        q2.*
      from
        (
        select
          --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
          decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
          q.*
        from
          (
          select /*+ ordered use_nl(po pn)
            full(z)
            index(po I_PHONE_OPERATOR_NAID)
            index(pn I_PHONENUM_NA_MSISDN)
            */
            po.network_address_id,
            po.start_date date_from,
            po.end_date date_to,
            pn.international_format msisdn
          from
            (select column_value network_address_id from table(p_na_ids)) z,
            phone_operator po,
            phone_number pn
          where 1 = 1
            and po.network_address_id = z.network_address_id
            and po.date_to_act = vp_phone_operator.c_date_to_act_active --!_!part
            and po.type in (vp_phone_operator.c_potype_own2other, vp_phone_operator.c_potype_own2own) --!_!subpart
            and po.start_date <= p_range_date_to
            and po.end_date >= p_range_date_from
            and pn.network_address_id = z.network_address_id
          order by
            po.network_address_id,
            date_from
          ) q
        ) q2
      ) q3
    group by
      network_address_id,
      msisdn,
      range_number
    )
  order by
    interval_id,
    date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_goers
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  if p_na_ids is null
  then
    ------------------------------
    v_res := get_goers_all
    (
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  else
    ------------------------------
    v_res := get_goers4na_id
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_comers_all
(
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into
    v_res
  from
    (
    select
      network_address_id interval_id,
      min(date_from) date_from,
      max(date_to) date_to,
      msisdn str1,
      network_operator_id num1
    from
      (
      select
        --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
        sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
        q2.*
      from
        (
        select
          --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
          decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
          q.*
        from
          (
          select /*+ ordered use_nl(pn)
            full(po)
            index(pn I_PHONENUM_NA_MSISDN)
            */
            po.network_address_id,
            po.start_date date_from,
            po.end_date date_to,
            pn.international_format msisdn,
            po.network_operator_id
          from
            phone_operator po,
            phone_number pn
          where 1 = 1
            and po.date_to_act = vp_phone_operator.c_date_to_act_active --!_!part
            and po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own) --!_!subpart
            and po.start_date <= p_range_date_to
            and po.end_date >= p_range_date_from
            and pn.network_address_id = po.network_address_id
          order by
            po.network_address_id,
            date_from
          ) q
        ) q2
      ) q3
    group by
      network_address_id,
      msisdn,
      range_number,
      network_operator_id
    )
  order by
    interval_id,
    date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;


----------------------------------!---------------------------------------------
function get_comers4na_id
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  lc_same number := 0;
  lc_new number := 1;
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  util_pkg.XCheck_Cond_Missing(p_na_ids is null, 'p_na_ids');
  ------------------------------
  select
    ot_interval
    (
      interval_id,
      date_from,
      date_to,
      str1,
      num1
    )
  bulk collect into
    v_res
  from
    (
    select
      network_address_id interval_id,
      min(date_from) date_from,
      max(date_to) date_to,
      msisdn str1,
      network_operator_id num1
    from
      (
      select
        --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
        sum(is_new_range) over (partition by network_address_id order by date_from) range_number,
        q2.*
      from
        (
        select
          --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
          decode(date_from - lag(date_to + util_pkg.c_dt_dif) over(partition by network_address_id order by date_from), 0, lc_same, lc_new) is_new_range,
          q.*
        from
          (
          select /*+ ordered use_nl(po pn)
            full(z)
            index(po I_PHONE_OPERATOR_NAID)
            index(pn I_PHONENUM_NA_MSISDN)
            */
            po.network_address_id,
            po.start_date date_from,
            po.end_date date_to,
            pn.international_format msisdn,
            po.network_operator_id
          from
            (select column_value network_address_id from table(p_na_ids)) z,
            phone_operator po,
            phone_number pn
          where 1 = 1
            and po.network_address_id = z.network_address_id
            and po.date_to_act = vp_phone_operator.c_date_to_act_active --!_!part
            and po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own) --!_!subpart
            and po.start_date <= p_range_date_to
            and po.end_date >= p_range_date_from
            and pn.network_address_id = z.network_address_id
          order by
            po.network_address_id,
            date_from
          ) q
        ) q2
      ) q3
    group by
      network_address_id,
      msisdn,
      range_number,
      network_operator_id
    )
  order by
    interval_id,
    date_from
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;


----------------------------------!---------------------------------------------
function get_comers
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return ct_interval
is
  v_res ct_interval;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_date_from is null, 'p_range_date_from');
  util_pkg.XCheck_Cond_Missing(p_range_date_to is null, 'p_range_date_to');
  ------------------------------
  if p_na_ids is null
  then
    ------------------------------
    v_res := get_comers_all
    (
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  else
    ------------------------------
    v_res := get_comers4na_id
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_goers2
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return sys_refcursor
is
  v_res sys_refcursor;
  v_opt number;
  v_interval ct_interval;
begin
  ------------------------------
  v_opt := install_pkg.nnget_option_num(c_opt_mnp_mode_goers, c_def_mnp_mode_goers);
  ------------------------------
  XCheck_mnp_mode(v_opt, c_opt_mnp_mode_goers);
  ------------------------------
  if v_opt = c_mnpmode_old
  then
    ------------------------------
    v_interval := get_goers_belarus
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  elsif v_opt = c_mnpmode_old_hash
  then
    ------------------------------
    v_interval := get_goers_belarus2
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  elsif v_opt = c_mnpmode_old_hashparallel
  then
    ------------------------------
    v_interval := get_goers_belarus3
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  else --!_!c_mnpmode_normal
    ------------------------------
    v_interval := get_goers
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  end if;
  ------------------------------
  open v_res for
  select
    str1 international_format,
    date_from start_date,
    date_to end_date
  from
    table(v_interval) q
  order by
    international_format,
    start_date
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_comers2
(
  p_na_ids ct_number,
  p_range_date_from date,
  p_range_date_to date
) return sys_refcursor
is
  v_res sys_refcursor;
  v_opt number;
  v_interval ct_interval;
begin
  ------------------------------
  v_opt := install_pkg.nnget_option_num(c_opt_mnp_mode_comers, c_def_mnp_mode_comers);
  ------------------------------
  XCheck_mnp_mode(v_opt, c_opt_mnp_mode_comers);
  ------------------------------
  if v_opt = c_mnpmode_old
  then
    ------------------------------
    v_interval := get_comers_belarus
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  elsif v_opt = c_mnpmode_old_hash
  then
    ------------------------------
    v_interval := get_comers_belarus2
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  elsif v_opt = c_mnpmode_old_hashparallel
  then
    ------------------------------
    v_interval := get_comers_belarus3
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  else --!_!c_mnpmode_normal
    ------------------------------
    v_interval := get_comers
    (
      p_na_ids => p_na_ids,
      p_range_date_from => p_range_date_from,
      p_range_date_to => p_range_date_to
    );
    ------------------------------
  end if;
  ------------------------------
  open v_res for
  select
    str1 international_format,
    num1 network_operator_id,
    date_from from_date,
    date_to to_date
  from
    table(v_interval) q
  order by
    international_format,
    from_date
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_no_po_i0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_id) != v_main_count, 'p_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q2) use_nl(z) index_asc(z, I_PHONE_OPERATOR_NAID)*/
    z.network_operator_id,
    q.rn
  bulk collect into
    v_res,
    v_rn
  from
    (select column_value network_address_id, rownum rn from table(p_na_id)) q,
    (select column_value on_date, rownum rn from table(p_date)) q2,
    phone_operator z
  where 1 = 1
    and q2.rn = q.rn
    and z.network_address_id = q.network_address_id
    and q2.on_date between z.start_date and z.end_date
    and z.date_to_act >= q2.on_date --!_! part
  order by
    q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'phone_operator');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_po_i(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_na_id), p_date);
  ------------------------------
  return get_no_po_i0(p_na_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_po_i2(p_na_id number, p_date date) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_no_po_i(v_na_id, p_date, FALSE)(util_pkg.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_po_internal0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number
is
  v_marks ct_number;
  v_no_id_po ct_number;
  v_no_type ct_varchar_s;
begin
  ------------------------------
  v_no_id_po := get_no_po_i0(p_na_id => p_na_id, p_date => p_date, p_trim_empty => false);
  ------------------------------
  v_no_type := util_ri.get_network_operator_type_x0(p_network_operator_id => v_no_id_po, p_date => p_date, p_trim_empty => false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_varchar_s(v_no_type, util_ri.c_NOPT_CODE_INTERNAL_FAKE);
  ------------------------------
  return util_pkg.get_marked_ct_number(p_vals => v_no_id_po, p_marks => v_marks, p_trim_empty => p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_po_internal(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_na_id), p_date);
  ------------------------------
  return get_no_po_internal0(p_na_id, v_date, p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_po_internal2(p_na_id number, p_date date) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_no_po_internal(v_na_id, p_date, FALSE)(util_pkg.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_po_external0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number
is
  v_marks ct_number;
  v_no_id_po ct_number;
  v_no_type ct_varchar_s;
begin
  ------------------------------
  v_no_id_po := get_no_po_i0(p_na_id => p_na_id, p_date => p_date, p_trim_empty => false);
  ------------------------------
  v_no_type := util_ri.get_network_operator_type_x0(p_network_operator_id => v_no_id_po, p_date => p_date, p_trim_empty => false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_varchar_s(v_no_type, util_ri.c_NOPT_CODE_EXTERNAL);
  ------------------------------
  return util_pkg.get_marked_ct_number(p_vals => v_no_id_po, p_marks => v_marks, p_trim_empty => p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_po_external(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_na_id), p_date);
  ------------------------------
  return get_no_po_external0(p_na_id, v_date, p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_po_external2(p_na_id number, p_date date) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_no_po_external(v_na_id, p_date, FALSE)(util_pkg.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_po_any0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number
is
begin
  ------------------------------
  return get_no_po_i0(p_na_id => p_na_id, p_date => p_date, p_trim_empty => p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_po_any(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_na_id), p_date);
  ------------------------------
  return get_no_po_any0(p_na_id, v_date, p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_po_any2(p_na_id number, p_date date) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_no_po_any(v_na_id, p_date, FALSE)(util_pkg.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xdet_pns_id4msisdn2(p_msisdn varchar2, p_date date) return number
is
  v_res number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn is null, 'p_msisdn');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_res := util_ri.det_pns_id4msisdn2(p_msisdn => p_msisdn, p_date => p_date);
  ------------------------------
  if v_res is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate(p_msisdn, p_date, VP_PHONE_NUMBER_SERIES.c_this_name || c_delim_for || c_name_phone_number);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xsplit_pns4msisdn
(
  p_msisdn varchar2,
  p_date date,
  p_user_id number
) return number
is
  v_sp_name varchar2(30);
  v_pns_id_mnp number;
  v_range range_pkg.t_range;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn is null, 'p_msisdn');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_pns_id_mnp := xdet_pns_id4msisdn2(p_msisdn => p_msisdn, p_date => p_date);
  ------------------------------
  v_range := fastp_phone_series_pkg.row2t_range(vp_phone_number_series.xget1(v_pns_id_mnp, p_date));
  ------------------------------
  if not range_pkg.is_equal(v_range.item_from, p_msisdn)
  then
    ------------------------------
    fastp_phone_series_pkg.split_range2
    (
      p_id => v_pns_id_mnp,
      p_item_split_from => p_msisdn,
      p_user_id => p_user_id
    );
    ------------------------------
  end if;
  ------------------------------
  v_pns_id_mnp := xdet_pns_id4msisdn2(p_msisdn => p_msisdn, p_date => p_date);
  ------------------------------
  v_range := fastp_phone_series_pkg.row2t_range(vp_phone_number_series.xget1(v_pns_id_mnp, p_date));
  ------------------------------
  if not range_pkg.is_equal(p_msisdn, v_range.item_to)
  then
    ------------------------------
    fastp_phone_series_pkg.split_range2
    (
      p_id => v_pns_id_mnp,
      p_item_split_from => range_pkg.item2next_item(p_msisdn),
      p_user_id => p_user_id
    );
    ------------------------------
  end if;
  ------------------------------
  v_pns_id_mnp := xdet_pns_id4msisdn2(p_msisdn => p_msisdn, p_date => p_date);
  ------------------------------
  return v_pns_id_mnp;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_pns_can_be_latched(p_pns_id number, p_date date)
is
  v_range range_pkg.t_range;
  v_locker_id number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pns_id is null, 'p_pns_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_range := fastp_phone_series_pkg.row2t_range(vp_phone_number_series.xget1(p_pns_id, p_date));
  ------------------------------
  v_locker_id := range_pkg.xget_locker_id(v_range);
  ------------------------------
  locker_pkg.release_locker(v_locker_id); --!_!silent if not exists
  ------------------------------
exception
when others then
  ------------------------------
  locker_pkg.release_locker(v_locker_id); --!_!silent if not exists
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_pns_can_be_latched2(p_msisdn varchar2, p_date date)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn is null, 'p_msisdn');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  xcheck_pns_can_be_latched(p_pns_id => xdet_pns_id4msisdn2(p_msisdn => p_msisdn, p_date => p_date), p_date => p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!both mnp and template belong to internal operators
function xcheck_data_and_get_net_op
(
  p_msisdn_mnp varchar2,
  p_msisdn_template varchar2,
  p_date date
) return number
is
  v_na_id_template number;
  v_na_id_mnp number;
  v_no_id_template number;
  v_no_id_mnp number;
  v_pns_id_mnp number;
  v_row_pns phone_number_series%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn_mnp is null, 'p_msisdn_mnp');
  util_pkg.XCheck_Cond_Missing(p_msisdn_template is null, 'p_msisdn_template');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_pns_id_mnp := xdet_pns_id4msisdn2(p_msisdn => p_msisdn_mnp, p_date => p_date);
  v_row_pns := vp_phone_number_series.xget1(p_id => v_pns_id_mnp, p_date => p_date);
  ------------------------------
  if v_row_pns.phone_number_type_code = util_ri.c_PNT_CODE_EXTERNAL
  then
    ------------------------------
    --!_!really wrong is pnt, but it means that is wrong own net_op (external instead internal)
    util_pkg.raise_exception(util_loc_pkg.c_ora_wrong_no, util_loc_pkg.c_msg_wrong_no || util_pkg.c_msg_delim01 || 'phone_number_type_code' || util_pkg.c_msg_delim02 || v_row_pns.phone_number_type_code);
    ------------------------------
  end if;
  ------------------------------
  v_na_id_template := util_ri.get_na_id2(p_msisdn_template, p_date);
  ------------------------------
  if v_na_id_template is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate(p_msisdn_template, p_date, c_name_phone_number);
    ------------------------------
  end if;
  ------------------------------
  v_no_id_template := get_no_own_internal2(v_na_id_template, p_date);
  ------------------------------
  if v_no_id_template is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(v_na_id_template, p_date, VP_PHONE_SERIES_OPERATOR.c_this_name || c_delim_for || c_name_network_address);
    ------------------------------
  end if;
  ------------------------------
  v_na_id_mnp := util_ri.get_na_id2(p_msisdn_mnp, p_date);
  ------------------------------
  if v_na_id_mnp is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate(p_msisdn_mnp, p_date, c_name_phone_number);
    ------------------------------
  end if;
  ------------------------------
  v_no_id_mnp := get_no_own_internal2(v_na_id_mnp, p_date);
  ------------------------------
  if v_no_id_mnp is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(v_na_id_mnp, p_date, VP_PHONE_SERIES_OPERATOR.c_this_name || c_delim_for || c_name_network_address);
    ------------------------------
  end if;
  ------------------------------
  if v_no_id_mnp = v_no_id_template
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_no_action_required, util_pkg.c_msg_no_action_required);
    ------------------------------
  end if;
  ------------------------------
  xcheck_pns_can_be_latched2(p_msisdn => p_msisdn_mnp, p_date => p_date);
  ------------------------------
  fast_parallel_pkg.xneed_to_restrict_flow(p_flow_type_id => fastp_phone_series_pkg.c_fastp_ft_ph_ser_split, p_this_is_created => false);
  ------------------------------
  return v_no_id_template;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_host4pn(p_msisdn varchar2, p_date date) return number
is
  v_na_id number;
  v_host_id number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn is null, 'p_msisdn');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_na_id := util_ri.get_na_id2(p_msisdn, p_date);
  ------------------------------
  if v_na_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate(p_msisdn, p_date, c_name_phone_number);
    ------------------------------
  end if;
  ------------------------------
  v_host_id := util_ri.get_na_host_id2(p_na_id => v_na_id, p_date => p_date);
  ------------------------------
  if v_host_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(v_na_id, p_date, VP_HOST.c_this_name || c_delim_for || c_name_network_address);
    ------------------------------
  end if;
  ------------------------------
  return v_host_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_host4sim(p_msisdn varchar2, p_date date) return number
is
  v_na_id number;
  v_ap_id number;
  v_host_id number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn is null, 'p_msisdn');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_na_id := util_ri.get_na_id2(p_msisdn, p_date);
  ------------------------------
  if v_na_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate(p_msisdn, p_date, c_name_phone_number);
    ------------------------------
  end if;
  ------------------------------
  v_ap_id := util_ri.get_linked_ap_id2(p_na_id => v_na_id, p_link_type_code => util_ri.c_NAAP_LINK_TYPE_CODE_MAIN, p_date => p_date);
  ------------------------------
  if v_ap_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(v_na_id, p_date, c_name_access_point || c_delim_for || c_name_network_address);
    ------------------------------
  end if;
  ------------------------------
  v_host_id := util_ri.get_ap_host_id2(p_ap_id => v_ap_id, p_date => p_date);
  ------------------------------
  if v_host_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(v_ap_id, p_date, VP_HOST.c_this_name || c_delim_for || c_name_access_point);
    ------------------------------
  end if;
  ------------------------------
  return v_host_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!both mnp and template belong to internal operators
procedure change_main_net_op4phone_num
(
  p_msisdn_mnp varchar2,
  p_msisdn_template varchar2,
  p_date date,
  p_user_id number
)
is
  v_sp_name varchar2(30);
  v_no_id_template number;
  v_pns_id_mnp number;
  v_row_pns phone_number_series%rowtype;
  v_row_pso phone_series_operator%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn_mnp is null, 'p_msisdn_mnp');
  util_pkg.XCheck_Cond_Missing(p_msisdn_template is null, 'p_msisdn_template');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_no_id_template := xcheck_data_and_get_net_op
  (
    p_msisdn_mnp => p_msisdn_mnp,
    p_msisdn_template => p_msisdn_template,
    p_date => p_date
  );
  ------------------------------
  --!_!parallel split
  v_pns_id_mnp := xsplit_pns4msisdn
  (
    p_msisdn => p_msisdn_mnp,
    p_date => p_date,
    p_user_id => p_user_id
  );
  ------------------------------
  --!_!same as util_ri.get_int_no4na2(v_na_id_mnp, p_date)
  v_row_pso := vp_phone_series_operator.get_4_net_op_type(p_external => false, p_pns_id => v_pns_id_mnp, p_date => p_date);
  ------------------------------
  if not vp_phone_series_operator.is_identified(v_row_pso)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(v_pns_id_mnp, p_date, VP_PHONE_SERIES_OPERATOR.c_this_name || c_delim_for || VP_PHONE_NUMBER_SERIES.c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if install_pkg.nnget_option_bool(c_opt_mnp_chnetop_change_host, c_def_mnp_chnetop_change_host)
  then
    ------------------------------
    v_row_pns := vp_phone_number_series.xlock_xget1(p_id => v_pns_id_mnp, p_date => p_date);
    ------------------------------
    v_row_pns.user_id_of_change := p_user_id;
    ------------------------------
    if install_pkg.nnget_option_bool(c_opt_mnp_chnetop_get_host_sim, c_def_mnp_chnetop_get_host_sim)
    then
      ------------------------------
      v_row_pns.host_id := xget_host4sim(p_msisdn => p_msisdn_template, p_date => p_date);
      ------------------------------
    else
      ------------------------------
      v_row_pns.host_id := xget_host4pn(p_msisdn => p_msisdn_template, p_date => p_date);
      ------------------------------
    end if;
    ------------------------------
    vp_phone_number_series.version_change(p_rec => v_row_pns);
    ------------------------------
  end if;
  ------------------------------
  v_row_pso := vp_phone_series_operator.xlock_xget1(p_id => v_row_pso.phone_number_series_id, p_id2 => v_row_pso.network_operator_id, p_date => p_date);
  ------------------------------
  vp_phone_series_operator.version_close(p_id => v_row_pso.phone_number_series_id, p_id2 => v_row_pso.network_operator_id, p_user_id => p_user_id);
  ------------------------------
  v_row_pso.network_operator_id := v_no_id_template;
  v_row_pso.start_date := null;
  v_row_pso.end_date := null;
  v_row_pso.user_id_of_change := p_user_id;
  ------------------------------
  vp_phone_series_operator.version_open(p_rec => v_row_pso);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!both mnp and template belong to internal operators
procedure xcheck4change_main_net_op
(
  p_msisdn_mnp varchar2,
  p_msisdn_template varchar2,
  p_date date
)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(xcheck_data_and_get_net_op
  (
    p_msisdn_mnp => p_msisdn_mnp,
    p_msisdn_template => p_msisdn_template,
    p_date => p_date
  ));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_no_own_internal0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  return util_ri.get_int_no4na0(p_na_id => p_na_id, p_date => p_date, p_trim_empty => p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_own_internal(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_na_id), p_date);
  ------------------------------
  return get_no_own_internal0(p_na_id => p_na_id, p_date => v_date, p_trim_empty => p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_own_internal2(p_na_id number, p_date date) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_no_own_internal(v_na_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_own_external0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  return util_ri.get_ext_no4na0(p_na_id => p_na_id, p_date => p_date, p_trim_empty => p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_own_external(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_na_id), p_date);
  ------------------------------
  return get_no_own_external0(p_na_id => p_na_id, p_date => v_date, p_trim_empty => p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_own_external2(p_na_id number, p_date date) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_no_own_external(v_na_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_own_any0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number
is
  v_no_id_int ct_number;
  v_no_id_ext ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_no_id_int := get_no_own_internal0(p_na_id => p_na_id, p_date => p_date, p_trim_empty => false);
  v_no_id_ext := get_no_own_external0(p_na_id => p_na_id, p_date => p_date, p_trim_empty => false);
  ------------------------------
  return util_pkg.supplement_ct_number(p_vals => v_no_id_int, p_supplement => v_no_id_ext, p_trim_empty => p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_own_any(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_na_id), p_date);
  ------------------------------
  return get_no_own_any0(p_na_id => p_na_id, p_date => v_date, p_trim_empty => p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_own_any2(p_na_id number, p_date date) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_no_own_any(v_na_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_current_any0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number
is
  v_no_id_po ct_number;
  v_no_id_own ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_no_id_po := get_no_po_i0(p_na_id => p_na_id, p_date => p_date, p_trim_empty => false);
  v_no_id_own := get_no_own_any0(p_na_id => p_na_id, p_date => p_date, p_trim_empty => false);
  ------------------------------
  return util_pkg.supplement_ct_number(p_vals => v_no_id_po, p_supplement => v_no_id_own, p_trim_empty => p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_current_any(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_date := util_pkg.make_ct_date(util_pkg.get_count_ct_number(p_na_id), p_date);
  ------------------------------
  return get_no_current_any0(p_na_id => p_na_id, p_date => v_date, p_trim_empty => p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no_current_any2(p_na_id number, p_date date) return number
is
  v_na_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  return get_no_current_any(v_na_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_!call only after PortIn
function xget_proper_hlr2(p_na_id number, p_date date) return number
is
  v_res number;
  v_ap_id number;
  v_no_id_own number;
  v_no_id_cur number;
  v_any_host boolean := false;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  if util_ri.get_msisdn2(p_na_id => p_na_id, p_date => p_date) is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_na_id, p_date, c_name_network_address);
    ------------------------------
  end if;
  ------------------------------
  v_ap_id := util_ri.get_linked_ap_id2(p_na_id => p_na_id, p_link_type_code => util_ri.c_NAAP_LINK_TYPE_CODE_ANYDUMMY, p_date => p_date);
  ------------------------------
  if v_ap_id is null --!_!need to check MNP or not
  then
    ------------------------------
    v_no_id_own := get_no_own_any2(p_na_id => p_na_id, p_date => p_date);
    v_no_id_cur := get_no_current_any2(p_na_id => p_na_id, p_date => p_date);
    ------------------------------
    util_pkg.XCheck_Cond_Invalid(v_no_id_own is null, 'v_no_id_own is null');
    util_pkg.XCheck_Cond_Invalid(v_no_id_cur is null, 'v_no_id_cur is null');
    ------------------------------
    if v_no_id_own = v_no_id_cur --!_!non-MNP
    then
      ------------------------------
      v_res := util_ri.get_na_host_id2(p_na_id => p_na_id, p_date => p_date); --!_!below it can raise exception if this phone_number_series.host_id is null (as usually for external series with type E)
      ------------------------------
    else --!_!MNP
      ------------------------------
      v_any_host := TRUE;
      ------------------------------
    end if;
    ------------------------------
  else --!_!don't care MNP or not
    ------------------------------
    v_res := util_ri.get_ap_host_id2(p_ap_id => v_ap_id, p_date => p_date);
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(not v_any_host and v_res is null, 'v_res (proper_hlr) is null');
  ------------------------------
  if v_any_host
  then
    ------------------------------
    v_res := c_ANY_VALUE_DUMMY_NULL;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_mnp_port_in_valid2
(
  p_msisdn_mnp varchar2,
  p_msisdn_template varchar2,
  p_date date
) return boolean
is
  v_na_id_mnp number;
  v_na_id_template number;
  v_ap_id_mnp number;
  v_ap_id_template number;
  v_no_id_own_mnp number;
  v_no_id_cur_mnp number;
  v_no_id_cur_template number;
  v_host_id_mnp number;
  v_host_id_template number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn_mnp is null, 'p_msisdn_mnp');
  util_pkg.XCheck_Cond_Missing(p_msisdn_template is null, 'p_msisdn_template');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_na_id_template := util_ri.get_na_id2(p_msisdn => p_msisdn_template, p_date => p_date);
  ------------------------------
  if v_na_id_template is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate(p_msisdn_template, p_date, c_name_network_address);
    ------------------------------
  end if;
  ------------------------------
  v_ap_id_template := util_ri.get_linked_ap_id2(p_na_id => v_na_id_template, p_link_type_code => util_ri.c_NAAP_LINK_TYPE_CODE_ANYDUMMY, p_date => p_date);
  ------------------------------
  if v_ap_id_template is null
  then
    ------------------------------
    util_pkg.raise_exception(util_loc_pkg.c_ora_na_not_linked, util_loc_pkg.c_msg_na_not_linked || util_pkg.c_msg_delim01 || util_pkg.number_to_char(v_na_id_template));
    ------------------------------
  end if;
  ------------------------------
  v_na_id_mnp := util_ri.get_na_id2(p_msisdn => p_msisdn_mnp, p_date => p_date);
  ------------------------------
  if v_na_id_mnp IS NULL
  then
    ------------------------------
    RETURN true;
    ------------------------------
  end if;
  ------------------------------
  v_ap_id_mnp := util_ri.get_linked_ap_id2(p_na_id => v_na_id_mnp, p_link_type_code => util_ri.c_NAAP_LINK_TYPE_CODE_ANYDUMMY, p_date => p_date);
  ------------------------------
  if v_ap_id_mnp IS NOT NULL
  then
    ------------------------------
    util_pkg.raise_exception(util_loc_pkg.c_ora_na_linked_to_other_ap, util_loc_pkg.c_msg_na_linked_to_other_ap || util_pkg.c_msg_delim01 || util_pkg.number_to_char(v_na_id_mnp));
    ------------------------------
  end if;
  ------------------------------
  v_no_id_own_mnp := get_no_own_any2(p_na_id => v_na_id_mnp, p_date => p_date);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_no_id_own_mnp is null, 'v_no_id_own_mnp is null');
  ------------------------------
  if util_ri.get_network_operator_type_x2(p_network_operator_id => v_no_id_own_mnp, p_date => p_date) = util_ri.c_NOPT_CODE_EXTERNAL
  then
    ------------------------------
    RETURN true;
    ------------------------------
  end if;
  ------------------------------
  v_no_id_cur_mnp := get_no_current_any2(p_na_id => v_na_id_mnp, p_date => p_date);
  v_no_id_cur_template := util_ri.get_ap_no_id2(p_ap_id => v_ap_id_template, p_date => p_date);
  ------------------------------
  if v_no_id_cur_mnp != v_no_id_cur_template
  then
    ------------------------------
    RETURN true;
    ------------------------------
  end if;
  ------------------------------
  v_host_id_mnp := util_ri.get_na_host_id2(p_na_id => v_na_id_mnp, p_date => p_date);
  v_host_id_template := util_ri.get_ap_host_id2(p_ap_id => v_ap_id_template, p_date => p_date);
  ------------------------------
  if v_host_id_mnp = v_host_id_template
  then
    ------------------------------
    RETURN true;
    ------------------------------
  end if;
  ------------------------------
  RETURN false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_expired_phone_operator
(
  p_expire_date date
) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_expire_date is null, 'p_expire_date');
  ------------------------------
  open v_res for
  select /*+ full(z)*/
    network_address_id,
    start_date date_from
  from
    phone_operator z
  where 1 = 1
    and date_to_act = vp_phone_operator.c_date_to_act_active --!_!part
    and end_date < p_expire_date
  order by
    end_date,
    network_address_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_phone_info
(
  p_msisdn ct_varchar_s,
  p_result out sys_refcursor
)
is
  v_date date := sysdate;
  v_na_id ct_number;
  v_m_na_id ct_number;
  v_l_na_id ct_number;
  v_m_msisdn ct_varchar_s;
  v_l_msisdn ct_varchar_s;
  v_m_na_status ct_varchar_s;
  v_l_na_status ct_varchar_s;
  v_m_na_sal_cat ct_varchar_s;
  v_l_na_sal_cat ct_varchar_s;
  v_m_pns_id ct_number;
  v_l_pns_id ct_number;
  v_m_pns_id2 ct_number;
  v_m_pns_type ct_varchar_s;
  v_l_pns_type ct_varchar_s;
  v_m_host_id ct_number;
  v_l_host_id ct_number;
  v_m_host_code ct_varchar_s;
  v_l_host_code ct_varchar_s;
  v_m_host_name ct_varchar;
  v_l_host_name ct_varchar;
  v_m_host_type ct_varchar_s;
  v_l_host_type ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdn);
  ------------------------------
  v_na_id := util_ri.get_na_id(p_msisdn, v_date, FALSE);
  ------------------------------
  util_ri.prepare_as_pnlnk_exact(v_na_id, v_date, v_m_na_id, v_l_na_id, v_m_msisdn, v_l_msisdn);
  ------------------------------
  v_m_na_status := util_ri.get_na_status_current1(v_m_na_id, v_date, FALSE);
  v_l_na_status := util_ri.get_na_status_current1(v_l_na_id, v_date, FALSE);
  ------------------------------
  v_m_na_sal_cat := util_ri.get_na_sel_cat_current(v_m_na_id, v_date, FALSE);
  v_l_na_sal_cat := util_ri.get_na_sel_cat_current(v_l_na_id, v_date, FALSE);
  ------------------------------
  ------------------------------
  v_m_pns_id := util_ri.get_na_pns_id(v_m_na_id, v_date, FALSE);
  v_l_pns_id := util_ri.get_na_pns_id(v_l_na_id, v_date, FALSE);
  ------------------------------
  v_m_pns_id2 := util_ri.det_pns_id4msisdn(p_msisdn, v_date, FALSE);
  ------------------------------
  v_m_pns_id := util_pkg.supplement_ct_number(v_m_pns_id, v_m_pns_id2, FALSE, NULL);
  ------------------------------
  ------------------------------
  v_m_pns_type := util_ri.get_pns_type(v_m_pns_id, v_date, FALSE);
  v_l_pns_type := util_ri.get_pns_type(v_l_pns_id, v_date, FALSE);
  ------------------------------
  v_m_host_id := util_ri.get_pns_host_id(v_m_pns_id, v_date, FALSE);
  v_l_host_id := util_ri.get_pns_host_id(v_l_pns_id, v_date, FALSE);
  ------------------------------
  v_m_host_code := util_ri.get_host_code(v_m_host_id, v_date, FALSE);
  v_l_host_code := util_ri.get_host_code(v_l_host_id, v_date, FALSE);
  ------------------------------
  v_m_host_name := util_ri.get_host_name(v_m_host_id, v_date, FALSE);
  v_l_host_name := util_ri.get_host_name(v_l_host_id, v_date, FALSE);
  ------------------------------
  v_m_host_type := util_ri.get_host_type(v_m_host_id, v_date, FALSE);
  v_l_host_type := util_ri.get_host_type(v_l_host_id, v_date, FALSE);
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q q1 q2 q3 q4 q5 q6 q7 q8 q9 q10 q11 q12 q13 q14 q15 q16)*/
  q.in_msisdn,
  q1.msisdn,
  q2.phone_status,
  q3.sal_cat,
  q4.phone_type,
  q5.host_id,
  q6.host_code,
  q7.host_name,
  q8.host_type,
  q9.msisdn_l,
  q10.phone_status_l,
  q11.sal_cat_l,
  q12.phone_type_l,
  q13.host_id_l,
  q14.host_code_l,
  q15.host_name_l,
  q16.host_type_l
  from
    (select column_value in_msisdn, rownum rn from table(p_msisdn)) q,
    (select column_value msisdn, rownum rn from table(v_m_msisdn)) q1,
    (select column_value phone_status, rownum rn from table(v_m_na_status)) q2,
    (select column_value sal_cat, rownum rn from table(v_m_na_sal_cat)) q3,
    (select column_value phone_type, rownum rn from table(v_m_pns_type)) q4,
    (select column_value host_id, rownum rn from table(v_m_host_id)) q5,
    (select column_value host_code, rownum rn from table(v_m_host_code)) q6,
    (select column_value host_name, rownum rn from table(v_m_host_name)) q7,
    (select column_value host_type, rownum rn from table(v_m_host_type)) q8,
    (select column_value msisdn_l, rownum rn from table(v_l_msisdn)) q9,
    (select column_value phone_status_l, rownum rn from table(v_l_na_status)) q10,
    (select column_value sal_cat_l, rownum rn from table(v_l_na_sal_cat)) q11,
    (select column_value phone_type_l, rownum rn from table(v_l_pns_type)) q12,
    (select column_value host_id_l, rownum rn from table(v_l_host_id)) q13,
    (select column_value host_code_l, rownum rn from table(v_l_host_code)) q14,
    (select column_value host_name_l, rownum rn from table(v_l_host_name)) q15,
    (select column_value host_type_l, rownum rn from table(v_l_host_type)) q16
  where 1 = 1
  and q1.rn(+) = q.rn
  and q2.rn(+) = q.rn
  and q3.rn(+) = q.rn
  and q4.rn(+) = q.rn
  and q5.rn(+) = q.rn
  and q6.rn(+) = q.rn
  and q7.rn(+) = q.rn
  and q8.rn(+) = q.rn
  and q9.rn(+) = q.rn
  and q10.rn(+) = q.rn
  and q11.rn(+) = q.rn
  and q12.rn(+) = q.rn
  and q13.rn(+) = q.rn
  and q14.rn(+) = q.rn
  and q15.rn(+) = q.rn
  and q16.rn(+) = q.rn
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_main_host_by_iccid
(
  p_iccid ct_varchar_s,
  p_result out sys_refcursor
)
is
  v_date date := sysdate;
  v_ap_id ct_number;
  v_host_id ct_number;
  v_host_code ct_varchar_s;
  v_host_name ct_varchar;
  v_host_type ct_varchar_s;
  v_parent_host_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_iccid);
  ------------------------------
  v_ap_id := util_ri.get_ap_id(p_iccid, v_date, FALSE);
  ------------------------------
  v_host_id := util_ri.get_ap_host_id(v_ap_id, v_date, FALSE);
  ------------------------------
  v_host_code := util_ri.get_host_code(v_host_id, v_date, FALSE);
  ------------------------------
  v_host_name := util_ri.get_host_name(v_host_id, v_date, FALSE);
  ------------------------------
  v_host_type := util_ri.get_host_type(v_host_id, v_date, FALSE);
  ------------------------------
  v_parent_host_id := util_ri.get_host_parent(v_host_id, v_date, FALSE);
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q q1 q2 q3 q4 q5)*/
  q.in_iccid,
  q1.host_id,
  q2.host_code,
  q3.host_name,
  q4.host_type,
  q5.parent_host_id
  from
    (select column_value in_iccid, rownum rn from table(p_iccid)) q,
    (select column_value host_id, rownum rn from table(v_host_id)) q1,
    (select column_value host_code, rownum rn from table(v_host_code)) q2,
    (select column_value host_name, rownum rn from table(v_host_name)) q3,
    (select column_value host_type, rownum rn from table(v_host_type)) q4,
    (select column_value parent_host_id, rownum rn from table(v_parent_host_id)) q5
  where 1 = 1
  and q1.rn(+) = q.rn
  and q2.rn(+) = q.rn
  and q3.rn(+) = q.rn
  and q4.rn(+) = q.rn
  and q5.rn(+) = q.rn
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
