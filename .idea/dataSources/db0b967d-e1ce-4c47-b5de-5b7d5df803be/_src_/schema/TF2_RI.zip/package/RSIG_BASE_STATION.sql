CREATE PACKAGE          "RSIG_BASE_STATION" IS
/****************************************************************************
<header>
  <name>             	package RSIG_BASE_STATION
  </name>

  <author>           	Jan Stodulka - GITUS
  </author>

  <version>           1.4.11    21.06.2011       Victor Smirnov
                      procedure Update_Base_Station updated
                      procedure Update_Base_Station2 updated
  </version>
  <version>           1.4.10    15.03.2011       Pavel Vasiliev
                      procedure Update_Base_Station2 updated
  </version>

  <version>           1.4.9    17.11.2010       Pavel Vasiliev
                      procedure Insert_Base_Station2 added
                      procedure Update_Base_Station2 added
                      procedure Get_LocNo added
  </version>

  <version>           1.4.8    08.08.2007       Roger Stockley
                      procedure Get_Base_Station_By_NetOp added
  </version>
  <version>           1.4.7    27.07.2007       Roger Stockley
                      procedure Get_Base_Station_Zone_History  updated
  </version>
  <version>           1.4.6    14.03.2007       Roger Stockley
                      procedure Insert_Base_Station updated
                      procedure Update_Base_Station updated
  </version>
  <version>           1.4.5    12.03.2007       Roger Stockley
                      procedure Update_Base_Station updated
                      procedure Insert_Base_Station updated
                      procedure Get_Base_Station_All updated
                      procedure Get_Base_Station_Zone_History created
  </version>
  <version>           1.4.4    22.02.2007   Petr Cepek
                      procedure Get_Base_Station_All updated
  </version>
  <version>           1.4.3    28.08.2006   Petr Cepek
                      procedure Delete_Base_Station updated
  </version>
  <version>           1.4.2    2.8.2006     Petr Cepek
                      procedure Update_Base_Station updated
                      procedure Insert_Base_Station updated
                      procedure Get_Base_Station deleted
  </version>
  <version>           1.4.1   10.04.2006    Petr Cepek
                      procedure Insert_Base_Station and Update_Base_Station updated
  </version>
  <version>
                      1.4.0   05.01.2005   Petr Cepek
                      procedures Insert_Base_Station,Update_Base_Station,Get_Base_Station_All updated
                      procedures Insert_BS_Address_Interval,Remove_BS_Address_Interval,Get_Address_Id_History_by_BS
                      created

  <version>

  <version>           1.3.0   16.12.2005   Petr Cepek
                      procedure Get_Base_Station_All updated

  </version>
	<version>			      1.1.2	3.8.2004     Jaroslav Holub
								      Delete_base_station - fixed for time difference between client and server,
								      p_deleted should be null and it means sysdate
	</version>
  <version>   			  1.2.1   13.4.2004     Pavel Stengl
                      Delete_Base_Station - add delete dependet on rows in ZONE_BASE_STATION table
  </version>

  <version>           1.2.0   8.4.2004     Jaroslav Holub
                      changed for undelete
  </version>
  <version>           1.1.20   31.3.2003     Pavel Stengl
                      procedure Get_Base_Station_All - statement for ref. cursor modified
  </version>
  <version>          	1.1.19  15.12.2003				jstodulk
								      Insert debug constant.
  </version>
  <version>          	1.1.18  9.12.2003				jstodulk
								      Change column EXCHANGE_ID -> HOST_ID and EXCHANGE_ID_PLACED -> HOST_ID_PLACED.
  </version>
  <version>				    1.0.1   16.9.2003    	jan Stodulka
								      created fisrts version
  </version>

  <Description>       Package contains procedures for managing base stations.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/

/****************************************************************************
  <header>
    <name>              procedure Insert_Base_Station
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.2.4   14.03.2007   Roger Stockley
                        Parameters p_zone_id, p_zone_type deleted.
                        No longer inserts into table zone_base_station
    </version>
    <version>           1.2.3   12.03.2007   Roger Stockley
                        parameter zone_type_id added
    </version>
    <version>           1.2.2   2.8.2006     Petr Cepek
                        inserting relation to zone changed
    </version>
    <version>           1.2.1   10.04.2005   Petr Cepek
                        error messages fixed
    </version>
    <version>           1.2.0   05.01.2005   Petr Cepek
                        new columns added(PARENT_BASE_STATION_ID,RADIUS,LONGITUDE,LATITUDE)
                        filling of table base_station_address_history added
    </version>
    <version>           1.1.0   8.4.2004     Jaroslav Holub
                                changed for undelete
    </version>
    <version>           1.0.2   30.3.2004     Sergei Korotkevich
                                added code for linking Zone and Basestation
    </version>
    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure inserts information about base station.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code            - Error code
                        p_location_area_code  - Code of location area
                        p_base_station_code   - Code of base station
                        p_base_station_name   - name of base station
                        p_zone_code           - Code of zone
                        p_user_id_of_change   - User id of change
    </Parameters>

  </header>
/****************************************************************************/

PROCEDURE Insert_Base_Station(
  handle_tran               IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT NUMBER,
  p_location_area_id        IN  BASE_STATION.LOCATION_AREA_ID%TYPE,
  p_base_station_code       IN  BASE_STATION.BASE_STATION_CODE%TYPE,
  p_base_station_name       IN  BASE_STATION.BASE_STATION_NAME%TYPE,
  p_user_id_of_change       IN  NUMBER,
  p_parent_base_station_id  IN  base_station.parent_base_station_id%TYPE,
  p_radius                  IN  base_station.radius%TYPE,
  p_longtitude              IN  base_station.longitude%TYPE,
  p_latitude                IN  base_station.latitude%TYPE,
  p_address_id              IN  base_station_address_history.address_id%TYPE
);

/****************************************************************************
  <header>
    <name>              procedure Update_Base_Station
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.2.4   14.03.2007   Roger Stockley
                        Parameters p_zone_id, p_zone_type deleted.
                        No longer inserts into table zone_base_station
    </version>
    <version>           1.2.3   12.03.2007   Roger Stockley
                        parameter zone_type_id added
    </version>
    <version>           1.2.2   03.08.2006   Petr Cepek
                        inserting relation to zone changed
    </version>
    <version>           1.2.1   10.04.2005   Petr Cepek
                        error messages fixed
    </version>
    <version>           1.2.0   05.01.2005   Petr Cepek
                        new columns added(PARENT_BASE_STATION_ID,RADIUS,LONGITUDE,LATITUDE)
                        filling of table base_station_address_history added
    </version>
    <version>           1.1.0   8.4.2004     Jaroslav Holub
                                changed for undelete
    </version>
    <version>           1.0.2   30.3.2004     Sergei Korotkevich
                                added code for updating link between Zone and Basestation
    </version>
    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure updates values of base station given by base
                        station code, if given base station is currently not
                        deleted.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_ORA_DELETED
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code            - Error code
                        p_base_station_id     - ID of base-station to change
						p_base_station_code   - Code of base station - this column not updated
                        p_location_area_id  -  ID of location area
                        p_base_station_name   - name of base station
                        p_zone_code           - Code of zone
                        p_user_id_of_change   - User id of change
    </Parameters>

  </header>
/****************************************************************************/

PROCEDURE Update_Base_Station(
  handle_tran               IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT NUMBER,
  p_base_station_id         IN  BASE_STATION.BASE_STATION_ID%TYPE,
  p_base_station_code       IN  BASE_STATION.BASE_STATION_CODE%TYPE,
  p_location_area_id        IN  BASE_STATION.LOCATION_AREA_ID%TYPE,
  p_base_station_name       IN  BASE_STATION.BASE_STATION_NAME%TYPE,
  p_user_id_of_change       IN  NUMBER,
  p_parent_base_station_id  IN  base_station.parent_base_station_id%TYPE,
  p_radius                  IN  base_station.radius%TYPE,
  p_longtitude              IN  base_station.longitude%TYPE,
  p_latitude                IN  base_station.latitude%TYPE,
  p_address_id              IN  base_station_address_history.address_id%TYPE
);

/****************************************************************************
  <header>
    <name>              procedure Delete_Base_Station
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.1.3    28.08.2006   Petr Cepek
                        condition added: base station can not be deleted when
                        has some sector
    </version>
	  <version>			      1.1.2	  3.8.2004     Jaroslav Holub
								        fixed for time difference between client and server,
								        p_deleted should be null and it means sysdate
	  </version>
  	<version>          	1.1.1   13.4.2004     Pavel Stengl
                                add delete dependet on rows in ZONE_BASE_STATION table
  	</version>
    <version>           1.1.0   8.4.2004     Jaroslav Holub
                                changed for undelete
    </version>
    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure sets column DELETED to value of parameter
                        deleted in base station given by base station code,
                        if given base station is currently not deleted.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_ORA_DELETED
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code          - Error code
                        p_base_station_id - ID of base station
                        p_deleted		        - value for set attribute (DELETED)
                        p_user_id_of_change - User id of change
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Delete_Base_Station(
    handle_tran          IN    CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code           OUT   NUMBER,
    p_base_station_id    IN    BASE_STATION.BASE_STATION_ID%TYPE,
    p_deleted            IN    BASE_STATION.DELETED%TYPE,
    p_user_id_of_change  IN    NUMBER
  );


/****************************************************************************
  <header>
    <name>              procedure Get_Base_Station_All
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.2.3   12.03.2007   Roger Stockley
                        cursor table now does not return information about zone.
    </version>
    <version>           1.2.1   22.02.2007     Petr Cepek
                        procedure fixed to work on Oracle 10g
    </version>
  	<version>           1.2.0   16.12.2005     Cepek Petr
                        procedure rewriten
    </version>
	<version>             1.1.0   8.4.2004     Jaroslav Holub
                        changed for undelete
    </version>
	<version>             1.0.2   31.3.2003     Pavel Stengl
                        statement for ref. cursor modified
    </version>
    <version>           1.0.1   3.2.2003     Pavel Stengl
                        created first version
    </version>

    <Description>       procedure for get all base stations for given network operator or mobile switching centre or location area
                        Procedure for get all base stations for given network operator or mobile switching centre or location area.
                        Input parameters are optional, the contents of output ref cursor depends on input parameter:
                        1.	If input parameter is p_exchange_id not null
                            then ref cursor contains records of table base station subordinated of table exchange
                        2.	If input parameter is p_network_operator_id not null
                            then ref cursor contains records of table base station subordinated of table network operator
                        3.	If input parameter is p_location_area_code not null
                            then ref cursor contains records of table base station subordinated of table location area
                        If entered more input parameters then ref cursor contains record fulfil requirement of each input parameter.
                        Ref cursor contains columns: BASE_STATION_CODE, BASE_STATION_NAME, LOCATION_AREA_CODE, ZONE_CODE,
																	 									 DATE_OF_CHANGE, USER_ID_OF_CHANGE, DELETED.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code            - Error code
                        p_host_id             - Host id
                        p_network_operator_id - Network operator id
                        p_location_area_id    - Code of location area
                        p_cur_base_station    - cursor to retrieve all base stations
                                                (BASE_STATION_CODE, BASE_STATION_NAME, LOCATION_AREA_CODE,
																								 ZONE_CODE, DATE_OF_CHANGE, USER_ID_OF_CHANGE, DELETED)
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Get_Base_Station_All(
    error_code            OUT  NUMBER,
    p_host_id             IN   EXCHANGE.HOST_ID%TYPE,
    p_network_operator_id IN   NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
    p_location_area_id    IN   LOCATION_AREA.LOCATION_AREA_ID%TYPE,
    p_cur_base_station    OUT  RSIG_UTILS.REF_CURSOR
  );

/****************************************************************************
<header>
  <name>            procedure Insert_BS_Address_Interval
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  3.1.2006 12:59:54  -  created
  </version>

  <Description>
                    Procedure terminates previous interval and
                    insert new interval into the table base_station_address_history
                    with appropriate address_id and base_station_id. If p_address_id is null then only
                    previous interval is terminated.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Insert_BS_Address_Interval(
  p_base_station_id     IN  base_station_address_history.base_station_id%TYPE,
  p_address_id          IN  base_station_address_history.address_id%TYPE,
  p_start_date          IN  DATE,
  p_user_id_of_change   IN  NUMBER,
  handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	        IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code            OUT NUMBER,
  error_message	        OUT VARCHAR2
);

/****************************************************************************
<header>
  <name>            procedure Remove_BS_Address_Interval
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  5.1.2006   -  created
  </version>

  <Description>
                    Procedure remove last interval in the table base_station_address_history
                    and open previous interval for appropriate base_station_id. If only one
                    interval for appropriate base_station_id exists then is only removed.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Remove_BS_Address_Interval(
  p_base_station_id     IN  base_station_address_history.base_station_id%TYPE,
  p_user_id_of_change   IN  NUMBER,
  handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	        IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code            OUT NUMBER,
  error_message	        OUT VARCHAR2
);

/****************************************************************************
<header>
  <name>            procedure Get_Address_Id_History_by_BS
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  5.1.2006   -  created
  </version>

  <Description>
                    Procedure returns recordset with address history of
                    given base station specified by parameter p_base_station_id;
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Address_Id_History_by_BS(
  p_base_station_id     IN  base_station.base_station_id%TYPE,
  p_raise_error	        IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code            OUT NUMBER,
  error_message         OUT VARCHAR2,
  result_list           OUT sys_refcursor
);


/****************************************************************************
<header>
  <name>            procedure get_base_station_zone_history
  </name>

  <author>          Roger Stockley
  </author>

  <version>         1.0.1   27.7.2007     Roger Stockley
                    changed to search using BSC_ID instead of BSC_Code
  </version>
  <version>
                    1.0.0  08.03.2007  -  created
  </version>

  <Description>     Procedure to select zone history of given BSC.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Base_Station_Zone_History(
  p_bsc_id                 IN  base_station.base_station_id%TYPE,
  p_start_date             IN  DATE,
  p_end_date               IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

/****************************************************************************
  PROCEDURE

  %author            Roger Stockley
  %created           08.08.2007
  %version           1.0.0
  %application       Resource Inventory - Client

  %usage             Procedure returns base stations for the given network operator.

  %param             p_raise_error   IN   CHAR - (Y/N) - raise error
  %param             p_error_code    OUT  NUMBER - error code
  %param             p_error_message OUT  VARCHAR2 - error message

  %expected_error_codes
  0 - successful completion
*/
/* {%skip}

  %version_log

****************************************************************************/
PROCEDURE Get_Base_Station_By_NetOp(
  p_network_operator_id IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_location_area_id    IN  LOCATION_AREA.LOCATION_AREA_ID%TYPE,
  p_cur_base_station    OUT RSIG_UTILS.REF_CURSOR,
  p_raise_error         IN CHAR,
  p_ERROR_CODE          OUT NUMBER,
  p_error_message       OUT VARCHAR2
  );
  
  /****************************************************************************
  <header>
    <name>              procedure Insert_Base_Station2
    </name>

    <author>            Pavel Vasiliev
    </author>
    <version>           1.0.1   17.11.2010     Pavel Vasiliev
                                created first version
    </version>

    <Description>       Procedure inserts information about base station.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code            - Error code
                        p_location_area_code  - Code of location area
                        p_base_station_code   - Code of base station
                        p_base_station_name   - name of base station
                        p_zone_code           - Code of zone
                        p_user_id_of_change   - User id of change
    </Parameters>

  </header>
/****************************************************************************/
  PROCEDURE Insert_Base_Station2(
  handle_tran               IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT NUMBER,
  p_location_area_id        IN  BASE_STATION.LOCATION_AREA_ID%TYPE,
  p_base_station_code       IN  BASE_STATION.BASE_STATION_CODE%TYPE,
  p_base_station_name       IN  BASE_STATION.BASE_STATION_NAME%TYPE,
  p_user_id_of_change       IN  NUMBER,
  p_parent_base_station_id  IN  base_station.parent_base_station_id%TYPE,
  p_radius                  IN  base_station.radius%TYPE,
  p_longtitude              IN  base_station.longitude%TYPE,
  p_latitude                IN  base_station.latitude%TYPE,
  p_address_id              IN  base_station_address_history.address_id%TYPE,
  p_location_numbers        IN  common.t_varchar2_10
  );
  
  

/****************************************************************************
  <header>
    <name>              procedure Update_Base_Station2
    </name>

    <author>            Pavel Vasiliev
    </author>
    <version>           1.0.1   17.11.2010     Pavel Vasiliev
                                created first version
    </version>

    <Description>       Procedure updates values of base station given by base
                        station code, if given base station is currently not
                        deleted.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_ORA_DELETED
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code            - Error code
                        p_base_station_id     - ID of base-station to change
						p_base_station_code   - Code of base station - this column not updated
                        p_location_area_id  -  ID of location area
                        p_base_station_name   - name of base station
                        p_zone_code           - Code of zone
                        p_user_id_of_change   - User id of change
    </Parameters>

  </header>
/****************************************************************************/
  PROCEDURE Update_Base_Station2(
  handle_tran               IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT NUMBER,
  p_base_station_id         IN  BASE_STATION.BASE_STATION_ID%TYPE,
  p_base_station_code       IN  BASE_STATION.BASE_STATION_CODE%TYPE,
  p_location_area_id        IN  BASE_STATION.LOCATION_AREA_ID%TYPE,
  p_base_station_name       IN  BASE_STATION.BASE_STATION_NAME%TYPE,
  p_user_id_of_change       IN  NUMBER,
  p_parent_base_station_id  IN  base_station.parent_base_station_id%TYPE,
  p_radius                  IN  base_station.radius%TYPE,
  p_longtitude              IN  base_station.longitude%TYPE,
  p_latitude                IN  base_station.latitude%TYPE,
  p_address_id              IN  base_station_address_history.address_id%TYPE,
  p_location_numbers        IN  common.t_varchar2_10
  );
  
  /****************************************************************************
  <header>
    <name>              procedure Get_LocNo
    </name>

    <author>            Pavel Vasiliev
    </author>
    <version>           1.0.1   17.11.2010     Pavel Vasiliev
                                created first version
    </version>

    <Description>       Procedure return LocNo for given base_station_id.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_ORA_DELETED
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        
                        error_code            - Error code
                        p_base_station_id     - ID of base-station to change
    </Parameters>

  </header>
/****************************************************************************/
  PROCEDURE Get_LocNo(
  p_base_station_id         IN  BASE_STATION.BASE_STATION_ID%TYPE,
  p_location_numbers        OUT SYS_REFCURSOR,
  p_raise_error             IN CHAR,
  p_error_code              OUT NUMBER,
  p_error_message           OUT VARCHAR2
  );

END RSIG_BASE_STATION;

/
