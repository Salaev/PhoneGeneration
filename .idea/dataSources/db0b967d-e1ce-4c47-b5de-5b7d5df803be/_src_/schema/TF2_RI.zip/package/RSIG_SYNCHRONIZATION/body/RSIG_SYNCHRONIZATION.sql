CREATE PACKAGE BODY RSIG_SYNCHRONIZATION IS

----------------------------------!---------------------------------------------
  procedure get_synchronization_packet_all
  (
    p_synchronization_sn in number,
    p_network_operator_id network_operator.network_operator_id%type,
    p_synchronization_type synchronization_history.synchronization_type%type,
    p_include_child synchronization_history.including_child%type,
    p_request_date synchronization_history.request_date%type,
    handle_tran char,
    p_raise_error char,
    p_synchronization_date out synchronization_history.request_date%type,
    error_code out number,
    error_message out varchar2,
    p_use_temporary_tab_result boolean := false
  )
  IS
    v_module varchar2(63) := 'RSIG_SYNCHRONIZATION.GET_SYNCHRONIZATION_PACKET_ALL';
    --v_delete_temp CHAR(1);
    --pom_cur                sys_refcursor;
    --    v_last_synch           DATE;
    --    v_synchronization_date DATE;
    v_sysdate DATE;
    v_sqlcode NUMBER;
    v_network_operator_id TABLE_OF_NUMBER;
  BEGIN
    RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_start,
                         RSIG_UTILS.c_debug_level_1,
                         RSIG_UTILS.c_debug_event_type_d,
                         v_module);

    IF handle_tran = RSIG_UTILS.c_handle_tran_s THEN
      SAVEPOINT GET_SYNCHRONIZATION_PACKET_ALL;
    END IF;
    v_sysdate              := SYSDATE;
    p_synchronization_date := nvl(p_request_date, v_sysdate);

    -- loop for all net.ops and all its children
    SELECT NETWORK_OPERATOR_ID
      BULK COLLECT INTO v_network_operator_id
      FROM NETWORK_OPERATOR z
      WHERE 1 = 1
      AND (LEVEL = 1 OR upper(p_include_child) = RSIG_UTILS.c_YES)
      AND DELETED IS NULL
    START WITH NETWORK_OPERATOR_ID = p_network_operator_id
    CONNECT BY PRIOR NETWORK_OPERATOR_ID = NETWORK_OPERATOR_ID_UPPER
    ;

    get_synchronization_packet_int(
                                 p_synchronization_sn   => p_synchronization_sn,
                                 p_network_operator_id => v_network_operator_id,
                                 p_synchronization_type => p_synchronization_type,
                                 p_synchronization_date => nvl(p_request_date, v_sysdate),
                                 p_delete_temp          => RSIG_UTILS.c_YES,
                                 handle_tran            => RSIG_UTILS.c_HANDLE_TRAN_N,
                                 p_raise_error          => RSIG_UTILS.c_YES,
                                 ERROR_CODE             => ERROR_CODE,
                                 error_message          => error_message,
                                 p_use_temporary_tab_result => p_use_temporary_tab_result);

    IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
      COMMIT;
    END IF;
    RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_end,
                         RSIG_UTILS.c_debug_level_1,
                         RSIG_UTILS.c_debug_event_type_d,
                         v_module);

  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      --error_message := SQLERRM;
      error_message := SQLERRM || '|' || dbms_utility.format_error_backtrace;
      --      dbms_output.put_line(error_message);
      ERROR_CODE := RSIG_UTILS.handle_error(v_sqlcode);
      RSIG_UTILS.debug_rsi(to_char(ERROR_CODE) || '|' || error_message,
                           RSIG_UTILS.c_debug_level_0,
                           RSIG_UTILS.c_debug_event_type_er,
                           v_module);

      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT GET_SYNCHRONIZATION_PACKET_ALL;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
      IF upper(p_raise_error) = RSIG_UTILS.c_YES THEN
        RAISE;
      END IF;
  END;

----------------------------------!---------------------------------------------
  PROCEDURE SET_SYNCHRONIZATION_REQUEST
  (
    p_synchronization_sn   IN NUMBER,
    p_network_operator_id  IN NUMBER,
    p_synchronization_type IN CHAR,
    p_including_child      IN VARCHAR2,
    p_status               IN NUMBER,
    handle_tran            IN CHAR,
    p_raise_error          IN CHAR,
    ERROR_CODE             OUT NUMBER,
    error_message          OUT VARCHAR2
  )
  IS
    v_sqlcode NUMBER;
    v_sysdate DATE;
    v_cnt number;
  BEGIN
    RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_start,
                         RSIG_UTILS.c_debug_level_1,
                         RSIG_UTILS.c_debug_event_type_d,
                         'set_synchronization_request');
    -- check handle_tran parameter
    IF (upper(handle_tran) NOT IN
       (RSIG_UTILS.c_handle_tran_s, RSIG_UTILS.c_handle_tran_y, RSIG_UTILS.c_handle_tran_n) OR
       (handle_tran IS NULL)) THEN
      raise_application_error(RSIG_UTILS.c_ora_invalid_handle, 'invalid handle_tran parameter!');
    END IF;

    /*  if test input parameters then
            raise_application_error(RSIG_UTILS.c_ora_invalid_parameter, 'invalid input parameter');
        end if;
    */
    v_sysdate := SYSDATE;

    select count(1)
      into v_cnt
      from synchronization_history t
      where 1 = 1
      and t.synchronization_sn = p_synchronization_sn
    ;

    if v_cnt > 0
    then
      raise_application_error(util_pkg.c_ora_object_not_unique, util_pkg.c_msg_object_not_unique);
    end if;

    -- set savepoint
    IF (upper(handle_tran) = RSIG_UTILS.c_handle_tran_s) THEN
      SAVEPOINT set_synchronization_request;
    END IF;

    -- procedure body here

    INSERT INTO synchronization_history sh
      (network_operator_id,
       synchronization_type,
       synchronization_sn,
       including_child,
       request_result_code,
       request_date,
       transfer_result_code,
       transfer_date,
       completion_result_code,
       completion_date,
       number_of_synchronized_numbers)
    VALUES
      (p_network_operator_id,
       p_synchronization_type,
       p_synchronization_sn,
       p_including_child,
       p_status,
       v_sysdate,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL);

    -- commit
    IF upper(handle_tran) = RSIG_UTILS.c_handle_tran_y THEN
      COMMIT;
    END IF;

    -- set error code to succesfully completed
    ERROR_CODE := RSIG_UTILS.c_ok;
    RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_end,
                         RSIG_UTILS.c_debug_level_1,
                         RSIG_UTILS.c_debug_event_type_d,
                         'set_synchronization_request');
  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --      dbms_output.put_line(error_message);
      ERROR_CODE := RSIG_UTILS.handle_error(v_sqlcode);
      RSIG_UTILS.debug_rsi(to_char(ERROR_CODE),
                           RSIG_UTILS.c_debug_level_0,
                           RSIG_UTILS.c_debug_event_type_er,
                           'set_synchronization_request');
      CASE handle_tran
        WHEN RSIG_UTILS.c_handle_tran_s THEN
          ROLLBACK TO SAVEPOINT set_synchronization_request;
        WHEN RSIG_UTILS.c_handle_tran_y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
      IF upper(p_raise_error) = RSIG_UTILS.c_yes THEN
        RAISE;
      END IF;
  END;

----------------------------------!---------------------------------------------
PROCEDURE GET_SYNCHRONIZATION_PACKET_INT
(
  p_synchronization_sn   IN NUMBER,
  p_network_operator_id  IN TABLE_OF_NUMBER,
  p_synchronization_date IN SYNCHRONIZATION_HISTORY.REQUEST_DATE%TYPE,
  p_synchronization_type IN SYNCHRONIZATION_HISTORY.SYNCHRONIZATION_TYPE%TYPE,
  p_delete_temp          IN CHAR DEFAULT 'Y',
  handle_tran            IN CHAR,
  p_raise_error          IN CHAR,
  ERROR_CODE             OUT NUMBER,
  error_message          OUT VARCHAR2,
  p_use_temporary_tab_result in boolean := false
) IS
  v_module varchar2(63) := 'RSIG_SYNCHRONIZATION.GET_SYNCHRONIZATION_PACKET_INT';
  v_sqlcode              NUMBER;
  v_sysdate              DATE;
  v_bef_area             VARCHAR2(15) := NULL;
  v_bef_country          VARCHAR2(15) := NULL;
  v_bef_num              NUMBER := NULL;
  v_bef_int              VARCHAR2(30) := NULL;
  v_act_area             VARCHAR2(15) := NULL;
  v_act_country          VARCHAR2(15) := NULL;
  v_act_num              NUMBER := NULL;
  v_act_int              VARCHAR2(30) := NULL;
  v_start_area           VARCHAR2(15) := NULL;
  v_start_country        VARCHAR2(15) := NULL;
  v_start_int            VARCHAR2(30) := NULL;
  v_bef_action           VARCHAR2(10);
  v_act_action           VARCHAR2(10);
  v_curs                    sys_refcursor;
  v_synchronization_date DATE;
  v_last_synch           DATE;
  --v_last_na_id           NUMBER;
  v_bef_net_op           NUMBER := NULL;
  v_act_net_op           NUMBER := NULL;
  --g_false constant number := 0;
  g_true constant number := 1;
  v_on_inc_sync_big_bang constant varchar2(127) := 'incremental_synchronization_big_bang';
  v_odv_inc_sync_big_bang constant varchar2(255) := '0';
  v_o_inc_sync_big_bang varchar2(255);

function get_option(p_name varchar2, p_default varchar2 := null) return varchar2 is
v_res varchar2(255);
begin
    select /*+ full(z)*/ --need func index lower(db_parameter_name)
        db_parameter_value into v_res from db_parameters z
        where lower(db_parameter_name) = lower(p_name)
    ;
    return v_res;
exception
when others then
    return p_default;
end;
BEGIN
  RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_start,
                       RSIG_UTILS.c_debug_level_1,
                       RSIG_UTILS.c_debug_event_type_d,
                       v_module);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_handle_tran_s, RSIG_UTILS.c_handle_tran_y, RSIG_UTILS.c_handle_tran_n) OR
     (handle_tran IS NULL)) THEN
    raise_application_error(RSIG_UTILS.c_ora_invalid_handle, 'invalid handle_tran parameter!');
  END IF;

  v_sysdate              := SYSDATE;
  v_synchronization_date := nvl(p_synchronization_date, v_sysdate);
  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_handle_tran_s) THEN
    SAVEPOINT get_synchronization_packet_int;
  END IF;

  -- delete temporary table if required
  IF upper(p_delete_temp) = rsig_utils.c_yes and not p_use_temporary_tab_result THEN
    DELETE FROM tmp_synch_phone_numbers t;
  END IF;

  delete from tt_n;

  insert into tt_n(id) select distinct column_value id from table(cast(p_network_operator_id as table_of_number));

  -- full synchronization
  ----------------------------------------------------------------------------------------------

  IF p_synchronization_type = RSIG_UTILS.c_SYNCHRONIZATION_FULL THEN
    ------------------------------
    --preparing intervals of telephone numbers
    OPEN v_curs FOR
      SELECT country_code, area_code, num, international_format, network_operator_id
        FROM (SELECT /*+ ordered use_hash(z, pso, pns, p) full(z) full(pso) full(pns) full(p) parallel(z, 8) parallel(pso, 8) parallel(pns, 8) parallel(p, 8)*/
                     pns.country_code,
                     pns.area_code,
                     to_number(p.international_format) num,
                     p.international_format,
                     z.id network_operator_id
                FROM tt_n z
                JOIN phone_series_operator pso ON pso.network_operator_id = z.id
                JOIN phone_number_series pns ON pns.phone_number_series_id = pso.phone_number_series_id
                JOIN phone_number p ON p.phone_number_series_id = pns.phone_number_series_id
               WHERE 1 = 1
                 AND v_synchronization_date BETWEEN pso.start_date AND nvl(pso.end_date, v_synchronization_date)
                 AND (pns.deleted IS NULL OR pns.deleted > v_synchronization_date)
                 AND NOT EXISTS
               (SELECT /*+ hash_aj full(nash) parallel(nash, 8)*/ 1
                        FROM NETWORK_ADDRESS_STATUS_HISTORY nash
                       WHERE nash.NETWORK_ADDRESS_ID = p.NETWORK_ADDRESS_ID
                         AND v_synchronization_date BETWEEN nash.START_DATE AND nvl(nash.END_DATE, v_synchronization_date)
                         AND trim(nash.NET_ADDRESS_STATUS_CODE) in (util_ri.c_NASH_CODE_OTHER, util_ri.c_NASH_CODE_EXTERNAL))
              union
              SELECT /*+ ordered use_hash(z, po, p, pns) full(z) full(po) full(p) full(pns) parallel(z, 8) parallel(po, 8) parallel(p, 8) parallel(pns, 8)*/
                     pns.country_code,
                     pns.area_code,
                     to_number(p.international_format) num,
                     p.international_format,
                     z.id network_operator_id
                FROM tt_n z
                JOIN phone_operator po ON po.network_operator_id = z.id
                JOIN phone_number p ON p.network_address_id = po.network_address_id
                JOIN phone_number_series pns ON pns.phone_number_series_id = p.phone_number_series_id
               WHERE 1 = 1
                 AND v_synchronization_date BETWEEN po.start_date AND po.end_date
                 AND po.date_to_act >= v_synchronization_date
                 AND po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
                 AND (pns.deleted IS NULL OR pns.deleted > v_synchronization_date)
                 AND NOT EXISTS
               (SELECT /*+ hash_aj full(nash) parallel(nash, 8)*/ 1
                        FROM NETWORK_ADDRESS_STATUS_HISTORY nash
                       WHERE nash.NETWORK_ADDRESS_ID = p.NETWORK_ADDRESS_ID
                         AND v_synchronization_date BETWEEN nash.START_DATE AND nvl(nash.END_DATE, v_synchronization_date)
                         AND trim(nash.NET_ADDRESS_STATUS_CODE) in (util_ri.c_NASH_CODE_OTHER, util_ri.c_NASH_CODE_EXTERNAL))
             )
       ORDER BY network_operator_id, country_code, area_code, international_format;
    ------------------------------
    -- inserting intervals of telephone numbers into temp table
    v_start_int := NULL;
    LOOP
      FETCH v_curs
        INTO v_act_country, v_act_area, v_act_num, v_act_int, v_act_net_op;
      IF v_curs%NOTFOUND
         OR v_start_int IS NULL
         OR v_act_net_op <> v_bef_net_op
         OR v_act_country <> v_bef_country
         OR v_act_area <> v_bef_area
         OR v_act_num <> v_bef_num + 1
         THEN
        IF v_start_int IS NOT NULL THEN
          if (p_use_temporary_tab_result)
          then
            INSERT INTO TT_SYNCH_PHONE_NUMBERS
              (SYNCHRONIZATION_SN,
               COUNTRY_CODE,
               AREA_CODE,
               INTERNATIONAL_FORMAT,
               COUNTRY_CODE_END,
               AREA_CODE_END,
               INT_FORMAT_END,
               ACTION,
               NETWORK_OPERATOR_ID)
            VALUES
              (p_synchronization_sn,
               v_start_country,
               v_start_area,
               v_start_int,
               v_bef_country,
               v_bef_area,
               v_bef_int,
               RSIG_UTILS.c_synchronization_add,
               v_bef_net_op);
          else
            INSERT INTO tmp_synch_phone_numbers
              (SYNCHRONIZATION_SN,
               COUNTRY_CODE,
               AREA_CODE,
               INTERNATIONAL_FORMAT,
               COUNTRY_CODE_END,
               AREA_CODE_END,
               INT_FORMAT_END,
               ACTION,
               NETWORK_OPERATOR_ID)
            VALUES
              (p_synchronization_sn,
               v_start_country,
               v_start_area,
               v_start_int,
               v_bef_country,
               v_bef_area,
               v_bef_int,
               RSIG_UTILS.c_synchronization_add,
               v_bef_net_op);
          end if;
        END IF;
        IF v_curs%NOTFOUND THEN
          EXIT;
        END IF;
        v_start_country := v_act_country;
        v_start_area := v_act_area;
        v_start_int := v_act_int;
      END IF;
      v_bef_country := v_act_country;
      v_bef_area := v_act_area;
      v_bef_num := v_act_num;
      v_bef_int := v_act_int;
      v_bef_net_op := v_act_net_op;
    END LOOP;

    -- incremental synchronization
    ----------------------------------------------------------------------------------------------
  ELSIF p_synchronization_type = RSIG_UTILS.c_synchronization_incremental THEN

    -- check last synchronization
    -- incremental synchronization is possible ONLY for all regions in current RI installation,
    -- and not for particular regions, so it will exist data in table, and for childs could be only full

    SELECT /*+ ordered use_hash(nos, sh) full(sh)*/
      MAX(sh.TRANSFER_DATE)
      INTO v_last_synch
      FROM (SELECT DISTINCT NETWORK_OPERATOR_ID
              FROM NETWORK_OPERATOR z
              WHERE 1 = 1
              AND DELETED IS NULL
             START WITH NETWORK_OPERATOR_ID in (SELECT ID FROM TT_N)
            CONNECT BY PRIOR NETWORK_OPERATOR_ID_UPPER = NETWORK_OPERATOR_ID) nos
      JOIN SYNCHRONIZATION_HISTORY sh ON sh.NETWORK_OPERATOR_ID = nos.network_operator_id
     WHERE sh.COMPLETION_DATE IS NOT NULL
       AND sh.COMPLETION_RESULT_CODE = RSIG_SYNCHRONIZATION.c_SYNCH_UPRS_DONE_OK;

    IF v_last_synch IS NULL THEN
      raise_application_error(RSIG_UTILS.c_ORA_INVALID_PARAMETER,
                              'wrong synchronization type, first must be full!!!');
    END IF;

    IF v_last_synch > p_synchronization_date THEN
      raise_application_error(RSIG_UTILS.c_ORA_INVALID_DATE,
                              'Date of last successfull synchronization greather than date of actual synchronization!');
    END IF;

    DELETE FROM tt_synchronization1;
    DELETE FROM tt_synchronization2;
    DELETE FROM tt_synchronization3;
    DELETE FROM tt_synchronization4;
    DELETE FROM tt_synchronization5;

    v_o_inc_sync_big_bang := nvl(get_option(v_on_inc_sync_big_bang, v_odv_inc_sync_big_bang), v_odv_inc_sync_big_bang);

    --IF (C_USE_BRANCH_IF_LONG_PERIOD = 'Y') AND (v_synchronization_date - v_last_synch > C_MAXIMUM_PERIOD_VALUE)
    IF to_number(v_o_inc_sync_big_bang) = g_true THEN
      ------------------------------
      insert into tt_synchronization3 (id, dt, action)
        select /*+ full(nash) parallel(nash, 8)*/
            nash.network_address_id,
            nash.start_date max_date,
            rsig_utils.c_synchronization_sub ACTION
          from network_address_status_history nash -- kandidati na other billing
          where 1 = 1
          and nash.start_date between v_last_synch and v_synchronization_date
          and nvl(nash.end_date, v_synchronization_date) >= v_synchronization_date
          and trim(nash.net_address_status_code) in (util_ri.c_nash_code_other, util_ri.c_nash_code_external)
        union all
        select /*+ ordered use_hash(nash) full(nash) parallel(nash, 8)*/
            nash.network_address_id,
            nash.end_date max_date,
            rsig_utils.c_synchronization_add ACTION
          from network_address_status_history nash
          where 1 = 1
          and nvl(nash.end_date,to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) between v_last_synch and v_synchronization_date
          and trim(nash.net_address_status_code) in (util_ri.c_nash_code_other, util_ri.c_nash_code_external)
      ;
      ------------------------------
      insert into tt_synchronization4 (id, dt, action, id2)
        select /*+ ordered use_hash(z, pso) full(z) full(pso)*/
            pso.phone_number_series_id,
            pso.start_date max_date,
            rsig_utils.c_synchronization_add ACTION,
            pso.network_operator_id
          from phone_series_operator pso, tt_n z
          where 1 = 1
          and (pso.start_date between v_last_synch and v_synchronization_date /*and  (pso.end_date not between v_last_synch and v_synchronization_date)*/)
          and z.id = pso.network_operator_id
          and nvl(pso.end_date, v_synchronization_date) >= v_synchronization_date
        union all
        select /*+ ordered use_hash(z, pso) full(z) full(pso)*/
            pso.phone_number_series_id,
            pso.end_date max_date,
            rsig_utils.c_synchronization_sub ACTION,
            pso.network_operator_id
          from phone_series_operator pso, tt_n z
          where 1 = 1
          and nvl(pso.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) between v_last_synch and v_synchronization_date
          and z.id = pso.network_operator_id
      ;
      ------------------------------
      insert into tt_synchronization5 (id, dt, action, id2)
        select /*+ ordered use_hash(z, pso) full(z) full(po) parallel(z, 8) parallel(po, 8)*/
            po.network_address_id,
            po.start_date max_date,
            rsig_utils.c_synchronization_add ACTION,
            z.id
          from tt_n z, phone_operator po
          where 1 = 1
          and po.network_operator_id = z.id
          and po.start_date between v_last_synch and v_synchronization_date
          and po.end_date >= v_synchronization_date
          and po.date_to_act >= v_synchronization_date
          and po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
        union all
        select /*+ ordered use_hash(z, pso) full(z) full(po) parallel(z, 8) parallel(po, 8)*/
            po.network_address_id,
            po.end_date max_date,
            rsig_utils.c_synchronization_sub ACTION,
            z.id
          from tt_n z, phone_operator po
          where 1 = 1
          and po.network_operator_id = z.id
          and po.end_date between v_last_synch and v_synchronization_date
          and po.date_to_act >= v_last_synch
          and po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
      ;
      ------------------------------
      insert into tt_synchronization2 (id, dt, action, id2, code)
        select /*+ ordered use_hash(n, pn, pso, po, z) full(n) full(pn) full(pso) full(po) full(z) parallel(n, 8) parallel(pn, 8) parallel(pso, 8) parallel(po, 8) parallel(z, 8)*/
            n.id,
            n.dt,
            n.action,
            z.id,
            pn.international_format
          from tt_synchronization3 n, phone_number pn, phone_series_operator pso, phone_operator po, tt_n z
          where 1 = 1
          and pn.network_address_id = n.id
          and pso.phone_number_series_id = pn.phone_number_series_id
          and n.dt between pso.start_date and nvl(pso.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
          and po.network_address_id(+) = n.id
          and n.dt between po.start_date(+) and po.end_date(+)
          and po.date_to_act(+) >= n.dt
          and po.type(+) in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
          and z.id = nvl(po.network_operator_id, pso.network_operator_id)
      ;
      ------------------------------
      insert into tt_synchronization2 (id, dt, action, id2, code)
        select /*+ ordered use_hash(t po z nash) full(t) full(po)  full(z) full(nash) parallel(t, 8) parallel(po, 8) parallel(z, 8) parallel(nash, 8)*/
            t.network_address_id,
            t.dt,
            t.action,
            z.id,
            t.international_format
        from (select /*+ ordered use_hash(n, pn) full(n) full(pn)  full(po) parallel(n, 8) parallel(pn, 8)*/
                  pn.network_address_id,
                  n.dt,
                  n.action,
                  n.id2,
                  pn.international_format
                from tt_synchronization4 n, phone_number pn
                where 1 = 1
                and pn.phone_number_series_id = n.id
                ) t, phone_operator po, tt_n z, network_address_status_history nash
          where 1 = 1
          and po.network_address_id(+) = t.network_address_id
          and t.dt between po.start_date(+) and po.end_date(+)
          and po.date_to_act(+) >= t.dt
          and po.type(+) in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
          and z.id = nvl(po.network_operator_id, t.id2)
          and nash.network_address_id = t.network_address_id
          and t.dt between nash.start_date and nvl(nash.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
          and trim(nash.net_address_status_code) not in (util_ri.c_nash_code_other, util_ri.c_nash_code_external)
      ;
      ------------------------------
      insert into tt_synchronization2 (id, dt, action, id2, code)
        select /*+ ordered use_hash(n, pn, nash) full(n) full(pn) full(nash) parallel(n, 8) parallel(pn, 8) parallel(nash, 8)*/
            n.id,
            n.dt,
            n.action,
            n.id2,
            pn.international_format
          from tt_synchronization5 n, phone_number pn, network_address_status_history nash
          where 1 = 1
          and pn.network_address_id = n.id
          and nash.network_address_id = n.id
          and n.dt between nash.start_date and nvl(nash.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
          and trim(nash.net_address_status_code) not in (util_ri.c_nash_code_other, util_ri.c_nash_code_external)
      ;
      ------------------------------
    ELSE
      ------------------------------
      insert into tt_synchronization3 (id, dt, action)
        select /*+ index_asc(nash, PK_NETWORK_ADDRESS_STATUS_HIST)*/
            nash.network_address_id,
            nash.start_date max_date,
            rsig_utils.c_synchronization_sub ACTION
          from network_address_status_history nash
          where 1 = 1
          and nash.start_date between v_last_synch and v_synchronization_date
          and nvl(nash.end_date, v_synchronization_date) >= v_synchronization_date
          and trim(nash.net_address_status_code) in (util_ri.c_nash_code_other, util_ri.c_nash_code_external)
        union all
        select /*+ index_asc(nash, I_NASH_DATE_TO)*/
            nash.network_address_id,
            nash.end_date max_date,
            rsig_utils.c_synchronization_add ACTION
          from network_address_status_history nash
          where 1 = 1
          and nvl(nash.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) between v_last_synch and v_synchronization_date
          and trim(nash.net_address_status_code) in (util_ri.c_nash_code_other, util_ri.c_nash_code_external)
      ;
      ------------------------------
      insert into tt_synchronization4 (id, dt, action, id2)
        select /*+ ordered use_hash(z, pso) full(z) full(pso)*/
            pso.phone_number_series_id,
            pso.start_date max_date,
            rsig_utils.c_synchronization_add ACTION,
            pso.network_operator_id
          from phone_series_operator pso, tt_n z
          where 1 = 1
          and (pso.start_date between v_last_synch and v_synchronization_date /*and  (pso.end_date not between v_last_synch and v_synchronization_date)*/)
          and z.id = pso.network_operator_id
          and nvl(pso.end_date, v_synchronization_date) >= v_synchronization_date
        union all
        select /*+ ordered use_hash(z, pso) full(z) full(pso)*/
            pso.phone_number_series_id,
            pso.end_date max_date,
            rsig_utils.c_synchronization_sub ACTION,
            pso.network_operator_id
          from phone_series_operator pso, tt_n z
          where 1 = 1
          and nvl(pso.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) between v_last_synch and v_synchronization_date
          and z.id = pso.network_operator_id
      ;
      ------------------------------
      insert into tt_synchronization5 (id, dt, action, id2)
        select /*+ ordered use_nl(z, pso) full(z) index(po I_PHONE_OPERATOR_NOID)*/
            po.network_address_id,
            po.start_date max_date,
            rsig_utils.c_synchronization_add ACTION,
            z.id
          from tt_n z, phone_operator po
          where 1 = 1
          and po.network_operator_id = z.id
          and po.start_date between v_last_synch and v_synchronization_date
          and po.end_date >= v_synchronization_date
          and po.date_to_act >= v_synchronization_date
          and po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
        union all
        select /*+ ordered use_nl(z, pso) full(z) index(po I_PHONE_OPERATOR_NOID)*/
            po.network_address_id,
            po.end_date max_date,
            rsig_utils.c_synchronization_sub ACTION,
            z.id
          from tt_n z, phone_operator po
          where 1 = 1
          and po.network_operator_id = z.id
          and po.end_date between v_last_synch and v_synchronization_date
          and po.date_to_act >= v_last_synch
          and po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
      ;
      ------------------------------
      insert into tt_synchronization2 (id, dt, action, id2, code)
        select /*+ ordered use_nl(n, pn, pso, po) use_hash(z) full(n) index_asc(pn, PK_PHONE_NUMBER) index(pso I_PSO_PNS) index(po I_PHONE_OPERATOR_NAID) full(z)*/
            n.id,
            n.dt,
            n.action,
            z.id,
            pn.international_format
          from tt_synchronization3 n, phone_number pn, phone_series_operator pso, phone_operator po, tt_n z
          where 1 = 1
          and pn.network_address_id = n.id
          and pso.phone_number_series_id = pn.phone_number_series_id
          and n.dt between pso.start_date and nvl(pso.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
          and po.network_address_id(+) = n.id
          and n.dt between po.start_date(+) and po.end_date(+)
          and po.date_to_act(+) >= n.dt
          and po.type(+) in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
          and z.id = nvl(po.network_operator_id, pso.network_operator_id)
      ;
      ------------------------------
      insert into tt_synchronization2 (id, dt, action, id2, code)
        select /*+ ordered use_nl(t po nash) use_hash(z) full(t) index(po I_PHONE_OPERATOR_NAID) full(z) index(nash I_NETADSTAHI_NETWORK_ADDRES_I2)*/
            t.network_address_id,
            t.dt,
            t.action,
            z.id,
            t.international_format
        from (select /*+ ordered use_nl(n, pn) full(n) index_asc(pn, I_PHONENUM_PHONE_NUM_SERIES_ID)  index(po I_PHONE_OPERATOR_NAID)*/
                  pn.network_address_id,
                  n.dt,
                  n.action,
                  n.id2,
                  pn.international_format
                from tt_synchronization4 n, phone_number pn
                where 1 = 1
                and pn.phone_number_series_id = n.id
                ) t, phone_operator po, tt_n z, network_address_status_history nash
          where 1 = 1
          and po.network_address_id(+) = t.network_address_id
          and t.dt between po.start_date(+) and po.end_date(+)
          and po.date_to_act(+) >= t.dt
          and po.type(+) in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
          and z.id = nvl(po.network_operator_id, t.id2)
          and nash.network_address_id = t.network_address_id
          and t.dt between nash.start_date and nvl(nash.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
          and trim(nash.net_address_status_code) not in (util_ri.c_nash_code_other, util_ri.c_nash_code_external)
      ;
      ------------------------------
      insert into tt_synchronization2 (id, dt, action, id2, code)
        select /*+ ordered use_nl(n, pn, nash) full(n) index_asc(pn, PK_PHONE_NUMBER) index(nash I_NETADSTAHI_NETWORK_ADDRES_I2)*/
            n.id,
            n.dt,
            n.action,
            n.id2,
            pn.international_format
          from tt_synchronization5 n, phone_number pn, network_address_status_history nash
          where 1 = 1
          and pn.network_address_id = n.id
          and nash.network_address_id = n.id
          and n.dt between nash.start_date and nvl(nash.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
          and trim(nash.net_address_status_code) not in (util_ri.c_nash_code_other, util_ri.c_nash_code_external)
      ;
      ------------------------------
    END IF;
    ------------------------------
    insert into tt_synchronization1 (id, dt, action, id2, code)
select id, max(dt) dt, max(action) action, max(id2) id2, max(code) code
    from (
select id, dt, action, id2, code, max(dt) over(partition by id) aaa
    from tt_synchronization2
    )
    where 1 = 1
    and aaa = dt
    group by id
    ;
    ------------------------------
    OPEN v_curs FOR
select to_number(code) num, code, action, id2
    from tt_synchronization1 z
    order by id2, code
    ;
    ------------------------------
    -- inserting intervals of telephone numbers into temp table
    v_start_int := NULL;
    LOOP
      FETCH v_curs
        INTO v_act_num, v_act_int, v_act_action, v_act_net_op;
      IF v_curs%NOTFOUND
         OR v_start_int IS NULL
         OR v_act_action <> v_bef_action
         OR v_act_net_op <> v_bef_net_op
         OR v_act_num <> v_bef_num + 1
         THEN
        IF v_start_int IS NOT NULL THEN
          if (p_use_temporary_tab_result)
          then
            INSERT INTO TT_SYNCH_PHONE_NUMBERS
              (SYNCHRONIZATION_SN,
               INTERNATIONAL_FORMAT,
               INT_FORMAT_END,
               ACTION,
               NETWORK_OPERATOR_ID)
            VALUES
              (p_synchronization_sn,
               v_start_int,
               v_bef_int,
               v_bef_action,
               v_bef_net_op);
          else
            INSERT INTO TMP_SYNCH_PHONE_NUMBERS
              (SYNCHRONIZATION_SN,
               INTERNATIONAL_FORMAT,
               INT_FORMAT_END,
               ACTION,
               NETWORK_OPERATOR_ID)
            VALUES
              (p_synchronization_sn,
               v_start_int,
               v_bef_int,
               v_bef_action,
               v_bef_net_op);
          end if;
        END IF;
        IF v_curs%NOTFOUND THEN
          EXIT;
        END IF;
        v_start_int := v_act_int;
      END IF;
      v_bef_num := v_act_num;
      v_bef_int := v_act_int;
      v_bef_action := v_act_action;
      v_bef_net_op := v_act_net_op;
    END LOOP;

  END IF; -- incremental synchronization
  ----------------------------------------------------------------------------------------------

  IF v_curs%ISOPEN THEN
    CLOSE v_curs;
  END IF;

  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_ok;
  RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_end,
                       RSIG_UTILS.c_debug_level_1,
                       RSIG_UTILS.c_debug_event_type_d,
                       v_module);

EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    --error_message := SQLERRM;
    error_message := SQLERRM || '|' || dbms_utility.format_error_backtrace;
    --      dbms_output.put_line(error_message);
    ERROR_CODE := RSIG_UTILS.handle_error(v_sqlcode);
    RSIG_UTILS.debug_rsi(to_char(ERROR_CODE) || '|' || error_message,
                         RSIG_UTILS.c_debug_level_0,
                         RSIG_UTILS.c_debug_event_type_er,
                         v_module);
    CASE handle_tran
      WHEN RSIG_UTILS.c_handle_tran_s THEN
        ROLLBACK TO SAVEPOINT get_synchronization_packet_int;
      WHEN RSIG_UTILS.c_handle_tran_y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF upper(p_raise_error) = RSIG_UTILS.c_yes THEN
      RAISE;
    END IF;
END;

----------------------------------!---------------------------------------------
  PROCEDURE SET_SYNCHRONIZATION_STATUS
  (
    p_synchronization_sn IN SYNCHRONIZATION_HISTORY.SYNCHRONIZATION_SN%TYPE,
    p_type               IN CHAR,
    p_result_code        IN SYNCHRONIZATION_HISTORY.REQUEST_RESULT_CODE%TYPE,
    p_result_date        IN SYNCHRONIZATION_HISTORY.REQUEST_DATE%TYPE,
    handle_tran          IN CHAR,
    p_raise_error        IN CHAR,
    ERROR_CODE           OUT NUMBER,
    error_message        OUT VARCHAR2
  ) IS
    v_sqlcode NUMBER;
  BEGIN
    RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_start,
                         RSIG_UTILS.c_debug_level_1,
                         RSIG_UTILS.c_debug_event_type_d,
                         'set_synchronization_status');
    -- check handle_tran parameter
    IF (upper(handle_tran) NOT IN
       (RSIG_UTILS.c_handle_tran_s, RSIG_UTILS.c_handle_tran_y, RSIG_UTILS.c_handle_tran_n) OR
       (handle_tran IS NULL)) THEN
      raise_application_error(RSIG_UTILS.c_ora_invalid_handle, 'invalid handle_tran parameter!');
    END IF;

    /*  if test input parameters then
            raise_application_error(RSIG_UTILS.c_ora_invalid_parameter, 'invalid input parameter');
        end if;
    */

    -- set savepoint
    IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
      SAVEPOINT set_synchronization_status;
    END IF;

    -- procedure body here

    IF p_type = C_SYNCH_STATUS_TYPE_TRANSFER THEN
      UPDATE SYNCHRONIZATION_HISTORY sh
         SET sh.TRANSFER_RESULT_CODE = nvl(p_result_code, sh.TRANSFER_RESULT_CODE),
             sh.TRANSFER_DATE        = nvl(p_result_date, SYSDATE)
       WHERE sh.SYNCHRONIZATION_SN = p_synchronization_sn;
    ELSIF p_type = C_SYNCH_STATUS_TYPE_COMPLETION THEN
      UPDATE SYNCHRONIZATION_HISTORY sh
         SET sh.COMPLETION_RESULT_CODE = nvl(p_result_code, sh.COMPLETION_RESULT_CODE),
             sh.COMPLETION_DATE        = nvl(p_result_date, SYSDATE)
       WHERE sh.SYNCHRONIZATION_SN = p_synchronization_sn;
    ELSIF p_type = C_SYNCH_STATUS_TYPE_REQUEST THEN
      UPDATE SYNCHRONIZATION_HISTORY sh
         SET sh.REQUEST_RESULT_CODE = p_result_code,
             sh.REQUEST_DATE        = nvl(p_result_date, SYSDATE)
       WHERE sh.SYNCHRONIZATION_SN = p_synchronization_sn;
    ELSE
      raise_application_error(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'invalid input parameter');
    END IF;

    -- commit
    IF upper(handle_tran) = RSIG_UTILS.c_handle_tran_y THEN
      COMMIT;
    END IF;

    -- set error code to succesfully completed
    ERROR_CODE := RSIG_UTILS.c_ok;
    RSIG_UTILS.debug_rsi(RSIG_UTILS.c_debug_text_end,
                         RSIG_UTILS.c_debug_level_1,
                         RSIG_UTILS.c_debug_event_type_d,
                         'set_synchronization_status');
  EXCEPTION
    WHEN OTHERS THEN
      v_sqlcode     := SQLCODE;
      error_message := SQLERRM;
      --      dbms_output.put_line(error_message);
      ERROR_CODE := RSIG_UTILS.handle_error(v_sqlcode);
      RSIG_UTILS.debug_rsi(to_char(ERROR_CODE),
                           RSIG_UTILS.c_debug_level_0,
                           RSIG_UTILS.c_debug_event_type_er,
                           'set_synchronization_status');
      CASE handle_tran
        WHEN RSIG_UTILS.c_handle_tran_s THEN
          ROLLBACK TO SAVEPOINT set_synchronization_status;
        WHEN RSIG_UTILS.c_handle_tran_y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
      IF upper(p_raise_error) = RSIG_UTILS.c_yes THEN
        RAISE;
      END IF;
  END;

----------------------------------!---------------------------------------------
PROCEDURE DELETE_SYNCH_DATA
(
  p_synchronization_sn  IN NUMBER,
  handle_tran   IN CHAR,
  p_raise_error IN CHAR,
  ERROR_CODE    OUT NUMBER,
  error_message OUT VARCHAR2
) IS
  v_sqlcode NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       'DELETE_SYNCH_DATA');
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  IF p_synchronization_sn IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT DELETE_SYNCH_DATA;
  END IF;

  -- procedure body here

     DELETE FROM TMP_SYNCH_PHONE_NUMBERS t
     WHERE t.SYNCHRONIZATION_SN = p_synchronization_sn;

  -- commit

  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       'DELETE_SYNCH_DATA');
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         'DELETE_SYNCH_DATA');
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT DELETE_SYNCH_DATA;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END;

----------------------------------!---------------------------------------------
procedure xcheck_synchronization_param
(
    p_uprs_member_code varchar2,
    p_synchronization_type char,
    p_ro_code out varchar2,
    p_including_child out varchar2
)
is
begin
  -------------------------
  if to_number(p_uprs_member_code) = -1 OR p_uprs_member_code IS NULL
  then
    -------------------------
    p_ro_code := install_pkg.get_option_str(c_setting_def_ro_code, null, c_default_ro_code);
    p_including_child := rsig_utils.c_yes;
    -------------------------
  else
    -------------------------
    p_ro_code := p_uprs_member_code;
    p_including_child := rsig_utils.c_no;
    -------------------------
    if(p_synchronization_type = rsig_utils.c_synchronization_incremental)
    then
      util_pkg.raise_exception(util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter);
    end if;
    -------------------------
  end if;
  -------------------------
end;

----------------------------------!---------------------------------------------
function get_net_op_by_uprs_code(p_uprs_member_code varchar2) return number
is
  v_network_operator_id number;
begin
  -------------------------
  select network_operator_id
    into v_network_operator_id
    from network_operator no
   where no.uprs_member_code = p_uprs_member_code
     and no.network_operator_type is null;
  -------------------------
  return v_network_operator_id;
  -------------------------
end;

----------------------------------!---------------------------------------------
procedure at_set_synchronization_request
(
    p_synchronization_sn number,
    p_uprs_member_code varchar2,
    p_synchronization_type char,
    p_status number
)
is
  pragma autonomous_transaction;
  v_network_operator_id number;
  v_including_child varchar2(3);
  v_uprs_member_code varchar2(15);
  v_error_code number;
  v_error_message varchar2(4000);
begin
  -------------------------
  xcheck_synchronization_param(p_uprs_member_code, p_synchronization_type, v_uprs_member_code, v_including_child);
  -------------------------
  v_network_operator_id := get_net_op_by_uprs_code(v_uprs_member_code);
  -------------------------
  set_synchronization_request(p_synchronization_sn => p_synchronization_sn,
                              p_network_operator_id => v_network_operator_id ,
                              p_synchronization_type => p_synchronization_type,
                              p_including_child => v_including_child,
                              p_status => p_status,
                              handle_tran => rsig_utils.c_handle_tran_n,
                              p_raise_error => rsig_utils.c_yes,
                              error_code => v_error_code,
                              error_message => v_error_message );
  -------------------------
  if (v_error_code <> util_pkg.c_ora_ok)
  then
    util_pkg.raise_exception(util_pkg.c_ora_x_common, util_pkg.c_msg_x_common || util_pkg.c_msg_delim01 || v_error_code || util_pkg.c_msg_delim01 || v_error_message);
  end if;
  -------------------------
  commit;
exception
when others then
  -------------------------
  v_error_code := util_pkg.get_err_code;
  v_error_message := util_pkg.get_err_msg;
  -------------------------
  rollback;
  -------------------------
  util_pkg.raise_exception(util_pkg.c_ora_x_common, util_pkg.c_msg_x_common || util_pkg.c_msg_delim01 || v_error_code || util_pkg.c_msg_delim01 || v_error_message);
  -------------------------
end;

----------------------------------!---------------------------------------------
procedure at_set_synchronization_status
(
    p_synchronization_sn in synchronization_history.synchronization_sn%type,
    p_type               in char,
    p_result_code        in synchronization_history.request_result_code%type,
    p_result_date        in synchronization_history.request_date%type
)
is
  pragma autonomous_transaction;
  v_error_code number;
  v_error_message varchar2(4000);
begin
  -------------------------
  set_synchronization_status(p_synchronization_sn =>p_synchronization_sn,
                             p_type => p_type,
                             p_result_code => p_result_code,
                             p_result_date => p_result_date,
                             handle_tran => rsig_utils.c_handle_tran_n,
                             p_raise_error => rsig_utils.c_yes,
                             error_code => v_error_code,
                             error_message => v_error_message
                            );
  -------------------------
  if (v_error_code <> util_pkg.c_ora_ok)
  then
    util_pkg.raise_exception(util_pkg.c_ora_x_common, util_pkg.c_msg_x_common || util_pkg.c_msg_delim01 || v_error_code || util_pkg.c_msg_delim01 || v_error_message);
  end if;
  -------------------------
  commit;
exception
when others then
  -------------------------
  v_error_code := util_pkg.get_err_code;
  v_error_message := util_pkg.get_err_msg;
  -------------------------
  rollback;
  -------------------------
  util_pkg.raise_exception(util_pkg.c_ora_x_common, util_pkg.c_msg_x_common || util_pkg.c_msg_delim01 || v_error_code || util_pkg.c_msg_delim01 || v_error_message);
  -------------------------
end;

----------------------------------!---------------------------------------------
procedure init_synchronization_request
(
    p_uprs_member_code     in varchar2,
    p_synchronization_type synchronization_history.synchronization_type%type,
    p_synchronization_sn   synchronization_history.synchronization_sn%type
) is
begin
  -------------------------
  -- To create synchronization request at status 11 - "in action"
  -------------------------
  at_set_synchronization_request( p_synchronization_sn => p_synchronization_sn,
                                  p_uprs_member_code => p_uprs_member_code,
                                  p_synchronization_type => p_synchronization_type,
                                  p_status => c_synch_ri_req_in_process);
  -------------------------
  -- To set synchronization status of request at 1 - "success"
  -- In this version intermediate statuses are not necessary. Nothing depends on it. It only "for history"
  -------------------------
  at_set_synchronization_status( p_synchronization_sn => p_synchronization_sn,
                                 p_type => c_synch_status_type_request,
                                 p_result_code => c_synch_ri_req_ok,
                                 p_result_date => sysdate);
  -------------------------
  -- To set synchronization status of request at 12 - "in action"
  -------------------------
  at_set_synchronization_status( p_synchronization_sn => p_synchronization_sn,
                                 p_type => c_synch_status_type_request,
                                 p_result_code => c_synch_uprs_req_in_process,
                                 p_result_date => sysdate);
  -------------------------
end;

----------------------------------!---------------------------------------------
procedure get_synchronization_data_int
(
    p_uprs_member_code     in varchar2,
    p_synchronization_type synchronization_history.synchronization_type%type,
    p_synchronization_sn   synchronization_history.synchronization_sn%type,
    p_synchronization_date synchronization_history.transfer_date%type,
    p_use_temporary_tab_result boolean
)
is
  v_network_operator_id  number;
  v_including_child      varchar2(3);
  v_uprs_member_code     varchar2(15);
  v_synchronization_date date;
  v_error_code number;
  v_error_message varchar2(4000);
begin
  -------------------------
  xcheck_synchronization_param(p_uprs_member_code, p_synchronization_type, v_uprs_member_code, v_including_child);
  -------------------------
  v_network_operator_id := get_net_op_by_uprs_code(v_uprs_member_code);
  -------------------------
  if v_error_code <> 0
  then
    util_pkg.raise_exception(util_pkg.c_ora_x_common, util_pkg.c_msg_x_common || util_pkg.c_msg_delim01 || v_error_code || util_pkg.c_msg_delim01 || v_error_message);
  end if;
  -------------------------
  get_synchronization_packet_all(
                                  p_synchronization_sn => p_synchronization_sn,
                                  p_network_operator_id => v_network_operator_id,
                                  p_synchronization_type => p_synchronization_type,
                                  p_include_child => v_including_child,
                                  p_request_date => p_synchronization_date,
                                  handle_tran => rsig_utils.c_handle_tran_n,
                                  p_raise_error => rsig_utils.c_yes,
                                  p_synchronization_date => v_synchronization_date,
                                  ERROR_CODE => v_error_code,
                                  error_message => v_error_message,
                                  p_use_temporary_tab_result => p_use_temporary_tab_result);
  -------------------------
  if v_error_code <> 0
  then
    util_pkg.raise_exception(util_pkg.c_ora_x_common, util_pkg.c_msg_x_common || util_pkg.c_msg_delim01 || v_error_code || util_pkg.c_msg_delim01 || v_error_message);
  end if;
  -------------------------
end;

----------------------------------!---------------------------------------------
function check_session_alive(p_sid_serial nvarchar2) return number
is
  v_sid number;
  v_serial number;
  v_cnt number;
begin
  -------------------------
  util_ri.varchar2sid_serial(to_char(p_sid_serial), v_sid, v_serial);
  -------------------------
  select count(1)
    into v_cnt
    from v$session
   where sid = v_sid
     and serial# = v_serial
  ;
  -------------------------
  if (v_cnt > 0)
  then
    -------------------------
    return util_pkg.c_true;
    -------------------------
  else
    -------------------------
    return util_pkg.c_false;
    -------------------------
  end if;
  -------------------------
end;

----------------------------------!---------------------------------------------
function lock_synchronization_sn(p_synchronization_sn synchronization_history.synchronization_sn%type) return locker_pkg.t_locker
is
  v_result locker_pkg.t_locker;
  v_locker locker_pkg.t_locker;
  v_locker_data_range locker_pkg.ct_locker_data_range;
  v_sid_serial nvarchar2(50);
begin
  -------------------------
  v_locker := locker_pkg.get_locker_eq
  (
    p_type_id => c_locker_type_synch_sn,
    p_stock_id => p_synchronization_sn
  );
  -------------------------
  --!_!if locker exists check his validity
  if v_locker.locker_group_id is not null
  then
    -------------------------
    --!_!get all locks related with locker_group
    v_locker_data_range := locker_pkg.get_locker_data_sr4group(p_locker_group_id => v_locker.locker_group_id);
    -------------------------
    if locker_pkg.get_count_ct_locker_data_range(v_locker_data_range) > 0
    then
      for v_i in v_locker_data_range.first..v_locker_data_range.last
      loop
        if (check_session_alive(v_locker_data_range(v_i).sn_from) = util_pkg.c_true)
        then
          util_pkg.raise_exception(util_loc_pkg.c_ora_synchronization_executed, util_loc_pkg.c_msg_synchronization_executed);
        end if;
      end loop;
    end if;
    -------------------------
    locker_pkg.release_locker_group(v_locker.locker_group_id);
    -------------------------
  end if;
  -------------------------
  v_result := locker_pkg.xl_latch_type_on_stock2
  (
    p_type_id => c_locker_type_synch_sn,
    p_stock_id => p_synchronization_sn
  );
  -------------------------
  select to_nchar(util_ri.sid_serial2varchar(sid, serial#))
    into v_sid_serial
    from v$session where audsid = userenv('sessionid');
  ------------------------------
  v_result := locker_pkg.xl_latch_range
  (
    p_type_id => c_locker_type_sid,
    p_sn_from => v_sid_serial,
    p_sn_to => v_sid_serial,
    p_locker_group_id => v_result.locker_group_id,
    p_allow_non_digit_sn => true,
    p_allow_input_overlap => true
  );
  -------------------------
  return v_result;
  -------------------------
exception
when others then
  -------------------------
  if v_result.locker_group_id is not null
  then
    locker_pkg.release_locker_group(v_result.locker_group_id);
  end if;
  -------------------------
  raise;
  -------------------------
end;

----------------------------------!---------------------------------------------
procedure get_synchronization_data_2
(
    p_uprs_member_code     in varchar2,
    p_synchronization_type synchronization_history.synchronization_type%type,
    p_synchronization_sn   synchronization_history.synchronization_sn%type,
    p_synchronization_date synchronization_history.transfer_date%type,
    p_handle_tran          char default rsig_utils.c_handle_tran_y,
    p_error_code           out number,
    p_error_message        out varchar2,
    result_list            out sys_refcursor
) is
  v_procedure_name varchar2(200) := 'Get_Synchronization_Data_2';
  v_ascode varchar2(20);
  v_locker locker_pkg.t_locker;
  v_error_code number;
  v_error_message varchar2(4000);
begin
  -------------------------
  Common.Check_Handle_Tran(p_handle_tran, v_procedure_name);
  -------------------------
  v_locker := lock_synchronization_sn(p_synchronization_sn);
  -------------------------
  v_ascode := install_pkg.get_option_str(c_setting_def_ascode, null, c_default_ascode);
  -------------------------
  init_synchronization_request
  (
    p_uprs_member_code => p_uprs_member_code,
    p_synchronization_type => p_synchronization_type,
    p_synchronization_sn => p_synchronization_sn
  );
  -------------------------
  begin
    -------------------------
    delete from tt_synch_phone_numbers;
    -------------------------
    get_synchronization_data_int(p_uprs_member_code, p_synchronization_type, p_synchronization_sn, p_synchronization_date, true);
    -------------------------
    open result_list for
       select international_format startrange,
               int_format_end endrange,
               action editcode,
               no.uprs_member_code serviceprovidercode,
               v_ascode ascode
          from tt_synch_phone_numbers tmp
          join network_operator no on tmp.network_operator_id = no.network_operator_id
         order by international_format;
    -------------------------
    set_synchronization_status(
        p_synchronization_sn => p_synchronization_sn,
        p_type => c_synch_status_type_request,
        p_result_code => c_synch_uprs_req_ok,
        p_result_date => NULL,
        handle_tran => rsig_utils.c_handle_tran_n,
        p_raise_error => rsig_utils.c_yes,
        ERROR_CODE => v_error_code,
        error_message => v_error_message);
    -------------------------
    set_synchronization_status(
        p_synchronization_sn => p_synchronization_sn,
        p_type => c_synch_status_type_transfer,
        p_result_code => c_synch_uprs_tran_in_process,
        p_result_date => NULL,
        handle_tran => rsig_utils.c_handle_tran_n,
        p_raise_error => rsig_utils.c_yes,
        ERROR_CODE => v_error_code,
        error_message => v_error_message);
    -------------------------
  exception
  when others then
    -------------------------
    at_set_synchronization_status( p_synchronization_sn => p_synchronization_sn,
                                   p_type => c_synch_status_type_request,
                                   p_result_code => c_synch_uprs_req_failed,
                                   p_result_date => sysdate);
    -------------------------
  end;
  -------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  -------------------------
  if (p_handle_tran = rsig_utils.c_handle_tran_y)
  then
    commit;
  end if;
  -------------------------
  locker_pkg.release_locker_group(v_locker.locker_group_id);
  -------------------------
exception
when others then
  -------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  -------------------------
  if (p_handle_tran = rsig_utils.c_handle_tran_y)
  then
    rollback;
  end if;
  -------------------------
  if (v_locker.locker_group_id is not null)
  then
    locker_pkg.release_locker_group(v_locker.locker_group_id);
  end if;
  -------------------------
end;

----------------------------------!---------------------------------------------
procedure set_transfer_status_complete
(
    p_synchronization_sn synchronization_history.synchronization_sn%type,
    p_synchronization_date synchronization_history.transfer_date%type,
    p_error_code out number,
    p_error_message out varchar2
) is
  v_locker locker_pkg.t_locker;
  v_error_code number;
  v_error_message varchar2(4000);
begin
  -------------------------
  v_locker := lock_synchronization_sn(p_synchronization_sn);
  -------------------------
  set_synchronization_status(
      p_synchronization_sn => p_synchronization_sn,
      p_type => c_synch_status_type_transfer,
      p_result_code => c_synch_uprs_tran_ok,
      p_result_date => p_synchronization_date,
      handle_tran => rsig_utils.c_handle_tran_n,
      p_raise_error => rsig_utils.c_yes,
      ERROR_CODE => v_error_code,
      error_message => v_error_message);
  -------------------------
  set_synchronization_status(
      p_synchronization_sn => p_synchronization_sn,
      p_type => c_synch_status_type_completion,
      p_result_code => c_synch_uprs_done_in_process,
      p_result_date => p_synchronization_date,
      handle_tran => rsig_utils.c_handle_tran_n,
      p_raise_error => rsig_utils.c_yes,
      ERROR_CODE => v_error_code,
      error_message => v_error_message);
  -------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  -------------------------
  commit;
  -------------------------
  locker_pkg.release_locker_group(v_locker.locker_group_id);
  -------------------------
exception
when others then
  -------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  -------------------------
  rollback;
  -------------------------
  if (v_locker.locker_group_id is not null)
  then
    locker_pkg.release_locker_group(v_locker.locker_group_id);
  end if;
  -------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_pso_changes
(
  p_start_date date,
  p_date date,
  p_ps_ids out ct_number,
  p_ps_start_dates out ct_date
)
is
begin
  ------------------------------
  select phone_number_series_id, start_date
    bulk collect into p_ps_ids, p_ps_start_dates
    from
      (
      select
          phone_number_series_id, start_date, row_number() over ( partition by phone_number_series_id order by start_date desc) rn
        from
        (
          select /*+ index(pso I_PSO_DATE_FROM)*/
              phone_number_series_id, start_date
            from phone_series_operator pso
            where 1 = 1
            and start_date between p_start_date and p_date
          union
          select /*+ index(pso I_PSO_DATE_TO)*/
              phone_number_series_id, start_date
            from phone_series_operator pso
            where 1 = 1
            and nvl(end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) between p_start_date and p_date
        )
      )
    where 1 = 1
    and rn = 1
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_naap_changes
(
  p_start_date date,
  p_date date,
  p_na_ids out ct_number,
  p_na_from_dates out ct_date
)
is
begin
  ------------------------------
  select network_address_id, from_date
    bulk collect into p_na_ids, p_na_from_dates
    from
      (
      select
          network_address_id, from_date, row_number() over ( partition by network_address_id order by from_date desc) rn
        from
        (
          select /*+ index(naap I_NAAP_DATE_FROM)*/
              network_address_id, from_date
            from network_address_access_point naap
            where 1 = 1
            and from_date between p_start_date and p_date
          union
          select /*+ index(naap I_NAAP_DATE_TO)*/
              network_address_id, from_date
            from network_address_access_point naap
            where 1 = 1
            and nvl(to_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) between p_start_date and p_date
        )
      )
    where 1 = 1
    and rn = 1
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_appa_changes
(
  p_start_date date,
  p_date date,
  p_ap_ids out ct_number,
  p_ap_from_dates out ct_date
)
is
begin
  ------------------------------
  select access_point_id, from_date
    bulk collect into p_ap_ids, p_ap_from_dates
    from
      (
      select
          access_point_id, from_date, row_number() over ( partition by access_point_id order by from_date desc) rn
        from
        (
          select /*+ index(appa I_APPA_DATE_FROM)*/
              access_point_id, from_date
            from access_point_personal_account appa
            where 1 = 1
            and from_date between p_start_date and p_date
          union
          select /*+ index(appa I_APPA_DATE_TO)*/
              access_point_id, from_date
            from access_point_personal_account appa
            where 1 = 1
            and nvl(to_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) between p_start_date and p_date
        )
      )
    where 1 = 1
    and rn = 1
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_pah_changes
(
  p_start_date date,
  p_date date,
  p_pas out ct_varchar_s,
  p_pa_start_dates out ct_date
)
is
begin
  ------------------------------
  select personal_account, start_date
    bulk collect into p_pas, p_pa_start_dates
    from
      (
      select
          personal_account, start_date, row_number() over ( partition by personal_account order by start_date desc) rn
        from
        (
          select /*+ index(pah I_PAH_DATE_FROM)*/
              personal_account, start_date
            from  personal_account_history pah
            where 1 = 1
            and start_date between p_start_date and p_date
          union
          select /*+ index(pah I_PAH_DATE_TO)*/
              personal_account, start_date
            from  personal_account_history pah
            where 1 = 1
            and nvl(end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) between p_start_date and p_date
        )
      )
    where 1 = 1
    and rn = 1
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_no_changes
(
  p_start_date date,
  p_date date,
  p_na_no_ids out ct_number,
  p_na_no_start_dates out ct_date
)
is
begin
  ------------------------------
  select network_address_id, start_date
    bulk collect into p_na_no_ids, p_na_no_start_dates
    from
      (
      select
          network_address_id, start_date, row_number() over ( partition by network_address_id order by start_date desc) rn
        from
        (
          select /*+ index(po I_PO_DATE_FROM)*/
              network_address_id, start_date
            from phone_operator po
            where 1 = 1
            and start_date between p_start_date and p_date
            and date_to_act >= p_start_date
            and type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own) --!_!CUST_SIDE
          union
          select /*+ index(po I_PO_DATE_TO)*/
              network_address_id, start_date
            from phone_operator po
            where 1 = 1
            and end_date between p_start_date and p_date
            and date_to_act >= p_start_date
            and type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own) --!_!CUST_SIDE
        )
      )
    where 1 = 1
    and rn = 1
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_nash_changes
(
  p_start_date date,
  p_date date,
  p_nash_ids out ct_number,
  p_nash_start_dates out ct_date
)
is
begin
  ------------------------------
  select network_address_id, start_date
    bulk collect into p_nash_ids, p_nash_start_dates
    from
      (
      select
          network_address_id, start_date, row_number() over ( partition by network_address_id order by start_date desc) rn
        from
        (
          select /*+ index(nash I_NASH_DATE_FROM)*/
              network_address_id, start_date
            from network_address_status_history nash
            where 1 = 1
            and start_date between p_start_date and p_date
          union
          select /*+ index(nash I_NASH_DATE_TO)*/
              network_address_id, start_date
            from network_address_status_history nash
            where 1 = 1
            and nvl(end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) between p_start_date and p_date
        )
      )
    where 1 = 1
    and rn = 1
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_phone_statuses_by_pso
(
  p_network_operator_ids ct_number,
  p_date date,
  p_city_phone_type varchar2,
  p_ps_ids ct_number,
  p_ps_start_dates ct_date
) return ct_msisdn_status
is
  v_res ct_msisdn_status;
begin
  ------------------------------
  select /*+ ordered use_hash(q2 z) use_nl(pso n pn pns naap s appa pah h)
      full(q1)
      full(q2)
      index(pso I_PSO_PNS)
      full(z)
      index(n PK_NETWORK_OPERATOR)
      index(pn I_PHONENUM_PNS_ID_EXT)
      index(pns PK_PHONE_NUMBER_SERIES)
      index(naap I_NETADDRACCPO_NET_ADDRESS_ID2)
      index(s PK_SIM_CARD)
      index(appa I_APPA_AP)
      index(pah I_PAH_PA)
      index(h PK_HOST)
      */
      ot_msisdn_status
      (
        s.imsi,
        pn.international_format,
        pah.balance_storage,
        h.host_type_code,
        n.uprs_member_code
      )
      bulk collect into v_res
      from
        (select column_value phone_number_series_id, rownum rn from  table(cast(p_ps_ids as ct_number))) q1,
        (select column_value start_date, rownum rn from  table(cast(p_ps_start_dates as ct_date))) q2,
        phone_series_operator pso,
        (select column_value network_operator_id, rownum rn from  table(cast(p_network_operator_ids as ct_number))) z,
        network_operator n,
        phone_number pn,
        phone_number_series pns,
        network_address_access_point naap,
        sim_card s,
        access_point_personal_account appa,
        personal_account_history pah,
        host h
      where 1 = 1
      --
      and q2.rn = q1.rn
      --
      and pso.phone_number_series_id = q1.phone_number_series_id
      and nvl(pso.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > q2.start_date --!_!
      and pso.start_date = q2.start_date
      --
      and z.network_operator_id = pso.network_operator_id
      --
      and n.network_operator_id = z.network_operator_id
      and nvl(n.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
      and n.network_operator_type(+) IS NULL
      --
      and pn.phone_number_series_id = pso.phone_number_series_id
      and nvl(pn.deleted, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > p_date
      and pn.net_address_status_code not in (util_ri.c_NASH_CODE_OTHER, util_ri.c_NASH_CODE_EXTERNAL) --!_!CUST_SIDE
      --
      and pns.phone_number_series_id = pn.phone_number_series_id
      and nvl(pns.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
      and pns.phone_number_type_code != p_city_phone_type
      --
      and naap.network_address_id(+) = pn.network_address_id
      and p_date between naap.from_date(+) and nvl(naap.to_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
      --
      and s.access_point_id(+) = naap.access_point_id
      and nvl(s.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
      --
      and appa.access_point_id(+) = s.access_point_id
      and p_date between appa.from_date(+) and nvl(appa.to_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
      --
      and pah.personal_account(+) = appa.personal_account
      and p_date between pah.start_date(+) and nvl(pah.end_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
      --
      and h.host_id(+) = pah.balance_storage
      and nvl(h.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
      --
    ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_phone_statuses_by_naap
(
  p_network_operator_ids ct_number,
  p_date date,
  p_city_phone_type varchar2,
  p_na_ids ct_number,
  p_na_from_dates ct_date
) return ct_msisdn_status
is
  v_res ct_msisdn_status;
begin
  ------------------------------
  select /*+ ordered use_hash(q2 z) use_nl(naap pso n pn pns s appa pah h)
    full(q1)
    full(q2)
    index(naap I_NETADDRACCPO_NET_ADDRESS_ID2)
    index(pn PK_PHONE_NUMBER)
    index(pns PK_PHONE_NUMBER_SERIES)
    index(pso I_PSO_PNS)
    full(z)
    index(n PK_NETWORK_OPERATOR)
    index(s PK_SIM_CARD)
    index(appa I_APPA_AP)
    index(pah I_PAH_PA)
    index(h PK_HOST)
    */
    ot_msisdn_status
    (
      s.imsi,
      pn.international_format,
      pah.balance_storage,
      h.host_type_code,
      n.uprs_member_code
    )
    bulk collect into v_res
    from
      (select column_value network_address_id, rownum rn from  table(cast(p_na_ids as ct_number))) q1,
      (select column_value from_date, rownum rn from  table(cast(p_na_from_dates as ct_date))) q2,
      network_address_access_point naap,
      phone_number pn,
      phone_number_series pns,
      phone_series_operator pso,
      (select column_value network_operator_id, rownum rn from  table(cast(p_network_operator_ids as ct_number))) z,
      network_operator n,
      sim_card s,
      access_point_personal_account appa,
      personal_account_history pah,
      host h
    where 1 = 1
    --
    and q2.rn = q1.rn
    --
    and naap.network_address_id = q1.network_address_id
    and nvl(naap.to_date,to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > q2.from_date --!_!
    and naap.from_date = q2.from_date
    --
    and pn.network_address_id = naap.network_address_id
    and nvl(pn.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    and pn.net_address_status_code not in (util_ri.c_NASH_CODE_OTHER, util_ri.c_NASH_CODE_EXTERNAL) --!_!CUST_SIDE
    --
    and pns.phone_number_series_id = pn.phone_number_series_id
    and nvl(pns.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    and pns.phone_number_type_code != p_city_phone_type
    --
    and pso.phone_number_series_id = pns.phone_number_series_id
    and p_date between pso.start_date and nvl(pso.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and z.network_operator_id = pso.network_operator_id  --!_! Phone numbers must be deleted on cust side
    --
    and n.network_operator_id = z.network_operator_id
    and nvl(n.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    and n.network_operator_type IS NULL
    --
    and s.access_point_id(+) = naap.access_point_id
    and nvl(s.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
    --
    and appa.access_point_id(+) = s.access_point_id
    and p_date between appa.from_date(+) and nvl(appa.to_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and pah.personal_account(+) = appa.personal_account
    and p_date between pah.start_date(+) and nvl(pah.end_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and h.host_id(+) = pah.balance_storage
    and nvl(h.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
    --
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_phone_statuses_by_appa
(
  p_network_operator_ids ct_number,
  p_date date,
  p_city_phone_type varchar2,
  p_ap_ids ct_number,
  p_ap_from_dates ct_date
) return ct_msisdn_status
is
  v_res ct_msisdn_status;
begin
  ------------------------------
  select /*+ ordered use_hash(q2 z) use_nl(appa s naap pn pns pso n pah h)
    full(q1)
    full(q2)
    index(appa I_APPA_AP)
    index(s PK_SIM_CARD)
    index(naap I_NAAP_AP)
    index(pn PK_PHONE_NUMBER)
    index(pns PK_PHONE_NUMBER_SERIES)
    index(pso I_PSO_PNS)
    full(z)
    index(n PK_NETWORK_OPERATOR)
    index(pah I_PAH_PA)
    index(h PK_HOST)
    */
    ot_msisdn_status
    (
      s.imsi,
      pn.international_format,
      pah.balance_storage,
      h.host_type_code,
      n.uprs_member_code
    )
    bulk collect into v_res
    from
      (select column_value access_point_id, rownum rn from  table(cast(p_ap_ids as ct_number))) q1,
      (select column_value from_date, rownum rn from  table(cast(p_ap_from_dates as ct_date))) q2,
      access_point_personal_account appa,
      sim_card s,
      network_address_access_point naap,
      phone_number pn,
      phone_number_series pns,
      phone_series_operator pso,
      (select column_value network_operator_id, rownum rn from  table(cast(p_network_operator_ids as ct_number))) z,
      network_operator n,
      personal_account_history pah,
      host h
    where 1 = 1
    --
    and q2.rn = q1.rn
    --
    and appa.access_point_id = q1.access_point_id
    and nvl(appa.to_date,to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > q2.from_date --!_!
    and appa.from_date = q2.from_date
    --
    and s.access_point_id = appa.access_point_id
    and nvl(s.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    --
    and naap.access_point_id = s.access_point_id
    and p_date between naap.from_date and nvl(naap.to_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and pn.network_address_id = naap.network_address_id
    and nvl(pn.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    and pn.net_address_status_code not in (util_ri.c_NASH_CODE_OTHER, util_ri.c_NASH_CODE_EXTERNAL) --!_!CUST_SIDE
    --
    and pns.phone_number_series_id = pn.phone_number_series_id
    and nvl(pns.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    and pns.phone_number_type_code != p_city_phone_type
    --
    and pso.phone_number_series_id = pns.phone_number_series_id
    and p_date between pso.start_date and nvl(pso.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and z.network_operator_id = pso.network_operator_id --!_! Phone numbers must be deleted on cust side
    --
    and n.network_operator_id = z.network_operator_id
    and nvl(n.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    and n.network_operator_type IS NULL
    --
    and pah.personal_account(+) = appa.personal_account
    and p_date between pah.start_date(+) and nvl(pah.end_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and h.host_id(+) = pah.balance_storage
    and nvl(h.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
    --
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_phone_statuses_by_pah
(
  p_network_operator_ids ct_number,
  p_date date,
  p_city_phone_type varchar2,
  p_pas ct_varchar_s,
  p_pa_start_dates ct_date
) return ct_msisdn_status
is
  v_res ct_msisdn_status;
begin
  ------------------------------
  select /*+ ordered use_hash(q2 z) use_nl(pah appa s naap pn pns pso n h)
    full(q1)
    full(q2)
    index(pah I_PAH_PA)
    index(appa I_APPA_PA)
    index(s PK_SIM_CARD)
    index(naap I_NAAP_AP)
    index(pn PK_PHONE_NUMBER)
    index(pns PK_PHONE_NUMBER_SERIES)
    index(pso I_PSO_PNS)
    full(z)
    index(n PK_NETWORK_OPERATOR)
    index(h PK_HOST)
    */
    ot_msisdn_status
    (
      s.imsi,
      pn.international_format,
      pah.balance_storage,
      h.host_type_code,
      n.uprs_member_code
    )
    bulk collect into v_res
    from
      (select column_value personal_account, rownum rn from  table(cast(p_pas as ct_varchar_s))) q1,
      (select column_value start_date, rownum rn from  table(cast(p_pa_start_dates as ct_date))) q2,
      personal_account_history pah,
      access_point_personal_account appa,
      sim_card s,
      network_address_access_point naap,
      phone_number pn,
      phone_number_series pns,
      phone_series_operator pso,
      (select column_value network_operator_id, rownum rn from  table(cast(p_network_operator_ids as ct_number))) z,
      network_operator n,
      host h
    where 1 = 1
    --
    and q2.rn = q1.rn
    --
    and pah.personal_account = q1.personal_account
    and nvl(pah.end_date,to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > q2.start_date --!_!
    and pah.start_date = q2.start_date
    --
    and appa.personal_account = pah.personal_account
    and p_date between appa.from_date and nvl(appa.to_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and s.access_point_id = appa.access_point_id
    and nvl(s.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    --
    and naap.access_point_id = s.access_point_id
    and p_date between naap.from_date and nvl(naap.to_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and pn.network_address_id = naap.network_address_id
    and nvl(pn.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    and pn.net_address_status_code not in (util_ri.c_NASH_CODE_OTHER, util_ri.c_NASH_CODE_EXTERNAL) --!_!CUST_SIDE
    --
    and pns.phone_number_series_id = pn.phone_number_series_id
    and nvl(pns.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    and pns.phone_number_type_code != p_city_phone_type
    --
    and pso.phone_number_series_id = pns.phone_number_series_id
    and p_date between pso.start_date and nvl(pso.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and z.network_operator_id = pso.network_operator_id  --!_! Phone numbers must be deleted on cust side
    --
    and n.network_operator_id = z.network_operator_id
    and nvl(n.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    and n.network_operator_type IS NULL
    --
    and h.host_id(+) = pah.balance_storage
    and nvl(h.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
    --
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_phone_statuses_by_po
(
  p_network_operator_ids ct_number,
  p_date date,
  p_city_phone_type varchar2,
  p_na_no_ids ct_number,
  p_na_no_start_dates ct_date
) return ct_msisdn_status
is
  v_res ct_msisdn_status;
begin
  ------------------------------
  select /*+ ordered use_hash(q2 z) use_nl(po n pn pns naap s appa pah h)
    full(q1)
    full(q2)
    index(po I_PHONE_OPERATOR_NAID)
    full(z)
    index(n PK_NETWORK_OPERATOR)
    index(pn PK_PHONE_NUMBER)
    index(pns PK_PHONE_NUMBER_SERIES)
    index(naap I_NETADDRACCPO_NET_ADDRESS_ID2)
    index(s PK_SIM_CARD)
    index(appa I_APPA_AP)
    index(pah I_PAH_PA)
    index(h PK_HOST)
    */
    ot_msisdn_status
    (
      s.imsi,
      pn.international_format,
      pah.balance_storage,
      h.host_type_code,
      n.uprs_member_code
    )
    bulk collect into v_res
    from
      (select column_value network_address_id, rownum rn from  table(cast(p_na_no_ids as ct_number))) q1,
      (select column_value start_date, rownum rn from  table(cast(p_na_no_start_dates as ct_date))) q2,
      phone_operator po,
      (select column_value network_operator_id, rownum rn from  table(cast(p_network_operator_ids as ct_number))) z,
      network_operator n,
      phone_number pn,
      phone_number_series pns,
      network_address_access_point naap,
      sim_card s,
      access_point_personal_account appa,
      personal_account_history pah,
      host h
    where 1 = 1
    --
    and q2.rn = q1.rn
    --
    and po.network_address_id = q1.network_address_id
    and po.end_date > q2.start_date --!_!
    and po.start_date = q2.start_date
    and po.date_to_act > q2.start_date
    and po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own) --!_!CUST_SIDE
    --
    and z.network_operator_id = po.network_operator_id
    --
    and n.network_operator_id = z.network_operator_id
    and nvl(n.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    and n.network_operator_type IS NULL
    --
    and pn.network_address_id = po.network_address_id
    and nvl(pn.deleted, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > p_date
    and pn.net_address_status_code not in (util_ri.c_NASH_CODE_OTHER, util_ri.c_NASH_CODE_EXTERNAL) --!_!CUST_SIDE
    --
    and pns.phone_number_series_id = pn.phone_number_series_id
    and nvl(pns.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    and pns.phone_number_type_code != p_city_phone_type
    --
    and naap.network_address_id(+) = pn.network_address_id
    and p_date between naap.from_date(+) and nvl(naap.to_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and s.access_point_id(+) = naap.access_point_id
    and nvl(s.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
    --
    and appa.access_point_id(+) = s.access_point_id
    and p_date between appa.from_date(+) and nvl(appa.to_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and pah.personal_account(+) = appa.personal_account
    and p_date between pah.start_date(+) and nvl(pah.end_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and h.host_id(+) = pah.balance_storage
    and nvl(h.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
    --
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_phone_statuses_by_nash
(
  p_network_operator_ids ct_number,
  p_date date,
  p_city_phone_type varchar2,
  p_nash_ids ct_number,
  p_nash_start_dates ct_date
) return ct_msisdn_status
is
  v_res ct_msisdn_status;
begin
  ------------------------------
  select /*+ ordered use_hash(q2 z) use_nl(nash n pn po pso pns naap s appa pah h)
    full(q1)
    full(q2)
    index(nash I_NETADSTAHI_NETWORK_ADDRES_I2)
    index(pn PK_PHONE_NUMBER)
    index(pns PK_PHONE_NUMBER_SERIES)
    index(pso I_PSO_PNS)
    index(po I_PHONE_OPERATOR_NAID)
    full(z)
    index(n PK_NETWORK_OPERATOR)
    index(naap I_NETADDRACCPO_NET_ADDRESS_ID2)
    index(s PK_SIM_CARD)
    index(appa I_APPA_AP)
    index(pah I_PAH_PA)
    index(h PK_HOST)
    */
    ot_msisdn_status
    (
      s.imsi,
      pn.international_format,
      pah.balance_storage,
      h.host_type_code,
      n.uprs_member_code
    )
    bulk collect into v_res
    from
      (select column_value network_address_id, rownum rn from  table(cast(p_nash_ids as ct_number))) q1,
      (select column_value start_date, rownum rn from  table(cast(p_nash_start_dates as ct_date))) q2,
      network_address_status_history nash,
      phone_number pn,
      phone_number_series pns,
      phone_series_operator pso,
      phone_operator po,
      (select column_value network_operator_id, rownum rn from  table(cast(p_network_operator_ids as ct_number))) z,
      network_operator n,
      network_address_access_point naap,
      sim_card s,
      access_point_personal_account appa,
      personal_account_history pah,
      host h
    where 1 = 1
    --
    and q2.rn = q1.rn
    --
    and nash.network_address_id = q1.network_address_id
    and nvl(nash.end_date,to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > q2.start_date --!_!
    and nash.start_date = q2.start_date
    --
    and pn.network_address_id = nash.network_address_id
    and nvl(pn.deleted, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > p_date
    and pn.net_address_status_code not in (util_ri.c_NASH_CODE_OTHER, util_ri.c_NASH_CODE_EXTERNAL) --!_!CUST_SIDE
    --
    and pns.phone_number_series_id = pn.phone_number_series_id
    and nvl(pns.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    and pns.phone_number_type_code != p_city_phone_type
    --
    and pso.phone_number_series_id = pns.phone_number_series_id
    and p_date between pso.start_date and nvl(pso.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and po.network_address_id(+) = nash.network_address_id
    and p_date between po.start_date(+) and po.end_date(+)
    and po.date_to_act(+) >= p_date
    and po.type(+) in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own) --!_!CUST_SIDE
    --
    and z.network_operator_id = nvl(po.network_operator_id, pso.network_operator_id)
    --
    and n.network_operator_id = z.network_operator_id
    and nvl(n.deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    and n.network_operator_type IS NULL
    --
    and naap.network_address_id(+) = pn.network_address_id
    and p_date between naap.from_date(+) and nvl(naap.to_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and s.access_point_id(+) = naap.access_point_id
    and nvl(s.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
    --
    and appa.access_point_id(+) = s.access_point_id
    and p_date between appa.from_date(+) and nvl(appa.to_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and pah.personal_account(+) = appa.personal_account
    and p_date between pah.start_date(+) and nvl(pah.end_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
    --
    and h.host_id(+) = pah.balance_storage
    and nvl(h.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
    --
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_! we get only current versions: pn BUT NOT nash;
--!_! and ONLY OWN phone numbers: pn.net_address_status_code not in (util_ri.c_NASH_CODE_OTHER, util_ri.c_NASH_CODE_EXTERNAL)
--!_! because NOT OWN phone numbers must be deleted on CUST side (--!_!CUST_SIDE)
--!_! but CUST can't do it
----------------------------------!---------------------------------------------
procedure get_msisdn_status_for_cust
(
    p_start_date date,
    p_network_operator_id number,
    p_result_list out sys_refcursor
)
is
  v_date date := sysdate;
  v_network_operator_ids ct_number;
  v_city_phone_type varchar2(50);
  --
  v_ps_ids ct_number;
  v_ps_start_dates ct_date;
  v_change_no_ps_links ct_msisdn_status;
  --
  v_na_ids ct_number;
  v_na_from_dates ct_date;
  v_change_na_ap_links ct_msisdn_status;
  --
  v_ap_ids ct_number;
  v_ap_from_dates ct_date;
  v_change_ap_pa_links ct_msisdn_status;
  --
  v_pas ct_varchar_s;
  v_pa_start_dates ct_date;
  v_change_pa_bs_links ct_msisdn_status;
  --
  v_na_no_ids ct_number;
  v_na_no_start_dates ct_date;
  v_change_na_no_links ct_msisdn_status;
  --
  v_nash_ids ct_number;
  v_nash_start_dates ct_date;
  v_change_nash_links ct_msisdn_status;
  --
begin
  ------------------------------
  v_city_phone_type := install_pkg.nnget_option_str(c_set_no_sync_msisdn_status_pt, 50, c_def_no_sync_msisdn_status_pt);
  ------------------------------
  v_network_operator_ids := util_ri.get_child_nos
  (
    p_root_parent_id => p_network_operator_id,
    p_date => v_date,
    p_include_self => true
  );
  ------------------------------
  if p_start_date is null
  then
    ------------------------------
    open p_result_list for
    select /*+ ordered use_hash(z n pso pn pns naap s appa pah h)
                full(z) full(n) full(pso) full(pn) full(pns) full(naap) full(s) full(appa) full(pah) full(h)
                parallel(z 8) parallel(n 8) parallel(pso 8) parallel(pn 8) parallel(pns 8)
                parallel(naap 8) parallel(s 8) parallel(appa 8) parallel(pah 8) parallel(h 8)*/
        s.imsi,
        pn.international_format MSISDN,
        pah.balance_storage,
        h.host_type_code STORAGE_TYPE,
        n.uprs_member_code
      from
        (select column_value network_operator_id, rownum rn from table(cast(v_network_operator_ids as ct_number))) z,
        network_operator n,
        phone_series_operator pso,
        phone_number pn,
        phone_number_series pns,
        network_address_access_point naap,
        sim_card s,
        access_point_personal_account appa,
        personal_account_history pah,
        host h
      where 1 = 1
      --
      and n.network_operator_id = z.network_operator_id
      and nvl(n.deleted, v_date + util_ri.c_dummy_date_shift) > v_date
      and n.network_operator_type IS NULL
      --
      and pso.network_operator_id = n.network_operator_id
      and v_date between pso.start_date and nvl(pso.end_date, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
      --
      and pn.phone_number_series_id = pso.phone_number_series_id
      and nvl(pn.deleted, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > v_date
      and pn.net_address_status_code not in (util_ri.c_NASH_CODE_OTHER, util_ri.c_NASH_CODE_EXTERNAL) --!_!CUST_SIDE
      --
      and pns.phone_number_series_id = pn.phone_number_series_id
      and nvl(pns.deleted, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > v_date
      and pns.phone_number_type_code != v_city_phone_type
      --
      and naap.network_address_id(+) = pn.network_address_id
      and v_date between naap.from_date(+) and nvl(naap.to_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
      --
      and s.access_point_id(+) = naap.access_point_id
      and nvl(s.deleted(+), v_date + util_ri.c_dummy_date_shift) > v_date
      --
      and appa.access_point_id(+) = s.access_point_id
      and v_date between appa.from_date(+) and nvl(appa.to_date(+), v_date)
      --
      and pah.personal_account(+) = appa.personal_account
      and v_date between pah.start_date(+) and nvl(pah.end_date(+), v_date)
      --
      and h.host_id(+) = pah.balance_storage
      and nvl(h.deleted(+), v_date + util_ri.c_dummy_date_shift) > v_date
      --
    union all
    select /*+ ordered use_hash(z n po pn pns naap s appa pah h)
                full(z) full(n) full(po) full(pn) full(pns) full(naap) full(s) full(appa) full(pah) full(h)
                parallel(z 8) parallel(n 8) parallel(po 8) parallel(pn 8) parallel(pns 8)
                parallel(naap 8) parallel(s 8) parallel(appa 8) parallel(pah 8) parallel(h 8)*/
        s.imsi,
        pn.international_format MSISDN,
        pah.balance_storage,
        h.host_type_code STORAGE_TYPE,
        n.uprs_member_code
      from
        (select column_value network_operator_id, rownum rn from table(cast(v_network_operator_ids as ct_number))) z,
        network_operator n,
        phone_operator po,
        phone_number pn,
        phone_number_series pns,
        network_address_access_point naap,
        sim_card s,
        access_point_personal_account appa,
        personal_account_history pah,
        host h
      where 1 = 1
      --
      and n.network_operator_id = z.network_operator_id
      and nvl(n.deleted, v_date + util_ri.c_dummy_date_shift) > v_date
      and n.network_operator_type IS NULL
      --
      and po.network_operator_id = n.network_operator_id
      and v_date between po.start_date and po.end_date
      and po.date_to_act >= v_date
      and po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own) --!_!CUST_SIDE
      --
      and pn.network_address_id = po.network_address_id
      and nvl(pn.deleted, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > v_date
      and pn.net_address_status_code not in (util_ri.c_NASH_CODE_OTHER, util_ri.c_NASH_CODE_EXTERNAL) --!_!CUST_SIDE
      --
      and pns.phone_number_series_id = pn.phone_number_series_id
      and nvl(pns.deleted, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > v_date
      and pns.phone_number_type_code != v_city_phone_type --!_!
      --
      and naap.network_address_id(+) = pn.network_address_id
      and v_date between naap.from_date(+) and nvl(naap.to_date(+), to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))
      --
      and s.access_point_id(+) = naap.access_point_id
      and nvl(s.deleted(+), v_date + util_ri.c_dummy_date_shift) > v_date
      --
      and appa.access_point_id(+) = s.access_point_id
      and v_date between appa.from_date(+) and nvl(appa.to_date(+), v_date)
      --
      and pah.personal_account(+) = appa.personal_account
      and v_date between pah.start_date(+) and nvl(pah.end_date(+), v_date)
      --
      and h.host_id(+) = pah.balance_storage
      and nvl(h.deleted(+), v_date + util_ri.c_dummy_date_shift) > v_date
      --
    ;
    ------------------------------
  else
    ------------------------------
    ------------------------------
    get_pso_changes
    (
      p_start_date => p_start_date,
      p_date => v_date,
      p_ps_ids => v_ps_ids,
      p_ps_start_dates => v_ps_start_dates
    )
    ;
    ------------------------------
    v_change_no_ps_links := get_phone_statuses_by_pso
    (
      p_network_operator_ids => v_network_operator_ids,
      p_date => v_date,
      p_city_phone_type => v_city_phone_type,
      p_ps_ids => v_ps_ids,
      p_ps_start_dates => v_ps_start_dates
    )
    ;
    ------------------------------
    ------------------------------
    get_naap_changes
    (
      p_start_date => p_start_date,
      p_date => v_date,
      p_na_ids => v_na_ids,
      p_na_from_dates => v_na_from_dates
    )
    ;
    ------------------------------
    v_change_na_ap_links := get_phone_statuses_by_naap
    (
      p_network_operator_ids => v_network_operator_ids,
      p_date => v_date,
      p_city_phone_type => v_city_phone_type,
      p_na_ids => v_na_ids,
      p_na_from_dates => v_na_from_dates
    )
    ;
    ------------------------------
    ------------------------------
    get_appa_changes
    (
      p_start_date => p_start_date,
      p_date => v_date,
      p_ap_ids => v_ap_ids,
      p_ap_from_dates => v_ap_from_dates
    )
    ;
    ------------------------------
    v_change_ap_pa_links := get_phone_statuses_by_appa
    (
      p_network_operator_ids => v_network_operator_ids,
      p_date => v_date,
      p_city_phone_type => v_city_phone_type,
      p_ap_ids => v_ap_ids,
      p_ap_from_dates => v_ap_from_dates
    )
    ;
    ------------------------------
    ------------------------------
    get_pah_changes
    (
      p_start_date => p_start_date,
      p_date => v_date,
      p_pas => v_pas,
      p_pa_start_dates => v_pa_start_dates
    )
    ;
    ------------------------------
    v_change_pa_bs_links := get_phone_statuses_by_pah
    (
      p_network_operator_ids => v_network_operator_ids,
      p_date => v_date,
      p_city_phone_type => v_city_phone_type,
      p_pas => v_pas,
      p_pa_start_dates => v_pa_start_dates
    )
    ;
    ------------------------------
    ------------------------------
    get_no_changes
    (
      p_start_date => p_start_date,
      p_date => v_date,
      p_na_no_ids => v_na_no_ids,
      p_na_no_start_dates => v_na_no_start_dates
    )
    ;
    ------------------------------
    v_change_na_no_links := get_phone_statuses_by_po
    (
      p_network_operator_ids => v_network_operator_ids,
      p_date => v_date,
      p_city_phone_type => v_city_phone_type,
      p_na_no_ids => v_na_no_ids,
      p_na_no_start_dates => v_na_no_start_dates
    )
    ;
    ------------------------------
    ------------------------------
    get_nash_changes
    (
      p_start_date => p_start_date,
      p_date => v_date,
      p_nash_ids => v_nash_ids,
      p_nash_start_dates => v_nash_start_dates
    )
    ;
    ------------------------------
    v_change_nash_links := get_phone_statuses_by_nash
    (
      p_network_operator_ids => v_network_operator_ids,
      p_date => v_date,
      p_city_phone_type => v_city_phone_type,
      p_nash_ids => v_nash_ids,
      p_nash_start_dates => v_nash_start_dates
    )
    ;
    ------------------------------
    ------------------------------
    open p_result_list for
      select * from table(v_change_no_ps_links)
      union
      select * from table(v_change_na_ap_links)
      union
      select * from table(v_change_ap_pa_links)
      union
      select * from table(v_change_pa_bs_links)
      union
      select * from table(v_change_na_no_links)
      union
      select * from table(v_change_nash_links)
    ;
    ------------------------------
    ------------------------------
  end if;
end;

----------------------------------!---------------------------------------------
procedure delete_dup_naap_for_cust
(
    p_date_from date,
    p_network_operator_id number
)
is
begin
  ------------------------------
  util_loc_pkg.touch_date(p_date_from);
  util_loc_pkg.touch_number(p_network_operator_id);
  ------------------------------
  null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

END;
/
