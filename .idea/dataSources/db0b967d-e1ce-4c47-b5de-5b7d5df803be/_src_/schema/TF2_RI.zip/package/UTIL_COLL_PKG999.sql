CREATE package util_coll_pkg999 is

----------------------------------!---------------------------------------------
  function get_marked_ol_ct_number(p_vals ct_number, p_marks ct_number) return ct_number;
  function get_marked_ol_ct_date(p_vals ct_date, p_marks ct_number) return ct_date;
  function get_marked_ol_ct_varchar_s(p_vals ct_varchar_s, p_marks ct_number) return ct_varchar_s;
  function get_marked_ol_ct_varchar(p_vals ct_varchar, p_marks ct_number) return ct_varchar;
  function get_marked_ol_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marks ct_number) return ct_nvarchar_s;
  function get_marked_ol_ct_nvarchar(p_vals ct_nvarchar, p_marks ct_number) return ct_nvarchar;

  function get_unmarked_ol_ct_number(p_vals ct_number, p_marks ct_number) return ct_number;
  function get_unmarked_ol_ct_date(p_vals ct_date, p_marks ct_number) return ct_date;
  function get_unmarked_ol_ct_varchar_s(p_vals ct_varchar_s, p_marks ct_number) return ct_varchar_s;
  function get_unmarked_ol_ct_varchar(p_vals ct_varchar, p_marks ct_number) return ct_varchar;
  function get_unmarked_ol_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marks ct_number) return ct_nvarchar_s;
  function get_unmarked_ol_ct_nvarchar(p_vals ct_nvarchar, p_marks ct_number) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function get_by_pos_ol_ct_number(p_vals ct_number, p_positions ct_number) return ct_number;
  function get_by_pos_ol_ct_date(p_vals ct_date, p_positions ct_number) return ct_date;
  function get_by_pos_ol_ct_varchar_s(p_vals ct_varchar_s, p_positions ct_number) return ct_varchar_s;
  function get_by_pos_ol_ct_varchar(p_vals ct_varchar, p_positions ct_number) return ct_varchar;
  function get_by_pos_ol_ct_nvarchar_s(p_vals ct_nvarchar_s, p_positions ct_number) return ct_nvarchar_s;
  function get_by_pos_ol_ct_nvarchar(p_vals ct_nvarchar, p_positions ct_number) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function get_mark2pos_ol(p_marks ct_number) return ct_number;
  function get_unmark2pos_ol(p_marks ct_number) return ct_number;

----------------------------------!---------------------------------------------
  function unique_ol_ct_number(p_vals ct_number) return ct_number;
  function unique_ol_ct_date(p_vals ct_date) return ct_date;
  function unique_ol_ct_varchar_s(p_vals ct_varchar_s) return ct_varchar_s;
  function unique_ol_ct_varchar(p_vals ct_varchar) return ct_varchar;
  function unique_ol_ct_nvarchar_s(p_vals ct_nvarchar_s) return ct_nvarchar_s;
  function unique_ol_ct_nvarchar(p_vals ct_nvarchar) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function imark_unique_ct_number(p_vals ct_number, p_not_unique boolean, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number;
  function imark_unique_ct_date(p_vals ct_date, p_not_unique boolean, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number;
  function imark_unique_ct_varchar_s(p_vals ct_varchar_s, p_not_unique boolean, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number;
  function imark_unique_ct_varchar(p_vals ct_varchar, p_not_unique boolean, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number;
  function imark_unique_ct_nvarchar_s(p_vals ct_nvarchar_s, p_not_unique boolean, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number;
  function imark_unique_ct_nvarchar(p_vals ct_nvarchar, p_not_unique boolean, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number;

  function mark_unique_ct_number(p_vals ct_number) return ct_number;
  function mark_unique_ct_date(p_vals ct_date) return ct_number;
  function mark_unique_ct_varchar_s(p_vals ct_varchar_s) return ct_number;
  function mark_unique_ct_varchar(p_vals ct_varchar) return ct_number;
  function mark_unique_ct_nvarchar_s(p_vals ct_nvarchar_s) return ct_number;
  function mark_unique_ct_nvarchar(p_vals ct_nvarchar) return ct_number;

  function mark_not_unique_ct_number(p_vals ct_number) return ct_number;
  function mark_not_unique_ct_date(p_vals ct_date) return ct_number;
  function mark_not_unique_ct_varchar_s(p_vals ct_varchar_s) return ct_number;
  function mark_not_unique_ct_varchar(p_vals ct_varchar) return ct_number;
  function mark_not_unique_ct_nvarchar_s(p_vals ct_nvarchar_s) return ct_number;
  function mark_not_unique_ct_nvarchar(p_vals ct_nvarchar) return ct_number;

----------------------------------!---------------------------------------------
  function trim_ct_varchar_s(p_coll ct_varchar_s) return ct_varchar_s;
  function trim_ct_varchar(p_coll ct_varchar) return ct_varchar;
  function trim_ct_nvarchar_s(p_coll ct_nvarchar_s) return ct_nvarchar_s;
  function trim_ct_nvarchar(p_coll ct_nvarchar) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function map_pos1in2_ct_number(p_vals1_not_unique ct_number, p_vals2_unique ct_number) return ct_number;
  function map_pos1in2_ct_date(p_vals1_not_unique ct_date, p_vals2_unique ct_date) return ct_number;
  function map_pos1in2_ct_varchar_s(p_vals1_not_unique ct_varchar_s, p_vals2_unique ct_varchar_s) return ct_number;
  function map_pos1in2_ct_varchar(p_vals1_not_unique ct_varchar, p_vals2_unique ct_varchar) return ct_number;
  function map_pos1in2_ct_nvarchar_s(p_vals1_not_unique ct_nvarchar_s, p_vals2_unique ct_nvarchar_s) return ct_number;
  function map_pos1in2_ct_nvarchar(p_vals1_not_unique ct_nvarchar, p_vals2_unique ct_nvarchar) return ct_number;

----------------------------------!---------------------------------------------
  function apply_map_ct_number(p_size2 number, p_vals_not_unique_size1 ct_number, p_vals_pos1in2_size1 ct_number) return ct_number;
  function apply_map_ct_date(p_size2 number, p_vals_not_unique_size1 ct_date, p_vals_pos1in2_size1 ct_number) return ct_date;
  function apply_map_ct_varchar_s(p_size2 number, p_vals_not_unique_size1 ct_varchar_s, p_vals_pos1in2_size1 ct_number) return ct_varchar_s;
  function apply_map_ct_varchar(p_size2 number, p_vals_not_unique_size1 ct_varchar, p_vals_pos1in2_size1 ct_number) return ct_varchar;
  function apply_map_ct_nvarchar_s(p_size2 number, p_vals_not_unique_size1 ct_nvarchar_s, p_vals_pos1in2_size1 ct_number) return ct_nvarchar_s;
  function apply_map_ct_nvarchar(p_size2 number, p_vals_not_unique_size1 ct_nvarchar, p_vals_pos1in2_size1 ct_number) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function restore_map_ct_number(p_vals_size2 ct_number, p_vals_pos1in2_size1 ct_number) return ct_number;
  function restore_map_ct_date(p_vals_size2 ct_date, p_vals_pos1in2_size1 ct_number) return ct_date;
  function restore_map_ct_varchar_s(p_vals_size2 ct_varchar_s, p_vals_pos1in2_size1 ct_number) return ct_varchar_s;
  function restore_map_ct_varchar(p_vals_size2 ct_varchar, p_vals_pos1in2_size1 ct_number) return ct_varchar;
  function restore_map_ct_nvarchar_s(p_vals_size2 ct_nvarchar_s, p_vals_pos1in2_size1 ct_number) return ct_nvarchar_s;
  function restore_map_ct_nvarchar(p_vals_size2 ct_nvarchar, p_vals_pos1in2_size1 ct_number) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function mark_ambig_vals_ct_number(p_vals ct_number, p_val_ids_ambig ct_number) return ct_number;
  function mark_ambig_vals_ct_date(p_vals ct_date, p_val_ids_ambig ct_number) return ct_number;
  function mark_ambig_vals_ct_varchar_s(p_vals ct_varchar_s, p_val_ids_ambig ct_number) return ct_number;
  function mark_ambig_vals_ct_varchar(p_vals ct_varchar, p_val_ids_ambig ct_number) return ct_number;
  function mark_ambig_vals_ct_nvarchar_s(p_vals ct_nvarchar_s, p_val_ids_ambig ct_number) return ct_number;
  function mark_ambig_vals_ct_nvarchar(p_vals ct_nvarchar, p_val_ids_ambig ct_number) return ct_number;

----------------------------------!---------------------------------------------

end;

/
