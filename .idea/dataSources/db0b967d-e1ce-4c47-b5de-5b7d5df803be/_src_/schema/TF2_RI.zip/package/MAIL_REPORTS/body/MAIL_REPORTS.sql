CREATE PACKAGE BODY          "MAIL_REPORTS" IS

------------------------------------------------------------------------------------------------------------------------------
--  Get_Log
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Log(
   p_start_date    IN  DATE,
   p_end_date      IN  DATE,
   p_raise_error   IN  CHAR,
   p_result        OUT sys_refcursor,
   error_code      OUT NUMBER,
   error_message   OUT VARCHAR2
)
IS
  v_sqlcode	       number;
  v_event_source   varchar2(60) :='MAIL_REPORTS.Get_Log';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

/*	IF test input parameters THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
*/

-- start of the procedure body --------------------------------------------------------------------------------------------------


  OPEN p_result FOR
  SELECT le.event_id,
         le.event_type,
         le.event_source,
         le.event_message,
         le.event_user,
         le.event_computer,
         to_char(le.event_time,'dd.mm.yyyy HH24:MI:SS')
  FROM log_event le
  WHERE le.event_type='A'
    AND le.event_source='Schema_Audit trigger'
    AND le.event_time>=p_start_date
    AND le.event_time<=p_end_date
  ORDER BY le.event_id;


-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
    END IF;
END Get_Log;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Datafiles_Info
------------------------------------------------------------------------------------------------------------------------------
/*
PROCEDURE Get_Datafiles_Info(
  p_raise_error   IN  CHAR,
  p_result        OUT CLOB,
  error_code      OUT NUMBER,
  error_message   OUT VARCHAR2
)
IS
  v_cursor         sys_refcursor;
  v_header         VARCHAR2(100);
  v_sqlcode	       number;
  v_event_source   varchar2(60) :='MAIL_REPORTS.Get_Datafiles_Info';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

\*	IF test input parameters THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
*\

-- start of the procedure body --------------------------------------------------------------------------------------------------


  v_header:='Status;Datafile;Tablespace;Size MB;Used MB;Used %;Autoext.';

  OPEN v_cursor FOR
  SELECT status || ';' || datafile_name || ';' ||
         tablespace_name || ';' || size_M || ';' || used_M || ';' ||
         used_percent || ';' || autoextensible

  FROM(
    SELECT \*+ ordered no_merge(v) *\
         v.status status,
         d.file_name datafile_name,
         d.tablespace_name tablespace_name,
         TO_CHAR(NVL(d.bytes / 1024 / 1024, 0), '99999990.000') size_M,
         TO_CHAR(NVL((d.bytes - NVL(s.bytes, 0))/1024/1024, 0),'99999990.000') used_M,
         TO_CHAR(NVL((d.bytes - NVL(s.bytes, 0)) / d.bytes * 100, 0), '990.00') used_percent,
         NVL(d.autoextensible, ' NO') autoextensible
    FROM sys.dba_data_files d,
         v$datafile v,
         (SELECT file_id,
                 SUM(bytes) bytes
            FROM sys.dba_free_space
            GROUP BY file_id
         ) s
    WHERE (s.file_id (+)= d.file_id)
      --AND d.tablespace_name LIKE 'RI%'
      AND (d.file_name = v.NAME)
    UNION ALL
    SELECT \*+ ordered no_merge(v) *\
           v.status status,
           d.file_name datafile_name,
           d.tablespace_name tablespace_name,
           TO_CHAR(NVL(d.bytes / 1024 / 1024, 0), '99999990.000') size_M,
           TO_CHAR(NVL(t.bytes_cached/1024/1024, 0),'99999990.000') used_M,
           TO_CHAR(NVL(t.bytes_cached / d.bytes * 100, 0), '990.00') used_percent,
           NVL(d.autoextensible, ' NO') autoextensible
      FROM sys.dba_temp_files d,
           v$temp_extent_pool t,
           v$tempfile v
      WHERE (t.file_id (+)= d.file_id)
        --AND t.TABLESPACE_NAME LIKE 'RI%'
        AND (d.file_id = v.file#))
  ORDER BY tablespace_name;


   p_result:= Make_Report('Datafiles Info',';',v_header,80,v_cursor);

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);


EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
    END IF;
END Get_Datafiles_Info;*/


------------------------------------------------------------------------------------------------------------------------------
--  Get_Tables_Info
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Tables_Info(
  p_raise_error   IN   CHAR,
  p_result        OUT  sys_refcursor,
  error_code      OUT  NUMBER,
  error_message   OUT  VARCHAR2
)
IS
  v_sqlcode	       number;
  v_event_source   varchar2(60) :='MAIL_REPORTS.Get_Tables_Info';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

/*	IF test input parameters THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
*/

-- start of the procedure body --------------------------------------------------------------------------------------------------


  OPEN p_result FOR
  SELECT ut.table_name,
         ut.tablespace_name,
         ut.num_rows,
         to_char(ut.last_analyzed,'dd.mm.yyyy HH24:MI:SS')
  FROM user_tables ut;



-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
    END IF;
END Get_Tables_Info;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Index_Info
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Index_Info(
  p_raise_error   IN   CHAR,
  p_result        OUT  sys_refcursor,
  error_code      OUT  NUMBER,
  error_message   OUT  VARCHAR2
)
IS
  v_sqlcode	       number;
  v_event_source   varchar2(60) :='MAIL_REPORTS.Get_Index_Info';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

/*	IF test input parameters THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
*/

-- start of the procedure body --------------------------------------------------------------------------------------------------


  OPEN p_result FOR
  SELECT ui.table_name,
         ui.index_name,
         ui.index_type,
         ui.tablespace_name,
         ui.num_rows,
         ui.sample_size,
         ui.last_analyzed
  FROM user_indexes ui
  ORDER BY ui.table_name,ui.index_name;


-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
    END IF;
END Get_Index_Info;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Constraints
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Constraints_Info(
  p_raise_error   IN  CHAR,
  p_result        OUT sys_refcursor,
  error_code      OUT NUMBER,
  error_message   OUT VARCHAR2
)
IS
  v_sqlcode	       number;
  v_event_source   varchar2(60) :='MAIL_REPORTS.Get_Constraints_Info';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

/*	IF test input parameters THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
*/

-- start of the procedure body --------------------------------------------------------------------------------------------------



  OPEN p_result FOR
  SELECT uc.table_name,
         uc.constraint_name,
         ucc.column_name,
         uc.status
  FROM User_Constraints uc
  JOIN user_cons_columns ucc ON ucc.constraint_name=uc.constraint_name
  WHERE uc.constraint_type IN ('P','R','C','U')
    AND uc.constraint_name NOT LIKE 'SYS%'
  ORDER BY uc.table_name,uc.constraint_name,ucc.position;


-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
    END IF;
END Get_Constraints_Info;

-----------------------------------------------------------------------------------------------------------------------------
--  Get_Jobs_Info
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Jobs_Info(
  p_raise_error   IN  CHAR,
  p_result        OUT sys_refcursor,
  error_code      OUT NUMBER,
  error_message   OUT VARCHAR2
)
IS
  v_sqlcode	       number;
  v_event_source   varchar2(60) :='MAIL_REPORTS.Get_Jobs_Info';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

/*	IF test input parameters THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
*/

-- start of the procedure body --------------------------------------------------------------------------------------------------


  OPEN p_result FOR
  SELECT uj.job,
         uj.what,
         uj.INTERVAL,
         to_char(uj.last_date,'dd.mm.yyyy HH24:MI:SS'),
         to_char(uj.next_date,'dd.mm.yyyy HH24:MI:SS'),
         uj.broken,
         uj.failures
  FROM user_jobs uj
  ORDER BY uj.job;



-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);


EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
    END IF;
END Get_Jobs_Info;

-----------------------------------------------------------------------------------------------------------------------------
--  Get_Version_Info
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Version_Info(
  p_raise_error   IN  CHAR,
  p_result        OUT sys_refcursor,
  error_code      OUT NUMBER,
  error_message   OUT VARCHAR2
)
IS
  v_sqlcode	       number;
  v_event_source   varchar2(60) :='MAIL_REPORTS.Get_Version_Info';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

/*	IF test input parameters THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
*/

-- start of the procedure body --------------------------------------------------------------------------------------------------


  OPEN p_result FOR
  SELECT d.application,
         d.installation_date,
         d.creation_date,
         d.install_script_type,
         d.version_number,
         d.description,
         d.user_name
  FROM version_log d
  ORDER BY d.installation_date;



-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);


EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
    END IF;
END Get_Version_Info;
END MAIL_REPORTS;


/
