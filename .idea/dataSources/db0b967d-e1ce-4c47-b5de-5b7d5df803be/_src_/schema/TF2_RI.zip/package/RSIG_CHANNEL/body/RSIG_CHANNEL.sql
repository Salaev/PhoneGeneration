CREATE PACKAGE BODY RSIG_CHANNEL IS

---------------------------------------------
--     PROCEDURE Test_Row_For_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Row_For_Exist_And_Deleted(p_channel_id IN CHANNEL.CHANNEL_ID%TYPE) IS
  v_deleted CHANNEL.DELETED%TYPE;
BEGIN
  select DELETED into v_deleted from CHANNEL where CHANNEL_id = p_channel_id;

  IF v_deleted IS NOT NULL THEN
    IF v_deleted < sysdate THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
    END IF;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Test_Row_For_Exist_And_Deleted;

---------------------------------------------
--     PROCEDURE Test_Network_Operator_Deleted
---------------------------------------------

PROCEDURE Test_Network_Operator_Deleted(p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE) IS
  v_s VARCHAR2(1);
BEGIN
  select 'X'
    into v_s
    from NETWORK_OPERATOR
   where network_operator_id = p_network_operator_id
     and deleted is not null;

  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    NULL;
END Test_Network_Operator_Deleted;

---------------------------------------------
--     PROCEDURE Insert_Channel
---------------------------------------------

PROCEDURE Insert_Channel
(
  handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_channel_number      IN CHANNEL.CHANNEL_NUMBER%TYPE,
  p_host_id_placed_on   IN CHANNEL.HOST_ID_PLACED_ON%TYPE,
  p_host_id             IN CHANNEL.HOST_ID%TYPE,
  p_network_operator_id IN CHANNEL.NETWORK_OPERATOR_ID%TYPE,
  p_user_id_of_change   IN NUMBER,
  p_channel_id          OUT CHANNEL.CHANNEL_ID%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_CHANNEL.Insert_Channel';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint insert_channel_a;
  END IF;

  IF p_network_operator_id IS NOT NULL THEN
    Test_Network_Operator_Deleted(p_network_operator_id);
  END IF;

  select s_channel.nextval into p_channel_id from DUAL;

  insert into CHANNEL
    (CHANNEL_ID,
     CHANNEL_NUMBER,
     HOST_ID_PLACED_ON,
     HOST_ID,
     NETWORK_OPERATOR_ID,
     DELETED,
     DATE_OF_CHANGE,
     USER_ID_OF_CHANGE)
  values
    (p_channel_id,
     p_channel_number,
     p_host_id_placed_on,
     p_host_id,
     p_network_operator_id,
     null,
     sysdate,
     p_user_id_of_change);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint insert_channel_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Insert_Channel;

---------------------------------------------
--     PROCEDURE Update_Channel
---------------------------------------------

PROCEDURE Update_Channel
(
  handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_channel_id          IN CHANNEL.CHANNEL_ID%TYPE,
  p_channel_number      IN CHANNEL.CHANNEL_NUMBER%TYPE,
  p_host_id_placed_on   IN CHANNEL.HOST_ID_PLACED_ON%TYPE,
  p_host_id             IN CHANNEL.HOST_ID%TYPE,
  p_network_operator_id IN CHANNEL.NETWORK_OPERATOR_ID%TYPE,
  p_user_id_of_change   IN NUMBER
) IS
  v_event_source VARCHAR2(60) := 'RSIG_CHANNEL.Update_Channel';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint update_channel_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_channel_id);
  IF p_network_operator_id IS NOT NULL THEN
    Test_Network_Operator_Deleted(p_network_operator_id);
  END IF;

  update CHANNEL
     set CHANNEL_NUMBER      = p_channel_number,
         HOST_ID_PLACED_ON   = p_host_id_placed_on,
         HOST_ID             = p_host_id,
         NETWORK_OPERATOR_ID = p_network_operator_id,
         DATE_OF_CHANGE      = sysdate,
         USER_ID_OF_CHANGE   = p_user_id_of_change
   where CHANNEL_ID = p_channel_id;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint update_channel_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Update_Channel;

---------------------------------------------
--     PROCEDURE Delete_Channel
---------------------------------------------

PROCEDURE Delete_Channel
(
  handle_tran         IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT NUMBER,
  p_channel_id        IN CHANNEL.CHANNEL_ID%TYPE,
  p_deleted           IN CHANNEL.DELETED%TYPE,
  p_user_id_of_change IN NUMBER
) IS
  v_event_source VARCHAR2(60) := 'RSIG_CHANNEL.Delete_Channel';
  v_deleted      DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  v_deleted := nvl(p_deleted, SYSDATE);
  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint delete_channel_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_channel_id);

  update CHANNEL
     set DELETED           = v_deleted,
         DATE_OF_CHANGE    = sysdate,
         USER_ID_OF_CHANGE = p_user_id_of_change
   where CHANNEL_ID = p_channel_id;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint delete_channel_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Delete_Channel;

---------------------------------------------
--     PROCEDURE Get_Channel
---------------------------------------------

PROCEDURE Get_Channel
(
  error_code            OUT NUMBER,
  p_host_id_placed_on   IN CHANNEL.HOST_ID_PLACED_ON%TYPE,
  p_host_id             IN CHANNEL.HOST_ID%TYPE,
  p_network_operator_id IN CHANNEL.NETWORK_OPERATOR_ID%TYPE,
  p_cur_channel         OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_CHANNEL.Get_Channel';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_channel FOR
    select CHANNEL_ID,
           CHANNEL_NUMBER,
           HOST_ID_PLACED_ON,
           HOST_ID,
           NETWORK_OPERATOR_ID,
           DATE_OF_CHANGE,
           USER_ID_OF_CHANGE
      from CHANNEL
     where (HOST_ID_PLACED_ON = p_host_id_placed_on or p_host_id_placed_on is null)
       and (HOST_ID = p_host_id or p_host_id is null)
       and (NETWORK_OPERATOR_ID = p_network_operator_id or p_network_operator_id is null)
       and DELETED is null;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_Channel;

---------------------------------------------
--     PROCEDURE Get_Channel_All
---------------------------------------------

PROCEDURE Get_Channel_All
(
  error_code            OUT NUMBER,
  p_host_id_placed_on   IN CHANNEL.HOST_ID_PLACED_ON%TYPE,
  p_host_id             IN CHANNEL.HOST_ID%TYPE,
  p_network_operator_id IN CHANNEL.NETWORK_OPERATOR_ID%TYPE,
  p_cur_channel         OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_CHANNEL.Get_Channel_All';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_channel FOR
    SELECT ch.CHANNEL_ID,
           ch.CHANNEL_NUMBER,
           ch.HOST_ID_PLACED_ON,
           ch.HOST_ID,
           ch.NETWORK_OPERATOR_ID,
           ch.DATE_OF_CHANGE,
           ch.USER_ID_OF_CHANGE,
           ch.DELETED,
           h.HOST_NAME,
           no.NETWORK_OPERATOR_NAME,
           h2.HOST_NAME PLACED_ON_HOST_NAME
      FROM CHANNEL ch
      LEFT JOIN HOST h ON ch.HOST_ID = h.HOST_ID
      LEFT JOIN NETWORK_OPERATOR no ON ch.NETWORK_OPERATOR_ID = no.NETWORK_OPERATOR_ID
      LEFT JOIN HOST h2 ON ch.host_id_placed_on = h2.host_id
     WHERE (ch.HOST_ID_PLACED_ON = p_host_id_placed_on OR p_host_id_placed_on IS NULL)
       AND (ch.HOST_ID = p_host_id OR p_host_id IS NULL)
       AND (ch.NETWORK_OPERATOR_ID = p_network_operator_id OR p_network_operator_id IS NULL);

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_Channel_All;


END RSIG_CHANNEL;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_CHANNEL.pkb,v 1.17 2003/12/22 11:29:44 rhejduk Exp $
/
