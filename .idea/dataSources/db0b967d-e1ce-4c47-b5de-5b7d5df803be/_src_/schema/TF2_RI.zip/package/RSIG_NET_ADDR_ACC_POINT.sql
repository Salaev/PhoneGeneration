CREATE PACKAGE "RSIG_NET_ADDR_ACC_POINT" IS
/****************************************************************************
<header>
  <name>             	package RSIG_NET_ADDR_ACC_POINT
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>           1.2.3    22.11.2006   Petr Cepek
                      procedure Is_Access_Point_Deleted deleted
  </version>
  <version>           1.2.2    22.09.2006   Petr Cepek
                      procedure Exist_Batch_Session_id deleted
                      procedure Insert_Packet_Of_Intervals deleted
                      procedure Close_Packet_Of_Intervals deleted
  </version>
  <version>           1.2.1    31.07.2006   Petr Cepek
                      procedure Is_Net_Address_Deleted deleted
  </version>
  <version>
                      1.2.0    1.9.2005  Petr Cepek
                      procedure Is_Interval_Overlap updated
  </version>
	<version>			      1.1.20	4.8.2004     Jaroslav Holub
								      Insert_Interval,Close_Interval,Insert_Packet_Of_Intervals,Close_Packet_Of_Intervals
                                - fixed for time difference between client and server,
								  date should be null and it means sysdate
	</version>
  	<version>          	1.1.19	30.04.2004     Jaroslav Holub
								changed cursor for fetch only values which has not null NA_id and ACC_POINT_id and has result = c_OK
  	</version>
 	<version>          	1.1.18  15.12.2003		prybicka
								*** empty log message ***
  	</version>
  	<version>          	1.1.17  15.12.2003		jstodulk
  								Insert debug constant.
  	</version>
  	<version>          	1.1.16  15.12.2003		prybicka
  								used constants c_DEBUG_TEXT_*
  	</version>
  	<version>          	1.1.15  15.12.2003		jstodulk
  								Insert parameter RSIG_UTILS.c_MIN_DATE.
  	</version>
  	<version>          	1.1.14  12.12.2003		prybicka
  								*** empty log message ***
  	</version>
  	<version>          	1.1.13  12.12.2003		prybicka
  								p_to_date=>p_end_date
  	</version>
  	<version>          	1.1.12  12.12.2003		prybicka
  								odstarneni from_date z ClosePacketOfIntervals
  	</version>
  	<version>          	1.1.11  5.12.2003		prybicka
  								parameter p_from_date added
  	</version>
  	<version>				1.1.10  5.12.2003		rhejduk
  								*** empty log message ***
  	</version>
  	<version>				1.0.1   10.9.2003		Radek Hejduk
                                created first version
  	</version>

  <Description>      	package for table NETWORK_ADDRESS_ACCESS_POINT
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/

PROCEDURE Is_Interval_Overlap
(
  p_access_point_id    IN NETWORK_ADDRESS_ACCESS_POINT.ACCESS_POINT_ID%TYPE,
  p_network_address_id IN NETWORK_ADDRESS_ACCESS_POINT.NETWORK_ADDRESS_ID%TYPE,
  p_from_date          IN NETWORK_ADDRESS_ACCESS_POINT.FROM_DATE%TYPE DEFAULT NULL,
  p_to_date            IN NETWORK_ADDRESS_ACCESS_POINT.TO_DATE%TYPE DEFAULT NULL
);

/****************************************************************************
<header>
  <name>             	procedure Insert_Interval
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

	<version>			1.0.2	4.8.2004     Jaroslav Holub
								fixed for time difference between client and server,
								date should be null and it means sysdate
	</version>
   <version>          	1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	Procedure first checks, whether p_start_date is greater
                      than start date of the last interval for given series.
                      If it is not, then procedure ends with error c_DATE_OVERLAP.
                      If check passed successfully, procedure inserts interval
                      with given access point id and network address.

  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_access_point_id - IN - value for ACCESS_POINT_ID
                      p_network_address_id - IN - value for NETWORK_ADDRESS_ID
                      p_link_type_code - IN - value for LINK_TYPE_CODE
                      p_from_date - IN - value for FROM_DATE
                      p_to_date - IN - value for FROM_DATE
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Insert_Interval (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_access_point_id         IN     NETWORK_ADDRESS_ACCESS_POINT.ACCESS_POINT_ID%TYPE,
    p_network_address_id      IN     NETWORK_ADDRESS_ACCESS_POINT.NETWORK_ADDRESS_ID%TYPE,
    p_link_type_code          IN     NETWORK_ADDRESS_ACCESS_POINT.LINK_TYPE_CODE%TYPE,
    p_from_date               IN     NETWORK_ADDRESS_ACCESS_POINT.FROM_DATE%TYPE,
    p_to_date                 IN     NETWORK_ADDRESS_ACCESS_POINT.TO_DATE%TYPE DEFAULT NULL,
    p_user_id_of_change       IN     NETWORK_ADDRESS_ACCESS_POINT.USER_ID_OF_CHANGE%TYPE
  );
/****************************************************************************
<header>
  <name>             	procedure Close_Interval
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>


	<version>			1.0.3	4.8.2004     Jaroslav Holub
								fixed for time difference between client and server,
								date should be null and it means sysdate
	</version>
   	<version>           1.0.2   5.12.2003 
                              	parameter p_from_date added
  	</version>
  	<version>           1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	Procedure first checks,  whether the end date of the interval
                      being closed is null or not. If it is not null, the procedure
                      ends with error c_DELETED.
                      Further procedure checks,  whether p_end_date is greater
                      then start_date of given interval. If it is not greater,
                      the procedure ends with error c_DATE_OVERLAP.
                      If all checks passed successfully, then procedure sets
                      end_date of given interval to value given by p_end_date
                      parameter.

  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_from_date - IN - value for set of the from (FROM_DATE)
                      p_access_point_id - IN - value for identification updating row (ACCESS_POINT_ID)
                      p_network_address_id - IN - value for identification updating row (NETWORK_ADDRESS_ID)
                      p_to_date - IN - value for set of the end (TO_DATE)
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Close_Interval (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_from_date               IN     NETWORK_ADDRESS_ACCESS_POINT.FROM_DATE%TYPE,
    p_access_point_id         IN     NETWORK_ADDRESS_ACCESS_POINT.ACCESS_POINT_ID%TYPE,
    p_network_address_id      IN     NETWORK_ADDRESS_ACCESS_POINT.NETWORK_ADDRESS_ID%TYPE,
    p_to_date                 IN     NETWORK_ADDRESS_ACCESS_POINT.TO_DATE%TYPE,
    p_user_id_of_change       IN     NETWORK_ADDRESS_ACCESS_POINT.USER_ID_OF_CHANGE%TYPE
  );

END RSIG_NET_ADDR_ACC_POINT;
/
