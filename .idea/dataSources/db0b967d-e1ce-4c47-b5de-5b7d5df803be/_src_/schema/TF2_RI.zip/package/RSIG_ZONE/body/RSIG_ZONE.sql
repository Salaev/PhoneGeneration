CREATE PACKAGE BODY RSIG_ZONE IS

---------------------------------------------
--     PROCEDURE Test_Row_For_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Row_For_Exist_And_Deleted(p_zone_id IN ZONE.ZONE_ID%TYPE) IS
  v_deleted ZONE.DELETED%TYPE;

BEGIN

  select DELETED into v_deleted from ZONE where ZONE_ID = p_zone_id;

  IF v_deleted IS NOT NULL THEN
    IF v_deleted < sysdate THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
    END IF;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Test_Row_For_Exist_And_Deleted;

---------------------------------------------
--     PROCEDURE Get_All_Zones
---------------------------------------------

PROCEDURE Get_All_Zones
(
  error_code      OUT NUMBER,
  p_validity_date IN ZONE_BASE_STATION.START_DATE%TYPE,
  p_result        OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source  VARCHAR2(60) := 'RSIG_ZONE.Get_All_Zones';
  v_validity_date DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  v_validity_date := nvl(p_validity_date, SYSDATE);

  /*    IF p_validity_date IS NULL THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
      END IF;
  */
  IF v_validity_date < RSIG_UTILS.c_MIN_DATE THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;

  OPEN p_result FOR
    select zo.ZONE_ID,
           zo.ZONE_CODE,
           zo.ZONE_NAME,
           no.NETWORK_OPERATOR_NAME
      from ZONE zo
      join NETWORK_OPERATOR no on no.NETWORK_OPERATOR_ID = zo.NETWORK_OPERATOR_ID
     where (zo.DELETED >= v_validity_date or zo.DELETED is null);

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_result FOR
        select error_code from dual;
    END;
END Get_All_Zones;

---------------------------------------------
--     PROCEDURE Get_Zones
---------------------------------------------

PROCEDURE Get_Zones
(
  error_code    OUT NUMBER,
  p_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_result      OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_ZONE.Get_Zones';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_operator_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  OPEN p_result FOR
    SELECT zo.ZONE_ID,
           zo.ZONE_CODE,
           zo.ZONE_NAME,
           no.NETWORK_OPERATOR_NAME
      from ZONE zo
      join NETWORK_OPERATOR no on no.NETWORK_OPERATOR_ID = zo.NETWORK_OPERATOR_ID
     where no.network_operator_id = p_operator_id
       and (zo.deleted is null or zo.deleted > sysdate);

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_result FOR
        select error_code from dual;
    END;
END Get_Zones;


---------------------------------------------
--     PROCEDURE Insert_Zone
---------------------------------------------

PROCEDURE Insert_Zone
(
  handle_tran           CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_zone_code           IN ZONE.ZONE_CODE%TYPE,
  p_zone_name           IN ZONE.ZONE_NAME%TYPE,
  p_zone_type_id        IN ZONE.zone_type_code%TYPE,
  p_network_operator_id IN ZONE.NETWORK_OPERATOR_ID%TYPE,
  p_user_id_of_change   IN ZONE.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_ZONE.Insert_Zone';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint insert_sim_card_type_a;
  END IF;

  BEGIN
    INSERT INTO ZONE
      (ZONE_ID,
       ZONE_CODE,
       ZONE_NAME,
       ZONE_TYPE_code,
       NETWORK_OPERATOR_ID,
       USER_ID_OF_CHANGE,
       DATE_OF_CHANGE)
    VALUES
      (S_ZONE.NEXTVAL,
       p_zone_code,
       p_zone_name,
       p_zone_type_id,
       p_network_operator_id,
       p_user_id_of_change,
       sysdate);

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      IF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_ZONE THEN
        -- Not unique zone name ---------------------
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_ZONE_NAME, 'Not unique zone name.');
      ELSIF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_ZONE_CODE THEN
        -- Not unique zone code ---------------------
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_ZONE_CODE, 'NOt unique zone code.');
      ELSE
        RAISE;
      END IF;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint insert_sim_card_type_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Insert_Zone;

---------------------------------------------
--     PROCEDURE Delete_Zone
---------------------------------------------

PROCEDURE Delete_Zone
(
  handle_tran         CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT NUMBER,
  p_zone_id           IN ZONE.ZONE_ID%TYPE,
  p_deleted           IN ZONE.DELETED%TYPE,
  p_user_id_of_change IN ZONE.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_ZONE.Delete_Zone';
  v_date         DATE;
  v_deleted      DATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint delete_zone;
  END IF;

  v_deleted := nvl(p_deleted, SYSDATE);

  Test_Row_For_Exist_And_Deleted(p_zone_id);

  select sysdate into v_date from dual;

  update ZONE
     set DELETED           = v_deleted,
         DATE_OF_CHANGE    = v_date,
         USER_ID_OF_CHANGE = p_user_id_of_change
   where ZONE_ID = p_zone_id;

  update ZONE_BASE_STATION
     set END_DATE = v_deleted
   where ZONE_ID = p_zone_id
     and (end_date > v_date or end_date is null);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint delete_zone;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Delete_Zone;

---------------------------------------------
--     PROCEDURE Update_Zone
---------------------------------------------

PROCEDURE Update_Zone
(
  handle_tran           CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_zone_id             IN ZONE.ZONE_ID%TYPE,
  p_zone_code           IN ZONE.ZONE_CODE%TYPE,
  p_zone_name           IN ZONE.ZONE_NAME%TYPE,
  p_network_operator_id IN ZONE.NETWORK_OPERATOR_ID%TYPE,
  p_user_id_of_change   IN ZONE.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_ZONE.Update_Zone';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint update_zone;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_zone_id);

  BEGIN
    UPDATE zone
       SET ZONE_NAME           = nvl(p_zone_name, ZONE_NAME),
           ZONE_CODE           = nvl(p_zone_code, ZONE_CODE),
           NETWORK_OPERATOR_ID = p_network_operator_id,
           DATE_OF_CHANGE      = sysdate,
           USER_ID_OF_CHANGE   = p_user_id_of_change
     WHERE ZONE_ID = p_zone_id;

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      IF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_ZONE THEN
        -- Not unique zone name ---------------------
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_ZONE_NAME, 'Not unique zone name.');
      ELSIF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_ZONE_CODE THEN
        -- Not unique zone code ---------------------
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_ZONE_CODE, 'NOt unique zone code.');
      ELSE
        RAISE;
      END IF;
  END;
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint update_zone;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Update_Zone;

---------------------------------------------
--     PROCEDURE Get_Zone_All
---------------------------------------------

PROCEDURE Get_Zone_All
(
  error_code    OUT NUMBER,
  p_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_result      OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_ZONE.Get_Zone_All';
  v_start_date DATE := SYSDATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_operator_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  OPEN p_result FOR
    SELECT zo.ZONE_ID,
           zo.ZONE_CODE,
           zo.ZONE_NAME,
           zt.ZONE_TYPE_CODE,
           zt.ZONE_TYPE_NAME,
           no.NETWORK_OPERATOR_NAME,
           zo.deleted,
           zo.date_of_change,
           u.user_name
      from ZONE zo
      join zone_type zt ON zt.ZONE_TYPE_code = zo.zone_type_code
           AND (zt.DELETED IS NULL OR zt.deleted > v_start_date)
      join NETWORK_OPERATOR no on no.NETWORK_OPERATOR_ID = zo.NETWORK_OPERATOR_ID
      join USERS u on u.user_id = zo.user_id_of_change
     where no.network_operator_id = p_operator_id;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_result FOR
        select error_code from dual;
    END;
END Get_Zone_All;


------------------------------------------------------------------------------------------------------------------------------
--  Get_Zone_Type
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Zone_Type(
  p_LA_ID                  IN  location_area.location_area_id%TYPE,
  p_BS_ID                  IN  base_station.base_station_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'RSIG_ZONE';
  v_procedure_name        VARCHAR2(30) := 'Get_Zone_Type';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(32767);
  v_sysdate               DATE:=SYSDATE;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  v_message:= 'Input parameters:' || chr(10) ||
                'p_LA_ID ' || p_LA_ID || chr(10) ||
                'p_BS_ID ' || p_BS_ID;

  -- check input parameters
  IF p_LA_ID IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;
---------------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
  SELECT zt.ZONE_TYPE_code,
         zt.ZONE_TYPE_NAME
  FROM Zone_Type zt
  WHERE zt.DELETED IS NULL
    AND zt.ZONE_TYPE_code NOT IN (SELECT zbs.zone_type_code
                                FROM Zone_Base_Station zbs
                                WHERE zbs.location_area_id=p_LA_ID
                                AND (zbs.base_station_id=p_BS_ID OR
                                     (zbs.base_station_id IS NULL AND p_BS_ID IS NULL))
                                      AND zbs.msc_id IS NULL
                                      AND zbs.network_operator_id IS NULL
                                AND v_sysdate BETWEEN zbs.start_date AND nvl(zbs.end_date,v_sysdate))
  ORDER BY zt.ZONE_TYPE_NAME;
---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    OPEN p_result_list FOR SELECT p_error_code FROM dual;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_Zone_Type;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Zone_of_Type
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Zone_of_Type(
  p_zone_type_id           IN  ZONE.ZONE_TYPE_code%TYPE,
  p_NO_id                  IN  network_operator.network_operator_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'RSIG_ZONE';
  v_procedure_name        VARCHAR2(30) := 'Get_Zone_of_Type';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(32767);
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  v_message:= 'Input parameters:' || chr(10) ||
                'p_zone_type_id ' || p_zone_type_id || chr(10) ||
                'p_NO_id ' || p_NO_id;

  -- check input parameters
  IF p_zone_type_id IS NULL OR p_NO_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;
---------------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
  SELECT z.zone_id,
         z.zone_name
  FROM ZONE z
  WHERE z.zone_type_code=p_zone_type_id
    AND z.deleted IS NULL
    AND z.network_operator_id IN (
      SELECT n.network_operator_id
      FROM Network_Operator n
      CONNECT BY PRIOR n.network_operator_id_upper=n.network_operator_id
      START WITH n.network_operator_id=p_NO_id)
  ORDER BY z.zone_name;
---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    OPEN p_result_list FOR SELECT p_error_code FROM dual;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_Zone_of_Type;

END RSIG_ZONE;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_ZONE.pkb,v 1.7 2003/12/22 13:04:18 rhejduk Exp $
/
