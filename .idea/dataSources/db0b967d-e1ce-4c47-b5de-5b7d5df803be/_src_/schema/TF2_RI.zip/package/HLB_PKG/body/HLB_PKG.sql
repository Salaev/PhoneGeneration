CREATE package body hlb_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  c_no_value_null_number         constant number := null;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure dbg_ct_host_lac_bs(p_coll ct_host_lac_bs, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(util_pkg.c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(util_pkg.c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(util_pkg.c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(util_pkg.c_msg_v_i || v_i || util_pkg.c_msg_delim02 
            || ' record_id' || util_pkg.c_msg_delim01 || p_coll(v_i).record_id
            || ' host_id' || util_pkg.c_msg_delim01 || p_coll(v_i).host_id
            || ' host_code' || util_pkg.c_msg_delim01 || p_coll(v_i).host_code
            || ' host_code2' || util_pkg.c_msg_delim01 || p_coll(v_i).host_code2
            || ' location_area_id' || util_pkg.c_msg_delim01 || p_coll(v_i).location_area_id
            || ' location_area_code' || util_pkg.c_msg_delim01 || p_coll(v_i).location_area_code
            || ' location_area_code2' || util_pkg.c_msg_delim01 || p_coll(v_i).location_area_code2
            || ' base_station_id' || util_pkg.c_msg_delim01 || p_coll(v_i).base_station_id
            || ' base_station_code' || util_pkg.c_msg_delim01 || p_coll(v_i).base_station_code
            || ' base_station_code2' || util_pkg.c_msg_delim01 || p_coll(v_i).base_station_code2
            || ' validity_date' || util_pkg.c_msg_delim01 || util_pkg.date_to_char(p_coll(v_i).validity_date)
            || ' value_id1' || util_pkg.c_msg_delim01 || p_coll(v_i).value_id1
            || ' value_code1' || util_pkg.c_msg_delim01 || p_coll(v_i).value_code1
            || ' value_id2' || util_pkg.c_msg_delim01 || p_coll(v_i).value_id2
            || ' value_code2' || util_pkg.c_msg_delim01 || p_coll(v_i).value_code2
            || ' rnum' || util_pkg.c_msg_delim01 || p_coll(v_i).rnum);
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_host_for_host_lac_bs(p_coll ct_host_lac_bs, p_trim_empty boolean) return ct_host_lac_bs
is
  v_res ct_host_lac_bs;
  v_sysdate date := sysdate;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_host_nl_limit number;
begin
  ------------------------------
  v_host_nl_limit := install_pkg.nnget_option_num(c_opt_HOST_nl_limit, c_default_HOST_nl_limit);
  ------------------------------
  if util_ri.get_count_ct_host_lac_bs(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  if v_host_nl_limit < util_ri.get_count_ct_host_lac_bs(p_coll)
  then
    ------------------------------
    select /*+ ordered use_hash(b zz) full(b)*/
    ot_host_lac_bs
    (
      record_id => b.record_id,
      host_id => zz.host_id,
      host_code => b.host_code,
      host_code2 => zz.host_code2,
      location_area_id => b.location_area_id,
      location_area_code => b.location_area_code,
      location_area_code2 => b.location_area_code2,
      base_station_id => b.base_station_id,
      base_station_code => b.base_station_code,
      base_station_code2 => b.base_station_code2,
      validity_date => b.validity_date,
      value_id1 => b.value_id1,
      value_code1 => b.value_code1,
      value_id2 => b.value_id2,
      value_code2 => b.value_code2,
      rnum => b.rnum
    )
    bulk collect into v_res
    from
      ( select q.*, rownum rn from table(p_coll) q) b,
      (
        select /*+ ordered use_hash(t z) full(t) full(z)*/
          z.host_id,
          z.host_code host_code2,
          t.rn
          from (select q.*, rownum rn from table(p_coll) q) t, host z
          where 1 = 1
          and t.host_code = z.host_code
          and (nvl(t.validity_date, v_sysdate) < z.deleted or z.deleted is null)
        union
        select /*+ full(t)*/
          to_number(null) host_id,
          to_char(null) host_code2,
          t.rn
          from (select q.*, rownum rn from table(p_coll) q) t
          where 1 = 1
      ) zz
    where 1 = 1
    and b.rn = zz.rn(+)
    and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(zz.host_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    order by b.rn, zz.host_id
    ;
    ------------------------------
  else
    ------------------------------
    select /*+ ordered use_hash(b zz) full(b)*/
    ot_host_lac_bs
    (
      record_id => b.record_id,
      host_id => zz.host_id,
      host_code => b.host_code,
      host_code2 => zz.host_code2,
      location_area_id => b.location_area_id,
      location_area_code => b.location_area_code,
      location_area_code2 => b.location_area_code2,
      base_station_id => b.base_station_id,
      base_station_code => b.base_station_code,
      base_station_code2 => b.base_station_code2,
      validity_date => b.validity_date,
      value_id1 => b.value_id1,
      value_code1 => b.value_code1,
      value_id2 => b.value_id2,
      value_code2 => b.value_code2,
      rnum => b.rnum
    )
    bulk collect into v_res
    from
      ( select q.*, rownum rn from table(p_coll) q) b,
      (
        select /*+ ordered use_nl(t z) full(t) index(z UK_HOST_CODE)*/
          z.host_id,
          z.host_code host_code2,
          t.rn
          from (select q.*, rownum rn from table(p_coll) q) t, host z
          where 1 = 1
          and t.host_code = z.host_code
          and (nvl(t.validity_date, v_sysdate) < z.deleted or z.deleted is null)
        union
        select /*+ full(t)*/
          to_number(null) host_id,
          to_char(null) host_code2,
          t.rn
          from (select q.*, rownum rn from table(p_coll) q) t
          where 1 = 1
      ) zz
    where 1 = 1
    and b.rn = zz.rn(+)
    and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(zz.host_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    order by b.rn, zz.host_id
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_la_for_host_lac_bs(p_coll ct_host_lac_bs, p_trim_empty boolean) return ct_host_lac_bs
is
  v_res ct_host_lac_bs;
  v_sysdate date := sysdate;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_la_nl_limit number;
begin
  ------------------------------
  v_la_nl_limit := install_pkg.nnget_option_num(c_opt_LA_nl_limit, c_default_LA_nl_limit);
  ------------------------------
  if util_ri.get_count_ct_host_lac_bs(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  if v_la_nl_limit < util_ri.get_count_ct_host_lac_bs(p_coll)
  then
    ------------------------------
    select /*+ ordered use_hash(b zz) full(b)*/
    ot_host_lac_bs
    (
      record_id => b.record_id,
      host_id => b.host_id,
      host_code => b.host_code,
      host_code2 => b.host_code2,
      location_area_id => zz.location_area_id,
      location_area_code => b.location_area_code,
      location_area_code2 => zz.location_area_code2,
      base_station_id => b.base_station_id,
      base_station_code => b.base_station_code,
      base_station_code2 => b.base_station_code2,
      validity_date => b.validity_date,
      value_id1 => b.value_id1,
      value_code1 => b.value_code1,
      value_id2 => b.value_id2,
      value_code2 => b.value_code2,
      rnum => b.rnum
    )
    bulk collect into v_res
    from
      ( select q.*, rownum rn from table(p_coll) q) b,
      (
        select /*+ ordered use_hash(z t) full(z) full(t)*/
          z.location_area_id,
          z.location_area_code location_area_code2,
          t.rn
          from location_area z, (select q.*, rownum rn from table(p_coll) q) t
          where 1 = 1
          and t.host_id = z.host_id
          and t.location_area_code like z.location_area_code
          and (nvl(t.validity_date, v_sysdate) < z.deleted or z.deleted is null)
        union
        select /*+ full(t)*/
          to_number(null) location_area_id,
          to_char(null) location_area_code2,
          t.rn
          from (select q.*, rownum rn from table(p_coll) q) t
          where 1 = 1
        ) zz
    where 1 = 1
    and b.rn = zz.rn(+)
    and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(zz.location_area_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    order by b.rn, zz.location_area_id
    ;
    ------------------------------
  else
    ------------------------------
    select /*+ ordered use_hash(b zz) full(b)*/
    ot_host_lac_bs
    (
      record_id => b.record_id,
      host_id => b.host_id,
      host_code => b.host_code,
      host_code2 => b.host_code2,
      location_area_id => zz.location_area_id,
      location_area_code => b.location_area_code,
      location_area_code2 => zz.location_area_code2,
      base_station_id => b.base_station_id,
      base_station_code => b.base_station_code,
      base_station_code2 => b.base_station_code2,
      validity_date => b.validity_date,
      value_id1 => b.value_id1,
      value_code1 => b.value_code1,
      value_id2 => b.value_id2,
      value_code2 => b.value_code2,
      rnum => b.rnum
    )
    bulk collect into v_res
    from
      ( select q.*, rownum rn from table(p_coll) q) b,
      (
        select /*+ ordered use_nl(t z) full(t) index(z UK_LOCATION_AREA_CODE)*/
          z.location_area_id,
          z.location_area_code location_area_code2,
          t.rn
          from (select q.*, rownum rn from table(p_coll) q) t, location_area z
          where 1 = 1
          and t.host_id = z.host_id
          and t.location_area_code = z.location_area_code
          and (nvl(t.validity_date, v_sysdate) < z.deleted or z.deleted is null)
        union
        select /*+ ordered use_hash(z t) full(z) full(t)*/
          z.location_area_id,
          z.location_area_code location_area_code2,
          t.rn
          from location_area z, (select q.*, rownum rn from table(p_coll) q) t
          where 1 = 1
          and z.generalization = util_ri.c_yes
          and t.host_id = z.host_id
          and t.location_area_code like z.location_area_code
          and (nvl(t.validity_date, v_sysdate) < z.deleted or z.deleted is null)
        union
        select /*+ full(t)*/
          to_number(null) location_area_id,
          to_char(null) location_area_code2,
          t.rn
          from (select q.*, rownum rn from table(p_coll) q) t
          where 1 = 1
        ) zz
    where 1 = 1
    and b.rn = zz.rn(+)
    and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(zz.location_area_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    order by b.rn, zz.location_area_id
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_bs_for_host_lac_bs(p_coll ct_host_lac_bs, p_trim_empty boolean) return ct_host_lac_bs
is
  v_res ct_host_lac_bs;
  v_sysdate date := sysdate;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_bs_nl_limit number;
begin
  ------------------------------
  v_bs_nl_limit := install_pkg.nnget_option_num(c_opt_BS_nl_limit, c_default_BS_nl_limit);
  ------------------------------
  if util_ri.get_count_ct_host_lac_bs(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  if v_bs_nl_limit < util_ri.get_count_ct_host_lac_bs(p_coll)
  then
    ------------------------------
    select /*+ ordered use_hash(b zz) full(b)*/
    ot_host_lac_bs
    (
      record_id => b.record_id,
      host_id => b.host_id,
      host_code => b.host_code,
      host_code2 => b.host_code2,
      location_area_id => b.location_area_id,
      location_area_code => b.location_area_code,
      location_area_code2 => b.location_area_code2,
      base_station_id => zz.base_station_id,
      base_station_code => b.base_station_code,
      base_station_code2 => zz.base_station_code2,
      validity_date => b.validity_date,
      value_id1 => b.value_id1,
      value_code1 => b.value_code1,
      value_id2 => b.value_id2,
      value_code2 => b.value_code2,
      rnum => b.rnum
    )
    bulk collect into v_res
    from
      ( select q.*, rownum rn from table(p_coll) q) b,
      ( 
        select /*+ ordered use_hash(z t) full(z) full(t)*/
          z.base_station_id,
          z.base_station_code base_station_code2,
          t.rn
          from base_station z, (select q.*, rownum rn from table(p_coll) q) t
          where 1 = 1
          and t.location_area_id = z.location_area_id
          and t.base_station_code like z.base_station_code
          and (nvl(t.validity_date, v_sysdate) < z.deleted or z.deleted is null)
        union
        select /*+ full(t)*/
          to_number(null) base_station_id,
          to_char(null) base_station_code2,
          t.rn
          from (select q.*, rownum rn from table(p_coll) q) t
          where 1 = 1
      ) zz
    where 1 = 1
    and b.rn = zz.rn(+)
    and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(zz.base_station_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    order by b.rn, zz.base_station_id
    ;
    ------------------------------
  else
    ------------------------------
    select /*+ ordered use_hash(b zz) full(b)*/
    ot_host_lac_bs
    (
      record_id => b.record_id,
      host_id => b.host_id,
      host_code => b.host_code,
      host_code2 => b.host_code2,
      location_area_id => b.location_area_id,
      location_area_code => b.location_area_code,
      location_area_code2 => b.location_area_code2,
      base_station_id => zz.base_station_id,
      base_station_code => b.base_station_code,
      base_station_code2 => zz.base_station_code2,
      validity_date => b.validity_date,
      value_id1 => b.value_id1,
      value_code1 => b.value_code1,
      value_id2 => b.value_id2,
      value_code2 => b.value_code2,
      rnum => b.rnum
    )
    bulk collect into v_res
    from
      ( select q.*, rownum rn from table(p_coll) q) b,
      ( 
        select /*+ ordered use_nl(t z) full(t) index(z UK_BASE_STATION_CODE)*/
          z.base_station_id,
          z.base_station_code base_station_code2,
          t.rn
          from (select q.*, rownum rn from table(p_coll) q) t, base_station z
          where 1 = 1
          and t.location_area_id = z.location_area_id
          and t.base_station_code = z.base_station_code
          and (nvl(t.validity_date, v_sysdate) < z.deleted or z.deleted is null)
        union
        select /*+ ordered use_hash(z t) full(z) full(t)*/
          z.base_station_id,
          z.base_station_code base_station_code2,
          t.rn
          from base_station z, (select q.*, rownum rn from table(p_coll) q) t
          where 1 = 1
          and z.generalization = util_ri.c_yes
          and t.location_area_id = z.location_area_id
          and t.base_station_code like z.base_station_code
          and (nvl(t.validity_date, v_sysdate) < z.deleted or z.deleted is null)
        union
        select /*+ full(t)*/
          to_number(null) base_station_id,
          to_char(null) base_station_code2,
          t.rn
          from (select q.*, rownum rn from table(p_coll) q) t
          where 1 = 1
      ) zz
    where 1 = 1
    and b.rn = zz.rn(+)
    and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(zz.base_station_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    order by b.rn, zz.base_station_id
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_zbs_for_host_lac_bs(p_coll ct_host_lac_bs, p_trim_empty boolean) return ct_host_lac_bs
is
  v_res ct_host_lac_bs;
  v_sysdate date := sysdate;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  if util_ri.get_count_ct_host_lac_bs(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(b zz) full(b)*/
  ot_host_lac_bs
  (
    record_id => b.record_id,
    host_id => b.host_id,
    host_code => b.host_code,
    host_code2 => b.host_code2,
    location_area_id => b.location_area_id,
    location_area_code => b.location_area_code,
    location_area_code2 => b.location_area_code2,
    base_station_id => b.base_station_id,
    base_station_code => b.base_station_code,
    base_station_code2 => b.base_station_code2,
    validity_date => b.validity_date,
    value_id1 => b.value_id1,
    value_code1 => zz.zone_code,
    value_id2 => b.value_id2,
    value_code2 => zz.zone_type_code,
    rnum => b.rnum
  )
  bulk collect into v_res
  from
    ( select q.*, rownum rn from table(p_coll) q) b,
    ( 
      select /*+ ordered driving_site(z1) use_nl(t z1 z2) use_hash(z3) full(t) index(z1 UK_ZONE_BASE_STATION) index(z2 PK_ZONE) full(z3)*/
        z2.zone_code,
        z3.zone_type_code,
        t.rn
        from (select q.*, rownum rn from table(p_coll) q) t, zone_base_station z1, zone z2, zone_type z3
        where 1 = 1
        and (z1.location_area_id = t.location_area_id or (z1.location_area_id is null and t.location_area_id is null))
        and (z1.base_station_id = t.base_station_id or (z1.base_station_id is null and t.base_station_id is null))
        and nvl(t.validity_date, v_sysdate) between z1.start_date and nvl(z1.end_date, nvl(t.validity_date, v_sysdate))
        and z1.zone_id=z2.zone_id
        and (nvl(t.validity_date, v_sysdate) < z2.deleted or z2.deleted is null)
        and z2.zone_type_code=z3.zone_type_code
        and (nvl(t.validity_date, v_sysdate) < z3.deleted or z3.deleted is null)
    ) zz
  where 1 = 1
  and b.rn = zz.rn(+)
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(zz.zone_code, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by b.rn, zz.zone_code
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_roaming_for_host_lac_bs
(
  p_home_no_id ct_number,
  p_neighbour_no_id ct_number,
  p_coll ct_host_lac_bs,
  p_trim_empty boolean
) return ct_host_lac_bs
is
  v_res ct_host_lac_bs;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  if util_ri.get_count_ct_host_lac_bs(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(b zz) full(b)*/
  ot_host_lac_bs
  (
    record_id => b.record_id,
    host_id => b.host_id,
    host_code => b.host_code,
    host_code2 => b.host_code2,
    location_area_id => b.location_area_id,
    location_area_code => b.location_area_code,
    location_area_code2 => b.location_area_code2,
    base_station_id => b.base_station_id,
    base_station_code => b.base_station_code,
    base_station_code2 => b.base_station_code2,
    validity_date => b.validity_date,
    value_id1 => zz.roaming_type_code,
    value_code1 => b.value_code1,
    value_id2 => b.value_id2,
    value_code2 => b.value_code2,
    rnum => b.rnum
  )
  bulk collect into v_res
  from
    ( select q.*, rownum rn from table(p_coll) q) b,
    ( 
      select /*+ ordered driving_site(z1) use_hash(q1 q2 q3) use_nl(z1 z2) full(q1) full(q2) full(q3) index(z1 UK_NETWORK_OPERATOR_NEIGHBOURS) index(z2 UI_NO_NEIGH_RD_ID_ROAM_TYPE)*/
        z1.roaming_type_code + nvl(z2.ext_roaming_type_code, 0) roaming_type_code,
        q3.rn
        from
          (select column_value network_operator_id, rownum rn from table(p_home_no_id)) q1,
          (select column_value neighbouring_operator_id, rownum rn from table(p_neighbour_no_id)) q2,
          (select t.*, rownum rn from table(p_coll) t) q3,
          network_operator_neighbours z1,
          (select roaming_definition_id, SUM(ext_roaming_type_code) ext_roaming_type_code
               from network_operator_neighb_ext group by roaming_definition_id) z2
        where 1 = 1
        and q2.rn = q1.rn
        and q3.rnum = q1.rn
        and z1.network_operator_id = q1.network_operator_id
        and z1.neighbouring_operator_id = q2.neighbouring_operator_id
        and (z1.location_area_id = q3.location_area_id or (z1.location_area_id is null and q3.location_area_id is null))
        and (z1.base_station_id = q3.base_station_id or (z1.base_station_id is null and q3.base_station_id is null))
        and q3.validity_date between z1.start_date and nvl(z1.end_date, q3.validity_date)
        and z2.roaming_definition_id(+)=z1.roaming_definition_id
    ) zz
  where 1 = 1
  and b.rn = zz.rn(+)
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(zz.roaming_type_code, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by b.rn, zz.roaming_type_code
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_zone_result(p_base_coll ct_host_lac_bs, p_coll ct_host_lac_bs, p_trim_empty boolean) return ct_host_lac_bs
is
  v_res ct_host_lac_bs;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  if util_ri.get_count_ct_host_lac_bs(p_base_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(b zz) full(b)*/
  ot_host_lac_bs
  (
    record_id => b.record_id,
    host_id => zz.host_id,
    host_code => b.host_code,
    host_code2 => zz.host_code2,
    location_area_id => zz.location_area_id,
    location_area_code => b.location_area_code,
    location_area_code2 => zz.location_area_code2,
    base_station_id => zz.base_station_id,
    base_station_code => b.base_station_code,
    base_station_code2 => zz.base_station_code2,
    validity_date => b.validity_date,
    value_id1 => zz.value_id1,
    value_code1 => zz.value_code1,
    value_id2 => zz.value_id2,
    value_code2 => zz.value_code2,
    rnum => b.rnum
  )
  bulk collect into v_res
  from
    ( select q.*, rownum rn from table(p_base_coll) q) b,
    ( 
      select
        zzz.*
        from
          (
            select
              zzzz.*,
              row_number() over (
                partition by zzzz.value_code2, zzzz.rnum
                order by zzzz.msc_priority, zzzz.lac_priority, zzzz.bsc_priority, zzzz.msc_unlikeness, zzzz.lac_unlikeness, zzzz.bsc_unlikeness
              ) priority
              from
                (
                  select /*+ full(t)*/
                    t.*,
                    decode(t.host_code2, null, 3, t.host_code, 1, 2) msc_priority,
                    decode(t.location_area_code2, null, 3, t.location_area_code, 1, 2) lac_priority,
                    decode(t.base_station_code2, null, 3, t.base_station_code, 1, 2) bsc_priority,
                    (length(t.host_code) - length(translate(t.host_code2, 'A_%', 'A'))) msc_unlikeness,
                    (length(t.location_area_code) - length(translate(t.base_station_code2, 'A_%', 'A'))) lac_unlikeness,
                    (length(t.base_station_code) - length(translate(t.base_station_code2, 'A_%', 'A'))) bsc_unlikeness
                    from (select q.* from table(p_coll) q) t
                    where 1 = 1
                ) zzzz
            ) zzz
        where 1 = 1
        and zzz.priority = 1
    ) zz
  where 1 = 1
  and b.rnum = zz.rnum(+)
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(zz.value_code1, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by b.rn, zz.host_id, zz.location_area_id, zz.base_station_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_roaming_result(p_base_coll ct_host_lac_bs, p_coll ct_host_lac_bs, p_trim_empty boolean) return ct_host_lac_bs
is
  v_res ct_host_lac_bs;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  if util_ri.get_count_ct_host_lac_bs(p_base_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  select /*+ ordered use_hash(b zz) full(b)*/
  ot_host_lac_bs
  (
    record_id => b.record_id,
    host_id => zz.host_id,
    host_code => b.host_code,
    host_code2 => zz.host_code2,
    location_area_id => zz.location_area_id,
    location_area_code => b.location_area_code,
    location_area_code2 => zz.location_area_code2,
    base_station_id => zz.base_station_id,
    base_station_code => b.base_station_code,
    base_station_code2 => zz.base_station_code2,
    validity_date => b.validity_date,
    value_id1 => zz.value_id1,
    value_code1 => zz.value_code1,
    value_id2 => zz.value_id2,
    value_code2 => zz.value_code2,
    rnum => b.rnum
  )
  bulk collect into v_res
  from
    ( select q.*, rownum rn from table(p_base_coll) q) b,
    ( 
      select
        zzz.*
        from
          (
            select
              zzzz.*,
              row_number() over (partition by zzzz.rnum order by zzzz.msc_priority, zzzz.lac_priority, zzzz.bsc_priority, zzzz.msc_unlikeness, zzzz.lac_unlikeness, zzzz.bsc_unlikeness) priority
              from
                (
                  select /*+ full(t)*/
                    t.*,
                    decode(t.host_code2, null, 3, t.host_code, 1, 2) msc_priority,
                    decode(t.location_area_code2, null, 3, t.location_area_code, 1, 2) lac_priority,
                    decode(t.base_station_code2, null, 3, t.base_station_code, 1, 2) bsc_priority,
                    (length(t.host_code) - length(translate(t.host_code2, 'A_%', 'A'))) msc_unlikeness,
                    (length(t.location_area_code) - length(translate(t.base_station_code2, 'A_%', 'A'))) lac_unlikeness,
                    (length(t.base_station_code) - length(translate(t.base_station_code2, 'A_%', 'A'))) bsc_unlikeness
                    from (select q.* from table(p_coll) q) t
                    where 1 = 1
                ) zzzz
            ) zzz
        where 1 = 1
        and zzz.priority = 1
    ) zz
  where 1 = 1
  and b.rnum = zz.rnum(+)
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(zz.value_id1, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by b.rn, zz.host_id, zz.location_area_id, zz.base_station_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_roaming_by_msc_lac_cell_i
(
  p_home_no_id ct_number,
  p_neighbour_no_id ct_number,
  p_msc ct_varchar_s,
  p_lac ct_varchar_s,
  p_cell ct_varchar_s,
  p_validity_date ct_date
) return ct_number
is
  v_total_count number;
  v_host_lac_bs ct_host_lac_bs;
  v_res_tmp1 ct_host_lac_bs;
  v_res ct_number;
begin
  ------------------------------
  v_total_count := util_pkg.get_count_ct_number(p_home_no_id);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_total_count <> util_pkg.get_count_ct_number(p_neighbour_no_id), 'p_home_no_id.count <> p_neighbour_no_id.count');
  util_pkg.XCheck_Cond_Invalid(v_total_count <> util_pkg.get_count_ct_varchar_s(p_msc), 'p_home_no_id.count <> p_msc.count');
  util_pkg.XCheck_Cond_Invalid(v_total_count <> util_pkg.get_count_ct_varchar_s(p_lac), 'p_home_no_id.count <> p_lac.count');
  util_pkg.XCheck_Cond_Invalid(v_total_count <> util_pkg.get_count_ct_varchar_s(p_cell), 'p_home_no_id.count <> p_cell.count');
  util_pkg.XCheck_Cond_Invalid(v_total_count <> util_pkg.get_count_ct_date(p_validity_date), 'p_home_no_id.count <> p_validity_date.count');
  ------------------------------
  select /*+ ordered use_hash(q1 q2 q3 q4) full(q1) full(q2) full(q3) full(q4)*/
    ot_host_lac_bs
    (
      record_id => q1.rn,
      host_id => null,
      host_code => q1.msc,
      host_code2 => null,
      location_area_id => null,
      location_area_code => q2.lac,
      location_area_code2 => null,
      base_station_id => null,
      base_station_code => q3.cell,
      base_station_code2 => null,
      validity_date => q4.validity_date,
      value_id1 => null,
      value_code1 => null,
      value_id2 => null,
      value_code2 => null,
      rnum => q1.rn
    )
  bulk collect into v_host_lac_bs
  from
    (select column_value msc, rownum rn from table(p_msc)) q1,
    (select column_value lac, rownum rn from table(p_lac)) q2,
    (select column_value cell, rownum rn from table(p_cell)) q3,
    (select column_value validity_date, rownum rn from table(p_validity_date)) q4
  where 1 = 1
    and q2.rn = q1.rn
    and q3.rn = q1.rn
    and q4.rn = q1.rn
  order by
    q1.rn,
    q1.msc,
    q2.lac,
    q3.cell
  ;
  ------------------------------
  v_res_tmp1 := get_host_for_host_lac_bs(v_host_lac_bs, true);
  --!_!dbg_ct_host_lac_bs(v_res_tmp1);
  ------------------------------
  v_res_tmp1 := get_la_for_host_lac_bs(v_res_tmp1, false);
  --!_!dbg_ct_host_lac_bs(v_res_tmp1);
  ------------------------------
  v_res_tmp1 := get_bs_for_host_lac_bs(v_res_tmp1, false);
  --!_!dbg_ct_host_lac_bs(v_res_tmp1);
  ------------------------------
  v_res_tmp1 := get_roaming_for_host_lac_bs
  (
    p_home_no_id => p_home_no_id,
    p_neighbour_no_id => p_neighbour_no_id,
    p_coll => v_res_tmp1,
    p_trim_empty => true
  );
  --!_!dbg_ct_host_lac_bs(v_res_tmp1);
  ------------------------------
  v_res_tmp1 := get_roaming_result(v_host_lac_bs, v_res_tmp1, false);
  --!_!dbg_ct_host_lac_bs(v_res_tmp1);
  ------------------------------
  select q.value_id1
    bulk collect into v_res
    from (select t.*, rownum rn from table(v_res_tmp1) t) q
    where 1 = 1
    order by q.rnum;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Get_Roaming_Type_i
(
  p_msisdn ct_varchar_s,
  p_validity_date ct_date,
  p_msc ct_varchar_s,
  p_lac ct_varchar_s,
  p_cell ct_varchar_s,
  p_mcc ct_varchar_s,
  p_mnc ct_varchar_s,
  p_roaming_type out ct_number,
  p_network_operator_id out ct_number,
  p_error_code out ct_number,
  p_error_message out ct_varchar
)
is
  v_main_count number;
  v_pivot ct_number;
  v_marks ct_number;
  v_positions ct_number;
  --
  v_na_ids ct_number;
  v_no_ids_home ct_number;
  v_no_ids_mcc_mnc ct_number;
  v_no_ids_msc ct_number;
  v_no_ids_call ct_number;
  v_call_roamings ct_number;
  --
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdn);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdn) != v_main_count, 'p_msisdn.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_validity_date) <> v_main_count, 'p_validity_date.count <> p_msisdn.count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msc) <> v_main_count, 'p_msc.count <> p_msisdn.count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_lac) <> v_main_count, 'p_lac.count <> p_msisdn.count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_cell) <> v_main_count, 'p_cell.count <> p_msisdn.count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_mcc) <> v_main_count, 'p_mcc.count <> p_msisdn.count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_mnc) <> v_main_count, 'p_mnc.count <> p_msisdn.count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdn, 'p_msisdn');
  util_pkg.XCheckP_FS_ct_date(p_validity_date, 'p_validity_date');
  util_pkg.XCheckP_FS_ct_varchar_s(p_msc, 'p_msc');
  ------------------------------
  ------------------------------
  p_roaming_type := util_pkg.make_ct_number(v_main_count, c_rt_international_roaming); --!_!
  --!_!p_network_operator_id := util_pkg.make_ct_number(v_main_count, c_no_value_null_number);
  ------------------------------
  util_ext_ri.setup_common_error(util_pkg.get_count_ct_varchar_s(p_msisdn), util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_code, p_error_message);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  ------------------------------
  v_na_ids := util_ri.get_na_id0(p_msisdn => p_msisdn, p_date => p_validity_date, p_trim_empty => false);
  ------------------------------
  v_no_ids_home := mnp_pkg.get_no_current_any0(p_na_id => v_na_ids, p_date => p_validity_date, p_trim_empty => false);
  ------------------------------
  v_no_ids_mcc_mnc := util_ri.get_no_by_mcc_mnc0(p_mcc, p_mnc, p_validity_date, false, true);
  v_no_ids_msc := util_ri.get_no_by_msc_mask0(p_msc, p_validity_date, false);
  v_no_ids_call := util_pkg.supplement_ct_number(p_vals => v_no_ids_mcc_mnc, p_supplement => v_no_ids_msc, p_trim_empty => false);
  ------------------------------
  ------------------------------
  v_marks := util_pkg.cmp_ct_number(v_no_ids_home, v_no_ids_call);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_roaming_type, c_rt_no_roaming, v_positions);
  ------------------------------
  ------------------------------
  v_call_roamings := get_roaming_by_msc_lac_cell_i
  (
    p_home_no_id => v_no_ids_home,
    p_neighbour_no_id => v_no_ids_call,
    p_msc => p_msc,
    p_lac => p_lac,
    p_cell => p_cell,
    p_validity_date => p_validity_date
  );
  ------------------------------
  p_roaming_type := util_pkg.supplement_ct_number(p_vals => v_call_roamings, p_supplement => p_roaming_type, p_trim_empty => false);
  ------------------------------
  ------------------------------
  --!_!reverse order of error setting to preserve more important
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_no_ids_call, c_no_value_null_number);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_roaming_type, c_no_value_null_number, v_positions);
  util_pkg.set_val_by_pos2_ct_number(p_error_code, c_ec_no_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_message, c_em_no_not_found, v_positions);
  ------------------------------
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_no_ids_home, c_no_value_null_number);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_roaming_type, c_no_value_null_number, v_positions);
  util_pkg.set_val_by_pos2_ct_number(p_error_code, c_ec_home_no_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_message, c_em_home_no_not_found, v_positions);
  ------------------------------
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_na_ids, c_no_value_null_number);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_roaming_type, c_no_value_null_number, v_positions);
  util_pkg.set_val_by_pos2_ct_number(p_error_code, c_ec_home_no_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_message, c_em_home_no_not_found, v_positions);
  ------------------------------
  --!_!reverse order of error setting to preserve more important
  ------------------------------
  ------------------------------
  p_network_operator_id := v_no_ids_call;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
