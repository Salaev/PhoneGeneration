CREATE PACKAGE BODY RSIG_ACCESS_POINT_HOST IS

---------------------------------------------
--     PROCEDURE Is_Access_Point_Deleted
---------------------------------------------

PROCEDURE Is_Access_Point_Deleted(p_access_point_id IN ACCESS_POINT_HOST.ACCESS_POINT_ID%TYPE) IS
  v_pom NUMBER;
BEGIN
  SELECT 1
    INTO v_pom
    FROM sim_card
   WHERE ACCESS_POINT_ID = p_access_point_id
     AND deleted IS NOT NULL;
  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    NULL;
END Is_Access_Point_Deleted;

---------------------------------------------
--     PROCEDURE Is_Host_Deleted
---------------------------------------------

PROCEDURE Is_Host_Deleted(p_host_id IN HOST.HOST_ID%TYPE) IS
  v_pom NUMBER;
BEGIN
  SELECT 1
    INTO v_pom
    FROM HOST
   WHERE HOST_ID = p_host_id
     AND deleted IS NOT NULL;

  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    NULL;
END Is_Host_Deleted;

---------------------------------------------
--     PROCEDURE Is_Interval_Overlap
---------------------------------------------

PROCEDURE Is_Interval_Overlap
(
  p_access_point_id IN ACCESS_POINT_HOST.ACCESS_POINT_ID%TYPE,
  p_host_id         IN HOST.HOST_ID%TYPE,
  p_start_date      IN ACCESS_POINT_HOST.START_DATE%TYPE DEFAULT NULL,
  p_end_date        IN ACCESS_POINT_HOST.END_DATE%TYPE DEFAULT NULL
) IS
  v_aux INT;
BEGIN
  -- check start date
  IF p_start_date IS NOT NULL
     AND p_start_date < RSIG_UTILS.c_MIN_DATE THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;

  -- check end date
  IF p_end_date IS NOT NULL
     AND p_end_date < RSIG_UTILS.c_MIN_DATE THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;

  -- check interval overlapping
  SELECT 1.0
    INTO v_aux
    FROM access_point_host aph
    JOIN host h ON h.host_id = aph.host_id
   WHERE aph.access_point_id = p_access_point_id
     AND nvl(p_start_date, SYSDATE) <= nvl(aph.end_date, nvl(p_start_date, SYSDATE))
     AND nvl(p_end_date, aph.start_date) >= aph.start_date
     AND TRIM(h.host_type_code) = TRIM((SELECT ho.host_type_code FROM host ho WHERE ho.host_id = p_host_id));

  -- some overlapped interval exists => raise error
  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DATE_OVERLAP, '');

EXCEPTION
  WHEN no_data_found THEN
    NULL;
  WHEN too_many_rows THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DATE_OVERLAP, '');
END Is_Interval_Overlap;

---------------------------------------------
--     PROCEDURE Insert_Interval
---------------------------------------------

PROCEDURE Insert_Interval
(
  handle_tran         CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT NUMBER,
  p_access_point_id   IN ACCESS_POINT_HOST.ACCESS_POINT_ID%TYPE,
  p_host_id           IN ACCESS_POINT_HOST.HOST_ID%TYPE,
  p_start_date        IN ACCESS_POINT_HOST.START_DATE%TYPE,
  p_end_date          IN ACCESS_POINT_HOST.END_DATE%TYPE DEFAULT NULL,
  p_user_id_of_change IN ACCESS_POINT_HOST.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source      VARCHAR2(60) := 'RSIG_ACCESS_POINT_HOST.Insert_Interval';
  -- for handling NULL value in input start date
  v_start_date        DATE := nvl(p_start_date, SYSDATE);
  v_host_type         host.host_type_code%TYPE;
  v_host_exists       INT;
BEGIN
  -- debug start
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle tran
  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;
  -- set savepoint
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT insert_interval_a;
  END IF;

  v_start_date := nvl(p_start_date, SYSDATE);

  IF v_start_date IS NOT NULL
     AND p_end_date IS NOT NULL
     AND v_start_date > p_end_date THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_INTERVAL, '');
  END IF;

  Is_Interval_Overlap(p_access_point_id => p_access_point_id,
                      p_host_id         => p_host_id,
                      p_start_date      => v_start_date,
                      p_end_date        => p_end_date);

  Is_Access_Point_Deleted(p_access_point_id);

  Is_Host_Deleted(p_host_id);

  BEGIN
    SELECT h.host_type_code
    INTO v_host_type
    FROM host h
    WHERE h.host_id=p_host_id;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NO_DATA_FOUND, 'Host not found.');
  END;

  -- Relation to host can be created only for those types, which are already set for all series.
  SELECT COUNT(1)
  INTO v_host_exists
  FROM dual
  WHERE NOT EXISTS(SELECT 1
                   FROM sim_card sc
                   JOIN sim_series_host ssh ON ssh.sim_series_id=sc.sim_series_id
                   WHERE sc.access_point_id=p_access_point_id
                     AND ssh.host_type_code=TRIM(v_host_type)
                     AND v_start_date BETWEEN ssh.start_date AND nvl(ssh.end_date,v_start_date))
    AND EXISTS(SELECT 1
               FROM sim_card k
               WHERE k.access_point_id=p_access_point_id);

  IF v_host_exists = 1 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_HOST_SERIE_NOT_EXISTS, '');
  END IF;

  INSERT INTO ACCESS_POINT_HOST
    (ACCESS_POINT_ID,
     HOST_ID,
     START_DATE,
     END_DATE,
     DATE_OF_CHANGE,
     USER_ID_OF_CHANGE)
  VALUES
    (p_access_point_id,
     p_host_id,
     v_start_date,
     p_end_date,
     SYSDATE,
     p_user_id_of_change);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT insert_interval_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
END Insert_Interval;

---------------------------------------------
--     PROCEDURE Close_Interval
---------------------------------------------

PROCEDURE Close_Interval
(
  handle_tran         CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT NUMBER,
  p_start_date        IN ACCESS_POINT_HOST.START_DATE%TYPE,
  p_access_point_id   IN ACCESS_POINT_HOST.ACCESS_POINT_ID%TYPE,
  p_host_id           IN ACCESS_POINT_HOST.HOST_ID%TYPE,
  p_end_date          IN ACCESS_POINT_HOST.END_DATE%TYPE,
  p_user_id_of_change IN ACCESS_POINT_HOST.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_ACCESS_POINT_HOST.Close_Interval';
  v_end_date     DATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT close_interval_a;
  END IF;

  /*IF p_end_date IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;*/
  v_end_date := nvl(p_end_date, SYSDATE);

  Is_Interval_Overlap(p_access_point_id, NULL, v_end_date);

  DECLARE
    end_date_h ACCESS_POINT_HOST.END_DATE%TYPE;
  BEGIN
    SELECT END_DATE
      INTO end_date_h
      FROM ACCESS_POINT_HOST
     WHERE ACCESS_POINT_ID = p_access_point_id
       AND HOST_ID = p_host_id
       AND START_DATE = p_start_date
       AND END_DATE IS NULL;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
  END;

  UPDATE ACCESS_POINT_HOST
     SET END_DATE          = v_end_date,
         DATE_OF_CHANGE    = SYSDATE,
         USER_ID_OF_CHANGE = p_user_id_of_change
   WHERE ACCESS_POINT_ID = p_access_point_id
     AND HOST_ID = p_host_id
     AND START_DATE = p_start_date
     AND END_DATE IS NULL;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT close_interval_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
END Close_Interval;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Host_Relations
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Host_Relations(
  p_host_id                IN  host.host_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='RSIG_HOST.Get_Host_Relations';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

	IF p_host_id IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

-- start of the procedure body --------------------------------------------------------------------------------------------------

  OPEN result_list FOR
  SELECT *
  FROM(
  	SELECT RSIG_UTILS.c_PORT_TYPE AS RECORD_TYPE,
           ep.exchange_port_number,
           '' sn,
           h.host_name,
           aph.start_date,
           aph.end_date,
           u.user_name,
           aph.date_of_change
    FROM access_point_host aph
    JOIN exchange_port ep ON ep.access_point_id=aph.access_point_id
    JOIN host h ON h.host_id=ep.host_id
    JOIN users u ON u.user_id=aph.user_id_of_change
    WHERE aph.host_id=p_host_id
    UNION ALL
    SELECT RSIG_UTILS.c_SIMCARD_TYPE AS RECORD_TYPE,
           sc.imsi,
           sc.sn,
           h.host_name,
           aph.start_date,
           aph.end_date,
           u.user_name,
           aph.date_of_change
    FROM sim_card sc
    JOIN sim_series ss ON ss.sim_series_id=sc.sim_series_id
    JOIN access_point_host aph ON aph.access_point_id=sc.access_point_id
    JOIN host h ON h.host_id=ss.host_id
    JOIN users u ON u.user_id=aph.user_id_of_change
    WHERE aph.host_id=p_host_id
    UNION ALL
    SELECT RSIG_UTILS.c_SIMSERIE_TYPE AS RECORD_TYPE,
           ss.start_imsi_number || ' - ' || ss.end_imsi_number AS sim_serie_IMSI,
           '' sn,
           h.host_name,
           ssh.start_date,
           ssh.end_date,
           u.user_name,
           ssh.date_of_change
    FROM sim_series ss
    JOIN sim_series_host ssh ON ssh.sim_series_id=ss.sim_series_id
    JOIN host h ON h.host_id=ss.host_id
    JOIN users u ON u.user_id=ssh.user_id_of_change
    WHERE ssh.host_id=p_host_id
    ) k
  ORDER BY k.record_type,k.exchange_port_number,k.start_date;

  COMMIT;
-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
	  v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Host_Relations;

------------------------------------------------------------------------------------------------------------------------------
--  Get_AP_Relations
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_AP_Relations(
  p_access_point_id        IN  access_point.access_point_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
is
  c_unknown_user varchar2(50) := 'unknown user';
  ------------------------------
  v_sqlcode number;
  v_event_source varchar2(60) :='RSIG_ACCESS_POINT_HOST.Get_AP_Relations';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

	-- check handle_tran parameter
	IF p_access_point_id IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

-- start of the procedure body --------------------------------------------------------------------------------------------------

  OPEN result_list FOR
	SELECT ht.HOST_TYPE_NAME,
         h.host_name,
         aph.start_date,
         aph.end_date,
         nvl(util_ri.get_user_name(aph.user_id_of_change), c_unknown_user) user_name,
         aph.date_of_change,
         aph.host_id,
         aph.access_point_id
  FROM access_point_host aph
  JOIN host h ON h.host_id=aph.host_id
  JOIN host_type ht ON ht.HOST_TYPE_CODE=h.host_type_code
  WHERE aph.access_point_id=p_access_point_id
  ORDER BY aph.start_date;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
	  v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_AP_Relations;


END;
/
