CREATE package RSIG_STATISTICS is

  -- Author  : JHOLUB
  -- Created : 04/03/2004 14:33:38
  -- Purpose : For statistical purposes

 /****************************************************************************
  <header>
    <name>              package STATISTICS
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.7  04.10.2006   Petr Cepek
                        procedure Get_statistic updated
    </version>
    <version>       1.0.6   22.4.2005     Jaroslav Holub
                            RUN_STATISTICS - fixed payment desks, not count deleted.
    </version>
    <version>       1.0.5   17.5.2004     Jaroslav Holub
                            missing fill pay desk in main statistics, wrong fill of not - bind phone number
							base station count - count only through exchanges
    </version>
    <version>       1.0.4   11.5.2004     Jaroslav Holub
                               RUN_STATISTICS - changes for count only active records (which have deleted null or < p_rundate)
    </version>
    <version>           1.0.3   8.4.2004     Jaroslav Holub
                                changed for undelete
    </version>
    <version>			1.0.2	09.3.2004	  Jaroslav Holub
						phone number statistics - all numbers
    </version>
    <version>			1.0.1   04.3.2004     Jaroslav Holub
                        created first version
    </version>

    <Description>       package for statistical watching of NETWORK_OPERATOR
						DATA STRUCTURE - table STAT_MAIN  -	each row hold information about one operator and specified rundate(Net. op. name,
																number of location area, base stations, payment entrances, pay desks,
																child networks operators and zones.
											other tables (connected to STAT_MAIN through STAT_ID) holds specifical informations
												for rundate and network operator
											about:
												STATS_HOST			- number of hosts, one row for each type of host
												STATS_PHONE_NUMBER	- number of telephone number for each combination of SALABILITY CATEGORY,
																		PHONE NUMBER TYPE CODE and BIND(if phone number is connected to network address)
												STATS_PHONE_SERIE	- number of series ( row for phone serie type)
												STATS_SIM_CARD		- number of simcards (one row for combination of sim_card_status and bind)
												STATS_SIM_SERIE		- number of sim series (one row fro combination SIM SERIE STATUS and SIM CARD TYPE CODE)

										in tables is nop only actual statistic, but there is stored history for all network operators	and rundates for
											which is job executed.

						procedure RUN_STATISTICS 	- insert statistic (for suplied rundate) into all statistical tables
								  STATISTIC_JOB 	- call RUN_STATISTIC for sysdate, this procedure is for aoutomatic job running
								  GET_STATISTIC		- retrieve statistic data for specified type.
								  						1) get cursor for C_STATS_MAIN - there is information of net. op, and rundate (if NULL, get everything, if date is specified it gets data with exactly same date, or nearest smaller
														2) get STAT_ID from cursor for C_STATS_MAIN (for network operoator and rundate) and get other statistical information for host, sim cards ...
															(C_STATS_HOST, C_STATS_PHONE_NUMBER, C_STATS_PHONE_SERIE, C_STATS_SIM_CARD, C_STATS_SIM_SERIE)
    </Description>

    <Application>       Resource Inventory
    </Application>

  </header>
****************************************************************************/
--constants for procedure gets_stats -
  c_STATS_MAIN 				CONSTANT NUMBER(2) := 0;
  c_STATS_HOST 				CONSTANT NUMBER(2) := 1;
  c_STATS_PHONE_NUMBER 		CONSTANT NUMBER(2) := 2;
  c_STATS_PHONE_SERIE 		CONSTANT NUMBER(2) := 3;
  c_STATS_SIM_CARD 			CONSTANT NUMBER(2) := 4;
  c_STATS_SIM_SERIE 		CONSTANT NUMBER(2) := 5;

 /****************************************************************************
  <header>
    <name>              RUN_STATISTICS
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>       1.0.5   22.4.2005     Jaroslav Holub
                            fixed payment desks, not count deleted.
    </version>
    <version>       1.0.4   17.5.2004     Jaroslav Holub
                            missing fill pay desk in main statistics, wrong fill of not -bind phone number,
							base station count - count only through exchanges
    </version>
    <version>       1.0.3   11.5.2004     Jaroslav Holub
                                changes for count only active records (which have deleted null or < p_rundate)
    </version>
    <version>       1.0.3   8.4.2004     Jaroslav Holub
                                changed for undelete
    </version>
    <version>		1.0.2	09.3.2004	  Jaroslav Holub
							phone number statistics - all numbers
    </version>
    <version>		1.0.1   04.3.2004     Jaroslav Holub
                        	created first version
    </version>

    <Description>       run statistics

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>		p_rundate 		- 	date for statistics (NULL - take sysdate
    </Parameters>		result_list
  </header>
****************************************************************************/
  PROCEDURE RUN_STATISTICS (
	error_code				OUT	NUMBER,
	handle_tran				CHAR DEFAULT RSIG_UTILS.C_HANDLE_TRAN_Y,
	p_rundate				DATE
  );


/****************************************************************************
  <header>
    <name>              Get_statistic
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.2    04.10.2006   Petr Cepek
                        view sim_series_status changed for view ap_prod_status
    </version>
    <version>			      1.0.1	   09.3.2004	  Jaroslav Holub
                        		created first version
    </version>

    <Description>       get specified statistic cursor
                        usage: 1) get c_STATS_MAIN statistic
							          2) for each row of cursor (which we get for c_STATS_MAIN) all other statistic (by p_stats_id)
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>			p_statistic_type		- specified a type of statistics which is returned
														as result list
														should be (c_STATS_HOST,c_STATS_MAIN,
														c_STATS_PHONE_NUMBER, c_STATS_PHONE_SERIE ,
														c_STATS_SIM_CARD, c_STATS_SIM_SERIE)

							p_network_operator_id	- id of operator (used only for c_STATS_MAIN type)
							p_rundate				- date of (used only for c_STATS_MAIN type)
							p_stats_id				- id of statistic (should be NULL !ONLY! for c_STATS_MAIN)
							error_code				- returned err. code
							result_list				- returned cursor
    </Parameters>		result_list
  </header>
****************************************************************************/
  PROCEDURE Get_statistic(
	p_stats_id				IN	NUMBER,
	p_network_operator_id	IN  STATS_MAIN.NETWORK_OPERATOR_ID%TYPE,
	p_statistic_type 		IN 	NUMBER,
	p_rundate				IN	DATE,
	error_code				OUT NUMBER,
	result_list				OUT	sys_refcursor);


/****************************************************************************
  <header>
    <name>              Get_rundates
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>			1.0.0	17.3.2004	  Jaroslav Holub
                        created first version
    </version>

    <Description>

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>			p_start_date 			-start of interval, can be NULL,
							p_end_date				-end of interval, can be NULL,
							error_code				- returned err. code
							result_list				- returned cursor (rundate, amount of netw.operators statisticked ;-)
    </Parameters>
  </header>
****************************************************************************/
PROCEDURE Get_rundates(
	p_start_date 	IN	DATE,
	p_end_date		IN	DATE,
	error_code		OUT NUMBER,
	result_list 	OUT sys_refcursor
);

/****************************************************************************
  <header>
    <name>              STATISTIC_JOB
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>			1.0.0	22.3.2004	  Jaroslav Holub
                        created first version
    </version>

    <Description>       Procedure for implement automatic job run - calls RUN_STATISTIC and handle errors

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>
    </Parameters>
  </header>
****************************************************************************/
PROCEDURE STATISTIC_JOB;


end;
/
