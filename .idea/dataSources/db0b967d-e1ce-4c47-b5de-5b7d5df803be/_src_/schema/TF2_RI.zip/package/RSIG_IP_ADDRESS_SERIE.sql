CREATE PACKAGE RSIG_IP_ADDRESS_SERIE IS

  /****************************************************************************
<header>
  	<name>             	package RSIG_IP_ADDRESS_SERIE
  	</name>

  	<author>           	Jaroslav Holub STROM Telecom
  	</author>

    <version>           1.0.8    18.07.2006   Petr Cepek
                        procedure Delete_IP_address_serie updated

    </version>
    <versions           1.0.7    12.01.2006   Petr Cepek
                        procedure TEST_IP_SERIE_OVERLAP updated
    </version>
    <version>           1.0.6    1.12.2005    Petr Cepek
                        procedure Get_ip_address_serie update,
                        procedure Get_IP_Serie_Detail created
    </vesion>
  	<version>			      1.0.5	  3.8.2004     Jaroslav Holub
								        Delete_IP_address_serie,TEST_IP_SERIE_OVERLAP - fixed for time difference between client and server,
								        date should be null and it means sysdate
  	</version>
  	<version>           1.0.4   21.6.2004	Jaroslav Holub
                        Insert_IP_address_serie - fix checks of input params
  	</version>
  	<version> 			    1.0.3   17.6.2004		Jaroslav Holub
                      	Get_IP_ADDRESS_SERIE - fix paging/fix condition in output cursor
  	</version>
  	<version> 			    1.0.2   16.6.2004		Jaroslav Holub
                      	Insert_ip_address - added net_op_id
  	</version>
  	<version> 			    1.0.1   4.6.2004		Jaroslav Holub
                      			created first version
  	</version>

  <Description>      	package for table IP_ADDRESS_SERIE
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/

/****************************************************************************
  <header>
    <name>              procedure Insert_IP_address_serie
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.2   21.6.2004	Jaroslav Holub
                                fix checks of input params
    </version>
    <version>           1.0.1   16.6.2004	Jaroslav Holub
                                added net_op_id
    </version>
    <version>           1.0.0   28.5.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure insert IP address serie into table

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource Inventory
    </Application>

    <Parameters>
	p_ip_address_start		first ip adres in serie (varchar2 representation of ip address (123.43.12.10 or 0::4:fffd )
	p_ip_address_end		last ip addres in serie (could be NULL, but ammount of addresses has to be not null)
	p_amount_of_addresses 	amount of adddresses (could be NULL, but then Ip_address_end
	p_mask					mask of ip network (number 0 .. 32 for ipv4, and 0..128 for ipv6)
	p_ip_version			ip version (number 4 or 6)
	p_user_id_of_change		user id
	p_network_operator		netw. operator which owns IP serie
	p_ip_address_serie_id	OUT - id of created IP serie

	                    ,
                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Insert_IP_address_serie(
	p_ip_address_start		IN	IP_ADDRESS.IP_ADDRESS%TYPE,
	p_ip_address_end		IN	IP_ADDRESS.IP_ADDRESS%TYPE,
	p_amount_of_addresses 	IN  NUMBER,
	p_mask					IN  IP_ADDRESS_SERIE.MASK%TYPE,
	p_ip_version			IN  IP_ADDRESS_SERIE.IP_VERSION%TYPE,
	p_user_id_of_change		IN	IP_ADDRESS.USER_ID_OF_CHANGE%TYPE,
	p_network_operator_id	IN 	NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
	p_ip_address_serie_id	OUT IP_ADDRESS_SERIE.IP_ADDRESS_SERIE_ID%TYPE,
	handle_tran       	IN  CHAR,
	p_raise_error     	IN  CHAR,
	error_code        	OUT NUMBER,
	error_message     	OUT VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure TEST_IP_SERIE_OVERLAP
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.2    12.01.2006    Petr Cepek
                        error constant c_ORA_SERIE_BETWEEN_SERIES changed to c_ORA_IP_SERIE_OVEVERLAPED
    </version
	  <version>			      1.0.1	   3.8.2004     Jaroslav Holub
								        fixed for time difference between client and server,
								        date should be null and it means sysdate
	  </version>
    <version>           1.0.0   15.6.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure testing overlaping of series, if overlap -> raise app error

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
	p_ip_address_start	first ip address in serie
	p_ip_address_end	last ip address in serie
	p_ip_version		ip version
	p_test_date			date of testing
                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
procedure TEST_IP_SERIE_OVERLAP(
	p_ip_address_start	IN	IP_ADDRESS.IP_ADDRESS%TYPE,
	p_ip_address_end	IN	IP_ADDRESS.IP_ADDRESS%TYPE,
	p_ip_version		IN 	IP_ADDRESS_SERIE.IP_VERSION%TYPE,
	p_test_date			IN 	DATE,
	p_raise_error		IN  CHAR,
	error_code			OUT NUMBER,
	error_message		OUT VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Delete_IP_address_serie
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.2      18.07.2006    Petr Cepek
                        columns from network_address moved to ip_address
    </version>
	  <version>			      1.0.1	     3.8.2004     Jaroslav Holub
								        fixed for time difference between client and server,
								        date should be null and it means sysdate
	  </version>
    <version>           1.0.0      15.6.2004	Jaroslav Holub
                        created first version
    </version>

    <Description>       procedure marks IP_addresses and serie as deleted

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
                        p_ip_address_serie_id 	id of serie
						            p_user_id_of_change		id of user
						            p_date					date of deletion
                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
procedure Delete_IP_address_serie(

	p_ip_address_serie_id 	IN 	IP_ADDRESS_SERIE.IP_ADDRESS_SERIE_ID%TYPE,
	p_user_id_of_change		IN 	IP_ADDRESS_SERIE.USER_ID_OF_CHANGE%TYPE,
	p_date					IN 	DATE,
	handle_tran		IN  CHAR,
	p_raise_error	IN  CHAR,
	error_code		OUT NUMBER,
	error_message	OUT VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Get_ip_address_serie
    </name>

    <author>            Jaroslav Holub
    </author>

  <version>             1.0.3    1.12.2005   Petr Cepek
                        ordering added
  </version>
	<version> 			      1.0.2   17.6.2004		Jaroslav Holub
                      			fix paging/fix condition in output cursor
	</version>
    <version>           1.0.1   16.6.2004	Jaroslav Holub
                                added net_op_id
    </version>
    <version>           1.0.0   15.6.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure gets cursor of ip adress series,
						parametrized by id, mask, version
						cursor starts on id (or at the beginning if id is null)
						and show as many rows as specified in row_count (or all if NULL)
						(if you want to select oly one specified please fill ID and set row_count to 1)
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
	p_ip_address_serie_id 	id of serie from which we start selecting
	p_mask					mask
	p_ip_version			ip version
	p_show_deleted			if we show deleted records
	p_row_count				page size (number of rows for one select
	result_list				output cursor
                        ,
                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/

procedure Get_ip_address_serie(

	p_network_operator_id	IN 	NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
	p_ip_address_serie_id 	IN 	IP_ADDRESS_SERIE.IP_ADDRESS_SERIE_ID%TYPE,
	p_mask					IN 	IP_ADDRESS_SERIE.MASK%TYPE,
	p_ip_version			IN 	IP_ADDRESS_SERIE.IP_VERSION%TYPE,
	p_show_deleted			IN 	CHAR,
	p_row_count				IN 	NUMBER,
	result_list				OUT	sys_refcursor,
	p_raise_error	IN  CHAR,
	error_code		OUT NUMBER,
	error_message	OUT VARCHAR2
);

/****************************************************************************
<header>
  <name>            procedure Get_IP_Serie_Detail
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  1.12.2005 9:37:56  -  created
  </version>

  <Description>     Procedure returns details about appropriate IP serie.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_IP_Serie_Detail(
  p_IP_Serie_Id         IN   ip_address_serie.ip_address_serie_id%TYPE,
  p_raise_error         IN   CHAR,
  error_code            OUT  NUMBER,
  error_message         OUT  VARCHAR2,
  result_list           OUT  sys_refcursor
);


 end RSIG_IP_ADDRESS_SERIE;
/
