CREATE package util_ri is

----------------------------------!---------------------------------------------
  c_opt_na_host_id               constant varchar2(100) := 'NA_HOST_ID';

  c_opt_use_sim_imsi             constant varchar2(100) := 'Common.UseSimImsi';
  c_opt_use_sim_current_pa       constant varchar2(100) := 'Common.UseSimCurrentPersonalAccount';

----------------------------------!---------------------------------------------
  --!_!c_def_na_host_id               constant number := null;

  c_def_use_sim_imsi             constant boolean := true;
  c_def_use_sim_current_pa       constant boolean := true;

----------------------------------!---------------------------------------------
  c_lct_search_pkg               constant number := 1;

----------------------------------!---------------------------------------------
  c_dummy_date_shift             constant number := 1234;

  c_index_one                    constant number := 1;

  c_link_status_all              constant number := 0;
  c_link_status_free             constant number := 1;
  c_link_status_linked           constant number := 2;

  c_link2_status_free            constant number := 0;
  c_link2_status_linked          constant number := 1;
  --!_!c_link2_status_all             constant number := NULL;

  c_str_host_id_any              constant varchar2(100) := '%';
  c_rt_not_roaming               constant number := 0;

  c_any_value_num                constant number := -1;
  c_any_count                    constant number := c_any_value_num;

  c_list_delimiter               constant varchar2(1) := ',';

  c_NO                           constant varchar2(1) := 'N';
  c_YES                          constant varchar2(1) := 'Y';

  c_tran_no                      constant varchar2(1) := c_no;
  c_tran_yes                     constant varchar2(1) := c_yes;
  c_tran_savepoint               constant varchar2(1) := 'S';

  --!_! varchar2(1)
  c_NAAP_LINK_TYPE_CODE_ANYDUMMY constant varchar2(1) := NULL;
  c_NAAP_LINK_TYPE_CODE_MAIN     constant varchar2(1) := 'M';
  c_NAAP_LINK_TYPE_CODE_SECOND   constant varchar2(1) := 'S';

  --!_! varchar2(1)
  c_NASH_CODE_FREE               constant varchar2(1) := 'F';
  c_NASH_CODE_RESERVE            constant varchar2(1) := 'R';
  c_NASH_CODE_USED               constant varchar2(1) := 'U';
  c_NASH_CODE_OTHER              constant varchar2(1) := 'O';
  c_NASH_CODE_NOT_USED           constant varchar2(1) := 'N'; --!_! otstoi
  c_NASH_CODE_INTERNAL           constant varchar2(1) := 'I';
  c_NASH_CODE_EXTERNAL           constant varchar2(1) := 'E';
  c_NASH_CODE_CLOSE              constant varchar2(1) := 'C'; --!_! Otstoi mnp.
  --!_! char(1)
  c_NASHZ_CODE_EXTERNAL          constant char(1) := c_NASH_CODE_EXTERNAL;

  --!_! PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE varchar2(15)
  c_PNT_CODE_EXTERNAL            constant varchar2(1) := 'E';

  --!_! varchar2(2)
  c_AP_TYPE_SIM_DSA              constant varchar2(2) := 'DS';
  c_AP_TYPE_VIRTUAL              constant varchar2(2) := 'VR';

  --!_! varchar2(1)
  c_APSH_CODE_NOT_ACTIVATED      constant varchar2(1) := 'N';
  c_APSH_CODE_ACTIVATED          constant varchar2(1) := 'A';

  --!_! varchar2(2)
  c_APPSH_PLANNING               constant varchar2(2) := 'PS';
  c_APPSH_IN_PRODUCTION          constant varchar2(2) := 'I';
  c_APPSH_PRODUCED               constant varchar2(2) := 'P';

  --!_! varchar2(1) salability_category
  c_SC_CODE_NORMAL               constant varchar2(1) := 'N';

  --!_! varchar2(2) network_operator_type
  c_NOPT_CODE_INTERNAL_NULLDUMMY constant varchar2(2) := NULL; --!_!
  c_NOPT_CODE_INTERNAL_FAKE      constant varchar2(2) := 'IN'; --!_!
  c_NOPT_CODE_EXTERNAL           constant varchar2(2) := 'EX';

  c_locker_type_synch_sn         constant number := -2;
  c_locker_type_sid              constant number := -3;
  c_locker_type_pns_range        constant number := -4;
  c_locker_type_sim_ser_range    constant number := -5;

  --!_! varchar2(1)
  c_HOST_TYPE_CODE_HLR           constant varchar2(2) := 'HL';

----------------------------------!--------------------------------------------
  c_no_value_not_null_ot_range   constant ot_range := ot_range
  (
    util_pkg.c_no_value_not_null_nvarchar_s,
    util_pkg.c_no_value_not_null_nvarchar_s,
    util_pkg.c_no_value_not_null_number,
    util_pkg.c_no_value_not_null_number,
    util_pkg.c_no_value_not_null_number,
    util_pkg.c_no_value_not_null_date,
    util_pkg.c_no_value_not_null_number
  )
  ;

----------------------------------!---------------------------------------------
  function xget_default_user_id return number;

  procedure xcheck_user_id(p_user_id number);
  procedure xcheck_user_name(p_user_name users.login_name%type);
  function check_user_id(p_user_id number) return number;
  function check_user_name(p_user_name users.login_name%type) return number;

  function xget_user_id(p_user_name users.login_name%type) return number;
  function xget_user_name(p_user_id number) return users.login_name%type;
  function get_user_id(p_user_name users.login_name%type) return number;
  function get_user_name(p_user_id number) return users.login_name%type;

----------------------------------!---------------------------------------------
  procedure XCheck_naap_link_type_code(p_link_type_code varchar2, p_label varchar2 := null);
  procedure XCheck_naap_link_type_code_any(p_link_type_code varchar2, p_label varchar2 := null);

  function xis_main_link(p_link_type_code varchar2) return boolean;
  function det_link_type_code(p_main_link boolean) return varchar2;

----------------------------------!---------------------------------------------
  function xget_not_available_host_id return number;

----------------------------------!---------------------------------------------
  function valid_code2(p_code varchar2) return varchar2;

  function valid_date_to(p_date date) return date;

  function invalid_date_to2valid_date_to(p_date date) return date;
  function valid_date_to2invalid_date_to(p_date date) return date;

  function deleted2valid_date_to(p_date date) return date;
  function valid_date_to2deleted(p_date date) return date;

  function is_date_open(p_date date) return boolean;

----------------------------------!---------------------------------------------
  function split_str_list(p_str_list varchar2, p_null_str_is_empty_list boolean) return ct_varchar_s;
  function split_str_list2(p_str_list varchar2, p_null_str_is_empty_list boolean) return ct_varchar;
  function split_nstr_list(p_str_list nvarchar2, p_null_str_is_empty_list boolean) return ct_nvarchar_s;
  function split_nstr_list2(p_str_list nvarchar2, p_null_str_is_empty_list boolean) return ct_nvarchar;

  function merge_str_list(p_coll_list ct_varchar_s) return varchar2;
  function merge_str_list2(p_coll_list ct_varchar) return varchar2;
  function merge_nstr_list(p_coll_list ct_nvarchar_s) return nvarchar2;
  function merge_nstr_list2(p_coll_list ct_nvarchar) return nvarchar2;

----------------------------------!---------------------------------------------
  function sid_serial2varchar(p_sid number, p_serial number) return varchar2;
  procedure varchar2sid_serial(p_value varchar2, p_sid out number, p_serial out number);

----------------------------------!---------------------------------------------
  function cast_cit_arrays2ct_identity(p_rec_ids util_pkg.cit_number, p_record_ids util_pkg.cit_number, p_record_codes util_pkg.cit_varchar) return ct_identity;
  function cast_cit_arrays2ct_identity(p_rec_ids util_pkg.cit_number, p_record_ids util_pkg.cit_number) return ct_identity;

----------------------------------!---------------------------------------------
  function cast_ct_array2ct_sys_item
  (
    p_sys_rec_ids ct_number,
    p_sys_type_codes ct_varchar_s,
    p_sys_error_codes ct_number,
    p_sys_error_messages ct_varchar,
    p_sys_ids ct_number,
    p_sys_codes ct_varchar_s,
    p_sys_names ct_nvarchar
  ) return ct_sys_item;

  function cast_ct_array2ct_sys_item11
  (
    p_sys_type_codes ct_varchar_s,
    p_sys_error_codes ct_number,
    p_sys_error_messages ct_varchar,
    p_sys_ids ct_number,
    p_sys_codes ct_varchar_s,
    p_sys_names ct_nvarchar
  ) return ct_sys_item;

  function cast_ct_array2ct_sys_item12
  (
    p_sys_type_codes ct_varchar_s,
    p_sys_error_codes ct_number,
    p_sys_error_messages ct_varchar,
    p_sys_ids ct_number,
    p_sys_codes ct_varchar_s
  ) return ct_sys_item;

  function cast_ct_array2ct_sys_item2
  (
    p_sys_rec_ids ct_number,
    p_sys_type_code varchar2,
    p_sys_error_codes ct_number,
    p_sys_error_messages ct_varchar,
    p_sys_ids ct_number,
    p_sys_codes ct_varchar_s,
    p_sys_names ct_nvarchar
  ) return ct_sys_item;

  function cast_ct_array2ct_sys_item21
  (
    p_sys_type_code varchar2,
    p_sys_error_codes ct_number,
    p_sys_error_messages ct_varchar,
    p_sys_ids ct_number,
    p_sys_codes ct_varchar_s,
    p_sys_names ct_nvarchar
  ) return ct_sys_item;

  function cast_ct_array2ct_sys_item3
  (
    p_sys_rec_ids ct_number,
    p_sys_type_code varchar2,
    p_sys_error_codes ct_number,
    p_sys_error_messages ct_varchar,
    p_sys_ids ct_number,
    p_sys_codes ct_varchar_s
  ) return ct_sys_item;

  function cast_ct_array2ct_sys_item31
  (
    p_sys_type_code varchar2,
    p_sys_error_codes ct_number,
    p_sys_error_messages ct_varchar,
    p_sys_ids ct_number,
    p_sys_codes ct_varchar_s
  ) return ct_sys_item;

----------------------------------!---------------------------------------------
  function get_count_ct_host_lac_bs(p_coll ct_host_lac_bs) return number;

----------------------------------!---------------------------------------------
  procedure aggregate_results(p_records ct_identity, p_error_code out number, p_error_message out varchar2);
  procedure aggregate_results02(p_error_codes ct_number, p_error_code out number, p_error_message out varchar2);

----------------------------------!---------------------------------------------
  function check_na_id0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number;
  function check_na_id(p_na_id ct_number, p_date date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number;
  function check_na_id2(p_na_id number, p_date date, p_show_not_found boolean) return number;

  function get_msisdn(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_msisdn2(p_na_id number, p_date date) return varchar2;

  function get_na_id0(p_msisdn ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_na_id(p_msisdn ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_na_id2(p_msisdn varchar2, p_date date) return number;

  function qwerty_get_na_id_last(p_msisdn ct_varchar_s, p_view_date date, p_trim_empty boolean) return ct_number;

  function get_na_status0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_na_status(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_na_status2(p_na_id number, p_date date) return varchar2;

  function get_na_status_max_date_from0(p_na_id ct_number, p_status ct_varchar_s, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_date;
  function get_na_status_max_date_from(p_na_id ct_number, p_status varchar2, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_date;
  function get_na_status_max_date_from2(p_na_id number, p_status varchar2) return date;

  function get_na_pns_id0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_na_pns_id(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_na_pns_id2(p_na_id number, p_date date) return number;

  function get_na_host_id0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_na_host_id(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_na_host_id2(p_na_id number, p_date date) return number;

  function get_na_type0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_na_type(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_na_type2(p_na_id number, p_date date) return varchar2;

  function get_linked_ap_id0(p_na_id ct_number, p_link_type_code varchar2, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_linked_ap_id(p_na_id ct_number, p_link_type_code varchar2, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_linked_ap_id2(p_na_id number, p_link_type_code varchar2, p_date date) return number;

----------------------------------!---------------------------------------------
  function get_pns_host_id0(p_pns_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_pns_host_id(p_pns_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_pns_host_id2(p_pns_id number, p_date date) return number;

  function get_pns_subhost_id0(p_pns_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_pns_subhost_id(p_pns_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_pns_subhost_id2(p_pns_id number, p_date date) return number;

  function get_pns_type0(p_pns_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_pns_type(p_pns_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_pns_type2(p_pns_id number, p_date date) return varchar2;

----------------------------------!---------------------------------------------
  procedure get_na_status_current(p_na_id ct_number, p_date date, p_trim_empty boolean, p_pn_status out ct_varchar_s, p_date_of_status_change out ct_date, p_xcheck_data boolean := true);
  function get_na_status_current1(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  procedure get_na_status_current2(p_na_id number, p_date date, p_pn_status out varchar2, p_date_of_status_change out date);

  function get_na_sel_cat_current(p_na_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_na_sel_cat_current2(p_na_id number, p_date date) return varchar2;

----------------------------------!---------------------------------------------
  function get_na_by_pns(p_pns_id number, p_date date) return ct_number;

----------------------------------!---------------------------------------------
  procedure get_iccid_imsi(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_iccid out ct_varchar_s, p_imsi out ct_varchar_s, p_xcheck_data boolean := true);
  function get_iccid(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_imsi(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  procedure get_iccid_imsi2(p_ap_id number, p_date date, p_iccid out varchar2, p_imsi out varchar2);
  function get_iccid2(p_ap_id number, p_date date) return varchar2;
  function get_imsi2(p_ap_id number, p_date date) return varchar2;

  function get_ap_id0(p_iccid ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_id(p_iccid ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_id2(p_iccid varchar2, p_date date) return number;

  function qwerty_get_ap_id2_all(p_iccid varchar2) return ct_number;

  function get_own_ap_id03(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_own_ap_id3(p_imsi ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_own_ap_id4(p_imsi varchar2, p_date date) return number;

  function get_ext_ap_id03(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ext_ap_id3(p_imsi ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ext_ap_id4(p_imsi varchar2, p_date date) return number;

  function get_ap_id03(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_id3(p_imsi ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_id4(p_imsi varchar2, p_date date) return number;

  function get_ap_id05(p_iccid_without_control_digit ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_id5(p_iccid_without_control_digit ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_id6(p_iccid_without_control_digit varchar2, p_date date) return number;

  function qwerty_get_ap_id4_all(p_imsi varchar2) return ct_number;

  function get_ap_id_sim_imsi(p_imsi ct_varchar_s, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_id_sim_imsi2(p_imsi varchar2) return number;

  function get_ap_id_full0(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_id_full(p_imsi ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_id_full2(p_imsi varchar2, p_date date) return number;

  function get_ap_ss_id0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_ss_id(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_ss_id2(p_ap_id number, p_date date) return number;

  function get_ap_status0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_ap_status(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_ap_status2(p_ap_id number, p_date date) return varchar2;

  function get_ap_pa0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_pa(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_pa2(p_ap_id number, p_date date) return number;

  function get_cur_ap_pa(p_ap_id ct_number/*!_!, p_date date*/, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_cur_ap_pa2(p_ap_id number/*!_!, p_date date*/) return number;

  function get_ap_host_id0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_host_id(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_host_id2(p_ap_id number, p_date date) return number;

  function get_own_ss_host_id0(p_ss_id ct_number, p_host_type_code varchar2, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_own_ss_host_id(p_ss_id ct_number, p_host_type_code varchar2, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_own_ss_host_id2(p_ss_id number, p_host_type_code varchar2, p_date date) return number;

  function get_own_ap_host_id0(p_ap_id ct_number, p_host_type_code varchar2, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_own_ap_host_id(p_ap_id ct_number, p_host_type_code varchar2, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_own_ap_host_id2(p_ap_id number, p_host_type_code varchar2, p_date date) return number;

  function get_ap_no_id0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_no_id(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ap_no_id2(p_ap_id number, p_date date) return number;

  function get_ap_type0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_ap_type(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_ap_type2(p_ap_id number, p_date date) return varchar2;

  procedure get_linked_na_id(p_ap_id ct_number, p_link_type_code varchar2, p_date date, p_trim_empty boolean, p_ap_id2 out ct_number, p_na_id out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := FALSE);
  function get_linked_na_id2(p_ap_id number, p_link_type_code varchar2, p_date date, p_xcheck_unique_data boolean := FALSE) return ct_number;

  function get_linked_na_id_main(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_linked_na_id_main2(p_ap_id number, p_date date) return number;

  procedure get_linked_na_id_sec_no_plink(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_ap_id2 out ct_number, p_na_id out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := FALSE);
  function get_linked_na_id_sec_no_plink2(p_ap_id number, p_date date, p_xcheck_unique_data boolean := FALSE) return ct_number;

----------------------------------!---------------------------------------------
  function check_ss_id0(p_ss_id ct_number, p_date ct_date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number;
  function check_ss_id(p_ss_id ct_number, p_date date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number;
  function check_ss_id2(p_ss_id number, p_date date, p_show_not_found boolean) return number;

  function get_ss_host_id0(p_ss_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ss_host_id(p_ss_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ss_host_id2(p_ss_id number, p_date date) return number;

  function get_ss_subhost_id0(p_ss_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ss_subhost_id(p_ss_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ss_subhost_id2(p_ss_id number, p_date date) return number;

  function get_ss_network_operator0(p_ss_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ss_network_operator(p_ss_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ss_network_operator2(p_ss_id number, p_date date) return number;

  function get_ss_type0(p_ss_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_ss_type(p_ss_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_ss_type2(p_ss_id number, p_date date) return varchar2;

  function det_ss_id4imsi0(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function det_ss_id4imsi(p_imsi ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function det_ss_id4imsi2(p_imsi varchar2, p_date date) return number;

----------------------------------!---------------------------------------------
  function get_pa_host0(p_pa ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_pa_host(p_pa ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_pa_host2(p_pa number, p_date date) return number;

  procedure get_pa_linked_ap_id(p_pa ct_number, p_date date, p_trim_empty boolean, p_pa2 out ct_number, p_ap_id out ct_number, p_xcheck_data boolean := true, p_xcheck_unique_data boolean := FALSE);
  function get_pa_linked_ap_id2(p_pa number, p_date date, p_xcheck_unique_data boolean := FALSE) return ct_number;

----------------------------------!---------------------------------------------
  function check_host_id0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number;
  function check_host_id(p_host_id ct_number, p_date date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number;
  function check_host_id2(p_host_id number, p_date date, p_show_not_found boolean) return number;

  function get_host_id0(p_host_code ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_host_id(p_host_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_host_id2(p_host_code varchar2, p_date date) return number;

  function get_host_code0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_host_code(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_host_code2(p_host_id number, p_date date) return varchar2;

  function get_host_name0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar;
  function get_host_name(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar;
  function get_host_name2(p_host_id number, p_date date) return varchar2;

  function get_host_address0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar;
  function get_host_address(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar;
  function get_host_address2(p_host_id number, p_date date) return varchar2;

  function get_host_type0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_host_type(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_host_type2(p_host_id number, p_date date) return varchar2;

  function get_host_network_operator0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_host_network_operator(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_host_network_operator2(p_host_id number, p_date date) return number;

  function get_host_parent0(p_host_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_host_parent(p_host_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_host_parent2(p_host_id number, p_date date) return number;

----------------------------------!---------------------------------------------
  function get_zone_id0(p_zone_code ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_zone_id(p_zone_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_zone_id2(p_zone_code varchar2, p_date date) return number;

  function get_zone_code0(p_zone_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_zone_code(p_zone_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_zone_code2(p_zone_id number, p_date date) return varchar2;

----------------------------------!---------------------------------------------
  function get_network_operator_id0(p_network_operator_code ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_network_operator_id(p_network_operator_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_network_operator_id2(p_network_operator_code varchar2, p_date date) return number;
  function xget_network_operator_id2(p_network_operator_code varchar2, p_date date) return number;

  function get_network_operator_code0(p_network_operator_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_network_operator_code(p_network_operator_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_network_operator_code2(p_network_operator_id number, p_date date) return varchar2;

  --!_!DON'T USE WITHOUT REASON
  --!_!returns raw data: NULL and EX (c_NOPT_CODE_INTERNAL_NULLDUMMY and c_NOPT_CODE_EXTERNAL)
  function get_network_operator_type_raw0(p_network_operator_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_network_operator_type_raw(p_network_operator_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_network_operator_type_raw2(p_network_operator_id number, p_date date) return varchar2;
  --!_!DON'T USE WITHOUT REASON

  --!_!returns wrapped data: IN and EX (c_NOPT_CODE_INTERNAL_FAKE and c_NOPT_CODE_EXTERNAL)
  function get_network_operator_type_x0(p_network_operator_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_network_operator_type_x(p_network_operator_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_network_operator_type_x2(p_network_operator_id number, p_date date) return varchar2;

  function get_network_operator_uprsc0(p_network_operator_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_network_operator_uprsc(p_network_operator_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_network_operator_uprsc2(p_network_operator_id number, p_date date) return varchar2;

  function get_network_operator_name0(p_network_operator_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar;
  function get_network_operator_name(p_network_operator_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar;
  function get_network_operator_name2(p_network_operator_id number, p_date date) return varchar2;

  function get_int_no4na0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number;
  function get_int_no4na(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number;
  function get_int_no4na2(p_na_id number, p_date date) return number;

  function get_ext_no4na0(p_na_id ct_number, p_date ct_date, p_trim_empty boolean) return ct_number;
  function get_ext_no4na(p_na_id ct_number, p_date date, p_trim_empty boolean) return ct_number;
  function get_ext_no4na2(p_na_id number, p_date date) return number;

  function det_int_no0(p_msisdn ct_varchar_s, p_date ct_date, p_trim_empty boolean) return ct_number;
  function det_int_no(p_msisdn ct_varchar_s, p_date date, p_trim_empty boolean) return ct_number;
  function det_int_no2(p_msisdn varchar2, p_date date) return number;

  function get_no_by_ap0(p_ap_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_no_by_ap(p_ap_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_no_by_ap2(p_ap_id number, p_date date) return number;

  function get_no_by_mcc_mnc0(p_mcc ct_varchar_s, p_mnc ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_no_by_mcc_mnc(p_mcc ct_varchar_s, p_mnc ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_no_by_mcc_mnc2(p_mcc varchar2, p_mnc varchar2, p_date date) return varchar2;

  function get_no_by_msc_mask0(p_msc ct_varchar_s, p_date ct_date, p_trim_empty boolean) return ct_number;
  function get_no_by_msc_mask(p_msc ct_varchar_s, p_date date, p_trim_empty boolean) return ct_number;
  function get_no_by_msc_mask2(p_msc varchar2, p_date date) return varchar2;

  function get_no_by_uprsc0(p_uprs_member_code ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_no_by_uprsc(p_uprs_member_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_no_by_uprsc2(p_uprs_member_code varchar2, p_date date) return number;

  function no_is_parent_no(p_child_id ct_number, p_parent_id ct_number, p_date date, p_include_self boolean, p_is_value number := util_pkg.c_true, p_is_not_value number := util_pkg.c_false) return ct_number;
  function get_child_nos(p_root_parent_id number, p_date date, p_include_self boolean) return ct_number;

----------------------------------!---------------------------------------------
  function det_pns_id4msisdn0(p_msisdn ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function det_pns_id4msisdn(p_msisdn ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function det_pns_id4msisdn2(p_msisdn varchar2, p_date date) return number;

----------------------------------!---------------------------------------------
  function check_dst_rule_id0(p_dst_rule_id ct_number, p_date ct_date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number;
  function check_dst_rule_id(p_dst_rule_id ct_number, p_date date, p_trim_empty boolean, p_show_not_found boolean, p_xcheck_data boolean := true) return ct_number;
  function check_dst_rule_id2(p_dst_rule_id number, p_date date, p_show_not_found boolean) return number;

----------------------------------!---------------------------------------------
  function get_linked_naap_value(p_link_status number) return boolean;
  function get_linked_naap_value2(p_link_status number) return boolean; --for GetPhonesByStatus2 using SearchPhonesModeEnum

----------------------------------!---------------------------------------------
  function normalize_mask(p_mask varchar2) return varchar2;

----------------------------------!---------------------------------------------
  procedure normalize_str_host_alike(p_str_host_alike varchar2, p_str_host_normal out varchar2, p_host_empty out boolean);
  procedure normalize_str_host_id(p_str_host_id varchar2, p_date date, p_xcheck_exist boolean, p_host_id out number, p_host_empty out boolean);
  procedure normalize_str_host_id2(p_str_host_id varchar2, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean);

  procedure normalize_coll_str_host_alike(p_coll_str_host_alike ct_varchar_s, p_coll_str_host_normal out ct_varchar_s, p_host_empty out boolean);
  procedure normalize_coll_str_host_alike2(p_coll_str_host_alike util_pkg.cit_varchar_s, p_coll_str_host_normal out ct_varchar_s, p_host_empty out boolean);
  procedure normalize_coll_str_host_id(p_coll_str_host_id ct_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean);
  procedure normalize_coll_str_host_id2(p_coll_str_host_id util_pkg.cit_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean);
  procedure normalize_coll_str_host_code(p_coll_str_host_code ct_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean);
  procedure normalize_coll_str_host_code2(p_coll_str_host_code util_pkg.cit_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean);

----------------------------------!---------------------------------------------
  function get_1nash_i(p_id number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return network_address_status_history%rowtype;
  function get_1nash(p_id number, p_date date) return network_address_status_history%rowtype;
  function get_min_date_from_nash(p_id number) return date;
  function get_max_date_from_nash(p_id number) return date;
  function get_max_date_to_nash(p_id number) return date;
  function get_first_nash(p_id number) return network_address_status_history%rowtype;
  function get_last_nash(p_id number) return network_address_status_history%rowtype;
  function get_prev_nash(p_id number) return network_address_status_history%rowtype;
  function lock_1nash(p_id number, p_date date, p_wait boolean) return boolean;
  function lock_nash(p_id ct_number, p_date ct_date, p_wait boolean, p_locked_value number := util_pkg.c_true, p_unlocked_value number := util_pkg.c_false) return ct_number;

----------------------------------!---------------------------------------------
  function get_1apsh_i(p_id number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return access_point_status_history%rowtype;
  function get_1apsh(p_id number, p_date date) return access_point_status_history%rowtype;
  function get_min_date_from_apsh(p_id number) return date;
  function get_max_date_from_apsh(p_id number) return date;
  function get_max_date_to_apsh(p_id number) return date;
  function get_first_apsh(p_id number) return access_point_status_history%rowtype;
  function get_last_apsh(p_id number) return access_point_status_history%rowtype;
  function lock_1apsh(p_id number, p_date date, p_wait boolean) return boolean;
  function lock_apsh(p_id ct_number, p_date ct_date, p_wait boolean, p_locked_value number := util_pkg.c_true, p_unlocked_value number := util_pkg.c_false) return ct_number;

----------------------------------!---------------------------------------------
  function get_1appsh_i(p_id number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return ap_prod_status_hist%rowtype;
  function get_1appsh(p_id number, p_date date) return ap_prod_status_hist%rowtype;
  function get_min_date_from_appsh(p_id number) return date;
  function get_max_date_from_appsh(p_id number) return date;
  function get_max_date_to_appsh(p_id number) return date;
  function get_first_appsh(p_id number) return ap_prod_status_hist%rowtype;
  function get_last_appsh(p_id number) return ap_prod_status_hist%rowtype;
  function lock_1appsh(p_id number, p_date date, p_wait boolean) return boolean;
  function lock_appsh(p_id ct_number, p_date ct_date, p_wait boolean, p_locked_value number := util_pkg.c_true, p_unlocked_value number := util_pkg.c_false) return ct_number;

----------------------------------!---------------------------------------------
  function get_1naap_i(p_na_id number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return network_address_access_point%rowtype;
  function get_1naap(p_na_id number, p_date date) return network_address_access_point%rowtype;
  function get_min_date_from_naap(p_na_id number) return date;
  function get_max_date_from_naap(p_na_id number) return date;
  function get_max_date_to_naap(p_na_id number) return date;
  function get_first_naap(p_na_id number) return network_address_access_point%rowtype;
  function get_last_naap(p_na_id number) return network_address_access_point%rowtype;
  function lock_1naap(p_na_id number, p_date date, p_wait boolean) return boolean;
  function lock_naap(p_na_id ct_number, p_date ct_date, p_wait boolean, p_locked_value number := util_pkg.c_true, p_unlocked_value number := util_pkg.c_false) return ct_number;

----------------------------------!---------------------------------------------
  function get_1appa_i(p_ap_id number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return access_point_personal_account%rowtype;
  function get_1appa(p_ap_id number, p_date date) return access_point_personal_account%rowtype;
  function get_min_date_from_appa(p_ap_id number) return date;
  function get_max_date_from_appa(p_ap_id number) return date;
  function get_max_date_to_appa(p_ap_id number) return date;
  function get_first_appa(p_ap_id number) return access_point_personal_account%rowtype;
  function get_last_appa(p_ap_id number) return access_point_personal_account%rowtype;
  function lock_1appa(p_ap_id number, p_date date, p_wait boolean) return boolean;
  function lock_appa(p_ap_id ct_number, p_date ct_date, p_wait boolean, p_locked_value number := util_pkg.c_true, p_unlocked_value number := util_pkg.c_false) return ct_number;

----------------------------------!---------------------------------------------
  function get_1pah_i(p_pa number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return personal_account_history%rowtype;
  function get_1pah(p_pa number, p_date date) return personal_account_history%rowtype;
  function get_min_date_from_pah(p_pa number) return date;
  function get_max_date_from_pah(p_pa number) return date;
  function get_max_date_to_pah(p_pa number) return date;
  function get_first_pah(p_pa number) return personal_account_history%rowtype;
  function get_last_pah(p_pa number) return personal_account_history%rowtype;
  function lock_1pah(p_pa number, p_date date, p_wait boolean) return boolean;
  function lock_pah(p_pa ct_number, p_date ct_date, p_wait boolean, p_locked_value number := util_pkg.c_true, p_unlocked_value number := util_pkg.c_false) return ct_number;

----------------------------------!---------------------------------------------
  function get_1pn_i(p_id number, p_lock boolean, p_wait boolean, p_is_locked out boolean) return phone_number%rowtype;
  function get_1pn(p_id number) return phone_number%rowtype;
  function lock_1pn(p_id number, p_wait boolean) return boolean;
  function xlock_get_1pn(p_id number) return phone_number%rowtype;
  procedure xlock_1pn(p_id number);

----------------------------------!---------------------------------------------
  function get_pn_cursor_by_status
  (
    p_status varchar2,
    p_date date
  ) return sys_refcursor;

----------------------------------!---------------------------------------------
  function get_1sc_i(p_id number, p_lock boolean, p_wait boolean, p_is_locked out boolean) return sim_card%rowtype;
  function get_1sc(p_id number) return sim_card%rowtype;
  function lock_1sc(p_id number, p_wait boolean) return boolean;
  function xlock_get_1sc(p_id number) return sim_card%rowtype;
  procedure xlock_1sc(p_id number);

----------------------------------!---------------------------------------------
  procedure prepare_as_pnlnk_i(p_na_id ct_number, p_date date, p_uniquelize boolean, p_trim_empty boolean, p_na_id_m out ct_number, p_na_id_l out ct_number, p_msisdn_m out ct_varchar_s, p_msisdn_l out ct_varchar_s);

  procedure prepare_as_pnlnk_exact(p_na_id ct_number, p_date date, p_na_id_m out ct_number, p_na_id_l out ct_number, p_msisdn_m out ct_varchar_s, p_msisdn_l out ct_varchar_s);
  procedure prepare_as_pnlnk_fuzzy(p_na_id ct_number, p_date date, p_na_id_m out ct_number, p_na_id_l out ct_number, p_msisdn_m out ct_varchar_s, p_msisdn_l out ct_varchar_s);
  procedure prepare_as_pnlnk2_exact(p_na_id ct_number, p_date date, p_na_id_m out ct_number, p_na_id_l out ct_number);
  procedure prepare_as_pnlnk2_fuzzy(p_na_id ct_number, p_date date, p_na_id_m out ct_number, p_na_id_l out ct_number);
  procedure prepare_as_pnlnk2_fuzzy_fuzzy(p_na_id ct_number, p_date date, p_na_id_m out ct_number, p_na_id_l out ct_number);
  procedure prepare_as_pnlnk3_exact(p_na_id ct_number, p_date date, p_msisdn_m out ct_varchar_s, p_msisdn_l out ct_varchar_s);
  procedure prepare_as_pnlnk3_fuzzy(p_na_id ct_number, p_date date, p_msisdn_m out ct_varchar_s, p_msisdn_l out ct_varchar_s);
  procedure prepare_as_pnlnk3_fuzzy_fuzzy(p_na_id ct_number, p_date date, p_msisdn_m out ct_varchar_s, p_msisdn_l out ct_varchar_s);

  function get_as_pnlnk_naid_m_exact(p_na_id ct_number, p_date date) return ct_number;
  function get_as_pnlnk_naid_m_fuzzy(p_na_id ct_number, p_date date) return ct_number;
  function get_as_pnlnk_naid_l_exact(p_na_id ct_number, p_date date) return ct_number;
  function get_as_pnlnk_naid_l_fuzzy(p_na_id ct_number, p_date date) return ct_number;
  function get_as_pnlnk_naid_exact(p_na_id ct_number, p_date date) return ct_number;
  function get_as_pnlnk_naid_fuzzy(p_na_id ct_number, p_date date) return ct_number;

  function get_as_pnlnk_msisdn_m_exact(p_na_id ct_number, p_date date) return ct_varchar_s;
  function get_as_pnlnk_msisdn_m_fuzzy(p_na_id ct_number, p_date date) return ct_varchar_s;
  function get_as_pnlnk_msisdn_l_exact(p_na_id ct_number, p_date date) return ct_varchar_s;
  function get_as_pnlnk_msisdn_l_fuzzy(p_na_id ct_number, p_date date) return ct_varchar_s;
  function get_as_pnlnk_msisdn_exact(p_na_id ct_number, p_date date) return ct_varchar_s;
  function get_as_pnlnk_msisdn_fuzzy(p_na_id ct_number, p_date date) return ct_varchar_s;

  function get_pnlnk_other_side_exact(p_na_id ct_number, p_date date) return ct_number;
  function get_pnlnk_other_side_fuzzy(p_na_id ct_number, p_date date) return ct_number;

  function get_pnlnk_found(p_na_id ct_number, p_na_id_m ct_number, p_na_id_l ct_number) return ct_number;
  function get_pnlnk_found2(p_na_id ct_number, p_na_id_ml ct_number) return ct_number;
  function get_pnlnk_not_found(p_na_id ct_number, p_na_id_m ct_number, p_na_id_l ct_number) return ct_number;
  function get_pnlnk_not_found2(p_na_id ct_number, p_na_id_ml ct_number) return ct_number;

  function suppress_plink_m(p_na_id ct_number, p_date date) return ct_number;
  function suppress_plink_l(p_na_id ct_number, p_date date) return ct_number;

----------------------------------!---------------------------------------------
  function get_count_ct_range(p_coll ct_range) return number;

  procedure fill_ct_range(p_coll in out nocopy ct_range, p_val ot_range);
  procedure resize_ct_range(p_coll in out nocopy ct_range, p_size number);
  function make_ct_range(p_count number, p_val ot_range) return ct_range;
  procedure add_ct_range_val(p_coll in out nocopy ct_range, p_val ot_range);

  function filter_val_ct_range(p_vals ct_range, p_filter_vals ct_range, p_include_by_filter boolean) return ct_range;
  function filter_val_ct_range_1val(p_vals ct_range, p_filter_val ot_range, p_include_by_filter boolean) return ct_range;

  function filter_val_ct_range_num2(p_vals ct_range, p_filter_vals ct_number, p_include_by_filter boolean) return ct_range;
  function filter_val_ct_range_num2_1val(p_vals ct_range, p_filter_val number, p_include_by_filter boolean) return ct_range;

  function make_ot_range
  (
    p_val1 nvarchar2,
    p_val2 nvarchar2,
    p_num1 number,
    p_num2 number,
    p_num3 number,
    p_dat1 date,
    p_num4 number
  ) return ot_range;

  function make_ot_range1
  (
    p_range_start nvarchar2,
    p_range_end nvarchar2,
    p_model_id number,
    p_id_original number,
    p_quantity number,
    p_valid_until date
  ) return ot_range;

  function make_ct_range0
  (
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s,
    p_num1 ct_number,
    p_num2 ct_number,
    p_num3 ct_number,
    p_dat1 ct_date,
    p_num4 ct_number
  ) return ct_range;

  function make_ct_range1
  (
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s
  ) return ct_range;

  function make_ct_range2
  (
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s,
    p_num1 ct_number
  ) return ct_range;

  function make_ct_range3
  (
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s,
    p_num1 ct_number,
    p_num2 ct_number
  ) return ct_range;

----------------------------------!---------------------------------------------
  function get_sim_series_range4host(p_host_id number, p_date date, p_sim_card_type_code varchar2 := null) return ct_range;

----------------------------------!---------------------------------------------

end;
/
