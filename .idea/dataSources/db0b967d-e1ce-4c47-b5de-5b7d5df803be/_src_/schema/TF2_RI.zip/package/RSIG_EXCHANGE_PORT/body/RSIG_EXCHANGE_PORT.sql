CREATE PACKAGE BODY RSIG_EXCHANGE_PORT IS
---------------------------------------------
--     PROCEDURE Is_Exchange_Deleted
---------------------------------------------

PROCEDURE Is_Exchange_Deleted(p_exchange_id IN INTEGER --CF*EXCHANGE.EXCHANGE_ID%TYPE
                              ) IS
  v_pom number;

BEGIN
  SELECT 1
    INTO v_pom
    FROM HOST
   WHERE HOST_ID = p_exchange_id
     AND DELETED is not null
     AND DELETED < sysdate;
  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    null;
END Is_Exchange_Deleted;

---------------------------------------------
--     PROCEDURE Test_Row_For_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Row_For_Exist_And_Deleted(p_access_point_id IN EXCHANGE_PORT.ACCESS_POINT_ID%TYPE) IS
  v_deleted EXCHANGE_PORT.DELETED%TYPE;
BEGIN
  select DELETED into v_deleted from EXCHANGE_PORT where ACCESS_POINT_ID = p_access_point_id;

  IF v_deleted IS NOT NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Test_Row_For_Exist_And_Deleted;


---------------------------------------------
--     PROCEDURE Insert_Exchange_Port
---------------------------------------------

PROCEDURE Insert_Exchange_Port
(
  handle_tran               CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT NUMBER,
  p_access_point_id         OUT EXCHANGE_PORT.ACCESS_POINT_ID%TYPE,
  p_exchange_id             IN HOST.HOST_ID%TYPE,
  p_exchange_port_number    IN EXCHANGE_PORT.EXCHANGE_PORT_NUMBER%TYPE,
  p_exchange_port_type_code IN EXCHANGE_PORT.EXCHANGE_PORT_TYPE_CODE%TYPE,
  p_user_id_of_change       IN EXCHANGE_PORT.USER_ID_OF_CHANGE%TYPE,
  p_raise_error	            IN CHAR DEFAULT rsig_utils.c_NO
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE_PORT.Insert_Exchange_Port';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint Insert_Exchange_Port;
  END IF;

  Is_Exchange_Deleted(p_exchange_id);

  SELECT S_ACCESS_POINT.NEXTVAL INTO p_access_point_id FROM SYS.DUAL;

  INSERT INTO ACCESS_POINT
    (ACCESS_POINT_ID)
  VALUES
    (p_access_point_id);

  BEGIN
    INSERT INTO EXCHANGE_PORT
      (ACCESS_POINT_ID,
       HOST_ID,
       EXCHANGE_PORT_NUMBER,
       EXCHANGE_PORT_TYPE_CODE,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE)
    VALUES
      (p_access_point_id,
       p_exchange_id,
       p_exchange_port_number,
       p_exchange_port_type_code,
       sysdate,
       p_user_id_of_change);

  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      IF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_EXCHANGE_PORT THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_PORT_NUMBER_EXISTS, 'Port exists.');
      END IF;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint Insert_Exchange_Port;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;

    IF p_raise_error = rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Insert_Exchange_Port;

---------------------------------------------
--     PROCEDURE Generate_Exchange_Port
---------------------------------------------

PROCEDURE Generate_Exchange_Port
(
  handle_tran                  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                   OUT NUMBER,
  p_exchange_id                IN HOST.HOST_ID%TYPE,
  p_exchange_port_number_start IN EXCHANGE_PORT.EXCHANGE_PORT_NUMBER%TYPE,
  p_exchange_port_number_count IN NUMBER,
  p_exchange_port_type_code    IN EXCHANGE_PORT.EXCHANGE_PORT_TYPE_CODE%TYPE,
  p_user_id_of_change          IN EXCHANGE_PORT.USER_ID_OF_CHANGE%TYPE,
  p_exchange_prefix            IN VARCHAR2,
  p_fill_zero                  IN CHAR, -- Y fill, N not fill
  p_count_digits               IN NUMBER -- if p_fill_zero=Y then this is length exchange_port_number with zero

) IS
  v_event_source    VARCHAR2(60) := 'RSIG_EXCHANGE_PORT.Generate_Exchange_Port';
  s_access_point_id EXCHANGE_PORT.ACCESS_POINT_ID%TYPE;
  v_exchange_prefix VARCHAR2(20);
  v_fill_zero       CHAR(1);
  v_count_digits    NUMBER;
  v_export_number   EXCHANGE_PORT.EXCHANGE_PORT_NUMBER%TYPE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF p_exchange_port_number_start IS NULL
     OR p_exchange_port_number_count IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  v_exchange_prefix := nvl(p_exchange_prefix, '');
  v_fill_zero       := nvl(p_fill_zero, 'N');
  v_count_digits    := nvl(p_count_digits, 5);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint Generate_Exchange_Port;
  END IF;

  FOR v_exchange_port_number IN p_exchange_port_number_start .. (p_exchange_port_number_start +
                                                                p_exchange_port_number_count - 1)
  LOOP

    v_export_number := TO_CHAR(v_exchange_port_number);
    IF v_fill_zero = 'Y'
       AND v_count_digits > LENGTH(v_export_number) THEN
      v_export_number := LPAD(v_export_number, v_count_digits, '0');
    END IF;
    v_export_number := v_exchange_prefix || v_export_number;

    Insert_Exchange_Port(handle_tran,
                         error_code,
                         s_access_point_id,
                         p_exchange_id,
                         v_export_number,
                         p_exchange_port_type_code,
                         p_user_id_of_change,
                         rsig_utils.c_YES);

  END LOOP;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint Generate_Exchange_Port;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Generate_Exchange_Port;

---------------------------------------------
--     PROCEDURE Delete_Exchange_Port
---------------------------------------------

PROCEDURE Delete_Exchange_Port
(
  handle_tran         CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT NUMBER,
  p_access_point_id   IN EXCHANGE_PORT.ACCESS_POINT_ID%TYPE,
  p_deleted           IN EXCHANGE_PORT.DELETED%TYPE,
  p_user_id_of_change IN EXCHANGE_PORT.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE_PORT.Delete_Exchange_Port';
  v_sysdate      DATE;
  v_deleted      DATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  v_deleted := nvl(p_deleted, SYSDATE);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Delete_Exchange_Port;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_access_point_id);

  v_sysdate := SYSDATE;

  UPDATE EXCHANGE_PORT
     SET DATE_OF_CHANGE    = v_sysdate,
         USER_ID_OF_CHANGE = p_user_id_of_change,
         DELETED           = v_deleted
   WHERE ACCESS_POINT_ID = p_access_point_id;


  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Delete_Exchange_Port;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
END Delete_Exchange_Port;

---------------------------------------------
--     PROCEDURE Get_Exchange_Port_Types
---------------------------------------------

PROCEDURE Get_Exchange_Port_Types
(
  error_code            OUT NUMBER,
  p_exchange_port_types IN OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE_PORT.Get_Exchange_Port_Types';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_exchange_port_types FOR
    SELECT ept.EXCHANGE_PORT_TYPE_CODE,
           ept.EXCHANGE_PORT_TYPE_NAME
      FROM EXCHANGE_PORT_TYPE ept;

  /*
  OPEN p_cur_exchange_port FOR
       SELECT
          ex.ACCESS_POINT_ID,
          ex.EXCHANGE_PORT_NUMBER,
          ex.EXCHANGE_PORT_TYPE_CODE,
          ex.DELETED,
          ex.DATE_OF_CHANGE,
          ex.USER_ID_OF_CHANGE,
          h.HOST_ID,
          h.HOST_NAME,
          --h.DATE_OF_CHANGE,
          --h.USER_ID_OF_CHANGE,
          h.HOST_CODE,
          h.HOST_ADDRESS,
          h.HOST_LOCATION,
          h.HOST_TYPE_CODE,
          h.NETWORK_OPERATOR_ID
     FROM EXCHANGE_PORT ex
     JOIN HOST h on h.HOST_ID = ex.HOST_ID
     JOIN ACCESS_POINT_HOST acph ON acph.HOST_ID = h.HOST_ID
     JOIN ACCESS_POINT acp on acp.ACCESS_POINT_ID = acph.ACCESS_POINT_ID
     WHERE (  h.HOST_ID = p_exchange_id
             OR  p_exchange_id is null)
        AND (acp.PERSONAL_ACCOUNT = p_personal_account
             OR p_personal_account  is null)
        AND h.DELETED is null;
        */

  error_code := RSIG_UTILS.c_OK; -- succesfully completed
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Get_Exchange_Port_Types;

---------------------------------------------
--     PROCEDURE Update_Exchange_Port
---------------------------------------------

PROCEDURE Update_Exchange_Port
(
  handle_tran               CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT NUMBER,
  p_access_point_id         IN EXCHANGE_PORT.ACCESS_POINT_ID%TYPE,
  p_host_id                 IN EXCHANGE_PORT.HOST_ID%TYPE,
  p_exchange_port_type_code IN EXCHANGE_PORT.EXCHANGE_PORT_TYPE_CODE%TYPE,
  p_user_id_of_change       IN EXCHANGE_PORT.USER_ID_OF_CHANGE%TYPE,
  p_exchange_port_number    IN EXCHANGE_PORT.EXCHANGE_PORT_NUMBER%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE_PORT.Update_Exchange_Port';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint Update_Exchange_Port;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_access_point_id);

  BEGIN
    UPDATE EXCHANGE_PORT
       SET date_of_change          = sysdate,
           user_id_of_change       = p_user_id_of_change,
           host_id                 = nvl(p_host_id, HOST_ID),
           exchange_port_type_code = nvl(p_exchange_port_type_code, EXCHANGE_PORT_TYPE_CODE),
           exchange_port_number    = nvl(p_exchange_port_number, '')
     WHERE access_point_id = p_access_point_id;

  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      IF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_EXCHANGE_PORT THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_PORT_NUMBER_EXISTS, 'Port exists.');
      END IF;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint Update_Exchange_Port;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Update_Exchange_Port;



---------------------------------------------
--     PROCEDURE Get_Exchange_port_Next
---------------------------------------------

procedure Get_Exchange_port_Next
(
  p_host_id                 IN EXCHANGE_PORT.HOST_ID%TYPE,
  p_access_point_id         IN EXCHANGE_PORT.ACCESS_POINT_ID%TYPE,
  p_exchange_port_type_code IN VARCHAR2,
  p_show_deleted            IN CHAR,
  p_in_row_count            IN NUMBER,
  p_raise_error             IN CHAR,
  error_code                OUT NUMBER,
  error_message             OUT VARCHAR2,
  result_list               OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE_PORT.Get_Exchange_port_Next';
  v_sqlcode      NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF p_host_id IS NULL
     OR p_in_row_count IS NULL
     OR p_show_deleted IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, '');
  END IF;

  DELETE FROM TT_INTERFACE_FOR_SUPS_NA_AP;

  INSERT INTO TT_INTERFACE_FOR_SUPS_NA_AP tt
    (access_point_desc)
    SELECT *
      FROM TABLE(RSIG_COMMON.GET_STRING_AS_TABLE(CAST(p_exchange_port_type_code AS VARCHAR2(2000)),
                                                 CAST(',' AS VARCHAR2(10))));

  -- procedure body here

  /*  v_SQLstring :=
    'SELECT    --+ FIRST_ROWS
      ep.ACCESS_POINT_ID,
      ep.EXCHANGE_PORT_NUMBER,
      ep.EXCHANGE_PORT_TYPE_CODE,
      ep.DELETED,
      ep.DATE_OF_CHANGE,
      ep.USER_ID_OF_CHANGE,
      ept.EXCHANGE_PORT_TYPE_NAME,
      (SELECT COUNT(1)
       FROM NETWORK_ADDRESS_ACCESS_POINT naap
       WHERE naap.access_point_id = ep.access_point_id
        AND SYSDATE BETWEEN naap.from_date AND nvl(naap.To_Date,SYSDATE)
      ) AMOUNT_OF_PHONENUMBERS
    FROM EXCHANGE_PORT ep
      JOIN EXCHANGE_PORT_TYPE ept ON ept.EXCHANGE_PORT_TYPE_CODE = ep.EXCHANGE_PORT_TYPE_CODE
    WHERE 1=1
        AND ep.host_id = '|| to_char(p_host_id) || '
      AND ep.access_point_id > '|| to_char(nvl(p_access_point_id,-1)) || '
      AND ( '''|| nvl(p_show_deleted,'N') ||''' = ''Y'' OR ep.deleted IS NULL)
      AND ROWNUM <= ' || to_char(p_in_row_count)|| '
      ';
    IF p_exchange_port_type_code IS NOT NULL THEN
      v_SQLstring := v_SQLstring || 'AND ep.exchange_port_type_code IN ( '|| p_exchange_port_type_code || ')
      ';
    END IF;
    v_SQLstring := v_SQLstring || ' ORDER BY ep.access_point_id ' ;
  */

  OPEN result_list FOR
    SELECT /*+ FIRST_ROWS */
     ep.ACCESS_POINT_ID,
     ep.EXCHANGE_PORT_NUMBER,
     ep.EXCHANGE_PORT_TYPE_CODE,
     ep.DELETED,
     ep.DATE_OF_CHANGE,
     ep.USER_ID_OF_CHANGE,
     ept.EXCHANGE_PORT_TYPE_NAME,
     (SELECT COUNT(1)
        FROM NETWORK_ADDRESS_ACCESS_POINT naap
       WHERE naap.access_point_id = ep.access_point_id
         AND SYSDATE BETWEEN naap.from_date AND nvl(naap.To_Date, SYSDATE)) AMOUNT_OF_PHONENUMBERS,
     (SELECT COUNT(1)
        FROM access_point_host aph
       WHERE aph.access_point_id = ep.access_point_id
         AND SYSDATE BETWEEN aph.start_date AND nvl(aph.end_date, SYSDATE)) AMOUNT_OF_HOSTS
      FROM EXCHANGE_PORT ep
      JOIN EXCHANGE_PORT_TYPE ept ON TRIM(ept.EXCHANGE_PORT_TYPE_CODE) = TRIM(ep.EXCHANGE_PORT_TYPE_CODE)
     WHERE 1 = 1
       AND ep.host_id = p_host_id
       AND ep.access_point_id > nvl(p_access_point_id, -1)
       AND (nvl(p_show_deleted, 'N') = 'Y' OR ep.deleted IS NULL)
       AND ROWNUM <= to_char(p_in_row_count)
       AND (p_exchange_port_type_code IS NULL OR
           TRIM(ep.exchange_port_type_code) IN
           (SELECT trim(t.access_point_desc) FROM TT_INTERFACE_FOR_SUPS_NA_AP t))
     ORDER BY ep.access_point_id;

  -- commit
  -- set error code to succesfully completed
  error_code := 0;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    DBMS_OUTPUT.PUT_LINE(error_message);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF p_raise_error = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_Exchange_port_Next;


---------------------------------------------
--     PROCEDURE Get_Phone_hist_by_exch_port
---------------------------------------------

procedure Get_Phone_hist_by_exch_port
(
  p_host_id     IN HOST.HOST_ID%TYPE,
  p_port_number IN EXCHANGE_PORT.EXCHANGE_PORT_NUMBER%TYPE,
  p_raise_error IN CHAR,
  error_code    OUT NUMBER,
  error_message OUT VARCHAR2,
  result_list   OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE_PORT.Get_Phone_hist_by_exch_port';
  v_sqlcode      number;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  IF p_host_id IS NULL
     OR p_port_number IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  OPEN result_list FOR
    SELECT pn.INTERNATIONAL_FORMAT,
           naap.FROM_DATE,
           naap.TO_DATE
      FROM EXCHANGE_PORT ep
      JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON ep.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
      JOIN PHONE_NUMBER pn ON naap.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
     WHERE 1 = 1
       AND ep.EXCHANGE_PORT_NUMBER = p_port_number
       AND ep.HOST_ID = p_host_id
     ORDER BY naap.FROM_DATE;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_Phone_hist_by_exch_port;


---------------------------------------------
--     PROCEDURE Get_Phone_Series_Ports
---------------------------------------------

procedure Get_Phone_Series_Ports
(
  p_phone_series_id IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
  p_date            IN DATE,
  p_raise_error     IN CHAR,
  error_code        OUT NUMBER,
  error_message     OUT VARCHAR2,
  result_list       OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE_PORT.Get_Phone_Series_Ports';
  v_sqlcode      NUMBER;
  v_sysdate      DATE;

  CURSOR c_phone IS
    SELECT pn.INTERNATIONAL_FORMAT,
           nvl(ep.EXCHANGE_PORT_TYPE_CODE, '@@'),
           nvl(ep.EXCHANGE_PORT_NUMBER, '-1'),
           (SELECT COUNT(1)
              FROM NETWORK_ADDRESS_ACCESS_POINT naap2
             WHERE 1 = 1
               AND naap2.ACCESS_POINT_ID = ep.ACCESS_POINT_ID
               AND nvl(p_date, v_sysdate) BETWEEN naap2.FROM_DATE AND
                   nvl(naap2.TO_DATE, nvl(p_date, v_sysdate)))
      FROM PHONE_NUMBER_SERIES pns
      JOIN PHONE_NUMBER pn ON pns.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
      LEFT JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON (naap.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID AND
                                                     nvl(p_date, v_sysdate) BETWEEN naap.FROM_DATE AND
                                                     nvl(naap.TO_DATE, nvl(p_date, v_sysdate)))
      LEFT JOIN EXCHANGE_PORT ep ON ep.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
      LEFT JOIN EXCHANGE e ON ep.HOST_ID = e.HOST_ID
     WHERE 1 = 1
       AND pns.PHONE_NUMBER_SERIES_ID = p_phone_series_id
     ORDER BY pn.INTERNATIONAL_FORMAT,
              ep.HOST_ID,
              ep.EXCHANGE_PORT_NUMBER,
              ep.EXCHANGE_PORT_TYPE_CODE;

  /*  CURSOR c_port IS
      SELECT ep.ACCESS_POINT_ID, COUNT(naap.NETWORK_ADDRESS_ID)
      FROM EXCHANGE_PORT ep
        JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.ACCESS_POINT_ID = ep.ACCESS_POINT_ID
      WHERE 1=1
        AND nvl(p_date,v_sysdate) BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE,nvl(p_date,v_sysdate))
      GROUP BY naap.NETWORK_ADDRESS_ID;
  */
  col_phone_number  t_phone_number;
  col_exchange_port t_port_number;
  col_port_code     t_port_code;
  col_port_count    t_number;
  v_last_PN         PHONE_NUMBER.INTERNATIONAL_FORMAT%TYPE;
  v_first_PN        PHONE_NUMBER.INTERNATIONAL_FORMAT%TYPE;
  v_last_code       EXCHANGE_PORT.EXCHANGE_PORT_TYPE_CODE%TYPE;
  v_last_count      NUMBER;
  v_PI_obj          t_phone_interval_obj := t_phone_interval_obj(NULL, NULL, NULL, NULL, NULL);
  v_PI_obj_table    t_phone_interval_obj_tab := t_phone_interval_obj_tab();
  v_obj_counter     NUMBER := 1;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- procedure body here
  v_sysdate := SYSDATE;
  OPEN c_phone;

  FETCH C_PHONE BULK COLLECT
    INTO col_phone_number, col_port_code, col_exchange_port, col_port_count;

  v_last_PN    := NULL;
  v_last_code  := NULL;
  v_last_count := NULL;

  FOR i IN nvl(col_phone_number.FIRST, 1) .. nvl(col_phone_number.LAST, 0)
  LOOP
    IF v_first_PN IS NULL THEN
      v_first_PN := col_phone_number(i);
    END IF;
    IF v_last_code IS NULL THEN
      v_last_code := col_port_code(i);
    END IF;
    IF v_last_count IS NULL THEN
      v_last_count := col_port_count(i);
    END IF;

    IF ((to_number(col_phone_number(i)) != to_number(nvl(v_last_PN, '1')) + 1) AND (v_last_PN IS NOT NULL))
       OR (col_port_code(i) != v_last_code)
       OR (col_port_count(i) != v_last_count) THEN
      --MAKE OBJECT
      v_PI_obj.start_number := v_first_PN;
      v_PI_obj.end_number   := v_last_PN;
      v_PI_obj.port_type    := v_last_code;
      v_PI_obj.port_count   := v_last_count;
      --save start of
      v_first_PN := col_phone_number(i);

      v_PI_obj_table.EXTEND; -- grow
      v_PI_obj_table(v_obj_counter) := v_PI_obj; -- insert into collection
      v_obj_counter := v_obj_counter + 1;
    END IF;
    v_last_PN    := col_phone_number(i);
    v_last_code  := col_port_code(i);
    v_last_count := col_port_count(i);
  END LOOP;

  IF nvl(col_phone_number.LAST, 0) <> 0 THEN
    v_PI_obj.start_number := v_first_PN;
    v_PI_obj.end_number   := v_last_PN;
    v_PI_obj.port_type    := v_last_code;
    v_PI_obj.port_count   := v_last_count;
    --save start of
    v_PI_obj_table.EXTEND; -- grow
    v_PI_obj_table(v_obj_counter) := v_PI_obj; -- insert into collection
  ELSE
    NULL;
  END IF;

  OPEN result_list FOR
    SELECT t.start_number,
           t.end_number,
           ept.EXCHANGE_PORT_TYPE_NAME port_type,
           t.port_count phone_numbers_per_port
      FROM TABLE(CAST(v_PI_obj_table AS t_phone_interval_obj_tab)) t
      LEFT JOIN EXCHANGE_PORT_TYPE ept ON TRIM(decode(t.port_type, '@@', NULL, t.port_type)) =
                                          TRIM(ept.EXCHANGE_PORT_TYPE_CODE)
     ORDER BY t.start_number,
              t.end_number;
  IF c_phone%ISOPEN THEN
    CLOSE c_phone;
  END IF;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF c_phone%ISOPEN THEN
      CLOSE c_phone;
    END IF;
    OPEN result_list FOR
      SELECT error_code,
             error_message
        FROM dual;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_Phone_Series_Ports;

---------------------------------------------
--     PROCEDURE Generate_Ports_For_Phones
---------------------------------------------

procedure Generate_Ports_For_Phones
(
  p_phone_number_series_id IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
  col_phone_start          IN RSIG_EXCHANGE_PORT.t_phone_number_I,
  col_phone_end            IN RSIG_EXCHANGE_PORT.t_phone_number_I,
  col_port_code            IN RSIG_EXCHANGE_PORT.t_port_code_I,
  col_port_count           IN RSIG_EXCHANGE_PORT.t_number_I,
  p_start_date             IN DATE,
  p_user_id_of_change      IN NUMBER,
  handle_tran              IN CHAR,
  p_raise_error            IN CHAR,
  p_exchange_prefix        IN VARCHAR2,
  p_fill_zero              IN CHAR,
  p_count_digits           IN NUMBER,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
) IS
  v_event_source           VARCHAR2(60) := 'RSIG_EXCHANGE_PORT.Generate_Ports_For_Phones';
  v_sqlcode                NUMBER;
  v_result                 NUMBER;
  v_sysdate                DATE;
  v_access_point_id        ACCESS_POINT.ACCESS_POINT_ID%TYPE;
  v_exchange_port_number   EXCHANGE_PORT.EXCHANGE_PORT_NUMBER%TYPE;
  v_phone_count            NUMBER;
  v_start_date             DATE;
  v_exchange_id            EXCHANGE.HOST_ID%TYPE;
  v_obj_counter            NUMBER := 1;
  v_exist_phone_connection CHAR(1);

  v_PI_obj       t_phone_interval_obj := t_phone_interval_obj(NULL, NULL, NULL, NULL, NULL);
  v_PI_obj_table t_phone_interval_obj_tab := t_phone_interval_obj_tab();

  ex_phones_already_connected EXCEPTION;
  ex_not_enough_phones_for_ports EXCEPTION;
  ex_not_continual_interval EXCEPTION;

  v_exchange_prefix VARCHAR2(20);
  v_eport_number    NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;
  
  --check col_phone_start parameter
  IF (col_phone_start.COUNT = 0) OR (col_phone_start.COUNT = 1 AND col_phone_start(col_phone_start.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
  --check col_phone_end parameter
  IF (col_phone_end.COUNT = 0) OR (col_phone_end.COUNT = 1 AND col_phone_end(col_phone_end.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
    --check col_port_code parameter
  IF (col_port_code.COUNT = 0) OR (col_port_code.COUNT = 1 AND col_port_code(col_port_code.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
    --check col_port_count parameter
  IF (col_port_count.COUNT = 0) OR (col_port_count.COUNT = 1 AND col_port_count(col_port_count.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF (nvl(col_phone_start.LAST, -1) <> nvl(col_phone_end.LAST, -1) AND
     nvl(col_phone_end.LAST, -1) <> nvl(col_port_code.LAST, -1) AND
     nvl(col_port_code.LAST, -1) <> nvl(col_port_count.LAST, -1))
     OR (1 = 2) --tmp
   THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER,
                            'Invalid input parameter - input collections differs in length');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Generate_ports_for_phones;
  END IF;

  BEGIN
    SELECT pns.HOST_ID
      INTO v_exchange_id
      FROM PHONE_NUMBER_SERIES pns
      JOIN EXCHANGE e ON e.HOST_ID = pns.HOST_ID
     WHERE pns.PHONE_NUMBER_SERIES_ID = p_phone_number_series_id;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_EXCHANGE_NOT_EXISTS,
                              'Not exists exchange with same host id as phone_serie');
  END;

  v_phone_count     := 0;
  v_start_date      := nvl(p_start_date, SYSDATE);
  v_sysdate         := SYSDATE;
  v_exchange_prefix := nvl(p_exchange_prefix, '');

  FOR i IN nvl(col_phone_start.FIRST, 1) .. nvl(col_phone_start.LAST, 0)
  LOOP
    BEGIN
      SAVEPOINT RSIG_EXCH_P_before_serie;
      --test zda uz nejsou telefony spojeny,
      BEGIN
        SELECT RSIG_UTILS.c_YES
          INTO v_exist_phone_connection
          FROM dual
         WHERE EXISTS
         (SELECT 1
                  FROM PHONE_NUMBER pn
                  JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
                  JOIN EXCHANGE_PORT ep ON ep.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
                 WHERE 1 = 1
                   AND to_number(pn.INTERNATIONAL_FORMAT) BETWEEN to_number(col_phone_start(i)) AND
                       to_number(col_phone_end(i))
                   AND v_start_date BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE, v_start_date)
                   AND pn.PHONE_NUMBER_SERIES_ID = p_phone_number_series_id
                UNION
                SELECT 1
                  FROM PHONE_NUMBER pn
                  JOIN NETWORK_ADDRESS_STATUS_HISTORY nash ON nash.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
                 WHERE 1 = 1
                   AND v_start_date BETWEEN nash.START_DATE AND nvl(nash.END_DATE, v_start_date)
                   AND TRIM(nash.NET_ADDRESS_STATUS_CODE) != TRIM(RSIG_UTILS.c_FREE_PHONE_NUMBER_CODE)
                   AND to_number(pn.INTERNATIONAL_FORMAT) BETWEEN to_number(col_phone_start(i)) AND
                       to_number(col_phone_end(i))
                   AND pn.PHONE_NUMBER_SERIES_ID = p_phone_number_series_id);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          v_exist_phone_connection := RSIG_UTILS.c_NO;
      END;
      --if exist connected phoen number from serie - stop work
      IF v_exist_phone_connection = RSIG_UTILS.c_YES THEN
        v_result := RSIG_UTILS.c_NOT_FREE_PHONES;
        RAISE ex_phones_already_connected;
      END IF;

      -- get count of all phone numbers to conect them to ports
      SELECT COUNT(1)
        INTO v_phone_count
        FROM PHONE_NUMBER pn
       WHERE 1 = 1
         AND to_number(pn.INTERNATIONAL_FORMAT) BETWEEN to_number(col_phone_start(i)) AND
             to_number(col_phone_end(i));

      --detect if there exist enough phone numbers for port count
      IF MOD(v_phone_count, col_port_count(i)) <> 0 THEN
        v_result := RSIG_UTILS.c_PHONE_NUMBER_NOT_EXISTS;
        RAISE ex_not_enough_phones_for_ports;
      END IF;

      --this can be turned off
      IF v_phone_count <> (to_number(col_phone_end(i)) - to_number(col_phone_start(i)) + 1) THEN
        v_result := RSIG_UTILS.c_INVALID_INTERVAL;
        RAISE ex_not_continual_interval;
      END IF;

      v_phone_count := 0;

      FOR cur IN (SELECT pn.INTERNATIONAL_FORMAT,
                         pn.NETWORK_ADDRESS_ID
                    FROM PHONE_NUMBER pn
                   WHERE to_number(pn.INTERNATIONAL_FORMAT) BETWEEN to_number(col_phone_start(i)) AND
                         to_number(col_phone_end(i))
                   ORDER BY pn.INTERNATIONAL_FORMAT)
      LOOP
        -- test if I have to create new port (for making
        IF MOD(v_phone_count, col_port_count(i)) = 0 THEN
          --get next sequence value
          SELECT S_ACCESS_POINT.NEXTVAL INTO v_access_point_id FROM SYS.DUAL;

          --get next port number - possible place for conflict
          SELECT TO_CHAR(nvl(MAX(Get_Number_From_Char(ep.EXCHANGE_PORT_NUMBER)), 0) + 1)
            INTO v_exchange_port_number
            FROM EXCHANGE_PORT ep
           WHERE ep.HOST_ID = v_exchange_id;

          -- fill zero if p_fill_zero is Y
          IF p_fill_zero = 'Y' THEN
            v_eport_number := LENGTH(v_exchange_port_number);
            if nvl(p_count_digits, 0) > v_eport_number THEN
              v_exchange_port_number := LPAD(v_exchange_port_number, p_count_digits, '0');
            END IF;
          END IF;

          --create access point
          INSERT INTO ACCESS_POINT
            (ACCESS_POINT_ID)
          VALUES
            (v_access_point_id);

          -- create exchange_port
          INSERT INTO EXCHANGE_PORT
            (ACCESS_POINT_ID,
             HOST_ID,
             EXCHANGE_PORT_NUMBER,
             EXCHANGE_PORT_TYPE_CODE,
             DATE_OF_CHANGE,
             USER_ID_OF_CHANGE)
          VALUES
            (v_access_point_id,
             v_exchange_id,
             v_exchange_prefix || v_exchange_port_number,
             col_port_code(i),
             v_sysdate,
             p_user_id_of_change);
        END IF;

        --connect phone number and port
        INSERT INTO NETWORK_ADDRESS_ACCESS_POINT
          (ACCESS_POINT_ID,
           NETWORK_ADDRESS_ID,
           LINK_TYPE_CODE,
           FROM_DATE,
           TO_DATE,
           DATE_OF_CHANGE,
           USER_ID_OF_CHANGE)
        VALUES
          (v_access_point_id,
           cur.NETWORK_ADDRESS_ID,
           decode(MOD(v_phone_count, col_port_count(i)),
                  0,
                  RSIG_UTILS.c_MAIN_LINK_TYPE,
                  RSIG_UTILS.c_SECOND_LINK_TYPE), --link type code
           v_start_date,
           NULL,
           v_sysdate,
           p_user_id_of_change);

        v_phone_count := v_phone_count + 1;
      END LOOP;
      --report successfully created
      /*        v_PI_obj.start_number := col_phone_start(i);
              v_PI_obj.end_number   := col_phone_end(i);
              v_PI_obj.port_type    := col_port_code(i);
              v_PI_obj.port_count   := col_port_count(i);
              v_PI_obj.result     := RSIG_UTILS.c_OK;
              --save start of
              v_PI_obj_table.EXTEND;              -- grow
            v_PI_obj_table(v_obj_counter) := v_PI_obj;    -- insert into collection
            v_obj_counter := v_obj_counter + 1;
      */
    EXCEPTION
      WHEN ex_phones_already_connected
           OR ex_not_continual_interval
           OR ex_not_enough_phones_for_ports THEN
        ROLLBACK TO RSIG_EXCH_P_before_serie;
        v_PI_obj.start_number := col_phone_start(i);
        v_PI_obj.end_number   := col_phone_end(i);
        v_PI_obj.port_type    := col_port_code(i);
        v_PI_obj.port_count   := col_port_count(i);
        v_PI_obj.result       := v_result;
        --save start of
        v_PI_obj_table.EXTEND; -- grow
        v_PI_obj_table(v_obj_counter) := v_PI_obj; -- insert into collection
        v_obj_counter := v_obj_counter + 1;
    END;
  END LOOP;

  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  OPEN result_list FOR
    SELECT t.start_number,
           t.end_number,
           ept.EXCHANGE_PORT_TYPE_NAME port_type,
           t.port_count phone_numbers_per_port,
           t.result result
      FROM TABLE(CAST(v_PI_obj_table AS t_phone_interval_obj_tab)) t
      LEFT JOIN EXCHANGE_PORT_TYPE ept ON TRIM(decode(t.port_type, '@@', NULL, t.port_type)) =
                                          TRIM(ept.EXCHANGE_PORT_TYPE_CODE)
     ORDER BY t.start_number,
              t.end_number;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint Generate_ports_for_phones;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
    OPEN result_list FOR
      SELECT error_code,
             error_message
        FROM dual;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Generate_ports_for_phones;

---------------------------------------------
--     PROCEDURE Link_Ex_Port_To_Ph_Number
---------------------------------------------

procedure Link_Ex_Port_To_Ph_Number
(
  p_access_point_id   IN access_point.access_point_id%TYPE,
  p_phone_number      IN phone_number.international_format%TYPE,
  p_link_type_code    IN network_address_access_point.link_type_code%TYPE,
  p_from_date         IN DATE,
  p_user_id_of_change IN NUMBER,
  handle_tran         IN CHAR,
  p_raise_error       IN CHAR,
  error_code          OUT NUMBER,
  error_message       OUT VARCHAR2
) IS
  v_event_source      VARCHAR2(60) := 'RSIG_EXCHANGE_PORT.Link_Ex_Port_To_Ph_Number';
  v_sqlcode           number;
  v_access_point_id   access_point.access_point_id%TYPE;
  v_network_adress_id network_address.network_address_id%TYPE;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  IF (p_link_type_code IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Link_Ex_Port_to_Ph_Number;
  END IF;

  -- start of the procedure body
  ----------------------------------------------------------------------------------------------------------------------------------------------------

  BEGIN
    -- search for appropriate access point
    SELECT ep.access_point_id
      INTO v_access_point_id
      FROM exchange_port ep
     WHERE ep.access_point_id = p_access_point_id
       AND ep.deleted IS NULL;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- access point does not exist
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ACCES_POINT_NOT_EXISTS, 'Access point does not exist.');
  END;

  BEGIN
    -- search for appropriate phone number
    SELECT pn.network_address_id
      INTO v_network_adress_id
      FROM phone_number pn
     WHERE pn.international_format = p_phone_number
       AND (pn.deleted IS NULL OR pn.deleted>SYSDATE);

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- phone number does not exist
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_PHONE_NUMBER_NOT_EXISTS, 'Phone number does not exist.');
  END;

  INSERT INTO network_address_access_point
    (access_point_id,
     network_address_id,
     link_type_code,
     from_date,
     to_date,
     date_of_change,
     user_id_of_change)
  VALUES
    (v_access_point_id,
     v_network_adress_id,
     p_link_type_code,
     nvl(p_from_date, SYSDATE),
     NULL,
     SYSDATE,
     p_user_id_of_change);

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- end of the procedure body
  ----------------------------------------------------------------------------------------------------------------------------------------------------
  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint Link_Ex_Port_to_Ph_Number;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Link_Ex_Port_to_Ph_Number;

---------------------------------------------
--     FUNCTION Get_Number_From_Char
---------------------------------------------

FUNCTION Get_Number_From_Char(p_string IN VARCHAR2 -- string to change
                              ) RETURN NUMBER IS

  v_char       CHAR(1);
  v_chr_number VARCHAR2(40);

BEGIN
  v_chr_number := '0';
  IF LENGTH(p_string) > 0 THEN
    FOR a IN 1 .. LENGTH(p_string)
    LOOP
      v_char := SUBSTR(p_string, a, 1);
      IF v_char >= '0'
         AND v_char <= '9' THEN
        v_chr_number := v_chr_number || v_char;
      END IF;
    END LOOP;
  END IF;
  RETURN TO_NUMBER(v_chr_number);
END Get_Number_From_Char;

END RSIG_EXCHANGE_PORT;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_EXCHANGE_PORT.pkb,v 1.28 2003/12/22 11:32:38 rhejduk Exp $
/
