CREATE package body fastp_sim_series_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_fast_parallel_params return fast_parallel_pkg.t_fast_parallel_params
is
  v_res fast_parallel_pkg.t_fast_parallel_params;
begin
  ------------------------------
  v_res.block_count := install_pkg.nnget_option_num(c_opt_fastp_block_count, c_def_fastp_block_count);
  v_res.job_count := install_pkg.nnget_option_num(c_opt_fastp_job_count, c_def_fastp_job_count);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function row2t_range(p_row sim_series%rowtype) return range_pkg.t_range
is
  v_res range_pkg.t_range;
begin
  ------------------------------
  v_res := null;
  ------------------------------
  v_res.id := p_row.sim_series_id;
  ------------------------------
  get_items_from_to(p_row, v_res.item_from, v_res.item_to);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function t_range2row
(
  p_range range_pkg.t_range,
  p_user_id number,
  p_date date,
  p_sim_card_type_code varchar2,
  p_host_id number,
  p_network_operator_id number
)
return sim_series%rowtype
is
  v_res sim_series%rowtype;
begin
  ------------------------------
  range_pkg.XCheck_t_range(p_range => p_range, p_check_vals => FALSE);
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_sim_card_type_code is null, 'p_sim_card_type_code');
  --!_!util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_network_operator_id is null, 'p_network_operator_id');
  ------------------------------
  v_res.sim_series_id := p_range.id;
  ------------------------------
  v_res.start_imsi_number := p_range.item_from;
  v_res.end_imsi_number := p_range.item_to;
  ------------------------------
  v_res.date_of_change := p_date;
  v_res.user_id_of_change := p_user_id;
  v_res.sim_card_type_code := p_sim_card_type_code;
  v_res.host_id := p_host_id;
  v_res.network_operator_id := p_network_operator_id;
  v_res.deleted := null;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_items_from_to
(
  p_row sim_series%rowtype,
  p_item_from out varchar2,
  p_item_to out varchar2
)
is
begin
  ------------------------------
  p_item_from := p_row.start_imsi_number;
  p_item_to := p_row.end_imsi_number;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure copy_ss_host
(
  p_ss_id_src number,
  p_ss_id_dst number,
  p_user_id number,
  p_date date
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ss_id_src is null, 'p_ss_id_src');
  util_pkg.XCheck_Cond_Missing(p_ss_id_dst is null, 'p_ss_id_dst');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  insert into sim_series_host
  (
    sim_series_id,
    host_type_code,
    host_id,
    start_date,
    end_date,
    date_of_change,
    user_id_of_change
  )
  select /*+ index(z I_SSH_SIM_SERIES_ID)*/
      p_ss_id_dst sim_series_id,
      host_type_code,
      host_id,
      start_date,
      end_date,
      p_date date_of_change,
      p_user_id user_id_of_change
    from sim_series_host z
    where 1 = 1
    and z.sim_series_id = p_ss_id_src
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure delete_ss_host
(
  p_ss_id number,
  p_user_id number,
  p_date date
)
is
  v_date date := sysdate;  --!_!
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ss_id is null, 'p_ss_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  update /*+ index(z I_SSH_SIM_SERIES_ID)*/
      sim_series_host z
    set
      end_date = v_date,
      date_of_change = p_date,
      user_id_of_change = p_user_id
    where 1 = 1
    and sim_series_id = p_ss_id
    and nvl(end_date,to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) < v_date
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure copy_ss_status_validity
(
  p_ss_id_src number,
  p_ss_id_dst number,
  p_user_id number,
  p_date date
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ss_id_src is null, 'p_ss_id_src');
  util_pkg.XCheck_Cond_Missing(p_ss_id_dst is null, 'p_ss_id_dst');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  insert into sim_series_status_validity
  (
    status_code,
    sim_series_id,
    start_date,
    end_date,
    date_of_change,
    user_id_of_change
  )
  select /*+ index(z I_SIMSESTAVA_SIM_SERIES_ID)*/
      status_code,
      p_ss_id_dst sim_series_id,
      start_date,
      end_date,
      p_date date_of_change,
      p_user_id user_id_of_change
    from sim_series_status_validity z
    where 1 = 1
    and z.sim_series_id = p_ss_id_src
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure delete_ss_status_validity
(
  p_ss_id number,
  p_user_id number,
  p_date date
)
is
  v_date date := sysdate; --!_!
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ss_id is null, 'p_ss_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  update /*+ index(z I_SIMSESTAVA_SIM_SERIES_ID2)*/
      sim_series_status_validity z
    set
      end_date = v_date,
      date_of_change = p_date,
      user_id_of_change = p_user_id
    where 1 = 1
    and sim_series_id = p_ss_id
    and nvl(end_date,to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) < v_date
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_ranges_real
(
  p_item_from varchar2,
  p_item_to varchar2,
  p_range_size integer,
  p_range_numbers out ct_number,
  p_range_item_counts out ct_number
)
is
  v_item_from_num number;
begin
  ------------------------------
  range_pkg.XCheck_rangeable(p_item_from, p_item_to);
  util_pkg.XCheck_size(p_range_size, 'p_range_size');
  ------------------------------
  v_item_from_num := range_pkg.item2num(p_item_from);
  ------------------------------
  select /*+ index(z UK_SIM_IMSI)*/
    floor((to_number(imsi, util_pkg.c_number_format2, util_pkg.c_number_nlsparam) - v_item_from_num)/p_range_size) + 1 part_no,
    count(1) cnt
    bulk collect into
    p_range_numbers,
    p_range_item_counts
  from sim_card z
  where 1 = 1
    and imsi between p_item_from and p_item_to
    and length(imsi) = length(p_item_from)
  group by floor((to_number(imsi, util_pkg.c_number_format2, util_pkg.c_number_nlsparam) - v_item_from_num)/p_range_size) + 1
  order by part_no
  ;
  ------------------------------
  --!_! sim_imsi
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_dummy_row(p_row_template sim_series%rowtype) return sim_series%rowtype
is
  v_res sim_series%rowtype;
begin
  ------------------------------
  v_res := p_row_template;
  ------------------------------
  v_res.start_imsi_number := util_pkg.number_to_char(p_row_template.sim_series_id);
  v_res.end_imsi_number := util_pkg.number_to_char(p_row_template.sim_series_id);
  v_res.sim_card_type_code := p_row_template.sim_card_type_code;
  v_res.host_id := p_row_template.host_id;
  v_res.network_operator_id := p_row_template.network_operator_id;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function create_dummy_range
(
  p_row_template sim_series%rowtype,
  p_user_id number
) return number
is
  v_row sim_series%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_row := make_dummy_row(p_row_template => p_row_template);
  ------------------------------
  v_row.sim_series_id := NULL; --!_!
  v_row.user_id_of_change := p_user_id;
  ------------------------------
  vp_sim_series.version_open(v_row);
  ------------------------------
  return v_row.sim_series_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure delete_dummy_range
(
  p_range_id number,
  p_user_id number
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_id is null, 'p_range_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  vp_sim_series.version_close(p_range_id, p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure change_items_range_id
(
  p_item_from varchar2,
  p_item_to varchar2,
  p_range_id_new number
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_item_from is null, 'p_item_from');
  util_pkg.XCheck_Cond_Missing(p_item_to is null, 'p_item_to');
  util_pkg.XCheck_Cond_Missing(p_range_id_new is null, 'p_range_id_new');
  ------------------------------
  update /*+ index(z UK_SIM_IMSI)*/
    sim_card z
  set
    sim_series_id = p_range_id_new
  where 1 = 1
    and imsi between p_item_from and p_item_to
    and length(imsi) = length(p_item_from)
  ;
  ------------------------------
  update /*+ index(z UK_SIM_IMSI_IMSI)*/
    sim_imsi z
  set
    sim_series_id = p_range_id_new
  where 1 = 1
    and imsi between p_item_from and p_item_to
    and length(imsi) = length(p_item_from)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure split_range_pre_forward
(
  p_item_split_from varchar2,
  p_range range_pkg.t_range,
  p_block_count number,
  p_job_count number,
  p_user_id number,
  p_date date,
  p_range_to_trunc_item_froms out ct_varchar_s,
  p_range_to_trunc_item_tos out ct_varchar_s,
  p_range_to_truncation out range_pkg.t_range,
  p_range_to_creation out range_pkg.t_range,
  p_locker_id out number
)
is
  lc_dummy_id number := -100500;
  v_sp_name varchar2(30);
  v_row_template sim_series%rowtype;
  v_range_template range_pkg.t_range;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  range_pkg.XCheck_t_range(p_range => p_range, p_check_vals => FALSE);
  range_pkg.XCheck_3rangeable4split(p_range.item_from, p_item_split_from, p_range.item_to);
  util_pkg.XCheck_size(p_block_count, 'p_block_count');
  util_pkg.XCheck_size(p_job_count, 'p_job_count');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  p_locker_id := range_pkg.xget_locker_id(p_range);
  ------------------------------
  v_row_template := vp_sim_series.xget1(p_range.id, p_date);
  v_range_template := row2t_range(v_row_template);
  ------------------------------
  if 1 = 0
    or not range_pkg.is_equal(p_range.item_from, v_range_template.item_from)
    or not range_pkg.is_equal(p_range.item_to, v_range_template.item_to)
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_changed, util_pkg.c_msg_object_changed || util_pkg.c_msg_delim01 || VP_SIM_SERIES.c_this_name || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_range.id));
    ------------------------------
  end if;
  ------------------------------
  split_range_i
  (
    p_item_split_from => p_item_split_from,
    p_range => p_range,
    p_block_count => p_block_count,
    p_job_count => p_job_count,
    p_range_to_creation_id => lc_dummy_id, --!_!temporary and explicit
    p_range_to_trunc_item_froms => p_range_to_trunc_item_froms,
    p_range_to_trunc_item_tos => p_range_to_trunc_item_tos,
    p_range_to_truncation => p_range_to_truncation,
    p_range_to_creation => p_range_to_creation
  );
  ------------------------------
  p_range_to_creation.id := create_dummy_range --!_!real id instead of lc_dummy_id
  (
    p_row_template => v_row_template,
    p_user_id => p_user_id
  );
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  locker_pkg.release_locker(p_locker_id); --!_!silent if not exists
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure split_range_pre_backward
(
  p_range_to_creation_id number,
  p_locker_id number,
  p_user_id number
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range_to_creation_id is null, 'p_range_to_creation_id');
  util_pkg.XCheck_Cond_Missing(p_locker_id is null, 'p_locker_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  delete_dummy_range
  (
    p_range_id => p_range_to_creation_id,
    p_user_id => p_user_id
  );
  ------------------------------
  locker_pkg.release_locker(p_locker_id);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  --!_!locker_pkg.release_locker(p_locker_id); --!_!silent if not exists
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure split_range_mid_forward
(
  p_item_from varchar2,
  p_item_to varchar2,
  p_range_id_new number
)
is
begin
  ------------------------------
  change_items_range_id
  (
    p_item_from => p_item_from,
    p_item_to => p_item_to,
    p_range_id_new => p_range_id_new
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure split_range_mid_backward
(
  p_item_from varchar2,
  p_item_to varchar2,
  p_range_id_old number --!_!
)
is
begin
  ------------------------------
  change_items_range_id
  (
    p_item_from => p_item_from,
    p_item_to => p_item_to,
    p_range_id_new => p_range_id_old --!_!
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure split_range_post_forward
(
  p_range_to_truncation range_pkg.t_range,
  p_range_to_creation range_pkg.t_range,
  p_locker_id number,
  p_release_locker_on_error boolean,
  p_user_id number,
  p_date date
)
is
  v_sp_name varchar2(30);
  v_template_row sim_series%rowtype;
  v_row_to_truncation sim_series%rowtype;
  v_row_to_creation sim_series%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  range_pkg.XCheck_t_range(p_range => p_range_to_truncation, p_check_vals => FALSE);
  range_pkg.XCheck_t_range(p_range => p_range_to_creation, p_check_vals => FALSE);
  util_pkg.XCheck_Cond_Missing(p_locker_id is null, 'p_locker_id');
  util_pkg.XCheck_Cond_Missing(p_release_locker_on_error is null, 'p_release_locker_on_error');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_template_row := vp_sim_series.xget1(p_range_to_truncation.id, p_date);
  ------------------------------
  v_row_to_truncation := t_range2row
  (
    p_range => p_range_to_truncation,
    p_user_id => p_user_id,
    p_date => p_date,
    p_sim_card_type_code => v_template_row.sim_card_type_code,
    p_host_id => v_template_row.host_id,
    p_network_operator_id => v_template_row.network_operator_id
  );
  ------------------------------
  v_row_to_creation := t_range2row
  (
    p_range => p_range_to_creation,
    p_user_id => p_user_id,
    p_date => p_date,
    p_sim_card_type_code => v_template_row.sim_card_type_code,
    p_host_id => v_template_row.host_id,
    p_network_operator_id => v_template_row.network_operator_id
  );
  ------------------------------
  vp_sim_series.version_change(v_row_to_truncation);
  vp_sim_series.version_change(v_row_to_creation);
  ------------------------------
  copy_ss_host
  (
    p_ss_id_src => v_row_to_truncation.sim_series_id,
    p_ss_id_dst => v_row_to_creation.sim_series_id,
    p_user_id => p_user_id,
    p_date => p_date
  );
  ------------------------------
  copy_ss_status_validity
  (
    p_ss_id_src => v_row_to_truncation.sim_series_id,
    p_ss_id_dst => v_row_to_creation.sim_series_id,
    p_user_id => p_user_id,
    p_date => p_date
  );
  ------------------------------
  locker_pkg.release_locker(p_locker_id);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  if p_release_locker_on_error --!_!p_release_locker_on_error can be null; util_pkg.XCheck_Cond_Missing can be not reached yet
  then
    ------------------------------
    locker_pkg.release_locker(p_locker_id); --!_!silent if not exists
    ------------------------------
  end if;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure split_range_post_backward
(
  p_range_initial range_pkg.t_range,
  p_range_to_dummy_id number,
  p_range_to_truncation range_pkg.t_range,
  p_range_to_creation range_pkg.t_range,
  p_user_id number,
  p_date date,
  p_locker_id out number
)
is
  v_sp_name varchar2(30);
  v_template_row sim_series%rowtype;
  v_row_initial sim_series%rowtype;
  v_row_to_dummy sim_series%rowtype;
  v_range_to_truncation range_pkg.t_range;
  v_range_to_creation range_pkg.t_range;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  range_pkg.XCheck_t_range(p_range => p_range_initial, p_check_vals => FALSE);
  util_pkg.XCheck_Cond_Missing(p_range_to_dummy_id is null, 'p_range_to_dummy_id');
  range_pkg.XCheck_t_range(p_range => p_range_to_truncation, p_check_vals => FALSE);
  range_pkg.XCheck_t_range(p_range => p_range_to_creation, p_check_vals => FALSE);
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  p_locker_id := range_pkg.xget_locker_id(p_range_initial);
  ------------------------------
  v_range_to_truncation := row2t_range(vp_sim_series.xget1(p_range_to_truncation.id, p_date));
  ------------------------------
  if 1 = 0
    or not range_pkg.is_equal(p_range_to_truncation.item_from, v_range_to_truncation.item_from)
    or not range_pkg.is_equal(p_range_to_truncation.item_to, v_range_to_truncation.item_to)
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_changed, util_pkg.c_msg_object_changed || util_pkg.c_msg_delim01 || VP_SIM_SERIES.c_this_name || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_range_to_truncation.id));
    ------------------------------
  end if;
  ------------------------------
  v_range_to_creation := row2t_range(vp_sim_series.xget1(p_range_to_creation.id, p_date));
  ------------------------------
  if 1 = 0
    or not range_pkg.is_equal(p_range_to_creation.item_from, v_range_to_creation.item_from)
    or not range_pkg.is_equal(p_range_to_creation.item_to, v_range_to_creation.item_to)
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_changed, util_pkg.c_msg_object_changed || util_pkg.c_msg_delim01 || VP_SIM_SERIES.c_this_name || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_range_to_creation.id));
    ------------------------------
  end if;
  ------------------------------
  delete_ss_host
  (
    p_ss_id => p_range_to_dummy_id,
    p_user_id => p_user_id,
    p_date => p_date
  );
  ------------------------------
  delete_ss_status_validity
  (
    p_ss_id => p_range_to_dummy_id,
    p_user_id => p_user_id,
    p_date => p_date
  );
  ------------------------------
  v_template_row := vp_sim_series.xget1(p_range_initial.id, p_date);
  ------------------------------
  v_row_to_dummy := make_dummy_row(p_row_template => vp_sim_series.xget1(p_range_to_dummy_id, p_date));
  v_row_to_dummy.user_id_of_change := p_user_id;
  ------------------------------
  v_row_initial := t_range2row
  (
    p_range => p_range_initial,
    p_user_id => p_user_id,
    p_date => p_date,
    p_sim_card_type_code => v_template_row.sim_card_type_code,
    p_host_id => v_template_row.host_id,
    p_network_operator_id => v_template_row.network_operator_id
  );
  ------------------------------
  vp_sim_series.version_change(v_row_to_dummy);
  vp_sim_series.version_change(v_row_initial);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  locker_pkg.release_locker(p_locker_id); --!_!silent if not exists
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function prm_pre_serialize(p_obj t_param_action_pre) return clob
is
  v_res clob;
  v_delim varchar2(10);
  v_delim2 varchar2(10);
  v_coll ct_varchar;
begin
  ------------------------------
  v_delim := fast_parallel_pkg.get_serialization_delim;
  v_delim2 := fast_parallel_pkg.get_serialization_delim2;
  ------------------------------
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.bool_to_char(p_obj.skip_action));
  util_pkg.add_ct_varchar_val(v_coll, p_obj.item_split_from);
  util_pkg.add_ct_varchar_val(v_coll, range_pkg.range_serialize(p_obj => p_obj.range, p_delim => v_delim2));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.block_count));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.job_count));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.user_id));
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) != c_srzi_count_pre, 'Wrong format 001');
  ------------------------------
  v_res := to_clob(util_pkg.merge_string(v_coll, v_delim));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function prm_pre_deserialize(p_str clob) return t_param_action_pre
is
  v_res t_param_action_pre;
  v_delim varchar2(10);
  v_delim2 varchar2(10);
  v_coll ct_varchar;
begin
  ------------------------------
  v_delim := fast_parallel_pkg.get_serialization_delim;
  v_delim2 := fast_parallel_pkg.get_serialization_delim2;
  ------------------------------
  v_coll := util_pkg.split_string(p_str, v_delim); --!_!clob to varchar2(???)
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) < c_srzi_count_pre, 'Wrong format 001');
  ------------------------------
  v_res.skip_action := util_pkg.char_to_bool(v_coll(c_srzi_pre_skip_action));
  v_res.item_split_from := v_coll(c_srzi_pre_item_split_from);
  v_res.range := range_pkg.range_deserialize(p_str => v_coll(c_srzi_pre_range), p_delim => v_delim2);
  v_res.block_count := util_pkg.char_to_number(v_coll(c_srzi_pre_block_count));
  v_res.job_count := util_pkg.char_to_number(v_coll(c_srzi_pre_job_count));
  v_res.user_id := util_pkg.char_to_number(v_coll(c_srzi_pre_user_id));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function prm_paral_serialize(p_obj t_param_action_parallel) return clob
is
  v_res clob;
  v_delim varchar2(10);
  v_coll ct_varchar;
begin
  ------------------------------
  v_delim := fast_parallel_pkg.get_serialization_delim;
  ------------------------------
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.bool_to_char(p_obj.skip_action));
  util_pkg.add_ct_varchar_val(v_coll, p_obj.item_from);
  util_pkg.add_ct_varchar_val(v_coll, p_obj.item_to);
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.range_id_old));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.range_id_new));
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) != c_srzi_count_paral, 'Wrong format 001');
  ------------------------------
  v_res := to_clob(util_pkg.merge_string(v_coll, v_delim));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function prm_paral_deserialize(p_str clob) return t_param_action_parallel
is
  v_res t_param_action_parallel;
  v_delim varchar2(10);
  v_coll ct_varchar;
begin
  ------------------------------
  v_delim := fast_parallel_pkg.get_serialization_delim;
  ------------------------------
  v_coll := util_pkg.split_string(p_str, v_delim); --!_!clob to varchar2(???)
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) < c_srzi_count_paral, 'Wrong format 001');
  ------------------------------
  v_res.skip_action := util_pkg.char_to_bool(v_coll(c_srzi_paral_skip_action));
  v_res.item_from := v_coll(c_srzi_paral_item_from);
  v_res.item_to := v_coll(c_srzi_paral_item_to);
  v_res.range_id_old := util_pkg.char_to_number(v_coll(c_srzi_paral_range_id_old));
  v_res.range_id_new := util_pkg.char_to_number(v_coll(c_srzi_paral_range_id_new));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function prm_post_serialize(p_obj t_param_action_post) return clob
is
  v_res clob;
  v_delim varchar2(10);
  v_delim2 varchar2(10);
  v_coll ct_varchar;
begin
  ------------------------------
  v_delim := fast_parallel_pkg.get_serialization_delim;
  v_delim2 := fast_parallel_pkg.get_serialization_delim2;
  ------------------------------
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.bool_to_char(p_obj.skip_action));
  util_pkg.add_ct_varchar_val(v_coll, range_pkg.range_serialize(p_obj => p_obj.range_to_truncation, p_delim => v_delim2));
  util_pkg.add_ct_varchar_val(v_coll, range_pkg.range_serialize(p_obj => p_obj.range_to_creation, p_delim => v_delim2));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.locker_id));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.bool_to_char(p_obj.release_locker_on_error));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.user_id));
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) != c_srzi_count_post, 'Wrong format 001');
  ------------------------------
  v_res := to_clob(util_pkg.merge_string(v_coll, v_delim));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function prm_post_deserialize(p_str clob) return t_param_action_post
is
  v_res t_param_action_post;
  v_delim varchar2(10);
  v_delim2 varchar2(10);
  v_coll ct_varchar;
begin
  ------------------------------
  v_delim := fast_parallel_pkg.get_serialization_delim;
  v_delim2 := fast_parallel_pkg.get_serialization_delim2;
  ------------------------------
  v_coll := util_pkg.split_string(p_str, v_delim); --!_!clob to varchar2(???)
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) < c_srzi_count_post, 'Wrong format 001');
  ------------------------------
  v_res.skip_action := util_pkg.char_to_bool(v_coll(c_srzi_post_skip_action));
  v_res.range_to_truncation := range_pkg.range_deserialize(p_str => v_coll(c_srzi_post_range2truncation), p_delim => v_delim2);
  v_res.range_to_creation := range_pkg.range_deserialize(p_str => v_coll(c_srzi_post_range2creation), p_delim => v_delim2);
  v_res.locker_id := util_pkg.char_to_number(v_coll(c_srzi_post_locker_id));
  v_res.release_locker_on_error := util_pkg.char_to_bool(v_coll(c_srzi_post_release_lckr_onerr));
  v_res.user_id := util_pkg.char_to_number(v_coll(c_srzi_post_user_id));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_job_text(p_job_text_raw clob) return clob
is
  v_res clob;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_job_text_raw is null, 'p_job_text_raw');
  ------------------------------
  v_res := p_job_text_raw;
  ------------------------------
  v_res := replace(v_res, ':p_this_package_name', c_this_package_name);
  ------------------------------
  v_res := replace(v_res, ':p_qwerty_job_id', fast_parallel_pkg.c_pph_job_id);
  v_res := replace(v_res, ':p_qwerty_direction_forward', fast_parallel_pkg.c_pph_direction_forward);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_flow
(
  p_flow_type_id number,
  p_user_id number,
  p_parallel_job_count number,
  p_task_pre_job_context clob
) return fast_parallel_pkg.t_flow
is
  v_res fast_parallel_pkg.t_flow;
  v_tasks fast_parallel_pkg.cit_task;
  v_jobs_pre fast_parallel_pkg.cit_job;
  v_jobs_parallel fast_parallel_pkg.cit_job;
  v_jobs_post fast_parallel_pkg.cit_job;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_flow_type_id is null, 'p_flow_type_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_size(p_parallel_job_count, 'p_parallel_job_count');
  ------------------------------
  ------------------------------
  v_jobs_pre(c_job_single_index_pre) := fast_parallel_pkg.make_t_job2
  (
    p_user_id => p_user_id,
    p_retry_count => install_pkg.nnget_option_num(c_opt_fastp_prej_retry_count, c_def_fastp_prej_retry_count),
    p_retry_interval_sec => install_pkg.nnget_option_num(c_opt_fastp_prej_retry_sec, c_def_fastp_prej_retry_sec),
    p_idle_sleep_time_sec => install_pkg.nnget_option_num(c_opt_fastp_prej_slp_tm_sec, c_def_fastp_prej_slp_tm_sec),
    p_expired_timeout_sec => install_pkg.nnget_option_num(c_opt_fastp_prej_exp_tmt_sec, c_def_fastp_prej_exp_tmt_sec),
    p_wait_lock_sec => install_pkg.nnget_option_num(c_opt_fastp_prej_wt_lck_sec, c_def_fastp_prej_wt_lck_sec),
    p_keepalive_sec => install_pkg.nnget_option_num(c_opt_fastp_prej_keepalv_sec, c_def_fastp_prej_keepalv_sec),
    p_job_text => make_job_text(c_job_text_pre),
    p_context => p_task_pre_job_context
  );
  ------------------------------
  for v_i in 1..p_parallel_job_count
  loop
    ------------------------------
    v_jobs_parallel(v_i) := fast_parallel_pkg.make_t_job2
    (
      p_user_id => p_user_id,
      p_retry_count => install_pkg.nnget_option_num(c_opt_fastp_paralj_retry_count, c_def_fastp_paralj_retry_count),
      p_retry_interval_sec => install_pkg.nnget_option_num(c_opt_fastp_paralj_retry_sec, c_def_fastp_paralj_retry_sec),
      p_idle_sleep_time_sec => install_pkg.nnget_option_num(c_opt_fastp_paralj_slp_tm_sec, c_def_fastp_paralj_slp_tm_sec),
      p_expired_timeout_sec => install_pkg.nnget_option_num(c_opt_fastp_paralj_exp_tmt_sec, c_def_fastp_paralj_exp_tmt_sec),
      p_wait_lock_sec => install_pkg.nnget_option_num(c_opt_fastp_paralj_wt_lck_sec, c_def_fastp_paralj_wt_lck_sec),
      p_keepalive_sec => install_pkg.nnget_option_num(c_opt_fastp_paralj_keepalv_sec, c_def_fastp_paralj_keepalv_sec),
      p_job_text => make_job_text(c_job_text_parallel),
      p_context => null
    );
    ------------------------------
  end loop;
  ------------------------------
  v_jobs_post(c_job_single_index_post) := fast_parallel_pkg.make_t_job2
  (
    p_user_id => p_user_id,
    p_retry_count => install_pkg.nnget_option_num(c_opt_fastp_postj_retry_count, c_def_fastp_postj_retry_count),
    p_retry_interval_sec => install_pkg.nnget_option_num(c_opt_fastp_postj_retry_sec, c_def_fastp_postj_retry_sec),
    p_idle_sleep_time_sec => install_pkg.nnget_option_num(c_opt_fastp_postj_slp_tm_sec, c_def_fastp_postj_slp_tm_sec),
    p_expired_timeout_sec => install_pkg.nnget_option_num(c_opt_fastp_postj_exp_tmt_sec, c_def_fastp_postj_exp_tmt_sec),
    p_wait_lock_sec => install_pkg.nnget_option_num(c_opt_fastp_postj_wt_lck_sec, c_def_fastp_postj_wt_lck_sec),
    p_keepalive_sec => install_pkg.nnget_option_num(c_opt_fastp_postj_keepalv_sec, c_def_fastp_postj_keepalv_sec),
    p_job_text => make_job_text(c_job_text_post),
    p_context => null
  );
  ------------------------------
  ------------------------------
  v_tasks(c_task_index_pre) := fast_parallel_pkg.make_t_task
  (
    p_user_id => p_user_id,
    p_completion_rule => fast_parallel_pkg.c_cr_all,
    p_retry_count => install_pkg.nnget_option_num(c_opt_fastp_pre_retry_count, c_def_fastp_pre_retry_count),
    p_retry_interval_sec => install_pkg.nnget_option_num(c_opt_fastp_pre_retry_sec, c_def_fastp_pre_retry_sec),
    p_wait_all_jobs_completion => install_pkg.nnget_option_bool(c_opt_fastp_pre_waitalljobs, c_def_fastp_pre_waitalljobs),
    p_sync_commit => install_pkg.nnget_option_bool(c_opt_fastp_pre_sync_commit, c_def_fastp_pre_sync_commit),
    p_idle_sleep_time_sec => install_pkg.nnget_option_num(c_opt_fastp_pre_slp_tm_sec, c_def_fastp_pre_slp_tm_sec),
    p_expired_timeout_sec => install_pkg.nnget_option_num(c_opt_fastp_pre_exp_tmt_sec, c_def_fastp_pre_exp_tmt_sec),
    p_wait_lock_sec => install_pkg.nnget_option_num(c_opt_fastp_pre_wt_lck_sec, c_def_fastp_pre_wt_lck_sec),
    p_context => null,
    p_jobs => v_jobs_pre,
    p_set_childs_parent => true
  );
  ------------------------------
  v_tasks(c_task_index_paral) := fast_parallel_pkg.make_t_task
  (
    p_user_id => p_user_id,
    p_completion_rule => fast_parallel_pkg.c_cr_all,
    p_retry_count => install_pkg.nnget_option_num(c_opt_fastp_paral_retry_count, c_def_fastp_paral_retry_count),
    p_retry_interval_sec => install_pkg.nnget_option_num(c_opt_fastp_paral_retry_sec, c_def_fastp_paral_retry_sec),
    p_wait_all_jobs_completion => install_pkg.nnget_option_bool(c_opt_fastp_paral_waitalljobs, c_def_fastp_paral_waitalljobs),
    p_sync_commit => install_pkg.nnget_option_bool(c_opt_fastp_paral_sync_commit, c_def_fastp_paral_sync_commit),
    p_idle_sleep_time_sec => install_pkg.nnget_option_num(c_opt_fastp_paral_slp_tm_sec, c_def_fastp_paral_slp_tm_sec),
    p_expired_timeout_sec => install_pkg.nnget_option_num(c_opt_fastp_paral_exp_tmt_sec, c_def_fastp_paral_exp_tmt_sec),
    p_wait_lock_sec => install_pkg.nnget_option_num(c_opt_fastp_paral_wt_lck_sec, c_def_fastp_paral_wt_lck_sec),
    p_context => null,
    p_jobs => v_jobs_parallel,
    p_set_childs_parent => true
  );
  ------------------------------
  v_tasks(c_task_index_post) := fast_parallel_pkg.make_t_task
  (
    p_user_id => p_user_id,
    p_completion_rule => fast_parallel_pkg.c_cr_all,
    p_retry_count => install_pkg.nnget_option_num(c_opt_fastp_post_retry_count, c_def_fastp_post_retry_count),
    p_retry_interval_sec => install_pkg.nnget_option_num(c_opt_fastp_post_retry_sec, c_def_fastp_post_retry_sec),
    p_wait_all_jobs_completion => install_pkg.nnget_option_bool(c_opt_fastp_post_waitalljobs, c_def_fastp_post_waitalljobs),
    p_sync_commit => install_pkg.nnget_option_bool(c_opt_fastp_post_sync_commit, c_def_fastp_post_sync_commit),
    p_idle_sleep_time_sec => install_pkg.nnget_option_num(c_opt_fastp_post_slp_tm_sec, c_def_fastp_post_slp_tm_sec),
    p_expired_timeout_sec => install_pkg.nnget_option_num(c_opt_fastp_post_exp_tmt_sec, c_def_fastp_post_exp_tmt_sec),
    p_wait_lock_sec => install_pkg.nnget_option_num(c_opt_fastp_post_wt_lck_sec, c_def_fastp_post_wt_lck_sec),
    p_context => null,
    p_jobs => v_jobs_post,
    p_set_childs_parent => true
  );
  ------------------------------
  ------------------------------
  v_res := fast_parallel_pkg.make_t_flow
  (
    p_user_id => p_user_id,
    p_flow_type_id => p_flow_type_id,
    p_reversible => install_pkg.nnget_option_bool(c_opt_fastp_flow_reversible, c_def_fastp_flow_reversible),
    p_direction_forward => TRUE,
    p_retry_count => install_pkg.nnget_option_num(c_opt_fastp_flow_retry_count, c_def_fastp_flow_retry_count),
    p_retry_interval_sec => install_pkg.nnget_option_num(c_opt_fastp_flow_retry_sec, c_def_fastp_flow_retry_sec),
    p_wait_lock_sec => install_pkg.nnget_option_num(c_opt_fastp_flow_wt_lck_sec, c_def_fastp_flow_wt_lck_sec),
    p_context => null,
    p_tasks => v_tasks,
    p_set_childs_parent => true
  );
  ------------------------------
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_target_ranges_by_blocks
(
  p_item_boundary varchar2,
  p_item_from varchar2,
  p_item_to varchar2,
  p_block_count integer,
  p_max_target_range_count integer,
  p_ranges_approx_count out ct_number,
  p_ranges_from out ct_varchar_s,
  p_ranges_to out ct_varchar_s
)
is
  v_block_size integer;
  v_block_numbers ct_number;
  v_block_item_counts ct_number;
begin
  ------------------------------
  range_pkg.XCheck_3rangeable4split(p_item_from, p_item_boundary, p_item_to);
  util_pkg.XCheck_size(p_block_count, 'p_block_count');
  util_pkg.XCheck_size(p_max_target_range_count, 'p_max_target_range_count');
  ------------------------------
  v_block_size := range_pkg.calc_block_size
  (
    p_item_from => p_item_from,
    p_item_to => p_item_to,
    p_block_count => p_block_count
  );
  ------------------------------
  get_ranges_real
  (
    p_item_from => p_item_from,
    p_item_to => p_item_to,
    p_range_size => v_block_size,
    p_range_numbers => v_block_numbers,
    p_range_item_counts => v_block_item_counts
  );
  ------------------------------
  range_pkg.make_target_ranges_by_blocks
  (
    p_item_boundary => p_item_boundary,
    p_item_from => p_item_from,
    p_item_to => p_item_to,
    p_block_size => v_block_size,
    p_block_numbers => v_block_numbers,
    p_block_item_counts => v_block_item_counts,
    p_max_target_range_count => p_max_target_range_count,
    p_ranges_approx_count => p_ranges_approx_count,
    p_ranges_from => p_ranges_from,
    p_ranges_to => p_ranges_to
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure split_range_i
(
  p_item_split_from varchar2,
  p_range range_pkg.t_range,
  p_block_count integer,
  p_job_count integer,
  p_range_to_creation_id number,
  p_range_to_trunc_item_froms out ct_varchar_s,
  p_range_to_trunc_item_tos out ct_varchar_s,
  p_range_to_truncation out range_pkg.t_range,
  p_range_to_creation out range_pkg.t_range
)
is
  v_approx_counts2change ct_number;
  v_range2change_item_from varchar2(50);
  v_range2change_item_to varchar2(50);
begin
  ------------------------------
  range_pkg.XCheck_t_range(p_range => p_range, p_check_vals => FALSE);
  range_pkg.XCheck_3rangeable4split(p_range.item_from, p_item_split_from, p_range.item_to);
  util_pkg.XCheck_Cond_Missing(p_block_count is null, 'p_block_count');
  util_pkg.XCheck_Cond_Missing(p_job_count is null, 'p_job_count');
  util_pkg.XCheck_Cond_Missing(p_range_to_creation_id is null, 'p_range_to_creation_id');
  ------------------------------
  get_target_ranges_by_blocks
  (
    p_item_boundary => p_item_split_from,
    p_item_from => p_range.item_from,
    p_item_to => p_range.item_to,
    p_block_count => p_block_count,
    p_max_target_range_count => p_job_count,
    p_ranges_approx_count => v_approx_counts2change,
    p_ranges_from => p_range_to_trunc_item_froms,
    p_ranges_to => p_range_to_trunc_item_tos
  );
  ------------------------------
  range_pkg.get_total_range_items
  (
    p_item_froms => p_range_to_trunc_item_froms,
    p_item_tos => p_range_to_trunc_item_tos,
    p_total_item_from => v_range2change_item_from,
    p_total_item_to => v_range2change_item_to
  );
  ------------------------------
  --!_!v_total_count2change := util_pkg.get_sum_ct_number(v_approx_counts2change);
  ------------------------------
  range_pkg.prepare_splitted_ranges_meta
  (
    p_item_split_from => p_item_split_from,
    p_range => p_range,
    p_range2change_item_from => v_range2change_item_from,
    p_range2change_item_to => v_range2change_item_to,
    p_range_to_creation_id => p_range_to_creation_id,
    p_range_to_truncation => p_range_to_truncation,
    p_range_to_creation => p_range_to_creation
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure split_range_parallel_i
(
  p_range range_pkg.t_range,
  p_item_split_from varchar2,
  p_user_id number
)
is
  lc_flow_type_id constant number := c_fastp_ft_sim_ser_split; --!_!
  v_params_parallel fast_parallel_pkg.t_fast_parallel_params;
  v_params_out t_param_action_pre;
  v_flow fast_parallel_pkg.t_flow;
  v_exec_result number;
  v_error_id number;
  v_error_message varchar2(4000);
  v_failed_task_id number;
  v_failed_task_index number;
  v_failed_job_id number;
  v_failed_job_index number;
  v_error_id2 number;
  v_error_message2 varchar2(4000);
begin
  ------------------------------
  range_pkg.XCheck_t_range(p_range => p_range, p_check_vals => FALSE);
  util_pkg.XCheck_Cond_Missing(p_item_split_from is null, 'p_item_split_from');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_params_parallel := get_fast_parallel_params;
  ------------------------------
  v_params_out.skip_action := false;
  v_params_out.item_split_from := p_item_split_from;
  v_params_out.range := p_range;
  v_params_out.block_count := v_params_parallel.block_count;
  v_params_out.job_count := v_params_parallel.job_count;
  v_params_out.user_id := p_user_id;
  ------------------------------
  fast_parallel_pkg.xneed_to_restrict_flow(p_flow_type_id => lc_flow_type_id, p_this_is_created => FALSE);
  ------------------------------
  v_flow := make_flow
  (
    p_flow_type_id => lc_flow_type_id,
    p_user_id => p_user_id,
    p_parallel_job_count => v_params_parallel.job_count,
    p_task_pre_job_context => prm_pre_serialize(v_params_out)
  );
  ------------------------------
  fast_parallel_pkg.at_save_flow(p_flow => v_flow);
  ------------------------------
  v_exec_result := fast_parallel_pkg.at_execute_flow3(p_flow_id => v_flow.flow_id);
  ------------------------------
  if v_exec_result = fast_parallel_pkg.c_exec_result_ok
  then
    ------------------------------
    NULL;
    ------------------------------
  elsif 1 = 0
    or v_exec_result = fast_parallel_pkg.c_exec_result_pending
    or v_exec_result = fast_parallel_pkg.c_exec_result_error
  then
    ------------------------------
    fast_parallel_pkg.get_flow_exact_error
    (
      p_flow_id => v_flow.flow_id,
      p_error_id => v_error_id,
      p_error_message => v_error_message,
      p_failed_task_id => v_failed_task_id,
      p_failed_task_index => v_failed_task_index,
      p_failed_job_id => v_failed_job_id,
      p_failed_job_index => v_failed_job_index
    );
    ------------------------------
    if v_error_id = util_pkg.c_ora_object_latched
    then
      ------------------------------
      v_error_id2 := util_pkg.c_ora_object_latched;
      v_error_message2 := util_pkg.c_msg_object_latched;
      ------------------------------
    else
      ------------------------------
      v_error_id2 := util_pkg.c_ora_execution_error;
      v_error_message2 := util_pkg.c_msg_execution_error;
      ------------------------------
    end if;
    ------------------------------
    util_pkg.raise_exception(v_error_id2, v_error_message2
      || util_pkg.c_msg_delim01 || 'flow_id' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_flow.flow_id)
      || util_pkg.c_msg_delim02 || 'task_id' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_failed_task_id)
      || util_pkg.c_msg_delim02 || 'task_index' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_failed_task_index)
      || util_pkg.c_msg_delim02 || 'job_id' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_failed_job_id)
      || util_pkg.c_msg_delim02 || 'job_index' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_failed_job_index)
      || util_pkg.c_msg_delim02 || 'error_id' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_error_id)
      || util_pkg.c_msg_delim02 || 'error_message' || util_pkg.c_msg_delim02 || v_error_message
    );
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'EXEC RESULT 001' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_exec_result));
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure split_range_serial_i
(
  p_range range_pkg.t_range,
  p_item_split_from varchar2,
  p_user_id number
)
is
  lc_job_count number := 1;
  v_sp_name varchar2(30);
  v_date date;
  v_block_count number;
  v_range_to_trunc_item_froms ct_varchar_s;
  v_range_to_trunc_item_tos ct_varchar_s;
  v_range_to_truncation range_pkg.t_range;
  v_range_to_creation range_pkg.t_range;
  v_locker_id number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  range_pkg.XCheck_t_range(p_range => p_range, p_check_vals => FALSE);
  util_pkg.XCheck_Cond_Missing(p_item_split_from is null, 'p_item_split_from');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_block_count := install_pkg.nnget_option_num(c_opt_fastp_block_count, c_def_fastp_block_count);
  ------------------------------
  v_date := sysdate;
  ------------------------------
  split_range_pre_forward
  (
    p_item_split_from => p_item_split_from,
    p_range => p_range,
    p_block_count => v_block_count,
    p_job_count => lc_job_count,
    p_user_id => p_user_id,
    p_date => v_date,
    p_range_to_trunc_item_froms => v_range_to_trunc_item_froms,
    p_range_to_trunc_item_tos => v_range_to_trunc_item_tos,
    p_range_to_truncation => v_range_to_truncation,
    p_range_to_creation => v_range_to_creation,
    p_locker_id => v_locker_id
  );
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(lc_job_count <> util_pkg.get_count_ct_varchar_s(v_range_to_trunc_item_froms),' lc_job_count <> v_range_to_trunc_item_froms.count');
  ------------------------------
  split_range_mid_forward
  (
    p_item_from => v_range_to_trunc_item_froms(util_ri.c_index_one),
    p_item_to => v_range_to_trunc_item_tos(util_ri.c_index_one),
    p_range_id_new => v_range_to_creation.id
  );
  ------------------------------
  v_date := sysdate;
  ------------------------------
  split_range_post_forward
  (
    p_range_to_truncation => v_range_to_truncation,
    p_range_to_creation => v_range_to_creation,
    p_locker_id => v_locker_id,
    p_release_locker_on_error => FALSE, --!_!see below
    p_user_id => p_user_id,
    p_date => v_date
  );
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  locker_pkg.release_locker(v_locker_id); --!_!silent if not exists
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure job_action_pre
(
  p_fastp_job_id number,
  p_fastp_direction_forward boolean
)
is
  v_date date := sysdate;
  v_job fast_parallel_pkg.t_job;
  v_task fast_parallel_pkg.t_task;
  v_flow fast_parallel_pkg.t_flow;
  v_params_pre t_param_action_pre;
  v_params_paral t_param_action_parallel;
  v_params_post t_param_action_post;
  v_range_to_trunc_item_froms ct_varchar_s;
  v_range_to_trunc_item_tos ct_varchar_s;
  v_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_fastp_job_id is null, 'p_fastp_job_id');
  util_pkg.XCheck_Cond_Missing(p_fastp_direction_forward is null, 'p_fastp_direction_forward');
  ------------------------------
  v_job := fast_parallel_pkg.job_get(p_job_id => p_fastp_job_id);
  v_task := fast_parallel_pkg.task_get(p_task_id => v_job.parent_id);
  v_flow := fast_parallel_pkg.flow_get(p_flow_id => v_task.parent_id);
  ------------------------------
  if p_fastp_direction_forward
  then
    ------------------------------
    v_params_pre := prm_pre_deserialize(fast_parallel_pkg.object_context_get(p_object_id => p_fastp_job_id));
    ------------------------------
    split_range_pre_forward
    (
      p_item_split_from => v_params_pre.item_split_from,
      p_range => v_params_pre.range,
      p_block_count => v_params_pre.block_count,
      p_job_count => v_params_pre.job_count,
      p_user_id => v_params_pre.user_id,
      p_date => v_date,
      p_range_to_trunc_item_froms => v_range_to_trunc_item_froms,
      p_range_to_trunc_item_tos => v_range_to_trunc_item_tos,
      p_range_to_truncation => v_params_post.range_to_truncation,
      p_range_to_creation => v_params_post.range_to_creation,
      p_locker_id => v_params_post.locker_id
    );
    ------------------------------
    v_params_post.skip_action := false;
    v_params_post.release_locker_on_error := FALSE; --!_!
    v_params_post.user_id := v_params_pre.user_id;
    ------------------------------
    --!_!util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_range_to_trunc_item_froms) != v_params_pre.job_count, 'Wrong job count 001');
    --!_!util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_range_to_trunc_item_tos) != v_params_pre.job_count, 'Wrong job count 002');
    ------------------------------
    v_count := util_pkg.get_count_ct_varchar_s(v_range_to_trunc_item_froms);
    util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_range_to_trunc_item_tos) != v_count, 'Wrong job count 001');
    ------------------------------
    util_pkg.XCheck_Cond_Invalid(fast_parallel_pkg.get_count_cit_job(v_flow.tasks(c_task_index_paral).jobs) != v_params_pre.job_count, 'Wrong job count 003');
    ------------------------------
    for v_i in 1..v_params_pre.job_count
    loop
      ------------------------------
      v_params_paral := null;
      v_params_paral.skip_action := TRUE; --!_!
      ------------------------------
      if v_i <= v_count
      then
        ------------------------------
        v_params_paral.skip_action := FALSE; --!_!
        v_params_paral.item_from := v_range_to_trunc_item_froms(v_i);
        v_params_paral.item_to := v_range_to_trunc_item_tos(v_i);
        v_params_paral.range_id_old := v_params_post.range_to_truncation.id;
        v_params_paral.range_id_new := v_params_post.range_to_creation.id;
        ------------------------------
      end if;
      ------------------------------
      fast_parallel_pkg.object_context_set
      (
        p_object_id => v_flow.tasks(c_task_index_paral).jobs(v_i).job_id,
        p_context => prm_paral_serialize(v_params_paral),
        p_wait_lock_sec => v_job.wait_lock_sec
      );
      ------------------------------
    end loop;
    ------------------------------
    fast_parallel_pkg.object_context_set
    (
      p_object_id => v_flow.tasks(c_task_index_post).jobs(c_job_single_index_post).job_id,
      p_context => prm_post_serialize(v_params_post),
      p_wait_lock_sec => v_job.wait_lock_sec
    );
    ------------------------------
  else
    ------------------------------
    v_params_post := prm_post_deserialize(fast_parallel_pkg.object_context_get(p_object_id => v_flow.tasks(c_task_index_post).jobs(c_job_single_index_post).job_id));
    ------------------------------
    split_range_pre_backward
    (
      p_range_to_creation_id => v_params_post.range_to_creation.id,
      p_locker_id => v_params_post.locker_id,
      p_user_id => v_params_post.user_id
    );
    ------------------------------
  end if;
  ------------------------------
  --!_!commit in framework
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure job_action_parallel
(
  p_fastp_job_id number,
  p_fastp_direction_forward boolean
)
is
  v_params t_param_action_parallel;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_fastp_job_id is null, 'p_fastp_job_id');
  util_pkg.XCheck_Cond_Missing(p_fastp_direction_forward is null, 'p_fastp_direction_forward');
  ------------------------------
  v_params := prm_paral_deserialize(fast_parallel_pkg.object_context_get(p_object_id => p_fastp_job_id));
  ------------------------------
  if v_params.skip_action
  then
    ------------------------------
    RETURN;
    ------------------------------
  end if;
  ------------------------------
  if p_fastp_direction_forward
  then
    ------------------------------
    split_range_mid_forward
    (
      p_item_from => v_params.item_from,
      p_item_to => v_params.item_to,
      p_range_id_new => v_params.range_id_new
    );
    ------------------------------
  else
    ------------------------------
    split_range_mid_backward
    (
      p_item_from => v_params.item_from,
      p_item_to => v_params.item_to,
      p_range_id_old => v_params.range_id_old
    );
    ------------------------------
  end if;
  ------------------------------
  --!_!commit in framework
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure job_action_post
(
  p_fastp_job_id number,
  p_fastp_direction_forward boolean
)
is
  v_date date := sysdate;
  v_job fast_parallel_pkg.t_job;
  v_task fast_parallel_pkg.t_task;
  v_flow fast_parallel_pkg.t_flow;
  v_params_pre t_param_action_pre;
  v_params_post t_param_action_post;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_fastp_job_id is null, 'p_fastp_job_id');
  util_pkg.XCheck_Cond_Missing(p_fastp_direction_forward is null, 'p_fastp_direction_forward');
  ------------------------------
  v_job := fast_parallel_pkg.job_get(p_job_id => p_fastp_job_id);
  v_task := fast_parallel_pkg.task_get(p_task_id => v_job.parent_id);
  v_flow := fast_parallel_pkg.flow_get(p_flow_id => v_task.parent_id);
  ------------------------------
  v_params_post := prm_post_deserialize(fast_parallel_pkg.object_context_get(p_object_id => p_fastp_job_id));
  ------------------------------
  if p_fastp_direction_forward
  then
    ------------------------------
    split_range_post_forward
    (
      p_range_to_truncation => v_params_post.range_to_truncation,
      p_range_to_creation => v_params_post.range_to_creation,
      p_locker_id => v_params_post.locker_id,
      p_release_locker_on_error => v_params_post.release_locker_on_error,
      p_user_id => v_params_post.user_id,
      p_date => v_date
    );
    ------------------------------
  else
    ------------------------------
    v_params_pre := prm_pre_deserialize(fast_parallel_pkg.object_context_get(p_object_id => v_flow.tasks(c_task_index_pre).jobs(c_job_single_index_pre).job_id));
    ------------------------------
    split_range_post_backward
    (
      p_range_initial => v_params_pre.range,
      p_range_to_dummy_id => v_params_post.range_to_creation.id,
      p_range_to_truncation => v_params_post.range_to_truncation,
      p_range_to_creation => v_params_post.range_to_creation,
      p_user_id => v_params_post.user_id,
      p_date => v_date,
      p_locker_id => v_params_post.locker_id --!_!OUT
    );
    ------------------------------
    fast_parallel_pkg.object_context_set
    (
      p_object_id => p_fastp_job_id,
      p_context => prm_post_serialize(v_params_post),
      p_wait_lock_sec => v_job.wait_lock_sec
    );
    ------------------------------
    ------------------------------
  end if;
  ------------------------------
  --!_!commit in framework
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure split_range
(
  p_range range_pkg.t_range,
  p_item_split_from varchar2,
  p_user_id number
)
is
begin
  ------------------------------
  if install_pkg.nnget_option_bool(c_opt_sim_ser_split_paral_mode, c_def_sim_ser_split_paral_mode)
  then
    ------------------------------
    split_range_parallel_i
    (
      p_range => p_range,
      p_item_split_from => p_item_split_from,
      p_user_id => p_user_id
    );
    ------------------------------
  else
    ------------------------------
    split_range_serial_i
    (
      p_range => p_range,
      p_item_split_from => p_item_split_from,
      p_user_id => p_user_id
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure split_range2
(
  p_id number,
  p_item_split_from varchar2,
  p_user_id number
)
is
  v_date date := sysdate;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_item_split_from is null, 'p_item_split_from');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  split_range
  (
    p_item_split_from => p_item_split_from,
    p_range => row2t_range(vp_sim_series.xget1(p_id, v_date)),
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
