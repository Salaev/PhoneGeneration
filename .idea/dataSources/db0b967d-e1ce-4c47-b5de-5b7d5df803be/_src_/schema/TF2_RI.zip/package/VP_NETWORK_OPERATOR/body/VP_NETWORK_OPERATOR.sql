CREATE package body VP_NETWORK_OPERATOR is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return network_operator%rowtype
is
  v_res network_operator%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, PK_NETWORK_OPERATOR)*/
        * into v_res
        from network_operator z
        where 1 = 1
        and network_operator_id = p_id
        and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, PK_NETWORK_OPERATOR)*/
        * into v_res
        from network_operator z
        where 1 = 1
        and network_operator_id = p_id
        and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, PK_NETWORK_OPERATOR)*/
      * into v_res
      from network_operator z
      where 1 = 1
      and network_operator_id = p_id
      and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1(p_id integer, p_date date) return network_operator%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get1_i(p_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget1(p_id integer, p_date date) return network_operator%rowtype
is
  v_res network_operator%rowtype;
begin
  ------------------------------
  v_res := get1(p_id, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get1(p_id integer, p_date date) return network_operator%rowtype
is
  v_res network_operator%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_i(p_id, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_xget1(p_id integer, p_date date) return network_operator%rowtype
is
  v_res network_operator%rowtype;
begin
  ------------------------------
  v_res := xlock_get1(p_id, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xlock(p_id integer, p_date date)
is
begin
  ------------------------------
  util_loc_pkg.touch_number(xlock_xget1(p_id, p_date).network_operator_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function find_i_id(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_cnt number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.network_operator_id is null, 'p_rec.network_operator_id');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  if p_check_only_other_ids
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
select /*+ index_asc(z, PK_NETWORK_OPERATOR)*/
  count(1) cnt into v_cnt
  from network_operator z
  where 1 = 1
  and network_operator_id = p_rec.network_operator_id
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  --!_!and (v_check_only_other_ids = util_pkg.c_false or network_operator_id != p_rec.network_operator_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_code(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
  v_date date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.network_operator_id is null, 'p_rec.network_operator_id');
  util_pkg.XCheck_Cond_Missing(p_rec.network_operator_code is null, 'p_rec.network_operator_code');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  v_date := util_ri.deleted2valid_date_to(p_rec.deleted);
  ------------------------------
select /*+ index_asc(z, UK_NETWORK_OPERATOR_CODE)*/
  count(1) cnt into v_cnt
  from network_operator z
  where 1 = 1
  and network_operator_code = p_rec.network_operator_code
  and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  and (v_check_only_other_ids = util_pkg.c_false or network_operator_id != p_rec.network_operator_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_name(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
  v_date date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.network_operator_id is null, 'p_rec.network_operator_id');
  util_pkg.XCheck_Cond_Missing(p_rec.network_operator_name is null, 'p_rec.network_operator_name');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  v_date := util_ri.deleted2valid_date_to(p_rec.deleted);
  ------------------------------
select /*+ index_asc(z, UK_NETWORK_OPERATOR_NAME)*/
  count(1) cnt into v_cnt
  from network_operator z
  where 1 = 1
  and network_operator_name = p_rec.network_operator_name
  and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  and (v_check_only_other_ids = util_pkg.c_false or network_operator_id != p_rec.network_operator_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_mcc_mnc(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.network_operator_id is null, 'p_rec.network_operator_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_rec.mcc is null, 'p_rec.mcc');
  --!_!util_pkg.XCheck_Cond_Missing(p_rec.mnc is null, 'p_rec.mnc');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  if 1 = 1
    and p_rec.mcc is null
    and p_rec.mnc is null
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
  if p_rec.mcc is NOT null
  then
    ------------------------------
    return find_i_mcc_mnc1(p_rec, p_check_only_other_ids);
    ------------------------------
  end if;
  ------------------------------
  --!_!p_rec.mnc is NOT null
  ------------------------------
  return find_i_mcc_mnc2(p_rec, p_check_only_other_ids);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_mcc_mnc1(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
  v_date date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.network_operator_id is null, 'p_rec.network_operator_id');
  util_pkg.XCheck_Cond_Missing(p_rec.mcc is null, 'p_rec.mcc');
  --!_!util_pkg.XCheck_Cond_Missing(p_rec.mnc is null, 'p_rec.mnc');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  v_date := util_ri.deleted2valid_date_to(p_rec.deleted);
  ------------------------------
select /*+ index_asc(z, UK_NETWORK_OPERATOR_MCC_MNC)*/
  count(1) cnt into v_cnt
  from network_operator z
  where 1 = 1
  and mcc = p_rec.mcc
  and (mnc = p_rec.mnc or (mnc is null and p_rec.mnc is null))
  and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  and (v_check_only_other_ids = util_pkg.c_false or network_operator_id != p_rec.network_operator_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_mcc_mnc2(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
  v_date date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.network_operator_id is null, 'p_rec.network_operator_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_rec.mcc is null, 'p_rec.mcc');
  util_pkg.XCheck_Cond_Missing(p_rec.mnc is null, 'p_rec.mnc');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  v_date := util_ri.deleted2valid_date_to(p_rec.deleted);
  ------------------------------
select /*+ index_asc(z, UK_NETWORK_OPERATOR_MNC_MCC)*/
  count(1) cnt into v_cnt
  from network_operator z
  where 1 = 1
  and mnc = p_rec.mnc
  and (mcc = p_rec.mcc or (mcc is null and p_rec.mcc is null))
  and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  and (v_check_only_other_ids = util_pkg.c_false or network_operator_id != p_rec.network_operator_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i(p_rec network_operator%rowtype, p_check_only_other_ids boolean) return boolean
is
begin
  ------------------------------
  if find_i_id(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_code(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_name(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_mcc_mnc(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xunique_i(p_rec network_operator%rowtype, p_check_only_other_ids boolean)
is
begin
  ------------------------------
  if find_i_id(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    --!_!util_pkg.Raise_Obj_NotUniq_OnDate2(p_rec.network_operator_id, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    util_pkg.Raise_Obj_NotUniq_ID2(p_rec.network_operator_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_code(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_OnDate(p_rec.network_operator_code, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_name(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_OnDate(p_rec.network_operator_name, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_mcc_mnc(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_OnDate(p_rec.mcc, p_rec.mnc, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_i(p_rec network_operator%rowtype)
is
begin
  ------------------------------
  xunique_i(p_rec, FALSE);
  ------------------------------
  insert into network_operator
  values p_rec;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure change_i(p_rec network_operator%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xunique_i(p_rec, TRUE);
  ------------------------------
update /*+ index_asc(z, PK_NETWORK_OPERATOR)*/
  network_operator z
  set
    row = p_rec
  where 1 = 1
  and network_operator_id = p_rec.network_operator_id
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_ID2(p_rec.network_operator_id, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_ID2(p_rec.network_operator_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_identified(p_rec network_operator%rowtype) return boolean
is
begin
  ------------------------------
  return (p_rec.network_operator_id is not null);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open(p_rec in out nocopy network_operator%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  p_rec.network_operator_id := nvl(p_rec.network_operator_id, s_network_operator.nextval);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change(p_rec in out nocopy network_operator%rowtype, p_date_from_virt date := null)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.network_operator_id is null, 'p_rec.network_operator_id');
  ------------------------------
  v_date_from_new := nvl(p_date_from_virt, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  xlock(p_rec.network_operator_id, v_date_to_prev);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  change_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close
(
  p_id integer,
  p_user_id integer,
  p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_rec network_operator%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_date_from_new := nvl(p_date_from, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  v_rec := xlock_xget1(p_id, v_date_to_prev);
  ------------------------------
  v_rec.user_id_of_change := p_user_id;
  ------------------------------
  v_rec.date_of_change := v_sysdate;
  v_rec.deleted := util_ri.valid_date_to2deleted(v_date_to_prev);
  ------------------------------
  --!_! need to check for childs (zone, host, etc), now skipped
  ------------------------------
  change_i(v_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open2
(
  p_rec in out nocopy network_operator%rowtype,
  p_routing_number_id integer,
  p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_rec_ch routing_number_no%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  version_open(p_rec);
  ------------------------------
  if p_routing_number_id is not null
  then
    ------------------------------
    v_rec_ch := NULL;
    ------------------------------
    v_rec_ch.routing_number_id := p_routing_number_id;
    v_rec_ch.network_operator_id := p_rec.network_operator_id;
    v_rec_ch.date_from := p_date_from;
    v_rec_ch.date_to := util_ri.deleted2valid_date_to(p_rec.deleted);
    v_rec_ch.user_id_of_change := p_rec.user_id_of_change;
    ------------------------------
    vp_routing_number_no.version_open(v_rec_ch);
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change2
(
  p_rec in out nocopy network_operator%rowtype,
  p_routing_number_id integer,
  p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_rec_ch routing_number_no%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  v_date_from_new := nvl(p_date_from, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  version_change(p_rec, v_date_from_new);
  ------------------------------
  v_rec_ch := vp_routing_number_no.get1(p_rec.network_operator_id, v_date_to_prev);
  ------------------------------
  if v_rec_ch.network_operator_id is not null
  then
    ------------------------------
    vp_routing_number_no.version_close
    (
      p_network_operator_id => v_rec_ch.network_operator_id,
      p_user_id => p_rec.user_id_of_change,
      p_date_from => v_date_from_new
    );
    ------------------------------
  end if;
  ------------------------------
  if p_routing_number_id is not null
  then
    ------------------------------
    v_rec_ch := NULL;
    ------------------------------
    v_rec_ch.routing_number_id := p_routing_number_id;
    v_rec_ch.network_operator_id := p_rec.network_operator_id;
    v_rec_ch.date_from := p_date_from;
    v_rec_ch.date_to := util_ri.deleted2valid_date_to(p_rec.deleted);
    v_rec_ch.user_id_of_change := p_rec.user_id_of_change;
    ------------------------------
    vp_routing_number_no.version_open(v_rec_ch);
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close2
(
  p_id integer,
  p_user_id integer,
  p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_rec_ch routing_number_no%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_date_from_new := nvl(p_date_from, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  v_rec_ch := vp_routing_number_no.get1(p_id, v_date_to_prev);
  ------------------------------
  if v_rec_ch.network_operator_id is not null
  then
    ------------------------------
    vp_routing_number_no.version_close
    (
      p_network_operator_id => v_rec_ch.network_operator_id,
      p_user_id => p_user_id,
      p_date_from => v_date_from_new
    );
    ------------------------------
  end if;
  ------------------------------
  version_close
  (
    p_id => p_id,
    p_user_id => p_user_id,
    p_date_from => v_date_from_new
  );
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xcheck_network_operator_type(p_network_operator_type_code varchar2)
is
begin
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(p_network_operator_type_code is null, 'p_network_operator_type_code');
  ------------------------------
  if 1 = 0
    or p_network_operator_type_code is null
    or p_network_operator_type_code = c_net_op_type_code_external
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'network_operator_type_code' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_network_operator_type_code));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_external(p_network_operator_type_code varchar2) return boolean
is
begin
  ------------------------------
  xcheck_network_operator_type(p_network_operator_type_code);
  ------------------------------
  return (nvl(p_network_operator_type_code, c_net_op_type_code_internal) = c_net_op_type_code_external);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_external2(p_rec network_operator%rowtype) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(not is_identified(p_rec), 'p_rec.network_operator_id');
  ------------------------------
  return is_external(p_network_operator_type_code => p_rec.network_operator_type);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_external3(p_network_operator_id number, p_date date) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_network_operator_id is null, 'p_network_operator_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  return is_external2(p_rec => xget1(p_id => p_network_operator_id, p_date => p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
