CREATE PACKAGE RSIG_SIM_SERIES IS
/****************************************************************************
<header>
  <name>               package RSIG_SIM_SERIES
  </name>

  <author>             Radek Hejduk - GITUS
  </author>

  <version>           1.3.2     30.03.2011   Pavel Vasiliev
                      procedure Update_Sim_Series: change hints
  </version>

  <version>           1.3.1     28.09.2010   Sergey Ermakov
                      procedure Get_Sim_Cards: change hints:
                      SELECT + ORDERED use_nl(k apsh psh)  -> SELECT + ORDERED use_nl(k apsh aps psh sssv ps)
                      and
                      v_select:=v_select || 'SELECT + ORDERED use_nl(k apsh psh) ' || -> v_select:=v_select || 'SELECT + ORDERED use_nl(k apsh aps psh sssv ps) ' ||
  </version>
  <version>           1.3.0     04.06.2010   Katerina Cerna
                      procedure Delete_Sim_Serie: new hints INDEX(NAAP I_NETADDRACCPO_ACCESS_POINT_ID)
                      INDEX (SC I_SIMCARD_SIM_SERIES_ID)  are added
  </version>
  <version>           1.2.9     01.07.2009   Sergey Ermakov
                      error into procedure GET_SIM_CARDS is corrected
  </version>
  <version>           1.2.8     25.06.2009   Sergey Ermakov
                      procedure Get_Sim_Cards updated (Field 'authent_type' from sim_card table is added into output cursor)
  </version>
  <version>           1.2.7     22.10.2008   Josef Hartman
                      procedure Get_Sim_Cards updated
  </version>
  <version>           1.2.6     16.02.2007   Petr Cepek
                      procedure Get_Sim_Cards updated
  </version>
  <version>           1.2.5     09.11.2006   Petr Cepek
                      procedure Get_Sim_Cards updated
                      procedure Get_Sim_Cards_Detail deleted
                      procedure Get_Sim_Series deleted
                      procedure Get_Sim_Series_Operator deleted
  </version>
  <version>           1.2.4     13.10.2006   Petr Cepek
                      procedure Insert_Sim_Series updated
                      procedure Get_Sim_Cards_Serie_Detail updated
                      procedure Get_Status_History updated
                      procedure Get_Sim_Cards updated
  </version>
  <version>
                      1.2.3     10.04.2006   Petr Cepek
                      procedure Get_Filtered_SIM_Series updated
  </version>
  <version>           1.2.2     30.03.2006   Petr Cepek
                      procedures Set_Host_Relation and Get_Relation_to_Host created
  </version>
  <version>           1.2.1     22.03.2006   Petr Cepek
                      procedure Get_Sim_Cards updated
  </version>
  <version>           1.2.0     16.02.2006   Petr Cepek
                      procedure Get_Sim_Cards created, procedures Get_Sim_Cards_Detail_First,
                      Get_Sim_Cards_Next, Get_Sim_Cards_Previous, Get_Sim_Cards_Detail2_Next deleted
  </version>
  <version>           1.1.3     01.12.2005   Petr Cepek
                      procedure Get_Filtered_SIM_Series updated
  </version>
  <version>           1.1.2    09.11.2005    Petr Cepek
                      procedures Delete_Sim_Serie, Get_Sim_Cards_Serie_Detail updated
  </version>
  <version>           1.1.1    29.9.2005     Petr Cepek
                      procedure Get_Filtered_SIM_Series updated
  </version>
  <version>           1.1.0    04.08.2005    Petr Cepek
                      procedure Get_Filtered_SIM_Series updated
  </version>
  <version>
                      1.0.15   17.06.2005    Radomir Lipka
                      Add procedure Get_Filtered_SIM_Series
  </version>
  <version>
                      1.0.14   1.06.2005    Petr Cepek
                      procedure Get_Sim_Cards_Detail2_Next optimalized
  </version>
  <version>            1.0.13   20.4.2004     Jaroslav Holub
                      Update_Sim_Series - check if exist active connection between phone and sim,
                      if yes - raise error c_ORA_PHONE_IN_SIM_SERIE_USE
  </version>
  <version>           1.0.12   12.4.2005  Jaroslav Holub
                      Get_sim_series_for_cache - time zone added to output cursor
  </version>
  <version>            1.0.11  24.3.2005      Jaroslav Holub
                      added new procedure Get_sim_series_for_cache
  </version>
  <version>            1.0.10  15.09.2004      Jaroslav Holub
                Join_Sim_Series - fixed for time difference
                between client and server, date should be null and
                it means sysdate
                fix version numbering
  </version>
  <version>             1.0.9   10.9.2004     Jaroslav Holub
                         Is_Interval_Overlap,Delete_Sim_Serie,
                Update_Sim_Series_Status - fixed for time difference
                between client and server, date should be null and
                it means sysdate
  </version>
  <version>             1.0.8   07.09.2004     Jaroslav Holub
                                Get_Sim_Cards_Detail2_Next - added p_bind_phone_filter -
                for filter by number of phones connected to sim
  </version>
  <version>             1.0.7   23.8.2004     Martin Zabka
                                Get_Sim_Cards_Detail2_Next - fix  missing brackets in innner select last end
  </version>
  <version>             1.0.6   16.8.2004     Jaroslav Holub
                                Get_Sim_Cards_Detail2_Next - fix error when p_in_status_filter is NULL
  </version>
  <version>             1.0.5   9.8.2004     Jaroslav Holub
                                Get_Sim_Cards_Detail2_Next - created first version
  </version>
  <version>            1.0.4   10.05.2004     Jaroslav Holub
                Split_Sim_Series - corrected - badly set end of sim serie
                Join_Sim_Series update simcards - set ownership from sim serie being deleted to sim serie which stay active in DB
  </version>
  <version>            1.0.3   23.4.2004     Jaroslav Holub
                              procedure Is_Split_IMSI_Number_OK - change for cut-off last number (end-number)from serie.
  </version>
  <version>            1.0.2   10.9.2003     Radek Hejduk
                              procedure Is_IMSI_Interval_Overlap - check DELETED
  </version>
  <version>            1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>        package for table SIM_SERIES
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>        Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/
  TYPE t_code IS TABLE OF varchar2(32) INDEX BY BINARY_INTEGER;

  ----------------------------------!---------------------------------------------
  c_opt_disp_addit_imsi_amount  constant varchar2(100) := 'DISPLAYED_ADDITION_IMSI_AMOUNT';

  ----------------------------------!---------------------------------------------
  c_locker_type_sim_ser_range constant number := util_ri.c_locker_type_sim_ser_range;

/****************************************************************************
<header>
  <name>               procedure Insert_Sim_Series
  </name>

  <author>             Radek Hejduk - GITUS
  </author>

  <version>           1.0.2   29.09.2006    Petr Cepek
                      parameter p_prod_status added
  </version>
  <version>            1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>        Procedure first checks, whether sim_card_type or
                      network_operator is deleted; if one of them is deleted,
                      it ends and returns error c_DELETED.
                      Further procedure checks, whether series given
                      by start_imsi_number and end_imsi_number is overlapped
                      with any other existing series. If it overlaps, procedure
                      ends with error c_IMSI_ERROR.
                      If all checks passed successfully, then procedure inserts
                      a new sim series.

  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      PROCEDURE RSIG_SIM_SE_STAT_VALIDITY.Insert_Interval (handle_tran,
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>        Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_sim_series_id - OUT - value for column SIM_SERIES_ID
                                              this value is generated from sequence S_SIM_SERIES
                      p_start_imsi_number - IN - value from column START_IMSI_NUMBER
                      p_end_imsi_number - IN - value from column END_IMSI_NUMBER
                      p_user_id_of_change - IN - value change in for column USER_ID_OF_CHANGE
                                                 id of user which executes insert
                      p_sim_card_type_code - IN - value from column SIM_CARD_TYPE_CODE
                      p_host_id - IN - value from column HOST_ID
                      p_network_operator_id - IN - value from column NETWORK_OPERATOR_ID
  </Parameters>

</header>
****************************************************************************/
PROCEDURE Insert_Sim_Series(
  p_start_imsi_number     IN  SIM_SERIES.START_IMSI_NUMBER%TYPE,
  p_end_imsi_number       IN  SIM_SERIES.END_IMSI_NUMBER%TYPE,
  p_sim_card_type_code    IN  SIM_SERIES.SIM_CARD_TYPE_CODE%TYPE,
  p_host_id               IN  SIM_SERIES.HOST_ID%TYPE,
  p_subhost_id            IN  SIM_SERIES.SUBHOST_ID%TYPE,
  p_network_operator_id   IN  SIM_SERIES.NETWORK_OPERATOR_ID%TYPE,
  p_prod_status           IN  sim_series_status_validity.status_code%TYPE,
  p_user_id               IN  NUMBER,
  p_handle_tran            IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_sim_series_id         OUT SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_error_code            OUT NUMBER,
  p_error_message          OUT VARCHAR2
);
/****************************************************************************
<header>
  <name>               procedure Update_Sim_Series
  </name>

  <author>             Radek Hejduk - GITUS
  </author>

  <version>            1.0.2   20.4.2004     Jaroslav Holub
                      check if exist active connection between phone and sim,
                      if yes - raise error c_ORA_PHONE_IN_SIM_SERIE_USE
  </version>
  <version>            1.0.1   10.9.2003     Radek Hejduk
                      created first version
  </version>

  <Description>        Procedure first checks, whether the column "DELETED"
                      of the interval being updated is null. If it is not null,
                      procedure ends with error_code c_DELETED.
                      Further procedure checks, whether series given by start_imsi_number
                      and end_imsi_number is overlapped with any other existing series.
                      If it overlaps, procedure ends with error c_IMSI_ERROR.
                      If all checks passed successfully, then procedure executes
                      changes for given id of sim series.

  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>        Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_sim_series_id - IN - value for identification of the updating row (SIM_SERIES_ID)
                      p_start_imsi_number - IN - value for change in column START_IMSI_NUMBER
                      p_end_imsi_number - IN - value for change in column END_IMSI_NUMBER%TYPE
                      p_user_id_of_change - IN - value for change in column USER_ID_OF_CHANGE
                                                 id of user which executes update
                      p_sim_card_type_code - IN - value for change in column SIM_CARD_TYPE_CODE
                      p_host_id - IN - value for change in column HOST_ID
                      p_network_operator_id - IN - value for change in column NETWORK_OPERATOR_ID
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Update_Sim_Series (
    handle_tran               IN     CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_sim_series_id           IN     SIM_SERIES.SIM_SERIES_ID%TYPE,
    p_start_imsi_number       IN     SIM_SERIES.START_IMSI_NUMBER%TYPE,
    p_end_imsi_number         IN     SIM_SERIES.END_IMSI_NUMBER%TYPE,
    p_user_id_of_change       IN     SIM_SERIES.USER_ID_OF_CHANGE%TYPE,
    p_sim_card_type_code      IN     SIM_SERIES.SIM_CARD_TYPE_CODE%TYPE,
    p_host_id                 IN     SIM_SERIES.HOST_ID%TYPE,
    p_subhost_id              IN     SIM_SERIES.SUBHOST_ID%TYPE,
    p_network_operator_id     IN     SIM_SERIES.NETWORK_OPERATOR_ID%TYPE
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure split_sim_series
  (
    handle_tran char default rsig_utils.c_handle_tran_y, --!_! ignore always Y
    p_error_code out number,
    p_error_message out varchar2,
    p_sim_series_id_current number,
    p_sim_series_id out number,
    p_split_imsi_number varchar2,
    p_user_id_of_change number
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
/****************************************************************************
<header>
  <name>               procedure Split_Sim_Series_for_synch
  </name>

  <author>             Radek Hejduk - GITUS
  </author>

  <version>            1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>        Procedure first checks, whether given series contains sim series
                      given by parameter p_split_imsi_number. If it not contains,
                      procedure ends with error_code c_INVALID_INTERVAL.
                      Further procedure checks, whether the column "DELETED"
                      of the interval being splitted is null or not. If it is not null
                      procedure ends with error_code c_DELETED.
                      If all checks passed successfully, procedure
                         - sets end imsi number of the current series to p_split_imsi_number minus one,
                         - inserts new series (which start_imsi_number equals to p_split_imsi_number and   end_imsi_number equals to original end_imsi_number of split series),
                         - copies history of the series operator and history of statuses from current series to new series and changes series identification for appropriate phone series.

  </Description>

  <Prerequisites>      PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
                      RSIG_UTILS.c_DEBUG_LEVEL_2
                      RSIG_UTILS.c_DEBUG_LEVEL_3
  </Prerequisites>

  <Application>        Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_sim_series_id_current - IN - id of current series (SIM_SERIES_ID)
                      p_sim_series_id - OUT - id of e new series
                                              this value is returned by procedure Insert_Sim_Series
                      p_split_imsi_number - IN - value for split series (value between start_imsi_number and end_imsi_number of current series)
                                               - this value is used as end_imsi_number for current series
                      p_user_id_of_change - IN - value for new series and for change in current series (USER_ID_OF_CHANGE)
                                                 id of user which executes changes
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Split_Sim_Series_for_synch(
    handle_tran               IN     CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_sim_series_id_current   IN     SIM_SERIES.SIM_SERIES_ID%TYPE,
    p_sim_series_id           OUT    SIM_SERIES.SIM_SERIES_ID%TYPE,
    p_split_imsi_number       IN     SIM_SERIES.START_IMSI_NUMBER%TYPE,
    p_user_id_of_change       IN     SIM_SERIES.USER_ID_OF_CHANGE%TYPE,
  p_optimize          IN  CHAR  DEFAULT RSIG_UTILS.c_OPTIMIZE_YES
  );



/****************************************************************************
<header>
  <name>               procedure Join_Sim_Series
  </name>

  <author>             Radek Hejduk - GITUS
  </author>

  <version>            1.0.4  15.09.2004      Jaroslav Holub
                fixed for time difference
                between client and server, date should be null and
                it means sysdate
  </version>
  <version>            1.0.3  10.05.2004      Jaroslav Holub
                update simcards - set ownership from sim serie being deleted to sim serie which stay active in DB
  </version>
  <version>            1.0.2  18.2.2004      Pavel Stengl
                check the same histiory  corrected
  </version>
  <version>            1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>        Procedure first checks,  whether column "DELETED" of both
                      given intervals to join is null. If it is not null,
                      procedure ends with error_code c_DELETED.
                      Further procedure checks,  whether both given intervals to
                      join have the same history. If they do not have the same history,
                      ends with error_code c_DIFFERENCE_HISTORY.
                      Further procedure checks, whether given start imsi number
                      of series 2 equals to end imsi number of series 1 + 1.
                      If it equals, then procedure ends with error_code
                      c_IMSI_ERROR.
                      Further procedure checks,  whether both given intervals
                      to join have the same network operator id, sim card type
                      code and host id, unless it ends with error_code c_DIFFERENCE_VALUES.
                      If all checks passed successfully, then procedure
                         - sets end_imsi_number of series 1 to end_imsi_number of series 2,
                         - changes sim series identification for all sim cards from series 2 to series 1 identification,
                         - deletes status history for series 2
                         - deletes series 2
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_TEXT_BEFORE_LOOP
                      RSIG_UTILS.c_DEBUG_TEXT_IN_LOOP
                      RSIG_UTILS.c_DEBUG_TEXT_AFTER_LOOP
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
                      RSIG_UTILS.c_DEBUG_LEVEL_2
                      RSIG_UTILS.c_DEBUG_LEVEL_3
  </Prerequisites>

  <Application>        Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_sim_series_id_1 - IN - id of first series (SIM_SERIES_ID)
                                               id of joined series
                      p_sim_series_id_2 - IN - id of second series (SIM_SERIES_ID)
                                               id of "deleted" series
                      p_user_id_of_change - IN - user id of change for both series (USER_ID_OF_CHANGE)
                      p_deleted - IN - value for change in second series (DELETED)
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Join_Sim_Series(
    handle_tran               IN     CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_sim_series_id_1         IN     SIM_SERIES.SIM_SERIES_ID%TYPE,
    p_sim_series_id_2         IN     SIM_SERIES.SIM_SERIES_ID%TYPE,
    p_user_id_of_change       IN     SIM_SERIES.USER_ID_OF_CHANGE%TYPE,
    p_deleted                 IN     SIM_SERIES.DELETED%TYPE
  );


/****************************************************************************
<header>
  <name>               procedure Get_Status_History
  </name>

  <author>             Radek Hejduk - GITUS
  </author>

  <version>           1.0.2   04,10,2006    Petr Cepek
                      view sim_series_status changed for view ap_prod_status
  </version>
  <version>            1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>        Procedure provides one series status history as IN OUT
                      ref cursor containing status code, status name, start date,
                      end date, date of change and user id of change.

  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_TEXT_BEFORE_SELECT
                      RSIG_UTILS.c_DEBUG_TEXT_AFTER_SELECT
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
                      RSIG_UTILS.c_DEBUG_LEVEL_2
  </Prerequisites>

  <Application>        Resource inventory
  </Application>

  <Parameters>        error_code - OUT - NUMBER
                      p_sim_series_id - IN - id of series we want to get status history (SIM_SERIES_ID)
                      p_cur_status_history - IN OUT - ref cursor containing
                       STATUS_CODE
                       STATUS_NAME
                       START_DATE
                       END_DATE
                       DATE_OF_CHANGE
                       USER_ID_OF_CHANGE
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Get_Status_History(
    error_code                OUT    NUMBER,
    p_sim_series_id           IN     SIM_SERIES.SIM_SERIES_ID%TYPE,
    p_cur_status_history      IN OUT RSIG_UTILS.REF_CURSOR
  );


 /****************************************************************************
  <header>
    <name>              procedure Get_Sim_Cards_Serie_Detail
    </name>

    <author>            Pavel Stengl
    </author>

    <version>           1.0.3   04,10,2006    Petr Cepek
                        view sim_series_status changed for view ap_prod_status
    </version>
    <version>           1.0.2   10.11.2005    Petr Cepek
                        number of sim cards in sim serie fixed
    </version>
    <version>           1.0.1   21.1.2004     Pavel Stengl
                                created first version
    </version>

    <Description>       procedure returns ref cursor variable
                        containing details of sim cards series.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code - OUT - NUMBER
                        p_sim_series_id  - id of sim cards series
                        p_cur_series - cursor containing infromation
                              of table sim_series for given
                              sim cards series.
    </Parameters>

  </header>
****************************************************************************/


PROCEDURE Get_Sim_Cards_Serie_Detail (
    error_code                 OUT     NUMBER,
    p_sim_series_id            IN      SIM_SERIES.SIM_SERIES_ID%TYPE,
    p_cur_sim_cards            IN OUT  RSIG_UTILS.REF_CURSOR                      -- cursor containing all series of given operator and phone number count for each serie
  );


 /****************************************************************************
<header>
  <name>               procedure Delete_Sim_Serie
  </name>

  <author>             Pavel Stengl
  </author>

  <version>
                      1.0.3       9.11.2005     Petr Cepek
                      check for number of connections to phone numbers adjusted
  </version>
  <version>           1.0.2   10.9.2004     Jaroslav Holub
                       fixed for time difference
                      between client and server, date should be null
                      and it means sysdate
  </version>
  <version>            1.0.1   23.1.2004     Pavel Stengl
                                created first version
  </version>

  <Description>        Procedure sets column DELETED to value of parameter deleted in sim serie given by sim serie id,
                      if given sim series is currently not deleted.
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>        Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_sim_series_id - IN - value for identification of the updating row (SIM_SERIES_ID)
                      p_deleted - IN - value for set attribute (DELETED)
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/

PROCEDURE Delete_Sim_Serie (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_sim_series_id           IN     SIM_SERIES.SIM_SERIES_ID%TYPE,
    p_deleted                 IN     SIM_SERIES.DELETED%TYPE,
    p_user_id_of_change       IN     SIM_SERIES.USER_ID_OF_CHANGE%TYPE
  );

/****************************************************************************
<header>
  <name>               procedure Update_Sim_Series_Status
  </name>

  <author>             Pavel Steng - STROM
  </author>

  <version>             1.0.2   10.9.2004     Jaroslav Holub
                         fixed for time difference
                between client and server, date should be null
                and it means sysdate
  </version>
  <version>            1.0.1   4.2.2004     Pavel Stengl
                                created first version
  </version>

  <Description>        Procedure set end_date for row where end date is null
            for given sim series and status code for given sim series is changed.
            Then insert new row with given status code.

  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>        Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_sim_series_id - IN - value for identification of the updating row (SIM_SERIES_ID)
                      p_status_code - IN - value for change in column (STATUS_CODE)
                      p_start_date - IN - value for change in column (START_DATE)
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/

PROCEDURE Update_Sim_Series_Status (
    handle_tran               IN     CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_sim_series_id           IN     SIM_SERIES.SIM_SERIES_ID%TYPE,
    p_status_code             IN     SIM_SERIES_STATUS_VALIDITY.STATUS_CODE%TYPE,
    p_start_date              IN     SIM_SERIES_STATUS_VALIDITY.START_DATE%TYPE,
    p_user_id_of_change       IN     SIM_SERIES.USER_ID_OF_CHANGE%TYPE
  );



/****************************************************************************
  <header>
    <name>              procedure Get_Sim_Cards
    </name>

    <author>            Petr Cepek
    </author>

    <version>           1.1.4     22.02.2007   Josef Hartman
                        removed hint on subselect
    </version>
    <version>           1.1.3     16.02.2007   Petr Cepek
                        procedure fixed to work with data access with ODP.NET 10
    </version>
    <version>           1.1.2     09.11.2006   Petr Cepek
                        columns from access_point tables moved to table sim_card
    </version>
    <version>           1.1.1    16.10.2006    Petr Cepek
                        condition for AP_TRANS_REASON_CODE added
    </version>
    <version>           1.1.0    22.03.2006    Petr Cepek
                        ordering of sim card fixed
    </version>
    <version>           1.0.0   16.02.2006     Petr Cepek
                                created first version
    </version>

    <Description>       Procedure returns in cursor sim cards in
                        given sim series. When other parameters are entered
                        then appropriate filter is applied.
    </Description>

    <Prerequisites>

    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>

    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Get_Sim_Cards(
  error_code            OUT NUMBER,
  p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_sim_series_id       IN SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_imsi                IN SIM_CARD.IMSI%TYPE,
  p_in_row_count        IN NUMBER, -- <=     not null
  p_status_filter_l     IN t_code,
  p_trans_reason_l      IN t_code,
  p_prod_status_filtr   IN VARCHAR2,
  p_like                IN VARCHAR2, -- LIKE
  p_IMSI_search         IN CHAR, -- 'Y' => search by IMSI
  p_ICCID_search        IN CHAR, -- 'Y' => search by ICCID
  p_bind_phone_filter   IN NUMBER,
  p_cur_sim_series      OUT RSIG_UTILS.REF_CURSOR,
  p_cur_addit_imsi      OUT RSIG_UTILS.REF_CURSOR
);

/****************************************************************************
  <header>
    <name>              procedure Get_sim_series_for_cache
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.1   12.4.2005  Jaroslav Holub
                                Get_sim_series_for_cache - time zone added to output cursor
    </version>
    <version>           1.0.0   24.3.2005  Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure Procedure returns all not deleted SIM series.
                        The output result set has to include:
                          - id of sim serie
                          -  SIM series start IMSI number
                          -  SIM series end IMSI number
                          -  network operator id, code, name
                          -  top parent operator id
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
                        p_sim_card_type_code  - return result list by code or all if NULL
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Get_sim_series_for_cache
(
  p_sim_card_type_code IN SIM_SERIES.SIM_CARD_TYPE_CODE%TYPE,
  p_raise_error        IN CHAR,
  ERROR_CODE           OUT NUMBER,
  error_message        OUT VARCHAR2,
  result_list          OUT sys_refcursor
);

/****************************************************************************
  <header>
    <name>              procedure Get_Filtered_SIM_Series
    </name>

    <author>            Radomir Lipka
    </author>

    <version>           1.1.3   10.04.2006  Petr Cepek
                        problem with conversion of parameter p_host_id fixed
    </version>
    <version>           1.1.2   1.12.2005   Petr Cepek
                        ordering updated
    </version>
    <version>           1.1.1   29.09.2005  Petr Cepek
                        condition p_show_deleted='N' changed to p_show_deleted='Y'
    </version>
    <version>           1.1.0   04.08.2005  Petr Cepek
                        procedure rewritten to non-dynamic SQL
    </version>
    <version>           1.0.0   17.6.2005  Radomir Lipka
                                created first version
    </version>

    <Description>       procedure Procedure returns SIM cards series belonging to given network operators,
                        which are suitable for given input parameters values.
                        The output result set has to include:
                          - sim_series_id
                          - start_imsi_number
                          - end_imsi_number
                          - date_of_change
                          - user_id_of_change
                          - sim_card_type_code
                          - host_id
                          - SIM_SERIES_STATUS_VALIDITY status_code
                          -                            start_date
                          -                            date_of_change STATUS_DATE_OF_CHANGE
                          -                            user_id_of_change STATUS_USER_ID_OF_CHANGE
                          - deleted
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>         FORIS Resource inventory
    </Application>

    <Parameters>
                          p_raise_error          CHAR           --Y - procedure ends with error in matter of failure (error code and error message will not be set)
                                                                --N - procedure ends successfully in matter of failure (error code and error message is set)
                          p_network_operator_id  SIM_SERIES.NETWORK_OPERATOR_ID%TYPE,
                          p_show_deleted         CHAR           --Y - deleted SIM series will be returned,N - deleted SIM series will not be returned
                          p_host_id              VARCHAR2       --Identification of the host Number - concrete host id Null - SIM series having HOST_ID null % - HOST_ID not considered
                          p_sim_card_type        SIM_CARD_TYPE.SIM_CARD_TYPE_CODE%TYPE
                          error_code             NUMBER,
                          p_error_message        VARCHAR2,
                          p_cur_sim_series       RSIG_UTILS.REF_CURSOR
    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Get_Filtered_SIM_Series(
    p_raise_error             IN     CHAR,                                      --Y - procedure ends with error in matter of failure (error code and error message will not be set)
                                                                                --N - procedure ends successfully in matter of failure (error code and error message is set)
    p_network_operator_id     IN     SIM_SERIES.NETWORK_OPERATOR_ID%TYPE,
    p_show_deleted            IN     CHAR,                                      --Y - deleted SIM series will be returned,N - deleted SIM series will not be returned
    p_host_id                 IN     VARCHAR2,                                  --Identification of the host Number - concrete host id Null - SIM series having HOST_ID null % - HOST_ID not considered
    p_sim_card_type           IN     SIM_CARD_TYPE.SIM_CARD_TYPE_CODE%TYPE,
    error_code                OUT    NUMBER,
    p_error_message           OUT    VARCHAR2,
    p_cur_sim_series          OUT    RSIG_UTILS.REF_CURSOR
  );


/****************************************************************************
<header>
  <name>            procedure Set_Host_Relation
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  30.3.2006   -  created
  </version>

  <Description>     Procedure insert new relation between sim serie and some host.
                    Old relation for same host type is terminated. When new host is
                    same as old host error is raised.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Set_Host_Relation(
  p_sim_series_id         IN  sim_series.sim_series_id%TYPE,
  p_host_id               IN  host.host_id%TYPE,
  p_start_date            IN  DATE,
  p_end_date              IN  DATE,
  p_user_id_of_change     IN  NUMBER,
  handle_tran              IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code              OUT NUMBER,
  error_message            OUT VARCHAR2
);

/****************************************************************************
<header>
  <name>            procedure Get_Relation_to_Host
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  30.3.2006  -  created
  </version>

  <Description>     Procedure returns in cursor data about relation
                    of given sim series and hosts.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Relation_to_Host(
  p_sim_series_id          IN  sim_series.sim_series_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

END;
/
