CREATE package body VP_SIM_IMSI is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_rct_sim_imsi(p_coll rct_sim_imsi) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_rct_sim_imsi(p_coll in out nocopy rct_sim_imsi, p_size number)
is
  v_dif number;
begin
  ------------------------------
  util_pkg.XCheck_size0(p_size, 'p_size');
  ------------------------------
  if p_coll is null
  then
    p_coll := rct_sim_imsi();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get1_i(p_id_imsi varchar2, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return sim_imsi%rowtype
is
  v_res sim_imsi%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id_imsi is null, 'p_id_imsi');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date'); --!_!not used
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, UK_SIM_IMSI_IMSI)*/
        * into v_res
        from sim_imsi z
        where 1 = 1
        and imsi = p_id_imsi
        --!_!and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, UK_SIM_IMSI_IMSI)*/
        * into v_res
        from sim_imsi z
        where 1 = 1
        and imsi = p_id_imsi
        --!_!and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, UK_SIM_IMSI_IMSI)*/
      * into v_res
      from sim_imsi z
      where 1 = 1
      and imsi = p_id_imsi
      --!_!and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1(p_id_imsi varchar2, p_date date) return sim_imsi%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get1_i(p_id_imsi, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget1(p_id_imsi varchar2, p_date date) return sim_imsi%rowtype
is
  v_res sim_imsi%rowtype;
begin
  ------------------------------
  v_res := get1(p_id_imsi, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate(p_id_imsi, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get1(p_id_imsi varchar2, p_date date) return sim_imsi%rowtype
is
  v_res sim_imsi%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_i(p_id_imsi, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_xget1(p_id_imsi varchar2, p_date date) return sim_imsi%rowtype
is
  v_res sim_imsi%rowtype;
begin
  ------------------------------
  v_res := xlock_get1(p_id_imsi, p_date);
  ------------------------------
  if not is_identified(v_res)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate(p_id_imsi, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xlock(p_id_imsi varchar2, p_date date)
is
begin
  ------------------------------
  util_loc_pkg.touch_varchar(xlock_xget1(p_id_imsi, p_date).imsi);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function getN_ap_id_i(p_ap_id number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return rct_sim_imsi
is
  v_res rct_sim_imsi;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date'); --!_!not used
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_SIM_IMSI_ACCESS_POINT_IMSI)*/
        * bulk collect into v_res
      from sim_imsi z
      where 1 = 1
        and access_point_id = p_ap_id
        --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
      order by access_point_id, imsi_type_code
      for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_SIM_IMSI_ACCESS_POINT_IMSI)*/
        * bulk collect into v_res
      from sim_imsi z
      where 1 = 1
        and access_point_id = p_ap_id
        --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
      order by access_point_id, imsi_type_code
      for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_SIM_IMSI_ACCESS_POINT_IMSI)*/
      * bulk collect into v_res
    from sim_imsi z
    where 1 = 1
      and access_point_id = p_ap_id
      --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
    order by access_point_id, imsi_type_code
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function getN_ap_id(p_ap_id number, p_date date) return rct_sim_imsi
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return getN_ap_id_i(p_ap_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_getN_ap_id(p_ap_id number, p_date date) return rct_sim_imsi
is
  v_res rct_sim_imsi;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := getN_ap_id_i(p_ap_id, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function find_i_id_imsi(p_rec sim_imsi%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_cnt number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.imsi is null, 'p_rec.imsi');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  if p_check_only_other_ids
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
select /*+ index_asc(z, UK_SIM_IMSI_IMSI)*/
  count(1) cnt into v_cnt
  from sim_imsi z
  where 1 = 1
  and imsi = p_rec.imsi
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  --!_!and (v_check_only_other_ids = util_pkg.c_false or sim_imsi_id != p_rec.sim_imsi_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_ap_imsi_type(p_rec sim_imsi%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
  --!_!v_date date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.imsi is null, 'p_rec.imsi');
  util_pkg.XCheck_Cond_Missing(p_rec.access_point_id is null, 'p_rec.access_point_id');
  util_pkg.XCheck_Cond_Missing(p_rec.imsi_type_code is null, 'p_rec.imsi_type_code');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  --!_!v_date := util_ri.deleted2valid_date_to(p_rec.deleted);
  ------------------------------
select /*+ index_asc(z, I_SIM_IMSI_ACCESS_POINT_IMSI)*/
  count(1) cnt into v_cnt
  from sim_imsi z
  where 1 = 1
  and access_point_id = p_rec.access_point_id
  and imsi_type_code = p_rec.imsi_type_code
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  and (v_check_only_other_ids = util_pkg.c_false or imsi != p_rec.imsi)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i(p_rec sim_imsi%rowtype, p_check_only_other_ids boolean) return boolean
is
begin
  ------------------------------
  if find_i_id_imsi(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_ap_imsi_type(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xunique_i(p_rec sim_imsi%rowtype, p_check_only_other_ids boolean)
is
begin
  ------------------------------
  if find_i_id_imsi(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    --!_!util_pkg.Raise_Obj_NotUniq_OnDate(p_rec.imsi, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    util_pkg.Raise_Obj_NotUniq_ID(p_rec.imsi, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_ap_imsi_type(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    --!_!util_pkg.Raise_Obj_NotUniq_OnDate(p_rec.imsi, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    util_pkg.Raise_Obj2_NotUniq_ID3(p_rec.access_point_id, p_rec.imsi_type_code, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_i(p_rec sim_imsi%rowtype)
is
begin
  ------------------------------
  xunique_i(p_rec, FALSE);
  ------------------------------
  insert into sim_imsi
  values p_rec;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure change_i(p_rec sim_imsi%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xunique_i(p_rec, TRUE);
  ------------------------------
update /*+ index_asc(z, UK_SIM_IMSI_IMSI)*/
  sim_imsi z
  set
    row = p_rec
  where 1 = 1
  and imsi = p_rec.imsi
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_ID(p_rec.imsi, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_ID(p_rec.imsi, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure close_i(p_rec sim_imsi%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xunique_i(p_rec, TRUE);
  ------------------------------
delete /*+ index_asc(z, UK_SIM_IMSI_IMSI)*/
  sim_imsi z
  where 1 = 1
  and imsi = p_rec.imsi
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_ID(p_rec.imsi, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_ID(p_rec.imsi, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_identified(p_rec sim_imsi%rowtype) return boolean
is
begin
  ------------------------------
  return (p_rec.imsi is not null);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open(p_rec in out nocopy sim_imsi%rowtype)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  --!_!nextval
  ------------------------------
  --!_!p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change(p_rec in out nocopy sim_imsi%rowtype, p_date_from_virt date := null)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.imsi is null, 'p_rec.imsi');
  ------------------------------
  v_date_from_new := nvl(p_date_from_virt, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  xlock(p_rec.imsi, v_date_to_prev);
  ------------------------------
  --!_!p_rec.date_of_change := v_sysdate;
  ------------------------------
  change_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close
(
  p_id_imsi varchar2,
  p_user_id integer,
  p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_rec sim_imsi%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id_imsi is null, 'p_id_imsi');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_date_from_new := nvl(p_date_from, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  v_rec := xlock_xget1(p_id_imsi, v_date_to_prev);
  ------------------------------
  --!_!v_rec.user_id_of_change := p_user_id;
  ------------------------------
  --!_!v_rec.date_of_change := v_sysdate;
  --!_!v_rec.deleted := util_ri.valid_date_to2deleted(v_date_to_prev);
  ------------------------------
  --!_!change_i(v_rec);
  close_i(v_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_imsi_type(p_imsi_order_num integer) return varchar2
is
begin
  ------------------------------
  util_pkg.XCheck_index2(p_imsi_order_num, 'p_imsi_order_num');
  ------------------------------
  return c_imsi_type_prefix || util_pkg.number_to_char(p_imsi_order_num);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_imsi_add_type(p_imsi_add_order_num integer) return varchar2
is
begin
  ------------------------------
  util_pkg.XCheck_index2(p_imsi_add_order_num, 'p_imsi_add_order_num');
  ------------------------------
  return make_imsi_type(c_order_num_main_imsi + p_imsi_add_order_num);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_imsi_type_main return varchar2
is
begin
  ------------------------------
  return make_imsi_type(c_order_num_main_imsi);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
