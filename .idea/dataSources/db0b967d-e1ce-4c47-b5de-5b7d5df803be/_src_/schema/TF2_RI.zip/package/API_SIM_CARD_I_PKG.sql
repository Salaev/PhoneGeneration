CREATE package API_SIM_CARD_I_PKG is

----------------------------------!---------------------------------------------
  procedure clear_sim_card_details
  (
    p_ap_id number,
    p_user_id number
  );

  function ap_is_alive(p_ap_id number, p_date date) return boolean;

  procedure set_sim_series_status_validity
  (
    p_ss_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure validate_addition_sims
  (
    p_sim_imsi ct_varchar_s,
    p_main_imsi_index ct_number,
    p_date date,
    p_break_on_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  );

----------------------------------!---------------------------------------------
  procedure import_sim_card1_ii
  (
    p_imsi varchar2,
    p_iccid varchar2,
    p_pin varchar2,
    p_pin2 varchar2,
    p_puk varchar2,
    p_puk2 varchar2,
    p_msisdn_bound varchar2,
    p_personal_account number,
    p_ki nvarchar2,
    p_adm1 nvarchar2,
    p_access_control nvarchar2,
    p_authent_type varchar2,
    p_ss_id number,
    p_status varchar2,
    p_date date,
    p_addition_imsi ct_varchar_s,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure import_sim_card_i
  (
    p_sim_list ct_varchar_s,
    p_sn_list ct_varchar_s,
    p_pin_list ct_varchar_s,
    p_pin2_list ct_varchar_s,
    p_puk_list ct_varchar_s,
    p_puk2_list ct_varchar_s,
    p_ki_list ct_nvarchar_s,
    p_adm1_list ct_nvarchar_s,
    p_access_control_list ct_nvarchar_s,
    p_authent_type_list ct_varchar_s,
    p_main_imsi_index ct_number,
    p_addition_imsi ct_varchar_s,
    p_user_id number,
    p_break_on_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  );

----------------------------------!---------------------------------------------

end;
/
