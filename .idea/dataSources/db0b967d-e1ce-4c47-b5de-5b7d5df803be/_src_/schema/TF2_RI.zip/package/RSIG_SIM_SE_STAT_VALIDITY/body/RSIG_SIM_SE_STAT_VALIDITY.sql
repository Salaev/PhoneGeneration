CREATE PACKAGE BODY RSIG_SIM_SE_STAT_VALIDITY IS

---------------------------------------------
--     PROCEDURE Is_Sim_Series_Deleted
---------------------------------------------

PROCEDURE Is_Sim_Series_Deleted(p_sim_series_id IN SIM_SERIES.SIM_SERIES_ID%TYPE) IS
  v_pom number;
BEGIN
  select 1
    into v_pom
    from SIM_SERIES
   where SIM_SERIES_ID = p_sim_series_id
     and DELETED is not null;
  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    null;
END Is_Sim_Series_Deleted;

----------------------------------------------------------------------------------------------------
-- Is_Prod_Status_Change_Allowed
----------------------------------------------------------------------------------------------------
FUNCTION Is_Prod_Status_Change_Allowed(
  p_sim_series_id          IN  sim_series.sim_series_id%TYPE,
  p_new_status             IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_IS_BP                  IN  VARCHAR2,
  p_date                   IN  DATE
)RETURN INT
IS
  v_exist                     INT;
  v_date                      DATE;
  v_result                    NUMBER(5);
  v_old_status                ap_prod_status_hist.ap_prod_status_code%TYPE;
BEGIN

  v_date:=nvl(p_date,SYSDATE);

  BEGIN
    SELECT sssv.status_code
    INTO v_old_status
    FROM sim_series_status_validity sssv
    WHERE sssv.sim_series_id=p_sim_series_id
      AND v_date BETWEEN sssv.start_date AND nvl(sssv.end_date,v_date);
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_old_status:=NULL;
    WHEN TOO_MANY_ROWS THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_CHANGE_SP_STATUS_NOT_ALW, '');
  END;


  SELECT COUNT(1)
  INTO v_exist
  FROM dual
  WHERE EXISTS(SELECT 1
               FROM AP_PROD_STATUS_trans apst
               WHERE (apst.status_code_from=v_old_status OR (v_old_status IS NULL AND apst.status_code_from IS NULL))
                 AND apst.status_code_to=p_new_status
                 AND (apst.is_bp_only=p_IS_BP OR p_IS_BP=rsig_utils.c_YES));


  IF v_exist=0 THEN
    -- change is not allowed
    v_result:=RSIG_UTILS.c_CHANGE_SP_STATUS_NOT_ALW;
  ELSE
    v_result:=RSIG_UTILS.c_ok;
  END IF;

  RETURN v_result;

END Is_Prod_Status_Change_Allowed;
----------------------------------------------------------------------------------------------------------------------------------------------------
--  Insert_Interval
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_Interval(
  p_status_code           IN  SIM_SERIES_STATUS_VALIDITY.STATUS_CODE%TYPE,
  p_sim_series_id         IN  SIM_SERIES_STATUS_VALIDITY.SIM_SERIES_ID%TYPE,
  p_start_date            IN  SIM_SERIES_STATUS_VALIDITY.START_DATE%TYPE,
  p_IS_BP                 IN  VARCHAR2,
  p_user_id               IN  NUMBER,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message	        OUT VARCHAR2
)
IS
  v_package_name          VARCHAR2(30) := 'RSIG_SIM_SE_STAT_VALIDITY';
  v_procedure_name        VARCHAR2(30) := 'Insert_Interval';
  v_event_source          VARCHAR2(60);
  v_start_date            DATE;
  v_error                 NUMBER:=rsig_utils.c_OK;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check input parameters
  IF p_status_code IS NULL OR p_sim_series_id IS NULL OR p_user_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

--------------------------------------------------------------------------------------------------
  v_start_date := nvl(p_start_date, SYSDATE);

  Is_Sim_Series_Deleted(p_sim_series_id);

  v_error:=Is_Prod_Status_Change_Allowed(p_sim_series_id => p_sim_series_id,
                                         p_new_status => p_status_code,
                                         p_IS_BP => p_IS_BP,
                                         p_date => v_start_date);

  p_error_code :=v_error;


  IF v_error = RSIG_UTILS.c_OK THEN

    -- close previous interval
    update SIM_SERIES_STATUS_VALIDITY
       set END_DATE          = v_start_date - RSIG_UTILS.c_INTERVAL_DIFFERENCE,
           DATE_OF_CHANGE    = sysdate,
           USER_ID_OF_CHANGE = p_user_id
     where SIM_SERIES_ID = p_sim_series_id
       and (END_DATE is NULL or END_DATE > v_start_date)
       AND status_code<>p_status_code;

    -- create new interval
    insert into SIM_SERIES_STATUS_VALIDITY
      (STATUS_CODE,
       SIM_SERIES_ID,
       START_DATE,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE)
    VALUES(p_status_code,
           p_sim_series_id,
           v_start_date,
           SYSDATE,
           p_user_id);
  ELSE
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_CHANGE_SP_STATUS_NOT_ALW, 'Status change not allowed.');
  END IF;

---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,p_handle_tran,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Insert_Interval;


----------
END RSIG_SIM_SE_STAT_VALIDITY;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_SIM_SE_STAT_VALIDITY.pkb,v 1.20 2003/12/22 13:04:08 rhejduk Exp $
/
