CREATE PACKAGE RSIG_USERS IS
/****************************************************************************
<header>
  <name>             	package RSIG_USERS
  </name>

  <author>           	Pavel Stengl - STROM
  </author>

  	<version>		1.0.5  20.07.2009 Sergey Ermakov
                    		 Fixed error in function Get_User_login
  	</version>

  	<version>		1.0.4  19.02.2009 Josef Hartman
                    		 Added function Get_User_login
                    		 Added function Get_user_id_by_login
  	</version>
  	<version>		1.0.3   10.9.2004     Jaroslav Holub
                    			Delete_User - fixed for time difference
		            					between client and server, date should be null
            							and it means sysdate
  	</version>
    <version>       1.0.2   01.07.2004     Jaroslav Holub
                    		added constant c_NO_USER
							Get_User_id - when no user found then return in p_user_id c_NO_USER
    </version>
    <version> 		1.0.1   21.4.2004     Pavel Stengl
                            created first version
    </version>

  <Description>      	package for table USERS
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/

c_NO_USER CONSTANT NUMBER 	:= -1;		--constant for indicating no user found
TYPE t_tt_users IS TABLE OF tt_users%rowtype;


 /****************************************************************************
<header>
  <name>             	procedure Insert_User
  </name>

  <author>           	Pavel Stengl
  </author>

  <version>          	1.0.1   31.3.2004     Pavel Stengl
                                created first version
  </version>

  <Description>      	procedure inserts a new user
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );

                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code 	- OUT - NUMBER
					  p_user_name	- IN  - value for inserting row (USER_NAME)
					  p_login_name	- IN  - value for inserting row (LOGIN_NAME)
					  p_user_id		- OUT - returned id inserting row (USER_ID)
</Parameters>

</header>
****************************************************************************/

PROCEDURE Insert_User (
    handle_tran                	   	CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code             	OUT    	NUMBER,
	p_user_name				IN 		USERS.USER_NAME%TYPE,
	p_login_name			IN 		USERS.LOGIN_NAME%TYPE,
	p_user_id				OUT 	USERS.USER_ID%TYPE
  );

/****************************************************************************
<header>
  <name>             	procedure Delete_User
  </name>

  <author>           	Pavel Stengl
  </author>

	<version>			1.0.2   10.9.2004     Jaroslav Holub
                 				fixed for time difference
								between client and server, date should be null and it means sysdate
	</version>
	<version>          	1.0.1   31.3.2004     Pavel Stengl
                                created first version
	</version>

  <Description>      	Procedure sets column DELETED to value of parameter deleted in user given by user id,
                      		if given user is currently not deleted.
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code 	- OUT - NUMBER
					  p_user_id		- IN
					  p_user_name	- IN
					  p_deleted		- IN

  </Parameters>

</header>
****************************************************************************/

PROCEDURE Delete_User (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_user_id				  IN 	 USERS.USER_ID%TYPE,
    p_deleted                 IN     USERS.DELETED%TYPE
  );

/****************************************************************************
<header>
  <name>             	procedure Update_User
  </name>

  <author>           	Pavel Stengl
  </author>

  <version>          	1.0.1   31.3.2004     Pavel Stengl
                                created first version
  </version>

  <Description>      	Procedure user name and login name of given user
                      		if given user is currently not deleted.
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code 	- OUT - NUMBER
					  p_user_id		- IN
	  				  p_user_name	- IN
					  p_login_name	- IN


</Parameters>

</header>
****************************************************************************/

PROCEDURE Update_User (
    handle_tran                     CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code              OUT    	NUMBER,
	p_user_id				IN 		USERS.USER_ID%TYPE,
	p_user_name				IN 		USERS.USER_NAME%TYPE,
	p_login_name			IN 		USERS.LOGIN_NAME%TYPE
  );

  /****************************************************************************
  <header>
    <name>              procedure Get_User_id
    </name>

    <author>            Pavel Stengl
    </author>

    <version>           1.0.2   01.07.2004     Jaroslav Holub
                                when no user found then return in p_user_id c_NO_USER
    </version>
    <version>           1.0.1   31.3.2004     Pavel Stengl
                                created first version
    </version>

    <Description>     This procedure will return user_id for given user

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code            - Error code
						p_login_name	- IN  -  LOGIN_NAME
					  	p_user_id		- OUT - returned USER_ID
    </Parameters>

  </header>
/****************************************************************************/

PROCEDURE Get_User_id(
    error_code            OUT  NUMBER,
    p_login_name          IN   USERS.LOGIN_NAME%TYPE,
    p_users_id            OUT  USERS.USER_ID%TYPE
  );

  /****************************************************************************
  <header>
    <name>              procedure Get_User_login
    </name>

    <author>            Josef Hartman
    </author>

    <version>           1.0.1   19.02.2009     Josef Hartman
                                created first version
    </version>

    <Description>     This procedure will return login_name for given user

    </Description>

    <Application>       Resource Inventory
    </Application>

  </header>
/****************************************************************************/

PROCEDURE Get_User_login(
    error_code            OUT  NUMBER,
    p_users_id            IN  USERS.USER_ID%TYPE,
    p_login_name          OUT USERS.LOGIN_NAME%TYPE
  );

  /****************************************************************************
  <header>
    <name>              function Get_user_id_by_login
    </name>

    <author>            Josef Hartman
    </author>

    <version>           1.0.1   17.02.2009   Josef Hartman
                                created first version
    </version>

    <Description>     This function will return user_id for given user, otherwise raises error

    </Description>

    <Application>       Resource Inventory
    </Application>

  </header>
/****************************************************************************/

FUNCTION Get_user_id_by_login
(
  p_login_name  IN users.login_name%TYPE
) RETURN NUMBER;

END RSIG_USERS;
/
