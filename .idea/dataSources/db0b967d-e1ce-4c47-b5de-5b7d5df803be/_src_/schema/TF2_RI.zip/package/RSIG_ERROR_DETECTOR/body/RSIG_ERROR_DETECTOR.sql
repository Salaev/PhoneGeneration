CREATE PACKAGE BODY          "RSIG_ERROR_DETECTOR" is

 ----------------------------------------------------------------------------
  --  Host_difference_SIM_Phone
  ----------------------------------------------------------------------------

  procedure Host_difference_SIM_Phone(
   result_list  OUT sys_refcursor,
   error_code  OUT NUMBER,
   error_message OUT VARCHAR2
  )
  IS
   v_sqlcode number;
  BEGIN


    OPEN result_list
    FOR SELECT /*+ FIRST_ROWS */
            sc.sn,
            pn.international_format,
            pns.host_id PHONE_HOST,
            ss.host_id SIM_HOST,
            pn.phone_number_series_id,
            ss.sim_series_id,
            naap.From_Date,
            naap.to_date,
            naap.link_type_code,
            pn.network_address_id,
         sc.access_point_id,
            pns.*,
            ss.*
        FROM Network_Address_Access_Point naap
        JOIN phone_number pn ON pn.network_address_id = naap.network_address_id
        JOIN phone_number_series pns ON pns.phone_number_series_id = pn.phone_number_series_id
        JOIN sim_card sc ON sc.access_point_id = naap.access_point_id
        JOIN sim_series ss ON sc.sim_series_id = ss.sim_series_id
        WHERE ss.host_id <> pns.host_id
        ORDER BY naap.network_address_id,naap.access_point_id,naap.from_date;


   -- set error code to succesfully completed
   error_code := RSIG_UTILS.c_OK;
  EXCEPTION
   WHEN OTHERS THEN
    v_sqlcode := sqlcode;
    error_message := sqlerrm;
  --  DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, 'RSIG_SIM_SERIES.Insert_Sim_Series');
  END Host_difference_SIM_Phone;





  ----------------------------------------------------------------------------
  --  Incomplete_series
  ----------------------------------------------------------------------------

  procedure Incomplete_series(
    p_phone_series  OUT sys_refcursor,
    p_sim_series OUT sys_refcursor,
   error_code  OUT NUMBER,
   error_message OUT VARCHAR2
  )
  IS
   v_sqlcode number;



  BEGIN

    OPEN p_sim_series FOR
    SELECT /*+ FIRST_ROWS*/
  ss.sim_series_id,
  ss.start_imsi_number,
     ss.end_imsi_number,
     (to_number(ss.end_imsi_number) - to_number(ss.start_imsi_number)+1) SERIE_COUNT,
     (SELECT COUNT(*) FROM sim_card sc WHERE sc.sim_series_id = ss.sim_series_id) SIM_COUNT
 FROM sim_series ss
 WHERE (to_number(ss.end_imsi_number) - to_number(ss.start_imsi_number)+1) - (SELECT COUNT(*) FROM sim_card sc WHERE sc.sim_series_id = ss.sim_series_id) <> 0;
  -- check handle_tran parameter

    OPEN p_phone_series FOR
    SELECT /*+ FIRST_ROWS*/
  pns.phone_number_series_id,
  pns.country_code,
        pns.area_code,
        pns.local_number_start,
     pns.local_number_end,
     (to_number(pns.local_number_end) - to_number(pns.local_number_start)+1) SERIE_COUNT,
     (SELECT COUNT(*) FROM phone_number pn WHERE pns.phone_number_series_id = pn.phone_number_series_id) PHONE_COUNT
 FROM phone_number_series pns
 WHERE (to_number(pns.local_number_end) - to_number(pns.local_number_start)+1) - (SELECT COUNT(*) FROM phone_number pn WHERE pns.phone_number_series_id = pn.phone_number_series_id) <> 0;

   error_code := 0;
  EXCEPTION
   WHEN OTHERS THEN
    v_sqlcode := sqlcode;
    error_message := sqlerrm;
  --  DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, 'RSIG_SIM_SERIES.Insert_Sim_Series');

  END Incomplete_series;


  ----------------------------------------------------------------------------
  --  Wrongly_placed_phone_sims
  ----------------------------------------------------------------------------

  procedure Wrongly_placed_phone_sims(

    p_phones  OUT sys_refcursor,
    p_sims   OUT sys_refcursor,
    error_code  OUT NUMBER,
   error_message OUT VARCHAR2
  )
  IS
   v_sqlcode number;
  BEGIN
 OPEN p_sims FOR
 SELECT SC.ACCESS_POINT_ID, SC.IMSI, SC.SN, SC.SIM_SERIES_ID,ss.start_imsi_number,ss.end_imsi_number,'Should belong to', ss2.sim_series_id,ss2.start_imsi_number,ss2.end_imsi_number
 FROM SIM_CARD sc
 JOIN SIM_SERIES ss ON sc.sim_series_id = ss.sim_series_id
    LEFT JOIN SIM_SERIES ss2 ON (TO_NUMBER(sc.imsi) BETWEEN TO_NUMBER(ss2.start_imsi_number) AND TO_NUMBER(ss2.end_imsi_number))
 WHERE NOT (TO_NUMBER(sc.imsi) BETWEEN TO_NUMBER(ss.start_imsi_number) AND TO_NUMBER(ss.end_imsi_number));

    OPEN p_phones FOR
    SELECT PN.NETWORK_ADDRESS_ID,PN.INTERNATIONAL_FORMAT,PN.PHONE_NUMBER_SERIES_ID
 FROM PHONE_NUMBER pn
 JOIN PHONE_NUMBER_SERIES pns ON pns.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
 WHERE NOT (TO_NUMBER(PN.INTERNATIONAL_FORMAT) BETWEEN TO_NUMBER(PNS.COUNTRY_CODE||PNS.AREA_CODE||PNS.LOCAL_NUMBER_START) AND TO_NUMBER(PNS.COUNTRY_CODE||PNS.AREA_CODE||PNS.LOCAL_NUMBER_end));

   -- set error code to succesfully completed
   error_code := 0;
  EXCEPTION
   WHEN OTHERS THEN
    v_sqlcode := sqlcode;
    error_message := sqlerrm;
  --  DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, 'RSIG_SIM_SERIES.Insert_Sim_Series');
  END Wrongly_placed_phone_sims;


  ----------------------------------------------------------------------------
  --  SIM_SERIE_HLR_CONNECTION
  ----------------------------------------------------------------------------

  procedure SIM_SERIES_HLR_CONNECTION(
 p_sim_series  OUT sys_refcursor,
   error_code  OUT NUMBER,
   error_message OUT VARCHAR2
  )
  IS
   v_sqlcode number;
  BEGIN
   OPEN p_sim_series FOR
    SELECT *
    FROM sim_series ss
    LEFT JOIN HOST h ON h.host_id = ss.host_id
    WHERE h.host_type_code <> 'HL' OR h.host_type_code IS NULL
    ORDER BY ss.start_imsi_number;
   error_code := RSIG_UTILS.c_OK;
  EXCEPTION
   WHEN OTHERS THEN
    v_sqlcode := sqlcode;
    error_message := sqlerrm;
  --  DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, 'RSIG_SIM_SERIES.Insert_Sim_Series');
  END SIM_SERIES_HLR_CONNECTION;


 ----------------------------------------------------------------------------
 --  access_point_host_HLR
 ----------------------------------------------------------------------------

 procedure access_point_host_HLR(

  p_sim_card  OUT sys_refcursor,
  error_code  OUT NUMBER,
  error_message OUT VARCHAR2
 )
 IS
  v_sqlcode number;
 BEGIN
  OPEN p_sim_card FOR
    select
  ap.access_point_id,
     sc.sn,
     sc.sim_series_id, h.host_type_code,h.host_id
 FROM access_point_host t
 JOIN Access_Point ap ON ap.access_point_id = t.access_point_id
 JOIN host h ON h.host_id = t.host_id
 JOIN sim_card sc ON sc.access_point_id = ap.access_point_id
 WHERE h.host_type_code = 'HL'
 ORDER BY sc.sn;

  error_code := RSIG_UTILS.c_OK;
 EXCEPTION
  WHEN OTHERS THEN
   v_sqlcode := SQLCODE;
   error_message := SQLERRM;
 --  DBMS_OUTPUT.PUT_LINE(error_message);
   error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
   RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, 'RSIG_SIM_SERIES.Insert_Sim_Series');
 END access_point_host_HLR;

end RSIG_ERROR_DETECTOR;
/
