CREATE PACKAGE BODY PHONE_NUMBER_PCK IS
---------------------------------------------------------------------------------------------------
-- Lock_Phones
---------------------------------------------------------------------------------------------------
PROCEDURE Lock_Phones
IS
  CURSOR c_lock_phone IS
  SELECT /*+ index(pn UK_PHONE_NUM_PHONE_NUMBER) */
         pn.network_address_id
  FROM tt_batch_na_ap t
  JOIN phone_number pn ON pn.international_format=t.International_Format
  FOR UPDATE;
BEGIN
  OPEN c_lock_phone;
  CLOSE c_lock_phone;
END;

---------------------------------------------------------------------------------------------------
-- Lock_Phones_by_ID
---------------------------------------------------------------------------------------------------
PROCEDURE Lock_Phones_by_ID
IS
  CURSOR c_lock_phone IS
  SELECT /*+ index(pn PK_PHONE_NUMBER) */
         pn.network_address_id
  FROM tt_batch_na_ap t
  JOIN phone_number pn ON pn.network_address_id=t.network_address_id
  FOR UPDATE;
BEGIN
  OPEN c_lock_phone;
  CLOSE c_lock_phone;
END;

---------------------------------------------------------------------------------------------------
-- Lock_Phones
---------------------------------------------------------------------------------------------------
PROCEDURE Lock_Phones(
  p_international_format  IN  phone_number.international_format%TYPE,
  p_network_address_id    OUT phone_number.network_address_id%TYPE,
  p_error                 OUT INT
)
IS
BEGIN
  SELECT pn.network_address_id
  INTO p_network_address_id
  FROM phone_number pn
  WHERE pn.international_format=p_international_format
    AND (pn.deleted IS NULL OR pn.deleted>SYSDATE)
  FOR UPDATE;

  p_error:=rsig_utils.c_OK;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    p_error:=RSIG_UTILS.c_PHONE_NUMBER_NOT_EXISTS;
END;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Salability_Category_Recalculation
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Salability_Cat_Recalculation(
  p_phone_number_series_id        IN  PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
  p_recalculate_all_status        IN  CHAR,
  p_recalculate_all_sc            IN  CHAR,
  p_start_date                    IN  DATE,
  p_user_id                       IN  NUMBER,
  p_handle_tran                   IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error                   IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                    OUT NUMBER,
  p_error_message                   OUT VARCHAR2
) IS
  v_package_name                  VARCHAR2(30) := 'PHONE_NUMBER_PCK';
  v_procedure_name                VARCHAR2(30) := 'Salability_Cat_Recalculation';
  v_event_source                  VARCHAR2(60);
  v_start_date                    DATE;
  v_sysdate                       DATE:=SYSDATE;
  TYPE t_num_tab IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
  TYPE t_var_tab IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
  v_main_msisdn t_var_tab;
  v_linked_msisdn t_var_tab;
  v_main_naid t_num_tab;
  v_linked_naid t_num_tab;
  v_main_pnsid t_num_tab;
  v_linked_pnsid t_num_tab;
  /*v_main_nasc t_var_tab;
  v_linked_nasc t_var_tab;
  v_main_scc t_var_tab;
  v_linked_scc t_var_tab;*/
  v_cnt_opt number;
  v_cnt_act number;

  c_sett_large_pns_threshold     constant varchar2(100) := 'LARGE_PNS_THRESHOLD';
  c_def_large_pns_threshold      constant number := 10000;

function geto_large_pns_threshold return number
is
  v_def_res number := c_def_large_pns_threshold;
begin
  ------------------------------
  return nvl(RSIG_UTILS.get_ri_setting_num(c_sett_large_pns_threshold, v_def_res), v_def_res);
  ------------------------------
end;

BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check input parameters
  IF (p_phone_number_series_id IS NULL) OR (nvl(p_recalculate_all_status, 'Z') NOT IN (RSIG_UTILS.c_YES, RSIG_UTILS.c_NO))
                                        OR (nvl(p_recalculate_all_sc, 'Z') NOT IN (RSIG_UTILS.c_YES, RSIG_UTILS.c_NO)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  --------------------------------------------------------------------------------------------------
  v_cnt_opt := geto_large_pns_threshold;

  select /*+ index_asc(pn, I_PHONENUM_PHONE_NUM_SERIES_ID)*/
    count(1) into v_cnt_act
    from phone_number z
    where 1 = 1
    and phone_number_series_id = p_phone_number_series_id
  ;

  v_start_date:=nvl(p_start_date,SYSDATE);

  BEGIN

    IF v_cnt_act >= v_cnt_opt
    THEN

      select
        main_msisdn,
        linked_msisdn,
        main_network_address_id,
        linked_network_address_id,
        main_phone_number_series_id,
        linked_phone_number_series_id
      bulk collect into
        v_main_msisdn, v_linked_msisdn, v_main_naid, v_linked_naid, v_main_pnsid, v_linked_pnsid
      from (
        select /*+ ordered use_hash(pn, pll, plm, pnl, pnm)
            full(pn)
            full(pll)
            full(plm)
            full(pnl)
            full(pnm)
            */
          nvl(pnl.international_format, pn.international_format) main_msisdn,
          nvl(pll.linked_msisdn, plm.linked_msisdn) linked_msisdn,
          nvl(pnl.network_address_id, pn.network_address_id) main_network_address_id,
          nvl(pnm.network_address_id, pn.network_address_id) linked_network_address_id,
          nvl(pnl.phone_number_series_id, pn.phone_number_series_id) main_phone_number_series_id,
          nvl(pnm.phone_number_series_id, pn.phone_number_series_id) linked_phone_number_series_id,
          nvl(pnl.net_address_status_code, pn.net_address_status_code) main_nasc,
          nvl(pnm.net_address_status_code, pn.net_address_status_code) linked_nasc,
          nvl(pnl.salability_category_code, pn.salability_category_code) main_scc,
          nvl(pnm.salability_category_code, pn.salability_category_code) linked_scc
        from phone_number pn, phone_link pll, phone_link plm, phone_number pnl, phone_number pnm
        where 1 = 1
          and pn.phone_number_series_id = p_phone_number_series_id
          and pll.linked_msisdn(+) = pn.international_format
          and plm.main_msisdn(+) = pn.international_format
          and pnl.international_format(+) = pll.main_msisdn
          and pnm.international_format(+) = plm.linked_msisdn
          and nvl(pn.deleted, v_start_date + 123) > v_start_date
          and nvl(pnl.deleted(+), v_start_date + 123) > v_start_date
          and nvl(pnm.deleted(+), v_start_date + 123) > v_start_date
      )
      where 1 = 1
        and (p_recalculate_all_status = RSIG_UTILS.c_YES
          or (main_nasc = rsig_utils.c_FREE_PHONE_NUMBER_CODE
            and nvl(linked_nasc, rsig_utils.c_FREE_PHONE_NUMBER_CODE) = rsig_utils.c_FREE_PHONE_NUMBER_CODE
          )
        )
        and (p_recalculate_all_sc = RSIG_UTILS.c_YES
          or (main_scc = rsig_utils.c_STANDARD_SAL_CATEGORY
            and nvl(linked_scc, rsig_utils.c_STANDARD_SAL_CATEGORY) = rsig_utils.c_STANDARD_SAL_CATEGORY
          )
        )
      order by main_phone_number_series_id, main_network_address_id, linked_network_address_id
      for update nowait
      ;

    ELSE

      select
        main_msisdn,
        linked_msisdn,
        main_network_address_id,
        linked_network_address_id,
        main_phone_number_series_id,
        linked_phone_number_series_id
      bulk collect into
        v_main_msisdn, v_linked_msisdn, v_main_naid, v_linked_naid, v_main_pnsid, v_linked_pnsid
      from (
        select /*+ ordered use_nl(pn, pll, plm, pnl, pnm)
            index_asc(pn, I_PHONENUM_PHONE_NUM_SERIES_ID)
            index_asc(pll, I_PHONE_LINK_LINKED_MSISDN)
            index_asc(plm, PK_PHONE_LINK)
            index_asc(pnl, UK_PHONE_NUM_PHONE_NUMBER)
            index_asc(pnm, UK_PHONE_NUM_PHONE_NUMBER)
            */
          nvl(pnl.international_format, pn.international_format) main_msisdn,
          nvl(pll.linked_msisdn, plm.linked_msisdn) linked_msisdn,
          nvl(pnl.network_address_id, pn.network_address_id) main_network_address_id,
          nvl(pnm.network_address_id, pn.network_address_id) linked_network_address_id,
          nvl(pnl.phone_number_series_id, pn.phone_number_series_id) main_phone_number_series_id,
          nvl(pnm.phone_number_series_id, pn.phone_number_series_id) linked_phone_number_series_id,
          nvl(pnl.net_address_status_code, pn.net_address_status_code) main_nasc,
          nvl(pnm.net_address_status_code, pn.net_address_status_code) linked_nasc,
          nvl(pnl.salability_category_code, pn.salability_category_code) main_scc,
          nvl(pnm.salability_category_code, pn.salability_category_code) linked_scc
        from phone_number pn, phone_link pll, phone_link plm, phone_number pnl, phone_number pnm
        where 1 = 1
          and pn.phone_number_series_id = p_phone_number_series_id
          and pll.linked_msisdn(+) = pn.international_format
          and plm.main_msisdn(+) = pn.international_format
          and pnl.international_format(+) = pll.main_msisdn
          and pnm.international_format(+) = plm.linked_msisdn
          and nvl(pn.deleted, v_start_date + 123) > v_start_date
          and nvl(pnl.deleted(+), v_start_date + 123) > v_start_date
          and nvl(pnm.deleted(+), v_start_date + 123) > v_start_date
      )
      where 1 = 1
        and (p_recalculate_all_status = RSIG_UTILS.c_YES
          or (main_nasc = rsig_utils.c_FREE_PHONE_NUMBER_CODE
            and nvl(linked_nasc, rsig_utils.c_FREE_PHONE_NUMBER_CODE) = rsig_utils.c_FREE_PHONE_NUMBER_CODE
          )
        )
        and (p_recalculate_all_sc = RSIG_UTILS.c_YES
          or (main_scc = rsig_utils.c_STANDARD_SAL_CATEGORY
            and nvl(linked_scc, rsig_utils.c_STANDARD_SAL_CATEGORY) = rsig_utils.c_STANDARD_SAL_CATEGORY
          )
        )
      order by main_phone_number_series_id, main_network_address_id, linked_network_address_id
      for update nowait
      ;

    END IF;

  EXCEPTION
    WHEN RSIG_UTILS.RESOURCE_BUSY THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_RESOURCE_BUSY, 'Resource is busy');
  END;

  delete from tt_phone_link2;
  forall v_i in v_main_msisdn.first..v_main_msisdn.last
    insert into tt_phone_link2(
      main_msisdn, linked_msisdn, main_network_address_id, linked_network_address_id,
      main_phone_number_series_id, linked_phone_number_series_id
      )
    values(
      v_main_msisdn(v_i), v_linked_msisdn(v_i), v_main_naid(v_i), v_linked_naid(v_i),
      v_main_pnsid(v_i), v_linked_pnsid(v_i)
    )
  ;
  -- close old salability category for linked phone numbers
  update (
    select /*+ ordered use_nl(pnsc) index_asc(pnsc, I_PHONUSALCA_NET_ADDRESS_ID)*/
      pnsc.date_of_change, pnsc.user_id_of_change, pnsc.end_date
    from tt_phone_link2 t, phone_number_salability_categ pnsc
    where 1 = 1
      and pnsc.network_address_id = t.linked_network_address_id
      and v_start_date between pnsc.start_date and nvl(pnsc.end_date, v_start_date)
  )
  set
    date_of_change = v_sysdate,
    user_id_of_change = p_user_id,
    end_date = v_start_date - rsig_utils.c_INTERVAL_DIFFERENCE
  ;
  -- close old salability category for main phone numbers
  update (
    select /*+ ordered use_nl(pnsc) index_asc(pnsc, I_PHONUSALCA_NET_ADDRESS_ID)*/
      pnsc.date_of_change, pnsc.user_id_of_change, pnsc.end_date
    from tt_phone_link2 t, phone_number_salability_categ pnsc
    where 1 = 1
      and pnsc.network_address_id = t.main_network_address_id
      and v_start_date between pnsc.start_date and nvl(pnsc.end_date, v_start_date)
  )
  set
    date_of_change = v_sysdate,
    user_id_of_change = p_user_id,
    end_date = v_start_date - rsig_utils.c_INTERVAL_DIFFERENCE
  ;
  -- new salability category for linked phone numbers
  insert into phone_number_salability_categ
  (
    salability_category_code, network_address_id, start_date,
    date_of_change, user_id_of_change, end_date
  )
  select result_scc salability_category_code, network_address_id, v_start_date start_date,
    v_sysdate date_of_change, p_user_id user_id_of_change, null end_date
  from (
    select /*+ driving_site(z) ordered use_hash(z, psc) full(psc)*/
      row_number() over (partition by z.mask_msisdn order by z.in_mask desc, nvl(psc.attractiveness_level, 999999999999999999), trim(psc.phone_salability_category_code)) ord,
      decode(z.in_mask, 0, rsig_utils.c_standard_sal_category, z.salability_category_code) result_scc,
      z.*
    from (
      select /*+ ordered use_nl(scm) full(scm)*/
        PHONE_NUMBER_PCK.is_phone_number_in_mask(z.mask_msisdn, scm.mask) in_mask,
        scm.salability_category_code,
        z.*
      from (
        select
          linked_network_address_id network_address_id,
          nvl(linked_msisdn, main_msisdn) mask_msisdn
        from tt_phone_link2
        where 1 = 1
          and linked_msisdn is not null
      ) z, salability_category_mask scm
      where 1 = 1
        and PHONE_NUMBER_PCK.is_phone_number_in_mask(z.mask_msisdn, scm.mask(+)) = 1
    ) z, phone_salability_category psc
    where 1 = 1
      and trim(psc.phone_salability_category_code(+)) = trim(z.salability_category_code)
  )
  where 1 = 1
    and ord = 1
  ;
  -- insert new salability category for main phone numbers
  insert into phone_number_salability_categ(
    salability_category_code, network_address_id, start_date,
    date_of_change, user_id_of_change, end_date
  )
  select result_scc salability_category_code, network_address_id, v_start_date start_date,
    v_sysdate date_of_change, p_user_id user_id_of_change, null end_date
  from (
    select /*+ driving_site(z) ordered use_hash(z, psc) full(psc)*/
      row_number() over (partition by z.mask_msisdn order by z.in_mask desc, nvl(psc.attractiveness_level, 999999999999999999), trim(psc.phone_salability_category_code)) ord,
      decode(z.in_mask, 0, rsig_utils.c_standard_sal_category, z.salability_category_code) result_scc,
      z.*
    from (
      select /*+ ordered use_nl(scm) full(scm)*/
        PHONE_NUMBER_PCK.is_phone_number_in_mask(z.mask_msisdn, scm.mask) in_mask,
        scm.salability_category_code,
        z.*
      from (
        select
          main_network_address_id         network_address_id,
          nvl(linked_msisdn, main_msisdn) mask_msisdn --!_! #42954
        from tt_phone_link2
      ) z, salability_category_mask scm
      where 1 = 1
        and PHONE_NUMBER_PCK.is_phone_number_in_mask(z.mask_msisdn, scm.mask(+)) = 1
    ) z, phone_salability_category psc
    where 1 = 1
      and trim(psc.phone_salability_category_code(+)) = trim(z.salability_category_code)
  )
  where 1 = 1
    and ord = 1
  ;
  ---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,p_handle_tran,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Salability_Cat_Recalculation;

-------------------------------------------------------------------------------
--      FUNCTION Is_Phone_Number_In_Mask
-------------------------------------------------------------------------------
FUNCTION Is_Phone_Number_In_Mask
(
  p_phone_number IN VARCHAR2, -- actuall phone number
  p_mask         IN VARCHAR2 -- actuall mask
) RETURN INT
IS
  v_char      CHAR(1);
  v_char_pn   CHAR(1);
  v_is_char   INT;

BEGIN
  v_is_char := 0;
  IF LENGTH(p_phone_number) > 0
     AND LENGTH(p_mask) > 0 THEN
    v_is_char := 1;
    FOR a IN REVERSE 1 .. LENGTH(p_mask)
    LOOP
      IF v_is_char=1 THEN
        v_char := UPPER(SUBSTR(p_mask, a, 1));
        IF v_char >= '0'
           AND v_char <= '9' THEN
          IF SUBSTR(p_phone_number, LENGTH(p_phone_number) - (LENGTH(p_mask) - a), 1) <> v_char THEN
            v_is_char := 0;
          END IF;
        END IF;
        IF v_char >= 'A'
           AND v_char <= 'Z' THEN
          v_char_pn := SUBSTR(p_phone_number, LENGTH(p_phone_number) - (LENGTH(p_mask) - a), 1);
          FOR b IN REVERSE 1 .. (a - 1)
          LOOP
            IF UPPER(SUBSTR(p_mask, b, 1)) = v_char THEN
              IF SUBSTR(p_phone_number, LENGTH(p_phone_number) - (LENGTH(p_mask) - b), 1) <> v_char_pn THEN
                v_is_char := 0;
              END IF;
            END IF;
          END LOOP;
        END IF;
      END IF;
    END LOOP;
  END IF;
  RETURN v_is_char;
END Is_Phone_Number_In_Mask;


-----------------------------------------------------------------------------------------------------------------------------------------------------
--  ImportPhoneLinks
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE ImportPhoneLinks(
  p_linked_MSISDN_l       IN  common.t_international_format,
  p_main_MSISDN_l         IN  common.t_international_format,
  p_host_id_l             IN  common.t_number,
  p_network_operator_id   IN  network_operator.network_operator_id%TYPE,
  p_external_operator_id  IN  network_operator.network_operator_id%TYPE,
  p_user_id               IN  NUMBER,
  p_handle_tran              IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error              IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message            OUT VARCHAR2,
  p_error_list            OUT SYS_REFCURSOR
)
IS
  v_package_name          VARCHAR2(30) := 'PHONE_NUMBER_PCK';
  v_procedure_name        VARCHAR2(30) := 'ImportPhoneLinks';
  v_event_source          VARCHAR2(60);
  v_sysdate               DATE:=SYSDATE;
  v_first_id              NUMBER;
  v_last_id               NUMBER:=1;
  v_MSISDN_l              common.t_international_format;
  v_host_id_l             common.t_number;
  v_line_number_l         common.t_number;
  v_handle_tran           VARCHAR2(1);
  v_pns_id                phone_number_series.phone_number_series_id%TYPE;

  c_federal_phone_type    CONSTANT  VARCHAR2(1):='F';
  c_city_phone_type       CONSTANT  VARCHAR2(2):='P2';
  c_country_code          CONSTANT  VARCHAR2(1):='7';

  v_exists                BOOLEAN := FALSE;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check input parameters
  IF p_linked_MSISDN_l.COUNT=0 OR (p_linked_MSISDN_l.COUNT = 1 AND p_linked_MSISDN_l(p_linked_MSISDN_l.FIRST) IS NULL) OR
   (p_main_MSISDN_l.COUNT = 1 AND p_main_MSISDN_l(p_main_MSISDN_l.FIRST) IS NULL) OR p_linked_MSISDN_l.COUNT<>p_main_MSISDN_l.COUNT OR
    (p_host_id_l.COUNT = 1 AND p_host_id_l(p_host_id_l.FIRST) IS NULL) OR  p_main_MSISDN_l.COUNT<>p_host_id_l.COUNT OR p_user_id IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  DELETE FROM tt_phone_link;
--------------------------------------------------------------------------------------------------
  v_handle_tran:=rsig_utils.Get_Handle_Tran_For_Call_Proc(p_handle_tran);

  -- test for network operators existence
  rsig_network_operator.Test_Network_Operator_Deleted(p_network_operator_id);
  rsig_network_operator.Test_Network_Operator_Deleted(p_external_operator_id);

  -- generate line number
  FOR i IN p_linked_MSISDN_l.FIRST .. p_linked_MSISDN_l.LAST LOOP
    v_line_number_l(i):=i;
  END LOOP;

  -- copy data into the temporary table
  FORALL i IN p_main_MSISDN_l.FIRST .. p_main_MSISDN_l.LAST
  INSERT INTO tt_phone_link(linked_msisdn,main_msisdn,host_id,line_number,error_code)
  VALUES(p_linked_MSISDN_l(i),p_main_MSISDN_l(i),p_host_id_l(i),v_line_number_l(i),rsig_utils.c_OK);

  -- check data ----------------------------------------------------------------------------
  -- check linked MSISDN duplicity
  UPDATE tt_phone_link t
  SET t.error_code=constants.c_ERR_LINKED_MSISDN_DUPLICITY
  WHERE t.linked_msisdn IN (SELECT t.linked_msisdn
                            FROM tt_phone_link t
                            GROUP BY t.linked_msisdn
                            HAVING COUNT(*)>1);

  IF SQL%FOUND THEN
    v_exists:=TRUE;
  END IF;

  -- check main MSISDN duplicity
  UPDATE tt_phone_link t
  SET t.error_code=constants.c_ERR_MAIN_MSISDN_DUPLICITY
  WHERE t.main_msisdn IN (SELECT t.main_msisdn
                            FROM tt_phone_link t
                            GROUP BY t.main_msisdn
                            HAVING COUNT(*)>1);

  IF SQL%FOUND THEN
    v_exists:=TRUE;
  END IF;

  -- check linked MSISDN existence
  UPDATE tt_phone_link t
  SET t.error_code=constants.c_ERR_LINKED_MSISDN_EXISTS
  WHERE EXISTS(SELECT /*+ index(pn UK_PHONE_NUM_PHONE_NUMBER) */
                      1
               FROM phone_number pn
               WHERE pn.international_format=c_country_code || t.linked_msisdn
                 AND pn.deleted IS NULL);

  IF SQL%FOUND THEN
    v_exists:=TRUE;
  END IF;

  -- check main MSISDN existence
  UPDATE tt_phone_link t
  SET t.error_code=constants.c_ERR_MAIN_MSISDN_EXISTS
  WHERE EXISTS(SELECT /*+ index(pn UK_PHONE_NUM_PHONE_NUMBER) index(naap I_NETADDRACCPO_NET_ADDRESS_ID) */
                      1
               FROM phone_number pn
               JOIN network_address_access_point naap ON naap.network_address_id=pn.network_address_id
                    AND v_sysdate BETWEEN naap.from_date AND nvl(naap.To_Date,v_sysdate)
               WHERE pn.international_format=c_country_code || t.main_msisdn
                 AND pn.deleted IS NULL);

  IF SQL%FOUND THEN
    v_exists:=TRUE;
  END IF;

  -- check if main MSISDN is already linked
  UPDATE tt_phone_link t
  SET t.error_code=constants.c_ERR_MAIN_MSISDN_LINKED
  WHERE EXISTS(SELECT /* index(pl PK_PHONE_LINK)*/
                      1
               FROM phone_link pl
               WHERE pl.main_msisdn=c_country_code || t.main_msisdn);

  IF SQL%FOUND THEN
    v_exists:=TRUE;
  END IF;


  ------------------------------------------------------------------------------------------
  IF v_exists THEN  -- some problem exists, data cannot be imported
    p_error_code:=constants.c_ERR_LINKED_MSISDN_DUPLICITY;
  ELSE             -- import of data

    -- mark phone numbers which already exist
    UPDATE tt_phone_link t
    SET t.error_code=-1
    WHERE EXISTS(SELECT /*+ index(pn UK_PHONE_NUM_PHONE_NUMBER) index(naap I_NETADDRACCPO_NET_ADDRESS_ID) */
                        1
                 FROM phone_number pn
                 WHERE pn.international_format=c_country_code || t.main_msisdn
                   AND pn.deleted IS NULL);

    -- order main MSISDN
    SELECT t.main_msisdn,t.host_id
    BULK COLLECT INTO v_MSISDN_l,v_host_id_l
    FROM tt_phone_link t
    WHERE t.error_code=rsig_utils.c_OK
    ORDER BY t.host_id,t.main_msisdn;

    UPDATE tt_phone_link t
    SET t.error_code=rsig_utils.c_OK
    WHERE t.error_code=-1;

    -- create continous ranges for main MSISDN
    IF v_MSISDN_l.COUNT>0 THEN
      FOR i IN v_MSISDN_l.FIRST .. v_MSISDN_l.LAST LOOP
        -- first loop or new range
        IF v_MSISDN_l(v_last_id)+1 <> v_MSISDN_l(i) OR v_host_id_l(v_last_id) <> v_host_id_l(i) THEN
          IF v_first_id IS NOT NULL THEN -- new range

            rsig_host.Test_Row_For_Exist_And_Deleted(v_host_id_l(v_first_id));

            rsig_phone_number_series.Insert_Phone_Number_Series
                     (p_phone_number_type_code => c_federal_phone_type,
                      p_phone_num_status_code => rsig_utils.c_FREE_PHONE_NUMBER_CODE,
                      p_country_code => c_country_code,
                      p_area_code => substr(v_MSISDN_l(v_first_id),1,3),
                      p_starting_local_number => substr(v_MSISDN_l(v_first_id),4),
                      p_ending_local_number => substr(v_MSISDN_l(v_last_id),4),
                      p_network_operator_id => p_network_operator_id,
                      p_start_date => v_sysdate,
                      p_host_id => v_host_id_l(v_first_id),
                      p_subhost_id => null,
                      p_set_gold => rsig_utils.c_YES,
                      p_create_phones => util_pkg.c_true,
                      p_user_id => p_user_id,
                      p_handle_tran => v_handle_tran,
                      p_raise_error => rsig_utils.c_YES,
                      p_phone_serie_id => v_pns_id,
                      p_error_code => p_error_code,
                      p_error_message => p_error_message);

          END IF;

          v_first_id:=i;
        END IF;
        v_last_id:=i;
      END LOOP;

      rsig_host.Test_Row_For_Exist_And_Deleted(v_host_id_l(v_first_id));
      -- create last phone series
      rsig_phone_number_series.Insert_Phone_Number_Series
               (p_phone_number_type_code => c_federal_phone_type,
                p_phone_num_status_code => rsig_utils.c_FREE_PHONE_NUMBER_CODE,
                p_country_code => c_country_code,
                p_area_code => substr(v_MSISDN_l(v_first_id),1,3),
                p_starting_local_number => substr(v_MSISDN_l(v_first_id),4),
                p_ending_local_number => substr(v_MSISDN_l(v_last_id),4),
                p_network_operator_id => p_network_operator_id,
                p_start_date => v_sysdate,
                p_host_id => v_host_id_l(v_first_id),
                p_subhost_id => null,
                p_set_gold => rsig_utils.c_YES,
                p_create_phones => util_pkg.c_true,
                p_user_id => p_user_id,
                p_handle_tran => v_handle_tran,
                p_raise_error => rsig_utils.c_YES,
                p_phone_serie_id => v_pns_id,
                p_error_code => p_error_code,
                p_error_message => p_error_message);

    END IF;

     -- order linked MSISDN ---------------------------------------------------------------------
    SELECT t.linked_msisdn,t.host_id
    BULK COLLECT INTO v_MSISDN_l,v_host_id_l
    FROM tt_phone_link t
    ORDER BY t.linked_msisdn;

    v_first_id:=NULL;
    v_last_id:=1;

    IF v_MSISDN_l.COUNT>0 THEN
      FOR i IN v_MSISDN_l.FIRST .. v_MSISDN_l.LAST LOOP
        -- first loop or new range
        IF v_MSISDN_l(v_last_id)+1 <> v_MSISDN_l(i) THEN
          IF v_first_id IS NOT NULL THEN -- new range
            -- create new phone series

            rsig_phone_number_series.Insert_Phone_Number_Series
                     (p_phone_number_type_code => c_city_phone_type,
                      p_phone_num_status_code => rsig_utils.c_FREE_PHONE_NUMBER_CODE,
                      p_country_code => c_country_code,
                      p_area_code => substr(v_MSISDN_l(v_first_id),1,3),
                      p_starting_local_number => substr(v_MSISDN_l(v_first_id),4),
                      p_ending_local_number => substr(v_MSISDN_l(v_last_id),4),
                      p_network_operator_id => p_network_operator_id,
                      p_start_date => v_sysdate,
                      p_host_id => v_host_id_l(v_first_id),
                      p_subhost_id => null,
                      p_set_gold => rsig_utils.c_YES,
                      p_create_phones => util_pkg.c_true,
                      p_user_id => p_user_id,
                      p_handle_tran => v_handle_tran,
                      p_raise_error => rsig_utils.c_YES,
                      p_phone_serie_id => v_pns_id,
                      p_error_code => p_error_code,
                      p_error_message => p_error_message);

            INSERT INTO phone_series_operator
                   (phone_number_series_id,
                    network_operator_id,
                    start_date,
                    end_date,
                    date_of_change,
                    user_id_of_change)
            VALUES(v_pns_id,
                   p_external_operator_id,
                   v_sysdate,
                   NULL,
                   v_sysdate,
                   p_user_id);

          END IF;

          v_first_id:=i;
        END IF;
        v_last_id:=i;
      END LOOP;

      -- create last phone series
      rsig_phone_number_series.Insert_Phone_Number_Series
               (p_phone_number_type_code => c_city_phone_type,
                p_phone_num_status_code => rsig_utils.c_FREE_PHONE_NUMBER_CODE,
                p_country_code => c_country_code,
                p_area_code => substr(v_MSISDN_l(v_first_id),1,3),
                p_starting_local_number => substr(v_MSISDN_l(v_first_id),4),
                p_ending_local_number => substr(v_MSISDN_l(v_last_id),4),
                p_network_operator_id => p_network_operator_id,
                p_start_date => v_sysdate,
                p_host_id => v_host_id_l(v_first_id),
                p_subhost_id => null,
                p_set_gold => rsig_utils.c_YES,
                p_create_phones => util_pkg.c_true,
                p_user_id => p_user_id,
                p_handle_tran => v_handle_tran,
                p_raise_error => rsig_utils.c_YES,
                p_phone_serie_id => v_pns_id,
                p_error_code => p_error_code,
                p_error_message => p_error_message);

      -- assigne series to external operator
      INSERT INTO phone_series_operator
             (phone_number_series_id,
              network_operator_id,
              start_date,
              end_date,
              date_of_change,
              user_id_of_change)
      VALUES(v_pns_id,
             p_external_operator_id,
             v_sysdate,
             NULL,
             v_sysdate,
             p_user_id);

    END IF;


    INSERT INTO phone_link(main_msisdn,linked_msisdn)
    SELECT c_country_code || t.main_msisdn,
           c_country_code || t.linked_msisdn
    FROM tt_phone_link t;

  END IF;

  -- empty cursor
  OPEN p_error_list FOR
  SELECT t.line_number,
         t.linked_msisdn,
         t.main_msisdn,
         t.host_id,
         t.error_code
  FROM tt_phone_link t
  ORDER BY t.line_number;



---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,p_handle_tran,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;


    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END ImportPhoneLinks;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure delete_last_open_previous
(
  p_phone_list util_pkg.cit_varchar_s,
  p_user_login varchar2,
  p_error_code out number,
  p_error_message out varchar2,
  p_result_list out sys_refcursor
)
is
begin
  ------------------------------
  util_pkg.XCheckP_cit_varchar_s(p_phone_list, 'p_phone_list');
  util_pkg.XCheck_Cond_Missing(p_user_login is null, 'p_user_login');
  ------------------------------
  delete_last_open_previous_int
  (
    p_msisdn => util_pkg.cast_cit2ct_varchar_s(p_phone_list, true),
    p_user_id => util_ri.xget_user_id(p_user_login)
  );
  ------------------------------
  open p_result_list for
  select
    international_format,
    result
  from tt_batch_na_ap
  where 1 = 1
    and result != util_pkg.c_ora_ok
  ;
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure delete_last_open_previous2
(
  p_network_address_id number,
  p_user_id_of_change number,
  error_code out number,
  p_error_message out varchar2
)
IS
  v_date date := sysdate;
  v_error_code number;
  v_error_message varchar2(4000);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id_of_change is null, 'p_user_id_of_change');
  util_pkg.XCheck_Cond_Missing(p_network_address_id is null, 'p_network_address_id');
  ------------------------------
  util_ri.xcheck_user_id(p_user_id_of_change);
  ------------------------------
  if not util_ext_ri.del_na_status3
  (
    p_na_id => p_network_address_id,
    p_date => v_date,
    p_user_id => p_user_id_of_change,
    p_lock_pn => true,
    p_silent_prev_lack => FALSE,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  )
  then
    ------------------------------
    util_pkg.raise_exception(v_error_code, v_error_message);
    ------------------------------
  end if;
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure delete_last_open_previous_int
(
  p_msisdn ct_varchar_s,
  p_user_id number
)
is
  v_date date := sysdate;
  v_na_id ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  DELETE FROM tt_batch_na_ap;
  ------------------------------
  v_na_id := util_ri.get_na_id(p_msisdn, v_date, false);
  ------------------------------
  util_loc_pkg.touch_boolean(util_ext_ri.del_na_status2
  (
    p_na_id => v_na_id,
    p_date => v_date,
    p_user_id => p_user_id,
    p_break_on_error => false,
    p_lock_pn => true,
    p_silent_prev_lack => FALSE,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  )
  );
  ------------------------------
  if util_pkg.get_count_ct_varchar_s(p_msisdn) > 0
  then
    ------------------------------
    forall i in p_msisdn.first..p_msisdn.last
      insert into tt_batch_na_ap(international_format, network_address_id, result)
      values(p_msisdn(i), v_na_id(i), v_error_code(i))
    ;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------------------------------------------------
--  Get_phone_numbers_info
----------------------------------------------------------------------------
procedure Get_phone_numbers_info
(
  p_Validity_Date     IN DATE,
  p_Phone_Number_List IN common.t_international_format,
  p_raise_error       IN CHAR,
  error_code          OUT NUMBER,
  error_message       OUT VARCHAR2,
  result_list         OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'PHONE_NUMBER_PCK.Get_phone_numbers_info';
  v_sqlcode       number;
  i               NUMBER;
  j               NUMBER;
  obj             t_v2_60_obj := t_v2_60_obj(NULL);
  obj_col         t_v2_60_obj_tab := t_v2_60_obj_tab();
  v_Validity_Date DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- procedure body here
  -- check input parameters

  IF (p_Phone_Number_List.COUNT = 0) OR (p_Phone_Number_List.COUNT = 1 AND p_Phone_Number_List(p_Phone_Number_List.FIRST) IS NULL) THEN
  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  j               := 1;
  v_Validity_Date := nvl(p_Validity_Date, SYSDATE);
  FOR i IN nvl(p_Phone_Number_List.FIRST, 1) .. nvl(p_Phone_Number_List.LAST, 0)
  LOOP
    -- for all members of input associative array
    obj := t_v2_60_obj(p_Phone_Number_List(i)); -- ccreate object
    obj_col.EXTEND; -- grow
    obj_col(j) := obj; -- insert into collection
    j := j + 1;
  END LOOP;

  IF p_Validity_Date IS NULL THEN
    OPEN result_list FOR
    SELECT /*+ ordered use_nl(k, n, pl, pnl, psom, no)
      index_asc(n, PK_NETWORK_OPERATOR)
      index_asc(pl, PK_PHONE_LINK)
      index_asc(pnl, I_PHONENUM_MSISDN_EXT)
      index_asc(psom, I_PSO_PNS)
      index_asc(no, PK_NETWORK_OPERATOR)
      */
        k.phone_number,
        n.network_operator_code,
        k.phone_number_status,
        k.ERROR_CODE,
        k.phone_number_type_code,
        TRIM(k.salability_category_code) as salability_category_code,
        k.sn,
        k.host_id,
        k.user_id_of_change,
        k.date_of_change,
        pl.linked_msisdn Linked_Phone_Number,
        no.network_operator_code LinkedNetworkOperatorCode
    FROM
    (
      SELECT /*+ ordered use_nl(t_obj, pn, pns, po, pso, naap, sc)
        full(t_obj)
        index_asc(pn, UK_PHONE_NUM_PHONE_NUMBER)
        index_asc(pns, I_PHONUMSE_PNSID_EXT)
        index_asc(po, I_PHONE_OPERATOR_NAID)
        index_asc(pso, I_PSO_PNS)
        index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID2)
        index_asc(sc, PK_SIM_CARD)
        */
          t_obj.v2_60 PHONE_NUMBER,
          nvl(po.NETWORK_OPERATOR_ID, pso.NETWORK_OPERATOR_ID) NETWORK_OPERATOR_ID,
          pn.NET_ADDRESS_STATUS_CODE PHONE_NUMBER_STATUS,
          decode(nvl(pn.NETWORK_ADDRESS_ID, -1), -1, RSIG_UTILS.c_ROW_NOT_FOUND, RSIG_UTILS.c_OK) ERROR_CODE,
          pns.phone_number_type_code,
          pn.salability_category_code,
          nvl(pn.date_of_status_change, pn.date_of_change) as date_of_change,
          pn.user_id_of_change,
          sc.sn,
          pns.host_id
      FROM TABLE(CAST(obj_col AS t_v2_60_obj_tab)) t_obj
        LEFT JOIN PHONE_NUMBER pn ON pn.INTERNATIONAL_FORMAT = t_obj.v2_60
             AND (pn.deleted IS NULL OR pn.deleted > v_Validity_Date)
             --!_!AND nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date --!_!nvl(pn.date_of_status_change, pn.date_of_change) not in index I_PHONENUM_MSISDN_EXT
        LEFT JOIN PHONE_NUMBER_SERIES pns ON pns.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND nvl(pns.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
        LEFT JOIN PHONE_OPERATOR po ON po.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN po.start_date AND po.end_date
             AND po.date_to_act >= v_Validity_Date
             AND po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
        LEFT JOIN PHONE_SERIES_OPERATOR pso ON pso.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND v_Validity_Date BETWEEN pso.START_DATE AND nvl(pso.END_DATE, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN network_address_access_point naap ON naap.network_address_id = pn.network_address_id
             AND v_Validity_Date BETWEEN naap.From_Date AND nvl(naap.To_Date, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN sim_card sc ON sc.access_point_id = naap.access_point_id
             AND (sc.deleted IS NULL OR sc.deleted > v_Validity_Date) --!_!sc.sn not in index I_SIMCARD_AP_EXT
    ) k
      LEFT JOIN network_operator n ON n.network_operator_id = k.NETWORK_OPERATOR_ID
      LEFT JOIN phone_link pl ON pl.main_msisdn = k.PHONE_NUMBER
      LEFT JOIN phone_number pnl ON pnl.international_format = pl.linked_msisdn
      LEFT JOIN phone_series_operator psom ON psom.phone_number_series_id = pnl.phone_number_series_id
           AND v_Validity_Date BETWEEN psom.start_date AND nvl(psom.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
      LEFT JOIN network_operator no ON no.network_operator_id = psom.network_operator_id
           AND (no.deleted IS NULL OR no.deleted > v_Validity_Date)
    WHERE 1 = 1
      AND (no.network_operator_type is not null or pl.linked_msisdn is null)
    ;
  ELSE
    OPEN result_list FOR
    SELECT /*+ ordered use_nl(k, n, pl, pnl, psom, no)
      index_asc(n, PK_NETWORK_OPERATOR)
      index_asc(pl, PK_PHONE_LINK)
      index_asc(pnl, I_PHONENUM_MSISDN_EXT)
      index_asc(psom, I_PSO_PNS)
      index_asc(no, PK_NETWORK_OPERATOR)
      */
        k.phone_number,
        n.network_operator_code,
        k.phone_number_status,
        k.ERROR_CODE,
        k.phone_number_type_code,
        TRIM(k.salability_category_code) as salability_category_code,
        k.sn,
        k.host_id,
        k.user_id_of_change,
        k.date_of_change,
        pl.linked_msisdn Linked_Phone_Number,
        no.network_operator_code LinkedNetworkOperatorCode
    FROM
    (
      SELECT /*+ ordered use_nl(t_obj, pn, nash, pns, po, pso, pnsc, naap, sc)
        full(t_obj)
        index_asc(pn, UK_PHONE_NUM_PHONE_NUMBER)
        index_asc(nash, I_NETADSTAHI_NETWORK_ADDRES_I2)
        index_asc(pns, I_PHONUMSE_PNSID_EXT)
        index_asc(po, I_PHONE_OPERATOR_NAID)
        index_asc(pso, I_PSO_PNS)
        index_asc(pnsc, I_PHONUSALCA_NET_ADDRESS_ID2)
        index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID2)
        index_asc(sc, PK_SIM_CARD)
        */
          t_obj.v2_60 PHONE_NUMBER,
          nvl(po.NETWORK_OPERATOR_ID, pso.NETWORK_OPERATOR_ID) NETWORK_OPERATOR_ID,
          nash.NET_ADDRESS_STATUS_CODE PHONE_NUMBER_STATUS,
          decode(nvl(pn.NETWORK_ADDRESS_ID, -1), -1, RSIG_UTILS.c_ROW_NOT_FOUND, RSIG_UTILS.c_OK) ERROR_CODE,
          pns.phone_number_type_code,
          pnsc.salability_category_code,
          nvl(nash.start_date, nvl(pn.date_of_status_change, pn.date_of_change)) as date_of_change,
          nvl(nash.user_id_of_change, pn.user_id_of_change) as user_id_of_change,
          sc.sn,
          pns.host_id
      FROM TABLE(CAST(obj_col AS t_v2_60_obj_tab)) t_obj
        LEFT JOIN PHONE_NUMBER pn ON pn.INTERNATIONAL_FORMAT = t_obj.v2_60
             AND (pn.deleted IS NULL OR pn.deleted > v_Validity_Date)
             --!_!AND nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date --!_!nvl(pn.date_of_status_change, pn.date_of_change) not in index I_PHONENUM_MSISDN_EXT
        LEFT JOIN NETWORK_ADDRESS_STATUS_HISTORY nash ON nash.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN nash.START_DATE AND nvl(nash.END_DATE, to_date('01.01.4000', 'dd.mm.yyyy')) --!_!nvl(nash.user_id_of_change, pn.user_id_of_change) not in index I_NETADSTAHI_NETWORK_ADDRES_I2
        LEFT JOIN PHONE_NUMBER_SERIES pns ON pns.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND nvl(pns.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
        LEFT JOIN PHONE_OPERATOR po ON po.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN po.start_date AND po.end_date
             AND po.date_to_act >= v_Validity_Date
             AND po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
        LEFT JOIN PHONE_SERIES_OPERATOR pso ON pso.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND v_Validity_Date BETWEEN pso.START_DATE AND nvl(pso.END_DATE, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN PHONE_NUMBER_SALABILITY_CATEG pnsc ON pn.NETWORK_ADDRESS_ID = pnsc.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN pnsc.start_date AND nvl(pnsc.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN network_address_access_point naap ON naap.network_address_id = pn.network_address_id
             AND v_Validity_Date BETWEEN naap.From_Date AND nvl(naap.To_Date, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN sim_card sc ON sc.access_point_id = naap.access_point_id
             AND (sc.deleted IS NULL OR sc.deleted > v_Validity_Date) --!_!sc.sn not in index I_SIMCARD_AP_EXT
    ) k
      LEFT JOIN network_operator n ON n.network_operator_id = k.NETWORK_OPERATOR_ID
      LEFT JOIN phone_link pl ON pl.main_msisdn = k.PHONE_NUMBER
      LEFT JOIN phone_number pnl ON pnl.international_format = pl.linked_msisdn
      LEFT JOIN phone_series_operator psom ON psom.phone_number_series_id = pnl.phone_number_series_id
           AND v_Validity_Date BETWEEN psom.start_date AND nvl(psom.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
      LEFT JOIN network_operator no ON no.network_operator_id = psom.network_operator_id
           AND (no.deleted IS NULL OR no.deleted > v_Validity_Date)
    WHERE 1 = 1
      AND (no.network_operator_type is not null or pl.linked_msisdn is null)
    ;
  END IF;
  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);

    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
    OPEN result_list FOR
      SELECT error_code FROM dual;
END Get_phone_numbers_info;

----------------------------------------------------------------------------
--  Get_linked_phone_numbers_info
----------------------------------------------------------------------------
procedure Get_linked_phone_numbers_info
(
  p_Validity_Date     IN DATE,
  p_Phone_Number_List IN common.t_international_format,
  p_raise_error       IN CHAR,
  error_code          OUT NUMBER,
  error_message       OUT VARCHAR2,
  result_list         OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'PHONE_NUMBER_PCK.Get_linked_phone_numbers_info';
  v_sqlcode       number;
  i               NUMBER;
  j               NUMBER;
  obj             t_v2_60_obj := t_v2_60_obj(NULL);
  obj_col         t_v2_60_obj_tab := t_v2_60_obj_tab();
  v_Validity_Date DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- procedure body here
  -- check input parameters
  IF (p_Phone_Number_List.COUNT = 0) OR (p_Phone_Number_List.COUNT = 1 AND p_Phone_Number_List(p_Phone_Number_List.FIRST) IS NULL) THEN
  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  j               := 1;
  v_Validity_Date := nvl(p_Validity_Date, SYSDATE);
  FOR i IN nvl(p_Phone_Number_List.FIRST, 1) .. nvl(p_Phone_Number_List.LAST, 0)
  LOOP
    -- for all members of input associative array
    obj := t_v2_60_obj(p_Phone_Number_List(i)); -- ccreate object
    obj_col.EXTEND; -- grow
    obj_col(j) := obj; -- insert into collection
    j := j + 1;
  END LOOP;

  IF p_Validity_Date IS NULL THEN
    --!_!use_nl(pol) index_asc(pol, I_PHONE_OPERATOR_NAID)
    OPEN result_list FOR
    SELECT /*+ ordered use_nl(n, pl, pnl, pnsl, psol, nl)
      index_asc(n, PK_NETWORK_OPERATOR)
      index_asc(pl, PK_PHONE_LINK)
      index_asc(pnl, I_PHONENUM_MSISDN_EXT)
      index_asc(pnsl, I_PHONUMSE_PNSID_EXT)
      index_asc(psol, I_PSO_PNS)
      index_asc(nl, PK_NETWORK_OPERATOR)
      */
        k.phone_number,
        pl.linked_msisdn,
        n.network_operator_code,
        TRIM(k.phone_number_status) as phone_number_status,
        k.ERROR_CODE,
        TRIM(k.phone_number_type_code) as phone_number_type_code,
        TRIM(k.salability_category_code) as salability_category_code,
        k.sn,
        k.host_id,
        nl.network_operator_code linked_network_operator_code,
        k.user_id_of_change,
        k.date_of_change
    FROM
    (
      SELECT /*+ ordered use_nl(t_obj, pn, pns, po, pso, naap, sc)
        full(t_obj)
        index_asc(pn, UK_PHONE_NUM_PHONE_NUMBER)
        index_asc(pns, I_PHONUMSE_PNSID_EXT)
        index_asc(po, I_PHONE_OPERATOR_NAID)
        index_asc(pso, I_PSO_PNS)
        index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID2)
        index_asc(sc, PK_SIM_CARD)
        */
          t_obj.v2_60 PHONE_NUMBER,
          nvl(po.NETWORK_OPERATOR_ID, pso.NETWORK_OPERATOR_ID) NETWORK_OPERATOR_ID,
          pn.NET_ADDRESS_STATUS_CODE PHONE_NUMBER_STATUS,
          decode(nvl(pn.NETWORK_ADDRESS_ID, -1), -1, RSIG_UTILS.c_ROW_NOT_FOUND, RSIG_UTILS.c_OK) ERROR_CODE,
          pns.phone_number_type_code,
          pn.salability_category_code,
          nvl(pn.date_of_status_change, pn.date_of_change) as date_of_change,
          pn.user_id_of_change,
          sc.sn,
          pns.host_id
      FROM TABLE(CAST(obj_col AS t_v2_60_obj_tab)) t_obj
        LEFT JOIN PHONE_NUMBER pn ON pn.INTERNATIONAL_FORMAT = t_obj.v2_60
             AND (pn.deleted IS NULL OR pn.deleted > v_Validity_Date)
             --!_!AND nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date --!_!nvl(pn.date_of_status_change, pn.date_of_change) not in index I_PHONENUM_MSISDN_EXT
        LEFT JOIN PHONE_NUMBER_SERIES pns ON pns.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND nvl(pns.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
        LEFT JOIN PHONE_OPERATOR po ON po.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN po.start_date AND po.end_date
             AND po.date_to_act >= v_Validity_Date
             AND po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
        LEFT JOIN PHONE_SERIES_OPERATOR pso ON pso.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND v_Validity_Date BETWEEN pso.START_DATE AND nvl(pso.END_DATE, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN network_address_access_point naap ON naap.network_address_id = pn.network_address_id
             AND v_Validity_Date BETWEEN naap.From_Date AND nvl(naap.To_Date, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN sim_card sc ON sc.access_point_id = naap.access_point_id
             AND (sc.deleted IS NULL OR sc.deleted > v_Validity_Date) --!_!sc.sn not in index I_SIMCARD_AP_EXT
    ) k
      LEFT JOIN network_operator n ON n.network_operator_id = k.NETWORK_OPERATOR_ID
           AND (n.deleted IS NULL OR n.deleted > v_Validity_Date)
      LEFT JOIN phone_link pl ON pl.main_msisdn = k.phone_number
      LEFT JOIN PHONE_NUMBER pnl ON pnl.INTERNATIONAL_FORMAT = pl.linked_msisdn
           AND nvl(pnl.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
      LEFT JOIN PHONE_NUMBER_SERIES pnsl ON pnsl.PHONE_NUMBER_SERIES_ID = pnl.PHONE_NUMBER_SERIES_ID
           AND nvl(pnsl.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
      --!_!LEFT JOIN PHONE_OPERATOR pol ON pol.NETWORK_ADDRESS_ID = pnl.NETWORK_ADDRESS_ID
      --!_!     AND v_Validity_Date BETWEEN pol.start_date AND pol.end_date
      --!_!     AND pol.date_to_act >= v_Validity_Date
      --!_!     AND pol.type in (vp_phone_operator.c_potype_3rdsideother2own)
      LEFT JOIN PHONE_SERIES_OPERATOR psol ON psol.PHONE_NUMBER_SERIES_ID = pnl.PHONE_NUMBER_SERIES_ID
           AND v_Validity_Date BETWEEN psol.start_date AND nvl(psol.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
      LEFT JOIN NETWORK_OPERATOR nl ON nl.NETWORK_OPERATOR_ID = psol.NETWORK_OPERATOR_ID --!_!nvl(pol.NETWORK_OPERATOR_ID, psol.NETWORK_OPERATOR_ID)
           AND (nl.deleted IS NULL OR nl.deleted > v_Validity_Date)
    WHERE 1 = 1
      --!_!AND (nl.NETWORK_OPERATOR_TYPE is not null or nvl(pol.NETWORK_OPERATOR_ID, psol.NETWORK_OPERATOR_ID) is null)
      AND (nl.NETWORK_OPERATOR_TYPE is not null or psol.NETWORK_OPERATOR_ID is null)
    ;
  ELSE
    --!_!use_nl(pol) index_asc(pol, I_PHONE_OPERATOR_NAID)
    OPEN result_list FOR
    SELECT /*+ ordered use_nl(n, pl, pnl, pnsl, psol, nl)
      index_asc(n, PK_NETWORK_OPERATOR)
      index_asc(pl, PK_PHONE_LINK)
      index_asc(pnl, I_PHONENUM_MSISDN_EXT)
      index_asc(pnsl, I_PHONUMSE_PNSID_EXT)
      index_asc(psol, I_PSO_PNS)
      index_asc(nl, PK_NETWORK_OPERATOR)
      */
        k.phone_number,
        pl.linked_msisdn,
        n.network_operator_code,
        TRIM(k.phone_number_status) as phone_number_status,
        k.ERROR_CODE,
        TRIM(k.phone_number_type_code) as phone_number_type_code,
        TRIM(k.salability_category_code) as salability_category_code,
        k.sn,
        k.host_id,
        nl.network_operator_code linked_network_operator_code,
        k.user_id_of_change,
        k.date_of_change
    FROM
    (
      SELECT /*+ ordered use_nl(t_obj, pn, nash, pns, po, pso, pnsc, naap, sc)
        full(t_obj)
        index_asc(pn, UK_PHONE_NUM_PHONE_NUMBER)
        index_asc(nash, I_NETADSTAHI_NETWORK_ADDRES_I2)
        index_asc(pns, I_PHONUMSE_PNSID_EXT)
        index_asc(po, I_PHONE_OPERATOR_NAID)
        index_asc(pso, I_PSO_PNS)
        index_asc(pnsc, I_PHONUSALCA_NET_ADDRESS_ID2)
        index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID2)
        index_asc(sc, PK_SIM_CARD)
        */
          t_obj.v2_60 PHONE_NUMBER,
          nvl(po.NETWORK_OPERATOR_ID, pso.NETWORK_OPERATOR_ID) NETWORK_OPERATOR_ID,
          nash.NET_ADDRESS_STATUS_CODE PHONE_NUMBER_STATUS,
          decode(nvl(pn.NETWORK_ADDRESS_ID, -1), -1, RSIG_UTILS.c_ROW_NOT_FOUND, RSIG_UTILS.c_OK) ERROR_CODE,
          pns.phone_number_type_code,
          pnsc.salability_category_code,
          nvl(nash.start_date, nvl(pn.date_of_status_change, pn.date_of_change)) as date_of_change,
          nvl(nash.user_id_of_change, pn.user_id_of_change) as user_id_of_change,
          sc.sn,
          pns.host_id
      FROM TABLE(CAST(obj_col AS t_v2_60_obj_tab)) t_obj
        LEFT JOIN PHONE_NUMBER pn ON pn.INTERNATIONAL_FORMAT = t_obj.v2_60
             AND (pn.deleted IS NULL OR pn.deleted > v_Validity_Date)
             --!_!AND nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date --!_!nvl(pn.date_of_status_change, pn.date_of_change) not in index I_PHONENUM_MSISDN_EXT
        LEFT JOIN NETWORK_ADDRESS_STATUS_HISTORY nash ON nash.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN nash.START_DATE AND nvl(nash.END_DATE, to_date('01.01.4000', 'dd.mm.yyyy')) --!_!nvl(nash.user_id_of_change, pn.user_id_of_change) not in index I_NETADSTAHI_NETWORK_ADDRES_I2
        LEFT JOIN PHONE_NUMBER_SERIES pns ON pns.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND nvl(pns.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
        LEFT JOIN PHONE_OPERATOR po ON po.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN po.start_date AND po.end_date
             AND po.date_to_act >= v_Validity_Date
             AND po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
        LEFT JOIN PHONE_SERIES_OPERATOR pso ON pso.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND v_Validity_Date BETWEEN pso.START_DATE AND nvl(pso.END_DATE, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN PHONE_NUMBER_SALABILITY_CATEG pnsc ON pn.NETWORK_ADDRESS_ID = pnsc.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN pnsc.start_date AND nvl(pnsc.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN network_address_access_point naap ON naap.network_address_id = pn.network_address_id
             AND v_Validity_Date BETWEEN naap.From_Date AND nvl(naap.To_Date, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN sim_card sc ON sc.access_point_id = naap.access_point_id
             AND (sc.deleted IS NULL OR sc.deleted > v_Validity_Date) --!_!sc.sn not in index I_SIMCARD_AP_EXT
    ) k
      LEFT JOIN network_operator n ON n.network_operator_id = k.NETWORK_OPERATOR_ID
           AND (n.deleted IS NULL OR n.deleted > v_Validity_Date)
      LEFT JOIN phone_link pl ON pl.main_msisdn = k.phone_number
      LEFT JOIN PHONE_NUMBER pnl ON pnl.INTERNATIONAL_FORMAT = pl.linked_msisdn
           AND nvl(pnl.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
      LEFT JOIN PHONE_NUMBER_SERIES pnsl ON pnsl.PHONE_NUMBER_SERIES_ID = pnl.PHONE_NUMBER_SERIES_ID
           AND nvl(pnsl.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
      --!_!LEFT JOIN PHONE_OPERATOR pol ON pol.NETWORK_ADDRESS_ID = pnl.NETWORK_ADDRESS_ID
      --!_!     AND v_Validity_Date BETWEEN pol.start_date AND pol.end_date
      --!_!     AND pol.date_to_act >= v_Validity_Date
      --!_!     AND pol.type in (vp_phone_operator.c_potype_3rdsideother2own)
      LEFT JOIN PHONE_SERIES_OPERATOR psol ON psol.PHONE_NUMBER_SERIES_ID = pnl.PHONE_NUMBER_SERIES_ID
           AND v_Validity_Date BETWEEN psol.start_date AND nvl(psol.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
      LEFT JOIN NETWORK_OPERATOR nl ON nl.NETWORK_OPERATOR_ID = psol.NETWORK_OPERATOR_ID --!_!nvl(pol.NETWORK_OPERATOR_ID, psol.NETWORK_OPERATOR_ID)
           AND (nl.deleted IS NULL OR nl.deleted > v_Validity_Date)
    WHERE 1 = 1
      --!_!AND (nl.NETWORK_OPERATOR_TYPE is not null or nvl(pol.NETWORK_OPERATOR_ID, psol.NETWORK_OPERATOR_ID) is null)
      AND (nl.NETWORK_OPERATOR_TYPE is not null or psol.NETWORK_OPERATOR_ID is null)
    ;
  END IF;
  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);

    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
    OPEN result_list FOR
      SELECT error_code FROM dual;
END Get_linked_phone_numbers_info;

----------------------------------------------------------------------------
--  Get_phone_numbers_info3
----------------------------------------------------------------------------
procedure Get_phone_numbers_info3
(
  p_Validity_Date     IN DATE,
  p_Phone_Number_List IN common.t_international_format,
  p_raise_error       IN CHAR,
  error_code          OUT NUMBER,
  error_message       OUT VARCHAR2,
  result_list         OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'PHONE_NUMBER_PCK.Get_phone_numbers_info3';
  v_sqlcode       number;
  i               NUMBER;
  v_Validity_Date DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- procedure body here
  -- check input parameters

  IF (p_Phone_Number_List.COUNT = 0) OR (p_Phone_Number_List.COUNT = 1 AND p_Phone_Number_List(p_Phone_Number_List.FIRST) IS NULL) THEN
  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  DELETE FROM tt_phone_link;
  v_Validity_Date := nvl(p_Validity_Date, SYSDATE);

  forall i in nvl(p_Phone_Number_List.first, 1)..nvl(p_Phone_Number_List.last,0)
    insert into tt_phone_link(main_msisdn)
      values(p_Phone_Number_List(i));

   IF p_Validity_Date IS NULL THEN
    --!_!use_nl(pol) index_asc(pol, I_PHONE_OPERATOR_NAID)
    OPEN result_list FOR
    SELECT /*+ ordered use_nl(k, n, pl, pnl, pnsl, psol, nl, h, n2)
      index_asc(n, PK_NETWORK_OPERATOR)
      index_asc(pl, PK_PHONE_LINK)
      index_asc(pnl, I_PHONENUM_MSISDN_EXT)
      index_asc(pnsl, I_PHONUMSE_PNSID_EXT)
      index_asc(psol, I_PSO_PNS)
      index_asc(nl, PK_NETWORK_OPERATOR)
      index_asc(h, PK_HOST)
      index_asc(n2, PK_NETWORK_OPERATOR)
      */
        k.phone_number,
        n.network_operator_code OwnerNetworkOperatorCode,
        nvl(n2.network_operator_code, n.network_operator_code) CurrentNetworkOperatorCode,
        h.host_code CurrentHLRCode,
        h.host_id CurrentHLRId,
        TRIM(k.phone_number_status) as phone_number_status,
        k.ERROR_CODE,
        TRIM(k.phone_number_type_code) as phone_number_type_code,
        TRIM(k.salability_category_code) as salability_category_code,
        k.sn,
        k.user_id_of_change,
        k.date_of_change,
        pl.linked_msisdn,
        nl.network_operator_code linked_network_operator_code
    FROM
    (
      SELECT /*+ ordered use_nl(t, pn, pns, po, pso, naap, sc, ss)
        full(t)
        index_asc(pn, UK_PHONE_NUM_PHONE_NUMBER)
        index_asc(pns, I_PHONUMSE_PNSID_EXT)
        index_asc(po, I_PHONE_OPERATOR_NAID)
        index_asc(pso, I_PSO_PNS)
        index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID2)
        index_asc(sc, PK_SIM_CARD)
        index_asc(ss, I_SIMSERIES_SSID_EXT)
        */
          t.main_msisdn PHONE_NUMBER,
          nvl(po.NETWORK_OPERATOR_ID, pso.NETWORK_OPERATOR_ID) NETWORK_OPERATOR_ID,
          pn.NET_ADDRESS_STATUS_CODE PHONE_NUMBER_STATUS,
          decode(nvl(pn.NETWORK_ADDRESS_ID, -1), -1, RSIG_UTILS.c_ROW_NOT_FOUND, RSIG_UTILS.c_OK) ERROR_CODE,
          pns.phone_number_type_code,
          pn.salability_category_code,
          nvl(pn.date_of_status_change, pn.date_of_change) as date_of_change,
          pn.user_id_of_change,
          sc.sn,
          pns.host_id,
          ss.host_id sim_host_id
      FROM tt_phone_link t
        LEFT JOIN PHONE_NUMBER pn ON pn.INTERNATIONAL_FORMAT = t.main_msisdn
             AND (pn.deleted IS NULL OR pn.deleted > v_Validity_Date)
             --!_!AND nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date --!_!nvl(pn.date_of_status_change, pn.date_of_change) not in index I_PHONENUM_MSISDN_EXT
        LEFT JOIN PHONE_NUMBER_SERIES pns ON pns.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND nvl(pns.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
        LEFT JOIN PHONE_OPERATOR po ON po.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN po.start_date AND po.end_date
             AND po.date_to_act >= v_Validity_Date
             AND po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
        LEFT JOIN PHONE_SERIES_OPERATOR pso ON pso.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND v_Validity_Date BETWEEN pso.START_DATE AND nvl(pso.END_DATE, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN network_address_access_point naap ON naap.network_address_id = pn.network_address_id
             AND v_Validity_Date BETWEEN naap.From_Date AND nvl(naap.To_Date, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN sim_card sc ON sc.access_point_id = naap.access_point_id
             AND (sc.deleted IS NULL OR sc.deleted > v_Validity_Date) --!_!sc.sn not in index I_SIMCARD_AP_EXT
        LEFT JOIN sim_series ss ON ss.sim_series_id = sc.sim_series_id
             AND nvl(ss.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
    ) k
      LEFT JOIN network_operator n ON n.network_operator_id = k.NETWORK_OPERATOR_ID
           AND (n.deleted IS NULL OR n.deleted > v_Validity_Date)
      LEFT JOIN phone_link pl ON pl.main_msisdn = k.phone_number
      LEFT JOIN PHONE_NUMBER pnl ON pnl.INTERNATIONAL_FORMAT = pl.linked_msisdn
           AND nvl(pnl.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
      LEFT JOIN PHONE_NUMBER_SERIES pnsl ON pnsl.PHONE_NUMBER_SERIES_ID = pnl.PHONE_NUMBER_SERIES_ID
           AND nvl(pnsl.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
      --!_!LEFT JOIN PHONE_OPERATOR pol ON pol.NETWORK_ADDRESS_ID = pnl.NETWORK_ADDRESS_ID
      --!_!     AND v_Validity_Date BETWEEN pol.start_date AND pol.end_date
      --!_!     AND pol.date_to_act >= v_Validity_Date
      --!_!     AND pol.type in (vp_phone_operator.c_potype_3rdsideother2own)
      LEFT JOIN PHONE_SERIES_OPERATOR psol ON psol.PHONE_NUMBER_SERIES_ID = pnl.PHONE_NUMBER_SERIES_ID
           AND v_Validity_Date BETWEEN psol.start_date AND nvl(psol.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
      LEFT JOIN NETWORK_OPERATOR nl ON nl.NETWORK_OPERATOR_ID = psol.NETWORK_OPERATOR_ID --!_!nvl(pol.NETWORK_OPERATOR_ID, psol.NETWORK_OPERATOR_ID)
           AND (nl.deleted IS NULL OR nl.deleted > v_Validity_Date)
      LEFT JOIN host h on h.host_id = nvl(k.sim_host_id, k.host_id)
           AND (h.deleted IS NULL OR h.deleted > v_Validity_Date)
      LEFT JOIN network_operator n2 on n2.network_operator_id = h.network_operator_id
           AND (n2.deleted IS NULL OR n2.deleted > v_Validity_Date)
    WHERE 1 = 1
      AND (nl.network_operator_type is not null or pl.linked_msisdn is null)
    ;
  ELSE
    --!_!use_nl(pol) index_asc(pol, I_PHONE_OPERATOR_NAID)
    OPEN result_list FOR
    SELECT /*+ ordered use_nl(k, n, pl, pnl, pnsl, psol, nl, h, n2)
      index_asc(n, PK_NETWORK_OPERATOR)
      index_asc(pl, PK_PHONE_LINK)
      index_asc(pnl, I_PHONENUM_MSISDN_EXT)
      index_asc(pnsl, I_PHONUMSE_PNSID_EXT)
      index_asc(psol, I_PSO_PNS)
      index_asc(nl, PK_NETWORK_OPERATOR)
      index_asc(h, PK_HOST)
      index_asc(n2, PK_NETWORK_OPERATOR)
      */
        k.phone_number,
        n.network_operator_code OwnerNetworkOperatorCode,
        nvl(n2.network_operator_code, n.network_operator_code) CurrentNetworkOperatorCode,
        h.host_code CurrentHLRCode,
        h.host_id CurrentHLRId,
        TRIM(k.phone_number_status) as phone_number_status,
        k.ERROR_CODE,
        TRIM(k.phone_number_type_code) as phone_number_type_code,
        TRIM(k.salability_category_code) as salability_category_code,
        k.sn,
        k.user_id_of_change,
        k.date_of_change,
        pl.linked_msisdn,
        nl.network_operator_code linked_network_operator_code
    FROM
    (
      SELECT /*+ ordered use_nl(t, pn, nash, pns, po, pso, pnsc, naap, sc, ss)
        full(t)
        index_asc(pn, UK_PHONE_NUM_PHONE_NUMBER)
        index_asc(nash, I_NETADSTAHI_NETWORK_ADDRES_I2)
        index_asc(pns, I_PHONUMSE_PNSID_EXT)
        index_asc(po, I_PHONE_OPERATOR_NAID)
        index_asc(pso, I_PSO_PNS)
        index_asc(pnsc, I_PHONUSALCA_NET_ADDRESS_ID2)
        index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID2)
        index_asc(sc, PK_SIM_CARD)
        index_asc(ss, I_SIMSERIES_SSID_EXT)
        */
          t.main_msisdn PHONE_NUMBER,
          nvl(po.NETWORK_OPERATOR_ID, pso.NETWORK_OPERATOR_ID) NETWORK_OPERATOR_ID,
          nash.NET_ADDRESS_STATUS_CODE PHONE_NUMBER_STATUS,
          decode(nvl(pn.NETWORK_ADDRESS_ID, -1), -1, RSIG_UTILS.c_ROW_NOT_FOUND, RSIG_UTILS.c_OK) ERROR_CODE,
          pns.phone_number_type_code,
          pnsc.salability_category_code,
          nvl(nash.start_date, nvl(pn.date_of_status_change, pn.date_of_change)) as date_of_change,
          nvl(nash.user_id_of_change, pn.user_id_of_change) as user_id_of_change,
          sc.sn,
          pns.host_id,
          ss.host_id sim_host_id
      FROM tt_phone_link t
        LEFT JOIN PHONE_NUMBER pn ON pn.INTERNATIONAL_FORMAT = t.main_msisdn
             AND (pn.deleted IS NULL OR pn.deleted > v_Validity_Date)
             --!_!AND nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date --!_!nvl(pn.date_of_status_change, pn.date_of_change) not in index I_PHONENUM_MSISDN_EXT
        LEFT JOIN NETWORK_ADDRESS_STATUS_HISTORY nash ON nash.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN nash.START_DATE AND nvl(nash.END_DATE, to_date('01.01.4000', 'dd.mm.yyyy')) --!_!nvl(nash.user_id_of_change, pn.user_id_of_change) not in index I_NETADSTAHI_NETWORK_ADDRES_I2
        LEFT JOIN PHONE_NUMBER_SERIES pns ON pns.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND nvl(pns.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
        LEFT JOIN PHONE_OPERATOR po ON po.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN po.start_date AND po.end_date
             AND po.date_to_act >= v_Validity_Date
             AND po.type in (vp_phone_operator.c_potype_other2own, vp_phone_operator.c_potype_own2own)
        LEFT JOIN PHONE_SERIES_OPERATOR pso ON pso.PHONE_NUMBER_SERIES_ID = pn.PHONE_NUMBER_SERIES_ID
             AND v_Validity_Date BETWEEN pso.START_DATE AND nvl(pso.END_DATE, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN PHONE_NUMBER_SALABILITY_CATEG pnsc ON pn.NETWORK_ADDRESS_ID = pnsc.NETWORK_ADDRESS_ID
             AND v_Validity_Date BETWEEN pnsc.start_date AND nvl(pnsc.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN network_address_access_point naap ON naap.network_address_id = pn.network_address_id
             AND v_Validity_Date BETWEEN naap.From_Date AND nvl(naap.To_Date, to_date('01.01.4000', 'dd.mm.yyyy'))
        LEFT JOIN sim_card sc ON sc.access_point_id = naap.access_point_id
             AND (sc.deleted IS NULL OR sc.deleted > v_Validity_Date) --!_!sc.sn not in index I_SIMCARD_AP_EXT
        LEFT JOIN sim_series ss ON ss.sim_series_id = sc.sim_series_id
             AND nvl(ss.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
    ) k
      LEFT JOIN network_operator n ON n.network_operator_id = k.NETWORK_OPERATOR_ID
           AND (n.deleted IS NULL OR n.deleted > v_Validity_Date)
      LEFT JOIN phone_link pl ON pl.main_msisdn = k.phone_number
      LEFT JOIN PHONE_NUMBER pnl ON pnl.INTERNATIONAL_FORMAT = pl.linked_msisdn
           AND nvl(pnl.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
      LEFT JOIN PHONE_NUMBER_SERIES pnsl ON pnsl.PHONE_NUMBER_SERIES_ID = pnl.PHONE_NUMBER_SERIES_ID
           AND nvl(pnsl.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > v_Validity_Date
      --!_!LEFT JOIN PHONE_OPERATOR pol ON pol.NETWORK_ADDRESS_ID = pnl.NETWORK_ADDRESS_ID
      --!_!     AND v_Validity_Date BETWEEN pol.start_date AND pol.end_date
      --!_!     AND pol.date_to_act >= v_Validity_Date
      --!_!     AND pol.type in (vp_phone_operator.c_potype_3rdsideother2own)
      LEFT JOIN PHONE_SERIES_OPERATOR psol ON psol.PHONE_NUMBER_SERIES_ID = pnl.PHONE_NUMBER_SERIES_ID
           AND v_Validity_Date BETWEEN psol.start_date AND nvl(psol.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
      LEFT JOIN NETWORK_OPERATOR nl ON nl.NETWORK_OPERATOR_ID = psol.NETWORK_OPERATOR_ID --!_!nvl(pol.NETWORK_OPERATOR_ID, psol.NETWORK_OPERATOR_ID)
           AND (nl.deleted IS NULL OR nl.deleted > v_Validity_Date)
      LEFT JOIN host h on h.host_id = nvl(k.sim_host_id, k.host_id)
           AND (h.deleted IS NULL OR h.deleted > v_Validity_Date)
      LEFT JOIN network_operator n2 on n2.network_operator_id = h.network_operator_id
           AND (n2.deleted IS NULL OR n2.deleted > v_Validity_Date)
    WHERE 1 = 1
      AND (nl.network_operator_type is not null or pl.linked_msisdn is null)
    ;
  END IF;
  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);

    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
    OPEN result_list FOR
      SELECT error_code FROM dual;
END;

END;
/
