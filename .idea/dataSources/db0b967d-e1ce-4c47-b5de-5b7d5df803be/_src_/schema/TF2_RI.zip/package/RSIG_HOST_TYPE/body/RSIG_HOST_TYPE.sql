CREATE PACKAGE BODY          "RSIG_HOST_TYPE" IS

---------------------------------------------
--     PROCEDURE Get_Host_Type
---------------------------------------------

PROCEDURE Get_Host_Type
(
  error_code      OUT NUMBER,
  p_cur_host_type OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_HOST_TYPE.Get_Host_Type';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_host_type FOR
    select HOST_TYPE_CODE,
           HOST_TYPE_NAME,
           DELETED, 
           IS_EXCHANGE
      from HOST_TYPE h
     WHERE (h.deleted IS NULL OR h.deleted > SYSDATE)
     ORDER BY h.host_type_name;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_Host_Type;

END RSIG_HOST_TYPE;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_HOST_TYPE.pkb,v 1.17 2003/12/22 11:21:28 rhejduk Exp $
/
