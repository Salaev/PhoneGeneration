CREATE PACKAGE SCP_RI is

  -- Author  : TARAS.MOTREVICH
  -- Created : 23.02.2006 18:04:13
  -- Purpose : Requests to Resource Inventory implementation

  PROCEDURE Get_Hosts(ERROR_CODE OUT NUMBER, result_list OUT sys_refcursor);

  PROCEDURE Get_SimSeries(ERROR_CODE  OUT NUMBER,
                          result_list OUT sys_refcursor);

  PROCEDURE Get_net_op_Neighbours(ERROR_CODE  OUT NUMBER,
                                  result_list OUT sys_refcursor);

  PROCEDURE Get_ZoneBaseStations(ERROR_CODE OUT NUMBER,
                                 p_result   OUT SYS_REFCURSOR);

  PROCEDURE Get_Prefixes(ERROR_CODE OUT NUMBER, p_result OUT SYS_REFCURSOR);

  PROCEDURE Get_NetworkKind(ERROR_CODE OUT NUMBER,
                            p_result   OUT SYS_REFCURSOR);

  PROCEDURE Get_Prefixes_MCCMNC(ERROR_CODE OUT NUMBER,
                                p_result   OUT SYS_REFCURSOR);

  PROCEDURE Get_Hosts_MCCMNC(ERROR_CODE  OUT NUMBER,
                             result_list OUT sys_refcursor);

  PROCEDURE Get_ZoneBaseStations_MCCMNC(ERROR_CODE OUT NUMBER,
                                        p_result   OUT SYS_REFCURSOR);

  PROCEDURE Get_NetworkKind_MCCMNC(ERROR_CODE OUT NUMBER,
                                   p_result   OUT SYS_REFCURSOR);

  PROCEDURE get_operator_type(in_msisdn         IN VARCHAR2,
                              out_result_code   OUT NUMBER,
                              out_operator_type OUT VARCHAR2);

  PROCEDURE GET_VERSION
  ( --out_result_code      OUT NUMBER
    out_scp_ri_version        OUT VARCHAR2
  , out_foris_ri_version      OUT VARCHAR2
  , out_last_synch            OUT DATE
  , out_synch_status          OUT VARCHAR2
  , out_scp_ri_version_last   OUT VARCHAR2
  , out_foris_ri_version_last OUT VARCHAR2
  , out_last_synch_last       OUT DATE
  , out_synch_status_last     OUT VARCHAR2
  ) DETERMINISTIC;

  PROCEDURE GET_SERVICES
  ( ERROR_CODE OUT NUMBER
  , p_result   OUT SYS_REFCURSOR
  );

  PROCEDURE GET_DEF_ABC_RULE
  ( ERROR_CODE      OUT NUMBER
  , OUT_RESULT_LIST OUT SYS_REFCURSOR
  );

--  PROCEDURE get_replication_state(out_cursor OUT SYS_REFCURSOR);

end SCP_RI;
/
