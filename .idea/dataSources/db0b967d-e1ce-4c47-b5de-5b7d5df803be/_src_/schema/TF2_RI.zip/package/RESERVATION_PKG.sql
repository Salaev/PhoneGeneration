CREATE package RESERVATION_PKG is

----------------------------------!---------------------------------------------
  type t_phones_sims_container is record
  (
    rec_ids ct_number,
    iccids ct_varchar_s,
    imsis ct_varchar_s,
    msisdn ct_varchar_s,
    network_operator_codes ct_varchar_s
  );
  
  type t_check_setting is record
  (
    check_sim_card_not_active boolean,
    check_phone_free_or_int boolean,
    check_sim_phone_host boolean,
    check_sim_host_belong_no boolean,
    check_phone_sim_link boolean
  );

----------------------------------!---------------------------------------------
  function reserve_na_on_period_i
  (
    p_na_id ct_number,
    p_date_reserved date,
    p_user_id number,
    p_reserve_number out number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function reserve_msisdns_on_period_i
  (
    p_msisdns ct_varchar_s,
    p_date_reserved date,
    p_user_id number,
    p_reserve_number out number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

----------------------------------!---------------------------------------------
  procedure set_reserved_msisdn_on_period
  (
    p_msisdns util_pkg.cit_varchar_s,
    p_date_reserved date,
    p_user_login varchar2,
    p_commit number,
    p_reserve_number out number,
    p_result_list out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure change_reserve_period
  (
    p_reserve_number_list util_pkg.cit_number,
    p_date_reserved date,
    p_user_login varchar2,
    p_commit number,
    p_result_list out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure check_reserves
  (
    p_reserve_number_list util_pkg.cit_number,
    p_result_list out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure check_sim_card_and_phone
  (
    p_rec_id util_pkg.cit_number,
    p_iccids util_pkg.cit_varchar_s,
    p_imsis util_pkg.cit_varchar_s,
    p_msisdns util_pkg.cit_varchar_s,
    p_network_operator_codes util_pkg.cit_varchar_s,
    p_check_sim_card_not_active number,
    p_check_phone_free_or_int number,
    p_check_sim_phone_host number,
    p_check_sim_host_belong_no number,
    p_check_phone_sim_link number,
    p_result_list out sys_refcursor,
    p_error_list out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure set_ph_st_and_reset_reserve_ii
  (
    p_na_id ct_number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure set_ph_st_and_reset_reserve_i
  (
    p_msisdns ct_varchar_s,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
  );

  procedure set_ph_st_and_reset_reserve
  (
    p_msisdns ct_varchar_s,
    p_status varchar2,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
  );

----------------------------------!---------------------------------------------
  procedure reserve_phones4period
  (
    p_na_id_ml ct_number,
    p_reserve_period_minutes number,
    p_user_id number,
    p_reserve_number out number
  );

  procedure reserve_phones4period2
  (
    p_msisdn_ml ct_varchar_s,
    p_reserve_period_minutes number,
    p_user_id number,
    p_reserve_number out number
  );

----------------------------------!---------------------------------------------
  procedure get_result_cursor01(p_msisdns ct_varchar_s, p_error_code ct_number, p_error_message ct_varchar, p_result out sys_refcursor);
  procedure get_result_cursor02(p_reserve_numbers ct_number, p_error_code ct_number, p_error_message ct_varchar, p_result out sys_refcursor);
  procedure get_result_cursor03(p_phone_sim_data t_phones_sims_container, p_is_linked_to_sim_card ct_number, p_result out sys_refcursor);
  procedure get_result_cursor04(p_rec_ids ct_number, p_error_code ct_number, p_error_message ct_varchar, p_result out sys_refcursor);

----------------------------------!---------------------------------------------

end;
/
