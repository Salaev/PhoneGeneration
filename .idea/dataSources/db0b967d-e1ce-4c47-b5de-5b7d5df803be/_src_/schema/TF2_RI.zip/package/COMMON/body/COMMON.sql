CREATE PACKAGE BODY          "COMMON" IS
---------------------------------------------------------------------------------------------------
-- Event_Logger
---------------------------------------------------------------------------------------------------
PROCEDURE Event_Logger(
  p_text         IN  LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
  p_level        IN  NUMBER, -- level of debuging
  p_event_type   IN  LOG_EVENT.EVENT_TYPE%TYPE, -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
  p_event_source IN  LOG_EVENT.EVENT_SOURCE%TYPE -- name of the source where this calling is performed
)
IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  v_user             LOG_EVENT.EVENT_USER%TYPE; -- name of the user who runs this procedure
  v_computer         LOG_EVENT.EVENT_COMPUTER%TYPE; -- name of the computer this procedure is run at
  v_file_handle      UTL_FILE.FILE_TYPE; -- file handle of OS flat file
  v_text             VARCHAR2(400); -- text for c_DEBUG_TO_BUFFER or c_DEBUG_TO_FILE
BEGIN

  -- do not debug when debugging level is higher than level set in db_parameters table
  IF p_level > RSIG_UTILS.v_debug_level THEN
    RETURN;
  END IF;

  v_computer := sys_context('userenv', 'terminal');
  v_user     := sys_context('userenv', 'os_user');

  v_text := substr('Date: ' || to_char(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' User: ' || v_user || ' Computer: ' ||
            v_computer || ' Called in: ' || p_event_source || ' Text: ' || p_text,1,400);

  CASE RSIG_UTILS.v_output
  -- Log to buffer
    WHEN RSIG_UTILS.c_DEBUG_TO_BUFFER THEN
      DBMS_OUTPUT.PUT_LINE(v_text);
      -- Log to file
    WHEN RSIG_UTILS.c_DEBUG_TO_FILE THEN
      BEGIN
        --append text to debug file
        --is debug file open - wait
        LOOP
          v_file_handle := UTL_FILE.FOPEN('RSIG_DEBUG', 'debug_' || lower(v_computer) || '.log', 'a');
          IF UTL_FILE.IS_OPEN(v_file_handle) THEN
            UTL_FILE.PUT_LINE(v_file_handle, substr(v_text, 1, 1022)); --MAX 1023 B
            UTL_FILE.FCLOSE(v_file_handle);
            EXIT;
          END IF;
        END LOOP;
      END;
      -- log to table
    WHEN RSIG_UTILS.c_DEBUG_TO_TABLE THEN
      BEGIN
        INSERT INTO LOG_EVENT
          (EVENT_ID,
           EVENT_TYPE,
           EVENT_SOURCE,
           EVENT_MESSAGE,
           EVENT_USER,
           EVENT_COMPUTER,
           EVENT_TIME)
        VALUES
          (S_LOG_EVENT.NEXTVAL,
           p_event_type,
           p_event_source,
           p_text,
           v_user,
           v_computer,
           SYSDATE);
      END;
  END CASE;

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(SQLERRM);
    ROLLBACK;
    IF RSIG_UTILS.v_output = RSIG_UTILS.c_DEBUG_TO_FILE THEN
      IF UTL_FILE.IS_OPEN(v_file_handle) THEN
        UTL_FILE.FCLOSE(v_file_handle);
      END IF;
    END IF;
END Event_Logger;

---------------------------------------------------------------------------------------------------
-- Event_Logger
---------------------------------------------------------------------------------------------------
PROCEDURE Check_Handle_Tran(
  p_handle_tran  IN  CHAR,
  p_procedure    IN  VARCHAR2
)
IS
BEGIN

  IF p_handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR p_handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid handle transaction parameter.');
  END IF;

  IF p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S THEN
    EXECUTE IMMEDIATE 'SAVEPOINT ' || p_procedure || 'S';
  END IF;

END Check_Handle_Tran;

---------------------------------------------------------------------------------------------------
-- Handle_Error
---------------------------------------------------------------------------------------------------
FUNCTION Handle_Error(
  p_ora_error_number  IN  NUMBER,
  p_handle_tran       IN  CHAR,
  p_package           IN  VARCHAR2,
  p_procedure         IN  VARCHAR2
) RETURN NUMBER
IS
  v_error_code            NUMBER;
  v_event_source          VARCHAR2(60);
BEGIN

  v_event_source:=p_package || '.' || p_procedure;

  IF (p_ora_error_number <= -20000) THEN
    v_error_code := p_ora_error_number + 20000;
  ELSE
    v_error_code := p_ora_error_number;
  END IF;

  CASE p_handle_tran
    WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
      EXECUTE IMMEDIATE 'ROLLBACK TO SAVEPOINT ' || p_procedure || 'S';
    WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
      ROLLBACK;
    ELSE
      NULL;
  END CASE;

  Common.Event_Logger(to_number(v_error_code),RSIG_UTILS.c_DEBUG_LEVEL_0,RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                      v_event_source);


  RETURN v_error_code;
END Handle_Error;

---------------------------------------------------------------------------------------------------
-- Handle_Error with parameter loging
---------------------------------------------------------------------------------------------------
FUNCTION Handle_Error(
  p_ora_error_number  IN  NUMBER,
  p_ora_message       IN  VARCHAR2,
  p_message           IN  VARCHAR2,
  p_handle_tran       IN  CHAR,
  p_package           IN  VARCHAR2,
  p_procedure         IN  VARCHAR2
) RETURN NUMBER
IS
  v_error_code            NUMBER;
  v_event_source          VARCHAR2(60);
  v_error_message         VARCHAR2(4000);
BEGIN

  v_event_source:=p_package || '.' || p_procedure;

  IF (p_ora_error_number <= -20000) THEN
    v_error_code := p_ora_error_number + 20000;
  ELSE
    v_error_code := p_ora_error_number;
  END IF;

  CASE p_handle_tran
    WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
      EXECUTE IMMEDIATE 'ROLLBACK TO SAVEPOINT ' || p_procedure || 'S';
    WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
      ROLLBACK;
    ELSE
      NULL;
  END CASE;

  -- create error message

  v_error_message:=substr('Error number: ' || to_char(p_ora_error_number) || chr(10) ||
                   'Error message: ' || p_ora_message || chr(10) ||p_message,1,4000);

  Common.Event_Logger(v_error_message,RSIG_UTILS.c_DEBUG_LEVEL_0,RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                      v_event_source);


  RETURN v_error_code;
END Handle_Error;
---------------------------------------------------------------------------------------------------
-- LPad_Shorter
---------------------------------------------------------------------------------------------------
FUNCTION LPad_Shorter(
  p_str     VARCHAR2,
  p_len     NUMBER,
  p_pad     VARCHAR2
)RETURN VARCHAR2
IS
BEGIN
  IF p_len>length(p_str) THEN
    RETURN lpad(p_str,p_len,p_pad);
  ELSE
    RETURN p_str;
  END IF;

END;

------------------------------------------------------------------------------------------------------
-- Fill_Ap_Id_From_Sn
------------------------------------------------------------------------------------------------------
PROCEDURE Fill_Access_Point_ID_SN(
  p_num_miss   OUT   NUMBER
)
IS
BEGIN

  update TT_BATCH_NA_AP t
  set t.access_point_id = (select /*+ index(sc UK_SIM_SN) */
                                  sc.access_point_id
                           from SIM_CARD sc
                           where sc.sn = t.sn);


  update TT_BATCH_NA_AP t
  set t.RESULT = RSIG_utils.c_SIM_CARD_NOT_EXISTS
  where t.access_point_id IS NULL;

  p_num_miss:=SQL%ROWCOUNT;
END Fill_Access_Point_ID_SN;

------------------------------------------------------------------------------------------------------
-- Fill_Ap_Id_From_Sn
------------------------------------------------------------------------------------------------------
PROCEDURE Fill_Network_Address_ID(
  p_num_miss   OUT   NUMBER
)
IS
BEGIN

  UPDATE TT_BATCH_NA_AP t
  SET t.NETWORK_ADDRESS_ID = (SELECT /*+ index (pn UK_PHONE_NUM_PHONE_NUMBER)*/
                                     pn.NETWORK_ADDRESS_ID
	     							          FROM PHONE_NUMBER pn
											        WHERE pn.INTERNATIONAL_FORMAT = t.international_format
                                AND (pn.deleted IS NULL OR pn.deleted>SYSDATE));


  UPDATE TT_BATCH_NA_AP t
  SET t.RESULT = rsig_utils.c_PHONE_NUMBER_NOT_EXISTS
  WHERE t.network_address_id IS NULL;

  p_num_miss:=SQL%ROWCOUNT;
END Fill_Network_Address_ID;

END COMMON;
/
