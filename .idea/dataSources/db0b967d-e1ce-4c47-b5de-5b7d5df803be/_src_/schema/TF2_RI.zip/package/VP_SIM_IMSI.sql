CREATE package VP_SIM_IMSI is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'SIM_IMSI';

  c_imsi_type_prefix             constant varchar2(5) := 'IMSI';
  c_order_num_main_imsi          constant number := 1;

  type rct_sim_imsi is table of sim_imsi%rowtype;

----------------------------------!---------------------------------------------
  function get_count_rct_sim_imsi(p_coll rct_sim_imsi) return number;

  procedure resize_rct_sim_imsi(p_coll in out nocopy rct_sim_imsi, p_size number);

----------------------------------!---------------------------------------------
  function get1_i(p_id_imsi varchar2, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return sim_imsi%rowtype;
  function get1(p_id_imsi varchar2, p_date date) return sim_imsi%rowtype;
  function xget1(p_id_imsi varchar2, p_date date) return sim_imsi%rowtype;
  function xlock_get1(p_id_imsi varchar2, p_date date) return sim_imsi%rowtype;
  function xlock_xget1(p_id_imsi varchar2, p_date date) return sim_imsi%rowtype;
  procedure xlock(p_id_imsi varchar2, p_date date);

----------------------------------!---------------------------------------------
  function getN_ap_id_i(p_ap_id number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return rct_sim_imsi;
  function getN_ap_id(p_ap_id number, p_date date) return rct_sim_imsi;
  function xlock_getN_ap_id(p_ap_id number, p_date date) return rct_sim_imsi;

----------------------------------!---------------------------------------------
  function find_i_id_imsi(p_rec sim_imsi%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_ap_imsi_type(p_rec sim_imsi%rowtype, p_check_only_other_ids boolean) return boolean;

  function find_i(p_rec sim_imsi%rowtype, p_check_only_other_ids boolean) return boolean;
  procedure xunique_i(p_rec sim_imsi%rowtype, p_check_only_other_ids boolean);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec sim_imsi%rowtype);
  procedure change_i(p_rec sim_imsi%rowtype);
  procedure close_i(p_rec sim_imsi%rowtype);

----------------------------------!---------------------------------------------
  function is_identified(p_rec sim_imsi%rowtype) return boolean;

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy sim_imsi%rowtype);
  procedure version_change(p_rec in out nocopy sim_imsi%rowtype, p_date_from_virt date := null);

  procedure version_close
  (
    p_id_imsi varchar2,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------
  function make_imsi_type(p_imsi_order_num integer) return varchar2;
  function make_imsi_add_type(p_imsi_add_order_num integer) return varchar2;
  function get_imsi_type_main return varchar2;

----------------------------------!---------------------------------------------

end;
/
