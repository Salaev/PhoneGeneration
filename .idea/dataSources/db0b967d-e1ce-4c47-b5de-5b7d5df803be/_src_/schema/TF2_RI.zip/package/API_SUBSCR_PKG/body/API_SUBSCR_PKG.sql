CREATE package body API_SUBSCR_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure activate_msisdn
(
  p_date date,
  p_user_id number,
  p_na_id number,
  p_ap_id number,
  p_pa number,
  p_host_id number,
  p_na_id_extra ct_number,
  p_na_status_new varchar2,
  p_na_add_status_new varchar2,
  p_ap_status_new varchar2,
  p_not_change_msisdn_status boolean,
  p_not_change_sim_status boolean,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_na_status_new varchar2(2);
  v_na_add_status_new varchar2(2);
  v_ap_status_new varchar2(2);
  --
  v_lock_pn boolean := true;
  v_lock_sc boolean := true;
  v_break_on_error boolean := true;
  v_silent_proper_lack boolean := true;
  v_silent_break_actual boolean := false;
  --
  v_x_app exception;
  v_num number;
  v_bool boolean;
  --
  v_ap_id2 number;
  v_na_id2 number;
  v_na_id_extra ct_number := NULL;
  --
  v_error_code ct_number;
  v_error_message ct_varchar;
  v_error_code2 number;
  v_error_message2 varchar2(4000);
  --
begin
  ------------------------------
  savepoint sp_activate_msisdn;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  --!_!util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_not_change_msisdn_status is null, 'p_not_change_msisdn_status');
  util_pkg.XCheck_Cond_Missing(p_not_change_sim_status is null, 'p_not_change_sim_status');
  ------------------------------
  ------------------------------
  v_na_status_new := util_ri.valid_code2(p_na_status_new);
  v_na_add_status_new := NVL(util_ri.valid_code2(p_na_add_status_new), v_na_status_new);
  v_ap_status_new := util_ri.valid_code2(p_ap_status_new);
  ------------------------------
  util_pkg.XCheck_Cond_Missing(NOT p_not_change_msisdn_status and v_na_status_new is null, 'p_na_status_new');
  util_pkg.XCheck_Cond_Missing(NOT p_not_change_sim_status and v_ap_status_new is null, 'p_ap_status_new');
  ------------------------------
  ------------------------------
  if p_na_id is null
  then
    ------------------------------
    p_error_code := util_loc_pkg.c_ora_phone_not_found;
    p_error_message := util_loc_pkg.c_msg_phone_not_found;
    raise v_x_app;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  if p_ap_id is null
  then
    ------------------------------
    p_error_code := util_loc_pkg.c_ora_sim_card_not_found;
    p_error_message := util_loc_pkg.c_msg_sim_card_not_found;
    raise v_x_app;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  if p_host_id is null
  then
    ------------------------------
    p_error_code := util_loc_pkg.c_ora_host_not_found;
    p_error_message := util_loc_pkg.c_msg_host_not_found;
    raise v_x_app;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  if util_pkg.get_count_ct_number(p_na_id_extra) > 0
  then
    ------------------------------
    for v_i in p_na_id_extra.first..p_na_id_extra.last
    loop
      ------------------------------
      if p_na_id_extra(v_i) is null
      then
        ------------------------------
        p_error_code := util_loc_pkg.c_ora_phone_not_found;
        p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_phone_not_found
          || util_pkg.c_msg_delim01 || 'na_id_extra for na_id=' || util_pkg.number_to_char(p_na_id)
        );
        raise v_x_app;
        ------------------------------
      end if;
      ------------------------------
    end loop;
    ------------------------------
    v_na_id_extra := util_ri.suppress_plink_l(p_na_id_extra, p_date);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_ap_id2 := util_ri.get_linked_ap_id2(p_na_id, util_ri.c_NAAP_LINK_TYPE_CODE_MAIN, p_date);
  ------------------------------
  if v_ap_id2 is not null
    and v_ap_id2 != p_ap_id
  then
    ------------------------------
    p_error_code := util_loc_pkg.c_ora_na_linked_to_other_ap;
    p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_na_linked_to_other_ap
      || util_pkg.c_msg_delim01 || 'na_id=' || util_pkg.number_to_char(p_na_id)
      || util_pkg.c_msg_delim02 || 'ap_id=' || util_pkg.number_to_char(v_ap_id2)
    );
    raise v_x_app;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_na_id2 := util_ri.get_linked_na_id_main2(p_ap_id, p_date);
  ------------------------------
  if v_na_id2 is not null
    and v_na_id2 != p_na_id
  then
    ------------------------------
    p_error_code := util_loc_pkg.c_ora_ap_linked_to_other_na;
    p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_ap_linked_to_other_na
      || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(p_ap_id)
      || util_pkg.c_msg_delim02 || 'na_id=' || util_pkg.number_to_char(v_na_id2)
    );
    raise v_x_app;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  --!_!link main msisdn with sim
  ------------------------------
  if v_ap_id2 is null
    --!_!and v_na_id2 is null
  then
    ------------------------------
    ------------------------------
    v_bool := util_ext_ri.set_naap_status3
    (
      p_na_id => p_na_id,
      p_ap_id => p_ap_id,
      p_link_type_code => util_ri.c_NAAP_LINK_TYPE_CODE_MAIN,
      p_date => p_date,
      p_user_id => p_user_id,
      p_lock_pn => v_lock_pn,
      p_lock_sc => v_lock_sc,
      p_silent_proper_lack => v_silent_proper_lack,
      p_silent_break_actual => v_silent_break_actual,
      p_error_code => v_error_code2,
      p_error_message => v_error_message2
    );
    ------------------------------
    if not v_bool
    then
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_linking_failed;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_linking_failed
        || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(p_ap_id)
        || util_pkg.c_msg_delim02 || 'na_id=' || util_pkg.number_to_char(p_na_id)
        || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
        || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
  end if;
  ------------------------------
  --!_!link main msisdn with sim
  ------------------------------
  ------------------------------
  --!_!set main msisdn status
  ------------------------------
  if NOT p_not_change_msisdn_status
  then
    ------------------------------
    v_bool := util_ext_ri.set_na_status3
    (
      p_na_id => p_na_id,
      p_status => v_na_status_new,
      p_date => p_date,
      p_user_id => p_user_id,
      p_lock_pn => v_lock_pn,
      p_error_code => v_error_code2,
      p_error_message => v_error_message2
    );
    ------------------------------
    if not v_bool
    then
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_status_changing_failed;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_status_changing_failed
        || util_pkg.c_msg_delim01 || 'na_id=' || util_pkg.number_to_char(p_na_id)
        || util_pkg.c_msg_delim02 || 'status=' || v_na_status_new
        || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
        || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  --!_!set main msisdn status
  ------------------------------
  ------------------------------
  --!_!set sim status
  ------------------------------
  if NOT p_not_change_sim_status
  then
    ------------------------------
    v_bool := util_ext_ri.set_ap_status3
    (
      p_ap_id => p_ap_id,
      p_status => v_ap_status_new,
      p_date => p_date,
      p_user_id => p_user_id,
      p_lock_sc => v_lock_sc,
      p_error_code => v_error_code2,
      p_error_message => v_error_message2
    );
    ------------------------------
    if not v_bool
    then
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_status_changing_failed;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_status_changing_failed
        || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(p_ap_id)
        || util_pkg.c_msg_delim02 || 'status=' || v_ap_status_new
        || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
        || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  --!_!set sim status
  ------------------------------
  ------------------------------
  --!_!extra msisdns
  ------------------------------
  if util_pkg.get_count_ct_number(v_na_id_extra) > 0
  then
    ------------------------------
    v_bool := util_ext_ri.set_naap_status3_open_second
    (
      p_na_id => v_na_id_extra,
      p_ap_id => p_ap_id,
      p_date => p_date,
      p_user_id => p_user_id,
      p_lock_pn => v_lock_pn,
      p_lock_sc => v_lock_sc,
      p_silent_proper_lack => v_silent_proper_lack,
      p_silent_break_actual => v_silent_break_actual,
      p_error_code => v_error_code,
      p_error_message => v_error_message
    );
    ------------------------------
    if not v_bool
    then
      ------------------------------
      v_num := util_ext_ri.get_first_error_pos(v_error_code);
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_linking_failed;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_linking_failed
        || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(p_ap_id)
        || util_pkg.c_msg_delim02 || 'na_id=' || util_pkg.number_to_char(v_na_id_extra(v_num))
        || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code(v_num))
        || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message(v_num)
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
    if NOT p_not_change_msisdn_status
    then
      ------------------------------
      v_bool := util_ext_ri.set_na_status2
      (
        p_na_id => v_na_id_extra,
        p_status => v_na_add_status_new,
        p_date => p_date,
        p_user_id => p_user_id,
        p_break_on_error => v_break_on_error,
        p_lock_pn => v_lock_pn,
        p_error_code => v_error_code,
        p_error_message => v_error_message
      );
      ------------------------------
      if not v_bool
      then
        ------------------------------
        v_num := util_ext_ri.get_first_error_pos(v_error_code);
        ------------------------------
        p_error_code := util_loc_pkg.c_ora_status_changing_failed;
        p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_status_changing_failed
          || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(p_ap_id)
          || util_pkg.c_msg_delim02 || 'na_id=' || util_pkg.number_to_char(v_na_id_extra(v_num))
          || util_pkg.c_msg_delim02 || 'status=' || v_na_add_status_new
          || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code(v_num))
          || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message(v_num)
        );
        raise v_x_app;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  --!_!extra msisdns
  ------------------------------
  ------------------------------
  --!_!link sim to pa
  ------------------------------
  v_bool := util_ext_ri.set_appa_status3
  (
    p_ap_id => p_ap_id,
    p_pa => p_pa,
    p_date => p_date,
    p_user_id => p_user_id,
    p_lock_sc => v_lock_sc,
    p_silent_proper_lack => v_silent_proper_lack,
    p_silent_break_actual => v_silent_break_actual,
    p_error_code => v_error_code2,
    p_error_message => v_error_message2
  );
  ------------------------------
  if not v_bool
  then
    ------------------------------
    p_error_code := util_loc_pkg.c_ora_linking_failed;
    p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_linking_failed
      || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(p_ap_id)
      || util_pkg.c_msg_delim02 || 'pa=' || util_pkg.number_to_char(p_pa)
      || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
      || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
    );
    raise v_x_app;
    ------------------------------
  end if;
  ------------------------------
  --!_!link sim to pa
  ------------------------------
  ------------------------------
  --!_!remove from na batches
  ------------------------------
  batch_pkg.na_res_batch_remove_from2(p_na_id, p_user_id);
  ------------------------------
  --!_!remove from na batches
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when v_x_app then
  ------------------------------
  rollback to sp_activate_msisdn;
  ------------------------------
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback to sp_activate_msisdn;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure activate_pa_pre
(
  p_date date,
  p_user_id number,
  p_pa number,
  p_host_id number,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_silent_proper_lack boolean := true;
  v_silent_break_actual boolean := false;
  --
  v_x_app exception;
  v_bool boolean;
  --
  v_rec_pah personal_account_history%rowtype;
  v_ap_id ct_number;
  --
  v_error_code2 number;
  v_error_message2 varchar2(4000);
  --
begin
  ------------------------------
  savepoint sp_activate_pa_pre;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  ------------------------------
  ------------------------------
  --!_!unlink pa from host
  ------------------------------
  if TRUE
  then
    ------------------------------
    ------------------------------
    v_rec_pah := util_ri.get_1pah(p_pa, p_date);
    ------------------------------
    if v_rec_pah.balance_storage is not null
    then
      ------------------------------
      if v_rec_pah.balance_storage != p_host_id
      then
        ------------------------------
        v_ap_id := util_ri.get_pa_linked_ap_id2(p_pa, p_date);
        ------------------------------
        if util_pkg.get_count_ct_number(v_ap_id) > 0
        then
          ------------------------------
          p_error_code := util_loc_pkg.c_ora_already_linked;
          p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_already_linked
            || util_pkg.c_msg_delim01 || 'pa=' || util_pkg.number_to_char(p_pa)
            || util_pkg.c_msg_delim01 || 'balance_storage=' || util_pkg.number_to_char(v_rec_pah.balance_storage)
            || util_pkg.c_msg_delim01 || 'ap count=' || util_pkg.number_to_char(util_pkg.get_count_ct_number(v_ap_id))
          );
          raise v_x_app;
          ------------------------------
        end if;
        ------------------------------
      end if;
      ------------------------------
      v_bool := util_ext_ri.set_pah_status3_close
      (
        p_pa => p_pa,
        p_date => p_date,
        p_user_id => p_user_id,
        p_silent_proper_lack => v_silent_proper_lack,
        p_silent_break_actual => v_silent_break_actual,
        p_error_code => v_error_code2,
        p_error_message => v_error_message2
      );
      ------------------------------
      if not v_bool
      then
        ------------------------------
        p_error_code := util_loc_pkg.c_ora_unlinking_failed;
        p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_unlinking_failed
          || util_pkg.c_msg_delim01 || 'pa=' || util_pkg.number_to_char(p_pa)
          || util_pkg.c_msg_delim02 || 'from host'
          || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
          || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
        );
        raise v_x_app;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
  end if;
  ------------------------------
  --!_!unlink pa from host
  ------------------------------
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when v_x_app then
  ------------------------------
  rollback to sp_activate_pa_pre;
  ------------------------------
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback to sp_activate_pa_pre;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure activate_pa
(
  p_date date,
  p_user_id number,
  p_pa number,
  p_host_id number,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_silent_proper_lack boolean := true;
  v_silent_break_actual boolean := false;
  --
  v_x_app exception;
  v_bool boolean;
  --
  v_error_code2 number;
  v_error_message2 varchar2(4000);
  --
begin
  ------------------------------
  savepoint sp_activate_pa;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  ------------------------------
  ------------------------------
  --!_!link pa to host
  ------------------------------
  if TRUE
  then
    ------------------------------
    ------------------------------
    v_bool := util_ext_ri.set_pah_status3
    (
      p_pa => p_pa,
      p_host_id => p_host_id,
      p_date => p_date,
      p_user_id => p_user_id,
      p_silent_proper_lack => v_silent_proper_lack,
      p_silent_break_actual => v_silent_break_actual,
      p_error_code => v_error_code2,
      p_error_message => v_error_message2
    );
    ------------------------------
    if not v_bool
    then
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_linking_failed;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_linking_failed
        || util_pkg.c_msg_delim01 || 'pa=' || util_pkg.number_to_char(p_pa)
        || util_pkg.c_msg_delim02 || 'host_id=' || util_pkg.number_to_char(p_host_id)
        || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
        || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
  end if;
  ------------------------------
  --!_!link pa to host
  ------------------------------
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when v_x_app then
  ------------------------------
  rollback to sp_activate_pa;
  ------------------------------
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback to sp_activate_pa;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure subscribers_activate
(
  p_msisdn util_pkg.cit_varchar_s,
  p_iccid util_pkg.cit_varchar_s,
  p_personal_account util_pkg.cit_number,
  p_host_code util_pkg.cit_varchar_s,
  p_msisdns_extra util_pkg.cit_varchar,
  p_date date,
  p_user_nt_name varchar2,
  p_not_change_msisdn_status util_pkg.cit_number,
  p_not_change_sim_status util_pkg.cit_number,
  p_error_code out number,
  p_error_message out varchar2,
  p_result out sys_refcursor
)
is
  v_date date := nvl(p_date, sysdate);
  v_user_id number;
  v_main_count number;
  --
  v_pivot ct_number;
  v_msisdn ct_varchar_s;
  v_iccid ct_varchar_s;
  v_pa ct_number;
  v_host_code ct_varchar_s;
  v_msisdns_extra ct_varchar;
  v_msisdns_extra_coll ct_varchar_s;
  v_na_id ct_number;
  v_ap_id ct_number;
  v_host_id ct_number;
  v_na_id_extra ct_number;
  v_batch_id ct_number;
  v_err_code ct_number;
  v_err_msg ct_varchar;
  --
  v_error_code number;
  v_error_message varchar2(4000);
  v_x_app exception;
  --
  v_first_time boolean;
  v_pa_cur number;
  v_seq_num_cur ct_number;
  v_host_id_cur number;
  v_index number;
  v_index_err number;
  --
  v_num number;
  v_coll_num ct_number;
  --
  lc_no_value constant number := null;
  --
  type lrt_pa_desc is record(pa number, seq_nums ct_number);
  type lct_pa_desc is table of lrt_pa_desc;
  v_pa_desc lct_pa_desc := lct_pa_desc();
  --
begin
  ------------------------------
  util_pkg.XCheckP_FSU_cit_varchar_s(p_msisdn, 'p_msisdn', FALSE);
  util_pkg.XCheckP_FSU_cit_varchar_s(p_iccid, 'p_iccid', FALSE);
  util_pkg.XCheckP_FS_cit_number(p_personal_account, 'p_personal_account', FALSE);
  util_pkg.XCheckP_FS_cit_varchar_s(p_host_code, 'p_host_code', FALSE); --!_! MANDATORY in spite of HLA (LT240337)
  util_pkg.XCheckP_cit_varchar(p_msisdns_extra, 'p_msisdns_extra', FALSE);
  --!_!util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_nt_name is null, 'p_user_nt_name');
  util_pkg.XCheckP_FS_cit_number(p_not_change_msisdn_status, 'p_not_change_msisdn_status', FALSE);
  util_pkg.XCheckP_FS_cit_number(p_not_change_sim_status, 'p_not_change_sim_status', FALSE);
  ------------------------------
  v_main_count := p_msisdn.count;
  util_pkg.XCheck_Cond_Invalid(p_msisdn.count != v_main_count, 'p_msisdn.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_iccid.count != v_main_count, 'p_iccid.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_personal_account.count != v_main_count, 'p_personal_account.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_msisdns_extra.count != v_main_count, 'p_msisdns_extra.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_host_code.count != v_main_count, 'p_host_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_not_change_msisdn_status.count != v_main_count, 'p_not_change_msisdn_status.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_not_change_sim_status.count != v_main_count, 'p_not_change_sim_status.count != v_main_count');
  ------------------------------
  v_user_id := util_ri.xget_user_id(p_user_nt_name);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  v_msisdn := util_pkg.cast_cit2ct_varchar_s(p_msisdn, FALSE);
  v_iccid := util_pkg.cast_cit2ct_varchar_s(p_iccid, FALSE);
  v_pa := util_pkg.cast_cit2ct_number(p_personal_account, FALSE);
  v_host_code := util_pkg.cast_cit2ct_varchar_s(p_host_code, FALSE);
  v_msisdns_extra := util_pkg.cast_cit2ct_varchar(p_msisdns_extra, FALSE);
  ------------------------------
  v_na_id := util_ri.get_na_id(v_msisdn, v_date, FALSE);
  v_ap_id := util_ri.get_ap_id(v_iccid, v_date, FALSE);
  v_host_id := util_ri.get_host_id(v_host_code, v_date, FALSE);
  v_batch_id := batch_pkg.get_na_res_batches_by_na(v_na_id);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_pivot) != v_main_count, 'v_pivot.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_msisdn) != v_main_count, 'v_msisdn.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_iccid) != v_main_count, 'v_iccid.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_pa) != v_main_count, 'v_pa.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_host_code) != v_main_count, 'v_host_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_na_id) != v_main_count, 'v_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_ap_id) != v_main_count, 'v_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_host_id) != v_main_count, 'v_host_id.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, NULL, NULL, v_err_code, v_err_msg, TRUE);
  ------------------------------
  ------------------------------
  v_first_time := true;
  ------------------------------
  for v_i in
  (
    select /*+ ordered use_hash(q0, q1, q2, q3)*/
      q0.seq_num, q1.na_id, q2.ap_id, q3.pa
      from
        (select column_value seq_num, rownum rn from table(v_pivot)) q0,
        (select column_value na_id, rownum rn from table(v_na_id)) q1,
        (select column_value ap_id, rownum rn from table(v_ap_id)) q2,
        (select column_value pa, rownum rn from table(v_pa)) q3
      where 1 = 1
      and q1.rn(+) = q0.rn
      and q2.rn(+) = q0.rn
      and q3.rn(+) = q0.rn
      --order by q0.rn
      order by q3.pa NULLS FIRST, q2.ap_id NULLS FIRST, q0.seq_num --!_! order is critical
  )
  loop
    ------------------------------
    if (1 = 0
      or v_first_time
      or NOT util_pkg.is_eq_null_vals_number(v_pa_cur, v_i.pa)
    )
    then
      ------------------------------
      v_first_time := false;
      ------------------------------
      v_pa_cur := v_i.pa;
      ------------------------------
      v_pa_desc.extend;
      v_pa_desc(v_pa_desc.last).pa := v_pa_cur;
      util_pkg.resize_ct_number(v_pa_desc(v_pa_desc.last).seq_nums, 0);
      ------------------------------
    end if;
    ------------------------------
    util_pkg.add_ct_number_val(v_pa_desc(v_pa_desc.last).seq_nums, v_i.seq_num);
    ------------------------------
  end loop;
  ------------------------------
  ------------------------------
  for v_i in v_pa_desc.first..v_pa_desc.last
  loop
    ------------------------------
    ------------------------------
    v_pa_cur := v_pa_desc(v_i).pa;
    v_seq_num_cur := v_pa_desc(v_i).seq_nums;
    v_host_id_cur := NULL;
    ------------------------------
    if v_pa_cur is not null
    then
      ------------------------------
      v_coll_num := util_pkg.filter_ct_number(v_host_id, v_pivot, v_seq_num_cur, true);
      ------------------------------
      v_num := v_coll_num(v_coll_num.first);
      ------------------------------
      if util_pkg.index_of_ct_number(v_coll_num, v_num, 1, util_pkg.C_FALSE) != util_pkg.c_index_not_found
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter
          || util_pkg.c_msg_delim01 || 'not same p_host_code'
          || util_pkg.c_msg_delim02 || 'pa=' || util_pkg.number_to_char(v_pa_cur)
        );
        ------------------------------
      end if;
      ------------------------------
      v_host_id_cur := v_num;
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    begin
      ------------------------------
      ------------------------------
      savepoint sp_subscribers_activate_pa;
      ------------------------------
      ------------------------------
      --!_!if v_pa_cur is not null
      --!_!then
        ------------------------------
        activate_pa_pre
        (
          p_date => v_date,
          p_user_id => v_user_id,
          p_pa => v_pa_cur,
          p_host_id => v_host_id_cur,
          p_error_code => v_error_code,
          p_error_message => v_error_message
        );
        ------------------------------
        if util_pkg.is_error(v_error_code)
        then
          ------------------------------
          raise v_x_app;
          ------------------------------
        end if;
        ------------------------------
      --!_!end if;
      ------------------------------
      ------------------------------
      for v_j in v_seq_num_cur.first..v_seq_num_cur.last
      loop
        ------------------------------
        v_index := v_seq_num_cur(v_j);
        ------------------------------
        v_msisdns_extra_coll := util_ri.split_str_list(v_msisdns_extra(v_index), TRUE);
        ------------------------------
        v_na_id_extra := NULL;
        ------------------------------
        if util_pkg.get_count_ct_varchar_s(v_msisdns_extra_coll) > 0
        then
          ------------------------------
          v_na_id_extra := util_ri.get_na_id(v_msisdns_extra_coll, v_date, FALSE);
          ------------------------------
          v_index_err := util_pkg.index_of_ct_number(v_na_id_extra, lc_no_value);
          ------------------------------
          if v_index_err != util_pkg.c_index_not_found
          then
            ------------------------------
            util_pkg.raise_exception(util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter
              || util_pkg.c_msg_delim01 || 'not found extra msisdn=' || v_msisdns_extra_coll(v_index_err)
            );
            ------------------------------
          end if;
          ------------------------------
        end if;
        ------------------------------
        activate_msisdn
        (
          p_date => v_date,
          p_user_id => v_user_id,
          p_na_id => v_na_id(v_index),
          p_ap_id => v_ap_id(v_index),
          p_pa => v_pa_cur,
          p_host_id => v_host_id_cur,
          p_na_id_extra => v_na_id_extra,
          p_na_status_new => util_ri.c_NASH_CODE_USED,
          p_na_add_status_new => util_ri.c_NASH_CODE_USED,
          p_ap_status_new => util_ri.c_APSH_CODE_ACTIVATED,
          p_not_change_msisdn_status => util_pkg.int_to_bool_2val(p_not_change_msisdn_status(v_index)),
          p_not_change_sim_status => util_pkg.int_to_bool_2val(p_not_change_sim_status(v_index)),
          p_error_code => v_error_code,
          p_error_message => v_error_message
        );
        ------------------------------
        if util_pkg.is_error(v_error_code)
        then
          ------------------------------
          raise v_x_app;
          ------------------------------
        end if;
        ------------------------------
      end loop;
      ------------------------------
      ------------------------------
      --!_!if v_pa_cur is not null
      --!_!then
        ------------------------------
        activate_pa
        (
          p_date => v_date,
          p_user_id => v_user_id,
          p_pa => v_pa_cur,
          p_host_id => v_host_id_cur,
          p_error_code => v_error_code,
          p_error_message => v_error_message
        );
        ------------------------------
        if util_pkg.is_error(v_error_code)
        then
          ------------------------------
          raise v_x_app;
          ------------------------------
        end if;
        ------------------------------
      --!_!end if;
      ------------------------------
      ------------------------------
      util_pkg.set_ok(v_error_code, v_error_message);
      ------------------------------
    exception
    when v_x_app then
      ------------------------------
      rollback to sp_subscribers_activate_pa;
      ------------------------------
    when others then
      ------------------------------
      util_pkg.set_error(v_error_code, v_error_message);
      ------------------------------
      rollback to sp_subscribers_activate_pa;
      ------------------------------
    end;
    ------------------------------
    ------------------------------
    for v_j in v_seq_num_cur.first..v_seq_num_cur.last
    loop
      ------------------------------
      v_index := v_seq_num_cur(v_j);
      ------------------------------
      v_err_code(v_index) := v_error_code;
      v_err_msg(v_index) := v_error_message;
      ------------------------------
    end loop;
    ------------------------------
    ------------------------------
  end loop;
  ------------------------------
  ------------------------------
  if (util_pkg.get_count_ct_number(v_batch_id) > 0)
  then
    batch_pkg.na_res_batches_del_smart(v_batch_id, v_user_id);
  end if;
  ------------------------------
  ------------------------------
  open p_result for
  select /*+ ordered use_hash(q1, q2, q3, q4, q5)*/
    q1.rn,
    q1.msisdn,
    q2.personal_account,
    q3.iccid,
    q4.error_code,
    q5.error_message
    from
      (select column_value msisdn, rownum rn from table(v_msisdn)) q1,
      (select column_value personal_account, rownum rn from table(v_pa)) q2,
      (select column_value iccid, rownum rn from table(v_iccid)) q3,
      (select column_value error_code, rownum rn from table(v_err_code)) q4,
      (select column_value error_message, rownum rn from table(v_err_msg)) q5
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    and q4.rn(+) = q1.rn
    and q5.rn(+) = q1.rn
    order by q1.rn
  ;
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure deactivate_msisdn
(
  p_date date,
  p_user_id number,
  p_na_id number,
  p_ap_id number,
  p_na_status_new varchar2,
  p_na_add_status_new varchar2,
  p_ap_status_new varchar2,
  p_ap_pstatus_new varchar2,
  p_change_sim_prod_status boolean,
  p_clear_sim_card_detail boolean,
  p_unlink_phone_and_sim boolean,
  p_link_phone_and_first_sim boolean,
  p_set_previous_phone_status boolean,
  p_not_change_sim_status boolean,
  p_not_change_msisdn_status boolean,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_na_status_new varchar2(2);
  v_na_add_status_new varchar2(2);
  v_ap_status_new varchar2(2);
  v_ap_pstatus_new varchar2(2);
  --
  v_lock_pn boolean := true;
  v_lock_sc boolean := true;
  v_break_on_error boolean := true;
  v_silent_proper_lack boolean := true;
  v_silent_break_actual boolean := false;
  --
  v_x_app exception;
  v_num number;
  v_bool boolean;
  v_coll_num ct_number;
  --
  v_na_id_extra ct_number;
  v_ap_id_first number;
  v_status_tmp varchar2(2);
  --
  v_error_code ct_number;
  v_error_message ct_varchar;
  v_error_code2 number;
  v_error_message2 varchar2(4000);
  --
begin
  ------------------------------
  savepoint sp_deactivate_msisdn;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_change_sim_prod_status is null, 'p_change_sim_prod_status');
  util_pkg.XCheck_Cond_Missing(p_clear_sim_card_detail is null, 'p_clear_sim_card_detail');
  util_pkg.XCheck_Cond_Missing(p_unlink_phone_and_sim is null, 'p_unlink_phone_and_sim');
  util_pkg.XCheck_Cond_Missing(p_link_phone_and_first_sim is null, 'p_link_phone_and_first_sim');
  util_pkg.XCheck_Cond_Missing(p_set_previous_phone_status is null, 'p_set_previous_phone_status');
  util_pkg.XCheck_Cond_Missing(p_not_change_sim_status is null, 'p_not_change_sim_status');
  util_pkg.XCheck_Cond_Missing(p_not_change_msisdn_status is null, 'p_not_change_msisdn_status');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_set_previous_phone_status and p_not_change_msisdn_status, 'p_set_previous_phone_status and p_not_change_msisdn_status');
  ------------------------------
  ------------------------------
  v_na_status_new := util_ri.valid_code2(p_na_status_new);
  v_na_add_status_new := NVL(util_ri.valid_code2(p_na_add_status_new), v_na_status_new);
  v_ap_status_new := util_ri.valid_code2(p_ap_status_new);
  v_ap_pstatus_new := util_ri.valid_code2(p_ap_pstatus_new);
  ------------------------------
  util_pkg.XCheck_Cond_Missing(NOT p_set_previous_phone_status and NOT p_not_change_msisdn_status and v_na_status_new is null, 'p_na_status_new');
  util_pkg.XCheck_Cond_Missing(NOT p_not_change_sim_status and v_ap_status_new is null, 'p_ap_status_new');
  util_pkg.XCheck_Cond_Missing(p_change_sim_prod_status and v_ap_pstatus_new is null, 'p_ap_pstatus_new');
  ------------------------------
  ------------------------------
  if p_na_id is null
  then
    ------------------------------
    p_error_code := util_loc_pkg.c_ora_phone_not_found;
    p_error_message := util_loc_pkg.c_msg_phone_not_found;
    raise v_x_app;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_num := util_ri.get_linked_ap_id2(p_na_id, util_ri.c_NAAP_LINK_TYPE_CODE_SECOND, p_date);
  ------------------------------
  if v_num is not null --!_! passed NOT util_ri.c_NAAP_LINK_TYPE_CODE_MAIN msisdn
  then
    ------------------------------
    p_error_code := util_pkg.c_ora_invalid_parameter;
    p_error_message := util_pkg.cut_err_msg(util_pkg.c_msg_invalid_parameter || util_pkg.c_msg_delim01 || 'Not main link type.');
    raise v_x_app;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  if p_ap_id is null
  then
    ------------------------------
    --!_!p_error_code := util_loc_pkg.c_ora_na_not_linked;
    --!_!p_error_message := util_loc_pkg.c_msg_na_not_linked;
    ------------------------------
    util_pkg.set_ok(p_error_code, p_error_message);
    ------------------------------
    raise v_x_app;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  --!_!extra msisdns
  ------------------------------
  v_na_id_extra := util_ri.get_linked_na_id_sec_no_plink2(p_ap_id, p_date);
  ------------------------------
  if util_pkg.get_count_ct_number(v_na_id_extra) > 0
  then
    ------------------------------
    --!_! Make or not del_na_status2 for extra msisdns; I'm not sure - leaving current variant.
    ------------------------------
    if p_set_previous_phone_status
    then
      ------------------------------
      v_bool := util_ext_ri.del_na_status2
      (
        p_na_id => v_na_id_extra,
        p_date => p_date,
        p_user_id => p_user_id,
        p_break_on_error => v_break_on_error,
        p_lock_pn => v_lock_pn,
        p_silent_prev_lack => TRUE,
        p_error_code => v_error_code,
        p_error_message => v_error_message
      );
      ------------------------------
    elsif NOT p_not_change_msisdn_status
    then
      ------------------------------
      v_bool := util_ext_ri.set_na_status2
      (
        p_na_id => v_na_id_extra,
        p_status => v_na_add_status_new,
        p_date => p_date,
        p_user_id => p_user_id,
        p_break_on_error => v_break_on_error,
        p_lock_pn => v_lock_pn,
        p_error_code => v_error_code,
        p_error_message => v_error_message
      );
      ------------------------------
    else
      ------------------------------
      v_bool := TRUE;
      ------------------------------
    end if;
    ------------------------------
    if not v_bool
    then
      ------------------------------
      v_num := util_ext_ri.get_first_error_pos(v_error_code);
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_status_changing_failed;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_status_changing_failed
        || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(p_ap_id)
        || util_pkg.c_msg_delim02 || 'na_id=' || util_pkg.number_to_char(v_na_id_extra(v_num))
        || util_pkg.c_msg_delim02 || 'status=' || v_na_add_status_new
        || util_pkg.c_msg_delim02 || 'p_set_previous_phone_status=' || util_pkg.bool_to_char(p_set_previous_phone_status)
        || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code(v_num))
        || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message(v_num)
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
    v_bool := util_ext_ri.set_naap_status2_close
    (
      p_na_id => v_na_id_extra,
      p_date => p_date,
      p_user_id => p_user_id,
      p_break_on_error => v_break_on_error,
      p_lock_pn => v_lock_pn,
      p_silent_proper_lack => v_silent_proper_lack,
      p_silent_break_actual => v_silent_break_actual,
      p_error_code => v_error_code,
      p_error_message => v_error_message
    );
    ------------------------------
    if not v_bool
    then
      ------------------------------
      v_num := util_ext_ri.get_first_error_pos(v_error_code);
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_unlinking_failed;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_unlinking_failed
        || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(p_ap_id)
        || util_pkg.c_msg_delim02 || 'na_id=' || util_pkg.number_to_char(v_na_id_extra(v_num))
        || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code(v_num))
        || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message(v_num)
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  --!_!extra msisdns
  ------------------------------
  ------------------------------
  --!_!unlink main msisdn
  ------------------------------
  if (1 = 0
    or p_unlink_phone_and_sim
    or p_link_phone_and_first_sim
  )
  then
    ------------------------------
    v_bool := util_ext_ri.set_naap_status3_close
    (
      p_na_id => p_na_id,
      p_date => p_date,
      p_user_id => p_user_id,
      p_lock_pn => v_lock_pn,
      p_silent_proper_lack => v_silent_proper_lack,
      p_silent_break_actual => v_silent_break_actual,
      p_error_code => v_error_code2,
      p_error_message => v_error_message2
    );
    ------------------------------
    if not v_bool
    then
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_unlinking_failed;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_unlinking_failed
        || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(p_ap_id)
        || util_pkg.c_msg_delim02 || 'na_id=' || util_pkg.number_to_char(p_na_id)
        || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
        || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  --!_!unlink main msisdn
  ------------------------------
  ------------------------------
  --!_!link main msisdn with first sim
  ------------------------------
  if p_link_phone_and_first_sim
  then
    ------------------------------
    ------------------------------
    v_ap_id_first := util_ri.get_first_naap(p_na_id).access_point_id;
    ------------------------------
    if v_ap_id_first is null
    then
      ------------------------------
      p_error_code := util_pkg.c_ora_object_not_found;
      p_error_message := util_pkg.cut_err_msg(util_pkg.c_msg_object_not_found
        || util_pkg.c_msg_delim01 || 'first sim for na_id=' || util_pkg.number_to_char(p_na_id)
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
    v_coll_num := util_ri.get_linked_na_id2(v_ap_id_first, NULL, p_date);
    ------------------------------
    if util_pkg.get_count_ct_number(v_coll_num) > 0
    then
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_already_linked;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_already_linked
        || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(v_ap_id_first)
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    v_bool := util_ext_ri.set_naap_status3
    (
      p_na_id => p_na_id,
      p_ap_id => v_ap_id_first,
      p_link_type_code => util_ri.c_NAAP_LINK_TYPE_CODE_MAIN,
      p_date => p_date,
      p_user_id => p_user_id,
      p_lock_pn => v_lock_pn,
      p_lock_sc => v_lock_sc,
      p_silent_proper_lack => v_silent_proper_lack,
      p_silent_break_actual => v_silent_break_actual,
      p_error_code => v_error_code2,
      p_error_message => v_error_message2
    );
    ------------------------------
    if not v_bool
    then
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_linking_failed;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_linking_failed
        || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(v_ap_id_first)
        || util_pkg.c_msg_delim02 || 'na_id=' || util_pkg.number_to_char(p_na_id)
        || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
        || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    if 1 = 1
      and v_ap_id_first != p_ap_id
      and NOT p_not_change_sim_status
      and v_ap_status_new != util_ri.valid_code2(util_ri.get_1apsh(v_ap_id_first, p_date).access_point_status_code)
    then
      ------------------------------
      v_bool := util_ext_ri.set_ap_status3
      (
        p_ap_id => v_ap_id_first,
        p_status => v_ap_status_new,
        p_date => p_date,
        p_user_id => p_user_id,
        p_lock_sc => v_lock_sc,
        p_error_code => v_error_code2,
        p_error_message => v_error_message2
      );
      ------------------------------
      if not v_bool
      then
        ------------------------------
        p_error_code := util_loc_pkg.c_ora_status_changing_failed;
        p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_status_changing_failed
          || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(v_ap_id_first)
          || util_pkg.c_msg_delim02 || 'status=' || v_ap_status_new
          || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
          || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
        );
        raise v_x_app;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    if 1 = 1
      and v_ap_id_first != p_ap_id
      and p_change_sim_prod_status
      and v_ap_pstatus_new != util_ri.valid_code2(util_ri.get_1appsh(v_ap_id_first, p_date).ap_prod_status_code)
    then
      ------------------------------
      v_bool := util_ext_ri.set_ap_pstatus3
      (
          p_ap_id => v_ap_id_first,
          p_status => v_ap_pstatus_new,
          p_date => p_date,
          p_user_id => p_user_id,
          p_lock_sc => v_lock_sc,
          p_error_code => v_error_code2,
          p_error_message => v_error_message2
      );
      ------------------------------
      if not v_bool
      then
        ------------------------------
        p_error_code := util_loc_pkg.c_ora_status_changing_failed;
        p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_status_changing_failed
          || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(v_ap_id_first)
          || util_pkg.c_msg_delim02 || 'prod_status=' || v_ap_pstatus_new
          || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
          || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
        );
        raise v_x_app;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    if 1 = 1
      and v_ap_id_first != p_ap_id
      and p_clear_sim_card_detail
    then
      ------------------------------
      api_sim_card_i_pkg.clear_sim_card_details
      (
        p_ap_id => v_ap_id_first,
        p_user_id => p_user_id
      );
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    if 1 = 1
      and v_ap_id_first != p_ap_id
    then
      ------------------------------
      v_bool := util_ext_ri.set_appa_status3_close
      (
        p_ap_id => v_ap_id_first,
        p_date => p_date,
        p_user_id => p_user_id,
        p_lock_sc => v_lock_sc,
        p_silent_proper_lack => v_silent_proper_lack,
        p_silent_break_actual => v_silent_break_actual,
        p_error_code => v_error_code2,
        p_error_message => v_error_message2
      );
      ------------------------------
      if not v_bool
      then
        ------------------------------
        p_error_code := util_loc_pkg.c_ora_unlinking_failed;
        p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_unlinking_failed
          || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(v_ap_id_first)
          || util_pkg.c_msg_delim02 || 'from pa'
          || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
          || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
        );
        raise v_x_app;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
  end if;
  ------------------------------
  --!_!link main msisdn with first sim
  ------------------------------
  ------------------------------
  --!_!set main msisdn status
  ------------------------------
  if p_set_previous_phone_status
  then
    ------------------------------
    v_bool := util_ext_ri.del_na_status3
    (
      p_na_id => p_na_id,
      p_date => p_date,
      p_user_id => p_user_id,
      p_lock_pn => v_lock_pn,
      p_silent_prev_lack => TRUE,
      p_error_code => v_error_code2,
      p_error_message => v_error_message2
    );
    ------------------------------
  elsif NOT p_not_change_msisdn_status
  then
    ------------------------------
    v_bool := util_ext_ri.set_na_status3
    (
      p_na_id => p_na_id,
      p_status => v_na_status_new,
      p_date => p_date,
      p_user_id => p_user_id,
      p_lock_pn => v_lock_pn,
      p_error_code => v_error_code2,
      p_error_message => v_error_message2
    );
    ------------------------------
  else
    ------------------------------
    v_bool := TRUE;
    ------------------------------
  end if;
  ------------------------------
  if not v_bool
  then
    ------------------------------
    p_error_code := util_loc_pkg.c_ora_status_changing_failed;
    p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_status_changing_failed
      || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(p_ap_id)
      || util_pkg.c_msg_delim02 || 'na_id=' || util_pkg.number_to_char(p_na_id)
      || util_pkg.c_msg_delim02 || 'status=' || v_na_status_new
      || util_pkg.c_msg_delim02 || 'p_set_previous_phone_status=' || util_pkg.bool_to_char(p_set_previous_phone_status)
      || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
      || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
    );
    raise v_x_app;
    ------------------------------
  end if;
  ------------------------------
  --!_!set main msisdn status
  ------------------------------
  ------------------------------
  if p_change_sim_prod_status
  then
    ------------------------------
    v_bool := util_ext_ri.set_ap_pstatus3
    (
      p_ap_id => p_ap_id,
      p_status => v_ap_pstatus_new,
      p_date => p_date,
      p_user_id => p_user_id,
      p_lock_sc => v_lock_sc,
      p_error_code => v_error_code2,
      p_error_message => v_error_message2
    );
    ------------------------------
    if not v_bool
    then
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_status_changing_failed;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_status_changing_failed
        || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(p_ap_id)
        || util_pkg.c_msg_delim02 || 'prod_status=' || v_ap_pstatus_new
        || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
        || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  if p_clear_sim_card_detail
  then
    ------------------------------
    api_sim_card_i_pkg.clear_sim_card_details
    (
      p_ap_id => p_ap_id,
      p_user_id => p_user_id
    );
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  --!_!set source sim status
  ------------------------------
  if NOT p_not_change_sim_status
  then
    ------------------------------
    v_status_tmp := v_ap_status_new;
    ------------------------------
    if 1 = 1
      and p_link_phone_and_first_sim
      and v_ap_id_first != p_ap_id --!_! v_ap_id_first initialized in prev if p_link_phone_and_first_sim
    then
      ------------------------------
      v_status_tmp := util_ri.c_APSH_CODE_NOT_ACTIVATED; --!_!
      ------------------------------
    end if;
    ------------------------------
    v_bool := util_ext_ri.set_ap_status3
    (
      p_ap_id => p_ap_id,
      p_status => v_status_tmp,
      p_date => p_date,
      p_user_id => p_user_id,
      p_lock_sc => v_lock_sc,
      p_error_code => v_error_code2,
      p_error_message => v_error_message2
    );
    ------------------------------
    if not v_bool
    then
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_status_changing_failed;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_status_changing_failed
        || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(p_ap_id)
        || util_pkg.c_msg_delim02 || 'status=' || v_status_tmp
        || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
        || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  --!_!set source sim status
  ------------------------------
  ------------------------------
  --!_!unlink sim from pa
  ------------------------------
  v_bool := util_ext_ri.set_appa_status3_close
  (
    p_ap_id => p_ap_id,
    p_date => p_date,
    p_user_id => p_user_id,
    p_lock_sc => v_lock_sc,
    p_silent_proper_lack => v_silent_proper_lack,
    p_silent_break_actual => v_silent_break_actual,
    p_error_code => v_error_code2,
    p_error_message => v_error_message2
  );
  ------------------------------
  if not v_bool
  then
    ------------------------------
    p_error_code := util_loc_pkg.c_ora_unlinking_failed;
    p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_unlinking_failed
      || util_pkg.c_msg_delim01 || 'ap_id=' || util_pkg.number_to_char(p_ap_id)
      || util_pkg.c_msg_delim02 || 'from pa'
      || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
      || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
    );
    raise v_x_app;
    ------------------------------
  end if;
  ------------------------------
  --!_!unlink sim from pa
  ------------------------------
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when v_x_app then
  ------------------------------
  rollback to sp_deactivate_msisdn;
  ------------------------------
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback to sp_deactivate_msisdn;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure deactivate_pa
(
  p_date date,
  p_user_id number,
  p_pa number,
  p_not_available_host_id number,
  p_set_empty_host boolean,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_silent_proper_lack boolean := true;
  v_silent_break_actual boolean := false;
  --
  v_x_app exception;
  v_bool boolean;
  --
  v_ap_id ct_number;
  --
  v_error_code2 number;
  v_error_message2 varchar2(4000);
  --
begin
  ------------------------------
  savepoint sp_deactivate_pa;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  util_pkg.XCheck_Cond_Missing(p_not_available_host_id is null, 'p_not_available_host_id');
  util_pkg.XCheck_Cond_Missing(p_set_empty_host is null, 'p_set_empty_host');
  ------------------------------
  ------------------------------
  --!_!link pa to na host
  ------------------------------
  if p_set_empty_host
  then
    ------------------------------
    ------------------------------
    v_ap_id := util_ri.get_pa_linked_ap_id2(p_pa, p_date);
    ------------------------------
    if util_pkg.get_count_ct_number(v_ap_id) > 0
    then
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_already_linked;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_already_linked
        || util_pkg.c_msg_delim01 || 'pa=' || util_pkg.number_to_char(p_pa)
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    v_bool := util_ext_ri.set_pah_status3_close
    (
      p_pa => p_pa,
      p_date => p_date,
      p_user_id => p_user_id,
      p_silent_proper_lack => v_silent_proper_lack,
      p_silent_break_actual => v_silent_break_actual,
      p_error_code => v_error_code2,
      p_error_message => v_error_message2
    );
    ------------------------------
    if not v_bool
    then
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_unlinking_failed;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_unlinking_failed
        || util_pkg.c_msg_delim01 || 'pa=' || util_pkg.number_to_char(p_pa)
        || util_pkg.c_msg_delim02 || 'from host'
        || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
        || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    v_bool := util_ext_ri.set_pah_status3
    (
      p_pa => p_pa,
      p_host_id => p_not_available_host_id,
      p_date => p_date,
      p_user_id => p_user_id,
      p_silent_proper_lack => v_silent_proper_lack,
      p_silent_break_actual => v_silent_break_actual,
      p_error_code => v_error_code2,
      p_error_message => v_error_message2
    );
    ------------------------------
    if not v_bool
    then
      ------------------------------
      p_error_code := util_loc_pkg.c_ora_unlinking_failed;
      p_error_message := util_pkg.cut_err_msg(util_loc_pkg.c_msg_unlinking_failed
        || util_pkg.c_msg_delim01 || 'pa=' || util_pkg.number_to_char(p_pa)
        || util_pkg.c_msg_delim02 || 'host_id=' || util_pkg.number_to_char(p_not_available_host_id)
        || util_pkg.c_msg_delim02 || 'error_code=' || util_pkg.number_to_char(v_error_code2)
        || util_pkg.c_msg_delim02 || 'error_message=' || v_error_message2
      );
      raise v_x_app;
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
  end if;
  ------------------------------
  --!_!link pa to na host
  ------------------------------
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when v_x_app then
  ------------------------------
  rollback to sp_deactivate_pa;
  ------------------------------
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback to sp_deactivate_pa;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure subscribers_deactivate
(
  p_msisdn util_pkg.cit_varchar_s,
  p_phone_status_code util_pkg.cit_varchar_s,
  p_phone_add_status_code util_pkg.cit_varchar_s,
  p_sim_status_code util_pkg.cit_varchar_s,
  p_ap_prod_status_code util_pkg.cit_varchar_s,
  p_date date,
  p_user_nt_name varchar2,
  p_change_sim_prod_status util_pkg.cit_number,
  p_clear_sim_card_detail util_pkg.cit_number,
  p_unlink_phone_and_sim util_pkg.cit_number,
  p_link_first_sim_and_phone util_pkg.cit_number,
  p_set_empty_balance_storage util_pkg.cit_number,
  p_set_previous_phone_status util_pkg.cit_number,
  p_not_change_sim_status util_pkg.cit_number,
  p_not_change_msisdn_status util_pkg.cit_number,
  p_error_code out number,
  p_error_message out varchar2,
  p_result out sys_refcursor
)
is
  v_date date := nvl(p_date, sysdate);
  v_user_id number;
  v_main_count number;
  v_not_available_host_id number;
  --
  v_pivot ct_number;
  v_msisdn ct_varchar_s;
  v_na_id ct_number;
  v_ap_id ct_number;
  v_pa ct_number;
  v_set_empty_host ct_number;
  v_err_code ct_number;
  v_err_msg ct_varchar;
  --
  v_error_code number;
  v_error_message varchar2(4000);
  v_x_app exception;
  --
  v_first_time boolean;
  v_pa_cur number;
  v_seq_num_cur ct_number;
  v_set_empty_host_cur boolean;
  v_index number;
  --
  v_num number;
  v_coll_num ct_number;
  --
  type lrt_pa_desc is record(pa number, seq_nums ct_number);
  type lct_pa_desc is table of lrt_pa_desc;
  v_pa_desc lct_pa_desc := lct_pa_desc();
  --
begin
  ------------------------------
  util_pkg.XCheckP_FSU_cit_varchar_s(p_msisdn, 'p_msisdn', FALSE);
  --
  --!_! elements can be nulls if not set p_-flag using this status_code
  util_pkg.XCheckP_cit_varchar_s(p_phone_status_code, 'p_phone_status_code', FALSE);
  util_pkg.XCheckP_cit_varchar_s(p_phone_add_status_code, 'p_phone_add_status_code', FALSE);
  util_pkg.XCheckP_cit_varchar_s(p_sim_status_code, 'p_sim_status_code', FALSE);
  util_pkg.XCheckP_cit_varchar_s(p_ap_prod_status_code, 'p_ap_prod_status_code', FALSE);
  --
  --!_!util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_nt_name is null, 'p_user_nt_name');
  util_pkg.XCheckP_FS_cit_number(p_change_sim_prod_status, 'p_change_sim_prod_status', FALSE);
  util_pkg.XCheckP_FS_cit_number(p_clear_sim_card_detail, 'p_clear_sim_card_detail', FALSE);
  util_pkg.XCheckP_FS_cit_number(p_unlink_phone_and_sim, 'p_unlink_phone_and_sim', FALSE);
  util_pkg.XCheckP_FS_cit_number(p_link_first_sim_and_phone, 'p_link_first_sim_and_phone', FALSE);
  util_pkg.XCheckP_FS_cit_number(p_set_empty_balance_storage, 'p_set_empty_balance_storage', FALSE);
  util_pkg.XCheckP_FS_cit_number(p_set_previous_phone_status, 'p_set_previous_phone_status', FALSE);
  util_pkg.XCheckP_FS_cit_number(p_not_change_sim_status, 'p_not_change_sim_status', FALSE);
  util_pkg.XCheckP_FS_cit_number(p_not_change_msisdn_status, 'p_not_change_msisdn_status', FALSE);
  ------------------------------
  v_main_count := p_msisdn.count;
  util_pkg.XCheck_Cond_Invalid(p_msisdn.count != v_main_count, 'p_msisdn.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_phone_status_code.count != v_main_count, 'p_phone_status_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_phone_add_status_code.count != v_main_count, 'p_phone_add_status_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_sim_status_code.count != v_main_count, 'p_sim_status_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_ap_prod_status_code.count != v_main_count, 'p_ap_prod_status_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_change_sim_prod_status.count != v_main_count, 'p_change_sim_prod_status.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_clear_sim_card_detail.count != v_main_count, 'p_clear_sim_card_detail.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_unlink_phone_and_sim.count != v_main_count, 'p_unlink_phone_and_sim.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_link_first_sim_and_phone.count != v_main_count, 'p_link_first_sim_and_phone.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_set_empty_balance_storage.count != v_main_count, 'p_set_empty_balance_storage.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_set_previous_phone_status.count != v_main_count, 'p_set_previous_phone_status.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_not_change_sim_status.count != v_main_count, 'p_not_change_sim_status.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_not_change_msisdn_status.count != v_main_count, 'p_not_change_msisdn_status.count != v_main_count');
  ------------------------------
  v_user_id := util_ri.xget_user_id(p_user_nt_name);
  ------------------------------
  v_not_available_host_id := util_ri.xget_not_available_host_id;
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  v_msisdn := util_pkg.cast_cit2ct_varchar_s(p_msisdn, FALSE);
  v_na_id := util_ri.get_na_id(v_msisdn, v_date, FALSE);
  v_ap_id := util_ri.get_linked_ap_id(v_na_id, NULL, v_date, FALSE);
  v_pa := util_ri.get_ap_pa(v_ap_id, v_date, FALSE);
  v_set_empty_host := util_pkg.cast_cit2ct_number(p_set_empty_balance_storage, FALSE);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_pivot) != v_main_count, 'v_pivot.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_msisdn) != v_main_count, 'v_msisdn.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_na_id) != v_main_count, 'v_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_ap_id) != v_main_count, 'v_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_pa) != v_main_count, 'v_pa.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_set_empty_host) != v_main_count, 'v_set_empty_host.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, NULL, NULL, v_err_code, v_err_msg, TRUE);
  ------------------------------
  ------------------------------
  v_first_time := true;
  ------------------------------
  for v_i in
  (
    select /*+ ordered use_hash(q0, q1, q2, q3)*/
      q0.seq_num, q1.na_id, q2.ap_id, q3.pa
      from
        (select column_value seq_num, rownum rn from table(v_pivot)) q0,
        (select column_value na_id, rownum rn from table(v_na_id)) q1,
        (select column_value ap_id, rownum rn from table(v_ap_id)) q2,
        (select column_value pa, rownum rn from table(v_pa)) q3
      where 1 = 1
      and q1.rn(+) = q0.rn
      and q2.rn(+) = q0.rn
      and q3.rn(+) = q0.rn
      --order by q0.rn
      order by q3.pa NULLS FIRST, q2.ap_id NULLS FIRST, q0.seq_num --!_! order is critical
  )
  loop
    ------------------------------
    if (1 = 0
      or v_first_time
      or NOT util_pkg.is_eq_null_vals_number(v_pa_cur, v_i.pa)
    )
    then
      ------------------------------
      v_first_time := false;
      ------------------------------
      v_pa_cur := v_i.pa;
      ------------------------------
      v_pa_desc.extend;
      v_pa_desc(v_pa_desc.last).pa := v_pa_cur;
      util_pkg.resize_ct_number(v_pa_desc(v_pa_desc.last).seq_nums, 0);
      ------------------------------
    end if;
    ------------------------------
    util_pkg.add_ct_number_val(v_pa_desc(v_pa_desc.last).seq_nums, v_i.seq_num);
    ------------------------------
  end loop;
  ------------------------------
  ------------------------------
  for v_i in v_pa_desc.first..v_pa_desc.last
  loop
    ------------------------------
    ------------------------------
    v_pa_cur := v_pa_desc(v_i).pa;
    v_seq_num_cur := v_pa_desc(v_i).seq_nums;
    v_set_empty_host_cur := FALSE;
    ------------------------------
    if v_pa_cur is not null
    then
      ------------------------------
      v_coll_num := util_pkg.filter_ct_number(v_set_empty_host, v_pivot, v_seq_num_cur, true);
      ------------------------------
      v_num := v_coll_num(v_coll_num.first);
      ------------------------------
      if util_pkg.index_of_ct_number(v_coll_num, v_num, 1, util_pkg.C_FALSE) != util_pkg.c_index_not_found
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_option_wrong, util_pkg.c_msg_option_wrong
          || util_pkg.c_msg_delim01 || 'not same p_set_empty_balance_storage'
          || util_pkg.c_msg_delim02 || 'pa=' || util_pkg.number_to_char(v_pa_cur)
        );
        ------------------------------
      end if;
      ------------------------------
      v_set_empty_host_cur := util_pkg.int_to_bool_2val(v_num);
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    begin
      ------------------------------
      ------------------------------
      savepoint sp_subscribers_deactivate_pa;
      ------------------------------
      ------------------------------
      for v_j in v_seq_num_cur.first..v_seq_num_cur.last
      loop
        ------------------------------
        v_index := v_seq_num_cur(v_j);
        ------------------------------
        deactivate_msisdn
        (
          p_date => v_date,
          p_user_id => v_user_id,
          p_na_id => v_na_id(v_index),
          p_ap_id => v_ap_id(v_index),
          p_na_status_new => p_phone_status_code(v_index),
          p_na_add_status_new => p_phone_add_status_code(v_index),
          p_ap_status_new => p_sim_status_code(v_index),
          p_ap_pstatus_new => p_ap_prod_status_code(v_index),
          p_change_sim_prod_status => util_pkg.int_to_bool_2val(p_change_sim_prod_status(v_index)),
          p_clear_sim_card_detail => util_pkg.int_to_bool_2val(p_clear_sim_card_detail(v_index)),
          p_unlink_phone_and_sim => util_pkg.int_to_bool_2val(p_unlink_phone_and_sim(v_index)),
          p_link_phone_and_first_sim => util_pkg.int_to_bool_2val(p_link_first_sim_and_phone(v_index)),
          p_set_previous_phone_status => util_pkg.int_to_bool_2val(p_set_previous_phone_status(v_index)),
          p_not_change_sim_status => util_pkg.int_to_bool_2val(p_not_change_sim_status(v_index)),
          p_not_change_msisdn_status => util_pkg.int_to_bool_2val(p_not_change_msisdn_status(v_index)),
          p_error_code => v_error_code,
          p_error_message => v_error_message
        );
        ------------------------------
        if util_pkg.is_error(v_error_code)
        then
          ------------------------------
          raise v_x_app;
          ------------------------------
        end if;
        ------------------------------
      end loop;
      ------------------------------
      ------------------------------
      if v_pa_cur is not null
      then
        ------------------------------
        deactivate_pa
        (
          p_date => v_date,
          p_user_id => v_user_id,
          p_pa => v_pa_cur,
          p_not_available_host_id => v_not_available_host_id,
          p_set_empty_host => v_set_empty_host_cur,
          p_error_code => v_error_code,
          p_error_message => v_error_message
        );
        ------------------------------
        if util_pkg.is_error(v_error_code)
        then
          ------------------------------
          raise v_x_app;
          ------------------------------
        end if;
        ------------------------------
      end if;
      ------------------------------
      ------------------------------
      util_pkg.set_ok(v_error_code, v_error_message);
      ------------------------------
    exception
    when v_x_app then
      ------------------------------
      rollback to sp_subscribers_deactivate_pa;
      ------------------------------
    when others then
      ------------------------------
      util_pkg.set_error(v_error_code, v_error_message);
      ------------------------------
      rollback to sp_subscribers_deactivate_pa;
      ------------------------------
    end;
    ------------------------------
    ------------------------------
    for v_j in v_seq_num_cur.first..v_seq_num_cur.last
    loop
      ------------------------------
      v_index := v_seq_num_cur(v_j);
      ------------------------------
      v_err_code(v_index) := v_error_code;
      v_err_msg(v_index) := v_error_message;
      ------------------------------
    end loop;
    ------------------------------
    ------------------------------
  end loop;
  ------------------------------
  ------------------------------
  open p_result for
  select /*+ ordered use_hash(q1, q2, q3)*/
    q1.rn, q1.msisdn, q2.error_code, q3.error_message
    from
      (select column_value msisdn, rownum rn from table(v_msisdn)) q1,
      (select column_value error_code, rownum rn from table(v_err_code)) q2,
      (select column_value error_message, rownum rn from table(v_err_msg)) q3
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    order by q1.rn
  ;
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
