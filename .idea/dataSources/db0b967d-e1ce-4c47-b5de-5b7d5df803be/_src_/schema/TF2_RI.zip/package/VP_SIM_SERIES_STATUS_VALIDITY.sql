CREATE package vp_sim_series_status_validity is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'SIM_SERIES_STATUS_VALIDITY';

----------------------------------!---------------------------------------------
  function get1_i(p_sim_series_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return sim_series_status_validity%rowtype;
  function get1(p_sim_series_id integer, p_date date) return sim_series_status_validity%rowtype;
  function xlock_get1(p_sim_series_id integer, p_date date) return sim_series_status_validity%rowtype;

----------------------------------!---------------------------------------------
  procedure xvalid_i(p_rec sim_series_status_validity%rowtype);

----------------------------------!---------------------------------------------
  function find_i_id(p_rec sim_series_status_validity%rowtype) return boolean;

  function find_i(p_rec sim_series_status_validity%rowtype) return boolean;
  procedure xunique_i(p_rec sim_series_status_validity%rowtype);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec sim_series_status_validity%rowtype);
  procedure close_i(p_rec sim_series_status_validity%rowtype);

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy sim_series_status_validity%rowtype);
  procedure version_change(p_rec in out nocopy sim_series_status_validity%rowtype);

  procedure version_close
  (
    p_sim_series_id integer,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------

end;
/
