CREATE package body VIRTUAL_SIM_PKG is

----------------------------------!---------------------------------------------
function make_virtual_imsi4msisdn(p_msisdns ct_varchar_s) return ct_varchar_s
is
  v_main_count number;
  v_res ct_varchar_s;
  v_imsi_prefix varchar2(50);
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns, 'p_msisdns');
  ------------------------------
  v_imsi_prefix := install_pkg.xget_option_str(c_opt_imsi_prefix, null);
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  ------------------------------
  util_pkg.resize_ct_varchar_s(v_res, v_main_count);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := v_imsi_prefix || p_msisdns(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_virtual_iccid4msisdn(p_msisdns ct_varchar_s) return ct_varchar_s
is
  v_main_count number;
  v_res ct_varchar_s;
  v_iccid_prefix varchar2(50);
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns, 'p_msisdns');
  ------------------------------
  v_iccid_prefix := install_pkg.xget_option_str(c_opt_iccid_prefix, null);
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  ------------------------------
  util_pkg.resize_ct_varchar_s(v_res, v_main_count);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := v_iccid_prefix || p_msisdns(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_sims
(
  p_imsis ct_varchar_s,
  p_iccids ct_varchar_s,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_out_ap_id out ct_number,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  --
  v_main_count number;
  v_length number;
  --
  v_ss_ids ct_number;
  --
  v_pivot ct_number;
  v_mark_err ct_number;
  --
  v_stub_varchar_s ct_varchar_s;
  v_stub_nvarchar_s ct_nvarchar_s;
  v_stub_number ct_number;
  --
  v_tmp_ap_ids ct_number;
  v_tmp_imsis ct_varchar_s;
  v_tmp_iccids ct_varchar_s;
  v_tmp_ss_ids ct_number;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
  v_res boolean;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_imsis);
  util_pkg.XCheckP_FS_ct_varchar_s(p_iccids);
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_imsis);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  util_pkg.resize_ct_number(p_out_ap_id, v_main_count);
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages); 
  ------------------------------
  v_ss_ids := util_ri.det_ss_id4imsi(p_imsis, p_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_ss_ids, null, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_sim_serie_not_found, util_loc_pkg.c_msg_sim_serie_not_found, util_pkg.c_true, p_error_codes, p_error_messages);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, TRUE, util_pkg.c_false, NULL);
  ------------------------------
  v_tmp_imsis := util_pkg.get_by_pos_ct_varchar_s(p_imsis, v_pivot, TRUE, NULL);
  v_tmp_iccids := util_pkg.get_by_pos_ct_varchar_s(p_iccids, v_pivot, TRUE, NULL);
  v_tmp_ss_ids := util_pkg.get_by_pos_ct_number(v_ss_ids, v_pivot, TRUE, NULL);
  ------------------------------
  v_length := util_pkg.get_count_ct_varchar_s(v_tmp_imsis);
  util_pkg.resize_ct_varchar_s(v_stub_varchar_s, v_length);
  util_pkg.resize_ct_nvarchar_s(v_stub_nvarchar_s, v_length);
  util_pkg.resize_ct_number(v_stub_number, v_length);
  ------------------------------
  v_res := util_ext_ri.ins_sim2
  (
    p_imsi => v_tmp_imsis,
    p_sn => v_tmp_iccids,
    p_pin => v_stub_varchar_s,
    p_pin2 => v_stub_varchar_s,
    p_puk2 => v_stub_varchar_s,
    p_puk => v_stub_varchar_s,
    p_ss_id => v_tmp_ss_ids,
    p_msisdn_bound => v_stub_varchar_s,
    p_personal_account => v_stub_number,
    p_ki => v_stub_nvarchar_s,
    p_adm1 => v_stub_nvarchar_s,
    p_access_control => v_stub_nvarchar_s,
    p_authent_type => v_stub_varchar_s,
    p_main_imsi_index => null,
    p_addition_imsi => null,
    p_status => util_ri.c_APSH_CODE_NOT_ACTIVATED,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_ap_ids => v_tmp_ap_ids,
    p_error_code => v_error_codes,
    p_error_message => v_error_messages
  );
  ------------------------------
  util_loc_pkg.touch_boolean(v_res); --!_!
  -------------------------------
  util_pkg.set_by_pos_ct_number(p_out_ap_id, v_tmp_ap_ids, v_pivot);
  util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes, v_pivot);
  util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages, v_pivot);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_msisdn
(
  p_msisdns ct_varchar_s,
  p_phone_status varchar2,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_na_no_ids in out nocopy ct_number,
  p_error_codes in out nocopy ct_number,
  p_error_messages in out nocopy ct_varchar
) return ct_number
is
  v_main_count number;
  v_msisdns ct_varchar_s;
  v_na_ids ct_number;
  v_na_status  ct_varchar_s;
  v_no_type  ct_varchar_s;
  --
  v_pivot ct_number;
  v_mark_err ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_error_codes) != v_main_count, 'p_error_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_error_messages) != v_main_count, 'p_error_messages.count != v_main_count');
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  v_mark_err := util_pkg.mark_val_ct_number(p_error_codes, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
  v_msisdns := util_pkg.get_marked_ct_varchar_s(p_msisdns, v_mark_err, FALSE, util_pkg.c_false, NULL);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_na_ids := util_ri.get_na_id(v_msisdns, p_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_na_ids, null, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found, util_pkg.c_true, p_error_codes, p_error_messages);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  if p_phone_status is not null
  then
    ------------------------------
    v_na_status := util_ri.get_na_status(v_na_ids, p_date, FALSE);
    v_mark_err := util_pkg.mark_val_ct_varchar_s(v_na_status, p_phone_status, util_pkg.c_false, util_pkg.c_true);
    util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_wrong_na_status, util_loc_pkg.c_msg_wrong_na_status, util_pkg.c_true, p_error_codes, p_error_messages);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
    ------------------------------
  end if;
  ------------------------------
  p_na_no_ids := mnp_pkg.get_no_own_any(v_na_ids, p_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(p_na_no_ids, null, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_net_op_not_found, util_loc_pkg.c_msg_net_op_not_found, util_pkg.c_true, p_error_codes, p_error_messages);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_no_type := util_ri.get_network_operator_type_x(p_na_no_ids, p_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_varchar_s(v_no_type, util_ri.c_NOPT_CODE_INTERNAL_FAKE, util_pkg.c_false, util_pkg.c_true); --!_!
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_wrong_no, util_loc_pkg.c_msg_wrong_no, util_pkg.c_true, p_error_codes, p_error_messages);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  return v_na_ids;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function prepare_virtual_sim
(
  p_imsi ct_varchar_s,
  p_iccid ct_varchar_s,
  p_no_ids ct_number,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes in out nocopy ct_number,
  p_error_messages in out nocopy ct_varchar
) return ct_number
is
  v_main_count number;
  v_imsis ct_varchar_s;
  v_iccids ct_varchar_s;
  v_ap_ids ct_number;
  v_ss_ids ct_number;
  v_ss_ids2 ct_number;
  v_ap_status ct_varchar_s;
  v_ap_type ct_varchar_s;
  v_no_ids ct_number;
  v_ap_no_ids ct_number;
  --
  v_pivot ct_number;
  v_mark_err ct_number;
  v_mark01 ct_number;
  v_tmp_map ct_number;
  --
  v_tmp_ap_id ct_number;
  v_tmp_imsi ct_varchar_s;
  v_tmp_iccid ct_varchar_s;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_varchar_s(p_imsi);
  util_pkg.XCheckP_FSU_ct_varchar_s(p_iccid);
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_imsi) != v_main_count, 'p_imsi.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_iccid) != v_main_count, 'p_iccid.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_error_codes) != v_main_count, 'p_error_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_error_messages) != v_main_count, 'p_error_messages.count != v_main_count');
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  v_mark_err := util_pkg.mark_val_ct_number(p_error_codes, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
  v_imsis := util_pkg.get_marked_ct_varchar_s(p_imsi, v_mark_err, FALSE, util_pkg.c_false, NULL);
  v_iccids := util_pkg.get_marked_ct_varchar_s(p_iccid, v_mark_err, FALSE, util_pkg.c_false, NULL);
  v_no_ids := util_pkg.get_marked_ct_number(p_no_ids, v_mark_err, FALSE, util_pkg.c_false, NULL);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_ss_ids := util_ri.det_ss_id4imsi(v_imsis, p_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_ss_ids, null, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_sim_serie_not_found, util_loc_pkg.c_msg_sim_serie_not_found, util_pkg.c_true, p_error_codes, p_error_messages);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_ap_type := util_ri.get_ss_type(v_ss_ids, p_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_varchar_s(v_ap_type, util_ri.c_AP_TYPE_VIRTUAL, util_pkg.c_false, util_pkg.c_true);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_wrong_ap_type, util_loc_pkg.c_msg_wrong_ap_type, util_pkg.c_true, p_error_codes, p_error_messages);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_ap_ids := util_ri.get_ap_id(v_iccids, p_date, FALSE);
  v_mark01 := util_pkg.mark_val_ct_number(v_ap_ids, null, util_pkg.c_true, util_pkg.c_false);
  v_tmp_map := util_pkg.get_marked_ct_number(v_pivot, v_mark01, TRUE, util_pkg.c_true, NULL);
  ------------------------------
  if util_pkg.get_count_ct_number(v_tmp_map) > 0
  then
    ------------------------------
    v_tmp_imsi := util_pkg.get_by_pos_ct_varchar_s(v_imsis, v_tmp_map, FALSE, NULL);
    v_tmp_iccid := util_pkg.get_by_pos_ct_varchar_s(v_iccids, v_tmp_map, FALSE, NULL);
    ------------------------------
    add_sims
    (
      p_imsis => v_tmp_imsi,
      p_iccids => v_tmp_iccid,
      p_date => p_date - util_pkg.c_dt_dif, --!_!
      p_user_id => p_user_id,
      p_break_on_error => p_break_on_error,
      p_out_ap_id => v_tmp_ap_id,
      p_error_codes => v_error_codes,
      p_error_messages => v_error_messages
    );
    ------------------------------
    util_pkg.set_by_pos_ct_number(v_ap_ids, v_tmp_ap_id, v_tmp_map);
    util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes, v_tmp_map);
    util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages, v_tmp_map);
    ------------------------------
  end if;
  ------------------------------
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_ss_ids2 := util_ri.get_ap_ss_id(v_ap_ids, p_date, FALSE);
  v_mark_err := util_pkg.cmp_ct_number(v_ss_ids, v_ss_ids2, util_pkg.c_false, util_pkg.c_true);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_wrong_sim_serie, util_loc_pkg.c_msg_wrong_sim_serie, util_pkg.c_true, p_error_codes, p_error_messages);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_ap_status := util_ri.get_ap_status(v_ap_ids, p_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_varchar_s(v_ap_status, util_ri.c_APSH_CODE_ACTIVATED, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_wrong_ap_status, util_loc_pkg.c_msg_wrong_ap_status, util_pkg.c_true, p_error_codes, p_error_messages);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_ap_no_ids := util_ri.get_ss_network_operator(v_ss_ids2, p_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_ap_no_ids, null, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_net_op_not_found, util_loc_pkg.c_msg_net_op_not_found, util_pkg.c_true, p_error_codes, p_error_messages);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_mark_err := util_pkg.cmp_ct_number(v_no_ids, v_ap_no_ids, util_pkg.c_false, util_pkg.c_true);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_not_same_no, util_loc_pkg.c_msg_not_same_no, util_pkg.c_true, p_error_codes, p_error_messages);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  return v_ap_ids;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure link_na_ap_pa_i
(
  p_na_ids ct_number,
  p_ap_ids ct_number,
  p_pa_ids ct_number,
  p_set_na_status ct_varchar_s,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes in out nocopy ct_number,
  p_error_messages in out nocopy ct_varchar
)
is
  v_main_count number;
  v_dates ct_date;
  v_na_ids ct_number;
  v_ap_ids ct_number;
  v_user_id ct_number;
  --
  v_pivot ct_number;
  v_mark_err ct_number;
  v_mark01 ct_number;
  v_tmp_map ct_number;
  v_res boolean;
  --
  v_tmp_na_id ct_number;
  v_tmp_na_status ct_varchar_s;
  v_tmp_ap_id ct_number;
  v_tmp_pa_id ct_number;
  v_tmp_link_type ct_varchar_s;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_ids) != v_main_count, 'p_na_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ap_ids) != v_main_count, 'p_ap_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_pa_ids) != v_main_count, 'p_pa_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_error_codes) != v_main_count, 'p_error_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_error_messages) != v_main_count, 'p_error_messages.count != v_main_count');
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  v_mark_err := util_pkg.mark_val_ct_number(p_error_codes, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
  v_na_ids := util_pkg.get_marked_ct_number(p_na_ids, v_mark_err, FALSE, util_pkg.c_false, NULL);
  v_ap_ids := util_pkg.get_marked_ct_number(p_ap_ids, v_mark_err, FALSE, util_pkg.c_false, NULL);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_tmp_map := util_pkg.get_by_pos_ct_number(v_pivot, v_pivot, TRUE, NULL);
  ------------------------------
  if util_pkg.get_count_ct_number(v_tmp_map) > 0
  then
    ------------------------------
    v_tmp_na_id := util_pkg.get_by_pos_ct_number(v_na_ids, v_tmp_map, TRUE, NULL);
    v_tmp_ap_id := util_pkg.get_by_pos_ct_number(v_ap_ids, v_tmp_map, TRUE, NULL);
    ------------------------------
    util_pkg.resize_ct_varchar_s(v_tmp_link_type, util_pkg.get_count_ct_number(v_tmp_map));
    util_pkg.fill_ct_varchar_s(v_tmp_link_type, util_ri.c_NAAP_LINK_TYPE_CODE_MAIN);
    ------------------------------
    v_res := util_ext_ri.set_naap_status2
    (
      p_na_id => v_tmp_na_id,
      p_ap_id => v_tmp_ap_id,
      p_link_type_code => v_tmp_link_type,
      p_date => p_date,
      p_user_id => p_user_id,
      p_break_on_error => p_break_on_error,
      p_lock_pn => TRUE,
      p_lock_sc => TRUE,
      p_silent_proper_lack => FALSE,
      p_silent_break_actual => TRUE,
      p_error_code => v_error_codes,
      p_error_message => v_error_messages
    );
    ------------------------------
    util_loc_pkg.touch_boolean(v_res); --!_!
    ------------------------------
    util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes, v_tmp_map);
    util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages, v_tmp_map);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
    v_mark_err := util_pkg.mark_val_ct_number(p_error_codes, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
    v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
    ------------------------------
  end if;
  ------------------------------
  v_tmp_map := util_pkg.get_by_pos_ct_number(v_pivot, v_pivot, TRUE, NULL);
  ------------------------------
  if util_pkg.get_count_ct_number(v_tmp_map) > 0
  then
    ------------------------------
    v_tmp_ap_id := util_pkg.get_by_pos_ct_number(v_ap_ids, v_tmp_map, TRUE, NULL);
    v_tmp_pa_id := util_pkg.get_by_pos_ct_number(p_pa_ids, v_tmp_map, TRUE, NULL);
    ------------------------------
    v_res := util_ext_ri.set_appa_status2
    (
      p_ap_id => v_tmp_ap_id,
      p_pa => v_tmp_pa_id,
      p_date => p_date,
      p_user_id => p_user_id,
      p_break_on_error => p_break_on_error,
      p_lock_sc => TRUE,
      p_silent_proper_lack => FALSE,
      p_silent_break_actual => TRUE,
      p_error_code => v_error_codes,
      p_error_message => v_error_messages
    );
    ------------------------------
    util_loc_pkg.touch_boolean(v_res); --!_!
    ------------------------------
    util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes, v_tmp_map);
    util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages, v_tmp_map);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
    v_mark_err := util_pkg.mark_val_ct_number(p_error_codes, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
    v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
    ------------------------------
  end if;
  ------------------------------
  v_mark01 := util_pkg.mark_val_ct_varchar_s(p_set_na_status, null, util_pkg.c_false, util_pkg.c_true);
  v_tmp_map := util_pkg.get_marked_ct_number(v_pivot, v_mark01, TRUE, util_pkg.c_true, NULL);
  ------------------------------
  if util_pkg.get_count_ct_number(v_tmp_map) > 0
  then
    ------------------------------
    v_tmp_na_id := util_pkg.get_by_pos_ct_number(v_na_ids, v_tmp_map, TRUE, NULL);
    v_tmp_na_status := util_pkg.get_by_pos_ct_varchar_s(p_set_na_status, v_tmp_map, TRUE, NULL);
    ------------------------------
    util_pkg.resize_ct_date(v_dates, util_pkg.get_count_ct_number(v_tmp_map));
    util_pkg.resize_ct_number(v_user_id, util_pkg.get_count_ct_number(v_tmp_map));
    util_pkg.fill_ct_date(v_dates, p_date);
    util_pkg.fill_ct_number(v_user_id, p_user_id);
    ------------------------------
    v_res := util_ext_ri.set_na_status
    (
      p_na_id => v_tmp_na_id,
      p_status => v_tmp_na_status,
      p_date => v_dates,
      p_user_id => v_user_id,
      p_break_on_error => p_break_on_error,
      p_lock_pn => TRUE,
      p_error_code => v_error_codes,
      p_error_message => v_error_messages
    );
    ------------------------------
    util_loc_pkg.touch_boolean(v_res); --!_!
    ------------------------------
    util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes, v_tmp_map);
    util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages, v_tmp_map);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_virtual_sim_i
(
  p_msisdns ct_varchar_s,
  p_phone_status varchar2,
  p_user_id number,
  p_break_on_error boolean,
  p_na_ids in out nocopy ct_number,
  p_ap_ids in out nocopy ct_number,
  p_imsis in out nocopy ct_varchar_s,
  p_iccids in out nocopy ct_varchar_s,
  p_error_codes in out nocopy ct_number,
  p_error_messages in out nocopy ct_varchar
)
is
  --
  v_main_count number;
  v_date date := sysdate;
  v_no_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_varchar_s(p_msisdns, 'p_msisdns');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  ------------------------------
  p_na_ids := check_msisdn
  (
    p_msisdns => p_msisdns,
    p_phone_status => p_phone_status,
    p_date => v_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_na_no_ids => v_no_ids,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
  p_imsis := make_virtual_imsi4msisdn(p_msisdns);
  p_iccids := make_virtual_iccid4msisdn(p_msisdns);
  ------------------------------
  p_ap_ids := prepare_virtual_sim
  (
    p_imsi => p_imsis,
    p_iccid => p_iccids,
    p_no_ids => v_no_ids,
    p_date => v_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_virtual_sim
(
  p_msisdns ct_varchar_s,
  p_user_id number,
  p_break_on_error boolean,
  p_imsis in out nocopy ct_varchar_s,
  p_iccids in out nocopy ct_varchar_s,
  p_error_codes in out nocopy ct_number,
  p_error_messages in out nocopy ct_varchar
)
is
  --
  v_main_count number;
  v_na_ids ct_number;
  v_ap_ids ct_number;
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FSU_ct_varchar_s(p_msisdns, 'p_msisdns');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  create_virtual_sim_i
  (
    p_msisdns => p_msisdns,
    p_phone_status => NULL,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_na_ids => v_na_ids,
    p_ap_ids => v_ap_ids,
    p_imsis => p_imsis,
    p_iccids => p_iccids,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_virtual_sim_and_link_pa
(
  p_msisdns ct_varchar_s,
  p_set_na_status ct_varchar_s,
  p_personal_accounts ct_number,
  p_user_id number,
  p_break_on_error boolean,
  p_imsis in out nocopy ct_varchar_s,
  p_iccids in out nocopy ct_varchar_s,
  p_error_codes in out nocopy ct_number,
  p_error_messages in out nocopy ct_varchar
)
is
  v_sp_name varchar2(30);
  --
  v_main_count number;
  v_date date := sysdate;
  v_na_ids ct_number;
  v_ap_ids ct_number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FSU_ct_varchar_s(p_msisdns, 'p_msisdns');
  util_pkg.XCheckP_FS_ct_number(p_personal_accounts, 'p_personal_accounts');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_set_na_status) != v_main_count, 'p_set_na_status.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_personal_accounts) != v_main_count, 'p_personal_accounts.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  create_virtual_sim_i
  (
    p_msisdns => p_msisdns,
    p_phone_status => util_ri.c_NASH_CODE_FREE,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_na_ids => v_na_ids,
    p_ap_ids => v_ap_ids,
    p_imsis => p_imsis,
    p_iccids => p_iccids,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
  link_na_ap_pa_i
  (
    p_na_ids => v_na_ids,
    p_ap_ids => v_ap_ids,
    p_pa_ids => p_personal_accounts,
    p_set_na_status => p_set_na_status,
    p_date => v_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
end;
/
