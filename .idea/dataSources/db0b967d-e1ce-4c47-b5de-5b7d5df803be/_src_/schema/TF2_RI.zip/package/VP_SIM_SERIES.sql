CREATE package VP_SIM_SERIES is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'SIM_SERIES';

----------------------------------!---------------------------------------------
  function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return sim_series%rowtype;

  function get1(p_id integer, p_date date) return sim_series%rowtype;
  function xget1(p_id integer, p_date date) return sim_series%rowtype;
  function xlock_get1(p_id integer, p_date date) return sim_series%rowtype;
  function xlock_xget1(p_id integer, p_date date) return sim_series%rowtype;

----------------------------------!---------------------------------------------
  function find_i_id(p_rec sim_series%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_imsi_start_imsi_end(p_rec sim_series%rowtype, p_check_only_other_ids boolean) return boolean;

  function find_i(p_rec sim_series%rowtype, p_check_only_other_ids boolean) return boolean;
  procedure xunique_i(p_rec sim_series%rowtype, p_check_only_other_ids boolean);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec sim_series%rowtype);
  procedure change_i(p_rec sim_series%rowtype);

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy sim_series%rowtype);
  procedure version_change(p_rec in out nocopy sim_series%rowtype, p_date_from_virt date := null);

  procedure version_close
  (
    p_id integer,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------

end;
/
