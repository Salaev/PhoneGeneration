CREATE PACKAGE PERSONAL_ACCOUNT_PCK IS

 -- Type for list of hosts (balance storage).
 TYPE t_host             IS TABLE OF VARCHAR2(50) INDEX BY BINARY_INTEGER;
 TYPE t_IMSI             IS TABLE OF VARCHAR2(20) INDEX BY BINARY_INTEGER;
 TYPE t_personal_account IS TABLE OF NUMBER(15) INDEX BY BINARY_INTEGER;

PROCEDURE Set_balance_storage(
  p_PA_l                  IN  common.t_number,
  p_host_l                IN  t_host,
  p_Start_Date            IN  DATE,
  p_user_login            IN  VARCHAR2,
  p_handle_tran            IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message          OUT VARCHAR2
);

PROCEDURE Set_Personal_Account_For_SIM(
  p_sn_l                  IN  common.t_ICCID,
  p_PA_l                  IN  common.t_number,
  p_user_login            IN  VARCHAR2,
  p_handle_tran            IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list           OUT SYS_REFCURSOR
);

PROCEDURE set_distribution_platform(
  p_personal_accounts_list   IN  common.t_number,
  p_host_id                  IN  NUMBER,
  p_error_code               OUT NUMBER,
  p_error_message            OUT VARCHAR2
);

PROCEDURE get_distribution_platform(
  p_personal_accounts_list    IN  common.t_number,
  p_date                      IN  DATE,
  p_cur_distribution_platform IN OUT RSIG_UTILS.REF_CURSOR,
  p_error_code                OUT NUMBER,
  p_error_message             OUT VARCHAR2
);

PROCEDURE check_distribution_platform(
  p_personal_account          IN  NUMBER,
  p_check_date                IN  DATE,
  p_check_result              OUT NUMBER,
  p_error_code                OUT NUMBER,
  p_error_message             OUT VARCHAR2
);

PROCEDURE delete_balance_storage_for_pa(
  p_personal_accounts_list    IN  common.t_number,
  p_user_login                IN  VARCHAR2,
  p_date_of_operation         IN  DATE,
  p_handle_tran               IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error               IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                OUT NUMBER,
  p_error_message             OUT VARCHAR2
);

procedure Get_Type_Host_By_PAList(
    p_personal_account_numbers       in  common.t_number,
    p_hosts                          out sys_refcursor,
    p_error_code                     out number,
    p_error_message                  out varchar2
  );

PROCEDURE Get_Balance_Storage_by_PA(
  p_PA_list                IN  t_personal_account,
  p_start_date             IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);

END;
/
