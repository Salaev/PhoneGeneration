CREATE PACKAGE BODY "CATALOGUES" IS
------------------------------------------------------------------------------------------------------------------------------
--  Get_AP_Statuses
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_AP_Statuses(
  p_status_code_from       IN  access_point_status_history.access_point_status_code%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'CATALOGUES';
  v_procedure_name        VARCHAR2(30) := 'Get_AP_Statuses';
  v_event_source          VARCHAR2(60);
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

---------------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
  SELECT aps.ACCESS_POINT_STATUS_CODE,
         aps.ACCESS_POINT_STATUS_NAME
  FROM access_point_status aps
  WHERE aps.ACCESS_POINT_STATUS_CODE IN (
        SELECT ast.status_code_to
        FROM ap_status_trans ast
        WHERE (ast.deleted IS NULL OR ast.deleted>SYSDATE)
          AND (ast.status_code_from=TRIM(p_status_code_from) OR
               (ast.status_code_from IS NULL AND p_status_code_from IS NULL) OR
                trim(p_status_code_from)='%')
          AND ASt.is_bp_only=rsig_utils.c_NO)
    AND (aps.DELETED IS NULL OR aps.DELETED>SYSDATE)
  ORDER BY aps.ACCESS_POINT_STATUS_NAME;

---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    OPEN p_result_list FOR SELECT p_error_code FROM dual;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_AP_Statuses;

------------------------------------------------------------------------------------------------------------------------------
--  Get_AP_Prod_Statuses
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_AP_Prod_Statuses(
  p_status_code_from       IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_is_bp                  IN  varchar2,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'CATALOGUES';
  v_procedure_name        VARCHAR2(30) := 'Get_AP_Prod_Statuses';
  v_event_source          VARCHAR2(60);
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

---------------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
  SELECT aps.ap_prod_status_code,
         aps.ap_prod_status_name
  FROM ap_prod_status aps
  WHERE aps.ap_prod_status_code IN (
        SELECT apst.status_code_to
        FROM ap_prod_status_trans apst
        WHERE (apst.deleted IS NULL OR apst.deleted>SYSDATE)
          AND (apst.is_bp_only=p_is_bp OR p_is_bp=rsig_utils.c_YES)
          AND (apst.status_code_from=p_status_code_from OR
               (apst.status_code_from IS NULL AND p_status_code_from IS NULL) OR
                p_status_code_from='%'))
    AND (aps.deleted IS NULL OR aps.deleted>SYSDATE)
  ORDER BY aps.ap_prod_status_name;

---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    OPEN p_result_list FOR SELECT p_error_code FROM dual;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_AP_Prod_Statuses;

------------------------------------------------------------------------------------------------------------------------------
--  Get_NA_Statuses_Tran_Reasons
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_AP_Statuses_Tran_Reasons(
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'CATALOGUES';
  v_procedure_name        VARCHAR2(30) := 'Get_AP_Statuses_Tran_Reasons';
  v_event_source          VARCHAR2(60);
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

---------------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
  select DISTINCT
         aps.ACCESS_POINT_STATUS_CODE,
         aps.ACCESS_POINT_STATUS_NAME,
         k.ap_trans_reason_code,
         k.ap_trans_reason_name,
         k.status_code_from
  from access_point_status aps
  LEFT JOIN (SELECT atr.ap_trans_reason_code,
                    atr.ap_trans_reason_name,
                    ast.status_code_from,
                    ast.status_code_to
             FROM ap_status_trans ast
             JOIN ap_trans_reason atr ON atr.ap_status_trans_code=ast.ap_status_trans_code
             WHERE ast.deleted IS NULL
               AND atr.deleted IS NULL) k ON aps.ACCESS_POINT_STATUS_CODE=k.status_code_to
  WHERE aps.DELETED IS NULL
  ORDER BY aps.ACCESS_POINT_STATUS_CODE,k.ap_trans_reason_code;

---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    OPEN p_result_list FOR SELECT p_error_code FROM dual;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_AP_Statuses_Tran_Reasons;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Initial_AP_Prod_Status
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Products(
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'CATALOGUES';
  v_procedure_name        VARCHAR2(30) := 'Get_Products';
  v_event_source          VARCHAR2(60);
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

---------------------------------------------------------------------------------------------------------
  OPEN p_result_list FOR
  SELECT p.product_code,
         p.product_name,
         p.supplier_code
  FROM product p
  ORDER BY p.product_name;
---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    OPEN p_result_list FOR SELECT p_error_code FROM dual;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_Products;

------------------------------------------------------------------------------------------------------------------------------
--  Get_NA_Statuses_Tran_Reasons
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_NA_Statuses_Tran_Reasons(
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'CATALOGUES';
  v_procedure_name        VARCHAR2(30) := 'Get_NA_Statuses_Tran_Reasons';
  v_event_source          VARCHAR2(60);
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

---------------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
  select DISTINCT
         nas.NET_ADDRESS_STATUS_CODE,
         nas.NET_ADDRESS_STATUS_NAME,
         k.na_trans_reason_code,
         k.na_trans_reason_name,
         k.status_code_from
  from Network_Address_Status nas
  LEFT JOIN (SELECT ntr.na_trans_reason_code,
                    ntr.na_trans_reason_name,
                    nst.status_code_from,
                    nst.status_code_to
             FROM na_status_trans nst
             JOIN na_trans_reason ntr ON ntr.na_status_trans_code=nst.na_status_trans_code
             WHERE nst.deleted IS NULL
               AND ntr.deleted IS NULL) k ON nas.NET_ADDRESS_STATUS_CODE=k.status_code_to
  WHERE nas.DELETED IS NULL
  ORDER BY nas.NET_ADDRESS_STATUS_CODE,k.na_trans_reason_code;

---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    OPEN p_result_list FOR SELECT p_error_code FROM dual;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_NA_Statuses_Tran_Reasons;

------------------------------------------------------------------------------------------------------------------------------
--  Get_NA_Statuses
------------------------------------------------------------------------------------------------------------------------------
procedure get_na_statuses
(
    p_na_status_from varchar2,
    p_allow_inernal_status number,
    p_raise_error char default rsig_utils.c_no,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor
)
is
  v_date date := sysdate;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_allow_inernal_status is null, 'p_allow_inernal_status');
  ------------------------------
  if p_na_status_from is null
  then
    ------------------------------
    open p_result_list for
  select /*+ ordered use_hash(nst nas ntr) full(nst) full(nas) full(ntr)*/
      nas.net_address_status_code,
      nas.net_address_status_name,
      ntr.na_trans_reason_code,
      ntr.na_trans_reason_name
    from na_status_trans nst, network_address_status nas, na_trans_reason ntr
    where 1 = 1
    and nst.is_bp_only=util_ri.c_NO
    and nst.status_code_from is null
    and nvl(nst.deleted, v_date + util_ri.c_dummy_date_shift) > v_date
    and decode(p_allow_inernal_status, util_pkg.c_true, util_pkg.c_true, decode(util_ri.valid_code2(nst.status_code_to), util_ri.c_nash_code_internal, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    and nas.net_address_status_code = nst.status_code_to
    and nvl(nas.deleted, v_date + util_ri.c_dummy_date_shift) > v_date
    and ntr.na_status_trans_code(+) = nst.na_status_trans_code
    and nvl(ntr.deleted(+), v_date + util_ri.c_dummy_date_shift) > v_date
    order by nas.net_address_status_code
    ;
    ------------------------------
  else
    ------------------------------
    open p_result_list for
  select /*+ ordered use_hash(nst nas ntr) full(nst) full(nas) full(ntr)*/
      nas.net_address_status_code,
      nas.net_address_status_name,
      ntr.na_trans_reason_code,
      ntr.na_trans_reason_name
    from na_status_trans nst, network_address_status nas, na_trans_reason ntr
    where 1 = 1
    and nst.is_bp_only=util_ri.c_NO
    and upper(trim(nst.status_code_from))=upper(trim(p_na_status_from))
    and nvl(nst.deleted, v_date + util_ri.c_dummy_date_shift) > v_date
    and decode(p_allow_inernal_status, util_pkg.c_true, util_pkg.c_true, decode(util_ri.valid_code2(nst.status_code_to), util_ri.c_nash_code_internal, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    and nas.net_address_status_code = nst.status_code_to
    and nvl(nas.deleted, v_date + util_ri.c_dummy_date_shift) > v_date
    and ntr.na_status_trans_code(+) = nst.na_status_trans_code
    and nvl(ntr.deleted(+), v_date + util_ri.c_dummy_date_shift) > v_date
    order by nas.net_address_status_code
    ;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  open p_result_list for select p_error_code from dual;
  ------------------------------
  if upper(p_raise_error)=rsig_utils.c_yes then
    raise;
  end if;
  ------------------------------
end;

END;
/
