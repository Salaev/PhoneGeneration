CREATE package body util_coll_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  c_no_value_null_number         constant number := null;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_marked2_ct_number(p_vals ct_number, p_marks ct_number, p_trim_unmarked boolean, p_mark_value number := util_pkg.c_true, p_no_value number := null) return ct_number
is
  v_res ct_number;
  v_trim_unmarked number := util_pkg.bool_to_int_2val(p_trim_unmarked);
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_unmarked is null, 'p_trim_unmarked');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_unmarked, util_pkg.c_false, util_pkg.c_true, decode(q2.mark, p_mark_value, util_pkg.c_true, util_pkg.c_false)) = util_pkg.c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked2_ct_date(p_vals ct_date, p_marks ct_number, p_trim_unmarked boolean, p_mark_value number := util_pkg.c_true, p_no_value date := null) return ct_date
is
  v_res ct_date;
  v_trim_unmarked number := util_pkg.bool_to_int_2val(p_trim_unmarked);
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_unmarked is null, 'p_trim_unmarked');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_date(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_unmarked, util_pkg.c_false, util_pkg.c_true, decode(q2.mark, p_mark_value, util_pkg.c_true, util_pkg.c_false)) = util_pkg.c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked2_ct_varchar_s(p_vals ct_varchar_s, p_marks ct_number, p_trim_unmarked boolean, p_mark_value number := util_pkg.c_true, p_no_value varchar2 := null) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_trim_unmarked number := util_pkg.bool_to_int_2val(p_trim_unmarked);
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_unmarked is null, 'p_trim_unmarked');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_unmarked, util_pkg.c_false, util_pkg.c_true, decode(q2.mark, p_mark_value, util_pkg.c_true, util_pkg.c_false)) = util_pkg.c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked2_ct_varchar(p_vals ct_varchar, p_marks ct_number, p_trim_unmarked boolean, p_mark_value number := util_pkg.c_true, p_no_value varchar2 := null) return ct_varchar
is
  v_res ct_varchar;
  v_trim_unmarked number := util_pkg.bool_to_int_2val(p_trim_unmarked);
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_unmarked is null, 'p_trim_unmarked');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_unmarked, util_pkg.c_false, util_pkg.c_true, decode(q2.mark, p_mark_value, util_pkg.c_true, util_pkg.c_false)) = util_pkg.c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked2_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marks ct_number, p_trim_unmarked boolean, p_mark_value number := util_pkg.c_true, p_no_value nvarchar2 := null) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_trim_unmarked number := util_pkg.bool_to_int_2val(p_trim_unmarked);
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_unmarked is null, 'p_trim_unmarked');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_unmarked, util_pkg.c_false, util_pkg.c_true, decode(q2.mark, p_mark_value, util_pkg.c_true, util_pkg.c_false)) = util_pkg.c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked2_ct_nvarchar(p_vals ct_nvarchar, p_marks ct_number, p_trim_unmarked boolean, p_mark_value number := util_pkg.c_true, p_no_value nvarchar2 := null) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_trim_unmarked number := util_pkg.bool_to_int_2val(p_trim_unmarked);
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_unmarked is null, 'p_trim_unmarked');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select column_value val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_unmarked, util_pkg.c_false, util_pkg.c_true, decode(q2.mark, p_mark_value, util_pkg.c_true, util_pkg.c_false)) = util_pkg.c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_marked_ol_ct_number(p_vals ct_number, p_marks ct_number) return ct_number
is
begin
  ------------------------------
  return get_marked2_ct_number(p_vals => p_vals, p_marks => p_marks, p_trim_unmarked => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ol_ct_date(p_vals ct_date, p_marks ct_number) return ct_date
is
begin
  ------------------------------
  return get_marked2_ct_date(p_vals => p_vals, p_marks => p_marks, p_trim_unmarked => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ol_ct_varchar_s(p_vals ct_varchar_s, p_marks ct_number) return ct_varchar_s
is
begin
  ------------------------------
  return get_marked2_ct_varchar_s(p_vals => p_vals, p_marks => p_marks, p_trim_unmarked => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ol_ct_varchar(p_vals ct_varchar, p_marks ct_number) return ct_varchar
is
begin
  ------------------------------
  return get_marked2_ct_varchar(p_vals => p_vals, p_marks => p_marks, p_trim_unmarked => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ol_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marks ct_number) return ct_nvarchar_s
is
begin
  ------------------------------
  return get_marked2_ct_nvarchar_s(p_vals => p_vals, p_marks => p_marks, p_trim_unmarked => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ol_ct_nvarchar(p_vals ct_nvarchar, p_marks ct_number) return ct_nvarchar
is
begin
  ------------------------------
  return get_marked2_ct_nvarchar(p_vals => p_vals, p_marks => p_marks, p_trim_unmarked => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unmarked_ol_ct_number(p_vals ct_number, p_marks ct_number) return ct_number
is
begin
  ------------------------------
  return get_marked2_ct_number(p_vals => p_vals, p_marks => p_marks, p_trim_unmarked => true, p_mark_value => util_pkg.c_false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unmarked_ol_ct_date(p_vals ct_date, p_marks ct_number) return ct_date
is
begin
  ------------------------------
  return get_marked2_ct_date(p_vals => p_vals, p_marks => p_marks, p_trim_unmarked => true, p_mark_value => util_pkg.c_false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unmarked_ol_ct_varchar_s(p_vals ct_varchar_s, p_marks ct_number) return ct_varchar_s
is
begin
  ------------------------------
  return get_marked2_ct_varchar_s(p_vals => p_vals, p_marks => p_marks, p_trim_unmarked => true, p_mark_value => util_pkg.c_false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unmarked_ol_ct_varchar(p_vals ct_varchar, p_marks ct_number) return ct_varchar
is
begin
  ------------------------------
  return get_marked2_ct_varchar(p_vals => p_vals, p_marks => p_marks, p_trim_unmarked => true, p_mark_value => util_pkg.c_false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unmarked_ol_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marks ct_number) return ct_nvarchar_s
is
begin
  ------------------------------
  return get_marked2_ct_nvarchar_s(p_vals => p_vals, p_marks => p_marks, p_trim_unmarked => true, p_mark_value => util_pkg.c_false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unmarked_ol_ct_nvarchar(p_vals ct_nvarchar, p_marks ct_number) return ct_nvarchar
is
begin
  ------------------------------
  return get_marked2_ct_nvarchar(p_vals => p_vals, p_marks => p_marks, p_trim_unmarked => true, p_mark_value => util_pkg.c_false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_by_pos_ol_ct_number(p_vals ct_number, p_positions ct_number) return ct_number
is
begin
  ------------------------------
  return util_pkg.get_by_pos_ct_number(p_vals => p_vals, p_positions => p_positions, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ol_ct_date(p_vals ct_date, p_positions ct_number) return ct_date
is
begin
  ------------------------------
  return util_pkg.get_by_pos_ct_date(p_vals => p_vals, p_positions => p_positions, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ol_ct_varchar_s(p_vals ct_varchar_s, p_positions ct_number) return ct_varchar_s
is
begin
  ------------------------------
  return util_pkg.get_by_pos_ct_varchar_s(p_vals => p_vals, p_positions => p_positions, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ol_ct_varchar(p_vals ct_varchar, p_positions ct_number) return ct_varchar
is
begin
  ------------------------------
  return util_pkg.get_by_pos_ct_varchar(p_vals => p_vals, p_positions => p_positions, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ol_ct_nvarchar_s(p_vals ct_nvarchar_s, p_positions ct_number) return ct_nvarchar_s
is
begin
  ------------------------------
  return util_pkg.get_by_pos_ct_nvarchar_s(p_vals => p_vals, p_positions => p_positions, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ol_ct_nvarchar(p_vals ct_nvarchar, p_positions ct_number) return ct_nvarchar
is
begin
  ------------------------------
  return util_pkg.get_by_pos_ct_nvarchar(p_vals => p_vals, p_positions => p_positions, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_mark2pos_ol(p_marks ct_number) return ct_number
is
begin
  ------------------------------
  return util_pkg.mark2pos(p_marks => p_marks, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unmark2pos_ol(p_marks ct_number) return ct_number
is
begin
  ------------------------------
  return util_pkg.mark2pos(p_marks => p_marks, p_trim_empty => true, p_mark_value => util_pkg.c_false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function unique_ol_ct_number(p_vals ct_number) return ct_number
is
begin
  ------------------------------
  return util_pkg.unique_ct_number(p_coll => p_vals, p_save_order => false, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_ol_ct_date(p_vals ct_date) return ct_date
is
begin
  ------------------------------
  return util_pkg.unique_ct_date(p_coll => p_vals, p_save_order => false, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_ol_ct_varchar_s(p_vals ct_varchar_s) return ct_varchar_s
is
begin
  ------------------------------
  return util_pkg.unique_ct_varchar_s(p_coll => p_vals, p_save_order => false, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_ol_ct_varchar(p_vals ct_varchar) return ct_varchar
is
begin
  ------------------------------
  return util_pkg.unique_ct_varchar(p_coll => p_vals, p_save_order => false, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_ol_ct_nvarchar_s(p_vals ct_nvarchar_s) return ct_nvarchar_s
is
begin
  ------------------------------
  return util_pkg.unique_ct_nvarchar_s(p_coll => p_vals, p_save_order => false, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function unique_ol_ct_nvarchar(p_vals ct_nvarchar) return ct_nvarchar
is
begin
  ------------------------------
  return util_pkg.unique_ct_nvarchar(p_coll => p_vals, p_save_order => false, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function imark_unique_ct_number(p_vals ct_number, p_not_unique boolean, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number
is
  v_vals ct_number;
  v_main_count number;
  v_mark_value number;
  v_unmark_value number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_not_unique is null, 'p_not_unique');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_vals);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  select
    val
  bulk collect into
    v_vals --!_!unique list of not unique vals
  from
    (select column_value val, rownum rn from table(p_vals)) q
  where 1 = 1
  group by
    val
  having
    count(1) > 1
  order by
    val
  ;
  ------------------------------
  if p_not_unique
  then
    ------------------------------
    v_mark_value := p_mark_value;
    v_unmark_value := p_unmark_value;
    ------------------------------
  else
    ------------------------------
    v_mark_value := p_unmark_value;
    v_unmark_value := p_mark_value;
    ------------------------------
  end if;
  ------------------------------
  return util_pkg.mark_ct_number(p_vals => p_vals, p_marker_vals => v_vals, p_mark_value => v_mark_value, p_unmark_value => v_unmark_value, p_x_marker_vals_not_unique => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function imark_unique_ct_date(p_vals ct_date, p_not_unique boolean, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number
is
  v_vals ct_date;
  v_main_count number;
  v_mark_value number;
  v_unmark_value number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_not_unique is null, 'p_not_unique');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_date(p_vals);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  select
    val
  bulk collect into
    v_vals --!_!unique list of not unique vals
  from
    (select column_value val, rownum rn from table(p_vals)) q
  where 1 = 1
  group by
    val
  having
    count(1) > 1
  order by
    val
  ;
  ------------------------------
  if p_not_unique
  then
    ------------------------------
    v_mark_value := p_mark_value;
    v_unmark_value := p_unmark_value;
    ------------------------------
  else
    ------------------------------
    v_mark_value := p_unmark_value;
    v_unmark_value := p_mark_value;
    ------------------------------
  end if;
  ------------------------------
  return util_pkg.mark_ct_date(p_vals => p_vals, p_marker_vals => v_vals, p_mark_value => v_mark_value, p_unmark_value => v_unmark_value, p_x_marker_vals_not_unique => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function imark_unique_ct_varchar_s(p_vals ct_varchar_s, p_not_unique boolean, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number
is
  v_vals ct_varchar_s;
  v_main_count number;
  v_mark_value number;
  v_unmark_value number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_not_unique is null, 'p_not_unique');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_vals);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  select
    val
  bulk collect into
    v_vals --!_!unique list of not unique vals
  from
    (select column_value val, rownum rn from table(p_vals)) q
  where 1 = 1
  group by
    val
  having
    count(1) > 1
  order by
    val
  ;
  ------------------------------
  if p_not_unique
  then
    ------------------------------
    v_mark_value := p_mark_value;
    v_unmark_value := p_unmark_value;
    ------------------------------
  else
    ------------------------------
    v_mark_value := p_unmark_value;
    v_unmark_value := p_mark_value;
    ------------------------------
  end if;
  ------------------------------
  return util_pkg.mark_ct_varchar_s(p_vals => p_vals, p_marker_vals => v_vals, p_mark_value => v_mark_value, p_unmark_value => v_unmark_value, p_x_marker_vals_not_unique => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function imark_unique_ct_varchar(p_vals ct_varchar, p_not_unique boolean, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number
is
  v_vals ct_varchar;
  v_main_count number;
  v_mark_value number;
  v_unmark_value number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_not_unique is null, 'p_not_unique');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar(p_vals);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  select
    val
  bulk collect into
    v_vals --!_!unique list of not unique vals
  from
    (select column_value val, rownum rn from table(p_vals)) q
  where 1 = 1
  group by
    val
  having
    count(1) > 1
  order by
    val
  ;
  ------------------------------
  if p_not_unique
  then
    ------------------------------
    v_mark_value := p_mark_value;
    v_unmark_value := p_unmark_value;
    ------------------------------
  else
    ------------------------------
    v_mark_value := p_unmark_value;
    v_unmark_value := p_mark_value;
    ------------------------------
  end if;
  ------------------------------
  return util_pkg.mark_ct_varchar(p_vals => p_vals, p_marker_vals => v_vals, p_mark_value => v_mark_value, p_unmark_value => v_unmark_value, p_x_marker_vals_not_unique => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function imark_unique_ct_nvarchar_s(p_vals ct_nvarchar_s, p_not_unique boolean, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number
is
  v_vals ct_nvarchar_s;
  v_main_count number;
  v_mark_value number;
  v_unmark_value number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_not_unique is null, 'p_not_unique');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_vals);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  select
    val
  bulk collect into
    v_vals --!_!unique list of not unique vals
  from
    (select column_value val, rownum rn from table(p_vals)) q
  where 1 = 1
  group by
    val
  having
    count(1) > 1
  order by
    val
  ;
  ------------------------------
  if p_not_unique
  then
    ------------------------------
    v_mark_value := p_mark_value;
    v_unmark_value := p_unmark_value;
    ------------------------------
  else
    ------------------------------
    v_mark_value := p_unmark_value;
    v_unmark_value := p_mark_value;
    ------------------------------
  end if;
  ------------------------------
  return util_pkg.mark_ct_nvarchar_s(p_vals => p_vals, p_marker_vals => v_vals, p_mark_value => v_mark_value, p_unmark_value => v_unmark_value, p_x_marker_vals_not_unique => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function imark_unique_ct_nvarchar(p_vals ct_nvarchar, p_not_unique boolean, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number
is
  v_vals ct_nvarchar;
  v_main_count number;
  v_mark_value number;
  v_unmark_value number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_not_unique is null, 'p_not_unique');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar(p_vals);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  select
    val
  bulk collect into
    v_vals --!_!unique list of not unique vals
  from
    (select column_value val, rownum rn from table(p_vals)) q
  where 1 = 1
  group by
    val
  having
    count(1) > 1
  order by
    val
  ;
  ------------------------------
  if p_not_unique
  then
    ------------------------------
    v_mark_value := p_mark_value;
    v_unmark_value := p_unmark_value;
    ------------------------------
  else
    ------------------------------
    v_mark_value := p_unmark_value;
    v_unmark_value := p_mark_value;
    ------------------------------
  end if;
  ------------------------------
  return util_pkg.mark_ct_nvarchar(p_vals => p_vals, p_marker_vals => v_vals, p_mark_value => v_mark_value, p_unmark_value => v_unmark_value, p_x_marker_vals_not_unique => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_unique_ct_number(p_vals ct_number) return ct_number
is
begin
  ------------------------------
  return imark_unique_ct_number(p_vals => p_vals, p_not_unique => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_unique_ct_date(p_vals ct_date) return ct_number
is
begin
  ------------------------------
  return imark_unique_ct_date(p_vals => p_vals, p_not_unique => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_unique_ct_varchar_s(p_vals ct_varchar_s) return ct_number
is
begin
  ------------------------------
  return imark_unique_ct_varchar_s(p_vals => p_vals, p_not_unique => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_unique_ct_varchar(p_vals ct_varchar) return ct_number
is
begin
  ------------------------------
  return imark_unique_ct_varchar(p_vals => p_vals, p_not_unique => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_unique_ct_nvarchar_s(p_vals ct_nvarchar_s) return ct_number
is
begin
  ------------------------------
  return imark_unique_ct_nvarchar_s(p_vals => p_vals, p_not_unique => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_unique_ct_nvarchar(p_vals ct_nvarchar) return ct_number
is
begin
  ------------------------------
  return imark_unique_ct_nvarchar(p_vals => p_vals, p_not_unique => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_not_unique_ct_number(p_vals ct_number) return ct_number
is
begin
  ------------------------------
  return imark_unique_ct_number(p_vals => p_vals, p_not_unique => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_not_unique_ct_date(p_vals ct_date) return ct_number
is
begin
  ------------------------------
  return imark_unique_ct_date(p_vals => p_vals, p_not_unique => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_not_unique_ct_varchar_s(p_vals ct_varchar_s) return ct_number
is
begin
  ------------------------------
  return imark_unique_ct_varchar_s(p_vals => p_vals, p_not_unique => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_not_unique_ct_varchar(p_vals ct_varchar) return ct_number
is
begin
  ------------------------------
  return imark_unique_ct_varchar(p_vals => p_vals, p_not_unique => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_not_unique_ct_nvarchar_s(p_vals ct_nvarchar_s) return ct_number
is
begin
  ------------------------------
  return imark_unique_ct_nvarchar_s(p_vals => p_vals, p_not_unique => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_not_unique_ct_nvarchar(p_vals ct_nvarchar) return ct_number
is
begin
  ------------------------------
  return imark_unique_ct_nvarchar(p_vals => p_vals, p_not_unique => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function trim_ct_varchar_s(p_coll ct_varchar_s) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_coll);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := p_coll;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := trim(v_res(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function trim_ct_varchar(p_coll ct_varchar) return ct_varchar
is
  v_res ct_varchar;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar(p_coll);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := p_coll;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := trim(v_res(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function trim_ct_nvarchar_s(p_coll ct_nvarchar_s) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_coll);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := p_coll;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := trim(v_res(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function trim_ct_nvarchar(p_coll ct_nvarchar) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar(p_coll);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := p_coll;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := trim(v_res(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function map_pos1in2_ct_number(p_vals1_not_unique ct_number, p_vals2_unique ct_number) return ct_number
is
begin
  ------------------------------
  util_pkg.xis_unique_ct_number(p_vals2_unique, 'p_vals2_unique');
  ------------------------------
  return util_pkg.map_ct_number(p_vals1 => p_vals1_not_unique, p_vals2 => p_vals2_unique, p_trim_empty => false, p_reverse => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function map_pos1in2_ct_date(p_vals1_not_unique ct_date, p_vals2_unique ct_date) return ct_number
is
begin
  ------------------------------
  util_pkg.xis_unique_ct_date(p_vals2_unique, 'p_vals2_unique');
  ------------------------------
  return util_pkg.map_ct_date(p_vals1 => p_vals1_not_unique, p_vals2 => p_vals2_unique, p_trim_empty => false, p_reverse => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function map_pos1in2_ct_varchar_s(p_vals1_not_unique ct_varchar_s, p_vals2_unique ct_varchar_s) return ct_number
is
begin
  ------------------------------
  util_pkg.xis_unique_ct_varchar_s(p_vals2_unique, 'p_vals2_unique');
  ------------------------------
  return util_pkg.map_ct_varchar_s(p_vals1 => p_vals1_not_unique, p_vals2 => p_vals2_unique, p_trim_empty => false, p_reverse => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function map_pos1in2_ct_varchar(p_vals1_not_unique ct_varchar, p_vals2_unique ct_varchar) return ct_number
is
begin
  ------------------------------
  util_pkg.xis_unique_ct_varchar(p_vals2_unique, 'p_vals2_unique');
  ------------------------------
  return util_pkg.map_ct_varchar(p_vals1 => p_vals1_not_unique, p_vals2 => p_vals2_unique, p_trim_empty => false, p_reverse => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function map_pos1in2_ct_nvarchar_s(p_vals1_not_unique ct_nvarchar_s, p_vals2_unique ct_nvarchar_s) return ct_number
is
begin
  ------------------------------
  util_pkg.xis_unique_ct_nvarchar_s(p_vals2_unique, 'p_vals2_unique');
  ------------------------------
  return util_pkg.map_ct_nvarchar_s(p_vals1 => p_vals1_not_unique, p_vals2 => p_vals2_unique, p_trim_empty => false, p_reverse => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function map_pos1in2_ct_nvarchar(p_vals1_not_unique ct_nvarchar, p_vals2_unique ct_nvarchar) return ct_number
is
begin
  ------------------------------
  util_pkg.xis_unique_ct_nvarchar(p_vals2_unique, 'p_vals2_unique');
  ------------------------------
  return util_pkg.map_ct_nvarchar(p_vals1 => p_vals1_not_unique, p_vals2 => p_vals2_unique, p_trim_empty => false, p_reverse => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mapnn_pos1in2_ct_number(p_vals1_not_unique ct_number, p_vals2_unique ct_number) return ct_number
is
begin
  ------------------------------
  util_pkg.xis_unique_ct_number(util_pkg.filter_val_ct_number_1val(p_vals => p_vals2_unique, p_filter_val => NULL, p_include_by_filter => FALSE), 'p_vals2_unique');
  ------------------------------
  return util_pkg.map_ct_number(p_vals1 => p_vals1_not_unique, p_vals2 => p_vals2_unique, p_trim_empty => false, p_reverse => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mapnn_pos1in2_ct_date(p_vals1_not_unique ct_date, p_vals2_unique ct_date) return ct_number
is
begin
  ------------------------------
  util_pkg.xis_unique_ct_date(util_pkg.filter_val_ct_date_1val(p_vals => p_vals2_unique, p_filter_val => NULL, p_include_by_filter => FALSE), 'p_vals2_unique');
  ------------------------------
  return util_pkg.map_ct_date(p_vals1 => p_vals1_not_unique, p_vals2 => p_vals2_unique, p_trim_empty => false, p_reverse => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mapnn_pos1in2_ct_varchar_s(p_vals1_not_unique ct_varchar_s, p_vals2_unique ct_varchar_s) return ct_number
is
begin
  ------------------------------
  util_pkg.xis_unique_ct_varchar_s(util_pkg.filter_val_ct_varchar_s_1val(p_vals => p_vals2_unique, p_filter_val => NULL, p_include_by_filter => FALSE), 'p_vals2_unique');
  ------------------------------
  return util_pkg.map_ct_varchar_s(p_vals1 => p_vals1_not_unique, p_vals2 => p_vals2_unique, p_trim_empty => false, p_reverse => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mapnn_pos1in2_ct_varchar(p_vals1_not_unique ct_varchar, p_vals2_unique ct_varchar) return ct_number
is
begin
  ------------------------------
  util_pkg.xis_unique_ct_varchar(util_pkg.filter_val_ct_varchar_1val(p_vals => p_vals2_unique, p_filter_val => NULL, p_include_by_filter => FALSE), 'p_vals2_unique');
  ------------------------------
  return util_pkg.map_ct_varchar(p_vals1 => p_vals1_not_unique, p_vals2 => p_vals2_unique, p_trim_empty => false, p_reverse => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mapnn_pos1in2_ct_nvarchar_s(p_vals1_not_unique ct_nvarchar_s, p_vals2_unique ct_nvarchar_s) return ct_number
is
begin
  ------------------------------
  util_pkg.xis_unique_ct_nvarchar_s(util_pkg.filter_val_ct_nvarchar_s_1val(p_vals => p_vals2_unique, p_filter_val => NULL, p_include_by_filter => FALSE), 'p_vals2_unique');
  ------------------------------
  return util_pkg.map_ct_nvarchar_s(p_vals1 => p_vals1_not_unique, p_vals2 => p_vals2_unique, p_trim_empty => false, p_reverse => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mapnn_pos1in2_ct_nvarchar(p_vals1_not_unique ct_nvarchar, p_vals2_unique ct_nvarchar) return ct_number
is
begin
  ------------------------------
  util_pkg.xis_unique_ct_nvarchar(util_pkg.filter_val_ct_nvarchar_1val(p_vals => p_vals2_unique, p_filter_val => NULL, p_include_by_filter => FALSE), 'p_vals2_unique');
  ------------------------------
  return util_pkg.map_ct_nvarchar(p_vals1 => p_vals1_not_unique, p_vals2 => p_vals2_unique, p_trim_empty => false, p_reverse => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function apply_map_ct_number(p_size2 number, p_vals_not_unique_size1 ct_number, p_vals_pos1in2_size1 ct_number, p_no_value number := null) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_marks ct_number;
  v_vals_not_unique ct_number;
  v_vals_pos1in2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_size0(p_size2, 'p_size2');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_vals_not_unique_size1);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_vals_not_unique_size1) != v_main_count, 'p_vals_not_unique_size1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_vals_pos1in2_size1) != v_main_count, 'p_vals_pos1in2_size1.count != v_main_count');
  ------------------------------
  if p_size2 = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := util_pkg.make_ct_number(p_size2, p_no_value);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_vals_pos1in2_size1, c_no_value_null_number);
  ------------------------------
  v_vals_not_unique := get_unmarked_ol_ct_number(p_vals_not_unique_size1, v_marks);
  v_vals_pos1in2 := get_unmarked_ol_ct_number(p_vals_pos1in2_size1, v_marks);
  ------------------------------
  util_pkg.set_by_pos2_ct_number(p_coll => v_res, p_vals => v_vals_not_unique, p_positions => v_vals_pos1in2);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function apply_map_ct_date(p_size2 number, p_vals_not_unique_size1 ct_date, p_vals_pos1in2_size1 ct_number, p_no_value date := null) return ct_date
is
  v_res ct_date;
  v_main_count number;
  v_marks ct_number;
  v_vals_not_unique ct_date;
  v_vals_pos1in2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_size0(p_size2, 'p_size2');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_date(p_vals_not_unique_size1);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_vals_not_unique_size1) != v_main_count, 'p_vals_not_unique_size1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_vals_pos1in2_size1) != v_main_count, 'p_vals_pos1in2_size1.count != v_main_count');
  ------------------------------
  if p_size2 = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := util_pkg.make_ct_date(p_size2, p_no_value);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_vals_pos1in2_size1, c_no_value_null_number);
  ------------------------------
  v_vals_not_unique := get_unmarked_ol_ct_date(p_vals_not_unique_size1, v_marks);
  v_vals_pos1in2 := get_unmarked_ol_ct_number(p_vals_pos1in2_size1, v_marks);
  ------------------------------
  util_pkg.set_by_pos2_ct_date(p_coll => v_res, p_vals => v_vals_not_unique, p_positions => v_vals_pos1in2);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function apply_map_ct_varchar_s(p_size2 number, p_vals_not_unique_size1 ct_varchar_s, p_vals_pos1in2_size1 ct_number, p_no_value varchar2 := null) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_marks ct_number;
  v_vals_not_unique ct_varchar_s;
  v_vals_pos1in2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_size0(p_size2, 'p_size2');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_vals_not_unique_size1);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_vals_not_unique_size1) != v_main_count, 'p_vals_not_unique_size1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_vals_pos1in2_size1) != v_main_count, 'p_vals_pos1in2_size1.count != v_main_count');
  ------------------------------
  if p_size2 = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := util_pkg.make_ct_varchar_s(p_size2, p_no_value);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_vals_pos1in2_size1, c_no_value_null_number);
  ------------------------------
  v_vals_not_unique := get_unmarked_ol_ct_varchar_s(p_vals_not_unique_size1, v_marks);
  v_vals_pos1in2 := get_unmarked_ol_ct_number(p_vals_pos1in2_size1, v_marks);
  ------------------------------
  util_pkg.set_by_pos2_ct_varchar_s(p_coll => v_res, p_vals => v_vals_not_unique, p_positions => v_vals_pos1in2);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function apply_map_ct_varchar(p_size2 number, p_vals_not_unique_size1 ct_varchar, p_vals_pos1in2_size1 ct_number, p_no_value varchar2 := null) return ct_varchar
is
  v_res ct_varchar;
  v_main_count number;
  v_marks ct_number;
  v_vals_not_unique ct_varchar;
  v_vals_pos1in2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_size0(p_size2, 'p_size2');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar(p_vals_not_unique_size1);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_vals_not_unique_size1) != v_main_count, 'p_vals_not_unique_size1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_vals_pos1in2_size1) != v_main_count, 'p_vals_pos1in2_size1.count != v_main_count');
  ------------------------------
  if p_size2 = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := util_pkg.make_ct_varchar(p_size2, p_no_value);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_vals_pos1in2_size1, c_no_value_null_number);
  ------------------------------
  v_vals_not_unique := get_unmarked_ol_ct_varchar(p_vals_not_unique_size1, v_marks);
  v_vals_pos1in2 := get_unmarked_ol_ct_number(p_vals_pos1in2_size1, v_marks);
  ------------------------------
  util_pkg.set_by_pos2_ct_varchar(p_coll => v_res, p_vals => v_vals_not_unique, p_positions => v_vals_pos1in2);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function apply_map_ct_nvarchar_s(p_size2 number, p_vals_not_unique_size1 ct_nvarchar_s, p_vals_pos1in2_size1 ct_number, p_no_value nvarchar2 := null) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_main_count number;
  v_marks ct_number;
  v_vals_not_unique ct_nvarchar_s;
  v_vals_pos1in2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_size0(p_size2, 'p_size2');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_vals_not_unique_size1);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_vals_not_unique_size1) != v_main_count, 'p_vals_not_unique_size1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_vals_pos1in2_size1) != v_main_count, 'p_vals_pos1in2_size1.count != v_main_count');
  ------------------------------
  if p_size2 = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := util_pkg.make_ct_nvarchar_s(p_size2, p_no_value);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_vals_pos1in2_size1, c_no_value_null_number);
  ------------------------------
  v_vals_not_unique := get_unmarked_ol_ct_nvarchar_s(p_vals_not_unique_size1, v_marks);
  v_vals_pos1in2 := get_unmarked_ol_ct_number(p_vals_pos1in2_size1, v_marks);
  ------------------------------
  util_pkg.set_by_pos2_ct_nvarchar_s(p_coll => v_res, p_vals => v_vals_not_unique, p_positions => v_vals_pos1in2);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function apply_map_ct_nvarchar(p_size2 number, p_vals_not_unique_size1 ct_nvarchar, p_vals_pos1in2_size1 ct_number, p_no_value nvarchar2 := null) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_main_count number;
  v_marks ct_number;
  v_vals_not_unique ct_nvarchar;
  v_vals_pos1in2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_size0(p_size2, 'p_size2');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar(p_vals_not_unique_size1);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar(p_vals_not_unique_size1) != v_main_count, 'p_vals_not_unique_size1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_vals_pos1in2_size1) != v_main_count, 'p_vals_pos1in2_size1.count != v_main_count');
  ------------------------------
  if p_size2 = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := util_pkg.make_ct_nvarchar(p_size2, p_no_value);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_vals_pos1in2_size1, c_no_value_null_number);
  ------------------------------
  v_vals_not_unique := get_unmarked_ol_ct_nvarchar(p_vals_not_unique_size1, v_marks);
  v_vals_pos1in2 := get_unmarked_ol_ct_number(p_vals_pos1in2_size1, v_marks);
  ------------------------------
  util_pkg.set_by_pos2_ct_nvarchar(p_coll => v_res, p_vals => v_vals_not_unique, p_positions => v_vals_pos1in2);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function restore_map_ct_number(p_vals_size2 ct_number, p_vals_pos1in2_size1 ct_number) return ct_number
is
  v_main_count number;
  v_pivot ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_vals_size2);
  ------------------------------
  v_pivot := util_pkg.make_pivot_or_empty(v_main_count);
  ------------------------------
  return util_pkg.join2pivot_ct_number(p_vals => p_vals_size2, p_ids_pivot_main => p_vals_pos1in2_size1, p_ids_pivot_for_vals => v_pivot);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function restore_map_ct_date(p_vals_size2 ct_date, p_vals_pos1in2_size1 ct_number) return ct_date
is
  v_main_count number;
  v_pivot ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_date(p_vals_size2);
  ------------------------------
  v_pivot := util_pkg.make_pivot_or_empty(v_main_count);
  ------------------------------
  return util_pkg.join2pivot_ct_date(p_vals => p_vals_size2, p_ids_pivot_main => p_vals_pos1in2_size1, p_ids_pivot_for_vals => v_pivot);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function restore_map_ct_varchar_s(p_vals_size2 ct_varchar_s, p_vals_pos1in2_size1 ct_number) return ct_varchar_s
is
  v_main_count number;
  v_pivot ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_vals_size2);
  ------------------------------
  v_pivot := util_pkg.make_pivot_or_empty(v_main_count);
  ------------------------------
  return util_pkg.join2pivot_ct_varchar_s(p_vals => p_vals_size2, p_ids_pivot_main => p_vals_pos1in2_size1, p_ids_pivot_for_vals => v_pivot);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function restore_map_ct_varchar(p_vals_size2 ct_varchar, p_vals_pos1in2_size1 ct_number) return ct_varchar
is
  v_main_count number;
  v_pivot ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar(p_vals_size2);
  ------------------------------
  v_pivot := util_pkg.make_pivot_or_empty(v_main_count);
  ------------------------------
  return util_pkg.join2pivot_ct_varchar(p_vals => p_vals_size2, p_ids_pivot_main => p_vals_pos1in2_size1, p_ids_pivot_for_vals => v_pivot);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function restore_map_ct_nvarchar_s(p_vals_size2 ct_nvarchar_s, p_vals_pos1in2_size1 ct_number) return ct_nvarchar_s
is
  v_main_count number;
  v_pivot ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_vals_size2);
  ------------------------------
  v_pivot := util_pkg.make_pivot_or_empty(v_main_count);
  ------------------------------
  return util_pkg.join2pivot_ct_nvarchar_s(p_vals => p_vals_size2, p_ids_pivot_main => p_vals_pos1in2_size1, p_ids_pivot_for_vals => v_pivot);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function restore_map_ct_nvarchar(p_vals_size2 ct_nvarchar, p_vals_pos1in2_size1 ct_number) return ct_nvarchar
is
  v_main_count number;
  v_pivot ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar(p_vals_size2);
  ------------------------------
  v_pivot := util_pkg.make_pivot_or_empty(v_main_count);
  ------------------------------
  return util_pkg.join2pivot_ct_nvarchar(p_vals => p_vals_size2, p_ids_pivot_main => p_vals_pos1in2_size1, p_ids_pivot_for_vals => v_pivot);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function mark_ambig_vals_ct_number(p_vals ct_number, p_val_ids_ambig ct_number) return ct_number
is
  v_main_count number;
  v_positions ct_number;
  v_vals ct_number;
  v_ids ct_number;
  v_ids_ambig ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_vals) != v_main_count, 'p_vals.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_val_ids_ambig) != v_main_count, 'p_val_ids_ambig.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  v_positions := get_mark2pos_ol(mark_not_unique_ct_number(p_val_ids_ambig));
  ------------------------------
  if util_pkg.get_count_ct_number(v_positions) = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  v_vals := get_by_pos_ol_ct_number(p_vals => p_vals, p_positions => v_positions);
  v_ids := get_by_pos_ol_ct_number(p_vals => p_val_ids_ambig, p_positions => v_positions);
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q2.id
  bulk collect into
    v_ids_ambig
  from
    (select column_value val, rownum rn from table(v_vals)) q1,
    (select column_value id, rownum rn from table(v_ids)) q2
  where 1 = 1
    and q2.rn(+) = q1.rn
  group by
    q2.id
  having
    count(distinct q1.val) > 1
  order by
    q2.id
  ;
  ------------------------------
  return util_pkg.mark_ct_number(p_val_ids_ambig, v_ids_ambig);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_ambig_vals_ct_date(p_vals ct_date, p_val_ids_ambig ct_number) return ct_number
is
  v_main_count number;
  v_positions ct_number;
  v_vals ct_date;
  v_ids ct_number;
  v_ids_ambig ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_date(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_vals) != v_main_count, 'p_vals.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_val_ids_ambig) != v_main_count, 'p_val_ids_ambig.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  v_positions := get_mark2pos_ol(mark_not_unique_ct_number(p_val_ids_ambig));
  ------------------------------
  if util_pkg.get_count_ct_number(v_positions) = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  v_vals := get_by_pos_ol_ct_date(p_vals => p_vals, p_positions => v_positions);
  v_ids := get_by_pos_ol_ct_number(p_vals => p_val_ids_ambig, p_positions => v_positions);
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q2.id
  bulk collect into
    v_ids_ambig
  from
    (select column_value val, rownum rn from table(v_vals)) q1,
    (select column_value id, rownum rn from table(v_ids)) q2
  where 1 = 1
    and q2.rn(+) = q1.rn
  group by
    q2.id
  having
    count(distinct q1.val) > 1
  order by
    q2.id
  ;
  ------------------------------
  return util_pkg.mark_ct_number(p_val_ids_ambig, v_ids_ambig);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_ambig_vals_ct_varchar_s(p_vals ct_varchar_s, p_val_ids_ambig ct_number) return ct_number
is
  v_main_count number;
  v_positions ct_number;
  v_vals ct_varchar_s;
  v_ids ct_number;
  v_ids_ambig ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_vals) != v_main_count, 'p_vals.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_val_ids_ambig) != v_main_count, 'p_val_ids_ambig.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  v_positions := get_mark2pos_ol(mark_not_unique_ct_number(p_val_ids_ambig));
  ------------------------------
  if util_pkg.get_count_ct_number(v_positions) = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  v_vals := get_by_pos_ol_ct_varchar_s(p_vals => p_vals, p_positions => v_positions);
  v_ids := get_by_pos_ol_ct_number(p_vals => p_val_ids_ambig, p_positions => v_positions);
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q2.id
  bulk collect into
    v_ids_ambig
  from
    (select column_value val, rownum rn from table(v_vals)) q1,
    (select column_value id, rownum rn from table(v_ids)) q2
  where 1 = 1
    and q2.rn(+) = q1.rn
  group by
    q2.id
  having
    count(distinct q1.val) > 1
  order by
    q2.id
  ;
  ------------------------------
  return util_pkg.mark_ct_number(p_val_ids_ambig, v_ids_ambig);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_ambig_vals_ct_varchar(p_vals ct_varchar, p_val_ids_ambig ct_number) return ct_number
is
  v_main_count number;
  v_positions ct_number;
  v_vals ct_varchar;
  v_ids ct_number;
  v_ids_ambig ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(p_vals) != v_main_count, 'p_vals.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_val_ids_ambig) != v_main_count, 'p_val_ids_ambig.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  v_positions := get_mark2pos_ol(mark_not_unique_ct_number(p_val_ids_ambig));
  ------------------------------
  if util_pkg.get_count_ct_number(v_positions) = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  v_vals := get_by_pos_ol_ct_varchar(p_vals => p_vals, p_positions => v_positions);
  v_ids := get_by_pos_ol_ct_number(p_vals => p_val_ids_ambig, p_positions => v_positions);
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q2.id
  bulk collect into
    v_ids_ambig
  from
    (select column_value val, rownum rn from table(v_vals)) q1,
    (select column_value id, rownum rn from table(v_ids)) q2
  where 1 = 1
    and q2.rn(+) = q1.rn
  group by
    q2.id
  having
    count(distinct q1.val) > 1
  order by
    q2.id
  ;
  ------------------------------
  return util_pkg.mark_ct_number(p_val_ids_ambig, v_ids_ambig);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_ambig_vals_ct_nvarchar_s(p_vals ct_nvarchar_s, p_val_ids_ambig ct_number) return ct_number
is
  v_main_count number;
  v_positions ct_number;
  v_vals ct_nvarchar_s;
  v_ids ct_number;
  v_ids_ambig ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_vals) != v_main_count, 'p_vals.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_val_ids_ambig) != v_main_count, 'p_val_ids_ambig.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  v_positions := get_mark2pos_ol(mark_not_unique_ct_number(p_val_ids_ambig));
  ------------------------------
  if util_pkg.get_count_ct_number(v_positions) = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  v_vals := get_by_pos_ol_ct_nvarchar_s(p_vals => p_vals, p_positions => v_positions);
  v_ids := get_by_pos_ol_ct_number(p_vals => p_val_ids_ambig, p_positions => v_positions);
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q2.id
  bulk collect into
    v_ids_ambig
  from
    (select column_value val, rownum rn from table(v_vals)) q1,
    (select column_value id, rownum rn from table(v_ids)) q2
  where 1 = 1
    and q2.rn(+) = q1.rn
  group by
    q2.id
  having
    count(distinct q1.val) > 1
  order by
    q2.id
  ;
  ------------------------------
  return util_pkg.mark_ct_number(p_val_ids_ambig, v_ids_ambig);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_ambig_vals_ct_nvarchar(p_vals ct_nvarchar, p_val_ids_ambig ct_number) return ct_number
is
  v_main_count number;
  v_positions ct_number;
  v_vals ct_nvarchar;
  v_ids ct_number;
  v_ids_ambig ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar(p_vals) != v_main_count, 'p_vals.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_val_ids_ambig) != v_main_count, 'p_val_ids_ambig.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  v_positions := get_mark2pos_ol(mark_not_unique_ct_number(p_val_ids_ambig));
  ------------------------------
  if util_pkg.get_count_ct_number(v_positions) = 0
  then
    ------------------------------
    return null;
    ------------------------------
  end if;
  ------------------------------
  v_vals := get_by_pos_ol_ct_nvarchar(p_vals => p_vals, p_positions => v_positions);
  v_ids := get_by_pos_ol_ct_number(p_vals => p_val_ids_ambig, p_positions => v_positions);
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q2.id
  bulk collect into
    v_ids_ambig
  from
    (select column_value val, rownum rn from table(v_vals)) q1,
    (select column_value id, rownum rn from table(v_ids)) q2
  where 1 = 1
    and q2.rn(+) = q1.rn
  group by
    q2.id
  having
    count(distinct q1.val) > 1
  order by
    q2.id
  ;
  ------------------------------
  return util_pkg.mark_ct_number(p_val_ids_ambig, v_ids_ambig);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
