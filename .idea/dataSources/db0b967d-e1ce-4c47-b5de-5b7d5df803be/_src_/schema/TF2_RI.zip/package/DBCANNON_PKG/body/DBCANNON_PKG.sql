CREATE package body DBCANNON_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure GetHostByMsisdn(p_msisdns util_pkg.cit_varchar_s, p_error_code out number, p_error_message out varchar2, p_result out sys_refcursor)
is
  v_msisdns ct_varchar_s;
  v_date date := sysdate;
begin
  ------------------------------
  v_msisdns := util_pkg.cast_cit2ct_varchar_s(p_msisdns, true);
  ------------------------------
  --v_msisdns := util_pkg.unique_ct_varchar_s(v_msisdns, FALSE, TRUE, NULL);
  ------------------------------
  open p_result for
select
  q.msisdn,
  decode(q.cnt, 1, q.host_id, to_number(null)) host_id,
  decode(q.cnt, 1, q.host_type_code, to_char(null)) host_type_code,
  case
      when q.cnt > 1 then util_pkg.c_ora_object_not_unique
      when q.host_id is null then util_pkg.c_ora_object_not_found
      else util_pkg.c_ora_ok
  end error_code,
  case
      when q.cnt > 1 then util_pkg.c_msg_object_not_unique
      when q.host_id is null then util_pkg.c_msg_object_not_found
      else util_pkg.c_msg_ok
  end error_message
from (select /*+ ordered use_nl(z, pn, naap, appa, pah, h)
          index_asc(pn, UK_PHONE_NUM_PHONE_NUMBER)
          index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID2)
          index_asc(appa, I_APPA_ACCESS_POINT_ID)
          index_asc(pah, PK_PER_ACCOUNT_HISTORY)
          index_asc(h, PK_HOST)
          */
          z.msisdn,
          min(h.host_id) host_id,
          min(h.host_type_code) host_type_code,
          count(1) cnt,
          z.rn
          from (select column_value msisdn, rownum rn from table(cast(v_msisdns as ct_varchar_s))) z,
              phone_number pn,
              network_address_access_point naap,
              access_point_personal_account appa,
              personal_account_history pah,
              host h
          where 1 = 1
          and pn.international_format(+) = z.msisdn
          and nvl(pn.deleted(+), v_date + util_ri.c_dummy_date_shift) > v_date
          and naap.network_address_id(+) = pn.network_address_id
          and v_date between naap.from_date(+) and nvl(naap.to_date(+), to_date('01.01.4000', 'dd.mm.yyyy'))
          and appa.access_point_id(+) = naap.access_point_id
          and v_date between appa.from_date(+) and nvl(appa.to_date(+), v_date)
          and pah.personal_account(+) = appa.personal_account
          and v_date between pah.start_date(+) and nvl(pah.end_date(+), v_date)
          and h.host_id(+) = pah.balance_storage
          and nvl(h.deleted(+), v_date + util_ri.c_dummy_date_shift) > v_date
          group by z.msisdn, z.rn
      ) q
      order by rn
  ;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end DBCANNON_PKG;
/
