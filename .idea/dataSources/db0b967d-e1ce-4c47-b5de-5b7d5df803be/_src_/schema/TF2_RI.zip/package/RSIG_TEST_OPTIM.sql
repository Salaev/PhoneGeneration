CREATE PACKAGE          "RSIG_TEST_OPTIM" is

  -- Author  : JHOLUB
  -- Created : 18.8.2004 12:00:04
  -- Purpose : for testing and improve performance

 TYPE T_VAR2_255 IS TABLE OF VARCHAR2(255) INDEX BY BINARY_INTEGER;
 TYPE T_DATE IS TABLE OF DATE INDEX BY BINARY_INTEGER;

 c_MAIN_LINK_TYPE       NETWORK_ADDRESS_ACCESS_POINT.link_type_code%TYPE := 'M'; -- constant representing "STANDARD" link type


 PROCEDURE Get_Phones_By_SIM_list (
 p_ACCESS_POINT_DESC  IN T_VAR2_255,
 p_DATE_TIME    IN T_DATE,
-- p_NETWORK_ADDRESS_DESC IN T_VAR2_255,
 result_list             OUT sys_refcursor,
 error_code              OUT NUMBER
);

 PROCEDURE Get_Phones_By_SIM_list2 (
 p_ACCESS_POINT_DESC  IN T_VAR2_255,
 p_DATE_TIME    IN T_DATE,
-- p_NETWORK_ADDRESS_DESC IN T_VAR2_255,
 result_list             OUT sys_refcursor,
 error_code              OUT NUMBER
);

end RSIG_TEST_OPTIM;


/
