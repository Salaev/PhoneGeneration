CREATE PACKAGE BODY          "RSIG_BASE_STATION" IS

---------------------------------------------
--     PROCEDURE Test_Row_For_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Row_For_Exist_And_Deleted(p_base_station_id IN BASE_STATION.BASE_STATION_ID%TYPE) IS
  v_deleted BASE_STATION.DELETED%TYPE;
BEGIN
  select DELETED into v_deleted from BASE_STATION where BASE_STATION_id = p_base_station_id;
  IF v_deleted IS NOT NULL THEN
    IF v_deleted < sysdate THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
    END IF;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Test_Row_For_Exist_And_Deleted;

---------------------------------------------
--     PROCEDURE Test_Location_Area_Deleted
---------------------------------------------

PROCEDURE Test_Location_Area_Deleted(p_location_area_id IN LOCATION_AREA.LOCATION_AREA_ID%TYPE) IS
  v_s VARCHAR2(1);
BEGIN
  select 'X'
    into v_s
    from LOCATION_AREA
   where location_area_id = p_location_area_id
     and deleted is not null;

  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    NULL;
END Test_Location_Area_Deleted;

---------------------------------------------
--     PROCEDURE Insert_Base_Station
---------------------------------------------

PROCEDURE Insert_Base_Station(
  handle_tran               IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT NUMBER,
  p_location_area_id        IN  BASE_STATION.LOCATION_AREA_ID%TYPE,
  p_base_station_code       IN  BASE_STATION.BASE_STATION_CODE%TYPE,
  p_base_station_name       IN  BASE_STATION.BASE_STATION_NAME%TYPE,
  p_user_id_of_change       IN  NUMBER,
  p_parent_base_station_id  IN  base_station.parent_base_station_id%TYPE,
  p_radius                  IN  base_station.radius%TYPE,
  p_longtitude              IN  base_station.longitude%TYPE,
  p_latitude                IN  base_station.latitude%TYPE,
  p_address_id              IN  base_station_address_history.address_id%TYPE
)
IS
  v_event_source            VARCHAR2(60) := 'RSIG_BASE_STATION.Insert_Base_Station';
  v_base_station_id         BASE_STATION.BASE_STATION_ID%TYPE;
  v_error_msg               VARCHAR2(1000);
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, 'Invalid handle');
  END IF;

  IF ((p_base_station_code IS NULL) OR (p_base_station_name IS NULL) OR (p_location_area_id IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameter');
  END IF;

  IF NOT ((p_parent_base_station_id IS NULL AND p_radius IS NULL AND p_longtitude IS NOT NULL AND p_latitude IS NOT NULL) OR
     (p_parent_base_station_id IS NOT NULL AND p_radius IS NOT NULL AND p_longtitude IS NULL AND p_latitude IS NULL))
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint insert_location_area_a;
  END IF;

  Test_Location_Area_Deleted(p_location_area_id);

  BEGIN
    insert into BASE_STATION
      (BASE_STATION_ID,
       BASE_STATION_CODE,
       BASE_STATION_NAME,
       DELETED,
       LOCATION_AREA_ID,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE,
       PARENT_BASE_STATION_ID,
       RADIUS,
       LONGITUDE,
       LATITUDE)
    values
      (S_BASE_STATION.NEXTVAL,
       p_base_station_code,
       p_base_station_name,
       null,
       p_location_area_id,
       sysdate,
       p_user_id_of_change,
       p_parent_base_station_id,
       p_radius,
       p_longtitude,
       p_latitude)
    RETURNING BASE_STATION_ID INTO v_base_station_id;

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_BASE_STATION THEN
        -- Not unique base station name --------------
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_BASE_STAT_NAME, 'Not unique base station name');
      ELSIF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_BASE_STATION_CODE THEN
        -- Not unique base station code --------------
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_BASE_STAT_CODE, 'Not unique base station code');
      ELSE
        RAISE;
      END IF;
  END;


  -- insert address_id when is not null
  IF p_address_id IS NOT NULL THEN
    Insert_BS_Address_Interval(p_base_station_id => v_base_station_id,
                               p_address_id => p_address_id,
                               p_start_date => SYSDATE,
                               p_user_id_of_change => p_user_id_of_change,
                               handle_tran => 'N',
                               p_raise_error => 'Y',
                               error_code => error_code,
                               error_message => v_error_msg);
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint insert_location_area_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Insert_Base_Station;

---------------------------------------------
--     PROCEDURE Update_Base_Station
---------------------------------------------
PROCEDURE Update_Base_Station(
  handle_tran               IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT NUMBER,
  p_base_station_id         IN  BASE_STATION.BASE_STATION_ID%TYPE,
  p_base_station_code       IN  BASE_STATION.BASE_STATION_CODE%TYPE,
  p_location_area_id        IN  BASE_STATION.LOCATION_AREA_ID%TYPE,
  p_base_station_name       IN  BASE_STATION.BASE_STATION_NAME%TYPE,
  p_user_id_of_change       IN  NUMBER,
  p_parent_base_station_id  IN  base_station.parent_base_station_id%TYPE,
  p_radius                  IN  base_station.radius%TYPE,
  p_longtitude              IN  base_station.longitude%TYPE,
  p_latitude                IN  base_station.latitude%TYPE,
  p_address_id              IN  base_station_address_history.address_id%TYPE
)
IS
  v_event_source            VARCHAR2(60) := 'RSIG_BASE_STATION.Update_Base_Station';
  v_error_msg               VARCHAR2(1000);
  v_sysdate                 DATE:=SYSDATE;
  v_old_address_id          base_station_address_history.address_id%TYPE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint update_location_area_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_base_station_id);
  Test_Location_Area_Deleted(p_location_area_id);

  BEGIN
    -- updating of basestation
    update BASE_STATION bs
       set bs.BASE_STATION_CODE = p_base_station_code,
           bs.BASE_STATION_NAME = p_base_station_name,
           bs.LOCATION_AREA_ID  = p_location_area_id,
           bs.DATE_OF_CHANGE    = v_sysdate,
           bs.USER_ID_OF_CHANGE = p_user_id_of_change,
           bs.parent_base_station_id = p_parent_base_station_id,
           bs.radius=p_radius,
           bs.longitude=p_longtitude,
           bs.latitude=p_latitude
     where BASE_STATION_ID = p_base_station_id;

    -- updating of intervals in ZONE_BASE_STATION:
    --      p_zone_code = null - close current interval
    --      p_zone_code <> v_prev_zone_code - insert new interval


  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Base station was not found.');
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_BASE_STATION THEN
        -- Not unique base station name --------------
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_BASE_STAT_NAME, '');
      ELSIF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_BASE_STATION_CODE THEN
        -- Not unique base station code --------------
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_BASE_STAT_CODE, '');
      ELSE
        RAISE;
      END IF;
  END;

  -- set address ID ------------------------------------------------------------------------
  -- check previous address_id
  BEGIN
    SELECT bsah.address_id
    INTO v_old_address_id
    FROM base_station_address_history bsah
    WHERE bsah.base_station_id=p_base_station_id
      AND SYSDATE BETWEEN bsah.start_date AND nvl(bsah.end_date,SYSDATE);

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_old_address_id := NULL;
  END;

  -- when previous address_id is different or not set and p_address_id is not null
  IF p_address_id<>v_old_address_id OR (v_old_address_id IS NULL AND p_address_id IS NOT NULL) OR
     (p_address_id IS NULL AND v_old_address_id IS NOT NULL)
  THEN

    Insert_BS_Address_Interval(p_base_station_id => p_base_station_id,
                               p_address_id => p_address_id,
                               p_start_date => SYSDATE,
                               p_user_id_of_change => p_user_id_of_change,
                               handle_tran => 'N',
                               p_raise_error => 'Y',
                               error_code => error_code,
                               error_message => v_error_msg);

  END IF;

  --------------------------------------------------------------------------------------------
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint update_location_area_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Update_Base_Station;

---------------------------------------------
--     PROCEDURE Delete_Base_Station
---------------------------------------------

PROCEDURE Delete_Base_Station
(
  handle_tran         IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT NUMBER,
  p_base_station_id   IN BASE_STATION.BASE_STATION_ID%TYPE,
  p_deleted           IN BASE_STATION.DELETED%TYPE,
  p_user_id_of_change IN NUMBER
) IS
  v_event_source      VARCHAR2(60) := 'RSIG_BASE_STATION.Delete_Base_Station';
  v_deleted           DATE;
  v_sector_exists     INT:=0;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  v_deleted := nvl(p_deleted, SYSDATE);
  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint delete_location_area_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_base_station_id);

  -- test for sector existence
  SELECT COUNT(1)
  INTO v_sector_exists
  FROM base_station bs
  WHERE bs.base_station_id=p_base_station_id
    AND bs.parent_base_station_id IS NULL
    AND (bs.deleted IS NULL OR bs.deleted>SYSDATE)
    AND EXISTS(SELECT 1
               FROM base_station ch
               WHERE ch.parent_base_station_id=bs.base_station_id
                 AND (ch.deleted IS NULL OR ch.deleted>SYSDATE));

  -- base station with existing sectors can not be deleted
  IF v_sector_exists>0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_BS_WITH_SECTORS, 'Base station has sectors.');
  END IF;

  update BASE_STATION
     set DELETED           = v_deleted,
         DATE_OF_CHANGE    = SYSDATE,
         USER_ID_OF_CHANGE = p_user_id_of_change
   where BASE_STATION_ID = p_base_station_id;

  update ZONE_BASE_STATION
     set END_DATE = v_deleted -- jho 040803 - changed from v date to deleted
   where BASE_STATION_ID = p_base_station_id
     and (end_date > v_deleted or end_date is null);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint delete_location_area_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Delete_Base_Station;

---------------------------------------------
--     PROCEDURE Get_Base_Station_All
---------------------------------------------

PROCEDURE Get_Base_Station_All
(
  error_code            OUT NUMBER,
  p_host_id             IN  EXCHANGE.HOST_ID%TYPE,
  p_network_operator_id IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_location_area_id    IN  LOCATION_AREA.LOCATION_AREA_ID%TYPE,
  p_cur_base_station    OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source        VARCHAR2(60) := 'RSIG_BASE_STATION.Get_Base_Station_All';
  v_sysdate             DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
-------------------------------------------------------------------------------------------------------
  v_sysdate:=SYSDATE;

  OPEN p_cur_base_station FOR
  SELECT *
  FROM (
  SELECT bs.base_station_id,
         bs.base_station_code,
         bs.base_station_name,
         bs.location_area_id,
         bs.date_of_change,
         bs.user_id_of_change,
         bs.deleted,
         bsah.address_id,
         bs.parent_base_station_id,
         bsp.base_station_code parent_code,
         bs.radius,
         bs.longitude,
         bs.latitude
  FROM host h
  JOIN location_area la ON la.host_id=h.host_id
  JOIN base_station bs ON bs.location_area_id=la.location_area_id
  LEFT JOIN base_station_address_history bsah ON bsah.base_station_id=bs.base_station_id
       AND v_sysdate BETWEEN bsah.start_date AND nvl(bsah.end_date,v_sysdate)
  LEFT JOIN base_station bsp ON bs.parent_base_station_id=bsp.base_station_id
  WHERE (p_network_operator_id IS NULL OR h.network_operator_id=p_network_operator_id)
    AND (p_host_id IS NULL OR h.host_id = p_host_id)
    AND (p_location_area_id IS NULL OR la.location_area_id = p_location_area_id)) m
  CONNECT BY PRIOR m.base_station_id = m.parent_base_station_id
  START WITH m.parent_base_station_id is NULL
  ORDER SIBLINGS BY m.base_station_code;


  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_Base_Station_All;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Insert_BS_Address_Interval
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_BS_Address_Interval(
  p_base_station_id     IN  base_station_address_history.base_station_id%TYPE,
  p_address_id          IN  base_station_address_history.address_id%TYPE,
  p_start_date          IN  DATE,
  p_user_id_of_change   IN  NUMBER,
  handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	        IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code            OUT NUMBER,
  error_message	        OUT VARCHAR2
)
IS
	v_sqlcode	            number;
  v_event_source        varchar2(60) :='RSIG_BASE_STATION.Insert_BS_Address_Interval';
  v_start_date          DATE;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;

	IF p_user_id_of_change IS NULL OR p_base_station_id IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


	-- set savepoint
	IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
		SAVEPOINT Insert_BS_Address_Interval;
	END IF;

  v_start_date:=nvl(p_start_date,SYSDATE);
-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------

  -- terminate previous intervals
  UPDATE base_station_address_history bsah
  SET bsah.end_date = v_start_date - rsig_utils.c_INTERVAL_DIFFERENCE
  WHERE bsah.base_station_id=p_base_station_id
    AND (bsah.end_date>=v_start_date OR bsah.end_date IS NULL);

  -- insert new interval when p_address_id is not null
  IF p_address_id IS NOT NULL THEN
    INSERT INTO base_station_address_history
      (base_station_id,
       address_id,
       start_date,
       end_date,
       date_of_change,
       user_id_of_change)
    VALUES
      (p_base_station_id,
       p_address_id,
       SYSDATE,
       NULL,
       SYSDATE,
       p_user_id_of_change);
  END IF;

-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Insert_BS_Address_Interval;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Insert_BS_Address_Interval;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Remove_BS_Address_Interval
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Remove_BS_Address_Interval(
  p_base_station_id     IN  base_station_address_history.base_station_id%TYPE,
  p_user_id_of_change   IN  NUMBER,
  handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	        IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code            OUT NUMBER,
  error_message	        OUT VARCHAR2
)
IS
	v_sqlcode	            number;
  v_event_source        varchar2(60) :='RSIG_BASE_STATION.Remove_BS_Address_Interval';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
	IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
	END IF;
  -- check input parameters
	IF p_user_id_of_change IS NULL OR p_base_station_id IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

	-- set savepoint
	IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
		SAVEPOINT Remove_BS_Address_Interval;
	END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------

  -- delete last interval
  DELETE FROM base_station_address_history bsah
  WHERE bsah.base_station_id=p_base_station_id
    AND bsah.start_date=(SELECT MAX(bsah2.start_date)
                         FROM base_station_address_history bsah2
                         WHERE bsah2.base_station_id=p_base_station_id);

  -- open previous interval
  UPDATE base_station_address_history bsah
  SET bsah.end_date = NULL,
      bsah.date_of_change = SYSDATE,
      bsah.user_id_of_change = p_user_id_of_change
  WHERE bsah.base_station_id=p_base_station_id
    AND bsah.start_date=(SELECT MAX(bsah2.start_date)
                         FROM base_station_address_history bsah2
                         WHERE bsah2.base_station_id=p_base_station_id);


-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

	-- commit
	IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
		COMMIT;
	END IF;

	-- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		CASE handle_tran
			WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Insert_BS_Address_Interval;
			WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
			ELSE NULL;
		END CASE;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Remove_BS_Address_Interval;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Address_Id_History_by_BS
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Address_Id_History_by_BS(
  p_base_station_id     IN  base_station.base_station_id%TYPE,
  p_raise_error	        IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code            OUT NUMBER,
  error_message         OUT VARCHAR2,
  result_list           OUT sys_refcursor
)
IS
	v_sqlcode	             number;
  v_event_source         varchar2(60) :='RSIG_BASE_STATION.Get_Address_Id_History_by_BS';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

	IF p_base_station_id IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


-- start of the procedure body --------------------------------------------------------------------------------------------------

  OPEN result_list FOR
  SELECT bsah.base_station_id,
         bsah.address_id,
         bsah.start_date,
         bsah.end_date,
         bsah.date_of_change,
         bsah.user_id_of_change
	FROM base_station_address_history bsah
  WHERE bsah.base_station_id=p_base_station_id
  ORDER BY bsah.start_date;



-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Address_Id_History_by_BS;


------------------------------------------------------------------------------------------------------------------------------
--  Get_Base_Station_Zone_History
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Base_Station_Zone_History(
  p_bsc_id                 IN  base_station.base_station_id%TYPE,
  p_start_date             IN  DATE,
  p_end_date               IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  result_list              OUT sys_refcursor
) IS
	v_sqlcode	               NUMBER;
  v_event_source           VARCHAR2(60);
  v_package_name           VARCHAR2(30) := 'RSIG_BASE_STATION';
  v_procedure_name         VARCHAR2(30) := 'Get_Base_Station_Zone_History';
  v_message                VARCHAR2(32767);
  v_start_date             DATE;
BEGIN
	v_event_source:=v_package_name || '.' || v_procedure_name;

  --v_message:= 'Input parameters:'
           --     || chr(10) ||'p_bsc_list ' || p_bsc_list.COUNT;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

/*	IF p_bsc_list.COUNT=0 THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
*/
  v_start_date := nvl(p_start_date, SYSDATE);

  IF v_start_date > p_end_date THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_INTERVAL, '');
  END IF;

-- start of the procedure body --------------------------------------------------------------

  OPEN result_list FOR
    SELECT z.zone_code,
           z.zone_name,
           zt.zone_type_code,
           zt.ZONE_TYPE_NAME,
           zbs.start_date,
           zbs.end_date,
           u.user_name,
           zbs.date_of_change,
           zbs.zone_base_station_id
      FROM base_station bs
      JOIN zone_base_station zbs ON bs.base_station_id = zbs.base_station_id
      JOIN zone z ON z.zone_id = zbs.zone_id
      JOIN zone_type zt ON zt.ZONE_TYPE_code = z.zone_type_code
      JOIN users u ON u.user_id = zbs.user_id_of_change
      WHERE bs.base_station_id = p_bsc_id
      ORDER BY z.zone_id,zt.ZONE_TYPE_CODE,zbs.start_date;

-- end of the procedure body ------------------------------------------------------------------

-- set error code to succesfully completed
  p_error_code := RSIG_UTILS.c_OK;
-- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
  p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
  p_error_message := SQLERRM;
	 OPEN result_list FOR SELECT v_sqlcode,p_error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_Base_Station_Zone_History;


---------------------------------------------
--     Get_Base_Station_By_NetOp
---------------------------------------------
PROCEDURE Get_Base_Station_By_NetOp
(
  p_network_operator_id IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_location_area_id    IN  LOCATION_AREA.LOCATION_AREA_ID%TYPE,
  p_cur_base_station    OUT RSIG_UTILS.REF_CURSOR,
  p_raise_error         IN CHAR,
  p_ERROR_CODE          OUT NUMBER,
  p_error_message       OUT VARCHAR2
) IS
  v_package_name          VARCHAR2(30) := 'RSIG_BASE_STATION';
  v_procedure_name        VARCHAR2(30) := 'Get_Base_Station_By_NetOp';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(32767);
  v_sysdate             DATE;
BEGIN
  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_network_operator_id: ' || p_network_operator_id || chr(10) ||
              'p_location_area_id: ' || p_location_area_id;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF p_network_operator_id IS NULL OR p_location_area_id IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;
---------------------------------------------------------------------------------------------------------  v_sysdate:=SYSDATE;

  OPEN p_cur_base_station FOR
  SELECT *
  FROM (
  SELECT bs.base_station_id,
         bs.base_station_code,
         bs.base_station_name,
         bs.location_area_id,
         bs.date_of_change,
         u.user_name,
         bs.deleted,
         bs.parent_base_station_id
  FROM host h
  JOIN location_area la ON la.host_id=h.host_id
  JOIN base_station bs ON bs.location_area_id=la.location_area_id
  JOIN users u ON u.user_id = bs.user_id_of_change
  LEFT JOIN base_station_address_history bsah ON bsah.base_station_id=bs.base_station_id
       AND v_sysdate BETWEEN bsah.start_date AND nvl(bsah.end_date,v_sysdate)
  LEFT JOIN base_station bsp ON bs.parent_base_station_id=bsp.base_station_id
  WHERE (p_network_operator_id IS NULL OR h.network_operator_id=p_network_operator_id)
    AND (p_location_area_id IS NULL OR la.location_area_id = p_location_area_id)) m
  CONNECT BY PRIOR m.base_station_id = m.parent_base_station_id
  START WITH m.parent_base_station_id is NULL
  ORDER SIBLINGS BY m.base_station_code;


--------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_Base_Station_By_NetOp;

---------------------------------------------
--     PROCEDURE Insert_Base_Station2
---------------------------------------------

PROCEDURE Insert_Base_Station2(
  handle_tran               IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT NUMBER,
  p_location_area_id        IN  BASE_STATION.LOCATION_AREA_ID%TYPE,
  p_base_station_code       IN  BASE_STATION.BASE_STATION_CODE%TYPE,
  p_base_station_name       IN  BASE_STATION.BASE_STATION_NAME%TYPE,
  p_user_id_of_change       IN  NUMBER,
  p_parent_base_station_id  IN  base_station.parent_base_station_id%TYPE,
  p_radius                  IN  base_station.radius%TYPE,
  p_longtitude              IN  base_station.longitude%TYPE,
  p_latitude                IN  base_station.latitude%TYPE,
  p_address_id              IN  base_station_address_history.address_id%TYPE,
  p_location_numbers        IN  common.t_varchar2_10
)
IS
  v_event_source            VARCHAR2(60) := 'RSIG_BASE_STATION.Insert_Base_Station2';
  v_base_station_id         BASE_STATION.BASE_STATION_ID%TYPE;
  v_error_msg               VARCHAR2(1000);
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, 'Invalid handle');
  END IF;

  IF ((p_base_station_code IS NULL) OR (p_base_station_name IS NULL) OR (p_location_area_id IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameter');
  END IF;

  IF NOT ((p_parent_base_station_id IS NULL AND p_radius IS NULL AND p_longtitude IS NOT NULL AND p_latitude IS NOT NULL) OR
     (p_parent_base_station_id IS NOT NULL AND p_radius IS NOT NULL AND p_longtitude IS NULL AND p_latitude IS NULL))
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint insert_location_area_a;
  END IF;

  Test_Location_Area_Deleted(p_location_area_id);

  BEGIN
    insert into BASE_STATION
      (BASE_STATION_ID,
       BASE_STATION_CODE,
       BASE_STATION_NAME,
       DELETED,
       LOCATION_AREA_ID,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE,
       PARENT_BASE_STATION_ID,
       RADIUS,
       LONGITUDE,
       LATITUDE)
    values
      (S_BASE_STATION.NEXTVAL,
       p_base_station_code,
       p_base_station_name,
       null,
       p_location_area_id,
       sysdate,
       p_user_id_of_change,
       p_parent_base_station_id,
       p_radius,
       p_longtitude,
       p_latitude)
    RETURNING BASE_STATION_ID INTO v_base_station_id;
    
    IF (p_location_numbers IS NOT NULL)
    THEN
      FOR i in p_location_numbers.FIRST..p_location_numbers.LAST
      LOOP
        IF p_location_numbers(i) IS NOT NULL
        THEN
          insert into BASE_STATION_LOCNO
            (BASE_STATION_LOCNO_ID,
             BASE_STATION_ID,
             LOCATION_NUMBER,
             DATE_OF_CHANGE,
             USER_ID_OF_CHANGE)
          values
            (S_BASE_STATION_LOCNO_ID.NEXTVAL,
             v_base_station_id,
             p_location_numbers(i),
             sysdate,
             p_user_id_of_change);
         END IF;
      END LOOP;
    END IF;

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_BASE_STATION THEN
        -- Not unique base station name --------------
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_BASE_STAT_NAME, 'Not unique base station name');
      ELSIF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_BASE_STATION_CODE THEN
        -- Not unique base station code --------------
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_BASE_STAT_CODE, 'Not unique base station code');
      ELSE
        RAISE;
      END IF;
  END;


  -- insert address_id when is not null
  IF p_address_id IS NOT NULL THEN
    Insert_BS_Address_Interval(p_base_station_id => v_base_station_id,
                               p_address_id => p_address_id,
                               p_start_date => SYSDATE,
                               p_user_id_of_change => p_user_id_of_change,
                               handle_tran => 'N',
                               p_raise_error => 'Y',
                               error_code => error_code,
                               error_message => v_error_msg);
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint insert_location_area_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Insert_Base_Station2;



---------------------------------------------
--     PROCEDURE Update_Base_Station2
---------------------------------------------
PROCEDURE Update_Base_Station2(
  handle_tran               IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT NUMBER,
  p_base_station_id         IN  BASE_STATION.BASE_STATION_ID%TYPE,
  p_base_station_code       IN  BASE_STATION.BASE_STATION_CODE%TYPE,
  p_location_area_id        IN  BASE_STATION.LOCATION_AREA_ID%TYPE,
  p_base_station_name       IN  BASE_STATION.BASE_STATION_NAME%TYPE,
  p_user_id_of_change       IN  NUMBER,
  p_parent_base_station_id  IN  base_station.parent_base_station_id%TYPE,
  p_radius                  IN  base_station.radius%TYPE,
  p_longtitude              IN  base_station.longitude%TYPE,
  p_latitude                IN  base_station.latitude%TYPE,
  p_address_id              IN  base_station_address_history.address_id%TYPE,
  p_location_numbers        IN  common.t_varchar2_10
)
IS
  v_event_source            VARCHAR2(60) := 'RSIG_BASE_STATION.Update_Base_Station2';
  v_error_msg               VARCHAR2(1000);
  v_sysdate                 DATE:=SYSDATE;
  v_old_address_id          base_station_address_history.address_id%TYPE;
  v_locno                   t_V2_60_obj:= t_V2_60_obj(null);
  v_locno_tab               t_V2_60_obj_tab := t_V2_60_obj_tab();
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint update_location_area_a;
  END IF;
  
  FOR i in p_location_numbers.FIRST..p_location_numbers.LAST
  LOOP
    IF (p_location_numbers(i) IS NOT NULL)
    THEN
      v_locno := t_V2_60_obj(p_location_numbers(i));
      v_locno_tab.EXTEND();
      v_locno_tab(i):=v_locno;
    END IF;
  END LOOP;

  Test_Row_For_Exist_And_Deleted(p_base_station_id);
  Test_Location_Area_Deleted(p_location_area_id);

  BEGIN
    -- updating of basestation
    update BASE_STATION bs
       set bs.BASE_STATION_CODE = p_base_station_code,
           bs.BASE_STATION_NAME = p_base_station_name,
           bs.LOCATION_AREA_ID  = p_location_area_id,
           bs.DATE_OF_CHANGE    = v_sysdate,
           bs.USER_ID_OF_CHANGE = p_user_id_of_change,
           bs.parent_base_station_id = p_parent_base_station_id,
           bs.radius=p_radius,
           bs.longitude=p_longtitude,
           bs.latitude=p_latitude
     where BASE_STATION_ID = p_base_station_id;
     
     DELETE FROM BASE_STATION_LOCNO bsl
     WHERE bsl.base_station_id = p_base_station_id
       AND bsl.location_number NOT IN (SELECT t.V2_60 FROM TABLE(CAST(v_locno_tab as t_V2_60_obj_tab)) t);
       
     IF (v_locno_tab IS NOT NULL)
     THEN  
     insert into BASE_STATION_LOCNO
            (BASE_STATION_LOCNO_ID,
             BASE_STATION_ID,
             LOCATION_NUMBER,
             DATE_OF_CHANGE,
             USER_ID_OF_CHANGE)
          select
             S_BASE_STATION_LOCNO_ID.NEXTVAL,
             p_base_station_id,
             location_number,
             sysdate,
             p_user_id_of_change
           from
           (
             SELECT t.V2_60 as location_number FROM TABLE(CAST(v_locno_tab as t_V2_60_obj_tab)) t
             WHERE NOT EXISTS (SELECT * FROM BASE_STATION_LOCNO bsl 
                              WHERE bsl.BASE_STATION_ID = p_base_station_id
                                AND bsl.LOCATION_NUMBER = t.V2_60)
           );
    END IF;
    -- updating of intervals in ZONE_BASE_STATION:
    --      p_zone_code = null - close current interval
    --      p_zone_code <> v_prev_zone_code - insert new interval


  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Base station was not found.');
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_BASE_STATION THEN
        -- Not unique base station name --------------
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_BASE_STAT_NAME, '');
      ELSIF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_BASE_STATION_CODE THEN
        -- Not unique base station code --------------
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_BASE_STAT_CODE, '');
      ELSE
        RAISE;
      END IF;
  END;

  -- set address ID ------------------------------------------------------------------------
  -- check previous address_id
  BEGIN
    SELECT bsah.address_id
    INTO v_old_address_id
    FROM base_station_address_history bsah
    WHERE bsah.base_station_id=p_base_station_id
      AND SYSDATE BETWEEN bsah.start_date AND nvl(bsah.end_date,SYSDATE);

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_old_address_id := NULL;
  END;

  -- when previous address_id is different or not set and p_address_id is not null
  IF p_address_id<>v_old_address_id OR (v_old_address_id IS NULL AND p_address_id IS NOT NULL) OR
     (p_address_id IS NULL AND v_old_address_id IS NOT NULL)
  THEN

    Insert_BS_Address_Interval(p_base_station_id => p_base_station_id,
                               p_address_id => p_address_id,
                               p_start_date => SYSDATE,
                               p_user_id_of_change => p_user_id_of_change,
                               handle_tran => 'N',
                               p_raise_error => 'Y',
                               error_code => error_code,
                               error_message => v_error_msg);

  END IF;

  --------------------------------------------------------------------------------------------
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint update_location_area_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Update_Base_Station2;


---------------------------------------------
--     PROCEDURE Get_LocNo
---------------------------------------------
PROCEDURE Get_LocNo(
  p_base_station_id         IN  BASE_STATION.BASE_STATION_ID%TYPE,
  p_location_numbers        OUT SYS_REFCURSOR,
  p_raise_error             IN CHAR,
  p_error_code              OUT NUMBER,
  p_error_message           OUT VARCHAR2
)
IS
  v_event_source            VARCHAR2(60) := 'RSIG_BASE_STATION.Get_LocNo';
  v_message             VARCHAR2(32767);
BEGIN

  v_message:= 'Input parameters:' || chr(10) ;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

 
---------------------------------------------------------------------------------------------------------  v_sysdate:=SYSDATE;
  OPEN p_location_numbers FOR
  SELECT 
    lno.location_number
  FROM BASE_STATION_LOCNO lno
  WHERE lno.base_station_id = p_base_station_id;

--------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
        p_error_code := RSIG_UTILS.Handle_Error(sqlcode);
        p_error_message := sqlerrm;
        RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
       
    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_LocNo;

END RSIG_BASE_STATION;
/
