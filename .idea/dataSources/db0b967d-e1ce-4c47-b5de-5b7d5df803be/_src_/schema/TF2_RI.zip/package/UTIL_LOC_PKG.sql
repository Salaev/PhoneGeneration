CREATE package util_loc_pkg is

----------------------------------!---------------------------------------------
  c_ora_wrong_network_number_rn  constant number(5) := -20402;
  c_ora_routing_number_not_found constant number(5) := -20403;
  c_ora_net_op_not_found         constant number(5) := -20404;
  c_ora_net_op_multiple          constant number(5) := -20405;

  c_ora_locker_session_not_fnd   constant number(5) := -20500;
  c_ora_table_is_empty           constant number(5) := -20501;
  c_ora_incorrect_sn             constant number(5) := -20502;
  c_ora_mutex_timeout            constant number(5) := -20503;
  c_ora_ranges_intersection_lck  constant number(5) := -20504;

  c_ora_phone_not_found          constant number(5) := -20520;
  c_ora_sim_card_not_found       constant number(5) := -20521;
  c_ora_imsi_not_corr_iccid      constant number(5) := -20522;
  c_ora_wrong_ap_status          constant number(5) := -20523;
  c_ora_wrong_na_status          constant number(5) := -20524;
  c_ora_not_same_host_na_and_ap  constant number(5) := -20525;
  c_ora_not_same_no              constant number(5) := -20526;
  c_ora_na_not_linked            constant number(5) := -20527;
  c_ora_na_linked_to_other_ap    constant number(5) := -20528;
  c_ora_prev_status_not_exist    constant number(5) := -20529;
  c_ora_already_locked           constant number(5) := -20530;
  c_ora_status_changing_failed   constant number(5) := -20531;
  c_ora_linking_failed           constant number(5) := -20532;
  c_ora_unlinking_failed         constant number(5) := -20533;
  c_ora_already_linked           constant number(5) := -20534;
  c_ora_host_not_found           constant number(5) := -20535;
  c_ora_ap_not_linked            constant number(5) := -20536;
  c_ora_ap_linked_to_other_na    constant number(5) := -20537;
  c_ora_na_already_in_na_batch   constant number(5) := -20538;
  c_ora_phone_serie_not_found    constant number(5) := -20539;
  c_ora_na_still_linked_to_ap    constant number(5) := -20540;
  c_ora_sim_serie_not_found      constant number(5) := -20541;
  c_ora_wrong_sim_serie          constant number(5) := -20542;
  c_ora_wrong_ap_type            constant number(5) := -20543;
  c_ora_sim_already_imported     constant number(5) := -20544;
  c_ora_uprs_code_not_set        constant number(5) := -20545;
  c_ora_na_status_other_billing  constant number(5) := -20546;
  c_ora_wrong_host               constant number(5) := -20547;
  c_ora_wrong_no                 constant number(5) := -20548;

  c_ora_synchronization_executed constant number(5) := -20599;

----------------------------------!---------------------------------------------
  c_msg_wrong_network_number_rn  constant varchar2(200) := 'Wrong format network phone number';
  c_msg_routing_number_not_found constant varchar2(200) := 'Routing number not found';
  c_msg_net_op_not_found         constant varchar2(200) := 'Network operator not found';
  c_msg_net_op_multiple          constant varchar2(200) := 'Multiple network operators found';

  c_msg_locker_session_not_fnd   constant varchar2(200) := 'Locker session not found';
  c_msg_table_is_empty           constant varchar2(200) := 'Input table TT_LOCKER_DATA is empty (need to commit data in TT_LOCKER_DATA_RANGE)';
  c_msg_table_is_empty_tt_eq_lst constant varchar2(200) := 'Input table TT_EQUIPMENT_LIST is empty';
  c_msg_eq_table_is_empty        constant varchar2(200) := 'Input table TT_LOCKER_DATA_EQ is empty (need to commit data in TT_LOCKER_DATA_EQ)';
  c_msg_incorrect_sn             constant varchar2(200) := 'Incorrect sn number or its length in ranges:';
  c_msg_mutex_timeout            constant varchar2(200) := 'Mutex timeout is exceeded';
  c_msg_ranges_intersection_lck  constant varchar2(200) := 'Ranges intersection is found in locker in:';

  c_msg_phone_not_found          constant varchar2(200) := 'Phone number is not found';
  c_msg_sim_card_not_found       constant varchar2(200) := 'Sim card is not found';
  c_msg_imsi_not_corr_iccid      constant varchar2(200) := 'IMSI does not correspond ICCID';
  c_msg_wrong_ap_status          constant varchar2(200) := 'Wrong access point status';
  c_msg_wrong_na_status          constant varchar2(200) := 'Wrong network address status';
  c_msg_not_same_host_na_and_ap  constant varchar2(200) := 'Host is not same for network address and access point';
  c_msg_not_same_no              constant varchar2(200) := 'Network operator is not same';
  c_msg_na_not_linked            constant varchar2(200) := 'Network address is not linked to access point';
  c_msg_na_linked_to_other_ap    constant varchar2(200) := 'Network address is linked to other access point';
  c_msg_prev_status_not_exist    constant varchar2(200) := 'Previous status not exists';
  c_msg_already_locked           constant varchar2(200) := 'Resource is already locked';
  c_msg_status_changing_failed   constant varchar2(200) := 'Status changing failed';
  c_msg_linking_failed           constant varchar2(200) := 'Linking failed';
  c_msg_unlinking_failed         constant varchar2(200) := 'Unlinking failed';
  c_msg_already_linked           constant varchar2(200) := 'Already linked';
  c_msg_host_not_found           constant varchar2(200) := 'Host is not found';
  c_msg_ap_not_linked            constant varchar2(200) := 'Access point is not linked to network address';
  c_msg_ap_linked_to_other_na    constant varchar2(200) := 'Access point is linked to other network address';
  c_msg_na_already_in_na_batch   constant varchar2(200) := 'Network address is already in network addresses batch';
  c_msg_phone_serie_not_found    constant varchar2(200) := 'Phone number serie is not found';
  c_msg_na_still_linked_to_ap    constant varchar2(200) := 'Network address is still linked to access point';
  c_msg_sim_serie_not_found      constant varchar2(200) := 'Sim serie is not found';
  c_msg_wrong_sim_serie          constant varchar2(200) := 'Wrong sim serie';
  c_msg_wrong_ap_type            constant varchar2(200) := 'Wrong access point type';
  c_msg_sim_already_imported     constant varchar2(200) := 'Sim card is already imported';
  c_msg_uprs_code_not_set        constant varchar2(200) := 'UPRS code is not set for network operator';
  c_msg_na_status_other_billing  constant varchar2(200) := 'Network address status is other billing';
  c_msg_wrong_host               constant varchar2(200) := 'Wrong host';
  c_msg_wrong_no                 constant varchar2(200) := 'Wrong network_operator';

  c_msg_synchronization_executed constant varchar2(200) := 'Syncronization already executed';

----------------------------------!---------------------------------------------
  procedure log_clob(p_log_clob_type_id number, p_dsc clob);

----------------------------------!---------------------------------------------
  procedure touch_number(p_value number);
  procedure touch_varchar(p_value varchar2);
  procedure touch_nvarchar(p_value nvarchar2);
  procedure touch_date(p_value date);
  procedure touch_boolean(p_value boolean);

----------------------------------!---------------------------------------------
  function wrap_null(p_value varchar2) return varchar2;
  function wrap_number(p_value number) return varchar2;
  function wrap_char(p_value varchar2) return varchar2;
  function wrap_boolean(p_value boolean) return varchar2;

----------------------------------!---------------------------------------------

end;
/
