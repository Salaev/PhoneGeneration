CREATE PACKAGE RSIG_PHONE_NUMBER_SERIES IS

----------------------------------!---------------------------------------------
 TYPE t_PHONE IS TABLE OF  VARCHAR2(30) INDEX BY BINARY_INTEGER;
 TYPE t_NA IS TABLE OF  NUMBER INDEX BY BINARY_INTEGER;
 TYPE t_rowid IS TABLE OF ROWID INDEX BY BINARY_INTEGER;
 TYPE t_code IS TABLE OF VARCHAR2(32) INDEX BY BINARY_INTEGER;
 TYPE t_host_id IS TABLE OF VARCHAR2(60) INDEX BY BINARY_INTEGER;

----------------------------------!---------------------------------------------
 c_locker_type_pns_range constant number := util_ri.c_locker_type_pns_range;

----------------------------------!---------------------------------------------


/****************************************************************************
  <header>
    <name>              procedure Insert_Phone_Number_Series
    </name>

    <author>            Petr Kout - GITUS
    </author>

    <version>           1.2.3     27.10.2006    Petr Cepek
                        parameter p_raise_error added
    </version>
    <version>           1.2.2     21.07.2006    Petr Cepek
                        columns from network_address moved to phone_number
    </version>
    <version>           1.2.1     30.05.2006    Petr Cepek
                        optimized, locking added
    </version>
    <version>
                        1.2.0     02.1.2006     Petr Cepek
                        fixed bug with creating serie with only one phone number
    </version>
    <version>
                        1.1.0     2.12.2005     Petr Cepek
                        procedure completely rewritten
    </version>

     <version>           1.0.12  17.05.2005    Radomir Lipka
                         to generating phone numbers from serie add
                         update field deleted to null if exists international
                         number phone
    </version>
   <version>           1.0.11  07.03.2005    Jaroslav Holub
                        added p_set_gold - if RSIG_UTILS.c_YES - then test and set gold numbers,
                              if others then set all numbers as normal
    </version>
    <version>           1.0.10  14.09.2004    Jaroslav Holub
                fix - in cursor use v_start_date instead of p_start_date
    </version>
    <version>           1.0.9  09.09.2004    Jaroslav Holub
                changed for accept date with NULL - sysdate
    </version>
    <version>           1.0.8  18.06.2004    Jaroslav Holub
                fix some errors in performance enhancements code
    </version>
    <version>           1.0.7  09.06.2004    Jaroslav Holub
                improve performance
    </version>
    <version>           1.0.6  20.05.2004    Jaroslav Holub
                fix testing if phone number has record in phone_number table
                and na_ad_status
    </version>
    <version>           1.0.5  19.05.2004    Jaroslav Holub
                fix problem with restore of sim serie (problem with existing phone number)
    </version>
    <version>           1.0.4  18.05.2004    Jaroslav Holub
                check overlaping only for active (non-deleted series)
    </version>
    <version>           1.0.3  05.02.2004    Jaroslav Holub
                into  function added parameter p_host_id
    </version>
    <version>           1.0.2  27.1.2004    Jaroslav Holub
                changed for performance boost - leave in cyklus only
                insert of PHONE_NUMBER  and NETWORK_ADDRESS, other things are made
                by insert with select clausule
    </version>
    <version>           1.0.1   22.9.2003     Petr Kout
                                created first version
    </version>

    <Description>       Procedure first checks, whether series given by
                        p_starting_local_number and p_ending_local_number is
                        overlapped with any other existing series. If it
                        overlaps, procedure ends with error c_IMSI_ERROR.
                        If all checks passed successfully, then procedure
                        inserts new phone number series, inserts phone series
                        operator interval, generates phone numbers and for each
                        phone number creates new network address, new row in
                        network address status history and marks gold phone
                        numbers.

    </Description>

    <Prerequisites>     'PHONE_NUMBER_SERIES', 'MSISDN_START_NUMBER',
                        'MSISDN_END_NUMBER' - hard-coded parameters
                        of Are_Intervals_Overlapping function calling
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                        RSIG_UTILS.Is_Gold_Number
                      Exists variable:
                        RSIG_PHONE_NUMBER_SERIES.Mark_Gold_Num_for_New_Serie
            RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_FALSE
                        RSIG_UTILS.c_PHONE_NUMBER_SERIE_OVERLAP
                        RSIG_UTILS.c_ERROR
                        RSIG_UTILS.c_GOLD_SAL_CATEGORY
                        RSIG_UTILS.c_STANDARD_SAL_CATEGORY
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code - OUT - NUMBER
                        p_phone_number_type_code - phone number type
                          code of the given serie of phone numbers
                        p_country_code - country code of given phone number serie
                        p_area_code - area code of given phone number serie
                        p_starting_local_number - starting local
                          phone number of new phone number serie
                        p_ending_local_number - ending local phone
                          number of new phone number serie
                        p_network_operator_id - id of the network
                          operator who will own this new inserted serie
                        p_start_date - the date since when given network
                          operator owns this new inserted serie
                        p_user_id_of_change - id of the user who insert this serie

    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Insert_Phone_Number_Series(
  p_phone_number_type_code   IN     PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE, -- phone number type code of the given serie of phone numbers
  p_phone_num_status_code    IN     NETWORK_ADDRESS_STATUS.NET_ADDRESS_STATUS_CODE%TYPE,
  p_country_code             IN     PHONE_NUMBER_SERIES.COUNTRY_CODE%TYPE, -- country code of given phone number serie
  p_area_code                IN     PHONE_NUMBER_SERIES.AREA_CODE%TYPE, -- area code of given phone number serie
  p_starting_local_number    IN     PHONE_NUMBER_SERIES.LOCAL_NUMBER_START%TYPE, -- starting local phone number of new phone number serie
  p_ending_local_number      IN     PHONE_NUMBER_SERIES.LOCAL_NUMBER_END%TYPE, -- ending local phone number of new phone number serie
  p_network_operator_id      IN     NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE, -- id of the network operator who will own this new inserted serie
  p_start_date               IN     DATE, -- the date since when given network operator owns this new inserted serie
  p_host_id                  IN     PHONE_NUMBER_SERIES.HOST_ID%TYPE,
  p_subhost_id               IN     PHONE_NUMBER_SERIES.SUBHOST_ID%TYPE,
  p_set_gold                 IN     CHAR,
  p_create_phones            IN     NUMBER,
  p_user_id                  IN     NUMBER,
  p_handle_tran               IN     CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error               IN     CHAR DEFAULT rsig_utils.c_NO,
  p_phone_serie_id           OUT    PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
  p_error_code               OUT    NUMBER,
  p_error_message             OUT    VARCHAR2
);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure split_phone_number_series
  (
    handle_tran char := rsig_utils.c_handle_tran_y, --!_!always Y
    p_error_code out number,
    p_error_message out varchar2,
    p_phone_number_serie_id number,
    p_start_phone_number varchar2,
    p_user_id_of_change number
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
/****************************************************************************
  <header>
    <name>              procedure Change_Phone_Serie_Type
    </name>

    <author>            Petr Kout - GITUS
    </author>

    <version>
                        1.1.0  16.9.2005    Petr Cepek
                        parameter p_raise_error added
   </version
   <version>
                        1.0.2   26.3.2004    Pavel Stengl
                        add check if phone serie type is changing
    </version>

    <version>
                        1.0.1   23.9.2003     Petr Kout
                        created first version
    </version>

    <Description>       Procedure updates values of phone series type for the
                        given phone number serie, if given phone series is
                        currently not deleted.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code - OUT - NUMBER
                        p_phone_number_serie_id - id of the phone number serie that
                          we want to change the type of
                        p_phone_number_type_code - code of the phone serie type that
                          given serie will be updated to
    </Parameters>

  </header>
****************************************************************************/

  PROCEDURE Change_Phone_Serie_Type (
    handle_tran               IN    CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT   NUMBER,
    p_phone_number_serie_id   IN    PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the phone number serie that we want to change the type of
    p_phone_number_type_code  IN    PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE,   -- code of the phone serie type that given serie will be updated to
    p_user_id_of_change       IN    NUMBER,                                         -- id of the user who insert this serie
    p_raise_error              IN    CHAR
  );

/****************************************************************************
  <header>
    <name>              procedure Change_Operator
    </name>

    <author>            Petr Kout - GITUS
    </author>

    <version>          1.0.5    30.10.2006      Petr Cepek
                       only internal operator is changed
    </version>
    <version>
                       1.0.4    23.12.2005
                       add test for network operator type
    </vesion>
    <version>          1.0.3     20.9.2004    Jaroslav Holub
                       Change_Operator - changed for accept date with NULL - sysdate,
                       and fix problem with interferencing dates
    </version>
    <version>
                        1.0.2  26.3.2004    Pavel Stengl
                       add check if phone serie operator is changing
    </version>

    <version>          1.0.1   23.9.2003     Petr Kout
                       created first version
    </version>

    <Description>       Procedure first checks, whether p_start_date is greater
                        than start date of the last serie for given phone number
                        series id. If it is not, then procedure ends with error
                        c_DATE_OVERLAP.
                        If check passed successfully, procedure inserts new
                        phone series operator given by phone number series id
                        and consequently closes last series (end_date is set
                        to value of parameter start date).

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code - OUT - NUMBER
                        p_phone_number_serie_id - id of the serie we want to update
                        p_network_operator_id - id of the network operator who will
                          own given serie
    </Parameters>

  </header>
****************************************************************************/

  PROCEDURE Change_Operator (
    handle_tran               IN    CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT   NUMBER,
    p_phone_number_serie_id   IN    PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the phone number serie that we want to change operator of
    p_old_net_operator_id     IN    network_operator.network_operator_id%TYPE,
    p_network_operator_id     IN    NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,       -- id of the network operator who will own the given serie
    p_start_date              IN    DATE,                                                     -- date since the series change is valid
    p_user_id_of_change       IN    NUMBER                                           -- id of the user who insert this serie
  );

/****************************************************************************
  <header>
    <name>              procedure Delete_Serie
    </name>

    <author>            Petr Kout - GITUS
    </author>
    <version>           1.2.2        10.11.2006     Petr Cepek
                        procedure delete also linked or main
                        phone numbers in table phone_link
    </version>
    <version>           1.2.1        21.07.2006     Petr Cepek
                        columns from network_address moved to phone_number
    </version>
    <version>
                        1.2.0          30.05.2006   Petr Cepek
                        optimized, locking added
    </version>
    <version>           1.1.0          2.12.2005    Petr Cepek
                        procedure completely rewritten
    </version>
    <version>           1.0.4           13.05.2005    Radomir Lipka
                        check if phone number from phone number series is used
    </version>
    <version>           1.0.3           14.09.2004    Jaroslav Holub
                        fix initialization of v_deleted variable
    </version>
    <version>           1.0.2           09.09.2004    Jaroslav Holub
                        changed for accept date with NULL - sysdate
    </version>
    <version>           1.0.1   23.9.2003     Petr Kout
                                created first version
    </version>

    <Description>       Procedure first checks,  whether the end date of the serie
                        being closed is null or not. If it is not null,
                        the procedure ends with error c_DELETED.
                        If check passes successfully,  then procedure sets columns
                        end_date to p_deleted in all appropriate phone number salability
                        categories, network address history rows, phone operators and phone
                        series operators, column to_date to p_deleted in all appropriate
                        network access_points and deleted to p_deleted in all appropriate
                        network addresses; subsequently it sets columns end_date to
                        p_deleted in the serie itself.


    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code - OUT - NUMBER
                        p_phone_number_serie_id - ID of the serie we want
                          to remove (including its phone numbers)
                        p_deleted  - value for set attribute (DELETED)
    </Parameters>

  </header>
****************************************************************************/

  PROCEDURE Delete_Serie (
    handle_tran               IN    CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    p_phone_number_serie_id   IN    PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
    p_deleted                 IN    PHONE_NUMBER_SERIES.DELETED%TYPE,
    p_user_id_of_change       IN    NUMBER,
    error_code                OUT   NUMBER
  );

/****************************************************************************
  <header>
    <name>              procedure Get_Operator_History
    </name>

    <author>            Petr Kout - GITUS
    </author>

    <version>           1.0.1   23.9.2003     Petr Kout
                                created first version
    </version>


    <Description>       Procedure returns ref cursor variable containing all
                        network operators for given phone number serie who
                        owned the serie in history containing network_operator_id,
                        start_date and end_date.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code - OUT - NUMBER
                        p_network_operator_id - id of the network
                          operator who owns returned series
    </Parameters>

  </header>
****************************************************************************/

 PROCEDURE Get_Operator_History (
    error_code                OUT     NUMBER,
    p_phone_number_serie_id   IN      NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE, -- id of the serie we want to get history of
    p_cur_series_hist_oper    IN OUT  RSIG_UTILS.REF_CURSOR                      -- ref cursor variable containing all network operators for given phone number serie who owned the serie in history
  );

/****************************************************************************
  <header>
    <name>              procedure Join_Series
    </name>

    <author>            Petr Kout - GITUS
    </author>

    <version>           1.0.3   20.9.2006    Petr Cepek
                        enabled to join two series when they have different
                        operator history, when it is same network operator
    </version>
    <version>           1.0.2   06.06.2005   Petr Cepek
                                error handling updated
    </version>
    <version>            1.0.2  05.02.2004    Jaroslav Holub
                        added testing if joined series has same host_id.
    </version>

    <version>           1.0.1   22.9.2003     Petr Kout
                                created first version
    </version>

    <Description>       Procedure joins two phone series when following conditions are
                        accomplished: series have same host, same phone type, belong to the same
                        operator in all history and series are continuous.
    </Description>

    <Prerequisites>

    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>

    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Join_Series(
  p_phone_number_serie_id1  IN  PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the fist serie of the series to join
  p_phone_number_serie_id2  IN  PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
  p_user_id                 IN  NUMBER,
  p_handle_tran              IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error              IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code              OUT NUMBER,
  p_error_message            OUT VARCHAR2
);


 /****************************************************************************
  <header>
    <name>              procedure Get_Serie_Detail
    </name>

    <author>            Pavel Stengl
    </author>

    <version>           1.0.3   10.11.2006    Petr Cepek
                        add external network operator into the cursor
    </version>
    <version>           1.0.2   18.5.2004     Martin Zabka
                                HOST ID added to output cursor
    </version>
    <version>           1.0.1   20.1.2004     Pavel Stengl
                                created first version
    </version>

    <Description>       procedure returns ref cursor variable
                        containing details of phone number series.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code - OUT - NUMBER
                        p_phone_number_series_id  - id of phone number series
                        p_cur_series - cursor containing infromation
                              of table phone_number for given
                              phone number series.
    </Parameters>

  </header>
****************************************************************************/

PROCEDURE Get_Serie_Detail (
    error_code                 OUT     NUMBER,
    p_phone_number_series_id   IN      PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the splitted phone number serie
    p_cur_series               IN OUT  RSIG_UTILS.REF_CURSOR                      -- cursor containing all series of given operator and phone number count for each serie
  );

/****************************************************************************
  <header>
    <name>              procedure Change_Phone_Serie_HLR
    </name>

    <author>            Pavel Stengl - STROM
    </author>

   <version>
                        1.1.1  16.9.2005    Petr Cepek
                        parameter p_raise_error added
   </version
   <version>
                        1.1.0  14.9.2005    Petr Cepek
                        added generating of exchange ports and linking with them
   </version>
   <version>            1.0.5  20.4.2005    Jaroslav Holub
                        check if exist active connection between NA and AP,
                        if yes - raise error c_ORA_PHONE_IN_SIM_SERIE_USE
   </version>
   <version>            1.0.4  09.09.2004    Jaroslav Holub
                        changed for accept date with NULL - sysdate
   </version>
   <version>            1.0.3  25.6.2004    Jaroslav Holub
                        fixed error when phone serie has no HLR
   </version>
   <version>            1.0.2  5.4.2004    Pavel Stengl
                        input parameter HOST_CODE was substitute for HOST_ID
   </version>
   <version>
                        1.0.1  26.3.2004    Pavel Stengl
                        created first version
   </version>


    <Description>       Procedure updates values of phone series host id for the
                        given phone number serie, if given phone series is
                        currently not deleted.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code - OUT - NUMBER
                        p_phone_number_serie_id - id of the phone number serie that
                                        we want to change the type of
                        p_phone_number_hlr_id   - host id that given serie will be updated to
            p_start_date      -
            p_user_id_of_change    -
    </Parameters>

  </header>
****************************************************************************/

  PROCEDURE Change_Phone_Serie_HLR (
    handle_tran               IN    CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT   NUMBER,
    p_phone_number_serie_id   IN    PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
    p_phone_number_hlr_id     IN    HOST.HOST_ID%TYPE,
    p_start_date              IN    DATE,
    p_user_id_of_change       IN    NUMBER,
    p_raise_error              IN    CHAR
  );

/****************************************************************************
  <header>
    <name>              procedure Change_Phone_Operator_And_HLR
    </name>

    <author>            Pavel Stengl - STROM
    </author>
    <version>           1.0.4  09.09.2004    Jaroslav Holub
                changed for accept date with NULL - sysdate
    </version>
    <version>
            1.0.3  20.4.2004    Pavel Stengl
                changed call exception
    </version>
  <version>
            1.0.2  5.4.2004    Pavel Stengl
                input parameter HOST_CODE was substitute for HOST_ID
    </version>
   <version>
            1.0.1  26.3.2004    Pavel Stengl
                created first version
    </version>


    <Description>       Procedure called procedures Change_Operator
              and Change_Phone_Serie_HLR
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code - OUT - NUMBER
                        p_phone_number_serie_id - id of the phone number serie that we want to change the type of
            p_network_operator_id   - id of the network operator who will own given serie
                        p_phone_number_hlr_id   - host id that given serie will be updated to
            p_start_date      -
            p_user_id_of_change    -
    </Parameters>

  </header>
****************************************************************************/

PROCEDURE Change_Phone_Operator_And_HLR (
  handle_tran               IN    CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT   NUMBER,
  p_phone_number_serie_id   IN    PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the splitted phone number serie
  p_old_net_operator_id     IN    network_operator.network_operator_id%TYPE,
  p_network_operator_id      IN     NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_phone_number_hlr_id     IN    HOST.HOST_ID%TYPE,
  p_start_date              IN    DATE,                                            -- date since the series change is valid
  p_user_id_of_change       IN    NUMBER                                           -- id of the user who insert this serie

);

/****************************************************************************
  <header>
    <name>              procedure Get_Filtered_Phone_Series
    </name>

    <author>            Radomir Lipka
    </author>

    <version>           1.0.2        10.11.2006   Petr Cepek
                        added condition for external operator
    </version>
    <version>
                        1.0.1        16.11.2005   Cepek Petr
                        ordering of phone series added
    </version>
   <version>
                        1.0.0         17.6.2005    Radomir Lipka
                        created first version
    </version>


    <Description>       Procedure returns phone numbers series belonging to given network operators,
                        which are suitable for given input parameters values.
                        The output result set has to include:
                         - phone_number_series_id
                         - country_code
                         - area_code
                         - local_number_start
                         - local_number_end
                         - PHONE_SERIES_OPERATOR end_date
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>
                        p_raise_error            CHAR      --Y - procedure ends with error in matter of failure (error code and error message will not be set)
                                                           --N - procedure ends successfully in matter of failure (error code and error message is set)
                        p_network_operator_id    NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
                        p_show_deleted           CHAR      --Y - deleted SIM series will be returned,N - deleted SIM series will not be returned
                        p_host_id                VARCHAR2  --Identification of the host Number - concrete host id Null - SIM series having HOST_ID null % - HOST_ID not considered
                        p_phone_number_type      PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE
                        error_code               NUMBER
                        p_error_message          VARCHAR2
                        p_cur_series             RSIG_UTILS.REF_CURSOR
    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Get_Filtered_Phone_Series(
 p_raise_error IN CHAR, --Y - procedure ends with error in matter of failure (error code and error message will not be set)
                        --N - procedure ends successfully in matter of failure (error code and error message is set)
 p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
 p_external_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
 p_show_deleted        IN CHAR, --Y - deleted SIM series will be returned,N - deleted SIM series will not be returned
 p_host_id             IN VARCHAR2, --Identification of the host Number - concrete host id Null - SIM series having HOST_ID null % - HOST_ID not considered
 p_phone_number_type   IN PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE,
 error_code            OUT NUMBER,
 p_error_message       OUT VARCHAR2,
 p_cur_series         OUT RSIG_UTILS.REF_CURSOR
 );

/****************************************************************************
<header>
  <name>            procedure Move_Phones_to_Host
  </name>

  <author>          Petr Cepek
  </author>

  <version>         1.1  13.11.2006    Petr Cepek
                    columns from talbe access_point moved into the table exchange_port
  </version>
  <version>
                    1.0  14.9.2005 11:28:47  -  created
  </version>

  <Description>
                    Procedure generates new exchange ports on new host when it is
                    needed and link phone numbers from
                    appropriate phone series with these exchange ports.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Move_Phones_to_Host(
  p_Phone_Serie_Id            IN  phone_number_series.phone_number_series_id%TYPE,
  p_New_Host_id               IN  host.host_id%TYPE,
  p_Start_Date                IN  DATE,
  p_user_id_of_change         IN  NUMBER,
  p_date_of_change            IN  DATE,
  handle_tran                  IN  CHAR,
  p_raise_error                IN  CHAR,
  error_code                  OUT NUMBER,
  error_message                OUT VARCHAR2
);


/****************************************************************************
<header>
  <name>            procedure Update_Phone_Number_Series
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.1  21.11.2005 fixed problem with compering old and new host
  </version>
  <version>
                    1.0  9/16/2005 4:00:54 PM  -  created
  </version>

  <Description>
                    Procedure changes PHONE_NUMBER_TYPE_CODE and HOST_ID
                    for specified phone number series only in the case that
                    new this parameter is different then old one. In the case
                    of host_id change are all phone number links to exchange
                    ports terminated and phone numbers are linked to new ports
                    on new host.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Update_Phone_Number_Series(
  p_phone_number_series_id      IN  phone_number_series.phone_number_series_id%TYPE,
  p_new_host_id                 IN  host.host_id%TYPE,
  p_new_subhost_id              IN  host.host_id%TYPE,
  p_PHONE_NUMBER_TYPE_CODE      IN  phone_number_series.phone_number_type_code%TYPE,
  p_Start_Date                  IN  DATE,
  p_user_id_of_change           IN  NUMBER,
  p_date_of_change              IN  DATE,
  handle_tran                    IN  CHAR,
  p_raise_error                  IN  CHAR,
  error_code                    OUT NUMBER,
  error_message                  OUT VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Test_network_operators_type
    </name>

    <author>            Petr Cepek
    </author>


    <version>           1.0.0   23.12.2005  Petr Cepek
                                created first version
    </version>

    <Description>       Procedure checks whether both network operators
                        are eather external or internal.
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    </Parameters>

  </header>
****************************************************************************/
PROCEDURE Test_network_operators_type(
  p_operator1           IN  network_operator.network_operator_id%TYPE,
  p_operator2           IN  network_operator.network_operator_id%TYPE
);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

END;
/
