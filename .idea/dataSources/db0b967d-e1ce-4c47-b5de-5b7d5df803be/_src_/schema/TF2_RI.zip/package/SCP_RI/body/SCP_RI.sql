CREATE PACKAGE BODY SCP_RI is
  /*
    * SCP_RI
    *
    *   Author:TARAS.MOTREVICH
    *   Created:23.02.2006 18:04:13
    *   Purpose : Requests to Resource Inventory implementation
    *
          1.4.0 sp1 - 28.02.2011 zivica.beslic
                - changed Get_Prefixes (added condition "AND pr.host_id=h.host_id(+)" for 2-nd part select,
                  to suppress creation of large ammount of possible rules combination)
          1.4.0 sp1 - 08.03.2011 zivica.beslic
                - changed Get_Prefixes (changed condition "  nvl(pr.host_id, nvl(la.host_id, -1)) =
                                                             nvl(la.host_id, nvl(h.host_id, -1)))
                  for 2-nd part select, to repair case of prefix replacement when NETWORK_OPERATOR_ID is not null)
          1.4.1 - 16.06.2011 irina.berezovska
                - completely change Get_Prefixes and Get_Prefixes_MCCMNC due to replace table PREFIX_REPLACEMENT on 3 new tables:
                   PREFIX_REPLACEMENT_GROUPS, PREFIX_REPLACEMENT_NET_EL, PREFIX_REPLACEMENT_RULES
          06.09.2011 irina.berezovska     Procedure GET_PREFIXES - if there is host_id in prefix_replacement_net_el but there isn't network_operator_id,
                                                                   get_prefixes has to insert it
          29.02.2012 irina.berezovska  - Procedure GET_OPERATOR_TYPE was added
          05.04.2012 irina.berezovska  - Procedure GET_ONLINE_CODES - return new parameter ACTIVITY_ID in the cursor
          20.04.2012 irina.berezovska  - Procedure Get_net_op_Neighbours - return new ext.roaming_type_code (TS Extended charging BCP Task #393035)
          21.05.2012 irina.berezovska  - Procedure Get_Hosts - host.host_type_code was returned in sys_refcursor (TFS 400477)
          23.05.2012 irina.berezovska  - procedure GET_HOSTS_MCCMNC (TFS 409461)
     *    29.05.2012 irina.berezovska  - procedure GET_HOSTS_MCCMNC (TFS 409461)was completely rewrite
     *    04.06.2012 irina.berezovska  - procedure GET_HOSTS_MCCMNC (TFS 409461)was change return result
     *    05.06.2012 irina.berezovska  - procedure GET_HOSTS_MCCMNC (TFS 415536)condition for control
                                         NETWORK_OPERATOR.DELETED was added
     *    21.12.2012 irina.berezovska  - [N] | Minor | TFS 527770 | Procedures Get_Prefixes and Get_Prefixes_MCCMNC - return parameter LIST_OF_ALLOWED_SERVICES in the cursor
     *    03.04.2013 irina.berezovska  - [M] | Minor | TFS 596428 | Procedure Get_Prefixes - host choice was changed
     *    06.05.2013 irina.berezovska  - [N] | Minor | TFS 620292 | Procedure GET_ONLINE_CODES was droped
     *    17.06.2013 irina berezovska  - [N] | Major | TFS 644245 | Procedure GET_VERSION - new procedure was added
     *    25.06.2013 irina.berezovska  - [N] | Major | TFS 644245 | Procedure GET_VERSION - new parameter out_synch_status was added
     *    16.1.2014  irina.berezovska  - [N] | TFS 767119 | SCP_RI.Get_SimSeries - out sys_refcursor was expanded on new parameter ROUTING_NUMBER_CODE
     *    07.04.2014 I.Berezovska      - TFS 802529 | Procedure GET_SERVICES was added
     *    09.05.2014 I.Berezovska      - [N] | Major | TFS 819181 | Procedure GET_DEF_ABC_RULE was added
     *    04.09.2014 I.Berezovska      - [F] | Minor | TFS 866873 | Procedure Get_Prefixes - output has been corrected according to the NETWORK_OPERATOR.DELETED
     *    21.11.2014 I.Berezovska      - [N] | Major | TFS 909030 | Procedures Get_Prefixes_MCCMNC, Get_Hosts_MCCMNC, Get_ZoneBaseStations_MCCMNC,
                                                             Get_NetworkKind_MCCMNC fields MCC_CODE and MNC_CODE were changed on MCC and MNC
                                             Procedure GET_VERSION was changed
                                             Procedure GET_DB_PARAMETER was added
     *    24.11.2014 I.Berezovska      - [F] | TFS 909030 | Procedure Get_Hosts_MCCMNC - declaration of parameter was corrected, procedure GET_DB_PARAMETER - small changes
     *    25.11.2014 I.Berezovska      - [F] | TFS 911336 | Procedures Get_Hosts_MCCMNC and GET_VERSION - calling of new function GET_PARAMS and procedure GET_VERSION was added
     *    19.12.2014 I.Berezovska      - [N] | TFS 932297 | Procedure GET_VERSION was changed (returns two records about synchronization: 1 - the latest completed status,
                                                                  2 - the last date)
     *    10.04.2015 I.Berezovska      - [N] | TFS 978711 | Procedure Get_SimSeries - new parameter host_id from sim_series table, was added into output cursor
  */

  ---------------------------------------------
  --     PROCEDURE Get_Hosts_By_Host_Type
  ---------------------------------------------
  PROCEDURE Get_Hosts(ERROR_CODE OUT NUMBER, result_list OUT sys_refcursor) IS
  BEGIN
    -- procedure body here
    OPEN result_list FOR
      SELECT h.HOST_ID,
             h.HOST_CODE,
             h.TIME_ZONE,
             h.NETWORK_OPERATOR_ID,
             no.NETWORK_OPERATOR_CODE,
             (SELECT NO1.NETWORK_OPERATOR_ID
                FROM NETWORK_OPERATOR NO1
               WHERE NO1.NETWORK_OPERATOR_ID_UPPER IS NULL
               START WITH NO1.NETWORK_OPERATOR_ID = h.NETWORK_OPERATOR_ID
              CONNECT BY PRIOR NO1.NETWORK_OPERATOR_ID_UPPER =
                          NO1.NETWORK_OPERATOR_ID) TOP_PARENT_OP_ID,
             dst.date_start AS daylightStartDate,
             dst.date_start_rule_mask AS daylightStartDateMask,
             dst.date_end AS daylightEndDate,
             dst.date_end_rule_mask AS daylightEndDateMask,
             h.HOST_TYPE_CODE
        FROM HOST h
        JOIN NETWORK_OPERATOR no ON no.NETWORK_OPERATOR_ID =
                                    h.NETWORK_OPERATOR_ID
        LEFT JOIN dst_rule dst ON dst.dst_rule_id = h.dst_rule_id
       WHERE (h.DELETED IS NULL OR h.DELETED > SYSDATE)
       ORDER BY HOST_CODE;
    -- set error code to succesfully completed
    ERROR_CODE := 0;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END Get_Hosts;

  --------------------------------------------
  --     PROCEDURE Get_Sim_Series_For_Cache
  ---------------------------------------------
/*  PROCEDURE Get_SimSeries(ERROR_CODE  OUT NUMBER,
                          result_list OUT sys_refcursor) IS

  BEGIN
    -- check handle_tran parameter

    OPEN result_list FOR
      SELECT ss.SIM_SERIES_ID,
             ss.START_IMSI_NUMBER,
             ss.END_IMSI_NUMBER,
             ss.NETWORK_OPERATOR_ID,
             (SELECT NO1.NETWORK_OPERATOR_ID
                FROM NETWORK_OPERATOR NO1
               WHERE NO1.NETWORK_OPERATOR_ID_UPPER IS NULL
               START WITH NO1.NETWORK_OPERATOR_ID = ss.NETWORK_OPERATOR_ID
              CONNECT BY PRIOR NO1.NETWORK_OPERATOR_ID_UPPER =
                          NO1.NETWORK_OPERATOR_ID) TOP_PARENT_OP_ID,
             h.TIME_ZONE,
             dst.date_start AS daylightStartDate,
             dst.date_start_rule_mask AS daylightStartDateMask,
             dst.date_end AS daylightEndDate,
             dst.date_end_rule_mask AS daylightEndDateMask
        FROM SIM_SERIES ss
        JOIN NETWORK_OPERATOR no ON ss.NETWORK_OPERATOR_ID =
                                    no.NETWORK_OPERATOR_ID
        JOIN HOST h ON h.HOST_ID = ss.HOST_ID
        LEFT JOIN dst_rule dst ON dst.dst_rule_id = h.dst_rule_id
       WHERE (ss.DELETED IS NULL OR ss.DELETED > SYSDATE)
       ORDER BY ss.START_IMSI_NUMBER;

    -- set error code to succesfully completed
    ERROR_CODE := 0;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END Get_SimSeries;
*/

  PROCEDURE Get_SimSeries(ERROR_CODE  OUT NUMBER,
                          result_list OUT sys_refcursor) IS

  BEGIN
    -- check handle_tran parameter

    OPEN result_list FOR
      SELECT t.sim_series_id
           , t.start_imsi_number
           , t.end_imsi_number
           , t.network_operator_id
           , t.top_parent_op_id
           , t.time_zone
           , t.daylightStartDate
           , t.daylightStartDateMask
           , t.daylightEndDate
           , t.daylightEndDateMask
           , t.routing_number_code
           , t.host_id
        FROM
          ( SELECT t1.*
                   , COUNT(*) OVER (PARTITION BY t1.SIM_SERIES_ID) AS cnt
              FROM
                ( SELECT DISTINCT
                         ss.SIM_SERIES_ID
                       , ss.START_IMSI_NUMBER
                       , ss.END_IMSI_NUMBER
                       , ss.NETWORK_OPERATOR_ID
                       , (SELECT NO1.NETWORK_OPERATOR_ID
                            FROM NETWORK_OPERATOR NO1
                           WHERE NO1.NETWORK_OPERATOR_ID_UPPER IS NULL
                           START WITH NO1.NETWORK_OPERATOR_ID = ss.NETWORK_OPERATOR_ID
                          CONNECT BY PRIOR NO1.NETWORK_OPERATOR_ID_UPPER =
                                      NO1.NETWORK_OPERATOR_ID) TOP_PARENT_OP_ID
                       , h.TIME_ZONE
                       , dst.date_start AS daylightStartDate
                       , dst.date_start_rule_mask AS daylightStartDateMask
                       , dst.date_end AS daylightEndDate
                       , dst.date_end_rule_mask AS daylightEndDateMask
                       , nvl(rn2.routing_number_code, rn1.routing_number_code) AS routing_number_code
                       , ss.host_id
                    FROM SIM_SERIES ss
                    JOIN NETWORK_OPERATOR no ON ss.NETWORK_OPERATOR_ID = no.NETWORK_OPERATOR_ID
                    LEFT JOIN routing_number_host rnh ON ( rnh.host_id = ss.host_id
                                                          AND SYSDATE BETWEEN nvl(rnh.date_from, SYSDATE) AND nvl(rnh.date_to, SYSDATE))
                    LEFT JOIN routing_number rn2 ON ( rnh.routing_number_id = rn2.routing_number_id
                                                     AND SYSDATE BETWEEN nvl(rn2.date_from, SYSDATE) AND nvl(rn2.date_to, SYSDATE)
                                                     )
                    LEFT JOIN routing_number_no rnn ON ( rnn.network_operator_id = ss.network_operator_id
                                                        AND SYSDATE BETWEEN nvl(rnn.date_from, SYSDATE) AND nvl(rnn.date_to, SYSDATE)
                                                        AND NOT EXISTS (SELECT 1
                                                              FROM routing_number_host i1
                                                                 , routing_number i2
                                                             WHERE i1.routing_number_id = i2.routing_number_id
                                                               AND i1.host_id = ss.host_id
                                                               AND SYSDATE BETWEEN nvl(i1.date_from, SYSDATE) AND nvl(i1.date_to, SYSDATE)
                                                               AND SYSDATE BETWEEN nvl(i2.date_from, SYSDATE) AND nvl(i2.date_to, SYSDATE))
                                                       )
                    LEFT JOIN routing_number rn1 ON ( rnn.routing_number_id = rn1.routing_number_id
                                                     AND SYSDATE BETWEEN nvl(rn1.date_from, SYSDATE) AND nvl(rn1.date_to, SYSDATE)
                                                     )
                    JOIN HOST h ON h.HOST_ID = ss.HOST_ID
                    LEFT JOIN dst_rule dst ON dst.dst_rule_id = h.dst_rule_id
                   WHERE (ss.DELETED IS NULL OR ss.DELETED > SYSDATE)
                     AND (h.DELETED IS NULL OR h.DELETED > SYSDATE)
                     AND (no.DELETED IS NULL OR no.DELETED > SYSDATE)
                   ORDER BY ss.START_IMSI_NUMBER
                  ) t1
          ) t
       WHERE (t.cnt > 1 AND t.routing_number_code IS NOT NULL)
          OR (t.cnt = 1);
    -- set error code to succesfully completed
    ERROR_CODE := 0;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END Get_SimSeries;

  ---------------------------------------------
  --     PROCEDURE Get_net_op_Neighbours
  ---------------------------------------------
  PROCEDURE Get_net_op_Neighbours(ERROR_CODE  OUT NUMBER,
                                  result_list OUT sys_refcursor) IS

  BEGIN
    -- check handle_tran parameter

    OPEN result_list FOR
        WITH NONE AS (SELECT roaming_definition_id, SUM(ext_roaming_type_code) ext_roaming_type_code
                        FROM network_operator_neighb_ext
                       GROUP BY roaming_definition_id)
      SELECT non.NETWORK_OPERATOR_ID,
             non.NEIGHBOURING_OPERATOR_ID,
             la.location_area_code AS lac,
             bs.base_station_code AS cellId,
             non.roaming_type_code + nvl(NONE.ext_roaming_type_code, 0)
        FROM NETWORK_OPERATOR_NEIGHBOURS non
        JOIN NETWORK_OPERATOR no ON no.NETWORK_OPERATOR_ID =
                                    non.NETWORK_OPERATOR_ID
        LEFT JOIN Location_Area la ON la.location_area_id =
                                      non.location_area_id
        LEFT JOIN base_station bs ON bs.base_station_id =
                                     non.base_station_id
        LEFT JOIN NONE ON non.roaming_definition_id = NONE.roaming_definition_id
       WHERE SYSDATE BETWEEN non.start_date AND nvl(non.end_date, SYSDATE);
    -- set error code to succesfully completed
    ERROR_CODE := 0;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END Get_net_op_Neighbours;

  ---------------------------------------------
  --     PROCEDURE Get_Zone_Base_Stations
  ---------------------------------------------
  PROCEDURE Get_ZoneBaseStations(ERROR_CODE OUT NUMBER,
                                 p_result   OUT SYS_REFCURSOR) IS

  BEGIN

    OPEN p_result FOR
      SELECT h.HOST_CODE as VLR_MSC,
             bs.base_station_code as CellId,
             zbs.start_date,
             zbs.end_date,
             zo.zone_code,
             la.location_area_code as LAC,
             zo.zone_type_code,
             la.location_area_type_code AS LAC_TYPE_CODE

        FROM ZONE_BASE_STATION zbs,
             BASE_STATION      bs,
             ZONE              zo,
             LOCATION_AREA     la,
             Host              h,
             network_operator  NO
       where zo.zone_id = zbs.zone_id
         AND zbs.location_area_id = la.location_area_id
         AND zbs.base_station_id = bs.base_station_id(+)
         AND (zbs.end_date IS NULL OR zbs.end_date > SYSDATE)
         AND la.HOST_ID = h.HOST_ID
         AND h.network_operator_id = NO.NETWORK_OPERATOR_ID
         AND

             la.DELETED IS NULL
         AND h.DELETED IS NULL
         AND bs.DELETED IS NULL
         AND zo.DELETED is NULL;

    ERROR_CODE := 0; -- succesfully completed

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END Get_ZoneBaseStations;

  ---------------------------------------------
  --     PROCEDURE Get_Prefixes
  ---------------------------------------------
  PROCEDURE Get_Prefixes(ERROR_CODE OUT NUMBER, p_result OUT SYS_REFCURSOR) IS

  BEGIN

/*    OLD query
      OPEN p_result FOR WITH prefixes AS(
      SELECT pr.prefix_replacement_id,
             h.host_id,
             h.host_code,
             pr.network_operator_id,
             pr.orig_phone_number_min_len,
             pr.orig_phone_number_max_len,
             pr.original_prefix,
             pr.overwritting_prefix,
             la.location_area_code as lac,
             pr.location_area_id,
             bs.base_station_code AS cellId,
             pr.base_station_id,
             pr.home_network_operator_id AS hlrNetworkId,
             pr.Start_Date
        FROM prefix_replacement pr,
             location_area      la,
             host               h,
             base_station       bs,
             network_operator   NO
       WHERE pr.network_operator_id = NO.NETWORK_OPERATOR_ID(+)
         AND pr.host_id = h.host_id(+)
         AND pr.location_area_id = la.location_area_id(+)
         AND pr.base_station_id = bs.base_station_id(+)

         AND nvl(pr.NETWORK_OPERATOR_ID, nvl(h.network_operator_id, -1)) =
             nvl(h.network_operator_id, nvl(NO.NETWORK_OPERATOR_ID, -1))
         AND nvl(pr.host_id, nvl(la.host_id, -1)) =
             nvl(la.host_id, nvl(h.host_id, -1))
         AND nvl(pr.location_area_id, nvl(bs.location_area_id, -1)) =
             nvl(bs.location_area_id, nvl(la.location_area_id, -1))
         AND nvl(pr.base_station_id, -1) = nvl(bs.base_station_id, -1)

         AND (

              (CASE WHEN
               h.host_id IS NULL AND la.location_area_id IS NOT NULL AND
               NO.NETWORK_OPERATOR_ID IS NOT NULL THEN
               (SELECT COUNT(la2.location_area_id) AS cc
                  FROM host h2, location_area la2, network_operator no2
                 WHERE no2.network_operator_id = h2.network_operator_id
                   AND h2.host_id = la2.host_id
                   AND la2.location_area_id = la.location_area_id
                   AND no2.network_operator_id = NO.Network_Operator_Id
                   AND ROWNUM = 1) ELSE 1 END) > 0)

         AND ((CASE WHEN la.location_area_id IS NULL AND
              bs.base_station_id IS NOT NULL THEN CASE WHEN
              h.host_id IS NOT NULL THEN
              (SELECT COUNT(la2.location_area_id) AS cc
                  FROM host h2, location_area la2, base_station bs2
                 WHERE h2.host_id = la2.host_id
                   AND la2.location_area_id = bs2.location_area_id
                   AND bs2.base_station_id = bs.base_station_id
                   AND h2.host_id = h.host_id
                   AND ROWNUM = 1) WHEN NO.NETWORK_OPERATOR_ID IS NOT NULL \*AND h.host_id IS null*\
              THEN (SELECT COUNT(la2.location_area_id) AS cc
                       FROM host             h2,
                            location_area    la2,
                            base_station     bs2,
                            network_operator no2
                      WHERE no2.network_operator_id = h2.network_operator_id
                        AND h2.host_id = la2.host_id
                        AND la2.location_area_id = bs2.location_area_id
                        AND bs2.base_station_id = bs.base_station_id
                        AND no2.network_operator_id = NO.Network_Operator_Id
                        AND ROWNUM = 1) ELSE 1 END ELSE 1 END) > 0

             )

         AND (pr.start_date < SYSDATE AND
             (pr.end_date IS NULL OR pr.end_date > SYSDATE))

         AND pr.deleted IS NULL
         AND la.deleted IS NULL
         AND bs.deleted IS NULL)
      -- 2-nd part
        SELECT pr.prefix_replacement_id,
         pr.network_operator_id,
         CASE
           WHEN pr.network_operator_id IS NULL THEN
            pr.host_code
           ELSE
            h.host_code
         END AS vlr,
         pr.lac,
         pr.cellid,
         pr.hlrNetworkId,
         pr.orig_phone_number_min_len,
         pr.orig_phone_number_max_len,
         pr.original_prefix,
         pr.overwritting_prefix,
         MAX(pr.start_date)

          FROM prefixes pr, host h, LOCATION_AREA la, base_station bs
         WHERE pr.network_operator_id = h.network_operator_id(+)
           AND pr.host_id = h.host_id(+) --bz added
           AND pr.location_area_id = la.location_area_id(+)
           AND pr.base_station_id = bs.base_station_id(+)

              \*bz test
                                                                   AND (pr.network_operator_id IS NULL OR
                                                                       h.host_id = nvl(la.host_id, h.host_id))
                                                                      *\
           AND (pr.network_operator_id IS NULL OR
               nvl(pr.host_id, nvl(la.host_id, -1)) =
               nvl(la.host_id, nvl(h.host_id, -1)))
           AND nvl(pr.location_area_id, nvl(bs.location_area_id, -1)) =
               nvl(bs.location_area_id, nvl(la.location_area_id, -1))
           AND nvl(pr.base_station_id, -1) =
               nvl(bs.base_station_id, -1)

           AND (

                (CASE WHEN h.host_id IS NULL AND
                 pr.network_operator_id IS NOT NULL AND
                 la.location_area_id IS NOT NULL THEN
                 (SELECT COUNT(la2.location_area_id) AS cc
                    FROM host h2, location_area la2
                   WHERE pr.network_operator_id = h2.network_operator_id
                     AND h2.host_id = la2.host_id
                     AND la2.location_area_id = la.location_area_id
                     AND ROWNUM = 1) ELSE 1 END) > 0)
           AND ((CASE WHEN la.location_area_id IS NULL AND
                bs.base_station_id IS NOT NULL AND
                h.host_id IS NOT NULL THEN
                (SELECT COUNT(la2.location_area_id) AS cc
                    FROM host h2, location_area la2, base_station bs2
                   WHERE h2.host_id = la2.host_id
                     AND la2.location_area_id = bs2.location_area_id
                     AND bs2.base_station_id = bs.base_station_id
                     AND h2.host_id = h.host_id
                     AND ROWNUM = 1) ELSE 1 END) > 0)

           AND la.deleted IS NULL
           AND bs.deleted IS NULL
         GROUP BY pr.prefix_replacement_id,
            pr.network_operator_id,
            pr.host_code,
            h.host_code,
            pr.orig_phone_number_min_len,
            pr.orig_phone_number_max_len,
            pr.original_prefix,
            pr.overwritting_prefix,
            pr.lac,
            pr.cellid,
            pr.hlrNetworkId;
*/

      OPEN p_result FOR
      SELECT DISTINCT
			       CASE WHEN (no.network_operator_id IS NULL AND h.host_id IS NOT NULL)
						   THEN no_1.network_operator_id
               ELSE no.network_operator_id
						 END AS network_operator_id,
             h.host_id AS host_id,
             la.location_area_id AS location_area_id,
             bs.base_station_id AS base_station_id,
             prr.home_network_operator_id AS hlrNetworkId,
             prne.network_operator_id AS replaced_network_operator_id, -- value in table before changes PREFIX_REPLACEMENT_NET_ELEM without checking of field PREFIX_REPLACEMENT_NET_ELEM.DELETED
             prne.host_id AS replaced_host_id, -- value in table before changes PREFIX_REPLACEMENT_NET_ELEM without checking of field PREFIX_REPLACEMENT_NET_ELEM.DELETED
             prne.location_area_id AS replaced_location_area_id, -- value in table before changes PREFIX_REPLACEMENT_NET_ELEM without checking of field PREFIX_REPLACEMENT_NET_ELEM.DELETED
             prne.base_station_id AS replaced_base_station_id, -- value in table before changes PREFIX_REPLACEMENT_NET_ELEM without checking of field PREFIX_REPLACEMENT_NET_ELEM.DELETED
             h.host_code AS host_code,
             la.location_area_code AS LAC,
             bs.base_station_code AS cellId,
             prr.min_phone_length AS orig_phone_number_min_len,
             prr.max_phone_length AS orig_phone_number_max_len,
             prr.original_prefix AS original_prefix,
             prr.overwritting_prefix AS overwritting_prefix,
             prg.start_date,
             prr.list_of_allowed_services
        FROM prefix_replacement_net_el prne
             JOIN prefix_replacement_groups prg ON (prne.group_id = prg.group_id)
             JOIN prefix_replacement_rules prr ON (prg.rule_id = prr.rule_id)
             LEFT OUTER JOIN host h ON (prne.host_id = h.host_id /*AND h.deleted IS NULL*/)
             JOIN network_operator no ON (prne.network_operator_id = no.NETWORK_OPERATOR_ID AND no.deleted IS NULL)
             LEFT OUTER JOIN location_area la ON (prne.location_area_id = la.location_area_id AND la.deleted IS NULL)
             LEFT OUTER JOIN base_station bs ON (prne.base_station_id = bs.base_station_id AND bs.deleted IS NULL)
						 LEFT OUTER JOIN network_operator no_1 ON (h.network_operator_id = no_1.network_operator_id AND no.deleted IS NULL)
       WHERE prg.deleted IS NULL
         AND (prg.start_date <= SYSDATE AND (prg.end_date IS NULL OR prg.end_date > SYSDATE))
         AND h.deleted IS NULL;

    ERROR_CODE := 0; -- succesfully completed

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END Get_Prefixes;

  ---------------------------------------------
  --     PROCEDURE Get_NetworkKind
  ---------------------------------------------
  PROCEDURE Get_NetworkKind(ERROR_CODE OUT NUMBER,
                            p_result   OUT SYS_REFCURSOR) IS

  BEGIN

    OPEN p_result FOR
      SELECT h.host_code,
             l.Location_Area_Code AS lac,
             nvl(l.location_area_type_code, 0) AS Type_Code
        FROM location_area l, host h, network_operator NO
       WHERE h.host_id = l.host_id
         AND h.network_operator_id = NO.NETWORK_OPERATOR_ID;

    ERROR_CODE := 0; -- succesfully completed

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END Get_NetworkKind;

  ---------------------------------------------
  --     PROCEDURE Get_Prefixes_MCCMNC
  ---------------------------------------------
  PROCEDURE Get_Prefixes_MCCMNC(ERROR_CODE OUT NUMBER,
                                p_result   OUT SYS_REFCURSOR) IS

  BEGIN

/*    OPEN p_result FOR
      SELECT pr.prefix_replacement_id AS id,
             no.mcc_code AS mcc,
             no.mnc_code AS mnc,
             pr.orig_phone_number_min_len,
             pr.orig_phone_number_max_len,
             pr.original_prefix,
             pr.overwritting_prefix,
             la.location_area_code as lac,
             bs. base_station_code AS cellid,
             pr.home_network_operator_id AS hlrNetworkId,
             MAX(pr.start_date)
        FROM prefix_replacement pr,
             location_area      la,
             BASE_STATION       bs,
             host               h,
             network_operator   no
       WHERE pr.location_area_id = la.location_area_id(+)
         AND pr.host_id = h.host_id
         AND no.network_operator_id = h.network_operator_id
         AND bs.location_area_id(+) = la.location_area_id
         AND pr.deleted IS NULL
         AND la.deleted IS NULL
         AND bs.deleted IS NULL
         AND (pr.start_date < SYSDATE AND
             (pr.end_date IS NULL OR pr.end_date > SYSDATE))
       GROUP BY pr.prefix_replacement_id,
                no.mcc_code,
                no.mnc_code,
                pr.orig_phone_number_min_len,
                pr.orig_phone_number_max_len,
                original_prefix,
                pr.overwritting_prefix,
                la.location_area_code,
                bs.base_station_code,
                pr.home_network_operator_id;
*/

      OPEN p_result FOR
      SELECT DISTINCT
             no.mcc,
             no.mnc,
             prr.min_phone_length AS orig_phone_number_min_len,
             prr.max_phone_length AS orig_phone_number_max_len,
             prr.original_prefix,
             prr.overwritting_prefix,
             la.location_area_code as lac,
             bs. base_station_code AS cellid,
             prr.home_network_operator_id AS hlrNetworkId,
             prg.start_date,
             prr.list_of_allowed_services
        FROM prefix_replacement_net_el prne
             INNER JOIN prefix_replacement_groups prg ON (prne.group_id = prg.group_id AND prg.deleted IS NULL)
             INNER JOIN prefix_replacement_rules prr ON (prg.rule_id = prr.rule_id)
             INNER JOIN host h ON (prne.host_id = h.host_id AND h.deleted IS NULL)
             INNER JOIN network_operator no ON (h.network_operator_id = no.network_operator_id AND no.deleted IS NULL)
             LEFT OUTER JOIN location_area la ON (prne.location_area_id = la.location_area_id AND la.deleted IS NULL)
             LEFT OUTER JOIN base_station bs ON (la.location_area_id = bs.base_station_id AND bs.deleted IS NULL)
       WHERE (prg.start_date <= SYSDATE AND (prg.end_date IS NULL OR prg.end_date > SYSDATE));

    ERROR_CODE := 0; -- succesfully completed

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END Get_Prefixes_MCCMNC;

  ---------------------------------------------
  --     PROCEDURE Get_Hosts_MCCMNC
  ---------------------------------------------
  PROCEDURE Get_Hosts_MCCMNC(ERROR_CODE  OUT NUMBER,
                             result_list OUT sys_refcursor) IS
    v_parameter  VARCHAR2(256);
	BEGIN
/*    SELECT parameter_value
      INTO v_parameter
      FROM ri_db_parameters
     WHERE parameter_name = 'IS_HOST_PRESENT';*/
    v_parameter := SCP_RI_CONFIG.GET_PARAMS('IS_HOST_PRESENT', '1');

    IF nvl(v_parameter, '1') = '1' THEN
		 OPEN result_list FOR
			WITH host_x AS
					(
						SELECT network_operator_id
								 , MIN(length(host_code)) KEEP (dense_rank FIRST ORDER BY (length(host_code))) AS host_code_length
								 , MIN(host_id) KEEP (dense_rank FIRST ORDER BY (length(host_code))) AS host_id
						FROM host h
						WHERE (h.deleted IS NULL OR h.deleted > SYSDATE)
						GROUP BY network_operator_id
					)

				SELECT no.mcc,
							 no.mnc,
							 no.network_operator_id,
							 (SELECT NO1.NETWORK_OPERATOR_ID
															 FROM NETWORK_OPERATOR NO1
															WHERE NO1.NETWORK_OPERATOR_ID_UPPER IS NULL
															START WITH NO1.NETWORK_OPERATOR_ID =
																				 NO.NETWORK_OPERATOR_ID
														 CONNECT BY PRIOR NO1.NETWORK_OPERATOR_ID_UPPER =
																				 NO1.NETWORK_OPERATOR_ID) TOP_PARENT_OP_ID,
							 h.time_zone,
							 d.date_start,
							 d.date_start_rule_mask,
							 d.date_end,
							 d.date_end_rule_mask
					FROM network_operator NO, host_x h1, host h, dst_rule d
				 WHERE NO.NETWORK_OPERATOR_ID = h1.network_operator_id
					 AND h.host_id = h1.host_id
					 AND h.network_operator_id = h1.network_operator_id
					 AND h.dst_rule_id = d.dst_rule_id(+)
           AND (no.deleted IS NULL OR no.Deleted > SYSDATE);
			ELSE
		    OPEN result_list FOR
         WITH host_x AS
            (
              SELECT network_operator_id
                   , MIN(length(host_code)) KEEP (dense_rank FIRST ORDER BY (length(host_code))) AS host_code_length
                   , MIN(host_id) KEEP (dense_rank FIRST ORDER BY (length(host_code))) AS host_id
              FROM host h
              WHERE (h.deleted IS NULL OR h.deleted > SYSDATE)
              GROUP BY network_operator_id
            )

          SELECT no.mcc,
                 no.mnc,
                 no.network_operator_id,
                 (SELECT NO1.NETWORK_OPERATOR_ID
                                 FROM NETWORK_OPERATOR NO1
                                WHERE NO1.NETWORK_OPERATOR_ID_UPPER IS NULL
                                START WITH NO1.NETWORK_OPERATOR_ID =
                                           NO.NETWORK_OPERATOR_ID
                               CONNECT BY PRIOR NO1.NETWORK_OPERATOR_ID_UPPER =
                                           NO1.NETWORK_OPERATOR_ID) TOP_PARENT_OP_ID,
                 h.time_zone,
                 d.date_start,
                 d.date_start_rule_mask,
                 d.date_end,
                 d.date_end_rule_mask
            FROM network_operator NO, host_x h1, host h, dst_rule d
           WHERE NO.NETWORK_OPERATOR_ID = h1.network_operator_id
             AND h.host_id = h1.host_id
             AND h.network_operator_id = h1.network_operator_id
             AND h.dst_rule_id = d.dst_rule_id(+)
             AND (no.deleted IS NULL OR no.Deleted > SYSDATE)

           UNION

          SELECT no.mcc,
                 no.mnc,
                 no.network_operator_id,
                 (SELECT NO1.NETWORK_OPERATOR_ID
                                 FROM NETWORK_OPERATOR NO1
                                WHERE NO1.NETWORK_OPERATOR_ID_UPPER IS NULL
                                START WITH NO1.NETWORK_OPERATOR_ID =
                                           NO.NETWORK_OPERATOR_ID
                               CONNECT BY PRIOR NO1.NETWORK_OPERATOR_ID_UPPER =
                                           NO1.NETWORK_OPERATOR_ID) TOP_PARENT_OP_ID,
                 NULL,
                 NULL,
                 NULL,
                 NULL,
                 NULL
            FROM network_operator NO
           WHERE NOT EXISTS (SELECT 1 FROM host h WHERE h.network_operator_id = NO.NETWORK_OPERATOR_ID)
             AND (no.Deleted IS NULL OR no.Deleted > SYSDATE);

			END IF;
    -- set error code to succesfully completed
    ERROR_CODE := 0;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END Get_Hosts_MCCMNC;

  ---------------------------------------------
  --     PROCEDURE Get_Zone_Base_Stations_MCCMNC
  ---------------------------------------------
  PROCEDURE Get_ZoneBaseStations_MCCMNC(ERROR_CODE OUT NUMBER,
                                        p_result   OUT SYS_REFCURSOR) IS

  BEGIN

    OPEN p_result FOR
      SELECT no.mcc,
             no.mnc,
             bs.base_station_code as CellId,
             zbs.start_date,
             zbs.end_date,
             zo.zone_code,
             la.location_area_code as LAC,
             zo.zone_type_code,
             la.location_area_type_code AS LAC_TYPE_CODE

        FROM ZONE_BASE_STATION zbs,
             BASE_STATION      bs,
             ZONE              zo,
             LOCATION_AREA     la,
             Host              h,
             network_operator  NO
       where zo.zone_id = zbs.zone_id
         AND zbs.location_area_id = la.location_area_id
         AND zbs.base_station_id = bs.base_station_id(+)
         AND (zbs.end_date IS NULL OR zbs.end_date > SYSDATE)
         AND la.HOST_ID = h.HOST_ID
         AND h.network_operator_id = NO.NETWORK_OPERATOR_ID
         AND

             la.DELETED IS NULL
         AND h.DELETED IS NULL
         AND bs.DELETED IS NULL
         AND zo.DELETED is NULL;

    ERROR_CODE := 0; -- succesfully completed

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END Get_ZoneBaseStations_MCCMNC;

  ---------------------------------------------
  --     PROCEDURE Get_NetworkKind_MCCMNC
  ---------------------------------------------
  PROCEDURE Get_NetworkKind_MCCMNC(ERROR_CODE OUT NUMBER,
                                   p_result   OUT SYS_REFCURSOR) IS

  BEGIN

    OPEN p_result FOR
      SELECT l.location_area_id AS lac_id,
             no.mcc,
             no.mnc,
             l.Location_Area_Code AS lac,
             nvl(l.location_area_type_code, 0) AS Type_Code
        FROM location_area l, host h, network_operator NO
       WHERE h.host_id = l.host_id
         AND h.network_operator_id = NO.NETWORK_OPERATOR_ID;

    ERROR_CODE := 0; -- succesfully completed

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END Get_NetworkKind_MCCMNC;

  PROCEDURE get_operator_type(in_msisdn         IN VARCHAR2,
                              out_result_code   OUT NUMBER,
                              out_operator_type OUT VARCHAR2)
  IS
    v_sys_date DATE;
    v_count    PLS_INTEGER;
  BEGIN
    out_operator_type := 'NOT MTS';
    v_sys_date := SYSDATE();

    SELECT count(1) INTO v_count
    FROM NETWORK_OPERATOR NO, PHONE_NUMBER_SERIES pns, PHONE_SERIES_OPERATOR pso
    WHERE pns.phone_number_series_id = pso.phone_number_series_id
      AND pso.network_operator_id = no.network_operator_id
      AND pso.start_date <= v_sys_date AND (pso.end_date > v_sys_date OR pso.end_date IS NULL)
      AND no.network_operator_type IS NULL
      AND in_msisdn BETWEEN (pns.country_code || pns.area_code || pns.local_number_start) AND (pns.country_code || pns.area_code || pns.local_number_end);

    IF (v_count > 0) THEN
      out_operator_type := NULL;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      out_result_code := SQLCODE;
  END get_operator_type;

  PROCEDURE GET_VERSION
  ( --out_result_code      OUT NUMBER
    out_scp_ri_version        OUT VARCHAR2
  , out_foris_ri_version      OUT VARCHAR2
  , out_last_synch            OUT DATE
  , out_synch_status          OUT VARCHAR2
  , out_scp_ri_version_last   OUT VARCHAR2
  , out_foris_ri_version_last OUT VARCHAR2
  , out_last_synch_last       OUT DATE
  , out_synch_status_last     OUT VARCHAR2
  ) DETERMINISTIC
  IS
  BEGIN
    SCP_RI_CONFIG.GET_VERSION( out_last_synch, out_foris_ri_version, out_scp_ri_version, out_synch_status, 1);
    SCP_RI_CONFIG.GET_VERSION( out_last_synch_last, out_foris_ri_version_last, out_scp_ri_version_last, out_synch_status_last, 2);

    -- out_synch_status := SCP_RI_CONFIG.GET_PARAMS('SYNCHRONIZATION_STATUS', '0');

  END GET_VERSION;

  PROCEDURE GET_SERVICES
  ( ERROR_CODE OUT NUMBER
  , p_result   OUT SYS_REFCURSOR
  )
  IS
  BEGIN

    OPEN p_result FOR
      SELECT no.network_operator_id
           , no.service_code
        FROM NETWORK_OPERATOR_SRVC NO
       WHERE SYSDATE BETWEEN no.date_from AND no.date_to;

    ERROR_CODE := 0; -- succesfully completed

  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END GET_SERVICES;

  PROCEDURE GET_DEF_ABC_RULE
  ( ERROR_CODE      OUT NUMBER
  , OUT_RESULT_LIST OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN OUT_RESULT_LIST FOR
      SELECT t.def_abc_rule_id
           , t.def
           , t.abc
        FROM DEF_ABC_RULE t;
    ERROR_CODE := 0; -- succesfully completed
  EXCEPTION
    WHEN OTHERS THEN
      RAISE;
  END;

/*
  PROCEDURE get_replication_state(out_cursor OUT SYS_REFCURSOR)
  IS
    out_last_synch       DATE;
    out_foris_ri_version VARCHAR2(100);
    out_scp_ri_version   VARCHAR2(100);
  BEGIN
    OPEN out_cursor FOR '
      SELECT *
        FROM replication_log t
       ORDER BY t.data DESC';
  EXCEPTION
    WHEN OTHERS THEN
      SCP_RI_CONFIG.GET_VERSION(out_last_synch, out_foris_ri_version, out_scp_ri_version);
      OPEN out_cursor FOR
        SELECT '0' AS id, out_last_synch AS "date", out_foris_ri_version AS foris_ver, out_scp_ri_version AS scp_ver, 'UNKNOWN' AS state FROM dual;
  END;
*/
end SCP_RI;
/
