CREATE package body vp_network_operator_srvc is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get1_i(p_no_id integer, p_svc_code varchar2, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return network_operator_srvc%rowtype
is
  v_res network_operator_srvc%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_no_id is null, 'p_no_id');
  util_pkg.XCheck_Cond_Missing(p_svc_code is null, 'p_svc_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_NETWORK_OPERATOR_SRVC_NO_SRV)*/
        * into v_res
        from network_operator_srvc z
        where 1 = 1
        and network_operator_id = p_no_id
        and p_date between date_from and date_to
        and service_code = p_svc_code
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_NETWORK_OPERATOR_SRVC_NO_SRV)*/
        * into v_res
        from network_operator_srvc z
        where 1 = 1
        and network_operator_id = p_no_id
        and p_date between date_from and date_to
        and service_code = p_svc_code
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_NETWORK_OPERATOR_SRVC_NO_SRV)*/
      * into v_res
      from network_operator_srvc z
      where 1 = 1
      and network_operator_id = p_no_id
      and p_date between date_from and date_to
      and service_code = p_svc_code
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1(p_no_id integer, p_svc_code varchar2, p_date date) return network_operator_srvc%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get1_i(p_no_id, p_svc_code, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get1(p_no_id integer, p_svc_code varchar2, p_date date) return network_operator_srvc%rowtype
is
  v_res network_operator_srvc%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_i(p_no_id, p_svc_code, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xvalid_i(p_rec network_operator_srvc%rowtype)
is
begin
  ------------------------------
  util_pkg.xcheck_version_dates(p_rec.date_from, p_rec.date_to);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_id_code(p_rec network_operator_srvc%rowtype) return boolean
is
  v_cnt number;
begin
  ------------------------------
select /*+ index_asc(z, I_NETWORK_OPERATOR_SRVC_NO_SRV)*/
  count(1) cnt into v_cnt
  from network_operator_srvc z
  where 1 = 1
  and network_operator_id = p_rec.network_operator_id
  and service_code = p_rec.service_code
  and greatest(p_rec.date_from, date_from) <= least(p_rec.date_to, date_to)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i(p_rec network_operator_srvc%rowtype) return boolean
is
begin
  ------------------------------
  if find_i_id_code(p_rec)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xunique_i(p_rec network_operator_srvc%rowtype)
is
begin
  ------------------------------
  if find_i_id_code(p_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_Vers3(p_rec.network_operator_id, p_rec.service_code, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_i(p_rec network_operator_srvc%rowtype)
is
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
  xunique_i(p_rec);
  ------------------------------
  insert into network_operator_srvc
  values p_rec;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure close_i(p_rec network_operator_srvc%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
update /*+ index_asc(z, I_NETWORK_OPERATOR_SRVC_NO_SRV)*/
  network_operator_srvc z
  set
    date_to = p_rec.date_to,
    user_id_of_change = p_rec.user_id_of_change,
    date_of_change = p_rec.date_of_change
  where 1 = 1
  and network_operator_id = p_rec.network_operator_id
  and service_code = p_rec.service_code
  and p_rec.date_to between date_from and date_to
  and date_from = p_rec.date_from
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotFound_Vers3(p_rec.network_operator_id, p_rec.service_code, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_OnDate3(p_rec.network_operator_id, p_rec.service_code, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open(p_rec in out nocopy network_operator_srvc%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  p_rec.date_from := nvl(p_rec.date_from, v_sysdate);
  p_rec.date_to := nvl(p_rec.date_to, util_pkg.c_open_date_to);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change(p_rec in out nocopy network_operator_srvc%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_to_prev date;
  v_rec network_operator_srvc%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.network_operator_id is null, 'p_rec.network_operator_id');
  util_pkg.XCheck_Cond_Missing(p_rec.service_code is null, 'p_rec.service_code');
  ------------------------------
  p_rec.date_from := nvl(p_rec.date_from, v_sysdate);
  p_rec.date_to := nvl(p_rec.date_to, util_pkg.c_open_date_to);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(p_rec.date_from);
  ------------------------------
  v_rec := xlock_get1(p_rec.network_operator_id, p_rec.service_code, v_date_to_prev);
  ------------------------------
  if v_rec.network_operator_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotFound_OnDate3(p_rec.network_operator_id, p_rec.service_code, v_date_to_prev, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.user_id_of_change := p_rec.user_id_of_change;
  ------------------------------
  v_rec.date_of_change := v_sysdate;
  v_rec.date_to := v_date_to_prev;
  ------------------------------
  close_i(v_rec);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close
(
    p_no_id integer,
    p_svc_code varchar2,
    p_user_id integer,
    p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_to_prev date;
  v_rec network_operator_srvc%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_no_id is null, 'p_no_id');
  util_pkg.XCheck_Cond_Missing(p_svc_code is null, 'p_svc_code');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(nvl(p_date_from, v_sysdate));
  ------------------------------
  v_rec := xlock_get1(p_no_id, p_svc_code, v_date_to_prev);
  ------------------------------
  if v_rec.network_operator_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotFound_OnDate3(p_no_id, p_svc_code, v_date_to_prev, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.user_id_of_change := p_user_id;
  ------------------------------
  v_rec.date_of_change := v_sysdate;
  v_rec.date_to := v_date_to_prev;
  ------------------------------
  close_i(v_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
