CREATE PACKAGE RSIG_PHONE_SALABILITY_CATEGORY IS

/****************************************************************************
  <header>
    <name>              package RSIG_PHONE_SALABILITY_CATEGORY
    </name>

    <author>            Petr Kout - GITUS
    </author>
    <version>           1.0.5     22.11.2006   Petr Cepek
                        procedure Insert_Salability_Category deleted
                        procedure Update_Salability_Category deleted
                        procedure Delete_Salability_Category deleted
    </version>
    <version>           1.0.4   26.7.2005     Radomir Lipka
                 				Procedure Set_Masks change type of parameters
                        p_salability_category and p_mask from CLOB to VARCHAR2.
    </version>
    <version>           1.0.3   20.5.2005     Radomir Lipka
                 				Add procedure Set_Masks and Get_Masks of table
                        Salability_Category_Mask.
    </version>
    <version>           1.0.2   10.9.2004     Jaroslav Holub
                 				Delete_Salability_Category - fixed for time difference
								between client and server, date should be null and it means sysdate
    </version>
    <version>           1.0.1   29.9.2003     Petr Kout
                                created first version
    </version>

    <Description>       package provides support for inserting, deleting,
                        updating and getting information about salability
                        categories
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
****************************************************************************/



/****************************************************************************
  <header>
    <name>              procedure Get_Salability_Categories
    </name>

    <author>            Petr Kout - GITUS
    </author>

    <version>           1.0.1   29.9.2003     Petr Kout
                                created first version
    </version>

    <Description>       Procedure provides IN OUT cursor containing data about
                        all salability categories  (salability_category_name,
                        salability_category_code, deleted).
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code - OUT - NUMBER
                        p_cur_categories - cursor variable containing data
                          about all salability categories
    </Parameters>

  </header>
****************************************************************************/

  PROCEDURE Get_Salability_Categories (
    error_code                OUT      NUMBER,
    p_cur_categories          IN OUT   RSIG_UTILS.REF_CURSOR -- cursor variable containing data about all salability categories
  );

/****************************************************************************
  <header>
    <name>              procedure Set_Masks
    </name>

    <author>            Radomir Lipka
    </author>

    <version>           1.0.1   20.5.2005     Radomir Lipka
                                created first version
    </version>

    <Description>
                        Procedure set data to table Salability Category Mask.
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>
                        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N

                        p_user_id_of_change      - id of the user who insert this serie
                        p_salability_category    - CLOB of salability category code
                        p_mask                   - CLOB of salability mask
                        error_code               - number of ora error code
    </Parameters>

  </header>
****************************************************************************/

  PROCEDURE Set_Masks (
    handle_tran               IN       CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    p_user_id_of_change       IN       NUMBER,
    p_salability_category     IN       VARCHAR2, -- Salability categories codes delimited by semicolon
    p_mask                    IN       VARCHAR2   -- Masks delimited by semicolon

  );

/****************************************************************************
  <header>
    <name>              procedure Get_Masks
    </name>

    <author>            Radomir Lipka
    </author>

    <version>           1.0.1   20.5.2005     Radomir Lipka
                                created first version
    </version>

    <Description>
                        procedure returns ref cursor variable
                        containing data of salability category mask.
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>
                        result_list               - cursor containing data
    </Parameters>

  </header>
****************************************************************************/

  PROCEDURE Get_Masks (
    result_list           OUT   RSIG_UTILS.REF_CURSOR
  );

END;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_PHONE_SALABILITY_CATEGORY.pkg,v 1.14 2003/12/15 10:20:45 prybicka Exp $
/
