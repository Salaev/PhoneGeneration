CREATE PACKAGE BODY RSIG_ACCESS_POINT_STATUS IS

---------------------------------------------------------------------------------------------------
-- Lock_sims
---------------------------------------------------------------------------------------------------
PROCEDURE Lock_sims
IS
  CURSOR c_lock_sim IS
  SELECT /*+ index(sc UK_SIM_SN) */sc.access_point_id
    FROM tt_batch_na_ap t
    JOIN sim_card sc ON sc.sn = t.sn
  FOR UPDATE;
BEGIN
  OPEN c_lock_sim;
  CLOSE c_lock_sim;
END;

---------------------------------------------------------------------------------------------------
-- Lock_sims_by_id
---------------------------------------------------------------------------------------------------
PROCEDURE Lock_sims_by_id
IS
  CURSOR c_lock_sim IS
  SELECT /*+ index(sc PK_SIM_CARD) */sc.access_point_id
    FROM tt_batch_na_ap t
    JOIN sim_card sc ON sc.access_point_id = t.access_point_id
  FOR UPDATE;
BEGIN
  OPEN c_lock_sim;
  CLOSE c_lock_sim;
END;

---------------------------------------------------------------------------------------------------
-- Lock_sims
---------------------------------------------------------------------------------------------------
PROCEDURE Lock_sims(
  p_sn               IN  sim_card.sn%TYPE,
  p_access_point_id  OUT sim_card.access_point_id%TYPE,
  p_error            OUT INT
) IS
BEGIN
  SELECT /*+ index(sc UK_SIM_SN) */sc.access_point_id
    INTO p_access_point_id
    FROM sim_card sc
   WHERE sc.sn = p_sn
  FOR UPDATE;

  p_error:=rsig_utils.c_OK;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
  p_error := RSIG_UTILS.c_SIM_CARD_NOT_EXISTS;
END;
---------------------------------------------
--     PROCEDURE Get_Access_Point_Statuses
---------------------------------------------

PROCEDURE Get_Access_Point_Statuses
(
  error_code                  OUT NUMBER,
  p_cur_access_point_statuses IN OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_ACCESS_POINT_STATUS.Get_Access_Point_Statuses';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_BEFORE_SELECT,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_access_point_statuses FOR
    select ACCESS_POINT_STATUS_CODE,
           ACCESS_POINT_STATUS_NAME
      from ACCESS_POINT_STATUS;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_AFTER_SELECT,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Get_Access_Point_Statuses;

----------------------------------------------------------------------------------------------------
-- Is_Prod_Status_Change_Allowed
----------------------------------------------------------------------------------------------------
FUNCTION Is_Prod_Status_Change_Allowed(
  p_access_point_id        IN  access_point.access_point_id%TYPE,
  p_new_status             IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_IS_BP                  IN  VARCHAR2,
  p_date                   IN  DATE
)RETURN INT
IS
  v_exist                  INT;
  v_date                   DATE;
  v_result                 NUMBER(5);
  v_old_status             ap_prod_status_hist.ap_prod_status_code%TYPE;
BEGIN

  v_date:=nvl(p_date,SYSDATE);

  BEGIN
    SELECT apsh.ap_prod_status_code
    INTO v_old_status
    FROM ap_prod_status_hist apsh
    WHERE apsh.access_point_id=p_access_point_id
      AND v_date BETWEEN apsh.start_date AND nvl(apsh.end_date,v_date);
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_old_status:=NULL;
    WHEN TOO_MANY_ROWS THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_CHANGE_SP_STATUS_NOT_ALW, '');
  END;


  SELECT COUNT(1)
  INTO v_exist
  FROM dual
  WHERE EXISTS(SELECT 1
               FROM AP_PROD_STATUS_trans apst
               WHERE (apst.status_code_from=v_old_status OR (v_old_status IS NULL AND apst.status_code_from IS NULL))
                 AND apst.status_code_to=p_new_status
                 AND (apst.is_bp_only=p_IS_BP OR p_IS_BP=rsig_utils.c_YES));


  IF v_exist=0 THEN
    -- change is not allowed
    v_result:=RSIG_UTILS.c_CHANGE_SP_STATUS_NOT_ALW;
  ELSE
    v_result:=RSIG_UTILS.c_ok;
  END IF;

  RETURN v_result;

END Is_Prod_Status_Change_Allowed;

----------------------------------------------------------------------------------------------------
-- Is_Status_Change_Allowed
----------------------------------------------------------------------------------------------------
FUNCTION Is_Status_Change_Allowed(
  p_access_point_id        IN  access_point.access_point_id%TYPE,
  p_new_status             IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_IS_BP                  IN  VARCHAR2,
  p_date                   IN  DATE
)RETURN INT
IS
  v_exist                     INT;
  v_tmp                       INT;
  v_date                      DATE;
  v_result                    NUMBER(5);
  v_old_status                ap_prod_status_hist.ap_prod_status_code%TYPE;
BEGIN

  v_date:=nvl(p_date,SYSDATE);

  BEGIN
    SELECT /*+ index_asc(apsh, I_ACCPOSTAHI_ACCESS_POINT_ID)*/
      trim(apsh.access_point_status_code)
      INTO v_old_status
      FROM access_point_status_history apsh
     WHERE apsh.access_point_id=p_access_point_id
       AND v_date BETWEEN apsh.start_date AND nvl(apsh.end_date,v_date);
    --check, if v_date is in the last range, if not -> raise
    SELECT /*+ index_asc(apsh, I_ACCPOSTAHI_ACCESS_POINT_ID)*/
      COUNT(1)
      INTO v_tmp
      FROM access_point_status_history apsh
     WHERE apsh.access_point_id=p_access_point_id
       AND v_date < apsh.start_date;
    IF v_tmp != 0 THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_CHANGE_SS_STATUS_NOT_ALW, '');
    END IF;
    
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_old_status:=NULL;
    WHEN TOO_MANY_ROWS THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_CHANGE_SS_STATUS_NOT_ALW, '');
  END;

  SELECT COUNT(1)
  INTO v_exist
  FROM dual
  WHERE EXISTS(SELECT 1
               FROM ap_status_trans ast
               WHERE (ast.status_code_from=v_old_status OR (v_old_status IS NULL AND ast.status_code_from IS NULL))
                 AND ast.status_code_to=p_new_status
                 AND (ast.is_bp_only=p_IS_BP OR p_IS_BP=rsig_utils.c_YES));


  IF v_exist=0 THEN
    -- change is not allowed
    v_result:=RSIG_UTILS.c_CHANGE_SS_STATUS_NOT_ALW;
  ELSE
    v_result:=RSIG_UTILS.c_ok;
  END IF;

  RETURN v_result;

END Is_Status_Change_Allowed;

-----------------------------------------------------------------------------------------------------------
-- Check_SIM_Status_Change
-----------------------------------------------------------------------------------------------------------
PROCEDURE Check_SIM_Status_Change(
  p_sim_status      IN  access_point_status_history.access_point_status_code%TYPE,
  p_date            IN  DATE
)
IS
  v_exist           INT;
BEGIN
  -- check changing phone status
  UPDATE tt_batch_na_ap t
  SET t.RESULT = RSIG_ACCESS_POINT_STATUS.Is_Status_Change_Allowed(t.access_point_id,
                                                                  p_sim_status,
                                                                  RSIG_UTILS.c_YES,
                                                                  p_date);
  SELECT COUNT(1)
  INTO v_exist
  FROM dual
  WHERE EXISTS(SELECT 1
               FROM tt_batch_na_ap t
               WHERE t.result<>rsig_utils.c_OK);

  IF v_exist=1 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_CHANGE_SS_STATUS_NOT_ALW,'Not allowed to change sim status.');
  END IF;

END Check_SIM_Status_Change;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Change_SIM_Prod_Status
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Change_SIM_Prod_Status(
  p_access_point_id       IN  access_point.access_point_id%TYPE,
  p_prod_status_code      IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_start_date            IN  DATE,
  p_user_id               IN  NUMBER,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message	        OUT VARCHAR2
)
IS
  v_package_name          VARCHAR2(30) := 'RSIG_ACCESS_POINT_STATUS';
  v_procedure_name        VARCHAR2(30) := 'Change_SIM_Prod_Status';
  v_event_source          VARCHAR2(60);
  v_start_date            DATE;
  v_sysdate               DATE:=SYSDATE;

  CURSOR c_sim IS
  SELECT sc.access_point_id
  FROM sim_card sc
  WHERE sc.access_point_id=p_access_point_id
  FOR UPDATE;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check input parameters
  IF p_access_point_id IS NULL OR p_prod_status_code IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  v_start_date:=nvl(p_start_date,SYSDATE);
--------------------------------------------------------------------------------------------------
  OPEN c_sim;
  CLOSE c_sim;
  -- check posible transition
  p_error_code:=Is_Prod_Status_Change_Allowed(p_access_point_id => p_access_point_id,
                                              p_new_status => p_prod_status_code,
                                              p_IS_BP => rsig_utils.c_NO,
                                              p_date => v_start_date);

  IF p_error_code<>rsig_utils.c_OK THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_CHANGE_SP_STATUS_NOT_ALW, 'Change is not allowed.');
  END IF;

  UPDATE ap_prod_status_hist apsh
     SET apsh.end_date=v_start_date - rsig_utils.c_INTERVAL_DIFFERENCE,
         apsh.user_id_of_change = p_user_id,
         apsh.date_of_change = v_sysdate
  WHERE apsh.access_point_id=p_access_point_id
    AND (apsh.end_date IS NULL OR apsh.end_date>=v_start_date);

  INSERT INTO ap_prod_status_hist
         (access_point_id,
          ap_prod_status_code,
          start_date,
          end_date,
          user_id_of_change,
          date_of_change)
  VALUES(p_access_point_id,
         p_prod_status_code,
         v_start_date,
         NULL,
         p_user_id,
         v_sysdate);

---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,p_handle_tran,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Change_SIM_Prod_Status;

END RSIG_ACCESS_POINT_STATUS;
/
