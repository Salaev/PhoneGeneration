CREATE package PERSISTENT_INTERFACE is

----------------------------------!---------------------------------------------
  c_VPOOL_GET_PREFIX_REPLACEMENT constant number := 1;  --!_!Virtual pool (vpool_id) for NSP call of RI.PERSISTENT_INTERFACE.Get_Prefix_Replacement

  c_ORA_ACQUIRE_VPOOL_SLOT_FAIL  constant number(5) := -20400;

  c_em_ACQUIRE_VPOOL_SLOT_FAIL   constant varchar2(2048) := 'acquire_vpool_slot is failed.';  --!_!Virtual pool (vpool_id) for NSP call of RI.PERSISTENT_INTERFACE.Get_Prefix_Replacement

----------------------------------!---------------------------------------------
  type cit_number is table of number index by pls_integer;
  type cit_date is table of date index by pls_integer;
  type cit_varchar_s is table of varchar2(50) index by pls_integer;
  type cit_varchar is table of varchar2(4000) index by pls_integer;
  type cit_nvarchar_s is table of nvarchar2(50) index by pls_integer;
  type cit_nvarchar is table of nvarchar2(2000) index by pls_integer;
  
----------------------------------!---------------------------------------------
  procedure get_prefix_replacement
  (
    error_code out number,
    p_validity_start_date date,
    p_validity_end_date date,
    p_host_code varchar2,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure reports_get_net_op_neighbours
  (
    p_network_operator_codes cit_varchar_s,
    p_date date,
    p_result_list out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure delete_last_open_previous
  (
    p_phone_list cit_varchar_s,
    p_user_login varchar2,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure reports_get_phones
  (
    p_host_id number,
    p_network_operator_id number,
    p_phone_type varchar2,
    p_salability_category_l cit_varchar_s,
    p_phone_number_status_code cit_varchar_s,
    p_search_date date,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure reports_get_salability_categ
  (
    p_result_list out sys_refcursor
  );

----------------------------------!---------------------------------------------
  function get_network_operator_id0(p_network_operator_code cit_varchar_s, p_date cit_date, p_trim_empty boolean, p_xcheck_data boolean := true) return cit_number;
  function get_network_operator_id(p_network_operator_code cit_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return cit_number;
  function get_network_operator_id2(p_network_operator_code varchar2, p_date date) return number;

----------------------------------!---------------------------------------------
  procedure prod_check_sim_list
  (
    p_host_id number,
    p_net_op_id number,
    p_iccid_without_control_digit cit_nvarchar_s,
    p_iccid out cit_nvarchar_s,
    p_imsi out cit_nvarchar_s,
    p_error_code out cit_number,
    p_error_message out cit_varchar
  );

----------------------------------!---------------------------------------------
  procedure check_roam_partner4imsi_list
  (
    p_imsi cit_varchar_s,
    p_date cit_date,
    p_roam_partner_flag out cit_number
  );

----------------------------------!---------------------------------------------
  procedure check_roam_partner4imsi_list2
  (
    p_imsi cit_varchar_s,
    p_date cit_date,
    p_roam_partner_flag_cur out sys_refcursor
  );

----------------------------------!---------------------------------------------

end;
/
