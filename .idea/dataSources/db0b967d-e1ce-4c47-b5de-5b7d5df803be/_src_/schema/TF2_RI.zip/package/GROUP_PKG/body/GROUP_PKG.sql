CREATE package body GROUP_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure group_add_items_id1
(
  p_group_id number,
  p_unique boolean,
  p_id1 ct_number,
  p_date date,
  p_user_id number
)
is
  v_main_count number;
  v_coll ct_agroup_data;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_group_id is null, 'p_group_id');
  util_pkg.XCheck_Cond_Missing(p_unique is null, 'p_unique');
  util_pkg.XCheckP_FSU_ct_number(p_id1, 'p_id1');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_id1);
  ------------------------------
  v_coll := vp_agroup_data.make_ct_agroup_data_lim
  (
    p_main_count => v_main_count,
    p_accept_nulls => true,
    p_agroup_data_id => null,
    p_agroup_id => util_pkg.make_ct_number(v_main_count, p_group_id),
    p_id1 => p_id1,
    p_id2 => null,
    p_date_from => util_pkg.make_ct_date(v_main_count, p_date),
    p_date_to => null,
    p_user_id => util_pkg.make_ct_number(v_main_count, p_user_id),
    p_change_date => null,
    p_dsc => null,
    p_date1 => null,
    p_num3 => null,
    p_str2 => null
  );
  ------------------------------
  vp_agroup_data.version_open_N2(v_coll, case when p_unique then vp_agroup_data.c_unq_id1 else vp_agroup_data.c_unq_none end);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure group_add_items_id1_id2
(
  p_group_id number,
  p_unique boolean,
  p_id1 ct_number,
  p_id2 ct_number,
  p_date date,
  p_user_id number
)
is
  v_main_count number;
  v_coll ct_agroup_data;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_group_id is null, 'p_group_id');
  util_pkg.XCheck_Cond_Missing(p_unique is null, 'p_unique');
  util_pkg.XCheckP_FSU_ct_number(p_id1, 'p_id1');
  util_pkg.XCheckP_FSU_ct_number(p_id2, 'p_id2');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_id1);
  ------------------------------
  v_coll := vp_agroup_data.make_ct_agroup_data_lim
  (
    p_main_count => v_main_count,
    p_accept_nulls => true,
    p_agroup_data_id => null,
    p_agroup_id => util_pkg.make_ct_number(v_main_count, p_group_id),
    p_id1 => p_id1,
    p_id2 => p_id2,
    p_date_from => util_pkg.make_ct_date(v_main_count, p_date),
    p_date_to => null,
    p_user_id => util_pkg.make_ct_number(v_main_count, p_user_id),
    p_change_date => null,
    p_dsc => null,
    p_date1 => null,
    p_num3 => null,
    p_str2 => null
  );
  ------------------------------
  vp_agroup_data.version_open_N2(v_coll, case when p_unique then vp_agroup_data.c_unq_id1id2 else vp_agroup_data.c_unq_none end);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure group_del_items_id1
(
  p_group_id number,
  p_id1 ct_number,
  p_date date,
  p_user_id number
)
is
  v_main_count number;
  v_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_group_id is null, 'p_group_id');
  util_pkg.XCheckP_FSU_ct_number(p_id1, 'p_id1');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_loc_pkg.touch_number(vp_agroup.xget1(p_group_id, p_date).agroup_id);
  ------------------------------
  select
    agroup_data_id
  bulk collect into
    v_ids
  from table(vp_agroup_data.xgetN_id1(p_pid => p_group_id, p_id1 => p_id1, p_date => p_date))
  ;
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(v_ids, 'v_ids');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(v_ids);
  ------------------------------
  vp_agroup_data.version_close_N
  (
    p_ids => v_ids,
    p_date_froms => util_pkg.make_ct_date(v_main_count, p_date),
    p_user_id => p_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure group_hard_del_all_items
(
  p_group_id number,
  p_user_id number
)
is
  v_ids ct_number;
  v_date_froms ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_group_id is null, 'p_group_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  select
    agroup_data_id,
    date_from
  bulk collect into
    v_ids,
    v_date_froms
  from table(vp_agroup_data.getN_all_versions(p_pid => p_group_id))
  ;
  ------------------------------
  vp_agroup_data.version_close_N
  (
    p_ids => v_ids,
    p_date_froms => v_date_froms,
    p_user_id => p_user_id,
    p_hard_delete => TRUE
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
