CREATE PACKAGE BODY          "LOGGING" IS
--------------------------------------------------------------------------------------------------------------
-- Get_DBparam_Value_by_Name
--------------------------------------------------------------------------------------------------------------
FUNCTION Get_DBparam_Value_by_Name(
  p_dbparam_name VARCHAR2
)
RETURN VARCHAR2
IS
  v_dbparam_value        VARCHAR2(255);
BEGIN

  -- Find identification column of the table
  SELECT db_parameter_value
    INTO v_dbparam_value
    FROM db_parameters dp
   WHERE dp.db_parameter_name = p_dbparam_name;

  RETURN v_dbparam_value;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN NULL;
END Get_DBparam_Value_by_Name;


-----------------------------------------------------------------------------------------------------------------------------------------------------
--  CLEAR_OLD_LOG_EVENTS
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE CLEAR_OLD_LOG_EVENTS
IS
  v_default_time            NUMBER;
  v_event_source            varchar2(60) :='LOGGING.CLEAR_OLD_LOG_EVENTS';
  v_type                    log_event.event_type%TYPE;
  v_date                    DATE;
BEGIN

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------

  --Fill default persistence time
  SELECT TO_NUMBER(dp.db_parameter_value)
    INTO v_default_time
    FROM db_parameters dp
   WHERE dp.db_parameter_name = 'LOG_DEFAULT_PERSISTENCE';
  IF v_default_time IS NULL THEN
    RAISE NO_DATA_FOUND;
  END IF;

  --Delete events
  FOR v_row IN (SELECT dp.db_parameter_name
                        FROM db_parameters dp
                        WHERE dp.db_parameter_name
                        LIKE 'LOG_PERSISTENCE_%')
  LOOP

    v_type:=SUBSTR(v_row.db_parameter_name,INSTR(v_row.db_parameter_name,'_',-1)+1);
    v_date:=SYSDATE-NVL(to_number(Get_dbparam_value_by_name(v_row.db_parameter_name)),v_default_time);

    DELETE FROM log_event le
    WHERE TRIM(le.event_type) = TRIM(v_type)
      AND le.event_time < v_date;
  END LOOP;
  COMMIT;

-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------
  COMMIT;
EXCEPTION
	WHEN OTHERS THEN
		RSIG_UTILS.Debug_Rsi (Sqlerrm, RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
    ROLLBACK;
END CLEAR_OLD_LOG_EVENTS;


END LOGGING;
/
