CREATE PACKAGE RSIG_SIM_CARD IS
/****************************************************************************
<header>
  <name>               package RSIG_SIM_CARD
  </name>

  <author>             Radek Hejduk - GITUS
  </author>

  <version>           1.2.4.6  27.09.2011   Sergey Ermakov
                      procedure subscriber_activate added
            procedure subscribers_activate added
  </version>
  <version>           1.2.4.5  05.05.2011   Pavel Vasilyev
                      procedure Import_Sim_Card updated
  </version>
  <version>           1.2.4.5  18.02.2011   Pavel Vasiliev
                      procedure get_simcard_detail_by_iccid added
  </version>
  <version>           1.2.4.4  29.08.2010   Denis Kovalchuk
                      procedure PROD_CheckSIMList updated
  </version>
  <version>           1.2.4.3  17.08.2010   Pavel Vasiliev
                      procedure PROD_CheckSIMList added
                      procedure PROD_Expand-Seria added
  </version>
  <version>           1.2.4.2  23.07.2010   Denis Kovalchuk
                      procedure PROD_CheckSimCardsBy-ICCIDList updated
  </version>
  <version>           1.2.4.1  09.10.2009   Denis Kovalchuk
                      procedure Get_SIMCard_Detail_By_IMSIist updated
  </version>
  <version>           1.2.4    24.10.2008   Maxim Anoev
                      procedure get_first_sim_of_msisdn created
                      procedure Get_SIMCard_Detail_By_IMSIist updated
  </version>
  <version>           1.2.3    05.11.2007   Roger Stockley
                      procedure Get_SIMCard_Detail_By_IMSIist created
  </version>
  <version>           1.2.2    13.11.2006   Petr Cepek
                      procedure Test_Row_For_Exist deleted
                      function Get_Sim_Series_Host_Ids2 deleted
                      procedure Get_Sim_Cards deleted
                      procedure Get_Sim_Series_Host_Ids deleted
                      procedure Import_Sim_Card updated
  </version>

  <version>           1.2.1    11.10.2006   Petr Cepek
                      procedure Get_Status_History updated
                      procedure Get_Prod_Status_History created
  </version>
  <version>           1.2.0    18.9.2006    Petr Cepek
                      procedure Exist_Import_Batch_Session_Id deleted
                      procedure Exist_Batch_Session_Id deleted
                      procedure Get_SIM_Card_Detail_SIM_List deleted
  </version>
  <version>           1.1.9    31.07.2006   Petr Cepek
                      procedure Get_ICCID_By_Phone_List updated
                      procedure Get_IMSI_By_NA_Ids deleted
                      procedure Get_IMSI_by_MSISDN update
  </version>
  <version>           1.1.8    15.5.2006    Petr Cepek
                      procedure Get_ICCID_By_Phone_List updated
  </version>
  <version>           1.1.7    15.5.2006    Petr Cepek
                      procedure Import_Sim_Card updated,
                      procedure Get_ICCID_By_Phone_List updated
  </version>
  <version>           1.1.6    25.04.2006   Petr Cepek
                      procedure Import_Sim_Card updated
  </version>
  <version>           1.1.5   16.02.2006    Petr Cepek
                      procedure Import_Sim_Card updated, procedure Import_One_Sim_Card deleted
  </version>
  <version>           1.1.4   12.01.2006    Petr Cepek
                      procedure Get_ICCID_By_Phone_List updated
  </version>
  <version>           1.1.3   01.12.2005  Radomir Lipka
                      procedure Import_Sim_Card updated
                      procedure Import_One_Sim_Card added
  </version>
  <version>           1.1.2   10.11.2005  Petr Cepek
                      procedure Import_Sim_Card updated
  </version>
  <version>
                    1.1.1   09.06.2005    Radomir Lipka
                            create procedure Get_IMSI_by_MSISDN
  </version>
  <version>
                    1.1.0   06.06.2005    Petr Cepek
                            procedure Get_Phone_history_by_sim_card updated
  </version>
    <version>        1.0.9   12.4.2005     Martin Zabka
                            Get_Status_History - "User name" was added to output cursor
    </version>
  <version>          1.0.8    23.02.2005    Jaroslav Holub
                    Import_Sim_Card - completely rewritten to not crash when exist sim_card in the system
  </version>

    <version>     1.0.1   10.9.2003    Radek Hejduk
                  created first version
  </version>

  <Description>        package for table SIM_CARD
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>        Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/

TYPE T_PHONE_NUMBER IS TABLE OF VARCHAR2(30)INDEX BY BINARY_INTEGER;
TYPE T_DATES IS TABLE OF DATE INDEX BY BINARY_INTEGER;
TYPE t_IMSI IS TABLE OF VARCHAR2(20) INDEX BY BINARY_INTEGER;
TYPE t_SN IS TABLE OF VARCHAR2(60) INDEX BY BINARY_INTEGER;
TYPE t_PIN IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;
TYPE t_NUMBER IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
TYPE t_varchar_30 IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
TYPE t_varchar_2 IS TABLE OF VARCHAR2(2) INDEX BY BINARY_INTEGER;
TYPE t_sc IS TABLE OF sim_card%rowtype;
TYPE t_tt_import_sim_card_1 is table of tt_import_sim_card_1%rowtype;

/****************************************************************************
  PROCEDURE

  %author           Radek Hejduk
  %created          23.06.2009
  %version          1.0.0
  %application      Resource Inventory

  %usage            Procedure set new value for AUTHENT TYPE.

  %param            p_sim_list  IN  t_IMSI - list of IMSIs
  %param            p_authent_type IN VARCHAR -new value of AUTHENT TYPE
  %param            Result_list IN  sys_refcursor - result list of not imported sim cards

  %expected_error_codes
  {*}0 - successful completion
*/
/* {%skip}
  %version_log
  {*} 1.0.0 - 10.11.2005 - Petr Cepek <br>
              procedure adjusted to be able restore deleted sim cards

****************************************************************************/
  PROCEDURE Set_Sim_Card_Authent_Type
  (
    handle_tran          IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code           OUT NUMBER,
    p_sim_list           IN t_IMSI,
    p_authent_type       IN VARCHAR, -- authent type we want to set the SIM
    p_user_id_of_change  IN NUMBER   -- number of the user who performs this procedure
  );

/****************************************************************************
<header>
  <name>               procedure Get_Status_History
  </name>

  <author>             Radek Hejduk - GITUS
  </author>

  <version>           1.0.3   11.10.2006    Petr Cepek
                      columns ap_trans_reason_code,ap_trans_reason_name added to cursor
  </version>
  <version>            1.0.2   12.4.2005     Martin Zabka
                                "User name" was added to output cursor
  </version>
  <version>            1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>        Procedure returns one SIM status history (history of specified
                      access point status) as IN OUT ref cursor (access_point_status_code,
                      access_point_status_name, start_date, end_date, date_of_change,
                      User_id_of_change).
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_TEXT_BEFORE_SELECT
                      RSIG_UTILS.c_DEBUG_TEXT_AFTER_SELECT
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
                      RSIG_UTILS.c_DEBUG_LEVEL_2
  </Prerequisites>

  <Application>        Resource inventory
  </Application>

  <Parameters>        error_code - OUT - NUMBER
                      p_access_point_id - IN - acces point status we want to get status history (ACCESS_POINT_ID)
                      p_cur_status_history - IN OUT - ref cursor containing
                        ACCESS_POINT_STATUS_CODE
                        ACCESS_POINT_STATUS_NAME
                        START_DATE
                        END_DATE
                        DATE_OF_CHANGE
                        USER_ID_OF_CHANGE
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Get_Status_History (
    error_code                 OUT    NUMBER,
    p_access_point_id          IN     ACCESS_POINT_STATUS_HISTORY.ACCESS_POINT_ID%TYPE,
    p_cur_status_history       IN OUT RSIG_UTILS.REF_CURSOR
  );

/****************************************************************************
<header>
  <name>               procedure Get_Phone_history_by_sim_card
  </name>

  <author>             Pavel Stengl - STROM
  </author>

  <version>            1.0.2   24.08.2004      Martin Zabka za asistence Jaroslava Holuba
                                added collumn user name to output cursor
  </version>
  <version>            1.0.1   3.3.2004      Pavel Stengl
                                created first version
  </version>

  <Description>        Procedure returns history of phone numbers by
              given sim card (ICCID)

  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_TEXT_BEFORE_SELECT
                      RSIG_UTILS.c_DEBUG_TEXT_AFTER_SELECT
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
                      RSIG_UTILS.c_DEBUG_LEVEL_2
  </Prerequisites>

  <Application>        Resource inventory
  </Application>

  <Parameters>        error_code     - OUT - NUMBER
                      p_iccid       - IN - sim card (SN) we want to get statistic
                      p_cur_statistic   - IN OUT - ref cursor containing
                        (INTERNATIONAL_FORMAT, TO_DATE, FROM_DATE)

</header>
****************************************************************************/
PROCEDURE Get_Phone_history_by_sim_card (
    error_code                   OUT    NUMBER,
    p_iccid                IN     SIM_CARD.SN%TYPE,
    p_cur_statistic              IN OUT RSIG_UTILS.REF_CURSOR
  );

/****************************************************************************
  <header>
    <name>              procedure Get_ICCID_By_Phone_List
    </name>

    <author>            Jaroslav Holub
    </author>

  <version>             1.0.8    31.07.2006     Petr Cepek
                        columns from network_address moved to phone_number
  </version>
  <version>             1.0.7   15.06.2006    Petr Cepek
                        error constants fixed
  </version>
  <version>             1.0.6   22.05.2006    Petr Cepek
                        error constants fixed
  </version>
  <version>
                        1.0.5   06.06.2005    Petr Cepek
                        error constant c_ORA_NO_DATA_FOUND changed to c_NO_DATA_FOUND
  </version>
  <version>
                        1.0.4   06.06.2005    Petr Cepek
                        error handling updated
  </version>
  <version>              1.0.3   13.9.2004     Jaroslav Holub
                        added column to ooutput cursor (validity date)
  </version>
  <version>              1.0.2   10.9.2004     Jaroslav Holub
                        fixed for time difference
                        between client and server, date should be null and it means sysdate
  </version>
    <version>           1.0.1   19.7.2004  Jaroslav Holub
                                add result column to output cursor, at the end
    </version>
    <version>           1.0.0   15.7.2004  Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure Returns list of phone numbers and ICCIDS of sim cards
            bind with phone numbers. Each phone number has own validity date
            for which we check binding between p. number and sim card

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
            col_phone_numbers  collection of phone numbers (international format)
            col_validity_dates  collection of dates of validity (for each of phone num.
            result_list      output cursor (international_format, ICCID)
                        p_raise_error       IN  CHAR,
                        error_code          OUT NUMBER,
                        error_message       OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
procedure Get_ICCID_By_Phone_List(
  col_phone_numbers  IN   T_PHONE_NUMBER,
  col_validity_dates  IN   T_DATES,
  result_list      OUT  sys_refcursor,
  p_raise_error    IN  CHAR,
  error_code      OUT NUMBER,
  error_message    OUT VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Get_IMSI_by_MSISDN
    </name>

    <author>            Radomir Lipka
    </author>

    <version>           1.0.1   31.07.2006   Petr Cepek
                        columns from network_address moved to phone_number
    </version>
    <version>           1.0.0   9.6.2005  Radomir Lipka
                                created first version
    </version>

    <Description>
                    procedure Returns list of phone numbers, imsi and link_type_code where are active
                    in given date range.

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
                    p_phone_number     -- selected phone number
                    p_validity_date    -- Validity date and time for range
                    p_result_list      -- output cursor (INTERNATIONAL_FORMAT, IMSI, LINK_TYPE_CODE)
    </Parameters>

  </header>
****************************************************************************/
procedure Get_IMSI_by_MSISDN(
  p_phone_number    IN  PHONE_NUMBER.INTERNATIONAL_FORMAT%TYPE,
  p_validity_date    IN   DATE,          -- Validity date and time
  p_result_list      OUT  sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure Get_Prod_Status_History
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  16.10.2006  -  created
  </version>

  <Description>     Procedure returns access point production status history
                    for given sim card. Statuses for series and sim cards
                    are merged together.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Prod_Status_History(
  p_access_point_id        IN  access_point.access_point_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);


/****************************************************************************
  <header>
    <name>              procedure Get_SIMCard_Detail_By_IMSIList
    </name>

    <author>            Roger Stockley
    </author>

    <version>           1.0.2   09.10.2009   Denis Kovalchuk
                        Added SIM production status to output cursor
                        Added Serial number to output cursor
    </version>
    <version>           1.0.1   24.10.2008   Maxim Anoev
                        created first version
    </version>
    <version>           1.0.0   05.11.2004     Roger Stockley
                        created first version
    </version>

    <Description>
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y                 -- Handle tran
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code                OUT    NUMBER
                        p_user_id_of_change       IN     ACCESS_POINT.USER_ID_OF_CHANGE%TYPE,
                        p_batch_session_id        IN     NUMBER                              -- Batch session identification
                        result_list               OUT    sys_refcursor
    </Parameters>

  </header>
/****************************************************************************/

procedure get_simcard_detail_by_imsilist
(
  p_imsi_list util_pkg.cit_varchar_s,
  p_raise_error char default rsig_utils.c_no,
  p_result_list out sys_refcursor,
  p_addit_result out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
);

/****************************************************************************
  <header>
    <name>              Get_SIMCard_Det_By_IMSIList2
    </name>

    <author>            Roger Stockley, Victor Smirnov
    </author>

    <version>           1.0.0   19.06.2009     Victor Smirnov
                        created first version
    </version>

    <Description>
                        only for SIM_CARD.authent_type in p_result_list
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>
    </Parameters>

  </header>
/****************************************************************************/

PROCEDURE Get_SIMCard_Det_By_IMSIList2 (
  p_imsi_list                  IN       common.t_IMSI,
  p_result_list                OUT      sys_refcursor,
  p_raise_error                IN       CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                 OUT      NUMBER,
  p_error_message              OUT      VARCHAR2
);

/****************************************************************************
  <header>
    <name>              get_first_sim_of_msisdn
    </name>

    <author>
    </author>

    <version>
    </version>

    <Description>
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>
    </Application>

    <Parameters>
    </Parameters>

  </header>
/****************************************************************************/

procedure get_first_sim_of_msisdn(
  p_msisdn_list     IN   T_PHONE_NUMBER,
  p_result_list    OUT  sys_refcursor
);

/****************************************************************************
  <header>
    <name>              PROD_CheckSIMList
    </name>

    <author>
    </author>

    <version>           1.0.1   29.08.2010   Denis Kovalchuk
        FIXED:
        -added left koin with access_point_history
        -fixed values replaced with constats from RSIG_UTILS
    </version>
    <version>           1.0.0   17.08.2010  Pavel Vasiliev
                                created first version
    </version>

    <Description>
                    procedure checks list of ICCID for host and return list of matching and not matching ICCIDs.

    </Description>


    <Prerequisites>
    </Prerequisites>

    <Application>
    </Application>

    <Parameters>
    </Parameters>

  </header>
/****************************************************************************/

PROCEDURE PROD_CheckSIMList
(
  p_Host_ID                NUMBER,
  p_Net_OP_ID              NUMBER,
  p_iccid                  RSIG_SIM_CARD.t_IMSI,
  p_result_list            OUT sys_refcursor,
  p_result_list_wrong      OUT sys_refcursor
);

PROCEDURE subscriber_migrate
(
  p_msisdn                     IN       VARCHAR2,
  p_phone_status_code          IN       VARCHAR2,
  p_user_nt_name               IN       VARCHAR2,
  p_date                       IN       DATE,
  p_set_empty_balance_storage  IN       NUMBER DEFAULT 0,
  p_error_code                 OUT      NUMBER,
  p_error_message              OUT      VARCHAR2
);

PROCEDURE subscribers_migrate
(
  p_msisdn                     IN       Common.t_international_format,
  p_phone_status_code          IN       Common.t_varchar2_10,
  p_date                       IN       DATE,
  p_user_nt_name               IN       VARCHAR2,
  p_set_empty_balance_storage  IN       Common.t_number,
  p_error_code                 OUT      NUMBER,
  p_error_message              OUT      VARCHAR2,
  p_result                     OUT      SYS_REFCURSOR
);

END;
/
