CREATE PACKAGE ZONE_BASE_STATION_PCK IS

----------------------------------!---------------------------------------------
TYPE t_ID IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
TYPE t_BSC IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;
TYPE t_MSC IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
TYPE t_date IS TABLE OF DATE INDEX BY BINARY_INTEGER;

----------------------------------!---------------------------------------------
PROCEDURE Get_Zone_Base_Station
(
  error_code            OUT  NUMBER,
  p_start_date  	      IN   DATE,
  p_end_date	          IN   DATE,
  p_bsc_list            IN   t_BSC,
  p_result              OUT  RSIG_UTILS.REF_CURSOR
);

----------------------------------!---------------------------------------------
PROCEDURE Get_Zone_Base_Station_All
(
  ERROR_CODE           OUT NUMBER,
  p_result             OUT RSIG_UTILS.REF_CURSOR
);

----------------------------------!---------------------------------------------
PROCEDURE Get_Zone_Base_Station_LAC
(
  p_msc_list               IN  t_MSC,
  p_bsc_list               IN  t_BSC,
  p_lac_list               IN  t_BSC,
  p_start_date             IN  DATE,
  p_end_date               IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

----------------------------------!---------------------------------------------
PROCEDURE Insert_LA_zone_intervals
(
  p_location_area_id    IN  location_area.location_area_id%TYPE,
  p_base_station_id     IN  base_station.base_station_id%TYPE,
  p_zone_type_id        IN  Zone_Base_Station.ZONE_TYPE_code%TYPE,
  p_start_date          IN  DATE,
  p_end_date            IN  DATE
);

----------------------------------!---------------------------------------------
PROCEDURE Insert_Zone_Base_Station
(
  p_location_area_id    IN  location_area.location_area_id%TYPE,
  p_base_station_id     IN  base_station.base_station_id%TYPE,
  p_zone_id             IN  zone.ZONE_ID%TYPE,
  p_start_date          IN  DATE,
  p_user_id_of_change   IN  NUMBER,
  p_handle_tran	        IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error         IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code          OUT NUMBER,
  p_error_message       OUT VARCHAR2
);

----------------------------------!---------------------------------------------
PROCEDURE Close_Zone_Base_Station_Int
(
  p_zone_base_station_id IN  zone.ZONE_ID%TYPE,
  p_user_id_of_change   IN  NUMBER,
  p_handle_tran	        IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error         IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code          OUT NUMBER,
  p_error_message       OUT VARCHAR2
);

----------------------------------!---------------------------------------------
PROCEDURE GetZonesForBaseStations
(
  p_id_l util_pkg.cit_number,
  p_msc_l util_pkg.cit_varchar_s,
  p_lac_l util_pkg.cit_varchar_s,
  p_cellid_l util_pkg.cit_varchar_s,
  p_Validity_Date_l util_pkg.cit_date,
  p_raise_error CHAR DEFAULT rsig_utils.c_NO,
  p_error_code OUT NUMBER,
  p_error_message OUT VARCHAR2,
  p_result_list OUT sys_refcursor
);

----------------------------------!---------------------------------------------
PROCEDURE GetMSCLACCellZones
(
  p_ValidityStartDate      IN  DATE,
  p_ValidityEndDate        IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);

----------------------------------!---------------------------------------------
PROCEDURE GetExternalZoneBaseStation
(
  p_validitydate           IN  DATE,
  p_msc_id                 IN NUMBER,
  p_network_operator_id    IN NUMBER,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);

----------------------------------!---------------------------------------------
PROCEDURE UpdateExtZoneBaseStation
(
  p_zone_base_station_id   IN  NUMBER,
  p_msc_id                 IN NUMBER,
  p_network_operator_id    IN NUMBER,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_handle_tran            IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_user_id_of_change      IN NUMBER,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2
);

----------------------------------!---------------------------------------------
procedure get_result_cursor01(p_zones ct_host_lac_bs, p_result out sys_refcursor);

----------------------------------!---------------------------------------------
END;
/
