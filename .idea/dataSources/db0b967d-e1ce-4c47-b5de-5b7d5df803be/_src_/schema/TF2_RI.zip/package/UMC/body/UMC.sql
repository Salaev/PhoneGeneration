CREATE PACKAGE BODY UMC IS
-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Create_bound_SIM_Series
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Create_bound_SIM_Series(
  p_network_operator_id   IN  network_operator.network_operator_id%TYPE,
  p_ICCID_prefix          IN  VARCHAR2,
  p_HLR_Code              IN  host.host_code%TYPE,
  p_MSISDN_Start          IN  phone_number.International_Format%TYPE,
  p_MSISDN_End            IN  phone_number.International_Format%TYPE,
  p_IMSI_Start            IN  sim_card.imsi%TYPE,
  p_ap_status             IN  access_point_status_history.access_point_status_code%TYPE,
  p_ap_prod_status        IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_user_id               IN  NUMBER,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_sim_series_id         OUT sim_series.sim_series_id%TYPE,
  p_error_code            OUT NUMBER,
  p_error_message	        OUT VARCHAR2
)
IS
  v_package_name          VARCHAR2(30) := 'UMC';
  v_procedure_name        VARCHAR2(30) := 'Create_bound_SIM_Series';
  v_sysdate               DATE:=SYSDATE;
  v_event_source          VARCHAR2(60);
  v_exist                 INT;
  v_series_diff           NUMBER;
  v_IMSI_pref             VARCHAR2(300);
  v_host_id               NUMBER;
  v_sim_series_id         sim_series.sim_series_id%TYPE;
  v_exists                INT;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check input parameters
 IF p_network_operator_id IS NULL OR p_ICCID_prefix IS NULL OR p_HLR_Code IS NULL OR p_MSISDN_Start IS NULL OR
     p_MSISDN_End IS NULL OR p_user_id IS NULL OR p_IMSI_Start IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameter.');
  END IF;

--------------------------------------------------------------------------------------------------
  DELETE FROM tt_batch_na_ap;

  -- check if all series are on the proper HLR
  SELECT COUNT(1)
  INTO v_exist
  FROM phone_number_series pns
  JOIN host h ON h.host_id=pns.host_id
  WHERE to_number(pns.country_code || pns.area_code || pns.local_number_start)<=to_number(p_MSISDN_end)
    AND to_number(pns.country_code || pns.area_code || pns.local_number_end)>=to_number(p_MSISDN_Start)
    AND length(trim(pns.country_code || pns.area_code || pns.local_number_start))=length(TRIM(p_MSISDN_Start))
    AND h.host_code<>p_HLR_Code;

  IF v_exist > 0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NOT_SAME_HOSTS, 'Series are not on the same HLR.');
  END IF;

  -- check if all phone numbers are not linked
  SELECT COUNT(1)
  INTO v_exists
  FROM dual
  WHERE EXISTS(SELECT /*+ index(pn UK_PHONE_NUM_PHONE_NUMBER) index(naap I_NETADDRACCPO_NET_ADDRESS_ID) */ 1
               FROM phone_number pn
               JOIN network_address_access_point naap ON naap.network_address_id=pn.network_address_id
                    AND v_sysdate BETWEEN naap.from_date AND nvl(naap.to_date,v_sysdate)
               WHERE pn.international_format BETWEEN p_MSISDN_Start AND p_MSISDN_End);

  IF v_exists > 0 THEN -- change error number
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_PHONES_ALREADY_LINKED, 'Phones already linked.');
  END IF;

  BEGIN
    SELECT h.host_id
    INTO v_host_id
    FROM host h
    WHERE h.host_code=p_HLR_Code
      AND h.deleted IS NULL;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Host deleted.');
  END;

  -- difference between SIM series and phone series
  v_series_diff := to_number(substr(p_MSISDN_Start,-c_IMSI_LN_length))-to_number(substr(p_IMSI_Start,-c_IMSI_LN_length));

  v_IMSI_pref := substr(p_IMSI_Start,1,length(p_IMSI_Start)-c_IMSI_LN_length);


  rsig_sim_series.Insert_Sim_Series
           (to_char(to_number(v_IMSI_pref || substr(p_MSISDN_Start,-c_IMSI_LN_length)) - v_series_diff),
            to_char(to_number(v_IMSI_pref || substr(p_MSISDN_End,-c_IMSI_LN_length)) - v_series_diff),
            rsig_utils.c_MULTI_SIM_CARD,
            v_host_id,
            null, --!_!p_subhost_id
            p_network_operator_id,
            p_AP_Prod_Status,
            p_user_id,
            rsig_utils.c_HANDLE_TRAN_N,
            rsig_utils.c_YES,
            v_sim_series_id,
            p_error_code,
            p_error_message);

  -- create IMSI and ICCID
  INSERT INTO tt_batch_na_ap(NETWORK_ADDRESS_ID,international_format,access_point_id)
  SELECT /*+ index(pn UK_PHONE_NUM_PHONE_NUMBER) */
         pn.network_address_id,
         pn.International_Format,
         s_access_point.nextval
  FROM phone_number pn
  WHERE pn.international_format BETWEEN p_MSISDN_Start AND p_MSISDN_End;

  -- insert into access_point
  INSERT INTO access_point(access_point_id)
  SELECT t.access_point_id
  FROM tt_batch_na_ap t;

  -- insert into sim_card
  BEGIN
    IF v_series_diff=0 THEN
      INSERT INTO sim_card(access_point_id,imsi,sn,sim_series_id,
                           msisdn_bound,user_id_of_change,date_of_change)
      SELECT t.access_point_id,
             v_IMSI_pref || substr(t.international_format,-c_IMSI_LN_length),
             p_ICCID_prefix || substr(t.international_format,-c_IMSI_LN_length)
             || Create_Control_Number(p_ICCID_prefix || substr(t.international_format,-c_IMSI_LN_length)),
             v_sim_series_id,
             t.international_format,
             p_user_id,
             v_sysdate
      FROM tt_batch_na_ap t;

       -- insert addition imsis
      INSERT INTO SIM_IMSI
             (ACCESS_POINT_ID,
              IMSI,
              SIM_SERIES_ID,
              IMSI_TYPE_CODE)
       SELECT t.access_point_id,
              v_IMSI_pref || substr(t.international_format,-c_IMSI_LN_length),
              v_sim_series_id,
              vp_sim_imsi.get_imsi_type_main
         FROM tt_batch_na_ap t;
    ELSE
      INSERT INTO sim_card(access_point_id,imsi,sn,sim_series_id,
                  msisdn_bound,user_id_of_change,date_of_change)
      SELECT t.access_point_id,
             to_char(to_number(v_IMSI_pref || substr(t.international_format,-c_IMSI_LN_length)) - v_series_diff),
             p_ICCID_prefix || substr(t.international_format,-c_IMSI_LN_length)
             || Create_Control_Number(p_ICCID_prefix || substr(t.international_format,-c_IMSI_LN_length)),
             v_sim_series_id,
             t.international_format,
             p_user_id,
             v_sysdate
      FROM tt_batch_na_ap t;

       -- insert addition imsis
      INSERT INTO SIM_IMSI
             (ACCESS_POINT_ID,
              IMSI,
              SIM_SERIES_ID,
              IMSI_TYPE_CODE)
       SELECT t.access_point_id,
              to_char(to_number(v_IMSI_pref || substr(t.international_format,-c_IMSI_LN_length)) - v_series_diff),
              v_sim_series_id,
              vp_sim_imsi.get_imsi_type_main
         FROM tt_batch_na_ap t;
    END IF;
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      IF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_SIM_SN THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DUP_ICCID, 'Duplicit ICCID');
      END IF;
      IF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_SIM_MSIDN_BOUND THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DUP_MSISDN_BOUND, 'Duplicit MSISDN Bound');
      END IF;
      RAISE;
  END;

  -- insert link between phone and sim
  INSERT INTO network_address_access_point(access_point_id,
                                             network_address_id,
                                             link_type_code,
                                             from_date,
                                             to_date,
                                             date_of_change,
                                             user_id_of_change)
  SELECT t.access_point_id,
             t.network_address_id,
             rsig_utils.c_MAIN_LINK_TYPE,
             v_sysdate,
             NULL,
             SYSDATE,
             p_user_id
  FROM tt_batch_na_ap t;

  -- insert into access_point_status_history
  INSERT INTO access_point_status_history
         (access_point_status_code,
          access_point_id,
          start_date,
          user_id_of_change,
          date_of_change)
  SELECT p_AP_Status,
         t.access_point_id,
         v_sysdate,
         p_user_id,
         v_sysdate
  FROM tt_batch_na_ap t;

  -- insert into ap_prod_status_hist
  INSERT INTO ap_prod_status_hist
         (access_point_id,
          ap_prod_status_code,
          start_date,
          user_id_of_change,
          date_of_change)
  SELECT t.access_point_id,
         p_AP_Prod_Status,
         v_sysdate,
         p_user_id,
         v_sysdate
  FROM tt_batch_na_ap t;

  p_sim_series_id:=v_sim_series_id;

---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,p_handle_tran,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Create_bound_SIM_Series;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Create_unbound_SIM_Series
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Create_unbound_SIM_Series(
  p_network_operator_id   IN  network_operator.network_operator_id%TYPE,
  p_ICCID_prefix          IN  VARCHAR2,
  p_HLR_Code              IN  host.host_code%TYPE,
  p_IMSI_Start            IN  sim_card.imsi%TYPE,
  p_IMSI_End              IN  sim_card.imsi%TYPE,
  p_ap_status             IN  access_point_status_history.access_point_status_code%TYPE,
  p_ap_prod_status        IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_user_id               IN  NUMBER,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_sim_series_id         OUT sim_series.sim_series_id%TYPE,
  p_error_code            OUT NUMBER,
  p_error_message	  OUT VARCHAR2
)
IS
  v_package_name          VARCHAR2(30) := 'UMC';
  v_procedure_name        VARCHAR2(30) := 'Create_unbound_SIM_Series';
  v_sysdate               DATE:=SYSDATE;
  v_event_source          VARCHAR2(60);
  v_host_id               host.host_id%TYPE;
  v_sim_series_id         sim_series.sim_series_id%TYPE;
  v_IMSI_l                common.t_IMSI;
  v_ICCID_l               common.t_ICCID;
  i                       NUMBER:=0;
  v_act_IMSI              NUMBER;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check input parameters
  IF p_network_operator_id IS NULL OR p_ICCID_prefix IS NULL OR p_HLR_Code IS NULL OR
     p_user_id IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameter.');
  END IF;

--------------------------------------------------------------------------------------------------
  DELETE FROM tt_batch_na_ap;

  BEGIN
    SELECT h.host_id
    INTO v_host_id
    FROM host h
    WHERE h.host_code=p_HLR_Code
      AND h.deleted IS NULL;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Host deleted.');
  END;

  rsig_sim_series.Insert_Sim_Series(
            p_IMSI_Start,
            p_IMSI_End,
            rsig_utils.c_MULTI_SIM_CARD,
            v_host_id,
            null, --!_!p_subhost_id
            p_network_operator_id,
            p_AP_Prod_Status,
            p_user_id,
            rsig_utils.c_HANDLE_TRAN_N,
            rsig_utils.c_YES,
            v_sim_series_id,
            p_error_code,
            p_error_message);

  -- create IMSI and ICCID
  v_act_IMSI:=to_number(p_IMSI_Start);

  WHILE v_act_IMSI<=to_number(p_IMSI_End) LOOP
    i:=i+1;
    v_IMSI_l(i):=to_char(v_act_IMSI);
    v_ICCID_l(i):=p_ICCID_prefix || substr(to_char(v_act_IMSI),-c_IMSI_LN_length);
    v_act_IMSI:=v_act_IMSI+1;
  END LOOP;


  FORALL j IN v_IMSI_l.FIRST .. v_IMSI_l.LAST
  INSERT INTO tt_batch_na_ap(imsi,sn,access_point_id)
  VALUES(v_IMSI_l(j),v_ICCID_l(j),s_access_point.NEXTVAL);

  -- insert into access_point
  INSERT INTO access_point(access_point_id)
  SELECT t.access_point_id
  FROM tt_batch_na_ap t;

  -- insert into sim_card
  BEGIN
    INSERT INTO sim_card(access_point_id,imsi,sn,sim_series_id,User_Id_Of_Change,date_of_change)
    SELECT t.access_point_id,
           t.imsi,
           --t.sn,
           t.sn || Create_Control_Number(t.sn),
           v_sim_series_id,
           p_user_id,
           v_sysdate
    FROM tt_batch_na_ap t;

       -- insert addition imsis
    INSERT INTO SIM_IMSI
           (ACCESS_POINT_ID,
            IMSI,
            SIM_SERIES_ID,
            IMSI_TYPE_CODE)
     SELECT t.access_point_id,
            t.imsi,
            v_sim_series_id,
            vp_sim_imsi.get_imsi_type_main
       FROM tt_batch_na_ap t;
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      IF rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_SIM_SN THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Duplicit ICCID');
      ELSE
        RAISE;
      END IF;
  END;

  -- insert into access_point_status_history
  INSERT INTO access_point_status_history
         (access_point_status_code,
          access_point_id,
          start_date,
          user_id_of_change,
          date_of_change)
  SELECT p_AP_Status,
         t.access_point_id,
         v_sysdate,
         p_user_id,
         v_sysdate
  FROM tt_batch_na_ap t;

  -- insert into ap_prod_status_hist
  INSERT INTO ap_prod_status_hist
         (access_point_id,
          ap_prod_status_code,
          start_date,
          user_id_of_change,
          date_of_change)
  SELECT t.access_point_id,
         p_AP_Prod_Status,
         v_sysdate,
         p_user_id,
         v_sysdate
  FROM tt_batch_na_ap t;

  p_sim_series_id:=v_sim_series_id;

---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,p_handle_tran,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Create_unbound_SIM_Series;

------------------------------------------------------------------------------------------------------------------------------
--  Get_SIM_Status_Ex
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_SIM_Status_Ex(
  p_validity_date          IN  DATE,
  p_IMSI_Start             IN  sim_card.imsi%TYPE,
  p_IMSI_End               IN  sim_card.imsi%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'UMC';
  v_procedure_name        VARCHAR2(30) := 'Get_SIM_Status_Ex';
  v_event_source          VARCHAR2(60);
  v_validity_date         DATE;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF p_IMSI_Start IS NULL OR p_IMSI_End IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  v_validity_date:=nvl(p_validity_date,SYSDATE);
---------------------------------------------------------------------------------------------------------

OPEN p_result_list FOR
  SELECT /*+ index(sc I_IMSI_ACCESS_POINT_ID) use_nl(sc apsh) index(apsh I_ACCPOSTAHI_ACCESS_POINT_ID) */
         sc.imsi as imsi,
         apsh.ap_trans_reason_code as ap_trans_reason_code,
         trim(apsh.access_point_status_code) as access_point_status_code
  FROM sim_card sc
  JOIN access_point_status_history apsh ON apsh.access_point_id=sc.access_point_id
  WHERE sc.imsi BETWEEN p_IMSI_Start AND p_IMSI_End
    AND (v_validity_date>=apsh.start_date AND (v_validity_date<=apsh.end_date OR apsh.end_date IS NULL));

---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    OPEN p_result_list FOR SELECT p_error_code FROM dual;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_SIM_Status_Ex;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Set_SIM_Production_Status
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Set_SIM_Production_Status(
  p_IMSI_Start_l          IN  common.t_IMSI,
  p_IMSI_End_l            IN  common.t_IMSI,
  p_SIM_Prod_Status_l     IN  t_status,
  p_user_login            IN  VARCHAR2,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message	        OUT VARCHAR2,
  p_result_list           OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'UMC';
  v_procedure_name        VARCHAR2(30) := 'Set_SIM_Production_Status';
  v_event_source          VARCHAR2(60);
  v_user_id               NUMBER;
  v_sysdate               DATE:=SYSDATE;

  CURSOR c_sims IS
  SELECT t.access_point_id
  FROM tt_batch_na_ap t
  JOIN sim_card sc ON sc.imsi BETWEEN t.imsi AND t.international_format
  FOR UPDATE;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check existence of user
  v_user_id := Rsig_users.Get_user_id_by_login(p_user_login);

  -- check input parameters
  IF p_IMSI_Start_l.COUNT = 0 OR (p_IMSI_Start_l.COUNT = 1 AND p_IMSI_Start_l(1) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF p_IMSI_End_l.COUNT = 0 OR (p_IMSI_End_l.COUNT = 1 AND p_IMSI_End_l(1) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF p_IMSI_Start_l.COUNT <> p_IMSI_End_l.COUNT THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF p_SIM_Prod_Status_l.COUNT = 0 OR (p_SIM_Prod_Status_l.COUNT = 1 AND p_SIM_Prod_Status_l(1) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF p_IMSI_Start_l.COUNT <> p_SIM_Prod_Status_l.COUNT
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  DELETE FROM tt_batch_na_ap;
--------------------------------------------------------------------------------------------------
  FORALL i IN p_IMSI_Start_l.FIRST .. p_IMSI_Start_l.LAST
  INSERT INTO tt_batch_na_ap(imsi,international_format,status,RESULT)
  VALUES(p_IMSI_Start_l(i),p_IMSI_End_l(i),p_SIM_Prod_Status_l(i),rsig_utils.c_OK);

  -- lock sim cards with changed status
  OPEN c_sims;
  CLOSE c_sims;

  -- mark ranges when some sim card can not be changed to given status
  UPDATE tt_batch_na_ap t
  SET t.result=rsig_utils.c_CHANGE_SP_STATUS_NOT_ALW
  WHERE EXISTS(SELECT /*+ index(sc I_IMSI_ACCESS_POINT_ID) */ 1
               FROM sim_card sc
               WHERE sc.imsi BETWEEN t.imsi AND t.international_format
                 AND rsig_access_point_status.Is_Prod_Status_Change_Allowed(
                                               sc.access_point_id,
                                               t.status,
                                               rsig_utils.c_YES,
                                               v_sysdate)<>rsig_utils.c_OK);

  -- terminate old status
  UPDATE /*+ ORDERED USE_NL(apsh) */
       ap_prod_status_hist apsh
  SET apsh.end_date=v_sysdate - rsig_utils.c_INTERVAL_DIFFERENCE,
      apsh.user_id_of_change=v_user_id,
      apsh.date_of_change=v_sysdate
  WHERE apsh.access_point_id IN (SELECT /*+ FIRST_ROWS */
                                        sc.access_point_id
                                 FROM tt_batch_na_ap t
                                 JOIN sim_card sc ON sc.imsi BETWEEN t.imsi AND t.international_format
                                 WHERE t.result=rsig_utils.c_OK);
  -- insert new status
  INSERT INTO ap_prod_status_hist
         (access_point_id,
          ap_prod_status_code,
          start_date,
          user_id_of_change,
          date_of_change)
  SELECT /*+ FIRST_ROWS */
         sc.access_point_id,
         t.status,
         v_sysdate,
         v_user_id,
         v_sysdate
  FROM tt_batch_na_ap t
  JOIN sim_card sc ON sc.imsi BETWEEN t.imsi AND t.international_format
  WHERE t.result=rsig_utils.c_OK;

  OPEN p_result_list FOR
  SELECT t.imsi IMSI_Start,
         t.international_format IMSI_End,
         t.status SIM_Prod_Status,
         t.RESULT ERROR_CODE
  FROM tt_batch_na_ap t;

---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,p_handle_tran,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    OPEN p_result_list FOR SELECT p_error_code FROM dual;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Set_SIM_Production_Status;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Set_SIM_Card_Details
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Set_SIM_Card_Details(
  p_IMSI_l                IN  common.t_IMSI,
  p_ICCID_l               IN  common.t_ICCID,
  p_PIN_l                 IN  t_pin,
  p_PIN2_l                IN  t_pin,
  p_PUK_l                 IN  t_puk,
  p_PUK2_l                IN  t_puk,
  p_user_login            IN  VARCHAR2,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message	        OUT VARCHAR2
)
IS
  v_package_name          VARCHAR2(30) := 'UMC';
  v_procedure_name        VARCHAR2(30) := 'Set_SIM_Card_Details';
  v_event_source          VARCHAR2(60);
  v_user_id               NUMBER;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check existence of user
  v_user_id := Rsig_users.Get_user_id_by_login(p_user_login);

  -- check input parameters
  IF (p_IMSI_l IS NULL) OR
     (p_IMSI_l.COUNT = 0) OR
     (p_IMSI_l.COUNT = 1 AND p_IMSI_l(p_IMSI_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  IF (p_ICCID_l IS NULL) OR
     (p_ICCID_l.COUNT = 0) OR
     (p_ICCID_l.COUNT = 1 AND p_ICCID_l(p_ICCID_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  IF p_IMSI_l.COUNT <> p_ICCID_l.COUNT OR
     p_IMSI_l.COUNT <> p_PIN_l.COUNT OR
     p_IMSI_l.COUNT <> p_PIN2_l.COUNT OR
     p_IMSI_l.COUNT <> p_PUK_l.COUNT OR
     p_IMSI_l.COUNT <> p_PUK2_l.COUNT
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

--------------------------------------------------------------------------------------------------
  FORALL i IN p_IMSI_l.FIRST .. p_IMSI_l.LAST
  UPDATE sim_card sc
  SET sc.sn=p_ICCID_l(i),
      sc.pin=p_PIN_l(i),
      sc.pin2=p_PIN2_l(i),
      sc.puk=p_PUK_l(i),
      sc.puk2=p_PUK2_l(i),
      sc.user_id_of_change=v_user_id,
      sc.date_of_change=SYSDATE
  WHERE sc.imsi=p_IMSI_l(i);

---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,p_handle_tran,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Set_SIM_Card_Details;

	-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Set_SIM_Card_Details_Ex
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Set_SIM_Card_Details_Ex(
  p_IMSI_l                IN  common.t_IMSI,
  p_ICCID_l               IN  common.t_ICCID,
  p_PIN_l                 IN  t_pin,
  p_PIN2_l                IN  t_pin,
  p_PUK_l                 IN  t_puk,
  p_PUK2_l                IN  t_puk,
  p_KI_l                  IN  t_ki,
  p_ADM1_l                IN  t_adm1,
  p_AccessControl_l       IN  t_ki,
  p_user_id               IN  NUMBER,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message	        OUT VARCHAR2
)
IS
  v_package_name          VARCHAR2(30) := 'UMC';
  v_procedure_name        VARCHAR2(30) := 'Set_SIM_Card_Details';
  v_event_source          VARCHAR2(60);
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check input parameters
  IF (p_IMSI_l IS NULL) OR
     (p_IMSI_l.COUNT = 0) OR
     (p_IMSI_l.COUNT = 1 AND p_IMSI_l(p_IMSI_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  IF (p_ICCID_l IS NULL) OR
     (p_ICCID_l.COUNT = 0) OR
     (p_ICCID_l.COUNT = 1 AND p_ICCID_l(p_ICCID_l.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  IF p_IMSI_l.COUNT <> p_ICCID_l.COUNT OR
     p_IMSI_l.COUNT <> p_PIN_l.COUNT OR
     p_IMSI_l.COUNT <> p_PIN2_l.COUNT OR
     p_IMSI_l.COUNT <> p_PUK_l.COUNT OR
     p_IMSI_l.COUNT <> p_PUK2_l.COUNT OR
     p_IMSI_l.COUNT <> p_KI_l.COUNT OR
     p_IMSI_l.COUNT <> p_ADM1_l.COUNT OR
     p_IMSI_l.COUNT <> p_AccessControl_l.COUNT
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

--------------------------------------------------------------------------------------------------
  FORALL i IN p_IMSI_l.FIRST .. p_IMSI_l.LAST
  UPDATE sim_card sc
  SET
      sc.sn=decode(p_ICCID_l(i), ' ', sc.sn, p_ICCID_l(i)),
      sc.pin=decode(p_PIN_l(i), ' ', null, p_PIN_l(i)),
      sc.pin2=decode(p_PIN2_l(i), ' ', null, p_PIN2_l(i)),
      sc.puk=decode(p_PUK_l(i), ' ', null, p_PUK_l(i)),
      sc.puk2=decode(p_PUK2_l(i), ' ', null, p_PUK2_l(i)),
      sc.KI=decode(p_KI_l(i), ' ', null, p_KI_l(i)),
      sc.ADM1=decode(p_ADM1_l(i), ' ', null, p_ADM1_l(i)),
      sc.Access_Control=decode(p_AccessControl_l(i), ' ', null, p_AccessControl_l(i)),
      sc.USER_ID_OF_CHANGE = p_user_id
  WHERE sc.imsi=p_IMSI_l(i);
---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,p_handle_tran,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Set_SIM_Card_Details_Ex;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_Sim_Cards_By_ICCID_List
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE get_sim_cards_by_iccid_list (
   p_hlr_l                      IN       t_ki,
   p_network_operator_code      IN       VARCHAR2,
   p_access_point_status_code   IN       access_point_status_history.access_point_status_code%TYPE,
   p_sim_card_type_code         IN       t_ki,
   p_ap_prod_status_code        IN       sim_series_status_validity.status_code%TYPE,
   p_sn_list                    IN       t_ki,
   p_date_op                    IN       DATE,
   p_only_linked                IN       NUMBER,
   p_handle_tran                IN       CHAR DEFAULT rsig_utils.c_handle_tran_y,
   p_raise_error                IN       CHAR DEFAULT rsig_utils.c_no,
   p_error_code                 OUT      NUMBER,
   p_error_message              OUT      VARCHAR2,
   p_result_list                OUT      sys_refcursor
)
IS
   v_package_name     VARCHAR2 (30) := 'UMC';
   v_procedure_name   VARCHAR2 (30) := 'Get_Sim_Cards_By_ICCID_List';
   v_event_source     VARCHAR2 (60);
   i                  NUMBER;
   sn                 VARCHAR2 (60);
   v_SC_Type_Any      CHAR;
BEGIN
   v_event_source := v_package_name || '.' || v_procedure_name;
   -- log start of procedure
   common.event_logger (rsig_utils.c_debug_text_start,
                        rsig_utils.c_debug_level_1,
                        rsig_utils.c_debug_event_type_d,
                        v_event_source
                       );

   -- check input parameters
   IF p_access_point_status_code IS NULL OR p_ap_prod_status_code IS NULL
   THEN
      raise_application_error (rsig_utils.c_ora_missing_parameter, 'Missing some mandatory parameter.');
   END IF;

   DELETE FROM TT_BATCH_PERSONAL_ACCOUNT;

   IF p_sn_list.COUNT = 0 OR (p_sn_list.COUNT = 1 AND p_sn_list(1) IS NULL)
   THEN
     --p_sn_list is not null
     IF (NOT (p_hlr_l.COUNT = 0 OR (p_hlr_l.COUNT = 1 AND p_hlr_l(1) IS NULL))) AND (p_hlr_l (1) <> '%')
     THEN
       --p_hlr_l is not null and p_hlr_l <> '%'
       FORALL i IN NVL (p_hlr_l.FIRST, 1) .. NVL (p_hlr_l.LAST, 0)
         INSERT INTO TT_BATCH_PERSONAL_ACCOUNT
                       (host_id
                       )
                VALUES (p_hlr_l (i)
                       );
     ELSE
       --p_hlr_l is null or p_hlr_l = '%'
       IF p_network_operator_code IS NOT NULL
       THEN
         INSERT INTO TT_BATCH_PERSONAL_ACCOUNT (host_id)
           SELECT hh.host_id
             FROM HOST hh JOIN network_operator n_o ON n_o.network_operator_id = hh.network_operator_id
               WHERE n_o.network_operator_code = p_network_operator_code AND hh.host_type_code = 'HL';
       ELSE
         raise_application_error (rsig_utils.c_ora_missing_parameter, 'Missing some mandatory parameter.');
       END IF;
     END IF;
   ELSE
     --p_sn_list is null
     IF NOT (p_hlr_l.COUNT = 0 OR (p_hlr_l.COUNT = 1 AND p_hlr_l(1) IS NULL))
     THEN
       IF p_network_operator_code IS NOT NULL
       THEN
         INSERT INTO TT_BATCH_PERSONAL_ACCOUNT (host_id)
           SELECT hh.host_id
             FROM HOST hh JOIN network_operator n_o ON n_o.network_operator_id = hh.network_operator_id
              WHERE n_o.network_operator_code = p_network_operator_code AND hh.host_type_code = 'HL';
       ELSE
         IF p_hlr_l.COUNT <> 1
         THEN
           FORALL i IN NVL (p_hlr_l.FIRST, 1) .. NVL (p_hlr_l.LAST, 0)
             INSERT INTO TT_BATCH_PERSONAL_ACCOUNT
                         (host_id
                         )
                  VALUES (p_hlr_l (i)
                         );
         ELSE
           IF p_hlr_l (1) = '%'
           THEN
             raise_application_error (rsig_utils.c_ora_missing_parameter, 'Missing some mandatory parameter.');
           ELSE
             INSERT INTO TT_BATCH_PERSONAL_ACCOUNT
                         (host_id
                         )
                  VALUES (p_hlr_l (1)
                         );
           END IF;
         END IF;
       END IF;
     END IF;
   END IF;

   DELETE FROM tt_iccid_by_phone_list;   --TT_IMPORT_SIM_CARD

   FORALL i IN NVL (p_sn_list.FIRST, 1) .. NVL (p_sn_list.LAST, 0)
      INSERT INTO tt_iccid_by_phone_list
                  (iccid
                  )
           VALUES (p_sn_list (i)
                  );

   DELETE      tt_phone_link;

   v_SC_Type_Any := 'N';

   IF p_sim_card_type_code.COUNT = 0 OR (p_sim_card_type_code.COUNT = 1 AND p_sim_card_type_code(1) IS NULL)
   THEN
      v_SC_Type_Any := 'Y';
   ELSE
      FORALL i IN NVL (p_sim_card_type_code.FIRST, 1) .. NVL (p_sim_card_type_code.LAST, 0)
      	INSERT INTO tt_phone_link
                  (linked_msisdn
                  )
        VALUES (p_sim_card_type_code (i)
                  );
   END IF;

   delete from tt_find_sim_cards;

   IF p_sn_list.COUNT = 0 OR (p_sn_list.COUNT = 1 AND p_sn_list(1) IS NULL)
   THEN
      OPEN p_result_list FOR
         select * from (
         SELECT ss.sim_series_id, sc.sn ICCID, ss.host_id, p_network_operator_code network_operator_code, ss.sim_card_type_code,
                apsh.access_point_status_code, NVL (appsh.ap_prod_status_code, sssv.status_code) ap_prod_status_code,
                pn.international_format Phone_number, pn.salability_category_code salability_category, pns.phone_number_type_code phone_number_type,
                pn.net_address_status_code network_address_status, rsig_utils.c_ok Error_code--, naap.NETWORK_ADDRESS_ID
           FROM TT_BATCH_PERSONAL_ACCOUNT tt INNER JOIN sim_series ss
                ON ss.host_id = tt.host_id
                AND (v_SC_Type_Any = 'Y'
                OR
                (RTRIM (ss.sim_card_type_code) IN (SELECT RTRIM (tt2.linked_msisdn)
                                                      FROM tt_phone_link tt2)))
              AND (p_date_op >= ss.date_of_change AND (p_date_op <= ss.deleted OR ss.deleted IS NULL))
                INNER JOIN sim_card sc
                ON sc.sim_series_id = ss.sim_series_id
              AND (p_date_op >= sc.date_of_change AND (p_date_op <= sc.deleted OR sc.deleted IS NULL))
                INNER JOIN access_point_status_history apsh
                ON apsh.access_point_id = sc.access_point_id
              AND RTRIM (apsh.access_point_status_code) = RTRIM (p_access_point_status_code)
              AND (p_date_op >= apsh.start_date AND (p_date_op <= apsh.end_date OR apsh.end_date IS NULL))
                LEFT JOIN ap_prod_status_hist appsh
                ON appsh.access_point_id = sc.access_point_id
              AND (p_date_op >= appsh.start_date AND (p_date_op <= appsh.end_date OR appsh.end_date IS NULL))
                LEFT JOIN sim_series_status_validity sssv
                ON sssv.sim_series_id = ss.sim_series_id
              AND (p_date_op >= sssv.start_date AND (p_date_op <= sssv.end_date OR sssv.end_date IS NULL))
                LEFT JOIN network_address_access_point naap
                ON naap.access_point_id = sc.access_point_id
                AND naap.link_type_code = rsig_utils.c_main_link_type
                AND (p_date_op >= naap.from_date AND (p_date_op <= naap.TO_DATE OR naap.TO_DATE IS NULL))
                and (p_only_linked = 0 OR (p_only_linked = 1 and naap.NETWORK_ADDRESS_ID is not null))
              LEFT JOIN phone_number pn
                ON pn.network_address_id = naap.network_address_id
              AND (p_date_op >= pn.date_of_change AND (p_date_op <= pn.deleted OR pn.deleted IS NULL))
                LEFT JOIN phone_number_series pns
                ON pns.phone_number_series_id = pn.phone_number_series_id
              AND (p_date_op >= pns.date_of_change AND (p_date_op <= pns.deleted OR pns.deleted IS NULL))) t
          WHERE RTRIM (t.ap_prod_status_code) = RTRIM (p_ap_prod_status_code)
          ;
   ELSE
      INSERT INTO tt_find_sim_cards
                  (sn, imsi, host_id, sim_card_type_code, ap_prod_status_code, access_point_status_code, sim_series_id,
                   access_point_id, network_operator_code, msisdn, salability_category, phone_number_type_code,
                   network_adress_status_code, RESULT)
         SELECT tt.iccid, sc.imsi, ss.host_id, ss.sim_card_type_code,
                NVL (psh.ap_prod_status_code, sssv.status_code) ap_prod_status_code, apsh.access_point_status_code,
                ss.sim_series_id, sc.access_point_id, p_network_operator_code, pn.international_format,
                pn.salability_category_code, pns.phone_number_type_code, pn.net_address_status_code, rsig_utils.c_ok
           FROM tt_iccid_by_phone_list tt LEFT JOIN sim_card sc
                ON tt.iccid = sc.sn
              AND (p_date_op >= sc.date_of_change AND (p_date_op <= sc.deleted OR sc.deleted IS NULL))
                LEFT JOIN ap_prod_status_hist psh
                ON psh.access_point_id = sc.access_point_id
              AND (p_date_op >= psh.start_date AND (p_date_op <= psh.end_date OR psh.end_date IS NULL))
                LEFT JOIN sim_series ss
                ON ss.sim_series_id = sc.sim_series_id
              AND (p_date_op >= ss.date_of_change AND (p_date_op <= ss.deleted OR ss.deleted IS NULL))
                LEFT JOIN access_point_status_history apsh
                ON apsh.access_point_id = sc.access_point_id
              AND (p_date_op >= apsh.start_date AND (p_date_op <= apsh.end_date OR apsh.end_date IS NULL))
                LEFT JOIN sim_series_status_validity sssv
                ON sssv.sim_series_id = ss.sim_series_id
              AND (p_date_op >= sssv.start_date AND (p_date_op <= sssv.end_date OR sssv.end_date IS NULL))
                LEFT JOIN network_address_access_point naap
                ON naap.access_point_id = sc.access_point_id
              AND naap.link_type_code = rsig_utils.c_main_link_type
              AND (p_date_op >= naap.from_date AND (p_date_op <= naap.TO_DATE OR naap.TO_DATE IS NULL))
                LEFT JOIN phone_number pn
                ON naap.network_address_id = pn.network_address_id
              AND (p_date_op >= pn.date_of_change AND (p_date_op <= pn.deleted OR pn.deleted IS NULL))
                LEFT JOIN phone_number_series pns
                ON pns.phone_number_series_id = pn.phone_number_series_id
              AND (p_date_op >= pns.date_of_change AND (p_date_op <= pns.deleted OR pns.deleted IS NULL))
                ;

      UPDATE tt_find_sim_cards tt
         SET RESULT = rsig_utils.c_sim_card_not_exists
       WHERE tt.imsi IS NULL AND RESULT = rsig_utils.c_ok;

      UPDATE tt_find_sim_cards tt
         SET RESULT = rsig_utils.c_not_same_host_id
       WHERE tt.host_id NOT IN (SELECT host_id
                                  FROM TT_BATCH_PERSONAL_ACCOUNT) AND RESULT = rsig_utils.c_ok;

      UPDATE tt_find_sim_cards tt
         SET RESULT = rsig_utils.c_sim_invalid_ps
       WHERE RTRIM (tt.ap_prod_status_code) <> RTRIM (p_ap_prod_status_code) AND RESULT = rsig_utils.c_ok;

      UPDATE tt_find_sim_cards tt
         SET RESULT = rsig_utils.c_sim_invalid_status
       WHERE RTRIM (tt.access_point_status_code) <> RTRIM (p_access_point_status_code) AND RESULT = rsig_utils.c_ok;

      IF (v_SC_Type_Any = 'N')
      THEN
          UPDATE tt_find_sim_cards tt
             SET RESULT = rsig_utils.c_sim_invalid_type
           WHERE RTRIM (tt.sim_card_type_code) NOT IN (SELECT RTRIM (linked_msisdn)
                                                     FROM tt_phone_link) AND RESULT = rsig_utils.c_ok;
      END IF;


      IF (p_only_linked <> 0)
      THEN
         UPDATE tt_find_sim_cards tt
            SET RESULT = rsig_utils.c_link_na_and_ap_not_ex
          WHERE tt.msisdn IS NULL AND RESULT = rsig_utils.c_ok;
      END IF;

      OPEN p_result_list FOR
         SELECT t.sim_series_id, t.sn, t.host_id, t.network_operator_code, t.sim_card_type_code,
                t.access_point_status_code, t.ap_prod_status_code, t.msisdn, t.salability_category,
                t.phone_number_type_code, t.network_adress_status_code, t.RESULT
           FROM tt_find_sim_cards t;
   END IF;

   IF (p_handle_tran = rsig_utils.c_handle_tran_y)
   THEN
      COMMIT;
   END IF;

   -- log end of procedure
   common.event_logger (rsig_utils.c_debug_text_end,
                        rsig_utils.c_debug_level_1,
                        rsig_utils.c_debug_event_type_d,
                        v_event_source
                       );
   p_error_code := rsig_utils.c_ok;   -- succesfully completed
EXCEPTION
   WHEN OTHERS
   THEN
      p_error_code := common.handle_error (SQLCODE, p_handle_tran, v_package_name, v_procedure_name);
      p_error_message := SQLERRM;

      IF UPPER (p_raise_error) = rsig_utils.c_yes
      THEN
         RAISE;
      END IF;
END get_sim_cards_by_iccid_list;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Get_Sim_Cards_By_ICCID_List_1
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE get_sim_cards_by_iccid_list_1 (
   p_hlr_l                      IN       t_ki,
   p_network_operator_code      IN       VARCHAR2,
   p_access_point_status_code   IN       access_point_status_history.access_point_status_code%TYPE,
   p_ap_trans_reason_code       IN       access_point_status_history.ap_trans_reason_code%TYPE,
   p_sim_card_type_code         IN       t_ki,
   p_ap_prod_status_code        IN       sim_series_status_validity.status_code%TYPE,
   p_sn_list                    IN       t_ki,
   p_date_op                    IN       DATE,
   p_date_from                  IN       DATE,
   p_date_to                    IN       DATE,
   p_only_linked                IN       NUMBER,
   p_handle_tran                IN       CHAR DEFAULT rsig_utils.c_handle_tran_y,
   p_raise_error                IN       CHAR DEFAULT rsig_utils.c_no,
   p_error_code                 OUT      NUMBER,
   p_error_message              OUT      VARCHAR2,
   p_result_list                OUT      sys_refcursor
)
IS
   v_package_name     VARCHAR2 (30) := 'UMC';
   v_procedure_name   VARCHAR2 (30) := 'Get_Sim_Cards_By_ICCID_List_1';
   v_event_source     VARCHAR2 (60);
   i                  NUMBER;
   sn                 VARCHAR2 (60);
   v_SC_Type_Any      CHAR;
BEGIN
   v_event_source := v_package_name || '.' || v_procedure_name;
   -- log start of procedure
   common.event_logger (rsig_utils.c_debug_text_start,
                        rsig_utils.c_debug_level_1,
                        rsig_utils.c_debug_event_type_d,
                        v_event_source
                       );

   -- check input parameters
   IF p_access_point_status_code IS NULL OR p_ap_prod_status_code IS NULL
   THEN
      raise_application_error (rsig_utils.c_ora_missing_parameter, 'Missing some mandatory parameter.');
   END IF;

   DELETE FROM TT_BATCH_PERSONAL_ACCOUNT;

   IF p_sn_list.COUNT = 0 OR (p_sn_list.COUNT = 1 AND p_sn_list(1) IS NULL)
   THEN
     --p_sn_list is not null
     IF (NOT (p_hlr_l.COUNT = 0 OR (p_hlr_l.COUNT = 1 AND p_hlr_l(1) IS NULL))) AND (p_hlr_l (1) <> '%')
     THEN
       --p_hlr_l is not null and p_hlr_l <> '%'
       FORALL i IN NVL (p_hlr_l.FIRST, 1) .. NVL (p_hlr_l.LAST, 0)
         INSERT INTO TT_BATCH_PERSONAL_ACCOUNT
                       (host_id
                       )
                VALUES (p_hlr_l (i)
                       );
     ELSE
       --p_hlr_l is null or p_hlr_l = '%'
       IF p_network_operator_code IS NOT NULL
       THEN
         INSERT INTO TT_BATCH_PERSONAL_ACCOUNT (host_id)
           SELECT hh.host_id
             FROM HOST hh JOIN network_operator n_o ON n_o.network_operator_id = hh.network_operator_id
               WHERE n_o.network_operator_code = p_network_operator_code AND hh.host_type_code = 'HL';
       ELSE
         raise_application_error (rsig_utils.c_ora_missing_parameter, 'Missing some mandatory parameter.');
       END IF;
     END IF;
   ELSE
     --p_sn_list is null
     IF NOT (p_hlr_l.COUNT = 0 OR (p_hlr_l.COUNT = 1 AND p_hlr_l(1) IS NULL))
     THEN
       IF p_network_operator_code IS NOT NULL
       THEN
         INSERT INTO TT_BATCH_PERSONAL_ACCOUNT (host_id)
           SELECT hh.host_id
             FROM HOST hh JOIN network_operator n_o ON n_o.network_operator_id = hh.network_operator_id
              WHERE n_o.network_operator_code = p_network_operator_code AND hh.host_type_code = 'HL';
       ELSE
         IF p_hlr_l.COUNT <> 1
         THEN
           FORALL i IN NVL (p_hlr_l.FIRST, 1) .. NVL (p_hlr_l.LAST, 0)
             INSERT INTO TT_BATCH_PERSONAL_ACCOUNT
                         (host_id
                         )
                  VALUES (p_hlr_l (i)
                         );
         ELSE
           IF p_hlr_l (1) = '%'
           THEN
             raise_application_error (rsig_utils.c_ora_missing_parameter, 'Missing some mandatory parameter.');
           ELSE
             INSERT INTO TT_BATCH_PERSONAL_ACCOUNT
                         (host_id
                         )
                  VALUES (p_hlr_l (1)
                         );
           END IF;
         END IF;
       END IF;
     END IF;
   END IF;

   DELETE FROM tt_iccid_by_phone_list;   --TT_IMPORT_SIM_CARD

   FORALL i IN NVL (p_sn_list.FIRST, 1) .. NVL (p_sn_list.LAST, 0)
      INSERT INTO tt_iccid_by_phone_list
                  (iccid
                  )
           VALUES (p_sn_list (i)
                  );

   DELETE      tt_phone_link;

   v_SC_Type_Any := 'N';

   IF p_sim_card_type_code.COUNT = 0 OR (p_sim_card_type_code.COUNT = 1 AND p_sim_card_type_code(1) IS NULL)
   THEN
      v_SC_Type_Any := 'Y';
   ELSE
      FORALL i IN NVL (p_sim_card_type_code.FIRST, 1) .. NVL (p_sim_card_type_code.LAST, 0)
          INSERT INTO tt_phone_link
                  (linked_msisdn
                  )
        VALUES (p_sim_card_type_code (i)
                  );
   END IF;

   delete from tt_find_sim_cards;

   IF p_sn_list.COUNT = 0 OR (p_sn_list.COUNT = 1 AND p_sn_list(1) IS NULL)
   THEN
      OPEN p_result_list FOR
         select * from (
         SELECT ss.sim_series_id,
                sc.sn ICCID,
                ss.host_id,
                p_network_operator_code as network_operator_code,
                ss.sim_card_type_code,
                apsh.access_point_status_code,
                --s3.current_point_status_code,
                NVL (appsh.ap_prod_status_code, sssv.status_code) as ap_prod_status_code,
                pn.international_format as Phone_number,
                pn.salability_category_code as salability_category,
                pns.phone_number_type_code as phone_number_type,
                pn.net_address_status_code as network_address_status,
                rsig_utils.c_ok Error_code
                --, naap.NETWORK_ADDRESS_ID
           FROM TT_BATCH_PERSONAL_ACCOUNT tt INNER JOIN sim_series ss
                ON ss.host_id = tt.host_id
                AND (v_SC_Type_Any = 'Y'
                OR
                (RTRIM (ss.sim_card_type_code) IN (SELECT RTRIM (tt2.linked_msisdn)
                                                      FROM tt_phone_link tt2)))
              AND (p_date_op >= ss.date_of_change AND (p_date_op <= ss.deleted OR ss.deleted IS NULL))
                INNER JOIN sim_card sc
                ON sc.sim_series_id = ss.sim_series_id
              AND (p_date_op >= sc.date_of_change AND (p_date_op <= sc.deleted OR sc.deleted IS NULL))

               INNER JOIN access_point_status_history apsh
                ON apsh.access_point_id = sc.access_point_id
              AND RTRIM (apsh.access_point_status_code) = RTRIM (p_access_point_status_code)
              AND RTRIM (apsh.ap_trans_reason_code) = RTRIM (p_ap_trans_reason_code)
              AND apsh.start_date IS NOT NULL
              AND apsh.end_date IS NULL
              AND apsh.start_date <= p_date_to
              AND apsh.start_date >= p_date_from

                LEFT JOIN ap_prod_status_hist appsh
                ON appsh.access_point_id = sc.access_point_id
              AND (p_date_op >= appsh.start_date AND (p_date_op <= appsh.end_date OR appsh.end_date IS NULL))
                LEFT JOIN sim_series_status_validity sssv
                ON sssv.sim_series_id = ss.sim_series_id
              AND (p_date_op >= sssv.start_date AND (p_date_op <= sssv.end_date OR sssv.end_date IS NULL))
                LEFT JOIN network_address_access_point naap
                ON naap.access_point_id = sc.access_point_id
                AND naap.link_type_code = rsig_utils.c_main_link_type
                AND (p_date_op >= naap.from_date AND (p_date_op <= naap.TO_DATE OR naap.TO_DATE IS NULL))
                and (p_only_linked = 0 OR (p_only_linked = 1 and naap.NETWORK_ADDRESS_ID is not null))
              LEFT JOIN phone_number pn
                ON pn.network_address_id = naap.network_address_id
              AND (p_date_op >= pn.date_of_change AND (p_date_op <= pn.deleted OR pn.deleted IS NULL))
                LEFT JOIN phone_number_series pns
                ON pns.phone_number_series_id = pn.phone_number_series_id
              AND (p_date_op >= pns.date_of_change AND (p_date_op <= pns.deleted OR pns.deleted IS NULL))) t
          WHERE RTRIM (t.ap_prod_status_code) = RTRIM (p_ap_prod_status_code)
          ;
   ELSE
      INSERT INTO tt_find_sim_cards
                  (sn, imsi,
                   host_id,
                   sim_card_type_code,
                   ap_prod_status_code,
                   access_point_status_code,
                   sim_series_id,
                   access_point_id,
                   network_operator_code,
                   msisdn,
                   salability_category,
                   phone_number_type_code,
                   network_adress_status_code,
                   RESULT)
         SELECT tt.iccid,
                sc.imsi,
                ss.host_id,
                ss.sim_card_type_code,
                NVL (psh.ap_prod_status_code, sssv.status_code) as ap_prod_status_code,
                apsh.access_point_status_code,
                ss.sim_series_id,
                sc.access_point_id,
                p_network_operator_code,
                pn.international_format,
                pn.salability_category_code,
                pns.phone_number_type_code,
                pn.net_address_status_code,
                rsig_utils.c_ok
           FROM tt_iccid_by_phone_list tt LEFT JOIN sim_card sc
                ON tt.iccid = sc.sn
              AND (p_date_op >= sc.date_of_change AND (p_date_op <= sc.deleted OR sc.deleted IS NULL))
                LEFT JOIN ap_prod_status_hist psh
                ON psh.access_point_id = sc.access_point_id
              AND (p_date_op >= psh.start_date AND (p_date_op <= psh.end_date OR psh.end_date IS NULL))
                LEFT JOIN sim_series ss
                ON ss.sim_series_id = sc.sim_series_id
              AND (p_date_op >= ss.date_of_change AND (p_date_op <= ss.deleted OR ss.deleted IS NULL))

                LEFT JOIN access_point_status_history apsh
                ON apsh.access_point_id = sc.access_point_id
              AND RTRIM (apsh.access_point_status_code) = RTRIM (p_access_point_status_code)
              AND RTRIM (apsh.ap_trans_reason_code) = RTRIM (p_ap_trans_reason_code)
              AND apsh.start_date IS NOT NULL
              AND apsh.end_date IS NULL
              AND apsh.start_date <= p_date_to
              AND apsh.start_date >= p_date_from

                LEFT JOIN sim_series_status_validity sssv
                ON sssv.sim_series_id = ss.sim_series_id
              AND (p_date_op >= sssv.start_date AND (p_date_op <= sssv.end_date OR sssv.end_date IS NULL))
                LEFT JOIN network_address_access_point naap
                ON naap.access_point_id = sc.access_point_id
              AND naap.link_type_code = rsig_utils.c_main_link_type
              AND (p_date_op >= naap.from_date AND (p_date_op <= naap.TO_DATE OR naap.TO_DATE IS NULL))
                LEFT JOIN phone_number pn
                ON naap.network_address_id = pn.network_address_id
              AND (p_date_op >= pn.date_of_change AND (p_date_op <= pn.deleted OR pn.deleted IS NULL))
                LEFT JOIN phone_number_series pns
                ON pns.phone_number_series_id = pn.phone_number_series_id
              AND (p_date_op >= pns.date_of_change AND (p_date_op <= pns.deleted OR pns.deleted IS NULL))
                ;

      UPDATE tt_find_sim_cards tt
         SET RESULT = rsig_utils.c_sim_card_not_exists
       WHERE tt.imsi IS NULL AND RESULT = rsig_utils.c_ok;

      UPDATE tt_find_sim_cards tt
         SET RESULT = rsig_utils.c_not_same_host_id
       WHERE tt.host_id NOT IN (SELECT host_id
                                  FROM TT_BATCH_PERSONAL_ACCOUNT) AND RESULT = rsig_utils.c_ok;

      UPDATE tt_find_sim_cards tt
         SET RESULT = rsig_utils.c_sim_invalid_ps
       WHERE RTRIM (tt.ap_prod_status_code) <> RTRIM (p_ap_prod_status_code) AND RESULT = rsig_utils.c_ok;

      UPDATE tt_find_sim_cards tt
         SET RESULT = rsig_utils.c_sim_invalid_status
       WHERE RTRIM (tt.access_point_status_code) <> RTRIM (p_access_point_status_code) AND RESULT = rsig_utils.c_ok;

      IF (v_SC_Type_Any = 'N')
      THEN
          UPDATE tt_find_sim_cards tt
             SET RESULT = rsig_utils.c_sim_invalid_type
           WHERE RTRIM (tt.sim_card_type_code) NOT IN (SELECT RTRIM (linked_msisdn)
                                                     FROM tt_phone_link) AND RESULT = rsig_utils.c_ok;
      END IF;

      IF (p_only_linked <> 0)
      THEN
         UPDATE tt_find_sim_cards tt
            SET RESULT = rsig_utils.c_link_na_and_ap_not_ex
          WHERE tt.msisdn IS NULL AND RESULT = rsig_utils.c_ok;
      END IF;

      OPEN p_result_list FOR
         SELECT t.sim_series_id,
                t.sn,
                t.host_id,
                t.network_operator_code,
                t.sim_card_type_code,
                t.access_point_status_code,
                t.ap_prod_status_code,
                t.msisdn,
                t.salability_category,
                t.phone_number_type_code,
                t.network_adress_status_code,
                t.RESULT
           FROM tt_find_sim_cards t;
   END IF;

   IF (p_handle_tran = rsig_utils.c_handle_tran_y)
   THEN
      COMMIT;
   END IF;

   -- log end of procedure
   common.event_logger (rsig_utils.c_debug_text_end,
                        rsig_utils.c_debug_level_1,
                        rsig_utils.c_debug_event_type_d,
                        v_event_source
                       );
   p_error_code := rsig_utils.c_ok;   -- succesfully completed
EXCEPTION
   WHEN OTHERS
   THEN
      p_error_code := common.handle_error (SQLCODE, p_handle_tran, v_package_name, v_procedure_name);
      p_error_message := SQLERRM;

      IF UPPER (p_raise_error) = rsig_utils.c_yes
      THEN
         RAISE;
      END IF;
END get_sim_cards_by_iccid_list_1;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Create_Control_Number
-----------------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION Create_Control_Number
(
  p_ICCID IN VARCHAR2
) RETURN VARCHAR2
IS
  v_sum   INT;
  v_dig   INT;
begin
  v_sum := 0;
  IF LENGTH(p_ICCID) > 0 THEN
    FOR a IN 1 .. LENGTH(p_ICCID)
    LOOP
      v_dig := to_number(SUBSTR(p_ICCID, a, 1));
      IF MOD(a, 2) = 1 THEN
        v_sum := v_sum + v_dig;
      ELSE
        v_dig := v_dig * 2;
        IF v_dig > 9 THEN
            v_dig := v_dig - 9;
        END IF;
        v_sum := v_sum + v_dig;
      END IF;
    END LOOP;
    v_sum := mod(10 - mod(v_sum, 10), 10);
    return to_nchar(v_sum);
  END IF;

end Create_Control_Number;

PROCEDURE Check_Phone_Range(
  p_phone_list             IN  common.t_international_format,
  p_HLR_code               IN  host.host_code%TYPE,
  p_phone_status_code      IN  phone_number.net_address_status_code%TYPE,
  p_phone_type_code        IN  phone_number_series.phone_number_type_code%TYPE,
  p_salability_category    IN  VARCHAR2,
  p_handle_tran	           IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'UMC';
  v_procedure_name        VARCHAR2(30) := 'Check_Phone_Range';
  v_event_source          VARCHAR2(60);
  v_MSISDN_l              common.t_international_format;
  v_PHONE_RES_OBJ         T_PHONE_RES_OBJ := T_PHONE_RES_OBJ(NULL,NULL);
  v_PHONE_RES_OBJ_tab     T_PHONE_RES_OBJ_TAB := T_PHONE_RES_OBJ_TAB();
  v_PHONE_RES_OBJ_tab1     T_PHONE_RES_OBJ_TAB := T_PHONE_RES_OBJ_TAB();
BEGIN

   v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);


  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check input parameters
  IF p_HLR_code IS NULL OR p_phone_status_code IS NULL OR p_phone_type_code IS NULL OR p_salability_category IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

  IF p_phone_list IS NULL OR
     p_phone_list.COUNT = 0 OR
     (p_phone_list.COUNT = 1 AND p_phone_list(p_phone_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

--------------------------------------------------------------------------------------------------

    -- make intervals
    IF p_phone_list.COUNT>0 THEN
      FOR i IN p_phone_list.FIRST .. p_phone_list.LAST LOOP
            v_PHONE_RES_OBJ:=t_PHONE_RES_OBJ(p_phone_list(i),NULL);
            v_PHONE_RES_OBJ_tab1.EXTEND;
            v_PHONE_RES_OBJ_tab1(i):=v_PHONE_RES_OBJ;
      END LOOP;
    END IF;


    SELECT k.international_format
    BULK COLLECT INTO v_MSISDN_l
    FROM(SELECT pn.international_format
         FROM phone_number pn
         JOIN phone_number_series pns ON pns.phone_number_series_id=pn.phone_number_series_id
         JOIN host h ON h.host_id=pns.host_id
         WHERE pn.International_Format IN (SELECT t.international_format
                                      FROM TABLE(CAST(v_PHONE_RES_OBJ_tab1 AS t_PHONE_RES_OBJ_tab)) t)
           AND pns.phone_number_type_code=p_phone_type_code
           AND pn.net_address_status_code=p_phone_status_code
           AND pn.salability_category_code = p_salability_category
           AND h.host_code=p_HLR_code
           AND NOT EXISTS(SELECT 1
                          FROM network_address_access_point n
                          WHERE pn.network_address_id = n.network_address_id
                            AND SYSDATE BETWEEN n.from_date AND NVL (n.TO_DATE, SYSDATE))
         ORDER BY pn.international_format) k;

  IF v_MSISDN_l.COUNT>0 THEN
    FOR i IN v_MSISDN_l.FIRST .. v_MSISDN_l.LAST LOOP
          v_PHONE_RES_OBJ:=t_PHONE_RES_OBJ(v_MSISDN_l(i),NULL);
          v_PHONE_RES_OBJ_tab.EXTEND;
          v_PHONE_RES_OBJ_tab(i):=v_PHONE_RES_OBJ;
    END LOOP;
  END IF;

  UPDATE phone_number pn
         SET pn.net_address_status_code='R'
  WHERE pn.international_format IN (SELECT t.international_format
                                      FROM TABLE(CAST(v_PHONE_RES_OBJ_tab AS t_PHONE_RES_OBJ_tab)) t);

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  OPEN p_result_list FOR
    SELECT t.international_format,
           p_HLR_code hlr_code,
           p_phone_type_code phone_type_code,
           p_salability_category salability_category_code
    FROM TABLE(CAST(v_PHONE_RES_OBJ_tab AS t_PHONE_RES_OBJ_tab)) t
    ORDER BY t.international_format;

---------------------------------------------------------------------------------------------------------
  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,p_handle_tran,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    OPEN p_result_list FOR SELECT p_error_code FROM dual;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Check_Phone_Range;

END;
/
