CREATE PACKAGE BODY RSIG_PAYMENT_ENTRANCE IS

---------------------------------------------
--     PROCEDURE Test_Row_For_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Row_For_Exist_And_Deleted(p_payment_entrance_id IN PAYMENT_ENTRANCE.PAYMENT_ENTRANCE_ID%TYPE) IS
  v_deleted PAYMENT_ENTRANCE.DELETED%TYPE;

BEGIN

  select DELETED into v_deleted from PAYMENT_ENTRANCE where PAYMENT_ENTRANCE_ID = p_payment_entrance_id;

  IF v_deleted IS NOT NULL THEN
    IF v_deleted < sysdate THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
    END IF;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Test_Row_For_Exist_And_Deleted;

---------------------------------------------
--     PROCEDURE Insert_Payment_Entrance
---------------------------------------------

PROCEDURE Insert_Payment_Entrance
(
  handle_tran             CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code              OUT NUMBER,
  p_payment_entrance_name IN PAYMENT_ENTRANCE.payment_entrance_name%TYPE,
  p_network_operator_id   IN PAYMENT_ENTRANCE.network_operator_id%TYPE,
  p_user_id_of_change     IN PAYMENT_ENTRANCE.user_id_of_change%TYPE,
  p_payment_entrance_id   OUT PAYMENT_ENTRANCE.PAYMENT_ENTRANCE_ID%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PAYMENT_ENTRANCE.Insert_Payment_Entrance';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint insert_payment_entrance_type_a;
  END IF;

  select s_payment_entrance.nextval into p_payment_entrance_id from DUAL;

  BEGIN
    INSERT INTO PAYMENT_ENTRANCE
      (PAYMENT_ENTRANCE_ID,
       PAYMENT_ENTRANCE_NAME,
       NETWORK_OPERATOR_ID,
       USER_ID_OF_CHANGE,
       DATE_OF_CHANGE)

    VALUES
      (p_payment_entrance_id,
       p_payment_entrance_name,
       p_network_operator_id,
       p_user_id_of_change,
       sysdate);

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_PAYMENT_ENTRANCE_NAME then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_PAY_ENTR_NAME, '');
      end if;
  END;
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint insert_payment_entrance_type_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Insert_Payment_Entrance;


---------------------------------------------
--     PROCEDURE Delete_Payment_Entrance
---------------------------------------------

PROCEDURE Delete_Payment_Entrance
(
  handle_tran           CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_payment_entrance_id IN PAYMENT_ENTRANCE.PAYMENT_ENTRANCE_ID%TYPE,
  p_deleted             IN PAYMENT_ENTRANCE.DELETED%TYPE,
  p_user_id_of_change   IN PAYMENT_ENTRANCE.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PAYMENT_ENTRANCE.Delete_Payment_Entrance';
  v_sysdate      DATE;
  v_deleted      DATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint delete_payment_entrance;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_payment_entrance_id);

  v_deleted := nvl(p_deleted, SYSDATE);

  SELECT SYSDATE INTO v_sysdate FROM dual;

  update PAYMENT_ENTRANCE
     set DELETED           = v_deleted,
         DATE_OF_CHANGE    = v_sysdate,
         USER_ID_OF_CHANGE = p_user_id_of_change
   where PAYMENT_ENTRANCE_ID = p_payment_entrance_id;

  UPDATE PAY_DESK pd
     SET pd.DELETED           = v_deleted,
         pd.DATE_OF_CHANGE    = v_sysdate,
         pd.USER_ID_OF_CHANGE = p_user_id_of_change
   WHERE pd.payment_entrance_id = p_payment_entrance_id
     AND (pd.deleted IS NULL OR pd.deleted > v_deleted);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint delete_payment_entrance;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Delete_Payment_Entrance;


---------------------------------------------
--     PROCEDURE Update_Payment_Entrance
---------------------------------------------

PROCEDURE Update_Payment_Entrance
(
  handle_tran             CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code              OUT NUMBER,
  p_payment_entrance_id   IN payment_entrance.payment_entrance_id%TYPE,
  p_payment_entrance_name IN payment_entrance.payment_entrance_name%TYPE,
  p_network_operator_id   IN payment_entrance.network_operator_id%TYPE,
  p_user_id_of_change     IN payment_entrance.user_id_of_change%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PAYMENT_ENTRANCE.Update_Payment_Entrance';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint update_payment_entrance;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_payment_entrance_id);

  BEGIN
    UPDATE PAYMENT_ENTRANCE
       SET PAYMENT_ENTRANCE_NAME = p_payment_entrance_name,
           NETWORK_OPERATOR_ID   = p_network_operator_id,
           DATE_OF_CHANGE        = sysdate,
           USER_ID_OF_CHANGE     = p_user_id_of_change
     WHERE PAYMENT_ENTRANCE_ID = p_payment_entrance_id;

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_PAYMENT_ENTRANCE_NAME then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_PAY_ENTR_NAME, '');
      end if;
  END;
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint update_payment_entrance;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Update_Payment_Entrance;

---------------------------------------------
--     PROCEDURE Get_Payment_Entrance
---------------------------------------------

PROCEDURE Get_Payment_Entrance
(
  error_code    OUT NUMBER,
  p_operator_id IN PAYMENT_ENTRANCE.NETWORK_OPERATOR_ID%TYPE,
  p_all_rows    IN CHAR,
  p_result      OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PAYMENT_ENTRANCE.Get_Payment_Entrance';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_operator_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF p_all_rows = 'Y' THEN
    OPEN p_result FOR
      select pe.payment_entrance_id,
             pe.payment_entrance_name,
             no.NETWORK_OPERATOR_NAME,
             pe.deleted,
             u.user_name,
             pe.date_of_change
        from PAYMENT_ENTRANCE pe
        JOIN NETWORK_OPERATOR no ON no.network_operator_id = pe.network_operator_id
        join USERS u on u.user_id = pe.user_id_of_change
       where no.network_operator_id = p_operator_id
       order by pe.payment_entrance_name;
  ELSE
    OPEN p_result FOR
      select pe.payment_entrance_id,
             pe.payment_entrance_name,
             no.NETWORK_OPERATOR_NAME,
             pe.deleted,
             u.user_name,
             pe.date_of_change
        from PAYMENT_ENTRANCE pe
        JOIN NETWORK_OPERATOR no ON no.network_operator_id = pe.network_operator_id
        join USERS u on u.user_id = pe.user_id_of_change
       where no.network_operator_id = p_operator_id
         and (pe.deleted is null or pe.deleted > sysdate)
       order by pe.payment_entrance_name;
  END IF;
  error_code := RSIG_UTILS.c_OK;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_result FOR
        select error_code from dual;
    END;
END Get_Payment_Entrance;


END RSIG_PAYMENT_ENTRANCE;
/
