CREATE PACKAGE UMC IS

  c_IMSI_LN_length    CONSTANT NUMBER(5):=6;

  TYPE t_pin IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;
  TYPE t_puk IS TABLE OF VARCHAR2(60) INDEX BY BINARY_INTEGER;
  TYPE t_status IS TABLE OF VARCHAR2(2) INDEX BY BINARY_INTEGER;
  TYPE t_tran_reason IS TABLE OF VARCHAR2(32) INDEX BY BINARY_INTEGER;

  TYPE t_KI IS TABLE OF VARCHAR2(40) INDEX BY BINARY_INTEGER;
  TYPE t_ADM1 IS TABLE OF VARCHAR2(20) INDEX BY BINARY_INTEGER;

PROCEDURE Create_bound_SIM_Series(
  p_network_operator_id   IN  network_operator.network_operator_id%TYPE,
  p_ICCID_prefix          IN  VARCHAR2,
  p_HLR_Code              IN  host.host_code%TYPE,
  p_MSISDN_Start          IN  phone_number.International_Format%TYPE,
  p_MSISDN_End            IN  phone_number.International_Format%TYPE,
  p_IMSI_Start            IN  sim_card.imsi%TYPE,
  p_ap_status             IN  access_point_status_history.access_point_status_code%TYPE,
  p_ap_prod_status        IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_user_id               IN  NUMBER,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_sim_series_id         OUT sim_series.sim_series_id%TYPE,
  p_error_code            OUT NUMBER,
  p_error_message	  OUT VARCHAR2
);

PROCEDURE Create_unbound_SIM_Series(
  p_network_operator_id   IN  network_operator.network_operator_id%TYPE,
  p_ICCID_prefix          IN  VARCHAR2,
  p_HLR_Code              IN  host.host_code%TYPE,
  p_IMSI_Start            IN  sim_card.imsi%TYPE,
  p_IMSI_End              IN  sim_card.imsi%TYPE,
  p_ap_status             IN  access_point_status_history.access_point_status_code%TYPE,
  p_ap_prod_status        IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_user_id               IN  NUMBER,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_sim_series_id         OUT sim_series.sim_series_id%TYPE,
  p_error_code            OUT NUMBER,
  p_error_message	  OUT VARCHAR2
);

PROCEDURE Get_SIM_Status_Ex(
  p_validity_date          IN  DATE,
  p_IMSI_Start             IN  sim_card.imsi%TYPE,
  p_IMSI_End               IN  sim_card.imsi%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);

PROCEDURE Set_SIM_Production_Status(
  p_IMSI_Start_l          IN  common.t_IMSI,
  p_IMSI_End_l            IN  common.t_IMSI,
  p_SIM_Prod_Status_l     IN  t_status,
  p_user_login            IN  VARCHAR2,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message	        OUT VARCHAR2,
  p_result_list           OUT sys_refcursor
);

PROCEDURE Set_SIM_Card_Details(
  p_IMSI_l                IN  common.t_IMSI,
  p_ICCID_l               IN  common.t_ICCID,
  p_PIN_l                 IN  t_pin,
  p_PIN2_l                IN  t_pin,
  p_PUK_l                 IN  t_puk,
  p_PUK2_l                IN  t_puk,
  p_user_login            IN  VARCHAR2,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message	        OUT VARCHAR2
);

PROCEDURE Set_SIM_Card_Details_Ex(
  p_IMSI_l                IN  common.t_IMSI,
  p_ICCID_l               IN  common.t_ICCID,
  p_PIN_l                 IN  t_pin,
  p_PIN2_l                IN  t_pin,
  p_PUK_l                 IN  t_puk,
  p_PUK2_l                IN  t_puk,
  p_KI_l                  IN  t_ki,
  p_ADM1_l                IN  t_adm1,
  p_AccessControl_l       IN  t_ki,
  p_user_id               IN  NUMBER,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message	      OUT VARCHAR2
);

PROCEDURE Get_Sim_Cards_By_ICCID_List(
  p_HLR_l                    IN  t_KI,
  p_Network_Operator_Code    IN  VARCHAR2,
  p_access_point_status_code IN  access_point_status_history.ACCESS_POINT_STATUS_CODE%TYPE,
  p_sim_card_type_code       IN  t_KI,
  p_ap_prod_status_code      IN  sim_series_status_validity.STATUS_CODE%TYPE,
  p_SN_list                  IN  t_KI,
  p_DATE_OP                  IN  DATE,
  p_only_linked              IN  NUMBER,
  p_handle_tran	             IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error              IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code               OUT NUMBER,
  p_error_message            OUT VARCHAR2,
  p_result_list              OUT sys_refcursor
);

PROCEDURE Get_Sim_Cards_By_ICCID_List_1(
  p_HLR_l                    IN  t_KI,
  p_Network_Operator_Code    IN  VARCHAR2,
  p_access_point_status_code IN  access_point_status_history.ACCESS_POINT_STATUS_CODE%TYPE,
  p_ap_trans_reason_code     IN  access_point_status_history.ap_trans_reason_code%TYPE,
  p_sim_card_type_code       IN  t_KI,
  p_ap_prod_status_code      IN  sim_series_status_validity.STATUS_CODE%TYPE,
  p_SN_list                  IN  t_KI,
  p_DATE_OP                  IN  DATE,
  p_date_from                IN  DATE,
  p_date_to                  IN  DATE,
  p_only_linked              IN  NUMBER,
  p_handle_tran              IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error              IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code               OUT NUMBER,
  p_error_message            OUT VARCHAR2,
  p_result_list              OUT sys_refcursor
);

FUNCTION Create_Control_Number(
  p_ICCID IN VARCHAR2
) RETURN VARCHAR2;

PROCEDURE Check_Phone_Range(
  p_phone_list             IN  common.t_international_format,
  p_HLR_code               IN  host.host_code%TYPE,
  p_phone_status_code      IN  phone_number.net_address_status_code%TYPE,
  p_phone_type_code        IN  phone_number_series.phone_number_type_code%TYPE,
  p_salability_category    IN  VARCHAR2,
  p_handle_tran	           IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);

END;
/
