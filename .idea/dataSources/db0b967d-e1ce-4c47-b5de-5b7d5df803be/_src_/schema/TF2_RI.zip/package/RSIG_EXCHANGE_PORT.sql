CREATE PACKAGE RSIG_EXCHANGE_PORT IS
/****************************************************************************
<header>
  <name>             	package RSIG_EXCHANGE_PORT
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>         1.2.2    11.09.2009   Pavel Vasiliev
                    procedure Generate_Ports_For_Phones deleted
  </version>
  <version>         1.2.1    13.11.2006   Petr Cepek
                    procedure Test_Port_Number_Exist deleted
                    procedure Get_Exchange_Port deleted
                    procedure Get_Status_History deleted
                    procedure Insert_Exchange_Port updated
                    procedure Delete_Exchange_Port updated
  </version>
  <version>         1.2.0    4.9.2006     Petr Cepek
                    procedure Generate_ports_for_phones updated
  </version>
  <version>         1.1.9   03.07.2006    Petr Cepek
                    procedure Link_Ex_Port_to_Ph_Number updated
  </version>
  <version>         1.1.8   13.06.2006    Petr Cepek
                    procedure Insert_Exchange_Port updated
                    procedure Update_Exchange_Port updated
  </version>
  <version>         1.1.7   2.05.2006     Petr Cepek
                    procedure Link_Ex_Port_to_Ph_Number updated
  </version>
  <version>         1.1.6   14.03.2006    Petr Cepek
                    procedure Get_Exchange_port_Next updated
  </version>
  <version>         1.1.5   17.10.2005    Petr Cepek
                    constant c_ORA_NOT_FREE_PHONES changed to c_NOT_FREE_PHONES
  </version>
  <version>         1.1.4   13.06.2005  Petr Cepek
                    procedure Get_Number_From_Char moved from package RSIG_ADMIN
  </version>
  <version>         1.1.3  06.06.2005   Petr Cepek
                    procedures Link_Exchange_Port_to_Phone_Number updated, Generate_ports_for_phones
  </version>

   <version>				1.1.2	 01.06.2005     Radomir Lipka
								    Procedure Update_Exchange_Port.
                    Add new parametr p_exchange_port_number for update.
   </version>
   <version>				1.1.1	 30.05.2005     Radomir Lipka
								    procedure Test_Port_Number_Exist
                    - change parametr p_exchange_port_number from NUMBER to VARCHAR2
								    procedure Insert_Exchange_Port
                    - change parametr p_exchange_port_number from NUMBER to VARCHAR2
                    Add new parameters to procedure Generate_Exchange_Port
                    - p_exchange_prefix  IN VARCHAR2       prefix for port number
                    - p_fill_zero        IN CHAR(1) Y,N    left pad zero port number
                    - p_count_digits     IN NUMBER         total length port number
								    procedure Get_Phone_hist_by_exch_port
                    - change parametr p_port_number from NUMBER to VARCHAR2
								    procedure Get_Phone_Series_Ports
                    - change variables v_last_port from NUMBER to VARCHAR2
                    - change variables col_exchange_port from NUMBER to VARCHAR2
                    Add new parameters to procedure Generate_ports_for_phones
                    - p_exchange_prefix  IN VARCHAR2       prefix for port number
                    - p_fill_zero        IN CHAR(1) Y,N    left pad zero port number
                    - p_count_digits     IN NUMBER         total length port number
                    - change variables v_exchange_port_number from NUMBER to VARCHAR2
  </version>
   <version>				1.1.0	 19.05.2005     Petr Cepek
								Procedure Link_Ex_Port_to_Ph_Number created
  </version>
   <version>				1.0.14	04.11.2004     Jaroslav Holub
								Generate_ports_for_phones - report only unsuccessfully connected series
								change type t_port_code_I from char to varchar2
  </version>

  <version>				1.0.14	04.11.2004     Jaroslav Holub
								Generate_ports_for_phones - report only unsuccessfully connected series
								change type t_port_code_I from char to varchar2
  </version>
  <version>				1.0.13	03.11.2004     Jaroslav Holub
                                added types - t_phone_number, t_port_code
								added Generate_ports_for_phones
  </version>
  <version>				1.0.12	09.09.2004     Jaroslav Holub
                                Get_Exchange_port_Next - changed to not use dynamic SQL
  </version>
  <version>				1.0.11	28.8.2004     Jaroslav Holub
								Get_Exchange_port_Next, Get_Phone_hist_by_exch_port - change order of parameters
  </version>
  <version>				1.0.10	3.8.2004     Jaroslav Holub
								Delete_Exchange_Port - fixed for time difference between client and server,
								p_start_date should be null and it means sysdate
  </version>
  <version>				1.0.9   21.7.2004	Jaroslav Holub
                                Get_Exchange_port_Next - added collumn into output cursor
  </version>
  <version>           	1.0.8   19.7.2004	Jaroslav Holub
                                added Get_Phone_hist_by_Exchange_port_
  </version>
  <version>           	1.0.7   12.7.2004	Jaroslav Holub
                                Get_Exchange_port_Next- in select fix error when p_show_deleted is NULL
  </version>
  <version>          	1.0.6   1.6.2004     Jaroslav Holub
                                Delete_Exchange_Port - fix delete in access_point table
  </version>
  <version>           	1.0.5   26.5.2004	Jaroslav Holub
                                Get_Exchange_port_Next - fix order of columns in result cursor, and join exch.port name
  </version>
  <version>           	1.0.4   25.5.2004	Jaroslav Holub
                                created first version
  </version>
  <version>          	1.0.3   10.5.2004     Jaroslav Holub
                                fixed safepoint definition in procedures with handle_tran parameter
								add procedure Update_exchange_port
								change procedure Test_Port_Number_Exist - test for existence of only active port numbers
  </version>
  <version>          	1.0.2   10.5.2004     Jaroslav Holub
								new procedure Get_Exchange_Port_Types
  </version>
  <version>          	1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      Package contains procedures for managing exchange ports.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/
--types
TYPE t_phone_number IS TABLE OF VARCHAR2(30);
TYPE t_port_code	IS TABLE OF CHAR(2);
TYPE t_number		IS TABLE OF NUMBER;
TYPE t_port_number	IS TABLE OF VARCHAR2(40);
TYPE t_phone_number_I	IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
TYPE t_port_code_I 		IS TABLE OF VARCHAR2(2) INDEX BY BINARY_INTEGER;
TYPE t_number_I			IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
TYPE t_port_number_I	IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;


/****************************************************************************
<header>
  <name>             	procedure Insert_Exchange_Port
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>           1.0.5   13.11.2006  Petr Cepek
                      columns from talbe access_point moved into the table sim_card
  </version>
  <version>           1.0.4   30.6.2006   Petr Cepek
                      error handling adjusted for duplicate port number
  </version>
  <version>          	1.0.3   30.5.2005     Radomir Lipka
                                change parametr p_exchange_port_number from NUMBER to VARCHAR2
  </version>
  <version>          	1.0.2   10.5.2004     Jaroslav Holub
                                fixed safepoint definition
  </version>
  <version>          	1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	Procedure first inserts a new access point.
                      Further procedure insers new exchange port with given data
                      and new access point id.
                      Procedure returns new access point id in parameter
                      p_access_point_id.

  </Description>

  <Prerequisites>
                      Exists function:
                        PROCEDURE Debug_Rsi (
                          p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                          p_level         NUMBER,                       -- level of debuging
                          p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                          p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                        );
                        FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      Exists variable:
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_access_point_id - IN - value for ACCESS_POINT_ID
                                               this value is generated by sequence S_ACCESS_POINT
                      p_exchange_id - IN - value for --host_id--EXCHANGE_ID
                      p_exchange_port_number - IN - value for EXCHANGE_PORT_NUMBER
                      p_exchange_port_type_code - IN - value for EXCHANGE_PORT_TYPE_CODE
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
                      p_host_code                 IN HOST.HOST_CODE%TYPE,
                      p_host_address              IN HOST.HOST_ADDRESS%TYPE,
                      p_host_location             IN HOST.HOST_LOCATION%TYPE,
                      p_host_type_code            IN HOST.HOST_TYPE_CODE%TYPE
                      p_host_name                 IN HOST.HOST_NAME%TYPE

  </Parameters>

</header>
****************************************************************************/
PROCEDURE Insert_Exchange_Port (
  handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT    NUMBER,
  p_access_point_id         OUT    EXCHANGE_PORT.ACCESS_POINT_ID%TYPE,
  p_exchange_id             IN      HOST.HOST_ID%TYPE,
  p_exchange_port_number    IN     EXCHANGE_PORT.EXCHANGE_PORT_NUMBER%TYPE,
  p_exchange_port_type_code IN     EXCHANGE_PORT.EXCHANGE_PORT_TYPE_CODE%TYPE,
  p_user_id_of_change       IN     EXCHANGE_PORT.USER_ID_OF_CHANGE%TYPE,
  p_raise_error	            IN     CHAR DEFAULT rsig_utils.c_NO
);
/****************************************************************************
<header>
  <name>             	procedure Generate_Exchange_Port
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>          	1.0.4   30.5.2005     Jaroslav Holub
                      Add new parameters
                      - p_exchange_prefix  IN VARCHAR2       prefix for port number
                      - p_fill_zero        IN CHAR(1) Y,N    left pad zero port number
                      - p_count_digits     IN NUMBER         total length port number
  </version>
  <version>          	1.0.3   10.5.2004     Jaroslav Holub
                                fixed safepoint definition
  </version>
  <version>          	1.0.2	03.03.2004	  Jarda Holub
  								repairing generating of ports
  </version>
  <version>           	1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	Procedure generates given number of exchange ports for
                      given exchange. It inserts new exchange ports with given
                      data and exchange port id in interval from p_exchange_port_number_start
                      to p_exchange_port_number_end.
  </Description>

  <Prerequisites>
                      Exists function:
                        PROCEDURE Debug_Rsi (
                          p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                          p_level         NUMBER,                       -- level of debuging
                          p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                          p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                        );
                        FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      Exists variable:
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_exchange_id - IN - value for EXCHANGE_ID
                      p_exchange_port_number_start - IN - starting exchange port number for EXCHANGE_PORT_NUMBER
                      p_exchange_port_number_count - IN - exchange port number we want to generate
                      p_exchange_port_type_code - IN - value for EXCHANGE_PORT_TYPE_CODE
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Generate_Exchange_Port (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                    OUT    NUMBER,
    p_exchange_id                 IN     HOST.HOST_ID%TYPE,
    p_exchange_port_number_start  IN     EXCHANGE_PORT.EXCHANGE_PORT_NUMBER%TYPE,
    p_exchange_port_number_count  IN     NUMBER,
    p_exchange_port_type_code     IN     EXCHANGE_PORT.EXCHANGE_PORT_TYPE_CODE%TYPE,
    p_user_id_of_change           IN     EXCHANGE_PORT.USER_ID_OF_CHANGE%TYPE,
    p_exchange_prefix             IN     VARCHAR2,
    p_fill_zero                   IN     CHAR,
    p_count_digits                IN     NUMBER
  );
/****************************************************************************
<header>
  <name>             	procedure Delete_Exchange_Port
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>           1.0.5    13.11.2006   Petr Cepek
                     columns from talbe access_point moved into the table sim_card
  </version>
  <version>			      1.0.4	   3.8.2004     Jaroslav Holub
								      fixed for time difference between client and server,
								      p_start_date should be null and it means sysdate
	</version>
  <version>          	1.0.3   1.6.2004     Jaroslav Holub
                                fix delete in access_point table
  </version>
  <version>          	1.0.2   10.5.2004     Jaroslav Holub
                                fixed safepoint definition
  </version>
  <version>          	1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	Procedure sets column DELETED to value of parameter deleted
                      in exchange port given by access point id id, if given
                      exchange port is currently not deleted.
  </Description>

  <Prerequisites>
                      Exists function:
                        PROCEDURE Debug_Rsi (
                          p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                          p_level         NUMBER,                       -- level of debuging
                          p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                          p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                        );
                        FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      Exists variable:
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_access_point_id - IN - value for identification of updating row (ACCESS_POINT_ID)
                      p_deleted - IN - value for DELETED
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Delete_Exchange_Port (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_access_point_id         IN     EXCHANGE_PORT.ACCESS_POINT_ID%TYPE,
    p_deleted                 IN     EXCHANGE_PORT.DELETED%TYPE,
    p_user_id_of_change       IN     EXCHANGE_PORT.USER_ID_OF_CHANGE%TYPE
  );


/****************************************************************************
<header>
  <name>             	procedure Get_Exchange_Port_Types
  </name>

  <author>           	Jaroslav Holub - STROM
  </author>

  <version>          	1.0.1   10.5.2004     Jaroslav Holub
                                created first version
  </version>

  <Description>      	Procedure returns information about all exchange port types
  </Description>

  <Prerequisites>
                      Exists function:
                        PROCEDURE Debug_Rsi (
                          p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                          p_level         NUMBER,                       -- level of debuging
                          p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                          p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                        );
                        FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      Exists variable:
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_LEVEL_2

  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        error_code - OUT - NUMBER
                      p_cur_exchange_port_types - IN OUT - ref cursor containing
					  		exchange_port_type_code,
							exchange_port_type_name
                      p_personal_account         IN     ACCESS_POINT.PERSONAL_ACCOUNT%TYPE

  </Parameters>

</header>
****************************************************************************/
PROCEDURE Get_Exchange_Port_types (
    error_code				OUT    NUMBER,
    p_exchange_port_types	IN OUT RSIG_UTILS.REF_CURSOR
);


/****************************************************************************
<header>
  <name>             	procedure Update_Exchange_Port
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>           1.0.2   30.6.2006   Petr Cepek
                      error handling adjusted for duplicate port number
  </version>
  <version>          	1.0.1   10.5.2004     Jaroslav Holub
                                created first version
  </version>

  <Description>      	Procedure update HOST_ID, EXCHANGE_PORT_TYPE_CODE for specified p_access_point_id
  </Description>

  <Prerequisites>
                      Exists function:
                        PROCEDURE Debug_Rsi (
                          p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                          p_level         NUMBER,                       -- level of debuging
                          p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                          p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                        );
                        FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      Exists variable:
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_access_point_id - IN - value for identification of updating row (ACCESS_POINT_ID)
                      p_deleted - IN - value for DELETED
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
                      p_exchange_port_number - new port number
  </Parameters>

</header>
****************************************************************************/
PROCEDURE Update_Exchange_Port (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_access_point_id         IN     EXCHANGE_PORT.ACCESS_POINT_ID%TYPE,
  	p_host_id				          IN 	   EXCHANGE_PORT.HOST_ID%TYPE,
	  p_exchange_port_type_code IN 	   EXCHANGE_PORT.EXCHANGE_PORT_TYPE_CODE%TYPE,
    p_user_id_of_change       IN     EXCHANGE_PORT.USER_ID_OF_CHANGE%TYPE,
    p_exchange_port_number    IN     EXCHANGE_PORT.EXCHANGE_PORT_NUMBER%TYPE
  );


/****************************************************************************
  <header>
    <name>              procedure Get_Exchange_port_Next
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.6   14.03.2006  Petr Cepek
                        column AMOUNT_OF_HOSTS added into the output cursor
    </version>
    <version>           1.0.5   09.09.2004	Jaroslav Holub
                                changed to not use dynamic SQL
    </version>
    <version>           1.0.4   26.8.2004	Martin Zabka
                                change sequence of parameters
    </version>
    <version>           1.0.3   21.7.2004	Jaroslav Holub
                                added collumn into output cursor
    </version>
	  <version>           1.0.2   12.7.2004	Jaroslav Holub
                                in select fix error when p_show_deleted is NULL
    </version>
    <version>           1.0.1   26.5.2004	Jaroslav Holub
                                fix order of columns in result cursor, and join exch.port name
    </version>
    <version>           1.0.0   25.5.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure Return one "page" of exchange port

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Catalogues
    </Application>

    <Parameters>
						            p_host_id			            Host id
						            p_access_point_id 	      id of last selected access point or NULL (if NULL then return cursor from first row)
						            p_exchange_port_type_code	"like" list for port type ex: 'is','n' (with apostrophes)
						            p_show_deleted		        if 'Y' then show deleted, otherwise show undeleted
						            p_in_row_count		        how many rows returned
						            result_list			          output cursor
                        p_raise_error             IN  CHAR,
                        error_code                OUT NUMBER,
                        error_message             OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
procedure Get_Exchange_port_Next(

  p_host_id					        IN	EXCHANGE_PORT.HOST_ID%TYPE,
  p_access_point_id 		    IN	EXCHANGE_PORT.ACCESS_POINT_ID%TYPE,
  p_exchange_port_type_code	IN	VARCHAR2,
  p_show_deleted			      IN  CHAR,
  p_in_row_count			      IN	NUMBER,
  p_raise_error     		    IN  CHAR,
  error_code        		    OUT NUMBER,
  error_message     		    OUT VARCHAR2,
  result_list				        OUT sys_refcursor
);


/****************************************************************************
  <header>
    <name>              procedure Get_Phone_hist_by_exch_port
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.2   30.5.2005	Radomir Lipka
                                change parametr p_port_number from NUMBER to VARCHAR2
    </version>
    <version>           1.0.1   26.8.2004	Jaroslav Holub
                                change order of parameters
    </version>
    <version>           1.0.0   16.7.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure return history of exchange port - phone number connection


    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
                        p_host_id,		id of exchange
						            p_port_number	port number
						            result list 	output cursor - (international_format, start_date, end_date)
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
procedure Get_Phone_hist_by_exch_port(
	p_host_id		  IN 	HOST.HOST_ID%TYPE,
	p_port_number	IN 	EXCHANGE_PORT.EXCHANGE_PORT_NUMBER%TYPE,
	p_raise_error	IN  CHAR,
	error_code		OUT NUMBER,
	error_message	OUT VARCHAR2,
	result_list		OUT sys_refcursor
);

/****************************************************************************
  <header>
    <name>              procedure Get_Phone_Series_Ports
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.1   30.5.2005	Radomir Lipka
                                change variables v_last_port from NUMBER to VARCHAR2
                                change variables col_exchange_port from NUMBER to VARCHAR2
    </version>
    <version>           1.0.0   1.11.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       procedure Return for specified phone series its asigment
						to ports


    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
	                      p_phone_series_id	IN	PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
	                      p_date				    IN	DATE,
	                      p_raise_error		  IN	CHAR,
	                      error_code			  OUT	NUMBER,
	                      error_message		  OUT	VARCHAR2,
	                      result_list			  OUT sys_refcursor
    </Parameters>

  </header>
****************************************************************************/

procedure Get_Phone_Series_Ports(
	p_phone_series_id	IN	PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
	p_date				    IN	DATE,
	p_raise_error		  IN	CHAR,
	error_code			  OUT	NUMBER,
	error_message		  OUT	VARCHAR2,
	result_list			  OUT sys_refcursor
);

/****************************************************************************
  <header>
    <name>              procedure Generate_ports_for_phones
    </name>

    <author>            Jaroslav Holub
    </author>

    <version>           1.0.3    4.9.2006     Petr Cepek
                        error code changed
    </version>
	  <version>			      1.0.2	  30.5.2005     Radomir Lipka
                                Add new parameters
                                p_exchange_prefix  IN VARCHAR2       prefix for port number
                                p_fill_zero        IN CHAR(1) Y,N    left pad zero port number
                                p_count_digits     IN NUMBER         total length port number

                                change variables v_exchange_port_number from NUMBER to VARCHAR2
	  </version>
	  <version>			      1.0.1	  04.11.2004     Jaroslav Holub
								                report only unsuccessfully connected series
	  </version>
    <version>           1.0.0   03.11.2004	Jaroslav Holub
                                created first version
    </version>

    <Description>       Procedure generate exchange ports for range of phone numbers and
                        link them together.

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
                        p_phone_number_series_id IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
                        col_phone_start          IN RSIG_EXCHANGE_PORT.t_phone_number_I,
                        col_phone_end            IN RSIG_EXCHANGE_PORT.t_phone_number_I,
                        col_port_code            IN RSIG_EXCHANGE_PORT.t_port_code_I,
                        col_port_count           IN RSIG_EXCHANGE_PORT.t_number_I,
                        p_start_date             IN DATE,
                        p_user_id_of_change      IN NUMBER,
                        handle_tran              IN CHAR,
                        p_raise_error            IN CHAR,
                        p_exchange_prefix        IN VARCHAR2,
                        p_fill_zero              IN CHAR,
                        p_count_digits           IN NUMBER,
                        error_code               OUT NUMBER,
                        error_message            OUT VARCHAR2,
                        result_list              OUT sys_refcursor);
    </Parameters>

  </header>
****************************************************************************/

----------------------------------------------------------------------------
--  Generate_ports_for_phone_numbers
----------------------------------------------------------------------------

procedure Generate_ports_for_phones(

  p_phone_number_series_id IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
  col_phone_start          IN RSIG_EXCHANGE_PORT.t_phone_number_I,
  col_phone_end            IN RSIG_EXCHANGE_PORT.t_phone_number_I,
  col_port_code            IN RSIG_EXCHANGE_PORT.t_port_code_I,
  col_port_count           IN RSIG_EXCHANGE_PORT.t_number_I,
  p_start_date             IN DATE,
  p_user_id_of_change      IN NUMBER,
  handle_tran              IN CHAR,
  p_raise_error            IN CHAR,
  p_exchange_prefix        IN VARCHAR2,
  p_fill_zero              IN CHAR,
  p_count_digits           IN NUMBER,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor);

/****************************************************************************
  <header>
    <name>              procedure Link_Ex_Port_to_Ph_Number
    </name>

    <author>            Petr Cepek
    </author>

    <version>           1.0.3     03.07.2006   Petr Cepek
                        columns from network_address moved to phone_number
    </version>
    <version>           1.0.2   2.05.2006  Petr Cepek
                        error handling fixed
    </version>
    <version>           1.0.1   06.06.2005 error handling adjusted
    </version>
    <version>           1.0.0   19.05.2005 created first version
    </version>

    <Description>       Procedure link appropriate exchange port identified by
                        access_point_id to appropriate phone number.

    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       FORIS Resource inventory
    </Application>

    <Parameters>
                        ,
                        handle_tran       IN  CHAR,
                        p_raise_error     IN  CHAR,
                        error_code        OUT NUMBER,
                        error_message     OUT VARCHAR2
    </Parameters>

  </header>
****************************************************************************/
procedure Link_Ex_Port_to_Ph_Number(
  p_access_point_id     IN  access_point.access_point_id%TYPE,
  p_phone_number        IN  phone_number.international_format%TYPE,
  p_link_type_code      IN  network_address_access_point.link_type_code%TYPE,
  p_from_date           IN  DATE,
  p_user_id_of_change   IN  NUMBER,
  handle_tran	          IN  CHAR,
  p_raise_error	        IN  CHAR,
  error_code            OUT NUMBER,
  error_message	        OUT VARCHAR2
);

 /****************************************************************************
    <header>
      <name>              function Get_Number_From_Char
      </name>

      <author>            Radomir Lipka
      </author>

      <version>           1.0.0   30.5.2005  Radomir Lipka
                                  created first version
      </version>

      <Description>
                          function returns number from some chars

      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       FORIS Resource inventory
      </Application>

      <Parameters>
                          p_string       IN VARCHAR2
      </Parameters>

    </header>
  ****************************************************************************/
  FUNCTION Get_Number_From_Char
  (
    p_string       IN VARCHAR2 -- string to change
  ) RETURN NUMBER;

END RSIG_EXCHANGE_PORT;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_EXCHANGE_PORT.pkg,v 1.15 2003/12/15 09:02:25 jstodulk Exp $
/
