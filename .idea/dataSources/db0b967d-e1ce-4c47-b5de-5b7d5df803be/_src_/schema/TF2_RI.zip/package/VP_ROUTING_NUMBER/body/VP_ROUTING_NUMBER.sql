CREATE package body vp_routing_number is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return routing_number%rowtype
is
  v_res routing_number%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_ROUTING_NUMBER_ID)*/
        * into v_res
        from routing_number z
        where 1 = 1
        and routing_number_id = p_id
        and p_date between date_from and date_to
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_ROUTING_NUMBER_ID)*/
        * into v_res
        from routing_number z
        where 1 = 1
        and routing_number_id = p_id
        and p_date between date_from and date_to
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_ROUTING_NUMBER_ID)*/
      * into v_res
      from routing_number z
      where 1 = 1
      and routing_number_id = p_id
      and p_date between date_from and date_to
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1(p_id integer, p_date date) return routing_number%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get1_i(p_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get1(p_id integer, p_date date) return routing_number%rowtype
is
  v_res routing_number%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_i(p_id, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xvalid_i(p_rec routing_number%rowtype)
is
begin
  ------------------------------
  util_pkg.xcheck_version_dates(p_rec.date_from, p_rec.date_to);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function find_i_id(p_rec routing_number%rowtype) return boolean
is
  v_cnt number;
begin
  ------------------------------
select /*+ index_asc(z, I_ROUTING_NUMBER_ID)*/
  count(1) cnt into v_cnt
  from routing_number z
  where 1 = 1
  and routing_number_id = p_rec.routing_number_id
  and greatest(p_rec.date_from, date_from) <= least(p_rec.date_to, date_to)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_code(p_rec routing_number%rowtype) return boolean
is
  v_cnt number;
begin
  ------------------------------
select /*+ index_asc(z, I_ROUTING_NUMBER_CODE)*/
  count(1) cnt into v_cnt
  from routing_number z
  where 1 = 1
  and routing_number_code = p_rec.routing_number_code
  and greatest(p_rec.date_from, date_from) <= least(p_rec.date_to, date_to)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_name(p_rec routing_number%rowtype) return boolean
is
  v_cnt number;
begin
  ------------------------------
select /*+ index_asc(z, I_ROUTING_NUMBER_NAME)*/
  count(1) cnt into v_cnt
  from routing_number z
  where 1 = 1
  and routing_number_name = p_rec.routing_number_name
  and greatest(p_rec.date_from, date_from) <= least(p_rec.date_to, date_to)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i(p_rec routing_number%rowtype) return boolean
is
begin
  ------------------------------
  if find_i_id(p_rec)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_code(p_rec)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_name(p_rec)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xunique_i(p_rec routing_number%rowtype)
is
begin
  ------------------------------
  if find_i_id(p_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_Vers2(p_rec.routing_number_id, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_code(p_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_Vers(p_rec.routing_number_code, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_name(p_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_Vers(util_pkg.nchar_to_char(p_rec.routing_number_name), p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_i(p_rec routing_number%rowtype)
is
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
  xunique_i(p_rec);
  ------------------------------
  insert into routing_number
  values p_rec;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure close_i(p_rec routing_number%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
update /*+ index_asc(z, I_ROUTING_NUMBER_ID)*/
  routing_number z
  set
    date_to = p_rec.date_to,
    user_id_of_change = p_rec.user_id_of_change,
    date_of_change = p_rec.date_of_change
  where 1 = 1
  and routing_number_id = p_rec.routing_number_id
  and p_rec.date_to between date_from and date_to
  and date_from = p_rec.date_from
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_Vers2(p_rec.routing_number_id, p_rec.date_from, p_rec.date_to, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_OnDate2(p_rec.routing_number_id, p_rec.date_to, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open(p_rec in out nocopy routing_number%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  p_rec.routing_number_id := nvl(p_rec.routing_number_id, sq_routing_number.nextval);
  ------------------------------
  p_rec.date_from := nvl(p_rec.date_from, v_sysdate);
  p_rec.date_to := nvl(p_rec.date_to, util_pkg.c_open_date_to);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change(p_rec in out nocopy routing_number%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_to_prev date;
  v_rec routing_number%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.routing_number_id is null, 'p_rec.routing_number_id');
  ------------------------------
  p_rec.date_from := nvl(p_rec.date_from, v_sysdate);
  p_rec.date_to := nvl(p_rec.date_to, util_pkg.c_open_date_to);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(p_rec.date_from);
  ------------------------------
  v_rec := xlock_get1(p_rec.routing_number_id, v_date_to_prev);
  ------------------------------
  if v_rec.routing_number_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_rec.routing_number_id, v_date_to_prev, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.user_id_of_change := p_rec.user_id_of_change;
  ------------------------------
  v_rec.date_of_change := v_sysdate;
  v_rec.date_to := v_date_to_prev;
  ------------------------------
  close_i(v_rec);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close
(
    p_id integer,
    p_user_id integer,
    p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_to_prev date;
  v_rec routing_number%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(nvl(p_date_from, v_sysdate));
  ------------------------------
  v_rec := xlock_get1(p_id, v_date_to_prev);
  ------------------------------
  if v_rec.routing_number_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, v_date_to_prev, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  xvalid_i(v_rec);
  ------------------------------
  v_rec.user_id_of_change := p_user_id;
  ------------------------------
  v_rec.date_of_change := v_sysdate;
  v_rec.date_to := v_date_to_prev;
  ------------------------------
  --!_! need to check for childs (network_operator, host, etc), now skipped
  ------------------------------
  close_i(v_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
