CREATE PACKAGE TIME_ZONE_OFFSET_PKG IS

PROCEDURE Get_date_from_dst_rule(
  p_year                        IN   VARCHAR2,
  p_dst_rule_mask               IN   VARCHAR2,
  p_dst_rule_date               IN   VARCHAR2,
  p_date                        OUT  DATE
);

PROCEDURE Get_time_zone_offset_list_root(
  p_date_from                   IN   DATE,
  p_date_to                     IN   DATE,
  p_error_code                  OUT  NUMBER,
  p_error_message               OUT  VARCHAR2,
  p_time_zone_offset_list       OUT  SYS_REFCURSOR
);

PROCEDURE Get_time_zone_offset_list(
  p_network_operator_code       IN   VARCHAR2,
  p_date_from                   IN   DATE,
  p_date_to                     IN   DATE,
  p_error_code                  OUT  NUMBER,
  p_error_message               OUT  VARCHAR2,
  p_time_zone_offset_list       OUT  SYS_REFCURSOR
);

END;
/
