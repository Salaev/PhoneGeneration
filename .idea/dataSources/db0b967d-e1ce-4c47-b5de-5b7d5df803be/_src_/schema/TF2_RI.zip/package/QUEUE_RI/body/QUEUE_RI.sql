CREATE package body QUEUE_RI is

------------------------------!------------------------------
procedure set_ResReservationMsg
(
  p_msisdn               varchar2,
  p_resource_param_code  varchar2,
  p_resource_param_value varchar2,
  p_event_date           date,
  p_event_type           number -- type of an event (exm. 0-false(unreservation), 1-true(reservation))
)
as
  v_enqueue_options dbms_aq.enqueue_options_t;
  v_message_properties dbms_aq.message_properties_t;
  v_message msg_resource_reservation_type;
  v_ms_handle raw(100);
  v_queue_name varchar2(60);
begin
  ------------------------------
  v_message :=
    msg_resource_reservation_type
    (
      msisdn => p_msisdn,
      resource_param_code => p_resource_param_code,
      resource_param_value => p_resource_param_value,
      event_date => p_event_date,
      event_type => p_event_type
    );
  ------------------------------
  v_queue_name := sys_context('USERENV', 'CURRENT_USER') || '.' || c_Q_RES_RESERVATION;
  ------------------------------
  dbms_aq.enqueue
  (
    queue_name => v_queue_name,
    enqueue_options => v_enqueue_options,
    message_properties => v_message_properties,
    payload => v_message,
    msgid => v_ms_handle
  );
  ------------------------------
end;

------------------------------!------------------------------
procedure get_ResReservationMsg
(
  p_subscriber           varchar2,
  p_msisdn               out varchar2,
  p_resource_param_code  out varchar2,
  p_resource_param_value out varchar2,
  p_event_date           out date,
  p_event_type           out number,
  p_ms_handle            out varchar2
)
as
  v_dequeue_options       dbms_aq.dequeue_options_t;
  v_message_properties    dbms_aq.message_properties_t;
  v_message               msg_resource_reservation_type;
  v_queue_name            varchar2(60);
begin
  ------------------------------
  v_dequeue_options.wait := 1;
  v_dequeue_options.consumer_name := p_subscriber;
  ------------------------------
  v_queue_name := sys_context('USERENV', 'CURRENT_USER') || '.' || c_Q_RES_RESERVATION;
  ------------------------------
  dbms_aq.dequeue
  (
    queue_name => v_queue_name,
    dequeue_options => v_dequeue_options,
    message_properties => v_message_properties,
    payload => v_message,
    msgid => p_ms_handle
  );
  ------------------------------
  p_msisdn                := v_message.msisdn;
  p_resource_param_code   := v_message.resource_param_code;
  p_resource_param_value  := v_message.resource_param_value;
  p_event_date            := v_message.event_date;
  p_event_type            := v_message.event_type;
  ------------------------------
end;

------------------------------!------------------------------
------------------------------!------------------------------
procedure set_bs_change_msg
(
  p_imsi                 varchar2,
  p_msisdn               varchar2,
  p_start_date_msisdn    date,
  p_end_date_msisdn      date,
  p_personal_account     number,
  p_balance_storage_type varchar2,
  p_balance_storage_code varchar2,
  p_start_date_bs        date,
  p_end_date_bs          date,
  p_operation_type       varchar2
)
as
  v_enqueue_options dbms_aq.enqueue_options_t;
  v_message_properties dbms_aq.message_properties_t;
  v_message msg_imsi_msisdn_bs_change;
  v_ms_handle raw(100);
  v_queue_name varchar2(60);
begin
  ------------------------------
  v_message :=
    msg_imsi_msisdn_bs_change
    (
      imsi => p_imsi,
      msisdn => p_msisdn,
      start_date_msisdn => p_start_date_msisdn,
      end_date_msisdn => p_end_date_msisdn,
      personal_account => p_personal_account,
      balance_storage_type => p_balance_storage_type,
      balance_storage_code => p_balance_storage_code,
      start_date_bs => p_start_date_bs,
      end_date_bs => p_end_date_bs,
      operation_type => p_operation_type
    );
  ------------------------------
  v_queue_name := sys_context('USERENV', 'CURRENT_USER') || '.' || c_Q_IMSI_MSISDN_BS_CHANGE;
  ------------------------------
  dbms_aq.enqueue
  (
    queue_name => v_queue_name,
    enqueue_options => v_enqueue_options,
    message_properties => v_message_properties,
    payload => v_message,
    msgid => v_ms_handle
  );
  ------------------------------
end;

------------------------------!------------------------------
procedure get_bs_change_msg
(
  p_subscriber           varchar2,
  p_imsi                 out varchar2,
  p_msisdn               out varchar2,
  p_start_date_msisdn    out date,
  p_end_date_msisdn      out date,
  p_personal_account     out number,
  p_balance_storage_type out varchar2,
  p_balance_storage_code out varchar2,
  p_start_date_bs        out date,
  p_end_date_bs          out date,
  p_operation_type       out varchar2,
  p_ms_handle            out varchar2
)
as
  v_dequeue_options dbms_aq.dequeue_options_t;
  v_message_properties dbms_aq.message_properties_t;
  v_message msg_imsi_msisdn_bs_change;
  v_queue_name varchar2(60);
begin
  ------------------------------
  v_dequeue_options.wait := 1;
  v_dequeue_options.consumer_name := p_subscriber;
  -- dequeue_options.navigation := dbms_aq.FIRST_MESSAGE;
  ------------------------------
  v_queue_name := sys_context('USERENV', 'CURRENT_USER') || '.' || c_Q_IMSI_MSISDN_BS_CHANGE;
  ------------------------------
  dbms_aq.dequeue(
    queue_name => v_queue_name,
    dequeue_options => v_dequeue_options,
    message_properties => v_message_properties,
    payload => v_message,
    msgid => p_ms_handle
  );
  ------------------------------
  p_imsi := v_message.imsi;
  p_msisdn := v_message.msisdn;
  p_start_date_msisdn := v_message.start_date_msisdn;
  p_end_date_msisdn := v_message.end_date_msisdn;
  p_personal_account := v_message.personal_account;
  p_balance_storage_type := v_message.balance_storage_type;
  p_balance_storage_code := v_message.balance_storage_code;
  p_start_date_bs := v_message.start_date_bs;
  p_end_date_bs := v_message.end_date_bs;
  p_operation_type := v_message.operation_type;
  ------------------------------
end;

------------------------------!------------------------------
end;
/
