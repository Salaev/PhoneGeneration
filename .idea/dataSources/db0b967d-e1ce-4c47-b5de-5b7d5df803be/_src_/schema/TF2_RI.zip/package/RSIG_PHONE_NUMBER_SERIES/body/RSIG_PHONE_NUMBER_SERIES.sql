CREATE PACKAGE BODY RSIG_PHONE_NUMBER_SERIES IS

---------------------------------------------
--     PROCEDURE Test_Row_For_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Row_For_Exist_And_Deleted(
    p_phone_number_series_id IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE
)
IS
  v_deleted         PHONE_NUMBER_SERIES.DELETED%TYPE;
BEGIN
  SELECT DELETED
  INTO v_deleted
  FROM PHONE_NUMBER_SERIES
  WHERE PHONE_NUMBER_SERIES_ID = p_phone_number_series_id;

  IF v_deleted IS NOT NULL THEN
    IF v_deleted < SYSDATE THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
    END IF;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Test_Row_For_Exist_And_Deleted;


---------------------------------------------
--     PROCEDURE Test_Phone_Number_Type_Deleted
---------------------------------------------

PROCEDURE Test_Phone_Number_Type_Deleted( p_phone_number_type_code IN PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE)
IS
  v_s         VARCHAR2(1);
BEGIN
  SELECT 'X'
  INTO  v_s
  FROM PHONE_NUMBER_TYPE
  WHERE TRIM(PHONE_NUMBER_TYPE_CODE) = TRIM(p_phone_number_type_code)
    AND deleted IS NULL;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, 'Phone number type not exists.');
END Test_Phone_Number_Type_Deleted;

---------------------------------------------
--     PROCEDURE Test_Network_Operator_Deleted
---------------------------------------------

PROCEDURE Test_Network_Operator_Deleted( p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE)
IS
v_s         VARCHAR2(1);
BEGIN
  SELECT 'X'
  INTO  v_s
  FROM NETWORK_OPERATOR
  WHERE NETWORK_OPERATOR_ID = p_network_operator_id
    AND deleted IS NOT NULL AND deleted < SYSDATE;

    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    NULL;
END Test_Network_Operator_Deleted;

---------------------------------------------
--     PROCEDURE Test_Host_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Host_Exist_And_Deleted( p_phone_number_hlr_id IN HOST.HOST_ID%TYPE)
IS
  v_deleted         HOST.DELETED%TYPE;
BEGIN
  SELECT DELETED
  INTO v_deleted
  FROM HOST h
  WHERE h.HOST_ID = p_phone_number_hlr_id;

  IF v_deleted IS NOT NULL THEN
    IF v_deleted < SYSDATE THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
    END IF;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Test_Host_Exist_And_Deleted;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Insert_Phone_Number_Series
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_Phone_Number_Series(
  p_phone_number_type_code   IN     PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE, -- phone number type code of the given serie of phone numbers
  p_phone_num_status_code    IN     NETWORK_ADDRESS_STATUS.NET_ADDRESS_STATUS_CODE%TYPE,
  p_country_code             IN     PHONE_NUMBER_SERIES.COUNTRY_CODE%TYPE, -- country code of given phone number serie
  p_area_code                IN     PHONE_NUMBER_SERIES.AREA_CODE%TYPE, -- area code of given phone number serie
  p_starting_local_number    IN     PHONE_NUMBER_SERIES.LOCAL_NUMBER_START%TYPE, -- starting local phone number of new phone number serie
  p_ending_local_number      IN     PHONE_NUMBER_SERIES.LOCAL_NUMBER_END%TYPE, -- ending local phone number of new phone number serie
  p_network_operator_id      IN     NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE, -- id of the network operator who will own this new inserted serie
  p_start_date               IN     DATE, -- the date since when given network operator owns this new inserted serie
  p_host_id                  IN     PHONE_NUMBER_SERIES.HOST_ID%TYPE,
  p_subhost_id               IN     PHONE_NUMBER_SERIES.SUBHOST_ID%TYPE,
  p_set_gold                 IN     CHAR,
  p_create_phones            IN     NUMBER,
  p_user_id                  IN     NUMBER,
  p_handle_tran               IN     CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error               IN     CHAR DEFAULT rsig_utils.c_NO,
  p_phone_serie_id           OUT    PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
  p_error_code               OUT    NUMBER,
  p_error_message             OUT    VARCHAR2
)
IS
  v_starting_local_number    VARCHAR2(20); -- starting local phone number of new phone number serie
  v_ending_local_number      VARCHAR2(20); -- ending local phone number of new phone number serie

  v_date                     DATE := SYSDATE; -- date of performing changes in this procedure
  v_phone_number_ser_id      NUMBER;
  v_length                   NUMBER;
  v_start_date               DATE;
  v_serie_exist              INT :=0;
  a_PN                       t_PHONE;
  i                          NUMBER:=1;
  v_create_phones            boolean := util_pkg.int_to_bool_2val(p_create_phones);
  --
  v_locker locker_pkg.t_locker;
  --
BEGIN
  ------------------------------
  -- check if mandatory parameters exist
  IF (p_starting_local_number IS NULL)
     OR (p_ending_local_number IS NULL)
     OR (p_country_code IS NULL)
     OR (p_user_id IS NULL)
     OR (p_network_operator_id IS NULL)
     OR (p_phone_number_type_code IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;
  v_start_date := nvl(p_start_date, SYSDATE);
  ------------------------------
  -- replacing spaces from phone number
  v_starting_local_number:=REPLACE(p_starting_local_number, ' ');
  v_ending_local_number:=REPLACE(p_ending_local_number, ' ');
  -- find length of phone number without prefix
  v_length:=length(v_ending_local_number);
  ------------------------------
  -- Start number is longer than end number
  IF v_length < length(v_starting_local_number) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, '');
  END IF;
  ------------------------------
  -- complete start number to same length as end number
  v_starting_local_number:=lpad(v_starting_local_number,v_length,'0');
  ------------------------------
  -- start number is greater than  end number
  IF to_number(v_ending_local_number) < to_number(v_starting_local_number) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, '');
  END IF;
  ------------------------------
  v_locker := locker_pkg.xl_latch_range2
  (
    p_type_id => c_locker_type_pns_range,
    p_sn_from => REPLACE(p_country_code, ' ') || REPLACE(p_area_code, ' ') || v_starting_local_number,
    p_sn_to => REPLACE(p_country_code, ' ') || REPLACE(p_area_code, ' ') || v_ending_local_number
  );
  ------------------------------
  -- test for overlaping of phone serie
  SELECT COUNT(1)
  INTO v_serie_exist
  FROM phone_number_series pns
  WHERE (pns.deleted>SYSDATE OR pns.deleted IS NULL)
    AND to_number(p_country_code || p_area_code || v_starting_local_number) <=
        to_number(pns.country_code || pns.area_code || pns.local_number_end)
    AND to_number(p_country_code || p_area_code || v_ending_local_number) >=
        to_number(pns.country_code || pns.area_code || pns.local_number_start);
  ------------------------------
  IF v_serie_exist > 0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INTERVAL_INTERFERES_D, '');
  END IF;
  ------------------------------
  Test_Phone_Number_Type_Deleted(p_phone_number_type_code);
  Test_Network_Operator_Deleted(p_network_operator_id);
  ------------------------------
  SELECT S_PHONE_NUMBER_SERIES.NEXTVAL INTO v_phone_number_ser_id FROM dual;
  ------------------------------
  -- inserting new phone number serie
  INSERT INTO PHONE_NUMBER_SERIES
    (PHONE_NUMBER_SERIES_ID,
     COUNTRY_CODE,
     AREA_CODE,
     LOCAL_NUMBER_START,
     LOCAL_NUMBER_END,
     PHONE_NUMBER_TYPE_CODE,
     DATE_OF_CHANGE,
     USER_ID_OF_CHANGE,
     HOST_ID,
     SUBHOST_ID
    )
  VALUES
    (v_phone_number_ser_id,
     p_country_code,
     p_area_code,
     v_starting_local_number,
     v_ending_local_number,
     p_phone_number_type_code,
     v_date,
     p_user_id,
     p_host_id,
     p_subhost_id
    );
  ------------------------------
  -- assign operator who owns the given serie to the given serie
  INSERT INTO PHONE_SERIES_OPERATOR
    (PHONE_NUMBER_SERIES_ID,
     NETWORK_OPERATOR_ID,
     START_DATE,
     END_DATE,
     DATE_OF_CHANGE,
     USER_ID_OF_CHANGE)
  VALUES
    (v_phone_number_ser_id,
     p_network_operator_id,
     v_start_date,
     NULL,
     v_date,
     p_user_id);
  ------------------------------
  if v_create_phones
  then
    ------------------------------
    DELETE FROM tt_batch_na_ap;
    ------------------------------
     -- generating phone numbers
    FOR v_cur_phone IN to_number(v_starting_local_number) .. to_number(v_ending_local_number) LOOP
      a_PN(i):=p_country_code || p_area_code || lpad(v_cur_phone, v_length, '0');
      i:=i+1;
    END LOOP;
    ------------------------------
    FORALL y IN a_PN.FIRST .. a_PN.LAST
    INSERT INTO tt_batch_na_ap(international_format)
    VALUES(a_PN(y));
    ------------------------------
    -- find already deleted phone numbers
    UPDATE tt_batch_na_ap t
    SET (t.network_address_id,t.RESULT)= (SELECT /*+ index(pn UK_PHONE_NUM_PHONE_NUMBER) */
                                                 pn.network_address_id,
                                                 rsig_utils.c_ORA_DELETED
                                          FROM phone_number pn
                                          WHERE pn.international_format=t.international_format);
    ------------------------------
    -- add new network address id for each new phone number
    UPDATE tt_batch_na_ap t
    SET t.network_address_id=s_network_address.NEXTVAL
    WHERE t.RESULT IS NULL;
    ------------------------------
    INSERT INTO network_address(network_address_id)
    SELECT t.network_address_id
    FROM tt_batch_na_ap t
    WHERE t.RESULT IS NULL;
    ------------------------------
      -- insert new phone numbers
    INSERT INTO phone_number(network_address_id,
                             phone_number_series_id,
                             international_format,
                             date_of_change,
                             user_id_of_change)
    SELECT t.network_address_id,
           v_phone_number_ser_id,
           t.international_format,
           v_date,
           p_user_id
    FROM tt_batch_na_ap t
    WHERE t.RESULT IS NULL;
    ------------------------------
    -- update already deleted phone numbers
    UPDATE phone_number pn
    SET pn.phone_number_series_id=v_phone_number_ser_id,
        pn.deleted = NULL
    WHERE EXISTS(SELECT 1
                 FROM tt_batch_na_ap t
                 WHERE t.network_address_id=pn.network_address_id
                   AND t.result=rsig_utils.c_ORA_DELETED);
    ------------------------------
    -- finding out, whether given phone numbers is "gold" category or not
    RSig_Phone_Number.Mark_Gold_Phone_Numbers(handle_tran => rsig_utils.c_NO,
                                              p_start_date => v_start_date,
                                              p_phone_number_series_id => v_phone_number_ser_id,
                                              p_user_id_of_change => p_user_id,
                                              p_set_gold => p_set_gold,
                                              p_leave_marked_unchanged => rsig_utils.c_NO,
                                              p_raise_error => rsig_utils.c_YES,
                                              error_code => p_error_code);
    ------------------------------
    -- setting status for given phone number
    INSERT INTO NETWORK_ADDRESS_STATUS_HISTORY
      (NET_ADDRESS_STATUS_CODE,
       NETWORK_ADDRESS_ID,
       START_DATE,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE,
       END_DATE)
      SELECT /*+ index(pn I_PHONENUM_PHONE_NUM_SERIES_ID)*/
             p_phone_num_status_code,
             pn.network_address_id,
             v_start_date,
             v_date,
             p_user_id,
             NULL
        FROM phone_number pn
       WHERE pn.phone_number_series_id=v_phone_number_ser_id;
    ------------------------------
  end if;
  ------------------------------
  p_phone_serie_id := v_phone_number_ser_id;
  ------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  locker_pkg.Release_Locker(v_locker.locker_id);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  locker_pkg.release_locker(v_locker.locker_id);
  ------------------------------
  if upper(p_raise_error)=rsig_utils.c_yes
  then
    util_pkg.reraise_exception;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure split_phone_number_series
(
  handle_tran char := rsig_utils.c_handle_tran_y, --!_!always Y
  p_error_code out number,
  p_error_message out varchar2,
  p_phone_number_serie_id number,
  p_start_phone_number varchar2,
  p_user_id_of_change number
)
is
begin
  ------------------------------
  util_loc_pkg.touch_varchar(handle_tran);
  ------------------------------
  fastp_phone_series_pkg.split_range2
  (
    p_id => p_phone_number_serie_id,
    p_item_split_from => p_start_phone_number,
    p_user_id => p_user_id_of_change
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
---------------------------------------------
--     PROCEDURE Change_Phone_Serie_Type
---------------------------------------------

PROCEDURE Change_Phone_Serie_Type
(
  handle_tran              IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code               OUT NUMBER,
  p_phone_number_serie_id  IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the splitted phone number serie
  p_phone_number_type_code IN PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE, -- code of the phone serie type that given serie will be updated to
  p_user_id_of_change      IN NUMBER, -- id of the user who insert this serie
  p_raise_error             IN  CHAR
) IS
  v_event_source           VARCHAR2(60) := 'RSIG_PHONE_NUMBER_SERIES.Change_Phone_Serie_Type';
  v_phone_number_type_code PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT change_phone_serie_type_a;
  END IF;

  SELECT phs.PHONE_NUMBER_TYPE_CODE
    INTO v_phone_number_type_code
    FROM PHONE_NUMBER_SERIES phs
   WHERE phs.PHONE_NUMBER_SERIES_ID = p_phone_number_serie_id;

  -- If phone serie type is not change it generate exception
  IF TRIM(v_phone_number_type_code) = TRIM(p_phone_number_type_code) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_SAME_PHONE_SERIE_TYPE, '');
  END IF;

  -- check if given serie exists
  Test_Row_For_Exist_And_Deleted(p_phone_number_serie_id);

  -- check if given phone number type exists
  Test_Phone_Number_Type_Deleted(p_phone_number_type_code);

  UPDATE PHONE_NUMBER_SERIES
     SET PHONE_NUMBER_TYPE_CODE = p_phone_number_type_code,
         DATE_OF_CHANGE         = SYSDATE,
         USER_ID_OF_CHANGE      = p_user_id_of_change
   WHERE PHONE_NUMBER_SERIES_ID = p_phone_number_serie_id;

  IF SQL%NOTFOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(to_number(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT change_phone_serie_type_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Change_Phone_Serie_Type;

---------------------------------------------
--     PROCEDURE Change_Operator
---------------------------------------------

PROCEDURE Change_Operator
(
  handle_tran             IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code              OUT NUMBER,
  p_phone_number_serie_id IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the phone number serie that we want to change operator of
  p_old_net_operator_id   IN network_operator.network_operator_id%TYPE,
  p_network_operator_id   IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE, -- id of the network operator who will own the given serie
  p_start_date            IN DATE, -- date since the series change is valid
  p_user_id_of_change     IN NUMBER -- id of the user who insert this serie
) IS
  v_event_source        VARCHAR2(60) := 'RSIG_PHONE_NUMBER_SERIES.Change_Operator';
  v_start_date          DATE; -- date since when the changed serie is valid
  v_change_date         DATE; -- date of changing the operator
  v_phone_number_used   number DEFAULT RSIG_UTILS.c_FALSE; -- some phone number in phone number series is used

  CURSOR phone_number_used IS -- check if one of series is closed (deleted)
    SELECT DISTINCT 0
      FROM PHONE_NUMBER                 pn,
           NETWORK_ADDRESS_ACCESS_POINT naap
     WHERE pn.PHONE_NUMBER_SERIES_ID = p_phone_number_serie_id
       AND pn.NETWORK_ADDRESS_ID = naap.NETWORK_ADDRESS_ID
       AND v_start_date BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE, v_start_date);


BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT change_operator_a;
  END IF;

  SELECT SYSDATE INTO v_change_date FROM dual;

  -- check if given serie exists
  Test_Row_For_Exist_And_Deleted(p_phone_number_serie_id);

  -- check if given operator exists
  Test_Network_Operator_Deleted(p_network_operator_id);


  v_start_date := nvl(p_start_date, SYSDATE);



  -- If phone operator is not change it generate exception
  IF p_old_net_operator_id = p_network_operator_id THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_SAME_PHONE_OPERATOR, '');
  END IF;

   -- test for type of operator
  Test_network_operators_type(p_old_net_operator_id,p_network_operator_id);

  -- check if some phone number from number phone series is used - raise error
  OPEN phone_number_used;
  FETCH phone_number_used
    INTO v_phone_number_used;
  CLOSE phone_number_used;

  IF v_phone_number_used = RSIG_UTILS.c_OK THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_PHONE_IN_PHONE_SER_USE, '');
  END IF;

  -- setting end date of the current phone number serie
  UPDATE PHONE_SERIES_OPERATOR
     SET END_DATE          = v_start_date - RSIG_UTILS.c_INTERVAL_DIFFERENCE,
         DATE_OF_CHANGE    = v_change_date,
         USER_ID_OF_CHANGE = p_user_id_of_change
   WHERE PHONE_NUMBER_SERIES_ID = p_phone_number_serie_id
     AND network_operator_id=p_old_net_operator_id
     AND END_DATE IS NULL;

  IF SQL%NOTFOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
  END IF;

  -- setting new phone serie operator
  INSERT INTO PHONE_SERIES_OPERATOR
    (PHONE_NUMBER_SERIES_ID,
     NETWORK_OPERATOR_ID,
     START_DATE,
     END_DATE,
     DATE_OF_CHANGE,
     USER_ID_OF_CHANGE)
  VALUES
    (p_phone_number_serie_id,
     p_network_operator_id,
     v_start_date,
     NULL,
     v_change_date,
     p_user_id_of_change);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(to_number(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT change_operator_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
END Change_Operator;

---------------------------------------------
--     PROCEDURE Delete_Serie
---------------------------------------------

PROCEDURE Delete_Serie(
  handle_tran             IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_phone_number_serie_id IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the serie to be deleted
  p_deleted               IN PHONE_NUMBER_SERIES.DELETED%TYPE,
  p_user_id_of_change     IN NUMBER,
  error_code              OUT NUMBER
)
IS
  v_event_source          VARCHAR2(60) := 'RSIG_PHONE_NUMBER_SERIES.Delete_Serie';
  v_referenced            INT;
  v_deleted               DATE; -- the time when the element was deleted
  v_sysdate               DATE;
  v_rec phone_operator%rowtype;
  v_na_ids ct_number;

  CURSOR c_phones IS
  SELECT pn.network_address_id
  FROM phone_number pn
  WHERE pn.phone_number_series_id=p_phone_number_serie_id
  FOR UPDATE NOWAIT;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT close_serie_a;
  END IF;

  -- lock phone numbers
  BEGIN
    OPEN c_phones;
    CLOSE c_phones;
  EXCEPTION
    WHEN RSIG_UTILS.RESOURCE_BUSY THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_RESOURCE_BUSY, 'Resource is busy');
  END;

  -- check if given serie exists
  Test_Row_For_Exist_And_Deleted(p_phone_number_serie_id);
  v_deleted := nvl(p_deleted, SYSDATE);

  -- check if some phone number in phone number series has reference to sim cart
  SELECT COUNT(1)
  INTO v_referenced
  FROM dual
  WHERE EXISTS(SELECT /*+ index(pn I_PHONENUM_PHONE_NUM_SERIES_ID) FIRST_ROWS */ 1
               FROM phone_number pn
               JOIN network_address_access_point naap ON naap.network_address_id=pn.network_address_id
                    AND (naap.to_date IS NULL OR naap.to_date >= v_deleted)
               WHERE pn.phone_number_series_id=p_phone_number_serie_id)
    OR EXISTS(SELECT /*+ use_nl(pn bd b) index(pn I_PHONENUM_PHONE_NUM_SERIES_ID) index(bd I_BATCH_DETAILS_OBJ_ID) index(b PK_BATCH)*/
                       1
                FROM phone_number pn
                JOIN batch_details bd ON bd.object_id = pn.network_address_id
                JOIN batch b ON b.batch_id = bd.batch_id
                WHERE pn.phone_number_series_id=p_phone_number_serie_id
                  AND b.batch_type in (batch_pkg.c_BATCH_TYPE_NA_MNG));


  IF v_referenced > 0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_PHONE_IN_PHONE_SER_USE, '');
  END IF;
  v_sysdate := SYSDATE;

  DELETE  /*+ ordered use_nl(bd) index(bd I_BATCH_DETAILS_OBJ_ID)*/ FROM batch_details bd
   WHERE 1 = 1
     AND (bd.object_id, bd.batch_id) IN (select /*+ ordered use_nl(pn tbd tb) index(pn I_PHONENUM_PHONE_NUM_SERIES_ID) index(tbd I_BATCH_DETAILS_OBJ_ID) index(tb PK_BATCH)*/
                                                tbd.object_id,tbd.batch_id
                                           from phone_number pn
                                           join batch_details tbd on tbd.object_id = pn.network_address_id
                                           join batch tb on tb.batch_id = tbd.batch_id and tb.batch_type = batch_pkg.c_BATCH_TYPE_NA_MNG
                                          where pn.phone_number_series_id = p_phone_number_serie_id);

  -- terminate salability category
  UPDATE /*+ ordered use_nl(pn pnsc) index(pnsc I_PHONUSALCA_NET_ADDRESS_ID) */
         PHONE_NUMBER_SALABILITY_CATEG pnsc
     SET pnsc.end_date=v_deleted,
         pnsc.date_of_change=v_sysdate,
         pnsc.user_id_of_change=p_user_id_of_change
   WHERE EXISTS(SELECT /*+ index(pn I_PHONENUM_PHONE_NUM_SERIES_ID)*/
                       1
                FROM phone_number pn
                WHERE pn.phone_number_series_id=p_phone_number_serie_id
                  AND pn.network_address_id=pnsc.network_address_id)
     AND v_deleted BETWEEN pnsc.start_date AND nvl(pnsc.end_date,v_deleted);

  -- terminate network address status
  UPDATE /*+ ordered use_nl(pn nash) index(nash I_NETADSTAHI_NETWORK_ADDRES_ID) */
         NETWORK_ADDRESS_STATUS_HISTORY nash
     SET nash.end_date=v_deleted,
         nash.date_of_change=v_sysdate,
         nash.user_id_of_change=p_user_id_of_change
   WHERE EXISTS(SELECT /*+ index(pn I_PHONENUM_PHONE_NUM_SERIES_ID)*/
                       1
                FROM phone_number pn
                WHERE pn.phone_number_series_id=p_phone_number_serie_id
                  AND pn.network_address_id=nash.network_address_id)
     AND v_deleted BETWEEN nash.start_date AND nvl(nash.end_date,v_deleted);


  -- mark phone as deleted

  UPDATE /*+ index(pn I_PHONENUM_PHONE_NUM_SERIES_ID) */
         phone_number pn
     SET pn.net_address_status_code=NULL,
         pn.salability_category_code=NULL,
         pn.deleted=v_deleted,
         pn.date_of_change=v_sysdate,
         pn.user_id_of_change=p_user_id_of_change
   WHERE pn.phone_number_series_id=p_phone_number_serie_id;


  -- terminate phone_operator
  v_na_ids := util_ri.get_na_by_pns(p_phone_number_serie_id, v_sysdate);
  if util_pkg.get_count_ct_number(v_na_ids) > 0
  then
    ------------------------------
    for v_i in 1..util_pkg.get_count_ct_number(v_na_ids)
    loop
      ------------------------------
      v_rec := vp_phone_operator.get1(v_na_ids(v_i), v_sysdate);
      ------------------------------
      if v_rec.network_address_id is not null
      then
        vp_phone_operator.version_close(v_na_ids(v_i), p_user_id_of_change, v_sysdate);
      end if;
      ------------------------------
    end loop;
    ------------------------------
  end if;

  -- terminate phone_series_operator
  UPDATE phone_series_operator pso
     SET pso.end_date=v_deleted,
         pso.date_of_change=v_sysdate,
         pso.user_id_of_change=p_user_id_of_change
   WHERE pso.phone_number_series_id=p_phone_number_serie_id
     AND v_deleted BETWEEN pso.start_date AND nvl(pso.end_date,v_deleted);

  -- delete from phone_link
  DELETE FROM phone_link pl
  WHERE pl.main_msisdn IN (SELECT /*+ index(pn I_PHONENUM_PHONE_NUM_SERIES_ID) USE_nl(pl pn)*/
                                  pn.international_format
                            FROM phone_number pn
                            WHERE pn.phone_number_series_id=p_phone_number_serie_id);

  DELETE FROM phone_link pl
  WHERE pl.linked_msisdn IN (SELECT /*+ index(pn I_PHONENUM_PHONE_NUM_SERIES_ID) USE_nl(pl pn)*/
                                   pn.international_format
                             FROM phone_number pn
                             WHERE pn.phone_number_series_id=p_phone_number_serie_id);

  -- mark serie as deleted
  UPDATE PHONE_NUMBER_SERIES
     SET DELETED           = v_deleted,
         DATE_OF_CHANGE    = v_sysdate,
         USER_ID_OF_CHANGE = p_user_id_of_change
   WHERE PHONE_NUMBER_SERIES_ID = p_phone_number_serie_id;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(to_number(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT close_serie_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
END Delete_Serie;

---------------------------------------------
--     PROCEDURE Get_Operator_History
---------------------------------------------

PROCEDURE Get_Operator_History
(
  error_code              OUT NUMBER,
  p_phone_number_serie_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE, -- id of the serie we want to get history of
  p_cur_series_hist_oper  IN OUT RSIG_UTILS.REF_CURSOR -- ref cursor variable containing all network operators for given phone number serie who owned the serie in history
) IS
  v_event_source          VARCHAR2(60) := 'RSIG_PHONE_NUMBER_SERIES.Get_Operator_History';
  v_phone_number_serie_id NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE; -- variable we will try to fetch ID of givwen serie into to find out whether this serie exists
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  SELECT PHONE_NUMBER_SERIES_ID
    INTO v_phone_number_serie_id
    FROM PHONE_NUMBER_SERIES
   WHERE PHONE_NUMBER_SERIES_ID = p_phone_number_serie_id;

  OPEN p_cur_series_hist_oper FOR
    SELECT no.network_operator_name,
           pso.START_DATE,
           pso.END_DATE
      FROM PHONE_SERIES_OPERATOR pso
      JOIN NETWORK_OPERATOR no ON no.network_operator_id = pso.network_operator_id
     WHERE pso.PHONE_NUMBER_SERIES_ID = p_phone_number_serie_id
     ORDER BY pso.start_date DESC;

  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(to_number(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Get_Operator_History;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Join_Series
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Join_Series(
  p_phone_number_serie_id1  IN  PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the fist serie of the series to join
  p_phone_number_serie_id2  IN  PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
  p_user_id                 IN  NUMBER,
  p_handle_tran              IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error              IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code              OUT NUMBER,
  p_error_message            OUT VARCHAR2
)
IS
  v_package_name            VARCHAR2(30) := 'RSIG_PHONE_NUMBER_SERIES';
  v_procedure_name          VARCHAR2(30) := 'Join_Series';
  v_event_source            VARCHAR2(60);
  v_serie1                  phone_number_series%ROWTYPE;
  v_serie2                  phone_number_series%ROWTYPE;
  v_new_serie_id            phone_number_series.phone_number_series_id%TYPE;
  v_old_serie_id            phone_number_series.phone_number_series_id%TYPE;
  v_sysdate                 DATE:=SYSDATE;
  v_local_number_start      phone_number_series.local_number_start%TYPE;
  v_local_number_end        phone_number_series.local_number_end%TYPE;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- check input parameters
  IF p_phone_number_serie_id1 IS NULL OR p_phone_number_serie_id2 IS NULL OR p_user_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;
--------------------------------------------------------------------------------------------------------
  -- check series deleted attribute
  BEGIN
    SELECT pns.*
    INTO v_serie1
    FROM phone_number_series pns
    WHERE pns.phone_number_series_id=p_phone_number_serie_id1
      AND pns.deleted IS NULL;

    SELECT pns.*
    INTO v_serie2
    FROM phone_number_series pns
    WHERE pns.phone_number_series_id=p_phone_number_serie_id2
      AND pns.deleted IS NULL;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_SERIE_DELETED, 'Phone series is deleted.');
  END;

  -- check network operators
  --SELECT COUNT(1)
  --INTO v_exist
  --FROM(SELECT DISTINCT pso.network_operator_id
  --     FROM phone_series_operator pso
  --     WHERE pso.phone_number_series_id IN (p_phone_number_serie_id1,p_phone_number_serie_id2));

  --IF v_exist>1 THEN
  --  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NOT_SAME_PO_HISTORY, 'Phone series do not have same operators.');
  --END IF;

  -- check hosts
  IF (v_serie1.host_id<>v_serie2.host_id) OR
     (v_serie1.host_id IS NULL AND v_serie2.host_id IS NOT NULL) OR
     (v_serie2.host_id IS NULL AND v_serie1.host_id IS NOT NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NOT_SAME_HOSTS, 'Phone series do not have same hosts.');
  END IF;

  -- check phone types
  IF trim(v_serie1.phone_number_type_code)<>trim(v_serie2.phone_number_type_code) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NOT_SAME_PHONE_TYPES, 'Phone series are not of the same type.');
  END IF;

  -- check area code
  IF (v_serie1.area_code<>v_serie2.area_code) OR (v_serie1.country_code<>v_serie2.country_code) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_SPLITED_SERIES, 'Phone series do not have same area code.');
  END IF;

  -- set new local number start
  IF v_serie1.local_number_start<v_serie2.local_number_start THEN
    v_local_number_start:=v_serie1.local_number_start;
  ELSE
    v_local_number_start:=v_serie2.local_number_start;
  END IF;

  -- set new local number end
  IF v_serie1.local_number_end<v_serie2.local_number_end THEN
    v_local_number_end:=v_serie2.local_number_end;
  ELSE
    v_local_number_end:=v_serie1.local_number_end;
  END IF;

  -- check sequence of that two series
  IF (v_serie1.local_number_start<v_serie2.local_number_start AND
      (to_number(v_serie2.local_number_start)-to_number(v_serie1.local_number_end))<>1
      ) OR
      (v_serie2.local_number_start<v_serie1.local_number_start AND
      (to_number(v_serie1.local_number_start)-to_number(v_serie2.local_number_end))<>1
      )
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_SPLITED_SERIES, 'Series are not in the sequence.');
  END IF;

  -- get older series
  BEGIN
    SELECT phone_number_series_id
    INTO v_new_serie_id
    FROM(SELECT pso.phone_number_series_id
         FROM phone_series_operator pso
         WHERE pso.phone_number_series_id IN (p_phone_number_serie_id1,p_phone_number_serie_id2)
         ORDER BY pso.start_date)
    WHERE rownum=1;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_SERIE_DELETED, 'Phone series is deleted.');
  END;


  IF v_new_serie_id=p_phone_number_serie_id1 THEN
    v_old_serie_id:=p_phone_number_serie_id2;
  ELSE
    v_old_serie_id:=p_phone_number_serie_id1;
  END IF;

  -- close interval of series which is joined to first series
  UPDATE phone_series_operator pso
  SET pso.end_date=v_sysdate,
      pso.date_of_change=v_sysdate,
      pso.user_id_of_change=p_user_id
  WHERE pso.phone_number_series_id=v_old_serie_id
    AND (pso.end_date>v_sysdate OR pso.end_date IS NULL);

  -- delete old series
  UPDATE phone_number_series pns
  SET pns.date_of_change=v_sysdate,
      pns.user_id_of_change=p_user_id,
      pns.deleted=v_sysdate
  WHERE pns.phone_number_series_id=v_old_serie_id;

  -- join series
  UPDATE phone_number_series pns
  SET pns.local_number_start=v_local_number_start,
      pns.local_number_end=v_local_number_end,
      pns.date_of_change=v_sysdate,
      pns.user_id_of_change=p_user_id
  WHERE pns.phone_number_series_id=v_new_serie_id;

  -- assign phone numbers from serie2 to serie1
  UPDATE /*+ index(pn I_PHONENUM_PHONE_NUM_SERIES_ID) */
         phone_number pn
  SET pn.phone_number_series_id=v_new_serie_id,
      pn.user_id_of_change=p_user_id,
      pn.date_of_change=v_sysdate
  WHERE pn.phone_number_series_id=v_old_serie_id;

---------------------------------------------------------------------------------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;


  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,p_handle_tran,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Join_Series;

---------------------------------------------
--     PROCEDURE Get_Serie_Detail
---------------------------------------------

PROCEDURE Get_Serie_Detail
(
  error_code               OUT NUMBER,
  p_phone_number_series_id IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the splitted phone number serie
  p_cur_series             IN OUT RSIG_UTILS.REF_CURSOR -- cursor containing all series of given operator and phone number count for each serie
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PHONE_NUMBER_SERIES.Get_Serie_Detail';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  OPEN p_cur_series FOR
  SELECT pnt.phone_number_type_name,
         host.host_name,
         (SELECT /*+ index(pn I_PHONENUM_PHONE_NUM_SERIES_ID)*/
                 COUNT(*)
          FROM phone_number pn
          WHERE pn.phone_number_series_id=pns.phone_number_series_id) AS phone_number_count,
         pns.date_of_change,
         users.user_name,
         pns.phone_number_type_code,
         host.HOST_CODE,
         host.host_id,
         (SELECT n.network_operator_name
          FROM phone_series_operator pso
          JOIN network_operator n ON n.network_operator_id=pso.network_operator_id
          WHERE pso.phone_number_series_id=p_phone_number_series_id
            AND SYSDATE BETWEEN pso.start_date AND nvl(pso.end_date,SYSDATE)
            AND n.network_operator_type IS NOT NULL) external_operator_name,
         sh.host_id subhost_id,
         sh.host_code subhost_code,
         sh.host_name subhost_name
  FROM phone_number_series pns
  JOIN phone_number_type pnt ON TRIM(pns.phone_number_type_code) = TRIM(pnt.phone_number_type_code)
  LEFT JOIN host ON pns.host_id = host.host_id
  LEFT JOIN host sh ON pns.subhost_id = sh.host_id
  JOIN users ON pns.user_id_of_change = users.user_id
  WHERE pns.phone_number_series_id = p_phone_number_series_id;

  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(to_number(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Get_Serie_Detail;

---------------------------------------------
--     PROCEDURE Change_Phone_Serie_HLR
---------------------------------------------

PROCEDURE Change_Phone_Serie_HLR
(
  handle_tran             IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  ERROR_CODE              OUT NUMBER,
  p_phone_number_serie_id IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the splitted phone number serie
  p_phone_number_hlr_id   IN HOST.HOST_ID%TYPE,
  p_start_date            IN DATE,
  p_user_id_of_change     IN NUMBER, -- id of the user who insert this serie
   p_raise_error          IN  CHAR
) IS
  v_event_source        VARCHAR2(60) := 'RSIG_PHONE_NUMBER_SERIES.Change_Phone_Serie_HLR';
  v_phone_number_hlr_id HOST.HOST_ID%TYPE;
  v_connection_exist    NUMBER;
  v_sysdate             DATE;
  v_err_msg             VARCHAR2(300);
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT change_phone_serie_type_a;
  END IF;

  -- check if given serie exists
  Test_Row_For_Exist_And_Deleted(p_phone_number_serie_id);
  -- check if given phone number type exists
  IF p_phone_number_hlr_id IS NOT NULL THEN
    Test_Host_Exist_And_Deleted(p_phone_number_hlr_id);
  END IF;

  BEGIN
    SELECT h.HOST_id
      INTO v_phone_number_hlr_id
      FROM PHONE_NUMBER_SERIES pns
      JOIN host h ON pns.HOST_ID = h.HOST_ID
     WHERE pns.PHONE_NUMBER_SERIES_ID = p_phone_number_serie_id;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_phone_number_hlr_id := NULL;
  END;

  -- If phone serie hlr code is not change it generate exception
  IF v_phone_number_hlr_id = p_phone_number_hlr_id THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_SAME_PHONE_SERIE_HLR, '');
  END IF;

  v_sysdate := SYSDATE;

  BEGIN
    -- check if any connections to phone numbers exist
    SELECT 1
    INTO v_connection_exist
    FROM dual
    WHERE EXISTS(SELECT /*+ ORDERED USE_NL(pn,naap) */ 1
                 FROM PHONE_NUMBER pn
                 JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
                 WHERE pn.PHONE_NUMBER_SERIES_ID = p_phone_number_serie_id
                   AND SYSDATE BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE, SYSDATE));

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- no connection exists
      v_connection_exist := 0;
  END;

  IF v_connection_exist = 1 THEN
    -- some phone numbers are connected
    BEGIN
      -- check if phone numbers are connected to sim cards
      SELECT 1
      INTO v_connection_exist
      FROM dual
      WHERE EXISTS(SELECT /*+ ORDERED USE_NL(pn,naap) */ 1
                   FROM PHONE_NUMBER pn
                   JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.NETWORK_ADDRESS_ID = pn.NETWORK_ADDRESS_ID
                   JOIN sim_card sc ON sc.access_point_id=naap.access_point_id
                   WHERE pn.PHONE_NUMBER_SERIES_ID = p_phone_number_serie_id
                     AND SYSDATE BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE, SYSDATE));
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_connection_exist := 0;
    END;

    IF v_connection_exist = 1 THEN
      -- some phone numbers are connected to sim card
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_change_host_phone_used,
                            'There is exist active connection between AP and NA!');
    ELSE
      -- generate exchange ports for phone numbers, which are connected to the ports
      IF p_phone_number_hlr_id IS NOT NULL THEN
      Move_Phones_to_Host(p_Phone_Serie_Id => p_phone_number_serie_id,
                          p_New_Host_id => p_phone_number_hlr_id,
                          p_Start_Date => p_start_date,
                          p_user_id_of_change => p_user_id_of_change,
                          p_date_of_change => v_sysdate,
                          handle_tran => rsig_utils.Get_Handle_Tran_For_Call_Proc(handle_tran),
                          p_raise_error => 'Y',
                          error_code => ERROR_CODE,
                          error_message => v_err_msg);
      END IF;

    END IF;
  END IF;

  -- change host id
  UPDATE PHONE_NUMBER_SERIES
     SET HOST_ID           = p_phone_number_hlr_id,
         DATE_OF_CHANGE    = nvl(p_start_date, v_sysdate),
         USER_ID_OF_CHANGE = p_user_id_of_change
   WHERE PHONE_NUMBER_SERIES_ID = p_phone_number_serie_id;

  IF SQL%NOTFOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(to_number(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT change_phone_serie_type_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Change_Phone_Serie_HLR;


---------------------------------------------
--     PROCEDURE Change_Phone_Operator_And_HLR
---------------------------------------------

PROCEDURE Change_Phone_Operator_And_HLR
(
  handle_tran             IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code              OUT NUMBER,
  p_phone_number_serie_id IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the splitted phone number serie
  p_old_net_operator_id   IN network_operator.network_operator_id%TYPE,
  p_network_operator_id   IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_phone_number_hlr_id   IN HOST.HOST_ID%TYPE,
  p_start_date            IN DATE, -- date since the series change is valid
  p_user_id_of_change     IN NUMBER -- id of the user who insert this serie
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PHONE_NUMBER_SERIES.Change_Phone_Operator_And_HLR';
  v_handle_tran  CHAR(1);
  v_start_date   DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Change_Phone_Oper_And_HLR_a;
  END IF;

  v_handle_tran := RSIG_UTILS.Get_Handle_Tran_For_Call_Proc(handle_tran);

  v_start_date := nvl(p_start_date, SYSDATE);

  RSIG_PHONE_NUMBER_SERIES.Change_Operator(v_handle_tran,
                                           error_code,
                                           p_phone_number_serie_id,
                                           p_old_net_operator_id,
                                           p_network_operator_id,
                                           v_start_date,
                                           p_user_id_of_change);

  IF error_code <> RSIG_UTILS.C_OK THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_CHAN_PHO_OPER_A_HLR_ERR, '');
  END IF;

  RSIG_PHONE_NUMBER_SERIES.Change_Phone_Serie_HLR(v_handle_tran,
                                                  error_code,
                                                  p_phone_number_serie_id,
                                                  p_phone_number_hlr_id,
                                                  v_start_date,
                                                  p_user_id_of_change,
                                                  p_raise_error =>rsig_utils.c_YES);

  IF error_code <> RSIG_UTILS.C_OK THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_CHAN_PHO_OPER_A_HLR_ERR, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    RSIG_UTILS.Debug_Rsi(to_number(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Change_Phone_Oper_And_HLR_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
END Change_Phone_Operator_And_HLR;

---------------------------------------------
--     PROCEDURE Get_Filtered_Phone_Series
---------------------------------------------

PROCEDURE Get_Filtered_Phone_Series
(
  p_raise_error IN CHAR, --Y - procedure ends with error in matter of failure (error code and error message will not be set)
                         --N - procedure ends successfully in matter of failure (error code and error message is set)
  p_network_operator_id  IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_external_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_show_deleted         IN CHAR, --Y - deleted SIM series will be returned,N - deleted SIM series will not be returned
  p_host_id              IN VARCHAR2, --Identification of the host Number - concrete host id Null - SIM series having HOST_ID null % - HOST_ID not considered
  p_phone_number_type    IN PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE,
  error_code             OUT NUMBER,
  p_error_message        OUT VARCHAR2,
  p_cur_series           OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PHONE_NUMBER_SERIES.Get_Filtered_Phone_Series';
  v_sql_string   VARCHAR2(2000);

BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_BEFORE_SELECT,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF ((upper(p_raise_error) NOT IN ('Y', 'N')) OR (p_raise_error IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF ((upper(p_show_deleted) NOT IN ('Y', 'N')) OR (p_show_deleted IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  -- create sql string for open cursor

  v_sql_string := 'SELECT pns.phone_number_series_id, pns.country_code, pns.area_code, pns.local_number_start,
                          pns.local_number_end, pso.end_date
                   FROM PHONE_NUMBER_SERIES pns
                   JOIN PHONE_SERIES_OPERATOR pso ON pso.phone_number_series_id = pns.phone_number_series_id';
  IF p_external_operator_id IS NOT NULL THEN
    v_sql_string := v_sql_string || ' JOIN PHONE_SERIES_OPERATOR pso1 ON pso1.phone_number_series_id = pns.phone_number_series_id';
  END IF;
  v_sql_string := v_sql_string || ' WHERE pso.NETWORK_OPERATOR_ID = ' || p_network_operator_id;

  -- p_show_deleted is N
  IF p_show_deleted = 'N' THEN
    v_sql_string := v_sql_string || ' AND pns.deleted IS NULL';
  END IF;

  -- p_phone_number_type not %
  IF p_phone_number_type != '%' THEN
    v_sql_string := v_sql_string || ' AND TRIM(pns.phone_number_type_code) = ' || chr(39) || TRIM(p_phone_number_type) ||
                    chr(39);
  END IF;

  -- p_host_id is NULL
  IF p_host_id IS NULL THEN
    v_sql_string := v_sql_string || ' AND pns.host_id IS NULL';
  END IF;

  -- condition for external operator
  IF p_external_operator_id IS NOT NULL THEN
    v_sql_string := v_sql_string || ' AND pso1.NETWORK_OPERATOR_ID = ' || p_external_operator_id;
  END IF;

  -- p_host_id is not NULL and p_host_id is number
  IF p_host_id IS NOT NULL
     AND p_host_id != '%' THEN
    v_sql_string := v_sql_string || ' AND pns.host_id = ' || p_host_id;
  END IF;

    v_sql_string := v_sql_string || ' ORDER BY pns.country_code, pns.area_code, pns.local_number_start,pns.deleted NULLS LAST';

  OPEN p_cur_series FOR v_sql_string;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_AFTER_SELECT,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    IF p_raise_error = 'N' THEN
      error_code      := RSIG_UTILS.Handle_Error(sqlcode);
      p_error_message := sqlerrm(sqlcode);
    ELSE
      RAISE;
    END IF;
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         'RSIG_SIM_SERIES.Get_Sim_Series_Operator');
END Get_Filtered_Phone_Series;

--------------------------------------------------------------------------------------------------------------
-- Move_Phones_to_Host
--------------------------------------------------------------------------------------------------------------

PROCEDURE Move_Phones_to_Host(
  p_Phone_Serie_Id            IN  phone_number_series.phone_number_series_id%TYPE,
  p_New_Host_id               IN  host.host_id%TYPE,
  p_Start_Date                IN  DATE,
  p_user_id_of_change         IN  NUMBER,
  p_date_of_change            IN  DATE,
  handle_tran                  IN  CHAR,
  p_raise_error                IN  CHAR,
  error_code                  OUT NUMBER,
  error_message                OUT VARCHAR2
)
IS
  v_sqlcode                     number;
  v_event_source               varchar2(60) :='Move_Phones_to_Host';
  v_start_date                 DATE;
  v_end_date                   DATE;
  v_epn_old_previous           exchange_port.exchange_port_number%TYPE;
  v_epn_new_previous           exchange_port.exchange_port_number%TYPE;
  v_epn_new                    exchange_port.exchange_port_number%TYPE;
  v_ap_new_previous            sim_card.access_point_id%TYPE;
  v_ap_new                     sim_card.access_point_id%TYPE;
  v_last_port                  exchange_port.exchange_port_number%TYPE;
  v_max                        exchange_port.exchange_port_number%TYPE;
  v_port_exist                 INT :=0;
  v_port_exist_prev            INT;

  CURSOR c_tt IS
    SELECT tt.exchange_port_number_old,
           tt.exchange_port_type_code,
           tt.exchange_port_number_new,
           tt.access_point_id_new
    FROM tt_move_range tt
    ORDER BY tt.exchange_port_type_code,tt.exchange_port_number_old
    FOR update;

BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
  END IF;

  IF p_Phone_Serie_Id IS NULL OR p_New_Host_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;


  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Move_Phone_Serie_To_Host;
  END IF;

  v_start_date:=nvl(p_Start_Date,SYSDATE);
  v_end_date:=v_start_date-rsig_utils.c_INTERVAL_DIFFERENCE;
-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------

  /*UPDATE phone_number_series pns
  SET pns.host_id=p_New_Host_id
  WHERE pns.phone_number_series_id=p_Phone_Serie_Id
    AND pns.host_id<>p_New_Host_id;

  IF SQL%NOTFOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;*/

  DELETE FROM tt_move_range;

  INSERT INTO tt_move_range(network_address_id,
                            access_point_id_old,
                            link_type_code,
                            exchange_port_number_old,
                            exchange_port_type_code)
  SELECT pn.network_address_id,
         ep.access_point_id,
         naap.link_type_code,
         ep.exchange_port_number,
         ep.exchange_port_type_code
  FROM phone_number pn
  JOIN network_address_access_point naap ON naap.network_address_id=pn.network_address_id
  JOIN Exchange_Port ep ON ep.access_point_id=naap.access_point_id
  WHERE pn.phone_number_series_id=p_Phone_Serie_Id
    AND naap.from_date=(SELECT MAX(n.from_date)
                        FROM network_address_access_point n
                        WHERE n.network_address_id=naap.network_address_id
                          AND n.from_date<=v_end_date);

  -- terminate all active links
  UPDATE network_address_access_point naap
     SET naap.to_date=v_end_date
   WHERE (naap.to_date>v_end_date OR naap.to_date IS NULL)
     AND EXISTS(SELECT 1
                FROM tt_move_range tt
                WHERE tt.network_address_id=naap.network_address_id);

  -- get last exchange port number
  SELECT nvl(max(rsig_exchange_port.Get_Number_From_Char(ep.exchange_port_number)),0),
         max(ep.exchange_port_number)
  INTO v_last_port,
       v_max
  FROM exchange_port ep
  WHERE ep.host_id=p_New_Host_id
    AND ep.deleted IS NULL;

  -- lock table exchange_port and network_address_access_point
  lock table exchange_port in SHARE mode;

  IF v_max IS NOT NULL THEN
    lock table network_address_access_point in SHARE mode;
  END IF;

  -- searching and generating exchange ports ----------------------------------------------------------------
  FOR v_row IN c_tt LOOP

    IF(v_row.exchange_port_number_old=v_epn_old_previous)THEN
    -- phone number was on the same port as the previous number
      v_epn_new:=v_epn_new_previous;
      v_ap_new:=v_ap_new_previous;
      v_port_exist:=v_port_exist_prev;
    ELSE
    -- phone number was on the different port the then previous number
      BEGIN
        -- find existing free port of the same type
        IF v_max IS NULL THEN
          RAISE NO_DATA_FOUND;
        ELSE
          SELECT ep.access_point_id,
                 ep.exchange_port_number
          INTO v_ap_new,v_epn_new
          FROM exchange_port ep
          WHERE ep.host_id=p_New_Host_id
            AND ep.exchange_port_type_code=v_row.exchange_port_type_code
            AND ep.deleted IS NULL
            AND NOT EXISTS(SELECT 1
                           FROM network_address_access_point naap
                           WHERE naap.access_point_id=ep.access_point_id
                             AND v_start_date BETWEEN naap.from_date AND nvl(naap.to_date,v_start_date))
            AND NOT EXISTS(SELECT 1
                           FROM tt_move_range tt
                           WHERE tt.access_point_id_new=ep.access_point_id)
            AND rownum=1;
        END IF;

        v_port_exist:=1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
        -- port does not exist yet
          v_epn_new:=v_last_port+1;

          SELECT s_access_point.nextval
          INTO v_ap_new
          FROM dual;

          v_last_port:= v_last_port + 1;
      END;

    END IF;

    UPDATE tt_move_range tt
    SET tt.exchange_port_number_new=v_epn_new,
        tt.access_point_id_new=v_ap_new,
        tt.port_exist=v_port_exist
    WHERE CURRENT OF c_tt;

    v_epn_old_previous:=v_row.exchange_port_number_old;
    v_epn_new_previous:=v_epn_new;
    v_ap_new_previous:=v_ap_new;
    v_port_exist_prev:=v_port_exist;
    v_port_exist:=0;
  END LOOP;  -- end of generating ports ------------------------------------------------------------------

  -- insert new access points
  INSERT INTO access_point(access_point_id)
  SELECT DISTINCT
         tt.access_point_id_new
  FROM tt_move_range tt
  WHERE tt.port_exist<>1;

  -- insert new exchange ports
  INSERT INTO exchange_port
         (host_id,
          access_point_id,
          exchange_port_number,
          exchange_port_type_code,
          user_id_of_change,
          date_of_change)
  SELECT DISTINCT
         p_New_Host_id,
         tt.access_point_id_new,
         tt.exchange_port_number_new,
         tt.exchange_port_type_code,
         p_user_id_of_change,
         p_date_of_change
  FROM tt_move_range tt
  WHERE tt.port_exist<>1;

  -- link phones and ports
  INSERT INTO network_address_access_point
         (access_point_id,
          network_address_id,
          link_type_code,
          from_date,
          date_of_change,
          user_id_of_change)
  SELECT tt.access_point_id_new,
         tt.network_address_id,
         tt.link_type_code,
         v_start_date,
         p_date_of_change,
         p_user_id_of_change
  FROM tt_move_range tt;

-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode := sqlcode;
    error_message := sqlerrm;
--    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Move_Phone_Serie_To_Host2;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
      ELSE NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Move_Phones_to_Host;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Update_Phone_Number_Series
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Update_Phone_Number_Series(
  p_phone_number_series_id      IN  phone_number_series.phone_number_series_id%TYPE,
  p_new_host_id                 IN  host.host_id%TYPE,
  p_new_subhost_id              IN  host.host_id%TYPE,
  p_PHONE_NUMBER_TYPE_CODE      IN  phone_number_series.phone_number_type_code%TYPE,
  p_Start_Date                  IN  DATE,
  p_user_id_of_change           IN  NUMBER,
  p_date_of_change              IN  DATE,
  handle_tran                    IN  CHAR,
  p_raise_error                  IN  CHAR,
  error_code                    OUT NUMBER,
  error_message                  OUT VARCHAR2
)
IS
  v_date date := sysdate;
  v_sqlcode                     number;
  v_event_source                varchar2(60) :='RSIG_PHONE_NUMBER_SERIES.Update_Phone_Number_Series';
  v_old_host_id                 host.host_id%TYPE;
  v_old_subhost_id              host.host_id%TYPE;
  v_old_type                    phone_number_series.phone_number_type_code%TYPE;
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  util_loc_pkg.touch_date(p_date_of_change);

  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_Phone_Number_Series;
  END IF;

-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
  BEGIN
    SELECT pns.host_id,
           pns.subhost_id,
           pns.phone_number_type_code
      INTO v_old_host_id,
           v_old_subhost_id,
           v_old_type
      FROM PHONE_NUMBER_SERIES pns
     WHERE pns.PHONE_NUMBER_SERIES_ID = p_phone_number_series_id;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(Rsig_Utils.c_ORA_Phone_Serie_NOT_Exists,'Phone serie does not exist!');
  END;


    -- change host_id

  IF trim(v_old_type) != trim(p_PHONE_NUMBER_TYPE_CODE) THEN
    Change_Phone_Serie_Type(handle_tran => RSIG_UTILS.Get_Handle_Tran_For_Call_Proc(handle_tran),
                            error_code => error_code,
                            p_phone_number_serie_id => p_phone_number_series_id,
                            p_phone_number_type_code => p_PHONE_NUMBER_TYPE_CODE,
                            p_user_id_of_change => p_user_id_of_change,
                            p_raise_error => rsig_utils.c_YES);
  END IF;

  IF not util_pkg.is_eq_null_vals_number(v_old_host_id, p_new_host_id) THEN
    Change_Phone_Serie_HLR(handle_tran => RSIG_UTILS.Get_Handle_Tran_For_Call_Proc(handle_tran),
                           error_code => error_code,
                           p_phone_number_serie_id => p_phone_number_series_id,
                           p_phone_number_hlr_id => p_new_host_id,
                           p_start_date => p_Start_Date,
                           p_user_id_of_change => p_user_id_of_change,
                           p_raise_error => rsig_utils.c_YES);

  END IF;

  IF not util_pkg.is_eq_null_vals_number(v_old_subhost_id, p_new_subhost_id) THEN
    UPDATE PHONE_NUMBER_SERIES
       SET SUBHOST_ID        = p_new_subhost_id,
           DATE_OF_CHANGE    = v_date,
           USER_ID_OF_CHANGE = p_user_id_of_change
     WHERE PHONE_NUMBER_SERIES_ID = p_phone_number_series_id
    ;
  END IF;

-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode := sqlcode;
    error_message := sqlerrm;
--    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Update_Phone_Number_Series;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
      ELSE NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Update_Phone_Number_Series;

------------------------------------------------------------------------------------------------------------------------------
--  Test_network_operators_type
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Test_network_operators_type(
  p_operator1           IN  network_operator.network_operator_id%TYPE,
  p_operator2           IN  network_operator.network_operator_id%TYPE
)
IS
  v_type1               network_operator.network_operator_code%TYPE;
  v_type2               network_operator.network_operator_code%TYPE;
BEGIN

  IF p_operator1 IS NULL OR p_operator2 IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;


-- start of the procedure body --------------------------------------------------------------------------------------------------
  SELECT no.network_operator_type
  INTO v_type1
  FROM network_operator no
  WHERE no.network_operator_id=p_operator1;

  SELECT no.network_operator_type
  INTO v_type2
  FROM network_operator no
  WHERE no.network_operator_id=p_operator2;


  -- test for type of  operators
  IF (v_type1 IS NULL AND v_type2 IS NOT NULL) OR
     (v_type1 IS NOT NULL AND v_type2 IS NULL) THEN

    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_not_same_operator_type,'Not same type of network operators');
  END IF;
-- end of the procedure body ----------------------------------------------------------------------------------------------------

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_operator_not_exist,'Network operator does not exist');
  WHEN OTHERS THEN
    RAISE;
END Test_network_operators_type;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

END;
/
