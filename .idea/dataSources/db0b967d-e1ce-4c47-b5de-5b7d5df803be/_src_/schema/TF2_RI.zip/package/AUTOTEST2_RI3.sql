CREATE package AUTOTEST2_RI3 is

  -- Author  : PAPONOMAREV
  -- Created : 17.08.2011 15:34:21
  -- Purpose : Обращения к таблицам пользователя RI для поиска тестовых данных

--------------- Наполнение таблицы свободных номеров
procedure fill_autotest2_phones;

procedure fill_phones_attributes_RI(iPHONE_NUMBER varchar2, error out sys_refcursor);

procedure fill_autotest2_sim_ri(istock_id number default null);

procedure fill_sim_attributes_ri(iSIM_NUMBER varchar2);
procedure packlog(itext in varchar2, iTEST_ID number default null);
end AUTOTEST2_RI3;
/
