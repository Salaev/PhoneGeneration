CREATE PACKAGE BODY          "UTIL" is

procedure my_raise(p_num binary_integer, p_msg varchar2, p_keeperrorstack boolean) is
begin
    raise_application_error(p_num, substr(p_msg, 1, 2048), p_keeperrorstack);
end;

function get_vpool(p_vpool_id number, p_lock boolean) return vpool%rowtype is
v_res vpool%rowtype;
v_lock boolean := nvl(p_lock, false);
begin
    if v_lock then
        select /*+ index_asc(z, PK_VPOOL)*/
    * into v_res
    from vpool z
    where 1 = 1
    and vpool_id = p_vpool_id
    for update nowait
        ;
    else
        select /*+ index_asc(z, PK_VPOOL)*/
    * into v_res
    from vpool z
    where 1 = 1
    and vpool_id = p_vpool_id
        ;
    end if;
    return v_res;
exception
when no_data_found then
    return null;
end;

function get_vpool_slot(p_vpool_id number, p_seq_num number, p_lock boolean) return vpool_slot%rowtype is
v_res vpool_slot%rowtype;
v_lock boolean := nvl(p_lock, false);
begin
    if v_lock then
        select /*+ index_asc(z, I_VPOOL_SLOT_VPOOL_ID)*/
    * into v_res
    from vpool_slot z
    where 1 = 1
    and vpool_id = p_vpool_id
    and seq_num = p_seq_num
    for update nowait
        ;
    else
        select /*+ index_asc(z, I_VPOOL_SLOT_VPOOL_ID)*/
    * into v_res
    from vpool_slot z
    where 1 = 1
    and vpool_id = p_vpool_id
    and seq_num = p_seq_num
        ;
    end if;
    return v_res;
exception
when no_data_found then
    return null;
end;

function insert_vpool_slot(p_rec vpool_slot%rowtype) return boolean is
pragma autonomous_transaction;
v_rec vpool_slot%rowtype := p_rec;
begin
    if v_rec.dt is null then
        v_rec.dt := sysdate;
    end if;
    insert into vpool_slot values v_rec;
    commit;
    return true;
exception
when dup_val_on_index then
    rollback;
    return false;
end;

function update_vpool_slot(p_rec vpool_slot%rowtype, p_check boolean, p_from_status number) return boolean is
pragma autonomous_transaction;
v_check boolean := nvl(p_check, false);
v_rec vpool_slot%rowtype;
v_num number;
begin
    v_rec := get_vpool_slot(p_rec.vpool_id, p_rec.seq_num, true);
    if v_rec.vpool_id is null or (v_check and v_rec.status != p_from_status) then
        rollback;
        return false;
    end if;
    update /*+ index_asc(z, I_VPOOL_SLOT_VPOOL_ID)*/
    vpool_slot z
    set
    --row = p_rec
    status = p_rec.status,
    dt = p_rec.dt
    where 1 = 1
    and vpool_id = p_rec.vpool_id
    and seq_num = p_rec.seq_num
    ;
    v_num := sql%rowcount;
    commit;
    if v_num > 0 then
        return true;
    end if;
    return false;
exception
when others then
    rollback;
    return false;
end;

function delete_vpool_slot(p_rec vpool_slot%rowtype, p_check boolean) return boolean is
pragma autonomous_transaction;
v_check boolean := nvl(p_check, false);
v_rec vpool_slot%rowtype;
v_num number;
begin
    v_rec := get_vpool_slot(p_rec.vpool_id, p_rec.seq_num, true);
    if v_rec.vpool_id is null or (v_check and v_rec.status != p_rec.status) then
        rollback;
        return false;
    end if;
    delete /*+ index_asc(z, I_VPOOL_SLOT_VPOOL_ID)*/
    from vpool_slot z
    where 1 = 1
    and vpool_id = p_rec.vpool_id
    and seq_num = p_rec.seq_num
    ;
    v_num := sql%rowcount;
    commit;
    if v_num > 0 then
        return true;
    end if;
    return false;
exception
when others then
    rollback;
    return false;
end;

procedure add_vpool_slots(p_vpool_id number, p_count number, p_status number, p_dt date) is
v_status number := nvl(p_status, g_vps_st_idle);
v_dt date := nvl(p_dt, sysdate);
v_rec vpool_slot%rowtype;
v_bool boolean;
begin
    v_rec.vpool_id := p_vpool_id;
    for v_i in (
    select /*+ ordered use_hash(q, z) full(q) index_asc(z, I_VPOOL_SLOT_VPOOL_ID)*/
    q.rn, z.*
    from (select rownum rn from dual where p_count > 0 connect by level <= p_count) q, vpool_slot z
    where 1 = 1
    and z.seq_num(+) = q.rn
    and z.vpool_id(+) = p_vpool_id
    and z.vpool_id is null
    --order by q.rn
    ) loop
        --!_!v_rec.vpool_id := p_vpool_id;
        v_rec.seq_num := v_i.rn;
        v_rec.status := v_status;
        v_rec.dt := v_dt;
        v_bool := insert_vpool_slot(v_rec);
    end loop;
end;

procedure trunc_vpool_slots(p_vpool_id number, p_count number, p_status number) is
v_status number := nvl(p_status, g_vps_st_idle);
v_rec vpool_slot%rowtype;
v_bool boolean;
begin
    v_rec.vpool_id := p_vpool_id;
    for v_i in (
    select /*+ ordered use_hash(z, q) index_asc(z, I_VPOOL_SLOT_VPOOL_ID) full(q)*/
    q.rn, z.*
    from vpool_slot z, (select rownum rn from dual where p_count > 0 connect by level <= p_count) q
    where 1 = 1
    and z.vpool_id = p_vpool_id
    and q.rn(+) = z.seq_num
    and q.rn is null
    --order by q.rn
    ) loop
        --!_!v_rec.vpool_id := p_vpool_id;
        v_rec.seq_num := v_i.seq_num;
        v_rec.status := v_status;
        --!_!v_rec.dt := ;
        v_bool := delete_vpool_slot(v_rec, true);
    end loop;
end;

procedure refresh_vpool_slots(p_vpool_id number, p_timeout_stale number, p_status_from number, p_status_to number) is
v_date date := sysdate - p_timeout_stale*g_second;
v_status_from number := nvl(p_status_from, g_vps_st_busy);
v_status_to number := nvl(p_status_to, g_vps_st_idle);
v_bool boolean;
begin
    for v_i in (
    select /*+ index_asc(z, I_VPOOL_SLOT_VPOOL_ID_STATUS)*/
    *
    from vpool_slot z
    where 1 = 1
    and vpool_id = p_vpool_id
    and status = v_status_from
    and dt <= v_date
    --order by seq_num
    ) loop
        v_bool := release_vpool_slot(p_vpool_id, v_i.seq_num, v_status_from, v_status_to);
    end loop;
end;

procedure ensure_vpool_slots(p_vpool_id number, p_count number, p_status number, p_dt date) is
v_status number := nvl(p_status, g_vps_st_idle);
v_dt date := nvl(p_dt, sysdate);
begin
    add_vpool_slots(p_vpool_id, p_count, v_status, v_dt);
    trunc_vpool_slots(p_vpool_id, p_count, v_status);
end;

procedure validate_vpool(p_vpool_id number, p_count number, p_timeout_stale number) is
v_count number := p_count;
v_timeout_stale number := p_timeout_stale;
v_rec vpool%rowtype;
begin
    if v_count is null or v_timeout_stale is null then
        v_rec := get_vpool(p_vpool_id);
        if v_rec.vpool_id is null then
            my_raise(xcode_common, g_em_vpool_not_found || p_vpool_id);
        end if;
        if v_count is null then
            v_count := v_rec.slot_count;
        end if;
        if v_timeout_stale is null then
            v_timeout_stale := v_rec.timeout_stale;
        end if;
    end if;
    refresh_vpool_slots(p_vpool_id, v_timeout_stale, g_vps_st_busy, g_vps_st_idle);
    ensure_vpool_slots(p_vpool_id, v_count, g_vps_st_idle, sysdate);
end;

function release_vpool_slot(p_vpool_id number, p_seq_num number, p_status_from number, p_status_to number) return boolean is
v_res boolean;
v_status_from number := nvl(p_status_from, g_vps_st_busy);
v_status_to number := nvl(p_status_to, g_vps_st_idle);
v_rec vpool_slot%rowtype;
begin
    v_rec.vpool_id := p_vpool_id;
    v_rec.seq_num := p_seq_num;
    v_rec.status := v_status_to;
    v_rec.dt := sysdate;
    v_res := update_vpool_slot(v_rec, true, v_status_from);
    return v_res;
end;

function acquire_vpool_slot(p_vpool_id number, p_status_from number, p_status_to number) return number is
v_res number := null;
v_status_from number := nvl(p_status_from, g_vps_st_idle);
v_status_to number := nvl(p_status_to, g_vps_st_busy);
v_rec vpool_slot%rowtype;
v_bool boolean;
begin
    v_rec.vpool_id := p_vpool_id;
    v_rec.status := v_status_to;
    for v_i in (
    select /*+ index_asc(z, I_VPOOL_SLOT_VPOOL_ID_STATUS)*/
    *
    from vpool_slot z
    where 1 = 1
    and vpool_id = p_vpool_id
    and status = v_status_from
    --order by seq_num
    ) loop
        --!_!v_rec.vpool_id := p_vpool_id;
        v_rec.seq_num := v_i.seq_num;
        --!_!v_rec.status := v_status_to;
        v_rec.dt := sysdate;
        v_bool := update_vpool_slot(v_rec, true, v_status_from);
        if v_bool then
           v_res := v_i.seq_num;
           exit;
        end if;
    end loop;
    return v_res;
end;

function loop_acquire_vpool_slot(p_vpool_id number, p_status_from number, p_status_to number) return number is
v_res number := null;
v_status_from number := nvl(p_status_from, g_vps_st_idle);
v_status_to number := nvl(p_status_to, g_vps_st_busy);
v_rec vpool%rowtype;
v_date1 date;
v_date2 date;
begin
    v_date1 := sysdate;
    loop
        v_rec := get_vpool(p_vpool_id);
        if v_rec.vpool_id is null then
            my_raise(xcode_common, g_em_vpool_not_found || p_vpool_id);
        end if;
        if v_rec.break = g_true then
            exit;
        end if;
        validate_vpool(v_rec.vpool_id, v_rec.slot_count, v_rec.timeout_stale);
        v_res := acquire_vpool_slot(v_rec.vpool_id, v_status_from, v_status_to);
        if v_res is not null then
            exit;
        end if;
        v_date2 := sysdate;
        if v_date2 - v_date1 >= v_rec.timeout_acquire*g_second then
            exit;
        end if;
        dbms_lock.sleep(v_rec.timeout_sleep);
    end loop;
    return v_res;
end;

begin
g_unit := $$plsql_unit; --11g--
--9i--g_unit := 'UTIL';
end;
/
