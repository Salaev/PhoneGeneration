CREATE package vp_agroup_data is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'AGROUP_DATA';

  c_not_defined_id               constant integer := -1;

  c_unq_none                     constant integer := 0;
  c_unq_id1                      constant integer := 1;
  c_unq_id2                      constant integer := 2;
  c_unq_id1id2                   constant integer := 4;
  c_unq_dsc                      constant integer := 8;
  c_unq_dsc_ic                   constant integer := 16;

----------------------------------!---------------------------------------------
  type rct_agroup_data is table of agroup_data%rowtype;
  --!_!type rcit_agroup_data is table of agroup_data%rowtype index by pls_integer;

----------------------------------!---------------------------------------------
  function get_count_ct_agroup_data(p_coll ct_agroup_data) return number;
  function get_count_rct_agroup_data(p_coll rct_agroup_data) return number;
  --!_!function get_count_rcit_agroup_data(p_coll rcit_agroup_data) return number;

  procedure resize_ct_agroup_data(p_coll in out nocopy ct_agroup_data, p_size number);
  procedure resize_rct_agroup_data(p_coll in out nocopy rct_agroup_data, p_size number);

  function cast_rct2ct_agroup_data(p_coll rct_agroup_data) return ct_agroup_data;
  function cast_ct2rct_agroup_data(p_coll ct_agroup_data) return rct_agroup_data;

----------------------------------!---------------------------------------------
  function make_ct_agroup_data
  (
    p_main_count number,
    p_agroup_data_id ct_number,
    p_agroup_id ct_number,
    p_id1 ct_number,
    p_id2 ct_number,
    p_date_from ct_date,
    p_date_to ct_date,
    p_user_id ct_number,
    p_change_date ct_date,
    p_dsc ct_varchar,
    p_date1 ct_date,
    p_num3 ct_number,
    p_str2 ct_varchar
  ) return ct_agroup_data;

  function make_ct_agroup_data_lim
  (
    p_main_count number,
    p_accept_nulls boolean,
    p_agroup_data_id ct_number,
    p_agroup_id ct_number,
    p_id1 ct_number,
    p_id2 ct_number,
    p_date_from ct_date,
    p_date_to ct_date,
    p_user_id ct_number,
    p_change_date ct_date,
    p_dsc ct_varchar,
    p_date1 ct_date,
    p_num3 ct_number,
    p_str2 ct_varchar
  ) return ct_agroup_data;

----------------------------------!---------------------------------------------
  function row2type(p_row agroup_data%rowtype) return ot_agroup_data;
  function type2row(p_obj ot_agroup_data) return agroup_data%rowtype;

----------------------------------!---------------------------------------------
  function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return agroup_data%rowtype;
  function get1_lock_wait_i(p_id integer, p_date date, p_wait_sec number, p_is_locked out boolean) return agroup_data%rowtype;

  function get1(p_id integer, p_date date) return agroup_data%rowtype;
  function xget1(p_id integer, p_date date) return agroup_data%rowtype;
  function xlock_get1(p_id integer, p_date date) return agroup_data%rowtype;
  function xlock_wait_get1(p_id integer, p_date date, p_wait_sec number) return agroup_data%rowtype;
  function xlock_xget1(p_id integer, p_date date) return agroup_data%rowtype;
  function xlock_wait_xget1(p_id integer, p_date date, p_wait_sec number) return agroup_data%rowtype;

  function xpget1_id1(p_pid integer, p_id1 number, p_date date) return agroup_data%rowtype;
  function xpget1_id2(p_pid integer, p_id2 number, p_date date) return agroup_data%rowtype;
  function xpget1_id1id2(p_pid integer, p_id1 number, p_id2 number, p_date date) return agroup_data%rowtype;
  function xpget1_dsc_nocase(p_pid integer, p_dsc varchar2, p_date date) return agroup_data%rowtype;
  function xpget1_dsc_case(p_pid integer, p_dsc varchar2, p_date date) return agroup_data%rowtype;
  function xpget1_dsc(p_pid integer, p_dsc varchar2, p_date date, p_ignore_case boolean) return agroup_data%rowtype;
  function xpget1_date1(p_pid integer, p_date1 date, p_date date) return agroup_data%rowtype;

  function pget1_id1(p_pid integer, p_id1 number, p_date date) return agroup_data%rowtype;
  function pget1_id2(p_pid integer, p_id2 number, p_date date) return agroup_data%rowtype;
  function pget1_id1id2(p_pid integer, p_id1 number, p_id2 number, p_date date) return agroup_data%rowtype;
  function pget1_dsc(p_pid integer, p_dsc varchar2, p_date date, p_ignore_case boolean) return agroup_data%rowtype;
  function pget1_date1(p_pid integer, p_date1 date, p_date date) return agroup_data%rowtype;

----------------------------------!---------------------------------------------
  function getN(p_pid number, p_date date) return ct_agroup_data;
  function getN_closed(p_pid number, p_date date, p_closed_on_date date) return ct_agroup_data;
  function getN_all_versions(p_pid number) return ct_agroup_data;

  function xgetN_id_i(p_id ct_number, p_date date, p_xcheck_data boolean := true) return ct_agroup_data;
  function xgetN_id(p_pid number, p_id ct_number, p_date date, p_xcheck_data boolean := true) return ct_agroup_data;
  function xgetN_id1(p_pid number, p_id1 ct_number, p_date date, p_xcheck_data boolean := true) return ct_agroup_data;
  function xgetN_id2(p_pid number, p_id2 ct_number, p_date date, p_xcheck_data boolean := true) return ct_agroup_data;
  function xgetN_id1id2(p_pid number, p_id1 ct_number, p_id2 ct_number, p_date date, p_xcheck_data boolean := true) return ct_agroup_data;
  function xgetN_dsc_nocase(p_pid number, p_dsc ct_varchar, p_date date, p_xcheck_data boolean := true) return ct_agroup_data;
  function xgetN_dsc_case(p_pid number, p_dsc ct_varchar, p_date date, p_xcheck_data boolean := true) return ct_agroup_data;
  function xgetN_dsc(p_pid number, p_dsc ct_varchar, p_date date, p_ignore_case boolean, p_xcheck_data boolean := true) return ct_agroup_data;
  function xgetN_date1(p_pid number, p_date1 ct_date, p_date date, p_xcheck_data boolean := true) return ct_agroup_data;

  function xgetN1_id_i(p_id ct_number, p_date date) return ct_agroup_data;
  function xgetN1_id(p_pid number, p_id ct_number, p_date date) return ct_agroup_data;
  function xgetN1_id1(p_pid number, p_id1 ct_number, p_date date) return ct_agroup_data;
  function xgetN1_id2(p_pid number, p_id2 ct_number, p_date date) return ct_agroup_data;
  function xgetN1_id1id2(p_pid number, p_id1 ct_number, p_id2 ct_number, p_date date) return ct_agroup_data;
  function xgetN1_dsc_nocase(p_pid number, p_dsc ct_varchar, p_date date) return ct_agroup_data;
  function xgetN1_dsc_case(p_pid number, p_dsc ct_varchar, p_date date) return ct_agroup_data;
  function xgetN1_dsc(p_pid number, p_dsc ct_varchar, p_date date, p_ignore_case boolean) return ct_agroup_data;
  function xgetN1_date1(p_pid number, p_date1 ct_date, p_date date) return ct_agroup_data;

  function xgetN2_id_i(p_id number, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data;
  function xgetN2_id(p_pid number, p_id number, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data;
  function xgetN2_id1(p_pid number, p_id1 number, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data;
  function xgetN2_id2(p_pid number, p_id2 number, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data;
  function xgetN2_id1id2(p_pid number, p_id1 number, p_id2 number, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data;
  function xgetN2_dsc_nocase(p_pid number, p_dsc varchar2, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data;
  function xgetN2_dsc_case(p_pid number, p_dsc varchar2, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data;
  function xgetN2_dsc(p_pid number, p_dsc varchar2, p_date date, p_ignore_case boolean, p_xcheck_data boolean := FALSE) return ct_agroup_data;
  function xgetN2_date1(p_pid number, p_date1 date, p_date date, p_xcheck_data boolean := FALSE) return ct_agroup_data;

----------------------------------!---------------------------------------------
  procedure xvalid_i(p_rec agroup_data%rowtype);

  procedure XCheck_Num_As_Mode_Invalid(p_unq_mode integer, p_label varchar2 := null);

----------------------------------!---------------------------------------------
  function find_i_id(p_rec agroup_data%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_pid_id1(p_rec agroup_data%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_pid_id2(p_rec agroup_data%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_pid_id1id2(p_rec agroup_data%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_pid_dsc(p_rec agroup_data%rowtype, p_ignore_case boolean, p_check_only_other_ids boolean) return boolean;

  function find_i(p_rec agroup_data%rowtype, p_unq_mode integer, p_check_only_other_ids boolean) return boolean;
  procedure xunique_i(p_rec agroup_data%rowtype, p_unq_mode integer, p_check_only_other_ids boolean);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec agroup_data%rowtype, p_unq_mode integer);
  procedure close_i(p_rec agroup_data%rowtype);
  procedure delete_i(p_rec agroup_data%rowtype);
  procedure touch_i(p_rec agroup_data%rowtype, p_unq_mode integer);

----------------------------------!---------------------------------------------
  function is_identified(p_rec agroup_data%rowtype) return boolean;

  function is_present_id1(p_pid number, p_id1 number, p_date_from date, p_date_to date) return boolean;
  function is_present_id2(p_pid number, p_id2 number, p_date_from date, p_date_to date) return boolean;
  function is_present_id1id2(p_pid number, p_id1 number, p_id2 number, p_date_from date, p_date_to date) return boolean;
  function is_present_dsc(p_pid number, p_dsc varchar2, p_date_from date, p_date_to date, p_ignore_case boolean) return boolean;

----------------------------------!---------------------------------------------
  function acquire_id return number;

  procedure version_open(p_rec in out nocopy agroup_data%rowtype, p_unq_mode integer);
  procedure version_change(p_rec in out nocopy agroup_data%rowtype, p_unq_mode integer);
  procedure version_touch(p_rec in out nocopy agroup_data%rowtype, p_unq_mode integer);

  procedure version_touch_date1
  (
    p_id integer,
    p_user_id integer,
    p_date1 date,
    p_date date
  );

  procedure version_close
  (
    p_id integer,
    p_user_id integer,
    p_date_from date := null, --!_!for p_hard_delete: p_date_from = v_rec.date_from (p_id = v_rec.table_name_id)
    p_hard_delete boolean := false
  );

----------------------------------!---------------------------------------------
  procedure version_open_N(p_items in out nocopy rct_agroup_data, p_unq_mode number);
  procedure version_open_N2(p_items in out nocopy ct_agroup_data, p_unq_mode number);

  procedure version_touch_N(p_items in out nocopy rct_agroup_data, p_unq_mode number);
  procedure version_touch_N2(p_items in out nocopy ct_agroup_data, p_unq_mode number);

  procedure version_touch_date1_N
  (
    p_ids ct_number,
    p_date1s ct_date,
    p_dates ct_date,
    p_user_id integer
  );

  procedure version_touch_date1_N2
  (
    p_ids ct_number,
    p_date1 date,
    p_date date,
    p_user_id integer
  );

  procedure version_close_N
  (
    p_ids ct_number,
    p_date_froms ct_date,
    p_user_id integer,
    p_hard_delete boolean := false
  );

  procedure version_close_N2
  (
    p_ids ct_number,
    p_date_from date,
    p_user_id integer,
    p_hard_delete boolean := false
  );

----------------------------------!---------------------------------------------

end;
/
