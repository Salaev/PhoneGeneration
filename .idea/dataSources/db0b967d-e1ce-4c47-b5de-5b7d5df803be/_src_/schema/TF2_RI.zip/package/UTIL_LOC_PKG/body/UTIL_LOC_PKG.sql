CREATE package body util_loc_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure log_clob(p_log_clob_type_id number, p_dsc clob)
is
pragma autonomous_transaction;
begin
  ------------------------------
  insert into log_clob(log_clob_id, log_clob_type_id, dt, dsc) values(sq_log_clob.nextval, p_log_clob_type_id, sysdate, p_dsc);
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure touch_number(p_value number)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_varchar(p_value varchar2)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_nvarchar(p_value nvarchar2)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_date(p_value date)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_boolean(p_value boolean)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function wrap_null(p_value varchar2) return varchar2
is
begin
  ------------------------------
  return nvl(p_value, 'null');
  ------------------------------
end;

----------------------------------!---------------------------------------------
function wrap_number(p_value number) return varchar2
is
begin
  ------------------------------
  return wrap_null(util_pkg.number_to_char(p_value));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function wrap_char(p_value varchar2) return varchar2
is
begin
  ------------------------------
  return util_pkg.c_quote || p_value || util_pkg.c_quote;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function wrap_boolean(p_value boolean) return varchar2
is
begin
  ------------------------------
  return wrap_null(util_pkg.bool_to_char(p_value));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
