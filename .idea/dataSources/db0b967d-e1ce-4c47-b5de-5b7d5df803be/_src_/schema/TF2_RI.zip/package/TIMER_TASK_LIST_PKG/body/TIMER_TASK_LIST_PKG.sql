CREATE package body TIMER_TASK_LIST_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_timer_period_val return number
is
begin
  ------------------------------
  return install_pkg.nnget_option_num(c_sett_timer_period_val, c_def_timer_period_val);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure add_task
(
  p_agroup_id number,
  p_task_name varchar2,
  p_period integer,
  p_delay_start boolean,
  p_user_id number
)
is
  v_row agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_agroup_id is null, 'p_agroup_id');
  util_pkg.XCheck_Cond_Missing(p_task_name is null, 'p_task_name');
  util_pkg.XCheck_Cond_Missing(p_period is null, 'p_period');
  util_pkg.XCheck_Cond_Missing(p_delay_start is null, 'p_delay_start');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_row := null;
  ------------------------------
  v_row.agroup_id := p_agroup_id;
  v_row.id1 := p_period;
  v_row.id2 := util_pkg.bool_to_int_2val(p_delay_start);
  v_row.dsc := p_task_name;
  v_row.user_id := p_user_id;
  ------------------------------
  vp_agroup_data.version_open(v_row, vp_agroup_data.c_unq_dsc_ic);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_task
(
  p_agroup_id number,
  p_task_name varchar2,
  p_user_id number
)
is
  v_date date := sysdate;
  v_row agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_agroup_id is null, 'p_agroup_id');
  util_pkg.XCheck_Cond_Missing(p_task_name is null, 'p_task_name');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_row := vp_agroup_data.xpget1_dsc(p_pid => p_agroup_id, p_dsc => p_task_name, p_date => v_date, p_ignore_case => true);
  ------------------------------
  vp_agroup_data.version_close(p_id => v_row.agroup_data_id, p_user_id => p_user_id, p_date_from => v_date, p_hard_delete => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_task_list
(
  p_agroup_id number,
  p_date date,
  p_task_name out ct_varchar,
  p_period out ct_number,
  p_delay_start out ct_number
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_agroup_id is null, 'p_agroup_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select
    id1,
    id2,
    dsc
  bulk collect into
    p_period,
    p_delay_start,
    p_task_name
  from table(vp_agroup_data.getN(p_agroup_id, p_date))
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_task_list2
(
  p_agroup_id number,
  p_task_name out ct_varchar,
  p_period out ct_number,
  p_delay_start out ct_number
)
is
begin
  ------------------------------
  get_task_list
  (
    p_agroup_id => p_agroup_id,
    p_date => sysdate,
    p_task_name => p_task_name,
    p_period => p_period,
    p_delay_start => p_delay_start
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_exist
(
  p_agroup_id number,
  p_task_name varchar2,
  p_date date
) return boolean
is
  v_rec agroup_data%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_agroup_id is null, 'p_agroup_id');
  util_pkg.XCheck_Cond_Missing(p_task_name is null, 'p_task_name');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_rec := vp_agroup_data.pget1_dsc(p_agroup_id, p_task_name, p_date, TRUE);
  ------------------------------
  return (v_rec.agroup_data_id is not null);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_exist2
(
  p_agroup_id number,
  p_task_name varchar2
) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_task_name is null, 'p_task_name');
  ------------------------------
  return is_exist(p_agroup_id, p_task_name, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_task_list_cursor
(
    p_agroup_id number,
    p_timer_tasks out sys_refcursor
)
is
  v_task_name ct_varchar;
  v_period ct_number;
  v_delay_start ct_number;
begin
  ------------------------------
  get_task_list
  (
    p_agroup_id => p_agroup_id,
    p_date => sysdate,
    p_task_name => v_task_name,
    p_period => v_period,
    p_delay_start => v_delay_start
  );
  ------------------------------
  p_timer_tasks := get_result_cursor01
  (
    p_task_name => v_task_name,
    p_period => v_period,
    p_delay_start => v_delay_start
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_result_cursor01
(
    p_task_name ct_varchar,
    p_period ct_number,
    p_delay_start ct_number
) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
      q1.task_name, q2.period, q3.delay_start
    from
      (select column_value task_name, rownum rn from table(p_task_name)) q1,
      (select column_value period, rownum rn from table(p_period)) q2,
      (select column_value delay_start, rownum rn from table(p_delay_start)) q3
    where 1 = 1
    and q2.rn = q1.rn
    and q3.rn = q1.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
