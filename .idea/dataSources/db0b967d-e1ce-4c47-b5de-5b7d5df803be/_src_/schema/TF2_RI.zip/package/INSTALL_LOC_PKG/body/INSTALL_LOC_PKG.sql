CREATE package body install_loc_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure touch_number(p_value number)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_varchar(p_value varchar2)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_date(p_value date)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_boolean(p_value boolean)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_option1(p_option_name varchar2, p_default varchar2) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  select
    db_parameter_value into v_res
    from db_parameters z
    where 1 = 1
    and lower(db_parameter_name) = lower(p_option_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return p_default;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_option2(p_option_name varchar2, p_default varchar2) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  select
    setting_value into v_res
    from ri_settings z
    where 1 = 1
    and lower(setting_name) = lower(p_option_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return p_default;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option1_str(p_option_name varchar2, p_option_value varchar2, p_option_dsc varchar2/*, p_user_id number, p_change_date date*/)
is
  v_option_dsc varchar2(1000) := substr(p_option_dsc, 1, 1000);
begin
  ------------------------------
  insert into db_parameters
  (
    db_parameter_name,
    db_parameter_value,
    description
  )
  values
  (
    p_option_name,
    p_option_value,
    v_option_dsc
  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option1_value_str(p_option_name varchar2, p_option_value varchar2/*, p_user_id number, p_change_date date*/)
is
begin
  ------------------------------
  update
    db_parameters
  set
    db_parameter_value = p_option_value
  where 1 = 1
  and upper(db_parameter_name) = upper(p_option_name)
  ;
  ------------------------------
  if sql%rowcount = 0
  then
    raise no_data_found;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option1_dsc(p_option_name varchar2, p_option_dsc varchar2/*, p_user_id number, p_change_date date*/)
is
  v_option_dsc varchar2(100) := substr(p_option_dsc, 1, 100);
begin
  ------------------------------
  update
    db_parameters
  set
    description = v_option_dsc
  where 1 = 1
  and upper(db_parameter_name) = upper(p_option_name)
  ;
  ------------------------------
  if sql%rowcount = 0
  then
    raise no_data_found;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_option1(p_option_name varchar2/*, p_user_id number, p_change_date date*/)
is
begin
  ------------------------------
  delete
    from db_parameters
  where 1 = 1
  and upper(db_parameter_name) = upper(p_option_name)
  ;
  ------------------------------
  if sql%rowcount = 0
  then
    raise no_data_found;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option2_str(p_option_name varchar2, p_option_value varchar2, p_option_dsc varchar2, p_user_id number, p_change_date date)
is
  v_option_dsc varchar2(255) := substr(p_option_dsc, 1, 255);
begin
  ------------------------------
  insert into ri_settings
  (
    setting_name,
    setting_description,
    setting_value,
    user_id_of_change,
    date_of_change,
    deleted
  )
  values
  (
    p_option_name,
    v_option_dsc,
    p_option_value,
    p_user_id,
    p_change_date,
    null
  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option2_value_str(p_option_name varchar2, p_option_value varchar2, p_user_id number, p_change_date date)
is
begin
  ------------------------------
  update
    ri_settings
  set
    setting_value = p_option_value,
    user_id_of_change = p_user_id,
    date_of_change = p_change_date
  where 1 = 1
  and upper(setting_name) = upper(p_option_name)
  ;
  ------------------------------
  if sql%rowcount = 0
  then
    raise no_data_found;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option2_dsc(p_option_name varchar2, p_option_dsc varchar2, p_user_id number, p_change_date date)
is
  v_option_dsc varchar2(255) := substr(p_option_dsc, 1, 255);
begin
  ------------------------------
  update
    ri_settings
  set
    setting_description = v_option_dsc,
    user_id_of_change = p_user_id,
    date_of_change = p_change_date
  where 1 = 1
  and upper(setting_name) = upper(p_option_name)
  ;
  ------------------------------
  if sql%rowcount = 0
  then
    raise no_data_found;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_option2(p_option_name varchar2, p_user_id number, p_change_date date)
is
begin
  ------------------------------
  touch_number(p_user_id);
  touch_date(p_change_date);
  ------------------------------
  delete
    from ri_settings
  where 1 = 1
  and upper(setting_name) = upper(p_option_name)
  ;
  ------------------------------
  if sql%rowcount = 0
  then
    raise no_data_found;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function check_user(p_user_id number, p_date date := sysdate) return number
is
  v_str varchar2(100);
begin
  ------------------------------
  v_str := get_user_name(p_user_id, p_date);
  ------------------------------
  if v_str is null
  then
    return install_pkg.c_false;
  end if;
  ------------------------------
  return install_pkg.c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_user_name(p_user_name varchar2, p_date date := sysdate) return number
is
  v_num number;
begin
  ------------------------------
  v_num := get_user_id(p_user_name, p_date);
  ------------------------------
  if v_num is null
  then
    return install_pkg.c_false;
  end if;
  ------------------------------
  return install_pkg.c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_user_name2(p_user_name nvarchar2, p_date date := sysdate) return number
is
  v_num number;
begin
  ------------------------------
  v_num := get_user_id2(p_user_name, p_date);
  ------------------------------
  if v_num is null
  then
    return install_pkg.c_false;
  end if;
  ------------------------------
  return install_pkg.c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_name(p_user_id number, p_date date := sysdate) return varchar2
is
  v_res varchar2(100);
  v_date date := nvl(p_date, sysdate);
begin
  ------------------------------
  select /*+ index_asc(z, PK_USERS)*/
    login_name into v_res
    from users z
    where 1 = 1
    and user_id = p_user_id
    and (deleted is null or deleted > v_date)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_name2(p_user_id number, p_date date := sysdate) return nvarchar2
is
  v_res nvarchar2(100);
  v_date date := nvl(p_date, sysdate);
begin
  ------------------------------
  select /*+ index_asc(z, PK_USERS)*/
    to_nchar(login_name) into v_res
    from users z
    where 1 = 1
    and user_id = p_user_id
    and (deleted is null or deleted > v_date)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_id(p_user_name varchar2, p_date date := sysdate) return number
is
  v_res number;
  v_date date := nvl(p_date, sysdate);
begin
  ------------------------------
  select /*+ index_asc(z, I_USERS_LOGIN_NAME)*/
    user_id into v_res
    from users z
    where 1 = 1
    and upper(login_name) = upper(p_user_name)
    and (deleted is null or deleted > v_date)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_id2(p_user_name nvarchar2, p_date date := sysdate) return number
is
  v_res number;
  v_date date := nvl(p_date, sysdate);
begin
  ------------------------------
  select /*+ index_asc(z, I_USERS_LOGIN_NAME)*/
    user_id into v_res
    from users z
    where 1 = 1
    and upper(login_name) = upper(to_char(p_user_name))
    and (deleted is null or deleted > v_date)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
