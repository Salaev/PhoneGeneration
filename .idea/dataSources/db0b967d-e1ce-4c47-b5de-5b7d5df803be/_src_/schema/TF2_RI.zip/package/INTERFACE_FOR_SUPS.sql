CREATE PACKAGE INTERFACE_FOR_SUPS IS

----------------------------------!---------------------------------------------
  c_get_locno_mode_collections   constant number := 1;
  c_get_locno_mode_com_sel1      constant number := 2;
  c_get_locno_mode_com_sel2      constant number := 3;

----------------------------------!---------------------------------------------
  c_opt_get_locno_mode           constant varchar2(100) := 'interface_for_sup.get_location_number_by_bs.get_locno_mode';

----------------------------------!---------------------------------------------
  c_default_get_locno_mode       constant number := c_get_locno_mode_collections;

/****************************************************************************
  Package    INTERFACE_FOR_SUPS contains procedures neccessary for interface
             with SUPS system

  %author            Lucie Sevcikova
  %created           29.12.2003
  %version           1.3.1

  %version_log 
   {*}1.3.11 - 24.10.2011 - Sergey Ermakov 
             procedure Interface_for_SUPS.get_dst_rule_for_root_no created     
   {*}1.3.10 - 11.03.2011 - Victor Smirnov
             Allmost all procedures updated (hinted, marked vsmirnov, related bug 185409)
   {*}1.3.9 - 17.01.2011 - Pavel Vasiliev 
             procedure INTERFACE_FOR_SUPS.Get_Balance_Storage_by_MSISDN updated 
   {*}1.3.8 - 17.11.2010 - Pavel Vasiliev 
             procedure Interface_for_SUPS.Get_Location_Number_by_BS created  
  {*}1.3.8 - 8.11.2010 - Pavel Vasiliev 
             procedure	Interface_for_SUPS.Get_Bal_Storage_By_PA_and_Date updated
             procedure INTERFACE_FOR_SUPS.Get_Location_Number_by_BS created  
   {*}1.3.7 - 21.05.2010 - Sergey Ermakov 
             procedure INTERFACE_FOR_SUPS.Get_DST_Rules_List created   
   {*}1.3.6 - 22.04.2010 - Pavel Vasiliev 
             procedure	INTERFACE_FOR_SUPS.Get_Bal_Storage_By_PA_and_Date updated
             procedure	INTERFACE_FOR_SUPS.Get_Balance_stor_by_one_PA updated
             procedure	INTERFACE_FOR_SUPS.Get_Balance_Storage_by_IMSI updated
             procedure	INTERFACE_FOR_SUPS.Get_Balance_Storage_by_MSISDN updated
             procedure	INTERFACE_FOR_SUPS.Get_Balance_storage_by_PA updated
             procedure	INTERFACE_FOR_SUPS.Get_Home_Network_Operator updated
             procedure	INTERFACE_FOR_SUPS.GET_HOME_NETWORK_OPERATOR updated
             procedure	INTERFACE_FOR_SUPS.Get_IMSI_And_Phone_By_PA updated
             procedure	INTERFACE_FOR_SUPS.Get_IMSI_And_Phone_By_PA_List updated
             procedure	INTERFACE_FOR_SUPS.Get_IMSI_By_PA_And_Phone updated
             procedure	INTERFACE_FOR_SUPS.Get_IMSI_By_PA_And_Phone_List updated
             procedure	INTERFACE_FOR_SUPS.Get_IMSI_By_Phone_list updated
             procedure	INTERFACE_FOR_SUPS.Get_IMSI_By_Phone_list_Ext updated
             procedure	INTERFACE_FOR_SUPS.Get_IMSI_By_Phone_List_Ext_NDC updated
             procedure	INTERFACE_FOR_SUPS.Get_one_PA_exist updated
             procedure	INTERFACE_FOR_SUPS.Get_PA_exist	updated
             procedure	INTERFACE_FOR_SUPS.Get_Phone_By_PA_And_IMSI updated
             procedure	INTERFACE_FOR_SUPS.Get_Phone_By_PA_And_IMSI_List updated
             procedure	INTERFACE_FOR_SUPS.Get_Phones_By_SIM_list_Ext updated
             procedure	INTERFACE_FOR_SUPS.Get_Phones_By_SIM_List_Ext_NDC updated
             procedure	INTERFACE_FOR_SUPS.Get_Phones_By_SIM_List2 updated
             procedure	INTERFACE_FOR_SUPS.Get_SIM_and_Main_Phn_By_Phones updated
  {*}1.3.5 - 11.09.2009 - Pavel Vasiliev
             procedure Get_Phones_By_SIM_list2 updated
             procedure Get_Phone_By_PA_And_IMSI_List updated 
             procedure Get_IMSI_By_PA_And_Phone_List updated
             procedure Get_IMSI_And_Phone_By_PA_List updated
             procedure Get_IMSI_By_Phone_list updated   
             procedure Get_Phones_By_SIM_list_Ext updated
             procedure Get_IMSI_By_Phone_list updated
             procedure Get_Ballance_storage_by_PA updated
             procedure Get_SIM_and_Main_Phn_By_Phones updated  
             procedure Get_Bal_Storage_By_PA_and_Date updated
             procedure Get_Home_Network_Operator updated
             procedure Get_Balance_Storage_by_IMSI updated
             procedure Get_PA_Exist updated
  {*}1.3.4 - 12.08.2009 - Denis Kovalchuk
             procedure Get_one_PA_exist created
             procedure Get_PA_Exist created
             function PA_Exist created
  {*}1.3.3 - 10.10.2008 - Josef Hartman
             procedure Get_Balance_Storage_by_MSISDN updated
             procedure Get_Bal_Storage_By_PA_and_Date  updated
  {*}1.3.2 - 14.9.2008 - Josef Hartman
             procedure Get_Phone_By_PA_And_IMSI_List updated
             procedue Get_IMSI_By_PA_And_Phone_List updated
             procedue Get_IMSI_And_Phone_By_PA_List updated
             procedure Get_IMSI_And_Phone_By_PA updated
  {*}1.3.1 - 05.9.2008 - Josef Hartman
             procedure Get_IMSI_And_Phone_By_PA updated
             procedure Get_Phone_By_PA_And_IMSI updated
             procedure Get_IMSI_By_PA_And_Phone updated
  {*}1.3.0 - 23.7.2008 - Josef Hartman
             procedure Get_Phone_By_PA_And_IMSI updated
             procedure Get_IMSI_By_PA_And_Phone updated
             procedure Get_IMSI_And_Phone_By_PA updated
             procedure Get_Phone_By_PA_And_IMSI_List updated
             procedue Get_IMSI_By_PA_And_Phone_List updated
             procedue Get_IMSI_And_Phone_By_PA_List updated
  {*}1.2.9.1 - 19.4.2007 - Petr Cepek
             procedure Get_Phones_By_SIM_list_Ext updated
             procedure Get_IMSI_By_Phone_list_Ext updated
             procedure Get_SIM_and_Main_Phn_By_Phones updated
             procedure Get_Balance_Storage_by_IMSI updated
             procedue Get_Balance_Storage_by_MSISDN updated
  {*}1.2.9 - 30.1.2007 - Roger stockley
             procedure Get_Balance_storage_by_PA updated
             procedure Get_Balance_stor_by_one_PA updated
  {*}1.2.8 - 15.11.2006 - Roger stockley
             columns from access_point and personal_account
             moved to sim_card.
             procedure Get_Phone_By_PA_And_IMSI updated
             procedure Get_IMSI_By_PA_And_Phone updated
             procedure Get_IMSI_And_Phone_By_PA updated
             procedure Get_Phone_By_PA_And_IMSI_List updated
             procedure Get_IMSI_By_PA_And_Phone_List updated
             procedure Get_IMSI_And_Phone_By_PA_List updated
             procedure Get_Phones_By_SIM_list_Ext updated
             procedure Get_IMSI_By_Phone_list_Ext updated
             procedure Get_Balance_storage_by_PA updated
             procedure Get_SIM_and_Main_Phn_By_Phones updated
             procedure Get_Balance_stor_by_one_PA updated
             procedure Get_Balance_Storage_by_IMSI updated
             procedure Get_Balance_Storage_by_MSISDN updated
  {*}1.2.7 - 11.10.2006 - Petr Cepek
             procedure Get_Phones_By_SIM_list2 updated
  {*}1.2.6 - 22.09.2006 - Petr Cepek
             procedure Exist_Batch_Session_id deleted
             procedure Get_Phones_By_SIM_list deleted
  {*}1.2.5 - 22.09.2006 - Petr Cepek
             procedure Get_Balance_Storage_by_MSISDN created
  {*}1.2.4 - 21.07.2006 - Petr Cepek
             procedure Get_IMSI_By_PA_And_Phone updated
             procedure Get_IMSI_And_Phone_By_PA updated
             procedure Get_Phone_By_PA_And_IMSI updated
             procedure Get_Phone_By_PA_And_IMSI_List updated
             procedure Get_Phones_By_SIM_list2 updated
             procedure Get_IMSI_By_PA_And_Phone_List updated
             procedure Get_IMSI_And_Phone_By_PA_List updated
             procedure Get_IMSI_By_Phone_list updated
             procedure Get_Phones_By_SIM_list_Ext updated
             procedure Get_IMSI_By_Phone_list_Ext updated
             procedure Get_SIM_and_Main_Phn_By_Phones updated
             procedure Get_Home_Network_Operator updated
  {*}1.2.3.2 - 20.07.2006 - Petr Cepek
             procedure Get_Phones_By_SIM_list2 updated
  {*}1.2.3.1 - 17.07.2006 - Petr Cepek
             procedure Get_Balance_Storage_by_IMSI updated
  {*}1.2.3 - 02.05.2006 - Petr Cepek
             procedures Get_Home_Network_Operator and Get_Balance_Storage_by_IMSI created
  {*}1.2.2 - 18.04.2006 - Petr Cepek
             procedure Get_Bal_Storage_By_PA_and_Date updated
  {*}1.2.1 - 29.03.2006 - Petr Cepek
             procedure Get_Balance_storage_by_PA updated
  {*}1.2.0 - 30.01.2005 - Petr Cepek
             procedure Get_Bal_Storage_By_PA_and_Date created
  {*}1.1.0 - 18.04.2006 - Petr Cepek
             procedures Get_Phones_By_SIM_list2, Get_Phone_By_PA_And_IMSI_List,
             Get_IMSI_By_PA_And_Phone_List,Get_IMSI_And_Phone_By_PA_List,
             Get_IMSI_By_Phone_list rewritten with associative arrays
  {*}1.0.12 - 21.09.2005 - Radomir Lipka
             Add procedure Get_Balance_stor_by_one_PA
  {*}1.0.11 - 06.04.2005 - Pavel Stengl
             Get_Phones_By_SIM_list_Ext, Get_IMSI_By_Phone_list_Ext,optimized - HINT added
  {*}1.0.10 - 02.03.2005 - Jaroslav Holub
             Get_Phones_By_SIM_list_Ext, Get_IMSI_By_Phone_list_Ext,
             Get_SIM_and_Main_Phn_By_Phones
                   optimized - changed position of join and added hints
  {*}1.0.9 - 31.01.2004 - Lucie Sevcikova
             added procedure - Get_SIM_and_Main_Phn_By_Phones
             changed all procedures with returning SIM
             cards by phone number (not only main phone number considered)
  {*}1.0.8 - 28.01.2004 - Jaroslav Holub
             optimized procedures
                    - Get_IMSI_By_Phone_list_Ext
                    - Get_Phones_By_SIM_list_Ext
  {*}1.0.7 - 06.12.2004 - Lucie Sevcikova
             Get_Phones_By_SIM_list_Ext, Get_IMSI_By_Phone_list_Ext,optimized - HINT added
             Column HostType was added into result of procedure Get_Balance_storage_by_PA
  {*}1.0.6 - 19.11.2004 - Lucie Sevcikova
             The bug (two columns having the same name with
             unspecifies usage) in the procedures
             Get_Phones_By_SIM_List_Ext and Get_IMSI_By_Phone_list_Ext was fixed
  {*}1.0.5 - 10.11.2004 - Jaroslav Holub
             added - procedure Get_Phones_By_SIM_list2
                   - type T_VAR2_255
  {*}1.0.4 - 25.10.2004 - Jaroslav Holub <br>
             added procedures
                   - Get_Phones_By_SIM_list_Ext
                   - Get_IMSI_By_Phone_list_Ext
                   - Get_Ballance_storage_by_PA
  {*}1.0.3 - 06.09.2004 - Jaroslav Holub
              Get_Phones_By_SIM_list - fix for time
              difference. At beginning at procedure is sysdate
              set to variable and this variable is then used in procedure body
  {*}1.0.2 - 16.8.2004 - Jaroslav Holub
              Get_Phones_By_SIM_list - fix error
                    when in tmp table is NULL -> nvl(...,nvl(..))
  {*}1.0.1 - 02.8.2004 - Jaroslav Holub
             changed for fix problems with time difference on console and server
  {*}1.0.0 - 29.12.2003 - Lucie Sevcikova
             created first version

****************************************************************************/

  -----------------------------------------------------------------------------
  -- constants
  -----------------------------------------------------------------------------

  -----------------------------------------------------------------------------
  -- types
  -----------------------------------------------------------------------------

  TYPE t_IMSI IS TABLE OF VARCHAR2(20) INDEX BY BINARY_INTEGER;
  TYPE t_date IS TABLE OF DATE INDEX BY BINARY_INTEGER;
  TYPE t_PHONE IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
  TYPE t_PA IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;

  TYPE T_VAR2_255 IS TABLE OF VARCHAR2(255) INDEX BY BINARY_INTEGER;
  --  TYPE T_DATE IS TABLE OF DATE INDEX BY BINARY_INTEGER;


/****************************************************************************
  PROCEDURE

  %author           Jaroslav Holub
  %created          10.11.2004
  %version          1.0.3
  %application      Resource Inventory

  %usage            Procedure returns phone numbers in international format
                    valid at date for IMSI given in the table
                    TMP_BATCH_NET_ADDR_ACC_POINT for given batch session.

  %param            p_IMSI_list     IN   t_imsi - list of sim cards
  %param            p_date_list     IN   t_date - list of validity dates

  %expected_error_codes
  {*} 0 - successful completion
  {*} 101 - invalid handle tran parameter value
  {*} 123 - missing mandatory parameter

*/
/* {%skip}
  %version_log
  {*}1.0.3 - 11.10.2006  -  Petr Cepek
             condition for main link type added
  {*}1.0.2 - 21.07.2006 - Petr Cepek
             columns from network_address moved to phone_number
  {*}1.0.1 - 20.07.2006 - Petr Cepek
             hint changed
  {*}1.0.0 - 10.11.2004 - Jaroslav Holub
             created first version

****************************************************************************/
  PROCEDURE Get_Phones_By_SIM_list2(
  p_IMSI_list        IN   t_imsi,
  p_date_list        IN   t_date,
  p_raise_error      IN   CHAR,
  error_code         OUT  NUMBER,
  error_message      OUT  VARCHAR2,
  result_list        OUT  SYS_REFCURSOR
);


/****************************************************************************
  PROCEDURE

  %author           Martin Zabka
  %created          7.1.2004
  %version          1.0.4
  %application      Resource Inventory

  %usage            Procedure returns phone number in international format
                    valid at date for given Personal account and IMSI.

  %param            p_PA                    IN personal account
  %param            p_IMSI                  IN sim card
  %param            p_Date_of_validity      IN validity date

*/
/* {%skip}
  %version_log
  {*}1.0.5 - 05.09.2008 - Josef Hartman
             Select optimalized
  {*}1.0.4 - 23.07.2008 - Josef Hartman
             now using history of PA
  {*}1.0.3 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.0.2 - 03.07.2006 - Petr Cepek
             columns from network_address moved to phone_number
  {*}1.0.1 - 02.08.2004 - Jaroslav Holub
             changed for fix problems with time difference on console and server
  {*}1.0.0 - 07.01.2004 - Martin Zabka
             created first version

****************************************************************************/
  PROCEDURE Get_Phone_By_PA_And_IMSI
  (
    ERROR_CODE         OUT NUMBER,
    p_PA               IN  sim_card.personal_account%TYPE,
    p_IMSI             IN  sim_card.imsi%TYPE,
    p_Date_of_validity IN  DATE,
    p_Phone_number     OUT phone_number.International_Format%TYPE
  );

/****************************************************************************
  PROCEDURE

  %author           Lucie Sevcikova
  %created          29.12.2003
  %version          1.0.4
  %application      Resource Inventory

  %usage            Procedure returns phone number in international format
                    valid at date for given Personal account and IMSI.

*/
/* {%skip}
  %version_log
  {*}1.0.4 - 23.07.2008 - Josef Hartman
             now using history of PA
  {*}1.0.3 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.0.2 - 03.07.2006 - Petr Cepek
             columns from network_address moved to phone_number
  {*}1.0.1 - 02.08.2004 - Jaroslav Holub
             changed for fix problems with time difference on console and server
  {*}1.0.0 - 29.12.2003 - Lucie Sevcikova
             created first version

****************************************************************************/
  PROCEDURE Get_IMSI_By_PA_And_Phone
  (
    ERROR_CODE          OUT NUMBER,
    p_PA                IN  sim_card.personal_account%TYPE,
    p_Phone_number      IN  phone_number.international_format%TYPE,
    p_Date_of_validity  IN  DATE,
    p_IMSI              OUT sim_card.imsi%TYPE
  );

/****************************************************************************
  PROCEDURE

  %author           Lucie Sevcikova
  %created          29.12.2003
  %version          1.0.5
  %application      Resource Inventory

  %usage            Procedure returns phone number in international format
                    valid at date for given Personal account and IMSI.

  %param            p_PA                          IN - personal account
  %param            p_Date_of_validity            IN - validity date

*/
/* {%skip}
  %version_log
  {*}1.0.6 - 05.09.2008 - Josef Hartman
             Hint optimized for cost
  {*}1.0.5 - 05.09.2008 - Josef Hartman
             Select optimized
  {*}1.0.4 - 23.07.2008 - Josef Hartman
             now using history of PA
  {*}1.0.3 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.0.2 - 03.07.2006 - Petr Cepek
             columns from network_address moved to phone_number
  {*}1.0.1 - 02.08.2004 - Jaroslav Holub
             changed for fix problems with time difference on console and server
  {*}1.0.0 - 29.12.2003 - Lucie Sevcikova
             created first version

****************************************************************************/
  PROCEDURE Get_IMSI_And_Phone_By_PA
  (
    ERROR_CODE         OUT NUMBER,
    p_PA               IN  sim_card.personal_account%TYPE,
    p_Date_of_validity IN  DATE,
    result_list        OUT sys_refcursor
  );

/****************************************************************************
  PROCEDURE

  %author           Lucie Sevcikova
  %created          29.12.2003
  %version          1.1.3
  %application      Resource Inventory

  %usage            Procedure returns phone number in international format
                    valid at date for given Personal account and IMSI.

  %param            p_PA                          IN - list of personal accounts
  %param            p_IMSI_list                   IN - list of sim cards
  %param            p_Date_list                   IN - list of validity dates

*/
/* {%skip}
  %version_log
  {*}1.1.4 - 14.09.2008 - Josef Hartman
             Method optimized
  {*}1.1.3 - 23.07.2008 - Josef Hartman
             now using history of PA
  {*}1.1.2 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.1.1 - 03.07.2006 - Petr Cepek
             columns from network_address moved to phone_number
  {*}1.1.0 - 29.09.2005 - Petr Cepek
             procedure rewritten with associative arrays
  {*}1.0.1 - 02.08.2004 - Jaroslav Holub
             changed for fix problems with time difference on console and server
  {*}1.0.0 - 29.12.2003 - Lucie Sevcikova
             created first version

****************************************************************************/
PROCEDURE Get_Phone_By_PA_And_IMSI_List(
  p_PA_list         IN  t_PA,
  p_IMSI_list       IN  t_imsi,
  p_Date_list       IN  t_date,
  p_raise_error   IN  CHAR,
  error_code      OUT NUMBER,
  error_message   OUT VARCHAR2,
  result_list     OUT sys_refcursor
);


/*  PROCEDURE Get_IMSI_By_PA_And_Phone_List
  (
    p_batch_session_id IN TMP_BATCH_NET_ADDR_ACC_POINT.BATCH_SESSION_ID%TYPE,
    ERROR_CODE         OUT NUMBER,
    result_list        OUT sys_refcursor
  );
  */

/****************************************************************************
  PROCEDURE

  %author           Lucie Sevcikova
  %created          29.12.2003
  %version          1.1.3
  %application      Resource Inventory

  %usage            Procedure return IMSI,phone number in international format
                    and personal account by personal account list and phone list
                    for appropriate validity date.

  %param            p_PA_list                     IN - list of personal accounts
  %param            p_PN_list                     IN - list of phone numbers
  %param            p_date_list                   IN - list of validity dates

*/
/* {%skip}
  %version_log
  {*}1.1.4 - 14.09.2008 - Josef Hartman
             Method optimized
  {*}1.1.3 - 23.07.2008 - Josef Hartman
             now using history of PA
  {*}1.1.2 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.1.1 - 03.07.2006 - Petr Cepek
             columns from network_address moved to phone_number
  {*}1.1.0 - 29.09.2005 - Petr Cepek
             procedure rewritten with associative arrays
  {*}1.0.1 - 02.08.2004 - Jaroslav Holub
             changed for fix problems with time difference on console and server
  {*}1.0.0 - 29.12.2003 - Lucie Sevcikova
             created first version

****************************************************************************/
 Procedure Get_IMSI_By_PA_And_Phone_List(
  p_PA_list          IN   t_PA,
  p_PN_list          IN   t_PHONE,
  p_date_list        IN   t_date,
  p_raise_error      IN   CHAR,
  error_code         OUT  NUMBER,
  error_message      OUT  VARCHAR2,
  result_list        OUT  SYS_REFCURSOR
);

/****************************************************************************
  PROCEDURE

  %author           Lucie Sevcikova
  %created          29.12.2003
  %version          1.1.3
  %application      Resource Inventory

  %usage            Procedure return IMSI,phone number in international format
                    and personal account by personal account list
                    for appropriate validity date.

  %param            p_PA_list                     IN - list of personal accounts
  %param            p_date_list                   IN - list of validity dates

*/
/* {%skip}
  %version_log
  {*}1.1.4 - 14.09.2008 - Josef Hartman
             Method optimized
  {*}1.1.3 - 23.07.2008 - Josef Hartman
             now using history of PA
  {*}1.1.2 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.1.1 - 03.07.2006 - Petr Cepek
             columns from network_address moved to phone_number
  {*}1.1.0 - 29.09.2005 - Petr Cepek
             procedure rewritten with associative arrays
  {*}1.0.1 - 02.08.2004 - Jaroslav Holub
             changed for fix problems with time difference on console and server
  {*}1.0.0 - 29.12.2003 - Lucie Sevcikova
             created first version

****************************************************************************/
PROCEDURE Get_IMSI_And_Phone_By_PA_List(
  p_PA_list          IN   t_PA,
  p_date_list        IN   t_date,
  p_raise_error      IN   CHAR,
  error_code         OUT  NUMBER,
  error_message      OUT  VARCHAR2,
  result_list        OUT  SYS_REFCURSOR
);


/*  PROCEDURE Get_IMSI_By_Phone_list
  (
    p_batch_session_id IN TMP_BATCH_NET_ADDR_ACC_POINT.BATCH_SESSION_ID%TYPE,
    result_list        OUT sys_refcursor,
    ERROR_CODE         OUT NUMBER
  );*/

/****************************************************************************
  PROCEDURE

  %author           Jaroslav Holub
  %created          29.12.2003
  %version          1.0.3
  %application      Resource Inventory

  %usage            Procedure returns IMSI number of the SIM card
                    valid at date for phone number given in the table
                    TMP_BATCH_NET_ADDR_ACC_POINT for given batch session.

  %param            p_PN_list                     IN - list of phone numbers
  %param            p_date_list                   IN - list of validity dates

*/
/* {%skip}
  %version_log
  {*}1.0.3 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.0.2 - 19.02.2004 - Jaroslav Holub
             change for international format
  {*}1.0.1 - 18.2.2004 - Lucie Sevcikova
             optimized
  {*}1.0.0 - 29.12.2003 - Jaroslav Holub
             created first version

****************************************************************************/
PROCEDURE Get_IMSI_By_Phone_list(
  p_PN_list          IN   t_PHONE,
  p_date_list        IN   t_date,
  p_raise_error      IN   CHAR,
  error_code         OUT  NUMBER,
  error_message      OUT  VARCHAR2,
  result_list        OUT  SYS_REFCURSOR
);


/****************************************************************************
  PROCEDURE

  %author           Lucie Sevcikova
  %created          29.12.2003
  %version          1.0.5
  %application      Resource Inventory

  %usage            Procedure returns IMSI valid at date
                    for given phone numbers in international
                    format in the input params


  %param            p_SIM_list                    IN - list of sim cards
  %param            p_date_list                   IN - list of validity dates

*/
/* {%skip}
  %version_log
  {*}1.0.5.1 - 19.04.2007 - Petr Cepek
             balance storage is taken from personal_account_history
  {*}1.0.5 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.0.4 - 03.07.2006 - Petr Cepek
             columns from network_address moved to phone_number,
             UNION replaced by UNION ALL
  {*}1.0.3 - 06.04.2005 - Pavel Stengl
             optimized - HINT added
  {*}1.0.2 - 02.03.2005 - Jaroslav Holub
             optimized - changed position of join
  {*}1.0.1 - 18.2.2004 - Jaroslav Holub
             optimized
  {*}1.0.0 - 29.12.2003 - Lucie Sevcikova
             created first version

****************************************************************************/
  PROCEDURE Get_Phones_By_SIM_list_Ext
  (
    p_SIM_list  IN t_IMSI,
    p_date_list IN t_date,
    result_list OUT sys_refcursor,
    ERROR_CODE  OUT NUMBER
  );

/****************************************************************************
  PROCEDURE

  %author           Jaroslav Holub
  %created          29.12.2003
  %version          1.0.5
  %application      Resource Inventory

  %usage            Procedure returns IMSI
                    valid at date  for given phone numbers in
                    international format in the input params

  %param            p_Phone_list                  IN - list of phone numbers
  %param            p_date_list                   IN - list of validity dates


*/
/* {%skip}
  %version_log
  {*}1.0.5.1 - 19.04.2007 - Petr Cepek
             balance storage is taken from personal_account_history
  {*}1.0.5 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.0.4 - 03.07.2006 - Petr Cepek
             columns from network_address moved to phone_number,
             UNION replaced by UNION ALL
  {*}1.0.3 - 06.04.2005 - Pavel Stengl
             optimized - HINT added
  {*}1.0.2 - 02.03.2005 - Jaroslav Holub
             optimized - changed position of join
  {*}1.0.1 - 28.01.2004 - Jaroslav Holub
             optimized
  {*}1.0.0 - 29.12.2003 - Jaroslav Holub
             created first version

****************************************************************************/
  PROCEDURE Get_IMSI_By_Phone_list_Ext
  (
    p_Phone_list IN t_PHONE,
    p_date_list  IN t_date,
    result_list  OUT sys_refcursor,
    ERROR_CODE   OUT NUMBER
  );

/****************************************************************************
  PROCEDURE

  %author           Jaroslav Holub
  %created          25.10.2003
  %version          1.0.4
  %application      Resource Inventory

  %usage            Procedure returns balance hold point for PA

  %param            p_PA_list                  IN - list of personal accounts


*/
/* {%skip}
  %version_log
  {*}1.0.4 - 30.1.2007 - Roger Stockley
             procedure now uses table personal_account_history instead of sim_card
  {*}1.0.3 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.0.2 - 29.03.2006 - Petr Cepek
             hint for using index PK_PERSONAL_ACCOUNT added
  {*}1.0.1 - 06.12.2004 - Lucie Sevcikova
             Column HostType was added into result
             of procedure Get_Balance_storage_by_PA.
  {*}1.0.0 - 25.10.2003 - Jaroslav Holub
             created first version

****************************************************************************/
  PROCEDURE Get_Balance_storage_by_PA
  (
    p_PA_list   IN t_PA,
    result_list OUT sys_refcursor,
    ERROR_CODE  OUT NUMBER
  );

/****************************************************************************
  PROCEDURE

  %author           Lucie Sevcikova
  %created          31.11.2005
  %version          1.0.2
  %application      Resource Inventory

  %usage            Procedure returns IMSI, main phone number....
                    valid at date  for given phone numbers in international format
                    in the input params

  %param            p_Phone_list                  IN - list of phone numbers
  %param            p_date_list                   IN - list of validity dates


*/
/* {%skip}
  %version_log
  {*}1.0.2.1 - 19.04.2007 - Petr Cepek
             balance storage is taken from personal_account_history
  {*}1.0.2 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.0.1 - 03.07.2006 - Petr Cepek
             columns from network_address moved to phone_number
  {*}1.0.0 - 31.11.2005 - Lucie Sevcikova
             created first version

****************************************************************************/
  PROCEDURE Get_SIM_and_Main_Phn_By_Phones
  (
    p_phone_list IN t_PHONE,
    p_date_list  IN t_date,
    result_list  OUT sys_refcursor,
    ERROR_CODE   OUT NUMBER
  );

/****************************************************************************
  PROCEDURE

  %author           Radomir Lipka
  %created          21.9.2005
  %version          1.0.2
  %application      Resource Inventory

  %usage            Procedure returns balance hold point for PA

  %param            p_personal_account                  IN - personal account

  %expected_error_codes
  {*} 0 - successful completion
  {*} 101 - invalid handle tran parameter value
  {*} 123 - missing mandatory parameter

*/
/* {%skip}
  %version_log
  {*}1.0.2 - 30.1.2007 - Roger Stockley
             procedure now uses table personal_account_history instead od sim_card
  {*}1.0.1 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.0.0 - 21.9.2005 - Radomir Lipka
             created first version

****************************************************************************/
  PROCEDURE Get_Balance_stor_by_one_PA
  (
    p_personal_account IN sim_card.PERSONAL_ACCOUNT%TYPE,
    result_list OUT sys_refcursor,
    ERROR_CODE  OUT NUMBER
  );

/****************************************************************************
  PROCEDURE

  %author           Petr Cepek
  %created          30.1.2006
  %version          1.2.0
  %application      Resource Inventory

  %usage            Procedure returns host_id for PA and date

  %param            p_personal_account                  IN - personal account
  %param            p_Date_of_validity                  IN - validity date

  %expected_error_codes
  {*} 0 - successful completion
  {*} 101 - invalid handle tran parameter value
  {*} 123 - missing mandatory parameter

*/
/* {%skip}
  %version_log
  {*}1.2.0 - 10.10.2008 - Josef Hartman
             Added host_id to output
  {*}1.1.0 - 30.1.2006 - Petr Cepek
             hint added
  {*}1.0.0 - 30.1.2006 - Petr Cepek
             created first version

****************************************************************************/
PROCEDURE Get_Bal_Storage_By_PA_and_Date(
  p_PA_list                IN  t_PA,
  p_validity_date          IN  t_date,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

/****************************************************************************
  PROCEDURE

  %author           Petr Cepek
  %created          26.4.2006
  %version          1.0.1
  %application      Resource Inventory

  %usage            Procedure returns network operator ID for given
                    list of phone numbers and validity date.

  %param            p_personal_account                  IN - list of phone numbers
  %param            p_Date_of_validity                  IN - list of validity dates

*/
/* {%skip}
  %version_log
  {*}1.0.1 - 03.07.2006 - Petr Cepek
             columns from network_address moved to phone_number
  {*}1.0.0 - 26.4.2006 - Petr Cepek
             created first version

****************************************************************************/

PROCEDURE Get_Home_Network_Operator(
  p_phone_list             IN  t_PHONE,
  p_validity_date          IN  t_date,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

/****************************************************************************
  PROCEDURE

  %author           Petr Cepek
  %created          26.4.2006
  %version          1.1.1
  %application      Resource Inventory

  %usage            Procedure returns balance storage for
                    given list of IMSI.

  %param            p_personal_account                  IN - list of sim cards

  %expected_error_codes
  {*} 0 - successful completion
  {*} 101 - invalid handle tran parameter value
  {*} 123 - missing mandatory parameter

*/
/* {%skip}
  %version_log
  {*}1.1.1.1 - 19.04.2007 - Petr Cepek
             balance storage is taken from personal_account_history
  {*}1.1.1 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.1.0 - 17.07.2006 - Petr Cepek
             hints changed
  {*}1.0.0 - 26.4.2006 - Petr Cepek
             created first version

****************************************************************************/
PROCEDURE Get_Balance_Storage_by_IMSI(
  p_IMSI_list              IN  t_IMSI,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

/****************************************************************************
  PROCEDURE

  %author           Petr Cepek
  %created          26.4.2006
  %version          1.0.2
  %application      Resource Inventory

  %usage            Procedure returns personal account and its
                    balance storage for given MSISDN.

  %param            p_personal_account                  IN - phone number

  %expected_error_codes
  {*} 0 - successful completion
  {*} 101 - invalid handle tran parameter value
  {*} 123 - missing mandatory parameter

*/
/* {%skip}
  %version_log
  {*}1.0.2 - 10.10.2008 - Added host_id as output parameter
             balance storage is taken from personal_account_history
  {*}1.0.1.1 - 19.04.2007 - Petr Cepek
             balance storage is taken from personal_account_history
  {*}1.0.1 - 14.11.2006 - Roger Stockley
             columns from access_point, personal_account moved to sim_card
  {*}1.0.0 - 26.4.2006 - Petr Cepek
             created first version

****************************************************************************/
PROCEDURE Get_Balance_Storage_by_MSISDN(
  p_MSISDN                   IN  phone_number.international_format%TYPE,
  p_personal_account         OUT sim_card.personal_account%TYPE,
  p_balance_storage_type     OUT host.host_type_code%TYPE,
  p_balance_storage_address  OUT host.host_address%TYPE,
  p_host_id                  OUT host.host_id%TYPE,
  p_error_code                 OUT NUMBER,
  p_error_message              OUT VARCHAR2
);

/****************************************************************************
  PROCEDURE

  %author           Denis Kovalchuk
  %created          12.08.2009
  %version          1.0.0
  %application      Resource Inventory

  %usage            Procedure returns whether PA exist in history of PA<->BalanceStorage

  %param            p_personal_account                  IN - personal account

  %expected_error_codes
  {*} 0 - successful completion
  {*} 101 - invalid handle tran parameter value
  {*} 123 - missing mandatory parameter

*/
/* {%skip}
  %version_log
  {*}1.0.0 - 12.08.2009 - Denis Kovalchuk
             created first version

****************************************************************************/
  PROCEDURE Get_one_PA_exist
  (
    p_personal_account IN sim_card.PERSONAL_ACCOUNT%TYPE,
    result_list OUT sys_refcursor,
    ERROR_CODE  OUT NUMBER
  );

/****************************************************************************
  PROCEDURE

  %author           Denis Kovalchuk
  %created          12.08.2009
  %version          1.0.0
  %application      Resource Inventory

  %usage            Procedure returns whether PA exist in history of PA<->BalanceStorage

  %param            p_PA_list                  IN - list of personal accounts


*/
/* {%skip}
  %version_log
  {*}1.0.0 - 12.08.2009 - Denis Kovalchuk
             created first version

****************************************************************************/
  PROCEDURE Get_PA_Exist
  (
    p_PA_list   IN t_PA,
    result_list OUT sys_refcursor,
    ERROR_CODE  OUT NUMBER
  );

/****************************************************************************
  FUNCTION

  %author           Denis Kovalchuk
  %created          12.08.2009
  %version          1.0.0
  %application      Resource Inventory

  %usage            Function returns whether PA exist in history of PA<->BalanceStorage

  %param            p_PA                  IN - list of personal accounts


*/
/* {%skip}
  %version_log
  {*}1.0.0 - 12.08.2009 - Denis Kovalchuk
             created first version

****************************************************************************/
  FUNCTION PA_Exist
  (
    p_PA IN personal_account_history.personal_account%TYPE
  )RETURN INT;

/****************************************************************************
  PROCEDURE

  %author           Sergey Ermakov
  %created          21.05.2010
  %version          1.0.0
  %application      Resource Inventory

  %usage            Procedure returns list of daylight saving time rules

*/
/* {%skip}
  %version_log
  {*}1.0.0 - 21.05.2010 - Segey Ermakov
             created first version

****************************************************************************/
PROCEDURE Get_DST_Rules_List(
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function cast_cit2t_bsc_lac_msc_obj_tab
  (
    p_msc util_pkg.cit_varchar_s,
    p_location_area_code util_pkg.cit_varchar_s,
    p_base_station_code util_pkg.cit_varchar_s
  ) return t_bsc_lac_msc_obj_tab;

  procedure add_t_bsc_lac_msc_obj_tab_val(p_coll in out nocopy t_bsc_lac_msc_obj_tab, p_val t_bsc_lac_msc_obj);
  function get_count_t_bsc_lac_msc(p_coll t_bsc_lac_msc_obj_tab) return number;

  function get_host4hlb0(p_hlb t_bsc_lac_msc_obj_tab, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_host4hlb(p_hlb t_bsc_lac_msc_obj_tab, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_host4hlb2(p_hlb t_bsc_lac_msc_obj, p_date date) return number;

  function get_location_area4hlb_par0(p_hlb t_bsc_lac_msc_obj_tab, p_parent_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_location_area4hlb_par(p_hlb t_bsc_lac_msc_obj_tab, p_parent_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_location_area4hlb_par2(p_hlb t_bsc_lac_msc_obj, p_parent_id number, p_date date) return number;

  function get_base_station4hlb_par0(p_hlb t_bsc_lac_msc_obj_tab, p_parent_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_base_station4hlb_par(p_hlb t_bsc_lac_msc_obj_tab, p_parent_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_base_station4hlb_par2(p_hlb t_bsc_lac_msc_obj, p_parent_id number, p_date date) return number;

  function get_locno4bs0(p_base_station_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_locno4bs(p_base_station_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_locno4bs2(p_base_station_id number, p_date date) return varchar2;

  procedure get_location_number_by_bs_ii
  (
    p_bsc_lac_msc_tab t_bsc_lac_msc_obj_tab,
    p_loc_no out ct_varchar_s,
    p_rn out ct_number
  );

  function get_location_number_by_bs_i1(p_bsc_lac_msc_tab t_bsc_lac_msc_obj_tab) return ct_varchar_s;

  function get_location_number_by_bs_i2(p_bsc_lac_msc_tab t_bsc_lac_msc_obj_tab) return ct_varchar_s;

  procedure get_location_number_by_bs_i3
  (
    p_bsc_lac_msc_tab t_bsc_lac_msc_obj_tab,
    p_result out sys_refcursor
  );

  procedure get_location_number_by_bs
  (
    p_msc util_pkg.cit_varchar_s,
    p_location_area_code util_pkg.cit_varchar_s,
    p_base_station_code util_pkg.cit_varchar_s,
    p_raise_error char,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  ) ;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

 /****************************************************************************
  PROCEDURE get_dst_rule_for_root_no 

  %author            Sergey Ermakov
  %created           24.10.2011
  %version           1.0.0
  %application       Resource Inventory - Server

  %usage             Get daylight saving time (DTS) rule for root network operator

  %param             p_error_code    OUT  NUMBER - error code
  %param             p_error_message OUT  VARCHAR2 - error message

  %expected_error_codes
  0 - successful completion
*/
/* {%skip}

  %version_log

****************************************************************************/ 
PROCEDURE get_dst_rule_for_root_no(
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
);

END;
/
