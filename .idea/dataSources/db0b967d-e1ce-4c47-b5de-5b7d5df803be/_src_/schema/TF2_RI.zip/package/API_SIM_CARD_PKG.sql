CREATE package API_SIM_CARD_PKG is

----------------------------------!---------------------------------------------
  procedure import_sim_card_2
  (
    p_sim_list util_pkg.cit_varchar_s,
    p_sn_list util_pkg.cit_varchar_s,
    p_pin_list util_pkg.cit_varchar_s,
    p_pin2_list util_pkg.cit_varchar_s,
    p_puk_list util_pkg.cit_varchar_s,
    p_puk2_list util_pkg.cit_varchar_s,
    p_ki_list util_pkg.cit_nvarchar_s,
    p_adm1_list util_pkg.cit_nvarchar_s,
    p_access_control_list util_pkg.cit_nvarchar_s,
    p_authent_type_list util_pkg.cit_varchar_s,
    p_main_imsi_index util_pkg.cit_number,
    p_addition_imsi util_pkg.cit_varchar_s,
    p_user_id_of_change number,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure get_result_cursor01
  (
    p_imsi ct_varchar_s,
    p_result out sys_refcursor,
    p_error_code ct_number,
    p_error_message ct_varchar
  );

----------------------------------!---------------------------------------------

end;
/
