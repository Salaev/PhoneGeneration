CREATE package roaming_cache_pkg is

----------------------------------!---------------------------------------------
  c_agroup_id_roam_cache_list    constant number := 1105;

  c_agroup_name_roam_cache_list  constant nvarchar2(255) := 'ROAMING_CACHE_LIST';

----------------------------------!---------------------------------------------
  c_agroup_name_subs_gen_prefix  constant nvarchar2(255) := 'SUBSCR_GEN_GR_!12345!_';

----------------------------------!---------------------------------------------
  procedure get_roaming_cache_i
  (
    p_range_date_from date,
    p_range_date_to date,
    p_host_nos out sys_refcursor,
    p_roaming_types out sys_refcursor,
    p_phone_series out sys_refcursor,
    p_mcc_mnc_nos out sys_refcursor,
    p_goers out sys_refcursor,
    p_comers out sys_refcursor
  );

  procedure get_roaming_cache_changes_i
  (
    p_cache_guid varchar2,
    p_range_date_from date,
    p_range_date_to date,
    p_date date,
    p_user_id number,
    p_goers out sys_refcursor,
    p_comers out sys_refcursor
  );

  procedure reg_roam_cache_subscr_i
  (
    p_cache_guid varchar2,
    p_date date,
    p_user_id number
  );

  procedure unreg_roam_cache_subscr_i
  (
    p_cache_guid varchar2,
    p_date date,
    p_user_id number
  );

  function get_cache_groups_i(p_date date) return ct_number;

  function get_cache_groups2_i return ct_number;

----------------------------------!---------------------------------------------
  procedure get_roaming_cache
  (
    p_cache_guid varchar2,
    p_range_date_from date,
    p_range_date_to date,
    p_HostNOs out sys_refcursor,
    p_RoamingTypes out sys_refcursor,
    p_phones out sys_refcursor,
    p_MCCMNCNOs out sys_refcursor,
    p_gone_subscribers out sys_refcursor,
    p_come_in_subscribers out sys_refcursor
  );

  procedure at_reg_roam_cache_subscr
  (
    p_cache_guid varchar2,
    p_user_id number
  );

  procedure at_unreg_roam_cache_subscr
  (
    p_cache_guid varchar2,
    p_user_id number
  );

  procedure at_remove_roam_cache_subscr
  (
    p_cache_guid varchar2,
    p_date_from date,
    p_user_id number
  );

  procedure add_ported_phones2group
  (
    p_group_id number,
    p_id1 ct_number,
    p_id2 ct_number,
    p_date date,
    p_user_id number
  );

  procedure add_ported_phones
  (
    p_na_id ct_number,
    p_potype ct_number,
    p_user_id number,
    p_date date
  );

  procedure add_ported_phones2
  (
    p_na_id number,
    p_potype number,
    p_user_id number,
    p_date date
  );

  procedure get_cache_activity_date
  (
    p_date date,
    p_dsc out ct_varchar,
    p_date1 out ct_date
  );

  procedure get_expired_cache
  (
    p_date date,
    p_delay_date date,
    p_dsc out ct_varchar,
    p_date_to out ct_date
  );

----------------------------------!---------------------------------------------

end;
/
