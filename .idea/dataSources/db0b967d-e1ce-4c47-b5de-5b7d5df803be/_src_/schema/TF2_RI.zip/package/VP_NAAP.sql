CREATE package VP_NAAP is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'NETWORK_ADDRESS_ACCESS_POINT';

  type rct_this is table of network_address_access_point%rowtype;

----------------------------------!---------------------------------------------
  function get_count_rct_this(p_coll rct_this) return number;

  procedure resize_rct_this(p_coll in out nocopy rct_this, p_size number);

----------------------------------!---------------------------------------------
  function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return network_address_access_point%rowtype;

  function get1(p_id integer, p_date date) return network_address_access_point%rowtype;
  function xget1(p_id integer, p_date date) return network_address_access_point%rowtype;
  function xlock_get1(p_id integer, p_date date) return network_address_access_point%rowtype;
  function xlock_xget1(p_id integer, p_date date) return network_address_access_point%rowtype;
  procedure xlock(p_id integer, p_date date);

----------------------------------!---------------------------------------------
  function getN_i(p_id_weak number, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return rct_this;
  function getN(p_id_weak number, p_date date) return rct_this;
  function xlock_getN(p_id_weak number, p_date date) return rct_this;

----------------------------------!---------------------------------------------
  procedure xvalid_i(p_rec network_address_access_point%rowtype);

----------------------------------!---------------------------------------------
  function find_i_id(p_rec network_address_access_point%rowtype) return boolean;
  function find_i_spec01(p_rec network_address_access_point%rowtype) return boolean;

  function find_i(p_rec network_address_access_point%rowtype) return boolean;
  procedure xunique(p_rec network_address_access_point%rowtype);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec network_address_access_point%rowtype);
  procedure close_i(p_rec network_address_access_point%rowtype);

----------------------------------!---------------------------------------------
  function is_identified(p_rec network_address_access_point%rowtype) return boolean;

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy network_address_access_point%rowtype);
  procedure version_change(p_rec in out nocopy network_address_access_point%rowtype);

  procedure version_close
  (
    p_id integer,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------
  procedure version_open2
  (
    p_na_id number,
    p_ap_id number,
    p_link_type_code varchar2,
    p_date date,
    p_user_id number,
    p_silent_proper_state boolean,
    p_explicit_intention boolean
  );

  procedure version_close2
  (
    p_na_id number,
    p_date date,
    p_user_id number,
    p_silent_proper_state boolean
  );

----------------------------------!---------------------------------------------

end;
/
