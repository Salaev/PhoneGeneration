CREATE package body VP_BATCH_DETAILS is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get1_i(p_batch_id integer, p_object_id integer, p_lock boolean, p_wait boolean, p_is_locked out boolean) return batch_details%rowtype
is
  v_res batch_details%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_object_id is null, 'p_object_id');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, I_BATCH_DETAILS_BATCH_ID)*/
        * into v_res
        from batch_details z
        where 1 = 1
        and batch_id = p_batch_id
        and object_id = p_object_id
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, I_BATCH_DETAILS_BATCH_ID)*/
        * into v_res
        from batch_details z
        where 1 = 1
        and batch_id = p_batch_id
        and object_id = p_object_id
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, I_BATCH_DETAILS_BATCH_ID)*/
      * into v_res
      from batch_details z
      where 1 = 1
      and batch_id = p_batch_id
      and object_id = p_object_id
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1(p_batch_id integer, p_object_id integer) return batch_details%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get1_i(p_batch_id, p_object_id, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get1(p_batch_id integer, p_object_id integer) return batch_details%rowtype
is
  v_res batch_details%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_i(p_batch_id, p_object_id, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function find_i_id2(p_rec batch_details%rowtype) return boolean
is
  v_cnt number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.batch_id is null, 'p_rec.batch_id');
  util_pkg.XCheck_Cond_Missing(p_rec.object_id is null, 'p_rec.object_id');
  ------------------------------
select /*+ index_asc(z, I_BATCH_DETAILS_BATCH_ID)*/
  count(1) cnt into v_cnt
  from batch_details z
  where 1 = 1
  and batch_id = p_rec.batch_id
  and object_id = p_rec.object_id
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  --!_!and (v_check_only_other_ids = util_pkg.c_false or batch_id != p_rec.batch_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i(p_rec batch_details%rowtype) return boolean
is
begin
  ------------------------------
  if find_i_id2(p_rec)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xunique_i(p_rec batch_details%rowtype)
is
begin
  ------------------------------
  if find_i_id2(p_rec)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_ID2(p_rec.batch_id, p_rec.object_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_i(p_rec batch_details%rowtype)
is
begin
  ------------------------------
  xunique_i(p_rec);
  ------------------------------
  insert into batch_details
  values p_rec;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure close_i(p_rec batch_details%rowtype)
is
  v_cnt number;
begin
  ------------------------------
delete /*+ index_asc(z, I_BATCH_DETAILS_BATCH_ID)*/ from
  batch_details z
  where 1 = 1
  and batch_id = p_rec.batch_id
  and object_id = p_rec.object_id
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotFound_ID2(p_rec.batch_id, p_rec.object_id, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_ID2(p_rec.batch_id, p_rec.object_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open(p_rec in out nocopy batch_details%rowtype)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close
(
    p_batch_id integer,
    p_object_id integer
)
is
  v_sp_name varchar2(30);
  v_rec batch_details%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_batch_id is null, 'p_batch_id');
  util_pkg.XCheck_Cond_Missing(p_object_id is null, 'p_object_id');
  ------------------------------
  v_rec := xlock_get1(p_batch_id, p_object_id);
  ------------------------------
  if v_rec.batch_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotFound_ID2(p_batch_id, p_object_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  --!_! v_rec.user_id_of_change := p_user_id;
  ------------------------------
  close_i(v_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
