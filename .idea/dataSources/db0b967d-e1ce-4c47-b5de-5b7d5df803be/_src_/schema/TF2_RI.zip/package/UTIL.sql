CREATE PACKAGE          "UTIL" is

g_unit varchar2(30);

g_false constant number := 0;
g_true constant number := 1;

g_min_date constant date := to_date('01.01.0001', 'dd.mm.yyyy');
g_max_date constant date := to_date('01.01.4000', 'dd.mm.yyyy');

g_second constant number := 1/24/60/60;

xcode_common constant number := -20000;
x_common exception;
pragma exception_init(x_common, -20000);

--x_locked exception;
--pragma exception_init(x_locked, -54);

--vpool_slot.status
g_vps_st_idle constant number := 0;
g_vps_st_busy constant number := 1;

g_em_vpool_not_found constant varchar2(256) := 'VPOOL not found:';

procedure my_raise(p_num binary_integer, p_msg varchar2, p_keeperrorstack boolean := true);

function get_vpool(p_vpool_id number, p_lock boolean := null) return vpool%rowtype;
function get_vpool_slot(p_vpool_id number, p_seq_num number, p_lock boolean := null) return vpool_slot%rowtype;

function insert_vpool_slot(p_rec vpool_slot%rowtype) return boolean;
function update_vpool_slot(p_rec vpool_slot%rowtype, p_check boolean := null, p_from_status number := null) return boolean;
function delete_vpool_slot(p_rec vpool_slot%rowtype, p_check boolean := null) return boolean;

procedure add_vpool_slots(p_vpool_id number, p_count number, p_status number := null, p_dt date := null);
procedure trunc_vpool_slots(p_vpool_id number, p_count number, p_status number := null);

procedure refresh_vpool_slots(p_vpool_id number, p_timeout_stale number, p_status_from number := null, p_status_to number := null);
procedure ensure_vpool_slots(p_vpool_id number, p_count number, p_status number := null, p_dt date := null);
procedure validate_vpool(p_vpool_id number, p_count number := null, p_timeout_stale number := null);

function release_vpool_slot(p_vpool_id number, p_seq_num number, p_status_from number := null, p_status_to number := null) return boolean;
function acquire_vpool_slot(p_vpool_id number, p_status_from number := null, p_status_to number := null) return number;
function loop_acquire_vpool_slot(p_vpool_id number, p_status_from number := null, p_status_to number := null) return number;

end;

/
