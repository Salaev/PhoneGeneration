CREATE package body external_interface is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
PROCEDURE Link_Phone_And_SIM_2 (
  p_phone_list              IN     t_PHONE,
  p_phone_linked_list       IN     t_PHONE,
  p_sn_list                 IN     t_SN,
  p_link_type_code          IN     NETWORK_ADDRESS_ACCESS_POINT.LINK_TYPE_CODE%TYPE,
  p_lnkd_ph_link_type_code  IN     NETWORK_ADDRESS_ACCESS_POINT.LINK_TYPE_CODE%TYPE,
  p_from_date               IN     NETWORK_ADDRESS_ACCESS_POINT.FROM_DATE%TYPE,
  p_user_login              IN     VARCHAR2,
  handle_tran               IN     CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT    NUMBER,
  Result_list               OUT    SYS_REFCURSOR,
  Rejected_list             OUT    SYS_REFCURSOR
)
IS
  v_sp_name varchar2(30);
  v_user_id               NUMBER;
  v_from_date             DATE;

  CURSOR c_lock_phone IS
  SELECT /*+ index(pn UK_PHONE_NUM_PHONE_NUMBER) */
         pn.network_address_id
  FROM tt_batch_na_ap t
  JOIN phone_number pn ON pn.international_format=t.International_Format
  FOR UPDATE;
BEGIN

  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, 'EXTERNAL_INTERFACE.Link_Phone_And_SIM_2');

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S,
                         RSIG_UTILS.c_HANDLE_TRAN_Y,
                         RSIG_UTILS.c_HANDLE_TRAN_N) OR
                         handle_tran IS NULL
  THEN
  	RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  -- check existence of user
  v_user_id := Rsig_users.Get_user_id_by_login(p_user_login);

  IF p_phone_list IS NULL OR
     p_phone_list.COUNT = 0 OR
     (p_phone_list.COUNT = 1 AND p_phone_list(p_phone_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'p_phone_list');
  END IF;

  /*
  IF p_phone_linked_list IS NOT NULL AND
     p_phone_linked_list.COUNT <> 0 AND
     (p_phone_linked_list.COUNT = 1 AND p_phone_linked_list(p_phone_linked_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'p_phone_linked_list');
  END IF;
  */

  IF p_sn_list IS NULL OR
     p_sn_list.COUNT = 0 OR
     (p_sn_list.COUNT = 1 AND p_sn_list(p_sn_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'p_sn_list');
  END IF;

  IF (p_link_type_code IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'p_link_type_code');
  END IF;

  IF (p_phone_linked_list.COUNT<>0 AND p_lnkd_ph_link_type_code IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'p_lnkd_ph_link_type_code');
  END IF;

  IF (p_phone_list.COUNT <> p_sn_list.COUNT) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'p_phone_list or p_sn_list');
  END IF;

  IF (p_phone_linked_list.COUNT<>0 AND p_phone_linked_list.COUNT <> p_sn_list.COUNT) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'p_phone_linked_list or p_sn_list');
  END IF;

  IF (p_link_type_code = p_lnkd_ph_link_type_code) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'p_link_type_code = p_lnkd_ph_link_type_code');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    v_sp_name := util_sys_pkg.make_savepoint;
  END IF;

  ------------------------------------------------------------------------------------------------
  v_from_date:=nvl(p_from_date,SYSDATE);

  DELETE FROM tt_batch_na_ap;
  DELETE FROM tt_phone_link;

  IF p_phone_linked_list.COUNT = 0
  THEN
    FORALL i IN nvl(p_phone_list.FIRST, 1) .. nvl(p_phone_list.LAST, 0)
      INSERT INTO tt_phone_link(main_msisdn)
      VALUES(p_phone_list(i));
  ELSE
  FORALL i IN nvl(p_phone_list.FIRST, 1) .. nvl(p_phone_list.LAST, 0)
    INSERT INTO tt_phone_link(main_msisdn,linked_msisdn)
    VALUES(p_phone_list(i),p_phone_linked_list(i));
  END IF;

  FORALL i IN nvl(p_phone_list.FIRST, 1) .. nvl(p_phone_list.LAST, 0)
    INSERT INTO tt_batch_na_ap(international_format,sn,exchange_port,result)
    VALUES(p_phone_list(i),p_sn_list(i), p_link_type_code,rsig_utils.c_OK);

  INSERT INTO tt_batch_na_ap(international_format,sn,exchange_port,result)
      SELECT tl.linked_msisdn, tm.sn, p_lnkd_ph_link_type_code, rsig_utils.c_OK
        FROM tt_phone_link tl
        JOIN tt_batch_na_ap tm ON tl.main_msisdn = tm.International_Format
        WHERE tl.linked_msisdn IS NOT NULL;
 /*
  FORALL i IN nvl(p_phone_linked_list.FIRST, 1) .. nvl(p_phone_linked_list.LAST, 0)
    INSERT INTO tt_batch_na_ap(international_format,sn,exchange_port,result)
    VALUES(p_phone_linked_list(i),p_sn_list(i), p_lnkd_ph_link_type_code,rsig_utils.c_OK);
*/
  OPEN c_lock_phone;
  CLOSE c_lock_phone;

	RSIG_UTILS.Fill_NA_ID_From_Int_Number;

	RSIG_UTILS.Fill_AP_ID_From_SN;


	UPDATE TT_BATCH_NA_AP T
	SET T.NETWORK_ADDRESS_ID = NULL,
		T.ACCESS_POINT_ID = NULL,
		T.RESULT = RSIG_UTILS.c_NOT_SAME_HOST_ID
	WHERE T.RESULT = RSIG_UTILS.C_OK
	  AND EXISTS (SELECT 1
				  FROM SIM_CARD SC,
				  SIM_SERIES SS,
				  PHONE_NUMBER PN,
				  PHONE_NUMBER_SERIES PNS,
				  PHONE_NUMBER_TYPE PNT
				  where
					T.ACCESS_POINT_ID = SC.ACCESS_POINT_ID and
					SS.SIM_SERIES_ID = SC.SIM_SERIES_ID and
					PN.NETWORK_ADDRESS_ID = T.NETWORK_ADDRESS_ID and
					PNS.PHONE_NUMBER_SERIES_ID = PN.PHONE_NUMBER_SERIES_ID and
					TRIM(PNT.PHONE_NUMBER_TYPE_CODE) = TRIM(PNS.PHONE_NUMBER_TYPE_CODE) AND
					  (PNS.HOST_ID <> SS.HOST_ID OR
					  (PNS.HOST_ID IS NULL AND SS.HOST_ID IS NOT NULL) OR
					  (PNS.HOST_ID IS NOT NULL AND SS.HOST_ID IS NULL)) AND
					PNT.CHECK_RELATION_TO_HOST = rsig_utils.c_YES);


	UPDATE tt_batch_na_ap t
	SET t.result = RSIG_UTILS.c_SIM_HAVE_PHONE_NUMBER
	WHERE t.result = RSIG_UTILS.C_OK
    AND EXISTS (SELECT 1
					      FROM 	NETWORK_ADDRESS_ACCESS_POINT naap
						    JOIN 	SIM_CARD sc ON sc.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
                JOIN SIM_SERIES ss ON ss.SIM_SERIES_ID = sc.SIM_SERIES_ID
					      WHERE ((naap.access_point_id = t.access_point_id
                        AND (trim(naap.link_type_code)=rsig_utils.c_MAIN_LINK_TYPE
                             AND trim(t.Exchange_Port)=rsig_utils.c_MAIN_LINK_TYPE))
                   OR naap.network_address_id=t.network_address_id)
					        AND (v_from_date<=naap.to_date OR naap.To_Date IS NULL)
                );


  INSERT INTO network_address_access_point(access_point_id,
                                           network_address_id,
                                           link_type_code,
                                           from_date,
                                           to_date,
                                           date_of_change,
                                           user_id_of_change)
  SELECT t.access_point_id,
         t.network_address_id,
         t.exchange_port,
         v_from_date,
         NULL,
         SYSDATE,
         v_user_id
  FROM tt_batch_na_ap t
  WHERE t.result=RSIG_UTILS.C_OK;

  DELETE FROM tt_processed_phones_sims;
  DELETE FROM tt_rejected_phones_sims;

  INSERT INTO tt_processed_phones_sims(MAIN_MSISDN,LINKED_MSISDN,ICCID)
    select t.international_format,
           tl.international_format as international_format_linked,
           t.sn
    FROM tt_phone_link pl
    LEFT JOIN tt_batch_na_ap t ON pl.main_msisdn = t.international_format
    LEFT JOIN tt_batch_na_ap tl ON pl.linked_msisdn = tl.international_format
    WHERE t.RESULT = RSIG_UTILS.C_OK
      AND (tl.result = RSIG_UTILS.C_OK OR pl.linked_msisdn IS NULL);

  INSERT INTO tt_rejected_phones_sims(MAIN_MSISDN,LINKED_MSISDN,ICCID,RESULT,Linked_Result)
    select t.international_format,
           tl.international_format as international_format_linked,
           t.sn,
           t.result as main_result,
           tl.result as linked_result
    FROM tt_phone_link pl
    LEFT JOIN tt_batch_na_ap t ON pl.main_msisdn = t.international_format
    LEFT JOIN tt_batch_na_ap tl ON pl.linked_msisdn = tl.international_format
    WHERE NOT (t.RESULT = RSIG_UTILS.C_OK
      AND (tl.result = RSIG_UTILS.C_OK OR pl.linked_msisdn IS NULL));

  OPEN Result_list FOR
  select t.international_format,
         tl.international_format as international_format_linked,
         t.sn
  FROM tt_phone_link pl
  LEFT JOIN tt_batch_na_ap t ON pl.main_msisdn = t.international_format
  LEFT JOIN tt_batch_na_ap tl ON pl.linked_msisdn = tl.international_format
  WHERE t.RESULT = RSIG_UTILS.C_OK
    AND (tl.result = RSIG_UTILS.C_OK OR pl.linked_msisdn IS NULL);

  OPEN Rejected_list FOR
  select t.international_format,
         tl.international_format as international_format_linked,
         t.sn,
         t.result as main_result,
         tl.result as linked_result
  FROM tt_phone_link pl
  LEFT JOIN tt_batch_na_ap t ON pl.main_msisdn = t.international_format
  LEFT JOIN tt_batch_na_ap tl ON pl.linked_msisdn = tl.international_format
  WHERE NOT (t.RESULT = RSIG_UTILS.C_OK
    AND (tl.result = RSIG_UTILS.C_OK OR pl.linked_msisdn IS NULL));
  -----------------------------------------------------------------------------------------------------------------
	IF error_code <> RSIG_UTILS.C_OK THEN
		RAISE_APPLICATION_ERROR(error_code,'');
	END IF;

	error_code := RSIG_UTILS.c_OK;

	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, 'EXTERNAL_INTERFACE.Link_Phone_And_SIM_2');

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
		commit;
	END IF;

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi (to_number(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, 'EXTERNAL_INTERFACE.Link_Phone_And_SIM_2');
	  CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        util_sys_pkg.rollback_savepoint(v_sp_name);
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
      ELSE NULL;
    END CASE;
END;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_!LEGACY for Scripts\8.20.501\CACHE_TIME_ZONE_OFFSET_base_filling.sql
--!_!also in SUPS.cs
--!_!move to API_RI_PKG
----------------------------------!---------------------------------------------
procedure get_time_zone_offset_list_root
(
  p_date_from date,
  p_date_to date,
  p_error_code out number,
  p_error_message out varchar2,
  p_time_zone_offset_list out sys_refcursor
)
is
begin
  ------------------------------
  TIME_ZONE_OFFSET_PKG.get_time_zone_offset_list_root
  (
    p_date_from => p_date_from,
    p_date_to => p_date_to,
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_time_zone_offset_list => p_time_zone_offset_list
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_time_zone_offset_list
(
  p_network_operator_code varchar2,
  p_date_from date,
  p_date_to date,
  p_error_code out number,
  p_error_message out varchar2,
  p_time_zone_offset_list out sys_refcursor
)
is
begin
  ------------------------------
  TIME_ZONE_OFFSET_PKG.get_time_zone_offset_list
  (
    p_network_operator_code => p_network_operator_code,
    p_date_from => p_date_from,
    p_date_to => p_date_to,
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_time_zone_offset_list => p_time_zone_offset_list
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
