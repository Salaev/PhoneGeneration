CREATE package COCAT_PKG is

----------------------------------!---------------------------------------------
  c_opt_cocat_delobj_corr_idcode constant varchar2(100) := 'COCAT.delete_objects.correlate_ids_codes';

  c_opt_cocat_no_extcode_imprtnt constant varchar2(100) := 'COCAT.NetworkOperator.ExtendedCodeIsMoreImportant';

----------------------------------!---------------------------------------------
  c_def_cocat_delobj_corr_idcode constant boolean := false;

  c_def_cocat_no_extcode_imprtnt constant boolean := false;

----------------------------------!---------------------------------------------
  procedure correlate_ids_codes
  (
    p_ids_in ct_number,
    p_codes_in ct_varchar_s,
    p_ids_real ct_number,
    p_codes_real ct_varchar_s,
    p_ids_out out ct_number,
    p_codes_out out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure correlate_ids
  (
    p_ids_in ct_number,
    p_codes_real ct_varchar_s,
    p_ids_out out ct_number,
    p_codes_out out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure correlate_codes
  (
    p_codes_in ct_varchar_s,
    p_ids_real ct_number,
    p_ids_out out ct_number,
    p_codes_out out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

----------------------------------!---------------------------------------------
  function xget_type_pos
  (
    p_type_code varchar2,
    p_type_codes ct_varchar_s,
    p_transparent boolean,
    p_main_count_opaque number,
    p_trim_empty boolean := TRUE
  ) return ct_number;

  ------------------------------
  --!_!p_type_code and p_type_codes is not used if NOT p_transparent
  --!_!initialize [error status] with [OK] state
  ------------------------------
  function xprepare_ids_part1a
  (
    p_transparent boolean,
    p_type_code varchar2,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_dates ct_date,
    p_main_count out number,
    p_poses_o out ct_number,
    p_ids_o out ct_number,
    p_codes_o out ct_varchar_s,
    p_dates_o out ct_date,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
  ) return boolean;

  function xprepare_ids_part1b
  (
    p_transparent boolean,
    p_type_code varchar2,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_extended_codes ct_varchar_s,
    p_dates ct_date,
    p_main_count out number,
    p_poses_o out ct_number,
    p_ids_o out ct_number,
    p_codes_o out ct_varchar_s,
    p_extended_codes_o out ct_varchar_s,
    p_dates_o out ct_date,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
  ) return boolean;

  procedure prepare_ids_part2
  (
    p_correlate_ids_codes boolean,
    p_ids_in ct_number,
    p_codes_in ct_varchar_s,
    p_ids_real ct_number,
    p_codes_real ct_varchar_s,
    p_ids_out out ct_number,
    p_codes_out out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  ------------------------------
  --!_! p_main_count != p_poses.count
  --!_! p_poses.count = p_ids.count
  ------------------------------
  procedure prepare_ids_part3
  (
    p_transparent boolean,
    p_main_count_opaque number,
    p_poses ct_number,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_error_codes ct_number,
    p_error_messages ct_varchar,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
  );

  procedure prepare_ids_parts23
  (
    p_transparent boolean,
    p_correlate_ids_codes boolean,
    p_main_count_opaque number,
    p_poses ct_number,
    p_ids_in ct_number,
    p_codes_in ct_varchar_s,
    p_ids_real ct_number,
    p_codes_real ct_varchar_s,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
  );

----------------------------------!---------------------------------------------
  procedure prepare_ids_transparent
  (
    p_correlate_ids_codes boolean,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_extended_codes ct_varchar_s,
    p_dates ct_date,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
  );

----------------------------------!---------------------------------------------
  procedure prepare_ids_routing_number
  (
    p_transparent boolean,
    p_correlate_ids_codes boolean,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_dates ct_date,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
  );

  procedure prepare_ids_dst_rule
  (
    p_transparent boolean,
    p_correlate_ids_codes boolean,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_dates ct_date,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
  );

  procedure apply_extended_codes_to_netop
  (
    p_poses ct_number,
    p_extended_codes ct_varchar_s,
    p_dates ct_date,
    p_ids_io in out nocopy ct_number
  );

  procedure prepare_ids_network_operator
  (
    p_transparent boolean,
    p_correlate_ids_codes boolean,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_extended_codes ct_varchar_s, --!_!uprsc
    p_dates ct_date,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
  );

  procedure prepare_ids_zone
  (
    p_transparent boolean,
    p_correlate_ids_codes boolean,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_dates ct_date,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
  );

  procedure prepare_ids_host
  (
    p_transparent boolean,
    p_correlate_ids_codes boolean,
    p_type_codes ct_varchar_s,
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_dates ct_date,
    p_ids_io in out nocopy ct_number,
    p_codes_io in out nocopy ct_varchar_s,
    p_error_codes_io in out nocopy ct_number,
    p_error_messages_io in out nocopy ct_varchar
  );

----------------------------------!---------------------------------------------
  procedure delete_objects
  (
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_extended_codes ct_varchar_s,
    p_type_codes ct_varchar_s,
    p_date_from ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids in out nocopy ct_number,
    p_out_codes in out nocopy ct_varchar_s,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
  );

  procedure delete_object_i
  (
    p_id number,
    p_type_code varchar2,
    p_user_id number,
    p_date_from date
  );

----------------------------------!---------------------------------------------
  procedure create_routing_number
  (
    p_rn_codes ct_varchar_s,
    p_rn_names ct_nvarchar,
    p_date_from ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure update_routing_number
  (
    p_rn_ids ct_number,
    p_rn_codes ct_varchar_s,
    p_rn_names ct_nvarchar,
    p_date_from ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure create_dst_rule
  (
    p_dst_rule_names ct_varchar,
    p_country_code ct_varchar_s,
    p_date_start_rule_masks ct_varchar_s,
    p_date_starts ct_varchar_s,
    p_date_end_rule_masks ct_varchar_s,
    p_date_ends ct_varchar_s,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure update_dst_rule
  (
    p_dst_rule_ids ct_number,
    p_dst_rule_names ct_varchar,
    p_country_code ct_varchar_s,
    p_date_start_rule_masks ct_varchar_s,
    p_date_starts ct_varchar_s,
    p_date_end_rule_masks ct_varchar_s,
    p_date_ends ct_varchar_s,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure create_network_operator
  (
    p_network_operator_codes ct_varchar_s,
    p_network_operator_names ct_varchar,
    p_network_operator_types ct_varchar_s,
    p_personal_account ct_varchar_s,
    p_deleted ct_date,
    p_network_operator_id_uppers ct_number,
    p_uprs_member_codes ct_varchar_s,
    --!_! p_replicated_region_ids ct_number,
    p_country ct_number,
    p_mcc ct_varchar_s,
    p_mnc ct_varchar_s,
    p_time_zones ct_number,
    p_dst_rule_ids ct_number,
    p_routing_number_ids ct_number,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure update_network_operator
  (
    p_network_operator_ids ct_number,
    p_network_operator_codes ct_varchar_s,
    p_network_operator_names ct_varchar,
    p_network_operator_types ct_varchar_s,
    p_personal_account ct_varchar_s,
    p_deleted ct_date,
    p_network_operator_id_uppers ct_number,
    p_uprs_member_codes ct_varchar_s,
    --!_! p_replicated_region_ids ct_number,
    p_country ct_number,
    p_mcc ct_varchar_s,
    p_mnc ct_varchar_s,
    p_time_zones ct_number,
    p_dst_rule_ids ct_number,
    p_routing_number_ids ct_number,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure create_zone
  (
    p_zone_codes ct_varchar_s,
    p_zone_names ct_varchar,
    p_network_operator_ids ct_number,
    p_deleted ct_date,
    p_zone_type_codes ct_varchar_s,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure update_zone
  (
    p_zone_ids ct_number,
    p_zone_codes ct_varchar_s,
    p_zone_names ct_varchar,
    p_network_operator_ids ct_number,
    p_deleted ct_date,
    p_zone_type_codes ct_varchar_s,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure create_host
  (
    p_host_codes ct_varchar_s,
    p_host_names ct_varchar,
    p_host_addresses ct_varchar,
    p_host_locations ct_varchar,
    p_deleted ct_date,
    p_host_type_codes ct_varchar_s,
    p_network_operator_ids ct_number,
    p_time_zones ct_number,
    p_dst_rule_ids ct_number,
    p_routing_number_ids ct_number,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure update_host
  (
    p_host_ids ct_number,
    p_host_codes ct_varchar_s,
    p_host_names ct_varchar,
    p_host_addresses ct_varchar,
    p_host_locations ct_varchar,
    p_deleted ct_date,
    p_host_type_codes ct_varchar_s,
    p_network_operator_ids ct_number,
    p_time_zones ct_number,
    p_dst_rule_ids ct_number,
    p_routing_number_ids ct_number,
    p_user_id number,
    p_break_on_error boolean,
    p_out_ids out ct_number,
    p_out_codes out ct_varchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

----------------------------------!---------------------------------------------
  procedure get_routing_number_by_ids
  (
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_routing_number_all
  (
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_routing_number
  (
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_dst_rule_by_ids
  (
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_dst_rule_all
  (
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_dst_rule
  (
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_network_operator_by_ids
  (
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_uprs_member_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_network_operator_all
  (
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_network_operator
  (
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_uprs_member_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_zone_by_ids
  (
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_zone_all
  (
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_zone
  (
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_host_by_ids
  (
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_host_all
  (
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_host
  (
    p_ids ct_number,
    p_codes ct_varchar_s,
    p_date date,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------

end;
/
