CREATE PACKAGE BODY RSIG_UTILS_EXT IS

--------------------------------------------------------------------------------------
-- Unlink_Phone_And_SIM
--------------------------------------------------------------------------------------
PROCEDURE Unlink_Phone_And_SIM
(
  handle_tran         CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT  NUMBER,
  p_phone_list        IN   t_PHONE,
  p_sn_list           IN   t_SN,
  p_end_date          IN   NETWORK_ADDRESS_ACCESS_POINT.TO_DATE%TYPE,
  p_user_login        IN   VARCHAR2,
  Result_list         OUT  RSIG_UTILS.REF_CURSOR
) IS
  v_event_source      VARCHAR2(60) := 'RSIG_UTILS_EXT.Unlink_Phone_And_SIM';
  v_user_id           NUMBER;
  v_end_date          DATE;

  CURSOR c_lock_phone IS
  SELECT /*+ index(pn UK_PHONE_NUM_PHONE_NUMBER) */
         pn.network_address_id
  FROM tt_batch_na_ap t
  JOIN phone_number pn ON pn.international_format=t.International_Format
  FOR UPDATE;

BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  -- check existence of user
  v_user_id := Rsig_users.Get_user_id_by_login(p_user_login);

  IF p_phone_list IS NULL OR 
     p_phone_list.COUNT = 0 OR
     (p_phone_list.COUNT = 1 AND p_phone_list(p_phone_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;  

  IF p_sn_list IS NULL OR 
     p_sn_list.COUNT = 0 OR
     (p_sn_list.COUNT = 1 AND p_sn_list(p_sn_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF; 

  IF (p_phone_list.COUNT <> p_sn_list.COUNT) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint unlink_phone_and_sim_a;
  END IF;

  ------------------------------------------------------------------------------------------------
  v_end_date := nvl(p_end_date,SYSDATE);

  DELETE FROM tt_batch_na_ap;

  FORALL i IN nvl(p_phone_list.FIRST, 1) .. nvl(p_phone_list.LAST, 0)
    INSERT INTO tt_batch_na_ap(international_format,sn,result)
    VALUES(p_phone_list(i),p_sn_list(i),rsig_utils.c_OK);

  OPEN c_lock_phone;
  CLOSE c_lock_phone;

	RSIG_UTILS.Fill_NA_ID_From_Int_Number;

	RSIG_UTILS.Fill_AP_ID_From_SN;

  UPDATE tt_batch_na_ap t
     SET t.result=RSIG_UTILS.c_ROW_NOT_FOUND
   WHERE t.result = rsig_utils.c_OK
     AND NOT EXISTS(SELECT 1
                    FROM network_address_access_point naap
                    WHERE naap.access_point_id=t.access_point_id
                      AND naap.network_address_id=t.network_address_id
                      AND v_end_date BETWEEN naap.from_date AND nvl(naap.to_date,v_end_date));


  UPDATE network_address_access_point naap
     SET naap.to_date=v_end_date,
         naap.user_id_of_change=v_user_id,
         naap.date_of_change=SYSDATE
   WHERE v_end_date BETWEEN naap.from_date AND nvl(naap.to_date,v_end_date)
     AND EXISTS(SELECT 1
                FROM tt_batch_na_ap t
                WHERE t.access_point_id=naap.access_point_id
                  AND t.network_address_id=naap.network_address_id
                  AND t.result = rsig_utils.c_OK);

  OPEN Result_list FOR
  select t.international_format,
         t.sn,
         t.result
  FROM tt_batch_na_ap t
  WHERE t.RESULT<>RSIG_UTILS.C_OK;
  ------------------------------------------------------------------------------------------------------

  error_code := RSIG_UTILS.c_OK;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(to_number(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint unlink_phone_and_sim_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Unlink_Phone_And_SIM;

--------------------------------------------------------------------------------------
-- Unlink_one_Phone_And_SIM
--------------------------------------------------------------------------------------
PROCEDURE Unlink_one_Phone_And_SIM (
  handle_tran               IN     CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT    NUMBER,
  p_international_format    IN     phone_number.international_format%TYPE,
  p_sn                      IN     sim_card.sn%TYPE,
  p_end_date                IN     NETWORK_ADDRESS_ACCESS_POINT.FROM_DATE%TYPE,
  p_user_login              IN     VARCHAR2,
  Result_list               OUT    RSIG_UTILS.REF_CURSOR
)
IS
  v_user_id               NUMBER;
  v_end_date              DATE;
  v_network_address_id    network_address.network_address_id%TYPE;
  v_access_point_id       access_point.access_point_id%TYPE;
  v_error                 INT;
  error_message           VARCHAR(256);

BEGIN
    error_code := NULL;
    error_message := NULL;
    v_error := RSIG_UTILS.c_OK;

	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, 'RSIG_UTILS_EXT.Unlink_one_Phone_And_SIM');

	IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S,
                         RSIG_UTILS.c_HANDLE_TRAN_Y,
                         RSIG_UTILS.c_HANDLE_TRAN_N)
		OR handle_tran IS NULL THEN
            error_code := RSIG_UTILS.c_ORA_INVALID_HANDLE;
            error_message := 'Invalid handle tran';
			RAISE_APPLICATION_ERROR(error_code, error_message);
	END IF;

  -- check existence of user
  v_user_id := Rsig_users.Get_user_id_by_login(p_user_login);

	IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
		savepoint link_phone_and_sim_a;
	END IF;

  -----------------------------------------------------------------------------------------------
  v_end_date := nvl(p_end_date, SYSDATE);

  -- lock phone
  BEGIN
    SELECT pn.network_address_id
      INTO v_network_address_id
     FROM phone_number pn
     WHERE pn.international_format = p_international_format
      AND (pn.deleted IS NULL OR pn.deleted>SYSDATE)
      FOR UPDATE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_error:= RSIG_UTILS.c_PHONE_NUMBER_NOT_EXISTS;
  END;

  BEGIN
    SELECT pn.network_address_id
    INTO v_network_address_id
    FROM phone_number pn
    JOIN phone_number_series pns ON pns.phone_number_series_id=pn.phone_number_series_id
    WHERE pn.international_format=p_international_format
      AND (pn.deleted IS NULL OR pn.deleted>v_end_date);
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_error:= RSIG_UTILS.c_PHONE_NUMBER_NOT_EXISTS;
  END;

  BEGIN
    SELECT sc.access_point_id
    INTO v_access_point_id
    FROM sim_card sc
    WHERE sc.sn=p_sn;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_error:= RSIG_UTILS.c_SIM_CARD_NOT_EXISTS;
  END;

  UPDATE network_address_access_point naap
     SET naap.to_date=v_end_date,
         naap.user_id_of_change=v_user_id,
         naap.date_of_change=SYSDATE
   WHERE v_end_date BETWEEN naap.from_date AND nvl(naap.to_date,v_end_date)
     AND naap.access_point_id=v_access_point_id
     AND naap.network_address_id=v_network_address_id;

  IF SQL%NOTFOUND AND v_error = rsig_utils.c_OK THEN
    v_error:=RSIG_UTILS.c_ROW_NOT_FOUND;
  END IF;

  OPEN Result_list FOR
    SELECT p_international_format AS international_format,
           p_sn AS sn,
           v_error AS RESULT
    FROM dual
  WHERE v_error <> RSIG_UTILS.c_OK;

  -----------------------------------------------------------------------------------------------

  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, 'RSIG_UTILS_EXT.Unlink_one_Phone_And_SIM');

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) 
  THEN
    COMMIT;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi (to_number(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, 'RSIG_UTILS_EXT.Unlink_one_Phone_And_SIM');
	  CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint link_phone_and_sim_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
        ELSE NULL;
      END CASE;
END Unlink_one_Phone_And_SIM;

---------------------------------------------
--     PROCEDURE Set_SIM_Status
---------------------------------------------

PROCEDURE Set_SIM_Status (
	handle_tran                IN    CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
	error_code                 OUT   NUMBER,
	p_start_date               IN    DATE,
	p_status_code              IN    ACCESS_POINT_STATUS_HISTORY.ACCESS_POINT_STATUS_CODE%TYPE,
	p_user_login               IN    VARCHAR2,
  p_SN_list                  IN    t_SN,
	Result_list                OUT   RSIG_UTILS.REF_CURSOR
)
IS
  v_event_source VARCHAR2(60) := 'RSIG_UTILS_EXT.Set_SIM_Status';
  v_user_id      NUMBER;
  v_start_date   DATE;

BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  -- check existence of user
  v_user_id := Rsig_users.Get_user_id_by_login(p_user_login);

  IF p_SN_list IS NULL OR 
     p_SN_list.COUNT = 0 OR
     (p_SN_list.COUNT = 1 AND p_SN_list(p_SN_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;  

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint set_phone_status_a;
  END IF;

  v_start_date := nvl(p_start_date, SYSDATE);

  DELETE FROM tt_batch_na_ap;

  FORALL i IN nvl(p_SN_list.FIRST, 1) .. nvl(p_SN_list.LAST, 0)
    INSERT INTO tt_batch_na_ap (sn,result)
    VALUES(p_SN_list(i),rsig_utils.c_OK);

  rsig_access_point_status.Lock_sims;

	RSIG_UTILS.Fill_Ap_Id_From_Sn;

  -- check previous interval ------------------------------------------------------------------
  UPDATE tt_batch_na_ap t
  SET t.RESULT = rsig_utils.c_SAME_ACC_POINT_STATUS
  WHERE t.RESULT=rsig_utils.c_OK
    AND EXISTS(SELECT /*+ index(apsh I_ACCPOSTAHI_ACCESS_POINT_ID)*/1
               FROM access_point_status_history apsh
               WHERE apsh.access_point_id=t.access_point_id
                 AND v_start_date BETWEEN apsh.start_date AND nvl(apsh.end_date,v_start_date)
                 AND trim(apsh.access_point_status_code)=TRIM(p_status_code));

  -- check previous status ------------------------------------------------------------------
  UPDATE tt_batch_na_ap t
     SET t.RESULT = rsig_access_point_status.Is_Status_Change_Allowed
                                                         (t.access_point_id,
                                                          p_status_code,
                                                          rsig_utils.c_YES,
                                                          v_start_date)
   WHERE t.RESULT=rsig_utils.c_OK;
  -- close previous interval -------------------------------------------------------------------
  UPDATE /*+ index(apsh I_ACCPOSTAHI_ACCESS_POINT_ID)*/
  access_point_status_history apsh
  SET apsh.end_date = v_start_date - RSIG_UTILS.c_INTERVAL_DIFFERENCE,
      apsh.date_of_change = sysdate,
      apsh.user_id_of_change = v_user_id
  WHERE v_start_date BETWEEN apsh.start_date AND nvl(apsh.end_date,v_start_date)
    AND EXISTS(SELECT /*+ use_nl(t apsh) */ 1
               FROM tt_batch_na_ap t
               WHERE t.access_point_id=apsh.access_point_id
                 AND t.result=rsig_utils.c_OK);

  -- insert new interval -----------------------------------------------------------------------
  insert into access_point_status_history
        (access_point_status_code,
         access_point_id,
         START_DATE,
         DATE_OF_CHANGE,
         USER_ID_OF_CHANGE)
   SELECT p_status_code,
          t.access_point_id,
          v_start_date,
          sysdate,
          v_user_id
   FROM tt_batch_na_ap t
   WHERE t.result=rsig_utils.c_OK;


  OPEN Result_list FOR
  select sn,
         RESULT
  from tt_batch_na_ap
  where RESULT <> RSIG_UTILS.c_OK;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    ERROR_CODE := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(to_number(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN Result_list FOR
    select sn,
           ERROR_CODE AS RESULT
    from tt_batch_na_ap;

    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint set_phone_status_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Set_SIM_Status;

---------------------------------------------
--     PROCEDURE Set_One_SIM_Status
---------------------------------------------

PROCEDURE Set_One_SIM_Status
( handle_tran               CHAR   DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  ERROR_CODE                OUT    NUMBER,
  p_start_date              IN     DATE,
  p_status_code             IN     ACCESS_POINT_STATUS_HISTORY.ACCESS_POINT_STATUS_CODE%TYPE,
  p_user_login              IN     VARCHAR2,
  p_SN                      IN     sim_card.sn%TYPE,
  Result_list               OUT    RSIG_UTILS.REF_CURSOR
)
IS
  v_event_source        VARCHAR2(60) := 'RSIG_UTILS_EXT.Set_One_SIM_Status';
  v_user_id             NUMBER;
  v_start_date          DATE;
  v_access_point_id     access_point.access_point_id%TYPE;
  v_error               INT :=RSIG_UTILS.c_OK;
  v_same_status         INT;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  -- check existence of user
  v_user_id := Rsig_users.Get_user_id_by_login(p_user_login);

  IF p_SN IS NULL then
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint set_phone_status_a;
  END IF;

  v_start_date := nvl(p_start_date, SYSDATE);

  --lock sim
  rsig_access_point_status.Lock_sims(p_sn, v_access_point_id, v_error);

  IF v_error = RSIG_UTILS.c_OK THEN
    -- check previous status
    SELECT COUNT(1)
    INTO v_same_status
    FROM dual
    WHERE EXISTS(SELECT 1
                 FROM access_point_status_history apsh
                 WHERE apsh.access_point_id = v_access_point_id
                   AND trim(apsh.access_point_status_code)=p_status_code
                   AND v_start_date BETWEEN apsh.start_date AND nvl(apsh.end_date,v_start_date));

    IF v_same_status = 1 THEN
      v_error := RSIG_UTILS.c_SAME_ACC_POINT_STATUS;
    ELSE
      --check if we can change status
      v_error := rsig_access_point_status.Is_Status_Change_Allowed
                  (p_access_point_id => v_access_point_id,
                   p_new_status => p_status_code,
                   p_IS_BP => rsig_utils.c_YES,
                   p_date => v_start_date);
    END IF;

    IF v_error = RSIG_UTILS.c_OK THEN
      -- close previous interval
      UPDATE access_point_status_history apsh
      SET  apsh.end_date = v_start_date - RSIG_UTILS.c_INTERVAL_DIFFERENCE,
           apsh.date_of_change = sysdate,
           apsh.user_id_of_change = v_user_id
      WHERE apsh.access_point_id = v_access_point_id
        AND v_start_date BETWEEN apsh.start_date AND nvl(apsh.end_date,v_start_date);

      -- create new interval
     insert into access_point_status_history
          (access_point_status_code,
           access_point_id,
           START_DATE,
           DATE_OF_CHANGE,
           USER_ID_OF_CHANGE)
      values
        (p_status_code,
         v_access_point_id,
         v_start_date,
         sysdate,
         v_user_id);
    END IF;
  END IF;

  OPEN result_list FOR
  select p_SN AS SN,
         v_error AS RESULT
  FROM dual
  WHERE v_error<>RSIG_UTILS.c_OK;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

EXCEPTION
  WHEN OTHERS THEN
    ERROR_CODE := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(to_number(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);

    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint set_phone_status_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
    
    OPEN result_list FOR
    SELECT p_SN AS SN,
           ERROR_CODE AS RESULT
    FROM dual;
END Set_One_SIM_Status;

---------------------------------------------
--     PROCEDURE Get_SIMCard_Details_By_SIMList
---------------------------------------------

procedure get_simcard_details_by_simlist
(
  p_sn_list util_pkg.cit_varchar_s,
  p_result_list out sys_refcursor,
  p_addit_result out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
) is
  v_access_point_id ct_number;
  v_sn ct_varchar_s;
  v_sysdate date := sysdate;
begin
  -----------------------------
  if (not util_pkg.CheckP_cit_varchar_s(p_sn_list)) then
    raise_application_error(util_pkg.c_ora_missing_parameter, util_pkg.c_msg_missing_parameter);
  end if;
 ---------------------------------------------------------------------------------------------
  v_sn := util_pkg.cast_cit2ct_varchar_s(p_sn_list, true);
  
  select /*+ ordered use_nl(t sc) full(t) index(sc UK_SIM_SN)*/
         distinct sc.access_point_id
    bulk collect into v_access_point_id
    from (select /*+ full(z)*/column_value sn from table(cast(v_sn as ct_varchar_s)) z) t
    join sim_card sc on sc.sn = t.sn;
  -----------------------------
  open p_result_list for
  select /*+ ordered use_nl(t sc ss sct appsh sssv) full(t) index(sc pk_sim_card)
             index(ss pk_sim_series) index(appsh i_appsthi_access_point_id) index(sssv i_simsestava_sim_series_id)*/
         sc.sn,
         sc.imsi,
         sc.pin,
         sc.puk,
         sc.pin2,
         sc.puk2,
         sct.sim_card_type_code,
         sct.sim_card_type_name,
         sc.ki ki,                 -- sc.ki,
         sc.adm1 adm1,               -- sc.adm1
         sc.access_control access_control,      -- sc.access_control
         nvl(appsh.ap_prod_status_code, sssv.status_code) ap_prod_status_code,
         substr(sc.sn, 1, length(sc.sn) - 1) serial_number,
         sc.authent_type,
         sc.personal_account,
         sc.access_point_id
  from (select /*+ full(z)*/column_value access_point_id from table(cast(v_access_point_id as ct_number)) z) t
  join sim_card sc on sc.access_point_id = t.access_point_id
  join sim_series ss on ss.sim_series_id = sc.sim_series_id
  join sim_card_type sct on trim(ss.sim_card_type_code) = trim(sct.sim_card_type_code)
  left join ap_prod_status_hist appsh
    on appsh.access_point_id = sc.access_point_id
    and v_sysdate between appsh.start_date and nvl(appsh.end_date, v_sysdate)
  left join sim_series_status_validity sssv
    on sssv.sim_series_id = ss.sim_series_id
    and v_sysdate between sssv.start_date and nvl(sssv.end_date, v_sysdate)
  where (sc.deleted is null or sc.deleted>v_sysdate)
  and (ss.deleted is null or ss.deleted>v_sysdate)
  ;
  
  open p_addit_result for
  select /*+ ordered use_nl(t si) full(t) index(si i_sim_imsi_access_point_imsi)*/
         si.access_point_id,
         si.imsi,
         si.imsi_type_code
    from (select /*+ full(z)*/column_value access_point_id from table(cast(v_access_point_id as ct_number)) z) t
    join sim_imsi si on si.access_point_id = t.access_point_id
    order by si.access_point_id, si.imsi_type_code
  ;
  ---------------------------------------------------------------------------------------------
  p_error_code := util_pkg.c_ora_ok; -- succesfully completed
  p_error_message := util_pkg.c_msg_ok;
  -----------------------------
exception
when others then
  -----------------------------
  p_error_code := util_pkg.get_err_code;
  p_error_message := util_pkg.get_err_msg;
  -----------------------------
end;

---------------------------------------------
--     PROCEDURE Get_IMSI_By_MSISDN_List
---------------------------------------------

PROCEDURE Get_IMSI_By_MSISDN_List
(
  handle_tran        CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code         OUT  NUMBER,
  p_phone_list       IN   t_PHONE,
  p_validity_date    IN   DATE := SYSDATE,
  p_cur_host         OUT  RSIG_UTILS.REF_CURSOR

) IS
  v_event_source     VARCHAR2(60) := 'RSIG_UTILS_EXT.Get_IMSI_By_MSISDN_List';
  v_validity_date    DATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF p_phone_list IS NULL OR 
     p_phone_list.COUNT = 0 OR
     (p_phone_list.COUNT = 1 AND p_phone_list(p_phone_list.FIRST) IS NULL)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;  

  IF nvl(p_validity_date, SYSDATE) < RSIG_UTILS.c_MIN_DATE THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint get_imsi_list_a;
  END IF;

  ----------------------------------------------------------------------------------------------------
  v_validity_date:=nvl(p_validity_date,SYSDATE);

  DELETE FROM tt_batch_na_ap;

  FORALL i IN nvl(p_phone_list.FIRST, 1) .. nvl(p_phone_list.LAST, 0)
    INSERT INTO tt_batch_na_ap(international_format,result)
    VALUES(p_phone_list(i),rsig_utils.c_OK);


  OPEN p_cur_host FOR
  select /*+ ORDERED use_nl(t p naap si) full(t) index(p UK_PHONE_NUM_PHONE_NUMBER)
             index(naap I_NETADDRACCPO_NET_ADDRESS_ID) index(si I_SIM_IMSI_ACCESS_POINT_IMSI)*/
         t.international_format,
         si.IMSI,
         naap.LINK_TYPE_CODE
  from tt_batch_na_ap t
  join PHONE_NUMBER p on t.international_format = p.INTERNATIONAL_FORMAT
  join NETWORK_ADDRESS_ACCESS_POINT naap on naap.NETWORK_ADDRESS_ID = p.NETWORK_ADDRESS_ID
  join SIM_IMSI si on si.ACCESS_POINT_ID = naap.ACCESS_POINT_ID
  where v_validity_date BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE,v_validity_date)
    AND (p.deleted IS NULL OR p.deleted>v_validity_date);


----------------------------------------------------------------------------------------------------
  error_code := RSIG_UTILS.c_OK;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(to_number(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint get_imsi_list_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Get_IMSI_By_MSISDN_List;

END;
/
