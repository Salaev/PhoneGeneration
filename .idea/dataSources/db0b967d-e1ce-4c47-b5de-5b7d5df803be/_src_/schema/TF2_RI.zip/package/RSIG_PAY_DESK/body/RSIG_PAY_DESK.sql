CREATE PACKAGE BODY RSIG_PAY_DESK IS

---------------------------------------------
--     PROCEDURE Test_Row_For_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Row_For_Exist_And_Deleted(p_pay_desk_id IN PAY_DESK.PAY_DESK_ID%TYPE) IS
  v_deleted PAY_DESK.DELETED%TYPE;

BEGIN

  select DELETED into v_deleted from PAY_DESK where PAY_DESK_ID = p_pay_desk_id;

  IF v_deleted IS NOT NULL THEN
    IF v_deleted < sysdate THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
    END IF;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Test_Row_For_Exist_And_Deleted;

---------------------------------------------
--     PROCEDURE Insert_Pay_Desk
---------------------------------------------

PROCEDURE Insert_Pay_Desk
(
  handle_tran           CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_pay_desk_sn         IN pay_desk.pay_desk_sn%TYPE,
  p_pay_desk_code       IN pay_desk.pay_desk_code%TYPE,
  P_pay_desk_name       IN pay_desk.pay_desk_name%TYPE,
  p_payment_entrance_id IN pay_desk.payment_entrance_id%TYPE,
  p_user_id_of_change   IN pay_desk.user_id_of_change%TYPE,
  p_pay_desk_id         OUT PAY_DESK.PAY_DESK_ID%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PAY_DESK.Insert_Pay_Desk';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint insert_pay_desk_type_a;
  END IF;

  select s_pay_desk.nextval into p_pay_desk_id from DUAL;

  BEGIN
    INSERT INTO PAY_DESK
      (PAY_DESK_ID,
       PAY_DESK_SN,
       PAY_DESK_CODE,
       PAY_DESK_NAME,
       PAYMENT_ENTRANCE_ID,
       USER_ID_OF_CHANGE,
       DATE_OF_CHANGE)
    VALUES
      (p_pay_desk_id,
       p_pay_desk_sn,
       p_pay_desk_code,
       P_pay_desk_name,
       p_payment_entrance_id,
       p_user_id_of_change,
       sysdate);

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      CASE rsig_utils.GET_CONSTRAINT_NAME(SQLERRM)
        WHEN rsig_utils.c_UK_PAY_DESK_CODE THEN
          raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_PAY_DESK_CODE, '');
        WHEN rsig_utils.c_UK_PAY_DESK_NAME THEN
          raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_PAY_DESK_NAME, '');
        ELSE
          raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_PAY_DESK_SN, '');
      END CASE;
  END;
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint insert_pay_desk_type_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Insert_Pay_Desk;


---------------------------------------------
--     PROCEDURE Delete_Pay_Desk
---------------------------------------------

PROCEDURE Delete_Pay_Desk
(
  handle_tran         CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT NUMBER,
  p_pay_desk_id       IN PAY_DESK.PAY_DESK_ID%TYPE,
  p_deleted           IN PAY_DESK.DELETED%TYPE,
  p_user_id_of_change IN PAY_DESK.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PAY_DESK.Delete_Pay_Desk';
  v_deleted      DATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint delete_pay_desk;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_pay_desk_id);
  v_deleted := nvl(p_deleted, SYSDATE);
  update PAY_DESK
     set DELETED           = v_deleted,
         DATE_OF_CHANGE    = sysdate,
         USER_ID_OF_CHANGE = p_user_id_of_change
   where PAY_DESK_ID = p_pay_desk_id;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint delete_pay_desk;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Delete_Pay_Desk;


---------------------------------------------
--     PROCEDURE Update_Pay_Desk
---------------------------------------------

PROCEDURE Update_Pay_Desk
(
  handle_tran           CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_pay_desk_id         IN pay_desk.pay_desk_id%TYPE,
  p_pay_desk_sn         IN pay_desk.pay_desk_sn%TYPE,
  p_pay_desk_code       IN pay_desk.pay_desk_code%TYPE,
  p_pay_desk_name       IN pay_desk.pay_desk_name%TYPE,
  p_payment_entrance_id IN pay_desk.payment_entrance_id%TYPE,
  p_user_id_of_change   IN pay_desk.user_id_of_change%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PAY_DESK.Update_Pay_Desk';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint update_pay_desk;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_pay_desk_id);

  BEGIN
    UPDATE PAY_DESK
       SET PAY_DESK_CODE       = p_pay_desk_code,
           PAY_DESK_SN         = p_pay_desk_sn,
           PAY_DESK_NAME       = p_pay_desk_name,
           PAYMENT_ENTRANCE_ID = p_payment_entrance_id,
           DATE_OF_CHANGE      = sysdate,
           USER_ID_OF_CHANGE   = p_user_id_of_change
     WHERE PAY_DESK_ID = p_pay_desk_id;

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      CASE rsig_utils.GET_CONSTRAINT_NAME(SQLERRM)
        WHEN rsig_utils.c_UK_PAY_DESK_CODE THEN
          raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_PAY_DESK_CODE, '');
        WHEN rsig_utils.c_UK_PAY_DESK_NAME THEN
          raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_PAY_DESK_NAME, '');
        ELSE
          raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_PAY_DESK_SN, '');
      END CASE;
  END;
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint update_pay_desk;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Update_Pay_Desk;

---------------------------------------------
--     PROCEDURE Get_Pay_Desk
---------------------------------------------

PROCEDURE Get_Pay_Desk
(
  error_code            OUT NUMBER,
  p_payment_entrance_id IN PAY_DESK.payment_entrance_id%TYPE,
  p_all_rows            IN CHAR,
  p_result              OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_PAY_DESK.Get_Pay_Desk';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_payment_entrance_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF p_all_rows = 'Y' THEN
    OPEN p_result FOR
      select pd.pay_desk_id,
             pd.pay_desk_sn,
             pd.pay_desk_code,
             pd.pay_desk_name,
             no.NETWORK_OPERATOR_NAME,
             pd.deleted,
             u.user_name,
             pd.date_of_change
        from PAY_DESK pd
        JOIN PAYMENT_ENTRANCE pe ON pe.payment_entrance_id = pd.payment_entrance_id
        JOIN NETWORK_OPERATOR no ON no.network_operator_id = pe.network_operator_id
        join USERS u on u.user_id = pd.user_id_of_change
       where pe.payment_entrance_id = p_payment_entrance_id
       order by pd.pay_desk_name;
  ELSE
    OPEN p_result FOR
      select pd.pay_desk_id,
             pd.pay_desk_sn,
             pd.pay_desk_code,
             pd.pay_desk_name,
             no.NETWORK_OPERATOR_NAME,
             pd.deleted,
             u.user_name,
             pd.date_of_change
        from PAY_DESK pd
        JOIN PAYMENT_ENTRANCE pe ON pe.payment_entrance_id = pd.payment_entrance_id
        JOIN NETWORK_OPERATOR no ON no.network_operator_id = pe.network_operator_id
        join USERS u on u.user_id = pd.user_id_of_change
       where pe.payment_entrance_id = p_payment_entrance_id
         and (pd.deleted is null or pd.deleted > sysdate)
       order by pd.pay_desk_name;
  END IF;
  error_code := RSIG_UTILS.c_OK;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      OPEN p_result FOR
        select error_code from dual;
    END;
END Get_Pay_Desk;


END RSIG_PAY_DESK;
/
