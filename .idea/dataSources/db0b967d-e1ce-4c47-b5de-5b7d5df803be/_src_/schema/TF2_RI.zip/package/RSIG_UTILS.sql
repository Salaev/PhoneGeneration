CREATE PACKAGE RSIG_UTILS IS
  /****************************************************************************
    <header>
      <name>              package RSIG_UTILS
      </name>

      <author>            Petr Kout - GITUS
      </author>


      <version>           1.4.7     18.05.2011      Victor Smirnov
                          procedure Debug_Rsi updated (validated)
      </version>
      <version>           1.4.6     17.08.2010     Denis Kovalchuk
                          constant c_SIM_INVALID_HOST added
                          constant c_SIM_INVALID_NET_OPER added
      </version>
      <version>           1.4.5     17.07.2010     Denis Kovalchuk
                          constant c_OFS_Phone_Type added
      </version>
      <version>           1.4.4     20.10.2009     Sergey Ermakov
                          constant c_ORA_NET_OPERATOR_NOT_EXIST added
                          constant c_ORA_VERY_BIG_VALUE added
      </version>
      <version>           1.4.3     17.08.2009      Victor Smirnov
                          constant c_APP_RESOURCE_BUSY added
      </version>
      <version>           1.4.2     24.10.2008      Denis Kovalchuk
                          constant c_SIM_INVALID_PS added
                          constant c_SIM_INVALID_STATUS added
                          constant c_SIM_INVALID_TYPE added
      </version>
      <version>           1.4.1     17.04.2008      Josef Hartman
                          constant c_ORA_DUP_MSISDN_BOUND added
                          constant c_UK_SIM_MSIDN_BOUND added
      </version>
      <version>           1.4.0     17.04.2008      Josef Hartman
                          constant c_PREVIOUS_STATUS_NOT_EXIST added
      </version>

      <version>           1.3.9     5.12.2006      Roger Stockley
                          constant c_ORA_UNABLE_TO_DEL_LAST_REC added
      </version>

      <version>           1.3.8     27.10.2006      Petr Cepek
                          constant c_ORA_PHONES_ALREADY_LINKED added
      </version>
      <version>           1.3.7     13.10.2006      Petr Cepek
                          constant c_ORA_CHANGE_SP_STATUS_NOT_ALW added
                          constant c_ORA_CHANGE_SS_STATUS_NOT_ALW added
      </version>
      <version>           1.3.6     20.09.2006      Petr Cepek
                          constant c_ORA_SPLITED_SERIES added
                          procedure Fill_Ap_Id_From_Na_Id deleted
      </version>
      <version>           1.3.5     23.08.2006      Petr Cepek
                          constant c_ORA_SIM_ACTIVATED added
                          constant c_ORA_SIM_and_PHONE_Range_diff added
                          constant c_ORA_less_SIMs_in_Range added
                          constant c_ORA_less_Phones_in_Range added
                          constant c_ORA_NOT_SAME_OPERATOR added
                          constant c_ORA_BS_WITH_SECTORS added
                          constant c_ORA_PHONE_PREFIX_EXISTS added
      </version>
      <version>           1.3.4     31.07.2006      Petr Cepek
                          procedure Fill_Na_Id_From_Msisdn deleted
                          procedure Fill_Ap_Id_From_Imsi deleted
                          procedure Fill_Na_Id_From_Int_Number updated
      </version>
      <version>           1.3.3     20.06.2006      Petr Cepek
                          constant c_ORA_INT_PHONE_STATUS_PERM added
                          constant c_ORA_IMSI_PREF_ID_NOT_EXISTS added
                          constant c_ORA_CHANGE_PH_STATUS_NOT_ALW added
      </version>
      <version>           1.3.2      16.06.2006     Petr Cepek
                          constant c_ORA_HOST_SERIE_NOT_EXISTS added
                          constant c_ORA_IMSI_PREFIX_EXISTS added
      </version>
      <version>           1.3.1      29.05.2006     Petr Cepek
                          constant c_ORA_RESOURCE_BUSY added
      </version>
      <version>           1.3.0      18.04.2006     Petr Cepek
                          new constants for unique keys added,
                          new constants c_SERIE_NOTFOUND_FOR_IMSI and c_HOST_NOTFOUND_FOR_SERIE,c_SIMSERIE_TYPE created,
                          new constant c_TOO_MANY_ROWS_RETRIEVED
      </version>
      <version>           1.2.9      30.03.2006     Petr Cepek
                          error constant c_ORA_SAME_HOST_SIM_SERIES added
      </version>
      <version>           1.2.8      24.01.2006     Petr Cepek
                          constants c_ORA_NOT_EXT_OPERATOR, c_ORA_SAME_NDC added
                          procedures Fill_Na_Id_From_Int_Number, Fill_Ap_Id_From_Sn updated
                          procedures Fill_Na_Id_From_Int_Number_aa,Fill_Ap_Id_From_Sn_aa,
                          Delete_Batch_Session,Delete_Base_Station_Session,Get_Batch_Session,
                          Is_Gold_Number deleted
      </version>
       <version>           1.2.7     12.01.2006     Petr Cepek
                          constant c_NO_DATA_FOUND,c_External_Net_Operator, c_ORA_IP_SERIE_OVEVERLAPED  added
      </version>
      <version>           1.2.6     28.12.2005     Petr Cepek
                          constant c_ORA_not_same_operator_type,c_ORA_operator_not_exist added
      </version>
      <version>           1.2.5     16.12.2005     Petr Cepek
                          constant c_Exchange_Usg_Type_PB added
      </version>
      <version>           1.2.4     21.11.2005     Petr Cepek
                          procedures Fill_Na_Id_From_Int_Number_aa and Fill_Ap_Id_From_Sn_aa created
      </version>
      <version>           1.2.3     17.10.2005     Petr Cepek
                          two same constant c_ORA_NOT_FREE_PHONES error fixed
      </version>
      <version>           1.2.2     10.08.2005     Petr Cepek
                          constant c_ORA_Err_Update_IMSI_Prefix added
      </version>
      <version>
                          1.2.1     15.07.2005     Petr Cepek

      </version>
      <version>
                          1.2.0      07.06.2005    Petr Cepek
                          error constants updated, procedure Handle_Error updated
      </version>

      <version>           1.0.1   10.9.2003     Petr Kout
                          created first version
      </version>

      <Description>       package provides set of usefull procedures and functions
                          performing various checks during run of the program
      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>
      </Parameters>

    </header>
  /****************************************************************************/

  TYPE REF_CURSOR IS REF CURSOR; -- ref cursor type to catch retrieved rows into a variable of this type
  TYPE Type_Packet_Of_Intervals IS TABLE OF NUMBER NOT NULL INDEX BY BINARY_INTEGER; /* TYPE for input parameter as packet of number type*/
  TYPE Type_Packet_Of_Intervals_V IS TABLE OF VARCHAR2(1023) NOT NULL INDEX BY BINARY_INTEGER; /* TYPE for input parameter as packet of varchar2 type*/

  RESOURCE_BUSY EXCEPTION;
  PRAGMA EXCEPTION_INIT(RESOURCE_BUSY,-54);

  c_OK                                CONSTANT NUMBER(3) := 0; -- constant indicating successfull completion of a function or procedure

  c_SERIE_NOTFOUND_FOR_IMSI           CONSTANT NUMBER(5) :=  -30;  -- Sim series for such an IMSI does not exist.
  c_HOST_NOTFOUND_FOR_SERIE           CONSTANT NUMBER(5) :=  -31;  -- Host does not exist for such a serie.
  c_NO_DATA_FOUND                     CONSTANT NUMBER(5) := -105;  --
  c_ROW_NOT_FOUND                     CONSTANT NUMBER(5) := -108;  -- Indicating that the row of update or delete does not exist.
  c_INVALID_INTERVAL                  CONSTANT NUMBER(5) := -110;  -- Given starting number of the interval is higher number than the ending number of the interval.
  c_TOO_MANY_ROWS_RETRIEVED           CONSTANT NUMBER(5) := -117;  -- constant indicating that "select into" statement retrieved more then expected count of rows
  c_PHONE_NUMBER_NOT_EXISTS           CONSTANT NUMBER(5) := -133;  -- constant indicating that given phone number does not exist
  c_SIM_CARD_NOT_EXISTS               CONSTANT NUMBER(5) := -134;  -- constant indicating that given sim card does not exist
  c_ACCES_POINT_NOT_EXISTS            CONSTANT NUMBER(5) := -135;  -- constant indicating that given acces point does not exist
  c_LAST_ERROR                        CONSTANT NUMBER(5) := -140;  -- constant indicating require last error
  c_SAME_NET_ADDR_STATUS              CONSTANT NUMBER(5) := -146;
  c_SIM_HAVE_PHONE_NUMBER             CONSTANT NUMBER(5) := -147;  -- constant informating, that the sim card already have assigned phone number
  c_SAME_ACC_POINT_STATUS             CONSTANT NUMBER(5) := -148;
  c_LINK_NA_AND_AP_NOT_EX             CONSTANT NUMBER(5) := -143;  -- constant informating, that the link berween network address (phone number) and access point (SIM card) not exists
  c_NOT_FREE_PHONES                   CONSTANT NUMBER(5) := -150;  -- No free phone number was found for sim card.
  c_INSERT_NET_ADDR_STAT_ERROR        CONSTANT NUMBER(5) := -183;  -- constant indicating that inserting new interval into NETWORK_ADDRESS_STATUS_HISTORY failed
  c_NOT_SAME_HOST_ID                  CONSTANT NUMBER(5) := -80;  -- constant indicating that phone and sim are not on same host
  c_SIM_ALREADY_IMPORTED              CONSTANT NUMBER(5) := -192;  -- defined oracle error number indicating that imported sim_card_exists
  c_SIM_DELETED                       CONSTANT NUMBER(5) := -193;  -- defined oracle error number indicating that sim_card_exists and is deleted
  c_BAD_PHONE_STATUS                  CONSTANT NUMBER(5) := -194;  -- Phone number status is different than expected
  c_INT_PHONE_STATUS_PERM             CONSTANT NUMBER(5) := -206;  -- User does not have a permission to operate with status Internal.
  c_CHANGE_PH_STATUS_NOT_ALW          CONSTANT NUMBER(5) := -208;  -- Status of the phone number can not be changed into this status, because of defined rules.
  c_SIM_ACTIVATED                     CONSTANT NUMBER(5) := -210;    -- Some of the SIM cards are in status activated.
  c_CHANGE_SP_STATUS_NOT_ALW          CONSTANT NUMBER(5) := -218;  -- SIM production status can not be changed into this status, because of defined rules.
  c_CHANGE_SS_STATUS_NOT_ALW          CONSTANT NUMBER(5) := -219;  -- SIM status can not be changed into this status, because of defined rules.
  c_PHONES_ALREADY_LINKED             CONSTANT NUMBER(5) := -221;  -- Phone numbers are already linked together.
  c_PREVIOUS_STATUS_NOT_EXIST         CONSTANT NUMBER(5) := -222;  -- There is only one record in network_address_status_history for given network_address
  c_SIM_INVALID_PS                    CONSTANT NUMBER(5) := -223;  -- SIM production status is invalid
  c_SIM_INVALID_STATUS                CONSTANT NUMBER(5) := -224;  -- SIM status is invalid
  c_SIM_INVALID_TYPE                  CONSTANT NUMBER(5) := -225;  -- SIM type is invalid
  c_APP_RESOURCE_BUSY                 CONSTANT NUMBER(5) := -226;  -- resource busy code for non-system (application) usage
  c_SIM_INVALID_HOST                  CONSTANT NUMBER(5) := -231;
  c_SIM_INVALID_NET_OPER              CONSTANT NUMBER(5) := -232;
  c_PHONE_INVALID_SAL_CAT             CONSTANT NUMBER(5) := -233;  -- invalid salability category
  c_PHONE_HAVE_NO_LINKED              CONSTANT NUMBER(5) := -234;  -- Phone number have no linked one.
  c_DIF_PHONE_TYPES_IN_LIST           CONSTANT NUMBER(5) := -235;  -- Different phone types in checked list.

  c_ORA_SERIE_NOTFOUND_FOR_IMSI       CONSTANT NUMBER(5) := -20030;  -- Sim series for such an IMSI does not exist.
  c_ORA_HOST_NOTFOUND_FOR_SERIE       CONSTANT NUMBER(5) := -20031;  -- defined oracle error number indicating that HOST is not found for serie
  c_ORA_NOT_SAME_HOSTS                CONSTANT NUMBER(5) := -20032;  -- Series are not on the same host.
  c_ORA_WRONG_SERIE_STATUS            CONSTANT NUMBER(5) := -20033;  -- defined oracle error number indicating that SERIE has wrong status
  c_ORA_CHAN_PHO_OPER_A_HLR_ERR       CONSTANT NUMBER(5) := -20072;  -- defined oracle error number indicating error in CHANGE_PHONE_OPERATOR_AND_HLR procedure
  c_ORA_SIM_ALREADY_IMPORTED          CONSTANT NUMBER(5) := -20081;  -- defined oracle error number indicating that imported sim_card_exists
  c_ORA_SIM_DELETED                   CONSTANT NUMBER(5) := -20082;  -- defined oracle error number indicating that sim_card_exists and is deleted
  c_ORA_OTHER_ERROR                   CONSTANT NUMBER(5) := -20100;  -- Unknown database error.
  c_ORA_INVALID_HANDLE                CONSTANT NUMBER(5) := -20101;  -- constant indicating that invalid handle_tran parameter was used
  c_ORA_DATE_OVERLAP                  CONSTANT NUMBER(5) := -20103;  -- constant indicating that given date overlaps with some date in the given table
  c_ORA_NO_DATA_FOUND                 CONSTANT NUMBER(5) := -20105;  -- constant indicating that no record was not found to be selected into a variable
  c_ORA_DELETED                       CONSTANT NUMBER(5) := -20107;  -- constant indicating that user is deleting deleted row (deleted is not null)
  c_ORA_ROW_NOT_FOUND                 CONSTANT NUMBER(5) := -20108;  -- constant indicating that the row of update or delete does not exist
  c_ORA_INVALID_PHONE_NUMBER          CONSTANT NUMBER(5) := -20109;  -- constant indicating that given phone number has wrong format (contains invalid character(s))
  c_ORA_INVALID_INTERVAL              CONSTANT NUMBER(5) := -20110;  -- constant indicating that the given starting number of the interval is higher number than the ending number of the interval
  c_ORA_DIFFERENCE_VALUES             CONSTANT NUMBER(5) := -20111;  -- constant indicating that joined sim series have differences in host id or network operator id or sim card type code
  c_ORA_IMSI_ERROR                    CONSTANT NUMBER(5) := -20112;  -- constant indicating that joined sim series have noncontinuous INSI intervals or imsi number is not a number value
  c_ORA_DIFFERENCE_HISTORY            CONSTANT NUMBER(5) := -20113;  -- constant indicating that joined sim series have not the same history
  c_ORA_UNABLE_TO_SPLIT_SERIE         CONSTANT NUMBER(5) := -20115;  -- constant indicating that given phone number serie cannot be splitted (probably because user chose too small starting number for the new serie or the splitted serie does not exist)
  c_ORA_INTERVAL_OUT_OF_BOUNDS        CONSTANT NUMBER(5) := -20116;  -- constant indicating that given the phone number that splits given serie is out of bounds of the serie
  c_ORA_TOO_MANY_ROWS_RETRIEVED       CONSTANT NUMBER(5) := -20117;  -- constant indicating that "select into" statement retrieved more then expected count of rows
  c_ORA_SERIE_BETWEEN_SERIES          CONSTANT NUMBER(5) := -20118;  -- constant indicating that between given two phone series exists another serie (so you cannot join them)
  c_ORA_NOT_SAME_OPERATORS            CONSTANT NUMBER(5) := -20119;  -- constant indicating that the joined series are owned by different operators, so they cannot be joined
  c_ORA_SERIE_DELETED                 CONSTANT NUMBER(5) := -20120;  -- One or both of the joined series are deleted or do not exist.
  c_ORA_NULL_VALUE                    CONSTANT NUMBER(5) := -20121;  -- constant indicating that insert null value into not null column or update not null column to null
  c_ORA_INVALID_DATE                  CONSTANT NUMBER(5) := -20122;  -- constant indicating that given date has no sense for given operation
  c_ORA_MISSING_PARAMETER             CONSTANT NUMBER(5) := -20123;  -- constant indicating that there is missing mandatory parameter in the function or procedure calling
  c_ORA_NOT_SAME_PHONE_TYPES          CONSTANT NUMBER(5) := -20124;  -- Series have different phone number type.
  c_ORA_NOT_SAME_PO_HISTORY           CONSTANT NUMBER(5) := -20125;  -- Both of series have not belonged to the same operator in the all history.
  c_ORA_INTERVAL_INTERFERES_A         CONSTANT NUMBER(5) := -20126;  -- constant indicating that first interval interferes into the second interval at its begining
  c_ORA_INTERVAL_INTERFERES_B         CONSTANT NUMBER(5) := -20127;  -- constant indicating that first interval interferes into the second interval at its ending
  c_ORA_INTERVAL_INTERFERES_C         CONSTANT NUMBER(5) := -20128;  -- constant indicating that first interval is contained in the scond interval
  c_ORA_INTERVAL_INTERFERES_D         CONSTANT NUMBER(5) := -20129;  -- constant indicating that first interval completely overlaps the second interval
  c_ORA_INVALID_PACKET                CONSTANT NUMBER(5) := -20130;  -- constant indicating that packet of intervals is invalid (e.g. '' or null or '::::')
  c_ORA_PORT_NUMBER_EXISTS            CONSTANT NUMBER(5) := -20131;  -- Port with same port number already exists.
  c_ORA_INVALID_PARAMETER             CONSTANT NUMBER(5) := -20132;  -- constant indicating that given parameter has no correct value
  c_ORA_PHONE_NUMBER_NOT_EXISTS       CONSTANT NUMBER(5) := -20133;  -- Phone number does not exist.
  c_ORA_SIM_CARD_NOT_EXISTS           CONSTANT NUMBER(5) := -20134;  -- Sim card does not exist.
  c_ORA_ACCES_POINT_NOT_EXISTS        CONSTANT NUMBER(5) := -20135;  -- Access point does not exist.
  c_ORA_MSISDN_ERROR                  CONSTANT NUMBER(5) := -20139;  -- constant indicating that error in msisdn
  c_ORA_PHONE_IN_SIM_SERIE_USE        CONSTANT NUMBER(5) := -20141;  -- constant informating, that the given sim series is not possible delete because some sim card in this series is use
  c_ORA_INSERT_INTERVAL_ERROR         CONSTANT NUMBER(5) := -20142;  -- constant informating, that the found phone numbers are not assigned to sim card
  c_ORA_NO_CHANGE_CATEGORY            CONSTANT NUMBER(5) := -20144;  -- constant informating, that value of category is not changed
  c_ORA_REFERENCED                    CONSTANT NUMBER(5) := -20145;  -- constant indicating that at least one record in table has reference to this row
  c_ORA_SAME_NET_ADDR_STATUS          CONSTANT NUMBER(5) := -20146;  -- constant informating, that given network address status have same value like old status
  c_ORA_SIM_HAVE_PHONE_NUMBER         CONSTANT NUMBER(5) := -20147;  -- constant informating, that the sim card already have assigned phone number
  c_ORA_SAME_ACC_POINT_STATUS         CONSTANT NUMBER(5) := -20148;  -- constant informating, that given access point status have same value like previous status
  c_ORA_RECORD_NOT_FOUND              CONSTANT NUMBER(5) := -20149;  -- constant informating, that record did not find for given date
  c_ORA_NOT_FREE_PHONES               CONSTANT NUMBER(5) := -20150;  -- constant informating, that free phone number for sim card was not found
  c_ORA_FILL_ACC_POINT_ERROR          CONSTANT NUMBER(5) := -20151;  -- constant informating, that fill access point error
  c_ORA_UNIQ_KEY_NET_OPER_CODE        CONSTANT NUMBER(5) := -20155;  -- constant indicating that given value of network operator code allready exists in the column and the column has a unique key
  c_ORA_UNIQ_KEY_NET_OPER_NAME        CONSTANT NUMBER(5) := -20156;  -- constant indicating that given value of network operator name allready exists in the column and the column has a unique key
  c_ORA_UNIQ_KEY_HOST_CODE            CONSTANT NUMBER(5) := -20157;  -- constant indicating that given value of host code allready exists in the column and the column has a unique key
  c_ORA_UNIQ_KEY_HOST_NAME            CONSTANT NUMBER(5) := -20158;  -- constant indicating that given value of host name allready exists in the column and the column has a unique key
  c_ORA_UNIQ_KEY_LOC_AREA_CODE        CONSTANT NUMBER(5) := -20159;  -- Location area with this location area code already exists.
  c_ORA_UNIQ_KEY_LOC_AREA_NAME        CONSTANT NUMBER(5) := -20160;  -- Location area with this location area name already exists.
  c_ORA_UNIQ_KEY_BASE_STAT_CODE       CONSTANT NUMBER(5) := -20161;  -- Base station with this base station code already exists.
  c_ORA_UNIQ_KEY_BASE_STAT_NAME       CONSTANT NUMBER(5) := -20162;  -- Base station with this base station name already exists.
  c_ORA_UNIQ_KEY_ZONE_CODE            CONSTANT NUMBER(5) := -20163;  -- Zone with this zone code already exists.
  c_ORA_UNIQ_KEY_ZONE_NAME            CONSTANT NUMBER(5) := -20164;  -- Zone with this zone name already exists.
  c_ORA_UNIQ_KEY_PAY_DESK_CODE        CONSTANT NUMBER(5) := -20165;  -- constant indicating that given value of pay desk code allready exists in the column and the column has a unique key
  c_ORA_UNIQ_KEY_PAY_DESK_SN          CONSTANT NUMBER(5) := -20166;  -- constant indicating that given value of pay desk serial number allready exists in the column and the column has a unique key
  c_ORA_SAME_SALABILITY_CODE          CONSTANT NUMBER(5) := -20167;  -- Salability category can not be changed to the same value.
  c_ORA_SAME_SIM_SERIES_STATUS        CONSTANT NUMBER(5) := -20168;  -- constant indicating that given sim series status have same value like old status
  c_ORA_UNIQ_KEY_PAY_ENTR_NAME        CONSTANT NUMBER(5) := -20169;  -- constant indicating that the given value of payment entrance name allready exists in the column and the column has a unique key
  c_ORA_HOST_DELETED                  CONSTANT NUMBER(5) := -20170;  -- constant indicating that the given host can not be use because the host is deleted
  c_ORA_NOT_VALID_STATUS              CONSTANT NUMBER(5) := -20171;  -- constant indicating that sim serie status is not possible to change in the given status
  c_ORA_STATUS_NOT_CHANGE             CONSTANT NUMBER(5) := -20172;  -- constant indicating that sim serie has statu PRODUCED and this status is not possible to change
  c_ORA_SAME_PHONE_SERIE_TYPE         CONSTANT NUMBER(5) := -20173;  -- constant indicating that the given phone serie type have same value like old code
  c_ORA_SAME_PHONE_OPERATOR           CONSTANT NUMBER(5) := -20174;  -- constant indicating that the given phone serie operator have same value like old code
  c_ORA_UNIQ_KEY_PAY_DESK_NAME        CONSTANT NUMBER(5) := -20175;  -- constant indicating that given value of pay desk name allready exists in the column and the column has a unique key
  c_ORA_USER_NOT_FOUND                CONSTANT NUMBER(5) := -20176;  -- constant indicating that the given user was not found
  c_ORA_SAME_PHONE_SERIE_HLR          CONSTANT NUMBER(5) := -20177;  -- constant indicating that the given phone serie host code have same value like old host code
  c_ORA_PHONE_IN_PHONE_SER_USE        CONSTANT NUMBER(5) := -20178;  -- constant informating, that the given phone number series is not possible delete because some phone number in this series is use
  c_ORA_UNIQ_KEY_USER_NAME            CONSTANT NUMBER(5) := -20179;  -- constant indicating that the given value of user name allready exists in the column and the column has a unique key
  c_ORA_UNIQ_KEY_USER_LOG_NAME        CONSTANT NUMBER(5) := -20180;  -- constant indicating that the given value of login name allready exists in the column and the column has a unique key
  c_ORA_START_AND_END_REVERSE         CONSTANT NUMBER(5) := -20181;  -- constant indicating that the given value of END number is smaller than START number
  c_ORA_INTERVAL_OVERLAP              CONSTANT NUMBER(5) := -20184;  -- constant indicating that given serie interval overlaps with some exists interval
  c_ORA_WRONG_CURSOR                  CONSTANT NUMBER(5) := -20185;  -- constant indicating that is some problem with cursor (opening, close)
  c_ORA_BULK_ERROR                    CONSTANT NUMBER(5) := -20186;  -- constant indicating taht is some problem with collections
  c_ORA_UNABLE_TO_DELETE              CONSTANT NUMBER(5) := -20187;  -- constant indicating that you are unable to delete rocord due to of existence of child record...
  c_ORA_UNABLE_CHANGE_NETSTATUS       CONSTANT NUMBER(5) := -20188;  -- constant indicating that you are unable to change network address status to another/ disallowed state change
  c_ORA_UNABLE_TO_GET_NEXT_IP         CONSTANT NUMBER(5) := -20189;  -- constant indicating that you are unable to get next IP
  c_ORA_NOT_SAME_IP_NETWORK           CONSTANT NUMBER(5) := -20190;  -- constant indicating that these 2 IP addresses are not on same network
  c_ORA_Phone_Serie_NOT_Exists        CONSTANT NUMBER(5) := -20191;  -- Phone number serie does not exist.
  c_ORA_BAD_PHONE_STATUS              CONSTANT NUMBER(5) := -20194;  -- Phone number status is different than expected
  c_ORA_Err_Update_IMSI_Prefix        CONSTANT NUMBER(5) := -20195;  -- IMSI prefix can not be updated. It is used for more than one network operators.
  c_ORA_change_host_phone_used        CONSTANT NUMBER(5) := -20196;  -- Host can not be changed because some phone numbers are linked with sim cards.
  c_ORA_not_same_operator_type        CONSTANT NUMBER(5) := -20197;  -- Network operator can not be change, because of different operator type.
  c_ORA_operator_not_exist            CONSTANT NUMBER(5) := -20198;  -- Appropriate network operator does not exist.
  c_ORA_IP_SERIE_OVEVERLAPED          CONSTANT NUMBER(5) := -20199;  -- Inserted IP serie overlap other IP serie.
  c_ORA_NOT_EXT_OPERATOR              CONSTANT NUMBER(5) := -20200;  -- Network operator is not external operator.
  c_ORA_SAME_NDC                      CONSTANT NUMBER(5) := -20201;  -- This NDC was already assigned to this phone serie.
  c_ORA_SAME_HOST_SIM_SERIES          CONSTANT NUMBER(5) := -20202;  -- This host was already assigned to this sim serie.
  c_ORA_RESOURCE_BUSY                 CONSTANT NUMBER(5) := -20203;  -- This operation could not be finished because is executed by other user in this time.
  c_ORA_HOST_SERIE_NOT_EXISTS         CONSTANT NUMBER(5) := -20204;  -- Sim serie has no host assigned of this type.
  c_ORA_IMSI_PREFIX_EXISTS            CONSTANT NUMBER(5) := -20205;  -- This imsi prefix is already assigned to some network operator in current time.
  c_ORA_INT_PHONE_STATUS_PERM         CONSTANT NUMBER(5) := -20206;  -- User does not have a permission to operate with status Internal.
  c_ORA_IMSI_PREF_ID_NOT_EXISTS       CONSTANT NUMBER(5) := -20207;  -- Imsi prefix ID does not exist.
  c_ORA_CHANGE_PH_STATUS_NOT_ALW      CONSTANT NUMBER(5) := -20208;  -- Status of the phone number can not be changed into this status, because of defined rules.
  c_ORA_UNABLE_TO_DEL_LAST_REC        CONSTANT NUMBER(5) := -20209;  -- The user has attempted to delete the last remaining record when it is not permitted.
  c_ORA_WRONG_PH_STATUS               CONSTANT NUMBER(5) := -20239;  -- Status of the phone number is wrong.
  c_ORA_DIF_LINKED_PH_NA_STATUS       CONSTANT NUMBER(5) := -20240;  -- Linked phones have different network address status.


 -- I_CRM
  c_ORA_SIM_ACTIVATED                 CONSTANT NUMBER(5) := -20210;  -- Some of the SIM cards are in status activated.
  c_ORA_SIM_and_PHONE_Range_diff      CONSTANT NUMBER(5) := -20211;  -- SIM and phone ranges have different size.
  c_ORA_less_SIMs_in_Range            CONSTANT NUMBER(5) := -20212;  -- Not enought SIM cards for linking with phone numbers.
  c_ORA_less_Phones_in_Range          CONSTANT NUMBER(5) := -20213;  -- Not enought phone numbers for linking with SIM cards.
  c_ORA_EXCHANGE_NOT_EXISTS           CONSTANT NUMBER(5) := -20214;  -- Exchange not exists for creating new ports.

  c_ORA_BS_WITH_SECTORS               CONSTANT NUMBER(5) := -20215;  -- Base station can not be deleted because of having valid sectors.
  c_ORA_PHONE_PREFIX_EXISTS           CONSTANT NUMBER(5) := -20216;  -- Phone prefix already exists.
  c_ORA_SPLITED_SERIES                CONSTANT NUMBER(5) := -20217;  -- Series do not concur to each other.
  c_ORA_CHANGE_SP_STATUS_NOT_ALW      CONSTANT NUMBER(5) := -20218;  -- SIM production status can not be changed into this status, because of defined rules.
  c_ORA_CHANGE_SS_STATUS_NOT_ALW      CONSTANT NUMBER(5) := -20219;  -- SIM status can not be changed into this status, because of defined rules.
  c_ORA_DUP_ICCID                     CONSTANT NUMBER(5) := -20220;  -- During generation of sim card was created sim card with ICCID, which already exists.

  c_ORA_PHONES_ALREADY_LINKED         CONSTANT NUMBER(5) := -20221;  -- Phone numbers are already linked together.
  c_ORA_DUP_MSISDN_BOUND              CONSTANT NUMBER(5) := -20222;  -- During generation of sim card was created sim card with MSISDN_BOUND, which already exists.

  c_ORA_NET_OPERATOR_NOT_EXIST        CONSTANT NUMBER(5) := -20230;  -- Network operator does not exist.

  c_ORA_VERY_BIG_VALUE                CONSTANT NUMBER(5) := -20300;  -- constant indicating that given parameter has very big value

  C_ORA_BAD_PHONE_RANGE               CONSTANT NUMBER(5) := -20301;

  c_ORA_DP_ALREADY_EXISTS             CONSTANT NUMBER(5) := -20302;  -- Distribution platform already exists.
  c_ORA_DP_NOT_FOUND                  CONSTANT NUMBER(5) := -20303;  -- Distribution platform is not found.
  c_ORA_DP_DELETED                    CONSTANT NUMBER(5) := -20304;  -- Distribution platform is deleted.
  c_ORA_DP_HOST_NOT_FOUND             CONSTANT NUMBER(5) := -20305;  -- Host is not found.
  c_ORA_DP_HOST_DELETED               CONSTANT NUMBER(5) := -20306;  -- Host is deleted.
  c_ORA_SIM_CARD_IS_LOCKED            CONSTANT NUMBER(5) := -20400;  -- The user has attempted to update locked sim card.
  c_ORA_PHONE_NUMBER_IS_LOCKED        CONSTANT NUMBER(5) := -20401;  -- The user has attempted to update locked phone number.

  -- set constrainst name

  c_UK_NETWORK_OPERATOR_CODE   CONSTANT VARCHAR2(30) := 'UK_NETWORK_OPERATOR_CODE';
  c_UK_HOST_CODE               CONSTANT VARCHAR2(30) := 'UK_HOST_CODE';
  c_UK_LOCATION_AREA           CONSTANT VARCHAR2(30) := 'UK_LOCATION_AREA'; -- LOCATION AREA NAME
  c_UK_LOCATION_AREA_CODE      CONSTANT VARCHAR2(30) := 'UK_LOCATION_AREA_CODE'; -- LOCATION AREA CODE
  c_UK_BASE_STATION            CONSTANT VARCHAR2(30) := 'UK_BASE_STATION'; -- BASE STATION NAME
  c_UK_BASE_STATION_CODE       CONSTANT VARCHAR2(30) := 'UK_BASE_STATION_CODE'; -- BASE STATION CODE
  c_UK_ZONE                    CONSTANT VARCHAR2(30) := 'UK_ZONE'; -- ZONE NAME
  c_UK_ZONE_CODE               CONSTANT VARCHAR2(30) := 'UK_ZONE_CODE'; -- ZONE CODE
  c_UK_PAY_DESK_CODE           CONSTANT VARCHAR2(30) := 'UK_PAY_DESK_CODE'; -- PAY DESK CODE
  c_UK_PAYMENT_ENTRANCE_NAME   CONSTANT VARCHAR2(30) := 'UK_PAYMENT_ENTRANCE_NAME'; -- PAYMENT ENTRANCE NAME
  c_UK_PAY_DESK_NAME           CONSTANT VARCHAR2(30) := 'UK_PAY_DESK_NAME'; -- PAY DESK NAME
  c_UK_USER_NAME               CONSTANT VARCHAR2(30) := 'UK_USER_NAME'; -- USER NAME
  c_UK_EXCHANGE_PORT           CONSTANT VARCHAR2(30) := 'UK_EXCHANGE_PORT';
  c_UK_SIM_SN                  CONSTANT VARCHAR2(30) := 'UK_SIM_SN';
  c_UK_SIM_MSIDN_BOUND         CONSTANT VARCHAR2(30) := 'UK_SIM_MSIDN_BOUND';

  -- set of handle_tran parameter possible values
  c_HANDLE_TRAN_S              CONSTANT CHAR(1) := 'S'; -- constant representing 'S' value of the handle_tran parameter
  c_HANDLE_TRAN_Y              CONSTANT CHAR(1) := 'Y'; -- constant representing 'Y' value of the handle_tran parameter
  c_HANDLE_TRAN_N              CONSTANT CHAR(1) := 'N'; -- constant representing 'N' value of the handle_tran parameter

  c_DEBUG_TO_BUFFER            CONSTANT VARCHAR2(6) := 'BUFFER'; -- constant informating that the debug output will be performed by DBMS_OUTPUT package
  c_DEBUG_TO_FILE              CONSTANT VARCHAR2(6) := 'FILE'; -- constant informating that the debug output will be performed to a text file
  c_DEBUG_TO_TABLE             CONSTANT VARCHAR2(6) := 'TABLE'; -- constant informating that the debug output will be performed to a table
  c_MAX_DEBUG_LEVEL            CONSTANT NUMBER(1) := 3; -- constant setting the maximum debug level number
  c_IS_PHONE_FREE_YES          CONSTANT CHAR(1) := 'Y'; -- constant informating, that the given phone number is free (used in Is_Phone_Free function)
  c_IS_PHONE_FREE_NO           CONSTANT CHAR(1) := 'N'; -- constant informating, that the given phone number is not free (used in Is_Phone_Free function)
  c_IT_IS_MY_PHONE             CONSTANT CHAR(1) := 'Y'; -- constant informating, that the given phone number is a phone number of the given network_operator
  c_IT_IS_NOT_MY_PHONE         CONSTANT CHAR(1) := 'N'; -- constant informating, that the given phone number is not a phone number of the given network_operator
  c_FREE_PHONE_NUMBER_CODE     CONSTANT CHAR(1) := 'F'; -- constant representing value in NETWORK_ADDRESS_STATUS table indicating, that the given phone number is free
  c_RESERVE_PHONE_NUMBER_CODE  CONSTANT CHAR(1) := 'R'; -- constant representing value in NETWORK_ADDRESS_STATUS table indicating, that the given phone number is reserved
  c_USED_PHONE_NUMBER_CODE     CONSTANT CHAR(1) := 'U'; -- constant representing value in NETWORK_ADDRESS_STATUS table indicating, that the given phone number is used
  c_OTHER_PHONE_NUMBER_CODE    CONSTANT CHAR(1) := 'O'; -- constant representing value in NETWORK_ADDRESS_STATUS table indicating, that the given phone number is other billing
  c_NOT_USED_PHONE_NUMBER_CODE CONSTANT CHAR(1) := 'N'; -- constant representing value in NETWORK_ADDRESS_STATUS table indicating, that the given phone number is not used
  c_INTERNAL_PHONE_NUMBER_CODE CONSTANT CHAR(1) := 'I'; -- constant representing value Internal in NETWORK_ADDRESS_STATUS table
  c_SET_ACESPOINT_HOST_CONN    CONSTANT CHAR(1) := 'N'; -- constant representing that while import sim cards we set also connection between accesspoint and host (VALUE 'Y' means yes set connection, value 'N' means that we don't
  c_ACCESSPOINT_STATUS_DEFAULT CONSTANT CHAR(1) := 'N'; -- default access point staus ('N' - not activated on HLR)
  c_OPTIMIZE_YES               CONSTANT CHAR(1) := 'Y'; -- constant for defining if turn on optimization in fynction split sim series for import
  c_OPTIMIZE_NO                CONSTANT CHAR(1) := 'N'; -- constant for defining if turn on optimization in fynction split sim series for import
  c_ERROR                      CONSTANT NUMBER(1) := -1; -- constant representing error code returned by functions if there occurs an error during their performing
  c_FALSE                      CONSTANT NUMBER(1) := 1; -- constant representing result number 1, which represents boolean value FALSE (used in function as return value)
  c_GOLD_SAL_CATEGORY          CONSTANT VARCHAR2(6) := 'G'; -- constant representing "GOLD" salability category
  c_STANDARD_SAL_CATEGORY      CONSTANT VARCHAR2(6) := 'N'; -- constant representing "STANDARD" salability category
  c_PRODUCED_SIM_S_STAT_CODE   CONSTANT VARCHAR2(6) := 'P'; -- constant representing "PRODUCED" sim series status
  c_IN_PRODC_SIM_S_STAT_CODE   CONSTANT VARCHAR2(6) := 'I'; -- constant representing "IN PRODUCE" sim series status
  c_HOST_TYPE_CODE_MSC         CONSTANT VARCHAR2(2) := 'MS'; -- constant representing value HOST_TYPE.HOST_TYPE_CODE = 'MSC'
  c_HOST_TYPE_CODE_HLR         CONSTANT VARCHAR2(2) := 'HL'; -- constant representing value HOST_TYPE.HOST_TYPE_CODE for host type of HLR
  c_HOST_TYPE_CODE_EX          CONSTANT VARCHAR2(2) := 'EX'; -- constant representing value HOST_TYPE.HOST_TYPE_CODE for host type of EX
  c_INTERVAL_DIFFERENCE        CONSTANT NUMBER := 1 / (24 * 60 * 60); -- difference between end_date and start_date of the next interval
  c_MAIN_LINK_TYPE             CONSTANT CHAR(1) := 'M'; -- "MAIN" link type between network address and access point
  c_SECOND_LINK_TYPE           CONSTANT CHAR(1) := 'S'; -- "SECOND" link type between network address and access point
  c_PRODUCED                   CONSTANT CHAR(1) := 'P'; -- constant representing 'P' value of the SIM_SERIE_STATUS
  c_PHONE_BIND                 CONSTANT NUMBER(1) := 1; --constant representing that phone is bind to access_point
  c_PHONE_NOT_BIND             CONSTANT NUMBER(1) := 0; --constant representing that phone is bind to access_point
  c_JOB_ADMIN_ID               CONSTANT NUMBER(9) := 1; --constant defined user ID of change of administrator which is responsible of JOB management
  c_External_Net_Operator      CONSTANT CHAR(2) := 'EX'; -- constant represents external operator code

  c_DEBUG_LEVEL_0              CONSTANT NUMBER := 0; -- constant representing value debug level
  c_DEBUG_LEVEL_1              CONSTANT NUMBER := 1;
  c_DEBUG_LEVEL_2              CONSTANT NUMBER := 2;
  c_DEBUG_LEVEL_3              CONSTANT NUMBER := 3;
  c_DEBUG_EVENT_TYPE_I         CONSTANT VARCHAR2(2) := 'I'; -- constant representing value debug event type
  c_DEBUG_EVENT_TYPE_W         CONSTANT VARCHAR2(2) := 'W';
  c_DEBUG_EVENT_TYPE_ER        CONSTANT VARCHAR2(2) := 'Er';
  c_DEBUG_EVENT_TYPE_D         CONSTANT VARCHAR2(2) := 'D';
  c_DEBUG_EVENT_TYPE_EX        CONSTANT VARCHAR2(2) := 'Ex';
  c_DEBUG_EVENT_TYPE_A         CONSTANT VARCHAR2(2) := 'A';
  c_DEBUG_TEXT_START           CONSTANT VARCHAR2(5) := 'start';
  c_DEBUG_TEXT_END             CONSTANT VARCHAR2(3) := 'end';
  c_DEBUG_TEXT_BEFORE_LOOP     CONSTANT VARCHAR2(11) := 'before loop';
  c_DEBUG_TEXT_IN_LOOP         CONSTANT VARCHAR2(7) := 'in loop';
  c_DEBUG_TEXT_AFTER_LOOP      CONSTANT VARCHAR2(10) := 'after loop';
  c_DEBUG_TEXT_BEFORE_SELECT   CONSTANT VARCHAR2(13) := 'before select';
  c_DEBUG_TEXT_AFTER_SELECT    CONSTANT VARCHAR2(12) := 'after select';

  c_NOT_ACTIVATED_SIM_STATUS   CONSTANT CHAR(1) :='N';
  c_ACTIVATED_SIM_STATUS       CONSTANT VARCHAR2(1) :='A';

  c_MIN_DATE CONSTANT DATE := TO_DATE('01.01.1900', 'DD.MM.YYYY'); -- constant representing min value for data parameter

  c_SYNCHRONIZATION_FULL        CONSTANT CHAR(1) := '1';
  c_SYNCHRONIZATION_INCREMENTAL CONSTANT CHAR(1) := '0';
  c_SYNCHRONIZATION_ADD         CONSTANT CHAR(1) := '0';
  c_SYNCHRONIZATION_SUB         CONSTANT CHAR(1) := '1';

  c_PORT_TYPE                   CONSTANT CHAR(1) := 'P'; -- constant for select history AP  by phone number - PORT
  c_SIMCARD_TYPE                CONSTANT CHAR(1) := 'S'; -- constant for select history AP  by phone number - SIMCARD
  c_SIMSERIE_TYPE               CONSTANT CHAR(2) := 'SS';

  c_PHONE_TYPE_EXTERNAL         CONSTANT VARCHAR(2) := 'E'; -- External phone type
  c_PHONE_STATUS_E              CONSTANT CHAR(1) := 'E'; -- External phone status --!!! CHAR(1) NOT CHAR(2)

  c_YES                         CONSTANT CHAR(1) := 'Y';
  c_NO                          CONSTANT CHAR(1) := 'N';
  c_MULTI_SIM_CARD              CONSTANT CHAR(1) := 'M'; -- constant that indicates that sim card is able to hold more then one phone_number
  c_SINGLE_SIM_CARD             CONSTANT CHAR(1) := 'S'; -- constant that indicates that sim card is able to hold only one phone_number

  c_DB_PARAM_OUTPUT             CONSTANT VARCHAR2(50) := 'OUTPUT'; -- constants for name of db parameter
  c_DB_PARAM_DEBUG_LEVEL        CONSTANT VARCHAR2(50) := 'DEBUG_LEVEL'; -- constants for name of db parameter

  v_debug_level                 NUMBER DEFAULT c_DEBUG_LEVEL_0; -- debug level set by Set_Debug_Level procedure
  v_output                      VARCHAR2(2000) DEFAULT c_DEBUG_TO_BUFFER; -- where to send output from Rsi_Debug function
  v_exist_db_params             NUMBER DEFAULT 0; -- test if exists db_parameters table

  c_Exchange_Usg_Type_PB        CONSTANT CHAR(2) := 'PB'; -- constant representing usage type of exchange for PBX exchange
  c_GUI_ROLE                    CONSTANT VARCHAR2(3) :='GUI';
  c_CRM_ROLE                    CONSTANT VARCHAR2(3) :='CRM';
  c_OFS_Phone_Type              CONSTANT PHONE_NUMBER_SERIES.PHONE_NUMBER_TYPE_CODE%TYPE := 'P2';

  c_any_object_mask             constant varchar2(1) := '%';

  /****************************************************************************
    <header>
      <name>              procedure Check_Interval_Overlapping
      </name>

      <author>            Petr Kout - GITUS
      </author>

      <version>           1.0.1   11.9.2003     Petr Kout
                                  created first version
      </version>

      <Description>       procedure checks if interval given as parameter
                          overlaps with some interval in the give table;
                          if it does then raise error
      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        error_code
                          p_start_date - the starting date of the interval
                          p_end_date - the ending date of the interval
                          p_table_name - the name of the table containing
                            the intervals we compare the interval given in the
                            first two parameters with
      </Parameters>

    </header>
  /****************************************************************************/

  FUNCTION Check_Interval_Overlapping
  (
    ERROR_CODE   OUT NUMBER,
    p_start_date IN DATE, -- the starting date of an interval
    p_end_date   IN DATE DEFAULT NULL, -- the ending date of an interval
    p_table_name IN VARCHAR2 -- the name of the table containing the intervals we compare given interval in the first two parameters with
  ) RETURN NUMBER;

  /****************************************************************************
    <header>
      <name>              FUNCTION Get_Constraint_Name
      </name>

      <author>            Pavel Stengl - STROM
      </author>

      <version>           1.0.1   20.2.2004     Pavel Stengl
                                  created first version
      </version>

      <Description>       function returnes part of text of standard error mesage
      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>
      </Parameters>

    </header>
  /****************************************************************************/

  FUNCTION Get_Constraint_Name(err_msg IN VARCHAR2) RETURN VARCHAR2;

  /****************************************************************************
    <header>
      <name>              function Handle_Error
      </name>

      <author>            Petr Kout - GITUS
      </author>
      <version>           1.0.2   4.6.2003     Jaroslav Holub
                                  added c_ORA_UNABLE_CHANGE_NETSTATUS handle
      </version>


      <version>           1.0.1   11.9.2003     Petr Kout
                                  created first version
      </version>

      <Description>       function handles ORA error in its parameter and
                          returns appropriate error_code
      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>
      </Parameters>

    </header>
  /****************************************************************************/

  FUNCTION Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;

  /****************************************************************************
    <header>
      <name>              procedure Set_Output
      </name>

      <author>            Petr Kout - GITUS
      </author>

      <version>           1.0.1   12.9.2003     Petr Kout
                                  created first version
      </version>

      <Description>       procedure sets output where to send output from
                          Rsi_Debug procedure
      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        p_output -- where to send output from Rsi_Debug function
                            where to send output (RSIG_UTILS.c_DEBUG_TO_BUFFER, RSIG_UTILS.c_DEBUG_TO_FILE)
      </Parameters>

    </header>
  /****************************************************************************/

  PROCEDURE Set_Output(p_output VARCHAR2 -- where to send output from Rsi_Debug function
                       );

  /****************************************************************************
    <header>
      <name>              procedure Set_Level
      </name>

      <author>            Petr Kout - GITUS
      </author>

      <version>           1.0.1   12.9.2003     Petr Kout
                                  created first version
      </version>

      <Description>       procedure sets level of debuging from Debug_Rsi procedure
      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        p_level -- level of debugging
      </Parameters>

    </header>
  /****************************************************************************/

  PROCEDURE Set_Level(p_level VARCHAR2 -- level of debugging
                      );

  /****************************************************************************
    <header>
      <name>              procedure Debug_Rsi
      </name>

      <author>            Petr Kout - GITUS
      </author>

      <version>           1.0.2     18.05.2011      Victor Smirnov
                          procedure Debug_Rsi updated (validated)
      </version>
      <version>           1.0.1   11.9.2003     Petr Kout
                                  created first version
      </version>

      <Description>       procedure offers various outputs from code while
                          debuging. Just put calling of this procedure in the
                          code where you want to see outputs and run the
                          debuged procedure or function.
                          Levels of debuging:
                          0: No debuging is performed
                          1: Time of running and ending the subprogram
                          2: Before loop and after loop and before a large
                             select statement and after a large before statement
                          3: Each cycle iteration
      </Description>

      <Prerequisites>     Hard-coded 'Called in' and 'Text' strings in dbms_output
                            of this procedure calling. Hard-coded error message displayed
                            when user enters invalid p_event_type parameter.
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        p_text - text to send to output
                          p_level - level of debuging
                          p_event_type - event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                          p_event_source - name of the source where this calling is performed
      </Parameters>
    </header>
  /****************************************************************************/

  PROCEDURE Debug_Rsi
  (
    p_text         LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
    p_level        NUMBER, -- level of debuging
    p_event_type   LOG_EVENT.EVENT_TYPE%TYPE, -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
    p_event_source LOG_EVENT.EVENT_SOURCE%TYPE -- name of the source where this calling is performed
  );


  /****************************************************************************
    <header>
      <name>              function Is_Serie_Between
      </name>

      <author>            Petr Kout - GITUS
      </author>

      <version>           1.0.1   19.9.2003     Petr Kout
                                  created first version
      </version>

      <Description>       if between given two series exists another
                          serie, return 0, else return 1; if there
                          occurs an error, return -1
      </Description>

      <Prerequisites>

      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        error_code
                          p_phone_number_serie_id1 - id of the first phone number serie
                          p_phone_number_serie_id2 - id of the second phone number serie
      </Parameters>

    </header>
  /****************************************************************************/

  FUNCTION Is_Serie_Between
  (
    ERROR_CODE               OUT NUMBER,
    p_phone_number_serie_id1 IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE, -- id of the first phone number serie
    p_phone_number_serie_id2 IN PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE -- id of the second phone number serie
  ) RETURN NUMBER;

  /****************************************************************************
    <header>
      <name>              function Get_Packet_Of_Intervals
      </name>

      <author>            Radek Hejduk - GITUS
      </author>

      <version>           1.0.3 13.05.2005    Radomir Lipka
                  add condition column DELETED must be null
      </version>
      <version>           1.0.2 13.02.2004    Jaroslav Holub
                  test if series has same local, area code
      </version>
      <version>           1.0.1   19.9.2003     Radek Hejduk
                                  created first version
      </version>

      <Description>       function transfers varchar input packet of intervals to PL/SQL table
                          if returned Table_Of_Val is not empty that function return 0,
                          else return -1
      </Description>

      <Prerequisites>

      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        Packet_Of_Val - in - varchar2 (packet of intervals as varchar2,
                                       delemiter is ':' (e.g. ':10:11:12:' or '10:11:12'))
                          Table_Of_Val - out - RSIG_UTILS.Type_Packet_Of_Intervals (packet of intervals
                                       as PL/SQL table)
      </Parameters>

    </header>
  /****************************************************************************/

  FUNCTION Get_Packet_Of_Intervals
  (
    Packet_Of_Val IN VARCHAR2,
    Table_Of_Val  OUT RSIG_UTILS.Type_Packet_Of_Intervals
  ) RETURN NUMBER;

  /****************************************************************************
    <header>
      <name>              function Get_Packet_Of_Intervals_V
      </name>

      <author>            Radek Hejduk - GITUS
      </author>

      <version>           1.0.1   19.9.2003     Radek Hejduk
                                  created first version
      </version>

      <Description>       function transfers varchar input packet of intervals to PL/SQL table
                          if returned Table_Of_Val is not empty that function return 0,
                          else return -1
      </Description>

      <Prerequisites>

      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        Packet_Of_Val - in - varchar2 (packet of intervals as varchar2,
                                       delemiter is ':' (e.g. ':10:11:12:' or '10:11:12'))
                          Table_Of_Val - out - RSIG_UTILS.Type_Packet_Of_Intervals (packet of intervals
                                       as PL/SQL table)
      </Parameters>

    </header>
  /****************************************************************************/

  FUNCTION Get_Packet_Of_Intervals_V
  (
    Packet_Of_Val IN VARCHAR2,
    Table_Of_Val  OUT RSIG_UTILS.Type_Packet_Of_Intervals_V
  ) RETURN NUMBER;

  /****************************************************************************
  <header>
    <name>              procedure Fill_Na_Id_From_Msisdn
    </name>

    <author>            Csaba Filip - GITUS
    </author>

      <version>           1.1.1   26.5.2004      Jaroslav Holub
                                add update of result to c_ok if is NULL
      </version>
    <version>          1.1    3.2.2004      Lucie Sevcikova
                              optimized
    </version>
    <version>          1.0.2  4.12.2003     Csaba Filip
                            created first version
    </version>

    <Description>       Procedure operates over the table TMP_BATCH_NET_ADDR_ACC_POINT.
                        Procedure reads data from column NETWORK_ADDRESS_DESC (where phone number
                        in federal format = area code + local number is stored) for given batch session.
                        For each phone number procedure finds appropriate network_address_id and fills
                        it into column NETWORK_ADDRESS_ID. If for some phone number the network_address_id
                        does not exist, then c_PHONE_NUMBER_NOT_EXISTS will be filled into the column result,
                        procedure ends successfully in this case.

    </Description>

    <Prerequisites>
                        Exists function:
                          RSIG_UTILS.Debug_Rsi
                          RSIG_UTILS.Handle_Error
                        Exists variable:
                          RSIG_UTILS.c_OK
                          RSIG_UTILS.c_DEBUG_TEXT_START
                          RSIG_UTILS.c_DEBUG_LEVEL_1
                          RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                          RSIG_UTILS.c_HANDLE_TRAN_S
                          RSIG_UTILS.c_HANDLE_TRAN_Y
                          RSIG_UTILS.c_HANDLE_TRAN_N
                          RSIG_UTILS.c_ORA_INVALID_HANDLE
                          RSIG_UTILS.c_ORA_MISSING_PARAMETER
                          RSIG_UTILS.c_DEBUG_LEVEL_2
                          RSIG_UTILS.c_DEBUG_LEVEL_3
                          RSIG_UTILS.c_DEBUG_LEVEL_0
                          RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                          RSIG_UTILS.c_DEBUG_TEXT_END
                          RSIG_UTILS.c_DEBUG_TEXT_BEFORE_LOOP
                          RSIG_UTILS.c_DEBUG_TEXT_IN_LOOP
                          RSIG_UTILS.c_DEBUG_TEXT_AFTER_LOOP
                          RSIG_UTILS.c_PHONE_NUMBER_NOT_EXISTS
    </Prerequisites>

    <Application>       Resource inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y - handle tran
                                    allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                     RSIG_UTILS.c_HANDLE_TRAN_Y
                                                     RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code OUT NUMBER
                        p_batch_session_id IN - Batch session identification

    </Parameters>

  </header>
  ****************************************************************************/
  /*PROCEDURE Fill_Na_Id_From_Msisdn(
      handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
      error_code OUT NUMBER,
      p_batch_session_id IN TMP_BATCH_NET_ADDR_ACC_POINT.BATCH_SESSION_ID%TYPE
  );
  */
  /****************************************************************************
  <header>
    <name>              procedure Fill_Na_Id_From_Int_Number
    </name>

    <author>            Csaba Filip - GITUS
    </author>
    <version>           1.1.3  16.2.2006      Petr Cepek
                        use for temporary table TT_BATCH_NA_AP
    </version>
      <version>           1.1.2 30.9.2004      Jaroslav Holub
                  improve performance
      </version>
      <version>           1.1.1 26.5.2004      Jaroslav Holub
                  add update of result to c_ok if is NULL
      </version>
      <version>           1.1   3.2.2004      Lucie Sevcikova
                  optimized
      </version>
      <version>           1.0.2 4.12.2003     Csaba Filip
                  created first version
      </version>

    <Description>       Procedure operates over the table TMP_BATCH_NET_ADDR_ACC_POINT.
                        Procedure reads data from column NETWORK_ADDRESS_DESC (where phone number in
                        international format = country code + area code + local number is stored) for given
                        batch session. For each phone number procedure finds appropriate network_address_id
                        and fills it into column NETWORK_ADDRESS_ID. If for some phone number the network_address_id
                        does not exist, then c_PHONE_NUMBER_NOT_EXISTS will be filled into the column result,
                        procedure ends successfully in this case.
    </Description>

    <Prerequisites>
                        Exists function:
                          RSIG_UTILS.Debug_Rsi
                          RSIG_UTILS.Handle_Error
                        Exists variable:
                          RSIG_UTILS.c_OK
                          RSIG_UTILS.c_DEBUG_TEXT_START
                          RSIG_UTILS.c_DEBUG_LEVEL_1
                          RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                          RSIG_UTILS.c_HANDLE_TRAN_S
                          RSIG_UTILS.c_HANDLE_TRAN_Y
                          RSIG_UTILS.c_HANDLE_TRAN_N
                          RSIG_UTILS.c_ORA_INVALID_HANDLE
                          RSIG_UTILS.c_ORA_MISSING_PARAMETER
                          RSIG_UTILS.c_DEBUG_LEVEL_2
                          RSIG_UTILS.c_DEBUG_LEVEL_3
                          RSIG_UTILS.c_DEBUG_LEVEL_0
                          RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                          RSIG_UTILS.c_DEBUG_TEXT_END
                          RSIG_UTILS.c_DEBUG_TEXT_BEFORE_LOOP
                          RSIG_UTILS.c_DEBUG_TEXT_IN_LOOP
                          RSIG_UTILS.c_DEBUG_TEXT_AFTER_LOOP
                          RSIG_UTILS.c_PHONE_NUMBER_NOT_EXISTS
    </Prerequisites>

    <Application>       Resource inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y - handle tran
                                    allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                     RSIG_UTILS.c_HANDLE_TRAN_Y
                                                     RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code OUT NUMBER
                        p_batch_session_id IN - Batch session identification
    </Parameters>

  </header>
  ****************************************************************************/
  PROCEDURE Fill_Na_Id_From_Int_Number;


  /****************************************************************************
  <header>
    <name>              procedure Fill_Ap_Id_From_Sn
    </name>

    <author>            Csaba Filip - GITUS
    </author>
     <version>           1.1.2   16.02.2006      Cepek Petr
                         use for temporary table TT_BATCH_NA_AP
      </version>
      <version>           1.1.1   26.5.2004      Jaroslav Holub
                                add update of result to c_ok if is NULL
      </version>
      <version>           1.1     3.2.2004      Lucie Sevcikova
                                optimized
      </version>
      <version>           1.0.2   5.12.2003     Csaba Filip
                                  created first version
    </version>

    <Description>       Procedure operates over the table TMP_BATCH_NET_ADDR_ACC_POINT.
                        Procedure reads data from column ACCESS_POINT_DESC (where serial number of
                        the SIM card - ICC ID - is stored) for given batch session. For each ACCESS_POINT_DESC
                        procedure finds appropriate access_point_id and fills it into column ACCESS_POINT_ID.
                        If for some row the access_point_id does not exist, then c_SIM_CARD_NOT_EXISTS will be
                        filled into the column result, procedure ends successfully in this case.

    </Description>

    <Prerequisites>
                        Exists function:
                          RSIG_UTILS.Debug_Rsi
                          RSIG_UTILS.Handle_Error
                        Exists variable:
                          RSIG_UTILS.c_OK
                          RSIG_UTILS.c_DEBUG_TEXT_START
                          RSIG_UTILS.c_DEBUG_LEVEL_1
                          RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                          RSIG_UTILS.c_HANDLE_TRAN_S
                          RSIG_UTILS.c_HANDLE_TRAN_Y
                          RSIG_UTILS.c_HANDLE_TRAN_N
                          RSIG_UTILS.c_ORA_INVALID_HANDLE
                          RSIG_UTILS.c_ORA_MISSING_PARAMETER
                          RSIG_UTILS.c_DEBUG_LEVEL_2
                          RSIG_UTILS.c_DEBUG_LEVEL_3
                          RSIG_UTILS.c_DEBUG_LEVEL_0
                          RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                          RSIG_UTILS.c_DEBUG_TEXT_END
                          RSIG_UTILS.c_DEBUG_TEXT_BEFORE_LOOP
                          RSIG_UTILS.c_DEBUG_TEXT_IN_LOOP
                          RSIG_UTILS.c_DEBUG_TEXT_AFTER_LOOP
                          RSIG_UTILS.c_SIM_CARD_NOT_EXISTS
    </Prerequisites>

    <Application>       Resource inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y - handle tran
                                    allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                     RSIG_UTILS.c_HANDLE_TRAN_Y
                                                     RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code OUT NUMBER
                        p_batch_session_id - Batch session identification
    </Parameters>

  </header>
  ****************************************************************************/
  PROCEDURE Fill_Ap_Id_From_Sn;


    /****************************************************************************
    <header>
      <name>              function Get_Handle_Tran_For_Call_Proc
      </name>

      <author>            Radek Hejduk - GITUS
      </author>

      <version>           1.0.1   16.12.2003     Radek Hejduk
                                  created first version
      </version>

      <Description>       function handles handle tran for calling procedure
                          from callers procedure (N -> N, Y -> S, S -> S)
      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       Resource Inventory
      </Application>

      <Parameters>        p_handle_tran IN VARCHAR2 - handle tran from callers procedure
      </Parameters>

    </header>
  /****************************************************************************/

  FUNCTION Get_Handle_Tran_For_Call_Proc(p_handle_tran IN VARCHAR2) RETURN VARCHAR2;

  /****************************************************************************
    <header>
      <name>              procedure Check_connection
      </name>

      <author>            Jaroslav Holub
      </author>

      <version>           1.0.0   14.1.2005 Jaroslav Holub
                                  created first version
      </version>

      <Description>       procedure serve for checking connection between BS <-> database

      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       FORIS Resource inventory
      </Application>

      <Parameters>
      </Parameters>

    </header>
  ****************************************************************************/
  PROCEDURE Check_connection;

  /****************************************************************************
    <header>
      <name>              procedure Get_normal_sal_cat_code
      </name>

      <author>            Martin Zabka
      </author>

      <version>           1.0.0   13.5.2005 Martin Zabka
                                  created first version
      </version>

      <Description>       procedure return code of normal (standart) salability category

      </Description>

      <Prerequisites>
      </Prerequisites>

      <Application>       FORIS Resource inventory
      </Application>

      <Parameters>
      </Parameters>

    </header>
  ****************************************************************************/
  PROCEDURE Get_normal_sal_cat_code
  (
   p_normal_sal_cat_code           OUT VARCHAR2
  );

  FUNCTION get_ri_setting(p_name VARCHAR2, p_default VARCHAR2 := NULL) RETURN VARCHAR2;

  FUNCTION get_ri_setting_num(p_name VARCHAR2, p_default number := NULL) RETURN number;


END RSIG_UTILS;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_UTILS.pkg,v 1.69 2003/12/22 13:04:11 rhejduk Exp $
/
