CREATE PACKAGE BODY SECURITY_PKG IS


----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_as_null_user_profile_id(p_user_profile_id number) return number
is
begin
  ------------------------------
  if p_user_profile_id = c_user_profile_id_empty
  then
    return NULL;
  end if;
  ------------------------------
  return p_user_profile_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_user_names_i
(
    p_date date,
    p_to_upper boolean,
    p_active boolean
) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_to_upper number := util_pkg.bool_to_int_2val(p_to_upper);
  v_is_active number := util_pkg.bool_to_int_3val(p_active);
begin
  ------------------------------
  util_loc_pkg.touch_number(v_is_active);
  ------------------------------
  select /*+ full(z)*/
    decode(v_to_upper, util_pkg.c_false, login_name, upper(login_name)) user_name
    bulk collect into v_res
    from users z
    where 1 = 1
    and (deleted is null or deleted > p_date)
    order by user_name
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_user_i
(
    p_user_id users.user_id%type
) return ctl_users
is
  v_res ctl_users;
begin
  ------------------------------
  select /*+ index_asc(z, PK_USERS)*/
    * bulk collect into v_res
  from users z
  where 1 = 1
  and user_id = p_user_id
  order by user_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_users_id_i
(
    p_login_name ct_nvarchar
) return ct_number
is
  v_login_name ct_varchar;
  v_res ct_number;
begin
  ------------------------------
  v_login_name := util_pkg.cast_ct_nvarchar2varchar(p_login_name);
  ------------------------------
  select /*+ ordered use_nl(z1 z2) full(z1) index_asc(z2 I_USERS_LOGIN_NAME)*/
    z2.user_id bulk collect into v_res
  from
    (select column_value login_name, rownum rn from table(v_login_name)) z1,
    users z2
  where 1 = 1
  and upper(z2.login_name(+)) = upper(z1.login_name)
  and z2.deleted(+) is null
  order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function users_ins_ii
(
    p_user_name users.login_name%type,
    p_name users.user_name%type
) return users.user_id%type
is
  v_res users.user_id%type;
begin
  ------------------------------
  v_res := s_users.nextval;
  ------------------------------
  insert into users
  (
    user_id, 
    user_name, 
    login_name, 
    deleted
  )
  values
  (
    v_res,
    p_name,
    p_user_name,
    null
  )
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_upd_ii
(
    p_user_id users.user_id%type,
    p_name users.user_name%type
)
is
begin
  ------------------------------
  update users
  set
    user_name = p_name
  where 1 = 1
  and user_id = p_user_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure users_insert_i
(
    p_execute_user_id number,
    p_user_name nvarchar2,
    p_user_profile_id number,
    p_name nvarchar2
)
is
  v_user_name users.login_name%type;
  v_name users.user_name%type;
  v_user_profile_id number;
  v_res number;
begin
  ------------------------------
  v_user_name := util_pkg.nchar_to_char(p_user_name); --!_! insert then not xget
  v_name := util_pkg.nchar_to_char(p_name); --!_!
  ------------------------------
  v_user_profile_id := make_as_null_user_profile_id(p_user_profile_id);
  ------------------------------
  util_loc_pkg.touch_number(p_execute_user_id); --!_!
  util_loc_pkg.touch_number(v_user_profile_id); --!_!
  ------------------------------
  v_res := users_ins_ii
  (
    p_user_name => v_user_name,
    p_name => v_name
  );
  ------------------------------
  util_loc_pkg.touch_number(v_res);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_update_i
(
    p_execute_user_id number,
    p_user_id number,
    p_user_profile_id number,
    p_name nvarchar2
)
is
  v_user_name users.login_name%type;
begin
  ------------------------------
  v_user_name := util_ri.xget_user_name(p_user_id);
  ------------------------------
  util_loc_pkg.touch_varchar(v_user_name);
  util_loc_pkg.touch_number(p_execute_user_id); --!_!
  util_loc_pkg.touch_number(p_user_profile_id); --!_!
  ------------------------------
  users_upd_ii
  (
    p_user_id => p_user_id,
    p_name => p_name
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_update_is_active_i
(
    p_execute_user_id number,
    p_user_id number,
    p_is_active number
)
is
  v_user_name users.user_name%type;
begin
  ------------------------------
  v_user_name := util_ri.xget_user_name(p_user_id);
  ------------------------------
  util_loc_pkg.touch_number(p_execute_user_id); --!_!
  util_loc_pkg.touch_varchar(v_user_name);
  util_loc_pkg.touch_number(p_is_active);
  ------------------------------
  --property IS_ACTIVE for user is not present in RI
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_user_profile_id_common return number
is
begin
  ------------------------------
  return c_user_profile_id_COMMON;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ctl_users(p_coll ctl_users) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_ctl_user_info(p_coll ctl_user_info) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_ctl_user_info(p_coll ctl_user_info, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(util_pkg.c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(util_pkg.c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(util_pkg.c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(util_pkg.c_msg_v_i || v_i || util_pkg.c_msg_delim02 || util_pkg.nchar_to_char(p_coll(v_i).user_name) || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_coll(v_i).user_profile_id) || util_pkg.c_msg_delim02 || util_pkg.nchar_to_char(p_coll(v_i).person_name));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user
(
    p_user_id number
) return ctl_users
is
begin
  ------------------------------
  return get_user_i(p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! p_map1 - user_types, p_map2 - user_profile_ids
function get_ctl_user_info(p_pivot_filter ct_number, p_map1 ct_number, p_map2 ct_number, p_user_types ct_number, p_user_names ct_nvarchar, p_person_names ct_nvarchar) return ctl_user_info
is
  v_res ctl_user_info;
  v_pivot ct_number;
  v_user_types ct_number;
  v_user_names ct_nvarchar;
  v_person_names ct_nvarchar;
  v_main_count number;
  v_main_count2 number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_user_types);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_user_types) != v_main_count, 'util_pkg.get_count_ct_number(p_user_types) != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar(p_user_names) != v_main_count, 'util_pkg.get_count_ct_nvarchar(p_user_names) != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar(p_person_names) != v_main_count, 'util_pkg.get_count_ct_nvarchar(p_person_names) != v_main_count');
  ------------------------------
  v_main_count2 := util_pkg.get_count_ct_number(p_map1);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_map1) != v_main_count2, 'util_pkg.get_count_ct_number(p_map1) != v_main_count2');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_map2) != v_main_count2, 'util_pkg.get_count_ct_number(p_map2) != v_main_count2');
  ------------------------------
  if v_main_count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  v_user_types := util_pkg.filter_ct_number(p_user_types, v_pivot, p_pivot_filter, true);
  v_user_names := util_pkg.filter_ct_nvarchar(p_user_names, v_pivot, p_pivot_filter, true);
  v_person_names := util_pkg.filter_ct_nvarchar(p_person_names, v_pivot, p_pivot_filter, true);
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3, m1, m2)*/
    q2.user_name,
    make_as_null_user_profile_id(m2.val) user_profile_id,
    q3.person_name
    bulk collect into v_res
    from
      (select column_value user_type, rownum rn from table(v_user_types)) q1,
      (select column_value user_name, rownum rn from table(v_user_names)) q2,
      (select column_value person_name, rownum rn from table(v_person_names)) q3,
      (select column_value val, rownum rn from table(p_map1)) m1,
      (select column_value val, rownum rn from table(p_map2)) m2
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    and m1.val(+) = q1.user_type
    and m2.rn(+) = m1.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure filter_users(p_filter_type number, p_types ct_number, p_vals ct_nvarchar, p_pivot out ct_number, p_vals_out out ct_nvarchar)
is
  lc_no_value constant nvarchar2(1) := NULL;
  v_marks ct_number;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_types);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_types) != v_main_count, 'util_pkg.get_count_ct_number(p_types) != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar(p_vals) != v_main_count, 'util_pkg.get_count_ct_nvarchar(p_vals) != v_main_count');
  ------------------------------
  p_pivot := null;
  p_vals_out := null;
  ------------------------------
  if v_main_count = 0
  then
    return;
  end if;
  ------------------------------
  p_pivot := util_pkg.make_pivot(util_pkg.get_count_ct_number(p_types));
  ------------------------------
  p_vals_out := util_pkg.upper_ct_nvarchar(p_vals); --!_! pivot is NOT changed
  ------------------------------
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_types, p_filter_type);
  ------------------------------
  p_pivot := util_pkg.get_marked_ct_number(p_pivot, v_marks, TRUE);
  p_vals_out := util_pkg.get_marked_ct_nvarchar(p_vals_out, v_marks, TRUE);
  ------------------------------
  ------------------------------
  p_vals_out := util_pkg.unique_ct_nvarchar(p_vals_out, TRUE, FALSE, lc_no_value); --!_! pivot IS CHANGED
  ------------------------------
  v_marks := util_pkg.mark_val_ct_nvarchar(p_vals_out, lc_no_value, util_pkg.C_FALSE, util_pkg.C_TRUE); --!_! reverse marking
  ------------------------------
  p_pivot := util_pkg.get_marked_ct_number(p_pivot, v_marks, TRUE);
  p_vals_out := util_pkg.get_marked_ct_nvarchar(p_vals_out, v_marks, TRUE);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_utypes_i return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_res, c_ext_user_type_COMMON);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_profile_ids_i return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_res, get_user_profile_id_common);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_users_i
(
  p_user_types ct_number,
  p_user_names ct_nvarchar,
  p_map1 out ct_number,
  p_map2 out ct_number,
  p_unames_uni_other out ct_nvarchar,
  p_pivot_other out ct_number
)
is
  v_main_count number;
  --
  v_utypes ct_number;
  v_uprofile_ids ct_number;
  --
  --
  v_pivot_other_common ct_number;
  --
  v_unames_uni_other_common ct_nvarchar;
begin
  ------------------------------
  v_utypes := get_utypes_i;
  v_uprofile_ids := get_profile_ids_i;
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(v_utypes);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_utypes) != v_main_count, 'util_pkg.get_count_ct_number(v_utypes) != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_uprofile_ids) != v_main_count, 'util_pkg.get_count_ct_number(v_uprofile_ids) != v_main_count');
  ------------------------------
  filter_users(v_utypes(1), p_user_types, p_user_names, v_pivot_other_common, v_unames_uni_other_common);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    util_pkg.add_ct_number_val(p_map1, v_utypes(v_i));
    util_pkg.add_ct_number_val(p_map2, v_uprofile_ids(v_i));
  end loop;
  ------------------------------
  p_unames_uni_other := v_unames_uni_other_common;
  ------------------------------
  p_pivot_other := v_pivot_other_common;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure synchronize_users_i
(
    p_execute_user_id users.user_id%type,
    p_user_types ct_number,
    p_user_names ct_nvarchar,
    p_person_names ct_nvarchar,
    p_new_users_pivot out ct_number,
    p_upd_users_pivot out ct_number,
    p_multiple_err_users_pivot out ct_number
)
is
  lc_no_value constant nvarchar2(1) := NULL;
  --
  v_unames_local ct_nvarchar;
  v_unames_local_mult ct_nvarchar;
  --
  v_pivot_other ct_number;
  v_unames_uni_other ct_nvarchar;
  v_unames_uni_local ct_nvarchar;
  --
  v_marks ct_number;
  --
  v_user_info ctl_user_info;
  v_map1 ct_number;
  v_map2 ct_number;
  --
  v_unames_tmp ct_nvarchar;
  v_users_tmp ctl_users;
  v_users_rec_tmp users%rowtype;
  v_user_id_tmp number;
  --
  v_main_count number;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_execute_user_id is null, 'p_execute_user_id');
  util_pkg.XCheckP_ct_number(p_user_types, 'p_user_types');
  util_pkg.XCheckP_ct_nvarchar(p_user_names, 'p_user_names');
  util_pkg.XCheckP_ct_nvarchar(p_person_names, 'p_person_names');
  ------------------------------
  v_main_count := p_user_types.count;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_user_types.count != v_main_count, 'p_user_types.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_user_names.count != v_main_count, 'p_user_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_person_names.count != v_main_count, 'p_person_names.count != v_main_count');
  ------------------------------
  util_ri.xcheck_user_id(p_execute_user_id);
  ------------------------------
  prepare_users_i(p_user_types, p_user_names, v_map1, v_map2, v_unames_uni_other, v_pivot_other);
  ------------------------------
  v_unames_local := get_user_names_i
  (
    p_date => sysdate,
    p_to_upper => TRUE, --!_!
    p_active => NULL
  );
  ------------------------------
  --!_! 0. errore when multiple present in local
  ------------------------------
  v_unames_uni_local := util_pkg.unique_ct_nvarchar(v_unames_local, TRUE, FALSE, lc_no_value);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_nvarchar(v_unames_uni_local, lc_no_value, util_pkg.C_TRUE, util_pkg.C_FALSE);
  ------------------------------
  v_unames_local_mult := util_pkg.get_marked_ct_nvarchar(v_unames_local, v_marks, TRUE);
  ------------------------------
  if util_pkg.get_count_ct_nvarchar(v_unames_local_mult) > 0
  then
    ------------------------------
    v_marks := util_pkg.mark_ct_nvarchar(v_unames_uni_other, v_unames_local_mult, util_pkg.C_TRUE, util_pkg.C_FALSE);
    ------------------------------
    p_multiple_err_users_pivot := util_pkg.get_marked_ct_number(v_pivot_other, v_marks, TRUE);
    ------------------------------
    v_marks := util_pkg.mark_ct_nvarchar(v_unames_local, v_unames_local_mult, util_pkg.C_TRUE, util_pkg.C_FALSE);
    ------------------------------
    v_unames_uni_local := util_pkg.get_marked_ct_nvarchar(v_unames_local, v_marks, TRUE, util_pkg.C_FALSE);
    ------------------------------
  end if;
  ------------------------------
  --!_! 1. present in other, NOT present in local
  ------------------------------
  --!_!v_unames_uni_temp := util_pkg.filter_val_ct_nvarchar(v_unames_uni_other, v_unames_uni_local, FALSE); --!_! ordered MULTISET EXCEPT DISTINCT
  v_marks := util_pkg.mark_ct_nvarchar(v_unames_uni_other, v_unames_local, util_pkg.C_FALSE, util_pkg.C_TRUE); --!_! reverse marking
  p_new_users_pivot := util_pkg.get_marked_ct_number(v_pivot_other, v_marks, TRUE);
  ------------------------------
  v_user_info := get_ctl_user_info(p_new_users_pivot, v_map1, v_map2, p_user_types, p_user_names, p_person_names);
  ------------------------------
  if get_count_ctl_user_info(v_user_info) > 0
  then
    ------------------------------
    for v_i in v_user_info.first..v_user_info.last
    loop
      ------------------------------
      users_insert_i
      (
        p_execute_user_id => p_execute_user_id,
        p_user_name => v_user_info(v_i).user_name,
        p_user_profile_id => v_user_info(v_i).user_profile_id,
        p_name => v_user_info(v_i).person_name
      );
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
  --!_! 2. present in Other, present in local(and unique in local)
  ------------------------------
  --!_!v_unames_uni_temp := util_pkg.filter_val_ct_nvarchar(v_unames_uni_other, v_unames_uni_local, TRUE); --!_! ordered MULTISET INTERSECT DISTINCT
  v_marks := util_pkg.mark_ct_nvarchar(v_unames_uni_other, v_unames_uni_local, util_pkg.C_TRUE, util_pkg.C_FALSE); --!_! direct marking
  p_upd_users_pivot := util_pkg.get_marked_ct_number(v_pivot_other, v_marks, TRUE);
  ------------------------------
  v_user_info := get_ctl_user_info(p_upd_users_pivot, v_map1, v_map2, p_user_types, p_user_names, p_person_names);
  ------------------------------
  if get_count_ctl_user_info(v_user_info) > 0
  then
    ------------------------------
    for v_i in v_user_info.first..v_user_info.last
    loop
      ------------------------------
      v_user_id_tmp := util_ri.xget_user_id(v_user_info(v_i).user_name);
      ------------------------------
      v_users_tmp := get_user
      (
        p_user_id => v_user_id_tmp
      );
      ------------------------------
      if get_count_ctl_users(v_users_tmp) = 0
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_user_not_found, util_pkg.c_msg_user_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(v_user_id_tmp));
        ------------------------------
      end if;
      ------------------------------
      v_users_rec_tmp := v_users_tmp(v_users_tmp.first);
      ------------------------------
      users_update_i
      (
        p_execute_user_id => p_execute_user_id,
        p_user_id => v_user_id_tmp,
        p_user_profile_id => v_user_info(v_i).user_profile_id,
        p_name => v_user_info(v_i).person_name
      );
      ------------------------------
      users_update_is_active_i
      (
        p_execute_user_id => p_execute_user_id,
        p_user_id => v_user_id_tmp,
        p_is_active => util_pkg.C_TRUE
      );
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
  --!_! 3. NOT present in Other, present in local(and uniq in local)
  ------------------------------
  --!_!v_unames_uni_temp := util_pkg.filter_val_ct_nvarchar(v_unames_uni_local, v_unames_uni_other, FALSE); --!_! ordered MULTISET EXCEPT DISTINCT
  v_marks := util_pkg.mark_ct_nvarchar(v_unames_uni_local, v_unames_uni_other, util_pkg.C_FALSE, util_pkg.C_TRUE); --!_! reverse marking
  v_unames_tmp := util_pkg.get_marked_ct_nvarchar(v_unames_uni_local, v_marks, TRUE);
  ------------------------------
  if util_pkg.get_count_ct_nvarchar(v_unames_tmp) > 0
  then
    ------------------------------
    for v_i in v_unames_tmp.first..v_unames_tmp.last
    loop
      ------------------------------
      users_update_is_active_i
      (
        p_execute_user_id => p_execute_user_id,
        p_user_id => util_ri.xget_user_id(v_unames_tmp(v_i)),
        p_is_active => util_pkg.C_FALSE
      );
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
PROCEDURE Synchronize_Users
(
    p_execute_user varchar2,
    p_login_names util_pkg.cit_nvarchar,
    p_user_names util_pkg.cit_nvarchar,
    p_added out sys_refcursor,
    p_updated out sys_refcursor,
    p_errors out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_execute_user_id users.user_id%type;
  v_main_count number;
  --
  v_pivot ct_number;
  v_login_names ct_nvarchar;
  v_user_names ct_nvarchar;
  --
  v_new_users_pivot ct_number;
  v_upd_users_pivot ct_number;
  v_multiple_err_users_pivot ct_number;
  --
  v_new_users_id ct_number;
  v_new_login_names ct_nvarchar;
  v_new_user_names ct_nvarchar;
  --
  v_upd_users_id ct_number;
  v_upd_login_names ct_nvarchar;
  v_upd_user_names ct_nvarchar;
  --
  v_err_login_names ct_nvarchar;
  v_err_user_names ct_nvarchar;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_execute_user is null, 'p_execute_user');
  --util_pkg.XCheckP_cit_number(p_user_types, 'p_user_types');
  util_pkg.XCheckP_FS_cit_nvarchar(p_login_names, 'p_login_names');
  util_pkg.XCheckP_FS_cit_nvarchar(p_user_names, 'p_user_names');
  ------------------------------
  v_main_count := util_pkg.get_count_cit_nvarchar(p_login_names);
  ------------------------------
  --util_pkg.XCheck_Cond_Invalid(p_user_types.count != v_main_count, 'p_user_types.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_cit_nvarchar(p_login_names) != v_main_count, 'p_login_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_cit_nvarchar(p_user_names) != v_main_count, 'p_user_names.count != v_main_count');
  ------------------------------
  v_execute_user_id := util_ri.xget_user_id(p_execute_user);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  v_login_names := util_pkg.cast_cit2ct_nvarchar(p_login_names, true);
  v_user_names := util_pkg.cast_cit2ct_nvarchar(p_user_names, true);
  ------------------------------
  synchronize_users_i
  (
    p_execute_user_id => v_execute_user_id,
    p_user_types => util_pkg.make_ct_number(v_main_count, c_user_profile_id_empty),
    p_user_names => v_login_names,
    p_person_names => v_user_names,
    p_new_users_pivot => v_new_users_pivot,
    p_upd_users_pivot => v_upd_users_pivot,
    p_multiple_err_users_pivot => v_multiple_err_users_pivot
  );
  ------------------------------
  if util_pkg.get_count_ct_number(v_new_users_pivot) > 0
  then
    v_new_login_names := util_pkg.filter_ct_nvarchar(v_login_names, v_pivot, v_new_users_pivot, true);
    v_new_user_names := util_pkg.filter_ct_nvarchar(v_user_names, v_pivot, v_new_users_pivot, true);
    v_new_users_id := get_users_id_i(v_new_login_names);
  end if;
  ------------------------------
  if util_pkg.get_count_ct_number(v_upd_users_pivot) > 0
  then
    v_upd_login_names := util_pkg.filter_ct_nvarchar(v_login_names, v_pivot, v_upd_users_pivot, true);
    v_upd_user_names := util_pkg.filter_ct_nvarchar(v_user_names, v_pivot, v_upd_users_pivot, true);
    v_upd_users_id := get_users_id_i(v_upd_login_names);
  end if;
  ------------------------------
  if util_pkg.get_count_ct_number(v_multiple_err_users_pivot) > 0
  then
    v_err_login_names := util_pkg.filter_ct_nvarchar(v_login_names, v_pivot, v_multiple_err_users_pivot, true);
    v_err_user_names := util_pkg.filter_ct_nvarchar(v_user_names, v_pivot, v_multiple_err_users_pivot, true);
  end if;
  ------------------------------
  commit;
  ------------------------------
  get_result_cursor001(v_new_users_id, v_new_login_names, v_new_user_names, p_added);
  get_result_cursor001(v_upd_users_id, v_upd_login_names, v_upd_user_names, p_updated);
  get_err_result_cursor001(v_err_login_names, v_err_user_names, p_errors);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_result_cursor001(p_user_ids ct_number, p_login_names ct_nvarchar, p_user_names ct_nvarchar, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
  select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
         q1.user_id, 
         q3.user_name, 
         q2.login_name, 
         util_pkg.c_ora_ok error_code, 
         util_pkg.c_msg_ok error_message
    from
      (select column_value user_id, rownum rn from table(p_user_ids)) q1,
      (select column_value login_name, rownum rn from table(p_login_names)) q2,
      (select column_value user_name, rownum rn from table(p_user_names)) q3
    where 1 = 1
    and q2.rn = q1.rn
    and q3.rn = q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_err_result_cursor001(p_login_names ct_nvarchar, p_user_names ct_nvarchar, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
  select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
         null user_id, 
         q2.user_name, 
         q1.login_name, 
         rsig_utils.c_ORA_TOO_MANY_ROWS_RETRIEVED error_code, 
         'Too many rows retrieved.' error_message
    from
      (select column_value login_name, rownum rn from table(p_login_names)) q1,
      (select column_value user_name, rownum rn from table(p_user_names)) q2
    where 1 = 1
    and q2.rn = q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
end;
/
