CREATE PACKAGE RSIG_DST_RULE1 IS

/****************************************************************************
  Package    RSIG_DST_RULE contains procedures neccessary for
             Daylight Saving Time rules management

  %author            Sergey Ermakov
  %created           31.05.2010
  %version           1.0.0

  {*}1.0.1 - 24.07.2010 - Sergey Ermakov 
             procedure Get_DST_Rules_List updated   
             procedure Insert_DTS_Rule updated 

  %version_log  
  {*}1.0.0 - 21.05.2010 - Sergey Ermakov 
             procedure Get_DST_Rules_List created   
             procedure Insert_DTS_Rule created  
             procedure Delete_DTS_Rule created  
             procedure Update_DST_Rule created 
             procedure Get_DTS_Rule_By_ID created
             procedure Get_DTS_Rule_By_Name name
             procedure Get_Country_List created 

****************************************************************************/

 
/****************************************************************************
  PROCEDURE

  %author           Sergey Ermakov
  %created          21.05.2010
  %version          1.0.0
  %application      Resource Inventory

  %usage            Procedure returns list of daylight saving time rules

*/
/* {%skip}
  %version_log
  {*}1.0.1 - 24.07.2010 - Segey Ermakov
             updated

  {*}1.0.0 - 21.05.2010 - Segey Ermakov
             created first version

****************************************************************************/
PROCEDURE Get_DST_Rules_List(
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
);

/****************************************************************************
  PROCEDURE

  %author           Sergey Ermakov
  %created          21.05.2010
  %version          1.0.0
  %application      Resource Inventory

  %usage            Procedure inserts a new DST rule.
    
*/
/* {%skip}
  %version_log
  {*}1.0.1 - 24.07.2010 - Segey Ermakov
             updated

  {*}1.0.0 - 21.05.2010 - Sergey Ermakov
             created first version

****************************************************************************/
PROCEDURE Insert_DST_Rule
(
  p_country_code          IN DST_RULE.COUNTRY_CODE%TYPE,
  p_DST_name              IN DST_RULE.DST_NAME%TYPE,
  p_date_start_rule_mask  IN DST_RULE.DATE_START_RULE_MASK%TYPE,
  p_date_start            IN DST_RULE.DATE_START%TYPE,
  p_date_end_rule_mask    IN DST_RULE.DATE_END_RULE_MASK%TYPE,
  p_date_end              IN DST_RULE.DATE_END%TYPE,  
  p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,   
  p_DST_rule_id           OUT HOST.HOST_ID%TYPE, 
  p_error_code            OUT NUMBER  
);

/****************************************************************************
  PROCEDURE

  %author           Sergey Ermakov
  %created          21.05.2010
  %version          1.0.0
  %application      Resource Inventory

  %usage            Procedure deleted DST rule.
    
*/
/* {%skip}
  %version_log
  {*}1.0.0 - 21.05.2010 - Sergey Ermakov
             created first version

****************************************************************************/
PROCEDURE Delete_DST_Rule
(
  p_DST_Rule_id           IN DST_RULE.DST_RULE_ID%TYPE,
  p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y, 
  p_error_code            OUT NUMBER 
);

/****************************************************************************
  PROCEDURE

  %author           Sergey Ermakov
  %created          21.05.2010
  %version          1.0.0
  %application      Resource Inventory

  %usage            Procedure updated DST rule.
    
*/
/* {%skip}
  %version_log
  {*}1.0.0 - 21.05.2010 - Sergey Ermakov
             created first version

****************************************************************************/
PROCEDURE Update_DST_Rule
(
  p_DST_Rule_id           IN DST_RULE.DST_RULE_ID%TYPE,
  p_country_code          IN DST_RULE.COUNTRY_CODE%TYPE,
  p_DST_name              IN DST_RULE.DST_NAME%TYPE,
  p_date_start_rule_mask  IN DST_RULE.DATE_START_RULE_MASK%TYPE,
  p_date_start            IN DST_RULE.DATE_START%TYPE,
  p_date_end_rule_mask    IN DST_RULE.DATE_END_RULE_MASK%TYPE,
  p_date_end              IN DST_RULE.DATE_END%TYPE,  
  p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,    
  p_error_code            OUT NUMBER 
);

/****************************************************************************
  PROCEDURE

  %author           Sergey Ermakov
  %created          21.05.2010
  %version          1.0.0
  %application      Resource Inventory

  %usage            Procedure returns daylight saving time rule by id.
    
*/
/* {%skip}
  %version_log
  {*}1.0.0 - 21.05.2010 - Sergey Ermakov
             created first version

****************************************************************************/
PROCEDURE Get_DST_Rule_By_ID(
  p_DST_Rule_id      IN   DST_RULE.DST_RULE_ID%TYPE,
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
);

/****************************************************************************
  PROCEDURE

  %author           Sergey Ermakov
  %created          21.05.2010
  %version          1.0.0
  %application      Resource Inventory

  %usage            Procedure returns daylight saving time rule by name.
    
*/
/* {%skip}
  %version_log
  {*}1.0.0 - 21.05.2010 - Sergey Ermakov
             created first version

****************************************************************************/
PROCEDURE Get_DST_Rule_By_Name(
  p_DST_Name         IN   DST_RULE.DST_NAME%TYPE,
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
);

/****************************************************************************
  PROCEDURE

  %author           Sergey Ermakov
  %created          21.05.2010
  %version          1.0.0
  %application      Resource Inventory

  %usage            Procedure returns list of countrys

*/
/* {%skip}
  %version_log
  {*}1.0.0 - 21.05.2010 - Segey Ermakov
             created first version

****************************************************************************/
PROCEDURE Get_Country_List(
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
);

---------------------------------------------
--     PROCEDURE Create_DST_Rules
---------------------------------------------
PROCEDURE Create_DST_Rules (
    p_dst_rule_codes          IN     Common.t_varchar2_255,
    p_dst_rule_country_codes  IN     Common.t_varchar2_10,
    p_dst_rule_names          IN     Common.t_varchar2_255,
    p_dst_rule_datestartmasks IN     Common.t_varchar2_10,
    p_dst_rule_dates_start    IN     Common.t_varchar2_255,
    p_dst_rule_dateendmasks   IN     Common.t_varchar2_255,
    p_dst_rule_dates_end      IN     Common.t_varchar2_255,
    p_user_name               IN     VARCHAR,
    handle_tran               CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    p_result                  OUT    SYS_REFCURSOR,
    p_error_details           OUT    SYS_REFCURSOR,
    p_error_code              OUT    NUMBER,
    p_error_message           OUT    VARCHAR2
  );
---------------------------------------------
--     PROCEDURE Update_DST_Rules
---------------------------------------------
PROCEDURE Update_DST_Rules (
    p_dst_rule_ids            IN     Common.t_number,
    p_dst_rule_country_codes  IN     Common.t_varchar2_10,
    p_dst_rule_names          IN     Common.t_varchar2_255,
    p_dst_rule_datestartmasks IN     Common.t_varchar2_10,
    p_dst_rule_dates_start    IN     Common.t_varchar2_255,
    p_dst_rule_dateendmasks   IN     Common.t_varchar2_255,
    p_dst_rule_dates_end      IN     Common.t_varchar2_255,
    p_user_name               IN     VARCHAR,
    handle_tran               CHAR   DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    p_result                  OUT    SYS_REFCURSOR,
    p_error_details           OUT    SYS_REFCURSOR,
    p_error_code              OUT    NUMBER,
    p_error_message           OUT    VARCHAR2
  );
---------------------------------------------
--     PROCEDURE Delete_DST_Rules
---------------------------------------------
PROCEDURE Delete_DST_Rules (
    p_dst_rule_ids            IN     Common.t_number,
    p_user_name               IN     VARCHAR,
    handle_tran               CHAR   DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    p_result                  OUT    SYS_REFCURSOR,
    p_error_details           OUT    SYS_REFCURSOR,
    p_error_code              OUT    NUMBER,
    p_error_message           OUT    VARCHAR2
  );

END RSIG_DST_RULE1;
/
