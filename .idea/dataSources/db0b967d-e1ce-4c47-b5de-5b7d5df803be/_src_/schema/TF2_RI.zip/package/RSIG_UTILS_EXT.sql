CREATE PACKAGE RSIG_UTILS_EXT IS

TYPE t_SN IS TABLE OF VARCHAR2(60) INDEX BY BINARY_INTEGER;
TYPE t_PHONE IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;

PROCEDURE Unlink_Phone_And_SIM
(
  handle_tran         CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT  NUMBER,
  p_phone_list        IN   t_PHONE,
  p_sn_list           IN   t_SN,
  p_end_date          IN   NETWORK_ADDRESS_ACCESS_POINT.TO_DATE%TYPE,
  p_user_login        IN   VARCHAR2,
  Result_list         OUT  RSIG_UTILS.REF_CURSOR
);

PROCEDURE Unlink_one_Phone_And_SIM (
	handle_tran               IN     CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
	error_code                OUT    NUMBER,
  p_international_format    IN     phone_number.international_format%TYPE,
  p_sn                      IN     sim_card.sn%TYPE,
	p_end_date                IN     NETWORK_ADDRESS_ACCESS_POINT.FROM_DATE%TYPE,
  p_user_login              IN     VARCHAR2,
	Result_list               OUT    RSIG_UTILS.REF_CURSOR
);

PROCEDURE Set_SIM_Status (
	handle_tran                IN    CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
	error_code                 OUT   NUMBER,
	p_start_date               IN    DATE,
	p_status_code              IN    ACCESS_POINT_STATUS_HISTORY.ACCESS_POINT_STATUS_CODE%TYPE,
	p_user_login               IN    VARCHAR2,
  p_SN_list                  IN    t_SN,
	Result_list                OUT   RSIG_UTILS.REF_CURSOR
);

PROCEDURE Set_One_SIM_Status
( handle_tran               CHAR   DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  ERROR_CODE                OUT    NUMBER,
  p_start_date              IN     DATE,
  p_status_code             IN     ACCESS_POINT_STATUS_HISTORY.ACCESS_POINT_STATUS_CODE%TYPE,
  p_user_login              IN     VARCHAR2,
  p_SN                      IN     sim_card.sn%TYPE,
  Result_list               OUT    RSIG_UTILS.REF_CURSOR
);

procedure get_simcard_details_by_simlist
(
  p_sn_list util_pkg.cit_varchar_s,
  p_result_list out sys_refcursor,
  p_addit_result out sys_refcursor,
  p_error_code out number,
  p_error_message out varchar2
);

PROCEDURE Get_IMSI_By_MSISDN_List (
	handle_tran                        CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
	error_code                   OUT   NUMBER,
  p_phone_list                 IN    t_PHONE,
	p_validity_date              IN    DATE := SYSDATE,
	p_cur_host                   OUT   RSIG_UTILS.REF_CURSOR

);

END;
/
