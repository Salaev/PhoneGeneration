CREATE package body search_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_reserve_status_or_null(p_reserve boolean) return varchar2
is
begin
  ------------------------------
  if p_reserve
  then
    return util_ri.c_NASH_CODE_RESERVE;
  end if;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_linked_naap_value(p_link_status number) return boolean
is
  v_res boolean;
begin
  ------------------------------
  if p_link_status = util_ri.c_link_status_free
  then
    v_res := false;
  elsif p_link_status = util_ri.c_link_status_linked
  then
    v_res := true;
  else --p_link_status = c_link_status_all
    v_res := null;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_linked_naap_value2(p_link_status number) return boolean
is
  v_res boolean;
begin
  ------------------------------
  if p_link_status = util_ri.c_link2_status_free
  then
    v_res := false;
  elsif p_link_status = util_ri.c_link2_status_linked
  then
    v_res := true;
  else --p_link_status = c_link2_status_all
    v_res := null;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function normalize_mask(p_mask varchar2) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := p_mask;
  ------------------------------
  v_res := replace(v_res, '?', '_');
  ------------------------------
  v_res := replace(v_res, '*', '%');
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure normalize_str_host_alike(p_str_host_alike varchar2, p_str_host_normal out varchar2, p_host_empty out boolean)
is
begin
  ------------------------------
  p_str_host_normal := null;
  p_host_empty := false;
  ------------------------------
  if p_str_host_alike is null
  then
    p_host_empty := true;
  elsif p_str_host_alike = util_ri.c_str_host_id_any
  then
    p_str_host_normal := null;
  else
    p_str_host_normal := p_str_host_alike;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_str_host_id(p_str_host_id varchar2, p_date date, p_xcheck_exist boolean, p_host_id out number, p_host_empty out boolean)
is
  v_str_host_id varchar2(4000);
  v_coll_str_host_id ct_varchar_s;
  v_coll_host_id ct_number;
  v_host_empty boolean;
begin
  ------------------------------
  normalize_str_host_alike(p_str_host_id, v_str_host_id, p_host_empty);
  ------------------------------
  p_host_id := util_pkg.char_to_number(v_str_host_id);
  ------------------------------
  if p_xcheck_exist and not p_host_empty and v_str_host_id is not null
  then
    ------------------------------
    util_pkg.add_ct_varchar_s_val(v_coll_str_host_id, v_str_host_id);
    ------------------------------
    normalize_coll_str_host_id(v_coll_str_host_id, p_date, p_xcheck_exist, v_coll_host_id, v_host_empty);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_str_host_id2(p_str_host_id varchar2, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean)
is
  v_host_id number;
begin
  ------------------------------
  p_host_id := null;
  ------------------------------
  normalize_str_host_id(p_str_host_id, p_date, p_xcheck_exist, v_host_id, p_host_empty);
  ------------------------------
  if not p_host_empty and v_host_id is not null
  then
    util_pkg.add_ct_number_val(p_host_id, v_host_id);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_coll_str_host_alike(p_coll_str_host_alike ct_varchar_s, p_coll_str_host_normal out ct_varchar_s, p_host_empty out boolean)
is
begin
  ------------------------------
  p_coll_str_host_normal := null;
  p_host_empty := false;
  ------------------------------
  if NOT util_pkg.CheckP_ct_varchar_s(p_coll_str_host_alike)
  then
    p_host_empty := true;
  elsif p_coll_str_host_alike.count > 0 and p_coll_str_host_alike(p_coll_str_host_alike.first) = util_ri.c_str_host_id_any
  then
    p_coll_str_host_normal := null;
  else
    p_coll_str_host_normal := util_pkg.unique_ct_varchar_s(p_coll_str_host_alike, true);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_coll_str_host_alike2(p_coll_str_host_alike util_pkg.cit_varchar_s, p_coll_str_host_normal out ct_varchar_s, p_host_empty out boolean)
is
begin
  ------------------------------
  normalize_coll_str_host_alike(util_pkg.cast_cit2ct_varchar_s(p_coll_str_host_alike, TRUE), p_coll_str_host_normal, p_host_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_coll_str_host_id(p_coll_str_host_id ct_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean)
is
  v_coll ct_varchar_s;
  v_host_code ct_varchar_s;
begin
  ------------------------------
  normalize_coll_str_host_alike(p_coll_str_host_id, v_coll, p_host_empty);
  ------------------------------
  p_host_id := null; --!_!
  ------------------------------
  if util_pkg.CheckP_ct_varchar_s(v_coll)
  then
    p_host_id := util_pkg.cast_ct_varchar_s2ct_number(v_coll, true);
  end if;
  ------------------------------
  if p_xcheck_exist
  then
    ------------------------------
    v_host_code := null; --!_!
    ------------------------------
    if util_pkg.CheckP_ct_number(p_host_id)
    then
      ------------------------------
      v_host_code := util_ri.get_host_code(p_host_id, p_date, TRUE);
      ------------------------------
      if NOT util_pkg.CheckP_ct_varchar_s(v_host_code)
      then
        v_host_code := null; --!_!
      end if;
      ------------------------------
    end if;
    ------------------------------
    if 1 = 1
      and not (v_host_code is null and p_host_id is null)
      and ((v_host_code is null and p_host_id is not null)
        or (v_host_code is not null and p_host_id is null)
        or v_host_code.count != p_host_id.count
      )
    then
      util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found);
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_coll_str_host_id2(p_coll_str_host_id util_pkg.cit_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean)
is
begin
  ------------------------------
  normalize_coll_str_host_id(util_pkg.cast_cit2ct_varchar_s(p_coll_str_host_id, TRUE), p_date, p_xcheck_exist, p_host_id, p_host_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_coll_str_host_code(p_coll_str_host_code ct_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean)
is
  v_coll ct_varchar_s;
begin
  ------------------------------
  normalize_coll_str_host_alike(p_coll_str_host_code, v_coll, p_host_empty);
  ------------------------------
  p_host_id := null; --!_!
  ------------------------------
  if util_pkg.CheckP_ct_varchar_s(v_coll)
  then
    ------------------------------
    p_host_id := util_ri.get_host_id(v_coll, p_date, p_xcheck_exist); --!_!
    ------------------------------
    if NOT util_pkg.CheckP_ct_number(p_host_id)
    then
      p_host_id := null; --!_!
    end if;
    ------------------------------
  end if;
  ------------------------------
  if p_xcheck_exist
  then
    ------------------------------
    if 1 = 1
      and not (v_coll is null and p_host_id is null)
      and ((v_coll is null and p_host_id is not null)
        or (v_coll is not null and p_host_id is null)
        or v_coll.count != p_host_id.count
      )
    then
      util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found);
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure normalize_coll_str_host_code2(p_coll_str_host_code util_pkg.cit_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean)
is
begin
  ------------------------------
  normalize_coll_str_host_code(util_pkg.cast_cit2ct_varchar_s(p_coll_str_host_code, TRUE), p_date, p_xcheck_exist, p_host_id, p_host_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_search_type(p_search_type number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_search_type is null, 'p_search_type');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_search_type not in (c_srch_type_single, c_srch_type_dual), 'p_search_type not in (c_srch_type_single, c_srch_type_dual)');
  ------------------------------
end;

----------------------------------!---------------------------------------------
function map_types_srch2tpns(p_srch_type number) return number
is
  v_res number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_srch_type not in (c_srch_type_single, c_srch_type_dual), 'p_srch_type not in (c_srch_type_single, c_srch_type_dual)');
  ------------------------------
  if p_srch_type = c_srch_type_single
  then
    ------------------------------
    v_res := c_tpns_type_main;
    ------------------------------
  else --!_! p_srch_type = c_srch_type_dual
    ------------------------------
    v_res := c_tpns_type_linked;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure clear_ttpns(p_type number)
is
begin
  ------------------------------
  delete from tt_phone_number_series where type = p_type;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ttpns_count(p_type number := null) return number
is
  v_res number;
begin
  ------------------------------
  select /*+ no_expand full(z)*/
  count(1) cnt into v_res
  from tt_phone_number_series z
  where 1 = 1
  and type = nvl(p_type, type)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure prepare_pso_pns_i
(
    p_type number,
    p_network_operator_id ct_number,
    p_phone_number_series_id ct_number,
    p_host_empty boolean,
    p_host_id ct_number,
    p_pns_type ct_varchar_s,
    p_date date,
    p_shuffle boolean,
    p_unique_pns boolean
)
is
  v_host_empty number := util_pkg.bool_to_int_2val(p_host_empty);
  v_date date := p_date;
  v_net_op_any number := util_pkg.c_false;
  v_pns_id_any number := util_pkg.c_false;
  v_host_any number := util_pkg.c_false;
  v_pns_type_any number := util_pkg.c_false;
  v_shuffle number := util_pkg.bool_to_int_2val(p_shuffle);
  v_unique_pns number := util_pkg.bool_to_int_2val(p_unique_pns);
  v_white_host_list ct_number;
  v_black_host_list ct_number;
  v_white_host_list_empty number := util_pkg.c_false;
  v_black_host_list_empty number := util_pkg.c_false;
begin
  ------------------------------
  v_white_host_list := bw_host_list_pkg.get_white_list2;
  v_black_host_list := bw_host_list_pkg.get_black_list2;
  ------------------------------
  if p_network_operator_id is null
  then
    v_net_op_any := util_pkg.c_true;
  end if;
  ------------------------------
  if p_phone_number_series_id is null
  then
    v_pns_id_any := util_pkg.c_true;
  end if;
  ------------------------------
  if util_pkg.get_count_ct_number(v_white_host_list) = 0
  then
    v_white_host_list_empty := util_pkg.c_true;
  end if;
  ------------------------------
  if util_pkg.get_count_ct_number(v_black_host_list) = 0
  then
    v_black_host_list_empty := util_pkg.c_true;
  end if;
  ------------------------------
  if v_host_empty = util_pkg.c_false and p_host_id is null
  then
    v_host_any := util_pkg.c_true;
  end if;
  ------------------------------
  if p_pns_type is null
  then
    v_pns_type_any := util_pkg.c_true;
  end if;
  ------------------------------
  clear_ttpns(p_type);
  ------------------------------
  insert into tt_phone_number_series (phone_number_series_id, host_id, phone_type_code, network_operator_id, type, date_from, date_to)
select /*+ ordered no_expand use_nl(pso, pns) full(pso) index_asc(pns, PK_PHONE_NUMBER_SERIES)*/
  pns.phone_number_series_id,
  pns.host_id,
  pns.phone_number_type_code phone_type_code,
  decode(v_unique_pns, util_pkg.c_false, pso.network_operator_id, c_dummy_network_operator_id) network_operator_id,
  p_type type,
  min(greatest(pso.start_date, util_pkg.c_minus_infinity)) date_from,
  max(least(nvl(pso.end_date, util_pkg.c_plus_infinity), nvl(pns.deleted, util_pkg.c_plus_infinity))) date_to
  from phone_series_operator pso, phone_number_series pns
  where 1 = 1
  --
  and (v_date is null or v_date between pso.start_date and nvl(pso.end_date, v_date))
  and pns.phone_number_series_id = pso.phone_number_series_id
  and (v_date is null or (pns.deleted is null or pns.deleted > v_date))
  and greatest(pso.start_date, util_pkg.c_minus_infinity) <= least(nvl(pso.end_date, util_pkg.c_plus_infinity), nvl(pns.deleted, util_pkg.c_plus_infinity))
  --
  and (v_net_op_any = util_pkg.c_true
    or pso.network_operator_id in (select distinct column_value from table(cast(p_network_operator_id as ct_number)))
  )
  --
  and (v_pns_id_any = util_pkg.c_true
    or pso.phone_number_series_id in (select distinct column_value from table(cast(p_phone_number_series_id as ct_number)))
  )
  --
  and (v_host_any = util_pkg.c_true
    or (v_host_empty = util_pkg.c_true and pns.host_id is null)
    or pns.host_id in (select distinct column_value from table(cast(p_host_id as ct_number)))
  )
  --
  and (v_white_host_list_empty = util_pkg.c_true
    or (pns.host_id is not null --!_! is redundancy, for clarity
      and pns.host_id in (select distinct column_value from table(cast(v_white_host_list as ct_number)))
       )
  )
  --
  and (v_black_host_list_empty = util_pkg.c_true
    or pns.host_id is null
    or pns.host_id not in (select distinct column_value from table(cast(v_black_host_list as ct_number)))
  )
  --
  and (v_pns_type_any = util_pkg.c_true
    or pns.phone_number_type_code in (select distinct column_value from table(cast(p_pns_type as ct_varchar_s)))
  )
  --
  group by
  pns.phone_number_series_id,
  pns.host_id,
  pns.phone_number_type_code,
  decode(v_unique_pns, util_pkg.c_false, pso.network_operator_id, c_dummy_network_operator_id)
  --
  order by decode(v_shuffle, util_pkg.c_false, 0, dbms_random.value), phone_number_series_id, date_from
  ;
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure prepare_pso_pns_normal_m
(
    p_network_operator_id number,
    p_phone_number_series_id number,
    p_host_empty boolean,
    p_host_id ct_number,
    p_pns_type ct_varchar_s,
    p_shuffle boolean
)
is
  v_date date := sysdate;
  v_network_operator_id ct_number;
  v_phone_number_series_id ct_number;
begin
  ------------------------------
  if p_network_operator_id is not null
  then
    util_pkg.add_ct_number_val(v_network_operator_id, p_network_operator_id);
  end if;
  ------------------------------
  if p_phone_number_series_id is not null
  then
    util_pkg.add_ct_number_val(v_phone_number_series_id, p_phone_number_series_id);
  end if;
  ------------------------------
  prepare_pso_pns_i
  (
    p_type => c_tpns_type_main,
    p_network_operator_id => v_network_operator_id,
    p_phone_number_series_id => v_phone_number_series_id,
    p_host_empty => p_host_empty,
    p_host_id => p_host_id,
    p_pns_type => p_pns_type,
    p_date => v_date,
    p_shuffle => p_shuffle,
    p_unique_pns => TRUE
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_pso_pns_normal_ml
(
    p_network_operator_id_m number,
    p_network_operator_id_l number,
    p_phone_number_series_id_m number,
    p_phone_number_series_id_l number,
    p_host_empty_m boolean,
    p_host_empty_l boolean,
    p_host_id_m ct_number,
    p_host_id_l ct_number,
    p_pns_type_m ct_varchar_s,
    p_pns_type_l ct_varchar_s,
    p_shuffle_m boolean,
    p_shuffle_l boolean
)
is
  v_date date := sysdate;
  v_network_operator_id_m ct_number;
  v_network_operator_id_l ct_number;
  v_phone_number_series_id_m ct_number;
  v_phone_number_series_id_l ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_network_operator_id_m is null, 'p_network_operator_id_m');
  util_pkg.XCheck_Cond_Missing(p_network_operator_id_l is null, 'p_network_operator_id_l');
  ------------------------------
  util_pkg.add_ct_number_val(v_network_operator_id_m, p_network_operator_id_m);
  util_pkg.add_ct_number_val(v_network_operator_id_l, p_network_operator_id_l);
  ------------------------------
  if p_phone_number_series_id_m is not null
  then
    util_pkg.add_ct_number_val(v_phone_number_series_id_m, p_phone_number_series_id_m);
  end if;
  ------------------------------
  if p_phone_number_series_id_l is not null
  then
    util_pkg.add_ct_number_val(v_phone_number_series_id_l, p_phone_number_series_id_l);
  end if;
  ------------------------------
  prepare_pso_pns_i
  (
    p_type => c_tpns_type_main,
    p_network_operator_id => v_network_operator_id_m,
    p_phone_number_series_id => v_phone_number_series_id_m,
    p_host_empty => p_host_empty_m,
    p_host_id => p_host_id_m,
    p_pns_type => p_pns_type_m,
    p_date => v_date,
    p_shuffle => p_shuffle_m,
    p_unique_pns => TRUE
  );
  ------------------------------
  prepare_pso_pns_i
  (
    p_type => c_tpns_type_linked,
    p_network_operator_id => v_network_operator_id_l,
    p_phone_number_series_id => v_phone_number_series_id_l,
    p_host_empty => p_host_empty_l,
    p_host_id => p_host_id_l,
    p_pns_type => p_pns_type_l,
    p_date => v_date,
    p_shuffle => p_shuffle_l,
    p_unique_pns => TRUE
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_pso_pns_intersect_m
(
    p_first_network_operator_id number,
    p_second_network_operator_id number,
    p_phone_number_series_id number,
    p_host_empty boolean,
    p_host_id ct_number,
    p_pns_type ct_varchar_s,
    p_shuffle boolean
)
is
  v_date date := sysdate;
  v_network_operator_id1 ct_number;
  v_network_operator_id2 ct_number;
  v_phone_number_series_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_first_network_operator_id is null, 'p_first_network_operator_id is null');
  util_pkg.XCheck_Cond_Missing(p_second_network_operator_id is null, 'p_second_network_operator_id is null');
  ------------------------------
  if p_first_network_operator_id is not null
  then
    util_pkg.add_ct_number_val(v_network_operator_id1, p_first_network_operator_id);
  end if;
  ------------------------------
  if p_second_network_operator_id is not null
  then
    util_pkg.add_ct_number_val(v_network_operator_id2, p_second_network_operator_id);
  end if;
  ------------------------------
  if p_phone_number_series_id is not null
  then
    util_pkg.add_ct_number_val(v_phone_number_series_id, p_phone_number_series_id);
  end if;
  ------------------------------
  prepare_pso_pns_i
  (
    p_type => c_tpns_type_temporary01,
    p_network_operator_id => v_network_operator_id1,
    p_phone_number_series_id => v_phone_number_series_id,
    p_host_empty => p_host_empty,
    p_host_id => p_host_id,
    p_pns_type => p_pns_type,
    p_date => v_date,
    p_shuffle => p_shuffle,
    p_unique_pns => TRUE
  );
  prepare_pso_pns_i
  (
    p_type => c_tpns_type_temporary02,
    p_network_operator_id => v_network_operator_id2,
    p_phone_number_series_id => v_phone_number_series_id,
    p_host_empty => p_host_empty,
    p_host_id => p_host_id,
    p_pns_type => p_pns_type,
    p_date => v_date,
    p_shuffle => p_shuffle,
    p_unique_pns => TRUE
  );
  ------------------------------
  intersect_pns
  (
      p_first_type => c_tpns_type_temporary01,
      p_second_type => c_tpns_type_temporary02,
      p_result_type => c_tpns_type_main,
      p_shuffle => p_shuffle,
      p_unique_pns => TRUE
  );
  ------------------------------
  clear_ttpns(c_tpns_type_temporary01);
  clear_ttpns(c_tpns_type_temporary02);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure intersect_pns
(
    p_first_type number,
    p_second_type number,
    p_result_type number,
    p_shuffle boolean,
    p_unique_pns boolean
)
is
  v_net_op_any number := util_pkg.c_true;
  v_shuffle number := util_pkg.bool_to_int_2val(p_shuffle);
  v_unique_pns number := util_pkg.bool_to_int_2val(p_unique_pns);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_first_type is null, 'p_first_type is null');
  util_pkg.XCheck_Cond_Invalid(p_second_type is null, 'p_second_type is null');
  util_pkg.XCheck_Cond_Invalid(p_result_type is null, 'p_result_type is null');
  util_pkg.XCheck_Cond_Invalid(p_first_type = p_result_type, 'p_first_type = p_result_type');
  util_pkg.XCheck_Cond_Invalid(p_second_type = p_result_type, 'p_second_type = p_result_type');
  ------------------------------
  clear_ttpns(p_result_type);
  ------------------------------
  insert into tt_phone_number_series (phone_number_series_id, host_id, phone_type_code, network_operator_id, type, date_from, date_to)
select /*+ ordered no_expand use_hash(ttpns1, ttpns1) full(ttpns1) full(ttpns2)*/
  ttpns1.phone_number_series_id,
  ttpns1.host_id,
  ttpns1.phone_type_code phone_type_code,
  decode(v_unique_pns, util_pkg.c_false, decode(v_net_op_any, util_pkg.c_false, ttpns1.network_operator_id, c_dummy_network_operator_id), c_dummy_network_operator_id) network_operator_id,
  p_result_type type,
  min(greatest(ttpns1.date_from, ttpns2.date_from)) date_from,
  max(least(nvl(ttpns1.date_to, util_pkg.c_plus_infinity), nvl(ttpns2.date_to, util_pkg.c_plus_infinity))) date_to
  from tt_phone_number_series ttpns1, tt_phone_number_series ttpns2
  where 1 = 1
  --
  and ttpns1.phone_number_series_id = ttpns2.phone_number_series_id
  and nvl2(ttpns1.host_id, 1, 2) = nvl2(ttpns2.host_id, 1, 2)
  and nvl(ttpns1.host_id, c_dummy_host_id) = nvl(ttpns2.host_id, c_dummy_host_id)
  and ttpns1.phone_type_code = ttpns2.phone_type_code
  and greatest(ttpns1.date_from, ttpns2.date_from) <= least(nvl(ttpns1.date_to, util_pkg.c_plus_infinity), nvl(ttpns2.date_to, util_pkg.c_plus_infinity))
  --
  and (v_net_op_any = util_pkg.c_true
    or ttpns1.network_operator_id = ttpns2.network_operator_id
  )
  --
  group by
  ttpns1.phone_number_series_id,
  ttpns1.host_id,
  ttpns1.phone_type_code,
  decode(v_unique_pns, util_pkg.c_false, decode(v_net_op_any, util_pkg.c_false, ttpns1.network_operator_id, c_dummy_network_operator_id), c_dummy_network_operator_id)
  --
  order by decode(v_shuffle, util_pkg.c_false, 0, dbms_random.value), phone_number_series_id, date_from
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure find_phones_i
(
    p_search_type number,
    p_m_mask varchar2,
    p_m_status ct_varchar_s,
    p_m_category ct_varchar_s,
    p_l_mask varchar2,
    p_l_status ct_varchar_s,
    p_l_category ct_varchar_s,
    p_count number,
    p_lock boolean,
    p_linked_pl boolean,
    p_linked_naap boolean,
    p_filter_mno_for_l boolean,
    p_m_l_same_status boolean,
    p_m_l_same_category boolean,
    p_m_l_same_naap boolean,
    p_order_by_msisdn boolean,
    p_msisdn_lower_bound varchar2,
    p_set_phone_status boolean,
    p_date_from_status date,
    p_set_phone_status_code varchar2,
    p_ret_phone_count boolean,
    p_user_id number,
    p_m_na_id out ct_number,
    p_l_na_id out ct_number,
    p_pn_count out number
)
is
  v_sp_name varchar2(30);
  v_date date := sysdate;

  v_lock boolean := util_pkg.bool_to_bool_2val(p_lock);
  v_linked_pl number := util_pkg.bool_to_int(p_linked_pl); --!_!null, 0, 1
  v_linked_naap number := util_pkg.bool_to_int(p_linked_naap); --!_!null, 0, 1
  v_filter_mno_for_l number := util_pkg.bool_to_int_2val(p_filter_mno_for_l);
  v_m_l_same_status number := util_pkg.bool_to_int_2val(p_m_l_same_status);
  v_m_l_same_category number := util_pkg.bool_to_int_2val(p_m_l_same_category);
  v_m_l_same_naap number := util_pkg.bool_to_int_2val(p_m_l_same_naap);
  v_order_by_msisdn boolean := util_pkg.bool_to_bool_2val(p_order_by_msisdn);
  v_ret_phone_count boolean := util_pkg.bool_to_bool_2val(p_ret_phone_count);

  v_res_set_na_status boolean;

  v_error_code number;
  v_error_message varchar2(32767);

  v_lock_res boolean;
  v_m_na_id number;
  v_l_na_id number;
  v_pn_count number;

  v_tmp_str varchar2(32767);
  v_cursor sys_refcursor;

  v_act_tpns_type number;
  v_ext_tpns_type number;
  v_sql_text varchar2(32767);
  v_act_mask varchar2(32767);
  v_ext_mask varchar2(32767);
  v_act_status ct_varchar_s;
  v_ext_status ct_varchar_s;
  v_act_category ct_varchar_s;
  v_ext_category ct_varchar_s;

  v_delim01 varchar2(10) := ',';

  v_cnt_opt number;
  v_cnt_act number;

  v_selective_sal_cats ct_varchar_s;

  v_may_filter_by_pns boolean;
  v_may_use_pn_msisdn_index boolean;
  v_may_use_pn_sal_index boolean;
  v_may_use_pn_stat_index boolean;

  v_use_pn_stat_pns_index boolean;

  v_sql_count_curs varchar2(200) := q'{count(1)}';
  v_sql_not_linked_curs varchar2(200) := q'{pn.network_address_id}';
  v_sql_linked_curs varchar2(200) := q'{pnm.network_address_id,
  pn.network_address_id l_network_address_id}';

  v_sql_text_not_linked varchar2(32767) := q'{select /*+ ordered :p_pn_tpns_join_operation :p_tpns_access_path :p_pn_access_path*/
  :p_cursor_descr
  from :p_pn_tpns_clause
  where 1 = 1
  --
  and tpns.type = :p_act_tpns_type
  and :p_date between tpns.date_from and tpns.date_to
  --
  and pn.phone_number_series_id = tpns.phone_number_series_id
  --
  and nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > :p_date
  --
  and decode(:p_linked_naap,
    0, decode(pn.naap_access_point_id, :p_dummy_access_point_id, 1, 0),
    1, decode(pn.naap_access_point_id, :p_dummy_access_point_id, 0, 1),
    1
  ) = 1
  --
  and decode(:p_linked_pl,
    0, decode(pn.pl_linked_msisdn, :p_dummy_msisdn, 1, 0),
    1, decode(pn.pl_linked_msisdn, :p_dummy_msisdn, 0, 1),
    1
  ) = 1
  and decode(:p_linked_pl,
    0, decode(pn.pl_main_msisdn, :p_dummy_msisdn, 1, 0),
    1, decode(pn.pl_main_msisdn, :p_dummy_msisdn, 0, 1),
    1
  ) = 1
  --
  and pn.net_address_status_code in (:p_act_net_addr_stat_code)
  and pn.salability_category_code in (:p_act_sal_cat_code)
  --
  :p_act_mask_clause
  --
  :p_msisdn_lower_bound
  --
  :p_order_clause
  --
}'
  ;

  v_sql_text_linked varchar2(32767) := q'{select /*+ ordered :p_pn_tpns_join_operation use_nl(pnm, tpnsm)
  :p_tpns_access_path
  :p_pn_access_path
  index_asc(pnm, UK_PHONE_NUM_PHONE_NUMBER)
  index_asc(tpnsm, I_TTPNS_PNSID)
  */
  :p_cursor_descr
  from :p_pn_tpns_clause, phone_number pnm, tt_phone_number_series tpnsm
  where 1 = 1
  --
  and tpns.type = :p_act_tpns_type
  and :p_date between tpns.date_from and tpns.date_to
  --
  and pn.phone_number_series_id = tpns.phone_number_series_id
  --
  and nvl(pn.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > :p_date
  --
  and decode(:p_linked_naap,
    0, decode(pn.naap_access_point_id, :p_dummy_access_point_id, 1, 0),
    1, decode(pn.naap_access_point_id, :p_dummy_access_point_id, 0, 1),
    1
  ) = 1
  --
  and pn.pl_main_msisdn != :p_dummy_msisdn
  --
  --
  and pn.net_address_status_code in (:p_act_net_addr_stat_code)
  and pn.salability_category_code in (:p_act_sal_cat_code)
  --
  :p_act_mask_clause
  --
  and pnm.international_format = pn.pl_main_msisdn
  --
  and nvl(pnm.deleted, to_date('01.01.4000', 'dd.mm.yyyy')) > :p_date
  --
  and decode(:p_linked_naap,
    0, decode(pnm.naap_access_point_id, :p_dummy_access_point_id, 1, 0),
    1, decode(pnm.naap_access_point_id, :p_dummy_access_point_id, 0, 1),
    1
  ) = 1
  --
  and (:p_m_l_same_status = 0 or pnm.net_address_status_code = pn.net_address_status_code)
  and (:p_m_l_same_category = 0 or pnm.salability_category_code = pn.salability_category_code)
  and (:p_m_l_same_naap = 0 or (pnm.naap_access_point_id = pn.naap_access_point_id or (pnm.naap_access_point_id is null and pn.naap_access_point_id is null)))
  --
  and pnm.net_address_status_code in (:p_ext_net_addr_stat_code)
  and pnm.salability_category_code in (:p_ext_sal_cat_code)
  --
  :p_ext_mask_clause
  --
  and tpnsm.phone_number_series_id(+) = pnm.phone_number_series_id
  and tpnsm.type(+) = :p_ext_tpns_type
  and :p_date between tpnsm.date_from(+) and tpnsm.date_to(+)
  and decode(:p_filter_mno_for_l,
    1, decode(tpnsm.phone_number_series_id, null, 0, 1),
    1
  ) = 1
  --
  :p_msisdn_lower_bound
  --
  :p_order_clause
  --
}'
  ;

begin
  ------------------------------
  XCheck_search_type(p_search_type);
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_set_phone_status is null, 'p_set_phone_status');
  util_pkg.XCheck_Cond_Invalid(p_set_phone_status and p_date_from_status is null, 'p_set_phone_status and p_date_from_status is null');
  util_pkg.XCheck_Cond_Invalid(p_set_phone_status and p_set_phone_status_code is null, 'p_set_phone_status and p_set_phone_status_code is null');
  util_pkg.XCheck_Cond_Invalid(p_set_phone_status and p_user_id is null, 'p_set_phone_status and p_user_id is null');
  util_pkg.XCheck_Cond_Invalid(p_set_phone_status and v_ret_phone_count, 'p_set_phone_status and p_ret_phone_count');
  ------------------------------
  if p_set_phone_status
  then
    ------------------------------
    v_lock := true;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(not v_order_by_msisdn and p_msisdn_lower_bound is not null, 'not p_order_by_msisdn and p_msisdn_lower_bound is not null');
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(p_count is null, 'p_count');
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Invalid(p_count <= 0, 'p_count <= 0');
  ------------------------------
  p_m_na_id := null;
  p_l_na_id := null;
  ------------------------------
  v_use_pn_stat_pns_index := install_pkg.nnget_option_bool(c_sett_use_status_pns_ind, c_def_use_status_pns_ind);
  ------------------------------
  if p_search_type = c_srch_type_dual
  then
    v_act_tpns_type := c_tpns_type_linked;
    v_ext_tpns_type := c_tpns_type_main;
    v_sql_text := v_sql_text_linked;
    v_act_mask := p_l_mask;
    v_ext_mask := p_m_mask;
    v_act_status := p_l_status;
    v_ext_status := p_m_status;
    v_act_category := p_l_category;
    v_ext_category := p_m_category;
    if v_order_by_msisdn
    then
      v_sql_text := replace(v_sql_text, ':p_order_clause', 'order by pnm.international_format, pn.international_format');
    else
      v_sql_text := replace(v_sql_text, ':p_order_clause', '');
    end if;
    if v_ret_phone_count
    then
      v_sql_text := replace(v_sql_text, ':p_cursor_descr', v_sql_count_curs);
    else
      v_sql_text := replace(v_sql_text, ':p_cursor_descr', v_sql_linked_curs);
    end if;
  else
    v_act_tpns_type := c_tpns_type_main;
    v_ext_tpns_type := null;
    v_sql_text := v_sql_text_not_linked;
    v_act_mask := p_m_mask;
    v_ext_mask := null;
    v_act_status := p_m_status;
    v_ext_status := null;
    v_act_category := p_m_category;
    v_ext_category := null;
    if v_order_by_msisdn
    then
      v_sql_text := replace(v_sql_text, ':p_order_clause', 'order by pn.international_format');
    else
      v_sql_text := replace(v_sql_text, ':p_order_clause', '');
    end if;
    if v_ret_phone_count
    then
      v_sql_text := replace(v_sql_text, ':p_cursor_descr', v_sql_count_curs);
    else
      v_sql_text := replace(v_sql_text, ':p_cursor_descr', v_sql_not_linked_curs);
    end if;
  end if;
  ------------------------------
  ------------------------------
  v_cnt_opt := install_pkg.nnget_option_num(c_sett_many_pns_count, c_def_many_pns_count);
  v_cnt_act := get_ttpns_count(v_act_tpns_type);
  ------------------------------
  v_may_filter_by_pns := false;
  ------------------------------
  if v_cnt_act < v_cnt_opt
  then
    v_may_filter_by_pns := true;
  end if;
  ------------------------------
  ------------------------------
  v_may_use_pn_msisdn_index := false;
  ------------------------------
  if v_act_mask is not null
  then
    ------------------------------
    v_cnt_opt := install_pkg.nnget_option_num(c_sett_mask_digits_at_begin, c_def_mask_digits_at_begin);
    v_cnt_act := util_pkg.get_mask_digits_at_begin(v_act_mask);
    ------------------------------
    if v_cnt_opt >= 0 and v_cnt_act >= v_cnt_opt
    then
      v_may_use_pn_msisdn_index := true;
    end if;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_selective_sal_cats := util_ri.split_str_list(install_pkg.nnget_option_str(c_sett_selective_sal_cats, NULL, c_def_selective_sal_cats), true);
  ------------------------------
  v_may_use_pn_sal_index := false;
  ------------------------------
  if 1 = 1
    and util_pkg.get_count_ct_varchar_s(v_act_category) > 0
    and util_pkg.get_count_ct_varchar_s(v_selective_sal_cats) > 0
    and util_pkg.get_count_ct_varchar_s(util_pkg.filter_val_ct_varchar_s(v_act_category, v_selective_sal_cats, true)) > 0
    and util_pkg.get_count_ct_varchar_s(util_pkg.filter_val_ct_varchar_s(v_act_category, v_selective_sal_cats, false)) = 0
  then
    v_may_use_pn_sal_index := true;
  end if;
  ------------------------------
  ------------------------------
  v_may_use_pn_stat_index := false;
  ------------------------------
  if util_pkg.get_count_ct_varchar_s(v_act_status) > 0
  then
    v_may_use_pn_stat_index := true;
  end if;
  ------------------------------
  ------------------------------
  if v_may_filter_by_pns
  then
    ------------------------------
    if v_use_pn_stat_pns_index and v_may_use_pn_stat_index
    then
      ------------------------------
      v_sql_text := replace(v_sql_text, ':p_pn_tpns_clause', 'tt_phone_number_series tpns, phone_number pn');
      v_sql_text := replace(v_sql_text, ':p_pn_tpns_join_operation', 'use_nl(tpns, pn)');
      v_sql_text := replace(v_sql_text, ':p_tpns_access_path', 'full(tpns)');
      v_sql_text := replace(v_sql_text, ':p_pn_access_path', 'index_asc(pn, I_PHONENUM_NASC_EXT2)');
      ------------------------------
    else
      ------------------------------
      v_sql_text := replace(v_sql_text, ':p_pn_tpns_clause', 'tt_phone_number_series tpns, phone_number pn');
      v_sql_text := replace(v_sql_text, ':p_pn_tpns_join_operation', 'use_nl(tpns, pn)');
      v_sql_text := replace(v_sql_text, ':p_tpns_access_path', 'full(tpns)');
      v_sql_text := replace(v_sql_text, ':p_pn_access_path', 'index_asc(pn, I_PHONENUM_PNS_ID_EXT)');
      ------------------------------
    end if;
    ------------------------------
  elsif v_may_use_pn_msisdn_index
  then
    ------------------------------
    v_sql_text := replace(v_sql_text, ':p_pn_tpns_clause', 'phone_number pn, tt_phone_number_series tpns');
    v_sql_text := replace(v_sql_text, ':p_pn_tpns_join_operation', 'use_nl(tpns, pn)');
    v_sql_text := replace(v_sql_text, ':p_tpns_access_path', 'index_asc(tpns, I_TTPNS_PNSID)');
    v_sql_text := replace(v_sql_text, ':p_pn_access_path', 'index_asc(pn, I_PHONENUM_MSISDN_EXT)');
    ------------------------------
  elsif v_may_use_pn_sal_index
  then
    ------------------------------
    v_sql_text := replace(v_sql_text, ':p_pn_tpns_clause', 'phone_number pn, tt_phone_number_series tpns');
    v_sql_text := replace(v_sql_text, ':p_pn_tpns_join_operation', 'use_nl(tpns, pn)');
    v_sql_text := replace(v_sql_text, ':p_tpns_access_path', 'index_asc(tpns, I_TTPNS_PNSID)');
    v_sql_text := replace(v_sql_text, ':p_pn_access_path', 'index_asc(pn, I_PHONENUM_SCNA_EXT)');
    ------------------------------
  elsif v_may_use_pn_stat_index
  then
    ------------------------------
    if v_use_pn_stat_pns_index
    then
      ------------------------------
      v_sql_text := replace(v_sql_text, ':p_pn_tpns_clause', 'tt_phone_number_series tpns, phone_number pn');
      v_sql_text := replace(v_sql_text, ':p_pn_tpns_join_operation', 'use_nl(tpns, pn)');
      v_sql_text := replace(v_sql_text, ':p_tpns_access_path', 'full(tpns)');
      v_sql_text := replace(v_sql_text, ':p_pn_access_path', 'index_asc(pn, I_PHONENUM_NASC_EXT2)');
      ------------------------------
    else
      ------------------------------
      v_sql_text := replace(v_sql_text, ':p_pn_tpns_clause', 'phone_number pn, tt_phone_number_series tpns');
      v_sql_text := replace(v_sql_text, ':p_pn_tpns_join_operation', 'use_nl(tpns, pn)');
      v_sql_text := replace(v_sql_text, ':p_tpns_access_path', 'index_asc(tpns, I_TTPNS_PNSID)');
      v_sql_text := replace(v_sql_text, ':p_pn_access_path', 'index_asc(pn, I_PHONENUM_NASC_EXT)');
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    v_sql_text := replace(v_sql_text, ':p_pn_tpns_clause', 'tt_phone_number_series tpns, phone_number pn');
    v_sql_text := replace(v_sql_text, ':p_pn_tpns_join_operation', 'use_hash(tpns, pn)');
    v_sql_text := replace(v_sql_text, ':p_tpns_access_path', 'full(tpns)');
    v_sql_text := replace(v_sql_text, ':p_pn_access_path', 'full(pn)');
    ------------------------------
  end if;
  ------------------------------
  --!_! mask clause is not omitted in case of null v_XXX_mask to save queries likeness and use bind (it decreases number of query versions)
  ------------------------------
  if v_act_mask is not null
  then
    v_sql_text := replace(v_sql_text, ':p_act_mask_clause', 'and pn.international_format like :p_act_mask');
  else
    v_sql_text := replace(v_sql_text, ':p_act_mask_clause', 'and :p_act_mask is null');
  end if;
  ------------------------------
  if v_ext_mask is not null
  then
    v_sql_text := replace(v_sql_text, ':p_ext_mask_clause', 'and pnm.international_format like :p_ext_mask');
  else
    v_sql_text := replace(v_sql_text, ':p_ext_mask_clause', 'and :p_ext_mask is null');
  end if;
  ------------------------------
  v_tmp_str := util_pkg.merge_string(util_pkg.cast_ct_varchar_s2varchar(v_act_status), v_delim01, util_pkg.c_quote, util_pkg.c_quote);
  v_sql_text := replace(v_sql_text, ':p_act_net_addr_stat_code', nvl(v_tmp_str, 'pn.net_address_status_code'));
  ------------------------------
  v_tmp_str := util_pkg.merge_string(util_pkg.cast_ct_varchar_s2varchar(v_ext_status), v_delim01, util_pkg.c_quote, util_pkg.c_quote);
  v_sql_text := replace(v_sql_text, ':p_ext_net_addr_stat_code', nvl(v_tmp_str, 'pnm.net_address_status_code'));
  ------------------------------
  v_tmp_str := util_pkg.merge_string(util_pkg.cast_ct_varchar_s2varchar(v_act_category), v_delim01, util_pkg.c_quote, util_pkg.c_quote);
  v_sql_text := replace(v_sql_text, ':p_act_sal_cat_code', nvl(v_tmp_str, 'pn.salability_category_code'));
  ------------------------------
  v_tmp_str := util_pkg.merge_string(util_pkg.cast_ct_varchar_s2varchar(v_ext_category), v_delim01, util_pkg.c_quote, util_pkg.c_quote);
  v_sql_text := replace(v_sql_text, ':p_ext_sal_cat_code', nvl(v_tmp_str, 'pnm.salability_category_code'));
  ------------------------------
  --!_! mask clause is not omitted in part of compare length of msisdn (and length(pn.international_format) = length(:p_msisdn_lower_bound))
  ------------------------------
  if p_msisdn_lower_bound is not null
  then
    v_sql_text := replace(v_sql_text, ':p_msisdn_lower_bound', 'and pn.international_format > :p_msisdn_lower_bound');
  else
    v_sql_text := replace(v_sql_text, ':p_msisdn_lower_bound', 'and :p_msisdn_lower_bound is null');
  end if;
  ------------------------------
  if install_pkg.nnget_option_bool(c_opt_log_clob, c_def_log_clob)
  then
    util_loc_pkg.log_clob(util_ri.c_lct_search_pkg, v_sql_text);
  end if;
  ------------------------------
  if p_search_type = c_srch_type_dual
  then
    open v_cursor for v_sql_text using
      v_act_tpns_type,
      v_date,
      --
      v_date,
      --
      v_linked_naap, c_dummy_access_point_id, c_dummy_access_point_id,
      --
      c_dummy_msisdn,
      --
      v_act_mask,
      --
      v_date,
      --
      v_linked_naap, c_dummy_access_point_id, c_dummy_access_point_id,
      --
      v_m_l_same_status,
      v_m_l_same_category,
      v_m_l_same_naap,
      --
      v_ext_mask,
      --
      v_ext_tpns_type,
      v_date,
      v_filter_mno_for_l,
      --
      p_msisdn_lower_bound
      --
    ;
    ------------------------------
  else
    open v_cursor for v_sql_text using
      v_act_tpns_type,
      v_date,
      --
      v_date,
      --
      v_linked_naap, c_dummy_access_point_id, c_dummy_access_point_id,
      --
      v_linked_pl, c_dummy_msisdn, c_dummy_msisdn,
      v_linked_pl, c_dummy_msisdn, c_dummy_msisdn,
      --
      v_act_mask,
      --
      p_msisdn_lower_bound
      --
    ;
    ------------------------------
  end if;
  ------------------------------
  loop
    ------------------------------
    if v_ret_phone_count
    then
      ------------------------------
      fetch v_cursor into v_pn_count;
      ------------------------------
      exit when v_cursor%notfound;
      ------------------------------
      p_pn_count := v_pn_count;
      ------------------------------
    else
      ------------------------------
      if p_search_type = c_srch_type_dual
      then
        ------------------------------
        fetch v_cursor into v_m_na_id, v_l_na_id;
        ------------------------------
      else
        ------------------------------
        fetch v_cursor into v_m_na_id;
        ------------------------------
      end if;
      ------------------------------
      exit when v_cursor%notfound;
      ------------------------------
      if v_lock
      then
        ------------------------------
        v_sp_name := util_sys_pkg.make_savepoint;
        ------------------------------
        v_lock_res := util_ri.lock_1pn(v_m_na_id, FALSE);
        ------------------------------
        if v_lock_res and p_search_type = c_srch_type_dual
        then
          ------------------------------
          v_lock_res := util_ri.lock_1pn(v_l_na_id, FALSE);
          ------------------------------
        end if;
        ------------------------------
        if NOT v_lock_res
        then
          ------------------------------
          util_sys_pkg.rollback_savepoint(v_sp_name);
          ------------------------------
          continue;
          ------------------------------
        end if;
        ------------------------------
      end if;
      ------------------------------
      if p_set_phone_status
      then
        ------------------------------
        v_res_set_na_status := util_ext_ri.set_na_status3
        (
         p_na_id => v_m_na_id,
         p_status => p_set_phone_status_code,
         p_date => p_date_from_status,
         p_user_id => p_user_id,
         p_lock_pn => v_lock,
         p_error_code => v_error_code,
         p_error_message => v_error_message
        );
        ------------------------------
        if not v_res_set_na_status
        then
          ------------------------------
          continue;
          ------------------------------
        end if;
        ------------------------------
      end if;
      ------------------------------
      util_pkg.add_ct_number_val(p_m_na_id, v_m_na_id);
      ------------------------------
      if p_search_type = c_srch_type_dual
      then
        util_pkg.add_ct_number_val(p_l_na_id, v_l_na_id);
      end if;
      ------------------------------
      exit when p_count is not null and p_m_na_id.count >= p_count;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  install_pkg.close_cursor(v_cursor);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_phones_m_i
(
    p_mask varchar2,
    p_status ct_varchar_s,
    p_category ct_varchar_s,
    p_count number,
    p_lock boolean,
    p_linked_naap boolean,
    p_set_phone_status boolean,
    p_date_from_status date,
    p_set_phone_status_code varchar2,
    p_ret_phone_count boolean,
    p_user_id number,
    p_na_id out ct_number,
    p_pn_count out number
)
is
  v_l_na_id ct_number;
begin
  ------------------------------
  find_phones_i
  (
    p_search_type => c_srch_type_single,
    p_m_mask => p_mask,
    p_m_status => p_status,
    p_m_category => p_category,
    p_l_mask => NULL,
    p_l_status => NULL,
    p_l_category => NULL,
    p_count => p_count,
    p_lock => p_lock,
    p_linked_pl => FALSE,
    p_linked_naap => p_linked_naap,
    p_filter_mno_for_l => NULL,
    p_m_l_same_status => NULL,
    p_m_l_same_category => NULL,
    p_m_l_same_naap => NULL,
    p_order_by_msisdn => FALSE,
    p_msisdn_lower_bound => NULL,
    p_set_phone_status => p_set_phone_status,
    p_date_from_status => p_date_from_status,
    p_set_phone_status_code => p_set_phone_status_code,
    p_ret_phone_count => p_ret_phone_count,
    p_user_id => p_user_id,
    p_m_na_id => p_na_id,
    p_l_na_id => v_l_na_id,
    p_pn_count => p_pn_count
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_phones_l_i
(
    p_m_mask varchar2,
    p_m_status ct_varchar_s,
    p_m_category ct_varchar_s,
    p_l_mask varchar2,
    p_l_status ct_varchar_s,
    p_l_category ct_varchar_s,
    p_count number,
    p_lock boolean,
    p_linked_naap boolean,
    p_filter_mno_for_l boolean,
    p_m_l_same_status boolean,
    p_m_l_same_category boolean,
    p_m_l_same_naap boolean,
    p_set_phone_status boolean,
    p_date_from_status date,
    p_set_phone_status_code varchar2,
    p_ret_phone_count boolean,
    p_user_id number,
    p_m_na_id out ct_number,
    p_l_na_id out ct_number,
    p_pn_count out number
)
is
begin
  ------------------------------
  find_phones_i
  (
    p_search_type => c_srch_type_dual,
    p_m_mask => p_m_mask,
    p_m_status => p_m_status,
    p_m_category => p_m_category,
    p_l_mask => p_l_mask,
    p_l_status => p_l_status,
    p_l_category => p_l_category,
    p_count => p_count,
    p_lock => p_lock,
    p_linked_pl => NULL,
    p_linked_naap => p_linked_naap,
    p_filter_mno_for_l => p_filter_mno_for_l,
    p_m_l_same_status => p_m_l_same_status,
    p_m_l_same_category => p_m_l_same_category,
    p_m_l_same_naap => p_m_l_same_naap,
    p_order_by_msisdn => FALSE,
    p_msisdn_lower_bound => NULL,
    p_set_phone_status => p_set_phone_status,
    p_date_from_status => p_date_from_status,
    p_set_phone_status_code => p_set_phone_status_code,
    p_ret_phone_count => p_ret_phone_count,
    p_user_id => p_user_id,
    p_m_na_id => p_m_na_id,
    p_l_na_id => p_l_na_id,
    p_pn_count => p_pn_count
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_phones_any_pl_ord_i
(
    p_mask varchar2,
    p_status ct_varchar_s,
    p_category ct_varchar_s,
    p_count number,
    p_lock boolean,
    p_linked_naap boolean,
    p_msisdn_lower_bound varchar2,
    p_na_id out ct_number
)
is
  v_l_na_id ct_number;
  v_pn_count number;
begin
  ------------------------------
  find_phones_i
  (
    p_search_type => c_srch_type_single,
    p_m_mask => p_mask,
    p_m_status => p_status,
    p_m_category => p_category,
    p_l_mask => NULL,
    p_l_status => NULL,
    p_l_category => NULL,
    p_count => p_count,
    p_lock => p_lock,
    p_linked_pl => NULL,
    p_linked_naap => p_linked_naap,
    p_filter_mno_for_l => NULL,
    p_m_l_same_status => NULL,
    p_m_l_same_category => NULL,
    p_m_l_same_naap => NULL,
    p_order_by_msisdn => TRUE,
    p_msisdn_lower_bound => p_msisdn_lower_bound,
    p_set_phone_status => FALSE,
    p_date_from_status => NULL,
    p_set_phone_status_code => NULL,
    p_ret_phone_count => FALSE,
    p_user_id => NULL,
    p_m_na_id => p_na_id,
    p_l_na_id => v_l_na_id,
    p_pn_count => v_pn_count
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Find_Linked_Phones_i
(
    p_extended                 boolean,
    p_host_id                  varchar2,
    p_network_operator_code    network_operator.network_operator_code%type,
    p_phone_number_series_id   phone_number_series.phone_number_series_id%type,
    p_linked_network_operator  network_operator.network_operator_code%type,
    p_salability_cat_code_l    util_pkg.cit_varchar_s,
    p_phone_status_code_l      util_pkg.cit_varchar_s,
    p_mask                     varchar2,
    p_phone_count              number,
    p_set_phone_status_code    phone_number.net_address_status_code%type,
    p_user_login               varchar2,
    p_link_status              number,
    p_error_code               out number,
    p_error_message            out varchar2,
    p_result_list              out sys_refcursor
)
is
  v_extended boolean := util_pkg.bool_to_bool_2val(p_extended);
  v_date date := sysdate;
  v_user_id number;
  v_host_empty boolean;
  v_host_id ct_number;
  v_mask varchar2(4000);
  v_status ct_varchar_s;
  v_category ct_varchar_s;
  v_phone_count number;
  v_linked_naap boolean;
  --
  v_network_operator_id_m number;
  v_network_operator_id_l number;
  --
  v_m_na_id ct_number;
  v_l_na_id ct_number;
  v_pn_count number;
  --
  v_set_phone_status boolean;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_network_operator_code is null, 'p_network_operator_code');
  util_pkg.XCheck_Cond_Missing(p_linked_network_operator is null, 'p_linked_network_operator');
  util_pkg.XCheckP_cit_varchar_s(p_salability_cat_code_l, 'p_salability_cat_code_l');
  util_pkg.XCheckP_cit_varchar_s(p_phone_status_code_l, 'p_phone_status_code_l');
  util_pkg.XCheck_Cond_Missing(p_phone_count is null, 'p_phone_count');
  ------------------------------
  v_user_id := util_ri.xget_user_id(p_user_login);
  ------------------------------
  v_mask := normalize_mask(p_mask);
  ------------------------------
  normalize_str_host_id2(p_host_id, v_date, TRUE, v_host_id, v_host_empty);
  ------------------------------
  v_status := util_pkg.cast_cit2ct_varchar_s(p_phone_status_code_l, true);
  ------------------------------
  v_category := util_pkg.cast_cit2ct_varchar_s(p_salability_cat_code_l, true);
  ------------------------------
  v_phone_count := p_phone_count;
  ------------------------------
  v_linked_naap := get_linked_naap_value(p_link_status);
  ------------------------------
  v_network_operator_id_m := util_ri.xget_network_operator_id2(p_network_operator_code, v_date);
  v_network_operator_id_l := util_ri.xget_network_operator_id2(p_linked_network_operator, v_date);
  ------------------------------
  prepare_pso_pns_normal_ml
  (
    p_network_operator_id_m => v_network_operator_id_m,
    p_network_operator_id_l => v_network_operator_id_l,
    p_phone_number_series_id_m => p_phone_number_series_id,
    p_phone_number_series_id_l => NULL,
    p_host_empty_m => v_host_empty,
    p_host_empty_l => FALSE,
    p_host_id_m => v_host_id,
    p_host_id_l => NULL,
    p_pns_type_m => NULL,
    p_pns_type_l => NULL,
    p_shuffle_m => true,
    p_shuffle_l => true
  );
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  v_set_phone_status := (p_set_phone_status_code is not null);
  ------------------------------
  find_phones_l_i
  (
    p_m_mask => v_mask,
    p_m_status => v_status, --!_!
    p_m_category => v_category, --!_! category and status about main
    p_l_mask => NULL,
    p_l_status => v_status, --!_!
    p_l_category => NULL,
    p_count => v_phone_count,
    p_lock => TRUE, --!_! see p_lock_pn in util_ext_ri.set_na_status2
    p_linked_naap => v_linked_naap,
    p_filter_mno_for_l => TRUE,
    p_m_l_same_status => TRUE, --!_!
    p_m_l_same_category => FALSE,
    p_m_l_same_naap => TRUE, --!_!
    p_set_phone_status => v_set_phone_status,
    p_date_from_status => v_date,
    p_set_phone_status_code => p_set_phone_status_code,
    p_ret_phone_count => FALSE,
    p_user_id => v_user_id,
    p_m_na_id => v_m_na_id,
    p_l_na_id => v_l_na_id,
    p_pn_count => v_pn_count
  );
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  if v_extended
  then
    get_result_cursor01(v_m_na_id, v_l_na_id, v_date, p_result_list);
  else
    get_result_cursor02(v_m_na_id, v_l_na_id, v_date, p_result_list);
  end if;
  ------------------------------
  commit;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Find_Linked_Phones
(
    p_host_id                  varchar2,
    p_network_operator_code    network_operator.network_operator_code%type,
    p_phone_number_series_id   phone_number_series.phone_number_series_id%type,
    p_linked_network_operator  network_operator.network_operator_code%type,
    p_salability_cat_code_l    util_pkg.cit_varchar_s,
    p_phone_status_code_l      util_pkg.cit_varchar_s,
    p_mask                     varchar2,
    p_phone_count              number,
    p_set_phone_status_code    phone_number.net_address_status_code%type,
    p_user_login               varchar2,
    p_error_code               out number,
    p_error_message            out varchar2,
    p_result_list              out sys_refcursor
)
is
begin
  ------------------------------
  Find_Linked_Phones_i
  (
    p_extended                 => FALSE,
    p_host_id                  => p_host_id,
    p_network_operator_code    => p_network_operator_code,
    p_phone_number_series_id   => p_phone_number_series_id,
    p_linked_network_operator  => p_linked_network_operator,
    p_salability_cat_code_l    => p_salability_cat_code_l,
    p_phone_status_code_l      => p_phone_status_code_l,
    p_mask                     => p_mask,
    p_phone_count              => p_phone_count,
    p_set_phone_status_code    => p_set_phone_status_code,
    p_user_login               => p_user_login,
    p_link_status              => util_ri.c_link_status_free,
    p_error_code               => p_error_code,
    p_error_message            => p_error_message,
    p_result_list              => p_result_list
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Find_Linked_Phones_Ex
(
    p_host_id                  varchar2,
    p_network_operator_code    network_operator.network_operator_code%type,
    p_phone_number_series_id   phone_number_series.phone_number_series_id%type,
    p_linked_network_operator  network_operator.network_operator_code%type,
    p_salability_cat_code_l    util_pkg.cit_varchar_s,
    p_phone_status_code_l      util_pkg.cit_varchar_s,
    p_mask                     varchar2,
    p_phone_count              number,
    p_set_phone_status_code    phone_number.net_address_status_code%type,
    p_user_login               varchar2,
    p_link_status              number,
    p_error_code               out number,
    p_error_message            out varchar2,
    p_result_list              out sys_refcursor
)
is
begin
  ------------------------------
  Find_Linked_Phones_i
  (
    p_extended                 => TRUE,
    p_host_id                  => p_host_id,
    p_network_operator_code    => p_network_operator_code,
    p_phone_number_series_id   => p_phone_number_series_id,
    p_linked_network_operator  => p_linked_network_operator,
    p_salability_cat_code_l    => p_salability_cat_code_l,
    p_phone_status_code_l      => p_phone_status_code_l,
    p_mask                     => p_mask,
    p_phone_count              => p_phone_count,
    p_set_phone_status_code    => p_set_phone_status_code,
    p_user_login               => p_user_login,
    p_link_status              => p_link_status,
    p_error_code               => p_error_code,
    p_error_message            => p_error_message,
    p_result_list              => p_result_list
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure PROD_GetLinkedPhonesAll_i
(
  p_host_id number,
  p_network_operator_code varchar2,
  p_linked_network_operator_code varchar2,
  p_phone_type varchar2,
  p_salability_category varchar2,
  p_mask varchar2,
  p_phone_number_status_code varchar2,
  p_set_phone_number_status_code varchar2,
  p_phone_number_count number,
  p_user_login varchar2,
  p_m_na_id out ct_number,
  p_l_na_id out ct_number
)
is
  --
  v_sp_name varchar2(30);
  v_date date := sysdate;
  v_user_id number;
  v_host_empty boolean;
  v_host_id ct_number;
  v_mask varchar2(4000);
  v_status ct_varchar_s;
  v_category ct_varchar_s;
  v_phone_count number;
  v_linked_naap boolean;
  --
  v_pns_type ct_varchar_s;
  --
  v_network_operator_id_m number;
  v_network_operator_id_l number;
  --
  v_set_phone_status boolean;
  --
  v_pn_count number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  --!_! util_pkg.xcheck_cond_missing(p_host_id is null, 'p_host_id');
  util_pkg.xcheck_cond_missing(p_network_operator_code is null, 'p_network_operator_code');
  util_pkg.xcheck_cond_missing(p_linked_network_operator_code is null, 'p_linked_network_operator_code');
  util_pkg.xcheck_cond_missing(p_phone_type is null, 'p_phone_type');
  util_pkg.xcheck_cond_missing(p_salability_category is null, 'p_salability_category');
  util_pkg.xcheck_cond_missing(p_phone_number_status_code is null, 'p_phone_number_status_code');
  util_pkg.xcheck_cond_missing(p_phone_number_count is null, 'p_phone_number_count');
  ------------------------------
  v_user_id := util_ri.xget_user_id(p_user_login);
  ------------------------------
  --!_! v_mask := normalize_mask(p_mask);
  v_mask := p_mask;
  ------------------------------
  v_host_empty := (p_host_id is null);
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_status, p_phone_number_status_code);
  util_pkg.add_ct_varchar_s_val(v_category, p_salability_category);
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_pns_type, p_phone_type);
  ------------------------------
  v_phone_count := p_phone_number_count;
  ------------------------------
  v_linked_naap := FALSE; --!_!
  ------------------------------
  v_network_operator_id_m := util_ri.xget_network_operator_id2(p_network_operator_code, v_date);
  v_network_operator_id_l := util_ri.xget_network_operator_id2(p_linked_network_operator_code, v_date);
  ------------------------------
  prepare_pso_pns_normal_ml
  (
    p_network_operator_id_m => v_network_operator_id_m,
    p_network_operator_id_l => v_network_operator_id_l,
    p_phone_number_series_id_m => NULL, --!_!
    p_phone_number_series_id_l => NULL, --!_!
    p_host_empty_m => v_host_empty,
    p_host_empty_l => FALSE,
    p_host_id_m => v_host_id,
    p_host_id_l => NULL,
    p_pns_type_m => NULL,
    p_pns_type_l => v_pns_type, --!_!
    p_shuffle_m => true,
    p_shuffle_l => true
  );
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  v_set_phone_status := p_set_phone_number_status_code is not null;
  ------------------------------
  find_phones_l_i
  (
    p_m_mask => v_mask,
    p_m_status => v_status, --!_!
    p_m_category => v_category,
    p_l_mask => NULL,
    p_l_status => v_status, --!_!
    p_l_category => NULL,
    p_count => v_phone_count,
    p_lock => TRUE, --!_! see p_lock_pn in util_ext_ri.set_na_status2
    p_linked_naap => v_linked_naap,
    p_filter_mno_for_l => TRUE,
    p_m_l_same_status => TRUE, --!_!
    p_m_l_same_category => FALSE,
    p_m_l_same_naap => TRUE, --!_!
    p_set_phone_status => v_set_phone_status,
    p_date_from_status => v_date,
    p_set_phone_status_code => p_set_phone_number_status_code,
    p_ret_phone_count => FALSE,
    p_user_id => v_user_id,
    p_m_na_id => p_m_na_id,
    p_l_na_id => p_l_na_id,
    p_pn_count => v_pn_count
  );
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception();
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure GetFreePhones_i
(
    p_host_codes util_pkg.cit_varchar_s,
    p_network_operator_code network_operator.network_operator_code%type,
    p_network_operator_code_linked network_operator.network_operator_code%type,
    p_phone_type util_pkg.cit_varchar_s,
    p_salability_categorys util_pkg.cit_varchar_s,
    p_mask varchar2,
    p_phone_number_status_code util_pkg.cit_varchar_s,
    p_phone_number_count number,
    p_search_type OUT number,
    p_m_na_id out ct_number,
    p_l_na_id out ct_number
)
is
  v_date date := sysdate;
  v_host_codes util_pkg.cit_varchar_s;
  v_host_empty boolean;
  v_host_id ct_number;
  v_mask varchar2(4000);
  v_pns_type ct_varchar_s;
  v_status ct_varchar_s;
  v_category ct_varchar_s;
  v_phone_count number;
  v_linked_naap boolean;
  --
  v_network_operator_id_m number;
  v_network_operator_id_l number;
  --
  v_pn_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_network_operator_code is null, 'p_network_operator_code');
  --!_!util_pkg.XCheck_Cond_Missing(p_linked_network_operator is null, 'p_linked_network_operator');
  --!_!util_pkg.XCheckP_cit_varchar_s(p_salability_categorys, 'p_salability_categorys');
  util_pkg.XCheckP_cit_varchar_s(p_phone_number_status_code, 'p_phone_number_status_code');
  util_pkg.XCheck_Cond_Missing(p_phone_number_count is null, 'p_phone_number_count');
  ------------------------------
  v_mask := normalize_mask(p_mask);
  ------------------------------
  if util_pkg.CheckP_cit_varchar_s(p_host_codes)
  then
    v_host_codes := p_host_codes;
  else
    v_host_codes(1) := util_ri.c_str_host_id_any;
  end if;
  normalize_coll_str_host_code2(v_host_codes, v_date, TRUE, v_host_id, v_host_empty);
  ------------------------------
  v_pns_type := util_pkg.cast_cit2ct_varchar_s(p_phone_type, true);
  ------------------------------
  v_status := util_pkg.cast_cit2ct_varchar_s(p_phone_number_status_code, true);
  ------------------------------
  v_category := util_pkg.cast_cit2ct_varchar_s(p_salability_categorys, true);
  ------------------------------
  v_phone_count := p_phone_number_count;
  ------------------------------
  v_linked_naap := FALSE;
  ------------------------------
  if p_network_operator_code_linked is null
  then
    p_search_type := c_srch_type_single;
  else
    p_search_type := c_srch_type_dual;
  end if;
  ------------------------------
  v_network_operator_id_m := util_ri.get_network_operator_id2(p_network_operator_code, v_date);
  util_pkg.XCheck_Cond_Invalid(v_network_operator_id_m is null, 'p_network_operator_code');
  ------------------------------
  if p_search_type = c_srch_type_dual
  then
    ------------------------------
    v_network_operator_id_l := util_ri.get_network_operator_id2(p_network_operator_code_linked, v_date);
    util_pkg.XCheck_Cond_Invalid(v_network_operator_id_l is null, 'p_network_operator_code_linked');
    ------------------------------
    prepare_pso_pns_normal_ml
    (
      p_network_operator_id_m => v_network_operator_id_m,
      p_network_operator_id_l => v_network_operator_id_l,
      p_phone_number_series_id_m => NULL,
      p_phone_number_series_id_l => NULL,
      p_host_empty_m => FALSE,
      p_host_empty_l => v_host_empty,
      p_host_id_m => NULL,
      p_host_id_l => v_host_id,
      p_pns_type_m => NULL,
      p_pns_type_l => v_pns_type,
      p_shuffle_m => true,
      p_shuffle_l => true
    );
    ------------------------------
    find_phones_l_i
    (
      p_m_mask => null,
      p_m_status => v_status, --!_!
      p_m_category => null,
      p_l_mask => v_mask,
      p_l_status => v_status, --!_!
      p_l_category => v_category,
      p_count => v_phone_count,
      p_lock => true,
      p_linked_naap => v_linked_naap,
      p_filter_mno_for_l => TRUE,
      p_m_l_same_status => TRUE, --!_!
      p_m_l_same_category => FALSE,
      p_m_l_same_naap => TRUE, --!_!
      p_set_phone_status => FALSE, --!_!
      p_date_from_status => NULL,
      p_set_phone_status_code => NULL,
      p_ret_phone_count => FALSE,
      p_user_id => NULL,
      p_m_na_id => p_m_na_id,
      p_l_na_id => p_l_na_id,
      p_pn_count => v_pn_count
    );
    ------------------------------
  else
    ------------------------------
    prepare_pso_pns_normal_m
    (
      p_network_operator_id => v_network_operator_id_m,
      p_phone_number_series_id => NULL,
      p_host_empty => v_host_empty,
      p_host_id => v_host_id,
      p_pns_type => v_pns_type,
      p_shuffle => true
    );
    ------------------------------
    find_phones_m_i
    (
      p_mask => v_mask,
      p_status => v_status,
      p_category => v_category,
      p_count => v_phone_count,
      p_lock => true,
      p_linked_naap => v_linked_naap,
      p_set_phone_status => FALSE, --!_!
      p_date_from_status => NULL,
      p_set_phone_status_code => NULL,
      p_ret_phone_count => FALSE,
      p_user_id => NULL,
      p_na_id => p_m_na_id,
      p_pn_count => v_pn_count
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ReservePhones_i
(
    p_in_m_na_id ct_number,
    p_in_l_na_id ct_number,
    p_search_type number,
    p_user_login varchar2,
    p_m_na_id out ct_number,
    p_l_na_id out ct_number
)
is
  v_date date := sysdate;
  v_user_id number;
  --
  v_m_na_id ct_number;
  v_l_na_id ct_number;
  --
  v_error_code ct_number;
  v_error_message ct_varchar;
  --
  v_res_set_na_status boolean;
  --
  v_error_code_filter ct_number;
  --
begin
  ------------------------------
  XCheck_search_type(p_search_type);
  ------------------------------
  v_user_id := util_ri.xget_user_id(p_user_login);
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  v_m_na_id := p_in_m_na_id;
  v_l_na_id := p_in_l_na_id;
  ------------------------------
  p_m_na_id := null;
  p_l_na_id := null;
  ------------------------------
  if util_pkg.CheckP_ct_number(v_m_na_id)
  then
    ------------------------------
    v_res_set_na_status := util_ext_ri.set_na_status2
    (
      p_na_id => v_m_na_id,
      p_status => rsig_utils.c_RESERVE_PHONE_NUMBER_CODE,
      p_date => v_date,
      p_user_id => v_user_id,
      p_break_on_error => FALSE,
      p_lock_pn => false,
      p_error_code => v_error_code,
      p_error_message => v_error_message
    );
    ------------------------------
    if not v_res_set_na_status
    then
      ------------------------------
      util_pkg.add_ct_number_val(v_error_code_filter, util_pkg.c_ora_ok);
      ------------------------------
      v_m_na_id := util_pkg.filter_ct_number(v_m_na_id, v_error_code, v_error_code_filter, true);
      ------------------------------
      if p_search_type = c_srch_type_dual
      then
        v_l_na_id := util_pkg.filter_ct_number(v_l_na_id, v_error_code, v_error_code_filter, true);
      end if;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  if util_pkg.CheckP_ct_number(v_m_na_id)
  then
    ------------------------------
    p_m_na_id := v_m_na_id;
    ------------------------------
    if p_search_type = c_srch_type_dual
    then
      p_l_na_id := v_l_na_id;
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure GetFreePhonesAndReserve_i
(
    p_host_codes               util_pkg.cit_varchar_s,
    p_network_operator_code    network_operator.network_operator_code%type,
    p_network_operator_code_linked network_operator.network_operator_code%type,
    p_phone_type               util_pkg.cit_varchar_s,
    p_salability_categorys     util_pkg.cit_varchar_s,
    p_mask                     varchar2,
    p_phone_number_status_code util_pkg.cit_varchar_s,
    p_phone_number_count       number,
    p_user_login               varchar2,
    p_result_list              out sys_refcursor,
    p_m_na_id                  out ct_number,
    p_l_na_id                  out ct_number
)
is
  v_date date := sysdate;
  --
  v_m_na_id ct_number;
  v_l_na_id ct_number;
  --
  v_search_type number; --!_! OUT
  --
begin
  ------------------------------
  GetFreePhones_i
  (
    p_host_codes,
    p_network_operator_code,
    p_network_operator_code_linked,
    p_phone_type,
    p_salability_categorys,
    p_mask,
    p_phone_number_status_code,
    p_phone_number_count,
    v_search_type, --!_! OUT
    v_m_na_id,
    v_l_na_id
  );
  ------------------------------
  ReservePhones_i
  (
    v_m_na_id,
    v_l_na_id,
    v_search_type,
    p_user_login,
    p_m_na_id,
    p_l_na_id
  );
  ------------------------------
  get_result_cursor03(p_m_na_id, p_l_na_id, v_date, map_types_srch2tpns(v_search_type), p_result_list);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure GetPhonesByStatus2_ii
(
    p_host_id                  util_pkg.cit_varchar_s,
    p_network_operator_code    network_operator.network_operator_code%type,
    p_is_netop_code_mandatory  number := util_pkg.c_true,
    p_phone_type               phone_number_series.phone_number_type_code%type,
    p_is_phone_type_mandatory  number := util_pkg.c_true,
    p_salability_category      util_pkg.cit_varchar_s,
    p_series_id                phone_number_series.phone_number_series_id%type,
    p_mask                     varchar2,
    p_use_linked               number,
    p_phone_number_status_code util_pkg.cit_varchar_s,
    p_set_phone_number_status_code phone_number.net_address_status_code%type,
    p_startingrow              number,
    p_phone_number_count       number,
    p_user_id                  number,
    p_m_na_id                  out ct_number
)
is
  v_date date := sysdate;
  v_host_empty boolean;
  v_host_id ct_number;
  v_mask varchar2(4000);
  v_pns_type ct_varchar_s;
  v_status ct_varchar_s;
  v_category ct_varchar_s;
  v_phone_count number;
  v_linked_naap boolean;
  --
  v_m_na_id ct_number;
  --
  v_is_netop_code_mandatory boolean := util_pkg.int_to_bool_2val(p_is_netop_code_mandatory);
  v_is_phone_type_mandatory boolean := util_pkg.int_to_bool_2val(p_is_phone_type_mandatory);
  v_network_operator_id number;
  --
  v_set_phone_status boolean;
  --
  v_pn_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_is_netop_code_mandatory is null, 'p_is_netop_code_mandatory');
  util_pkg.XCheck_Cond_Missing(p_is_phone_type_mandatory is null, 'p_is_phone_type_mandatory');
  ------------------------------
  --!_! util_pkg.XCheckP_cit_varchar_s(p_salability_category, 'p_salability_category');
  util_pkg.XCheckP_cit_varchar_s(p_phone_number_status_code, 'p_phone_number_status_code');
  -- !_! util_pkg.XCheck_Cond_Missing(p_phone_number_count is null, 'p_phone_number_count');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_loc_pkg.touch_number(p_startingrow);
  ------------------------------
  v_mask := normalize_mask(p_mask);
  ------------------------------
  normalize_coll_str_host_id2(p_host_id, v_date, TRUE, v_host_id, v_host_empty);
  ------------------------------
  if v_is_phone_type_mandatory
  then
    ------------------------------
    util_pkg.XCheck_Cond_Missing(p_phone_type is null, 'p_phone_type');
    util_pkg.add_ct_varchar_s_val(v_pns_type, p_phone_type);
    ------------------------------
  end if;
  ------------------------------
  v_status := util_pkg.cast_cit2ct_varchar_s(p_phone_number_status_code, true);
  ------------------------------
  v_category := util_pkg.cast_cit2ct_varchar_s(p_salability_category, true);
  ------------------------------
  v_phone_count := p_phone_number_count;
  ------------------------------
  v_linked_naap := get_linked_naap_value2(p_use_linked);
  ------------------------------
  if v_is_netop_code_mandatory
  then
    ------------------------------
    util_pkg.XCheck_Cond_Missing(p_network_operator_code is null, 'p_network_operator_code');
    v_network_operator_id := util_ri.get_network_operator_id2(p_network_operator_code, v_date);
    util_pkg.XCheck_Cond_Invalid(v_network_operator_id is null, 'p_network_operator_code');
    ------------------------------
  end if;
  ------------------------------
  prepare_pso_pns_normal_m
  (
    p_network_operator_id => v_network_operator_id,
    p_phone_number_series_id => p_series_id,
    p_host_empty => v_host_empty,
    p_host_id => v_host_id,
    p_pns_type => v_pns_type,
    p_shuffle => true
  );
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  v_set_phone_status := (p_set_phone_number_status_code is not null);
  ------------------------------
  find_phones_m_i
  (
    p_mask => v_mask,
    p_status => v_status,
    p_category => v_category,
    p_count => v_phone_count,
    p_lock => true,
    p_linked_naap => v_linked_naap,
    p_set_phone_status => v_set_phone_status,
    p_date_from_status => v_date,
    p_set_phone_status_code => p_set_phone_number_status_code,
    p_ret_phone_count => FALSE,
    p_user_id => p_user_id,
    p_na_id => v_m_na_id,
    p_pn_count => v_pn_count
  );
  ------------------------------
  p_m_na_id := null;
  ------------------------------
  if util_pkg.CheckP_ct_number(v_m_na_id)
  then
    p_m_na_id := v_m_na_id;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure GetPhonesByStatus2_i
(
    p_host_id                  util_pkg.cit_varchar_s,
    p_network_operator_code    network_operator.network_operator_code%type,
    p_is_netop_code_mandatory  number := util_pkg.c_true,
    p_phone_type               phone_number_series.phone_number_type_code%type,
    p_is_phone_type_mandatory  number := util_pkg.c_true,
    p_salability_category      util_pkg.cit_varchar_s,
    p_series_id                phone_number_series.phone_number_series_id%type,
    p_mask                     varchar2,
    p_use_linked               number,
    p_phone_number_status_code util_pkg.cit_varchar_s,
    p_set_phone_number_status_code phone_number.net_address_status_code%type,
    p_startingrow              number,
    p_phone_number_count       number,
    p_user_login               varchar2,
    p_m_na_id                  out ct_number
)
is
  v_user_id number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_is_netop_code_mandatory is null, 'p_is_netop_code_mandatory');
  --!_!util_pkg.XCheck_Cond_Missing(p_network_operator_code is null, 'p_network_operator_code');
  --!_!util_pkg.XCheck_Cond_Missing(p_phone_type is null, 'p_phone_type');
  util_pkg.XCheckP_cit_varchar_s(p_salability_category, 'p_salability_category');
  util_pkg.XCheckP_cit_varchar_s(p_phone_number_status_code, 'p_phone_number_status_code');
  util_pkg.XCheck_Cond_Missing(p_phone_number_count is null, 'p_phone_number_count');
  util_pkg.XCheck_Cond_Missing(p_user_login is null, 'p_user_login');
  ------------------------------
  v_user_id := util_ri.xget_user_id(p_user_login);
  ------------------------------
  GetPhonesByStatus2_ii
  (
    p_host_id => p_host_id,
    p_network_operator_code => p_network_operator_code,
    p_is_netop_code_mandatory => p_is_netop_code_mandatory,
    p_phone_type => p_phone_type,
    p_is_phone_type_mandatory => p_is_phone_type_mandatory,
    p_salability_category => p_salability_category,
    p_series_id => p_series_id,
    p_mask => p_mask,
    p_use_linked => p_use_linked,
    p_phone_number_status_code => p_phone_number_status_code,
    p_set_phone_number_status_code => p_set_phone_number_status_code,
    p_startingrow => p_startingrow,
    p_phone_number_count => p_phone_number_count,
    p_user_id => v_user_id,
    p_m_na_id => p_m_na_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_phone_numbers_i
(
    p_network_operator_id number,
    p_external_operator_id number,
    p_phone_number_series_id number,
    p_host_id varchar2,
    p_mask varchar2,
    p_status util_pkg.cit_varchar_s,
    p_category util_pkg.cit_varchar_s,
    p_phone_number_type varchar2,
    p_count number,
    p_linked_naap boolean,
    p_msisdn_lower_bound varchar2,
    p_na_id out ct_number
)
is
  v_date date := sysdate;
  v_pns_type ct_varchar_s;
  v_tmp_host_id ct_varchar_s;
  v_host_id ct_number;
  v_host_empty boolean;
  v_status ct_varchar_s;
  v_category ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_network_operator_id is null, 'p_network_operator_id is null');
  ------------------------------
  if p_host_id is not null
  then
    util_pkg.add_ct_varchar_s_val(v_tmp_host_id, p_host_id);
  end if;
  normalize_coll_str_host_id(v_tmp_host_id, v_date, TRUE, v_host_id, v_host_empty);
  ------------------------------
  v_status := util_pkg.cast_cit2ct_varchar_s(p_status, true);
  v_category := util_pkg.cast_cit2ct_varchar_s(p_category, true);
  if p_phone_number_type is not null
  then
    util_pkg.add_ct_varchar_s_val(v_pns_type, p_phone_number_type);
  end if;
  ------------------------------
  if p_external_operator_id is null
  then
    prepare_pso_pns_normal_m
    (
      p_network_operator_id => p_network_operator_id,
      p_phone_number_series_id => p_phone_number_series_id,
      p_host_empty => v_host_empty,
      p_host_id => v_host_id,
      p_pns_type => v_pns_type,
      p_shuffle => true
    );
  else
    prepare_pso_pns_intersect_m
    (
      p_first_network_operator_id => p_network_operator_id,
      p_second_network_operator_id => p_external_operator_id,
      p_phone_number_series_id => p_phone_number_series_id,
      p_host_empty => v_host_empty,
      p_host_id => v_host_id,
      p_pns_type => v_pns_type,
      p_shuffle => true
    );
  end if;
  ------------------------------
  find_phones_any_pl_ord_i
  (
    p_mask => p_mask,
    p_status => v_status,
    p_category => v_category,
    p_count => p_count,
    p_lock => FALSE,
    p_linked_naap => p_linked_naap,
    p_msisdn_lower_bound => p_msisdn_lower_bound,
    p_na_id => p_na_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_free_phone_count_i
(
    p_host_id ct_number,
    p_host_empty boolean,
    p_network_operator_id number,
    p_phone_type varchar2,
    p_salability_category ct_varchar_s,
    p_series_id number,
    p_mask varchar2,
    p_use_linked number,
    p_phone_number_status_code ct_varchar_s,
    p_ps_id out ct_number,
    p_pn_count out ct_number
)
is
  v_date date := sysdate;
  v_mask varchar2(4000);
  v_pns_type ct_varchar_s;
  v_linked_naap boolean;
  --
  v_m_na_id ct_number;
  v_pn_count number;
  --
  v_pns cit_tt_pns;
  v_count number;
  v_l_na_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_host_empty is null, 'p_host_empty');
  util_pkg.XCheck_Cond_Missing(p_network_operator_id is null, 'p_network_operator_id');
  util_pkg.XCheck_Cond_Missing(p_phone_type is null, 'p_phone_type');
  util_pkg.XCheckP_ct_varchar_s(p_salability_category, 'p_salability_category');
  util_pkg.XCheckP_ct_varchar_s(p_phone_number_status_code, 'p_phone_number_status_code');
  ------------------------------
  v_mask := normalize_mask(p_mask);
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_pns_type, p_phone_type);
  ------------------------------
  v_linked_naap := get_linked_naap_value2(p_use_linked);
  ------------------------------
  prepare_pso_pns_normal_m
  (
    p_network_operator_id => p_network_operator_id,
    p_phone_number_series_id => p_series_id,
    p_host_empty => p_host_empty,
    p_host_id => p_host_id,
    p_pns_type => v_pns_type,
    p_shuffle => true
  );
  ------------------------------
  select *
    bulk collect into v_pns
    from tt_phone_number_series
  ;
  ------------------------------
  select phone_number_series_id
    bulk collect into p_ps_id
    from tt_phone_number_series
    group by phone_number_series_id
  ;
  ------------------------------
  v_count := util_pkg.get_count_ct_number(p_ps_id);
  util_pkg.resize_ct_number(p_pn_count, v_count);
  ------------------------------
  v_date := sysdate; --!_!
  ------------------------------
  delete from tt_phone_number_series;
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    delete from tt_phone_number_series;
    ------------------------------
    for v_j in 1..v_pns.count
    loop
      if v_pns(v_j).phone_number_series_id = p_ps_id(v_i)
      then
        insert into tt_phone_number_series
        values v_pns(v_j);
      end if;
    end loop;
    ------------------------------
    find_phones_i
    (
      p_search_type => c_srch_type_single,
      p_m_mask => v_mask,
      p_m_status => p_phone_number_status_code,
      p_m_category => p_salability_category,
      p_l_mask => NULL,
      p_l_status => NULL,
      p_l_category => NULL,
      p_count => NULL,
      p_lock => FALSE,
      p_linked_pl => FALSE,
      p_linked_naap => v_linked_naap,
      p_filter_mno_for_l => NULL,
      p_m_l_same_status => NULL,
      p_m_l_same_category => NULL,
      p_m_l_same_naap => NULL,
      p_order_by_msisdn => FALSE,
      p_msisdn_lower_bound => NULL,
      p_set_phone_status => FALSE,
      p_date_from_status => v_date,
      p_set_phone_status_code => NULL,
      p_ret_phone_count => TRUE,
      p_user_id => NULL,
      p_m_na_id => v_m_na_id,
      p_l_na_id => v_l_na_id,
      p_pn_count => v_pn_count
    );
    ------------------------------
    p_pn_count(v_i) := v_pn_count;
    ------------------------------
  end loop;
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_! SPECIAL CASE is pn.date_of_status_change <= p_date_of_change
procedure GetPhonesByTypeAndStatus
(
  p_phone_type varchar2,
  p_phone_number_status_code varchar2,
  p_set_phone_number_status varchar2,
  p_phone_number_count number,
  p_network_operator_code varchar2,
  p_date_of_change date,
  p_user_id number,
  p_result out sys_refcursor
)
is
  lc_same number := 0;
  lc_new number := 1;
  v_msisdn ct_varchar_s;
  v_date date;
  v_cnt number;
  v_user_id number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_phone_type is null, 'p_phone_type');
  util_pkg.XCheck_Cond_Missing(p_phone_number_status_code is null, 'p_phone_number_status_code');
  util_pkg.XCheck_Cond_Missing(p_set_phone_number_status is null, 'p_set_phone_number_status');
  --!_!util_pkg.XCheck_Cond_Missing(p_phone_number_count is null, 'p_phone_number_count');
  --!_!util_pkg.XCheck_Cond_Missing(p_network_operator_code is null, 'p_network_operator_code');
  util_pkg.XCheck_Cond_Missing(p_date_of_change is null, 'p_date_of_change'); --!_!
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  delete from tt_found_phone_numbers;
  delete from tt_phone_number_free_phones;
  ------------------------------
  v_cnt := 0;
  ------------------------------
  loop
    ------------------------------
    v_date := sysdate;
    ------------------------------
    if p_network_operator_code is null
    then
      ------------------------------
      insert into tt_found_phone_numbers
      (
        network_address_id,
        msisdn,
        error_code
      )
      select /*+ ordered use_hash(pns) full(pn) full(pns)*/
        pn.network_address_id,
        pn.international_format msisdn,
        null error_code
      from
        phone_number pn,
        phone_number_series pns
      where 1 = 1
        and pn.net_address_status_code = p_phone_number_status_code
        and pn.date_of_status_change <= p_date_of_change
        and not exists(select /*+ hash_aj full(tpn)*/ * from tt_phone_number_free_phones tpn where tpn.network_address_id = pn.network_address_id)
        and pns.phone_number_series_id = pn.phone_number_series_id
        and nvl(pns.deleted, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > v_date
        and pns.phone_number_type_code = p_phone_type
        and (p_phone_number_count is null or rownum <= p_phone_number_count - v_cnt)
      ;
      ------------------------------
    else
      ------------------------------
      insert into tt_found_phone_numbers
      (
        network_address_id,
        msisdn,
        error_code
      )
      select /*+ ordered use_hash(pns pso no) full(pn) full(pns) full(pso) full(no)*/
        pn.network_address_id,
        pn.international_format,
        null
      from
        phone_number pn,
        phone_number_series pns,
        phone_series_operator pso,
        network_operator no
      where 1 = 1
        and pn.net_address_status_code = p_phone_number_status_code
        and pn.date_of_status_change <= p_date_of_change
        and not exists(select /*+ hash_aj full(tpn)*/ * from tt_phone_number_free_phones tpn where tpn.network_address_id = pn.network_address_id)
        and pns.phone_number_series_id = pn.phone_number_series_id
        and nvl(pns.deleted, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > v_date
        and pns.phone_number_type_code = p_phone_type
        and pso.phone_number_series_id = pns.phone_number_series_id
        and v_date between pso.start_date and nvl(pso.end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
        and pso.network_operator_id = no.network_operator_id
        and nvl(no.deleted, to_date(' 4000-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss')) > v_date
        and no.network_operator_code = p_network_operator_code
        --!_!and no.network_operator_type is null --!_!all not only own
        and (p_phone_number_count is null or rownum <= p_phone_number_count - v_cnt)
      ;
      ------------------------------
    end if;
    ------------------------------
    insert into tt_phone_number_free_phones
    (
      network_address_id
    )
    select
      network_address_id
    from tt_found_phone_numbers z
    where 1 = 1
      and error_code is null
    ;
    ------------------------------
    select
      msisdn
      bulk collect into v_msisdn
    from tt_found_phone_numbers z
    where 1 = 1
      and error_code is null
    ;
    ------------------------------
    update
      tt_found_phone_numbers
    set
      error_code = util_pkg.c_ora_ok
    where 1 = 1
      and error_code is null
    ;
    ------------------------------
    v_date := sysdate;
    ------------------------------
    if util_pkg.get_count_ct_varchar_s(v_msisdn) > 0
    then
      ------------------------------
      api_ri_pkg.Set_Phone_Status_i
      (
        p_msisdn => v_msisdn,
        p_set_phone_status => p_set_phone_number_status,
        p_date => v_date,
        p_user_id => v_user_id,
        p_break_on_error => false,
        p_lock_pn => true,
        p_error_code => v_error_code,
        p_error_message => v_error_message
      );
      ------------------------------
      update /*+ ordered use_nl(tt) index(tt I_TT_FPN_MSISDN)*/
        tt_found_phone_numbers tt
      set
        (error_code, error_message) =
        (
          select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
            q2.error_code, q3.error_message
          from
            (select column_value msisdn, rownum rn from table(cast(v_msisdn as ct_varchar_s))) q1,
            (select column_value error_code, rownum rn from table(cast(v_error_code as ct_number))) q2,
            (select column_value error_message, rownum rn from table(cast(v_error_message as ct_varchar))) q3
          where 1 = 1
            and q1.msisdn = tt.msisdn
            and q2.rn = q1.rn
            and q3.rn = q1.rn
        )
      where 1 = 1
        and msisdn in
        (
          select /*+ ordered use_hash(q1 q2 q3) full(q1) full(q2) full(q3)*/
            q1.msisdn
          from
            (select column_value msisdn, rownum rn from table(cast(v_msisdn as ct_varchar_s))) q1,
            (select column_value error_code, rownum rn from table(cast(v_error_code as ct_number))) q2,
            (select column_value error_message, rownum rn from table(cast(v_error_message as ct_varchar))) q3
          where 1 = 1
            and q2.rn = q1.rn
            and q3.rn = q1.rn
        )
        and error_code = util_pkg.c_ora_ok
      ;
      ------------------------------
    else
      ------------------------------
      exit;
      ------------------------------
    end if;
    ------------------------------
    delete
    from tt_found_phone_numbers
    where 1 = 1
      and error_code != util_pkg.c_ora_ok
    ;
    ------------------------------
    select
      count(1)
      into v_cnt
    from tt_found_phone_numbers
    ;
    ------------------------------
    if 1 = 0
      or p_phone_number_count is null
      or v_cnt >= p_phone_number_count
    then
      ------------------------------
      exit;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  open p_result for
  select
    min(msisdn) phone_number,
    count(group_no) cnt,
    group_no
  from
  (
    select
      msisdn,
      sum(start_of_group) over (partition by 1 order by msisdn) group_no
    from
    (
      select
        msisdn,
        decode
        (
          to_number(lag(msisdn) over (partition by 1 order by msisdn)),
          to_number(msisdn) - 1, lc_same,
          lc_new
        ) start_of_group
      from tt_found_phone_numbers tt
      where 1 = 1
        and error_code = util_pkg.c_ora_ok
      order by msisdn
    ) t
  )
  group by group_no
  order by phone_number
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_result_cursor01(p_m_na_id ct_number, p_l_na_id ct_number, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q1, q2) use_nl(pnm, pnl, pnsm, naap, sc)
  index_asc(pnm, PK_PHONE_NUMBER)
  index_asc(pnl, PK_PHONE_NUMBER)
  index_asc(pnsm, PK_PHONE_NUMBER_SERIES)
  index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID2)
  index_asc(sc, PK_SIM_CARD)
  */
  pnm.international_format main_msisdn,
  pnl.international_format linked_msisdn,
  pnm.salability_category_code,
  pnsm.phone_number_type_code,
  pnm.net_address_status_code,
  sc.sn
  from
    (select column_value network_address_id, rownum rn from table(cast(p_m_na_id as ct_number))) q1,
    (select column_value network_address_id, rownum rn from table(cast(p_l_na_id as ct_number))) q2,
    phone_number pnm, phone_number pnl,
    phone_number_series pnsm, network_address_access_point naap, sim_card sc
  where 1 = 1
  and q2.rn(+) = q1.rn
  and pnm.network_address_id(+) = q1.network_address_id
  and nvl(pnm.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and pnl.network_address_id(+) = q2.network_address_id
  and nvl(pnl.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and pnsm.phone_number_series_id(+) = pnm.phone_number_series_id
  and nvl(pnsm.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and naap.network_address_id(+) = pnm.network_address_id
  and p_date between naap.from_date(+) and nvl(naap.to_date(+), to_date('01.01.4000', 'dd.mm.yyyy'))
  and sc.access_point_id(+) = naap.access_point_id
  and nvl(sc.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  order by q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor02(p_m_na_id ct_number, p_l_na_id ct_number, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q1, q2) use_nl(pnm, pnl)
  index_asc(pnm, PK_PHONE_NUMBER)
  index_asc(pnl, PK_PHONE_NUMBER)
  */
  pnm.international_format main_msisdn,
  pnl.international_format linked_msisdn,
  pnm.salability_category_code
  from
    (select column_value network_address_id, rownum rn from table(cast(p_m_na_id as ct_number))) q1,
    (select column_value network_address_id, rownum rn from table(cast(p_l_na_id as ct_number))) q2,
    phone_number pnm, phone_number pnl
  where 1 = 1
  and q2.rn(+) = q1.rn
  and pnm.network_address_id(+) = q1.network_address_id
  and nvl(pnm.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and pnl.network_address_id(+) = q2.network_address_id
  and nvl(pnl.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  order by q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor03(p_m_na_id ct_number, p_l_na_id ct_number, p_date date, p_tpns_type number, p_result out sys_refcursor)
is
begin
  ------------------------------
  if p_tpns_type = c_tpns_type_linked
  then
    ------------------------------
    open p_result for
select /*+ ordered use_hash(q1, q2, tpns) use_nl(pnm, pnl, h)
  index_asc(pnm, PK_PHONE_NUMBER)
  index_asc(pnl, PK_PHONE_NUMBER)
  full(tpns)
  index_asc(h, PK_HOST)
  */
  q1.network_address_id,
  pnm.international_format msisdn,
  h.host_code,
  tpns.phone_type_code,
  pnl.salability_category_code, --!_!
  pnl.international_format linked_msisdn
  from
    (select column_value network_address_id, rownum rn from table(cast(p_m_na_id as ct_number))) q1,
    (select column_value network_address_id, rownum rn from table(cast(p_l_na_id as ct_number))) q2,
    phone_number pnm, phone_number pnl,
    tt_phone_number_series tpns, host h
  where 1 = 1
  and q2.rn(+) = q1.rn
  and pnm.network_address_id(+) = q1.network_address_id
  and nvl(pnm.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and pnl.network_address_id(+) = q2.network_address_id
  and nvl(pnl.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and tpns.phone_number_series_id(+) = pnl.phone_number_series_id --!_!
  and tpns.type(+) = p_tpns_type
  and p_date between tpns.date_from(+) and tpns.date_to(+)
  and h.host_id(+) = tpns.host_id
  and nvl(h.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  order by q1.rn
    ;
    ------------------------------
  else
    ------------------------------
    open p_result for
select /*+ ordered use_hash(q1, q2, tpns) use_nl(pnm, pnl, h)
  index_asc(pnm, PK_PHONE_NUMBER)
  index_asc(pnl, PK_PHONE_NUMBER)
  full(tpns)
  index_asc(h, PK_HOST)
  */
  q1.network_address_id,
  pnm.international_format msisdn,
  h.host_code,
  tpns.phone_type_code,
  pnm.salability_category_code, --!_!
  pnl.international_format linked_msisdn --!_!
  from
    (select column_value network_address_id, rownum rn from table(cast(p_m_na_id as ct_number))) q1,
    (select column_value network_address_id, rownum rn from table(cast(p_l_na_id as ct_number))) q2,
    phone_number pnm, phone_number pnl,
    tt_phone_number_series tpns, host h
  where 1 = 1
  and q2.rn(+) = q1.rn
  and pnm.network_address_id(+) = q1.network_address_id
  and nvl(pnm.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and pnl.network_address_id(+) = q2.network_address_id
  and nvl(pnl.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and tpns.phone_number_series_id(+) = pnm.phone_number_series_id --!_!
  and tpns.type(+) = p_tpns_type
  and p_date between tpns.date_from(+) and tpns.date_to(+)
  and h.host_id(+) = tpns.host_id
  and nvl(h.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  order by q1.rn
    ;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor04(p_na_id ct_number, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_nl(pn)
  index_asc(pn, PK_PHONE_NUMBER)
  */
  q1.network_address_id,
  pn.international_format,
  pn.salability_category_code
  from
    (select column_value network_address_id, rownum rn from table(cast(p_na_id as ct_number))) q1,
    phone_number pn
  where 1 = 1
  and pn.network_address_id(+) = q1.network_address_id
  and nvl(pn.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  order by q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor05(p_na_id ct_number, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_nl(pn)
  index_asc(pn, PK_PHONE_NUMBER)
  */
  q1.network_address_id,
  pn.international_format
  from
    (select column_value network_address_id, rownum rn from table(cast(p_na_id as ct_number))) q1,
    phone_number pn
  where 1 = 1
  and pn.network_address_id(+) = q1.network_address_id
  and nvl(pn.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  order by q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor06(p_na_id ct_number, p_date date, p_result out sys_refcursor)
is
  v_ap_id ct_number;
  v_other_na_id ct_number;
  v_other_msisdn ct_varchar_s;
begin
  ------------------------------
  v_ap_id := util_ri.get_linked_ap_id(p_na_id, null, p_date, false);
  v_other_na_id := util_ri.get_pnlnk_other_side_exact(p_na_id, p_date);
  v_other_msisdn := util_ri.get_msisdn(v_other_na_id, p_date, false);
  ------------------------------
  open p_result for
select /*+ driving_site(pn) ordered use_nl(q1 pn) use_hash(q2 q3 nas psc)
  index_asc(pn, PK_PHONE_NUMBER)
  full(q2)
  full(q3)
  full(nas)
  full(psc)
  */
  q1.network_address_id,
  pn.international_format,
  nas.net_address_status_name,
  pn.net_address_status_code,
  psc.phone_salability_category_name salability_category_name,
  pn.salability_category_code,
  decode(q2.access_point_id, null, 0 , 1) count,
  q3.linked_msisdn
  from
    (select column_value network_address_id, rownum rn from table(cast(p_na_id as ct_number))) q1,
    phone_number pn,
    (select column_value access_point_id, rownum rn from table(cast(v_ap_id as ct_number))) q2,
    (select column_value linked_msisdn, rownum rn from table(cast(v_other_msisdn as ct_varchar_s))) q3,
    network_address_status nas,
    phone_salability_category psc
  where 1 = 1
  and q2.rn(+) = q1.rn
  and q3.rn(+) = q1.rn
  and pn.network_address_id(+) = q1.network_address_id
  and nvl(pn.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and nas.net_address_status_code(+) = pn.net_address_status_code
  and psc.phone_salability_category_code(+) = pn.salability_category_code
  order by q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor07(p_na_id ct_number, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_nl(pn)
  index_asc(pn, PK_PHONE_NUMBER)
  */
  pn.international_format
  from
    (select column_value network_address_id, rownum rn from table(cast(p_na_id as ct_number))) q1,
    phone_number pn
  where 1 = 1
  and pn.network_address_id(+) = q1.network_address_id
  and nvl(pn.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  order by q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor08(p_na_id ct_number, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_nl(pn, pns, naap, sc)
    index_asc(pn, PK_PHONE_NUMBER)
    index_asc(pns, PK_PHONE_NUMBER_SERIES)
    index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID)
    index_asc(sc, PK_SIM_CARD)
    */
    q1.network_address_id,
    pn.international_format,
    pns.phone_number_type_code,
    pn.salability_category_code,
    pn.net_address_status_code,
    sc.sn,
    pns.host_id
    from (select column_value network_address_id, rownum rn from table(cast(p_na_id as ct_number))) q1,
         phone_number pn,
         phone_number_series pns,
         network_address_access_point naap,
         sim_card sc
    where 1 = 1
    and pn.network_address_id(+) = q1.network_address_id
    and pns.phone_number_series_id(+) = pn.phone_number_series_id
    and naap.network_address_id(+) = q1.network_address_id
    and p_date between naap.from_date(+) and nvl(naap.to_date(+), p_date)
    and sc.access_point_id(+) = naap.access_point_id
    and nvl(pn.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
    and nvl(pns.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
    and nvl(sc.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
    order by q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor09(p_m_na_id ct_number, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q1, tpns) use_nl(pnm, pnl, h)
  index_asc(pnm, PK_PHONE_NUMBER)
  full(tpns)
  index_asc(h, PK_HOST)
  */
  q1.network_address_id,
  pnm.international_format msisdn,
  h.host_code,
  tpns.phone_type_code,
  pnm.salability_category_code --!_!
  from
    (select column_value network_address_id, rownum rn from table(cast(p_m_na_id as ct_number))) q1,
    phone_number pnm, phone_number pnl,
    tt_phone_number_series tpns, host h
  where 1 = 1
  and pnm.network_address_id(+) = q1.network_address_id
  and nvl(pnm.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and tpns.phone_number_series_id(+) = pnm.phone_number_series_id --!_!
  and tpns.type(+) = c_tpns_type_main
  and p_date between tpns.date_from(+) and tpns.date_to(+)
  and h.host_id(+) = tpns.host_id
  and nvl(h.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  order by q1.rn
  ;
  ------------------------------

end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
