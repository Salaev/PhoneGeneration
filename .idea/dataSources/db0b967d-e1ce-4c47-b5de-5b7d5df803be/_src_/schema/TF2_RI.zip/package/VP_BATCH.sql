CREATE package VP_BATCH is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'BATCH';

----------------------------------!---------------------------------------------
  function get1_i(p_id integer, p_lock boolean, p_wait boolean, p_is_locked out boolean) return batch%rowtype;

  function get1(p_id integer) return batch%rowtype;
  function xlock_get1(p_id integer) return batch%rowtype;

----------------------------------!---------------------------------------------
  procedure xvalid(p_rec batch%rowtype);
  function find_i_id(p_rec batch%rowtype) return boolean;

  function find_i(p_rec batch%rowtype) return boolean;
  procedure xunique_i(p_rec batch%rowtype);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec batch%rowtype);
  procedure change_i(p_rec batch%rowtype);

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy batch%rowtype);
  procedure version_change(p_rec in out nocopy batch%rowtype);
  procedure version_close(p_id integer);

----------------------------------!---------------------------------------------

end;
/
