CREATE package util_ext_ri is

----------------------------------!---------------------------------------------
  c_sett_allow_del_na_status     constant varchar2(100) := 'ALLOW_NETWORK_ADDRESS_STATUS_FOR_DELETE';
  c_sett_naap_def_link_typecodes constant varchar2(100) := 'NAAP_DEFAULT_LINK_TYPE_CODES';

----------------------------------!---------------------------------------------
  c_def_allow_del_na_status      constant varchar2(4000) := 'R';
  c_def_naap_def_link_typecodes  constant varchar2(4000) := 'S,S';

----------------------------------!---------------------------------------------
  function get_first_error_pos(p_error_code ct_number) return number;
  procedure get_first_error(p_error_code ct_number, p_error_message ct_varchar, p_error_code2 out number, p_error_message2 out varchar2);

  procedure setup_common_error(p_main_count number, p_error_code number, p_error_message varchar2, p_error_code2 out ct_number, p_error_message2 out ct_varchar, p_allow_nulls boolean := false);

  function make_group_error_message
  (
    p_problem_id number,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_group_error_message2
  (
    p_problem_id number,
    p_problem_code varchar2,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_group_error_message3
  (
    p_problem_id number,
    p_problem_code varchar2,
    p_problem_name varchar2,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_group_error_message4
  (
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_error_message4val_char
  (
    p_problem_value varchar2,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_error_message4val_char2
  (
    p_problem_value1 varchar2,
    p_problem_value2 varchar2,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_error_message4val_num
  (
    p_problem_value number,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_error_message4val_num2
  (
    p_problem_value1 number,
    p_problem_value2 number,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  procedure xcheck_group_error_params
  (
    p_problem_id number,
    p_problem_index number,
    p_group_start number,
    p_group_size number,
    p_group_error_code number,
    p_group_error_message varchar2,
    p_error_code ct_number,
    p_error_message ct_varchar,
    p_main_count out number
  );

  procedure setup_group_error_for_grp_head
  (
    p_problem_id number,
    p_problem_index number,
    p_group_start number,
    p_group_size number,
    p_group_error_code number,
    p_group_error_message varchar2,
    p_error_code in out nocopy ct_number,
    p_error_message in out nocopy ct_varchar
  );

  procedure setup_group_error_for_all
  (
    p_problem_id number,
    p_problem_index number,
    p_group_start number,
    p_group_size number,
    p_group_error_code number,
    p_group_error_message varchar2,
    p_error_code in out nocopy ct_number,
    p_error_message in out nocopy ct_varchar
  );

  procedure setup_error_by_marks0
  (
    p_marks ct_number,
    p_pivot ct_number,
    p_error_code number,
    p_error_message varchar2,
    p_mark_value number := util_pkg.c_true,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
  );

  procedure setup_error_by_marks
  (
    p_marks ct_number,
    p_error_code number,
    p_error_message varchar2,
    p_mark_value number := util_pkg.c_true,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
  );

  procedure xcheck_has_error
  (
    p_break_on_error boolean,
    p_error_codes ct_number,
    p_error_messages ct_varchar
  );

  procedure xcheck_has_error_NOT_ORA
  (
    p_break_on_error boolean,
    p_error_codes ct_number,
    p_error_messages ct_varchar
  );

----------------------------------!---------------------------------------------
  function is_na_status_internal(p_status varchar2) return boolean;

  function is_na_status_changable_i(p_old_status varchar2, p_new_status varchar2, p_date date, p_internal_allowed boolean, p_is_bp boolean) return boolean;
  function is_na_status_changable(p_old_status varchar2, p_new_status varchar2, p_date date) return boolean;
  function is_na_status_can_change_i(p_network_address_id number, p_new_status varchar2, p_date date) return boolean;
  function is_na_status_can_change(p_network_address_id number, p_new_status varchar2, p_date date, p_error_code out number, p_error_message out varchar2) return boolean;

----------------------------------!---------------------------------------------
  function is_ap_status_changable_i(p_old_status varchar2, p_new_status varchar2, p_date date, p_is_bp boolean) return boolean;
  function is_ap_status_changable(p_old_status varchar2, p_new_status varchar2, p_date date) return boolean;
  function is_ap_status_can_change_i(p_access_point_id number, p_new_status varchar2, p_date date) return boolean;
  function is_ap_status_can_change(p_access_point_id number, p_new_status varchar2, p_date date, p_error_code out number, p_error_message out varchar2) return boolean;

----------------------------------!---------------------------------------------
  function is_ap_pstatus_changable_i(p_old_status varchar2, p_new_status varchar2, p_date date, p_is_bp boolean) return boolean;
  function is_ap_pstatus_changable(p_old_status varchar2, p_new_status varchar2, p_date date) return boolean;
  function is_ap_pstatus_can_change_i(p_access_point_id number, p_new_status varchar2, p_date date) return boolean;
  function is_ap_pstatus_can_change(p_access_point_id number, p_new_status varchar2, p_date date, p_error_code out number, p_error_message out varchar2) return boolean;

----------------------------------!---------------------------------------------
  function is_naap_status_can_change_i
  (
    p_network_address_id number,
    p_access_point_id number,
    p_date date,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean
  ) return boolean;

  function is_naap_status_can_change
  (
    p_network_address_id number,
    p_access_point_id number,
    p_date date,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  function is_appa_status_can_change_i
  (
    p_access_point_id number,
    p_personal_account number,
    p_date date,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean
  ) return boolean;

  function is_appa_status_can_change
  (
    p_access_point_id number,
    p_personal_account number,
    p_date date,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  function is_pah_status_can_change_i
  (
    p_personal_account number,
    p_host_id number,
    p_date date,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean
  ) return boolean;

  function is_pah_status_can_change
  (
    p_personal_account number,
    p_host_id number,
    p_date date,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  procedure set_1na_status_ii
  (
    p_na_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_na_trans_reason_code varchar2,
    p_lock_pn boolean
  );

  procedure set_1na_status_i
  (
    p_na_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_na_trans_reason_code varchar2,
    p_lock_pn boolean,
    p_error_code out number,
    p_error_message out varchar2
  );

  function set_na_status_ii
  (
    p_na_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_na_status_i
  (
    p_na_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_same_status_for_m_and_l boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

----------------------------------!---------------------------------------------
  function set_na_status
  (
    p_na_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_na_status2
  (
    p_na_id ct_number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_na_status3
  (
    p_na_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  procedure del_1na_status_ii
  (
    p_na_id number,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_allowed_statuses ct_varchar_s
  );

  procedure del_1na_status_i
  (
    p_na_id number,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_allowed_statuses ct_varchar_s,
    p_error_code out number,
    p_error_message out varchar2
  );

  function del_na_status_ii
  (
    p_na_id ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_allowed_statuses ct_varchar_s,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function del_na_status_i
  (
    p_na_id ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

----------------------------------!---------------------------------------------
  function del_na_status
  (
    p_na_id ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function del_na_status2
  (
    p_na_id ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function del_na_status3
  (
    p_na_id number,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  procedure set_1ap_status_ii
  (
    p_ap_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_ap_trans_reason_code varchar2,
    p_lock_sc boolean
  );

  procedure set_1ap_status_i
  (
    p_ap_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_ap_trans_reason_code varchar2,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
  );

  function set_ap_status_ii
  (
    p_ap_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_ap_status_i
  (
    p_ap_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

----------------------------------!---------------------------------------------
  function set_ap_status
  (
    p_ap_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_ap_status2
  (
    p_ap_id ct_number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_ap_status3
  (
    p_ap_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  procedure set_1ap_pstatus_ii
  (
    p_ap_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean
  );

  procedure set_1ap_pstatus_i
  (
    p_ap_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
  );

  function set_ap_pstatus_ii
  (
    p_ap_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_ap_pstatus_i
  (
    p_ap_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

----------------------------------!---------------------------------------------
  function set_ap_pstatus
  (
    p_ap_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_ap_pstatus2
  (
    p_ap_id ct_number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_ap_pstatus3
  (
    p_ap_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  procedure set_1naap_status_ii
  (
    p_na_id number,
    p_ap_id number,
    p_link_type_code varchar2,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_lock_sc boolean
  );

  procedure set_1naap_status_i
  (
    p_na_id number,
    p_ap_id number,
    p_link_type_code varchar2,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
  );

  function set_naap_status_ii
  (
    p_na_id ct_number,
    p_ap_id ct_number,
    p_link_type_code ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_naap_status_i
  (
    p_na_id ct_number,
    p_ap_id ct_number,
    p_link_type_code ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_same_status_for_m_and_l boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

----------------------------------!---------------------------------------------
  function set_naap_status
  (
    p_na_id ct_number,
    p_ap_id ct_number,
    p_link_type_code ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_naap_status2
  (
    p_na_id ct_number,
    p_ap_id ct_number,
    p_link_type_code ct_varchar_s,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_naap_status3_open_second
  (
    p_na_id ct_number,
    p_ap_id number,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_naap_status2_close
  (
    p_na_id ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_naap_status3
  (
    p_na_id number,
    p_ap_id number,
    p_link_type_code varchar2,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

  function set_naap_status3_close
  (
    p_na_id number,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  --!_!
  procedure set_1sc_pa_ii
  (
    p_ap_id number,
    p_pa number,
    p_user_id number,
    p_lock_sc boolean
  );
  --!_!

  procedure set_1appa_status_ii
  (
    p_ap_id number,
    p_pa number,
    p_date date,
    p_user_id number,
    p_lock_sc boolean
  );

  procedure set_1appa_status_i
  (
    p_ap_id number,
    p_pa number,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
  );

  function set_appa_status_ii
  (
    p_ap_id ct_number,
    p_pa ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_appa_status_i
  (
    p_ap_id ct_number,
    p_pa ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

----------------------------------!---------------------------------------------
  function set_appa_status
  (
    p_ap_id ct_number,
    p_pa ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_appa_status2
  (
    p_ap_id ct_number,
    p_pa ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_appa_status2_close
  (
    p_ap_id ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_appa_status3_open
  (
    p_ap_id ct_number,
    p_pa number,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_appa_status3
  (
    p_ap_id number,
    p_pa number,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

  function set_appa_status3_close
  (
    p_ap_id number,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  procedure set_1pah_status_ii
  (
    p_pa number,
    p_host_id number,
    p_date date,
    p_user_id number
  );

  procedure set_1pah_status_i
  (
    p_pa number,
    p_host_id number,
    p_date date,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
  );

  function set_pah_status_ii
  (
    p_pa ct_number,
    p_host_id ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_pah_status_i
  (
    p_pa ct_number,
    p_host_id ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

----------------------------------!---------------------------------------------
  function set_pah_status
  (
    p_pa ct_number,
    p_host_id ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_pah_status2
  (
    p_pa ct_number,
    p_host_id ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_pah_status2_close
  (
    p_pa ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_pah_status3_open
  (
    p_pa ct_number,
    p_host_id number,
    p_date date,
    p_user_id number,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_pah_status3
  (
    p_pa number,
    p_host_id number,
    p_date date,
    p_user_id number,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

  function set_pah_status3_close
  (
    p_pa number,
    p_date date,
    p_user_id number,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  function ins_phone
  (
    p_msisdns ct_varchar_s,
    p_pns_ids ct_number,
    p_status ct_varchar_s,
    p_sal_cat ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_na_ids out ct_number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function ins_phone2
  (
    p_msisdns ct_varchar_s,
    p_pns_ids ct_number,
    p_status varchar2,
    p_sal_cat varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_na_ids out ct_number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function ins_phone3
  (
    p_msisdn varchar2,
    p_pns_id number,
    p_status varchar2,
    p_sal_cat varchar2,
    p_date date,
    p_user_id number,
    p_na_id out number,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  function restore_phone
  (
    p_na_ids ct_number,
    p_pns_ids ct_number,
    p_status ct_varchar_s,
    p_sal_cat ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function restore_phone2
  (
    p_na_ids ct_number,
    p_pns_ids ct_number,
    p_status varchar2,
    p_sal_cat varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function restore_phone3
  (
    p_na_id number,
    p_pns_id number,
    p_status varchar2,
    p_sal_cat varchar2,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  function ins_sim
  (
    p_imsi ct_varchar_s,
    p_sn ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_ss_id ct_number,
    p_msisdn_bound ct_varchar_s,
    p_personal_account ct_number,
    p_ki ct_nvarchar_s,
    p_adm1 ct_nvarchar_s,
    p_access_control ct_nvarchar_s,
    p_authent_type ct_varchar_s,
    p_main_imsi_index ct_number,
    p_addition_imsi ct_varchar_s,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_ap_ids out ct_number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function ins_sim2
  (
    p_imsi ct_varchar_s,
    p_sn ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_ss_id ct_number,
    p_msisdn_bound ct_varchar_s,
    p_personal_account ct_number,
    p_ki ct_nvarchar_s,
    p_adm1 ct_nvarchar_s,
    p_access_control ct_nvarchar_s,
    p_authent_type ct_varchar_s,
    p_main_imsi_index ct_number,
    p_addition_imsi ct_varchar_s,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_ap_ids out ct_number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function ins_sim3
  (
    p_imsi varchar2,
    p_sn varchar2,
    p_pin varchar2,
    p_pin2 varchar2,
    p_puk2 varchar2,
    p_puk varchar2,
    p_ss_id number,
    p_msisdn_bound varchar2,
    p_personal_account number,
    p_ki nvarchar2,
    p_adm1 nvarchar2,
    p_access_control nvarchar2,
    p_authent_type varchar2,
    p_addition_imsi ct_varchar_s,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_ap_id out number,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  procedure set_1ap_params_ii
  (
    p_ap_id number,
    p_sn varchar2,
    p_pin varchar2,
    p_pin2 varchar2,
    p_puk2 varchar2,
    p_puk varchar2,
    p_msisdn_bound varchar2,
    p_ki nvarchar2,
    p_adm1 nvarchar2,
    p_access_control nvarchar2,
    p_authent_type varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean
  );

  procedure set_1ap_params_i
  (
    p_ap_id number,
    p_sn varchar2,
    p_pin varchar2,
    p_pin2 varchar2,
    p_puk2 varchar2,
    p_puk varchar2,
    p_msisdn_bound varchar2,
    p_ki nvarchar2,
    p_adm1 nvarchar2,
    p_access_control nvarchar2,
    p_authent_type varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
  );

  function set_ap_params_ii
  (
    p_ap_id ct_number,
    p_sn ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_msisdn_bound ct_varchar_s,
    p_ki ct_nvarchar_s,
    p_adm1 ct_nvarchar_s,
    p_access_control ct_nvarchar_s,
    p_authent_type ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_ap_params_i
  (
    p_ap_id ct_number,
    p_sn ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_msisdn_bound ct_varchar_s,
    p_ki ct_nvarchar_s,
    p_adm1 ct_nvarchar_s,
    p_access_control ct_nvarchar_s,
    p_authent_type ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

----------------------------------!---------------------------------------------
  function set_ap_params
  (
    p_ap_id ct_number,
    p_sn ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_msisdn_bound ct_varchar_s,
    p_ki ct_nvarchar_s,
    p_adm1 ct_nvarchar_s,
    p_access_control ct_nvarchar_s,
    p_authent_type ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_ap_params2
  (
    p_ap_id ct_number,
    p_sn ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_msisdn_bound ct_varchar_s,
    p_ki ct_nvarchar_s,
    p_adm1 ct_nvarchar_s,
    p_access_control ct_nvarchar_s,
    p_authent_type ct_varchar_s,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  ) return boolean;

  function set_ap_params3
  (
    p_ap_id number,
    p_sn varchar2,
    p_pin varchar2,
    p_pin2 varchar2,
    p_puk2 varchar2,
    p_puk varchar2,
    p_msisdn_bound varchar2,
    p_ki nvarchar2,
    p_adm1 nvarchar2,
    p_access_control nvarchar2,
    p_authent_type varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
  ) return boolean;

----------------------------------!---------------------------------------------
  function get_first_exist_imsi_in_range
  (
    p_start_imsi_number varchar2,
    p_end_imsi_number varchar2,
    p_with_sn boolean
  ) return varchar2;

  function expand_imsi_range(p_range ot_range) return ct_varchar_s;

  function get_range_length
  (
    p_start_imsi_number varchar2,
    p_end_imsi_number varchar2
  ) return number;

  function make_imsi
  (
    p_start_imsi_number varchar2,
    p_shift number
  ) return varchar2;

  function find_available_imsi_ranges
  (
    p_start_imsi_number varchar2,
    p_end_imsi_number varchar2,
    p_count number
  ) return ct_range;

  function find_available_imsi_in_range
  (
    p_start_imsi_number varchar2,
    p_end_imsi_number varchar2,
    p_count number
  ) return ct_varchar_s;

  procedure find_available_imsi_on_host
  (
    p_sim_card_type_code varchar2,
    p_host_id number,
    p_count number,
    p_date date,
    p_imsi out ct_varchar_s,
    p_ss_id out ct_number
  );

----------------------------------!---------------------------------------------

end;
/
