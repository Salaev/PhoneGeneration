CREATE PACKAGE CONSTANTS IS
/****************************************************************************
  Package contains constants and exceptions for whole modul.

  %author            Petr Cepek
  %created           6.6.2006
  %version           1.0.1

  %version_log
  {*}1.0.3 - 29.04.2008 - Josef Hartman <br>
             error E_CHANGE_SS_STATUS_NOT_ALW added
  {*}1.0.2 - 10.08.2007 - Roger Stockley <br>
             constant c_ERR_NET_OP_NEIGHBOUR_EXISTS added
  {*}1.0.1 - 16.11.2006 - Petr Cepek <br>
             constant c_ERR_PS_CAN_NOT_BE_SHARED added

****************************************************************************/

-- exceptions ********************************************************************************************
  -- parent key not found
  E_PARENT_KEY_NOT_FOUND EXCEPTION;
  PRAGMA EXCEPTION_INIT(E_PARENT_KEY_NOT_FOUND, -2291);

  -- E_PHONE_NUMBER_NOT_EXISTS
  E_PHONE_NUMBER_NOT_EXISTS EXCEPTION;
  PRAGMA EXCEPTION_INIT(E_PHONE_NUMBER_NOT_EXISTS,-20133);

  -- E_SIM_CARD_NOT_EXISTS
  E_SIM_CARD_NOT_EXISTS EXCEPTION;
  PRAGMA EXCEPTION_INIT(E_SIM_CARD_NOT_EXISTS,-20134);

  -- E_CHANGE_PH_STATUS_NOT_ALW
  E_CHANGE_PH_STATUS_NOT_ALW EXCEPTION;
  PRAGMA EXCEPTION_INIT(E_CHANGE_PH_STATUS_NOT_ALW,-20208);

  -- E_CHANGE_SS_STATUS_NOT_ALW
  E_CHANGE_SS_STATUS_NOT_ALW EXCEPTION;
  PRAGMA EXCEPTION_INIT(E_CHANGE_SS_STATUS_NOT_ALW,-20219);

-- error codes ********************************************************************************************

  c_ERR_BATCH_DUPLICITY               CONSTANT NUMBER(5) := -20228;

-- phone link
  c_ERR_PHONES_ALREADY_LINKED         CONSTANT NUMBER(5) := -20221;  -- Phone numbers are already linked together.
  c_ERR_LINKED_MSISDN_DUPLICITY       CONSTANT NUMBER(5) := -20222;  -- Linked phone duplicity.
  c_ERR_MAIN_MSISDN_DUPLICITY         CONSTANT NUMBER(5) := -20223;  -- Main phone duplicity.
  c_ERR_LINKED_MSISDN_EXISTS          CONSTANT NUMBER(5) := -20225;  -- Linked MSISDN already exists.
  c_ERR_MAIN_MSISDN_EXISTS            CONSTANT NUMBER(5) := -20226;  -- Main MSISDN already exists.
  c_ERR_MAIN_MSISDN_LINKED            CONSTANT NUMBER(5) := -20227;  -- Main MSISDN already linked.
  c_ERR_PS_CAN_NOT_BE_SHARED          CONSTANT NUMBER(5) := -20228;  -- This phone number series can not be shared by more then one network operator.

END;
/
