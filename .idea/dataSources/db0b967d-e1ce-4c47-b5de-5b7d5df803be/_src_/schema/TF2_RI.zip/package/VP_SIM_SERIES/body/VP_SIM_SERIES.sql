CREATE package body VP_SIM_SERIES is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return sim_series%rowtype
is
  v_res sim_series%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_lock is null, 'p_lock');
  util_pkg.XCheck_Cond_Missing(p_wait is null, 'p_wait');
  ------------------------------
  p_is_locked := false;
  ------------------------------
  if p_lock
  then
    ------------------------------
    if p_wait
    then
      ------------------------------
      select /*+ index_asc(z, PK_SIM_SERIES)*/
        * into v_res
        from sim_series z
        where 1 = 1
        and sim_series_id = p_id
        and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
        for update
      ;
      ------------------------------
    else
      ------------------------------
      select /*+ index_asc(z, PK_SIM_SERIES)*/
        * into v_res
        from sim_series z
        where 1 = 1
        and sim_series_id = p_id
        and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
        for update nowait
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    select /*+ index_asc(z, PK_SIM_SERIES)*/
      * into v_res
      from sim_series z
      where 1 = 1
      and sim_series_id = p_id
      and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
when util_pkg.lock_nowait_exception then
  ------------------------------
  p_is_locked := true;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get1(p_id integer, p_date date) return sim_series%rowtype
is
  v_is_locked_stub boolean;
begin
  ------------------------------
  return get1_i(p_id, p_date, false, false, v_is_locked_stub);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget1(p_id integer, p_date date) return sim_series%rowtype
is
  v_res sim_series%rowtype;
begin
  ------------------------------
  v_res := get1(p_id, p_date);
  ------------------------------
  if v_res.sim_series_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_get1(p_id integer, p_date date) return sim_series%rowtype
is
  v_res sim_series%rowtype;
  v_is_locked boolean;
begin
  ------------------------------
  v_res := get1_i(p_id, p_date, TRUE, FALSE, v_is_locked);
  ------------------------------
  if v_is_locked
  then
    ------------------------------
    raise util_pkg.lock_nowait_exception;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xlock_xget1(p_id integer, p_date date) return sim_series%rowtype
is
  v_res sim_series%rowtype;
begin
  ------------------------------
  v_res := xlock_get1(p_id, p_date);
  ------------------------------
  if v_res.sim_series_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, p_date, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xvalid_i(p_rec sim_series%rowtype)
is
begin
  ------------------------------
  if p_rec.start_imsi_number is null
    or p_rec.end_imsi_number is null
    or length(p_rec.start_imsi_number) <> length(p_rec.end_imsi_number)
    or util_pkg.char_to_number(p_rec.start_imsi_number) > util_pkg.char_to_number(p_rec.end_imsi_number)
  then
    util_pkg.Raise_Invalid_Param(util_pkg.cut_err_msg('Sims' || util_pkg.c_msg_delim01 || p_rec.start_imsi_number|| util_pkg.c_msg_delim02 || p_rec.end_imsi_number));
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_id(p_rec sim_series%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_cnt number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.sim_series_id is null, 'p_rec.sim_series_id');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  if p_check_only_other_ids
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
select /*+ index_asc(z, PK_SIM_SERIES)*/
  count(1) cnt into v_cnt
  from sim_series z
  where 1 = 1
  and sim_series_id = p_rec.sim_series_id
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  --!_!and (v_check_only_other_ids = util_pkg.c_false or sim_series_id != p_rec.sim_series_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i_imsi_start_imsi_end(p_rec sim_series%rowtype, p_check_only_other_ids boolean) return boolean
is
  v_check_only_other_ids number := util_pkg.bool_to_int_2val(p_check_only_other_ids);
  v_cnt number;
  v_date date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.sim_series_id is null, 'p_rec.sim_series_id');
  util_pkg.XCheck_Cond_Missing(p_rec.start_imsi_number is null, 'p_rec.start_imsi_number');
  util_pkg.XCheck_Cond_Missing(p_rec.end_imsi_number is null, 'p_rec.end_imsi_number');
  util_pkg.XCheck_Cond_Missing(p_check_only_other_ids is null, 'p_check_only_other_ids');
  ------------------------------
  v_date := util_ri.deleted2valid_date_to(p_rec.deleted);
  ------------------------------
select /*+ index_asc(z, I_SIMSERIES_LOCAL)*/
  count(1) cnt into v_cnt
  from sim_series z
  where 1 = 1
  and start_imsi_number = p_rec.start_imsi_number
  and end_imsi_number = p_rec.end_imsi_number
  and length(start_imsi_number) = length(p_rec.start_imsi_number)
  and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  and (v_check_only_other_ids = util_pkg.c_false or sim_series_id != p_rec.sim_series_id)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_cnt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_i(p_rec sim_series%rowtype, p_check_only_other_ids boolean) return boolean
is
begin
  ------------------------------
  if find_i_id(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  if find_i_imsi_start_imsi_end(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xunique_i(p_rec sim_series%rowtype, p_check_only_other_ids boolean)
is
begin
  ------------------------------
  if find_i_id(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    --!_!util_pkg.Raise_Obj_NotUniq_OnDate2(p_rec.sim_series_id, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    util_pkg.Raise_Obj_NotUniq_ID2(p_rec.sim_series_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  if find_i_imsi_start_imsi_end(p_rec, p_check_only_other_ids)
  then
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_OnDate(p_rec.start_imsi_number, p_rec.end_imsi_number, util_ri.deleted2valid_date_to(p_rec.deleted), c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_i(p_rec sim_series%rowtype)
is
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
  xunique_i(p_rec, FALSE);
  ------------------------------
  insert into sim_series
  values p_rec;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure change_i(p_rec sim_series%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  xvalid_i(p_rec);
  ------------------------------
  xunique_i(p_rec, TRUE);
  ------------------------------
update /*+ index_asc(z, PK_SIM_SERIES)*/
  sim_series z
  set
    row = p_rec
  where 1 = 1
  and sim_series_id = p_rec.sim_series_id
  --!_!and nvl(deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_ID2(p_rec.sim_series_id, c_this_name);
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_ID2(p_rec.sim_series_id, c_this_name);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure version_open(p_rec in out nocopy sim_series%rowtype)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  p_rec.sim_series_id := nvl(p_rec.sim_series_id, s_sim_series.nextval);
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  open_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_change(p_rec in out nocopy sim_series%rowtype, p_date_from_virt date := null)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_rec sim_series%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_rec.sim_series_id is null, 'p_rec.sim_series_id');
  ------------------------------
  v_date_from_new := nvl(p_date_from_virt, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  v_rec := xlock_get1(p_rec.sim_series_id, v_date_to_prev);
  ------------------------------
  if v_rec.sim_series_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_rec.sim_series_id, v_date_to_prev, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  p_rec.date_of_change := v_sysdate;
  ------------------------------
  change_i(p_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure version_close
(
    p_id integer,
    p_user_id integer,
    p_date_from date := null
)
is
  v_sp_name varchar2(30);
  v_sysdate date := sysdate;
  v_date_from_new date;
  v_date_to_prev date;
  v_rec sim_series%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_date_from_new := nvl(p_date_from, v_sysdate);
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_date_from_new);
  ------------------------------
  v_rec := xlock_get1(p_id, v_date_to_prev);
  ------------------------------
  if v_rec.sim_series_id is null
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_OnDate2(p_id, v_date_to_prev, c_this_name);
    ------------------------------
  end if;
  ------------------------------
  v_rec.user_id_of_change := p_user_id;
  ------------------------------
  v_rec.date_of_change := v_sysdate;
  v_rec.deleted := util_ri.valid_date_to2deleted(v_date_to_prev);
  ------------------------------
  --!_! need to check for childs (phone_numbers, etc), now skipped
  ------------------------------
  change_i(v_rec);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
