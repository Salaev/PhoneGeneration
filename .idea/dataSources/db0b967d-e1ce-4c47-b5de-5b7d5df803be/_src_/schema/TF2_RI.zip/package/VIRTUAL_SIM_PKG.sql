CREATE package VIRTUAL_SIM_PKG is

----------------------------------!---------------------------------------------
  c_opt_imsi_prefix              constant varchar2(100) := 'IMSI_PREFIX';
  c_opt_iccid_prefix             constant varchar2(100) := 'ICCID_PREFIX';

----------------------------------!---------------------------------------------
  --!_!c_def_imsi_prefix              constant varchar2(4000) := '';
  --!_!c_def_iccid_prefix             constant varchar2(4000) := '';

----------------------------------!---------------------------------------------
  procedure create_virtual_sim
  (
    p_msisdns ct_varchar_s,
    p_user_id number,
    p_break_on_error boolean,
    p_imsis in out nocopy ct_varchar_s,
    p_iccids in out nocopy ct_varchar_s,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
  );

----------------------------------!---------------------------------------------
  procedure create_virtual_sim_and_link_pa
  (
    p_msisdns ct_varchar_s,
    p_set_na_status ct_varchar_s,
    p_personal_accounts ct_number,
    p_user_id number,
    p_break_on_error boolean,
    p_imsis in out nocopy ct_varchar_s,
    p_iccids in out nocopy ct_varchar_s,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
  );

----------------------------------!---------------------------------------------
end;
/
