CREATE package body etc_pkg999 is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xget_roam_part_agroup_id return number
is
begin
  ------------------------------
  return install_pkg.nnget_option_num(c_sett_agroup_roaming_partner, c_def_agroup_roaming_partner);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_roam_part_zone_field return varchar2
is
begin
  ------------------------------
  return 'ZONE_ID';
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_roam_part_id_field return varchar2
is
begin
  ------------------------------
  return 'ROAMING_PARTNER_ID';
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_roaming_partner
(
  p_result_list out sys_refcursor,
  p_network_operator_id number,
  p_date date := null
)
is
  v_sysdate date := sysdate;
  v_date date := nvl(p_date, v_sysdate);
  v_agroup_id number;
  v_zone_type_code varchar2(10);
begin
  ------------------------------
  v_agroup_id := xget_roam_part_agroup_id;
  ------------------------------
  v_zone_type_code := install_pkg.xget_option_str(c_sett_ztc_roaming_partner, 10);
  ------------------------------
  open p_result_list for
select /*+ driving_site(gd) ordered use_nl(gd, no, z, zt)
    index_asc(gd, I_AGROUP_DATA_ID2)
    index_asc(no, PK_NETWORK_OPERATOR)
    index_asc(z, PK_ZONE)
    index_asc(zt, PK_ZONE_TYPE)
    */
    gd.agroup_data_id roaming_partner_id,
    gd.date_from,
    gd.date_to,
    no.network_operator_code,
    no.network_operator_name,
    z.zone_id,
    z.zone_code,
    z.zone_name,
    zt.zone_type_code,
    zt.zone_type_name
    from agroup_data gd, network_operator no, zone z, zone_type zt
    where 1 = 1
    and gd.agroup_id = v_agroup_id
    and gd.id2 = p_network_operator_id
    and no.network_operator_id(+) = gd.id2
    and z.zone_id(+) = gd.id1
    and z.zone_type_code(+) = v_zone_type_code
    and zt.zone_type_code(+) = z.zone_type_code
    and v_date between gd.date_from and gd.date_to
    and nvl(no.deleted(+), v_date + 123) >= v_date
    and nvl(z.deleted(+), v_date + 123) >= v_date
    and nvl(zt.deleted(+), v_date + 123) >= v_date
    order by zt.zone_type_code, z.zone_code, no.network_operator_code, gd.date_from, gd.agroup_data_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_avail_roaming_zones
(
  p_result_list out sys_refcursor,
  p_network_operator_id number,
  p_date date := null
)
is
  v_sysdate date := sysdate;
  v_date date := nvl(p_date, v_sysdate);
  v_agroup_id number;
  v_zone_type_code varchar2(10);
begin
  ------------------------------
  v_agroup_id := xget_roam_part_agroup_id;
  ------------------------------
  v_zone_type_code := install_pkg.xget_option_str(c_sett_ztc_roaming_partner, 10);
  ------------------------------
  open p_result_list for
select /*+ driving_site(z) ordered use_nl(z, gd, zt)
    full(z)
    index_asc(gd, I_AGROUP_DATA_ID2)
    index_asc(zt, PK_ZONE_TYPE)
    */
    z.zone_id,
    z.zone_code,
    z.zone_name,
    zt.zone_type_code,
    zt.zone_type_name
    from zone z, agroup_data gd, zone_type zt
    where 1 = 1
    and z.zone_type_code = v_zone_type_code
    and gd.agroup_id(+) = v_agroup_id
    and gd.id2(+) = p_network_operator_id
    and gd.id1(+) = z.zone_id
    and gd.id1 is null
    and zt.zone_type_code(+) = z.zone_type_code
    and nvl(z.deleted, v_date + 123) >= v_date
    and v_date between gd.date_from(+) and gd.date_to(+)
    and nvl(zt.deleted(+), v_date + 123) >= v_date
    order by zt.zone_type_code, z.zone_code, z.deleted
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function geto_msisdn_digits_at_begin return number
is
begin
  ------------------------------
  return install_pkg.nnget_option_num(c_sett_msisdn_digits_srch, c_def_msisdn_digits_srch);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function geto_msisdn_digits_at_middle return number
is
begin
  ------------------------------
  return install_pkg.nnget_option_num(c_sett_msisdn_digits_srch_wfs, c_def_msisdn_digits_srch_wfs);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_msisdn_digits_at_begin(p_mask varchar2) return number
is
begin
  ------------------------------
  return util_pkg.get_mask_digits_at_begin(p_mask);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_msisdn_digits_at_middle(p_mask varchar2) return number
is
begin
  ------------------------------
  return util_pkg.get_mask_digits_at_middle(p_mask);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_abc_rule_result(p_def_msisdn varchar2) return varchar2
is
  v_abc varchar2(50);
  v_def varchar2(50);
  v_msisdn varchar2(150) := p_def_msisdn;
begin
  ------------------------------
  while(1 = 1)
  loop
    ------------------------------
    begin
      ------------------------------
      select /*+ index(dar I_DEF_ABC_RULE_DEF)*/
        dar.abc, dar.def
      into v_abc, v_def
      from DEF_ABC_RULE dar
      where dar.def = v_msisdn;
      ------------------------------
      return v_abc || substr(p_def_msisdn, length(v_def) + 1);
      ------------------------------
    exception
      ------------------------------
      when no_data_found then null;
      ------------------------------
    end;
    ------------------------------
    if length(v_msisdn) <= 1
    then
      return null;
    end if;
    ------------------------------
    v_msisdn := substr(v_msisdn, 1, length(v_msisdn) - 1);
    ------------------------------
  end loop;
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_abc_rule_result_special
(
  p_msisdn ct_varchar_s,
  p_msisdn_abc out ct_varchar_s,
  p_type_abc out ct_varchar_s,
  p_type_def out ct_varchar_s,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_date date := sysdate;
  v_use_phone_link boolean;
  v_city_type_opt varchar2(50);
  v_city_type ct_varchar_s;
  v_main_count number;
  v_count number;
  v_pivot ct_number;
  v_pivot2 ct_number;
  v_pivot3 ct_number;
  v_na_id ct_number;
  v_na_id_m ct_number;
  v_na_id_l ct_number;
  v_msisdn_m ct_varchar_s;
  v_msisdn_l ct_varchar_s;
  v_type_l ct_varchar_s;
  v_err_mark ct_number;
  v_tmp_num ct_number;
  v_city_mark ct_number;
  v_city_pivot ct_number;
  v_city_pivot2 ct_number;
  v_msisdn_m2 ct_varchar_s;
  v_msisdn_l2 ct_varchar_s;
  v_type_l2 ct_varchar_s;
  v_not_city_pivot ct_number;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  --!_!1. Определяем в RI тип(phone type code: F, P, P2, …) входящего  номера(на вход может прийти как DEF так и ABC)
  --!_!2. Ищем связку номеров(phone_link) в РИ (пришедший на вход номер – основной номер связки)
  --!_!  3. Если нашли связку // это ОФС номер
  --!_!    4. Возвращаем в качестве типа DEF возвращаем тип ABC номера(на практике P2), связанный ABC номер и его тип(на практике P2).
  --!_!  5. Если не нашли связку
  --!_!    6. Если тип городской (P) // случай для  DEF номера ОФС и городских МТС(тоже описаны в RI в виде DEF номера)
  --!_!      7. ищем соответствующее правило по таблице def_abc_rules
  --!_!      8. Если нашли правило
  --!_!        9. Возвращаем преобразованный номер ABC и тип номера ABC(Такой же как у входного DEF номера(на практике задаем как P, см. п. 2))
  --!_!        //Это будет кейс для городских номеров из емкости МТС
  --!_!      10. Если не нашли правило
  --!_!        11. Возвращаем ошибку что abc номер не найден
  --!_!    12. Если тип не городской(все другие типы номеров не имеют ABC, поэтому искать его не нужно)
  --!_!      13. Возвращаем тип номера DEF как определили, ABC и типABC равные null
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdn, 'p_msisdn');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdn);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdn) != v_main_count, 'p_msisdn.count != v_main_count');
  ------------------------------
  v_use_phone_link := install_pkg.nnget_option_bool(c_opt_def_abc_use_phone_link, c_def_def_abc_use_phone_link);
  ------------------------------
  v_city_type_opt := install_pkg.xget_option_str(c_opt_city_type, NULL);
  ------------------------------
  v_city_type := util_pkg.cast_ct_varchar2varchar_s(util_pkg.split_string(p_str => v_city_type_opt, p_delim => util_pkg.c_msg_delim_comma), TRUE);
  ------------------------------
  p_type_def := util_pkg.make_ct_varchar_s(v_main_count, null);
  p_msisdn_abc := util_pkg.make_ct_varchar_s(v_main_count, null);
  p_type_abc := util_pkg.make_ct_varchar_s(v_main_count, null);
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  --!_!1. Определяем в RI тип(phone type code: F, P, P2, …) входящего  номера(на вход может прийти как DEF так и ABC)
  v_tmp_num := util_ri.det_pns_id4msisdn(p_msisdn, v_date, FALSE);
  p_type_def:= util_ri.get_pns_type(v_tmp_num, v_date, FALSE);
  ------------------------------
  v_err_mark := util_pkg.mark_val_ct_varchar_s(p_type_def, null);
  util_ext_ri.setup_error_by_marks
  (
    p_marks => v_err_mark,
    p_error_code => util_loc_pkg.c_ora_phone_not_found,
    p_error_message => util_loc_pkg.c_msg_phone_not_found || util_pkg.c_msg_delim01 || 'DEF phone number',
    p_mark_value => util_pkg.c_true,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_err_mark, FALSE, util_pkg.c_false, null);
  ------------------------------
  if v_use_phone_link
  then
    ------------------------------
    --!_!2. Ищем связку номеров(phone_link) в РИ (пришедший на вход номер – основной номер связки)
    v_na_id := util_ri.get_na_id(p_msisdn, v_date, FALSE);
    ------------------------------
    v_err_mark := util_pkg.mark_val_ct_number(v_na_id, null, util_pkg.c_true, util_pkg.c_false);
    v_pivot2 := util_pkg.get_marked_ct_number(v_pivot, v_err_mark, FALSE, util_pkg.c_false, null);
    ------------------------------
    --!_!       Связку ищем только для тех кого нашли в RI
    util_ri.prepare_as_pnlnk_exact
    (
      p_na_id => v_na_id,
      p_date => v_date,
      p_na_id_m => v_na_id_m,
      p_na_id_l => v_na_id_l,
      p_msisdn_m => v_msisdn_m,
      p_msisdn_l => v_msisdn_l
    );
    ------------------------------
    --!_!       Проверим что это def номер
    v_err_mark := util_pkg.mark_ct_number(v_na_id_m, v_na_id, util_pkg.c_false, util_pkg.c_true);
    v_pivot2 := util_pkg.get_marked_ct_number(v_pivot2, v_err_mark, FALSE, util_pkg.c_false, null);
    ------------------------------
    --!_!  3. Если нашли связку // это ОФС номер
    --!_!     Проверим наличие abc номера
    v_err_mark := util_pkg.mark_val_ct_number(v_na_id_l, null, util_pkg.c_true, util_pkg.c_false);
    v_pivot2 := util_pkg.get_marked_ct_number(v_pivot2, v_err_mark, FALSE, util_pkg.c_false, null);
    ------------------------------
    --!_!       Определим тип abc номера
    v_type_l := util_ri.get_na_type(v_na_id_l, v_date, FALSE);
    ------------------------------
    --!_!    4. Возвращаем в качестве типа DEF возвращаем тип ABC номера(на практике P2), связанный ABC номер и его тип(на практике P2).
    util_pkg.set_by_pos_ct_varchar_s(p_type_def, v_type_l, v_pivot2, TRUE);
    util_pkg.set_by_pos_ct_varchar_s(p_msisdn_abc, v_msisdn_l, v_pivot2, TRUE);
    util_pkg.set_by_pos_ct_varchar_s(p_type_abc, v_type_l, v_pivot2, TRUE);
    ------------------------------
  else
    ------------------------------
    v_err_mark := util_pkg.make_ct_number(v_main_count, util_pkg.c_true);
    ------------------------------
  end if;
  ------------------------------
  --!_!  5. Если не нашли связку
  v_pivot3 := util_pkg.get_marked_ct_number(v_pivot, v_err_mark, FALSE, util_pkg.c_true, null);
  ------------------------------
  v_city_mark := util_pkg.mark_ct_varchar_s(p_type_def, v_city_type);
  ------------------------------
  v_city_pivot := util_pkg.get_marked_ct_number(v_pivot3, v_city_mark, TRUE, util_pkg.c_true, null);
  v_not_city_pivot := util_pkg.get_marked_ct_number(v_pivot3, v_city_mark, TRUE, util_pkg.c_false, null);
  ------------------------------
  --!_!    6. Если тип городской (P) // случай для  DEF номера ОФС и городских МТС(тоже описаны в RI в виде DEF номера)
  if util_pkg.get_count_ct_number(v_city_pivot) > 0
  then
    ------------------------------
    v_msisdn_m2 := util_pkg.get_by_pos_ct_varchar_s(p_msisdn, v_city_pivot, FALSE);
    ------------------------------
  --!_!      7. ищем соответствующее правило по таблице def_abc_rules
    v_count := util_pkg.get_count_ct_number(v_city_pivot);
    for v_i in 1..v_count
    loop
      ------------------------------
      util_pkg.add_ct_varchar_s_val(v_msisdn_l2, get_abc_rule_result(v_msisdn_m2(v_i)));
      ------------------------------
    end loop;
    ------------------------------
    v_err_mark := util_pkg.mark_val_ct_varchar_s(v_msisdn_l2, null, util_pkg.c_true, util_pkg.c_false);
    ------------------------------
    --!_!        8. Если нашли правило
    v_city_pivot2 := util_pkg.get_marked_ct_number(v_city_pivot, v_err_mark, FALSE, util_pkg.c_false, null);
    v_type_l2 := util_pkg.get_by_pos_ct_varchar_s(p_type_def, v_city_pivot2, FALSE);
    ------------------------------
    --!_!          9. Возвращаем преобразованный номер ABC и тип номера ABC(Такой же как у входного DEF номера(на практике задаем как P, см. п. 2))
    --!_!             Это будет кейс для городских номеров из емкости МТС
    util_pkg.set_by_pos_ct_varchar_s(p_msisdn_abc, v_msisdn_l2, v_city_pivot2, TRUE);
    util_pkg.set_by_pos_ct_varchar_s(p_type_abc, v_type_l2, v_city_pivot2, TRUE);
    ------------------------------
    --!_!        10. Если не нашли правило
    v_city_pivot2 := util_pkg.get_marked_ct_number(v_city_pivot, v_err_mark, TRUE, util_pkg.c_true, null);
    v_count := util_pkg.get_count_ct_number(v_city_pivot2);
    ------------------------------
    --!_!          11. Возвращаем ошибку что abc номер не найден
    if v_count > 0
    then
      ------------------------------
      util_ext_ri.setup_common_error
      (
        p_main_count => v_count,
        p_error_code => util_pkg.c_ora_object_not_found,
        p_error_message => util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || VP_DEF_ABC_RULE.c_this_name,
        p_error_code2 => v_error_codes,
        p_error_message2 => v_error_messages
      );
      ------------------------------
      util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes, v_city_pivot2, TRUE);
      util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages, v_city_pivot2, TRUE);
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  --!_!    12. Если тип не городской(все другие типы номеров не имеют ABC, поэтому искать его не нужно)
  if util_pkg.get_count_ct_number(v_not_city_pivot) > 0
  then
    ------------------------------
    --!_!    13. Возвращаем тип номера DEF как определили, ABC и типABC равные null
    util_pkg.set_val_by_pos_ct_varchar_s(p_msisdn_abc, null, v_not_city_pivot);
    util_pkg.set_val_by_pos_ct_varchar_s(p_type_abc, null, v_not_city_pivot);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_all_def_abc_rule
(
  p_date date,
  p_result out sys_refcursor
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  util_loc_pkg.touch_date(p_date); --!_!
  ------------------------------
  open p_result for
  select /*+ full(z)*/
    def_abc_rule_id,
    def,
    abc
  from def_abc_rule z
  where 1 = 1
    --!_!and nvl(deleted, p_date + util_ri.c_dummy_date_shift) > p_date
    --!_!and p_date between date_from and date_to
  order by def_abc_rule_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure delete_def_abc_rule
(
  p_ids ct_number,
  p_date_from ct_date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_ids, 'p_ids');
  util_pkg.XCheckP_FS_ct_date(p_date_from, 'p_date_from');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != v_main_count, 'p_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date_from) != v_main_count, 'p_date_from.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    begin
      ------------------------------
      vp_def_abc_rule.version_close
      (
        p_id => p_ids(v_i),
        p_user_id => p_user_id,
        p_date_from => p_date_from(v_i)
      );
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message(p_ids(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure delete_def_abc_rule2
(
  p_id number,
  p_user_id number,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_ids ct_number;
  v_date_from ct_date;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ids, p_id);
  util_pkg.add_ct_date_val(v_date_from, SYSDATE);
  ------------------------------
  delete_def_abc_rule
  (
    p_ids => v_ids,
    p_date_from => v_date_from,
    p_user_id => p_user_id,
    p_break_on_error => FALSE, --!_!no raise in normal error
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_error_code := v_error_codes(util_ri.c_index_one);
  p_error_message := v_error_messages(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_def_abc_rule
(
  p_defs ct_varchar_s,
  p_abcs ct_varchar_s,
  p_user_id number,
  p_break_on_error boolean,
  p_out_ids out ct_number,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_rec def_abc_rule%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_defs, 'p_defs');
  util_pkg.XCheckP_FS_ct_varchar_s(p_abcs, 'p_abcs');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  util_loc_pkg.touch_number(p_user_id);
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_defs);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_defs) != v_main_count, 'p_defs.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_abcs) != v_main_count, 'p_abcs.count != v_main_count');
  ------------------------------
  p_out_ids := util_pkg.make_ct_number(v_main_count, NULL);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    begin
      ------------------------------
      p_out_ids(v_i) := NULL;
      ------------------------------
      v_rec := NULL;
      ------------------------------
      v_rec.def := p_defs(v_i);
      v_rec.abc := p_abcs(v_i);
      --!_!v_rec.user_id_of_change := p_user_id;
      ------------------------------
      vp_def_abc_rule.version_open(v_rec);
      ------------------------------
      p_out_ids(v_i) := v_rec.def_abc_rule_id;
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message3(p_out_ids(v_i), p_defs(v_i), p_abcs(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_def_abc_rule2
(
  p_def varchar2,
  p_abc varchar2,
  p_user_id number,
  p_out_id out number,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_defs ct_varchar_s;
  v_abcs ct_varchar_s;
  v_out_ids ct_number;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_defs, p_def);
  util_pkg.add_ct_varchar_s_val(v_abcs, p_abc);
  ------------------------------
  create_def_abc_rule
  (
    p_defs => v_defs,
    p_abcs => v_abcs,
    p_user_id => p_user_id,
    p_break_on_error => FALSE, --!_!no raise in normal error
    p_out_ids => v_out_ids,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_out_id := v_out_ids(util_ri.c_index_one);
  p_error_code := v_error_codes(util_ri.c_index_one);
  p_error_message := v_error_messages(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_def_abc_rule
(
  p_ids ct_number,
  p_defs ct_varchar_s,
  p_abcs ct_varchar_s,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_rec def_abc_rule%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_ids, 'p_ids');
  util_pkg.XCheckP_FS_ct_varchar_s(p_defs, 'p_defs');
  util_pkg.XCheckP_FS_ct_varchar_s(p_abcs, 'p_abcs');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  util_loc_pkg.touch_number(p_user_id);
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != v_main_count, 'p_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_defs) != v_main_count, 'p_defs.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_abcs) != v_main_count, 'p_abcs.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    begin
      ------------------------------
      v_rec := NULL;
      ------------------------------
      v_rec.def_abc_rule_id := p_ids(v_i);
      v_rec.def := p_defs(v_i);
      v_rec.abc := p_abcs(v_i);
      --!_!v_rec.user_id_of_change := p_user_id;
      ------------------------------
      vp_def_abc_rule.version_change(v_rec);
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message(p_ids(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure update_def_abc_rule2
(
  p_id number,
  p_def varchar2,
  p_abc varchar2,
  p_user_id number,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_ids ct_number;
  v_defs ct_varchar_s;
  v_abcs ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_ids, p_id);
  util_pkg.add_ct_varchar_s_val(v_defs, p_def);
  util_pkg.add_ct_varchar_s_val(v_abcs, p_abc);
  ------------------------------
  update_def_abc_rule
  (
    p_ids => v_ids,
    p_defs => v_defs,
    p_abcs => v_abcs,
    p_user_id => p_user_id,
    p_break_on_error => FALSE, --!_!no raise in normal error
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  p_error_code := v_error_codes(util_ri.c_index_one);
  p_error_message := v_error_messages(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_pnt_check_rel_to_host(p_pnt_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
select /*+ ordered use_nl(z) index_asc(z, PK_PHONE_NUMBER_TYPE)*/
  z.check_relation_to_host, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value phone_number_type_code, rownum rn from table(p_pnt_code)) q,
    phone_number_type z
  where 1 = 1
  and z.phone_number_type_code(+) = q.phone_number_type_code
  and nvl(z.deleted(+), p_date + util_ri.c_dummy_date_shift) > p_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.phone_number_type_code, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'phone_number_type');
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_pnt_check_rel_to_host2(p_pnt_code varchar2, p_date date) return varchar2
is
  v_pnt_code ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_pnt_code, p_pnt_code);
  ------------------------------
  return get_pnt_check_rel_to_host(v_pnt_code, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure link_na_ap_i
(
  p_na_ids ct_number,
  p_ap_ids ct_number,
  p_link_type_code varchar2,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_silent_already_linked_same boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  --
  v_main_count number;
  v_pivot ct_number;
  v_marks ct_number;
  v_positions ct_number;
  --
  v_msisdns ct_varchar_s;
  v_imsis ct_varchar_s;
  v_na_ids ct_number;
  v_ap_ids ct_number;
  v_pns_ids ct_number;
  v_ss_ids ct_number;
  v_pns_host_ids ct_number;
  v_ss_host_ids ct_number;
  v_pns_type_codes ct_varchar_s;
  v_pnt_chr2hs ct_varchar_s;
  v_link_type_codes ct_varchar_s;
  --
  v_na_ids2 ct_number;
  v_ap_ids2 ct_number;
  v_marks2 ct_number;
  v_positions2 ct_number;
  v_positions_skip ct_number;
  --
  v_no_ids_ap ct_number;
  v_no_ids_own ct_number;
  v_no_ids_cur ct_number;
  --
  v_bool boolean;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_ri.XCheck_naap_link_type_code(p_link_type_code, 'p_link_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_silent_already_linked_same is null, 'p_silent_already_linked_same');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_ids) != v_main_count, 'p_na_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ap_ids) != v_main_count, 'p_ap_ids.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_na_ids);
  util_pkg.XCheckP_FS_ct_number(p_ap_ids);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  ------------------------------
  v_msisdns := util_ri.get_msisdn(p_na_id => p_na_ids, p_date => p_date, p_trim_empty => false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_varchar_s(v_msisdns, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_phone_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_phone_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_imsis := util_ri.get_imsi(p_ap_id => p_ap_ids, p_date => p_date, p_trim_empty => false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_varchar_s(v_imsis, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_sim_card_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_sim_card_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_na_ids, v_pivot);
  ------------------------------
  v_ap_ids := util_ri.get_linked_ap_id(p_na_id => v_na_ids, p_link_type_code => util_ri.c_NAAP_LINK_TYPE_CODE_ANYDUMMY, p_date => p_date, p_trim_empty => false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_ap_ids, null, util_pkg.c_false, util_pkg.c_true); --!_!
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  if p_silent_already_linked_same
  then
    ------------------------------
    v_ap_ids := util_coll_pkg.get_marked_ol_ct_number(v_ap_ids, v_marks);
    v_ap_ids2 := util_coll_pkg.get_by_pos_ol_ct_number(p_ap_ids, v_positions);
    ------------------------------
    v_marks2 := util_pkg.cmp_ct_number(v_ap_ids, v_ap_ids2);
    ------------------------------
    v_positions2 := util_coll_pkg.get_marked_ol_ct_number(v_positions, v_marks2);
    ------------------------------
    util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_pkg.c_ora_ok, v_positions2);
    util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_pkg.c_msg_ok, v_positions2);
    ------------------------------
    util_pkg.add_ct_number(v_positions_skip, v_positions2);
    ------------------------------
    v_positions2 := util_coll_pkg.get_unmarked_ol_ct_number(v_positions, v_marks2);
    ------------------------------
    util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_na_linked_to_other_ap, v_positions2);
    util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_na_linked_to_other_ap, v_positions2);
    ------------------------------
  else
    ------------------------------
    util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_na_linked_to_other_ap, v_positions);
    util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_na_linked_to_other_ap, v_positions);
    ------------------------------
  end if;
  ------------------------------
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  if p_link_type_code = util_ri.c_NAAP_LINK_TYPE_CODE_MAIN --!_!for c_NAAP_LINK_TYPE_CODE_SECOND it can be more then 1 link
  then
    ------------------------------
    v_ap_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_ap_ids, v_pivot);
    ------------------------------
    v_na_ids := util_ri.get_linked_na_id_MAIN(p_ap_id => v_ap_ids, p_date => p_date, p_trim_empty => false);
    ------------------------------
    v_marks := util_pkg.mark_val_ct_number(v_na_ids, null, util_pkg.c_false, util_pkg.c_true); --!_!
    v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
    ------------------------------
    if p_silent_already_linked_same
    then
      ------------------------------
      v_na_ids := util_coll_pkg.get_marked_ol_ct_number(v_na_ids, v_marks);
      v_na_ids2 := util_coll_pkg.get_by_pos_ol_ct_number(p_na_ids, v_positions);
      ------------------------------
      v_marks2 := util_pkg.cmp_ct_number(v_na_ids, v_na_ids2);
      ------------------------------
      v_positions2 := util_coll_pkg.get_marked_ol_ct_number(v_positions, v_marks2);
      ------------------------------
      util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_pkg.c_ora_ok, v_positions2);
      util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_pkg.c_msg_ok, v_positions2);
      ------------------------------
      util_pkg.add_ct_number(v_positions_skip, v_positions2);
      ------------------------------
      v_positions2 := util_coll_pkg.get_unmarked_ol_ct_number(v_positions, v_marks2);
      ------------------------------
      util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_ap_linked_to_other_na, v_positions2);
      util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_ap_linked_to_other_na, v_positions2);
      ------------------------------
    else
      ------------------------------
      util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_ap_linked_to_other_na, v_positions);
      util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_ap_linked_to_other_na, v_positions);
      ------------------------------
    end if;
    ------------------------------
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
    v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  if install_pkg.nnget_option_bool(c_opt_check_same_no_naap, c_def_check_same_no_naap)
  then
    ------------------------------
    v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_na_ids, v_pivot);
    v_ap_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_ap_ids, v_pivot);
    ------------------------------
    v_no_ids_ap := util_ri.get_ap_no_id(p_ap_id => v_ap_ids, p_date => p_date, p_trim_empty => false);
    v_no_ids_cur := mnp_pkg.get_no_current_any(p_na_id => v_na_ids, p_date => p_date, p_trim_empty => false);
    ------------------------------
    v_marks := util_pkg.cmp_ct_number(v_no_ids_ap, v_no_ids_cur, util_pkg.c_false, util_pkg.c_true); --!_!
    v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
    ------------------------------
    util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_not_same_no, v_positions);
    util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_not_same_no, v_positions);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
    v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  if install_pkg.nnget_option_bool(c_opt_check_relation2host, c_def_check_relation2host)
  then
    ------------------------------
    if install_pkg.nnget_option_bool(c_opt_check_excl_na_diff_no, c_def_check_excl_na_diff_no)
    then
      ------------------------------
      v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_na_ids, v_pivot);
      ------------------------------
      v_no_ids_own := mnp_pkg.get_no_own_any(p_na_id => v_na_ids, p_date => p_date, p_trim_empty => false);
      v_no_ids_cur := mnp_pkg.get_no_current_any(p_na_id => v_na_ids, p_date => p_date, p_trim_empty => false);
      ------------------------------
      v_marks := util_pkg.cmp_ct_number(v_no_ids_own, v_no_ids_cur, util_pkg.c_false, util_pkg.c_true); --!_!
      v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
      ------------------------------
      util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_pkg.c_ora_ok, v_positions);
      util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_pkg.c_msg_ok, v_positions);
      --!_!util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
      ------------------------------
      v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_na_ids, v_pivot);
    ------------------------------
    v_pns_ids := util_ri.get_na_pns_id(p_na_id => v_na_ids, p_date => p_date, p_trim_empty => false);
    v_pns_type_codes := util_ri.get_pns_type(p_pns_id => v_pns_ids, p_date => p_date, p_trim_empty => false);
    v_pnt_chr2hs := get_pnt_check_rel_to_host(p_pnt_code => v_pns_type_codes, p_date => p_date, p_trim_empty => false);
    ------------------------------
    v_marks := util_pkg.mark_val_ct_varchar_s(v_pnt_chr2hs, util_ri.c_YES);
    v_pivot := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
    ------------------------------
    v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_na_ids, v_pivot);
    v_pns_ids := util_ri.get_na_pns_id(p_na_id => v_na_ids, p_date => p_date, p_trim_empty => false);
    v_pns_host_ids := util_ri.get_pns_host_id(p_pns_id => v_pns_ids, p_date => p_date, p_trim_empty => false);
    ------------------------------
    v_ap_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_ap_ids, v_pivot);
    v_ss_ids := util_ri.get_ap_ss_id(p_ap_id => v_ap_ids, p_date => p_date, p_trim_empty => false);
    v_ss_host_ids := util_ri.get_ss_host_id(p_ss_id => v_ss_ids, p_date => p_date, p_trim_empty => false);
    ------------------------------
    v_marks := util_pkg.cmp_ct_number(v_pns_host_ids, v_ss_host_ids, util_pkg.c_false, util_pkg.c_true); --!_!
    v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
    ------------------------------
    util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_not_same_host_na_and_ap, v_positions);
    util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_not_same_host_na_and_ap, v_positions);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
    --!_!never used v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_error_codes, util_pkg.c_ora_ok);
  v_pivot := util_pkg.make_pivot(v_main_count);
  v_pivot := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  v_positions_skip := util_pkg.unique_ct_number(p_coll => v_positions_skip, p_save_order => true, p_trim_empty => true);
  v_pivot := util_pkg.filter_val_ct_number(p_vals => v_pivot, p_filter_vals => v_positions_skip, p_include_by_filter => false);
  ------------------------------
  ------------------------------
  if util_pkg.get_count_ct_number(v_pivot) > 0
  then
    ------------------------------
    v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_na_ids, v_pivot);
    v_ap_ids := util_coll_pkg.get_by_pos_ol_ct_number(p_ap_ids, v_pivot);
    v_link_type_codes := util_pkg.make_ct_varchar_s(util_pkg.get_count_ct_number(v_pivot), p_link_type_code);
    ------------------------------
    v_bool := util_ext_ri.set_naap_status2
    (
      p_na_id => v_na_ids,
      p_ap_id => v_ap_ids,
      p_link_type_code => v_link_type_codes,
      p_date => p_date,
      p_user_id => p_user_id,
      p_break_on_error => p_break_on_error,
      p_lock_pn => true,
      p_lock_sc => true,
      p_silent_proper_lack => false, --!_!means only for closing
      p_silent_break_actual => FALSE, --!_!means only for opening
      p_error_code => v_error_codes,
      p_error_message => v_error_messages
    );
    ------------------------------
    util_loc_pkg.touch_boolean(v_bool);
    ------------------------------
    util_pkg.set_by_pos2_ct_number(p_error_codes, v_error_codes, v_pivot);
    util_pkg.set_by_pos2_ct_varchar(p_error_messages, v_error_messages, v_pivot);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure link_phone_sim_i
(
  p_msisdns ct_varchar_s,
  p_iccids ct_varchar_s,
  p_link_type_code varchar2,
  p_date date,
  p_user_id number,
  p_break_on_error boolean,
  p_silent_already_linked_same boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  --
  v_main_count number;
  v_pivot ct_number;
  v_marks ct_number;
  v_positions ct_number;
  --
  v_na_ids ct_number;
  v_ap_ids ct_number;
  v_iccids ct_varchar_s;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  util_ri.XCheck_naap_link_type_code(p_link_type_code, 'p_link_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_silent_already_linked_same is null, 'p_silent_already_linked_same');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_iccids) != v_main_count, 'p_iccids.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns);
  util_pkg.XCheckP_FS_ct_varchar_s(p_iccids);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  ------------------------------
  v_na_ids := util_ri.get_na_id(p_msisdn => p_msisdns, p_date => p_date, p_trim_empty => false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_na_ids, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_phone_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_phone_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_na_ids := util_coll_pkg.get_unmarked_ol_ct_number(v_na_ids, v_marks);
  v_iccids := util_coll_pkg.get_by_pos_ol_ct_varchar_s(p_iccids, v_pivot);
  ------------------------------
  v_ap_ids := util_ri.get_ap_id(p_iccid => v_iccids, p_date => p_date, p_trim_empty => false);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(v_ap_ids, null);
  v_positions := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  util_pkg.set_val_by_pos2_ct_number(p_error_codes, util_loc_pkg.c_ora_sim_card_not_found, v_positions);
  util_pkg.set_val_by_pos2_ct_varchar(p_error_messages, util_loc_pkg.c_msg_sim_card_not_found, v_positions);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_coll_pkg.get_unmarked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  ------------------------------
  v_na_ids := util_coll_pkg.get_unmarked_ol_ct_number(v_na_ids, v_marks); --!_!v_na_ids.count <= v_main_count
  v_ap_ids := util_coll_pkg.get_unmarked_ol_ct_number(v_ap_ids, v_marks); --!_!v_ap_ids.count <= v_main_count
  ------------------------------
  link_na_ap_i
  (
    p_na_ids => v_na_ids,
    p_ap_ids => v_ap_ids,
    p_link_type_code => p_link_type_code,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_silent_already_linked_same => p_silent_already_linked_same,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_by_pos2_ct_number(p_error_codes, v_error_codes, v_pivot);
  util_pkg.set_by_pos2_ct_varchar(p_error_messages, v_error_messages, v_pivot);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure legacy_link_phone_sim
(
  p_msisdns ct_varchar_s,
  p_iccids ct_varchar_s,
  p_link_type_code varchar2,
  p_date date,
  p_user_id number,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_error_codes ct_number;
begin
  ------------------------------
  link_phone_sim_i
  (
    p_msisdns => p_msisdns,
    p_iccids => p_iccids,
    p_link_type_code => p_link_type_code,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => FALSE,
    p_silent_already_linked_same => TRUE,
    p_error_codes => v_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
  if install_pkg.nnget_option_bool(c_opt_leg_map_error_link_p_s, c_def_leg_map_error_link_p_s)
  then
    ------------------------------
    p_error_codes := legacy_link_phone_sim_map_err(v_error_codes);
    ------------------------------
  else
    ------------------------------
    p_error_codes := v_error_codes;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function legacy_link_phone_sim_map_err(p_error_codes ct_number) return ct_number
is
  v_res ct_number;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_error_codes);
  ------------------------------
  v_res := p_error_codes;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := legacy_link_phone_sim_map_err(p_error_codes(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function legacy_link_phone_sim_map_err(p_error_code number) return number
is
  lc_lg_NOT_SAME_HOST_ID constant number := -80;
  lc_lg_PHONE_NUMBER_NOT_EXISTS constant number := -133;
  lc_lg_SIM_CARD_NOT_EXISTS constant number := -134;
  lc_lg_SIM_HAVE_PHONE_NUMBER constant number := -147;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_error_code is null, 'p_error_code');
  ------------------------------
  return case p_error_code
    when util_loc_pkg.c_ora_phone_not_found then lc_lg_PHONE_NUMBER_NOT_EXISTS
    when util_loc_pkg.c_ora_sim_card_not_found then lc_lg_SIM_CARD_NOT_EXISTS
    when util_loc_pkg.c_ora_na_linked_to_other_ap then lc_lg_SIM_HAVE_PHONE_NUMBER --!_!
    when util_loc_pkg.c_ora_ap_linked_to_other_na then lc_lg_SIM_HAVE_PHONE_NUMBER --!_!
    when util_loc_pkg.c_ora_not_same_host_na_and_ap then lc_lg_NOT_SAME_HOST_ID
    else p_error_code
  end;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;

/
