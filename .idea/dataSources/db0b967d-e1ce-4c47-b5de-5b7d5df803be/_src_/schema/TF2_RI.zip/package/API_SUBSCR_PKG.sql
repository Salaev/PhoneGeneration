CREATE package API_SUBSCR_PKG is

----------------------------------!---------------------------------------------
  procedure activate_msisdn
  (
    p_date date,
    p_user_id number,
    p_na_id number,
    p_ap_id number,
    p_pa number,
    p_host_id number,
    p_na_id_extra ct_number,
    p_na_status_new varchar2,
    p_na_add_status_new varchar2,
    p_ap_status_new varchar2,
    p_not_change_msisdn_status boolean,
    p_not_change_sim_status boolean,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure activate_pa_pre
  (
    p_date date,
    p_user_id number,
    p_pa number,
    p_host_id number,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure activate_pa
  (
    p_date date,
    p_user_id number,
    p_pa number,
    p_host_id number,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure subscribers_activate
  (
    p_msisdn util_pkg.cit_varchar_s,
    p_iccid util_pkg.cit_varchar_s,
    p_personal_account util_pkg.cit_number,
    p_host_code util_pkg.cit_varchar_s,
    p_msisdns_extra util_pkg.cit_varchar,
    p_date date,
    p_user_nt_name varchar2,
    p_not_change_msisdn_status util_pkg.cit_number,
    p_not_change_sim_status util_pkg.cit_number,
    p_error_code out number,
    p_error_message out varchar2,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure deactivate_msisdn
  (
    p_date date,
    p_user_id number,
    p_na_id number,
    p_ap_id number,
    p_na_status_new varchar2,
    p_na_add_status_new varchar2,
    p_ap_status_new varchar2,
    p_ap_pstatus_new varchar2,
    p_change_sim_prod_status boolean,
    p_clear_sim_card_detail boolean,
    p_unlink_phone_and_sim boolean,
    p_link_phone_and_first_sim boolean,
    p_set_previous_phone_status boolean,
    p_not_change_sim_status boolean,
    p_not_change_msisdn_status boolean,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure deactivate_pa
  (
    p_date date,
    p_user_id number,
    p_pa number,
    p_not_available_host_id number,
    p_set_empty_host boolean,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure subscribers_deactivate
  (
    p_msisdn util_pkg.cit_varchar_s,
    p_phone_status_code util_pkg.cit_varchar_s,
    p_phone_add_status_code util_pkg.cit_varchar_s,
    p_sim_status_code util_pkg.cit_varchar_s,
    p_ap_prod_status_code util_pkg.cit_varchar_s,
    p_date date,
    p_user_nt_name varchar2,
    p_change_sim_prod_status util_pkg.cit_number,
    p_clear_sim_card_detail util_pkg.cit_number,
    p_unlink_phone_and_sim util_pkg.cit_number,
    p_link_first_sim_and_phone util_pkg.cit_number,
    p_set_empty_balance_storage util_pkg.cit_number,
    p_set_previous_phone_status util_pkg.cit_number,
    p_not_change_sim_status util_pkg.cit_number,
    p_not_change_msisdn_status util_pkg.cit_number,
    p_error_code out number,
    p_error_message out varchar2,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------

end;
/
