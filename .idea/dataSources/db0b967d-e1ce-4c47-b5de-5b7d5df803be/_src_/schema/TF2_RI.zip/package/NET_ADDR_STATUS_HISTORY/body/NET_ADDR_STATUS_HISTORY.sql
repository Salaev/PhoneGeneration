CREATE PACKAGE BODY NET_ADDR_STATUS_HISTORY IS

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
PROCEDURE Lock_Phones(
  p_international_format  IN  phone_number.international_format%TYPE,
  p_network_address_id    OUT phone_number.network_address_id%TYPE,
  p_error                 OUT INT
)
IS
BEGIN
  SELECT /*+ index(pn UK_PHONE_NUM_PHONE_NUMBER) */pn.network_address_id
  INTO p_network_address_id
  FROM phone_number pn
  WHERE pn.international_format=p_international_format
    AND (pn.deleted IS NULL OR pn.deleted>SYSDATE)
  FOR UPDATE;

  p_error:=rsig_utils.c_OK;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    p_error:=RSIG_UTILS.c_PHONE_NUMBER_NOT_EXISTS;
END;

----------------------------------!---------------------------------------------
FUNCTION Lock_Phone(
  p_international_format  IN  phone_number.international_format%TYPE
) RETURN INT
IS
  v_network_address_id           number;
BEGIN
  SELECT /*+ index(pn UK_PHONE_NUM_PHONE_NUMBER) */pn.network_address_id
  INTO v_network_address_id
  FROM phone_number pn
  WHERE pn.international_format=p_international_format
    AND (pn.deleted IS NULL OR pn.deleted>SYSDATE)
  FOR UPDATE;

  return rsig_utils.c_OK;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    return RSIG_UTILS.c_PHONE_NUMBER_NOT_EXISTS;
END;

----------------------------------!---------------------------------------------
FUNCTION Is_Status_Change_Allowed(
  p_network_address_id        IN   network_address.network_address_id%TYPE,
  p_new_status                IN   network_address_status_history.net_address_status_code%TYPE,
  p_IS_BP                     IN   VARCHAR2,
  p_date                      IN   DATE,
  p_internal_allowed          IN   CHAR
)RETURN INT
IS
  v_status                    network_address_status_history.net_address_status_code%TYPE;
  v_date                      DATE;
  v_result                    NUMBER(5);
  v_exist                     INT;
  v_tmp                       INT;
BEGIN
  IF upper(trim(p_internal_allowed))=RSIG_UTILS.c_NO AND
     upper(TRIM(p_new_status))=RSIG_UTILS.c_INTERNAL_PHONE_NUMBER_CODE
  THEN
    v_result:= RSIG_UTILS.c_INT_PHONE_STATUS_PERM;
    RETURN v_result;
  END IF;

  v_date:=nvl(p_date,SYSDATE);


  BEGIN
    SELECT /*+ index_asc(nash, I_NETADSTAHI_NETWORK_ADDRES_ID)*/
    nash.net_address_status_code
    INTO v_status
    FROM network_address_status_history nash
    WHERE nash.network_address_id=p_network_address_id
      AND v_date BETWEEN nash.start_date AND nvl(nash.end_date,v_date);
    --check, if v_date is in the last range, if not -> raise
    SELECT /*+ index_asc(nash, I_NETADSTAHI_NETWORK_ADDRES_ID)*/
      COUNT(1)
      INTO v_tmp
      FROM network_address_status_history nash
     WHERE nash.network_address_id = p_network_address_id
       AND v_date < nash.start_date;
    IF v_tmp != 0 THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_CHANGE_PH_STATUS_NOT_ALW, '');
    END IF;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_status:=NULL;
    WHEN TOO_MANY_ROWS THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_CHANGE_PH_STATUS_NOT_ALW, '');
  END;

  SELECT COUNT(1)
  INTO v_exist
  FROM dual
  WHERE EXISTS(SELECT 1
               FROM na_status_trans nst
               WHERE (nst.status_code_from=trim(v_status) OR(v_status IS NULL AND nst.status_code_from IS NULL))
                 AND nst.status_code_to=trim(p_new_status)
                 AND (nst.is_bp_only=p_IS_BP OR p_IS_BP=rsig_utils.c_YES));


  IF v_exist=0 THEN
    -- change is not allowed
    v_result:=RSIG_UTILS.c_CHANGE_PH_STATUS_NOT_ALW;
  ELSE

    IF upper(trim(p_internal_allowed))=RSIG_UTILS.c_NO AND
       upper(TRIM(v_status))=RSIG_UTILS.c_INTERNAL_PHONE_NUMBER_CODE
    THEN
      v_result:= RSIG_UTILS.c_INT_PHONE_STATUS_PERM;
    ELSE
      v_result:=RSIG_UTILS.c_OK;
    END IF;
  END IF;


  RETURN v_result;

END;

----------------------------------!---------------------------------------------
PROCEDURE Check_Phone_Status_Change(
  p_phone_status    IN  phone_number.net_address_status_code%TYPE,
  p_date            IN  DATE
)
IS
  v_exist           INT;
BEGIN
  -- check changing phone status
  UPDATE tt_batch_na_ap t
  SET t.RESULT = NET_ADDR_STATUS_HISTORY.Is_Status_Change_Allowed(t.network_address_id,
                                                                  p_phone_status,
                                                                  RSIG_UTILS.c_YES,
                                                                  p_date,
                                                                  RSIG_UTILS.c_YES);
  SELECT COUNT(1)
  INTO v_exist
  FROM dual
  WHERE EXISTS(SELECT 1
               FROM tt_batch_na_ap t
               WHERE t.result<>rsig_utils.c_OK);

  IF v_exist=1 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_CHANGE_PH_STATUS_NOT_ALW,'Not allowed to change phone status.');
  END IF;

END;

----------------------------------!---------------------------------------------
PROCEDURE Exist_Status_Code(
  p_status_code IN network_address_status_history.net_address_status_code%TYPE
)
IS
  v_pom number;
BEGIN
  -- find appropriate network address status code
  select 1
  into v_pom
  from NETWORK_ADDRESS_STATUS
  where TRIM(NET_ADDRESS_STATUS_CODE) = TRIM(p_status_code)
    AND deleted IS NULL
    AND rownum=1;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END;

----------------------------------!---------------------------------------------
FUNCTION Fnc_Exist_Status_Code(
  p_status_code IN network_address_status_history.net_address_status_code%TYPE
) return INT
IS
  v_pom number;
BEGIN
  -- find appropriate network address status code
  select 1
  into v_pom
  from NETWORK_ADDRESS_STATUS
  where TRIM(NET_ADDRESS_STATUS_CODE) = TRIM(p_status_code)
    AND deleted IS NULL
    AND rownum=1;

  RETURN rsig_utils.c_OK;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN rsig_utils.c_BAD_PHONE_STATUS;
END;

----------------------------------!---------------------------------------------
PROCEDURE Exist_Transition_Reason_Code(
  p_status             IN  network_address_status_history.net_address_status_code%TYPE,
  p_phone_Tran_Reason  IN  network_address_status_history.na_trans_reason_code%TYPE
)
IS
  v_pom number;
BEGIN
  -- find appropriate network address status code
  IF (p_phone_Tran_Reason IS NOT NULL)  THEN
    select 1
    into v_pom
    from NA_TRANS_REASON t1
    join NA_STATUS_TRANS t2
         on TRIM(t1.na_status_trans_code) = TRIM(t2.na_status_trans_code)
    where
      TRIM(t1.NA_TRANS_REASON_CODE) = TRIM(p_phone_Tran_Reason)
      AND TRIM(t2.STATUS_CODE_TO) = TRIM(p_status)
      AND t1.deleted IS NULL
      AND rownum=1;
  END IF;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END;

----------------------------------!---------------------------------------------
FUNCTION F_Exist_Transition_Reason_Code(
  p_status             IN  network_address_status_history.net_address_status_code%TYPE,
  p_phone_Tran_Reason  IN  network_address_status_history.na_trans_reason_code%TYPE
) RETURN INT
IS
  v_pom number;
BEGIN
  -- find appropriate network address status code
  IF (p_phone_Tran_Reason IS NOT NULL)  THEN
    select 1
    into v_pom
    from NA_TRANS_REASON t1
    join NA_STATUS_TRANS t2
         on TRIM(t1.na_status_trans_code) = TRIM(t2.na_status_trans_code)
    where
      TRIM(t1.NA_TRANS_REASON_CODE) = TRIM(p_phone_Tran_Reason)
      AND TRIM(t2.STATUS_CODE_TO) = TRIM(p_status)
      AND t1.deleted IS NULL
      AND rownum=1;
  END IF;

  RETURN rsig_utils.c_OK;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN rsig_utils.c_ORA_UNABLE_CHANGE_NETSTATUS;
END;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
END;
/
