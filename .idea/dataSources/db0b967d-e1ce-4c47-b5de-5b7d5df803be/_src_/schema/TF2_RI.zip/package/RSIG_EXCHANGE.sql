CREATE PACKAGE          "RSIG_EXCHANGE" IS
/****************************************************************************
<header>
  <name>             	packager RSIG_EXCHANGE
  </name>

  <author>           	Jan Stodulka - GITUS
  </author>

  <version>           1.1.3   12.07.2010      Sergey Ermakov
                      procedure Get_Exchange updated
                      procedure Get_Exchange_NetHost updated
                      procedure Get_Exchange_NetHost_All updated
                      procedure Get_Exchange_All updated                      
  </version>
  <version>           1.1.2   02.06.2010      Sergey Ermakov
                      procedure Insert_Exchange2 updated
                      procedure Update_Exchange2 updated
  </version>
  <version>           1.1.1   30.03.2006      Petr Cepek
                      procedure Get_Exchange_NetHost_All updated
  </version>
  <version>
                      1.1.0   11.08.2005      Petr Cepek
                      constants c_get_exchange,c_get_exchange_nethost,c_get_exchange_nethost_all,c_get_exchange_all
                      deleted
  </version>
  <version>           1.0.9   20.06.2005      Petr Cepek
                              procedure Get_phone_ranges_by_IPs created

  </version>
  <version>           1.0.8   06.06.2005      Petr Cepek
                              procedures Insert_Exchange, Insert_Exchange2 updated

	<version>          	1.0.7   04.04.2005    	Jaroslav Holub
                              modify procedures GET_EXCHANGE, GET_EXCHANGE_NETHOST
                              GET_EXCHANGE_NETHOST_ALL,GET_EXCHANGE_ALL  to return
                              time_zone in result_list - it depends on constantc (name of procedure with prefix c_)
	</version>

	<version>          	1.0.6   24.3.2005    	Jaroslav Holub
                              added Insert_exchange2, Update_exchange2 and make
                              code in Insert/Update_exchange more readable
	</version>
	<version>          	1.0.5   12.7.2004    	Jaroslav Holub
								              GET_EXCHANGE, GET_EXCHANGE_NETHOST,
                              GET_EXCHANGE_NETHOST_ALL, GET_EXCHANGE_ALL
									            add - ORDER BY ex_t.EXCHANGE_TYPE_CODE, h.HOST_NAME
	</version>
	<version>          	1.0.4   21.6.2004    	Jaroslav Holub
                              modified for exchange_type_id column
	</version>
  <version>           1.0.3   16.6.2004     Jaroslav Holub
                              Insert_Exchange - Add parameter p_host_type_code

  </version>
	<version>          	1.0.2   8.12.2003     Csaba Filip
                              Include EXCHANGE among HOST
	</version>
	<version>          	1.0.1   17.9.2003    	jan Stodulka
                              created fisrts version
	</version>

  <Description>         Package contains procedures for managing exchanges.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/

-- constants for managing result_lists - if 'Y' - then return timezone,
--                                          'N' - do not return timezone
/*c_get_exchange             CONSTANT CHAR(1) := RSIG_UTILS.c_NO;
c_get_exchange_nethost     CONSTANT CHAR(1) := RSIG_UTILS.c_NO;
c_get_exchange_nethost_all CONSTANT CHAR(1) := RSIG_UTILS.c_NO;
c_get_exchange_all         CONSTANT CHAR(1) := RSIG_UTILS.c_NO;*/



/****************************************************************************
  <header>
    <name>              procedure Insert_Exchange
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>         1.0.5   06.06.2005   Petr Cepek
                      error handling updated
    </version>

	<version>          	1.0.4   21.6.2004    	Jaroslav Holub
                              	modified for exchange_type_id collumn
	</version>
    <version>           1.0.3   16.6.2004     Jaroslav Holub
                                Add parameter p_host_type_code

    </version>
    <version>           1.0.2   8.12.2003     Csaba Filip
                                Include EXCHANGE among HOST

    </version>
    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure inserts a new exchange.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code                  - Error code
                        p_exchange_name             - Name of exchange
                        p_exchange_phone_prefix     - Phone prefix of exchange
                        p_exchange_type_code        - Code of exchange type
                        p_exchange_usage_type_code  - Code of exchange usage type
                        p_network_operator_id       - Network operator id
                        p_commissioning_date        - Commissioning date of exchange
                        p_country_abbreviation      - Country abbreviation of exchange
                        p_address_id                - Address id
                        p_user_id_of_change         - User id of change
                        p_host_code
                        p_host_address
                        p_host_location
                        p_host_type_code
                        p_exchange_id               - New exchange id
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Insert_Exchange(
    handle_tran                 IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                  OUT NUMBER,
    p_exchange_name             IN  HOST.HOST_NAME%TYPE,--VARCHAR2,--cf*EXCHANGE.EXCHANGE_NAME%TYPE,
    p_exchange_phone_prefix     IN  EXCHANGE.EXCHANGE_PHONE_PREFIX%TYPE,
    p_exchange_type_id        	IN  EXCHANGE.EXCHANGE_TYPE_ID%TYPE,
    p_exchange_usage_type_code  IN  EXCHANGE.EXCHANGE_USAGE_TYPE_CODE%TYPE,
    p_network_operator_id       IN  HOST.NETWORK_OPERATOR_ID%TYPE,--NUMBER,--cf*EXCHANGE.NETWORK_OPERATOR_ID%TYPE,
    p_commissioning_date        IN  EXCHANGE.COMMISSIONING_DATE%TYPE,
    p_country_abbreviation      IN  EXCHANGE.COUNTRY_ABBREVIATION%TYPE,
    p_address_id                IN  EXCHANGE.ADDRESS_ID%TYPE,
    p_user_id_of_change         IN  NUMBER,
    p_host_code                 IN HOST.HOST_CODE%TYPE,
    p_host_address              IN HOST.HOST_ADDRESS%TYPE,
    p_host_location             IN HOST.HOST_LOCATION%TYPE,
    p_host_type_code            IN HOST.HOST_TYPE_CODE%TYPE,
    p_exchange_id               OUT NUMBER --cf*EXCHANGE.EXCHANGE_ID%TYPE
  );

/****************************************************************************
  <header>
    <name>              procedure Update_Exchange
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

	<version>          	1.0.3   21.6.2004    	Jaroslav Holub
                              	modified for exchange_type_id collumn
	</version>
    <version>           1.0.2   8.12.2003     Csaba Filip
                                Include EXCHANGE among HOST
	</version>

    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure updates values of exchange given by exchange id,
                        if given exchange is currently not deleted

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_ORA_DELETED
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code                  - Error code
                        p_exchange_id               - Exchange id - this column not updated
                        p_exchange_name             - Name of exchange
                        p_exchange_phone_prefix     - Phone prefix of exchange
                        p_exchange_type_code        - Code of exchange type
                        p_exchange_usage_type_code  - Code of exchange usage type
                        p_network_operator_id       - Network operator id
                        p_commissioning_date        - Commissioning date of exchange
                        p_country_abbreviation      - Country abbreviation of exchange
                        p_address_id                - Address id
                        p_user_id_of_change         - User id of change
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Update_Exchange(
    handle_tran                 IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                  OUT NUMBER,
    p_exchange_id               IN  HOST.HOST_ID%TYPE,--NUMBER,--cf*EXCHANGE.EXCHANGE_ID%TYPE,
    p_exchange_name             IN  HOST.HOST_NAME%TYPE,--VARCHAR2,--cf*EXCHANGE.EXCHANGE_NAME%TYPE,
    p_exchange_phone_prefix     IN  EXCHANGE.EXCHANGE_PHONE_PREFIX%TYPE,
    p_exchange_type_id        	IN  EXCHANGE.EXCHANGE_TYPE_ID%TYPE,
    p_exchange_usage_type_code  IN  EXCHANGE.EXCHANGE_USAGE_TYPE_CODE%TYPE,
    p_network_operator_id       IN  HOST.NETWORK_OPERATOR_ID%TYPE,----NUMBER,--cf*EXCHANGE.NETWORK_OPERATOR_ID%TYPE,
    p_commissioning_date        IN  EXCHANGE.COMMISSIONING_DATE%TYPE,
    p_country_abbreviation      IN  EXCHANGE.COUNTRY_ABBREVIATION%TYPE,
    p_address_id                IN  EXCHANGE.ADDRESS_ID%TYPE,
		p_host_address        			IN   HOST.HOST_ADDRESS%TYPE,
    p_host_location       			IN   HOST.HOST_LOCATION%TYPE,
    p_user_id_of_change         IN  NUMBER
  );

/****************************************************************************
  <header>
    <name>              procedure Delete_Exchange
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

	<version>          	1.0.3   21.6.2004    	Jaroslav Holub
                              	modified for exchange_type_id collumn
	</version>
    <version>           1.0.2   8.12.2003     Csaba Filip
                                Include EXCHANGE among HOST
                                procedure deleted
    </version>
    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure sets column DELETED to value of parameter
                        deleted in program exchange by exchange id, if given
                        xchange is currently not deleted.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_ORA_DELETED
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code    - Error code
                        p_exchange_id - Exchange id
                        p_deleted		  - value for set attribute (DELETED)
                        p_user_id_of_change - User id of change
    </Parameters>

  </header>
/****************************************************************************/
/*
  PROCEDURE Delete_Exchange(
    handle_tran             IN    CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code              OUT   NUMBER,
    p_exchange_id           IN    NUMBER,--cf*EXCHANGE.EXCHANGE_ID%TYPE,
    p_deleted               IN    DATE,--cf*EXCHANGE.DELETED%TYPE,
    p_user_id_of_change     IN    NUMBER
  );
*/
/****************************************************************************
  <header>
    <name>              procedure Get_Exchange
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

	<version>          	1.0.5   04.04.2005    	Jaroslav Holub
                              modify procedures GET_EXCHANGE, GET_EXCHANGE_NETHOST
                              GET_EXCHANGE_NETHOST_ALL,GET_EXCHANGE_ALL  to return
                              time_zone in result_list - it depends on constantc (name of procedure with prefix c_)
	</version>
	<version>          	1.0.4   12.7.2004    	Jaroslav Holub
								add - ORDER BY ex_t.EXCHANGE_TYPE_CODE, h.HOST_NAME
	</version>
	<version>          	1.0.3   21.6.2004    	Jaroslav Holub
                              	modified for exchange_type_id collumn
	</version>
    <version>           1.0.2   8.12.2003     Csaba Filip
                                Include EXCHANGE among HOST

    </version>
    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure for getting all exchanges for given network
                        operator.
                        Input parameters are optional, the contents of output
                        ref cursor depends on input parameter:
                        1.	If input parameter p_network_operator_id is not null
                        then ref cursor contains records of table exchange with
                        given network_operator_id
                        Ref cursor contains columns: EXCHANGE_ID, EXCHANGE_NAME,
                        EXCHANGE_PHONE_PREFIX, EXCHANGE_TYPE_CODE, EXCHANGE_USAGE_TYPE_CODE,
                        COMMISSIONING_DATE, COUNTRY_ABBREVIATION, ADDRESS_ID, DATE_OF_CHANGE,
                        USER_ID_OF_CHANGE.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code              - Error code
                        p_network_operator_id   - Network operator id
                        p_cur_exchange          - cursor to retrieve all exchange (ref cursor columns by equally as return value function Get_Exchange)
                                                  (EXCHANGE_ID, EXCHANGE_NAME, EXCHANGE_PHONE_PREFIX, EXCHANGE_TYPE_CODE, EXCHANGE_USAGE_TYPE_CODE, NETWORK_OPERATOR_ID, COMMISSIONING_DATE, COUNTRY_ABBREVIATION, ADDRESS_ID, DATE_OF_CHANGE, USER_ID_OF_CHANGE)
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Get_Exchange(
    error_code              OUT  NUMBER,
    p_network_operator_id   IN   HOST.NETWORK_OPERATOR_ID%TYPE,--NUMBER, --cf*EXCHANGE.NETWORK_OPERATOR_ID%TYPE,
    p_cur_exchange          OUT  RSIG_UTILS.REF_CURSOR
  );


 /****************************************************************************
  <header>
    <name>              procedure Get_Exchange_NetHost
    </name>

    <author>            Pavel Stengl
    </author>

	<version>          	1.0.4   04.04.2005    	Jaroslav Holub
                              modify procedures GET_EXCHANGE, GET_EXCHANGE_NETHOST
                              GET_EXCHANGE_NETHOST_ALL,GET_EXCHANGE_ALL  to return
                              time_zone in result_list - it depends on constantc (name of procedure with prefix c_)
	</version>
	<version>          	1.0.3   12.7.2004    	Jaroslav Holub
								add - ORDER BY ex_t.EXCHANGE_TYPE_CODE, h.HOST_NAME
	</version>
	<version>          	1.0.2   21.6.2004    	Jaroslav Holub
                              	modified for exchange_type_id collumn
	</version>
    <version>           1.0.1   21.1.2004     Pavel Stengl
                                created first version

    </version>

    <Description>       Procedure for getting exchanges for given network
                        operator and host type.
                        Input parameter NETTWORK_OPERATOR is optional, the contents of output
                        ref cursor depends on input parameter

                        Ref cursor contains columns: EXCHANGE_ID, EXCHANGE_NAME,
                        EXCHANGE_PHONE_PREFIX, EXCHANGE_TYPE_CODE, EXCHANGE_USAGE_TYPE_CODE,
                        COMMISSIONING_DATE, COUNTRY_ABBREVIATION, ADDRESS_ID, DATE_OF_CHANGE,
                        USER_ID_OF_CHANGE.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code              - Error code
                        p_network_operator_id   - Network operator id
                        p_host_type_code        - host type code
                        p_cur_exchange          - cursor to retrieve all exchange (ref cursor columns by equally as return value function Get_Exchange)
                                                  (EXCHANGE_ID, EXCHANGE_NAME, EXCHANGE_PHONE_PREFIX, EXCHANGE_TYPE_CODE, EXCHANGE_USAGE_TYPE_CODE, NETWORK_OPERATOR_ID, COMMISSIONING_DATE, COUNTRY_ABBREVIATION, ADDRESS_ID, DATE_OF_CHANGE, USER_ID_OF_CHANGE)
    </Parameters>

  </header>
/****************************************************************************/


 PROCEDURE Get_Exchange_NetHost(
    error_code              OUT  NUMBER,
    p_network_operator_id   IN   HOST.NETWORK_OPERATOR_ID%TYPE,--NUMBER, --cf*EXCHANGE.NETWORK_OPERATOR_ID%TYPE,
    p_host_type_code        IN   HOST.HOST_TYPE_CODE%TYPE,
    p_cur_exchange          OUT  RSIG_UTILS.REF_CURSOR
  );


 /****************************************************************************
  <header>
    <name>              procedure Get_Exchange_NetHost_All
    </name>

    <author>            Pavel Stengl
    </author>

    <version>           1.0.5   30.03.2006      Petr Cepek
                        new parameter p_exchange_usage_type was added
    </version>
	<version>          	  1.0.4   04.04.2005    	Jaroslav Holub
                              modify procedures GET_EXCHANGE, GET_EXCHANGE_NETHOST
                              GET_EXCHANGE_NETHOST_ALL,GET_EXCHANGE_ALL  to return
                              time_zone in result_list - it depends on constantc (name of procedure with prefix c_)
	</version>
	<version>          	  1.0.3   12.7.2004    	Jaroslav Holub
								        add - ORDER BY ex_t.EXCHANGE_TYPE_CODE, h.HOST_NAME
	</version>
	<version>          	  1.0.2   21.6.2004    	Jaroslav Holub
                              	modified for exchange_type_id collumn
	</version>
    <version>           1.0.1   4.2.2004     Pavel Stengl
                                created first version

    </version>

    <Description>       Procedure for getting all exchanges (deleted exchange too)
												for given network operator and host type.
                        Input parameter NETTWORK_OPERATOR is optional, the contents of output
                        ref cursor depends on input parameter

                        Ref cursor contains columns: EXCHANGE_ID, EXCHANGE_NAME,
                        EXCHANGE_PHONE_PREFIX, EXCHANGE_TYPE_CODE, EXCHANGE_USAGE_TYPE_CODE,
                        COMMISSIONING_DATE, COUNTRY_ABBREVIATION, ADDRESS_ID, DATE_OF_CHANGE,
                        USER_ID_OF_CHANGE.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code              - Error code
                        p_network_operator_id   - Network operator id
                        p_host_type_code        - host type code
                        p_cur_exchange          - cursor to retrieve all exchange (ref cursor columns by equally as return value function Get_Exchange)
                                                  (EXCHANGE_ID, EXCHANGE_NAME, EXCHANGE_PHONE_PREFIX, EXCHANGE_TYPE_CODE, EXCHANGE_USAGE_TYPE_CODE, NETWORK_OPERATOR_ID, COMMISSIONING_DATE, COUNTRY_ABBREVIATION, ADDRESS_ID, DATE_OF_CHANGE, USER_ID_OF_CHANGE)
    </Parameters>

  </header>
/****************************************************************************/

PROCEDURE Get_Exchange_NetHost_All(
  ERROR_CODE                   OUT NUMBER,
  p_network_operator_id        IN  network_operator.NETWORK_OPERATOR_ID%TYPE, --NUMBER, --cf*EXCHANGE.NETWORK_OPERATOR_ID%TYPE,
  p_host_type_code             IN  HOST.HOST_TYPE_CODE%TYPE,
  p_exchange_usage_type        IN  exchange.exchange_usage_type_code%TYPE,
  p_cur_exchange               OUT RSIG_UTILS.REF_CURSOR
);

/****************************************************************************
  <header>
    <name>              procedure Get_Exchange_All
    </name>

    <author>            PAvel Stengl
    </author>

	<version>          	1.0.4   04.04.2005    	Jaroslav Holub
                              modify procedures GET_EXCHANGE, GET_EXCHANGE_NETHOST
                              GET_EXCHANGE_NETHOST_ALL,GET_EXCHANGE_ALL  to return
                              time_zone in result_list - it depends on constantc (name of procedure with prefix c_)
	</version>
	<version>          	1.0.3   12.7.2004    	Jaroslav Holub
								add - ORDER BY ex_t.EXCHANGE_TYPE_CODE, h.HOST_NAME
	</version>
	<version>          	1.0.2   21.6.2004    	Jaroslav Holub
                              	modified for exchange_type_id collumn
	</version>
    <version> 		 	1.0.1   4.2.2004			Pavel Stengl
						created first version

    </version>

    <Description>       Procedure for getting all exchanges (deleted exchange too)
												for given network operator.
                        Input parameters are optional, the contents of output
                        ref cursor depends on input parameter:
                        1.	If input parameter p_network_operator_id is not null
                        then ref cursor contains records of table exchange with
                        given network_operator_id
                        Ref cursor contains columns: EXCHANGE_ID, EXCHANGE_NAME,
                        EXCHANGE_PHONE_PREFIX, EXCHANGE_TYPE_CODE, EXCHANGE_USAGE_TYPE_CODE,
                        COMMISSIONING_DATE, COUNTRY_ABBREVIATION, ADDRESS_ID, DATE_OF_CHANGE,
                        USER_ID_OF_CHANGE.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code              - Error code
                        p_network_operator_id   - Network operator id
                        p_cur_exchange          - cursor to retrieve all exchange (ref cursor columns by equally as return value function Get_Exchange)
                                                  (EXCHANGE_ID, EXCHANGE_NAME, EXCHANGE_PHONE_PREFIX, EXCHANGE_TYPE_CODE, EXCHANGE_USAGE_TYPE_CODE, NETWORK_OPERATOR_ID, COMMISSIONING_DATE, COUNTRY_ABBREVIATION, ADDRESS_ID, DATE_OF_CHANGE, USER_ID_OF_CHANGE)
    </Parameters>

  </header>
/****************************************************************************/

 PROCEDURE Get_Exchange_All(
    error_code              OUT  NUMBER,
    p_network_operator_id   IN   HOST.NETWORK_OPERATOR_ID%TYPE,--NUMBER, --cf*EXCHANGE.NETWORK_OPERATOR_ID%TYPE,
    p_cur_exchange          OUT  RSIG_UTILS.REF_CURSOR
  );

/****************************************************************************
  <header>
    <name>              procedure Insert_Exchange2
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.0.1   24.3.2005     Jaroslav Holub
                                created first version - build on Insert_exchange
                                but added p_time_zone
    </version>

    <Description>       Procedure inserts a new exchange.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code                  - Error code
                        p_exchange_name             - Name of exchange
                        p_exchange_phone_prefix     - Phone prefix of exchange
                        p_exchange_type_code        - Code of exchange type
                        p_exchange_usage_type_code  - Code of exchange usage type
                        p_network_operator_id       - Network operator id
                        p_commissioning_date        - Commissioning date of exchange
                        p_country_abbreviation      - Country abbreviation of exchange
                        p_address_id                - Address id
                        p_user_id_of_change         - User id of change
                        p_host_code
                        p_host_address
                        p_host_location
                        p_host_type_code
                        p_exchange_id               - New exchange id
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Insert_Exchange2
  (
    handle_tran                IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    ERROR_CODE                 OUT NUMBER,
    p_exchange_name            IN HOST.HOST_NAME%TYPE,
    p_exchange_phone_prefix    IN EXCHANGE.EXCHANGE_PHONE_PREFIX%TYPE,
    p_exchange_type_id         IN EXCHANGE.EXCHANGE_TYPE_ID%TYPE,
    p_exchange_usage_type_code IN EXCHANGE.EXCHANGE_USAGE_TYPE_CODE%TYPE,
    p_network_operator_id      IN HOST.NETWORK_OPERATOR_ID%TYPE,
    p_commissioning_date       IN EXCHANGE.COMMISSIONING_DATE%TYPE,
    p_country_abbreviation     IN EXCHANGE.COUNTRY_ABBREVIATION%TYPE,
    p_address_id               IN EXCHANGE.ADDRESS_ID%TYPE,
    p_user_id_of_change        IN NUMBER,
    p_host_code                IN HOST.HOST_CODE%TYPE,
    p_host_address             IN HOST.HOST_ADDRESS%TYPE,
    p_host_location            IN HOST.HOST_LOCATION%TYPE,
    p_host_type_code           IN HOST.HOST_TYPE_CODE%TYPE,
    p_time_zone                IN HOST.TIME_ZONE%TYPE,
    p_dst_rule_id              IN NUMBER,
    p_exchange_id              OUT NUMBER
  );

/****************************************************************************
  <header>
    <name>              procedure Update_Exchange2
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>         1.0.5   06.06.2005   Petr Cepek
                      error handling updated
    </version>
    <version>           1.0.1   24.3.2005     Jaroslav Holub
                                created first version - build on Update_exchange
                                but added p_time_zone
    </version>

    <Description>       Procedure updates values of exchange given by exchange id,
                        if given exchange is currently not deleted

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_ORA_DELETED
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code                  - Error code
                        p_exchange_id               - Exchange id - this column not updated
                        p_exchange_name             - Name of exchange
                        p_exchange_phone_prefix     - Phone prefix of exchange
                        p_exchange_type_code        - Code of exchange type
                        p_exchange_usage_type_code  - Code of exchange usage type
                        p_network_operator_id       - Network operator id
                        p_commissioning_date        - Commissioning date of exchange
                        p_country_abbreviation      - Country abbreviation of exchange
                        p_address_id                - Address id
                        p_user_id_of_change         - User id of change
                        p_time_zone                IN HOST.TIME_ZONE%TYPE

    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Update_Exchange2 (
    handle_tran                IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    ERROR_CODE                 OUT NUMBER,
    p_exchange_id              IN HOST.HOST_ID%TYPE, --NUMBER,--cf*EXCHANGE.EXCHANGE_ID%TYPE,
    p_exchange_name            IN HOST.HOST_NAME%TYPE, --VARCHAR2,--cf*EXCHANGE.EXCHANGE_NAME%TYPE,
    p_exchange_phone_prefix    IN EXCHANGE.EXCHANGE_PHONE_PREFIX%TYPE,
    p_exchange_type_id         IN EXCHANGE.EXCHANGE_TYPE_ID%TYPE,
    p_exchange_usage_type_code IN EXCHANGE.EXCHANGE_USAGE_TYPE_CODE%TYPE,
    p_network_operator_id      IN HOST.NETWORK_OPERATOR_ID%TYPE, ----NUMBER,--cf*EXCHANGE.NETWORK_OPERATOR_ID%TYPE,
    p_commissioning_date       IN EXCHANGE.COMMISSIONING_DATE%TYPE,
    p_country_abbreviation     IN EXCHANGE.COUNTRY_ABBREVIATION%TYPE,
    p_address_id               IN EXCHANGE.ADDRESS_ID%TYPE,
    p_host_address             IN HOST.HOST_ADDRESS%TYPE,
    p_host_location            IN HOST.HOST_LOCATION%TYPE,
    p_user_id_of_change        IN NUMBER,
    p_time_zone                IN HOST.TIME_ZONE%TYPE,
    p_dst_rule_id              IN NUMBER
  );

/****************************************************************************
<header>
  <name>            procedure Get_phone_ranges_by_IPs
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  15.6.2005 8:59:28  -  created
  </version>

  <Description>     Procedure returns phone ranges, which have relation to the same
                    host address at given moment
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_phone_ranges_by_IPs(
  p_validity_date   IN   Date,
  p_raise_error     IN   CHAR,
  error_code        OUT  NUMBER,
  error_message     OUT  VARCHAR2,
  result_list       OUT  sys_refcursor
);


END RSIG_EXCHANGE;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_EXCHANGE.pkg,v 1.15 2003/12/15 09:02:21 jstodulk Exp $

/
