CREATE PACKAGE RSIG_SIM_SE_STAT_VALIDITY IS
/****************************************************************************
<header>
  <name>             	package RSIG_SIM_SE_STAT_VALIDITY
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>           1.0.5    22.11.2006    Petr Cepek
                      procedure Close_Interval deleted
                      procedure Update_Interval deleted
  </version
  <version>           1.0.4   29.09.2006     Petr Cepek
                      procedure Insert_Interval updated
  </version>
  <version>           1.0.3   10.9.2004     Jaroslav Holub
                 			Insert_Interval, Update_Interval,Close_Interval
								       - fixed for time difference between client and
								        server, date should be null and it means sysdate
  </version>
  <version>          	1.0.2   09:48:02     Skorotkevich
                                Fixed several bugs related to intervals.
  </version>
  <version>          	1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	Package contains procedure for managing sim series
                      production status.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/

/****************************************************************************
<header>
  <name>            procedure Is_Prod_Status_Change_Allowed
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  4.10.2006  -  created
  </version>

  <Description>     Function check if for some sim series can
                    be changed production status to new status.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
FUNCTION Is_Prod_Status_Change_Allowed(
  p_sim_series_id          IN  sim_series.sim_series_id%TYPE,
  p_new_status             IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_IS_BP                  IN  VARCHAR2,
  p_date                   IN  DATE
)RETURN INT;

  /****************************************************************************
<header>
  <name>             	procedure Insert_Interval
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>           1.0.3   29.09.2006     Petr Cepek
                      procedure changed: when last status is same as
                      new status, no new status is inserted
  </version>

  <version>           1.0.2   10.9.2004     Jaroslav Holub
                 			fixed for time difference
								      between client and server, date should be null
								      and it means sysdate
  </version>
  <version>          	1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	procedure first checks,  whether interval, that starts
                      with given start date, is overlapped with any existing
                      interval or not. If it is overlapped, procedure ends
                      with error c_DATE_OVERLAP.
                      If check passed successfully,  procedure inserts interval
                      given by sim serie id and consequently closes last interval
                      (end_date is set to value of parameter start date).
  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_status_code - IN - value for new interval (STATUS_CODE)
                      p_sim_series_id - IN - value for new interval (SIM_SERIES_ID)
                      p_start_date - IN - value for new interval (START_DATE)
                                          value for set end of prior interval (END_DATE)
                      p_user_id_of_change - IN - user id of change for new interval and
                                                 for prior interval (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/
PROCEDURE Insert_Interval(
  p_status_code           IN  SIM_SERIES_STATUS_VALIDITY.STATUS_CODE%TYPE,
  p_sim_series_id         IN  SIM_SERIES_STATUS_VALIDITY.SIM_SERIES_ID%TYPE,
  p_start_date            IN  SIM_SERIES_STATUS_VALIDITY.START_DATE%TYPE,
  p_IS_BP                 IN  VARCHAR2,
  p_user_id               IN  NUMBER,
  p_handle_tran	          IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code            OUT NUMBER,
  p_error_message	        OUT VARCHAR2
);

END RSIG_SIM_SE_STAT_VALIDITY;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_SIM_SE_STAT_VALIDITY.pkg,v 1.15 2003/12/15 10:21:03 prybicka Exp $
/
