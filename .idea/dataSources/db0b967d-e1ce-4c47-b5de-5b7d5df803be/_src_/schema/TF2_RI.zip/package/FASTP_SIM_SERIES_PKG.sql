CREATE package fastp_sim_series_pkg is

----------------------------------!---------------------------------------------
  c_this_package_name            constant varchar2(30) := 'fastp_sim_series_pkg';

  --!_!flow_type_id
  c_fastp_ft_sim_ser_split       constant number := 2;

----------------------------------!---------------------------------------------
  c_opt_sim_ser_split_paral_mode constant varchar2(100) := 'SimSeries.Split.ParallelMode';

  c_opt_fastp_block_count        constant varchar2(100) := 'FastParallel.SplitSimSeries.BlockCount';
  c_opt_fastp_job_count          constant varchar2(100) := 'FastParallel.SplitSimSeries.JobCount';

  c_opt_fastp_flow_reversible    constant varchar2(100) := 'FastParallel.SplitSimSeries.Flow.Reversible';
  c_opt_fastp_flow_retry_count   constant varchar2(100) := 'FastParallel.SplitSimSeries.Flow.RetryCount';
  c_opt_fastp_flow_retry_sec     constant varchar2(100) := 'FastParallel.SplitSimSeries.Flow.RetryIntervalSeconds';
  c_opt_fastp_flow_wt_lck_sec    constant varchar2(100) := 'FastParallel.SplitSimSeries.Flow.WaitLockSeconds';

  c_opt_fastp_pre_retry_count    constant varchar2(100) := 'FastParallel.SplitSimSeries.Pre.RetryCount';
  c_opt_fastp_pre_retry_sec      constant varchar2(100) := 'FastParallel.SplitSimSeries.Pre.RetryIntervalSeconds';
  c_opt_fastp_pre_waitalljobs    constant varchar2(100) := 'FastParallel.SplitSimSeries.Pre.WaitAllJobsCompletion';
  c_opt_fastp_pre_sync_commit    constant varchar2(100) := 'FastParallel.SplitSimSeries.Pre.SynchronousCommit';
  c_opt_fastp_pre_slp_tm_sec     constant varchar2(100) := 'FastParallel.SplitSimSeries.Pre.IdleSleepTimeSeconds';
  c_opt_fastp_pre_exp_tmt_sec    constant varchar2(100) := 'FastParallel.SplitSimSeries.Pre.ExpiredTimeoutSeconds';
  c_opt_fastp_pre_wt_lck_sec     constant varchar2(100) := 'FastParallel.SplitSimSeries.Pre.WaitLockSeconds';
  c_opt_fastp_prej_retry_count   constant varchar2(100) := 'FastParallel.SplitSimSeries.Pre.Job.RetryCount';
  c_opt_fastp_prej_retry_sec     constant varchar2(100) := 'FastParallel.SplitSimSeries.Pre.Job.RetryIntervalSeconds';
  c_opt_fastp_prej_slp_tm_sec    constant varchar2(100) := 'FastParallel.SplitSimSeries.Pre.Job.IdleSleepTimeSeconds';
  c_opt_fastp_prej_exp_tmt_sec   constant varchar2(100) := 'FastParallel.SplitSimSeries.Pre.Job.ExpiredTimeoutSeconds';
  c_opt_fastp_prej_wt_lck_sec    constant varchar2(100) := 'FastParallel.SplitSimSeries.Pre.Job.WaitLockSeconds';
  c_opt_fastp_prej_keepalv_sec   constant varchar2(100) := 'FastParallel.SplitSimSeries.Pre.Job.KeepaliveSeconds';

  c_opt_fastp_paral_retry_count  constant varchar2(100) := 'FastParallel.SplitSimSeries.Parallel.RetryCount';
  c_opt_fastp_paral_retry_sec    constant varchar2(100) := 'FastParallel.SplitSimSeries.Parallel.RetryIntervalSeconds';
  c_opt_fastp_paral_waitalljobs  constant varchar2(100) := 'FastParallel.SplitSimSeries.Parallel.WaitAllJobsCompletion';
  c_opt_fastp_paral_sync_commit  constant varchar2(100) := 'FastParallel.SplitSimSeries.Parallel.SynchronousCommit';
  c_opt_fastp_paral_slp_tm_sec   constant varchar2(100) := 'FastParallel.SplitSimSeries.Parallel.IdleSleepTimeSeconds';
  c_opt_fastp_paral_exp_tmt_sec  constant varchar2(100) := 'FastParallel.SplitSimSeries.Parallel.ExpiredTimeoutSeconds';
  c_opt_fastp_paral_wt_lck_sec   constant varchar2(100) := 'FastParallel.SplitSimSeries.Parallel.WaitLockSeconds';
  c_opt_fastp_paralj_retry_count constant varchar2(100) := 'FastParallel.SplitSimSeries.Parallel.Job.RetryCount';
  c_opt_fastp_paralj_retry_sec   constant varchar2(100) := 'FastParallel.SplitSimSeries.Parallel.Job.RetryIntervalSeconds';
  c_opt_fastp_paralj_slp_tm_sec  constant varchar2(100) := 'FastParallel.SplitSimSeries.Parallel.Job.IdleSleepTimeSeconds';
  c_opt_fastp_paralj_exp_tmt_sec constant varchar2(100) := 'FastParallel.SplitSimSeries.Parallel.Job.ExpiredTimeoutSeconds';
  c_opt_fastp_paralj_wt_lck_sec  constant varchar2(100) := 'FastParallel.SplitSimSeries.Parallel.Job.WaitLockSeconds';
  c_opt_fastp_paralj_keepalv_sec constant varchar2(100) := 'FastParallel.SplitSimSeries.Parallel.Job.KeepaliveSeconds';

  c_opt_fastp_post_retry_count   constant varchar2(100) := 'FastParallel.SplitSimSeries.Post.RetryCount';
  c_opt_fastp_post_retry_sec     constant varchar2(100) := 'FastParallel.SplitSimSeries.Post.RetryIntervalSeconds';
  c_opt_fastp_post_waitalljobs   constant varchar2(100) := 'FastParallel.SplitSimSeries.Post.WaitAllJobsCompletion';
  c_opt_fastp_post_sync_commit   constant varchar2(100) := 'FastParallel.SplitSimSeries.Post.SynchronousCommit';
  c_opt_fastp_post_slp_tm_sec    constant varchar2(100) := 'FastParallel.SplitSimSeries.Post.IdleSleepTimeSeconds';
  c_opt_fastp_post_exp_tmt_sec   constant varchar2(100) := 'FastParallel.SplitSimSeries.Post.ExpiredTimeoutSeconds';
  c_opt_fastp_post_wt_lck_sec    constant varchar2(100) := 'FastParallel.SplitSimSeries.Post.WaitLockSeconds';
  c_opt_fastp_postj_retry_count  constant varchar2(100) := 'FastParallel.SplitSimSeries.Post.Job.RetryCount';
  c_opt_fastp_postj_retry_sec    constant varchar2(100) := 'FastParallel.SplitSimSeries.Post.Job.RetryIntervalSeconds';
  c_opt_fastp_postj_slp_tm_sec   constant varchar2(100) := 'FastParallel.SplitSimSeries.Post.Job.IdleSleepTimeSeconds';
  c_opt_fastp_postj_exp_tmt_sec  constant varchar2(100) := 'FastParallel.SplitSimSeries.Post.Job.ExpiredTimeoutSeconds';
  c_opt_fastp_postj_wt_lck_sec   constant varchar2(100) := 'FastParallel.SplitSimSeries.Post.Job.WaitLockSeconds';
  c_opt_fastp_postj_keepalv_sec  constant varchar2(100) := 'FastParallel.SplitSimSeries.Post.Job.KeepaliveSeconds';

----------------------------------!---------------------------------------------
  c_def_sim_ser_split_paral_mode constant boolean := false;

  c_def_fastp_block_count        constant number := 1000;
  c_def_fastp_job_count          constant number := 10;

  c_def_fastp_flow_reversible    constant boolean := false;
  c_def_fastp_flow_retry_count   constant number := fast_parallel_pkg.c_retry_count_infinity;
  c_def_fastp_flow_retry_sec     constant number := 60;
  c_def_fastp_flow_wt_lck_sec    constant number := 10;

  c_def_fastp_pre_retry_count    constant number := fast_parallel_pkg.c_retry_count_no_retry; --!_!fast_parallel_pkg.c_retry_count_infinity
  c_def_fastp_pre_retry_sec      constant number := 60;
  c_def_fastp_pre_waitalljobs    constant boolean := true;
  c_def_fastp_pre_sync_commit    constant boolean := true;
  c_def_fastp_pre_slp_tm_sec     constant number := 1;
  c_def_fastp_pre_exp_tmt_sec    constant number := 600;
  c_def_fastp_pre_wt_lck_sec     constant number := 10;
  c_def_fastp_prej_retry_count   constant number := fast_parallel_pkg.c_retry_count_no_retry; --!_!fast_parallel_pkg.c_retry_count_infinity
  c_def_fastp_prej_retry_sec     constant number := 60;
  c_def_fastp_prej_slp_tm_sec    constant number := 1;
  c_def_fastp_prej_exp_tmt_sec   constant number := 600;
  c_def_fastp_prej_wt_lck_sec    constant number := 10;
  c_def_fastp_prej_keepalv_sec   constant number := 3;

  c_def_fastp_paral_retry_count  constant number := fast_parallel_pkg.c_retry_count_infinity;
  c_def_fastp_paral_retry_sec    constant number := 60;
  c_def_fastp_paral_waitalljobs  constant boolean := true;
  c_def_fastp_paral_sync_commit  constant boolean := true;
  c_def_fastp_paral_slp_tm_sec   constant number := 1;
  c_def_fastp_paral_exp_tmt_sec  constant number := 600;
  c_def_fastp_paral_wt_lck_sec   constant number := 10;
  c_def_fastp_paralj_retry_count constant number := fast_parallel_pkg.c_retry_count_infinity;
  c_def_fastp_paralj_retry_sec   constant number := 60;
  c_def_fastp_paralj_slp_tm_sec  constant number := 1;
  c_def_fastp_paralj_exp_tmt_sec constant number := 600;
  c_def_fastp_paralj_wt_lck_sec  constant number := 10;
  c_def_fastp_paralj_keepalv_sec constant number := 3;

  c_def_fastp_post_retry_count   constant number := fast_parallel_pkg.c_retry_count_infinity;
  c_def_fastp_post_retry_sec     constant number := 60;
  c_def_fastp_post_waitalljobs   constant boolean := true;
  c_def_fastp_post_sync_commit   constant boolean := true;
  c_def_fastp_post_slp_tm_sec    constant number := 1;
  c_def_fastp_post_exp_tmt_sec   constant number := 600;
  c_def_fastp_post_wt_lck_sec    constant number := 10;
  c_def_fastp_postj_retry_count  constant number := fast_parallel_pkg.c_retry_count_infinity;
  c_def_fastp_postj_retry_sec    constant number := 60;
  c_def_fastp_postj_slp_tm_sec   constant number := 1;
  c_def_fastp_postj_exp_tmt_sec  constant number := 600;
  c_def_fastp_postj_wt_lck_sec   constant number := 10;
  c_def_fastp_postj_keepalv_sec  constant number := 3;

----------------------------------!---------------------------------------------
  c_job_text_pre                 constant clob := q'{begin
  :p_this_package_name.job_action_pre
  (
    p_fastp_job_id => :p_qwerty_job_id,
    p_fastp_direction_forward => :p_qwerty_direction_forward
  );
end;
}'
  ;

  c_job_text_parallel            constant clob := q'{begin
  :p_this_package_name.job_action_parallel
  (
    p_fastp_job_id => :p_qwerty_job_id,
    p_fastp_direction_forward => :p_qwerty_direction_forward
  );
end;
}'
  ;

  c_job_text_post                constant clob := q'{begin
  :p_this_package_name.job_action_post
  (
    p_fastp_job_id => :p_qwerty_job_id,
    p_fastp_direction_forward => :p_qwerty_direction_forward
  );
end;
}'
  ;

----------------------------------!---------------------------------------------
  --!_!flow tasks
  c_task_index_pre               constant integer := 1;
  c_task_index_paral             constant integer := 2;
  c_task_index_post              constant integer := 3;

  --!_!task jobs
  c_job_single_index_pre         constant integer := 1;
  c_job_single_index_post        constant integer := 1;

  --!_!serialization items

  c_srzi_pre_skip_action         constant integer := 1;
  c_srzi_pre_item_split_from     constant integer := 2;
  c_srzi_pre_range               constant integer := 3;
  c_srzi_pre_block_count         constant integer := 4;
  c_srzi_pre_job_count           constant integer := 5;
  c_srzi_pre_user_id             constant integer := 6;
  c_srzi_count_pre               constant number := c_srzi_pre_user_id;

  type t_param_action_pre is record
  (
    skip_action boolean := false, --!_!really not used
    item_split_from varchar2(50),
    range range_pkg.t_range,
    block_count number,
    job_count number,
    user_id number
  );

  c_srzi_paral_skip_action       constant integer := 1;
  c_srzi_paral_item_from         constant integer := 2;
  c_srzi_paral_item_to           constant integer := 3;
  c_srzi_paral_range_id_old      constant integer := 4;
  c_srzi_paral_range_id_new      constant integer := 5;
  c_srzi_count_paral             constant number := c_srzi_paral_range_id_new;

  type t_param_action_parallel is record
  (
    skip_action boolean := false,
    item_from varchar2(50),
    item_to varchar2(50),
    range_id_old number,
    range_id_new number
  );

  c_srzi_post_skip_action        constant integer := 1;
  c_srzi_post_range2truncation   constant integer := 2;
  c_srzi_post_range2creation     constant integer := 3;
  c_srzi_post_locker_id          constant integer := 4;
  c_srzi_post_release_lckr_onerr constant integer := 5;
  c_srzi_post_user_id            constant integer := 6;
  c_srzi_count_post              constant number := c_srzi_post_user_id;

  type t_param_action_post is record
  (
    skip_action boolean := false, --!_!really not used
    range_to_truncation range_pkg.t_range,
    range_to_creation range_pkg.t_range,
    locker_id number,
    release_locker_on_error boolean,
    user_id number
  );

----------------------------------!---------------------------------------------
  function get_fast_parallel_params return fast_parallel_pkg.t_fast_parallel_params;

----------------------------------!---------------------------------------------
  function row2t_range(p_row sim_series%rowtype) return range_pkg.t_range;

  function t_range2row
  (
    p_range range_pkg.t_range,
    p_user_id number,
    p_date date,
    p_sim_card_type_code varchar2,
    p_host_id number,
    p_network_operator_id number
  )
  return sim_series%rowtype;

----------------------------------!---------------------------------------------
  procedure get_items_from_to
  (
    p_row sim_series%rowtype,
    p_item_from out varchar2,
    p_item_to out varchar2
  );

----------------------------------!---------------------------------------------
  procedure copy_ss_host
  (
    p_ss_id_src number,
    p_ss_id_dst number,
    p_user_id number,
    p_date date
  );

  procedure delete_ss_host
  (
    p_ss_id number,
    p_user_id number,
    p_date date
  );

  procedure copy_ss_status_validity
  (
    p_ss_id_src number,
    p_ss_id_dst number,
    p_user_id number,
    p_date date
  );

  procedure delete_ss_status_validity
  (
    p_ss_id number,
    p_user_id number,
    p_date date
  );

----------------------------------!---------------------------------------------
  function make_dummy_row(p_row_template sim_series%rowtype) return sim_series%rowtype;

  function create_dummy_range
  (
    p_row_template sim_series%rowtype,
    p_user_id number
  ) return number;

  procedure delete_dummy_range
  (
    p_range_id number,
    p_user_id number
  );

  procedure change_items_range_id
  (
    p_item_from varchar2,
    p_item_to varchar2,
    p_range_id_new number
  );

----------------------------------!---------------------------------------------
  procedure split_range_pre_forward
  (
    p_item_split_from varchar2,
    p_range range_pkg.t_range,
    p_block_count number,
    p_job_count number,
    p_user_id number,
    p_date date,
    p_range_to_trunc_item_froms out ct_varchar_s,
    p_range_to_trunc_item_tos out ct_varchar_s,
    p_range_to_truncation out range_pkg.t_range,
    p_range_to_creation out range_pkg.t_range,
    p_locker_id out number
  );

  procedure split_range_pre_backward
  (
    p_range_to_creation_id number,
    p_locker_id number,
    p_user_id number
  );

  procedure split_range_mid_forward
  (
    p_item_from varchar2,
    p_item_to varchar2,
    p_range_id_new number
  );

  procedure split_range_mid_backward
  (
    p_item_from varchar2,
    p_item_to varchar2,
    p_range_id_old number --!_!
  );

  procedure split_range_post_forward
  (
    p_range_to_truncation range_pkg.t_range,
    p_range_to_creation range_pkg.t_range,
    p_locker_id number,
    p_release_locker_on_error boolean,
    p_user_id number,
    p_date date
  );

  procedure split_range_post_backward
  (
    p_range_initial range_pkg.t_range,
    p_range_to_dummy_id number,
    p_range_to_truncation range_pkg.t_range,
    p_range_to_creation range_pkg.t_range,
    p_user_id number,
    p_date date,
    p_locker_id out number
  );

----------------------------------!---------------------------------------------
  function prm_pre_serialize(p_obj t_param_action_pre) return clob;
  function prm_pre_deserialize(p_str clob) return t_param_action_pre;

  function prm_paral_serialize(p_obj t_param_action_parallel) return clob;
  function prm_paral_deserialize(p_str clob) return t_param_action_parallel;

  function prm_post_serialize(p_obj t_param_action_post) return clob;
  function prm_post_deserialize(p_str clob) return t_param_action_post;

----------------------------------!---------------------------------------------
  function make_job_text(p_job_text_raw clob) return clob;

  function make_flow
  (
    p_flow_type_id number,
    p_user_id number,
    p_parallel_job_count number,
    p_task_pre_job_context clob
  ) return fast_parallel_pkg.t_flow;

----------------------------------!---------------------------------------------
  procedure get_target_ranges_by_blocks
  (
    p_item_boundary varchar2,
    p_item_from varchar2,
    p_item_to varchar2,
    p_block_count integer,
    p_max_target_range_count integer,
    p_ranges_approx_count out ct_number,
    p_ranges_from out ct_varchar_s,
    p_ranges_to out ct_varchar_s
  );

  procedure split_range_i
  (
    p_item_split_from varchar2,
    p_range range_pkg.t_range,
    p_block_count integer,
    p_job_count integer,
    p_range_to_creation_id number,
    p_range_to_trunc_item_froms out ct_varchar_s,
    p_range_to_trunc_item_tos out ct_varchar_s,
    p_range_to_truncation out range_pkg.t_range,
    p_range_to_creation out range_pkg.t_range
  );

----------------------------------!---------------------------------------------
  procedure split_range_parallel_i
  (
    p_range range_pkg.t_range,
    p_item_split_from varchar2,
    p_user_id number
  );

  procedure split_range_serial_i
  (
    p_range range_pkg.t_range,
    p_item_split_from varchar2,
    p_user_id number
  );

----------------------------------!---------------------------------------------
  procedure job_action_pre
  (
    p_fastp_job_id number,
    p_fastp_direction_forward boolean
  );

  procedure job_action_parallel
  (
    p_fastp_job_id number,
    p_fastp_direction_forward boolean
  );

  procedure job_action_post
  (
    p_fastp_job_id number,
    p_fastp_direction_forward boolean
  );

----------------------------------!---------------------------------------------
  procedure split_range
  (
    p_range range_pkg.t_range,
    p_item_split_from varchar2,
    p_user_id number
  );

  procedure split_range2
  (
    p_id number,
    p_item_split_from varchar2,
    p_user_id number
  );

----------------------------------!---------------------------------------------

end;
/
