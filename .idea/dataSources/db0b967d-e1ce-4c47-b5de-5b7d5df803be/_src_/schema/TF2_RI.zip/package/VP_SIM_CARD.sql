CREATE package VP_SIM_CARD is

----------------------------------!---------------------------------------------
  c_this_name                    constant varchar2(30) := 'SIM_CARD';

----------------------------------!---------------------------------------------
  function get1_i(p_id integer, p_date date, p_lock boolean, p_wait boolean, p_is_locked out boolean) return sim_card%rowtype;

  function get1(p_id integer, p_date date) return sim_card%rowtype;
  function xget1(p_id integer, p_date date) return sim_card%rowtype;
  function xlock_get1(p_id integer, p_date date) return sim_card%rowtype;
  function xlock_xget1(p_id integer, p_date date) return sim_card%rowtype;
  procedure xlock(p_id integer, p_date date);

----------------------------------!---------------------------------------------
  function find_i_id(p_rec sim_card%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_imsi(p_rec sim_card%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_iccid(p_rec sim_card%rowtype, p_check_only_other_ids boolean) return boolean;
  function find_i_msisdn_bound(p_rec sim_card%rowtype, p_check_only_other_ids boolean) return boolean;

  function find_i(p_rec sim_card%rowtype, p_check_only_other_ids boolean) return boolean;
  procedure xunique_i(p_rec sim_card%rowtype, p_check_only_other_ids boolean);

----------------------------------!---------------------------------------------
  procedure open_i(p_rec sim_card%rowtype);
  procedure change_i(p_rec sim_card%rowtype);

----------------------------------!---------------------------------------------
  function is_identified(p_rec sim_card%rowtype) return boolean;

----------------------------------!---------------------------------------------
  procedure version_open(p_rec in out nocopy sim_card%rowtype);
  procedure version_change(p_rec in out nocopy sim_card%rowtype, p_date_from_virt date := null);

  procedure version_close
  (
    p_id integer,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------
  procedure version_open2(p_rec in out nocopy sim_card%rowtype, p_addition_imsi ct_varchar_s);
  procedure version_change2(p_rec in out nocopy sim_card%rowtype, p_addition_imsi ct_varchar_s, p_date_from_virt date := null);

  procedure version_close2
  (
    p_id integer,
    p_user_id integer,
    p_date_from date := null
  );

----------------------------------!---------------------------------------------

end;
/
