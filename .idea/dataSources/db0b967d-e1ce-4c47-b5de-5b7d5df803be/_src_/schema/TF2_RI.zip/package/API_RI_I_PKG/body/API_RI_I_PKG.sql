CREATE package body API_RI_I_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_salability_cat_rules
(
  p_result out sys_refcursor
)
is
  v_date date := sysdate;
begin
  ------------------------------
  open p_result for
select /*+ ordered driving_site(z2) use_hash(z1 z2) full(z1) full(z2)*/
  z1.phone_salability_category_code salability_category_code,
  z1.attractiveness_level, z2.mask
  from phone_salability_category z1, salability_category_mask z2
  where 1 = 1
  and z2.salability_category_code(+) = z1.phone_salability_category_code
  and nvl(z1.deleted, v_date + util_ri.c_dummy_date_shift) > v_date
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_phone_number_decomposition
(
  p_msisdns ct_varchar_s,
  p_country_code out ct_varchar_s,
  p_area_code out ct_varchar_s,
  p_local_phone out ct_varchar_s,
  p_error_code out ct_number,
  p_error_message out ct_varchar
)
is
  v_main_count number;
  v_date date := sysdate;
  v_pns_ids ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  ------------------------------
  v_pns_ids := util_ri.det_pns_id4msisdn(p_msisdns, v_date, FALSE);
  ------------------------------
  select /*+ ordered use_hash(q2) use_nl(z) full(q1) full(q2) index(z PK_PHONE_NUMBER_SERIES)*/
      z.country_code,
      z.area_code,
      decode(z.phone_number_series_id, null, null, substr(q1.msisdn, 1 + length(z.country_code) + length(z.area_code))) local_phone,
      decode(z.phone_number_series_id, null, util_loc_pkg.c_ora_phone_serie_not_found, util_pkg.c_ora_ok) error_code,
      decode(z.phone_number_series_id, null, util_loc_pkg.c_msg_phone_serie_not_found, util_pkg.c_msg_ok) error_message
    bulk collect into p_country_code, p_area_code, p_local_phone, p_error_code, p_error_message
    from
      (select column_value msisdn, rownum rn from table(p_msisdns)) q1,
      (select column_value phone_number_series_id, rownum rn from table(v_pns_ids)) q2,
      phone_number_series z
    where 1 = 1
    and q2.rn(+) = q1.rn
    and z.phone_number_series_id(+) = q2.phone_number_series_id
    order by q1.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure GetSimCardStatusHistChanges
(
  p_iccid varchar2,
  p_result out sys_refcursor
)
is
  v_ap_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_iccid is null, 'p_iccid');
  ------------------------------
  v_ap_ids := util_ri.qwerty_get_ap_id2_all(p_iccid);
  ------------------------------
  open p_result for
  select /*+ driving_site(q) ordered use_nl(apsh) use_hash(aps) index_asc(apsh, I_ACCPOSTAHI_ACCESS_POINT_ID) full(aps)*/
         aps.access_point_status_code status_code,
         aps.access_point_status_name status_name,
         apsh.start_date date_from,
         apsh.end_date date_to
    from (select column_value ap_id, rownum rn from table(v_ap_ids)) q,
         access_point_status_history apsh,
         access_point_status aps
   where 1 = 1
         and apsh.access_point_id = q.ap_id
         and util_ri.valid_code2(aps.access_point_status_code) = util_ri.valid_code2(apsh.access_point_status_code)
   order by apsh.start_date desc
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure create_msisdn_by_number_for_ps
(
  p_msisdns ct_varchar_s,
  p_date date,
  p_date_reserved date,
  p_user_id number,
  p_break_on_error boolean,
  p_reserve_number out number,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  --
  v_main_count number;
  v_pivot ct_number;
  v_marks ct_number;
  --
  v_na_ids ct_number;
  --
  v_bool boolean;
  --
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  --
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FSU_ct_varchar_s(p_msisdns, 'p_msisdns');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  p_reserve_number := null;
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  ------------------------------
  mnp_pkg.prepare_phones2port_in_i
  (
    p_msisdns => p_msisdns,
    p_phone_status => util_ri.c_NASH_CODE_FREE,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_out_na_ids => v_na_ids,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes, v_pivot);
  util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages, v_pivot);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
  ------------------------------
  ------------------------------
  if p_date_reserved is null
  then
    ------------------------------
    RETURN;
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_error_codes, util_pkg.c_ora_ok);
  v_pivot := util_coll_pkg.get_marked_ol_ct_number(v_pivot, v_marks);
  ------------------------------
  if util_pkg.get_count_ct_number(v_pivot) > 0
  then
    ------------------------------
    v_na_ids := util_coll_pkg.get_by_pos_ol_ct_number(v_na_ids, v_pivot);
    ------------------------------
    v_bool := reservation_pkg.reserve_na_on_period_i
    (
      p_na_id => v_na_ids,
      p_date_reserved => p_date_reserved,
      p_user_id => p_user_id,
      p_reserve_number => p_reserve_number,
      p_error_code => v_error_codes,
      p_error_message => v_error_messages
    );
    ------------------------------
    util_loc_pkg.touch_boolean(v_bool);
    ------------------------------
    util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes, v_pivot);
    util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages, v_pivot);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_codes, p_error_messages);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure open_network_operator_srvc
(
  p_no_ids ct_number,
  p_svc_codes ct_varchar_s,
  p_date_from ct_date,
  p_date_to ct_date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_rec network_operator_srvc%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_no_ids, 'p_no_ids');
  util_pkg.XCheckP_FS_ct_varchar_s(p_svc_codes, 'p_svc_codes');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_no_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_no_ids) != v_main_count, 'p_no_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_svc_codes) != v_main_count, 'p_svc_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date_from) != v_main_count, 'p_date_from.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date_to) != v_main_count, 'p_date_to.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    begin
      ------------------------------
      v_rec := NULL;
      ------------------------------
      v_rec.network_operator_id := p_no_ids(v_i);
      v_rec.service_code := p_svc_codes(v_i);
      v_rec.date_from := p_date_from(v_i);
      v_rec.date_to := p_date_to(v_i);
      v_rec.user_id_of_change := p_user_id;
      ------------------------------
      vp_network_operator_srvc.version_open(v_rec);
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message2(p_no_ids(v_i), p_svc_codes(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure close_network_operator_srvc
(
  p_no_ids ct_number,
  p_svc_codes ct_varchar_s,
  p_old_date_from ct_date,
  p_old_date_to ct_date,
  p_date_from ct_date,
  p_user_id number,
  p_break_on_error boolean,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_rec network_operator_srvc%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_no_ids, 'p_no_ids');
  util_pkg.XCheckP_FS_ct_varchar_s(p_svc_codes, 'p_svc_codes');
  util_pkg.XCheckP_FS_ct_date(p_old_date_from, 'p_old_date_from');
  util_pkg.XCheckP_FS_ct_date(p_old_date_to, 'p_old_date_to');
  --!_!util_pkg.XCheckP_FS_ct_date(p_date_from, 'p_date_from');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_no_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_no_ids) != v_main_count, 'p_no_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_svc_codes) != v_main_count, 'p_svc_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_old_date_from) != v_main_count, 'p_old_date_from.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_old_date_to) != v_main_count, 'p_old_date_to.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date_from) != v_main_count, 'p_date_from.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    begin
      ------------------------------
      v_rec := vp_network_operator_srvc.xlock_get1(p_no_ids(v_i), p_svc_codes(v_i), p_old_date_from(v_i));
      ------------------------------
      if v_rec.network_operator_id is null
      then
        util_pkg.Raise_Obj2_NotFound_OnDate3(p_no_ids(v_i), p_svc_codes(v_i), p_old_date_from(v_i));
      end if;
      ------------------------------
      if p_old_date_from(v_i) <> v_rec.date_from or p_old_date_to(v_i) <> v_rec.date_to
      then
        util_pkg.Raise_Obj2_NotFound_Vers3(p_no_ids(v_i), p_svc_codes(v_i), p_old_date_from(v_i), p_old_date_to(v_i));
      end if;
      ------------------------------
      util_pkg.XCheck_Cond_Invalid(p_date_from(v_i) is not null and not(util_pkg.date_from2date_to_prev(p_date_from(v_i)) between v_rec.date_from and v_rec.date_to), 'p_date_from');
      ------------------------------
      vp_network_operator_srvc.version_close(p_no_ids(v_i), p_svc_codes(v_i), p_user_id, p_date_from(v_i));
      ------------------------------
    exception
    when others then
      ------------------------------
      util_pkg.set_error(p_error_codes(v_i), p_error_messages(v_i));
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, util_ext_ri.make_group_error_message2(p_no_ids(v_i), p_svc_codes(v_i), v_i, p_error_codes(v_i), p_error_messages(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end;
    ------------------------------
  end loop;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_network_operator_srvc
(
  p_no_id integer,
  p_date date,
  p_no_date boolean,
  p_result out sys_refcursor
)
is
  v_sysdate date := sysdate;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_no_id is null, 'p_no_id');
  util_pkg.XCheck_Cond_Missing(p_no_date is null, 'p_no_date');
  ------------------------------
  if p_no_date
  then
    ------------------------------
    open p_result for
    select /*+ ordered use_nl(u) index_asc(z, I_NETWORK_OPERATOR_SRVC_NO_SRV) index(u PK_USERS)*/
        z.*,
        u.user_name
      from network_operator_srvc z, users u
      where 1 = 1
      and z.network_operator_id = p_no_id
      and u.user_id(+) = z.user_id_of_change
      order by z.network_operator_id, z.service_code, z.date_from
      ;
    ------------------------------
  else
    ------------------------------
    open p_result for
    select /*+ ordered use_nl(u) index_asc(z, I_NETWORK_OPERATOR_SRVC_NO_SRV) index(u PK_USERS)*/
        z.*,
        u.user_name
      from network_operator_srvc z, users u
      where 1 = 1
      and z.network_operator_id = p_no_id
      and nvl(p_date, v_sysdate) between z.date_from and z.date_to
      and u.user_id(+) = z.user_id_of_change
      order by z.network_operator_id, z.service_code, z.date_from
      ;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_uprs_member_code_by_phone
(
  p_msisdn varchar2,
  p_validity_date date,
  p_uprs_member_code out varchar2,
  p_net_operator_name out varchar2,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_validity_date date;
  v_na_id number;
  v_na_status varchar2(50);
  v_no_id number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn is null, 'p_msisdn');
  --util_pkg.XCheck_Cond_Missing(p_validity_date is null, 'p_validity_date');
  ------------------------------
  v_validity_date := nvl(p_validity_date, sysdate);
  ------------------------------
  v_na_id := util_ri.get_na_id2(p_msisdn, v_validity_date);
  ------------------------------
  if v_na_id is null
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found);
  end if;
  ------------------------------
  v_na_status := util_ri.get_na_status2(v_na_id, v_validity_date);
  ------------------------------
  if v_na_status = util_ri.c_NASH_CODE_OTHER
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_na_status_other_billing, util_loc_pkg.c_msg_na_status_other_billing);
  end if;
  ------------------------------
  v_no_id := mnp_pkg.get_no_current_any2(p_na_id => v_na_id, p_date => v_validity_date);
  ------------------------------
  if v_no_id is null
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_net_op_not_found, util_loc_pkg.c_msg_net_op_not_found);
  end if;
  ------------------------------
  p_net_operator_name := util_ri.get_network_operator_name2(v_no_id, v_validity_date);
  p_uprs_member_code := util_ri.get_network_operator_uprsc2(v_no_id, v_validity_date);
  ------------------------------
  if p_uprs_member_code is null
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_uprs_code_not_set, util_loc_pkg.c_msg_uprs_code_not_set);
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure prod_check_sim_list_i
(
  p_host_id number,
  p_net_op_id number,
  p_iccid_without_control_digit ct_varchar_s,
  p_iccid out ct_varchar_s,
  p_imsi out ct_varchar_s,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_main_count number;
  v_date date := sysdate;
  v_ap_id ct_number;
  v_host_id ct_number;
  v_no_id ct_number;
  v_status ct_varchar_s;
  v_na_id ct_number;
  --
  v_pivot ct_number;
  v_mark_err ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_iccid_without_control_digit);
  ------------------------------
  if v_main_count = 0
  then
    return;
  end if;
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_ap_id := util_ri.get_ap_id5(p_iccid_without_control_digit, v_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_ap_id, null, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_sim_card_not_found, util_loc_pkg.c_msg_sim_card_not_found, util_pkg.c_true, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_host_id := util_ri.get_ap_host_id(v_ap_id, v_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_host_id, p_host_id, util_pkg.c_false, util_pkg.c_true);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_wrong_host, util_loc_pkg.c_msg_wrong_host, util_pkg.c_true, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_no_id := util_ri.get_ap_no_id(v_ap_id, v_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_no_id, p_net_op_id, util_pkg.c_false, util_pkg.c_true);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_wrong_no, util_loc_pkg.c_msg_wrong_no, util_pkg.c_true, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_status := util_ri.get_ap_status(v_ap_id, v_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_varchar_s(v_status, util_ri.c_apsh_code_not_activated, util_pkg.c_false, util_pkg.c_true);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_wrong_ap_status, util_loc_pkg.c_msg_wrong_ap_status, util_pkg.c_true, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_na_id := util_ri.get_linked_na_id_main(v_ap_id, v_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_na_id, null, util_pkg.c_false, util_pkg.c_true);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_already_linked, util_loc_pkg.c_msg_already_linked, util_pkg.c_true, p_error_codes, p_error_messages);
  --v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, TRUE, util_pkg.c_false, NULL);
  ------------------------------
  util_ri.get_iccid_imsi(v_ap_id, v_date, FALSE, p_iccid, p_imsi);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure create_sim_cards_on_host
(
  p_host_id number,
  p_iccid ct_varchar_s,
  p_pin ct_varchar_s,
  p_pin2 ct_varchar_s,
  p_puk ct_varchar_s,
  p_puk2 ct_varchar_s,
  p_ki ct_nvarchar_s,
  p_auth_type ct_varchar_s,
  p_sim_card_type_code varchar2,
  p_user_id number,
  p_date date,
  p_imsi out ct_varchar_s,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_main_count number;
  v_pivot ct_number;
  v_mark_err ct_number;
  v_mark_exists ct_number;
  v_pos ct_number;
  v_count number;
  v_ap_id ct_number;
  v_ap_id2 ct_number;
  v_ap_id3 ct_number;
  v_imsi ct_varchar_s;
  v_imsi2 ct_varchar_s;
  v_ss_id ct_number;
  v_ss_id2 ct_number;
  v_iccid ct_varchar_s;
  v_pin ct_varchar_s;
  v_pin2 ct_varchar_s;
  v_puk ct_varchar_s;
  v_puk2 ct_varchar_s;
  v_msisdn_bound ct_varchar_s;
  v_personal_account ct_number;
  v_ki ct_nvarchar_s;
  v_adm1 ct_nvarchar_s;
  v_access_control ct_nvarchar_s;
  v_auth_type ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  v_res boolean;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  util_pkg.XCheckP_FSU_ct_varchar_s(p_iccid, 'p_iccid');
  util_pkg.XCheckP_FS_ct_varchar_s(p_pin, 'p_pin');
  util_pkg.XCheckP_FS_ct_varchar_s(p_pin2, 'p_pin2');
  util_pkg.XCheckP_FS_ct_varchar_s(p_puk, 'p_puk');
  util_pkg.XCheckP_FS_ct_varchar_s(p_puk2, 'p_puk2');
  --!_!util_pkg.XCheckP_FS_ct_nvarchar_s(p_ki, 'p_ki');
  --!_!util_pkg.XCheckP_FS_ct_varchar_s(p_auth_type, 'p_auth_type');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  --!_!util_pkg.XCheck_Cond_Missing(p_sim_card_type_code is null, 'p_sim_card_type_code');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_iccid);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_iccid) != v_main_count, 'p_iccid.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_pin) != v_main_count, 'p_pin.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_pin2) != v_main_count, 'p_pin2.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_puk) != v_main_count, 'p_puk.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_puk2) != v_main_count, 'p_puk2.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_ki) != v_main_count, 'p_ki.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_auth_type) != v_main_count, 'p_auth_type.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  p_imsi := util_pkg.make_ct_varchar_s(v_main_count, null);
  ------------------------------
  util_ext_ri.find_available_imsi_on_host(p_sim_card_type_code, p_host_id, v_main_count, p_date, v_imsi, v_ss_id);
  ------------------------------
  if util_pkg.get_count_ct_varchar_s(v_imsi) < v_main_count
  then
    util_pkg.resize_ct_varchar_s(v_imsi, v_main_count);
  end if;
  ------------------------------
  v_mark_err := util_pkg.mark_val_ct_varchar_s(v_imsi, null, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_sim_card_not_found, util_loc_pkg.c_msg_sim_card_not_found, util_pkg.c_true, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_ap_id := util_ri.get_ap_id3(v_imsi, p_date, FALSE);
  ------------------------------
  v_mark_exists := util_pkg.mark_val_ct_number(v_ap_id, null, util_pkg.c_false, util_pkg.c_true);
  ------------------------------
  v_pos := util_pkg.get_marked_ct_number(v_pivot, v_mark_exists, TRUE, util_pkg.c_true);
  v_count := util_pkg.get_count_ct_number(v_pos);
  ------------------------------
  if v_count > 0
  then
    ------------------------------
    v_imsi2 := util_pkg.get_by_pos_ct_varchar_s(v_imsi, v_pos, FALSE);
    v_ap_id2 := util_pkg.get_by_pos_ct_number(v_ap_id, v_pos, FALSE);
    v_iccid := util_pkg.get_by_pos_ct_varchar_s(p_iccid, v_pos, FALSE);
    v_pin := util_pkg.get_by_pos_ct_varchar_s(p_pin, v_pos, FALSE);
    v_pin2 := util_pkg.get_by_pos_ct_varchar_s(p_pin2, v_pos, FALSE);
    v_puk := util_pkg.get_by_pos_ct_varchar_s(p_puk, v_pos, FALSE);
    v_puk2 := util_pkg.get_by_pos_ct_varchar_s(p_puk2, v_pos, FALSE);
    v_msisdn_bound := util_pkg.make_ct_varchar_s(v_count, null);
    v_ki := util_pkg.get_by_pos_ct_nvarchar_s(p_ki, v_pos, FALSE);
    v_adm1 := util_pkg.make_ct_nvarchar_s(v_count, null);
    v_access_control := util_pkg.make_ct_nvarchar_s(v_count, null);
    v_auth_type := util_pkg.get_by_pos_ct_varchar_s(p_auth_type, v_pos, FALSE);
    ------------------------------
    v_res := util_ext_ri.set_ap_params2
    (
      p_ap_id => v_ap_id2,
      p_sn => v_iccid,
      p_pin => v_pin,
      p_pin2 => v_pin2,
      p_puk2 => v_puk2,
      p_puk => v_puk,
      p_msisdn_bound => v_msisdn_bound,
      p_ki => v_ki,
      p_adm1 => v_adm1,
      p_access_control => v_access_control,
      p_authent_type => v_auth_type,
      p_date => p_date,
      p_user_id => p_user_id,
      p_break_on_error => FALSE,
      p_lock_sc => TRUE,
      p_error_code => v_error_codes,
      p_error_message => v_error_messages
    );
    ------------------------------
    util_loc_pkg.touch_boolean(v_res);
    ------------------------------
    util_pkg.set_by_pos_ct_varchar_s(p_imsi, v_imsi2, v_pos);
    util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes, v_pos);
    util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages, v_pos);
    ------------------------------
  end if;
  ------------------------------
  v_pos := util_pkg.get_marked_ct_number(v_pivot, v_mark_exists, TRUE, util_pkg.c_false);
  v_count := util_pkg.get_count_ct_number(v_pos);
  ------------------------------
  if v_count > 0
  then
    ------------------------------
    v_imsi2 := util_pkg.get_by_pos_ct_varchar_s(v_imsi, v_pos, FALSE);
    v_ss_id2 := util_pkg.get_by_pos_ct_number(v_ss_id, v_pos, FALSE);
    v_iccid := util_pkg.get_by_pos_ct_varchar_s(p_iccid, v_pos, FALSE);
    v_pin := util_pkg.get_by_pos_ct_varchar_s(p_pin, v_pos, FALSE);
    v_pin2 := util_pkg.get_by_pos_ct_varchar_s(p_pin2, v_pos, FALSE);
    v_puk := util_pkg.get_by_pos_ct_varchar_s(p_puk, v_pos, FALSE);
    v_puk2 := util_pkg.get_by_pos_ct_varchar_s(p_puk2, v_pos, FALSE);
    v_msisdn_bound := util_pkg.make_ct_varchar_s(v_count, null);
    v_personal_account  := util_pkg.make_ct_number(v_count, null);
    v_ki := util_pkg.get_by_pos_ct_nvarchar_s(p_ki, v_pos, FALSE);
    v_adm1 := util_pkg.make_ct_nvarchar_s(v_count, null);
    v_access_control := util_pkg.make_ct_nvarchar_s(v_count, null);
    v_auth_type := util_pkg.get_by_pos_ct_varchar_s(p_auth_type, v_pos, FALSE);
  ------------------------------
    v_res := util_ext_ri.ins_sim2
    (
      p_imsi => v_imsi2,
      p_sn => v_iccid,
      p_pin => v_pin,
      p_pin2 => v_pin2,
      p_puk2 => v_puk2,
      p_puk => v_puk,
      p_ss_id => v_ss_id2,
      p_msisdn_bound => v_msisdn_bound,
      p_personal_account => v_personal_account,
      p_ki => v_ki,
      p_adm1 => v_adm1,
      p_access_control => v_access_control,
      p_authent_type => v_auth_type,
      p_main_imsi_index => null,
      p_addition_imsi => null,
      p_status => util_ri.c_APSH_CODE_NOT_ACTIVATED,
      p_date => p_date,
      p_user_id => p_user_id,
      p_break_on_error => FALSE,
      p_ap_ids => v_ap_id3,
      p_error_code => v_error_codes,
      p_error_message => v_error_messages
    );
    ------------------------------
    util_loc_pkg.touch_boolean(v_res);
    ------------------------------
    util_pkg.set_by_pos_ct_varchar_s(p_imsi, v_imsi2, v_pos);
    util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes, v_pos);
    util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages, v_pos);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure create_sim_cards
(
  p_msisdn_list ct_varchar_s,
  p_iccid_list ct_varchar_s,
  p_pin_list ct_varchar_s,
  p_pin2_list ct_varchar_s,
  p_puk_list ct_varchar_s,
  p_puk2_list ct_varchar_s,
  p_ki_list ct_nvarchar_s,
  p_auth_type_list ct_varchar_s,
  p_sim_card_type_code varchar2,
  p_user_id number,
  p_imsi out ct_varchar_s,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_main_count number;
  v_count number;
  v_pivot ct_number;
  v_pivot2 ct_number;
  v_mark_err ct_number;
  v_date date := sysdate;
  --
  v_na_id ct_number;
  v_host_id ct_number;
  v_host_id2 ct_number;
  
  v_uniq_host_id ct_number;
  v_mark ct_number;
  v_count2 number;
  v_pos ct_number;
  v_iccid ct_varchar_s;
  v_pin ct_varchar_s;
  v_pin2 ct_varchar_s;
  v_puk ct_varchar_s;
  v_puk2 ct_varchar_s;
  v_ki ct_nvarchar_s;
  v_auth_type ct_varchar_s;
  v_imsi ct_varchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_varchar_s(p_msisdn_list, 'p_msisdn_list');
  util_pkg.XCheckP_FSU_ct_varchar_s(p_iccid_list, 'p_iccid_list');
  util_pkg.XCheckP_FS_ct_varchar_s(p_pin_list, 'p_pin_list');
  util_pkg.XCheckP_FS_ct_varchar_s(p_pin2_list, 'p_pin2_list');
  util_pkg.XCheckP_FS_ct_varchar_s(p_puk_list, 'p_puk_list');
  util_pkg.XCheckP_FS_ct_varchar_s(p_puk2_list, 'p_puk2_list');
  --!_!util_pkg.XCheckP_FS_ct_nvarchar_s(p_ki_list, 'p_ki_list');
  --!_!util_pkg.XCheckP_FS_ct_varchar_s(p_auth_type_list, 'p_auth_type_list');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_sim_card_type_code is null, 'p_sim_card_type_code');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdn_list);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdn_list) != v_main_count, 'p_msisdn_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_iccid_list) != v_main_count, 'p_iccid_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_pin_list) != v_main_count, 'p_pin_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_pin2_list) != v_main_count, 'p_pin2_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_puk_list) != v_main_count, 'p_puk_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_puk2_list) != v_main_count, 'p_puk2_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_ki_list) != v_main_count, 'p_ki_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_auth_type_list) != v_main_count, 'p_auth_type_list.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  p_imsi := util_pkg.make_ct_varchar_s(v_main_count, null);
  ------------------------------
  v_na_id := util_ri.get_na_id(p_msisdn_list, v_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_na_id, null, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found, util_pkg.c_true, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_host_id := util_ri.get_na_host_id(v_na_id, v_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_host_id, null, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_host_not_found, util_loc_pkg.c_msg_host_not_found, util_pkg.c_true, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_pivot2 := util_pkg.filter_val_ct_number_1val(v_pivot, null, FALSE);
  v_count := util_pkg.get_count_ct_number(v_pivot2);
  if v_count > 0
  then
    ------------------------------
    v_host_id2 := util_pkg.get_by_pos_ct_number(v_host_id, v_pivot2, FALSE);
    ------------------------------
    v_uniq_host_id := util_pkg.unique_ct_number(v_host_id2, TRUE, TRUE);
    ------------------------------
    v_count2 := util_pkg.get_count_ct_number(v_uniq_host_id);
    ------------------------------
    for v_i in 1..v_count2
    loop
      ------------------------------
      v_mark := util_pkg.mark_val_ct_number(v_host_id2, v_uniq_host_id(v_i), util_pkg.c_true, util_pkg.c_false);
      ------------------------------
      v_pos := util_pkg.get_marked_ct_number(v_pivot2, v_mark, TRUE, util_pkg.c_true);
      ------------------------------
      v_iccid := util_pkg.get_by_pos_ct_varchar_s(p_iccid_list, v_pos, FALSE);
      v_pin := util_pkg.get_by_pos_ct_varchar_s(p_pin_list, v_pos, FALSE);
      v_pin2 := util_pkg.get_by_pos_ct_varchar_s(p_pin2_list, v_pos, FALSE);
      v_puk := util_pkg.get_by_pos_ct_varchar_s(p_puk_list, v_pos, FALSE);
      v_puk2 := util_pkg.get_by_pos_ct_varchar_s(p_puk2_list, v_pos, FALSE);
      v_ki := util_pkg.get_by_pos_ct_nvarchar_s(p_ki_list, v_pos, FALSE);
      v_auth_type := util_pkg.get_by_pos_ct_varchar_s(p_auth_type_list, v_pos, FALSE);
      ------------------------------
      create_sim_cards_on_host
      (
        p_host_id => v_uniq_host_id(v_i),
        p_iccid => v_iccid,
        p_pin => v_pin,
        p_pin2 => v_pin2,
        p_puk => v_puk,
        p_puk2 => v_puk2,
        p_ki => v_ki,
        p_auth_type => v_auth_type,
        p_sim_card_type_code => p_sim_card_type_code,
        p_user_id => p_user_id,
        p_date => v_date,
        p_imsi => v_imsi,
        p_error_codes => v_error_codes,
        p_error_messages => v_error_messages
      );
      ------------------------------
      util_pkg.set_by_pos_ct_varchar_s(p_imsi, v_imsi, v_pos);
      util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes, v_pos);
      util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages, v_pos);
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure cancel_param_sim_cards
(
  p_iccid_list ct_varchar_s,
  p_user_id number,
  p_error_codes out ct_number,
  p_error_messages out ct_varchar
)
is
  v_main_count number;
  v_count number;
  v_pivot ct_number;
  v_pivot2 ct_number;
  v_mark_err ct_number;
  v_date date := sysdate;
  --
  v_ap_ids ct_number;
  v_ap_statuses ct_varchar_s;
  --
  v_ap_ids2 ct_number;
  v_sn ct_varchar_s;
  v_pin ct_varchar_s;
  v_pin2 ct_varchar_s;
  v_puk2 ct_varchar_s;
  v_puk ct_varchar_s;
  v_msisdn_bound ct_varchar_s;
  v_ki ct_nvarchar_s;
  v_adm1 ct_nvarchar_s;
  v_access_control ct_nvarchar_s;
  v_authent_type ct_varchar_s;
  --
  v_res boolean;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_varchar_s(p_iccid_list, 'p_iccid_list');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_iccid_list);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_iccid_list) != v_main_count, 'p_iccid_list.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  v_ap_ids := util_ri.get_ap_id(p_iccid_list, v_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_ap_ids, null, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_sim_card_not_found, util_loc_pkg.c_msg_sim_card_not_found, util_pkg.c_true, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_ap_statuses := util_ri.get_ap_status(v_ap_ids, v_date, FALSE);
  v_mark_err := util_pkg.mark_val_ct_varchar_s(v_ap_statuses, util_ri.c_APSH_CODE_NOT_ACTIVATED, util_pkg.c_false, util_pkg.c_true);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_wrong_ap_status, util_loc_pkg.c_msg_wrong_ap_status, util_pkg.c_true, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_pivot2 := util_pkg.filter_val_ct_number_1val(v_pivot, null, FALSE);
  v_count := util_pkg.get_count_ct_number(v_pivot2);
  if v_count > 0
  then
    ------------------------------
    v_ap_ids2 := util_pkg.get_by_pos_ct_number(v_ap_ids, v_pivot2, FALSE);
    v_sn := util_pkg.make_ct_varchar_s(v_count, null);
    v_pin := util_pkg.make_ct_varchar_s(v_count, null);
    v_pin2 := util_pkg.make_ct_varchar_s(v_count, null);
    v_puk2 := util_pkg.make_ct_varchar_s(v_count, null);
    v_puk := util_pkg.make_ct_varchar_s(v_count, null);
    v_msisdn_bound := util_pkg.make_ct_varchar_s(v_count, null);
    v_ki := util_pkg.make_ct_nvarchar_s(v_count, null);
    v_adm1 := util_pkg.make_ct_nvarchar_s(v_count, null);
    v_access_control := util_pkg.make_ct_nvarchar_s(v_count, null);
    v_authent_type := util_pkg.make_ct_varchar_s(v_count, null);
    ------------------------------
    v_res := util_ext_ri.set_ap_params2
    (
      p_ap_id => v_ap_ids2,
      p_sn => v_sn,
      p_pin => v_pin,
      p_pin2 => v_pin2,
      p_puk2 => v_puk2,
      p_puk => v_puk,
      p_msisdn_bound => v_msisdn_bound,
      p_ki => v_ki,
      p_adm1 => v_adm1,
      p_access_control => v_access_control,
      p_authent_type => v_authent_type,
      p_date => v_date,
      p_user_id => p_user_id,
      p_break_on_error => FALSE,
      p_lock_sc => TRUE,
      p_error_code => v_error_codes,
      p_error_message => v_error_messages
    );
    ------------------------------
    if not v_res
    then
      util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes, v_pivot2);
      util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages, v_pivot2);
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_series_cont_free_phones
(
  p_host_id ct_number,
  p_host_empty boolean,
  p_network_operator_id number,
  p_phone_number_type varchar2,
  p_salability_category ct_varchar_s,
  p_phone_number_status_code ct_varchar_s,
  p_use_linked number,
  p_ps_id out ct_number,
  p_pn_count out ct_number
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_host_empty is null, 'p_host_empty');
  util_pkg.XCheck_Cond_Missing(p_network_operator_id is null, 'p_network_operator_id');
  util_pkg.XCheck_Cond_Missing(p_phone_number_type is null, 'p_phone_number_type');
  util_pkg.XCheckP_FS_ct_varchar_s(p_salability_category, 'p_salability_category');
  util_pkg.XCheckP_FS_ct_varchar_s(p_phone_number_status_code, 'p_phone_number_status_code');
  ------------------------------
  search_pkg.get_free_phone_count_i
  (
    p_host_id => p_host_id,
    p_host_empty => p_host_empty,
    p_network_operator_id => p_network_operator_id,
    p_phone_type => p_phone_number_type,
    p_salability_category => p_salability_category,
    p_series_id => null,
    p_mask => '%',
    p_use_linked => p_use_linked,
    p_phone_number_status_code => p_phone_number_status_code,
    p_ps_id => p_ps_id,
    p_pn_count => p_pn_count
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_series_cont_free_phones2
(
  p_host_id ct_number,
  p_host_empty boolean,
  p_network_operator_code varchar2,
  p_phone_number_type varchar2,
  p_salability_category ct_varchar_s,
  p_phone_number_status_code ct_varchar_s,
  p_use_linked number,
  p_ps_id out ct_number,
  p_pn_count out ct_number
)
is
  v_date date := sysdate;
  v_network_operator_id number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_host_empty is null, 'p_host_empty');
  util_pkg.XCheck_Cond_Missing(p_network_operator_code is null, 'p_network_operator_code');
  util_pkg.XCheck_Cond_Missing(p_phone_number_type is null, 'p_phone_number_type');
  util_pkg.XCheckP_FS_ct_varchar_s(p_salability_category, 'p_salability_category');
  util_pkg.XCheckP_FS_ct_varchar_s(p_phone_number_status_code, 'p_phone_number_status_code');
  ------------------------------
  v_network_operator_id := util_ri.get_network_operator_id2(p_network_operator_code, v_date);
  util_pkg.XCheck_Cond_Invalid(v_network_operator_id is null, 'p_network_operator_code');
  ------------------------------
  get_series_cont_free_phones
  (
    p_host_id => p_host_id,
    p_host_empty => p_host_empty,
    p_network_operator_id => v_network_operator_id,
    p_phone_number_type => p_phone_number_type,
    p_salability_category => p_salability_category,
    p_phone_number_status_code => p_phone_number_status_code,
    p_use_linked => p_use_linked,
    p_ps_id => p_ps_id,
    p_pn_count => p_pn_count
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_ap_host_smart
(
  p_ap_ids ct_number,
  p_host_type_code varchar2,
  p_date date,
  p_get_subhosts boolean,
  p_host_ids out ct_number,
  p_subhost_ids out ct_number
)
is
  v_ss_ids ct_number;
  v_host_ids_ss ct_number;
  v_host_ids_ssh ct_number;
  v_host_ids_aph ct_number;
  v_host_ids_ap ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_ap_ids);
  util_pkg.XCheck_Cond_Missing(p_host_type_code is null, 'p_host_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_get_subhosts is null, 'p_get_subhosts');
  ------------------------------
  v_ss_ids := util_ri.get_ap_ss_id(p_ap_id => p_ap_ids, p_date => p_date, p_trim_empty => false);
  ------------------------------
  v_host_ids_ss := util_ri.get_ss_host_id(p_ss_id => v_ss_ids, p_date => p_date, p_trim_empty => false);
  v_host_ids_ssh := util_ri.get_own_ss_host_id(p_ss_id => v_ss_ids, p_host_type_code => p_host_type_code, p_date => p_date, p_trim_empty => false);
  v_host_ids_aph := util_ri.get_own_ap_host_id(p_ap_id => p_ap_ids, p_host_type_code => p_host_type_code, p_date => p_date, p_trim_empty => false);
  ------------------------------
  v_host_ids_ap := util_pkg.supplement_ct_number(p_vals => v_host_ids_aph, p_supplement => v_host_ids_ssh, p_trim_empty => false);
  v_host_ids_ap := util_pkg.supplement_ct_number(p_vals => v_host_ids_ap, p_supplement => v_host_ids_ss, p_trim_empty => false);
  ------------------------------
  p_host_ids := v_host_ids_ap;
  ------------------------------
  if p_get_subhosts
  then
    ------------------------------
    p_subhost_ids := util_ri.get_ss_subhost_id(p_ss_id => v_ss_ids, p_date => p_date, p_trim_empty => false);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_imsi_host_smart
(
  p_imsis ct_varchar_s,
  p_host_type_code varchar2,
  p_date date,
  p_get_subhosts boolean,
  p_host_ids out ct_number,
  p_subhost_ids out ct_number
)
is
  v_ap_ids ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_varchar_s(p_imsis);
  util_pkg.XCheck_Cond_Missing(p_host_type_code is null, 'p_host_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_get_subhosts is null, 'p_get_subhosts');
  ------------------------------
  v_ap_ids := util_ri.get_ap_id3(p_imsi => p_imsis, p_date => p_date, p_trim_empty => false);
  ------------------------------
  get_ap_host_smart
  (
    p_ap_ids => v_ap_ids,
    p_host_type_code => p_host_type_code,
    p_date => p_date,
    p_get_subhosts => p_get_subhosts,
    p_host_ids => p_host_ids,
    p_subhost_ids => p_subhost_ids
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_iccid_host_smart_ex
(
  p_iccids ct_varchar_s,
  p_host_type_code varchar2,
  p_date date,
  p_get_subhosts boolean,
  p_host_ids out ct_number,
  p_subhost_ids out ct_number,
  p_no_ids out ct_number
)
is
  v_ap_ids ct_number;
  v_ss_ids ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_varchar_s(p_iccids);
  util_pkg.XCheck_Cond_Missing(p_host_type_code is null, 'p_host_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_get_subhosts is null, 'p_get_subhosts');
  ------------------------------
  v_ap_ids := util_ri.get_ap_id(p_iccid => p_iccids, p_date => p_date, p_trim_empty => false);
  ------------------------------
  get_ap_host_smart
  (
    p_ap_ids => v_ap_ids,
    p_host_type_code => p_host_type_code,
    p_date => p_date,
    p_get_subhosts => p_get_subhosts,
    p_host_ids => p_host_ids,
    p_subhost_ids => p_subhost_ids
  );
  ------------------------------
  v_ss_ids := util_ri.get_ap_ss_id(p_ap_id => v_ap_ids, p_date => p_date, p_trim_empty => false);
  p_no_ids := util_ri.get_ss_network_operator(p_ss_id => v_ss_ids, p_date => p_date, p_trim_empty => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_na_host_smart
(
  p_na_ids ct_number,
  p_host_type_code varchar2,
  p_date date,
  p_get_subhosts boolean,
  p_host_ids out ct_number,
  p_subhost_ids out ct_number
)
is
  v_ap_ids ct_number;
  v_na_ids4ap ct_number;
  v_na_ids4na ct_number;
  v_na_type_codes ct_varchar_s;
  v_host_ids_na ct_number;
  v_pns_ids ct_number;
  v_subhost_ids_na ct_number;
  v_marks ct_number;
  v_poss_e ct_number;
  v_poss_ne ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_na_ids);
  util_pkg.XCheck_Cond_Missing(p_host_type_code is null, 'p_host_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_get_subhosts is null, 'p_get_subhosts');
  ------------------------------
  v_na_ids4ap := p_na_ids;
  ------------------------------
  if p_host_type_code = util_ri.c_HOST_TYPE_CODE_HLR
  then
    ------------------------------
    v_na_type_codes := util_ri.get_na_type(p_na_id => v_na_ids4ap, p_date => p_date, p_trim_empty => false);
    ------------------------------
    v_marks := util_pkg.mark_val_ct_varchar_s(v_na_type_codes, util_ri.c_PNT_CODE_EXTERNAL); --!_!mark for E
    ------------------------------
    v_poss_ne := util_pkg.mark2pos(p_marks => v_marks, p_trim_empty => true, p_mark_value => util_pkg.c_false);
    util_pkg.set_val_by_pos2_ct_number(p_coll => v_na_ids4ap, p_val => NULL, p_positions => v_poss_ne); --!_!when E, don't use pns.host_id for sure; use ap_host through supplement below; erase not E
    ------------------------------
    v_na_ids4na := p_na_ids;
    ------------------------------
    v_poss_e := util_pkg.mark2pos(p_marks => v_marks, p_trim_empty => true);
    util_pkg.set_val_by_pos2_ct_number(p_coll => v_na_ids4na, p_val => NULL, p_positions => v_poss_e); --!_!when not E, use pns.host_id; erase E
    ------------------------------
  end if;
  ------------------------------
  v_ap_ids := util_ri.get_linked_ap_id(p_na_id => v_na_ids4ap, p_link_type_code => util_ri.c_NAAP_LINK_TYPE_CODE_MAIN, p_date => p_date, p_trim_empty => false);
  ------------------------------
  get_ap_host_smart
  (
    p_ap_ids => v_ap_ids,
    p_host_type_code => p_host_type_code,
    p_date => p_date,
    p_get_subhosts => p_get_subhosts,
    p_host_ids => p_host_ids,
    p_subhost_ids => p_subhost_ids
  );
  ------------------------------
  if p_host_type_code = util_ri.c_HOST_TYPE_CODE_HLR
  then
    ------------------------------
    v_pns_ids := util_ri.get_na_pns_id(p_na_id => v_na_ids4na, p_date => p_date, p_trim_empty => false);
    ------------------------------
    v_host_ids_na := util_ri.get_pns_host_id(p_pns_id => v_pns_ids, p_date => p_date, p_trim_empty => false);
    ------------------------------
    p_host_ids := util_pkg.supplement_ct_number(p_vals => v_host_ids_na, p_supplement => p_host_ids, p_trim_empty => false);
    ------------------------------
    if p_get_subhosts
    then
      ------------------------------
      v_subhost_ids_na := util_ri.get_pns_subhost_id(p_pns_id => v_pns_ids, p_date => p_date, p_trim_empty => false);
      ------------------------------
      p_subhost_ids := util_pkg.supplement_ct_number(p_vals => v_subhost_ids_na, p_supplement => p_subhost_ids, p_trim_empty => false);
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_msisdn_host_smart
(
  p_msisdns ct_varchar_s,
  p_host_type_code varchar2,
  p_date date,
  p_get_subhosts boolean,
  p_host_ids out ct_number,
  p_subhost_ids out ct_number
)
is
  v_na_ids ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Missing(p_host_type_code is null, 'p_host_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_get_subhosts is null, 'p_get_subhosts');
  ------------------------------
  v_na_ids := util_ri.get_na_id(p_msisdn => p_msisdns, p_date => p_date, p_trim_empty => false);
  ------------------------------
  get_na_host_smart
  (
    p_na_ids => v_na_ids,
    p_host_type_code => p_host_type_code,
    p_date => p_date,
    p_get_subhosts => p_get_subhosts,
    p_host_ids => p_host_ids,
    p_subhost_ids => p_subhost_ids
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_cur_ap_pahost_smart
(
  p_ap_ids ct_number
) return ct_number
is
  v_date date := sysdate;
  v_pa ct_number;
  v_opt_use_sim_cur_pa boolean;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_ap_ids);
  ------------------------------
  v_opt_use_sim_cur_pa := install_pkg.nnget_option_bool(util_ri.c_opt_use_sim_current_pa, util_ri.c_def_use_sim_current_pa);
  ------------------------------
  if v_opt_use_sim_cur_pa
  then
    ------------------------------
    v_pa := util_ri.get_cur_ap_pa(p_ap_id => p_ap_ids/*!_!, p_date => v_date*/, p_trim_empty => false);
    ------------------------------
  else
    ------------------------------
    v_pa := util_ri.get_ap_pa(p_ap_id => p_ap_ids, p_date => v_date, p_trim_empty => false);
    ------------------------------
  end if;
  ------------------------------
  return util_ri.get_pa_host(p_pa => v_pa, p_date => v_date, p_trim_empty => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_cur_imsi_pahost_smart
(
  p_imsis ct_varchar_s
) return ct_number
is
  v_date date := sysdate;
  v_ap_ids ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_varchar_s(p_imsis);
  ------------------------------
  v_ap_ids := util_ri.get_ap_id3(p_imsi => p_imsis, p_date => v_date, p_trim_empty => false);
  ------------------------------
  return get_cur_ap_pahost_smart
  (
    p_ap_ids => v_ap_ids
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_cur_na_pahost_smart
(
  p_na_ids ct_number
) return ct_number
is
  v_date date := sysdate;
  v_ap_ids ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_na_ids);
  ------------------------------
  v_ap_ids := util_ri.get_linked_ap_id(p_na_id => p_na_ids, p_link_type_code => util_ri.c_NAAP_LINK_TYPE_CODE_MAIN, p_date => v_date, p_trim_empty => false);
  ------------------------------
  return get_cur_ap_pahost_smart
  (
    p_ap_ids => v_ap_ids
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_cur_msisdn_pahost_smart
(
  p_msisdns ct_varchar_s
) return ct_number
is
  v_date date := sysdate;
  v_na_ids ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_varchar_s(p_msisdns);
  ------------------------------
  v_na_ids := util_ri.get_na_id(p_msisdn => p_msisdns, p_date => v_date, p_trim_empty => false);
  ------------------------------
  return get_cur_na_pahost_smart
  (
    p_na_ids => v_na_ids
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
