CREATE PACKAGE "RSIG_NET_ADDR_STATUS_HISTORY" IS
/****************************************************************************
<header>
  <name>             	package RSIG_NET_ADDR_STATUS_HISTORY
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>           1.2.5      05.12.2006   Roger Stockley
                      procedure Delete_Last_Open_Previous updated
  </version>
  <version>           1.2.4      22.09.2006   Petr Cepek
                      procedure Exist_Batch_Session_Id deleted
                      procedure Insert_Packet_Of_Intervals deleted
                      procedure Insert_Interval_Allowed deleted
  </version>
  <version>           1.2.3      05.09.2006   Petr Cepek
                      procedure Delete_Last_Open_Previous updated
  </version>
  <version>           1.2.2     31.07.2006   Petr Cepek
                      procedure Is_Net_Address_Deleted deleted
  </version>
  <version>           1.2.1     09.01.2005   Petr Cepek
                      procedure Delete_Last_Open_Previous updated
  </version>
   <version>
                      1.2.0     22.10.2005   Petr Cepek
                      procedure Is_Interval_Overlap updated - select for updated added
  </version>
  <version>          1.1.27	    01.06.2005     Radomir Lipka
							       Add new procedure Delete_Last_Open_Previous.
                     Procedure deleted interval ( end_date IS NULL and network_address_id )
                     and open previous interval ( end_date is not null )
                     if exists interval which be deleted and previous interval.
  </version>
  <version>          1.1.26	14.09.2004     Jaroslav  Holub
							       Change_Expired_States - fixed - not used v_expired_date, but old p_expired_date
  </version>
  <version>          1.1.25 03.09.2004     Jaroslav  Holub
							       in procedures Is_Interval_Overlap,Insert_Interval,
							       Close_Interval,Close_Packet_Of_Intervals,
							       Insert_Packet_Of_Intervals,Change_Expired_States
							       changed for NULL date acceptance in start(end)date
							       - if NULL presented then sysdate is filled instead
  </version>
  <version>          1.1.24   25.06.2004    Jaroslav Holub
                     Change_Expired_States -  fix error - when some error
                     ocured - then no state was changed, now only error
                     log was generated
  </version>
  <version> 		1.1.23  4.6.2004		Jaroslav Holub
                      		Add procedure Insert_Interval_Allowed
							and constants c_ROLE_GUI, c_ROLE_CRM
  </version>
  <version> 		1.1.22  10.5.2004		Jaroslav Holub
                      		Add function Change_Expired_States_job
  </version>

  <version> 		1.1.21  25.2.2004		Skorotkevich
                      		Fixed several bugs related to intervals.
  </version>

  <version> 		1.1.20  15.12.2003		prybicka
                      		*** empty log message ***
  </version>

  <version> 		1.1.19  15.12.2003		jstodulk
                      		Insert debug constant.
  </version>

  <version>  		1.1.18  15.12.2003		prybicka
                      		used constants c_DEBUG_TEXT_*
  </version>

  <version> 		1.1.17  15.12.2003		jstodulk
                      		Insert parameter RSIG_UTILS.c_MIN_DATE.
  </version>

  <version> 		1.1.16  15.12.2003		jstodulk
                      		New paraleter p_end_date in function Close_Packet_Of_Intervals.
  </version>

  <version> 		1.1.15  12.12.2003		prybicka
                      		package definition correction
  </version>

  <version> 		1.1.14  5.12.2003		prybicka
                      		p_start_date instead of p_net_address_status_code
  </version>

  <version> 		1.1.13  5.12.2003		prybicka
                      		changed procedure Insert_Packet_Of_Intervals
  </version>

  <version> 		1.0.1   10.9.2003     	Radek Hejduk
                      		created first version
  </version>

  <Description>      	package for table NETWORK_ADDRESS_STATUS_HISTORY
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/

c_ROLE_GUI	CONSTANT VARCHAR2(3) := 'GUI';
c_ROLE_CRM	CONSTANT VARCHAR2(3) := 'CRM';

/****************************************************************************
<header>
  <name>             	procedure Insert_Interval
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>          	1.0.2   03.09.2004     Jaroslav  Holub
                                changed for NULL date acceptance in start(end)date
                                - if NULL presented then sysdate is filled instead
  </version>
  <version>          	1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	Procedure first checks,  whether interval, that starts
                      with given start date, is overlapped with any existing
                      interval or not. If it is overlapped, procedure ends with
                      error c_DATE_OVERLAP.
                      If check passed successfully,  procedure inserts interval
                      given by net address status code and network address id
                      and consequently closes last interval (end_date is set to
                      value of parameter start date).

  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_net_address_status_code - IN - value for NET_ADDRESS_STATUS_CODE
                      p_network_address_id - IN - value for NETWORK_ADDRESS_ID
                      p_start_date - IN - value for START_DATE
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Insert_Interval (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_net_address_status_code IN     NETWORK_ADDRESS_STATUS_HISTORY.NET_ADDRESS_STATUS_CODE%TYPE,
    p_network_address_id      IN     NETWORK_ADDRESS_STATUS_HISTORY.NETWORK_ADDRESS_ID%TYPE,
    p_start_date              IN     NETWORK_ADDRESS_STATUS_HISTORY.START_DATE%TYPE,
    p_user_id_of_change       IN     NETWORK_ADDRESS_STATUS_HISTORY.USER_ID_OF_CHANGE%TYPE
  );
/****************************************************************************
<header>
  <name>             	procedure Close_Interval
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>          	1.0.3   03.09.2004     Jaroslav  Holub
                                changed for NULL date acceptance in start(end)date
                                - if NULL presented then sysdate is filled instead
  </version>
  <version>        	  1.0.2   5.12.2003     Pavel Rybi?ka
                              p_start_date instead of p_net_address_status_code
  </version>
  <version>        	  1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	Procedure first checks,  whether the end date of the
                      interval being closed is null or not. If it is not null,
                      the procedure ends with error c_DELETED.
                      Further procedure checks,  whether p_end_date is greater
                      then start_date of given interval. If it is not greater,
                      the procedure ends with error c_DATE_OVERLAP.
                      If all checks passed successfully, then procedure sets
                      end_date of given interval to value given by p_end_date
                      parameter.


  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_start_date - IN - value for START_DATE
                      p_network_address_id - IN - value for identification updating row (NETWORK_ADDRESS_ID)
                      p_end_date - IN - value for set of the end (END_DATE)
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Close_Interval (
    handle_tran                      CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                OUT    NUMBER,
    p_start_date              IN     NETWORK_ADDRESS_STATUS_HISTORY.START_DATE%TYPE,
    p_network_address_id      IN     NETWORK_ADDRESS_STATUS_HISTORY.NETWORK_ADDRESS_ID%TYPE,
    p_end_date                IN     NETWORK_ADDRESS_STATUS_HISTORY.END_DATE%TYPE,
    p_user_id_of_change       IN     NETWORK_ADDRESS_STATUS_HISTORY.USER_ID_OF_CHANGE%TYPE
  );

/****************************************************************************
<header>
  <name>             	procedure Close_Packet_Of_Intervals
  </name>

  <author>           	Radek Hejduk - GITUS
  </author>

  <version>          	1.0.3   03.09.2004     Jaroslav  Holub
                                changed for NULL date acceptance in start(end)date
                                - if NULL presented then sysdate is filled instead
  </version>
  <version>          	1.0.2   5.12.2003     Pavel Rybi?ka
                              p_start_date instead of p_net_address_status_code

  </version>
  <version>          	1.0.1   10.9.2003     Radek Hejduk
                                created first version
  </version>

  <Description>      	Procedure first checks,  whether the end date of the
                      interval being closed for all intervals given by paclet
                      of intervlas is null or not. If it is not null,
                      the procedure ends with error c_DELETED.
                      Further procedure checks,  whether p_end_date is greater
                      then start_date of all given intervals. If it is not
                      greater, the procedure ends with error c_DATE_OVERLAP.
                      If all checks passed successfully, then procedure sets
                      end_date to value given by p_end_date parameter of all
                      intervals given by packet of intervals and net address
                      status code.

  </Description>

  <Prerequisites>     PROCEDURE Debug_Rsi (
                        p_text          LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
                        p_level         NUMBER,                       -- level of debuging
                        p_event_type    LOG_EVENT.EVENT_TYPE%TYPE,    -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
                        p_event_source  LOG_EVENT.EVENT_SOURCE%TYPE   -- name of the source where this calling is performed
                      );
                      FUNCTION RSIG_UTILS.Handle_Error(p_ora_error_number NUMBER) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
                      RSIG_UTILS.c_DEBUG_TEXT_BEFORE_LOOP
                      RSIG_UTILS.c_DEBUG_TEXT_IN_LOOP
                      RSIG_UTILS.c_DEBUG_TEXT_AFTER_LOOP
                      FUNCTION Get_Packet_Of_Intervals(
                        Packet_Of_Val IN VARCHAR2,
                        Table_Of_Val OUT RSIG_UTILS.Type_Packet_Of_Intervals
                      ) RETURN NUMBER;
                      RSIG_UTILS.c_DEBUG_LEVEL_0
                      RSIG_UTILS.c_DEBUG_LEVEL_1
                      RSIG_UTILS.c_DEBUG_LEVEL_2
                      RSIG_UTILS.c_DEBUG_LEVEL_3
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code - OUT - NUMBER
                      p_net_address_status_code - IN - value for identification of updating rows (NET_ADDRESS_STATUS_CODE)
)                     p_packet_of_intervals - IN - packet of intervals as varchar2 (delimiter is ':' e.g. '11:12:13' or ':11:12:13:')
                      p_end_date - IN - value for END_DATE
                      p_user_id_of_change - IN - user id of change (USER_ID_OF_CHANGE)
  </Parameters>

</header>
****************************************************************************/
  PROCEDURE Close_Packet_Of_Intervals (
    handle_tran                        CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                  OUT    NUMBER,
    p_start_date                IN     NETWORK_ADDRESS_STATUS_HISTORY.START_DATE%TYPE,
    p_packet_of_intervals       IN     VARCHAR2,
    p_end_date                  IN     NETWORK_ADDRESS_STATUS_HISTORY.END_DATE%TYPE,
    p_user_id_of_change         IN     NETWORK_ADDRESS_STATUS_HISTORY.USER_ID_OF_CHANGE%TYPE
  );

END;
-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_NET_ADDR_STATUS_HISTORY.pkg,v 1.20 2003/12/15 10:20:17 prybicka Exp $
/
