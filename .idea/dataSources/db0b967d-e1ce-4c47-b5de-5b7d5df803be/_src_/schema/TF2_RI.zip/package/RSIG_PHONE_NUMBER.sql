CREATE PACKAGE RSIG_PHONE_NUMBER IS

  TYPE t_phone_number_col IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
  TYPE t_SN IS TABLE OF VARCHAR2(60) INDEX BY BINARY_INTEGER;
  TYPE t_date IS TABLE OF DATE INDEX BY BINARY_INTEGER;

  TYPE t_sal_cat IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;

  PROCEDURE Change_Salability_Category
  (
    handle_tran                IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                 OUT NUMBER,
    p_network_address_id       IN NUMBER, -- network ID of the phone number that we change the salability of
    p_salability_category_code IN VARCHAR2, -- salability we want to set the phone number to
    p_start_date               IN DATE, -- date since the salability change is valid
    p_user_id_of_change        IN NUMBER -- number of the user who performs this procedure
  );

  PROCEDURE Get_Phone_Status_History(
    p_network_address_id     IN  PHONE_NUMBER.NETWORK_ADDRESS_ID%TYPE,
    p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
    p_error_code             OUT NUMBER,
    p_error_message          OUT VARCHAR2,
    p_result_list            OUT sys_refcursor
  );

  PROCEDURE Get_Phone_Operator_History
  (
    error_code                   OUT NUMBER,
    p_network_address_id         IN PHONE_NUMBER.NETWORK_ADDRESS_ID%TYPE, -- id of the phone number we are getting the status history for
    p_cur_phone_operator_history IN OUT RSIG_UTILS.REF_CURSOR -- cursor that given phone operator history (network_address_id, start_date, end_date) will be stored in
  );

  PROCEDURE Get_Free_Phones_By_SIM_List(
    p_SN_list                  IN  t_SN, -- list of sim cards
    p_salability_category      IN  phone_number.salability_category_code%TYPE, -- code of the required salability category
    p_phone_type               IN  PHONE_NUMBER_TYPE.PHONE_NUMBER_TYPE_CODE%TYPE, -- code of the required phone type
    p_reserve                  IN  CHAR,
    p_join                     IN  CHAR,
    p_user_login               IN  VARCHAR2,
    handle_tran                IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code                 OUT NUMBER,
    error_message              OUT VARCHAR2,
    result_list                OUT sys_refcursor
  );

  PROCEDURE Get_Network_Operator_By_Phone
  (
    error_code         OUT NUMBER,
    p_phone_number     IN VARCHAR2, -- phone number in INTERNATIONAL FORMAT
    p_validity_date    IN DATE,
    p_uprs_member_code OUT NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE
  );

  PROCEDURE Get_Access_Point_Hist_By_Phone
  (
    error_code                 OUT NUMBER,
    p_network_address_id       IN PHONE_NUMBER.NETWORK_ADDRESS_ID%TYPE,
    p_cur_phone_status_history IN OUT RSIG_UTILS.REF_CURSOR
  );

  PROCEDURE Get_Phone_Salability_History
  (
    error_code              OUT NUMBER,
    p_network_address_id    IN PHONE_NUMBER.NETWORK_ADDRESS_ID%TYPE, -- id of the phone number we are getting the status history for
    p_cur_phone_sal_history IN OUT RSIG_UTILS.REF_CURSOR
  );

 procedure Get_phone_numbers_info(
   p_Validity_Date     IN DATE,
   p_Phone_Number_List IN t_phone_number_col,
   p_raise_error       IN CHAR,
   error_code          OUT NUMBER,
   error_message       OUT VARCHAR2,
   result_list         OUT SYS_REFCURSOR
 );

  PROCEDURE Get_Our_Net_Op_By_Phone
  (
    error_code         OUT NUMBER,
    p_phone_number     IN VARCHAR2, -- phone number in INTERNATIONAL FORMAT
    p_validity_date    IN DATE,
    p_uprs_member_code OUT NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
    p_operator_name    OUT network_operator.network_operator_name%TYPE
  );

  FUNCTION Is_Phone_Number_In_Mask
  (
    p_phone_number IN VARCHAR2, -- actuall phone number
    p_mask         IN VARCHAR2 -- actuall mask
  ) RETURN INT;

  PROCEDURE Mark_Gold_Phone_Numbers(
    handle_tran                     IN  CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    p_start_date                    IN  DATE, -- Validity start date and time (if null, then current date and time is considered)
    p_phone_number_series_id        IN  PHONE_NUMBER_SERIES.PHONE_NUMBER_SERIES_ID%TYPE,
    p_user_id_of_change             IN  NUMBER, -- id of the user who insert this serie
    p_set_gold                      IN  CHAR, -- "Y" means, that salability category should be set according to set masks, "N" means, that salability category should be set to "standard
    p_leave_marked_unchanged        IN  CHAR, -- "N" means, that salability category should be set for all phone numbers in series, "Y" means, that salability category should be set for "standard" phone numbers only
    p_raise_error                   IN  CHAR DEFAULT rsig_utils.c_NO,
    error_code                      OUT NUMBER
  );

  PROCEDURE Get_Net_Op_and_Status_By_Phone(
    p_phone_number           IN  phone_number.international_format%TYPE,
    p_validity_date          IN  DATE,
    p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
    error_code               OUT NUMBER,
    error_message            OUT VARCHAR2,
    p_other_billing          OUT CHAR,
    p_uprs_member_code       OUT NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE
  );

  procedure Get_Phone_Numbers_by_ICCID
  (
    p_ICCID_list    IN common.t_ICCID,
    p_raise_error   IN CHAR,
    error_code      OUT NUMBER,
    error_message   OUT VARCHAR2,
    result_list     OUT sys_refcursor
  );

  procedure PROD_FindFreePhoneNumbers(
    p_host_id host.host_id%type,
    p_msisdn_mask varchar2,
    p_msisdn_start varchar2,
    p_msisdn_end varchar2,
    p_service_provider_code varchar2,
    p_linked_service_provider_code varchar2,
    p_phone_status_code phone_number.net_address_status_code%type,
    p_phone_type_code phone_number_series.phone_number_type_code%type,
    p_quantity_limit number,
    p_salability_category varchar2,
    p_user_login users.login_name%type,
    p_handle_tran char default rsig_utils.c_handle_tran_y,
    p_raise_error char default rsig_utils.c_no,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor,
    p_rejected_list out sys_refcursor
  );

  procedure PROD_CheckPhonesByList(
    p_phone_list             IN  t_phone_number_col,
    p_host_id               IN  host.host_id%TYPE,
    p_service_provider_code  IN  VARCHAR2,
    p_linked_service_provider_code  IN  VARCHAR2,
    p_phone_status_code      IN  phone_number.net_address_status_code%TYPE,
    p_phone_type_code        IN  phone_number_series.phone_number_type_code%TYPE,
    p_salability_category    IN  VARCHAR2,
    p_user_login             IN  users.login_name%type,
    p_handle_tran             IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
    p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
    p_error_code             OUT NUMBER,
    p_error_message          OUT VARCHAR2,
    p_result_list            OUT sys_refcursor,
    p_rejected_list          OUT sys_refcursor
  );

  PROCEDURE Set_Phone_Number_Host_Relation(
    p_pnum_series_id        IN  phone_number_series_host.phone_number_series_id%TYPE,
    p_host_id               IN  host.host_id%TYPE,
    p_start_date            IN  DATE,
    p_end_date              IN  DATE,
    p_user_id_of_change     IN  NUMBER,
    handle_tran             IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
    p_raise_error           IN  CHAR DEFAULT rsig_utils.c_NO,
    error_code              OUT NUMBER,
    error_message           OUT VARCHAR2
  );

  PROCEDURE Get_Pnum_Relation_to_Host(
    p_pnum_series_id         IN  phone_number_series_host.phone_number_series_id%TYPE,
    p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
    error_code               OUT NUMBER,
    error_message            OUT VARCHAR2,
    result_list              OUT sys_refcursor
  );

  PROCEDURE GetBalanceStorageByPAMSISDN(
    p_international_format   IN  phone_number.international_format%TYPE,
    p_personal_account       IN  personal_account_history.personal_account%TYPE,
    p_validity_date          IN  DATE,
    p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
    p_error_code             OUT NUMBER,
    p_error_message          OUT VARCHAR2,
    result_list              OUT sys_refcursor
  );

  PROCEDURE GetBalanceStorageByPNList(
    p_PN_list                IN   t_phone_number_col,
    p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
    p_error_code             OUT NUMBER,
    p_error_message          OUT VARCHAR2,
    result_list              OUT sys_refcursor
  );

  PROCEDURE PROD_CheckPhonesByList2(
    p_phone_list             IN  t_phone_number_col,
    p_host_id               IN  host.host_id%TYPE,
    p_service_provider_code  IN  VARCHAR2,
    p_linked_service_provider_code  IN  VARCHAR2,
    p_phone_status_code      IN  phone_number.net_address_status_code%TYPE,
    p_phone_type_code        IN  phone_number_series.phone_number_type_code%TYPE,
    p_salability_category    IN  VARCHAR2,
    p_allowed_salability_category              IN t_sal_cat,
    p_user_login             IN  users.login_name%type,
    p_handle_tran             IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
    p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
    p_error_code             OUT NUMBER,
    p_error_message          OUT VARCHAR2,
    p_result_list            OUT sys_refcursor,
    p_rejected_list          OUT sys_refcursor
  );

  PROCEDURE Add_External_Phone
  (
    p_international_format          IN  VARCHAR2,
    p_user_nt_name                  IN  VARCHAR2,
    p_handle_tran                     IN  CHAR,
    p_raise_error                     IN  CHAR,
    p_error_code                     OUT NUMBER,
    p_error_message                  OUT VARCHAR2
  );

  PROCEDURE Add_External_Phones
  (
    p_international_format                IN  t_phone_number_col,
    p_user_nt_name                        IN  VARCHAR2,
    p_handle_tran                           IN  CHAR,
    p_raise_error                         IN  CHAR,
    p_cursor                              OUT SYS_REFCURSOR,
    p_error_code                          OUT NUMBER,
    p_error_message                       OUT VARCHAR2
  );

----------------------------------!---------------------------------------------
  procedure ChangeReservePhoneList
  (
    p_reserve_number number,
    p_select_msisdn_list util_pkg.cit_varchar_s,
    p_remove_msisdn_list util_pkg.cit_varchar_s,
    p_user_login varchar2,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor
  );

  procedure change_reserve_i
  (
    p_reserve_number number,
    p_na_ids ct_number,
    p_remove boolean,
    p_date date,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2,
    p_error_na_ids out ct_number,
    p_error_code_det out ct_number,
    p_error_message_det out ct_varchar
  );

----------------------------------!---------------------------------------------
  PROCEDURE ResetPhoneNumberReserve(
    p_user_login                   IN  VARCHAR2,
    p_reserve_number               IN  NUMBER,
    p_handle_tran                   IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
    p_raise_error                   IN  CHAR DEFAULT rsig_utils.c_NO,
    p_error_code                   OUT NUMBER,
    p_error_message                 OUT VARCHAR2,
    p_result_list                  OUT SYS_REFCURSOR
  );

  PROCEDURE ResetPhoneNumberReserveInt(
    p_user_id                      IN  NUMBER,
    p_reserve_number               IN  NUMBER
  );

  PROCEDURE ResetPhoneNumberReserves(
    p_user_login                   IN  VARCHAR2,
    p_reserve_numbers              IN  common.t_number,
    p_error_code                   OUT NUMBER,
    p_error_message                 OUT VARCHAR2,
    p_result_list                  OUT SYS_REFCURSOR
  );

  PROCEDURE ReservePhoneResetPeriodReserve(
    p_reserve_numbers              IN  util_pkg.cit_number,
    p_error_code                   OUT NUMBER,
    p_error_message                 OUT VARCHAR2,
    p_result_list                  OUT SYS_REFCURSOR
  );

  procedure SetPhoneStatusWithCheck(
    p_msisdn_list              Common.t_international_format,
    p_start_date               date,
    p_phone_number_status_code varchar2,
    p_set_phone_number_status  varchar2,
    p_user_login               varchar2,
    p_error_code               out number,
    p_error_message             out varchar2,
    p_result                   out sys_refcursor
  );

  PROCEDURE Insert_RIF_Phones(
    p_first_num          IN  VARCHAR2,
    p_last_num           IN  VARCHAR2,
    p_operator_code      IN  network_operator.network_operator_code%TYPE,
    p_pn_type_code       IN  phone_number_series.phone_number_type_code%TYPE,
    p_handle_tran        IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
    p_raise_error        IN  CHAR DEFAULT rsig_utils.c_NO,
    p_error_code         OUT NUMBER,
    p_error_message      OUT VARCHAR2);

END;
/
