CREATE package search_pkg is

----------------------------------!---------------------------------------------
--!_! if collection is null or empty - then any

----------------------------------!---------------------------------------------
--!_! p_host_empty: if null or false - use p_host_id

----------------------------------!---------------------------------------------
--!_! p_date: if null - any

----------------------------------!---------------------------------------------
--!_! p_xxx: if null - any

----------------------------------!---------------------------------------------
  c_opt_log_clob                 constant varchar2(100) := 'LOG_CLOB_search_pkg';

----------------------------------!---------------------------------------------
  c_def_log_clob                 constant boolean := false;

----------------------------------!---------------------------------------------
  c_srch_type_single             constant number := 0;
  c_srch_type_dual               constant number := 1;

  c_tpns_type_main               constant number := 0;
  c_tpns_type_linked             constant number := 1;

  c_tpns_type_temporary01        constant number := 1001;
  c_tpns_type_temporary02        constant number := 1002;

----------------------------------!---------------------------------------------
  c_dummy_msisdn                 constant varchar2(30) := 'ZXCVBNM';
  c_dummy_access_point_id        constant number := 0;
  c_dummy_network_operator_id    constant number := 0;
  c_dummy_host_id                constant number := 0;

----------------------------------!---------------------------------------------
  c_regress_mode_none            constant number := 0;
  c_regress_mode_old01           constant number := 1;
  c_regress_mode_old02           constant number := 2;

----------------------------------!---------------------------------------------
  --c_sett_max_loop_count          constant varchar2(100) := 'SearchPhones.MaxLoopCount';
  --c_sett_margin_count            constant varchar2(100) := 'SearchPhones.MarginCount';
  --c_sett_swap_pn_pns             constant varchar2(100) := 'SearchPhones.Swap_PN_PNS';
  c_sett_mask_digits_at_begin    constant varchar2(100) := 'SearchPhones.MaskDigitsAtBeginCount';
  c_sett_many_pns_count          constant varchar2(100) := 'SearchPhones.ManyPNSCount';
  c_sett_selective_sal_cats      constant varchar2(100) := 'SearchPhones.SelectiveSalabilityCategories';
  c_sett_use_status_pns_ind      constant varchar2(100) := 'SearchPhones.UseStatusPNSIndex';

  --c_def_max_loop_count           constant number := 1;
  --c_def_margin_count             constant number := 0;
  --c_def_swap_pn_pns              constant boolean := false;
  c_def_mask_digits_at_begin     constant number := 4;
  c_def_many_pns_count           constant number := 4;
  c_def_selective_sal_cats       constant varchar2(4000) := '';
  c_def_use_status_pns_ind       constant boolean := true;

----------------------------------!---------------------------------------------
  type cit_tt_pns is table of tt_phone_number_series%rowtype index by pls_integer;

----------------------------------!---------------------------------------------
  function make_reserve_status_or_null(p_reserve boolean) return varchar2;

----------------------------------!---------------------------------------------
  function get_linked_naap_value(p_link_status number) return boolean;
  function get_linked_naap_value2(p_link_status number) return boolean; --for GetPhonesByStatus2 using SearchPhonesModeEnum

----------------------------------!---------------------------------------------
  function normalize_mask(p_mask varchar2) return varchar2;

----------------------------------!---------------------------------------------
  procedure normalize_str_host_alike(p_str_host_alike varchar2, p_str_host_normal out varchar2, p_host_empty out boolean);
  procedure normalize_str_host_id(p_str_host_id varchar2, p_date date, p_xcheck_exist boolean, p_host_id out number, p_host_empty out boolean);
  procedure normalize_str_host_id2(p_str_host_id varchar2, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean);

  procedure normalize_coll_str_host_alike(p_coll_str_host_alike ct_varchar_s, p_coll_str_host_normal out ct_varchar_s, p_host_empty out boolean);
  procedure normalize_coll_str_host_alike2(p_coll_str_host_alike util_pkg.cit_varchar_s, p_coll_str_host_normal out ct_varchar_s, p_host_empty out boolean);
  procedure normalize_coll_str_host_id(p_coll_str_host_id ct_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean);
  procedure normalize_coll_str_host_id2(p_coll_str_host_id util_pkg.cit_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean);
  procedure normalize_coll_str_host_code(p_coll_str_host_code ct_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean);
  procedure normalize_coll_str_host_code2(p_coll_str_host_code util_pkg.cit_varchar_s, p_date date, p_xcheck_exist boolean, p_host_id out ct_number, p_host_empty out boolean);

----------------------------------!---------------------------------------------
  procedure XCheck_search_type(p_search_type number);

  function map_types_srch2tpns(p_srch_type number) return number;

----------------------------------!---------------------------------------------
  procedure clear_ttpns(p_type number);

  function get_ttpns_count(p_type number := null) return number;

----------------------------------!---------------------------------------------
  procedure prepare_pso_pns_i
  (
    p_type number,
    p_network_operator_id ct_number,
    p_phone_number_series_id ct_number,
    p_host_empty boolean,
    p_host_id ct_number,
    p_pns_type ct_varchar_s,
    p_date date,
    p_shuffle boolean,
    p_unique_pns boolean
  );

----------------------------------!---------------------------------------------
  procedure prepare_pso_pns_normal_m
  (
    p_network_operator_id number,
    p_phone_number_series_id number,
    p_host_empty boolean,
    p_host_id ct_number,
    p_pns_type ct_varchar_s,
    p_shuffle boolean
  );

  procedure prepare_pso_pns_normal_ml
  (
    p_network_operator_id_m number,
    p_network_operator_id_l number,
    p_phone_number_series_id_m number,
    p_phone_number_series_id_l number,
    p_host_empty_m boolean,
    p_host_empty_l boolean,
    p_host_id_m ct_number,
    p_host_id_l ct_number,
    p_pns_type_m ct_varchar_s,
    p_pns_type_l ct_varchar_s,
    p_shuffle_m boolean,
    p_shuffle_l boolean
  );

  procedure prepare_pso_pns_intersect_m
  (
    p_first_network_operator_id number,
    p_second_network_operator_id number,
    p_phone_number_series_id number,
    p_host_empty boolean,
    p_host_id ct_number,
    p_pns_type ct_varchar_s,
    p_shuffle boolean
  );

----------------------------------!---------------------------------------------
  procedure intersect_pns
  (
    p_first_type number,
    p_second_type number,
    p_result_type number,
    p_shuffle boolean,
    p_unique_pns boolean
  );

----------------------------------!---------------------------------------------
  procedure find_phones_i
  (
    p_search_type number,
    p_m_mask varchar2,
    p_m_status ct_varchar_s,
    p_m_category ct_varchar_s,
    p_l_mask varchar2,
    p_l_status ct_varchar_s,
    p_l_category ct_varchar_s,
    p_count number,
    p_lock boolean,
    p_linked_pl boolean,
    p_linked_naap boolean,
    p_filter_mno_for_l boolean,
    p_m_l_same_status boolean,
    p_m_l_same_category boolean,
    p_m_l_same_naap boolean,
    p_order_by_msisdn boolean,
    p_msisdn_lower_bound varchar2,
    p_set_phone_status boolean,
    p_date_from_status date,
    p_set_phone_status_code varchar2,
    p_ret_phone_count boolean,
    p_user_id number,
    p_m_na_id out ct_number,
    p_l_na_id out ct_number,
    p_pn_count out number
  );

  procedure find_phones_m_i
  (
    p_mask varchar2,
    p_status ct_varchar_s,
    p_category ct_varchar_s,
    p_count number,
    p_lock boolean,
    p_linked_naap boolean,
    p_set_phone_status boolean,
    p_date_from_status date,
    p_set_phone_status_code varchar2,
    p_ret_phone_count boolean,
    p_user_id number,
    p_na_id out ct_number,
    p_pn_count out number
  );

  procedure find_phones_l_i
  (
    p_m_mask varchar2,
    p_m_status ct_varchar_s,
    p_m_category ct_varchar_s,
    p_l_mask varchar2,
    p_l_status ct_varchar_s,
    p_l_category ct_varchar_s,
    p_count number,
    p_lock boolean,
    p_linked_naap boolean,
    p_filter_mno_for_l boolean,
    p_m_l_same_status boolean,
    p_m_l_same_category boolean,
    p_m_l_same_naap boolean,
    p_set_phone_status boolean,
    p_date_from_status date,
    p_set_phone_status_code varchar2,
    p_ret_phone_count boolean,
    p_user_id number,
    p_m_na_id out ct_number,
    p_l_na_id out ct_number,
    p_pn_count out number
  );

  procedure find_phones_any_pl_ord_i
  (
    p_mask varchar2,
    p_status ct_varchar_s,
    p_category ct_varchar_s,
    p_count number,
    p_lock boolean,
    p_linked_naap boolean,
    p_msisdn_lower_bound varchar2,
    p_na_id out ct_number
  );

----------------------------------!---------------------------------------------
  procedure Find_Linked_Phones_i
  (
    p_extended                 boolean,
    p_host_id                  varchar2,
    p_network_operator_code    network_operator.network_operator_code%type,
    p_phone_number_series_id   phone_number_series.phone_number_series_id%type,
    p_linked_network_operator  network_operator.network_operator_code%type,
    p_salability_cat_code_l    util_pkg.cit_varchar_s,
    p_phone_status_code_l      util_pkg.cit_varchar_s,
    p_mask                     varchar2,
    p_phone_count              number,
    p_set_phone_status_code    phone_number.net_address_status_code%type,
    p_user_login               varchar2,
    p_link_status              number,
    p_error_code               out number,
    p_error_message            out varchar2,
    p_result_list              out sys_refcursor
  );

  procedure Find_Linked_Phones
  (
    p_host_id                  varchar2,
    p_network_operator_code    network_operator.network_operator_code%type,
    p_phone_number_series_id   phone_number_series.phone_number_series_id%type,
    p_linked_network_operator  network_operator.network_operator_code%type,
    p_salability_cat_code_l    util_pkg.cit_varchar_s,
    p_phone_status_code_l      util_pkg.cit_varchar_s,
    p_mask                     varchar2,
    p_phone_count              number,
    p_set_phone_status_code    phone_number.net_address_status_code%type,
    p_user_login               varchar2,
    p_error_code               out number,
    p_error_message            out varchar2,
    p_result_list              out sys_refcursor
  );

  procedure Find_Linked_Phones_Ex
  (
    p_host_id                  varchar2,
    p_network_operator_code    network_operator.network_operator_code%type,
    p_phone_number_series_id   phone_number_series.phone_number_series_id%type,
    p_linked_network_operator  network_operator.network_operator_code%type,
    p_salability_cat_code_l    util_pkg.cit_varchar_s,
    p_phone_status_code_l      util_pkg.cit_varchar_s,
    p_mask                     varchar2,
    p_phone_count              number,
    p_set_phone_status_code    phone_number.net_address_status_code%type,
    p_user_login               varchar2,
    p_link_status              number,
    p_error_code               out number,
    p_error_message            out varchar2,
    p_result_list              out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure PROD_GetLinkedPhonesAll_i
  (
    p_host_id number,
    p_network_operator_code varchar2,
    p_linked_network_operator_code varchar2,
    p_phone_type varchar2,
    p_salability_category varchar2,
    p_mask varchar2,
    p_phone_number_status_code varchar2,
    p_set_phone_number_status_code varchar2,
    p_phone_number_count number,
    p_user_login varchar2,
    p_m_na_id out ct_number,
    p_l_na_id out ct_number
  );

----------------------------------!---------------------------------------------
  procedure GetFreePhones_i
  (
    p_host_codes util_pkg.cit_varchar_s,
    p_network_operator_code network_operator.network_operator_code%type,
    p_network_operator_code_linked network_operator.network_operator_code%type,
    p_phone_type util_pkg.cit_varchar_s,
    p_salability_categorys util_pkg.cit_varchar_s,
    p_mask varchar2,
    p_phone_number_status_code util_pkg.cit_varchar_s,
    p_phone_number_count number,
    p_search_type OUT number,
    p_m_na_id out ct_number,
    p_l_na_id out ct_number
  );

----------------------------------!---------------------------------------------
  procedure ReservePhones_i
  (
    p_in_m_na_id ct_number,
    p_in_l_na_id ct_number,
    p_search_type number,
    p_user_login varchar2,
    p_m_na_id out ct_number,
    p_l_na_id out ct_number
  );

----------------------------------!---------------------------------------------
  procedure GetFreePhonesAndReserve_i
  (
    p_host_codes               util_pkg.cit_varchar_s,
    p_network_operator_code    network_operator.network_operator_code%type,
    p_network_operator_code_linked network_operator.network_operator_code%type,
    p_phone_type               util_pkg.cit_varchar_s,
    p_salability_categorys     util_pkg.cit_varchar_s,
    p_mask                     varchar2,
    p_phone_number_status_code util_pkg.cit_varchar_s,
    p_phone_number_count       number,
    p_user_login               varchar2,
    p_result_list              out sys_refcursor,
    p_m_na_id                  out ct_number,
    p_l_na_id                  out ct_number
  );
----------------------------------!---------------------------------------------
  procedure GetPhonesByStatus2_ii
  (
    p_host_id                  util_pkg.cit_varchar_s,
    p_network_operator_code    network_operator.network_operator_code%type,
    p_is_netop_code_mandatory  number := util_pkg.c_true,
    p_phone_type               phone_number_series.phone_number_type_code%type,
    p_is_phone_type_mandatory  number := util_pkg.c_true,
    p_salability_category      util_pkg.cit_varchar_s,
    p_series_id                phone_number_series.phone_number_series_id%type,
    p_mask                     varchar2,
    p_use_linked               number,
    p_phone_number_status_code util_pkg.cit_varchar_s,
    p_set_phone_number_status_code phone_number.net_address_status_code%type,
    p_startingrow              number,
    p_phone_number_count       number,
    p_user_id                  number,
    p_m_na_id                  out ct_number
  );

  procedure GetPhonesByStatus2_i
  (
    p_host_id                  util_pkg.cit_varchar_s,
    p_network_operator_code    network_operator.network_operator_code%type,
    p_is_netop_code_mandatory  number := util_pkg.c_true,
    p_phone_type               phone_number_series.phone_number_type_code%type,
    p_is_phone_type_mandatory  number := util_pkg.c_true,
    p_salability_category      util_pkg.cit_varchar_s,
    p_series_id                phone_number_series.phone_number_series_id%type,
    p_mask                     varchar2,
    p_use_linked               number,
    p_phone_number_status_code util_pkg.cit_varchar_s,
    p_set_phone_number_status_code phone_number.net_address_status_code%type,
    p_startingrow              number,
    p_phone_number_count       number,
    p_user_login               varchar2,
    p_m_na_id                  out ct_number
  );

----------------------------------!---------------------------------------------
  procedure get_phone_numbers_i
  (
    p_network_operator_id number,
    p_external_operator_id number,
    p_phone_number_series_id number,
    p_host_id varchar2,
    p_mask varchar2,
    p_status util_pkg.cit_varchar_s,
    p_category util_pkg.cit_varchar_s,
    p_phone_number_type varchar2,
    p_count number,
    p_linked_naap boolean,
    p_msisdn_lower_bound varchar2,
    p_na_id out ct_number
  );

----------------------------------!---------------------------------------------
  procedure get_free_phone_count_i
  (
    p_host_id ct_number,
    p_host_empty boolean,
    p_network_operator_id number,
    p_phone_type varchar2,
    p_salability_category ct_varchar_s,
    p_series_id number,
    p_mask varchar2,
    p_use_linked number,
    p_phone_number_status_code ct_varchar_s,
    p_ps_id out ct_number,
    p_pn_count out ct_number
  );

----------------------------------!---------------------------------------------
  --!_! SPECIAL CASE is pn.date_of_status_change <= p_date_of_change
  procedure GetPhonesByTypeAndStatus
  (
    p_phone_type varchar2,
    p_phone_number_status_code varchar2,
    p_set_phone_number_status varchar2,
    p_phone_number_count number,
    p_network_operator_code varchar2,
    p_date_of_change date,
    p_user_id number,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure get_result_cursor01(p_m_na_id ct_number, p_l_na_id ct_number, p_date date, p_result out sys_refcursor);
  procedure get_result_cursor02(p_m_na_id ct_number, p_l_na_id ct_number, p_date date, p_result out sys_refcursor);
  procedure get_result_cursor03(p_m_na_id ct_number, p_l_na_id ct_number, p_date date, p_tpns_type number, p_result out sys_refcursor);
  procedure get_result_cursor04(p_na_id ct_number, p_date date, p_result out sys_refcursor);
  procedure get_result_cursor05(p_na_id ct_number, p_date date, p_result out sys_refcursor);
  procedure get_result_cursor06(p_na_id ct_number, p_date date, p_result out sys_refcursor);
  procedure get_result_cursor07(p_na_id ct_number, p_date date, p_result out sys_refcursor);
  procedure get_result_cursor08(p_na_id ct_number, p_date date, p_result out sys_refcursor);
  procedure get_result_cursor09(p_m_na_id ct_number, p_date date, p_result out sys_refcursor);
----------------------------------!---------------------------------------------

end;
/
