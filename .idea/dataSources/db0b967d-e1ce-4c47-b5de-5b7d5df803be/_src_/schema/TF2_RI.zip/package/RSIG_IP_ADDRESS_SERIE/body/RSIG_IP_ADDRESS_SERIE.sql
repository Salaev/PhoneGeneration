CREATE PACKAGE BODY RSIG_IP_ADDRESS_SERIE IS

---------------------------------------------
--     PROCEDURE Insert_IP_Address_Serie
---------------------------------------------

PROCEDURE Insert_IP_Address_Serie
(
  p_ip_address_start    IN IP_ADDRESS.IP_ADDRESS%TYPE,
  p_ip_address_end      IN IP_ADDRESS.IP_ADDRESS%TYPE,
  p_amount_of_addresses IN NUMBER,
  p_mask                IN IP_ADDRESS_SERIE.MASK%TYPE,
  p_ip_version          IN IP_ADDRESS_SERIE.IP_VERSION%TYPE,
  p_user_id_of_change   IN IP_ADDRESS.USER_ID_OF_CHANGE%TYPE,
  p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_ip_address_serie_id OUT IP_ADDRESS_SERIE.IP_ADDRESS_SERIE_ID%TYPE,
  handle_tran           IN CHAR,
  p_raise_error         IN CHAR,
  error_code            OUT NUMBER,
  error_message         OUT VARCHAR2
) IS
  v_event_source        VARCHAR2(60) := 'RSIG_IP_ADDRESS_SERIE.Insert_IP_Address_Serie';
  v_sqlcode             NUMBER;
  v_ip_number_start     NUMBER;
  v_ip_number_end       NUMBER;
  v_ip_address_start    IP_ADDRESS.IP_ADDRESS%TYPE;
  v_ip_address_end      IP_ADDRESS.IP_ADDRESS%TYPE;
  v_ip_address_serie_id NUMBER;
  v_network_address_id  NETWORK_ADDRESS.NETWORK_ADDRESS_ID%TYPE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  IF p_ip_address_start IS NULL
     OR (p_ip_address_end IS NULL AND p_amount_of_addresses IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid parameter.');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Insert_IP_address_serie;
  END IF;

  v_ip_address_end := p_ip_address_end;
  RSIG_IP_ADDRESS.IP_ADDRESS_TO_NUMBER(p_ip_address_start,
                                       p_ip_version,
                                       v_ip_number_start,
                                       RSIG_UTILS.c_YES,
                                       error_code,
                                       error_message);

  IF p_amount_of_addresses IS NOT NULL
     AND v_ip_address_end IS NOT NULL THEN
    RSIG_IP_ADDRESS.IP_ADDRESS_TO_NUMBER(v_ip_address_end,
                                         p_ip_version,
                                         v_ip_number_end,
                                         RSIG_UTILS.c_YES,
                                         error_code,
                                         error_message);

    IF p_amount_of_addresses <> (v_ip_number_end - v_ip_number_start + 1) THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER,
                              'Invalid parameter - amount of IP addresses doesn''t correspond with start-end interval.');
    END IF;
  END IF;

  IF p_amount_of_addresses IS NULL
     AND v_ip_address_end IS NOT NULL THEN
    RSIG_IP_ADDRESS.IP_ADDRESS_TO_NUMBER(v_ip_address_end,
                                         p_ip_version,
                                         v_ip_number_end,
                                         RSIG_UTILS.c_YES,
                                         error_code,
                                         error_message);

  ELSIF p_amount_of_addresses IS NOT NULL
        AND p_ip_address_end IS NULL THEN
    v_ip_number_end := v_ip_number_start + p_amount_of_addresses - 1;

    RSIG_IP_ADDRESS.IP_NUMBER_TO_ADDRESS(v_ip_number_end,
                                         p_ip_version,
                                         v_ip_address_end,
                                         RSIG_UTILS.c_YES,
                                         error_code,
                                         error_message);
  ELSE
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER,
                            'Invalid parameter - amount of IP addresses and end address are both NULL!');
  END IF;

  IF v_ip_number_end < v_ip_number_start THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER,
                            'Invalid parameter - wrong start-end interval!');
  END IF;

  TEST_IP_SERIE_OVERLAP(p_ip_address_start,
                        v_ip_address_end,
                        p_ip_version,
                        SYSDATE,
                        RSIG_UTILS.c_YES,
                        error_code,
                        error_message);
  RSIG_IP_ADDRESS.IS_SAME_NETWORK(p_ip_address_start,
                                  v_ip_address_end,
                                  p_mask,
                                  p_ip_version,
                                  RSIG_UTILS.c_YES,
                                  error_code,
                                  error_message);

  INSERT INTO IP_ADDRESS_SERIE
    (ip_address_serie_id,
     mask,
     ip_address_start,
     ip_address_end,
     ip_version,
     user_id_of_change,
     date_of_change,
     deleted,
     ip_number_start,
     ip_number_end)
  VALUES
    (S_IP_ADDRESS_SERIE.NEXTVAL,
     p_mask,
     p_ip_address_start,
     v_ip_address_end,
     p_ip_version,
     p_user_id_of_change,
     SYSDATE,
     NULL,
     v_ip_number_start,
     v_ip_number_end)
  RETURNING IP_ADDRESS_SERIE_ID INTO v_ip_address_serie_id;

  INSERT INTO IP_SERIE_OPERATOR
    (ip_address_serie_id,
     network_operator_id,
     start_date,
     end_date,
     user_id_of_change,
     date_of_change)
  VALUES
    (v_ip_address_serie_id,
     p_network_operator_id,
     SYSDATE,
     NULL,
     p_user_id_of_change,
     SYSDATE);

  WHILE v_ip_number_start <= v_ip_number_end
  LOOP
    RSIG_IP_ADDRESS.IP_NUMBER_TO_ADDRESS(v_ip_number_start,
                                         p_ip_version,
                                         v_ip_address_start,
                                         RSIG_UTILS.c_YES,
                                         error_code,
                                         error_message);
    RSIG_IP_ADDRESS.Insert_IP_address(v_ip_address_start,
                                      v_ip_address_serie_id,
                                      p_user_id_of_change,
                                      v_network_address_id,
                                      RSIG_UTILS.c_HANDLE_TRAN_N,
                                      RSIG_UTILS.c_YES,
                                      error_code,
                                      error_message);
    v_ip_number_start := v_ip_number_start + 1;
  END LOOP;

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;
  p_ip_address_serie_id := v_ip_address_serie_id;
  -- set error code to succesfully completed
  error_code := 0;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Insert_IP_address_serie;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Insert_IP_address_serie;

---------------------------------------------
--     PROCEDURE Test_Ip_Serie_Overlap
---------------------------------------------

PROCEDURE Test_Ip_Serie_Overlap
(
  p_ip_address_start IN IP_ADDRESS.IP_ADDRESS%TYPE,
  p_ip_address_end   IN IP_ADDRESS.IP_ADDRESS%TYPE,
  p_ip_version       IN IP_ADDRESS_SERIE.IP_VERSION%TYPE,
  p_test_date        IN DATE,
  p_raise_error      IN CHAR,
  error_code         OUT NUMBER,
  error_message      OUT VARCHAR2
) IS
  v_event_source     VARCHAR2(60) := 'RSIG_IP_ADDRESS_SERIE.Test_Ip_Serie_Overlap';
  v_sqlcode          number;
  v_ip_number_start  NUMBER;
  v_ip_number_end    NUMBER;
  v_ip_serie_overlap NUMBER;
  v_test_date        DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  v_test_date := nvl(p_test_date, SYSDATE);
  IF p_ip_address_start IS NULL
     OR p_ip_address_end IS NULL
     OR p_ip_version IS NULL
     OR p_ip_version NOT IN (RSIG_IP_ADDRESS.c_ipv4, RSIG_IP_ADDRESS.c_ipv6) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  RSIG_IP_ADDRESS.IP_ADDRESS_TO_NUMBER(p_ip_address_start,
                                       p_ip_version,
                                       v_ip_number_start,
                                       RSIG_UTILS.c_YES,
                                       error_code,
                                       error_message);

  RSIG_IP_ADDRESS.IP_ADDRESS_TO_NUMBER(p_ip_address_end,
                                       p_ip_version,
                                       v_ip_number_end,
                                       RSIG_UTILS.c_YES,
                                       error_code,
                                       error_message);

  -- procedure body here
  BEGIN
    SELECT 1
      INTO v_ip_serie_overlap
      FROM IP_ADDRESS_SERIE ias
     WHERE ((ias.ip_number_start BETWEEN v_ip_number_start AND v_ip_number_end OR
           ias.ip_number_end BETWEEN v_ip_number_start AND v_ip_number_end) OR
           (v_ip_number_start BETWEEN ias.ip_number_start AND ias.ip_number_end OR
           v_ip_number_end BETWEEN ias.ip_number_start AND ias.ip_number_end))
       AND (ias.deleted IS NULL OR ias.deleted > v_test_date)
       AND ROWNUM = 1;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_ip_serie_overlap := 0;
  END;

  IF v_ip_serie_overlap = 1 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_IP_SERIE_OVEVERLAPED, 'There exists serie between serie!');
  END IF;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END TEST_IP_SERIE_OVERLAP;


---------------------------------------------
--     PROCEDURE Delete_IP_Address_Serie
---------------------------------------------

PROCEDURE Delete_IP_Address_Serie
(
  p_ip_address_serie_id IN IP_ADDRESS_SERIE.IP_ADDRESS_SERIE_ID%TYPE,
  p_user_id_of_change   IN IP_ADDRESS_SERIE.USER_ID_OF_CHANGE%TYPE,
  p_date                IN DATE,
  handle_tran           IN CHAR,
  p_raise_error         IN CHAR,
  error_code            OUT NUMBER,
  error_message         OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IP_ADDRESS_SERIE.Delete_IP_Address_Serie';
  v_sqlcode      number;
  v_date         DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;
  v_date := nvl(p_date, SYSDATE);
  IF p_ip_address_serie_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Delete_IP_address_serie;
  END IF;

  -- procedure body here
  UPDATE IP_ADDRESS ia
     SET USER_ID_OF_CHANGE = p_user_id_of_change,
         DATE_OF_CHANGE    = SYSDATE,
         DELETED           = v_date
   WHERE ia.ip_address_serie_id = p_ip_address_serie_id
     AND ia.deleted IS NULL;

  UPDATE IP_ADDRESS_SERIE ias
     SET ias.USER_ID_OF_CHANGE = p_user_id_of_change,
         ias.deleted           = v_date,
         ias.date_of_change    = SYSDATE
   WHERE ias.ip_address_serie_id = p_ip_address_serie_id;

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint Delete_IP_address_serie;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Delete_IP_address_serie;

---------------------------------------------
--     PROCEDURE Get_Ip_Address_Serie
---------------------------------------------

PROCEDURE Get_Ip_Address_Serie
(
  p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_ip_address_serie_id IN IP_ADDRESS_SERIE.IP_ADDRESS_SERIE_ID%TYPE,
  p_mask                IN IP_ADDRESS_SERIE.MASK%TYPE,
  p_ip_version          IN IP_ADDRESS_SERIE.IP_VERSION%TYPE,
  p_show_deleted        IN CHAR,
  p_row_count           IN NUMBER,
  result_list           OUT sys_refcursor,
  p_raise_error         IN CHAR,
  error_code            OUT NUMBER,
  error_message         OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IP_ADDRESS_SERIE.Get_Ip_Address_Serie';
  v_sqlcode      number;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN result_list FOR
    SELECT RSIG_UTILS.c_OK,
           ias.IP_ADDRESS_SERIE_ID,
           ias.MASK,
           ias.IP_ADDRESS_START,
           ias.IP_ADDRESS_END,
           ias.IP_VERSION,
           ias.USER_ID_OF_CHANGE,
           ias.DATE_OF_CHANGE,
           ias.DELETED,
           ias.IP_NUMBER_START,
           ias.IP_NUMBER_END,
           iso.NETWORK_OPERATOR_ID
      FROM IP_ADDRESS_SERIE ias
      JOIN IP_SERIE_OPERATOR iso ON iso.ip_address_serie_id = ias.ip_address_serie_id
     WHERE 1 = 1
       AND (iso.end_date IS NULL OR iso.end_date > SYSDATE OR p_show_deleted IS NULL)
       AND (ias.IP_ADDRESS_SERIE_ID > p_ip_address_serie_id OR p_ip_address_serie_id IS NULL)
       AND (ias.MASK = p_mask OR p_mask IS NULL)
       AND (ias.ip_version = p_ip_version OR p_ip_version IS NULL)
       AND (ias.deleted IS NULL OR p_show_deleted = RSIG_UTILS.c_YES)
       AND (ROWNUM <= p_row_count OR p_row_count IS NULL)
       AND (iso.network_operator_id = p_network_operator_id OR p_network_operator_id IS NULL)
     ORDER BY ias.ip_number_start,ias.deleted NULLS LAST;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN result_list FOR
      SELECT error_code FROM dual;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_ip_address_serie;

------------------------------------------------------------------------------------------------------------------------------
--  Get_IP_Serie_Detail
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_IP_Serie_Detail(
  p_IP_Serie_Id         IN   ip_address_serie.ip_address_serie_id%TYPE,
  p_raise_error         IN   CHAR,
  error_code            OUT  NUMBER,
  error_message         OUT  VARCHAR2,
  result_list           OUT  sys_refcursor
)
IS
	v_sqlcode	             number;
  v_event_source         varchar2(60) :='RSIG_IP_ADDRESS_SERIE.Get_IP_Serie_Detail';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

	IF p_IP_Serie_Id IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


-- start of the procedure body --------------------------------------------------------------------------------------------------

  OPEN result_list FOR
  SELECT ias.ip_version,
         ias.mask,
         (SELECT /*+ index(ia I_IP_SERIES) */
                 COUNT(*)
          FROM ip_address ia
          WHERE ia.ip_address_serie_id=ias.ip_address_serie_id) ip_address_count,
         ias.ip_number_start,
         ias.ip_number_end,
         u.user_name,
         ias.date_of_change
  FROM ip_address_serie ias
  JOIN users u ON u.user_id=ias.user_id_of_change
  WHERE ias.ip_address_serie_id=p_IP_Serie_Id;


-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_IP_Serie_Detail;

end RSIG_IP_ADDRESS_SERIE;
/
