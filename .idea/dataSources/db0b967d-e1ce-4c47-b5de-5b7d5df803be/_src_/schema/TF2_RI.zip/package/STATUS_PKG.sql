CREATE package STATUS_PKG is

----------------------------------!---------------------------------------------
  c_name_network_address         constant varchar2(30) := 'NETWORK_ADDRESS';
  c_name_access_point            constant varchar2(30) := 'ACCESS_POINT';
  c_delim_for                    constant varchar2(30) := ' for ';

----------------------------------!---------------------------------------------
  type t_item is record
  (
    id ct_number,
    num1 ct_number,
    str1 ct_varchar_s,
    date1 ct_date,
    num2 ct_number,
    num3 ct_number
  );

  type ct_item is table of t_item;
  --!_!type cit_item is table of t_item index by binary_integer;

----------------------------------!---------------------------------------------
  function get_count_ct_item(p_coll ct_item) return number;
  procedure resize_ct_item(p_coll in out nocopy ct_item, p_size number);
  procedure add_ct_item_val(p_coll in out nocopy ct_item, p_val t_item);
  procedure add_ct_item(p_coll in out nocopy ct_item, p_coll_add ct_item);

----------------------------------!---------------------------------------------
  procedure XCheck_t_item(p_val t_item, p_check_fullness boolean, p_full_fullness boolean);
  procedure XCheck_t_item_sizes(p_val t_item);

  procedure XCheck_ct_item(p_val ct_item, p_check_fullness boolean, p_full_fullness boolean);
  procedure XCheck_ct_item_sizes(p_val ct_item);

----------------------------------!---------------------------------------------
  function make_t_item00
  (
    p_id ct_number,
    p_num1 ct_number,
    p_str1 ct_varchar_s,
    p_date1 ct_date,
    p_num2 ct_number,
    p_num3 ct_number
  ) return t_item;

  function make_t_item01
  (
    p_id util_pkg.cit_number,
    p_num1 util_pkg.cit_number,
    p_str1 util_pkg.cit_varchar_s,
    p_date1 util_pkg.cit_date,
    p_num2 util_pkg.cit_number,
    p_num3 util_pkg.cit_number
  ) return t_item;

  function make_t_item12
  (
    p_id1 number,
    p_id2 number,
    p_num11 number,
    p_num12 number,
    p_str11 varchar2,
    p_str12 varchar2,
    p_date11 date,
    p_date12 date,
    p_num21 number,
    p_num22 number,
    p_num31 number,
    p_num32 number
  ) return t_item;

  function make_t_item121
  (
    p_id1 number,
    p_id2 number,
    p_num1 number,
    p_str11 varchar2,
    p_str12 varchar2,
    p_date1 date,
    p_num2 number,
    p_num31 number,
    p_num32 number
  ) return t_item;

  function get_t_item_id1(p_item t_item) return number;
  function get_t_item_id2(p_item t_item) return number;

----------------------------------!---------------------------------------------
  function make_ct_item120
  (
    p_id1 ct_number,
    p_id2 ct_number,
    p_num1 ct_number,
    p_str11 ct_varchar_s,
    p_str12 ct_varchar_s,
    p_date1 date,
    p_num2 number,
    p_num31 ct_number,
    p_num32 ct_number
  ) return ct_item;

  function make_ct_item121
  (
    p_id1 ct_number,
    p_id2 ct_number,
    p_num1 ct_number,
    p_str11 varchar2,
    p_str12 varchar2,
    p_date1 date,
    p_num2 number,
    p_num31 number,
    p_num32 number
  ) return ct_item;

----------------------------------!---------------------------------------------
  procedure prepare_as_pnlnk
  (
    p_na_ids_unique ct_number,
    p_date date,
    p_na_ids_m out ct_number,
    p_na_ids_l out ct_number,
    p_pos_src_in_m_size_src out ct_number,
    p_pos_src_in_l_size_src out ct_number
  );

  procedure prepare_as_pnlnk2
  (
    p_na_ids_not_unique ct_number,
    p_date date,
    p_na_ids_m out ct_number,
    p_na_ids_l out ct_number,
    p_pos_src_in_m_size_src out ct_number,
    p_pos_src_in_l_size_src out ct_number,
    p_pos_src_in_unique_size_src out ct_number
  );

  procedure xprepare_as_pnlnk2
  (
    p_na_ids ct_number,
    p_ap_ids ct_number,
    p_date date,
    p_ap_ids_m out ct_number,
    p_na_ids_m out ct_number,
    p_na_ids_l out ct_number,
    p_pos_src_in_m_size_src out ct_number,
    p_pos_src_in_l_size_src out ct_number
  );

  procedure xprepare_as_pnlnk3
  (
    p_na_ids ct_number,
    p_ap_ids ct_number,
    p_date date,
    p_ap_ids_m out ct_number,
    p_na_ids_m out ct_number,
    p_na_ids_l out ct_number,
    p_explicit_intentions_m out ct_number,
    p_explicit_intentions_l out ct_number,
    p_pos_src_in_m_or_l_size_src out ct_number
  );

----------------------------------!---------------------------------------------
  procedure naap_open_ii
  (
    p_item t_item,
    p_silent_proper_state boolean
  );

  procedure naap_open_i
  (
    p_items ct_item,
    p_break_on_error boolean,
    p_silent_proper_state boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure naap_open_ex_i
  (
    p_na_ids ct_number,
    p_ap_ids ct_number,
    p_legacy_smart_link_type boolean,
    p_main_link4main_na boolean,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_silent_proper_state boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  function naap_open_make_ct_item
  (
    p_legacy_smart_link_type boolean,
    p_main_link4main_na boolean,
    p_explicit_intentions_m ct_number,
    p_explicit_intentions_l ct_number,
    p_na_ids_m ct_number,
    p_na_ids_l ct_number,
    p_ap_ids_m ct_number,
    p_date date,
    p_user_id number
  ) return ct_item;

  function naap_open_make_ct_item_simple
  (
    p_main_link4main_na boolean,
    p_na_ids_m ct_number,
    p_na_ids_l ct_number,
    p_ap_ids_m ct_number,
    p_date date,
    p_user_id number
  ) return ct_item;

  function naap_open_make_ct_item_smart
  (
    p_main_link4main_na boolean,
    p_explicit_intentions_m ct_number,
    p_explicit_intentions_l ct_number,
    p_na_ids_m ct_number,
    p_na_ids_l ct_number,
    p_ap_ids_m ct_number,
    p_date date,
    p_user_id number
  ) return ct_item;

----------------------------------!---------------------------------------------
  procedure naap_open
  (
    p_na_ids ct_number,
    p_ap_ids ct_number,
    p_main_link4main_na boolean,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_silent_proper_state boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure naap_open_legacy
  (
    p_na_ids ct_number,
    p_ap_ids ct_number,
    p_main_link4main_na boolean,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_silent_proper_state boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

----------------------------------!---------------------------------------------

end;
/
