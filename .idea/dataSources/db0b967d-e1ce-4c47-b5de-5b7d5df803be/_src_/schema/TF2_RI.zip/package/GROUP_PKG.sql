CREATE package GROUP_PKG is

----------------------------------!---------------------------------------------
  procedure group_add_items_id1
  (
    p_group_id number,
    p_unique boolean,
    p_id1 ct_number,
    p_date date,
    p_user_id number
  );

  procedure group_add_items_id1_id2
  (
    p_group_id number,
    p_unique boolean,
    p_id1 ct_number,
    p_id2 ct_number,
    p_date date,
    p_user_id number
  );

----------------------------------!---------------------------------------------
  procedure group_del_items_id1
  (
    p_group_id number,
    p_id1 ct_number,
    p_date date,
    p_user_id number
  );

----------------------------------!---------------------------------------------
  procedure group_hard_del_all_items
  (
    p_group_id number,
    p_user_id number
  );

----------------------------------!---------------------------------------------
end;
/
