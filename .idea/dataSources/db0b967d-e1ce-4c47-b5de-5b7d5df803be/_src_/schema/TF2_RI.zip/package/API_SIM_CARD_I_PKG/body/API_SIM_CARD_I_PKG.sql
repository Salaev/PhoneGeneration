CREATE package body API_SIM_CARD_I_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure clear_sim_card_details
(
  p_ap_id number,
  p_user_id number
)
is
begin
  ------------------------------
  update /*+ index_asc(z, PK_SIM_CARD)*/
    sim_card z
  set
    pin = null,
    pin2 = null,
    puk2 = null,
    puk = null,
    ki = null,
    adm1 = null,
    access_control = null,
    user_id_of_change = p_user_id,
    date_of_change = sysdate
  where 1 = 1
  and access_point_id = p_ap_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function ap_is_alive(p_ap_id number, p_date date) return boolean
is
  v_tmp_ss_id number;
begin
  ------------------------------
  v_tmp_ss_id := util_ri.get_ap_ss_id2(p_ap_id, p_date);
  v_tmp_ss_id := util_ri.check_ss_id2(v_tmp_ss_id, p_date, FALSE);
  if v_tmp_ss_id is not null
  then
    return true;
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_sim_series_status_validity
(
  p_ss_id number,
  p_status varchar2,
  p_date date,
  p_user_id number,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_ss_stat_val sim_series_status_validity%rowtype;
begin
 ------------------------------
  v_ss_stat_val := vp_sim_series_status_validity.xlock_get1(p_ss_id, p_date);
  if v_ss_stat_val.sim_series_id is null
  then
    ------------------------------
    v_ss_stat_val := null;
    v_ss_stat_val.sim_series_id := p_ss_id;
    v_ss_stat_val.status_code := p_status;
    v_ss_stat_val.start_date := p_date;
    v_ss_stat_val.user_id_of_change := p_user_id;
    vp_sim_series_status_validity.version_open(v_ss_stat_val);
    ------------------------------
  else
    ------------------------------
    if v_ss_stat_val.status_code <> p_status
    then
      ------------------------------
      v_ss_stat_val.status_code := p_status;
      v_ss_stat_val.start_date := p_date;
      v_ss_stat_val.user_id_of_change := p_user_id;
      vp_sim_series_status_validity.version_change(v_ss_stat_val);
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure validate_addition_sims
(
  p_sim_imsi ct_varchar_s,
  p_main_imsi_index ct_number,
  p_date date,
  p_break_on_error boolean,
  p_error_code out ct_number,
  p_error_message out ct_varchar
)
is
  v_main_count number;
  v_ss_id ct_number;
  --
  v_tmp_imsi ct_varchar_s;
  v_tmp_ap_id ct_number;
  v_tmp_ss_id ct_number;
  --
  v_pivot ct_number;
  v_mark_err ct_number;
  v_tmp_err ct_number;
  v_err_main_imsi_indexes ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheckP_FS_ct_varchar_s(p_sim_imsi, 'p_sim_imsi');
  util_pkg.XCheckP_FS_ct_number(p_main_imsi_index, 'p_main_imsi_index');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_sim_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_sim_imsi) != v_main_count, 'p_sim_imsi.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_main_imsi_index) != v_main_count, 'p_main_imsi_index.count != v_main_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_code, p_error_message);
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  v_tmp_imsi := util_pkg.unique_ct_varchar_s(p_sim_imsi, TRUE, FALSE, NULL);
  v_tmp_err := util_pkg.mark_val_ct_varchar_s(v_tmp_imsi, null);
  v_err_main_imsi_indexes := util_pkg.get_marked_ct_number(p_main_imsi_index, v_tmp_err, TRUE);
  v_mark_err := util_pkg.mark_ct_number(p_main_imsi_index, v_err_main_imsi_indexes);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_pkg.c_ora_object_not_unique, util_pkg.c_msg_object_not_unique, util_pkg.c_true, p_error_code, p_error_message);
  util_ext_ri.xcheck_has_error(TRUE, p_error_code, p_error_message); --!_!
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_tmp_imsi := util_pkg.get_by_pos2_ct_varchar_s(p_sim_imsi, v_pivot, FALSE);
  v_tmp_ap_id := util_ri.get_ap_id_full(v_tmp_imsi, p_date, FALSE);
  v_tmp_ss_id := util_ri.get_ap_ss_id(v_tmp_ap_id, p_date, FALSE);
  v_tmp_ss_id := util_ri.check_ss_id(v_tmp_ss_id, p_date, FALSE, FALSE);
  v_tmp_err := util_pkg.mark_val_ct_number(v_tmp_ss_id, null, util_pkg.c_false, util_pkg.c_true);
  v_err_main_imsi_indexes := util_pkg.get_marked_ct_number(p_main_imsi_index, v_tmp_err, TRUE);
  v_mark_err := util_pkg.mark_ct_number(p_main_imsi_index, v_err_main_imsi_indexes);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_sim_already_imported, util_loc_pkg.c_msg_sim_already_imported, util_pkg.c_true, p_error_code, p_error_message);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_code, p_error_message);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_tmp_imsi := util_pkg.get_by_pos2_ct_varchar_s(p_sim_imsi, v_pivot, FALSE);
  v_ss_id := util_ri.det_ss_id4imsi(v_tmp_imsi, p_date, FALSE);
  v_tmp_err := util_pkg.mark_val_ct_number(v_ss_id, null, util_pkg.c_true, util_pkg.c_false);
  v_err_main_imsi_indexes := util_pkg.get_marked_ct_number(p_main_imsi_index, v_tmp_err, TRUE);
  v_mark_err := util_pkg.mark_ct_number(p_main_imsi_index, v_err_main_imsi_indexes);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_sim_serie_not_found, util_loc_pkg.c_msg_sim_serie_not_found, util_pkg.c_true, p_error_code, p_error_message);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure import_sim_card1_ii
(
  p_imsi varchar2,
  p_iccid varchar2,
  p_pin varchar2,
  p_pin2 varchar2,
  p_puk varchar2,
  p_puk2 varchar2,
  p_msisdn_bound varchar2,
  p_personal_account number,
  p_ki nvarchar2,
  p_adm1 nvarchar2,
  p_access_control nvarchar2,
  p_authent_type varchar2,
  p_ss_id number,
  p_status varchar2,
  p_date date,
  p_addition_imsi ct_varchar_s,
  p_user_id number,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_add_count number;
  v_add_sim_rec sim_imsi%rowtype;
  v_sim_rec sim_card%rowtype;
  v_imsis ct_varchar_s;
  v_ap_id number;
  v_tmp_status varchar2(10);
  v_res boolean;
begin
  ------------------------------
  savepoint sp_import_sim_card1_ii;
  ------------------------------
  v_add_count := util_pkg.get_count_ct_varchar_s(p_addition_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_addition_imsi) != v_add_count, 'p_addition_imsi.count != v_add_count');
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_imsis, p_imsi);
  util_pkg.add_ct_varchar_s(v_imsis, p_addition_imsi);
  for v_i in 1..v_add_count + 1
  loop
    ------------------------------
    v_add_sim_rec := vp_sim_imsi.xlock_get1(v_imsis(v_i), p_date);
    ------------------------------
    if vp_sim_imsi.is_identified(v_add_sim_rec)
    then
      ------------------------------
      if ap_is_alive(v_add_sim_rec.access_point_id, p_date) --!_!
      then
        util_pkg.raise_exception(util_loc_pkg.c_ora_sim_already_imported, util_loc_pkg.c_msg_sim_already_imported);
      end if;
      ------------------------------
      vp_sim_imsi.version_close(v_add_sim_rec.imsi, p_user_id);
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  ------------------------------
  v_ap_id := util_ri.qwerty_get_ap_id4_all(p_imsi)(util_ri.c_index_one); --!_!(if exists) first ap_id for imsi
  ------------------------------
  if v_ap_id is null
  then
    ------------------------------
    v_sim_rec := null;
    v_sim_rec.imsi := p_imsi;
    v_sim_rec.sn := p_iccid;
    v_sim_rec.pin := p_pin;
    v_sim_rec.pin2 := p_pin2;
    v_sim_rec.puk := p_puk;
    v_sim_rec.puk2 := p_puk2;
    v_sim_rec.msisdn_bound := p_msisdn_bound;
    v_sim_rec.personal_account := p_personal_account;
    v_sim_rec.ki := p_ki;
    v_sim_rec.adm1 := p_adm1;
    v_sim_rec.access_control := p_access_control;
    v_sim_rec.authent_type := p_authent_type;
    v_sim_rec.sim_series_id := p_ss_id;
    v_sim_rec.user_id_of_change := p_user_id;
    ------------------------------
    vp_sim_card.version_open2(v_sim_rec, p_addition_imsi);
    ------------------------------
  else
    ------------------------------
    v_sim_rec := vp_sim_card.xlock_get1(v_ap_id, util_pkg.c_minus_infinity); --!_!
    ------------------------------
    if ap_is_alive(v_ap_id, p_date) --!_!
    then
      util_pkg.raise_exception(util_loc_pkg.c_ora_sim_already_imported, util_loc_pkg.c_msg_sim_already_imported);
    end if;
    ------------------------------
    v_sim_rec.imsi := p_imsi;
    v_sim_rec.sn := p_iccid;
    v_sim_rec.pin := p_pin;
    v_sim_rec.pin2 := p_pin2;
    v_sim_rec.puk := p_puk;
    v_sim_rec.puk2 := p_puk2;
    v_sim_rec.msisdn_bound := p_msisdn_bound;
    v_sim_rec.personal_account := p_personal_account;
    v_sim_rec.ki := p_ki;
    v_sim_rec.adm1 := p_adm1;
    v_sim_rec.access_control := p_access_control;
    v_sim_rec.authent_type := p_authent_type;
    v_sim_rec.sim_series_id := p_ss_id;
    v_sim_rec.user_id_of_change := p_user_id;
    ------------------------------
    vp_sim_card.version_change2(v_sim_rec, p_addition_imsi);
    ------------------------------
  end if;
  ------------------------------
  v_tmp_status := util_ri.get_ap_status2(v_sim_rec.access_point_id, p_date);
  if v_tmp_status is null or v_tmp_status != p_status
  then
    ------------------------------
    v_res := util_ext_ri.set_ap_status3
    (
      p_ap_id => v_sim_rec.access_point_id,
      p_status => p_status,
      p_date => p_date,
      p_user_id => p_user_id,
      p_lock_sc => FALSE,
      p_error_code => p_error_code,
      p_error_message => p_error_message
    );
    if not v_res
    then
      util_pkg.raise_exception(p_error_code, p_error_message);
    end if;
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  rollback to sp_import_sim_card1_ii;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure import_sim_card_i
(
  p_sim_list ct_varchar_s,
  p_sn_list ct_varchar_s,
  p_pin_list ct_varchar_s,
  p_pin2_list ct_varchar_s,
  p_puk_list ct_varchar_s,
  p_puk2_list ct_varchar_s,
  p_ki_list ct_nvarchar_s,
  p_adm1_list ct_nvarchar_s,
  p_access_control_list ct_nvarchar_s,
  p_authent_type_list ct_varchar_s,
  p_main_imsi_index ct_number,
  p_addition_imsi ct_varchar_s,
  p_user_id number,
  p_break_on_error boolean,
  p_error_code out ct_number,
  p_error_message out ct_varchar
)
is
  v_sysdate date := sysdate;
  v_main_count number;
  v_addition_count number;
  v_ss_id ct_number;
  v_host_id ct_number;
  v_tmp_imsi ct_varchar_s;
  v_pivot ct_number;
  v_mark_err ct_number;
  v_error_code_add ct_number;
  v_error_message_add ct_varchar;
  v_pivot01 ct_number;
  v_count01 number;
  v_err_code_tmp number;
  v_err_msg_tmp varchar2(4000);
  v_addition_imsi01 ct_varchar_s;
  v_count02 number;
  v_pivot02 ct_number;
  v_index02 integer;
  v_tmp_ss_id ct_number;
  v_tmp_ss_id2 ct_number;
  v_error_code number;
  v_error_message varchar2(4000);
  v_map ct_number;
  v_mark02 ct_number;
begin
  ------------------------------
  savepoint sp_import_sim_card_i;
  ------------------------------
  util_pkg.XCheckP_FSU_ct_varchar_s(p_sim_list, 'p_sim_list');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_sim_list);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_sim_list) != v_main_count, 'p_sim_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_sn_list) != v_main_count, 'p_sn_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_pin_list) != v_main_count, 'p_pin_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_pin2_list) != v_main_count, 'p_pin2_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_puk_list) != v_main_count, 'p_puk_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_puk2_list) != v_main_count, 'p_puk2_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_ki_list) != v_main_count, 'p_ki_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_adm1_list) != v_main_count, 'p_adm1_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_access_control_list) != v_main_count, 'p_access_control_list.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_authent_type_list) != v_main_count, 'p_authent_type_list.count != v_main_count');
  ------------------------------
  v_addition_count := util_pkg.get_count_ct_varchar_s(p_addition_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_addition_imsi) != v_addition_count, 'p_addition_imsi.count != v_addition_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_main_imsi_index) != v_addition_count, 'p_main_imsi_index.count != v_addition_count');
  ------------------------------
  util_ext_ri.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_code, p_error_message);
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  if v_addition_count > 0
  then
    ------------------------------
    validate_addition_sims
    (
      p_sim_imsi => p_addition_imsi,
      p_main_imsi_index => p_main_imsi_index,
      p_date => v_sysdate,
      p_break_on_error => p_break_on_error,
      p_error_code => v_error_code_add,
      p_error_message => v_error_message_add
    );
    ------------------------------
    util_pkg.set_by_pos_ct_number(p_error_code, v_error_code_add, p_main_imsi_index, TRUE);
    util_pkg.set_by_pos_ct_varchar(p_error_message, v_error_message_add, p_main_imsi_index, TRUE);
    v_mark_err := util_pkg.mark_val_ct_number(p_error_code, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_code, p_error_message);
    v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
    ------------------------------
  end if;
  ------------------------------
  v_tmp_imsi := util_pkg.get_by_pos2_ct_varchar_s(p_sim_list, v_pivot, FALSE);
  v_ss_id := util_ri.det_ss_id4imsi(v_tmp_imsi, v_sysdate, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_ss_id, null, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_sim_serie_not_found, util_loc_pkg.c_msg_sim_serie_not_found, util_pkg.c_true, p_error_code, p_error_message);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_code, p_error_message);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_host_id := util_ri.get_ss_host_id(v_ss_id, v_sysdate, FALSE);
  v_host_id := util_ri.check_host_id(v_host_id, v_sysdate, FALSE, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_host_id, null, util_pkg.c_true, util_pkg.c_false);
  util_ext_ri.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_host_not_found, util_loc_pkg.c_msg_host_not_found, util_pkg.c_true, p_error_code, p_error_message);
  util_ext_ri.xcheck_has_error(p_break_on_error, p_error_code, p_error_message);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_pivot01 := util_pkg.get_by_pos2_ct_number(v_pivot, v_pivot, TRUE);
  v_count01 := util_pkg.get_count_ct_number(v_pivot01);
  if v_count01 > 0
  then
    ------------------------------
    for v_i in 1.. v_count01
    loop
      ------------------------------
      v_index02 := v_pivot01(v_i);
      ------------------------------
      v_pivot02 := util_pkg.mark_val_ct_number(p_main_imsi_index, v_index02);
      v_addition_imsi01 := util_pkg.get_marked_ct_varchar_s(p_addition_imsi, v_pivot02, TRUE);
      ------------------------------
      import_sim_card1_ii
      (
        p_imsi => p_sim_list(v_index02),
        p_iccid => p_sn_list(v_index02),
        p_pin => p_pin_list(v_index02),
        p_pin2 => p_pin2_list(v_index02),
        p_puk => p_puk_list(v_index02),
        p_puk2 => p_puk2_list(v_index02),
        p_msisdn_bound => null,
        p_personal_account => null,
        p_ki => p_ki_list(v_index02),
        p_adm1 => p_adm1_list(v_index02),
        p_access_control => p_access_control_list(v_index02),
        p_authent_type => p_authent_type_list(v_index02),
        p_ss_id => v_ss_id(v_index02),
        p_status => util_ri.c_APSH_CODE_NOT_ACTIVATED,
        p_date => v_sysdate,
        p_addition_imsi => v_addition_imsi01,
        p_user_id => p_user_id,
        p_error_code => v_err_code_tmp,
        p_error_message => v_err_msg_tmp
      );
      ------------------------------
      p_error_code(v_index02) := v_err_code_tmp;
      p_error_message(v_index02) := v_err_msg_tmp;
      ------------------------------
      if util_pkg.get_count_ct_number(v_pivot02) > 0
      then
        util_pkg.set_val_by_pos_ct_number(v_error_code_add, v_err_code_tmp, v_pivot02);
        util_pkg.set_val_by_pos_ct_varchar(v_error_message_add, v_err_msg_tmp, v_pivot02);
      end if;
      ------------------------------
    end loop;
    ------------------------------
    v_mark_err := util_pkg.mark_val_ct_number(p_error_code, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
    util_ext_ri.xcheck_has_error(p_break_on_error, p_error_code, p_error_message);
    v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
    ------------------------------
  end if;
  ------------------------------
  v_pivot01 := util_pkg.get_by_pos2_ct_number(v_pivot, v_pivot, TRUE);
  v_count01 := util_pkg.get_count_ct_number(v_pivot01);
  if v_count01 > 0
  then
    ------------------------------
    v_tmp_ss_id := util_pkg.get_by_pos2_ct_number(v_ss_id, v_pivot01, FALSE);
    v_tmp_ss_id2 := util_pkg.filter_val_ct_number_1val(util_pkg.unique_ct_number(v_tmp_ss_id, FALSE, TRUE), NULL,FALSE);
    v_count02 := util_pkg.get_count_ct_number(v_tmp_ss_id2);
    v_map := util_pkg.map_ct_number(v_tmp_ss_id, v_tmp_ss_id2, FALSE);
    ------------------------------
    for v_j in 1..v_count02
    loop
      ------------------------------
      set_sim_series_status_validity
      (
        p_ss_id => v_tmp_ss_id2(v_j),
        p_status => util_ri.c_APPSH_PRODUCED,
        p_date => v_sysdate,
        p_user_id => p_user_id,
        p_error_code => v_error_code,
        p_error_message => v_error_message
      );
      ------------------------------
      v_mark02 := util_pkg.mark_val_ct_number(p_vals => v_map, p_marker_val => 1, p_mark_value => util_pkg.c_true, p_unmark_value => util_pkg.c_false);
      v_pivot02 := util_pkg.get_marked_ct_number(p_vals => v_pivot, p_marks => v_mark02, p_trim_empty => TRUE, p_mark_value => util_pkg.c_true);
      util_pkg.set_val_by_pos_ct_number(p_error_code, v_error_code, v_pivot02);
      util_pkg.set_val_by_pos_ct_varchar(p_error_message, v_error_message, v_pivot02);
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  rollback to sp_import_sim_card_i;
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
