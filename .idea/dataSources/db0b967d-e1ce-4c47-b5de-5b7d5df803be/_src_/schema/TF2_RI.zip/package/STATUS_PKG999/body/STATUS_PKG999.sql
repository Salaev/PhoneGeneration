CREATE package body STATUS_PKG999 is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  c_no_value_null_number         constant number := null;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ct_item(p_coll ct_item) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_ct_item(p_coll in out nocopy ct_item, p_size number)
is
  v_dif number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_item();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_item_val(p_coll in out nocopy ct_item, p_val t_item)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_item();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_item(p_coll in out nocopy ct_item, p_coll_add ct_item)
is
  v_count number;
begin
  ------------------------------
  if get_count_ct_item(p_coll_add) = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_item();
  end if;
  ------------------------------
  v_count := p_coll.count;
  ------------------------------
  p_coll.extend(p_coll_add.count);
  ------------------------------
  for v_i in p_coll_add.first..p_coll_add.last
  loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_t_item(p_val t_item, p_check_fullness boolean, p_full_fullness boolean)
is
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_fullness is null, 'p_check_fullness');
  util_pkg.XCheck_Cond_Missing(p_full_fullness is null, 'p_full_fullness');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_val.id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_val.id) != v_main_count, 'p_val.id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_val.num1) != v_main_count, 'p_val.num1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_val.str1) != v_main_count, 'p_val.str1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_val.date1) != v_main_count, 'p_val.date1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_val.num2) != v_main_count, 'p_val.num2.count != v_main_count');
  ------------------------------
  if p_check_fullness
  then
    ------------------------------
    util_pkg.XCheckP_FS_ct_number(p_val.id, 'p_val.id');
    util_pkg.XCheckP_FS_ct_varchar_s(p_val.str1, 'p_val.str1');
    util_pkg.XCheckP_FS_ct_date(p_val.date1, 'p_val.date1');
    util_pkg.XCheckP_FS_ct_number(p_val.num2, 'p_val.num2');
    ------------------------------
    if p_full_fullness
    then
      ------------------------------
      util_pkg.XCheckP_FS_ct_number(p_val.num1, 'p_val.num1');
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_ct_item(p_val ct_item, p_check_fullness boolean, p_full_fullness boolean)
is
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_fullness is null, 'p_check_fullness');
  ------------------------------
  v_main_count := get_count_ct_item(p_val);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    XCheck_t_item(p_val => p_val(v_i), p_check_fullness => p_check_fullness, p_full_fullness => p_full_fullness);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_t_item00
(
  p_id ct_number,
  p_num1 ct_number,
  p_str1 ct_varchar_s,
  p_date1 ct_date,
  p_num2 ct_number
) return t_item
is
  v_res t_item;
begin
  ------------------------------
  v_res := null;
  v_res.id := p_id;
  v_res.num1 := p_num1;
  v_res.str1 := p_str1;
  v_res.date1 := p_date1;
  v_res.num2 := p_num2;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_t_item01
(
  p_id util_pkg.cit_number,
  p_num1 util_pkg.cit_number,
  p_str1 util_pkg.cit_varchar_s,
  p_date1 util_pkg.cit_date,
  p_num2 util_pkg.cit_number
) return t_item
is
begin
  ------------------------------
  return make_t_item00
  (
    p_id => util_pkg.cast_cit2ct_number(p_coll => p_id, p_smart_cit => false),
    p_num1 => util_pkg.cast_cit2ct_number(p_coll => p_num1, p_smart_cit => false),
    p_str1 => util_pkg.cast_cit2ct_varchar_s(p_coll => p_str1, p_smart_cit => false),
    p_date1 => util_pkg.cast_cit2ct_date(p_coll => p_date1, p_smart_cit => false),
    p_num2 => util_pkg.cast_cit2ct_number(p_coll => p_num2, p_smart_cit => false)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_t_item12
(
  p_id1 number,
  p_id2 number,
  p_num11 number,
  p_num12 number,
  p_str11 varchar2,
  p_str12 varchar2,
  p_date11 date,
  p_date12 date,
  p_num21 number,
  p_num22 number
) return t_item
is
  v_id util_pkg.cit_number;
  v_num1 util_pkg.cit_number;
  v_str1 util_pkg.cit_varchar_s;
  v_date1 util_pkg.cit_date;
  v_num2 util_pkg.cit_number;
begin
  ------------------------------
  v_id(1) := p_id1;
  v_id(2) := p_id2;
  ------------------------------
  v_num1(1) := p_num11;
  v_num1(2) := p_num12;
  ------------------------------
  v_str1(1) := p_str11;
  v_str1(2) := p_str12;
  ------------------------------
  v_date1(1) := p_date11;
  v_date1(2) := p_date12;
  ------------------------------
  v_num2(1) := p_num21;
  v_num2(2) := p_num22;
  ------------------------------
  return make_t_item01
  (
    p_id => v_id,
    p_num1 => v_num1,
    p_str1 => v_str1,
    p_date1 => v_date1,
    p_num2 => v_num2
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_t_item121
(
  p_id1 number,
  p_id2 number,
  p_num1 number,
  p_str11 varchar2,
  p_str12 varchar2,
  p_date1 date,
  p_num2 number
) return t_item
is
begin
  ------------------------------
  return make_t_item12
  (
    p_id1 => p_id1,
    p_id2 => p_id2,
    p_num11 => p_num1,
    p_num12 => p_num1,
    p_str11 => p_str11,
    p_str12 => p_str12,
    p_date11 => p_date1,
    p_date12 => p_date1,
    p_num21 => p_num2,
    p_num22 => p_num2
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_ct_item121
(
  p_id1 ct_number,
  p_id2 ct_number,
  p_num1 ct_number,
  p_str11 varchar2,
  p_str12 varchar2,
  p_date1 date,
  p_num2 number
) return ct_item
is
  v_res ct_item;
  v_row t_item;
  v_main_count number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_id1, 'p_id1');
  --!_!util_pkg.XCheckP_FS_ct_number(p_id2, 'p_id2');
  --!_!util_pkg.XCheckP_FS_ct_number(p_num1, 'p_num1');
  --!_!util_pkg.XCheck_Cond_Missing(p_str11 is null, 'p_str11');
  --!_!util_pkg.XCheck_Cond_Missing(p_str12 is null, 'p_str12');
  --!_!util_pkg.XCheck_Cond_Missing(p_date1 is null, 'p_date1');
  --!_!util_pkg.XCheck_Cond_Missing(p_num2 is null, 'p_num2');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_id1);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_id1) != v_main_count, 'p_id1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_id2) != v_main_count, 'p_id2.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_num1) != v_main_count, 'p_num1.count != v_main_count');
  ------------------------------
  resize_ct_item(v_res, v_main_count);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_row := make_t_item121
    (
      p_id1 => p_id1(v_i),
      p_id2 => p_id2(v_i),
      p_num1 => p_num1(v_i),
      p_str11 => p_str11,
      p_str12 => p_str12,
      p_date1 => p_date1,
      p_num2 => p_num2
    );
    ------------------------------
    v_res(v_i) := v_row;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure prepare_as_pnlnk
(
  p_na_ids_unique ct_number,
  p_date date,
  p_na_ids_m out ct_number,
  p_na_ids_l out ct_number,
  p_pos_src_in_m_size_src out ct_number,
  p_pos_src_in_l_size_src out ct_number
)
is
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_ids_unique);
  --!_!util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_ids_unique) != v_main_count, 'p_na_ids_unique.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_na_ids_unique, 'p_na_ids_unique');
  ------------------------------
  util_ri.prepare_as_pnlnk2_fuzzy(p_na_ids_unique, p_date, p_na_ids_m, p_na_ids_l); --!_!fuzzy means that result is UNIQUE (m and l) and solid (m)
  ------------------------------
  p_pos_src_in_m_size_src := util_coll_pkg999.map_pos1in2_ct_number(p_vals1_not_unique => p_na_ids_unique, p_vals2_unique => p_na_ids_m);
  p_pos_src_in_l_size_src := util_coll_pkg999.map_pos1in2_ct_number(p_vals1_not_unique => p_na_ids_unique, p_vals2_unique => p_na_ids_l);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_as_pnlnk2
(
  p_na_ids_not_unique ct_number,
  p_date date,
  p_na_ids_m out ct_number,
  p_na_ids_l out ct_number,
  p_pos_src_in_m_size_src out ct_number,
  p_pos_src_in_l_size_src out ct_number,
  p_pos_src_in_unique_size_src out ct_number
)
is
  v_main_count number;
  v_na_ids ct_number;
  v_positions_u_m ct_number;
  v_positions_u_l ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_ids_not_unique);
  --!_!util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_ids_not_unique) != v_main_count, 'p_na_ids_not_unique.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_na_ids_not_unique, 'p_na_ids_not_unique');
  ------------------------------
  v_na_ids := util_coll_pkg999.unique_ol_ct_number(p_na_ids_not_unique);
  ------------------------------
  p_pos_src_in_unique_size_src := util_coll_pkg999.map_pos1in2_ct_number(p_vals1_not_unique => p_na_ids_not_unique, p_vals2_unique => v_na_ids);
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_pos_src_in_unique_size_src, 'p_pos_src_in_unique_size_src'); --!_!not check, just assertion
  ------------------------------
  prepare_as_pnlnk
  (
    p_na_ids_unique => v_na_ids,
    p_date => p_date,
    p_na_ids_m => p_na_ids_m,
    p_na_ids_l => p_na_ids_l,
    p_pos_src_in_m_size_src => v_positions_u_m,
    p_pos_src_in_l_size_src => v_positions_u_l
  );
  ------------------------------
  p_pos_src_in_m_size_src := util_coll_pkg999.restore_map_ct_number(p_vals_size2 => v_positions_u_m, p_vals_pos1in2_size1 => p_pos_src_in_unique_size_src);
  p_pos_src_in_l_size_src := util_coll_pkg999.restore_map_ct_number(p_vals_size2 => v_positions_u_l, p_vals_pos1in2_size1 => p_pos_src_in_unique_size_src);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xprepare_as_pnlnk2
(
  p_na_ids ct_number,
  p_ap_ids ct_number,
  p_date date,
  p_ap_ids_m out ct_number,
  p_na_ids_m out ct_number,
  p_na_ids_l out ct_number,
  p_pos_src_in_m_size_src out ct_number,
  p_pos_src_in_l_size_src out ct_number
)
is
  v_main_count number;
  v_positions ct_number;
  v_main_count_m number;
  v_ap_ids_m ct_number;
  v_ap_ids_l ct_number;
  v_ap_ids1 ct_number;
  v_ap_ids2 ct_number;
  v_na_ids ct_number;
  v_pos_nunq_in_unq ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_ids) != v_main_count, 'p_na_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ap_ids) != v_main_count, 'p_ap_ids.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_na_ids, 'p_na_ids');
  util_pkg.XCheckP_FS_ct_number(p_ap_ids, 'p_ap_ids');
  ------------------------------
  prepare_as_pnlnk2
  (
    p_na_ids_not_unique => p_na_ids,
    p_date => p_date,
    p_na_ids_m => p_na_ids_m,
    p_na_ids_l => p_na_ids_l,
    p_pos_src_in_m_size_src => p_pos_src_in_m_size_src,
    p_pos_src_in_l_size_src => p_pos_src_in_l_size_src,
    p_pos_src_in_unique_size_src => v_pos_nunq_in_unq
  );
  ------------------------------
  ------------------------------
  v_positions := util_coll_pkg999.get_mark2pos_ol(util_coll_pkg999.mark_ambig_vals_ct_number(p_vals => p_ap_ids, p_val_ids_ambig => v_pos_nunq_in_unq));
  ------------------------------
  if util_pkg.get_count_ct_number(v_positions) > 0
  then
    ------------------------------
    v_ap_ids1 := util_coll_pkg999.get_by_pos_ol_ct_number(p_ap_ids, v_positions);
    v_na_ids := util_coll_pkg999.get_by_pos_ol_ct_number(p_na_ids, v_positions);
    ------------------------------
    util_pkg.Raise_Obj2_NotUniq_ID2(v_ap_ids1(util_ri.c_index_one), v_na_ids(util_ri.c_index_one), c_name_access_point || c_delim_for || c_name_network_address);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  v_main_count_m := util_pkg.get_count_ct_number(p_na_ids_m);
  ------------------------------
  v_ap_ids_m := util_coll_pkg999.apply_map_ct_number(p_size2 => v_main_count_m, p_vals_not_unique_size1 => p_ap_ids, p_vals_pos1in2_size1 => p_pos_src_in_m_size_src);
  v_ap_ids_l := util_coll_pkg999.apply_map_ct_number(p_size2 => v_main_count_m, p_vals_not_unique_size1 => p_ap_ids, p_vals_pos1in2_size1 => p_pos_src_in_l_size_src);
  ------------------------------
  v_ap_ids1 := util_pkg.supplement_ct_number(p_vals => v_ap_ids_m, p_supplement => v_ap_ids_l, p_trim_empty => false);
  v_ap_ids2 := util_pkg.supplement_ct_number(p_vals => v_ap_ids_l, p_supplement => v_ap_ids_m, p_trim_empty => false);
  ------------------------------
  v_positions := util_coll_pkg999.get_unmark2pos_ol(util_pkg.cmp_ct_number(v_ap_ids1, v_ap_ids2));
  ------------------------------
  if util_pkg.get_count_ct_number(v_positions) > 0
  then
    ------------------------------
    v_ap_ids_m := util_coll_pkg999.get_by_pos_ol_ct_number(v_ap_ids_m, v_positions);
    v_ap_ids_l := util_coll_pkg999.get_by_pos_ol_ct_number(v_ap_ids_l, v_positions);
    v_na_ids := util_coll_pkg999.get_by_pos_ol_ct_number(p_na_ids, v_positions);
    ------------------------------
    util_pkg.Raise_Obj3_NotUniq_ID2(v_ap_ids_m(util_ri.c_index_one), v_ap_ids_l(util_ri.c_index_one), v_na_ids(util_ri.c_index_one), c_name_access_point || c_delim_for || c_name_network_address);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  p_ap_ids_m := v_ap_ids1;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;

/
