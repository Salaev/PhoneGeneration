CREATE PACKAGE RSIG_PREFIX_REPLACEMENT IS
/****************************************************************************
<header>
  <name>             	package RSIG_PREFIX_REPLACEMENT
  </name>
  <author>           	Csaba Filip - GITUS
  </author>
  <version>           1.2.16     10.11.2010    Pavel Vasiliev
                      procedure Get_Rules_Count add
                      procedure Get_Network_Elements_2 add
  </version>
  <version>           1.2.16     22.10.2010    Pavel Vasiliev
                      procedure Get_List_Of_Rules2 add
                      procedure Get_GUI_Rules2 add
  </version>
  <version>           1.2.15     12.10.2010    Pavel Vasiliev
                      procedure Get_fit_rule updated
  </version>
  <version>           1.2.14     11.10.2010    Pavel Vasiliev
                      procedure Get_Network_Elements add
                      procedure Extend_Network_Element_Group add
  </version>
  <version>           1.2.13     28.09.2010    Pavel Vasiliev
                      procedure Get_prefix_replacement updated
  </version>
  <version>           1.2.12     24.09.2010    Pavel Vasiliev
                      procedure Delete_Rule updated
  </version>
  <version>           1.2.11     16.09.2010    Pavel Vasiliev
                      procedure Get_Prfix_Replacement_Rules updated
  </version>
  <version>           1.2.10     15.09.2010    Pavel Vasiliev
                      procedure Get_GUI_Rule add
                      procedure Get_List_Of_Rules updated
  </version>
  <version>           1.2.9     13.09.2010    Pavel Vasiliev
                      procedure Get_Prfix_Replacement_Rules add
  </version>
  <version>           1.2.8     10.09.2010    Pavel Vasiliev
                      procedure Check_Rules_Conflict add
                      procedure Get_List_Of_Rules updated
  </version>
  <version>           1.2.8     07.09.2010    Pavel Vasiliev
                      procedure Delete_Rule add
                      procedure Get_List_Of_Rules updated
                      procedure Get_Rules updated
  </version>
  <version>           1.2.8     06.09.2010    Pavel Vasiliev
                      procedure Get_fit_group add
                      procedure Get_fit_rule add
                      procedure Insert_New_Rule add
                      procedure Update_Rule add
                      procedure Close_Rule add
                      procedure Get_List_Of_Rules add
                      procedure Get_Rules add
  </version>
  <version>           1.2.7     04.05.2010    Pavel Vasiliev
                      procedure Insert_Prefix_Replacement updated
                      procedure Update_Prefix_Replacement updated
                      procedure Get_GUI_Prefix_Replacement updated
                      procedure Get_Prefix_Replacement updated
  </version>
  <version>           1.2.6     04.05.2010    Pavel Vasiliev
                      procedure Get_Prefix_Replacement updated
  </version>
  <version>           1.2.5     18.03.2010    Denis Kovalchuk
                      procedure Get_Prefix_Replacement updated
  </version>
  <version>           1.2.4     28.08.2006    Petr Cepek
                      procedure Update_Prefix_Replacement updated
                      procedure Insert_Prefix_Replacement updated
  </version>
  <version>           1.2.3     26.04.2006    Petr Cepek
                      procedure Insert_Prefix_Replacement and Update_Prefix_Replacement updated
  </version>
  <version>           1.2.2     14.04.2006    Petr Cepek
                      procedure Get_Prefix_Replacement updated
  </version>
  <version>           1.2.1     10.3.2006     Petr Cepek
                      procedures Get_Prefix_Replacement,Insert_Prefix_Replacement,
                      Close_Prefix_Replacement updated, procedures Get_GUI_Prefix_Replacement,
                      Delete_Prefix_Replacement, Update_Prefix_Replacement created
  </version>
  <version>           1.2.0    30.11.2005    Petr Cepek
                      procedure Get_Prefix_Replacement updated
  </version>
  <version>
                      1.1.0    28.11.2005    Petr Cepek
                      procedures Insert_Prefix_Replacement, Close_Prefix_Replacement,
                      Get_Prefix_Replacement updated
  </version>
  <version>          	1.0.2   10.9.2003     Jaroslav Holub
                                Get_Prefix_Replacement,Close_Prefix_Replacement,
								                Insert_Prefix_Replacement - fixed for time difference
								                between client and server, date should be null
								                and it means sysdate
  </version>
  <version>          	1.0.1   5.12.2003     Csaba Filip
                                created first version
  </version>

  <Description>      	package for RSIG_PREFIX_REPLACEMENT
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
/****************************************************************************/

/****************************************************************************
<header>
  <name>             	function Insert_Prefix_Replacement
  </name>

  <author>           	Csaba Filip - GITUS
  </author>

  <version>           1.1.2   4.9.2006        Petr Cepek
                      error code added
  </version>
  <version>           1.1.1   26.04.2006      Petr Cepek
                      parameter p_description added
  </version>
  <version>           1.1.0   28.11.2005    Petr Cepek
                      rewritten according to new table structure
  </version>
  <version>           1.0.2   10.9.2004     Jaroslav Holub
                 			fixed for time difference
								      between client and server, date should be null and it means sysdate
  </version>
  <version>          	1.0.1   5.12.2003     Csaba Filip
                                created first version
  </version>

  <Description>      	The procedure inserts a record in the table PREFIX_REPLACEMENT for given EXCHANGE.

  </Description>

  <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_ORA_INVALID_INTERVAL
  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y - handle tran
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code OUT NUMBER
                      p_host_id	PREFIX_REPLACEMENT.HOST_ID%TYPE
                      p_original_prefix	PREFIX_REPLACEMENT.ORIGINAL_PREFIX%TYPE
                      p_start_date	PREFIX_REPLACEMENT.START_DATE%TYPE
                      p_end_date	PREFIX_REPLACEMENT.END_DATE%TYPE
                      p_overwritting_prefix	PREFIX_REPLACEMENT.OVERWRITING_PREFIX%TYPE
                      p_user_id_of_change	PREFIX_REPLACEMENT.USER_ID_OF_CHANGE%TYPE
  </Parameters>

</header>
****************************************************************************/
PROCEDURE Insert_Prefix_Replacement(
  p_host_id               IN   PREFIX_REPLACEMENT.HOST_ID%TYPE,
  p_location_area_id      IN   PREFIX_REPLACEMENT.LOCATION_AREA_ID%TYPE,
  p_base_station_id       IN   PREFIX_REPLACEMENT.BASE_STATION_ID%TYPE,
  p_home_network_operator IN   PREFIX_REPLACEMENT.HOME_NETWORK_OPERATOR_ID%TYPE,
  p_phone_number_length   IN   PREFIX_REPLACEMENT.ORIGINAL_PHONE_NUMBER_LENGTH%TYPE,
  p_original_prefix       IN   PREFIX_REPLACEMENT.ORIGINAL_PREFIX%TYPE,
  p_start_date            IN   PREFIX_REPLACEMENT.START_DATE%TYPE,
  p_overwritting_prefix   IN   PREFIX_REPLACEMENT.OVERWRITTING_PREFIX%TYPE,
  p_description           IN   prefix_replacement.description%TYPE,
  p_user_id_of_change     IN  NUMBER,
  handle_tran	            IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	          IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code              OUT NUMBER,
  error_message	          OUT VARCHAR2
);

/****************************************************************************
<header>
  <name>             	function Close_Prefix_Replacement
  </name>

  <author>           	Csaba Filip - GITUS
  </author>

  <version>           1.1.0   28.11.2005    Petr Cepek
                      rewritten according to new table structure
  </version>
  <version>           	1.0.2   10.9.2004     Jaroslav Holub
                 				fixed for time difference
								        between client and server, date should be null and it means sysdate
  </version>
  <version>          	1.0.1   5.12.2003     Csaba Filip
                                created first version
  </version>

  <Description>      	Procedure ends validity of given record in the table PREFIX_REPLACEMENT. The record is
                      found be HOST_ID, ORIGINAL_PREFIX a START_DATE. The record validity ends by filling
                      end_date (SYSDATE is not filled).

  </Description>

  <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_ORA_INVALID_INTERVAL

  </Prerequisites>

  <Application>	      Resource inventory
  </Application>

  <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y - handle tran
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                      error_code OUT NUMBER
                      p_host_id	PREFIX_REPLACEMENT.HOST_ID%TYPE
                      p_original_prefix	PREFIX_REPLACEMENT.ORIGINAL_PREFIX%TYPE
                      p_start_date	PREFIX_REPLACEMENT.START_DATE%TYPE
                      p_end_date	PREFIX_REPLACEMENT.END_DATE%TYPE
                      p_overwritting_prefix	PREFIX_REPLACEMENT.OVERWRITING_PREFIX%TYPE
                      p_user_id_of_change	PREFIX_REPLACEMENT.USER_ID_OF_CHANGE%TYPE
  </Parameters>

</header>
****************************************************************************/
PROCEDURE Close_Prefix_Replacement(
  handle_tran              IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code               OUT  NUMBER,
  p_prefix_replacement_id  IN   prefix_replacement.prefix_replacement_id%TYPE,
  p_end_date               IN   PREFIX_REPLACEMENT.END_DATE%TYPE,
  p_user_id_of_change      IN   PREFIX_REPLACEMENT.USER_ID_OF_CHANGE%TYPE
);

/****************************************************************************
  <header>
    <name>              procedure Get_Prefix_Replacement
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.4.0    18.03.2010    Denis Kovalchuk
                        Rewritten and splitted into 2 parts query to
                        decrease load on server 
    </version>
    <version>           1.3.1    14.04.2006    Petr Cepek
                        bug when parameter end_date is set to not null fixed
    </version>
    <version>           1.3.0    6.2.2006     Petr Cepek
                        for parameter p_validity_start_date added default value sysdate
    </version>
    <version>           1.2.0   30.11.2005    Petr Cepek
                        output cursore changed
    </version>
    <version>           1.1.0   28.11.2005    Petr Cepek
                        rewritten according to new table structure
    </version>
  	<version>           1.0.2   10.9.2004     Jaroslav Holub
                 				fixed for time difference
								between client and server, date should be null and it means sysdate
  	</version>
    <version>           1.0.1   8.12.2003     Jan Stodulka
                                created first version
    </version>

    <Description>     This procedure will be involved in requirements for changes in Resource Inventory system.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_INTERVAL
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code            - Error code
                        p_validity_start_date - Start date of prefix replacement
                        p_validity_end_date   - End date of prefix replacement
                        p_host_code           - Host code
                        p_result              - ref cursor (ORIGINAL PREFIX, OVERWRITING PREFIX, START DATE, END DATE)
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Get_Prefix_Replacement(
    error_code            OUT  NUMBER,
    p_validity_start_date IN   PREFIX_REPLACEMENT.START_DATE%TYPE,
    p_validity_end_date   IN   PREFIX_REPLACEMENT.END_DATE%TYPE,
    p_host_code           IN   HOST.HOST_CODE%TYPE,
    p_result              OUT  RSIG_UTILS.REF_CURSOR
  );

/****************************************************************************
<header>
  <name>            procedure Get_GUI_Prefix_Replacement
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  1.3.2006 13:43:59  -  created
  </version>

  <Description>     Procedure returns recordset of prefix replacements for
                    given network operator or prefixes replacements which
                    belong to all network operators.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_GUI_Prefix_Replacement(
  p_network_operator_id    IN  network_operator.network_operator_id%TYPE,
  p_show_deleted           IN  CHAR,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure Delete_Prefix_Replacement
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0  8.3.2006  -  created
  </version>

  <Description>     Procedure set given prefix replacement interval
                    as a deleted from current time.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Delete_Prefix_Replacement(
  p_prefix_replacement_id  IN  prefix_replacement.prefix_replacement_id%TYPE,
  p_user_id_of_change      IN  NUMBER,
  handle_tran	             IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	           IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message	           OUT VARCHAR2
);

/****************************************************************************
<header>
  <name>            procedure Update_Prefix_Replacement
  </name>

  <author>          Petr Cepek
  </author>

  <version>         1.2  28.08.2006      Petr Cepek
                    error code changed
  </version>
  <version>         1.1  26.04.2006      Petr Cepek
                    parameter p_description added
  </version>
  <version>
                    1.0  8.3.2006  -  created
  </version>

  <Description>     Procedure change overwritting prefix for specified
                    prefix replacement interval.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Update_Prefix_Replacement(
  p_prefix_replacement_id  IN  prefix_replacement.prefix_replacement_id%TYPE,
  p_host_id                IN   PREFIX_REPLACEMENT.HOST_ID%TYPE,
  p_location_area_id       IN   PREFIX_REPLACEMENT.LOCATION_AREA_ID%TYPE,
  p_base_station_id        IN   PREFIX_REPLACEMENT.BASE_STATION_ID%TYPE,
  p_home_network_operator  IN   PREFIX_REPLACEMENT.HOME_NETWORK_OPERATOR_ID%TYPE,
  p_phone_number_length    IN   PREFIX_REPLACEMENT.ORIGINAL_PHONE_NUMBER_LENGTH%TYPE,
  p_original_prefix        IN   PREFIX_REPLACEMENT.ORIGINAL_PREFIX%TYPE,
  p_start_date             IN   PREFIX_REPLACEMENT.START_DATE%TYPE,
  p_overwritting_prefix    IN   PREFIX_REPLACEMENT.OVERWRITTING_PREFIX%TYPE,
  p_description            IN   prefix_replacement.description%TYPE,
  p_user_id_of_change      IN  NUMBER,
  handle_tran	             IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	           IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message	           OUT VARCHAR2
);

PROCEDURE Get_fit_group(
  p_network_operator_id        IN   common.t_varchar2_10,
  p_host_id                    IN   common.t_varchar2_10,
  p_location_area_id           IN   common.t_varchar2_10,
  p_base_station_id            IN   common.t_varchar2_10,
  p_user_id_of_change          IN   NUMBER,
  p_handle_tran	               IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2,
  p_group_id                   OUT NUMBER
);

PROCEDURE Get_fit_rule(
  p_original_prefix            IN   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE,
  p_overwritting_prefix        IN   PREFIX_REPLACEMENT_RULES.OVERWRITTING_PREFIX%TYPE,
  p_min_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE,
  p_max_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE,
  p_description                IN   PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE,
  p_home_network_operator_id   IN   PREFIX_REPLACEMENT_RULES.HOME_NETWORK_OPERATOR_ID%TYPE,
  p_user_id_of_change          IN   NUMBER,
  p_handle_tran	               IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2,
  p_rule_id                    OUT NUMBER
);

PROCEDURE Insert_New_Rule(
  p_original_prefix            IN   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE,
  p_overwritting_prefix        IN   PREFIX_REPLACEMENT_RULES.OVERWRITTING_PREFIX%TYPE,
  p_min_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE,
  p_max_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE,
  p_description                IN   PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE,
  p_home_network_operator_id   IN   PREFIX_REPLACEMENT_RULES.HOME_NETWORK_OPERATOR_ID%TYPE,
  p_start_date                 IN   DATE,
  p_end_date                   IN   DATE,
  p_network_operator_id        IN   common.t_varchar2_10,
  p_host_id                    IN   common.t_varchar2_10,
  p_location_area_id           IN   common.t_varchar2_10,
  p_base_station_id            IN   common.t_varchar2_10,
  p_user_id_of_change          IN   NUMBER,
  p_handle_tran	               IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_row_identifer              OUT  NUMBER,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);

PROCEDURE Close_Rule(
  p_link_id                    IN   NUMBER,
  p_end_date                   IN   DATE,
  p_network_operator_id        IN   common.t_varchar2_10,
  p_host_id                    IN   common.t_varchar2_10,
  p_location_area_id           IN   common.t_varchar2_10,
  p_base_station_id            IN   common.t_varchar2_10,
  p_close_all_group            IN   CHAR DEFAULT rsig_utils.c_NO,
  p_user_id_of_change          IN   NUMBER,
  p_handle_tran	               IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_row_identifer              OUT  NUMBER,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);

PROCEDURE Delete_Rule(
  p_link_id                    IN   NUMBER,
  p_network_operator_id        IN   common.t_varchar2_10,
  p_host_id                    IN   common.t_varchar2_10,
  p_location_area_id           IN   common.t_varchar2_10,
  p_base_station_id            IN   common.t_varchar2_10,
  p_delete_all_group            IN   CHAR DEFAULT rsig_utils.c_NO,
  p_user_id_of_change          IN   NUMBER,
  p_handle_tran	               IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_row_identifer              OUT  NUMBER,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);

PROCEDURE Update_Rule(
  p_link_id                    IN   NUMBER,
  p_original_prefix            IN   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE,
  p_overwritting_prefix        IN   PREFIX_REPLACEMENT_RULES.OVERWRITTING_PREFIX%TYPE,
  p_min_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE,
  p_max_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE,
  p_description                IN   PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE,
  p_home_network_operator_id   IN   PREFIX_REPLACEMENT_RULES.HOME_NETWORK_OPERATOR_ID%TYPE,
  p_start_date                 IN   DATE,
  p_end_date                   IN   DATE,
  p_network_operator_id        IN   common.t_varchar2_10,
  p_host_id                    IN   common.t_varchar2_10,
  p_location_area_id           IN   common.t_varchar2_10,
  p_base_station_id            IN   common.t_varchar2_10,
  p_group_operation            IN   CHAR DEFAULT rsig_utils.c_NO,
  p_user_id_of_change          IN   NUMBER,
  p_handle_tran	               IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);

PROCEDURE Check_Rules_Conflict(
  p_link_except_id             IN   NUMBER,
  p_original_prefix            IN   PREFIX_REPLACEMENT_RULES.ORIGINAL_PREFIX%TYPE,
  p_min_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MIN_PHONE_LENGTH%TYPE,
  p_max_phone_number_length    IN   PREFIX_REPLACEMENT_RULES.MAX_PHONE_LENGTH%TYPE,
  p_home_network_operator_id   IN   PREFIX_REPLACEMENT_RULES.HOME_NETWORK_OPERATOR_ID%TYPE,
  p_start_date                 IN   DATE,
  p_end_date                   IN   DATE,
  p_network_operator_id        IN   common.t_varchar2_10,
  p_host_id                    IN   common.t_varchar2_10,
  p_location_area_id           IN   common.t_varchar2_10,
  p_base_station_id            IN   common.t_varchar2_10,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Get_List_Of_Rules
    </name>

    <author>             Pavel Vasiliev
    </author>
    <version>           1.0.1   06.09.2010     Pavel Vasiliev
                                created first version
    </version>

    <Description>     This procedure will be involved in requirements for changes in Resource Inventory system.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_INTERVAL
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        
                        p_network_operator_id            - Network operator id
                        p_network_operator_name
                        p_network_operator_code
                        p_host_id
                        p_host_name
                        p_host_code
                        p_location_area_id
                        p_location_area_name
                        p_location_area_code
                        p_base_station_id
                        p_base_station_name
                        p_base_station_code
                        p_original_prefix_mask
                        p_overwritting_prefix_mask
                        p_min_phone_number_length
                        p_max_phone_number_length
                        p_description
                        p_validity_date                  - Date of prefix replacement
                        p_show_deleted
                        p_raise_error                    - Rise exception on error ('Y','N')
                        p_result                         - ref cursor 
                        p_error_code                     - Error code
                        p_error_message                  - Error message
    </Parameters>

  </header>
/****************************************************************************/
PROCEDURE Get_List_Of_Rules(
  p_network_operator_id        IN   NUMBER,
  p_network_operator_name      IN   VARCHAR2 DEFAULT '%',
  p_network_operator_code      IN   VARCHAR2 DEFAULT '%',
  p_host_id                    IN   NUMBER,
  p_host_name                  IN   VARCHAR2 DEFAULT '%',
  p_host_code                  IN   VARCHAR2 DEFAULT '%',
  p_location_area_id           IN   NUMBER,
  p_location_area_name         IN   VARCHAR2 DEFAULT '%',
  p_location_area_code         IN   VARCHAR2 DEFAULT '%',
  p_base_station_id            IN   NUMBER,
  p_base_station_name          IN   VARCHAR2 DEFAULT '%',
  p_base_station_code          IN   VARCHAR2 DEFAULT '%',
  p_original_prefix_mask       IN   VARCHAR2 DEFAULT '%',
  p_overwritting_prefix_mask   IN   VARCHAR2 DEFAULT '%',
  p_min_phone_number_length    IN   NUMBER,
  p_max_phone_number_length    IN   NUMBER,
  p_description                IN   VARCHAR2 DEFAULT '%',
  p_validity_date              IN   DATE,
  p_show_deleted               IN   CHAR,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Get_List_Of_Rules2
    </name>

    <author>             Pavel Vasiliev
    </author>
    <version>           1.0.1   22.10.2010     Pavel Vasiliev
                                created first version
    </version>

    <Description>     This procedure will be involved in requirements for changes in Resource Inventory system.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_INTERVAL
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        
                        p_network_operator_id            - Network operator id
                        p_network_operator_name
                        p_network_operator_code
                        p_host_id
                        p_host_name
                        p_host_code
                        p_location_area_id
                        p_location_area_name
                        p_location_area_code
                        p_base_station_id
                        p_base_station_name
                        p_base_station_code
                        p_original_prefix_mask
                        p_overwritting_prefix_mask
                        p_min_phone_number_length
                        p_max_phone_number_length
                        p_description
                        p_validity_date                  - Date of prefix replacement
                        p_show_deleted
                        p_raise_error                    - Rise exception on error ('Y','N')
                        p_result                         - ref cursor 
                        p_error_code                     - Error code
                        p_error_message                  - Error message
    </Parameters>

  </header>
/****************************************************************************/
PROCEDURE Get_List_Of_Rules2(
  p_network_operator_id        IN   NUMBER,
  p_network_operator_name      IN   VARCHAR2 DEFAULT '%',
  p_network_operator_code      IN   VARCHAR2 DEFAULT '%',
  p_host_id                    IN   NUMBER,
  p_host_name                  IN   VARCHAR2 DEFAULT '%',
  p_host_code                  IN   VARCHAR2 DEFAULT '%',
  p_location_area_id           IN   NUMBER,
  p_location_area_name         IN   VARCHAR2 DEFAULT '%',
  p_location_area_code         IN   VARCHAR2 DEFAULT '%',
  p_base_station_id            IN   NUMBER,
  p_base_station_name          IN   VARCHAR2 DEFAULT '%',
  p_base_station_code          IN   VARCHAR2 DEFAULT '%',
  p_original_prefix_mask       IN   VARCHAR2 DEFAULT '%',
  p_overwritting_prefix_mask   IN   VARCHAR2 DEFAULT '%',
  p_min_phone_number_length    IN   NUMBER,
  p_max_phone_number_length    IN   NUMBER,
  p_description                IN   VARCHAR2 DEFAULT '%',
  p_validity_date              IN   DATE,
  p_show_deleted               IN   CHAR,
  p_return_rows_count          IN   NUMBER,
  p_return_total_count_value   IN   CHAR DEFAULT rsig_utils.c_NO,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_total_count_value          OUT  NUMBER,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Get_GUI_Rules
    </name>

    <author>             Pavel Vasiliev
    </author>
    <version>           1.0.1   15.09.2010     Pavel Vasiliev
                                created first version
    </version>

    <Description>     This procedure will be involved in requirements for changes in Resource Inventory system.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_INTERVAL
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        
                        p_network_operator_id            - Network operator id
                        p_show_deleted
                        p_raise_error                    - Rise exception on error ('Y','N')
                        p_result                         - ref cursor 
                        p_error_code                     - Error code
                        p_error_message                  - Error message
    </Parameters>

  </header>
/****************************************************************************/
PROCEDURE Get_GUI_Rules(
  p_network_operator_id        IN   NUMBER,
  p_show_deleted               IN   CHAR,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Get_GUI_Rules2
    </name>

    <author>             Pavel Vasiliev
    </author>
    <version>           1.0.1   22.10.2010     Pavel Vasiliev
                                created first version
    </version>

    <Description>     This procedure will be involved in requirements for changes in Resource Inventory system.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_INTERVAL
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        
                        p_network_operator_id            - Network operator id
                        p_show_deleted
                        p_raise_error                    - Rise exception on error ('Y','N')
                        p_result                         - ref cursor 
                        p_error_code                     - Error code
                        p_error_message                  - Error message
    </Parameters>

  </header>
/****************************************************************************/
PROCEDURE Get_GUI_Rules2(
  p_network_operator_id        IN   NUMBER,
  p_show_deleted               IN   CHAR,
  p_return_rows_count          IN   NUMBER,
  p_return_total_count_value   IN   CHAR DEFAULT rsig_utils.c_NO,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_total_count_value          OUT  NUMBER,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Get_Rules
    </name>

    <author>             Pavel Vasiliev
    </author>
    <version>           1.0.1   06.09.2010     Pavel Vasiliev
                                created first version
    </version>

    <Description>     This procedure will be involved in requirements for changes in Resource Inventory system.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_INTERVAL
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        
                        p_link_id                        - Prefix_replacement_groups id
                        p_network_operator_id            - Network operator id
                        p_validity_date                  - Date of prefix replacement
                        p_raise_error                    - Rise exception on error ('Y','N')
                        p_result                         - ref cursor 
                        p_error_code                     - Error code
                        p_error_message                  - Error message
    </Parameters>

  </header>
/****************************************************************************/
PROCEDURE Get_Rules(
  p_link_id                    IN   NUMBER,
  p_network_operator_id        IN   NUMBER,
  p_validity_date              IN   DATE,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Get_Prfix_Replacement_Rules
    </name>

    <author>             Pavel Vasiliev
    </author>
    <version>           1.0.1   13.09.2010     Pavel Vasiliev
                                created first version
    </version>

    <Description>     This procedure will be involved in requirements for changes in Resource Inventory system.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_INTERVAL
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        
                        p_network_operator_id            - Network operator id
                        p_host_id                        - Host id
                        p_location_area_id               - Location area id
                        p_base_station_id                - Base station id
                        p_validity_date_start            - Start date of prefix replacement
                        p_validity_date_end              - End date of prefix replacement
                        p_raise_error                    - Rise exception on error ('Y','N')
                        p_result                         - ref cursor 
                        p_error_code                     - Error code
                        p_error_message                  - Error message
    </Parameters>

  </header>
/****************************************************************************/
PROCEDURE Get_Prfix_Replacement_Rules(
  p_network_operator_id        IN   PREFIX_REPLACEMENT_NET_EL.NETWORK_OPERATOR_ID%TYPE,
  p_host_id                    IN   PREFIX_REPLACEMENT_NET_EL.HOST_ID%TYPE,
  p_location_area_id           IN   PREFIX_REPLACEMENT_NET_EL.LOCATION_AREA_ID%TYPE,
  p_base_station_id            IN   PREFIX_REPLACEMENT_NET_EL.BASE_STATION_ID%TYPE,
  p_validity_date_start        IN   DATE,
  p_validity_date_end          IN   DATE,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Get_Network_Elements
    </name>

    <author>             Pavel Vasiliev
    </author>
    <version>           1.0.1   07.10.2010     Pavel Vasiliev
                                created first version
    </version>

    <Description>     

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        
                        p_result                         - ref cursor 
                        p_error_code                     - Error code
                        p_error_message                  - Error message
    </Parameters>

  </header>
/****************************************************************************/
PROCEDURE Get_Network_Elements(
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Get_Network_Elements
    </name>

    <author>             Pavel Vasiliev
    </author>
    <version>           1.0.0   11.10.2010     Pavel Vasiliev
                                created first version
    </version>
  </header>
/****************************************************************************/
PROCEDURE Extend_Network_Element_Group(
  p_old_link_id                    IN   NUMBER,
  p_upd_link_id                    IN   NUMBER,
  p_new_description                IN   PREFIX_REPLACEMENT_RULES.DESCRIPTION%TYPE,
  p_new_start_date                 IN   DATE,
  p_new_end_date                   IN   DATE,
  p_new_network_operator_id        IN   common.t_varchar2_10,
  p_new_host_id                    IN   common.t_varchar2_10,
  p_new_location_area_id           IN   common.t_varchar2_10,
  p_new_base_station_id            IN   common.t_varchar2_10,
  p_group_operation                IN   CHAR DEFAULT rsig_utils.c_NO,
  p_user_id_of_change              IN   NUMBER,
  p_handle_tran	                   IN   CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error	                   IN   CHAR DEFAULT rsig_utils.c_NO,
  p_error_code                     OUT  NUMBER,
  p_error_message	                 OUT  VARCHAR2
);

/****************************************************************************
  <header>
    <name>              procedure Get_Rules_Count
    </name>

    <author>             Pavel Vasiliev
    </author>
    <version>           1.0.0   10.11.2010     Pavel Vasiliev
                                created first version
    </version>
  </header>
/****************************************************************************/
PROCEDURE Get_Rules_Count(
  p_show_deleted               IN   CHAR,
  p_raise_error	               IN   CHAR DEFAULT rsig_utils.c_NO,
  p_total_count_value          OUT  NUMBER,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);



/****************************************************************************
  <header>
    <name>              procedure Get_Network_Elements
    </name>

    <author>             Pavel Vasiliev
    </author>
    <version>           1.0.1   10.11.2010     Pavel Vasiliev
                                created first version
    </version>

    <Description>     

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        
                        p_result                         - ref cursor 
                        p_error_code                     - Error code
                        p_error_message                  - Error message
    </Parameters>

  </header>
/****************************************************************************/
PROCEDURE Get_Network_Elements_2(
  p_level                      IN NUMBER,
  p_result                     OUT  SYS_REFCURSOR,
  p_error_code                 OUT  NUMBER,
  p_error_message	             OUT  VARCHAR2
);

END RSIG_PREFIX_REPLACEMENT;
/
