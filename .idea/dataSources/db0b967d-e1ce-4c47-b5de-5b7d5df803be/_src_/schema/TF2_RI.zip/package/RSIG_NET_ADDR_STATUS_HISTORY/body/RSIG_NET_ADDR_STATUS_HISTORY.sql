CREATE PACKAGE BODY "RSIG_NET_ADDR_STATUS_HISTORY" IS

---------------------------------------------
--     PROCEDURE Exist_Status_Code
---------------------------------------------

PROCEDURE Exist_Status_Code(p_status_code IN NETWORK_ADDRESS_STATUS.NET_ADDRESS_STATUS_CODE%TYPE) IS
  v_pom number;
BEGIN
  select 1 into v_pom from NETWORK_ADDRESS_STATUS where TRIM(NET_ADDRESS_STATUS_CODE) = TRIM(p_status_code);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Exist_Status_Code;

---------------------------------------------
--     PROCEDURE Is_Interval_Overlap
---------------------------------------------

PROCEDURE Is_Interval_Overlap
(
  p_network_address_id IN NETWORK_ADDRESS_STATUS_HISTORY.NETWORK_ADDRESS_ID%TYPE,
  p_status_code        IN NETWORK_ADDRESS_STATUS_HISTORY.NET_ADDRESS_STATUS_CODE%TYPE,
  p_start_date         IN NETWORK_ADDRESS_STATUS_HISTORY.START_DATE%TYPE DEFAULT NULL,
  p_end_date           IN NETWORK_ADDRESS_STATUS_HISTORY.END_DATE%TYPE DEFAULT NULL
) IS
  v_start_date              DATE;
  v_net_address_status_code NETWORK_ADDRESS_STATUS_HISTORY.NET_ADDRESS_STATUS_CODE%TYPE;
  v_st_date                 DATE;
BEGIN

  v_st_date := nvl(p_start_date, SYSDATE);
  -- NOT NULL test of input parameters
  IF p_status_code IS NULL
     or p_network_address_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  -- test start date
  IF v_st_date < RSIG_UTILS.c_MIN_DATE THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;

  -- test end date
  IF p_end_date IS NOT NULL
     AND p_end_date < RSIG_UTILS.c_MIN_DATE THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;

  IF (p_end_date IS NOT NULL)
     AND (p_end_date < v_st_date) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;

   -- get info about last period
    /*select START_DATE, NET_ADDRESS_STATUS_CODE
      into v_start_date, v_net_address_status_code
      from (select START_DATE, NET_ADDRESS_STATUS_CODE



              from NETWORK_ADDRESS_STATUS_HISTORY
              where NETWORK_ADDRESS_ID = p_network_address_id
              order by START_DATE desc)
      where rownum = 1;*/

    select START_DATE, NET_ADDRESS_STATUS_CODE
    into v_start_date, v_net_address_status_code
    from NETWORK_ADDRESS_STATUS_HISTORY
    where NETWORK_ADDRESS_ID = p_network_address_id
      and end_date is null
    for update;

  -- if some period is overlapped with new one
  IF v_st_date <= v_start_date THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DATE_OVERLAP, '');
  END IF;

  -- previous period can't have the same status
  IF TRIM(v_net_address_status_code) = TRIM(p_status_code) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_SAME_NET_ADDR_STATUS, '');
  END IF;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    null;
END Is_Interval_Overlap;

---------------------------------------------
--     PROCEDURE Insert_Interval
---------------------------------------------

PROCEDURE Insert_Interval
(
  handle_tran               CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                OUT NUMBER,
  p_net_address_status_code IN NETWORK_ADDRESS_STATUS_HISTORY.NET_ADDRESS_STATUS_CODE%TYPE,
  p_network_address_id      IN NETWORK_ADDRESS_STATUS_HISTORY.NETWORK_ADDRESS_ID%TYPE,
  p_start_date              IN NETWORK_ADDRESS_STATUS_HISTORY.START_DATE%TYPE,
  p_user_id_of_change       IN NETWORK_ADDRESS_STATUS_HISTORY.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NET_ADDR_STATUS_HISTORY.Insert_Interval';
  v_start_date   DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;
  v_start_date := nvl(p_start_date, SYSDATE);
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint insert_interval_a;
  END IF;

  -- there is no check if p_network_address_id, p_net_address_status_code, p_start_date are null
  -- these checks are in Is_Interval_Overlap

  Is_Interval_Overlap(p_network_address_id, p_net_address_status_code, v_start_date, null);


  -- close previous interval
  update NETWORK_ADDRESS_STATUS_HISTORY
     set END_DATE          = v_start_date - RSIG_UTILS.c_INTERVAL_DIFFERENCE,
         DATE_OF_CHANGE    = sysdate,
         USER_ID_OF_CHANGE = p_user_id_of_change
   where NETWORK_ADDRESS_ID = p_network_address_id
     and (END_DATE is NULL or END_DATE > v_start_date);

  -- create new interval
  insert into NETWORK_ADDRESS_STATUS_HISTORY
    (NET_ADDRESS_STATUS_CODE,
     NETWORK_ADDRESS_ID,
     START_DATE,
     DATE_OF_CHANGE,
     USER_ID_OF_CHANGE)
  values
    (p_net_address_status_code,
     p_network_address_id,
     v_start_date,
     sysdate,
     p_user_id_of_change);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint insert_interval_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Insert_Interval;

---------------------------------------------
--     PROCEDURE Close_Interval
---------------------------------------------

PROCEDURE Close_Interval
(
  handle_tran          CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code           OUT NUMBER,
  p_start_date         IN NETWORK_ADDRESS_STATUS_HISTORY.START_DATE%TYPE,
  p_network_address_id IN NETWORK_ADDRESS_STATUS_HISTORY.NETWORK_ADDRESS_ID%TYPE,
  p_end_date           IN NETWORK_ADDRESS_STATUS_HISTORY.END_DATE%TYPE,
  p_user_id_of_change  IN NETWORK_ADDRESS_STATUS_HISTORY.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NET_ADDR_STATUS_HISTORY.Close_Interval';
  v_end_date     DATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint close_interval_a;
  END IF;

  /*    IF p_end_date IS NULL THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
      END IF;
  */
  v_end_date := nvl(p_end_date, SYSDATE);
  Is_Interval_Overlap(p_network_address_id,
                      '0', -- no need to check status
                      p_start_date + RSIG_UTILS.c_INTERVAL_DIFFERENCE,
                      v_end_date);

  DECLARE
    end_date_h NETWORK_ADDRESS_STATUS_HISTORY.END_DATE%TYPE;
  BEGIN
    select END_DATE
      into end_date_h
      from NETWORK_ADDRESS_STATUS_HISTORY
     where NETWORK_ADDRESS_ID = p_network_address_id
       and START_DATE = p_start_date
       and END_DATE is null;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
  END;

  update NETWORK_ADDRESS_STATUS_HISTORY
     set END_DATE          = v_end_date,
         DATE_OF_CHANGE    = sysdate,
         USER_ID_OF_CHANGE = p_user_id_of_change
   where START_DATE = p_start_date
     and NETWORK_ADDRESS_ID = p_network_address_id
     and END_DATE is null;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint close_interval_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Close_Interval;

---------------------------------------------
--     PROCEDURE Close_Packet_Of_Intervals
---------------------------------------------

PROCEDURE Close_Packet_Of_Intervals
(
  handle_tran           CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_start_date          IN NETWORK_ADDRESS_STATUS_HISTORY.START_DATE%TYPE,
  p_packet_of_intervals IN VARCHAR2,
  p_end_date            IN NETWORK_ADDRESS_STATUS_HISTORY.END_DATE%TYPE,
  p_user_id_of_change   IN NETWORK_ADDRESS_STATUS_HISTORY.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source        VARCHAR2(60) := 'RSIG_NET_ADDR_STATUS_HISTORY.Close_Packet_Of_Intervals';
  v_packet_of_intervals RSIG_UTILS.Type_Packet_Of_Intervals;
  v_handle_tran         CHAR(1);
  v_end_date            DATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;
  v_handle_tran := RSIG_UTILS.Get_Handle_Tran_For_Call_Proc(handle_tran);
  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint close_packet_of_intervals_a;
  END IF;

  v_end_date := nvl(p_end_date, SYSDATE);
  IF RSIG_UTILS.Get_Packet_Of_Intervals(p_packet_of_intervals, v_packet_of_intervals) = RSIG_UTILS.c_FALSE THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PACKET, '');
  END IF;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_BEFORE_LOOP,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  FOR p_packet_of_intervals_index IN nvl(v_packet_of_intervals.FIRST, 1) .. nvl(v_packet_of_intervals.LAST, 0)
  LOOP
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_IN_LOOP,
                         RSIG_UTILS.c_DEBUG_LEVEL_3,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);
    Close_Interval(v_handle_tran,
                   error_code,
                   p_start_date,
                   v_packet_of_intervals(p_packet_of_intervals_index),
                   v_end_date,
                   p_user_id_of_change);
    IF error_code != RSIG_UTILS.c_OK THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_LAST_ERROR, '');
    END IF;
  END LOOP;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_AFTER_LOOP,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint close_packet_of_intervals_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Close_Packet_Of_Intervals;

END;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_NET_ADDR_STATUS_HISTORY.pkb,v 1.30 2003/12/22 13:03:48 rhejduk Exp $
/
