CREATE package body util_ext_ri is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_first_error_pos(p_error_code ct_number) return number
is
begin
  ------------------------------
  return nullif(util_pkg.index_of_ct_number(p_error_code, util_pkg.c_ora_ok, 1, util_pkg.C_FALSE), util_pkg.c_index_not_found);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_first_error(p_error_code ct_number, p_error_message ct_varchar, p_error_code2 out number, p_error_message2 out varchar2)
is
  v_index number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_error_code) != util_pkg.get_count_ct_varchar(p_error_message), 'p_error_code.count != p_error_message.count');
  ------------------------------
  util_pkg.set_ok(p_error_code2, p_error_message2);
  ------------------------------
  v_index := get_first_error_pos(p_error_code);
  ------------------------------
  if v_index is not null
  then
    ------------------------------
    p_error_code2 := p_error_code(v_index);
    p_error_message2 := p_error_message(v_index);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_common_error(p_main_count number, p_error_code number, p_error_message varchar2, p_error_code2 out ct_number, p_error_message2 out ct_varchar, p_allow_nulls boolean := false)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_main_count is null, 'p_main_count');
  util_pkg.XCheck_Cond_Missing(p_allow_nulls is null, 'p_allow_nulls');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(NOT p_allow_nulls and p_error_code is null, 'p_error_code');
  util_pkg.XCheck_Cond_Missing(NOT p_allow_nulls and p_error_message is null, 'p_error_message');
  ------------------------------
  util_pkg.XCheck_size0(p_main_count, 'p_main_count');
  ------------------------------
  p_error_code2 := util_pkg.make_ct_number(p_main_count, p_error_code);
  p_error_message2 := util_pkg.make_ct_varchar(p_main_count, util_pkg.cut_err_msg(p_error_message));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_group_error_message
(
  p_problem_id number,
  p_problem_index number,
  p_group_error_code number,
  p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on id=' || util_pkg.number_to_char(p_problem_id)
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_group_error_message2
(
  p_problem_id number,
  p_problem_code varchar2,
  p_problem_index number,
  p_group_error_code number,
  p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on id=' || util_pkg.number_to_char(p_problem_id)
    || util_pkg.c_msg_delim02 || 'code=' || p_problem_code
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_group_error_message3
(
  p_problem_id number,
  p_problem_code varchar2,
  p_problem_name varchar2,
  p_problem_index number,
  p_group_error_code number,
  p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on id=' || util_pkg.number_to_char(p_problem_id)
    || util_pkg.c_msg_delim02 || 'code=' || p_problem_code
    || util_pkg.c_msg_delim02 || 'name=' || p_problem_name
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_group_error_message4
(
  p_problem_index number,
  p_group_error_code number,
  p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_error_message4val_char
(
  p_problem_value varchar2,
  p_problem_index number,
  p_group_error_code number,
  p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on value=' || p_problem_value
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_error_message4val_char2
(
  p_problem_value1 varchar2,
  p_problem_value2 varchar2,
  p_problem_index number,
  p_group_error_code number,
  p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on value1=' || p_problem_value1
    || util_pkg.c_msg_delim02 || 'value2=' || p_problem_value2
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_error_message4val_num
(
  p_problem_value number,
  p_problem_index number,
  p_group_error_code number,
  p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on value=' || util_pkg.number_to_char(p_problem_value)
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_error_message4val_num2
(
  p_problem_value1 number,
  p_problem_value2 number,
  p_problem_index number,
  p_group_error_code number,
  p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on value1=' || util_pkg.number_to_char(p_problem_value1)
    || util_pkg.c_msg_delim02 || 'value2=' || util_pkg.number_to_char(p_problem_value2)
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_group_error_params
(
  p_problem_id number,
  p_problem_index number,
  p_group_start number,
  p_group_size number,
  p_group_error_code number,
  p_group_error_message varchar2,
  p_error_code ct_number,
  p_error_message ct_varchar,
  p_main_count out number
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_problem_id is null, 'p_problem_id');
  util_pkg.XCheck_Cond_Missing(p_problem_index is null, 'p_problem_index');
  util_pkg.XCheck_Cond_Missing(p_group_start is null, 'p_group_start');
  util_pkg.XCheck_Cond_Missing(p_group_size is null, 'p_group_size');
  util_pkg.XCheck_Cond_Missing(p_group_error_code is null, 'p_group_error_code');
  util_pkg.XCheck_Cond_Missing(p_group_error_message is null, 'p_group_error_message');
  util_pkg.XCheckP_ct_number(p_error_code, 'p_error_code');
  util_pkg.XCheckP_ct_varchar(p_error_message, 'p_error_message');
  ------------------------------
  p_main_count := p_error_code.count;
  util_pkg.XCheck_Cond_Invalid(p_error_code.count != p_main_count, 'p_error_code.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid(p_error_message.count != p_main_count, 'p_error_message.count != p_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_problem_index not between 1 and p_main_count, 'p_problem_index not between 1 and p_main_count');
  util_pkg.XCheck_Cond_Invalid(p_group_start not between 1 and p_main_count, 'p_group_start not between 1 and p_main_count');
  util_pkg.XCheck_Cond_Invalid(p_group_size not between 1 and p_main_count, 'p_group_size not between 1 and p_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_problem_index < p_group_start, 'p_problem_index < p_group_start');
  util_pkg.XCheck_Cond_Invalid(p_problem_index > p_group_start + p_group_size - 1, 'p_problem_index > p_group_start + p_group_size - 1');
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_group_error_for_grp_head
(
  p_problem_id number,
  p_problem_index number,
  p_group_start number,
  p_group_size number,
  p_group_error_code number,
  p_group_error_message varchar2,
  p_error_code in out nocopy ct_number,
  p_error_message in out nocopy ct_varchar
)
is
  v_main_count number;
  v_msg varchar2(4000);
begin
  ------------------------------
  xcheck_group_error_params
  (
    p_problem_id => p_problem_id,
    p_problem_index => p_problem_index,
    p_group_start => p_group_start,
    p_group_size => p_group_size,
    p_group_error_code => p_group_error_code,
    p_group_error_message => p_group_error_message,
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_main_count => v_main_count
  );
  ------------------------------
  v_msg := make_group_error_message
  (
    p_problem_id => p_problem_id,
    p_problem_index => p_problem_index,
    p_group_error_code => p_group_error_code,
    p_group_error_message => p_group_error_message
  );
  ------------------------------
  for v_i in p_group_start..p_problem_index - 1
  loop
    ------------------------------
    p_error_code(v_i) := p_group_error_code;
    p_error_message(v_i) := v_msg;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_group_error_for_all
(
  p_problem_id number,
  p_problem_index number,
  p_group_start number,
  p_group_size number,
  p_group_error_code number,
  p_group_error_message varchar2,
  p_error_code in out nocopy ct_number,
  p_error_message in out nocopy ct_varchar
)
is
  v_main_count number;
  v_msg varchar2(4000);
begin
  ------------------------------
  xcheck_group_error_params
  (
    p_problem_id => p_problem_id,
    p_problem_index => p_problem_index,
    p_group_start => p_group_start,
    p_group_size => p_group_size,
    p_group_error_code => p_group_error_code,
    p_group_error_message => p_group_error_message,
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_main_count => v_main_count
  );
  ------------------------------
  v_msg := make_group_error_message
  (
    p_problem_id => p_problem_id,
    p_problem_index => p_problem_index,
    p_group_error_code => p_group_error_code,
    p_group_error_message => p_group_error_message
  );
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if v_i between p_group_start and p_group_start + p_group_size
    then
      ------------------------------
      p_error_message(v_i) := util_pkg.cut_err_msg(v_msg);
      p_error_code(v_i) := p_group_error_code;
      ------------------------------
    elsif v_i < p_problem_index
    then
      ------------------------------
      p_error_message(v_i) := util_pkg.cut_err_msg(util_pkg.c_msg_rolled_back || util_pkg.c_msg_delim01 || v_msg);
      p_error_code(v_i) := util_pkg.c_ora_rolled_back;
      ------------------------------
    else
      ------------------------------
      p_error_message(v_i) := util_pkg.cut_err_msg(util_pkg.c_msg_not_executed || util_pkg.c_msg_delim01 || v_msg);
      p_error_code(v_i) := util_pkg.c_ora_not_executed;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_error_by_marks0
(
  p_marks ct_number,
  p_pivot ct_number,
  p_error_code number,
  p_error_message varchar2,
  p_mark_value number := util_pkg.c_true,
  p_error_codes in out nocopy ct_number,
  p_error_messages in out nocopy ct_varchar
)
is
  v_map ct_number;
begin
  ------------------------------
  if 1 = 1
    and not util_pkg.CheckP_ct_number(p_marks)
    and not util_pkg.CheckP_ct_number(p_pivot)
    and not util_pkg.CheckP_ct_number(p_error_codes)
    and not util_pkg.CheckP_ct_varchar(p_error_messages)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  if (1 = 0
    or not util_pkg.CheckP_ct_number(p_marks)
    or not util_pkg.CheckP_ct_number(p_pivot)
    or not util_pkg.CheckP_ct_number(p_error_codes)
    or not util_pkg.CheckP_ct_varchar(p_error_messages)
  )
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter || util_pkg.c_msg_delim01 || 'p_marks, p_pivot, p_error_codes, p_error_messages');
    ------------------------------
  end if;
  ------------------------------
  v_map := util_pkg.get_marked_ct_number(p_pivot, p_marks, true, p_mark_value, null);
  ------------------------------
  if util_pkg.get_count_ct_number(v_map) > 0
  then
    ------------------------------
    util_pkg.set_val_by_pos_ct_number(p_error_codes, p_error_code, v_map);
    util_pkg.set_val_by_pos_ct_varchar(p_error_messages, p_error_message, v_map);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_error_by_marks
(
  p_marks ct_number,
  p_error_code number,
  p_error_message varchar2,
  p_mark_value number := util_pkg.c_true,
  p_error_codes in out nocopy ct_number,
  p_error_messages in out nocopy ct_varchar
)
is
  v_main_count number;
  v_pivot ct_number;
begin
  ------------------------------
  if 1 = 1
    and not util_pkg.CheckP_ct_number(p_marks)
    and not util_pkg.CheckP_ct_number(p_error_codes)
    and not util_pkg.CheckP_ct_varchar(p_error_messages)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  if (1 = 0
    or (not util_pkg.CheckP_ct_number(p_marks))
    or (not util_pkg.CheckP_ct_number(p_error_codes))
    or (not util_pkg.CheckP_ct_varchar(p_error_messages))
  )
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter || util_pkg.c_msg_delim01 || 'p_marks, p_error_codes, p_error_messages');
    ------------------------------
  end if;
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_marks);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  setup_error_by_marks0(p_marks, v_pivot, p_error_code, p_error_message, p_mark_value, p_error_codes, p_error_messages);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_has_error
(
  p_break_on_error boolean,
  p_error_codes ct_number,
  p_error_messages ct_varchar
)
is
  v_err_idx number;
begin
  ------------------------------
  if p_break_on_error
  then
    ------------------------------
    v_err_idx := get_first_error_pos(p_error_codes);
    ------------------------------
    if v_err_idx is not null
    then
      ------------------------------
      util_pkg.raise_exception(util_pkg.c_ora_x_common, make_group_error_message4(v_err_idx, p_error_codes(v_err_idx), p_error_messages(v_err_idx)));
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_has_error_NOT_ORA
(
  p_break_on_error boolean,
  p_error_codes ct_number,
  p_error_messages ct_varchar
)
is
begin
  ------------------------------
  xcheck_has_error
  (
    p_break_on_error => p_break_on_error,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_na_status_internal(p_status varchar2) return boolean
is
begin
  ------------------------------
  if util_ri.valid_code2(p_status) = util_ri.valid_code2(util_ri.c_NASH_CODE_INTERNAL)
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_na_status_changable_i(p_old_status varchar2, p_new_status varchar2, p_date date, p_internal_allowed boolean, p_is_bp boolean) return boolean
is
  v_old_status varchar2(2) := util_ri.valid_code2(p_old_status);
  v_new_status varchar2(2) := util_ri.valid_code2(p_new_status);
  v_is_bp number := util_pkg.bool_to_int_2val(p_is_bp);
  v_is_bp_char varchar2(1);
  v_num number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_internal_allowed is null, 'p_internal_allowed');
  util_pkg.XCheck_Cond_Missing(p_is_bp is null, 'p_is_bp');
  ------------------------------
  if not p_internal_allowed and (is_na_status_internal(p_old_status) or is_na_status_internal(p_new_status))
  then
    ------------------------------
    return false;
    ------------------------------
  end if;
  ------------------------------
  if p_is_bp
  then
    ------------------------------
    v_is_bp_char := util_ri.c_YES;
    ------------------------------
  else
    ------------------------------
    v_is_bp_char := util_ri.c_NO;
    ------------------------------
  end if;
  ------------------------------
  select /*+ full(z)*/
    count(1) cnt into v_num
    from na_status_trans z
    where 1 = 1
    and (status_code_from = v_old_status or (v_old_status is null and status_code_from is null))
    and status_code_to = v_new_status
    and (v_is_bp = util_pkg.c_true or is_bp_only = v_is_bp_char)
    and (deleted is null or deleted > p_date)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_num);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_na_status_changable(p_old_status varchar2, p_new_status varchar2, p_date date) return boolean
is
begin
  ------------------------------
  return is_na_status_changable_i(p_old_status, p_new_status, p_date, true, true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_na_status_can_change_i(p_network_address_id number, p_new_status varchar2, p_date date) return boolean
is
  v_new_status varchar2(2) := util_ri.valid_code2(p_new_status);
  v_rec network_address_status_history%rowtype;
  v_old_status varchar2(2) := null;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_rec := util_ri.get_last_nash(p_network_address_id);
  ------------------------------
  if (v_rec.start_date >= p_date or util_ri.valid_date_to(v_rec.end_date) <= p_date) --!_! version on p_date is not last ">" or not fitting "=" or not existent "<="
  then
    ------------------------------
    return false;
    ------------------------------
  end if;
  ------------------------------
  v_old_status := util_ri.valid_code2(v_rec.net_address_status_code); --!_! v_old_status can be null
  ------------------------------
  return is_na_status_changable(v_old_status, v_new_status, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_na_status_can_change(p_network_address_id number, p_new_status varchar2, p_date date, p_error_code out number, p_error_message out varchar2) return boolean
is
  v_res boolean;
begin
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  v_res := is_na_status_can_change_i(p_network_address_id, p_new_status, p_date);
  ------------------------------
  if not v_res
  then
    ------------------------------
    p_error_code := util_pkg.c_ora_not_allowed;
    p_error_message := util_pkg.c_msg_not_allowed;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_ap_status_changable_i(p_old_status varchar2, p_new_status varchar2, p_date date, p_is_bp boolean) return boolean
is
  v_old_status varchar2(2) := util_ri.valid_code2(p_old_status);
  v_new_status varchar2(2) := util_ri.valid_code2(p_new_status);
  v_is_bp number := util_pkg.bool_to_int_2val(p_is_bp);
  v_is_bp_char varchar2(1);
  v_num number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_is_bp is null, 'p_is_bp');
  ------------------------------
  if p_is_bp
  then
    ------------------------------
    v_is_bp_char := util_ri.c_YES;
    ------------------------------
  else
    ------------------------------
    v_is_bp_char := util_ri.c_NO;
    ------------------------------
  end if;
  ------------------------------
  select /*+ full(z)*/
    count(1) cnt into v_num
    from ap_status_trans z
    where 1 = 1
    and (status_code_from = v_old_status or (v_old_status is null and status_code_from is null))
    and status_code_to = v_new_status
    and (v_is_bp = util_pkg.c_true or is_bp_only = v_is_bp_char)
    and (deleted is null or deleted > p_date)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_num);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_ap_status_changable(p_old_status varchar2, p_new_status varchar2, p_date date) return boolean
is
begin
  ------------------------------
  return is_ap_status_changable_i(p_old_status, p_new_status, p_date, true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_ap_status_can_change_i(p_access_point_id number, p_new_status varchar2, p_date date) return boolean
is
  v_new_status varchar2(2) := util_ri.valid_code2(p_new_status);
  v_rec access_point_status_history%rowtype;
  v_old_status varchar2(2) := null;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_rec := util_ri.get_last_apsh(p_access_point_id);
  ------------------------------
  if (v_rec.start_date >= p_date or util_ri.valid_date_to(v_rec.end_date) <= p_date) --!_! version on p_date is not last ">" or not fitting "=" or not existent "<="
  then
    ------------------------------
    return false;
    ------------------------------
  end if;
  ------------------------------
  v_old_status := util_ri.valid_code2(v_rec.access_point_status_code); --!_! v_old_status can be null
  ------------------------------
  return is_ap_status_changable(v_old_status, v_new_status, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_ap_status_can_change(p_access_point_id number, p_new_status varchar2, p_date date, p_error_code out number, p_error_message out varchar2) return boolean
is
  v_res boolean;
begin
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  v_res := is_ap_status_can_change_i(p_access_point_id, p_new_status, p_date);
  ------------------------------
  if not v_res
  then
    ------------------------------
    p_error_code := util_pkg.c_ora_not_allowed;
    p_error_message := util_pkg.c_msg_not_allowed;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_ap_pstatus_changable_i(p_old_status varchar2, p_new_status varchar2, p_date date, p_is_bp boolean) return boolean
is
  v_old_status varchar2(2) := util_ri.valid_code2(p_old_status);
  v_new_status varchar2(2) := util_ri.valid_code2(p_new_status);
  v_is_bp number := util_pkg.bool_to_int_2val(p_is_bp);
  v_is_bp_char varchar2(1);
  v_num number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_is_bp is null, 'p_is_bp');
  ------------------------------
  if p_is_bp
  then
    ------------------------------
    v_is_bp_char := util_ri.c_YES;
    ------------------------------
  else
    ------------------------------
    v_is_bp_char := util_ri.c_NO;
    ------------------------------
  end if;
  ------------------------------
  select /*+ full(z)*/
    count(1) cnt into v_num
    from ap_prod_status_trans z
    where 1 = 1
    and (status_code_from = v_old_status or (v_old_status is null and status_code_from is null))
    and status_code_to = v_new_status
    and (v_is_bp = util_pkg.c_true or is_bp_only = v_is_bp_char)
    and (deleted is null or deleted > p_date)
  ;
  ------------------------------
  return util_pkg.int_to_bool_2val(v_num);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_ap_pstatus_changable(p_old_status varchar2, p_new_status varchar2, p_date date) return boolean
is
begin
  ------------------------------
  return is_ap_pstatus_changable_i(p_old_status, p_new_status, p_date, true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_ap_pstatus_can_change_i(p_access_point_id number, p_new_status varchar2, p_date date) return boolean
is
  v_new_status varchar2(2) := util_ri.valid_code2(p_new_status);
  v_rec ap_prod_status_hist%rowtype;
  v_old_status varchar2(2) := null;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_rec := util_ri.get_last_appsh(p_access_point_id);
  ------------------------------
  if (v_rec.start_date >= p_date or util_ri.valid_date_to(v_rec.end_date) <= p_date) --!_! version on p_date is not last ">" or not fitting "=" or not existent "<="
  then
    ------------------------------
    return false;
    ------------------------------
  end if;
  ------------------------------
  v_old_status := util_ri.valid_code2(v_rec.ap_prod_status_code); --!_! v_old_status can be null
  ------------------------------
  return is_ap_pstatus_changable(v_old_status, v_new_status, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_ap_pstatus_can_change(p_access_point_id number, p_new_status varchar2, p_date date, p_error_code out number, p_error_message out varchar2) return boolean
is
  v_res boolean;
begin
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  v_res := is_ap_pstatus_can_change_i(p_access_point_id, p_new_status, p_date);
  ------------------------------
  if not v_res
  then
    ------------------------------
    p_error_code := util_pkg.c_ora_not_allowed;
    p_error_message := util_pkg.c_msg_not_allowed;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_! p_access_point_id is null - close link
--!_! p_access_point_id is not null - open link
----------------------------------!---------------------------------------------
function is_naap_status_can_change_i
(
    p_network_address_id number,
    p_access_point_id number,
    p_date date,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean
) return boolean
is
  v_rec network_address_access_point%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_lack is null, 'p_silent_proper_lack');
  util_pkg.XCheck_Cond_Missing(p_silent_break_actual is null, 'p_silent_break_actual');
  ------------------------------
  v_rec := util_ri.get_last_naap(p_network_address_id);
  ------------------------------
  if 1 = 1
    and v_rec.network_address_id is NOT null
    and v_rec.from_date >= p_date --!_! version on p_date is not last ">" or not fitting "="
  then
    ------------------------------
    return false;
    ------------------------------
  end if;
  ------------------------------
  if p_access_point_id is null --!_! closing
  then
    ------------------------------
    if 1 = 1
      and (1 = 0
        or v_rec.network_address_id is null --!_! object is not existent
        or util_ri.valid_date_to(v_rec.to_date) <= p_date --!_! version on p_date is not existent "<" or not fitting "="
      )
      and NOT p_silent_proper_lack
    then
      ------------------------------
      return false;
      ------------------------------
    end if;
    ------------------------------
  else --opening
    ------------------------------
    if 1 = 1
      and v_rec.network_address_id is NOT null --!_! object exists
      and p_date between v_rec.from_date and util_ri.valid_date_to(v_rec.to_date) --!_! version on p_date exists
      and NOT p_silent_break_actual
    then
      ------------------------------
      return false;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_naap_status_can_change
(
    p_network_address_id number,
    p_access_point_id number,
    p_date date,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
begin
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  v_res := is_naap_status_can_change_i
  (
    p_network_address_id => p_network_address_id,
    p_access_point_id => p_access_point_id,
    p_date => p_date,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual
  );
  ------------------------------
  if not v_res
  then
    ------------------------------
    p_error_code := util_pkg.c_ora_not_allowed;
    p_error_message := util_pkg.c_msg_not_allowed;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_! p_personal_account is null - close link
--!_! p_personal_account is not null - open link
----------------------------------!---------------------------------------------
function is_appa_status_can_change_i
(
    p_access_point_id number,
    p_personal_account number,
    p_date date,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean
) return boolean
is
  v_rec access_point_personal_account%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_lack is null, 'p_silent_proper_lack');
  util_pkg.XCheck_Cond_Missing(p_silent_break_actual is null, 'p_silent_break_actual');
  ------------------------------
  v_rec := util_ri.get_last_appa(p_access_point_id);
  ------------------------------
  if 1 = 1
    and v_rec.access_point_id is NOT null
    and v_rec.from_date >= p_date --!_! version on p_date is not last ">" or not fitting "="
  then
    ------------------------------
    return false;
    ------------------------------
  end if;
  ------------------------------
  if p_personal_account is null --!_! closing
  then
    ------------------------------
    if 1 = 1
      and (1 = 0
        or v_rec.access_point_id is null --!_! object is not existent
        or util_ri.valid_date_to(v_rec.to_date) <= p_date --!_! version on p_date is not existent "<" or not fitting "="
      )
      and NOT p_silent_proper_lack
    then
      ------------------------------
      return false;
      ------------------------------
    end if;
    ------------------------------
  else --opening
    ------------------------------
    if 1 = 1
      and v_rec.access_point_id is NOT null --!_! object exists
      and p_date between v_rec.from_date and util_ri.valid_date_to(v_rec.to_date) --!_! version on p_date exists
      and NOT p_silent_break_actual
    then
      ------------------------------
      return false;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_appa_status_can_change
(
    p_access_point_id number,
    p_personal_account number,
    p_date date,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
begin
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  v_res := is_appa_status_can_change_i
  (
    p_access_point_id => p_access_point_id,
    p_personal_account => p_personal_account,
    p_date => p_date,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual
  );
  ------------------------------
  if not v_res
  then
    ------------------------------
    p_error_code := util_pkg.c_ora_not_allowed;
    p_error_message := util_pkg.c_msg_not_allowed;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_! p_host_id is null - close link
--!_! p_host_id is not null - open link
----------------------------------!---------------------------------------------
function is_pah_status_can_change_i
(
    p_personal_account number,
    p_host_id number,
    p_date date,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean
) return boolean
is
  v_rec personal_account_history%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_lack is null, 'p_silent_proper_lack');
  util_pkg.XCheck_Cond_Missing(p_silent_break_actual is null, 'p_silent_break_actual');
  ------------------------------
  v_rec := util_ri.get_last_pah(p_personal_account);
  ------------------------------
  if 1 = 1
    and v_rec.personal_account is NOT null
    and v_rec.start_date >= p_date --!_! version on p_date is not last ">" or not fitting "="
  then
    ------------------------------
    return false;
    ------------------------------
  end if;
  ------------------------------
  if p_host_id is null --!_! closing
  then
    ------------------------------
    if 1 = 1
      and (1 = 0
        or v_rec.personal_account is null --!_! object is not existent
        or util_ri.valid_date_to(v_rec.end_date) <= p_date --!_! version on p_date is not existent "<" or not fitting "="
      )
      and NOT p_silent_proper_lack
    then
      ------------------------------
      return false;
      ------------------------------
    end if;
    ------------------------------
  else --opening
    ------------------------------
    if 1 = 1
      and v_rec.personal_account is NOT null --!_! object exists
      and p_date between v_rec.start_date and util_ri.valid_date_to(v_rec.end_date) --!_! version on p_date exists
      and NOT p_silent_break_actual
    then
      ------------------------------
      return false;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_pah_status_can_change
(
    p_personal_account number,
    p_host_id number,
    p_date date,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
begin
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  v_res := is_pah_status_can_change_i
  (
    p_personal_account => p_personal_account,
    p_host_id => p_host_id,
    p_date => p_date,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual
  );
  ------------------------------
  if not v_res
  then
    ------------------------------
    p_error_code := util_pkg.c_ora_not_allowed;
    p_error_message := util_pkg.c_msg_not_allowed;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_1na_status_ii
(
    p_na_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_na_trans_reason_code varchar2,
    p_lock_pn boolean
)
is
  v_lock_pn boolean := util_pkg.bool_to_bool_2val(p_lock_pn);
  v_date_to_prev date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  if v_lock_pn
  then
    ------------------------------
    util_ri.xlock_1pn(p_na_id);
    ------------------------------
  end if;
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(p_date);
  ------------------------------
  update /*+ index_asc(z, I_NETADSTAHI_NETWORK_ADDRES_I2)*/
    network_address_status_history z
  set
    end_date = v_date_to_prev,
    date_of_change = sysdate,
    user_id_of_change = p_user_id
  where 1 = 1
    and network_address_id = p_na_id
    and v_date_to_prev between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  ;
  ------------------------------
  insert into network_address_status_history
  (
    net_address_status_code,
    network_address_id,
    start_date,
    date_of_change,
    user_id_of_change,
    end_date,
    na_trans_reason_code
  )
  values
  (
    p_status,
    p_na_id,
    p_date,
    sysdate,
    p_user_id,
    null,
    p_na_trans_reason_code
  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_1na_status_i
(
    p_na_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_na_trans_reason_code varchar2,
    p_lock_pn boolean,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  set_1na_status_ii
  (
    p_na_id => p_na_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_na_trans_reason_code => p_na_trans_reason_code,
    p_lock_pn => p_lock_pn
  );
  ------------------------------
  batch_pkg.na_res_batch_remove_from2(p_na_id, p_user_id);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! last p_error_code(v_i) in group shows whole group status
--!_! first erroneous p_error_code(v_i) in group shows real error point
----------------------------------!---------------------------------------------
function set_na_status_ii
(
    p_na_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean := true;
  v_nullable_group_head boolean := util_pkg.bool_to_bool_2val(p_nullable_group_head);
  v_nullable_group_tail boolean := util_pkg.bool_to_bool_2val(p_nullable_group_tail);
  v_propagate_group_error boolean := util_pkg.bool_to_bool_2val(p_propagate_group_error);
  v_main_count number;
  v_cur_allowed_and_done boolean;
  v_skip_group boolean;
  v_index_in_group number;
  v_group_number number;
  v_group_start number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheckP_ct_varchar_s(p_status, 'p_status');
  util_pkg.XCheckP_ct_date(p_date, 'p_date');
  util_pkg.XCheckP_ct_number(p_user_id, 'p_user_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_pn is null, 'p_lock_pn');
  util_pkg.XCheck_Cond_Missing(p_group_size is null, 'p_group_size');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_head is null, 'p_nullable_group_head');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_tail is null, 'p_nullable_group_tail');
  util_pkg.XCheck_Cond_Missing(p_propagate_group_error is null, 'p_propagate_group_error');
  ------------------------------
  v_main_count := p_na_id.count;
  util_pkg.XCheck_Cond_Invalid(p_na_id.count != v_main_count, 'p_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_status.count != v_main_count, 'p_status.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_date.count != v_main_count, 'p_date.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_user_id.count != v_main_count, 'p_user_id.count != v_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_group_size != trunc(p_group_size), 'p_group_size != trunc(p_group_size)');
  util_pkg.XCheck_Cond_Invalid(p_group_size <= 0, 'p_group_size <= 0');
  util_pkg.XCheck_Cond_Invalid(p_group_size > v_main_count, 'p_group_size > v_main_count');
  util_pkg.XCheck_Cond_Invalid(mod(v_main_count, p_group_size) != 0, 'mod(v_main_count, p_group_size) != 0');
  ------------------------------
  setup_common_error(v_main_count, util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
  ------------------------------
  savepoint sp_set_na_status_ii;
  ------------------------------
  v_skip_group := false;
  ------------------------------
  --!_!for v_i in p_na_id.first..p_na_id.last
  ------------------------------
  for v_i in 1..p_na_id.count
  loop
    ------------------------------
    v_index_in_group := util_pkg.get_index_on_page(v_i, p_group_size);
    ------------------------------
    if v_index_in_group = 1 --!_! new group
    then
      ------------------------------
      savepoint sp_set_na_status_ii_group;
      ------------------------------
      v_skip_group := false;
      ------------------------------
      v_group_number := util_pkg.get_page_number(v_i, p_group_size);
      v_group_start := util_pkg.get_page_start(v_group_number, p_group_size);
      --!_!v_group_start := v_i;
      ------------------------------
    end if;
    ------------------------------
    if v_skip_group
    then
      ------------------------------
      --!_!duplicate previous error
      ------------------------------
      p_error_code(v_i) := p_error_code(v_i - 1);
      p_error_message(v_i) := p_error_message(v_i - 1);
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    v_cur_allowed_and_done := false;
    util_pkg.set_ok(p_error_code(v_i), p_error_message(v_i));
    ------------------------------
    if p_na_id(v_i) is null
    then
      ------------------------------
      if (1 = 0
        or (v_nullable_group_head and v_index_in_group = 1) --!_! new group
        or (v_nullable_group_tail and v_index_in_group > 1) --!_! group continues
      )
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      else
        ------------------------------
        p_error_code(v_i) := util_pkg.c_ora_object_empty;
        p_error_message(v_i) := util_pkg.c_msg_object_empty;
        ------------------------------
      end if;
      ------------------------------
    elsif is_na_status_can_change(p_na_id(v_i), p_status(v_i), p_date(v_i), p_error_code(v_i), p_error_message(v_i))
    then
      ------------------------------
      set_1na_status_i
      (
        p_na_id => p_na_id(v_i),
        p_status => p_status(v_i),
        p_date => p_date(v_i),
        p_user_id => p_user_id(v_i),
        p_na_trans_reason_code => NULL,
        p_lock_pn => p_lock_pn,
        p_error_code => p_error_code(v_i),
        p_error_message => p_error_message(v_i)
      );
      ------------------------------
      if util_pkg.is_ok(p_error_code(v_i))
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    if not v_cur_allowed_and_done
    then
      ------------------------------
      rollback to sp_set_na_status_ii_group;
      ------------------------------
      v_res := false;
      v_skip_group := true;
      ------------------------------
      if v_propagate_group_error and v_index_in_group > 1 --!_! group continues
      then
        ------------------------------
        setup_group_error_for_grp_head
        (
          p_problem_id => p_na_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
      end if;
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        rollback to sp_set_na_status_ii;
        ------------------------------
        setup_group_error_for_all
        (
          p_problem_id => p_na_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_na_status_i
(
    p_na_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_same_status_for_m_and_l boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean;
  cl_group_size number := 2;
  v_index number;
  v_main_count number;
  v_main_count2 number;
  --
  v_na_id ct_number;
  v_status ct_varchar_s;
  v_date ct_date;
  v_user_id ct_number;
  --
  v_map_m ct_number;
  v_map_l ct_number;
  v_na_id_m ct_number;
  v_na_id_l ct_number;
  v_status_m ct_varchar_s;
  v_status_l ct_varchar_s;
  v_date_m ct_date;
  v_date_l ct_date;
  v_user_id_m ct_number;
  v_user_id_l ct_number;
  --
  v_na_id_err ct_number;
  v_map_err1 ct_number;
  v_map_err2 ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_na_id, 'p_na_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_pn is null, 'p_lock_pn');
  util_pkg.XCheck_Cond_Missing(p_same_status_for_m_and_l is null, 'p_same_status_for_m_and_l');
  ------------------------------
  util_ri.prepare_as_pnlnk2_fuzzy(p_na_id, sysdate, v_na_id_m, v_na_id_l);
  ------------------------------
  if p_break_on_error
  then
    ------------------------------
    v_na_id_err := util_ri.get_pnlnk_not_found(p_na_id, v_na_id_m, v_na_id_l);
    ------------------------------
    if util_pkg.get_count_ct_number(v_na_id_err) > 0
    then
      ------------------------------
      setup_common_error(util_pkg.get_count_ct_number(p_na_id), util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
      setup_common_error(util_pkg.get_count_ct_number(v_na_id_err), util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found, v_error_code, v_error_message);
      ------------------------------
      v_map_err1 := util_pkg.map_ct_number(v_na_id_err, p_na_id, TRUE, FALSE);
      ------------------------------
      util_pkg.set_by_pos_ct_number(p_error_code, v_error_code, v_map_err1);
      util_pkg.set_by_pos_ct_varchar(p_error_message, v_error_message, v_map_err1);
      ------------------------------
      return FALSE;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  --!_! initial error filling
  ------------------------------
  setup_common_error(util_pkg.get_count_ct_number(p_na_id), util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found, p_error_code, p_error_message);
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(v_na_id_m);
  ------------------------------
  if NOT p_break_on_error and v_main_count = 0
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
  --!_! p_trim_empty => FALSE in map_ct_number to save size of v_main_count = v_na_id_m.count
  --!_! v_%_m, v_%_l have same .count
  ------------------------------
  v_map_m := util_pkg.map_ct_number(v_na_id_m, p_na_id, FALSE);
  v_map_l := util_pkg.map_ct_number(v_na_id_l, p_na_id, FALSE);
  ------------------------------
  v_status_m := util_pkg.get_by_pos_ct_varchar_s(p_status, v_map_m, FALSE);
  v_status_l := util_pkg.get_by_pos_ct_varchar_s(p_status, v_map_l, FALSE);
  ------------------------------
  v_date_m := util_pkg.get_by_pos_ct_date(p_date, v_map_m, FALSE);
  v_date_l := util_pkg.get_by_pos_ct_date(p_date, v_map_l, FALSE);
  ------------------------------
  v_user_id_m := util_pkg.get_by_pos_ct_number(p_user_id, v_map_m, FALSE);
  v_user_id_l := util_pkg.get_by_pos_ct_number(p_user_id, v_map_l, FALSE);
  ------------------------------
  v_main_count2 := cl_group_size*v_main_count;
  util_pkg.resize_ct_number(v_na_id, v_main_count2);
  util_pkg.resize_ct_varchar_s(v_status, v_main_count2);
  util_pkg.resize_ct_date(v_date, v_main_count2);
  util_pkg.resize_ct_number(v_user_id, v_main_count2);
  ------------------------------
  --!_!for v_i in v_na_id_m.first..v_na_id_m.last
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_index := util_pkg.get_page_start(v_i, cl_group_size);
    ------------------------------
    v_na_id(v_index) := v_na_id_m(v_i);
    v_na_id(v_index + 1) := v_na_id_l(v_i); --!_! can be null - it defines behavior in set_na_status_ii
    ------------------------------
    --!_! (v_index + 1)'th elements below are always not null (if no error) but may be not used according v_na_id(v_index + 1)
    ------------------------------
    --!_! implicit loop till cl_group_size
    ------------------------------
    v_status(v_index) := nvl(v_status_m(v_i), v_status_l(v_i));
    v_status(v_index + 1) := nvl(v_status_l(v_i), v_status_m(v_i));
    v_date(v_index) := nvl(v_date_m(v_i), v_date_l(v_i));
    v_date(v_index + 1) := nvl(v_date_l(v_i), v_date_m(v_i));
    v_user_id(v_index) := nvl(v_user_id_m(v_i), v_user_id_l(v_i));
    v_user_id(v_index + 1) := nvl(v_user_id_l(v_i), v_user_id_m(v_i));
    ------------------------------
    util_pkg.XCheck_Cond_Missing
    (
      1 = 0
      or (v_status(v_index) is null)
      or (v_date(v_index) is null)
      or (v_user_id(v_index) is null)
      , 'v_status or v_date or v_user_id'
    );
    ------------------------------
    if p_same_status_for_m_and_l
      and (1 = 0
        or (v_status(v_index + 1) is NOT null and v_status(v_index) != v_status(v_index + 1))
        or (v_date(v_index) != v_date(v_index + 1))
      )
    then
      ------------------------------
      util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'In group are not same v_status or v_date');
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  v_res := set_na_status_ii
  (
    p_na_id => v_na_id,
    p_status => v_status,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_pn => p_lock_pn,
    p_group_size => cl_group_size,
    p_nullable_group_head => false,
    p_nullable_group_tail => true,
    p_propagate_group_error => TRUE,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  v_map_err1 := util_pkg.map_ct_number(v_na_id, p_na_id, TRUE, FALSE);
  v_map_err2 := util_pkg.map_ct_number(v_na_id, p_na_id, TRUE, TRUE);
  ------------------------------
  v_error_code := util_pkg.get_by_pos_ct_number(v_error_code, v_map_err2, TRUE);
  v_error_message := util_pkg.get_by_pos_ct_varchar(v_error_message, v_map_err2, TRUE);
  ------------------------------
  util_pkg.set_by_pos_ct_number(p_error_code, v_error_code, v_map_err1);
  util_pkg.set_by_pos_ct_varchar(p_error_message, v_error_message, v_map_err1);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function set_na_status
(
    p_na_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
begin
  ------------------------------
  return set_na_status_i
  (
    p_na_id => p_na_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_pn => p_lock_pn,
    p_same_status_for_m_and_l => TRUE,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_na_status2
(
    p_na_id ct_number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_status ct_varchar_s;
  v_date ct_date;
  v_user_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_pn is null, 'p_lock_pn');
  ------------------------------
  v_main_count := p_na_id.count;
  ------------------------------
  util_pkg.resize_ct_varchar_s(v_status, v_main_count);
  util_pkg.resize_ct_date(v_date, v_main_count);
  util_pkg.resize_ct_number(v_user_id, v_main_count);
  ------------------------------
  util_pkg.fill_ct_varchar_s(v_status, p_status);
  util_pkg.fill_ct_date(v_date, p_date);
  util_pkg.fill_ct_number(v_user_id, p_user_id);
  ------------------------------
  return set_na_status
  (
    p_na_id => p_na_id,
    p_status => v_status,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_pn => p_lock_pn,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_na_status3
(
    p_na_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_na_id ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  v_res := set_na_status2
  (
    p_na_id => v_na_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_lock_pn => p_lock_pn,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure del_1na_status_ii
(
    p_na_id number,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_allowed_statuses ct_varchar_s
)
is
  v_lock_pn boolean := util_pkg.bool_to_bool_2val(p_lock_pn);
  v_date_to_prev date;
  v_last network_address_status_history%rowtype;
  v_prev network_address_status_history%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_lock_pn is null, 'p_lock_pn');
  util_pkg.XCheck_Cond_Missing(p_silent_prev_lack is null, 'p_silent_prev_lack');
  --!_!util_pkg.XCheckP_ct_varchar_s(p_allowed_statuses, 'p_allowed_statuses');
  ------------------------------
  if v_lock_pn
  then
    ------------------------------
    util_ri.xlock_1pn(p_na_id);
    ------------------------------
  end if;
  ------------------------------
  v_last := util_ri.get_last_nash(p_na_id);
  ------------------------------
  if v_last.network_address_id is null
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_na_id));
    ------------------------------
  end if;
  ------------------------------
  if util_pkg.index_of_ct_varchar_s(p_allowed_statuses, util_ri.valid_code2(v_last.net_address_status_code)) = util_pkg.c_index_not_found
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed || util_pkg.c_msg_delim01 || v_last.net_address_status_code);
    ------------------------------
  end if;
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(v_last.start_date);
  ------------------------------
  v_prev := util_ri.get_1nash(p_na_id, v_date_to_prev);
  ------------------------------
  if v_prev.network_address_id is null
  then
    ------------------------------
    if p_silent_prev_lack
    then
      ------------------------------
      return;
      ------------------------------
    else
      ------------------------------
      util_pkg.raise_exception(util_loc_pkg.c_ora_prev_status_not_exist, util_loc_pkg.c_msg_prev_status_not_exist || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_na_id));
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  set_1na_status_ii
  (
    p_na_id => p_na_id,
    p_status => util_ri.valid_code2(v_prev.net_address_status_code),
    p_date => p_date,
    p_user_id => p_user_id,
    p_na_trans_reason_code => NULL,
    p_lock_pn => FALSE
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_1na_status_i
(
    p_na_id number,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_allowed_statuses ct_varchar_s,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  del_1na_status_ii
  (
    p_na_id => p_na_id,
    p_date => p_date,
    p_user_id => p_user_id,
    p_lock_pn => p_lock_pn,
    p_silent_prev_lack => p_silent_prev_lack,
    p_allowed_statuses => p_allowed_statuses
  );
  ------------------------------
  batch_pkg.na_res_batch_remove_from2(p_na_id, p_user_id);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function del_na_status_ii
(
    p_na_id ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_allowed_statuses ct_varchar_s,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean := true;
  v_nullable_group_head boolean := util_pkg.bool_to_bool_2val(p_nullable_group_head);
  v_nullable_group_tail boolean := util_pkg.bool_to_bool_2val(p_nullable_group_tail);
  v_propagate_group_error boolean := util_pkg.bool_to_bool_2val(p_propagate_group_error);
  v_main_count number;
  v_cur_allowed_and_done boolean;
  v_skip_group boolean;
  v_index_in_group number;
  v_group_number number;
  v_group_start number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheckP_ct_date(p_date, 'p_date');
  util_pkg.XCheckP_ct_number(p_user_id, 'p_user_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_pn is null, 'p_lock_pn');
  util_pkg.XCheck_Cond_Missing(p_silent_prev_lack is null, 'p_silent_prev_lack');
  util_pkg.XCheck_Cond_Missing(p_group_size is null, 'p_group_size');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_head is null, 'p_nullable_group_head');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_tail is null, 'p_nullable_group_tail');
  util_pkg.XCheck_Cond_Missing(p_propagate_group_error is null, 'p_propagate_group_error');
  ------------------------------
  v_main_count := p_na_id.count;
  util_pkg.XCheck_Cond_Invalid(p_na_id.count != v_main_count, 'p_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_date.count != v_main_count, 'p_date.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_user_id.count != v_main_count, 'p_user_id.count != v_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_group_size != trunc(p_group_size), 'p_group_size != trunc(p_group_size)');
  util_pkg.XCheck_Cond_Invalid(p_group_size <= 0, 'p_group_size <= 0');
  util_pkg.XCheck_Cond_Invalid(p_group_size > v_main_count, 'p_group_size > v_main_count');
  util_pkg.XCheck_Cond_Invalid(mod(v_main_count, p_group_size) != 0, 'mod(v_main_count, p_group_size) != 0');
  ------------------------------
  setup_common_error(v_main_count, util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
  ------------------------------
  savepoint sp_del_na_status_ii;
  ------------------------------
  v_skip_group := false;
  ------------------------------
  --!_!for v_i in p_na_id.first..p_na_id.last
  ------------------------------
  for v_i in 1..p_na_id.count
  loop
    ------------------------------
    v_index_in_group := util_pkg.get_index_on_page(v_i, p_group_size);
    ------------------------------
    if v_index_in_group = 1 --!_! new group
    then
      ------------------------------
      savepoint sp_del_na_status_ii_group;
      ------------------------------
      v_skip_group := false;
      ------------------------------
      v_group_number := util_pkg.get_page_number(v_i, p_group_size);
      v_group_start := util_pkg.get_page_start(v_group_number, p_group_size);
      --!_!v_group_start := v_i;
      ------------------------------
    end if;
    ------------------------------
    if v_skip_group
    then
      ------------------------------
      --!_!duplicate previous error
      ------------------------------
      p_error_code(v_i) := p_error_code(v_i - 1);
      p_error_message(v_i) := p_error_message(v_i - 1);
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    v_cur_allowed_and_done := false;
    util_pkg.set_ok(p_error_code(v_i), p_error_message(v_i));
    ------------------------------
    if p_na_id(v_i) is null
    then
      ------------------------------
      if (1 = 0
        or (v_nullable_group_head and v_index_in_group = 1) --!_! new group
        or (v_nullable_group_tail and v_index_in_group > 1) --!_! group continues
      )
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      else
        ------------------------------
        p_error_code(v_i) := util_pkg.c_ora_object_empty;
        p_error_message(v_i) := util_pkg.c_msg_object_empty;
        ------------------------------
      end if;
      ------------------------------
    else
      ------------------------------
      del_1na_status_i
      (
        p_na_id => p_na_id(v_i),
        p_date => p_date(v_i),
        p_user_id => p_user_id(v_i),
        p_lock_pn => p_lock_pn,
        p_silent_prev_lack => p_silent_prev_lack,
        p_allowed_statuses => p_allowed_statuses,
        p_error_code => p_error_code(v_i),
        p_error_message => p_error_message(v_i)
      );
      ------------------------------
      if util_pkg.is_ok(p_error_code(v_i))
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    if not v_cur_allowed_and_done
    then
      ------------------------------
      rollback to sp_del_na_status_ii_group;
      ------------------------------
      v_res := false;
      v_skip_group := true;
      ------------------------------
      if v_propagate_group_error and v_index_in_group > 1 --!_! group continues
      then
        ------------------------------
        setup_group_error_for_grp_head
        (
          p_problem_id => p_na_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
      end if;
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        rollback to sp_del_na_status_ii;
        ------------------------------
        setup_group_error_for_all
        (
          p_problem_id => p_na_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function del_na_status_i
(
    p_na_id ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean;
  cl_group_size number := 2;
  v_index number;
  v_main_count number;
  v_main_count2 number;
  --
  v_na_id ct_number;
  v_date ct_date;
  v_user_id ct_number;
  --
  v_map_m ct_number;
  v_map_l ct_number;
  v_na_id_m ct_number;
  v_na_id_l ct_number;
  v_date_m ct_date;
  v_date_l ct_date;
  v_user_id_m ct_number;
  v_user_id_l ct_number;
  --
  v_na_id_err ct_number;
  v_map_err1 ct_number;
  v_map_err2 ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
  --
  v_allowed_statuses ct_varchar_s;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_na_id, 'p_na_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_pn is null, 'p_lock_pn');
  util_pkg.XCheck_Cond_Missing(p_silent_prev_lack is null, 'p_silent_prev_lack');
  ------------------------------
  v_allowed_statuses := util_ri.split_str_list(install_pkg.nnget_option_str(c_sett_allow_del_na_status, NULL, c_def_allow_del_na_status), true);
  ------------------------------
  util_ri.prepare_as_pnlnk2_fuzzy(p_na_id, sysdate, v_na_id_m, v_na_id_l);
  ------------------------------
  if p_break_on_error
  then
    ------------------------------
    v_na_id_err := util_ri.get_pnlnk_not_found(p_na_id, v_na_id_m, v_na_id_l);
    ------------------------------
    if util_pkg.get_count_ct_number(v_na_id_err) > 0
    then
      ------------------------------
      setup_common_error(util_pkg.get_count_ct_number(p_na_id), util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
      setup_common_error(util_pkg.get_count_ct_number(v_na_id_err), util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found, v_error_code, v_error_message);
      ------------------------------
      v_map_err1 := util_pkg.map_ct_number(v_na_id_err, p_na_id, TRUE, FALSE);
      ------------------------------
      util_pkg.set_by_pos_ct_number(p_error_code, v_error_code, v_map_err1);
      util_pkg.set_by_pos_ct_varchar(p_error_message, v_error_message, v_map_err1);
      ------------------------------
      return FALSE;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  --!_! initial error filling
  ------------------------------
  setup_common_error(util_pkg.get_count_ct_number(p_na_id), util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found, p_error_code, p_error_message);
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(v_na_id_m);
  ------------------------------
  if NOT p_break_on_error and v_main_count = 0
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
  --!_! p_trim_empty => FALSE in map_ct_number to save size of v_main_count = v_na_id_m.count
  --!_! v_%_m, v_%_l have same .count
  ------------------------------
  v_map_m := util_pkg.map_ct_number(v_na_id_m, p_na_id, FALSE);
  v_map_l := util_pkg.map_ct_number(v_na_id_l, p_na_id, FALSE);
  ------------------------------
  v_date_m := util_pkg.get_by_pos_ct_date(p_date, v_map_m, FALSE);
  v_date_l := util_pkg.get_by_pos_ct_date(p_date, v_map_l, FALSE);
  ------------------------------
  v_user_id_m := util_pkg.get_by_pos_ct_number(p_user_id, v_map_m, FALSE);
  v_user_id_l := util_pkg.get_by_pos_ct_number(p_user_id, v_map_l, FALSE);
  ------------------------------
  v_main_count2 := cl_group_size*v_main_count;
  util_pkg.resize_ct_number(v_na_id, v_main_count2);
  util_pkg.resize_ct_date(v_date, v_main_count2);
  util_pkg.resize_ct_number(v_user_id, v_main_count2);
  ------------------------------
  --!_!for v_i in v_na_id_m.first..v_na_id_m.last
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_index := util_pkg.get_page_start(v_i, cl_group_size);
    ------------------------------
    v_na_id(v_index) := v_na_id_m(v_i);
    v_na_id(v_index + 1) := v_na_id_l(v_i); --!_! can be null - it defines behavior in set_na_status_ii
    ------------------------------
    --!_! (v_index + 1)'th elements below are always not null (if no error) but may be not used according v_na_id(v_index + 1)
    ------------------------------
    --!_! implicit loop till cl_group_size
    ------------------------------
    v_date(v_index) := nvl(v_date_m(v_i), v_date_l(v_i));
    v_date(v_index + 1) := nvl(v_date_l(v_i), v_date_m(v_i));
    v_user_id(v_index) := nvl(v_user_id_m(v_i), v_user_id_l(v_i));
    v_user_id(v_index + 1) := nvl(v_user_id_l(v_i), v_user_id_m(v_i));
    ------------------------------
    util_pkg.XCheck_Cond_Missing
    (
      1 = 0
      or (v_date(v_index) is null)
      or (v_user_id(v_index) is null)
      , 'v_date or v_user_id'
    );
    ------------------------------
  end loop;
  ------------------------------
  v_res := del_na_status_ii
  (
    p_na_id => v_na_id,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_pn => p_lock_pn,
    p_silent_prev_lack => p_silent_prev_lack,
    p_allowed_statuses => v_allowed_statuses,
    p_group_size => cl_group_size,
    p_nullable_group_head => false,
    p_nullable_group_tail => true,
    p_propagate_group_error => TRUE,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  v_map_err1 := util_pkg.map_ct_number(v_na_id, p_na_id, TRUE, FALSE);
  v_map_err2 := util_pkg.map_ct_number(v_na_id, p_na_id, TRUE, TRUE);
  ------------------------------
  v_error_code := util_pkg.get_by_pos_ct_number(v_error_code, v_map_err2, TRUE);
  v_error_message := util_pkg.get_by_pos_ct_varchar(v_error_message, v_map_err2, TRUE);
  ------------------------------
  util_pkg.set_by_pos_ct_number(p_error_code, v_error_code, v_map_err1);
  util_pkg.set_by_pos_ct_varchar(p_error_message, v_error_message, v_map_err1);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function del_na_status
(
    p_na_id ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
begin
  ------------------------------
  return del_na_status_i
  (
    p_na_id => p_na_id,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_pn => p_lock_pn,
    p_silent_prev_lack => p_silent_prev_lack,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function del_na_status2
(
    p_na_id ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_date ct_date;
  v_user_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_pn is null, 'p_lock_pn');
  util_pkg.XCheck_Cond_Missing(p_silent_prev_lack is null, 'p_silent_prev_lack');
  ------------------------------
  v_main_count := p_na_id.count;
  ------------------------------
  util_pkg.resize_ct_date(v_date, v_main_count);
  util_pkg.resize_ct_number(v_user_id, v_main_count);
  ------------------------------
  util_pkg.fill_ct_date(v_date, p_date);
  util_pkg.fill_ct_number(v_user_id, p_user_id);
  ------------------------------
  return del_na_status
  (
    p_na_id => p_na_id,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_pn => p_lock_pn,
    p_silent_prev_lack => p_silent_prev_lack,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function del_na_status3
(
    p_na_id number,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_silent_prev_lack boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_na_id ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  v_res := del_na_status2
  (
    p_na_id => v_na_id,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_lock_pn => p_lock_pn,
    p_silent_prev_lack => p_silent_prev_lack,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_1ap_status_ii
(
    p_ap_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_ap_trans_reason_code varchar2,
    p_lock_sc boolean
)
is
  v_lock_sc boolean := util_pkg.bool_to_bool_2val(p_lock_sc);
  v_date_to_prev date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  if v_lock_sc
  then
    ------------------------------
    util_ri.xlock_1sc(p_ap_id);
    ------------------------------
  end if;
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(p_date);
  ------------------------------
  update /*+ index_asc(z, I_ACCPOSTAHI_ACCESS_POINT_ID)*/
    access_point_status_history z
  set
    end_date = v_date_to_prev,
    date_of_change = sysdate,
    user_id_of_change = p_user_id
  where 1 = 1
    and access_point_id = p_ap_id
    and v_date_to_prev between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  ;
  ------------------------------
  insert into access_point_status_history
  (
    access_point_status_code,
    access_point_id,
    start_date,
    end_date,
    user_id_of_change,
    date_of_change,
    ap_trans_reason_code
  )
  values
  (
    p_status,
    p_ap_id,
    p_date,
    null,
    p_user_id,
    sysdate,
    p_ap_trans_reason_code
  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_1ap_status_i
(
    p_ap_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_ap_trans_reason_code varchar2,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  set_1ap_status_ii
  (
    p_ap_id => p_ap_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_ap_trans_reason_code => p_ap_trans_reason_code,
    p_lock_sc => p_lock_sc
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_ap_status_ii
(
    p_ap_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean := true;
  v_nullable_group_head boolean := util_pkg.bool_to_bool_2val(p_nullable_group_head);
  v_nullable_group_tail boolean := util_pkg.bool_to_bool_2val(p_nullable_group_tail);
  v_propagate_group_error boolean := util_pkg.bool_to_bool_2val(p_propagate_group_error);
  v_main_count number;
  v_cur_allowed_and_done boolean;
  v_skip_group boolean;
  v_index_in_group number;
  v_group_number number;
  v_group_start number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_ap_id, 'p_ap_id');
  util_pkg.XCheckP_ct_varchar_s(p_status, 'p_status');
  util_pkg.XCheckP_ct_date(p_date, 'p_date');
  util_pkg.XCheckP_ct_number(p_user_id, 'p_user_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_sc is null, 'p_lock_sc');
  util_pkg.XCheck_Cond_Missing(p_group_size is null, 'p_group_size');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_head is null, 'p_nullable_group_head');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_tail is null, 'p_nullable_group_tail');
  util_pkg.XCheck_Cond_Missing(p_propagate_group_error is null, 'p_propagate_group_error');
  ------------------------------
  v_main_count := p_ap_id.count;
  util_pkg.XCheck_Cond_Invalid(p_ap_id.count != v_main_count, 'p_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_status.count != v_main_count, 'p_status.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_date.count != v_main_count, 'p_date.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_user_id.count != v_main_count, 'p_user_id.count != v_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_group_size != trunc(p_group_size), 'p_group_size != trunc(p_group_size)');
  util_pkg.XCheck_Cond_Invalid(p_group_size <= 0, 'p_group_size <= 0');
  util_pkg.XCheck_Cond_Invalid(p_group_size > v_main_count, 'p_group_size > v_main_count');
  util_pkg.XCheck_Cond_Invalid(mod(v_main_count, p_group_size) != 0, 'mod(v_main_count, p_group_size) != 0');
  ------------------------------
  setup_common_error(v_main_count, util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
  ------------------------------
  savepoint sp_set_ap_status_ii;
  ------------------------------
  v_skip_group := false;
  ------------------------------
  --!_!for v_i in p_ap_id.first..p_ap_id.last
  ------------------------------
  for v_i in 1..p_ap_id.count
  loop
    ------------------------------
    v_index_in_group := util_pkg.get_index_on_page(v_i, p_group_size);
    ------------------------------
    if v_index_in_group = 1 --!_! new group
    then
      ------------------------------
      savepoint sp_set_ap_status_ii_group;
      ------------------------------
      v_skip_group := false;
      ------------------------------
      v_group_number := util_pkg.get_page_number(v_i, p_group_size);
      v_group_start := util_pkg.get_page_start(v_group_number, p_group_size);
      --!_!v_group_start := v_i;
      ------------------------------
    end if;
    ------------------------------
    if v_skip_group
    then
      ------------------------------
      --!_!duplicate previous error
      ------------------------------
      p_error_code(v_i) := p_error_code(v_i - 1);
      p_error_message(v_i) := p_error_message(v_i - 1);
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    v_cur_allowed_and_done := false;
    util_pkg.set_ok(p_error_code(v_i), p_error_message(v_i));
    ------------------------------
    if p_ap_id(v_i) is null
    then
      ------------------------------
      if (1 = 0
        or (v_nullable_group_head and v_index_in_group = 1) --!_! new group
        or (v_nullable_group_tail and v_index_in_group > 1) --!_! group continues
      )
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      else
        ------------------------------
        p_error_code(v_i) := util_pkg.c_ora_object_empty;
        p_error_message(v_i) := util_pkg.c_msg_object_empty;
        ------------------------------
      end if;
      ------------------------------
    elsif is_ap_status_can_change(p_ap_id(v_i), p_status(v_i), p_date(v_i), p_error_code(v_i), p_error_message(v_i))
    then
      ------------------------------
      set_1ap_status_i
      (
        p_ap_id => p_ap_id(v_i),
        p_status => p_status(v_i),
        p_date => p_date(v_i),
        p_user_id => p_user_id(v_i),
        p_ap_trans_reason_code => NULL,
        p_lock_sc => p_lock_sc,
        p_error_code => p_error_code(v_i),
        p_error_message => p_error_message(v_i)
      );
      ------------------------------
      if util_pkg.is_ok(p_error_code(v_i))
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    if not v_cur_allowed_and_done
    then
      ------------------------------
      rollback to sp_set_ap_status_ii_group;
      ------------------------------
      v_res := false;
      v_skip_group := true;
      ------------------------------
      if v_propagate_group_error and v_index_in_group > 1 --!_! group continues
      then
        ------------------------------
        setup_group_error_for_grp_head
        (
          p_problem_id => p_ap_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
      end if;
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        rollback to sp_set_ap_status_ii;
        ------------------------------
        setup_group_error_for_all
        (
          p_problem_id => p_ap_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_ap_status_i
(
    p_ap_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean;
  cl_group_size number := 1;
  --
  v_error_code ct_number;
  v_error_message ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_ap_id, 'p_ap_id');
  ------------------------------
  v_res := set_ap_status_ii
  (
    p_ap_id => p_ap_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_sc => p_lock_sc,
    p_group_size => cl_group_size,
    p_nullable_group_head => false,
    p_nullable_group_tail => true,
    p_propagate_group_error => TRUE,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code;
  p_error_message := v_error_message;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function set_ap_status
(
    p_ap_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
begin
  ------------------------------
  return set_ap_status_i
  (
    p_ap_id => p_ap_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_sc => p_lock_sc,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_ap_status2
(
    p_ap_id ct_number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_status ct_varchar_s;
  v_date ct_date;
  v_user_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_ap_id, 'p_ap_id');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_sc is null, 'p_lock_sc');
  ------------------------------
  v_main_count := p_ap_id.count;
  ------------------------------
  util_pkg.resize_ct_varchar_s(v_status, v_main_count);
  util_pkg.resize_ct_date(v_date, v_main_count);
  util_pkg.resize_ct_number(v_user_id, v_main_count);
  ------------------------------
  util_pkg.fill_ct_varchar_s(v_status, p_status);
  util_pkg.fill_ct_date(v_date, p_date);
  util_pkg.fill_ct_number(v_user_id, p_user_id);
  ------------------------------
  return set_ap_status
  (
    p_ap_id => p_ap_id,
    p_status => v_status,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_sc => p_lock_sc,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_ap_status3
(
    p_ap_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_ap_id ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  v_res := set_ap_status2
  (
    p_ap_id => v_ap_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_lock_sc => p_lock_sc,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_1ap_pstatus_ii
(
    p_ap_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean
)
is
  v_lock_sc boolean := util_pkg.bool_to_bool_2val(p_lock_sc);
  v_date_to_prev date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  if v_lock_sc
  then
    ------------------------------
    util_ri.xlock_1sc(p_ap_id);
    ------------------------------
  end if;
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(p_date);
  ------------------------------
  update /*+ index_asc(z, I_APPSTHI_ACCESS_POINT_ID)*/
    ap_prod_status_hist z
  set
    end_date = v_date_to_prev,
    date_of_change = sysdate,
    user_id_of_change = p_user_id
  where 1 = 1
    and access_point_id = p_ap_id
    and v_date_to_prev between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  ;
  ------------------------------
  insert into ap_prod_status_hist
  (
    access_point_id,
    ap_prod_status_code,
    start_date,
    end_date,
    user_id_of_change,
    date_of_change
  )
  values
  (
    p_ap_id,
    p_status,
    p_date,
    null,
    p_user_id,
    sysdate
  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_1ap_pstatus_i
(
    p_ap_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  set_1ap_pstatus_ii
  (
    p_ap_id => p_ap_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_lock_sc => p_lock_sc
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_ap_pstatus_ii
(
    p_ap_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean := true;
  v_nullable_group_head boolean := util_pkg.bool_to_bool_2val(p_nullable_group_head);
  v_nullable_group_tail boolean := util_pkg.bool_to_bool_2val(p_nullable_group_tail);
  v_propagate_group_error boolean := util_pkg.bool_to_bool_2val(p_propagate_group_error);
  v_main_count number;
  v_cur_allowed_and_done boolean;
  v_skip_group boolean;
  v_index_in_group number;
  v_group_number number;
  v_group_start number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_ap_id, 'p_ap_id');
  util_pkg.XCheckP_ct_varchar_s(p_status, 'p_status');
  util_pkg.XCheckP_ct_date(p_date, 'p_date');
  util_pkg.XCheckP_ct_number(p_user_id, 'p_user_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_sc is null, 'p_lock_sc');
  util_pkg.XCheck_Cond_Missing(p_group_size is null, 'p_group_size');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_head is null, 'p_nullable_group_head');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_tail is null, 'p_nullable_group_tail');
  util_pkg.XCheck_Cond_Missing(p_propagate_group_error is null, 'p_propagate_group_error');
  ------------------------------
  v_main_count := p_ap_id.count;
  util_pkg.XCheck_Cond_Invalid(p_ap_id.count != v_main_count, 'p_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_status.count != v_main_count, 'p_status.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_date.count != v_main_count, 'p_date.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_user_id.count != v_main_count, 'p_user_id.count != v_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_group_size != trunc(p_group_size), 'p_group_size != trunc(p_group_size)');
  util_pkg.XCheck_Cond_Invalid(p_group_size <= 0, 'p_group_size <= 0');
  util_pkg.XCheck_Cond_Invalid(p_group_size > v_main_count, 'p_group_size > v_main_count');
  util_pkg.XCheck_Cond_Invalid(mod(v_main_count, p_group_size) != 0, 'mod(v_main_count, p_group_size) != 0');
  ------------------------------
  setup_common_error(v_main_count, util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
  ------------------------------
  savepoint sp_set_ap_pstatus_ii;
  ------------------------------
  v_skip_group := false;
  ------------------------------
  --!_!for v_i in p_ap_id.first..p_ap_id.last
  ------------------------------
  for v_i in 1..p_ap_id.count
  loop
    ------------------------------
    v_index_in_group := util_pkg.get_index_on_page(v_i, p_group_size);
    ------------------------------
    if v_index_in_group = 1 --!_! new group
    then
      ------------------------------
      savepoint sp_set_ap_pstatus_ii_group;
      ------------------------------
      v_skip_group := false;
      ------------------------------
      v_group_number := util_pkg.get_page_number(v_i, p_group_size);
      v_group_start := util_pkg.get_page_start(v_group_number, p_group_size);
      --!_!v_group_start := v_i;
      ------------------------------
    end if;
    ------------------------------
    if v_skip_group
    then
      ------------------------------
      --!_!duplicate previous error
      ------------------------------
      p_error_code(v_i) := p_error_code(v_i - 1);
      p_error_message(v_i) := p_error_message(v_i - 1);
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    v_cur_allowed_and_done := false;
    util_pkg.set_ok(p_error_code(v_i), p_error_message(v_i));
    ------------------------------
    if p_ap_id(v_i) is null
    then
      ------------------------------
      if (1 = 0
        or (v_nullable_group_head and v_index_in_group = 1) --!_! new group
        or (v_nullable_group_tail and v_index_in_group > 1) --!_! group continues
      )
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      else
        ------------------------------
        p_error_code(v_i) := util_pkg.c_ora_object_empty;
        p_error_message(v_i) := util_pkg.c_msg_object_empty;
        ------------------------------
      end if;
      ------------------------------
    elsif is_ap_pstatus_can_change(p_ap_id(v_i), p_status(v_i), p_date(v_i), p_error_code(v_i), p_error_message(v_i))
    then
      ------------------------------
      set_1ap_pstatus_i
      (
        p_ap_id => p_ap_id(v_i),
        p_status => p_status(v_i),
        p_date => p_date(v_i),
        p_user_id => p_user_id(v_i),
        p_lock_sc => p_lock_sc,
        p_error_code => p_error_code(v_i),
        p_error_message => p_error_message(v_i)
      );
      ------------------------------
      if util_pkg.is_ok(p_error_code(v_i))
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    if not v_cur_allowed_and_done
    then
      ------------------------------
      rollback to sp_set_ap_pstatus_ii_group;
      ------------------------------
      v_res := false;
      v_skip_group := true;
      ------------------------------
      if v_propagate_group_error and v_index_in_group > 1 --!_! group continues
      then
        ------------------------------
        setup_group_error_for_grp_head
        (
          p_problem_id => p_ap_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
      end if;
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        rollback to sp_set_ap_pstatus_ii;
        ------------------------------
        setup_group_error_for_all
        (
          p_problem_id => p_ap_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_ap_pstatus_i
(
    p_ap_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean;
  cl_group_size number := 1;
  --
  v_error_code ct_number;
  v_error_message ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_ap_id, 'p_ap_id');
  ------------------------------
  v_res := set_ap_pstatus_ii
  (
    p_ap_id => p_ap_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_sc => p_lock_sc,
    p_group_size => cl_group_size,
    p_nullable_group_head => false,
    p_nullable_group_tail => true,
    p_propagate_group_error => TRUE,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code;
  p_error_message := v_error_message;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function set_ap_pstatus
(
    p_ap_id ct_number,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
begin
  ------------------------------
  return set_ap_pstatus_i
  (
    p_ap_id => p_ap_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_sc => p_lock_sc,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_ap_pstatus2
(
    p_ap_id ct_number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_status ct_varchar_s;
  v_date ct_date;
  v_user_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_ap_id, 'p_ap_id');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_sc is null, 'p_lock_sc');
  ------------------------------
  v_main_count := p_ap_id.count;
  ------------------------------
  util_pkg.resize_ct_varchar_s(v_status, v_main_count);
  util_pkg.resize_ct_date(v_date, v_main_count);
  util_pkg.resize_ct_number(v_user_id, v_main_count);
  ------------------------------
  util_pkg.fill_ct_varchar_s(v_status, p_status);
  util_pkg.fill_ct_date(v_date, p_date);
  util_pkg.fill_ct_number(v_user_id, p_user_id);
  ------------------------------
  return set_ap_pstatus
  (
    p_ap_id => p_ap_id,
    p_status => v_status,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_sc => p_lock_sc,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_ap_pstatus3
(
    p_ap_id number,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_ap_id ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  v_res := set_ap_pstatus2
  (
    p_ap_id => v_ap_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_lock_sc => p_lock_sc,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_1naap_status_ii
(
    p_na_id number,
    p_ap_id number,
    p_link_type_code varchar2,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_lock_sc boolean
)
is
  v_lock_pn boolean := util_pkg.bool_to_bool_2val(p_lock_pn);
  v_lock_sc boolean := util_pkg.bool_to_bool_2val(p_lock_sc);
  v_date_to_prev date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_link_type_code is null, 'p_link_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  if v_lock_pn
  then
    ------------------------------
    util_ri.xlock_1pn(p_na_id);
    ------------------------------
  end if;
  ------------------------------
  if v_lock_sc and p_ap_id is not null
  then
    ------------------------------
    util_ri.xlock_1sc(p_ap_id);
    ------------------------------
  end if;
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(p_date);
  ------------------------------
  update /*+ index_asc(z, I_NETADDRACCPO_NET_ADDRESS_ID2)*/
    network_address_access_point z
  set
    to_date = v_date_to_prev,
    date_of_change = sysdate,
    user_id_of_change = p_user_id
  where 1 = 1
    and network_address_id = p_na_id
    and v_date_to_prev between from_date and nvl(to_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  ;
  ------------------------------
  if p_ap_id is null
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  insert into network_address_access_point
  (
    access_point_id,
    network_address_id,
    link_type_code,
    from_date,
    to_date,
    date_of_change,
    user_id_of_change
  )
  values
  (
    p_ap_id,
    p_na_id,
    p_link_type_code,
    p_date,
    null,
    sysdate,
    p_user_id
  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_1naap_status_i
(
    p_na_id number,
    p_ap_id number,
    p_link_type_code varchar2,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  set_1naap_status_ii
  (
    p_na_id => p_na_id,
    p_ap_id => p_ap_id,
    p_link_type_code => p_link_type_code,
    p_date => p_date,
    p_user_id => p_user_id,
    p_lock_pn => p_lock_pn,
    p_lock_sc => p_lock_sc
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! last p_error_code(v_i) in group shows whole group status
--!_! first erroneous p_error_code(v_i) in group shows real error point
----------------------------------!---------------------------------------------
function set_naap_status_ii
(
    p_na_id ct_number,
    p_ap_id ct_number,
    p_link_type_code ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean := true;
  v_nullable_group_head boolean := util_pkg.bool_to_bool_2val(p_nullable_group_head);
  v_nullable_group_tail boolean := util_pkg.bool_to_bool_2val(p_nullable_group_tail);
  v_propagate_group_error boolean := util_pkg.bool_to_bool_2val(p_propagate_group_error);
  v_main_count number;
  v_cur_allowed_and_done boolean;
  v_skip_group boolean;
  v_index_in_group number;
  v_group_number number;
  v_group_start number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheckP_ct_number(p_ap_id, 'p_ap_id');
  util_pkg.XCheckP_ct_varchar_s(p_link_type_code, 'p_link_type_code');
  util_pkg.XCheckP_ct_date(p_date, 'p_date');
  util_pkg.XCheckP_ct_number(p_user_id, 'p_user_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_pn is null, 'p_lock_pn');
  util_pkg.XCheck_Cond_Missing(p_lock_sc is null, 'p_lock_sc');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_lack is null, 'p_silent_proper_lack');
  util_pkg.XCheck_Cond_Missing(p_silent_break_actual is null, 'p_silent_break_actual');
  util_pkg.XCheck_Cond_Missing(p_group_size is null, 'p_group_size');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_head is null, 'p_nullable_group_head');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_tail is null, 'p_nullable_group_tail');
  util_pkg.XCheck_Cond_Missing(p_propagate_group_error is null, 'p_propagate_group_error');
  ------------------------------
  v_main_count := p_na_id.count;
  util_pkg.XCheck_Cond_Invalid(p_na_id.count != v_main_count, 'p_na_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_ap_id.count != v_main_count, 'p_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_link_type_code.count != v_main_count, 'p_link_type_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_date.count != v_main_count, 'p_date.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_user_id.count != v_main_count, 'p_user_id.count != v_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_group_size != trunc(p_group_size), 'p_group_size != trunc(p_group_size)');
  util_pkg.XCheck_Cond_Invalid(p_group_size <= 0, 'p_group_size <= 0');
  util_pkg.XCheck_Cond_Invalid(p_group_size > v_main_count, 'p_group_size > v_main_count');
  util_pkg.XCheck_Cond_Invalid(mod(v_main_count, p_group_size) != 0, 'mod(v_main_count, p_group_size) != 0');
  ------------------------------
  setup_common_error(v_main_count, util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
  ------------------------------
  savepoint sp_set_naap_status_ii;
  ------------------------------
  v_skip_group := false;
  ------------------------------
  --!_!for v_i in p_na_id.first..p_na_id.last
  ------------------------------
  for v_i in 1..p_na_id.count
  loop
    ------------------------------
    v_index_in_group := util_pkg.get_index_on_page(v_i, p_group_size);
    ------------------------------
    if v_index_in_group = 1 --!_! new group
    then
      ------------------------------
      savepoint sp_set_naap_status_ii_group;
      ------------------------------
      v_skip_group := false;
      ------------------------------
      v_group_number := util_pkg.get_page_number(v_i, p_group_size);
      v_group_start := util_pkg.get_page_start(v_group_number, p_group_size);
      --!_!v_group_start := v_i;
      ------------------------------
    end if;
    ------------------------------
    if v_skip_group
    then
      ------------------------------
      --!_!duplicate previous error
      ------------------------------
      p_error_code(v_i) := p_error_code(v_i - 1);
      p_error_message(v_i) := p_error_message(v_i - 1);
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    v_cur_allowed_and_done := false;
    util_pkg.set_ok(p_error_code(v_i), p_error_message(v_i));
    ------------------------------
    if p_na_id(v_i) is null
    then
      ------------------------------
      if (1 = 0
        or (v_nullable_group_head and v_index_in_group = 1) --!_! new group
        or (v_nullable_group_tail and v_index_in_group > 1) --!_! group continues
      )
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      else
        ------------------------------
        p_error_code(v_i) := util_pkg.c_ora_object_empty;
        p_error_message(v_i) := util_pkg.c_msg_object_empty;
        ------------------------------
      end if;
      ------------------------------
    elsif is_naap_status_can_change
    (
      p_network_address_id => p_na_id(v_i),
      p_access_point_id => p_ap_id(v_i),
      p_date => p_date(v_i),
      p_silent_proper_lack => p_silent_proper_lack,
      p_silent_break_actual => p_silent_break_actual,
      p_error_code => p_error_code(v_i),
      p_error_message => p_error_message(v_i)
    )
    then
      ------------------------------
      set_1naap_status_i
      (
        p_na_id => p_na_id(v_i),
        p_ap_id => p_ap_id(v_i),
        p_link_type_code => p_link_type_code(v_i),
        p_date => p_date(v_i),
        p_user_id => p_user_id(v_i),
        p_lock_pn => p_lock_pn,
        p_lock_sc => p_lock_sc,
        p_error_code => p_error_code(v_i),
        p_error_message => p_error_message(v_i)
      );
      ------------------------------
      if util_pkg.is_ok(p_error_code(v_i))
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    if not v_cur_allowed_and_done
    then
      ------------------------------
      rollback to sp_set_naap_status_ii_group;
      ------------------------------
      v_res := false;
      v_skip_group := true;
      ------------------------------
      if v_propagate_group_error and v_index_in_group > 1 --!_! group continues
      then
        ------------------------------
        setup_group_error_for_grp_head
        (
          p_problem_id => p_na_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
      end if;
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        rollback to sp_set_naap_status_ii;
        ------------------------------
        setup_group_error_for_all
        (
          p_problem_id => p_na_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_naap_status_i
(
    p_na_id ct_number,
    p_ap_id ct_number,
    p_link_type_code ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_same_status_for_m_and_l boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean;
  cl_group_size number := 2;
  v_index number;
  v_main_count number;
  v_main_count2 number;
  --
  v_na_id ct_number;
  v_ap_id ct_number;
  v_link_type_code ct_varchar_s;
  v_date ct_date;
  v_user_id ct_number;
  --
  v_map_m ct_number;
  v_map_l ct_number;
  v_na_id_m ct_number;
  v_na_id_l ct_number;
  v_ap_id_m ct_number;
  v_ap_id_l ct_number;
  v_link_type_code_m ct_varchar_s;
  v_link_type_code_l ct_varchar_s;
  v_date_m ct_date;
  v_date_l ct_date;
  v_user_id_m ct_number;
  v_user_id_l ct_number;
  --
  v_na_id_err ct_number;
  v_map_err1 ct_number;
  v_map_err2 ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
  --
  v_def_link_type_codes ct_varchar_s;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_na_id, 'p_na_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_pn is null, 'p_lock_pn');
  util_pkg.XCheck_Cond_Missing(p_lock_sc is null, 'p_lock_sc');
  util_pkg.XCheck_Cond_Missing(p_same_status_for_m_and_l is null, 'p_same_status_for_m_and_l');
  ------------------------------
  v_def_link_type_codes := util_ri.split_str_list(install_pkg.nnget_option_str(c_sett_naap_def_link_typecodes, NULL, c_def_naap_def_link_typecodes), true);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(v_def_link_type_codes) != cl_group_size, 'v_def_link_type_codes.count != cl_group_size');
  util_pkg.XCheckP_FS_ct_varchar_s(v_def_link_type_codes, 'v_def_link_type_codes');
  ------------------------------
  util_ri.prepare_as_pnlnk2_fuzzy(p_na_id, sysdate, v_na_id_m, v_na_id_l);
  ------------------------------
  if p_break_on_error
  then
    ------------------------------
    v_na_id_err := util_ri.get_pnlnk_not_found(p_na_id, v_na_id_m, v_na_id_l);
    ------------------------------
    if util_pkg.get_count_ct_number(v_na_id_err) > 0
    then
      ------------------------------
      setup_common_error(util_pkg.get_count_ct_number(p_na_id), util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
      setup_common_error(util_pkg.get_count_ct_number(v_na_id_err), util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found, v_error_code, v_error_message);
      ------------------------------
      v_map_err1 := util_pkg.map_ct_number(v_na_id_err, p_na_id, TRUE, FALSE);
      ------------------------------
      util_pkg.set_by_pos_ct_number(p_error_code, v_error_code, v_map_err1);
      util_pkg.set_by_pos_ct_varchar(p_error_message, v_error_message, v_map_err1);
      ------------------------------
      return FALSE;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  --!_! initial error filling
  ------------------------------
  setup_common_error(util_pkg.get_count_ct_number(p_na_id), util_loc_pkg.c_ora_phone_not_found, util_loc_pkg.c_msg_phone_not_found, p_error_code, p_error_message);
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(v_na_id_m);
  ------------------------------
  if NOT p_break_on_error and v_main_count = 0
  then
    ------------------------------
    return FALSE;
    ------------------------------
  end if;
  ------------------------------
  --!_! p_trim_empty => FALSE in map_ct_number to save size of v_main_count = v_na_id_m.count
  --!_! v_%_m, v_%_l have same .count
  ------------------------------
  v_map_m := util_pkg.map_ct_number(v_na_id_m, p_na_id, FALSE);
  v_map_l := util_pkg.map_ct_number(v_na_id_l, p_na_id, FALSE);
  ------------------------------
  v_ap_id_m := util_pkg.get_by_pos_ct_number(p_ap_id, v_map_m, FALSE);
  v_ap_id_l := util_pkg.get_by_pos_ct_number(p_ap_id, v_map_l, FALSE);
  ------------------------------
  v_link_type_code_m := util_pkg.get_by_pos_ct_varchar_s(p_link_type_code, v_map_m, FALSE);
  v_link_type_code_l := util_pkg.get_by_pos_ct_varchar_s(p_link_type_code, v_map_l, FALSE);
  ------------------------------
  v_date_m := util_pkg.get_by_pos_ct_date(p_date, v_map_m, FALSE);
  v_date_l := util_pkg.get_by_pos_ct_date(p_date, v_map_l, FALSE);
  ------------------------------
  v_user_id_m := util_pkg.get_by_pos_ct_number(p_user_id, v_map_m, FALSE);
  v_user_id_l := util_pkg.get_by_pos_ct_number(p_user_id, v_map_l, FALSE);
  ------------------------------
  v_main_count2 := cl_group_size*v_main_count;
  util_pkg.resize_ct_number(v_na_id, v_main_count2);
  util_pkg.resize_ct_number(v_ap_id, v_main_count2);
  util_pkg.resize_ct_varchar_s(v_link_type_code, v_main_count2);
  util_pkg.resize_ct_date(v_date, v_main_count2);
  util_pkg.resize_ct_number(v_user_id, v_main_count2);
  ------------------------------
  --!_!for v_i in v_na_id_m.first..v_na_id_m.last
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_index := util_pkg.get_page_start(v_i, cl_group_size);
    ------------------------------
    v_na_id(v_index) := v_na_id_m(v_i);
    v_na_id(v_index + 1) := v_na_id_l(v_i); --!_! can be null - it defines behavior in set_na_status_ii
    ------------------------------
    --!_! (v_index + 1)'th elements below are always not null (if no error) but may be not used according v_na_id(v_index + 1)
    ------------------------------
    --!_! implicit loop till cl_group_size
    ------------------------------
    v_ap_id(v_index) := nvl(v_ap_id_m(v_i), v_ap_id_l(v_i));
    v_ap_id(v_index + 1) := nvl(v_ap_id_l(v_i), v_ap_id_m(v_i));
    ------------------------------
    ------------------------------
    v_link_type_code(v_index) := v_link_type_code_m(v_i);
    ------------------------------
    if 1 = 1
      and v_ap_id_m(v_i) is NULL
      and v_ap_id_l(v_i) is NOT NULL --!_! not closing
    then
      ------------------------------
      v_link_type_code(v_index) := v_def_link_type_codes(util_ri.c_index_one); --!_! then using default link_type_code
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    v_link_type_code(v_index + 1) := v_link_type_code_l(v_i);
    ------------------------------
    if 1 = 1
      and v_ap_id_l(v_i) is NULL
      and v_ap_id_m(v_i) is NOT NULL --!_! not closing
    then
      ------------------------------
      v_link_type_code(v_index + 1) := v_def_link_type_codes(util_ri.c_index_one + 1); --!_! then using default link_type_code
      ------------------------------
    end if;
    ------------------------------
    ------------------------------
    v_date(v_index) := nvl(v_date_m(v_i), v_date_l(v_i));
    v_date(v_index + 1) := nvl(v_date_l(v_i), v_date_m(v_i));
    v_user_id(v_index) := nvl(v_user_id_m(v_i), v_user_id_l(v_i));
    v_user_id(v_index + 1) := nvl(v_user_id_l(v_i), v_user_id_m(v_i));
    ------------------------------
    util_pkg.XCheck_Cond_Missing
    (
      1 = 0
      --!_!or (v_ap_id(v_index) is null)
      or (v_ap_id(v_index) is NOT null and v_link_type_code(v_index) is null)
      or (v_ap_id(v_index + 1) is NOT null and v_link_type_code(v_index + 1) is null)
      or (v_date(v_index) is null)
      or (v_user_id(v_index) is null)
      , 'v_date or v_user_id'
    );
    ------------------------------
    if p_same_status_for_m_and_l
      and (1 = 0
        or (v_ap_id(v_index + 1) is NOT null and v_ap_id(v_index) != v_ap_id(v_index + 1))
        --!_!or (v_link_type_code(v_index + 1) is NOT null and v_link_type_code(v_index) != v_link_type_code(v_index + 1))
        or (v_date(v_index) != v_date(v_index + 1))
      )
    then
      ------------------------------
      util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'In group are not same v_ap_id or v_date');
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  v_res := set_naap_status_ii
  (
    p_na_id => v_na_id,
    p_ap_id => v_ap_id,
    p_link_type_code => v_link_type_code,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_pn => p_lock_pn,
    p_lock_sc => p_lock_sc,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_group_size => cl_group_size,
    p_nullable_group_head => false,
    p_nullable_group_tail => true,
    p_propagate_group_error => TRUE,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  v_map_err1 := util_pkg.map_ct_number(v_na_id, p_na_id, TRUE, FALSE);
  v_map_err2 := util_pkg.map_ct_number(v_na_id, p_na_id, TRUE, TRUE);
  ------------------------------
  v_error_code := util_pkg.get_by_pos_ct_number(v_error_code, v_map_err2, TRUE);
  v_error_message := util_pkg.get_by_pos_ct_varchar(v_error_message, v_map_err2, TRUE);
  ------------------------------
  util_pkg.set_by_pos_ct_number(p_error_code, v_error_code, v_map_err1);
  util_pkg.set_by_pos_ct_varchar(p_error_message, v_error_message, v_map_err1);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function set_naap_status
(
    p_na_id ct_number,
    p_ap_id ct_number,
    p_link_type_code ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
begin
  ------------------------------
  return set_naap_status_i
  (
    p_na_id => p_na_id,
    p_ap_id => p_ap_id,
    p_link_type_code => p_link_type_code,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_pn => p_lock_pn,
    p_lock_sc => p_lock_sc,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_same_status_for_m_and_l => TRUE,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_naap_status2
(
    p_na_id ct_number,
    p_ap_id ct_number,
    p_link_type_code ct_varchar_s,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_date ct_date;
  v_user_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheckP_ct_number(p_ap_id, 'p_ap_id');
  util_pkg.XCheckP_ct_varchar_s(p_link_type_code, 'p_link_type_code');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_pn is null, 'p_lock_pn');
  util_pkg.XCheck_Cond_Missing(p_lock_sc is null, 'p_lock_sc');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_lack is null, 'p_silent_proper_lack');
  util_pkg.XCheck_Cond_Missing(p_silent_break_actual is null, 'p_silent_break_actual');
  ------------------------------
  v_main_count := p_na_id.count;
  ------------------------------
  util_pkg.resize_ct_date(v_date, v_main_count);
  util_pkg.resize_ct_number(v_user_id, v_main_count);
  ------------------------------
  util_pkg.fill_ct_date(v_date, p_date);
  util_pkg.fill_ct_number(v_user_id, p_user_id);
  ------------------------------
  return set_naap_status
  (
    p_na_id => p_na_id,
    p_ap_id => p_ap_id,
    p_link_type_code => p_link_type_code,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_pn => p_lock_pn,
    p_lock_sc => p_lock_sc,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_naap_status2_close
(
    p_na_id ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_ap_id ct_number;
  v_link_type_code ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_pn is null, 'p_lock_pn');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_lack is null, 'p_silent_proper_lack');
  util_pkg.XCheck_Cond_Missing(p_silent_break_actual is null, 'p_silent_break_actual');
  ------------------------------
  v_main_count := p_na_id.count;
  ------------------------------
  util_pkg.resize_ct_number(v_ap_id, v_main_count);
  util_pkg.resize_ct_varchar_s(v_link_type_code, v_main_count);
  ------------------------------
  util_pkg.fill_ct_number(v_ap_id, null);
  util_pkg.fill_ct_varchar_s(v_link_type_code, null);
  ------------------------------
  return set_naap_status2
  (
    p_na_id => p_na_id,
    p_ap_id => v_ap_id,
    p_link_type_code => v_link_type_code,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_pn => p_lock_pn,
    p_lock_sc => p_lock_pn, --!_!
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_naap_status3_open_second
(
    p_na_id ct_number,
    p_ap_id number,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_ap_id ct_number;
  v_link_type_code ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_id, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  ------------------------------
  v_main_count := p_na_id.count;
  ------------------------------
  util_pkg.resize_ct_number(v_ap_id, v_main_count);
  util_pkg.resize_ct_varchar_s(v_link_type_code, v_main_count);
  ------------------------------
  util_pkg.fill_ct_number(v_ap_id, p_ap_id);
  util_pkg.fill_ct_varchar_s(v_link_type_code, util_ri.c_NAAP_LINK_TYPE_CODE_SECOND);
  ------------------------------
  return set_naap_status2
  (
    p_na_id => p_na_id,
    p_ap_id => v_ap_id,
    p_link_type_code => v_link_type_code,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_lock_pn => p_lock_pn,
    p_lock_sc => p_lock_sc,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_naap_status3
(
    p_na_id number,
    p_ap_id number,
    p_link_type_code varchar2,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_na_id ct_number;
  v_ap_id ct_number;
  v_link_type_code ct_varchar_s;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_link_type_code is null, 'p_link_type_code');
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  util_pkg.add_ct_varchar_s_val(v_link_type_code, p_link_type_code);
  ------------------------------
  v_res := set_naap_status2
  (
    p_na_id => v_na_id,
    p_ap_id => v_ap_id,
    p_link_type_code => v_link_type_code,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_lock_pn => p_lock_pn,
    p_lock_sc => p_lock_sc,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_naap_status3_close
(
    p_na_id number,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_na_id ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_na_id, p_na_id);
  ------------------------------
  v_res := set_naap_status2_close
  (
    p_na_id => v_na_id,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_lock_pn => p_lock_pn,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_1sc_pa_ii
(
    p_ap_id number,
    p_pa number,
    p_user_id number,
    p_lock_sc boolean
)
is
  v_lock_sc boolean := util_pkg.bool_to_bool_2val(p_lock_sc);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  if v_lock_sc
  then
    ------------------------------
    util_ri.xlock_1sc(p_ap_id);
    ------------------------------
  end if;
  ------------------------------
  update /*+ index_asc(z, PK_SIM_CARD)*/
    sim_card z
  set
    personal_account = p_pa,
    date_of_change = sysdate,
    user_id_of_change = p_user_id
  where 1 = 1
    and access_point_id = p_ap_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_1appa_status_ii
(
    p_ap_id number,
    p_pa number,
    p_date date,
    p_user_id number,
    p_lock_sc boolean
)
is
  v_lock_sc boolean := util_pkg.bool_to_bool_2val(p_lock_sc);
  v_date_to_prev date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  if v_lock_sc
  then
    ------------------------------
    util_ri.xlock_1sc(p_ap_id);
    ------------------------------
  end if;
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(p_date);
  ------------------------------
  update /*+ index_asc(z, I_APPA_ACCESS_POINT_ID)*/
    access_point_personal_account z
  set
    to_date = v_date_to_prev,
    date_of_change = sysdate,
    user_id_of_change = p_user_id
  where 1 = 1
    and access_point_id = p_ap_id
    and v_date_to_prev between from_date and nvl(to_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  ;
  ------------------------------
  set_1sc_pa_ii
  (
    p_ap_id => p_ap_id,
    p_pa => p_pa,
    p_user_id => p_user_id,
    p_lock_sc => FALSE
  );
  ------------------------------
  if p_pa is null
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  insert into access_point_personal_account
  (
    access_point_id,
    personal_account,
    from_date,
    to_date,
    date_of_change,
    user_id_of_change
  )
  values
  (
    p_ap_id,
    p_pa,
    p_date,
    null,
    sysdate,
    p_user_id
  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_1appa_status_i
(
    p_ap_id number,
    p_pa number,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  set_1appa_status_ii
  (
    p_ap_id => p_ap_id,
    p_pa => p_pa,
    p_date => p_date,
    p_user_id => p_user_id,
    p_lock_sc => p_lock_sc
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! last p_error_code(v_i) in group shows whole group status
--!_! first erroneous p_error_code(v_i) in group shows real error point
----------------------------------!---------------------------------------------
function set_appa_status_ii
(
    p_ap_id ct_number,
    p_pa ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean := true;
  v_nullable_group_head boolean := util_pkg.bool_to_bool_2val(p_nullable_group_head);
  v_nullable_group_tail boolean := util_pkg.bool_to_bool_2val(p_nullable_group_tail);
  v_propagate_group_error boolean := util_pkg.bool_to_bool_2val(p_propagate_group_error);
  v_main_count number;
  v_cur_allowed_and_done boolean;
  v_skip_group boolean;
  v_index_in_group number;
  v_group_number number;
  v_group_start number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_ap_id, 'p_ap_id');
  util_pkg.XCheckP_ct_number(p_pa, 'p_pa');
  util_pkg.XCheckP_ct_date(p_date, 'p_date');
  util_pkg.XCheckP_ct_number(p_user_id, 'p_user_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_sc is null, 'p_lock_sc');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_lack is null, 'p_silent_proper_lack');
  util_pkg.XCheck_Cond_Missing(p_silent_break_actual is null, 'p_silent_break_actual');
  util_pkg.XCheck_Cond_Missing(p_group_size is null, 'p_group_size');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_head is null, 'p_nullable_group_head');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_tail is null, 'p_nullable_group_tail');
  util_pkg.XCheck_Cond_Missing(p_propagate_group_error is null, 'p_propagate_group_error');
  ------------------------------
  v_main_count := p_ap_id.count;
  util_pkg.XCheck_Cond_Invalid(p_ap_id.count != v_main_count, 'p_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_pa.count != v_main_count, 'p_pa.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_date.count != v_main_count, 'p_date.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_user_id.count != v_main_count, 'p_user_id.count != v_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_group_size != trunc(p_group_size), 'p_group_size != trunc(p_group_size)');
  util_pkg.XCheck_Cond_Invalid(p_group_size <= 0, 'p_group_size <= 0');
  util_pkg.XCheck_Cond_Invalid(p_group_size > v_main_count, 'p_group_size > v_main_count');
  util_pkg.XCheck_Cond_Invalid(mod(v_main_count, p_group_size) != 0, 'mod(v_main_count, p_group_size) != 0');
  ------------------------------
  setup_common_error(v_main_count, util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
  ------------------------------
  savepoint sp_set_appa_status_ii;
  ------------------------------
  v_skip_group := false;
  ------------------------------
  --!_!for v_i in p_ap_id.first..p_ap_id.last
  ------------------------------
  for v_i in 1..p_ap_id.count
  loop
    ------------------------------
    v_index_in_group := util_pkg.get_index_on_page(v_i, p_group_size);
    ------------------------------
    if v_index_in_group = 1 --!_! new group
    then
      ------------------------------
      savepoint sp_set_appa_status_ii_group;
      ------------------------------
      v_skip_group := false;
      ------------------------------
      v_group_number := util_pkg.get_page_number(v_i, p_group_size);
      v_group_start := util_pkg.get_page_start(v_group_number, p_group_size);
      --!_!v_group_start := v_i;
      ------------------------------
    end if;
    ------------------------------
    if v_skip_group
    then
      ------------------------------
      --!_!duplicate previous error
      ------------------------------
      p_error_code(v_i) := p_error_code(v_i - 1);
      p_error_message(v_i) := p_error_message(v_i - 1);
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    v_cur_allowed_and_done := false;
    util_pkg.set_ok(p_error_code(v_i), p_error_message(v_i));
    ------------------------------
    if p_ap_id(v_i) is null
    then
      ------------------------------
      if (1 = 0
        or (v_nullable_group_head and v_index_in_group = 1) --!_! new group
        or (v_nullable_group_tail and v_index_in_group > 1) --!_! group continues
      )
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      else
        ------------------------------
        p_error_code(v_i) := util_pkg.c_ora_object_empty;
        p_error_message(v_i) := util_pkg.c_msg_object_empty;
        ------------------------------
      end if;
      ------------------------------
    elsif is_appa_status_can_change
    (
      p_access_point_id => p_ap_id(v_i),
      p_personal_account => p_pa(v_i),
      p_date => p_date(v_i),
      p_silent_proper_lack => p_silent_proper_lack,
      p_silent_break_actual => p_silent_break_actual,
      p_error_code => p_error_code(v_i),
      p_error_message => p_error_message(v_i)
    )
    then
      ------------------------------
      set_1appa_status_i
      (
        p_ap_id => p_ap_id(v_i),
        p_pa => p_pa(v_i),
        p_date => p_date(v_i),
        p_user_id => p_user_id(v_i),
        p_lock_sc => p_lock_sc,
        p_error_code => p_error_code(v_i),
        p_error_message => p_error_message(v_i)
      );
      ------------------------------
      if util_pkg.is_ok(p_error_code(v_i))
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    if not v_cur_allowed_and_done
    then
      ------------------------------
      rollback to sp_set_appa_status_ii_group;
      ------------------------------
      v_res := false;
      v_skip_group := true;
      ------------------------------
      if v_propagate_group_error and v_index_in_group > 1 --!_! group continues
      then
        ------------------------------
        setup_group_error_for_grp_head
        (
          p_problem_id => p_ap_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
      end if;
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        rollback to sp_set_appa_status_ii;
        ------------------------------
        setup_group_error_for_all
        (
          p_problem_id => p_ap_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_appa_status_i
(
    p_ap_id ct_number,
    p_pa ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean;
  cl_group_size number := 1;
  --
  v_error_code ct_number;
  v_error_message ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_ap_id, 'p_ap_id');
  ------------------------------
  v_res := set_appa_status_ii
  (
    p_ap_id => p_ap_id,
    p_pa => p_pa,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_sc => p_lock_sc,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_group_size => cl_group_size,
    p_nullable_group_head => false,
    p_nullable_group_tail => true,
    p_propagate_group_error => TRUE,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code;
  p_error_message := v_error_message;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function set_appa_status
(
    p_ap_id ct_number,
    p_pa ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
begin
  ------------------------------
  return set_appa_status_i
  (
    p_ap_id => p_ap_id,
    p_pa => p_pa,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_sc => p_lock_sc,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_appa_status2
(
    p_ap_id ct_number,
    p_pa ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_date ct_date;
  v_user_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_ap_id, 'p_ap_id');
  util_pkg.XCheckP_ct_number(p_pa, 'p_pa');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_sc is null, 'p_lock_sc');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_lack is null, 'p_silent_proper_lack');
  util_pkg.XCheck_Cond_Missing(p_silent_break_actual is null, 'p_silent_break_actual');
  ------------------------------
  v_main_count := p_ap_id.count;
  ------------------------------
  util_pkg.resize_ct_date(v_date, v_main_count);
  util_pkg.resize_ct_number(v_user_id, v_main_count);
  ------------------------------
  util_pkg.fill_ct_date(v_date, p_date);
  util_pkg.fill_ct_number(v_user_id, p_user_id);
  ------------------------------
  return set_appa_status
  (
    p_ap_id => p_ap_id,
    p_pa => p_pa,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_sc => p_lock_sc,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_appa_status2_close
(
    p_ap_id ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_pa ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_ap_id, 'p_ap_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_sc is null, 'p_lock_sc');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_lack is null, 'p_silent_proper_lack');
  util_pkg.XCheck_Cond_Missing(p_silent_break_actual is null, 'p_silent_break_actual');
  ------------------------------
  v_main_count := p_ap_id.count;
  ------------------------------
  util_pkg.resize_ct_number(v_pa, v_main_count);
  ------------------------------
  util_pkg.fill_ct_number(v_pa, null);
  ------------------------------
  return set_appa_status2
  (
    p_ap_id => p_ap_id,
    p_pa => v_pa,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_sc => p_lock_sc,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_appa_status3_open
(
    p_ap_id ct_number,
    p_pa number,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_pa ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_ap_id, 'p_ap_id');
  util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  ------------------------------
  v_main_count := p_ap_id.count;
  ------------------------------
  util_pkg.resize_ct_number(v_pa, v_main_count);
  ------------------------------
  util_pkg.fill_ct_number(v_pa, p_pa);
  ------------------------------
  return set_appa_status2
  (
    p_ap_id => p_ap_id,
    p_pa => v_pa,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_lock_sc => p_lock_sc,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_appa_status3
(
    p_ap_id number,
    p_pa number,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_ap_id ct_number;
  v_pa ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  util_pkg.add_ct_number_val(v_pa, p_pa);
  ------------------------------
  v_res := set_appa_status2
  (
    p_ap_id => v_ap_id,
    p_pa => v_pa,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_lock_sc => p_lock_sc,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_appa_status3_close
(
    p_ap_id number,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_ap_id ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  ------------------------------
  v_res := set_appa_status2_close
  (
    p_ap_id => v_ap_id,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_lock_sc => p_lock_sc,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_1pah_status_ii
(
    p_pa number,
    p_host_id number,
    p_date date,
    p_user_id number
)
is
  v_date_to_prev date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  --!_!util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(p_date);
  ------------------------------
  update /*+ index_asc(z, I_PA_PERSONAL_ACCOUNT_HISTORY)*/
    personal_account_history z
  set
    end_date = v_date_to_prev,
    date_of_changed = sysdate,
    user_id_of_change = p_user_id
  where 1 = 1
    and personal_account = p_pa
    and v_date_to_prev between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  ;
  ------------------------------
  if p_host_id is null
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  insert into personal_account_history
  (
    personal_account,
    start_date,
    end_date,
    balance_storage,
    user_id_of_change,
    date_of_changed
  )
  values
  (
    p_pa,
    p_date,
    null,
    p_host_id,
    p_user_id,
    sysdate
  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_1pah_status_i
(
    p_pa number,
    p_host_id number,
    p_date date,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  set_1pah_status_ii
  (
    p_pa => p_pa,
    p_host_id => p_host_id,
    p_date => p_date,
    p_user_id => p_user_id
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! last p_error_code(v_i) in group shows whole group status
--!_! first erroneous p_error_code(v_i) in group shows real error point
----------------------------------!---------------------------------------------
function set_pah_status_ii
(
    p_pa ct_number,
    p_host_id ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean := true;
  v_nullable_group_head boolean := util_pkg.bool_to_bool_2val(p_nullable_group_head);
  v_nullable_group_tail boolean := util_pkg.bool_to_bool_2val(p_nullable_group_tail);
  v_propagate_group_error boolean := util_pkg.bool_to_bool_2val(p_propagate_group_error);
  v_main_count number;
  v_cur_allowed_and_done boolean;
  v_skip_group boolean;
  v_index_in_group number;
  v_group_number number;
  v_group_start number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_pa, 'p_pa');
  util_pkg.XCheckP_ct_number(p_host_id, 'p_host_id');
  util_pkg.XCheckP_ct_date(p_date, 'p_date');
  util_pkg.XCheckP_ct_number(p_user_id, 'p_user_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_lack is null, 'p_silent_proper_lack');
  util_pkg.XCheck_Cond_Missing(p_silent_break_actual is null, 'p_silent_break_actual');
  util_pkg.XCheck_Cond_Missing(p_group_size is null, 'p_group_size');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_head is null, 'p_nullable_group_head');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_tail is null, 'p_nullable_group_tail');
  util_pkg.XCheck_Cond_Missing(p_propagate_group_error is null, 'p_propagate_group_error');
  ------------------------------
  v_main_count := p_pa.count;
  util_pkg.XCheck_Cond_Invalid(p_pa.count != v_main_count, 'p_pa.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_host_id.count != v_main_count, 'p_host_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_date.count != v_main_count, 'p_date.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_user_id.count != v_main_count, 'p_user_id.count != v_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_group_size != trunc(p_group_size), 'p_group_size != trunc(p_group_size)');
  util_pkg.XCheck_Cond_Invalid(p_group_size <= 0, 'p_group_size <= 0');
  util_pkg.XCheck_Cond_Invalid(p_group_size > v_main_count, 'p_group_size > v_main_count');
  util_pkg.XCheck_Cond_Invalid(mod(v_main_count, p_group_size) != 0, 'mod(v_main_count, p_group_size) != 0');
  ------------------------------
  setup_common_error(v_main_count, util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
  ------------------------------
  savepoint sp_set_pah_status_ii;
  ------------------------------
  v_skip_group := false;
  ------------------------------
  --!_!for v_i in p_pa.first..p_pa.last
  ------------------------------
  for v_i in 1..p_pa.count
  loop
    ------------------------------
    v_index_in_group := util_pkg.get_index_on_page(v_i, p_group_size);
    ------------------------------
    if v_index_in_group = 1 --!_! new group
    then
      ------------------------------
      savepoint sp_set_pah_status_ii_group;
      ------------------------------
      v_skip_group := false;
      ------------------------------
      v_group_number := util_pkg.get_page_number(v_i, p_group_size);
      v_group_start := util_pkg.get_page_start(v_group_number, p_group_size);
      --!_!v_group_start := v_i;
      ------------------------------
    end if;
    ------------------------------
    if v_skip_group
    then
      ------------------------------
      --!_!duplicate previous error
      ------------------------------
      p_error_code(v_i) := p_error_code(v_i - 1);
      p_error_message(v_i) := p_error_message(v_i - 1);
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    v_cur_allowed_and_done := false;
    util_pkg.set_ok(p_error_code(v_i), p_error_message(v_i));
    ------------------------------
    if p_pa(v_i) is null
    then
      ------------------------------
      if (1 = 0
        or (v_nullable_group_head and v_index_in_group = 1) --!_! new group
        or (v_nullable_group_tail and v_index_in_group > 1) --!_! group continues
      )
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      else
        ------------------------------
        p_error_code(v_i) := util_pkg.c_ora_object_empty;
        p_error_message(v_i) := util_pkg.c_msg_object_empty;
        ------------------------------
      end if;
      ------------------------------
    elsif is_pah_status_can_change
    (
      p_personal_account => p_pa(v_i),
      p_host_id => p_host_id(v_i),
      p_date => p_date(v_i),
      p_silent_proper_lack => p_silent_proper_lack,
      p_silent_break_actual => p_silent_break_actual,
      p_error_code => p_error_code(v_i),
      p_error_message => p_error_message(v_i)
    )
    then
      ------------------------------
      set_1pah_status_i
      (
        p_pa => p_pa(v_i),
        p_host_id => p_host_id(v_i),
        p_date => p_date(v_i),
        p_user_id => p_user_id(v_i),
        p_error_code => p_error_code(v_i),
        p_error_message => p_error_message(v_i)
      );
      ------------------------------
      if util_pkg.is_ok(p_error_code(v_i))
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    if not v_cur_allowed_and_done
    then
      ------------------------------
      rollback to sp_set_pah_status_ii_group;
      ------------------------------
      v_res := false;
      v_skip_group := true;
      ------------------------------
      if v_propagate_group_error and v_index_in_group > 1 --!_! group continues
      then
        ------------------------------
        setup_group_error_for_grp_head
        (
          p_problem_id => p_pa(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
      end if;
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        rollback to sp_set_pah_status_ii;
        ------------------------------
        setup_group_error_for_all
        (
          p_problem_id => p_pa(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_pah_status_i
(
    p_pa ct_number,
    p_host_id ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean;
  cl_group_size number := 1;
  --
  v_error_code ct_number;
  v_error_message ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_pa, 'p_pa');
  ------------------------------
  v_res := set_pah_status_ii
  (
    p_pa => p_pa,
    p_host_id => p_host_id,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_group_size => cl_group_size,
    p_nullable_group_head => false,
    p_nullable_group_tail => true,
    p_propagate_group_error => TRUE,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code;
  p_error_message := v_error_message;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function set_pah_status
(
    p_pa ct_number,
    p_host_id ct_number,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
begin
  ------------------------------
  return set_pah_status_i
  (
    p_pa => p_pa,
    p_host_id => p_host_id,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_pah_status2
(
    p_pa ct_number,
    p_host_id ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_date ct_date;
  v_user_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_pa, 'p_pa');
  util_pkg.XCheckP_ct_number(p_host_id, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_lack is null, 'p_silent_proper_lack');
  util_pkg.XCheck_Cond_Missing(p_silent_break_actual is null, 'p_silent_break_actual');
  ------------------------------
  v_main_count := p_pa.count;
  ------------------------------
  util_pkg.resize_ct_date(v_date, v_main_count);
  util_pkg.resize_ct_number(v_user_id, v_main_count);
  ------------------------------
  util_pkg.fill_ct_date(v_date, p_date);
  util_pkg.fill_ct_number(v_user_id, p_user_id);
  ------------------------------
  return set_pah_status
  (
    p_pa => p_pa,
    p_host_id => p_host_id,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_pah_status2_close
(
    p_pa ct_number,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_pa, 'p_pa');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_silent_proper_lack is null, 'p_silent_proper_lack');
  util_pkg.XCheck_Cond_Missing(p_silent_break_actual is null, 'p_silent_break_actual');
  ------------------------------
  v_main_count := p_pa.count;
  ------------------------------
  util_pkg.resize_ct_number(v_host_id, v_main_count);
  ------------------------------
  util_pkg.fill_ct_number(v_host_id, null);
  ------------------------------
  return set_pah_status2
  (
    p_pa => p_pa,
    p_host_id => v_host_id,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_pah_status3_open
(
    p_pa ct_number,
    p_host_id number,
    p_date date,
    p_user_id number,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_host_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_pa, 'p_pa');
  util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  ------------------------------
  v_main_count := p_pa.count;
  ------------------------------
  util_pkg.resize_ct_number(v_host_id, v_main_count);
  ------------------------------
  util_pkg.fill_ct_number(v_host_id, p_host_id);
  ------------------------------
  return set_pah_status2
  (
    p_pa => p_pa,
    p_host_id => v_host_id,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_pah_status3
(
    p_pa number,
    p_host_id number,
    p_date date,
    p_user_id number,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_pa ct_number;
  v_host_id ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  --!_!util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_pa, p_pa);
  util_pkg.add_ct_number_val(v_host_id, p_host_id);
  ------------------------------
  v_res := set_pah_status2
  (
    p_pa => v_pa,
    p_host_id => v_host_id,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_pah_status3_close
(
    p_pa number,
    p_date date,
    p_user_id number,
    p_silent_proper_lack boolean,
    p_silent_break_actual boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_pa ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  ------------------------------
  util_pkg.add_ct_number_val(v_pa, p_pa);
  ------------------------------
  v_res := set_pah_status2_close
  (
    p_pa => v_pa,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_silent_proper_lack => p_silent_proper_lack,
    p_silent_break_actual => p_silent_break_actual,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_1na_sel_cat_ii
(
    p_na_id number,
    p_sel_cat varchar2,
    p_date date,
    p_user_id number,
    p_lock_pn boolean
)
is
  v_lock_pn boolean := util_pkg.bool_to_bool_2val(p_lock_pn);
  v_date_to_prev date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_sel_cat is null, 'p_sel_cat');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  if v_lock_pn
  then
    ------------------------------
    util_ri.xlock_1pn(p_na_id);
    ------------------------------
  end if;
  ------------------------------
  v_date_to_prev := util_pkg.date_from2date_to_prev(p_date);
  ------------------------------
  update /*+ index_asc(z, I_PHONUSALCA_NET_ADDRESS_ID2)*/
    phone_number_salability_categ z
  set
    end_date = v_date_to_prev,
    date_of_change = sysdate,
    user_id_of_change = p_user_id
  where 1 = 1
    and network_address_id = p_na_id
    and v_date_to_prev between start_date and nvl(end_date, to_date('01.01.4000', 'dd.mm.yyyy'))
  ;
  ------------------------------
  insert into phone_number_salability_categ
  (
    salability_category_code,
    network_address_id,
    start_date,
    date_of_change,
    user_id_of_change,
    end_date
  )
  values
  (
    p_sel_cat,
    p_na_id,
    p_date,
    sysdate,
    p_user_id,
    null
  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function ins_1na_ii return number
is
  v_na_id number;
begin
  ------------------------------
  v_na_id := s_network_address.nextval;
  ------------------------------
  insert into network_address(network_address_id)
    values (v_na_id)
  ;
  ------------------------------
  return v_na_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_1phone_ii
(
    p_na_id varchar2,
    p_pns_id number,
    p_msisdn varchar2,
    p_user_id number
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_pns_id is null, 'p_pns_id');
  util_pkg.XCheck_Cond_Missing(p_msisdn is null, 'p_msisdn');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  insert into phone_number
  (
    network_address_id,
    phone_number_series_id,
    international_format,
    date_of_change,
    user_id_of_change,
    deleted
  )
  values
  (
    p_na_id,
    p_pns_id,
    p_msisdn,
    sysdate,
    p_user_id,
    null
  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_1phone_i
(
    p_msisdn varchar2,
    p_pns_id number,
    p_status varchar2,
    p_sal_cat varchar2,
    p_date date,
    p_user_id number,
    p_na_id out number,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  p_na_id := ins_1na_ii;
  ----------------
  ins_1phone_ii
  (
    p_na_id => p_na_id,
    p_pns_id => p_pns_id,
    p_msisdn => p_msisdn,
    p_user_id => p_user_id
  );
  ------------------------------
  set_1na_status_ii
  (
    p_na_id => p_na_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_na_trans_reason_code => NULL,
    p_lock_pn => FALSE
  );
  ------------------------------
  set_1na_sel_cat_ii
  (
    p_na_id => p_na_id,
    p_sel_cat => p_sal_cat,
    p_date => p_date,
    p_user_id => p_user_id,
    p_lock_pn => FALSE
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  p_na_id := null;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function ins_phone_i
(
    p_msisdns ct_varchar_s,
    p_pns_ids ct_number,
    p_status ct_varchar_s,
    p_sal_cat ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_na_ids out ct_number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_sp_name varchar2(30);
  v_res boolean := true;
  v_main_count number;
  --
  v_error_code number;
  v_error_message varchar2(4000);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FSU_ct_varchar_s(p_msisdns, 'p_msisdns');
  util_pkg.XCheckP_FS_ct_number(p_pns_ids, 'p_pns_ids');
  util_pkg.XCheckP_FS_ct_varchar_s(p_status, 'p_status'); --!_!
  util_pkg.XCheckP_FS_ct_varchar_s(p_sal_cat, 'p_sal_cat'); --!_!
  util_pkg.XCheckP_FS_ct_date(p_date, 'p_date');
  util_pkg.XCheckP_FS_ct_number(p_user_id, 'p_user_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdns) != v_main_count, 'p_msisdns.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_pns_ids) != v_main_count, 'p_pns_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_status) != v_main_count, 'p_status.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_sal_cat) != v_main_count, 'p_sal_cat.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_user_id) != v_main_count, 'p_user_id.count != v_main_count');
  ------------------------------
  util_pkg.resize_ct_number(p_na_ids, v_main_count);
  setup_common_error(v_main_count, util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    util_pkg.set_ok(p_error_code(v_i), p_error_message(v_i));
    ------------------------------
    ins_1phone_i
    (
      p_msisdn => p_msisdns(v_i),
      p_pns_id => p_pns_ids(v_i),
      p_status => p_status(v_i),
      p_sal_cat => p_sal_cat(v_i),
      p_date => p_date(v_i),
      p_user_id => p_user_id(v_i),
      p_na_id => p_na_ids(v_i),
      p_error_code => p_error_code(v_i),
      p_error_message => p_error_message(v_i)
    );
    ------------------------------
    if not util_pkg.is_ok(p_error_code(v_i))
    then
      ------------------------------
      v_res := false;
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, make_error_message4val_char(p_msisdns(v_i), v_i, p_error_code(v_i), p_error_message(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(v_error_code, v_error_message);
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  return FALSE;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function ins_phone
(
    p_msisdns ct_varchar_s,
    p_pns_ids ct_number,
    p_status ct_varchar_s,
    p_sal_cat ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_na_ids out ct_number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
begin
  ------------------------------
  return ins_phone_i
  (
    p_msisdns => p_msisdns,
    p_pns_ids => p_pns_ids,
    p_status => p_status,
    p_sal_cat => p_sal_cat,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_na_ids => p_na_ids,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function ins_phone2
(
    p_msisdns ct_varchar_s,
    p_pns_ids ct_number,
    p_status varchar2,
    p_sal_cat varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_na_ids out ct_number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_status ct_varchar_s;
  v_sal_cat ct_varchar_s;
  v_date ct_date;
  v_user_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_varchar_s(p_msisdns, 'p_msisdns');
  util_pkg.XCheckP_ct_number(p_pns_ids, 'p_pns_ids');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_msisdns);
  ------------------------------
  util_pkg.resize_ct_varchar_s(v_status, v_main_count);
  util_pkg.resize_ct_varchar_s(v_sal_cat, v_main_count);
  util_pkg.resize_ct_date(v_date, v_main_count);
  util_pkg.resize_ct_number(v_user_id, v_main_count);
  ------------------------------
  util_pkg.fill_ct_varchar_s(v_status, p_status);
  util_pkg.fill_ct_varchar_s(v_sal_cat, p_sal_cat);
  util_pkg.fill_ct_date(v_date, p_date);
  util_pkg.fill_ct_number(v_user_id, p_user_id);
  ------------------------------
  return ins_phone
  (
    p_msisdns => p_msisdns,
    p_pns_ids => p_pns_ids,
    p_status => v_status,
    p_sal_cat => v_sal_cat,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_na_ids => p_na_ids,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function ins_phone3
(
    p_msisdn varchar2,
    p_pns_id number,
    p_status varchar2,
    p_sal_cat varchar2,
    p_date date,
    p_user_id number,
    p_na_id out number,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_msisdns ct_varchar_s;
  v_pns_ids ct_number;
  v_na_ids ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_msisdn is null, 'p_msisdn');
  util_pkg.XCheck_Cond_Missing(p_pns_id is null, 'p_pns_id');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_sal_cat is null, 'p_sal_cat');
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_msisdns, p_msisdn);
  util_pkg.add_ct_number_val(v_pns_ids, p_pns_id);
  ------------------------------
  v_res := ins_phone2
  (
    p_msisdns => v_msisdns,
    p_pns_ids => v_pns_ids,
    p_status => p_status,
    p_sal_cat => p_sal_cat,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_na_ids => v_na_ids,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_na_id := v_na_ids(v_na_ids.first);
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure restore_1phone_ii
(
    p_na_id varchar2,
    p_pns_id number,
    p_date date,
    p_user_id number,
    p_lock_pn boolean
)
is
  v_lock_pn boolean := util_pkg.bool_to_bool_2val(p_lock_pn);
  v_cnt number;
  v_date_to date := null;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_pns_id is null, 'p_pns_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  if v_lock_pn
  then
    ------------------------------
    util_ri.xlock_1pn(p_na_id);
    ------------------------------
  end if;
  ------------------------------
  update /*+ index(PK_PHONE_NUMBER)*/ phone_number
  set
    phone_number_series_id = p_pns_id,
    date_of_change = sysdate,
    user_id_of_change = p_user_id,
    deleted = v_date_to
  where network_address_id = p_na_id
  and nvl(deleted, util_pkg.c_open_date_to) < p_date
  ;
  ------------------------------
  v_cnt := sql%rowcount;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    util_pkg.Raise_Obj_NotFound_Vers2(p_na_id, p_date, util_ri.valid_date_to(v_date_to), 'phone_number');
    ------------------------------
  elsif v_cnt > 1
  then
    ------------------------------
    util_pkg.Raise_Obj_NotUniq_OnDate2(p_na_id, util_ri.valid_date_to(v_date_to), 'phone_number');
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure restore_1phone_i
(
    p_na_id number,
    p_pns_id number,
    p_status varchar2,
    p_sal_cat varchar2,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  restore_1phone_ii
  (
    p_na_id => p_na_id,
    p_pns_id => p_pns_id,
    p_date => p_date,
    p_user_id => p_user_id,
    p_lock_pn => p_lock_pn
  );
  ------------------------------
  set_1na_status_ii
  (
    p_na_id => p_na_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_na_trans_reason_code => NULL,
    p_lock_pn => p_lock_pn
  );
  ------------------------------
  set_1na_sel_cat_ii
  (
    p_na_id => p_na_id,
    p_sel_cat => p_sal_cat,
    p_date => p_date,
    p_user_id => p_user_id,
    p_lock_pn => p_lock_pn
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function restore_phone_i
(
    p_na_ids ct_number,
    p_pns_ids ct_number,
    p_status ct_varchar_s,
    p_sal_cat ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_sp_name varchar2(30);
  v_res boolean := true;
  v_main_count number;
  --
  v_error_code number;
  v_error_message varchar2(4000);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_na_ids, 'p_na_ids');
  util_pkg.XCheckP_FS_ct_number(p_pns_ids, 'p_pns_ids');
  util_pkg.XCheckP_FS_ct_varchar_s(p_status, 'p_status'); --!_!
  util_pkg.XCheckP_FS_ct_varchar_s(p_sal_cat, 'p_sal_cat'); --!_!
  util_pkg.XCheckP_FS_ct_date(p_date, 'p_date');
  util_pkg.XCheckP_FS_ct_number(p_user_id, 'p_user_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_na_ids) != v_main_count, 'p_na_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_pns_ids) != v_main_count, 'p_pns_ids.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_status) != v_main_count, 'p_status.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_sal_cat) != v_main_count, 'p_sal_cat.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_user_id) != v_main_count, 'p_user_id.count != v_main_count');
  ------------------------------
  setup_common_error(v_main_count, util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    util_pkg.set_ok(p_error_code(v_i), p_error_message(v_i));
    ------------------------------
    restore_1phone_i
    (
      p_na_id => p_na_ids(v_i),
      p_pns_id => p_pns_ids(v_i),
      p_status => p_status(v_i),
      p_sal_cat => p_sal_cat(v_i),
      p_date => p_date(v_i),
      p_user_id => p_user_id(v_i),
    p_lock_pn => p_lock_pn,
      p_error_code => p_error_code(v_i),
      p_error_message => p_error_message(v_i)
    );
    ------------------------------
    if not util_pkg.is_ok(p_error_code(v_i))
    then
      ------------------------------
      v_res := false;
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, make_error_message4val_num(p_na_ids(v_i), v_i, p_error_code(v_i), p_error_message(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(v_error_code, v_error_message);
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  return FALSE;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function restore_phone
(
    p_na_ids ct_number,
    p_pns_ids ct_number,
    p_status ct_varchar_s,
    p_sal_cat ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
begin
  ------------------------------
  return restore_phone_i
  (
    p_na_ids => p_na_ids,
    p_pns_ids => p_pns_ids,
    p_status => p_status,
    p_sal_cat => p_sal_cat,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_pn => p_lock_pn,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function restore_phone2
(
    p_na_ids ct_number,
    p_pns_ids ct_number,
    p_status varchar2,
    p_sal_cat varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_pn boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_status ct_varchar_s;
  v_sal_cat ct_varchar_s;
  v_date ct_date;
  v_user_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_na_ids, 'p_na_ids');
  util_pkg.XCheckP_ct_number(p_pns_ids, 'p_pns_ids');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_na_ids);
  ------------------------------
  util_pkg.resize_ct_varchar_s(v_status, v_main_count);
  util_pkg.resize_ct_varchar_s(v_sal_cat, v_main_count);
  util_pkg.resize_ct_date(v_date, v_main_count);
  util_pkg.resize_ct_number(v_user_id, v_main_count);
  ------------------------------
  util_pkg.fill_ct_varchar_s(v_status, p_status);
  util_pkg.fill_ct_varchar_s(v_sal_cat, p_sal_cat);
  util_pkg.fill_ct_date(v_date, p_date);
  util_pkg.fill_ct_number(v_user_id, p_user_id);
  ------------------------------
  return restore_phone
  (
    p_na_ids => p_na_ids,
    p_pns_ids => p_pns_ids,
    p_status => v_status,
    p_sal_cat => v_sal_cat,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_pn => p_lock_pn,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function restore_phone3
(
    p_na_id number,
    p_pns_id number,
    p_status varchar2,
    p_sal_cat varchar2,
    p_date date,
    p_user_id number,
    p_lock_pn boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_na_ids ct_number;
  v_pns_ids ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_na_id is null, 'p_na_id');
  util_pkg.XCheck_Cond_Missing(p_pns_id is null, 'p_pns_id');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_sal_cat is null, 'p_sal_cat');
  ------------------------------
  util_pkg.add_ct_number_val(v_na_ids, p_na_id);
  util_pkg.add_ct_number_val(v_pns_ids, p_pns_id);
  ------------------------------
  v_res := restore_phone2
  (
    p_na_ids => v_na_ids,
    p_pns_ids => v_pns_ids,
    p_status => p_status,
    p_sal_cat => p_sal_cat,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_lock_pn => p_lock_pn,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure ins_1sim_i
(
    p_imsi varchar2,
    p_sn varchar2,
    p_pin varchar2,
    p_pin2 varchar2,
    p_puk2 varchar2,
    p_puk varchar2,
    p_ss_id number,
    p_msisdn_bound varchar2,
    p_personal_account number,
    p_ki nvarchar2,
    p_adm1 nvarchar2,
    p_access_control nvarchar2,
    p_authent_type varchar2,
    p_addition_imsi ct_varchar_s,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_ap_id out number,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_rec sim_card%rowtype;
  v_ss_stat_val sim_series_status_validity%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  v_rec := null;
  v_rec.imsi := p_imsi;
  v_rec.sn := p_sn;
  v_rec.pin := p_pin;
  v_rec.pin2 := p_pin2;
  v_rec.puk2 := p_puk2;
  v_rec.puk := p_puk;
  v_rec.sim_series_id := p_ss_id;
  v_rec.msisdn_bound := p_msisdn_bound;
  v_rec.personal_account := p_personal_account;
  v_rec.user_id_of_change := p_user_id;
  v_rec.deleted := null;
  v_rec.date_of_change := p_date;
  v_rec.ki := p_ki;
  v_rec.adm1 := p_adm1;
  v_rec.access_control := p_access_control;
  v_rec.authent_type := p_authent_type;
  ------------------------------
  vp_sim_card.version_open2
  (
    p_rec => v_rec,
    p_addition_imsi => p_addition_imsi
  );
  ------------------------------
  set_1ap_status_ii
  (
    p_ap_id => v_rec.access_point_id,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_ap_trans_reason_code => NULL,
    p_lock_sc => FALSE
  );
  ------------------------------
  v_ss_stat_val := vp_sim_series_status_validity.xlock_get1(p_ss_id, p_date);
  if v_ss_stat_val.sim_series_id is null
  then
    ------------------------------
    v_ss_stat_val := null;
    v_ss_stat_val.sim_series_id := p_ss_id;
    v_ss_stat_val.status_code := util_ri.c_APPSH_PRODUCED;
    v_ss_stat_val.start_date := p_date;
    v_ss_stat_val.user_id_of_change := p_user_id;
    vp_sim_series_status_validity.version_open(v_ss_stat_val);
    ------------------------------
  else
    ------------------------------
    if v_ss_stat_val.status_code <> util_ri.c_APPSH_PRODUCED
    then
      ------------------------------
      v_ss_stat_val.status_code := util_ri.c_APPSH_PRODUCED;
      v_ss_stat_val.start_date := p_date;
      v_ss_stat_val.user_id_of_change := p_user_id;
      vp_sim_series_status_validity.version_change(v_ss_stat_val);
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  --!_! see UMC
  --set_1ap_pstatus_ii
  --(
  --  p_ap_id => p_ap_id,
  --  p_status => , --!_!
  --  p_date => p_date,
  --  p_user_id => p_user_id,
  --  p_lock_sc => FALSE
  --);
  ------------------------------
  p_ap_id := v_rec.access_point_id;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  p_ap_id := null;
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function ins_sim_i
(
    p_imsi ct_varchar_s,
    p_sn ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_ss_id ct_number,
    p_msisdn_bound ct_varchar_s,
    p_personal_account ct_number,
    p_ki ct_nvarchar_s,
    p_adm1 ct_nvarchar_s,
    p_access_control ct_nvarchar_s,
    p_authent_type ct_varchar_s,
    p_main_imsi_index ct_number,
    p_addition_imsi ct_varchar_s,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_ap_ids out ct_number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_sp_name varchar2(30);
  v_res boolean := true;
  v_main_count number;
  v_addition_count number;
  --
  v_mark01 ct_number;
  v_tmp_addit_imsi ct_varchar_s;
  --
  v_error_code number;
  v_error_message varchar2(4000);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.XCheckP_FSU_ct_varchar_s(p_imsi, 'p_imsi');
  util_pkg.XCheckP_FSU_ct_varchar_s(p_sn, 'p_sn');
  util_pkg.XCheckP_FS_ct_number(p_ss_id, 'p_ss_id');
  util_pkg.XCheckP_FS_ct_varchar_s(p_status, 'p_status'); --!_!
  util_pkg.XCheckP_FS_ct_date(p_date, 'p_date');
  util_pkg.XCheckP_FS_ct_number(p_user_id, 'p_user_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_imsi) != v_main_count, 'p_imsi.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_sn) != v_main_count, 'p_sn.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_pin) != v_main_count, 'p_pin.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_pin2) != v_main_count, 'p_pin2.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_puk2) != v_main_count, 'p_puk2.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_puk) != v_main_count, 'p_puk.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ss_id) != v_main_count, 'p_ss_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdn_bound) != v_main_count, 'p_msisdn_bound.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_personal_account) != v_main_count, 'p_personal_account.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_ki) != v_main_count, 'p_ki.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_adm1) != v_main_count, 'p_adm1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_access_control) != v_main_count, 'p_access_control.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_authent_type) != v_main_count, 'p_authent_type.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_status) != v_main_count, 'p_status.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_user_id) != v_main_count, 'p_user_id.count != v_main_count');
  ------------------------------
  v_addition_count := util_pkg.get_count_ct_number(p_main_imsi_index);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_main_imsi_index) != v_addition_count, 'p_main_imsi_index.count != v_addition_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_addition_imsi) != v_addition_count, 'p_addition_imsi.count != v_addition_count');
  ------------------------------
  util_pkg.resize_ct_number(p_ap_ids, v_main_count);
  setup_common_error(v_main_count, util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    util_pkg.set_ok(p_error_code(v_i), p_error_message(v_i));
    ------------------------------
    if v_addition_count > 0
    then
      ------------------------------
      v_mark01 := util_pkg.mark_val_ct_number(p_main_imsi_index, v_i, util_pkg.c_true, util_pkg.c_false);
      v_tmp_addit_imsi := util_pkg.get_marked_ct_varchar_s(p_addition_imsi, v_mark01, TRUE, util_pkg.c_true, NULL);
      ------------------------------
    else
      ------------------------------
      v_tmp_addit_imsi := null;
      ------------------------------
    end if;
    ------------------------------
    ins_1sim_i
    (

      p_imsi => p_imsi(v_i),
      p_sn => p_sn(v_i),
      p_pin => p_pin(v_i),
      p_pin2 => p_pin2(v_i),
      p_puk2 => p_puk2(v_i),
      p_puk => p_puk(v_i),
      p_ss_id => p_ss_id(v_i),
      p_msisdn_bound => p_msisdn_bound(v_i),
      p_personal_account => p_personal_account(v_i),
      p_ki => p_ki(v_i),
      p_adm1 => p_adm1(v_i),
      p_access_control => p_access_control(v_i),
      p_authent_type => p_authent_type(v_i),
      p_addition_imsi => v_tmp_addit_imsi,
      p_status => p_status(v_i),
      p_date => p_date(v_i),
      p_user_id => p_user_id(v_i),
      p_ap_id => p_ap_ids(v_i),
      p_error_code => p_error_code(v_i),
      p_error_message => p_error_message(v_i)
    );
    ------------------------------
    if not util_pkg.is_ok(p_error_code(v_i))
    then
      ------------------------------
      v_res := false;
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_x_common, make_error_message4val_char2(p_imsi(v_i), p_sn(v_i), v_i, p_error_code(v_i), p_error_message(v_i)));
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(v_error_code, v_error_message);
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  return FALSE;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function ins_sim
(
    p_imsi ct_varchar_s,
    p_sn ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_ss_id ct_number,
    p_msisdn_bound ct_varchar_s,
    p_personal_account ct_number,
    p_ki ct_nvarchar_s,
    p_adm1 ct_nvarchar_s,
    p_access_control ct_nvarchar_s,
    p_authent_type ct_varchar_s,
    p_main_imsi_index ct_number,
    p_addition_imsi ct_varchar_s,
    p_status ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_ap_ids out ct_number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
begin
  ------------------------------
  return ins_sim_i
  (
    p_imsi => p_imsi,
    p_sn => p_sn,
    p_pin => p_pin,
    p_pin2 => p_pin2,
    p_puk2 => p_puk2,
    p_puk => p_puk,
    p_ss_id => p_ss_id,
    p_msisdn_bound => p_msisdn_bound,
    p_personal_account => p_personal_account,
    p_ki => p_ki,
    p_adm1 => p_adm1,
    p_access_control => p_access_control,
    p_authent_type => p_authent_type,
    p_main_imsi_index => p_main_imsi_index,
    p_addition_imsi => p_addition_imsi,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_ap_ids => p_ap_ids,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function ins_sim2
(
    p_imsi ct_varchar_s,
    p_sn ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_ss_id ct_number,
    p_msisdn_bound ct_varchar_s,
    p_personal_account ct_number,
    p_ki ct_nvarchar_s,
    p_adm1 ct_nvarchar_s,
    p_access_control ct_nvarchar_s,
    p_authent_type ct_varchar_s,
    p_main_imsi_index ct_number,
    p_addition_imsi ct_varchar_s,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_ap_ids out ct_number,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_status ct_varchar_s;
  v_date ct_date;
  v_user_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_varchar_s(p_imsi, 'p_imsi');
  util_pkg.XCheckP_ct_varchar_s(p_sn, 'p_sn');
  util_pkg.XCheckP_ct_number(p_ss_id, 'p_ss_id');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_imsi);
  ------------------------------
  util_pkg.resize_ct_varchar_s(v_status, v_main_count);
  util_pkg.resize_ct_date(v_date, v_main_count);
  util_pkg.resize_ct_number(v_user_id, v_main_count);
  ------------------------------
  util_pkg.fill_ct_varchar_s(v_status, p_status);
  util_pkg.fill_ct_date(v_date, p_date);
  util_pkg.fill_ct_number(v_user_id, p_user_id);
  ------------------------------
  return ins_sim
  (
    p_imsi => p_imsi,
    p_sn => p_sn,
    p_pin => p_pin,
    p_pin2 => p_pin2,
    p_puk2 => p_puk2,
    p_puk => p_puk,
    p_ss_id => p_ss_id,
    p_msisdn_bound => p_msisdn_bound,
    p_personal_account => p_personal_account,
    p_ki => p_ki,
    p_adm1 => p_adm1,
    p_access_control => p_access_control,
    p_authent_type => p_authent_type,
    p_main_imsi_index => p_main_imsi_index,
    p_addition_imsi => p_addition_imsi,
    p_status => v_status,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_ap_ids => p_ap_ids,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function ins_sim3
(
    p_imsi varchar2,
    p_sn varchar2,
    p_pin varchar2,
    p_pin2 varchar2,
    p_puk2 varchar2,
    p_puk varchar2,
    p_ss_id number,
    p_msisdn_bound varchar2,
    p_personal_account number,
    p_ki nvarchar2,
    p_adm1 nvarchar2,
    p_access_control nvarchar2,
    p_authent_type varchar2,
    p_addition_imsi ct_varchar_s,
    p_status varchar2,
    p_date date,
    p_user_id number,
    p_ap_id out number,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_imsi ct_varchar_s;
  v_sn ct_varchar_s;
  v_pin ct_varchar_s;
  v_pin2 ct_varchar_s;
  v_puk2 ct_varchar_s;
  v_puk ct_varchar_s;
  v_ss_id ct_number;
  v_msisdn_bound ct_varchar_s;
  v_personal_account ct_number;
  v_ki ct_nvarchar_s;
  v_adm1 ct_nvarchar_s;
  v_access_control ct_nvarchar_s;
  v_authent_type ct_varchar_s;
  v_main_imsi_index ct_number;
  v_ap_ids ct_number;
  v_error_code ct_number;
  v_error_message ct_varchar;
  --
  v_length number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_imsi is null, 'p_imsi');
  util_pkg.XCheck_Cond_Missing(p_sn is null, 'p_sn');
  util_pkg.XCheck_Cond_Missing(p_ss_id is null, 'p_ss_id');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_imsi, p_imsi);
  util_pkg.add_ct_varchar_s_val(v_sn, p_sn);
  util_pkg.add_ct_varchar_s_val(v_pin, p_pin);
  util_pkg.add_ct_varchar_s_val(v_pin2, p_pin2);
  util_pkg.add_ct_varchar_s_val(v_puk2, p_puk2);
  util_pkg.add_ct_varchar_s_val(v_puk, p_puk);
  util_pkg.add_ct_number_val(v_ss_id, p_ss_id);
  util_pkg.add_ct_varchar_s_val(v_msisdn_bound, p_msisdn_bound);
  util_pkg.add_ct_number_val(v_personal_account, p_personal_account);
  util_pkg.add_ct_nvarchar_s_val(v_ki, p_ki);
  util_pkg.add_ct_nvarchar_s_val(v_adm1, p_adm1);
  util_pkg.add_ct_nvarchar_s_val(v_access_control, p_access_control);
  util_pkg.add_ct_varchar_s_val(v_authent_type, p_authent_type);
  ------------------------------
  v_length := util_pkg.get_count_ct_varchar_s(p_addition_imsi);
  v_main_imsi_index := util_pkg.make_ct_number(v_length, 1);
  ------------------------------
  v_res := ins_sim2
  (
    p_imsi => v_imsi,
    p_sn => v_sn,
    p_pin => v_pin,
    p_pin2 => v_pin2,
    p_puk2 => v_puk2,
    p_puk => v_puk,
    p_ss_id => v_ss_id,
    p_msisdn_bound => v_msisdn_bound,
    p_personal_account => v_personal_account,
    p_ki => v_ki,
    p_adm1 => v_adm1,
    p_access_control => v_access_control,
    p_authent_type => v_authent_type,
    p_main_imsi_index => v_main_imsi_index,
    p_addition_imsi => p_addition_imsi,
    p_status => p_status,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_ap_ids => v_ap_ids,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_ap_id := v_ap_ids(v_ap_ids.first);
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_1ap_params_ii
(
    p_ap_id number,
    p_sn varchar2,
    p_pin varchar2,
    p_pin2 varchar2,
    p_puk2 varchar2,
    p_puk varchar2,
    p_msisdn_bound varchar2,
    p_ki nvarchar2,
    p_adm1 nvarchar2,
    p_access_control nvarchar2,
    p_authent_type varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean
)
is
  v_lock_sc boolean := util_pkg.bool_to_bool_2val(p_lock_sc);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_sn is null, 'p_sn');
  --!_!util_pkg.XCheck_Cond_Missing(p_pin is null, 'p_pin');
  --!_!util_pkg.XCheck_Cond_Missing(p_pin2 is null, 'p_pin2');
  --!_!util_pkg.XCheck_Cond_Missing(p_puk2 is null, 'p_puk2');
  --!_!util_pkg.XCheck_Cond_Missing(p_puk is null, 'p_puk');
  --!_!util_pkg.XCheck_Cond_Missing(p_msisdn_bound is null, 'p_msisdn_bound');
  --!_!util_pkg.XCheck_Cond_Missing(p_personal_account is null, 'p_personal_account');
  --!_!util_pkg.XCheck_Cond_Missing(p_ki is null, 'p_ki');
  --!_!util_pkg.XCheck_Cond_Missing(p_adm1 is null, 'p_adm1');
  --!_!util_pkg.XCheck_Cond_Missing(p_access_control is null, 'p_access_control');
  --!_!util_pkg.XCheck_Cond_Missing(p_authent_type is null, 'p_authent_type');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  if v_lock_sc
  then
    ------------------------------
    util_ri.xlock_1sc(p_ap_id);
    ------------------------------
  end if;
  ------------------------------
  update /*+ index_asc(z, PK_SIM_CARD)*/
    sim_card z
  set
    sn = p_sn,
    pin = p_pin,
    pin2 = p_pin2,
    puk2 = p_puk2,
    puk = p_puk,
    msisdn_bound = p_msisdn_bound,
    ki = p_ki,
    adm1 = p_adm1,
    access_control = p_access_control,
    authent_type = p_authent_type,
    date_of_change = sysdate,
    user_id_of_change = p_user_id
  where 1 = 1
    and access_point_id = p_ap_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_1ap_params_i
(
    p_ap_id number,
    p_sn varchar2,
    p_pin varchar2,
    p_pin2 varchar2,
    p_puk2 varchar2,
    p_puk varchar2,
    p_msisdn_bound varchar2,
    p_ki nvarchar2,
    p_adm1 nvarchar2,
    p_access_control nvarchar2,
    p_authent_type varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  set_1ap_params_ii
  (
    p_ap_id => p_ap_id,
    p_sn => p_sn,
    p_pin => p_pin,
    p_pin2 => p_pin2,
    p_puk2 => p_puk2,
    p_puk => p_puk,
    p_msisdn_bound => p_msisdn_bound,
    p_ki => p_ki,
    p_adm1 => p_adm1,
    p_access_control => p_access_control,
    p_authent_type => p_authent_type,
    p_date => p_date,
    p_user_id => p_user_id,
    p_lock_sc => p_lock_sc
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! last p_error_code(v_i) in group shows whole group status
--!_! first erroneous p_error_code(v_i) in group shows real error point
----------------------------------!---------------------------------------------
function set_ap_params_ii
(
    p_ap_id ct_number,
    p_sn ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_msisdn_bound ct_varchar_s,
    p_ki ct_nvarchar_s,
    p_adm1 ct_nvarchar_s,
    p_access_control ct_nvarchar_s,
    p_authent_type ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_group_size number,
    p_nullable_group_head boolean,
    p_nullable_group_tail boolean,
    p_propagate_group_error boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean := true;
  v_nullable_group_head boolean := util_pkg.bool_to_bool_2val(p_nullable_group_head);
  v_nullable_group_tail boolean := util_pkg.bool_to_bool_2val(p_nullable_group_tail);
  v_propagate_group_error boolean := util_pkg.bool_to_bool_2val(p_propagate_group_error);
  v_main_count number;
  v_cur_allowed_and_done boolean;
  v_skip_group boolean;
  v_index_in_group number;
  v_group_number number;
  v_group_start number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_ap_id, 'p_ap_id');
  util_pkg.XCheckP_ct_date(p_date, 'p_date');
  util_pkg.XCheckP_ct_number(p_user_id, 'p_user_id');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_sc is null, 'p_lock_sc');
  util_pkg.XCheck_Cond_Missing(p_group_size is null, 'p_group_size');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_head is null, 'p_nullable_group_head');
  util_pkg.XCheck_Cond_Missing(p_nullable_group_tail is null, 'p_nullable_group_tail');
  util_pkg.XCheck_Cond_Missing(p_propagate_group_error is null, 'p_propagate_group_error');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ap_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ap_id) != v_main_count, 'p_ap_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_sn) != v_main_count, 'p_sn.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_pin) != v_main_count, 'p_pin.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_pin2) != v_main_count, 'p_pin2.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_puk2) != v_main_count, 'p_puk2.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_puk) != v_main_count, 'p_puk.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_msisdn_bound) != v_main_count, 'p_msisdn_bound.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_ki) != v_main_count, 'p_ki.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_adm1) != v_main_count, 'p_adm1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_access_control) != v_main_count, 'p_access_control.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_authent_type) != v_main_count, 'p_authent_type.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_date.count != v_main_count, 'p_date.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_user_id.count != v_main_count, 'p_user_id.count != v_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_group_size != trunc(p_group_size), 'p_group_size != trunc(p_group_size)');
  util_pkg.XCheck_Cond_Invalid(p_group_size <= 0, 'p_group_size <= 0');
  util_pkg.XCheck_Cond_Invalid(p_group_size > v_main_count, 'p_group_size > v_main_count');
  util_pkg.XCheck_Cond_Invalid(mod(v_main_count, p_group_size) != 0, 'mod(v_main_count, p_group_size) != 0');
  ------------------------------
  setup_common_error(v_main_count, util_pkg.c_ora_not_executed, util_pkg.c_msg_not_executed, p_error_code, p_error_message);
  ------------------------------
  savepoint sp_set_ap_params_ii;
  ------------------------------
  v_skip_group := false;
  ------------------------------
  --!_!for v_i in p_ap_id.first..p_ap_id.last
  ------------------------------
  for v_i in 1..p_ap_id.count
  loop
    ------------------------------
    v_index_in_group := util_pkg.get_index_on_page(v_i, p_group_size);
    ------------------------------
    if v_index_in_group = 1 --!_! new group
    then
      ------------------------------
      savepoint sp_set_ap_params_ii_group;
      ------------------------------
      v_skip_group := false;
      ------------------------------
      v_group_number := util_pkg.get_page_number(v_i, p_group_size);
      v_group_start := util_pkg.get_page_start(v_group_number, p_group_size);
      --!_!v_group_start := v_i;
      ------------------------------
    end if;
    ------------------------------
    if v_skip_group
    then
      ------------------------------
      --!_!duplicate previous error
      ------------------------------
      p_error_code(v_i) := p_error_code(v_i - 1);
      p_error_message(v_i) := p_error_message(v_i - 1);
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    v_cur_allowed_and_done := false;
    util_pkg.set_ok(p_error_code(v_i), p_error_message(v_i));
    ------------------------------
    if p_ap_id(v_i) is null
    then
      ------------------------------
      if (1 = 0
        or (v_nullable_group_head and v_index_in_group = 1) --!_! new group
        or (v_nullable_group_tail and v_index_in_group > 1) --!_! group continues
      )
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      else
        ------------------------------
        p_error_code(v_i) := util_pkg.c_ora_object_empty;
        p_error_message(v_i) := util_pkg.c_msg_object_empty;
        ------------------------------
      end if;
      ------------------------------
    else
      ------------------------------
      set_1ap_params_i
      (
        p_ap_id => p_ap_id(v_i),
        p_sn => p_sn(v_i),
        p_pin => p_pin(v_i),
        p_pin2 => p_pin2(v_i),
        p_puk2 => p_puk2(v_i),
        p_puk => p_puk(v_i),
        p_msisdn_bound => p_msisdn_bound(v_i),
        p_ki => p_ki(v_i),
        p_adm1 => p_adm1(v_i),
        p_access_control => p_access_control(v_i),
        p_authent_type => p_authent_type(v_i),
        p_date => p_date(v_i),
        p_user_id => p_user_id(v_i),
        p_lock_sc => p_lock_sc,
        p_error_code => p_error_code(v_i),
        p_error_message => p_error_message(v_i)
      );
      ------------------------------
      if util_pkg.is_ok(p_error_code(v_i))
      then
        ------------------------------
        v_cur_allowed_and_done := true;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    if not v_cur_allowed_and_done
    then
      ------------------------------
      rollback to sp_set_ap_params_ii_group;
      ------------------------------
      v_res := false;
      v_skip_group := true;
      ------------------------------
      if v_propagate_group_error and v_index_in_group > 1 --!_! group continues
      then
        ------------------------------
        setup_group_error_for_grp_head
        (
          p_problem_id => p_ap_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
      end if;
      ------------------------------
      if p_break_on_error
      then
        ------------------------------
        rollback to sp_set_ap_params_ii;
        ------------------------------
        setup_group_error_for_all
        (
          p_problem_id => p_ap_id(v_i),
          p_problem_index => v_i,
          p_group_start => v_group_start,
          p_group_size => p_group_size,
          p_group_error_code => p_error_code(v_i),
          p_group_error_message => p_error_message(v_i),
          p_error_code => p_error_code,
          p_error_message => p_error_message
        );
        ------------------------------
        exit;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_ap_params_i
(
    p_ap_id ct_number,
    p_sn ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_msisdn_bound ct_varchar_s,
    p_ki ct_nvarchar_s,
    p_adm1 ct_nvarchar_s,
    p_access_control ct_nvarchar_s,
    p_authent_type ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_res boolean;
  cl_group_size number := 1;
  --
  v_error_code ct_number;
  v_error_message ct_varchar;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_ap_id, 'p_ap_id');
  ------------------------------
  v_res := set_ap_params_ii
  (
    p_ap_id => p_ap_id,
    p_sn => p_sn,
    p_pin => p_pin,
    p_pin2 => p_pin2,
    p_puk2 => p_puk2,
    p_puk => p_puk,
    p_msisdn_bound => p_msisdn_bound,
    p_ki => p_ki,
    p_adm1 => p_adm1,
    p_access_control => p_access_control,
    p_authent_type => p_authent_type,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_sc => p_lock_sc,
    p_group_size => cl_group_size,
    p_nullable_group_head => false,
    p_nullable_group_tail => true,
    p_propagate_group_error => TRUE,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code;
  p_error_message := v_error_message;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function set_ap_params
(
    p_ap_id ct_number,
    p_sn ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_msisdn_bound ct_varchar_s,
    p_ki ct_nvarchar_s,
    p_adm1 ct_nvarchar_s,
    p_access_control ct_nvarchar_s,
    p_authent_type ct_varchar_s,
    p_date ct_date,
    p_user_id ct_number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
begin
  ------------------------------
  return set_ap_params_i
  (
    p_ap_id => p_ap_id,
    p_sn => p_sn,
    p_pin => p_pin,
    p_pin2 => p_pin2,
    p_puk2 => p_puk2,
    p_puk => p_puk,
    p_msisdn_bound => p_msisdn_bound,
    p_ki => p_ki,
    p_adm1 => p_adm1,
    p_access_control => p_access_control,
    p_authent_type => p_authent_type,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_sc => p_lock_sc,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_ap_params2
(
    p_ap_id ct_number,
    p_sn ct_varchar_s,
    p_pin ct_varchar_s,
    p_pin2 ct_varchar_s,
    p_puk2 ct_varchar_s,
    p_puk ct_varchar_s,
    p_msisdn_bound ct_varchar_s,
    p_ki ct_nvarchar_s,
    p_adm1 ct_nvarchar_s,
    p_access_control ct_nvarchar_s,
    p_authent_type ct_varchar_s,
    p_date date,
    p_user_id number,
    p_break_on_error boolean,
    p_lock_sc boolean,
    p_error_code out ct_number,
    p_error_message out ct_varchar
) return boolean
is
  v_main_count number;
  v_date ct_date;
  v_user_id ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_number(p_ap_id, 'p_ap_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_lock_sc is null, 'p_lock_sc');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_ap_id);
  ------------------------------
  util_pkg.resize_ct_date(v_date, v_main_count);
  util_pkg.resize_ct_number(v_user_id, v_main_count);
  ------------------------------
  util_pkg.fill_ct_date(v_date, p_date);
  util_pkg.fill_ct_number(v_user_id, p_user_id);
  ------------------------------
  return set_ap_params
  (
    p_ap_id => p_ap_id,
    p_sn => p_sn,
    p_pin => p_pin,
    p_pin2 => p_pin2,
    p_puk2 => p_puk2,
    p_puk => p_puk,
    p_msisdn_bound => p_msisdn_bound,
    p_ki => p_ki,
    p_adm1 => p_adm1,
    p_access_control => p_access_control,
    p_authent_type => p_authent_type,
    p_date => v_date,
    p_user_id => v_user_id,
    p_break_on_error => p_break_on_error,
    p_lock_sc => p_lock_sc,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function set_ap_params3
(
    p_ap_id number,
    p_sn varchar2,
    p_pin varchar2,
    p_pin2 varchar2,
    p_puk2 varchar2,
    p_puk varchar2,
    p_msisdn_bound varchar2,
    p_ki nvarchar2,
    p_adm1 nvarchar2,
    p_access_control nvarchar2,
    p_authent_type varchar2,
    p_date date,
    p_user_id number,
    p_lock_sc boolean,
    p_error_code out number,
    p_error_message out varchar2
) return boolean
is
  v_res boolean;
  v_ap_id ct_number;
  v_sn ct_varchar_s;
  v_pin ct_varchar_s;
  v_pin2 ct_varchar_s;
  v_puk2 ct_varchar_s;
  v_puk ct_varchar_s;
  v_msisdn_bound ct_varchar_s;
  v_ki ct_nvarchar_s;
  v_adm1 ct_nvarchar_s;
  v_access_control ct_nvarchar_s;
  v_authent_type ct_varchar_s;
  v_error_code ct_number;
  v_error_message ct_varchar;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ap_id is null, 'p_ap_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_pa is null, 'p_pa');
  ------------------------------
  util_pkg.add_ct_number_val(v_ap_id, p_ap_id);
  util_pkg.add_ct_varchar_s_val(v_sn, p_sn);
  util_pkg.add_ct_varchar_s_val(v_pin, p_pin);
  util_pkg.add_ct_varchar_s_val(v_pin2, p_pin2);
  util_pkg.add_ct_varchar_s_val(v_puk2, p_puk2);
  util_pkg.add_ct_varchar_s_val(v_puk, p_puk);
  util_pkg.add_ct_varchar_s_val(v_msisdn_bound, p_msisdn_bound);
  util_pkg.add_ct_nvarchar_s_val(v_ki, p_ki);
  util_pkg.add_ct_nvarchar_s_val(v_adm1, p_adm1);
  util_pkg.add_ct_nvarchar_s_val(v_access_control, p_access_control);
  util_pkg.add_ct_varchar_s_val(v_authent_type, p_authent_type);
  ------------------------------
  v_res := set_ap_params2
  (
    p_ap_id => v_ap_id,
    p_sn => v_sn,
    p_pin => v_pin,
    p_pin2 => v_pin2,
    p_puk2 => v_puk2,
    p_puk => v_puk,
    p_msisdn_bound => v_msisdn_bound,
    p_ki => v_ki,
    p_adm1 => v_adm1,
    p_access_control => v_access_control,
    p_authent_type => v_authent_type,
    p_date => p_date,
    p_user_id => p_user_id,
    p_break_on_error => true,
    p_lock_sc => p_lock_sc,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_error_code := v_error_code(v_error_code.first);
  p_error_message := v_error_message(v_error_message.first);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_first_exist_imsi_in_range
(
    p_start_imsi_number varchar2,
    p_end_imsi_number varchar2,
    p_with_sn boolean
) return varchar2
is
  v_res varchar2(50);
  v_with_sn number := util_pkg.bool_to_int_2val(p_with_sn);
begin
  ------------------------------
  select /*+ index_asc(z, UK_SIM_IMSI)*/
    min(imsi) imsi
    into v_res
    from sim_card z
    where 1 = 1
    and length(imsi) = length(p_start_imsi_number)
    and imsi between p_start_imsi_number and p_end_imsi_number
    and (v_with_sn = util_pkg.c_false or sn is not null)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function expand_imsi_range(p_range ot_range) return ct_varchar_s
is
  v_start number;
  v_end number;
  v_count number;
  v_pivot ct_number;
  v_res ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range is null, 'p_range');
  util_pkg.XCheck_Cond_Missing(p_range.val1 is null, 'p_range.val1');
  util_pkg.XCheck_Cond_Missing(p_range.val2 is null, 'p_range.val2');
  util_pkg.XCheck_Cond_Invalid(length(p_range.val2) <> length(p_range.val2), 'length(p_range.val2) <> length(p_range.val2)l');
  ------------------------------
  v_start := util_pkg.char_to_number(util_pkg.nchar_to_char(p_range.val1));
  v_end := util_pkg.char_to_number(util_pkg.nchar_to_char(p_range.val2));
  v_count := v_end - v_start + 1;
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_count, 0);
  ------------------------------
  select /*+ full(z)*/
      make_imsi(util_pkg.nchar_to_char(p_range.val1), z.column_value) imsi
      --lpad(util_pkg.number_to_char(v_start + column_value), v_lenght, '0') imsi
    bulk collect into v_res
    from table(v_pivot) z
    order by imsi
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_range_length
(
    p_start_imsi_number varchar2,
    p_end_imsi_number varchar2
) return number
is
  v_start number;
  v_end number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_start_imsi_number is null, 'p_start_imsi_number');
  util_pkg.XCheck_Cond_Missing(p_end_imsi_number is null, 'p_end_imsi_number');
  ------------------------------
  v_start := util_pkg.char_to_number(p_start_imsi_number);
  v_end := util_pkg.char_to_number(p_end_imsi_number);
  ------------------------------
  return v_end - v_start + 1;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_imsi
(
    p_start_imsi_number varchar2,
    p_shift number
) return varchar2
is
  v_start number;
  v_lenght number;
  v_end number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_start_imsi_number is null, 'p_start_imsi_number');
  util_pkg.XCheck_Cond_Missing(p_shift is null, 'p_shift');
  ------------------------------
  v_start := util_pkg.char_to_number(p_start_imsi_number);
  v_lenght := length(p_start_imsi_number);
  v_end := v_start + p_shift;
  ------------------------------
  return lpad(util_pkg.number_to_char(v_end), v_lenght, '0');
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_available_imsi_ranges
(
    p_start_imsi_number varchar2,
    p_end_imsi_number varchar2,
    p_count number
) return ct_range
is
  v_opt_use_sim_imsi number; --!_!
  v_first_imsi varchar2(50);
  v_first_shift number;
  v_end_imsi_number varchar2(50);
  v_range_length number;
  v_res ct_range;
  v_lenght number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_start_imsi_number is null, 'p_start_imsi_number');
  util_pkg.XCheck_Cond_Missing(p_end_imsi_number is null, 'p_end_imsi_number');
  util_pkg.XCheck_Cond_Missing(p_count is null, 'p_count');
  ------------------------------
  v_opt_use_sim_imsi := util_pkg.bool_to_int_2val(install_pkg.nnget_option_bool(util_ri.c_opt_use_sim_imsi, util_ri.c_def_use_sim_imsi));
  ------------------------------
  v_first_imsi := get_first_exist_imsi_in_range(p_start_imsi_number, p_end_imsi_number, true);
  ------------------------------
  if v_first_imsi is null
  then
    ------------------------------
    v_range_length := get_range_length(p_start_imsi_number, p_end_imsi_number);
    ------------------------------
    if v_range_length > p_count
    then
      ------------------------------
      v_end_imsi_number := make_imsi(p_start_imsi_number, p_count -1);
      ------------------------------
    else
      ------------------------------
      v_end_imsi_number := p_end_imsi_number;
      ------------------------------
    end if;
    ------------------------------
    v_res := util_ri.make_ct_range1
    (
      p_val1 => util_pkg.make_ct_nvarchar_s(1, util_pkg.char_to_nchar(p_start_imsi_number)),
      p_val2  => util_pkg.make_ct_nvarchar_s(1, util_pkg.char_to_nchar(v_end_imsi_number))
    );
    ------------------------------
  else
    ------------------------------
    v_first_shift := get_range_length(p_start_imsi_number, v_first_imsi) - 1;
    v_lenght := length(p_start_imsi_number);
    ------------------------------
    select
      ot_range
      (
        util_pkg.char_to_nchar(range_start), --val1 
        util_pkg.char_to_nchar(range_end), --val2 
        null, --num1 
        null, --num2 
        null, --num3 
        null, --dat1 
        null --num4
      )
      bulk collect into v_res
      from
      (
        select
          qqqq.range_start,
          make_imsi(qqqq.range_start, gets_from_range - 1) range_end
          from
          (
            select
              case 
                when p_count > found_before_and_this_range then count_in_range
                else p_count - found_before_range
              end gets_from_range,
              qqq.*
              from
              (
                --!_!first query in union all - available (free) range up to first busy sim
                select 
                  0 found_before_range,
                  v_first_shift found_before_and_this_range,
                  v_first_shift count_in_range,
                  p_start_imsi_number range_start
                  from dual
                  where v_first_shift > 0
                union all
                select
                  found_before_and_this_range - count_in_range as found_before_range,
                  found_before_and_this_range,
                  count_in_range,
                  range_start
                  from (
                    select
                      v_first_shift + sum(range_interval - 1) over (order by imsi) found_before_and_this_range,
                      range_interval - 1 count_in_range,
                      make_imsi(qq.imsi, 1) range_start
                      from 
                      (
                    --!_!gets used sims and builds available (free) ranges between them (in other words, inverts used)
                        select
                          q.*,
                          util_pkg.char_to_number(next_imsi) - util_pkg.char_to_number(imsi) range_interval
                          from
                          (
                        --!_!NEED RULES VALIDATION for table sim_imsi and lifecycle as a whole; can or can not be sims from same sim_series_id as main and as additional ?
                            select /*+ index_asc(z, UK_SIM_IMSI)*/
                              nvl(lead(imsi) over (order by imsi), p_end_imsi_number) next_imsi,
                              imsi
                              from sim_card z
                              where 1 = 1
                              and v_opt_use_sim_imsi = util_pkg.c_false
                              and length(imsi) = v_lenght
                              and imsi between p_start_imsi_number and p_end_imsi_number
                              and sn is not null
                            UNION ALL
                            select /*+ ordered use_nl(z2) index_asc(z, I_SIM_IMSI_IMSI_ACCESS_POINT) index_asc(z2, PK_SIM_CARD)*/
                              nvl(lead(z.imsi) over (order by z.imsi), p_end_imsi_number) next_imsi,
                              z.imsi
                            from
                              sim_imsi z,
                              sim_card z2
                            where 1 = 1
                              and v_opt_use_sim_imsi = util_pkg.c_true
                              and length(z.imsi) = v_lenght
                              and z.imsi between p_start_imsi_number and p_end_imsi_number
                              and z2.access_point_id = z.access_point_id
                              and z2.sn is not null --!_!used sims
                            ) q
                        ) qq
                    ) qq2
                  where 1 = 1
                  and count_in_range > 0
                ) qqq
              where 1 = 1
              and found_before_range < p_count
          ) qqqq
      )
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function find_available_imsi_in_range
(
    p_start_imsi_number varchar2,
    p_end_imsi_number varchar2,
    p_count number
) return ct_varchar_s
is
  v_ranges ct_range;
  v_count number;
  v_res ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_start_imsi_number is null, 'p_start_imsi_number');
  util_pkg.XCheck_Cond_Missing(p_end_imsi_number is null, 'p_end_imsi_number');
  util_pkg.XCheck_Cond_Missing(p_count is null, 'p_count');
  util_pkg.XCheck_Cond_Invalid(p_count <= 0, 'p_count');
  ------------------------------
  v_ranges := find_available_imsi_ranges
  (
    p_start_imsi_number => p_start_imsi_number,
    p_end_imsi_number => p_end_imsi_number,
    p_count => p_count
  );
  ------------------------------
  v_count := util_ri.get_count_ct_range(v_ranges);
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    util_pkg.add_ct_varchar_s(v_res, expand_imsi_range(v_ranges(v_i)));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_available_imsi_on_host
(
    p_sim_card_type_code varchar2,
    p_host_id number,
    p_count number,
    p_date date,
    p_imsi out ct_varchar_s,
    p_ss_id out ct_number
)
is
  v_imsi_count number;
  v_range ct_range;
  v_count number;
  v_count2 number;
  v_imsi ct_varchar_s;
begin
  ------------------------------
  --!_! util_pkg.XCheck_Cond_Missing(p_sim_card_type_code is null, 'p_sim_card_type_code');
  util_pkg.XCheck_Cond_Missing(p_host_id is null, 'p_host_id');
  util_pkg.XCheck_Cond_Missing(p_count is null, 'p_count');
  util_pkg.XCheck_Cond_Invalid(p_count <= 0, 'p_count');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_range := util_ri.get_sim_series_range4host(p_host_id, p_date, p_sim_card_type_code);
  v_count := util_ri.get_count_ct_range(v_range);
  ------------------------------
  v_imsi_count := p_count;
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_imsi := find_available_imsi_in_range(util_pkg.nchar_to_char(v_range(v_i).val1), util_pkg.nchar_to_char(v_range(v_i).val2), v_imsi_count);
    ------------------------------
    v_count2 := util_pkg.get_count_ct_varchar_s(v_imsi);
    ------------------------------
    if v_count2 > 0
    then
      ------------------------------
      util_pkg.add_ct_varchar_s(p_imsi, v_imsi);
      util_pkg.add_ct_number(p_ss_id, util_pkg.make_ct_number(v_count2, v_range(v_i).num1));
      ------------------------------
    end if;
    ------------------------------
    v_imsi_count := p_count - util_pkg.get_count_ct_varchar_s(p_imsi);
    ------------------------------
    exit when v_imsi_count <= 0;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
