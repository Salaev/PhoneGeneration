CREATE PACKAGE RSIG_CHANNEL IS
/****************************************************************************
<header>
  <name>             	packager RSIG_CHANNEL
  </name>

  <author>           	Jan Stodulka - GITUS
  </author>

  <version>				1.1.17	3.8.2004     Jaroslav Holub
								Delete_Channel - fixed for time difference between client and server,
								date should be null and it means sysdate
  </version>
  <version>           	1.1.16   24.6.2004     Jaroslav Holub
                                Get_channel_all -> added column to output cursor PLACED_ON_HOST_NAME
  </version>
  <version>          	1.1.15  15.12.2003	jstodulk
								Insert debug constant.
  </version>
  <version>          	1.1.14  9.12.2003	jstodulk
								Change column EXCHANGE_ID -> HOST_ID and EXCHANGE_ID_PLACED -> HOST_ID_PLACED.
  </version>
  <version>				1.0.1   17.9.2003	jan Stodulka
                              	created fisrt version
  </version>

  <Description>         package provides set of usefull procedures and functions
                        performing various checks during run of the program
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	      Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
****************************************************************************/

/****************************************************************************
  <header>
    <name>              procedure Insert_Channel
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>
    <version>           1.0.2   9.12.2003     Jan Stodulka
                                change EXCHANGE -> HOST
    </version>

    <Description>       Procedure inserts a new channel.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code              - Error code
                        p_channel_number        - Nnumber of channel
                        p_host_id_placed_on     - Host id placed
                        p_host_id               - Host id
                        p_network_operator_id   - Network operator id
                        p_user_id_of_change     - User id of change
                        p_channel_id            - New channel id
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Insert_Channel(
    handle_tran             IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code              OUT  NUMBER,
    p_channel_number        IN   CHANNEL.CHANNEL_NUMBER%TYPE,
    p_host_id_placed_on     IN   CHANNEL.HOST_ID_PLACED_ON%TYPE,
    p_host_id               IN   CHANNEL.HOST_ID%TYPE,
    p_network_operator_id   IN   CHANNEL.NETWORK_OPERATOR_ID%TYPE,
    p_user_id_of_change     IN   NUMBER,
    p_channel_id            OUT  CHANNEL.CHANNEL_ID%TYPE
  );

/****************************************************************************
  <header>
    <name>              procedure Update_Channel
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>
    <version>           1.0.2   9.12.2003     Jan Stodulka
                                change EXCHANGE -> HOST
    </version>

    <Description>       Procedure updates values of channel given by channel id,
                        if given channel is currently not deleted.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_ORA_DELETED
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code              - Error code
                        p_channel_id            - Channel id - updated this row - this column not updated
                        p_channel_number        - Number of channel
                        p_host_id_placed_on     - Host id placed
                        p_host_id               - Host id
                        p_network_operator_id   - Network operator id
                        p_user_id_of_change     - User id of change
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Update_Channel(
    handle_tran             IN   CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code              OUT  NUMBER,
    p_channel_id            IN   CHANNEL.CHANNEL_ID%TYPE,
    p_channel_number        IN   CHANNEL.CHANNEL_NUMBER%TYPE,
    p_host_id_placed_on     IN   CHANNEL.HOST_ID_PLACED_ON%TYPE,
    p_host_id               IN   CHANNEL.HOST_ID%TYPE,
    p_network_operator_id   IN   CHANNEL.NETWORK_OPERATOR_ID%TYPE,
    p_user_id_of_change     IN   NUMBER
  );

/****************************************************************************
  <header>
    <name>              procedure Delete_Channel
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

	<version>			1.0.2	3.8.2004     Jaroslav Holub
								fixed for time difference between client and server,
								date should be null and it means sysdate
	</version>
    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure sets column DELETED to value of parameter
                        deleted in channel given by channel id, if given channel
                        is currently not deleted.
    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_HANDLE_TRAN_S
                        RSIG_UTILS.c_HANDLE_TRAN_Y
                        RSIG_UTILS.c_HANDLE_TRAN_N
                        RSIG_UTILS.c_ORA_INVALID_HANDLE
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_ROW_NOT_FOUND
                        RSIG_UTILS.c_ORA_DELETED
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        handle_tran CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y
                                  allowed values - RSIG_UTILS.c_HANDLE_TRAN_S
                                                   RSIG_UTILS.c_HANDLE_TRAN_Y
                                                   RSIG_UTILS.c_HANDLE_TRAN_N
                        error_code   - Error code
                        p_channel_id - Channel id
                        p_deleted		 - value for set attribute (DELETED)
                        p_user_id_of_change - User id of change
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Delete_Channel(
    handle_tran         IN    CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code          OUT   NUMBER,
    p_channel_id        IN    CHANNEL.CHANNEL_ID%TYPE,
    p_deleted           IN    CHANNEL.DELETED%TYPE,
    p_user_id_of_change IN    NUMBER
  );

/****************************************************************************
  <header>
    <name>              procedure Get_Channel
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.0.2   9.12.2003     Jan Stodulka
                                change EXCHANGE -> HOST
    </version>
    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure for getting channels routing to given
                        network operator or routing to given mobile switching
                        centre or placed on given mobile switching centre.
                        Input parameters are optional, the contents of output
                        ref cursor depends on input parameter:
                        1.	If input parameter p_exchange_id_placed_on is not null
                        then ref cursor contains records of table channel with given exchange_id_placed_on.
                        2.	If input parameter p_exchange_id is not null then ref cursor
                        contains records of table channel with given exchange_id.
                        3.	If input parameter p_network_operator_id is not null then ref
                        cursor contains records of table channel with given network_operator_id.
                        If entered more input parameters then ref cursor
                        contains record fulfil requirement of each input parameter.
                        Ref cursor contains columns: CHANNEL_ID, CHANNEL_NUMBER,
                        HOST_ID_PLACED_ON, HOST_ID, NETWORK_OPERATOR_ID,
                        DATE_OF_CHANGE, USER_ID_OF_CHANGE.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code              - Error code
                        p_host_id_placed_on     - Host id placed on
                        p_host_id               - Host id
                        p_network_operator_id   - Network operator id
                        p_cur_channel           - cursor to retrieve all channels
                                                  (CHANNEL_ID, CHANNEL_NUMBER, HOST_ID_PLACED_ON, HOST_ID, NETWORK_OPERATOR_ID, DATE_OF_CHANGE, USER_ID_OF_CHANGE)
    </Parameters>

  </header>
/****************************************************************************/

  PROCEDURE Get_Channel(
    error_code              OUT  NUMBER,
    p_host_id_placed_on     IN   CHANNEL.HOST_ID_PLACED_ON%TYPE,
    p_host_id               IN   CHANNEL.HOST_ID%TYPE,
    p_network_operator_id   IN   CHANNEL.NETWORK_OPERATOR_ID%TYPE,
    p_cur_channel           OUT  RSIG_UTILS.REF_CURSOR
  );


	/****************************************************************************
  <header>
    <name>              procedure Get_Channel_All
    </name>

    <author>            Jan Stodulka - GITUS
    </author>

    <version>           1.0.4   24.6.2004     Jaroslav Holub
                                added column to output cursor PLACED_ON_HOST_NAME
    </version>
    <version>           1.0.3		3.2.2004			Pavel Stengl

    </version>
    <version>           1.0.2   9.12.2003     Jan Stodulka
                                change EXCHANGE -> HOST
    </version>
    <version>           1.0.1   15.9.2003     Jan Stodulka
                                created first version
    </version>

    <Description>       Procedure for getting all channels (deleted rows too) routing to given
                        network operator or routing to given mobile switching
                        centre or placed on given mobile switching centre.
                        Input parameters are optional, the contents of output
                        ref cursor depends on input parameter:
                        1.	If input parameter p_exchange_id_placed_on is not null
                        then ref cursor contains records of table channel with given exchange_id_placed_on.
                        2.	If input parameter p_exchange_id is not null then ref cursor
                        contains records of table channel with given exchange_id.
                        3.	If input parameter p_network_operator_id is not null then ref
                        cursor contains records of table channel with given network_operator_id.
                        If entered more input parameters then ref cursor
                        contains record fulfil requirement of each input parameter.
                        Ref cursor contains columns: CHANNEL_ID, CHANNEL_NUMBER,
                        HOST_ID_PLACED_ON, HOST_ID, NETWORK_OPERATOR_ID,
                        DATE_OF_CHANGE, USER_ID_OF_CHANGE.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_DEBUG_LEVEL_0
                        RSIG_UTILS.c_DEBUG_LEVEL_1
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_D
                        RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER
                        RSIG_UTILS.c_DEBUG_TEXT_START
                        RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code              - Error code
                        p_host_id_placed_on     - Host id placed on
                        p_host_id               - Host id
                        p_network_operator_id   - Network operator id
                        p_cur_channel           - cursor to retrieve all channels
                                                  (CHANNEL_ID, CHANNEL_NUMBER, HOST_ID_PLACED_ON, HOST_ID, NETWORK_OPERATOR_ID, DATE_OF_CHANGE, USER_ID_OF_CHANGE)
    </Parameters>

  </header>
/****************************************************************************/


  PROCEDURE Get_Channel_All(
    error_code              OUT  NUMBER,
    p_host_id_placed_on     IN   CHANNEL.HOST_ID_PLACED_ON%TYPE,
    p_host_id               IN   CHANNEL.HOST_ID%TYPE,
    p_network_operator_id   IN   CHANNEL.NETWORK_OPERATOR_ID%TYPE,
    p_cur_channel           OUT  RSIG_UTILS.REF_CURSOR
  );

END RSIG_CHANNEL;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_CHANNEL.pkg,v 1.15 2003/12/15 09:02:40 jstodulk Exp $
/
