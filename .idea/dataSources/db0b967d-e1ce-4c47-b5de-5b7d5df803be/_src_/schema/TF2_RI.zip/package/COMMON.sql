CREATE PACKAGE          "COMMON" IS
/****************************************************************************
<header>
  <name>            package COMMON
  </name>

  <author>          Petr Cepek
  </author>

  <version>         1.0.5     06.05.2008  Josef Hartman
                    Added new type t_varchar2_2
                    Added new type t_varchar2_10
  </version>
  <version>         1.0.4     08.11.2006  Petr Cepek
                    procedure Handle_Error overloaded
  </version>
  <version>         1.0.3     30.10.2006  Petr Cepek
                    type t_number added
  </version>
  <version>         1.0.2     13.10.2006  Petr Cepek
                    type t_IMSI created
  </version>
  <version>
                    1.0.1     23.08.2006  Petr Cepek
                    function LPad_Shorter created
                    procedure Fill_Access_Point_ID_SN created
                    procedure Fill_Network_Address_ID created
  </version>
  <version>
                    1.0.0  6.6.2006  -  created
  </version>

  <Description>     Package contains common procedures used accross all the packages.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
  TYPE t_international_format IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
  TYPE t_ICCID                IS TABLE OF VARCHAR2(60) INDEX BY BINARY_INTEGER;
  TYPE t_IMSI                 IS TABLE OF VARCHAR2(20) INDEX BY BINARY_INTEGER;
  TYPE t_varchar2_10          IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;
  TYPE t_varchar2_15          IS TABLE OF VARCHAR2(15) INDEX BY BINARY_INTEGER;
  TYPE t_varchar2_2           IS TABLE OF VARCHAR2(2)  INDEX BY BINARY_INTEGER;
  TYPE t_varchar2_255         IS TABLE OF VARCHAR2(255)INDEX BY BINARY_INTEGER;
  TYPE t_number               IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
  TYPE t_date                 IS TABLE OF DATE INDEX BY BINARY_INTEGER;

/****************************************************************************
<header>
  <name>            procedure Event_Logger
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  6.6.2006  -  created
  </version>

  <Description>     Procedure log debuging information during process of
                    some other procedure. Logging can be pass to file,
                    screen or logging table log_event. Logging is done only
                    when debuging level in parameter table is set to same or
                    higher number than parameter p_level.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Event_Logger(
  p_text          IN  LOG_EVENT.EVENT_MESSAGE%TYPE, -- text to send to output
  p_level         IN  NUMBER, -- level of debuging
  p_event_type    IN  LOG_EVENT.EVENT_TYPE%TYPE, -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
  p_event_source  IN  LOG_EVENT.EVENT_SOURCE%TYPE -- name of the source where this calling is performed
);

/****************************************************************************
<header>
  <name>            procedure Check_Handle_Tran
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  6.6.2006  -  created
  </version>

  <Description>     Procedure check whether p_handle_tran parameter
                    is correct transaction parameter:
                    Y - transaction si handled by procedure
                    N - transaction is not handled by procedure
                    S - transaction is not handled by procedure, only
                        save point is made
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Check_Handle_Tran(
  p_handle_tran  IN  CHAR,
  p_procedure    IN  VARCHAR2
);

/****************************************************************************
<header>
  <name>            function Handle_Error
  </name>

  <author>          Petr Cepek
  </author>

  <version>         1.0.1     8.11.2006   Petr Cepek
                    procedure overloaded for logging input parameters
  </version>
  <version>
                    1.0.0  6.6.2006  -  created
  </version>

  <Description>     Function makes all activities which are involved in process
                    of error handling. This covers: - decision about rollback or
                    rollback to savepoint, - logging error code to the log_event,
                    adjustment of error code. Function return error code.

  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
FUNCTION Handle_Error(
  p_ora_error_number  IN  NUMBER,
  p_handle_tran       IN  CHAR,
  p_package           IN  VARCHAR2,
  p_procedure         IN  VARCHAR2
) RETURN NUMBER;

FUNCTION Handle_Error(
  p_ora_error_number  IN  NUMBER,
  p_ora_message       IN  VARCHAR2,
  p_message           IN  VARCHAR2,
  p_handle_tran       IN  CHAR,
  p_package           IN  VARCHAR2,
  p_procedure         IN  VARCHAR2
) RETURN NUMBER ;

/****************************************************************************
<header>
  <name>            function LPad_Shorter
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  20.8.2006  -  created
  </version>

  <Description>    Function return string p_str left-padded to length
                   of parameter p_len with characters defined in parameter
                   p_pad only when p_str is smaller then p_len.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
FUNCTION LPad_Shorter(

  p_str     VARCHAR2,
  p_len     NUMBER,
  p_pad     VARCHAR2
)RETURN VARCHAR2;

/****************************************************************************
<header>
  <name>            function Fill_Access_Point_ID_SN
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  20.8.2006  -  created
  </version>

  <Description>    Procedure fills access_point_id to the temporary table
                   tt_batch_na_ap for serial numbers(ICCID) existing in this
                   table. Procedure returns in parameter p_num_miss number
                   of serial numbers that were not found in the table
                   SIM_CARD.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Fill_Access_Point_ID_SN(
  p_num_miss   OUT   NUMBER
);

/****************************************************************************
<header>
  <name>            function Fill_Access_Point_ID_SN
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  20.8.2006  -  created
  </version>

  <Description>    Procedure fills network_address_id to the temporary table
                   tt_batch_na_ap for phone numbers existing in this
                   table. Procedure returns in parameter p_num_miss number
                   of phone numbers that were not found in the table
                   PHONE_NUMBER.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Fill_Network_Address_ID(
  p_num_miss   OUT   NUMBER
);
END COMMON;

/
