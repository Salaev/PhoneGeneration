CREATE PACKAGE BODY RSIG_NETWORK_OPERATOR IS

---------------------------------------------
--     PROCEDURE Test_Row_For_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Row_For_Exist_And_Deleted(p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE) IS
  v_deleted NETWORK_OPERATOR.DELETED%TYPE;
BEGIN
  select DELETED into v_deleted from NETWORK_OPERATOR where NETWORK_OPERATOR_id = p_network_operator_id;

  IF v_deleted IS NOT NULL THEN
    IF v_deleted < sysdate THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
    END IF;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Test_Row_For_Exist_And_Deleted;


---------------------------------------------
--     PROCEDURE Check_Net_Operator_Referenced
---------------------------------------------

PROCEDURE Check_Net_Operator_Referenced(p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE) IS
  v_referenced NUMBER;
  v_sysdate    DATE;
BEGIN

  v_referenced := NULL;
  v_sysdate    := SYSDATE;

  SELECT 1
    INTO v_referenced
    FROM dual
   WHERE EXISTS (SELECT 1
            FROM ACCOUNT_CARD_SERIE acs
           WHERE acs.NETWORK_OPERATOR_ID = p_network_operator_id
             AND (acs.DELETED IS NULL OR acs.DELETED > v_sysdate))
      OR EXISTS (SELECT 1
            FROM CHANNEL ch
           WHERE ch.NETWORK_OPERATOR_ID = p_network_operator_id
             AND (ch.deleted IS NULL OR ch.deleted > v_sysdate))
      OR EXISTS (SELECT 1
            FROM HOST h
           WHERE h.NETWORK_OPERATOR_ID = p_network_operator_id
             AND (h.DELETED IS NULL OR h.DELETED > v_sysdate))
      OR EXISTS (SELECT /*+ index_asc(po I_PHONE_OPERATOR_NOID)*/1
            FROM PHONE_OPERATOR po
           WHERE po.NETWORK_OPERATOR_ID = p_network_operator_id
             AND v_sysdate BETWEEN po.START_DATE AND nvl(po.END_DATE, v_sysdate))
      OR EXISTS (SELECT 1
            FROM PHONE_SERIES_OPERATOR pso
           WHERE pso.NETWORK_OPERATOR_ID = p_network_operator_id
             AND v_sysdate BETWEEN pso.START_DATE AND nvl(pso.END_DATE, v_sysdate))
      OR EXISTS (SELECT 1
            FROM SIM_SERIES s
           WHERE s.NETWORK_OPERATOR_ID = p_network_operator_id
             AND (s.DELETED IS NULL OR s.DELETED > v_sysdate))
      OR EXISTS (SELECT 1
            FROM ZONE z
           WHERE z.NETWORK_OPERATOR_ID = p_network_operator_id
             AND (z.DELETED IS NULL OR z.DELETED > v_sysdate))
      OR EXISTS (SELECT 1
            FROM PAYMENT_ENTRANCE pe
           WHERE pe.NETWORK_OPERATOR_ID = p_network_operator_id
             AND (pe.DELETED IS NULL OR pe.DELETED > v_sysdate))
      OR EXISTS (SELECT 1
            FROM NETWORK_OPERATOR n
           WHERE n.NETWORK_OPERATOR_ID_UPPER = p_network_operator_id
             AND (n.DELETED IS NULL OR n.deleted > v_sysdate))
      OR EXISTS (SELECT 1
            FROM LOGIN_INFO li
           WHERE li.NETWORK_OPERATOR_ID = p_network_operator_id
             AND (li.DELETED IS NULL OR li.DELETED < v_sysdate))
      OR EXISTS (SELECT 1
            FROM IP_SERIE_OPERATOR iso
           WHERE iso.NETWORK_OPERATOR_ID = p_network_operator_id
             AND v_sysdate BETWEEN iso.START_DATE AND nvl(iso.END_DATE, v_sysdate));

  IF v_referenced = 1 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_REFERENCED, '');
  END IF;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    NULL;
END Check_Net_Operator_Referenced;

---------------------------------------------
--     PROCEDURE Test_Network_Operator_Deleted
---------------------------------------------
PROCEDURE Test_Network_Operator_Deleted(
  p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
)
IS
  v_s VARCHAR2(1);
BEGIN
  select 'X'
    into v_s
    from NETWORK_OPERATOR
   where network_operator_id = p_network_operator_id
     and deleted IS NULL;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, 'Operator not exists.');
END Test_Network_Operator_Deleted;

---------------------------------------------
--     PROCEDURE Insert_Network_Operator
---------------------------------------------

PROCEDURE Insert_Network_Operator
(
  handle_tran                 IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                  OUT NUMBER,
  p_network_operator_id_upper IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
  p_network_operator_code     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
  p_network_operator_name     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_NAME%TYPE,
  p_network_operator_type     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
  p_personal_account          IN  NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
  p_UPRS_Member_Code          IN  NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
  p_country                   IN  network_operator.country%TYPE,
  p_user_id_of_change         IN  NUMBER,
  p_network_operator_id       OUT NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Insert_Network_Operator';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint insert_network_operator_a;
  END IF;

  IF p_network_operator_id_upper IS NOT NULL THEN
    Test_Network_Operator_Deleted(p_network_operator_id_upper);
  END IF;

  select s_network_operator.nextval into p_network_operator_id from DUAL;
  BEGIN
    insert into NETWORK_OPERATOR
      (NETWORK_OPERATOR_ID,
       NETWORK_OPERATOR_CODE,
       NETWORK_OPERATOR_NAME,
       NETWORK_OPERATOR_TYPE,
       NETWORK_OPERATOR_ID_UPPER,
       PERSONAL_ACCOUNT,
       UPRS_MEMBER_CODE,
       DELETED,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE,
       country)
    values
      (p_network_operator_id,
       p_network_operator_code,
       p_network_operator_name,
       p_network_operator_type,
       p_network_operator_id_upper,
       p_personal_account,
       p_UPRS_Member_Code,
       null,
       sysdate,
       p_user_id_of_change,
       p_country);

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_NETWORK_OPERATOR_CODE then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_CODE, '');
      else
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_NAME, '');
      end if;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint insert_network_operator_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Insert_Network_Operator;

---------------------------------------------
--     PROCEDURE Update_Network_Operator
---------------------------------------------

PROCEDURE Update_Network_Operator
(
  handle_tran                 IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                  OUT NUMBER,
  p_network_operator_id       IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_network_operator_id_upper IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
  p_network_operator_code     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
  p_network_operator_name     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_NAME%TYPE,
  p_network_operator_type     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
  p_personal_account          IN  NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
  p_UPRS_Member_Code          IN  NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
  p_country                   IN  network_operator.country%TYPE,
  p_user_id_of_change         IN NUMBER
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Update_Network_Operator';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint update_network_operator_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_network_operator_id);
  IF p_network_operator_id_upper IS NOT NULL THEN
    Test_Network_Operator_Deleted(p_network_operator_id_upper);
  END IF;

  BEGIN
    update NETWORK_OPERATOR
       set NETWORK_OPERATOR_CODE     = p_network_operator_code,
           NETWORK_OPERATOR_NAME     = p_network_operator_name,
           NETWORK_OPERATOR_TYPE     = p_network_operator_type,
           NETWORK_OPERATOR_ID_UPPER = p_network_operator_id_upper,
           PERSONAL_ACCOUNT          = p_personal_account,
           UPRS_MEMBER_CODE          = p_UPRS_Member_Code,
           DATE_OF_CHANGE            = sysdate,
           USER_ID_OF_CHANGE         = p_user_id_of_change,
           country                   = p_country
     where NETWORK_OPERATOR_ID = p_network_operator_id;

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_NETWORK_OPERATOR_CODE then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_CODE, '');
      else
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_NAME, '');
      end if;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint update_network_operator_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Update_Network_Operator;

---------------------------------------------
--     PROCEDURE Delete_Network_Operator
---------------------------------------------

PROCEDURE Delete_Network_Operator
(
  handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code            OUT NUMBER,
  p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_deleted             IN NETWORK_OPERATOR.DELETED%TYPE,
  p_user_id_of_change   IN NUMBER
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Delete_Network_Operator';
  v_deleted      DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint delete_network_operator_a;
  END IF;
  v_deleted := nvl(p_deleted, SYSDATE);

  Test_Row_For_Exist_And_Deleted(p_network_operator_id);

  Check_Net_Operator_Referenced(p_network_operator_id);

  update NETWORK_OPERATOR
     set DELETED           = v_deleted,
         DATE_OF_CHANGE    = sysdate,
         USER_ID_OF_CHANGE = p_user_id_of_change
   where NETWORK_OPERATOR_ID = p_network_operator_id;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint delete_network_operator_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Delete_Network_Operator;

---------------------------------------------
--     PROCEDURE Get_Network_Operator
---------------------------------------------

PROCEDURE Get_Network_Operator
(
  error_code              OUT NUMBER,
  p_external              IN CHAR,
  p_network_operator_type IN NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
  p_cur_network_operator  OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Get_Network_Operator';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_external IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF p_external = 'Y' THEN
    OPEN p_cur_network_operator FOR
      select rownum ROW_NUM,
             0 L_LEVEL,
             NETWORK_OPERATOR_ID,
             NETWORK_OPERATOR_CODE,
             NETWORK_OPERATOR_NAME,
             NETWORK_OPERATOR_TYPE,
             NETWORK_OPERATOR_ID_UPPER,
             PERSONAL_ACCOUNT,
             UPRS_MEMBER_CODE,
             DATE_OF_CHANGE,
             USER_ID_OF_CHANGE,
             DELETED,
             COUNTRY
        from NETWORK_OPERATOR n
       WHERE n.NETWORK_OPERATOR_TYPE is NOT NULL
         AND n.deleted is NULL
         AND (TRIM(NETWORK_OPERATOR_TYPE) = TRIM(p_network_operator_type) OR p_network_operator_type IS NULL);

  ELSIF p_external = 'N' THEN
    OPEN p_cur_network_operator FOR
      select rownum ROW_NUM,
             level L_LEVEL,
             NETWORK_OPERATOR_ID,
             NETWORK_OPERATOR_CODE,
             NETWORK_OPERATOR_NAME,
             NETWORK_OPERATOR_TYPE,
             NETWORK_OPERATOR_ID_UPPER,
             PERSONAL_ACCOUNT,
             UPRS_MEMBER_CODE,
             DATE_OF_CHANGE,
             USER_ID_OF_CHANGE,
             DELETED,
             COUNTRY
        from NETWORK_OPERATOR
       WHERE NETWORK_OPERATOR_TYPE IS null
         AND deleted is NULL
      connect by prior NETWORK_OPERATOR_ID = NETWORK_OPERATOR_ID_UPPER
       start with NETWORK_OPERATOR_ID_UPPER is NULL;

  ELSE
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, '');
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN p_cur_network_operator FOR
      select error_code from dual;
END Get_Network_Operator;



---------------------------------------------
--     PROCEDURE Get_Network_Operator_Detail
---------------------------------------------

PROCEDURE Get_Network_Operator_Detail
(
  error_code             OUT NUMBER,
  p_network_operator_id  IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_cur_network_operator OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Get_Network_Operator_Detail';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_network_operator_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  OPEN p_cur_network_operator FOR
    select neo.network_operator_code,
           neo.network_operator_name,
           neo.personal_account,
           neo.uprs_member_code,
           neo.date_of_change,
           usr.user_name,
           neo.country,
           neo.mcc,
           neo.mnc,
           neo.time_zone,
           neo.dst_rule_id,
           neo.network_operator_id_upper
      from NETWORK_OPERATOR neo
      join users usr ON neo.user_id_of_change = usr.user_id
     where neo.network_operator_id = p_network_operator_id;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN p_cur_network_operator FOR
      select error_code from dual;
END Get_Network_Operator_Detail;

---------------------------------------------
--     PROCEDURE Get_Network_Operator_All
---------------------------------------------

PROCEDURE Get_Network_Operator_All
(
  error_code              OUT NUMBER,
  p_external              IN CHAR,
  p_network_operator_type IN NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
  p_cur_network_operator  OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Get_Network_Operator_All';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_external IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF p_external = 'Y' THEN
    OPEN p_cur_network_operator FOR
      select rownum ROW_NUM,
             0 L_LEVEL,
             n.NETWORK_OPERATOR_ID,
             n.NETWORK_OPERATOR_CODE,
             n.NETWORK_OPERATOR_NAME,
             n.NETWORK_OPERATOR_TYPE,
             n.NETWORK_OPERATOR_ID_UPPER,
             n.PERSONAL_ACCOUNT,
             n.UPRS_MEMBER_CODE,
             n.DATE_OF_CHANGE,
             n.USER_ID_OF_CHANGE,
             n.DELETED,
             noty.network_operator_type_name,
             c.country_id,
             c.country_name,
             n.mcc,
             n.mnc,
             n.time_zone,
             n.dst_rule_id
        from NETWORK_OPERATOR n
        join network_operator_type noty on TRIM(noty.network_operator_type_code) = TRIM(n.network_operator_type)
        LEFT JOIN country c ON c.country_id=n.country
       WHERE n.NETWORK_OPERATOR_TYPE is NOT NULL
         AND (TRIM(NETWORK_OPERATOR_TYPE) = TRIM(p_network_operator_type) OR p_network_operator_type IS NULL)
       order by NETWORK_OPERATOR_NAME;

  ELSIF p_external = 'N' THEN
    OPEN p_cur_network_operator FOR
      select rownum ROW_NUM,
             level L_LEVEL,
             n.NETWORK_OPERATOR_ID,
             n.NETWORK_OPERATOR_CODE,
             n.NETWORK_OPERATOR_NAME,
             n.NETWORK_OPERATOR_TYPE,
             n.NETWORK_OPERATOR_ID_UPPER,
             n.PERSONAL_ACCOUNT,
             n.UPRS_MEMBER_CODE,
             n.DATE_OF_CHANGE,
             n.USER_ID_OF_CHANGE,
             n.DELETED,
             noty.network_operator_type_name,
             n.mcc,
             n.mnc,
             n.time_zone,
             n.dst_rule_id
        from NETWORK_OPERATOR n
        join network_operator_type noty on TRIM(noty.network_operator_type_code) = TRIM(n.network_operator_type)
       WHERE NETWORK_OPERATOR_TYPE IS null
      connect by prior NETWORK_OPERATOR_ID = NETWORK_OPERATOR_ID_UPPER
       start with NETWORK_OPERATOR_ID_UPPER is NULL;

  ELSE
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, '');
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN p_cur_network_operator FOR
      select error_code from dual;
END Get_Network_Operator_All;


---------------------------------------------
--     PROCEDURE Get_Network_Operator_No_Child
---------------------------------------------

PROCEDURE Get_Network_Operator_No_Child
(
  error_code              OUT NUMBER,
  p_network_operator_id   IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_external              IN CHAR,
  p_network_operator_type IN NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
  p_deleted               IN CHAR DEFAULT 'N',
  p_cur_network_operator  OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Get_Network_Operator_No_Child';
  v_query        VARCHAR2(4000);
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_external IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF p_external = 'Y' THEN
    v_query := ' select rownum ROW_NUM, ' || ' 0 L_LEVEL, ' || ' NETWORK_OPERATOR_ID, ' ||
               ' NETWORK_OPERATOR_CODE, ' || ' NETWORK_OPERATOR_NAME, ' || ' NETWORK_OPERATOR_TYPE, ' ||
               ' NETWORK_OPERATOR_ID_UPPER, ' || ' PERSONAL_ACCOUNT, ' || ' UPRS_MEMBER_CODE, ' ||
               ' DATE_OF_CHANGE, ' || ' USER_ID_OF_CHANGE, ' || ' DELETED ' || ' from NETWORK_OPERATOR n ' ||
               ' WHERE n.NETWORK_OPERATOR_TYPE is NOT NULL ' || '  AND n.NETWORK_OPERATOR_ID <> ' ||
               p_network_operator_id || ' AND (TRIM(NETWORK_OPERATOR_TYPE) = ' ||
               nvl(TRIM(p_network_operator_type), 'NULL') || '  OR ' || nvl(p_network_operator_type, 'NULL') ||
               ' IS NULL) ';

    IF p_deleted = 'N' THEN
      v_query := v_query || ' and (DELETED >= sysdate or DELETED IS NULL)';
    END IF;

    OPEN p_cur_network_operator FOR v_query;

  ELSIF p_external = 'N' THEN

    v_query := ' select rownum ROW_NUM, ' || ' 0 L_LEVEL, ' || ' NETWORK_OPERATOR_ID, ' ||
               ' NETWORK_OPERATOR_CODE, ' || ' NETWORK_OPERATOR_NAME, ' || ' NETWORK_OPERATOR_TYPE, ' ||
               ' NETWORK_OPERATOR_ID_UPPER, ' || ' PERSONAL_ACCOUNT, ' || ' UPRS_MEMBER_CODE, ' ||
               ' DATE_OF_CHANGE, ' || ' USER_ID_OF_CHANGE, ' || ' DELETED ' || ' from NETWORK_OPERATOR n1 ' ||
               ' where NETWORK_OPERATOR_TYPE is null ' || ' and NOT EXISTS  ' ||
               ' (select n2.NETWORK_OPERATOR_ID ' || '	from NETWORK_OPERATOR n2 ' ||
               '	where n2.NETWORK_OPERATOR_TYPE is null ' ||
               '	  and n1.network_operator_id = n2.network_operator_id ' ||
               '	connect by prior n2.NETWORK_OPERATOR_ID =  n2.NETWORK_OPERATOR_ID_UPPER ' ||
               '	start with n2.NETWORK_OPERATOR_ID = ' || p_network_operator_id;

    IF p_deleted = 'N' THEN
      v_query := v_query || '    and (n2.DELETED >= sysdate or n2.DELETED IS NULL)) ' ||
                 ' and (DELETED >= sysdate or DELETED IS NULL) ';
    ELSE
      v_query := v_query || ' )';
    END IF;

    OPEN p_cur_network_operator FOR v_query;

  ELSE
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, '');
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN p_cur_network_operator FOR
      select error_code from dual;
END Get_Network_Operator_No_Child;

---------------------------------------------
--     PROCEDURE Get_Network_Operator_Type
---------------------------------------------

PROCEDURE Get_Network_Operator_Type
(
  p_raise_error IN CHAR,
  error_code    OUT NUMBER,
  error_message OUT VARCHAR2,
  result_list   OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Get_Network_Operator_Type';
  v_sqlcode      number;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  -- procedure body here
  OPEN result_list FOR
    SELECT NETWORK_OPERATOR_TYPE_CODE,
           NETWORK_OPERATOR_TYPE_NAME
      FROM NETWORK_OPERATOR_TYPE nt
     WHERE nt.deleted IS NULL
        OR nt.deleted > SYSDATE
     ORDER BY NETWORK_OPERATOR_TYPE_CODE;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_Network_Operator_Type;

---------------------------------------------
--     PROCEDURE Get_NetOp_By_MSC_List
---------------------------------------------

PROCEDURE Get_NetOp_By_MSC_List
(
  col_msc_list  IN T_MSC,
  result_list   OUT sys_refcursor,
  p_raise_error IN CHAR,
  error_code    OUT NUMBER,
  error_message OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Get_NetOp_By_MSC_List';
  v_sqlcode      number;
  v_NA_HOST_OBJ        t_na_host_obj:=t_na_host_obj(NULL,NULL);
  v_NA_HOST_list			  t_na_host_obj_tab:= t_na_host_obj_tab();
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  --check col_msc_list parameter
  IF (col_msc_list IS NULL) OR (col_msc_list.COUNT = 0) OR (col_msc_list.COUNT = 1 AND col_msc_list(col_msc_list.FIRST) IS NULL) THEN
--    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
    OPEN result_list FOR
        SELECT h.host_code,
               h.network_operator_id,
               h.host_id
          FROM HOST h
         ORDER BY h.host_code;
  ELSE
    FOR i IN nvl(col_msc_list.FIRST, 1) .. nvl(col_msc_list.LAST, 0) 
    loop 
      v_NA_HOST_OBJ:=t_na_host_obj(NULL,col_msc_list(i));
      v_NA_HOST_list.extend; 
      v_NA_HOST_list(i):=v_NA_HOST_OBJ; 
    end loop;
    
    OPEN result_list FOR
      SELECT t.msc_host_code,
             h.network_operator_id,
             h.host_id
        FROM TABLE(CAST(v_NA_HOST_list AS t_na_host_obj_tab))  t
        LEFT JOIN HOST h ON h.HOST_CODE = t.MSC_HOST_CODE
       ORDER BY t.msc_host_code;
  END IF;
  
  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := sqlcode;
    error_message := sqlerrm;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_NetOp_By_MSC_List;

---------------------------------------------
--     PROCEDURE Insert_Neighbour
---------------------------------------------

PROCEDURE Insert_Neighbour
(
  p_network_operator_id number,
  p_neighbour_net_op_id number,
  p_roaming_type_code number,
  p_location_area_id number,
  p_base_station_id number,
  p_addit_roaming_rype_code util_pkg.cit_number,
  p_start_date date,
  p_user_id number,
  p_handle_tran char default rsig_utils.c_handle_tran_y,
  p_raise_error char,
  p_error_code out number,
  p_error_message out varchar2
) IS
  v_net_op_neighbor_cnt NUMBER;
  v_sysdate DATE := sysdate;
  v_start_date DATE := NVL(p_start_date, v_sysdate);
  v_new_interval number;
  v_addit_roaming_rype_code ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid((upper(p_handle_tran) not in (rsig_utils.c_handle_tran_s, rsig_utils.c_handle_tran_y, rsig_utils.c_handle_tran_n) or (p_handle_tran is null)), 'p_handle_tran');
  util_pkg.XCheck_Cond_Invalid(p_network_operator_id is null, 'p_network_operator_id is null');
  util_pkg.XCheck_Cond_Invalid(p_neighbour_net_op_id is null, 'p_neighbour_net_op_id is null');
  util_pkg.XCheck_Cond_Invalid(v_start_date  < v_sysdate, 'start_date < sysdate');
  ------------------------------
  if (upper(p_handle_tran) = rsig_utils.c_handle_tran_s) then
    savepoint insert_neighbour;
  end if;
  ------------------------------
  v_addit_roaming_rype_code := util_pkg.cast_cit2ct_number(p_addit_roaming_rype_code, true);
  ------------------------------
  if (p_roaming_type_code = util_ri.c_rt_not_roaming and util_pkg.get_count_ct_number(v_addit_roaming_rype_code) > 0)
  then
    util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed);
  end if;
  ------------------------------
  SELECT COUNT(*)
     INTO v_net_op_neighbor_cnt
    FROM NETWORK_OPERATOR_NEIGHBOURS non
   WHERE non.NETWORK_OPERATOR_ID  = p_network_operator_id
       AND non.NEIGHBOURING_OPERATOR_ID = p_neighbour_net_op_id
       AND ((non.location_area_id = p_location_area_id) OR (non.location_area_id IS NULL AND p_location_area_id IS NULL))
       AND ((non.base_station_id = p_base_station_id ) OR (non.base_station_id IS NULL AND p_base_station_id IS NULL))
       AND v_start_date BETWEEN non.start_date AND NVL(non.end_date, v_start_date);

   IF v_net_op_neighbor_cnt <> 0 THEN
     util_pkg.raise_exception(util_pkg.c_ora_object_not_unique, util_pkg.c_msg_object_not_unique);
   END IF;
  ------------------------------
  v_new_interval := s_network_operator_neighbours.nextval;
  insert into network_operator_neighbours
        (roaming_definition_id,
          network_operator_id,
          neighbouring_operator_id,
          roaming_type_code,
          location_area_id,
          base_station_id,
          start_date,
          date_of_change,
          user_id_of_change)
      values
        ( v_new_interval,
          p_network_operator_id,
          p_neighbour_net_op_id,
          p_roaming_type_code,
          p_location_area_id,
          p_base_station_id,
          v_start_date,
          v_sysdate,
          p_user_id);
  ------------------------------
  if (util_pkg.get_count_ct_number(v_addit_roaming_rype_code) > 0)
  then
    forall i in v_addit_roaming_rype_code.first..v_addit_roaming_rype_code.last
      insert into network_operator_neighb_ext(roaming_definition_id, ext_roaming_type_code, date_of_change, user_id_of_change)
       values(v_new_interval, v_addit_roaming_rype_code(i), v_sysdate, p_user_id);
  end if;
  ------------------------------
  if upper(p_handle_tran) = rsig_utils.c_handle_tran_y then
    commit;
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  case p_handle_tran
    when rsig_utils.c_handle_tran_s then
      rollback to savepoint insert_neighbour;
    when rsig_utils.c_handle_tran_y then
      rollback;
    else
      null;
  end case;
  ------------------------------
  if upper(p_raise_error) = rsig_utils.c_yes then
    raise;
  end if;
  ------------------------------
end;

---------------------------------------------
--     PROCEDURE Update_Neighbour
---------------------------------------------

PROCEDURE Update_Neighbour
(
  p_roaming_definition_id number,
  p_network_operator_id number,
  p_roaming_type_code number,
  p_new_neighbour_net_op_id number,
  p_location_area_id number,
  p_base_station_id number,
  p_addit_roaming_rype_code util_pkg.cit_number,
  p_user_id number,
  p_start_date date,
  p_handle_tran char default rsig_utils.c_handle_tran_y,
  p_raise_error char,
  p_error_code out number,
  p_error_message out varchar2
) IS
  v_exists NUMBER;
  v_sysdate DATE := sysdate;
  v_start_date DATE := NVL(p_start_date, v_sysdate);
  v_old_start_date date;
  v_new_interval number;
  v_addit_roaming_rype_code ct_number;
BEGIN
  ------------------------------
  util_pkg.XCheck_Cond_Invalid((upper(p_handle_tran) not in (rsig_utils.c_handle_tran_s, rsig_utils.c_handle_tran_y, rsig_utils.c_handle_tran_n) or (p_handle_tran is null)), 'p_handle_tran');
  util_pkg.XCheck_Cond_Invalid(p_network_operator_id is null, 'p_network_operator_id is null');
  util_pkg.XCheck_Cond_Invalid(p_new_neighbour_net_op_id is null, 'p_neighbour_net_op_id is null');
  util_pkg.XCheck_Cond_Invalid(v_start_date  < v_sysdate, 'start_date < sysdate');
  ------------------------------
  if (upper(p_handle_tran) = rsig_utils.c_handle_tran_s) then
    savepoint update_neighbour;
  end if;
  ------------------------------
  v_addit_roaming_rype_code := util_pkg.cast_cit2ct_number(p_addit_roaming_rype_code, true);
  ------------------------------
  if (p_roaming_type_code = util_ri.c_rt_not_roaming and util_pkg.get_count_ct_number(v_addit_roaming_rype_code) > 0)
  then
    util_pkg.raise_exception(util_pkg.c_ora_not_allowed, util_pkg.c_msg_not_allowed);
  end if;
  ------------------------------
  SELECT COUNT(*)
     INTO v_exists
    FROM NETWORK_OPERATOR_NEIGHBOURS non
   WHERE non.roaming_definition_id <> p_roaming_definition_id
       AND non.NETWORK_OPERATOR_ID  = p_network_operator_id
       AND non.NEIGHBOURING_OPERATOR_ID = p_new_neighbour_net_op_id
       AND ((non.location_area_id = p_location_area_id) OR (non.location_area_id IS NULL AND p_location_area_id IS NULL))
       AND ((non.base_station_id = p_base_station_id ) OR (non.base_station_id IS NULL AND p_base_station_id IS NULL))
       AND v_start_date BETWEEN non.start_date AND NVL(non.end_date, v_start_date);

   IF v_exists <> 0 THEN
     util_pkg.raise_exception(util_pkg.c_ora_object_not_unique, util_pkg.c_msg_object_not_unique);
   END IF;
  ------------------------------
  SELECT COUNT(*)
     INTO v_exists
    FROM NETWORK_OPERATOR_NEIGHBOURS non
   WHERE non.roaming_definition_id = p_roaming_definition_id;

  IF v_exists = 0 THEN
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found);
  END IF;
  ------------------------------
  SELECT non.start_date
     INTO v_old_start_date
    FROM NETWORK_OPERATOR_NEIGHBOURS non
   WHERE non.roaming_definition_id = p_roaming_definition_id;
  ------------------------------
  if (v_old_start_date < v_start_date)
  then 
    ------------------------------
    UPDATE NETWORK_OPERATOR_NEIGHBOURS
       SET end_date = v_start_date - rsig_utils.c_INTERVAL_DIFFERENCE,
           DATE_OF_CHANGE = SYSDATE,
           USER_ID_OF_CHANGE = p_user_id
       WHERE roaming_definition_id = p_roaming_definition_id
    ;
    ------------------------------
    v_new_interval := S_NETWORK_OPERATOR_NEIGHBOURS.NEXTVAL;
    ------------------------------
    INSERT INTO NETWORK_OPERATOR_NEIGHBOURS
          (roaming_definition_id,
            network_operator_id,
            neighbouring_operator_id,
            roaming_type_code,
            location_area_id,
            base_station_id,
            start_date,
            date_of_change,
            user_id_of_change)
        VALUES
          ( v_new_interval,
            p_network_operator_id,
            p_new_neighbour_net_op_id,
            p_roaming_type_code,
            p_location_area_id,
            p_base_station_id,
            v_start_date,
            v_sysdate,
            p_user_id);
    ------------------------------
    if util_pkg.get_count_ct_number(v_addit_roaming_rype_code) > 0
    then
      forall i in v_addit_roaming_rype_code.first..v_addit_roaming_rype_code.last
        insert into network_operator_neighb_ext(roaming_definition_id, ext_roaming_type_code, date_of_change, user_id_of_change)
         values(v_new_interval, v_addit_roaming_rype_code(i), v_sysdate, p_user_id);
    end if;
    ------------------------------
  else
    ------------------------------
   UPDATE NETWORK_OPERATOR_NEIGHBOURS
       SET network_operator_id = p_network_operator_id,
           neighbouring_operator_id = p_new_neighbour_net_op_id,
           roaming_type_code = p_roaming_type_code,
           location_area_id = p_location_area_id,
           base_station_id = p_base_station_id,
           start_date = v_start_date,
           DATE_OF_CHANGE = v_sysdate,
           USER_ID_OF_CHANGE = p_user_id
       WHERE roaming_definition_id = p_roaming_definition_id
    ;
    ------------------------------
    delete /*+ index(none UI_NO_NEIGH_RD_ID_ROAM_TYPE)*/from network_operator_neighb_ext none
     where none.roaming_definition_id = p_roaming_definition_id
       and none.ext_roaming_type_code not in (select t.column_value ext_roaming_type_code from table(v_addit_roaming_rype_code) t);
    ------------------------------
    insert into network_operator_neighb_ext(roaming_definition_id, ext_roaming_type_code, date_of_change, user_id_of_change)
      select p_roaming_definition_id, tt.ext_roaming_type_code, v_sysdate, p_user_id
        from (select /*+ ordered use_nl(t none) full(t) index(none UI_NO_NEIGH_RD_ID_ROAM_TYPE)*/
                     t.ext_roaming_type_code 
                from (select column_value ext_roaming_type_code from table(v_addit_roaming_rype_code)) t
                left join network_operator_neighb_ext none on none.ext_roaming_type_code = t.ext_roaming_type_code
                                                          and none.roaming_definition_id = p_roaming_definition_id
               where 1 = 1
               and none.ext_roaming_type_code is null
               ) tt
    ;
    ------------------------------
  end if;
  ------------------------------
  if upper(p_handle_tran) = rsig_utils.c_handle_tran_y then
    commit;
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  case p_handle_tran
    when rsig_utils.c_handle_tran_s then
      rollback to savepoint update_neighbour;
    when rsig_utils.c_handle_tran_y then
      rollback;
    else
      null;
  end case;
  ------------------------------
  if upper(p_raise_error) = rsig_utils.c_yes then
    raise;
  end if;
  ------------------------------
end;

---------------------------------------------
--     PROCEDURE addit_rt_neighbour_interval
---------------------------------------------

PROCEDURE Addit_RT_Neighbour_Interval
(
  p_roaming_definition_id IN network_operator_neighbours.roaming_definition_id%TYPE,
  p_raise_error           IN CHAR,
  p_result                OUT SYS_REFCURSOR,
  p_error_code            OUT NUMBER,
  p_error_message         OUT VARCHAR2
) IS
  v_package_name          VARCHAR2(30) := 'RSIG_NETWORK_OPERATOR';
  v_procedure_name        VARCHAR2(30) := 'addit_rt_neighbour_interval';
  v_event_source          VARCHAR2(60);
BEGIN


 v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF p_roaming_definition_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;
---------------------------------------------------------------------------------------------------------
  -- procedure body here
  open p_result for
    select none.ext_roaming_type_code
      from network_operator_neighb_ext none
     where none.roaming_definition_id = p_roaming_definition_id;

---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Addit_RT_Neighbour_Interval;

---------------------------------------------
--     PROCEDURE Delete_Neighbour
---------------------------------------------

PROCEDURE Delete_Neighbour
(
  p_network_operator    IN NETWORK_OPERATOR_NEIGHBOURS.NETWORK_OPERATOR_ID%TYPE,
  p_neighbour_net_op_id IN NETWORK_OPERATOR_NEIGHBOURS.NEIGHBOURING_OPERATOR_ID%TYPE,
  handle_tran           IN CHAR,
  p_raise_error         IN CHAR,
  ERROR_CODE            OUT NUMBER,
  error_message         OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Delete_Neighbour';
  v_sqlcode      NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  IF p_network_operator IS NULL
     OR p_neighbour_net_op_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Delete_Neighbour;
  END IF;
  DELETE FROM network_operator_neighb_ext none
   WHERE none.roaming_definition_id IN (SELECT non.roaming_definition_id
                                          FROM NETWORK_OPERATOR_NEIGHBOURS non
                                         WHERE (non.NETWORK_OPERATOR_ID = p_network_operator AND
                                               non.NEIGHBOURING_OPERATOR_ID = p_neighbour_net_op_id)
                                            OR (non.NEIGHBOURING_OPERATOR_ID = p_network_operator AND
                                               non.NETWORK_OPERATOR_ID = p_neighbour_net_op_id));
  -- procedure body here
  DELETE FROM NETWORK_OPERATOR_NEIGHBOURS non
   WHERE (non.NETWORK_OPERATOR_ID = p_network_operator AND
         non.NEIGHBOURING_OPERATOR_ID = p_neighbour_net_op_id)
      OR (non.NEIGHBOURING_OPERATOR_ID = p_network_operator AND
         non.NETWORK_OPERATOR_ID = p_neighbour_net_op_id);

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Delete_Neighbour;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Delete_Neighbour;


---------------------------------------------
--     PROCEDURE Get_net_op_Neighbours
---------------------------------------------

PROCEDURE Get_Net_Op_Neighbours
(
  p_network_operator_id IN NETWORK_OPERATOR_NEIGHBOURS.NETWORK_OPERATOR_ID%TYPE,
  p_raise_error         IN CHAR,
  ERROR_CODE            OUT NUMBER,
  error_message         OUT VARCHAR2,
  result_list           OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Get_net_op_Neighbours';
  v_sqlcode      NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  OPEN result_list FOR
    SELECT non.NETWORK_OPERATOR_ID,
           no.NETWORK_OPERATOR_CODE NET_OP_CODE,
           no.NETWORK_OPERATOR_NAME NET_OP_NAME,
           (SELECT NO1.NETWORK_OPERATOR_ID
              FROM NETWORK_OPERATOR NO1
             WHERE NO1.NETWORK_OPERATOR_ID_UPPER IS NULL
             START WITH NO1.NETWORK_OPERATOR_ID = non.NETWORK_OPERATOR_ID
            CONNECT BY PRIOR NO1.NETWORK_OPERATOR_ID_UPPER = NO1.NETWORK_OPERATOR_ID) TOP_PARENT_OP_ID,
           non.NEIGHBOURING_OPERATOR_ID,
           no_n.NETWORK_OPERATOR_CODE NET_OP_NEIGHBOUR_CODE,
           no_n.NETWORK_OPERATOR_NAME NET_OP_NEIGHBOUR_NAME,
           (SELECT NO1.NETWORK_OPERATOR_ID
              FROM NETWORK_OPERATOR NO1
             WHERE NO1.NETWORK_OPERATOR_ID_UPPER IS NULL
             START WITH NO1.NETWORK_OPERATOR_ID = non.NEIGHBOURING_OPERATOR_ID
            CONNECT BY PRIOR NO1.NETWORK_OPERATOR_ID_UPPER = NO1.NETWORK_OPERATOR_ID) TOP_PARENT_NEIGHBOURING_OP_ID,
           non.roaming_type_code + nvl(none.ext_roaming_type_code, 0) roaming_type_code
      FROM NETWORK_OPERATOR_NEIGHBOURS non
      JOIN NETWORK_OPERATOR no ON no.NETWORK_OPERATOR_ID = non.NETWORK_OPERATOR_ID
      JOIN NETWORK_OPERATOR no_n ON no_n.NETWORK_OPERATOR_ID = non.NEIGHBOURING_OPERATOR_ID
      LEFT JOIN (select roaming_definition_id, SUM(ext_roaming_type_code) ext_roaming_type_code 
                   from network_operator_neighb_ext 
                  group by roaming_definition_id) none on none.roaming_definition_id = non.roaming_definition_id
     WHERE (non.NETWORK_OPERATOR_ID = p_network_operator_id OR p_network_operator_id IS NULL)
     ORDER BY NET_OP_CODE,
              NET_OP_NEIGHBOUR_CODE;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_net_op_Neighbours;

------------------------------------------------------------------------------------------------------------------------------
--  Get_NO_with_linked_phones
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_NO_with_linked_phones(
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'RSIG_NETWORK_OPERATOR';
  v_procedure_name        VARCHAR2(30) := 'Get_NO_with_linked_phones';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(32767);
  v_sysdate               DATE:=SYSDATE;
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  /*v_message:= 'Input parameters:' || chr(10) ||
                'parameter1 ' || parameter1 || chr(10) || ... */

  -- check input parameters
/*  IF .... THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;*/
---------------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
  SELECT n.network_operator_id,
         n.network_operator_name
  FROM network_operator n
  WHERE (n.deleted IS NULL OR n.deleted>v_sysdate)
    AND EXISTS(SELECT 1
               FROM phone_series_operator pso
               JOIN phone_number_series pns ON pns.phone_number_series_id=pso.phone_number_series_id
               JOIN phone_number_type pnt ON pnt.PHONE_NUMBER_TYPE_CODE=pns.phone_number_type_code
               WHERE v_sysdate BETWEEN pso.start_date AND nvl(pso.end_date,v_sysdate)
                 AND pnt.is_shared=rsig_utils.c_YES
                 AND n.network_operator_id=pso.network_operator_id);
---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    OPEN p_result_list FOR SELECT p_error_code FROM dual;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_NO_with_linked_phones;


------------------------------------------------------------------------------------------------------------------------------
--  Close_Neighbour_Interval
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Close_Neighbour_Interval (
  p_roaming_definition_id IN network_operator_neighbours.roaming_definition_id%TYPE,
  p_end_date              IN DATE,
  p_user_id               IN NUMBER,
  p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_raise_error           IN CHAR,
  p_error_code            OUT NUMBER,
  p_error_message         OUT VARCHAR2
) IS
  v_package_name          VARCHAR2(30) := 'RSIG_NETWORK_OPERATOR';
  v_procedure_name        VARCHAR2(30) := 'Close_Neighbour_Interval';
  v_event_source          VARCHAR2(60);
  v_sysdate               DATE := sysdate;
  v_end_date              DATE := NVL(p_end_date, v_sysdate);
  v_exist_netop           NUMBER;
BEGIN


 v_event_source:=v_package_name || '.' || v_procedure_name;

   -- check handle_tran parameter
  Common.Check_Handle_Tran(p_handle_tran,v_procedure_name);

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF p_roaming_definition_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;

  -- check input parameters
  IF v_end_date < v_sysdate THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter(p_end_date).');
  END IF;
---------------------------------------------------------------------------------------------------------
  -- procedure body here
  SELECT COUNT(*)
     INTO v_exist_netop
    FROM NETWORK_OPERATOR_NEIGHBOURS non
   WHERE non.roaming_definition_id = p_roaming_definition_id;

  IF v_exist_netop = 0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER,'Doesn''t exist network operator neighbour record for update');
  END IF;

  UPDATE NETWORK_OPERATOR_NEIGHBOURS
     SET END_DATE          = v_end_date,
         DATE_OF_CHANGE    = SYSDATE,
         USER_ID_OF_CHANGE = p_user_id
   WHERE roaming_definition_id = p_roaming_definition_id;

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Close_Neighbour_Interval;

------------------------------------------------------------------------------------------------------------------------------
--     Get_Net_Op_Neighbours_BS_LOC
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Net_Op_Neighbours_BS_LOC
(
  p_network_operator_id IN NETWORK_OPERATOR_NEIGHBOURS.NETWORK_OPERATOR_ID%TYPE,
  p_valid_date          IN DATE,
  p_raise_error         IN CHAR,
  p_ERROR_CODE          OUT NUMBER,
  p_error_message       OUT VARCHAR2,
  p_result_list         OUT sys_refcursor
) IS
  v_package_name          VARCHAR2(30) := 'RSIG_NETWORK_OPERATOR';
  v_procedure_name        VARCHAR2(30) := 'Get_Net_Op_Neighbours_BS_LOC';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(32767);
BEGIN
  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_network_operator_id: ' || p_network_operator_id || chr(10) ||
              'p_valid_date: ' || p_valid_date;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF p_network_operator_id IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;
---------------------------------------------------------------------------------------------------------

  OPEN p_result_list FOR
    SELECT /*+ ordered driving_site(non) use_nl(non no la bs u) use_hash(rt none) index(non UK_NETWORK_OPERATOR_NEIGHBOURS)
               index(no PK_NETWORK_OPERATOR) index(la PK_LOCATION_AREA) index(bs PK_BASE_STATION)
               index(u PK_USERS) full(rt)*/
           non.network_operator_id,
           non.roaming_definition_id,
           no.network_operator_name,
           rt.roaming_type_name,
           la.location_area_id,
           la.location_area_name,
           bs.base_station_id,
           bs.base_station_name,
           non.start_date,
           non.end_date,
           u.user_name,
           rt.roaming_type_code,
           no.network_operator_id,
           ext_raoming_types
    FROM network_operator_neighbours non
    JOIN network_operator no ON no.network_operator_id = non.neighbouring_operator_id
    LEFT JOIN location_area la ON la.location_area_id = non.location_area_id
    LEFT JOIN base_station bs ON bs.base_station_id = non.base_station_id
    JOIN roaming_type rt ON rt.roaming_type_code = non.roaming_type_code
    JOIN users u ON u.user_id = non.user_id_of_change
    LEFT JOIN (
      select /*+ ordered driving_site(t) use_hash(t rt1) full(t) full(rt)*/
        t.roaming_definition_id, str_concat(rt1.ROAMING_TYPE_NAME) as ext_raoming_types
      from network_operator_neighb_ext t
      join roaming_type rt1 on rt1.ROAMING_TYPE_CODE = t.ext_roaming_type_code
      group by t.roaming_definition_id) none on none.roaming_definition_id = non.roaming_definition_id
    WHERE non.network_operator_id = p_network_operator_id
    AND no.deleted IS NULL
    AND la.deleted IS NULL
    AND bs.deleted IS NULL;

--------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_Net_Op_Neighbours_BS_LOC;

------------------------------------------------------------------------------------------------------------------------------
--     Get_Net_Op_Neighbours_BS_LOC
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Net_Op_Neighbours_BS_LOC2
(
  p_network_operator_id         IN NUMBER,
  p_neigh_network_operator_name IN VARCHAR2,
  p_location_area_name          IN VARCHAR2,
  p_base_station_name           IN VARCHAR2,
  p_roaming_rype_code	          IN  T_HNO,
  p_valid_date_from             IN DATE,
  p_valid_date_to               IN DATE,
  p_raise_error                 IN CHAR,
  p_ERROR_CODE                  OUT NUMBER,
  p_error_message               OUT VARCHAR2,
  p_result_list                 OUT sys_refcursor
) IS
  v_package_name          VARCHAR2(30) := 'RSIG_NETWORK_OPERATOR';
  v_procedure_name        VARCHAR2(30) := 'Get_Net_Op_Neighbours_BS_LOC';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(32767);
  v_validity_date_from    date := nvl(p_valid_date_from, sysdate);
BEGIN
  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_network_operator_id: ' || p_network_operator_id || chr(10) ||
              'p_neigh_network_operator_name: ' || p_neigh_network_operator_name || chr(10) ||
              'p_location_area_name: ' || p_location_area_name || chr(10) ||
              'p_base_station_name: ' || p_base_station_name || chr(10) ||
              'p_roaming_rype_code.count: ' || p_roaming_rype_code.count || chr(10) ||
              'p_valid_date_from: ' || to_char(p_valid_date_from) || chr(10) ||
              'p_valid_date_to: ' || to_char(p_valid_date_to);

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  IF p_network_operator_id IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;
---------------------------------------------------------------------------------------------------------

  DELETE FROM TT_NUMBERS;
  for i in nvl(p_roaming_rype_code.first,1)..nvl(p_roaming_rype_code.last,0)
  loop
    if (p_roaming_rype_code(i) is not null)
    then
      insert into TT_NUMBERS(VALUE)
        values(p_roaming_rype_code(i));
    end if;
  end loop;
  commit;
  
  OPEN p_result_list FOR
    SELECT /*+ ordered driving_site(non) use_nl(non no la bs u) use_hash(rt none)
               index(no PK_NETWORK_OPERATOR) index(la PK_LOCATION_AREA) index(bs PK_BASE_STATION)
               index(u PK_USERS) full(rt)*/
           non.network_operator_id,
           non.roaming_definition_id,
           no.network_operator_name,
           rt.roaming_type_name,
           la.location_area_id,
           la.location_area_name,
           bs.base_station_id,
           bs.base_station_name,
           non.start_date,
           non.end_date,
           u.user_name,
           rt.roaming_type_code,
           no.network_operator_id,
           ext_raoming_types
    FROM (select /*+ ordered use_hash(non1 tt) index(non1 UK_NETWORK_OPERATOR_NEIGHBOURS) full(tt)*/
                 distinct non1.* 
            from network_operator_neighbours non1
            join tt_numbers tt on tt.value = non1.roaming_type_code
           where non1.network_operator_id = p_network_operator_id
           union
           select /*+ ordered use_nl(non2 none2) use_hash(tt) index(non2 UK_NETWORK_OPERATOR_NEIGHBOURS) index(none2 UI_NO_NEIGH_RD_ID_ROAM_TYPE) full(tt)*/
                 distinct non2.* 
            from network_operator_neighbours non2
            join network_operator_neighb_ext none2 on none2.roaming_definition_id = non2.roaming_definition_id
            join tt_numbers tt on tt.value = none2.ext_roaming_type_code
           where non2.network_operator_id = p_network_operator_id) non
    JOIN network_operator no ON no.network_operator_id = non.neighbouring_operator_id
    LEFT JOIN location_area la ON la.location_area_id = non.location_area_id
    LEFT JOIN base_station bs ON bs.base_station_id = non.base_station_id
    JOIN roaming_type rt ON rt.roaming_type_code = non.roaming_type_code
    JOIN users u ON u.user_id = non.user_id_of_change
    LEFT JOIN (
      select /*+ ordered driving_site(t) use_hash(t rt1) full(t) full(rt)*/
        t.roaming_definition_id, str_concat(rt1.ROAMING_TYPE_NAME) as ext_raoming_types
      from network_operator_neighb_ext t
      join roaming_type rt1 on rt1.ROAMING_TYPE_CODE = t.ext_roaming_type_code
      group by t.roaming_definition_id) none on none.roaming_definition_id = non.roaming_definition_id
    WHERE 1 = 1
    AND (no.network_operator_name like p_neigh_network_operator_name or p_neigh_network_operator_name is null)
    AND (la.location_area_name like p_location_area_name OR p_location_area_name = rsig_utils.c_any_object_mask OR (p_location_area_name IS NULL and la.location_area_name is null))
    AND (bs.base_station_name like p_base_station_name OR p_base_station_name = rsig_utils.c_any_object_mask OR (p_base_station_name IS NULL and bs.base_station_name is null))
    AND (v_validity_date_from BETWEEN non.start_date and nvl(non.end_date, v_validity_date_from)
      OR non.start_date BETWEEN v_validity_date_from and nvl(p_valid_date_to,v_validity_date_from))
    AND no.deleted IS NULL
    AND la.deleted IS NULL
    AND bs.deleted IS NULL;

--------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_Net_Op_Neighbours_BS_LOC2;

------------------------------------------------------------------------------------------------------------------------------
--     Get_Roaming_Type
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Roaming_Type
(
  p_hno_id_l            IN t_hno,
  p_msc_l               IN t_MSC,
  p_lac_l               IN t_BSC,
  p_cellid_l            IN t_BSC,
  p_Validity_Date_l     IN t_date,
  p_raise_error         IN CHAR,
  p_ERROR_CODE          OUT NUMBER,
  p_error_message       OUT VARCHAR2,
  p_result_list         OUT sys_refcursor
)
IS
  v_package_name          VARCHAR2(30) := 'RSIG_NETWORK_OPERATOR';
  v_procedure_name        VARCHAR2(30) := 'Get_Roaming_Type2';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(1000);
  v_sysdate               DATE:=SYSDATE;
  v_row_num_l             common.t_number;
  v_NET_OP_INF_OBJ        t_net_op_inf_obj:=t_net_op_inf_obj(NULL,NULL,NULL,NULL,NULL,NULL);
  v_NET_OP_INF_list			  t_net_op_inf_obj_tab:= t_net_op_inf_obj_tab();
BEGIN
  v_event_source:=v_package_name || '.' || v_procedure_name;

   v_message:= 'Input parameters:' || chr(10) ||
              'p_hno_id_l: ' || p_hno_id_l.COUNT || chr(10) ||
              'p_msc_l: ' || p_msc_l.COUNT || chr(10) ||
              'p_lac_l: ' || p_lac_l.COUNT || chr(10) ||
              'p_cellid_l: ' || p_cellid_l.COUNT || chr(10) ||
              'p_Validity_Date_l: ' || p_Validity_Date_l.COUNT;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check input parameters
  
  --check p_hno_id_l parameter
  IF (p_hno_id_l.COUNT = 0) OR (p_hno_id_l.COUNT = 1 AND p_hno_id_l(p_hno_id_l.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter (p_hno_id_l).');
  END IF;
  
  --check p_msc_l parameter
  IF (p_msc_l.COUNT = 0) OR (p_msc_l.COUNT = 1 AND p_msc_l(p_msc_l.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter (p_msc_l).');
  END IF;
  
  --check p_lac_l parameter
  IF (p_lac_l.COUNT = 0) OR (p_lac_l.COUNT = 1 AND p_lac_l(p_lac_l.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter (p_lac_l).');
  END IF;
  
  --check p_cellid_l parameter
  IF (p_cellid_l.COUNT = 0) OR (p_cellid_l.COUNT = 1 AND p_cellid_l(p_cellid_l.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter (p_cellid_l).');
  END IF;
  
  --check p_Validity_Date_l parameter
  IF (p_Validity_Date_l.COUNT = 0) OR (p_Validity_Date_l.COUNT = 1 AND p_Validity_Date_l(p_Validity_Date_l.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter. (p_Validity_Date_l).');
  END IF;
  
  IF p_hno_id_l.COUNT<>p_msc_l.COUNT OR
     p_msc_l.COUNT<>p_lac_l.COUNT OR
     p_lac_l.COUNT<>p_cellid_l.COUNT OR
     p_cellid_l.COUNT<>p_Validity_Date_l.COUNT
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters (COUNT).');
  END IF;
---------------------------------------------------------------------------------------------------------
  DELETE FROM TT_Network_Operator_Neighbours;

  FOR y IN p_hno_id_l.FIRST .. p_hno_id_l.LAST LOOP
    v_row_num_l(y):=y;
  END LOOP;
   -- fill input data to temporary table
  FOR i IN nvl(p_hno_id_l.FIRST, 1) .. nvl(p_hno_id_l.LAST, 0) 
  loop 
    v_NET_OP_INF_OBJ:=t_net_op_inf_obj(p_hno_id_l(i),
         p_cellid_l(i),
         p_lac_l(i),
         p_msc_l(i),
         nvl(p_Validity_Date_l(i),v_sysdate),
         v_row_num_l(i));
    v_NET_OP_INF_list.extend; 
    v_NET_OP_INF_list(i):=v_NET_OP_INF_OBJ; 
  end loop;

  INSERT INTO TT_Network_Operator_Neighbours(
         Home_Network_Operator_Id,
         Base_Station_Code,
         Location_Area_Code,
         Msc_Code,
         Validity_Date,
         Msc_Id,
         Network_Operator_Id,
         Location_Area_Id,
         Base_Station_Id,
         Row_Number)
  SELECT /*+ ordered use_hash(e la bs) full(la) full(bs) no_merge(e)*/
         e.home_network_operator_id,
         e.base_station_code,
         e.location_area_code,
         e.msc_code,
         e.Validity_Date,
         e.host_id,
         e.network_operator_id,
         la.location_area_id,
         bs.base_station_id,
         e.row_number
  FROM (select /*+ no_merge(r)*/
               home_network_operator_id,
               base_station_code,
               location_area_code,
               msc_code,
               Validity_Date,
               host_id,
               network_operator_id,
               host_code,
               row_number
        from (select /*+ ordered use_hash(t h) full(t) full(h)*/
              t.home_network_operator_id,
              t.base_station_code,
              t.location_area_code,
              t.msc_code,
              t.Validity_Date,
              h.host_id,
              h.network_operator_id,
              h.host_code,
              t.row_number,
              row_number() over (partition by t.row_number
                                 order by length(h.host_code) DESC) rn
              FROM TABLE(CAST(v_NET_OP_INF_list AS t_net_op_inf_obj_tab)) t
              join host h on ascii(h.host_code)=ascii(t.Msc_Code)
                   AND h.host_code=substr(t.Msc_Code,1,length(h.host_code))
              where h.deleted IS NULL) r
        where r.rn=1) e
  LEFT JOIN location_area la ON la.host_id=e.host_id
       AND la.location_area_code=e.location_area_code
       AND la.deleted IS NULL
  LEFT JOIN base_station bs ON bs.location_area_id=la.location_area_id
       AND bs.base_station_code=e.base_station_code
       AND bs.deleted IS NULL;

  -- no roaming
  UPDATE TT_Network_Operator_Neighbours t
  SET t.roaming_type_code=0
  WHERE t.home_network_operator_id=t.network_operator_id;



  update TT_Network_Operator_Neighbours t
  SET t.roaming_type_code=(select non.roaming_type_code + nvl(none.ext_roaming_type_code, 0) roaming_type_code
                           from network_operator_neighbours non
                           LEFT JOIN (select roaming_definition_id, SUM(ext_roaming_type_code) ext_roaming_type_code 
                                from network_operator_neighb_ext 
                               group by roaming_definition_id) none on none.roaming_definition_id = non.roaming_definition_id
                           where non.network_operator_id=t.home_network_operator_id
                             and non.neighbouring_operator_id=t.network_operator_id
                             and non.location_area_id=t.location_area_id
                             and non.base_station_id=t.base_station_id
                             and t.validity_date between non.start_date and nvl(non.end_date,t.validity_date)
                             and non.roaming_type_code is not null)
  where t.roaming_type_code is null;

  update TT_Network_Operator_Neighbours t
  SET t.roaming_type_code=(select non.roaming_type_code + nvl(none.ext_roaming_type_code, 0) roaming_type_code
                           from network_operator_neighbours non
                           LEFT JOIN (select roaming_definition_id, SUM(ext_roaming_type_code) ext_roaming_type_code 
                                from network_operator_neighb_ext 
                               group by roaming_definition_id) none on none.roaming_definition_id = non.roaming_definition_id
                           where non.network_operator_id=t.home_network_operator_id
                             and non.neighbouring_operator_id=t.network_operator_id
                             and non.location_area_id=t.location_area_id
                             and non.base_station_id is null
                             and t.validity_date between non.start_date and nvl(non.end_date,t.validity_date)
                             and non.roaming_type_code is not null)
  where t.roaming_type_code is null;


  update TT_Network_Operator_Neighbours t
  SET t.roaming_type_code=(select non.roaming_type_code + nvl(none.ext_roaming_type_code, 0) roaming_type_code
                           from network_operator_neighbours non
                           LEFT JOIN (select roaming_definition_id, SUM(ext_roaming_type_code) ext_roaming_type_code 
                                from network_operator_neighb_ext 
                               group by roaming_definition_id) none on none.roaming_definition_id = non.roaming_definition_id
                           where non.network_operator_id=t.home_network_operator_id
                             and non.neighbouring_operator_id=t.network_operator_id
                             and non.location_area_id is null
                             and non.base_station_id is null
                             and t.validity_date between non.start_date and nvl(non.end_date,t.validity_date)
                             and non.roaming_type_code is not null)
  where t.roaming_type_code is null;


 -- no roaming
  UPDATE TT_Network_Operator_Neighbours t
  SET t.roaming_type_code=4
  WHERE t.roaming_type_code is null;


  OPEN p_result_list FOR
  SELECT t.home_network_operator_id,
         t.msc_code,
         t.location_area_code,
         t.base_station_code,
         t.validity_date,
         t.roaming_type_code,
         t.network_operator_id
  FROM TT_Network_Operator_Neighbours t
  ORDER BY t.row_number;

 -------------------------------------------------------------------------------------------------------
  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;

    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END Get_Roaming_Type;

------------------------------------------------------------------------------------------------------------------------------
--  GetRoamingCache
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE GetRoamingCache(
  p_ValidityStartDate      IN  DATE,
  p_ValidityEndDate        IN  DATE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_HostNOs                OUT SYS_REFCURSOR,
  p_RoamingTypes           OUT SYS_REFCURSOR,
  p_phones                 OUT SYS_REFCURSOR
)
IS
  v_package_name          VARCHAR2(30) := 'RSIG_NETWORK_OPERATOR';
  v_procedure_name        VARCHAR2(30) := 'GetRoamingCache';
  v_event_source          VARCHAR2(60);
  v_message               VARCHAR2(1000);
BEGIN

  v_event_source:=v_package_name || '.' || v_procedure_name;

  v_message:= 'Input parameters:' || chr(10) ||
              'p_ValidityStartDate: ' || p_ValidityStartDate || chr(10) ||
              'p_ValidityEndDate: ' || p_ValidityEndDate;

  -- log start of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_START||' '||v_message,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);


  -- check input parameters
  IF p_ValidityStartDate IS NULL OR p_ValidityEndDate IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing mandatory parameters.');
  END IF;
---------------------------------------------------------------------------------------------------------
  OPEN p_HostNOs FOR
  SELECT h.host_code,
         h.network_operator_id
  FROM host h
  WHERE h.deleted IS NULL;


  OPEN p_RoamingTypes FOR
  SELECT non.network_operator_id,
         non.neighbouring_operator_id,
         h.host_code,
         la.location_area_code,
         bs.base_station_code,
         non.roaming_type_code + nvl(none.ext_roaming_type_code, 0) roaming_type_code,
         non.start_date,
         non.end_date
  FROM network_operator_neighbours non
  LEFT JOIN (select roaming_definition_id, SUM(ext_roaming_type_code) ext_roaming_type_code 
               from network_operator_neighb_ext 
              group by roaming_definition_id) none on none.roaming_definition_id = non.roaming_definition_id
  LEFT JOIN location_area la ON la.location_area_id=non.location_area_id
  LEFT JOIN host h ON h.host_id=la.host_id
  LEFT JOIN base_station bs ON bs.base_station_id=non.base_station_id
  WHERE non.start_date<=p_ValidityEndDate
    AND (non.end_date>=p_ValidityStartDate OR non.end_date IS NULL);
    
  
  OPEN p_phones FOR
  SELECT pns.country_code || pns.area_code || pns.local_number_start phone_number_start,
       pns.country_code || pns.area_code || pns.local_number_end phone_number_end,
       pso.network_operator_id,
       pso.start_date,
       pso.end_date
  FROM phone_number_series pns
  JOIN phone_series_operator pso ON pso.phone_number_series_id=pns.phone_number_series_id
  JOIN network_operator n ON n.network_operator_id=pso.network_operator_id
  WHERE pns.deleted IS NULL
    AND n.network_operator_type IS NULL
    AND pso.start_date<=p_ValidityEndDate
    AND (pso.end_date>=p_ValidityStartDate OR pso.end_date IS NULL)
  ORDER BY TO_NUMBER(pns.country_code || pns.area_code || pns.local_number_start);

---------------------------------------------------------------------------------------------------------

  -- log end of procedure
  Common.Event_Logger(RSIG_UTILS.c_DEBUG_TEXT_END,RSIG_UTILS.c_DEBUG_LEVEL_1,RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := common.Handle_Error(SQLCODE,SQLERRM,v_message,NULL,v_package_name,v_procedure_name);
    p_error_message := sqlerrm;


    IF upper(p_raise_error)=rsig_utils.c_YES THEN
      RAISE;
    END IF;
END GetRoamingCache;

--------------------------------------------------------------------
--     PROCEDURE Get_Net_Op_Id_By_Code
--------------------------------------------------------------------

PROCEDURE Get_Net_Op_Id_By_Code
(
  p_Error_Code            OUT NUMBER,
  p_Error_Message         OUT VARCHAR2,
  p_Network_Operator_Code IN  NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,  
  p_Network_Operator_Id   OUT NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
) IS

  v_Event_Source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Get_Net_Op_Id_By_Code';
  
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_Event_Source);

  p_Network_Operator_Id := NULL;

  IF p_Network_Operator_Code IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  BEGIN
	  SELECT NETWORK_OPERATOR_ID
			INTO p_Network_Operator_Id
		FROM NETWORK_OPERATOR
	  WHERE NETWORK_OPERATOR_CODE = p_Network_Operator_Code
		AND (DELETED IS NULL OR DELETED > SYSDATE);
	  EXCEPTION
	  WHEN NO_DATA_FOUND THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, 'Network operator code does not exist');
  END;

  p_Error_Code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_Event_Source);                        
EXCEPTION
    WHEN OTHERS THEN
      p_Error_Code := RSIG_UTILS.Handle_Error(SQLCODE);
      p_Error_Message := sqlerrm;
      
      RSIG_UTILS.Debug_Rsi(p_Error_Code,
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_Event_Source);

END Get_Net_Op_Id_By_Code;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Update_Network_Operator_PA
(
  p_network_operator_code varchar2,
  p_personal_account number,
  p_user_login varchar2,
  p_error_code out number,
  p_error_message out varchar2
)
is
  v_date date := sysdate;
  v_user_id number;
  v_network_operator_id number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_network_operator_code is null, 'p_network_operator_code is null');
  util_pkg.XCheck_Cond_Missing(p_personal_account is null, 'p_personal_account is null');
  util_pkg.XCheck_Cond_Missing(p_user_login is null, 'p_user_login is null');
  ------------------------------
  v_user_id := util_ri.xget_user_id(p_user_login);
  ------------------------------
  v_network_operator_id := util_ri.get_network_operator_id2(p_network_operator_code, v_date);
  ------------------------------
  --!_! must be moved to lower level layer
  update network_operator 
     set personal_account = p_personal_account, 
         date_of_change = v_date,
     user_id_of_change = v_user_id
   where network_operator_id = v_network_operator_id
  ;
  ------------------------------
  COMMIT;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ROLLBACK;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

---------------------------------------------
--     PROCEDURE Get_Country_ID_By_MCC
---------------------------------------------

PROCEDURE Get_Country_ID_By_MCC
(
  p_mcc                   IN VARCHAR2,
  error_code              OUT NUMBER,
  p_country_id            OUT VARCHAR2
) IS
  v_count          NUMBER;
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Get_Country_ID_By_MCC';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

    SELECT COUNT (1)
    INTO v_count
      FROM COUNTRY_MCC n
      WHERE n.MCC_CODE = p_mcc;

  IF (v_count > 1)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_TOO_MANY_ROWS_RETRIEVED, 'Too many rows retriewed.');
  END IF;

  IF (v_count = 0)
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NO_DATA_FOUND, 'No data found');
  END IF;

  BEGIN
    SELECT n.COUNTRY_ID
    INTO p_country_id
       FROM COUNTRY_MCC n
       WHERE n.MCC_CODE = p_mcc;
  END;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Get_Country_ID_By_MCC;

---------------------------------------------
--     PROCEDURE Insert_Network_Operator_1
---------------------------------------------

PROCEDURE Insert_Network_Operator_1
(
  handle_tran                 IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                  OUT NUMBER,
  p_network_operator_id_upper IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
  p_network_operator_code     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
  p_network_operator_name     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_NAME%TYPE,
  p_network_operator_type     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
  p_personal_account          IN  NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
  p_UPRS_Member_Code          IN  NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
  p_country                   IN  network_operator.country%TYPE,
  p_user_id_of_change         IN  NUMBER,  
  p_mcc                       IN   VARCHAR2,
  p_mnc                       IN   VARCHAR2,
  p_network_operator_id       OUT NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Insert_Network_Operator_1';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint insert_network_operator_a;
  END IF;

  IF p_network_operator_id_upper IS NOT NULL THEN
    Test_Network_Operator_Deleted(p_network_operator_id_upper);
  END IF;

  select s_network_operator.nextval into p_network_operator_id from DUAL;
  BEGIN
    insert into NETWORK_OPERATOR
      (NETWORK_OPERATOR_ID,
       NETWORK_OPERATOR_CODE,
       NETWORK_OPERATOR_NAME,
       NETWORK_OPERATOR_TYPE,
       NETWORK_OPERATOR_ID_UPPER,
       PERSONAL_ACCOUNT,
       UPRS_MEMBER_CODE,
       DELETED,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE,
       country,
       mcc,
       mnc)
    values
      (p_network_operator_id,
       p_network_operator_code,
       p_network_operator_name,
       p_network_operator_type,
       p_network_operator_id_upper,
       p_personal_account,
       p_UPRS_Member_Code,
       null,
       sysdate,
       p_user_id_of_change,
       p_country,
       p_mcc,
       p_mnc);

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_NETWORK_OPERATOR_CODE then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_CODE, '');
      else
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_NAME, '');
      end if;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint insert_network_operator_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Insert_Network_Operator_1;

---------------------------------------------
--     PROCEDURE Update_Network_Operator_1
---------------------------------------------

PROCEDURE Update_Network_Operator_1
(
  handle_tran                 IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                  OUT NUMBER,
  p_network_operator_id       IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_network_operator_id_upper IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
  p_network_operator_code     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
  p_network_operator_name     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_NAME%TYPE,
  p_network_operator_type     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
  p_personal_account          IN  NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
  p_UPRS_Member_Code          IN  NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
  p_country                   IN  network_operator.country%TYPE,
  p_user_id_of_change         IN NUMBER,
  p_mcc                       IN   VARCHAR2,
  p_mnc                       IN   VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Update_Network_Operator_1';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint update_network_operator_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_network_operator_id);
  IF p_network_operator_id_upper IS NOT NULL THEN
    Test_Network_Operator_Deleted(p_network_operator_id_upper);
  END IF;

  BEGIN
    update NETWORK_OPERATOR
       set NETWORK_OPERATOR_CODE     = p_network_operator_code,
           NETWORK_OPERATOR_NAME     = p_network_operator_name,
           NETWORK_OPERATOR_TYPE     = p_network_operator_type,
           NETWORK_OPERATOR_ID_UPPER = p_network_operator_id_upper,
           PERSONAL_ACCOUNT          = p_personal_account,
           UPRS_MEMBER_CODE          = p_UPRS_Member_Code,
           DATE_OF_CHANGE            = sysdate,
           USER_ID_OF_CHANGE         = p_user_id_of_change,
           country                   = p_country,
           mcc                       = p_mcc,
           mnc                       = p_mnc
     where NETWORK_OPERATOR_ID = p_network_operator_id;

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_NETWORK_OPERATOR_CODE then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_CODE, '');
      else
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_NAME, '');
      end if;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint update_network_operator_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Update_Network_Operator_1;

------------------------------------------------------------------------------------------------------------------------------
--  Get_No_Code_By_IMSI_List
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_No_Code_By_IMSI_List(
  p_IMSI_list        IN   t_imsi,
  p_raise_error      IN   CHAR,
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
)
IS
  v_sqlcode          number;
  v_event_source     varchar2(60) :='Interface_for_SUPS.Get_No_Code_By_IMSI_List';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  --check p_IMSI_list parameter
  IF (p_IMSI_list.COUNT = 0) OR (p_IMSI_list.COUNT = 1 AND p_IMSI_list(p_IMSI_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
  
  DELETE FROM tt_batch_na_ap;

-- start of the procedure body --------------------------------------------------------------------------------------------------
  
  FORALL i IN nvl(p_IMSI_list.FIRST, 1) .. nvl(p_IMSI_list.LAST, 0)
    INSERT INTO tt_batch_NA_AP(Imsi)
    VALUES(p_IMSI_list(i));

  OPEN p_result_list FOR
    SELECT /*+ ordered use_nl(tt si sc ss no) full(tt) index(si UK_SIM_IMSI_IMSI)
               index(sc PK_SIM_CARD) index(ss PK_SIM_SERIES) index(no PK_NETWORK_OPERATOR)*/
           tt.imsi, 
           no.network_operator_code
      FROM tt_batch_na_ap tt
        LEFT JOIN sim_imsi si ON si.imsi=tt.imsi
        LEFT JOIN sim_card sc ON sc.access_point_id=si.access_point_id        
        LEFT JOIN sim_series ss ON ss.sim_series_id = si.sim_series_id
        LEFT JOIN network_operator no ON ss.network_operator_id = no.network_operator_id;
  COMMIT;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
    p_error_code := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
    WHEN OTHERS THEN
        v_sqlcode := sqlcode;
        p_error_message := sqlerrm;
--        DBMS_OUTPUT.PUT_LINE(p_error_message);
        p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
        RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
        OPEN p_result_list FOR SELECT v_sqlcode, p_error_message FROM dual;
        IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
            RAISE;
        END IF;
END Get_No_Code_By_IMSI_List;

------------------------------------------------------------------------------------------------------------------------------
--  Get_No_Code_By_MSISDN_List
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_No_Code_By_MSISDN_List(
  p_MSISDN_list      IN   t_phone,
  p_raise_error      IN   CHAR,
  p_error_code       OUT  NUMBER,
  p_error_message    OUT  VARCHAR2,
  p_result_list      OUT  SYS_REFCURSOR
)
IS
  v_sqlcode          number;
  v_event_source     varchar2(60) :='Interface_for_SUPS.Get_No_Code_By_MSISDN_List';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  --check p_MSISDN_list parameter
  IF (p_MSISDN_list.COUNT = 0) OR (p_MSISDN_list.COUNT = 1 AND p_MSISDN_list(p_MSISDN_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
  
  DELETE FROM tt_batch_na_ap;

-- start of the procedure body --------------------------------------------------------------------------------------------------
  
  FORALL i IN nvl(p_MSISDN_list.FIRST, 1) .. nvl(p_MSISDN_list.LAST, 0)
    INSERT INTO tt_batch_NA_AP(international_format)
    VALUES(p_MSISDN_list(i));

  OPEN p_result_list FOR
    SELECT tt.international_format, 
           no.network_operator_code 
      FROM tt_batch_na_ap tt           
        LEFT JOIN phone_number pn ON tt.international_format = pn.international_format
        LEFT JOIN phone_number_series pns on pns.phone_number_series_id = pn.phone_number_series_id
        LEFT JOIN host h on h.host_id = pns.host_id
        LEFT JOIN network_operator no on h.network_operator_id = no.network_operator_id;

  COMMIT;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
    p_error_code := RSIG_UTILS.c_OK;
    RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
    WHEN OTHERS THEN
        v_sqlcode := sqlcode;
        p_error_message := sqlerrm;
--        DBMS_OUTPUT.PUT_LINE(p_error_message);
        p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
        RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
        OPEN p_result_list FOR SELECT v_sqlcode, p_error_message FROM dual;
        IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
            RAISE;
        END IF;
END Get_No_Code_By_MSISDN_List;

---------------------------------------------
--     PROCEDURE Insert_Network_Operator_2
---------------------------------------------

PROCEDURE Insert_Network_Operator_2
(
  handle_tran                 IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                  OUT NUMBER,
  p_network_operator_id_upper IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
  p_network_operator_code     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
  p_network_operator_name     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_NAME%TYPE,
  p_network_operator_type     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
  p_personal_account          IN  NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
  p_UPRS_Member_Code          IN  NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
  p_country                   IN  network_operator.country%TYPE,
  p_user_id_of_change         IN  NUMBER,  
  p_mcc                       IN  VARCHAR2,
  p_mnc                       IN  VARCHAR2,
  p_time_zone                 IN  NUMBER,
  p_DST_rule_id               IN  NUMBER,    
  p_network_operator_id       OUT NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Insert_Network_Operator_2';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint insert_network_operator_a;
  END IF;

  IF p_network_operator_id_upper IS NOT NULL THEN
    Test_Network_Operator_Deleted(p_network_operator_id_upper);
  END IF;

  select s_network_operator.nextval into p_network_operator_id from DUAL;
  BEGIN
    insert into NETWORK_OPERATOR
      (NETWORK_OPERATOR_ID,
       NETWORK_OPERATOR_CODE,
       NETWORK_OPERATOR_NAME,
       NETWORK_OPERATOR_TYPE,
       NETWORK_OPERATOR_ID_UPPER,
       PERSONAL_ACCOUNT,
       UPRS_MEMBER_CODE,
       DELETED,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE,
       country,
       mcc,
       mnc,
       time_zone,
       dst_rule_id)
    values
      (p_network_operator_id,
       p_network_operator_code,
       p_network_operator_name,
       p_network_operator_type,
       p_network_operator_id_upper,
       p_personal_account,
       p_UPRS_Member_Code,
       null,
       sysdate,
       p_user_id_of_change,
       p_country,
       p_mcc,
       p_mnc,
       p_time_zone,
       p_DST_rule_id);

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_NETWORK_OPERATOR_CODE then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_CODE, '');
      else
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_NAME, '');
      end if;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint insert_network_operator_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Insert_Network_Operator_2;

---------------------------------------------
--     PROCEDURE Update_Network_Operator_2
---------------------------------------------

PROCEDURE Update_Network_Operator_2
(
  handle_tran                 IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                  OUT NUMBER,
  p_network_operator_id       IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_network_operator_id_upper IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
  p_network_operator_code     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_CODE%TYPE,
  p_network_operator_name     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_NAME%TYPE,
  p_network_operator_type     IN  NETWORK_OPERATOR.NETWORK_OPERATOR_TYPE%TYPE,
  p_personal_account          IN  NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
  p_UPRS_Member_Code          IN  NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
  p_country                   IN  network_operator.country%TYPE,
  p_user_id_of_change         IN  NUMBER,
  p_mcc                       IN  VARCHAR2,
  p_mnc                       IN  VARCHAR2,
  p_time_zone                 IN  NUMBER,
  p_DST_rule_id               IN  NUMBER  
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Update_Network_Operator_2';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint update_network_operator_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_network_operator_id);
  IF p_network_operator_id_upper IS NOT NULL THEN
    Test_Network_Operator_Deleted(p_network_operator_id_upper);
  END IF;

  BEGIN
    update NETWORK_OPERATOR
       set NETWORK_OPERATOR_CODE     = p_network_operator_code,
           NETWORK_OPERATOR_NAME     = p_network_operator_name,
           NETWORK_OPERATOR_TYPE     = p_network_operator_type,
           NETWORK_OPERATOR_ID_UPPER = p_network_operator_id_upper,
           PERSONAL_ACCOUNT          = p_personal_account,
           UPRS_MEMBER_CODE          = p_UPRS_Member_Code,
           DATE_OF_CHANGE            = sysdate,
           USER_ID_OF_CHANGE         = p_user_id_of_change,
           country                   = p_country,
           mcc                       = p_mcc,
           mnc                       = p_mnc,
           time_zone                 = p_time_zone,
           dst_rule_id               = p_dst_rule_id
     where NETWORK_OPERATOR_ID = p_network_operator_id;

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_NETWORK_OPERATOR_CODE then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_CODE, '');
      else
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_NAME, '');
      end if;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint update_network_operator_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Update_Network_Operator_2;

PROCEDURE Update_Network_Operator_par
(
  handle_tran                 IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                  OUT NUMBER,
  p_network_operator_id       IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_network_operator_id_upper IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
  p_personal_account          IN  NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
  p_UPRS_Member_Code          IN  NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
  p_country                   IN  network_operator.country%TYPE,
  p_user_id_of_change         IN  NUMBER,
  p_mcc                       IN  VARCHAR2,
  p_mnc                       IN  VARCHAR2,
  p_time_zone                 IN  NUMBER,
  p_DST_rule_id               IN  NUMBER  
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Update_Network_Operator_par';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint update_network_operator_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_network_operator_id);
  IF p_network_operator_id_upper IS NOT NULL THEN
    Test_Network_Operator_Deleted(p_network_operator_id_upper);
  END IF;

  BEGIN
    update NETWORK_OPERATOR
       set NETWORK_OPERATOR_ID_UPPER = p_network_operator_id_upper,
           PERSONAL_ACCOUNT          = p_personal_account,
           UPRS_MEMBER_CODE          = p_UPRS_Member_Code,
           DATE_OF_CHANGE            = sysdate,
           USER_ID_OF_CHANGE         = p_user_id_of_change,
           country                   = p_country,
           mcc                       = p_mcc,
           mnc                       = p_mnc,
           time_zone                 = p_time_zone,
           dst_rule_id               = p_dst_rule_id
     where NETWORK_OPERATOR_ID = p_network_operator_id;

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_NETWORK_OPERATOR_CODE then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_CODE, '');
      else
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_NAME, '');
      end if;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint update_network_operator_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Update_Network_Operator_par;

---------------------------------------------
--     PROCEDURE Update_Network_Operator_par_1
---------------------------------------------

PROCEDURE Update_Network_Operator_par_1
(
  handle_tran                 IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code                  OUT NUMBER,
  p_network_operator_id       IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_network_operator_id_upper IN  NETWORK_OPERATOR.NETWORK_OPERATOR_ID_UPPER%TYPE,
  p_personal_account          IN  NETWORK_OPERATOR.PERSONAL_ACCOUNT%TYPE,
  p_UPRS_Member_Code          IN  NETWORK_OPERATOR.UPRS_MEMBER_CODE%TYPE,
  p_country                   IN  network_operator.country%TYPE,
  p_user_id_of_change         IN NUMBER,
  p_mcc                       IN   VARCHAR2,
  p_mnc                       IN   VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Update_Network_Operator_par_1';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint update_network_operator_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_network_operator_id);
  IF p_network_operator_id_upper IS NOT NULL THEN
    Test_Network_Operator_Deleted(p_network_operator_id_upper);
  END IF;

  BEGIN
    update NETWORK_OPERATOR
       set NETWORK_OPERATOR_ID_UPPER = p_network_operator_id_upper,
           PERSONAL_ACCOUNT          = p_personal_account,
           UPRS_MEMBER_CODE          = p_UPRS_Member_Code,
           DATE_OF_CHANGE            = sysdate,
           USER_ID_OF_CHANGE         = p_user_id_of_change,
           country                   = p_country,
           mcc                       = p_mcc,
           mnc                       = p_mnc
     where NETWORK_OPERATOR_ID = p_network_operator_id;

  EXCEPTION
    when DUP_VAL_ON_INDEX then
      if rsig_utils.GET_CONSTRAINT_NAME(SQLERRM) = rsig_utils.c_UK_NETWORK_OPERATOR_CODE then
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_CODE, '');
      else
        raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_NET_OPER_NAME, '');
      end if;
  END;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint update_network_operator_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
      END CASE;
    END;
END Update_Network_Operator_par_1;

---------------------------------------------
--     PROCEDURE Get_Owner_MNP_Code
---------------------------------------------
PROCEDURE Get_Owner_MNP_Code
(
  error_code              OUT NUMBER,
  p_mnp_code              OUT VARCHAR2
) IS
  v_event_source   VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Get_Owner_MNP_Code';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  SELECT /*+ ordered use_nl(n mnp) full(n) index(mnp I_NOMNP_NETOP_NET_OP_ID)*/
         mnp.network_operator_mnp_code
    INTO p_mnp_code
      FROM NETWORK_OPERATOR n
      JOIN NETWORK_OPERATOR_MNP mnp ON n.network_operator_id = mnp.network_operator_id
       WHERE n.network_operator_type IS NULL
         AND network_operator_id_upper IS NULL
         AND n.deleted IS NULL
         AND mnp.network_operator_mnp_code IS NOT NULL;
  
  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
                       
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
      
END Get_Owner_MNP_Code;

---------------------------------------------
--     PROCEDURE Get_Locations_Routing_Numbers
---------------------------------------------

PROCEDURE Get_Locations_Routing_Numbers
(
  error_code              OUT NUMBER,
  p_cur_location_routing_numbers  OUT SYS_REFCURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Get_Locations_Routing_Numbers';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

     OPEN p_cur_location_routing_numbers FOR
      SELECT /*+ ordered driving_site(mnp) use_nl(mnp n lsa lsaz) full(mnp) index(n PK_NETWORK_OPERATOR)*/
             mnp.network_operator_lrn,
             lsa.lsa_code lsa_code,
             lsaz.LSA_ZONE_CODE,
             n.network_operator_id,
             n.network_operator_code,
             mnp.network_rn
        FROM NETWORK_OPERATOR_MNP mnp
        JOIN NETWORK_OPERATOR n ON n.network_operator_id = mnp.network_operator_id
        JOIN LSA lsa ON lsa.LSA_ID = mnp.lsa_id
        JOIN LSA_ZONE lsaz ON lsaz.LSA_ZONE_ID = lsa.LSA_ZONE_ID
       WHERE mnp.deleted is null;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN p_cur_location_routing_numbers FOR
      select error_code from dual;

END Get_Locations_Routing_Numbers;

---------------------------------------------
--     PROCEDURE Get_MNP_Code_For_Net_Op
---------------------------------------------

PROCEDURE Get_MNP_Code_For_Net_Op
(
  p_network_operator_id   IN  NUMBER,
  p_error_code              OUT NUMBER,
  p_cur_network_operator  OUT SYS_REFCURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Get_MNP_Code_For_Net_Op';
BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);
       
    OPEN p_cur_network_operator FOR   
      select /*+ ordered use_nl(t mnp u) index(mnp I_NOMNP_NETOP_NET_OP_ID) index(u PK_USERS)*/
             mnp.id,
             mnp.network_operator_id,
             case 
               when t.root_network_operator_id = t.network_operator_id then 
                 mnp.network_operator_mnp_code 
               else 
                 t.network_operator_mnp_code 
             end network_operator_mnp_code,
             mnp.network_operator_lrn,
             mnp_pkg.get_lsa_code2(mnp.lsa_id, sysdate) network_operator_lsa_code,
             mnp.date_of_change,
             u.user_name,
             mnp.deleted,
             mnp.network_rn
        from (select /*+ ordered use_nl(no rmnp) full(no) index(rmnp I_NOMNP_NETOP_NET_OP_ID)*/
                     no.network_operator_id, 
                     no.network_operator_code,
                     no.network_operator_name,
                     CONNECT_BY_ROOT no.network_operator_id root_network_operator_id,
                     CONNECT_BY_ROOT rmnp.network_operator_mnp_code network_operator_mnp_code,
                     CONNECT_BY_ROOT rmnp.deleted root_deleted
                from network_operator no
                left join network_operator_mnp rmnp on rmnp.network_operator_id = no.network_operator_id and (rmnp.deleted is null or rmnp.deleted > sysdate)
               where no.network_operator_id = p_network_operator_id
                 and (no.deleted is null or no.deleted>sysdate)
               start with no.network_operator_id_upper is null
             connect by no.network_operator_id_upper = prior  no.network_operator_id
               order by root_network_operator_id, no.network_operator_id) t
        join network_operator_mnp mnp on mnp.network_operator_id = t.network_operator_id
        JOIN USERS u ON u.user_id = mnp.user_id_of_change
  ;

  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN p_cur_network_operator FOR
      select p_error_code from dual;
END Get_MNP_Code_For_Net_Op;

---------------------------------------------
--     PROCEDURE Delete_Net_Op_MNP
---------------------------------------------

PROCEDURE Delete_Net_Op_MNP
(
  p_id                    IN  NUMBER,
  p_user_id_of_change     IN  NUMBER,
  p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_error_code            OUT NUMBER,
  p_error_message         OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Delete_Net_Op_MNP';
  v_sysdate      DATE := SYSDATE;
BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);

  IF (p_handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (p_handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint Delete_Net_Op_MNP;
  END IF;

  UPDATE /*+ index(mnp PK_NOMNP_ID)*/
         NETWORK_OPERATOR_MNP mnp
       SET mnp.DELETED = v_sysdate,
           mnp.date_of_change = sysdate,
           mnp.user_id_of_change = p_user_id_of_change
     WHERE mnp.id = p_id
       AND mnp.deleted IS NULL;

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;


  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := RSIG_UTILS.Handle_Error(sqlcode);
    p_error_message := sqlerrm;
    RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE p_handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint Delete_Net_Op_MNP;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
     END CASE;
END Delete_Net_Op_MNP;

---------------------------------------------
--     PROCEDURE Update_Net_Op_MNP
---------------------------------------------

PROCEDURE Update_Net_Op_MNP
(
  p_id                    IN  NUMBER,
  p_network_operator_id   IN  NUMBER,
  p_mnp_code              IN  VARCHAR2,
  p_LRN                   IN  VARCHAR2,
  p_LSA_Code              IN  VARCHAR2,
  p_Network_RN            IN  VARCHAR2,
  p_user_id_of_change     IN  NUMBER,
  p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_error_code            OUT NUMBER,
  p_error_message         OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Update_Net_Op_MNP';
  v_cnt          NUMBER;
BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);

  IF (p_handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (p_handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;
  
  IF (p_network_operator_id IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER , 'p_network_operator_id');
  END IF;
  
  IF (p_LSA_Code IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER , 'p_LSA_Code');
  END IF;
  
  SELECT count(*) INTO v_cnt 
         FROM NETWORK_OPERATOR no
         WHERE no.network_operator_id = p_network_operator_id
           AND no.network_operator_id_upper IS NULL;
         
  IF (v_cnt = 0 AND p_mnp_code IS NOT NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_OTHER_ERROR, 'Not root operator.');
  END IF; 

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint Delete_Net_Op_MNP;
  END IF;

  UPDATE /*+ index(mnp PK_NOMNP_ID)*/
         NETWORK_OPERATOR_MNP mnp
       SET mnp.network_operator_id = p_network_operator_id,
           mnp.network_operator_mnp_code = p_mnp_code,
           mnp.network_operator_lrn = p_lrn,
           mnp.lsa_id = mnp_pkg.get_lsa_id2(p_LSA_Code, sysdate),
           mnp.network_rn = p_Network_RN,
           mnp.date_of_change = sysdate,
           mnp.user_id_of_change = p_user_id_of_change
     WHERE mnp.id = p_id
       AND mnp.deleted IS NULL;

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;


  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := RSIG_UTILS.Handle_Error(sqlcode);
    p_error_message := sqlerrm;
    RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE p_handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint Delete_Net_Op_MNP;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
     END CASE;
END Update_Net_Op_MNP;

---------------------------------------------
--     PROCEDURE Insert_Net_Op_MNP
---------------------------------------------

PROCEDURE Insert_Net_Op_MNP
(
  p_network_operator_id   IN  NUMBER,
  p_mnp_code              IN  VARCHAR2,
  p_LRN                   IN  VARCHAR2,
  p_LSA_Code              IN  VARCHAR2,
  p_Network_RN            IN  VARCHAR2,
  p_user_id_of_change     IN  NUMBER,
  p_handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  p_error_code            OUT NUMBER,
  p_error_message         OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_NETWORK_OPERATOR.Insert_Net_Op_MNP';
  v_new_id       NUMBER;
  v_cnt          NUMBER;
BEGIN
    RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                         RSIG_UTILS.c_DEBUG_LEVEL_1,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                         v_event_source);

  IF (p_handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (p_handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;
  
  IF (p_network_operator_id IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER , 'p_network_operator_id');
  END IF;
  
  IF (p_LSA_Code IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER , 'p_LSA_Code');
  END IF;
  
  SELECT /*+ index(mnp I_NOMNP_NETOP_NET_OP_ID)*/
         count(*) INTO v_cnt 
    FROM NETWORK_OPERATOR_MNP mnp
   WHERE mnp.network_operator_id = p_network_operator_id 
     AND mnp.deleted IS NULL;
         
  IF (v_cnt <> 0) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_OTHER_ERROR, 'Record already exist.');
  END IF; 
  
  SELECT /*+ index(n PK_NETWORK_OPERATOR)*/
         count(*) INTO v_cnt 
    FROM NETWORK_OPERATOR no
   WHERE no.network_operator_id = p_network_operator_id
     AND no.network_operator_id_upper IS NULL;
         
  IF (v_cnt = 0 AND p_mnp_code IS NOT NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_OTHER_ERROR, 'Not root operator.');
  END IF; 

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint Delete_Net_Op_MNP;
  END IF;
  
  v_new_id := S_NOMNP.NEXTVAL;
  SELECT /*+ index(mnp PK_NOMNP_ID)*/
         count(*) INTO v_cnt 
    FROM NETWORK_OPERATOR_MNP mnp
   WHERE mnp.id = v_new_id;
         
  WHILE(v_cnt > 0)
  LOOP  
    v_new_id := S_NOMNP.NEXTVAL;
    SELECT  /*+ index(mnp PK_NOMNP_ID)*/
           count(*) INTO v_cnt 
      FROM NETWORK_OPERATOR_MNP mnp
     WHERE mnp.id = v_new_id;
  END LOOP;

  INSERT INTO NETWORK_OPERATOR_MNP(ID,
                                   NETWORK_OPERATOR_ID,
                                   NETWORK_OPERATOR_MNP_CODE,
                                   NETWORK_OPERATOR_LRN,
                                   LSA_ID,
                                   NETWORK_RN,
                                   DATE_OF_CHANGE,
                                   USER_ID_OF_CHANGE,
                                   DELETED)
       VALUES (v_new_id,
               p_network_operator_id,
               p_mnp_code,
               p_LRN,
               mnp_pkg.get_lsa_id2(p_LSA_Code, sysdate),
               p_Network_RN,
               sysdate,
               p_user_id_of_change,
               NULL);

  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;


  p_error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    p_error_code := RSIG_UTILS.Handle_Error(sqlcode);
    p_error_message := sqlerrm;
    RSIG_UTILS.Debug_Rsi(TO_CHAR(p_error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE p_handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          rollback to savepoint Delete_Net_Op_MNP;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          rollback;
        ELSE
          NULL;
     END CASE;
END Insert_Net_Op_MNP;

END;
/
