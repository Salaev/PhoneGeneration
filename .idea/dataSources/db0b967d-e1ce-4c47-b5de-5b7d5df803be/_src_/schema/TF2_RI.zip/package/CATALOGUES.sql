CREATE PACKAGE "CATALOGUES" IS
/****************************************************************************
<header>
  <name>            package COMMON
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  04.10.2006  -  created
  </version>

  <Description>     Package contains procedures which maintain
                    views from catalogues.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/

/****************************************************************************
<header>
  <name>            procedure Get_AP_Statuses
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  04.10.2006  -  created
  </version>

  <Description>     Procedure returns all sim statuses at which
                    is possible to switch from old status in parameter
                    p_status_code_from. When parameter p_status_code_from is NULL,
                    then initial statuses are returned. When parameter
                    p_status_code_from='%' then all statuses are returned.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_AP_Statuses(
  p_status_code_from       IN  access_point_status_history.access_point_status_code%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);
/****************************************************************************
<header>
  <name>            procedure Get_AP_Prod_Statuses
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  04.10.2006  -  created
  </version>

  <Description>     Procedure returns all sim production statuses at which
                    is possible to switch from old status in parameter
                    p_status_code_from. When parameter p_status_code_from is NULL,
                    then initial statuses are returned. When parameter
                    p_status_code_from='%' then all statuses are returned.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_AP_Prod_Statuses(
  p_status_code_from       IN  ap_prod_status_hist.ap_prod_status_code%TYPE,
  p_is_bp                  IN  varchar2,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure Get_AP_Statuses_Tran_Reasons
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  04.10.2006  -  created
  </version>

  <Description>     Procedure returns all access point statuses with
                    their transition reasons.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_AP_Statuses_Tran_Reasons(
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure Get_Products
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  04.10.2006  -  created
  </version>

  <Description>     Procedure returns all products with supplier code.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_Products(
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure Get_NA_Statuses_Tran_Reasons
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  04.10.2006  -  created
  </version>

  <Description>     Procedure returns all network address statuses with
                    their transition reasons.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
PROCEDURE Get_NA_Statuses_Tran_Reasons(
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2,
  p_result_list            OUT sys_refcursor
);

/****************************************************************************
<header>
  <name>            procedure Get_NA_Statuses_Tran_Reasons
  </name>

  <author>          Petr Cepek
  </author>

  <version>
                    1.0.0  04.10.2006  -  created
  </version>

  <Description>     Procedure returns all network address statuses at which
                    is possible to switch from old status in parameter
                    p_NA_Status_From. When parameter p_NA_Status_From is NULL,
                    then initial statuses are returned.
  </Description>

  <Prerequisites>
  </Prerequisites>

  <Application>	    Resource Inventory
  </Application>

  <Parameters>
  </Parameters>

</header>
******************************************************************************/
  procedure get_na_statuses
  (
    p_na_status_from varchar2,
    p_allow_inernal_status number,
    p_raise_error char default rsig_utils.c_no,
    p_error_code out number,
    p_error_message out varchar2,
    p_result_list out sys_refcursor
  );
END;
/
