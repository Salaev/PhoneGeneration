CREATE PACKAGE BODY RSIG_SIM_SERIES IS

---------------------------------------------
--     FUNCTION Is_Interval_Overlap
---------------------------------------------

FUNCTION Is_Interval_Overlap
(
  p_sim_series_id IN SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_start_date    IN SIM_SERIES_STATUS_VALIDITY.START_DATE%TYPE
) RETURN NUMBER IS

  v_status     NUMBER(1);
  v_start_date DATE;
BEGIN
  v_start_date := nvl(p_start_date, SYSDATE);
  begin
    select RSIG_UTILS.c_FALSE
      into v_status
      from sim_series_status_validity ss
     where ss.SIM_SERIES_ID = p_sim_series_id
       and v_start_date <= END_DATE
       and rownum < 2;
    return RSIG_UTILS.c_FALSE;

  EXCEPTION
    WHEN NO_DATA_FOUND then
      return RSIG_UTILS.c_OK;
  end;
END Is_Interval_Overlap;

---------------------------------------------
--     PROCEDURE Is_Sim_Card_Type_Deleted
---------------------------------------------

PROCEDURE Is_Sim_Card_Type_Deleted(p_sim_card_type_code IN SIM_CARD_TYPE.SIM_CARD_TYPE_CODE%TYPE) IS
  v_pom number;
BEGIN
  select 1
    into v_pom
    from SIM_CARD_TYPE
   where TRIM(SIM_CARD_TYPE_CODE) = TRIM(p_sim_card_type_code)
     and DELETED is not null;
  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    null;
END Is_Sim_Card_Type_Deleted;

---------------------------------------------
--     PROCEDURE Is_Network_Operator_Deleted
---------------------------------------------

PROCEDURE Is_Network_Operator_Deleted(p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE) IS
  v_pom number;
BEGIN
  select 1
    into v_pom
    from NETWORK_OPERATOR
   where NETWORK_OPERATOR_ID = p_network_operator_id
     and DELETED is not null;
  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    null;
END Is_Network_Operator_Deleted;

---------------------------------------------
--     PROCEDURE Is_Host_Deleted
---------------------------------------------

PROCEDURE Is_Host_Deleted(p_host_id IN HOST.HOST_ID%TYPE) IS
  v_pom number;
BEGIN
  select 1
    into v_pom
    from HOST
   where HOST_ID = p_host_id
     and DELETED is not null;
  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_HOST_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    null;
END Is_Host_Deleted;

---------------------------------------------
--     PROCEDURE Test_Row_For_Exist
---------------------------------------------

PROCEDURE Test_Row_For_Exist(p_sim_series_id IN SIM_SERIES.SIM_SERIES_ID%TYPE) IS
  v_deleted SIM_SERIES.DELETED%TYPE;
BEGIN
  select DELETED into v_deleted from SIM_SERIES where SIM_SERIES_ID = p_sim_series_id;

  IF v_deleted IS NOT NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Test_Row_For_Exist;

---------------------------------------------
--     PROCEDURE Is_IMSI_Interval_Overlap
---------------------------------------------

PROCEDURE Is_IMSI_Interval_Overlap
(
  p_sim_series_id      IN SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_start_imsi_number  IN SIM_SERIES.START_IMSI_NUMBER%TYPE,
  p_end_imsi_number    IN SIM_SERIES.END_IMSI_NUMBER%TYPE,
  p_sim_card_type_code IN SIM_SERIES.SIM_CARD_TYPE_CODE%TYPE
) IS
  v_start_imsi_number NUMBER;
  v_end_imsi_number   NUMBER;
BEGIN
  ------------------------------
  util_loc_pkg.touch_varchar(p_sim_card_type_code);
  ------------------------------
  BEGIN
    v_start_imsi_number := TO_NUMBER(p_start_imsi_number);
    v_end_imsi_number   := TO_NUMBER(p_end_imsi_number);
  EXCEPTION
    WHEN VALUE_ERROR THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_IMSI_ERROR, '');
  END;
  FOR v_cur_IMSI_intervals IN (select START_IMSI_NUMBER,
                                      END_IMSI_NUMBER
                                 from SIM_SERIES
                                where (v_start_imsi_number between TO_NUMBER(START_IMSI_NUMBER) and
                                      TO_NUMBER(END_IMSI_NUMBER) or
                                      v_end_imsi_number between TO_NUMBER(START_IMSI_NUMBER) and
                                      TO_NUMBER(END_IMSI_NUMBER)
                                      -- Martin Zabka - 040219
                                      or (v_start_imsi_number < START_IMSI_NUMBER and
                                      v_end_imsi_number > END_IMSI_NUMBER))
                                     -- end Martin Zabka - 040219
                                     --  and SIM_CARD_TYPE_CODE = p_sim_card_type_code
                                  AND (SYSDATE < deleted OR DELETED IS NULL)
                                  and length(p_start_imsi_number) = length(START_IMSI_NUMBER)
                                  and ((p_sim_series_id IS NULL) OR (SIM_SERIES_ID != p_sim_series_id)))
  LOOP
    --JHO 20040217 test if p_series_id is null

    IF v_start_imsi_number > v_end_imsi_number THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_INTERVAL, '');
    ELSE
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INTERVAL_OVERLAP, '');
    END IF;

  END LOOP;
END Is_IMSI_Interval_Overlap;

---------------------------------------------
--     PROCEDURE Is_Split_IMSI_Number_OK
---------------------------------------------

PROCEDURE Is_Split_IMSI_Number_OK
(
  p_sim_series_id_current   IN SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_split_imsi_number       IN SIM_SERIES.START_IMSI_NUMBER%TYPE,
  p_end_imsi_number_current OUT SIM_SERIES.END_IMSI_NUMBER%TYPE
) IS
  v_start_imsi_number NUMBER;
  v_end_imsi_number   NUMBER;
  v_split_imsi_number NUMBER;
BEGIN
  BEGIN
    v_split_imsi_number := TO_NUMBER(p_split_imsi_number);
    select TO_NUMBER(START_IMSI_NUMBER),
           END_IMSI_NUMBER,
           TO_NUMBER(END_IMSI_NUMBER)
      into v_start_imsi_number,
           p_end_imsi_number_current,
           v_end_imsi_number
      from SIM_SERIES
     where SIM_SERIES_ID = p_sim_series_id_current;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
    WHEN VALUE_ERROR THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_IMSI_ERROR, '');
  END;
  IF v_split_imsi_number NOT BETWEEN v_start_imsi_number AND v_end_imsi_number
     OR v_split_imsi_number = v_start_imsi_number
  /*OR v_split_imsi_number = v_end_imsi_number*/
   THEN
    -- JHO 040423 - changed for split serie- cut last number out of the serie.
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_INTERVAL, '');
  END IF;
END Is_Split_IMSI_Number_OK;

------------------------------------------------------------------------------------------------------------------------------
--  Copy_Hosts_To_SIM_Series
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Copy_Hosts_To_SIM_Series(
  p_from_sim_series_id     IN  sim_series.sim_series_id%TYPE,
  p_to_sim_series_id       IN  sim_series.sim_series_id%TYPE,
  p_user_id_of_change      IN  sim_series.user_id_of_change%TYPE,
  p_raise_error             IN  CHAR DEFAULT rsig_utils.c_NO,
  p_error_code             OUT NUMBER,
  p_error_message          OUT VARCHAR2
)
IS
  v_sysdate                date := SYSDATE;
  v_event_source           varchar2(60) :='RSIG_SIM_SERIES.Copy_Hosts_To_SIM_Series';

BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  p_error_code := util_pkg.c_ora_ok;
  p_error_message := util_pkg.c_msg_ok;

  IF (p_from_sim_series_id IS NULL OR p_to_sim_series_id IS NULL OR p_user_id_of_change IS NULL) THEN
    RAISE_APPLICATION_ERROR(util_pkg.c_ora_missing_parameter, util_pkg.c_msg_missing_parameter);
  END IF;

  MERGE INTO sim_series_host ssh
    USING(SELECT /*+ INDEX(ssh1 PK_SIM_SERIES_HOST)*/
                 p_to_sim_series_id AS to_sim_series_id,
                 ssh1.host_type_code,
                 ssh1.host_id
            FROM sim_series_host ssh1
           WHERE ssh1.sim_series_id = p_from_sim_series_id
             AND v_sysdate BETWEEN ssh1.start_date AND NVL(ssh1.end_date, util_pkg.c_plus_infinity)
          )iQ
     ON(ssh.sim_series_id = iQ.to_sim_series_id
        AND ssh.host_id = iQ.host_id
        AND ssh.host_type_code = iQ.host_type_code)
  WHEN NOT MATCHED THEN
     INSERT(sim_series_id,
            host_type_code,
            host_id,
            start_date,
            end_date,
            date_of_change,
            user_id_of_change)
     VALUES(iQ.to_sim_series_id,
            iQ.host_type_code,
            iQ.host_id,
            v_sysdate,
            NULL,
            v_sysdate,
            p_user_id_of_change);


  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
  WHEN OTHERS THEN

    p_error_code := util_pkg.get_err_code;
    p_error_message := util_pkg.get_err_msg;

    IF UPPER(p_raise_error) = rsig_utils.c_yes THEN
      RAISE;
    END IF;

END; --Copy_Hosts_To_SIM_Series

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Insert_Sim_Series
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Insert_Sim_Series(
  p_start_imsi_number     IN  SIM_SERIES.START_IMSI_NUMBER%TYPE,
  p_end_imsi_number       IN  SIM_SERIES.END_IMSI_NUMBER%TYPE,
  p_sim_card_type_code    IN  SIM_SERIES.SIM_CARD_TYPE_CODE%TYPE,
  p_host_id               IN  SIM_SERIES.HOST_ID%TYPE,
  p_subhost_id            IN  SIM_SERIES.SUBHOST_ID%TYPE,
  p_network_operator_id   IN  SIM_SERIES.NETWORK_OPERATOR_ID%TYPE,
  p_prod_status           IN  sim_series_status_validity.status_code%TYPE,
  p_user_id               IN  NUMBER,
  p_handle_tran            IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  p_sim_series_id         OUT SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_error_code            OUT NUMBER,
  p_error_message          OUT VARCHAR2
)
IS
  v_prod_status           sim_series_status_validity.status_code%TYPE;
  v_sysdate               DATE := SYSDATE;
  --
  v_locker locker_pkg.t_locker;
  --
BEGIN
  -- check input parameters
  IF p_start_imsi_number IS NULL OR p_end_imsi_number IS NULL OR p_sim_card_type_code IS NULL OR
     p_network_operator_id IS NULL OR p_user_id IS NULL
  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF to_number(p_start_imsi_number) > to_number(p_end_imsi_number) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_START_AND_END_REVERSE, '');
  END IF;

  ------------------------------
  v_locker := locker_pkg.xl_latch_range2
  (
    p_type_id => c_locker_type_sim_ser_range,
    p_sn_from => p_start_imsi_number,
    p_sn_to => p_end_imsi_number
  );
  ------------------------------

  Is_Sim_Card_Type_Deleted(p_sim_card_type_code);

  Is_Network_Operator_Deleted(p_network_operator_id);

  IF p_host_id IS NOT NULL THEN
    Is_Host_Deleted(p_host_id);
  END IF;

  IF p_subhost_id IS NOT NULL THEN
    Is_Host_Deleted(p_subhost_id);
  END IF;

  Is_IMSI_Interval_Overlap(null, p_start_imsi_number, p_end_imsi_number, p_sim_card_type_code);

  insert into SIM_SERIES
    (SIM_SERIES_ID,
     START_IMSI_NUMBER,
     END_IMSI_NUMBER,
     DATE_OF_CHANGE,
     USER_ID_OF_CHANGE,
     SIM_CARD_TYPE_CODE,
     HOST_ID,
     SUBHOST_ID,
     NETWORK_OPERATOR_ID)
  values
    (S_SIM_SERIES.NEXTVAL,
     p_start_imsi_number,
     p_end_imsi_number,
     v_sysdate,
     p_user_id,
     p_sim_card_type_code,
     p_host_id,
     p_subhost_id,
     p_network_operator_id)
  RETURNING sim_series_id INTO p_sim_series_id;

  v_prod_status:=nvl(p_prod_status,RSIG_UTILS.c_IN_PRODC_SIM_S_STAT_CODE);

  RSIG_SIM_SE_STAT_VALIDITY.Insert_Interval(p_status_code => v_prod_status,
                                            p_sim_series_id =>p_sim_series_id,
                                            p_start_date => NULL,
                                            p_IS_BP => rsig_utils.c_no,
                                            p_user_id =>p_user_id,
                                            p_handle_tran =>rsig_utils.c_HANDLE_TRAN_N,
                                            p_raise_error =>rsig_utils.c_YES,
                                            p_error_code =>p_error_code,
                                            p_error_message =>p_error_message);


  ------------------------------
  IF (p_handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  locker_pkg.Release_Locker(v_locker.locker_id);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  locker_pkg.release_locker(v_locker.locker_id);
  ------------------------------
  if upper(p_raise_error)=rsig_utils.c_yes
  then
    util_pkg.reraise_exception;
  end if;
  ------------------------------
END;

---------------------------------------------
--     PROCEDURE Update_Sim_Series
---------------------------------------------

PROCEDURE Update_Sim_Series
(
  handle_tran           IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  ERROR_CODE            OUT NUMBER,
  p_sim_series_id       IN SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_start_imsi_number   IN SIM_SERIES.START_IMSI_NUMBER%TYPE,
  p_end_imsi_number     IN SIM_SERIES.END_IMSI_NUMBER%TYPE,
  p_user_id_of_change   IN SIM_SERIES.USER_ID_OF_CHANGE%TYPE,
  p_sim_card_type_code  IN SIM_SERIES.SIM_CARD_TYPE_CODE%TYPE,
  p_host_id             IN SIM_SERIES.HOST_ID%TYPE,
  p_subhost_id          IN SIM_SERIES.SUBHOST_ID%TYPE,
  p_network_operator_id IN SIM_SERIES.NETWORK_OPERATOR_ID%TYPE
) IS
  v_event_source     VARCHAR2(60) := 'RSIG_SIM_SERIES.Update_Sim_Series';
  v_sysdate          DATE;
  v_old_host_id      NUMBER;
  v_connection_exist NUMBER;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT update_sim_series_a;
  END IF;

  Test_Row_For_Exist(p_sim_series_id);
  Is_Sim_Card_Type_Deleted(p_sim_card_type_code);
  Is_Network_Operator_Deleted(p_network_operator_id);

  IF p_host_id IS NOT NULL THEN
    Is_Host_Deleted(p_host_id);
  END IF;
  IF p_subhost_id IS NOT NULL THEN
    Is_Host_Deleted(p_subhost_id);
  END IF;
  Is_IMSI_Interval_Overlap(p_sim_series_id, p_start_imsi_number, p_end_imsi_number, p_sim_card_type_code);

  SELECT host_id INTO v_old_host_id FROM SIM_SERIES ss WHERE ss.SIM_SERIES_ID = p_sim_series_id;

  v_sysdate := SYSDATE;
  IF nvl(v_old_host_id, -1) <> nvl(p_host_id, -1) THEN
    BEGIN
      SELECT 1
        INTO v_connection_exist
        FROM dual
       WHERE EXISTS (SELECT /*+ driving_site(sc) ordered use_nl(sc, naap) index_asc(sc, I_SIMCARD_SIM_SERIES_ID) index_asc(naap, I_NETADDRACCPO_ACCESS_POINT_ID)*/ 1
                FROM SIM_CARD sc
                JOIN NETWORK_ADDRESS_ACCESS_POINT naap ON naap.ACCESS_POINT_ID = sc.ACCESS_POINT_ID
               WHERE v_sysdate BETWEEN naap.FROM_DATE AND nvl(naap.TO_DATE, v_sysdate)
                 AND sc.SIM_SERIES_ID = p_sim_series_id);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_connection_exist := 0;
    END;

    IF v_connection_exist = 1 THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_PHONE_IN_SIM_SERIE_USE,
                              'There is exist active connection between AP and NA!');
    END IF;
  END IF;

  UPDATE SIM_SERIES /*+ index(PK_SIM_SERIES)*/
     SET START_IMSI_NUMBER   = p_start_imsi_number,
         END_IMSI_NUMBER     = p_end_imsi_number,
         DATE_OF_CHANGE      = v_sysdate,
         USER_ID_OF_CHANGE   = p_user_id_of_change,
         SIM_CARD_TYPE_CODE  = p_sim_card_type_code,
         HOST_ID             = p_host_id,
         SUBHOST_ID          = p_subhost_id,
         NETWORK_OPERATOR_ID = p_network_operator_id
   WHERE sim_series_id = p_sim_series_id;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT update_sim_series_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
END Update_Sim_Series;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure split_sim_series
(
  handle_tran char default rsig_utils.c_handle_tran_y, --!_! ignore always Y
  p_error_code out number,
  p_error_message out varchar2,
  p_sim_series_id_current number,
  p_sim_series_id out number,
  p_split_imsi_number varchar2,
  p_user_id_of_change number
)
is
begin
  ------------------------------
  util_loc_pkg.touch_varchar(handle_tran);
  ------------------------------
  fastp_sim_series_pkg.split_range2
  (
    p_id => p_sim_series_id_current,
    p_item_split_from => p_split_imsi_number,
    p_user_id => p_user_id_of_change
  );
  ------------------------------
  p_sim_series_id := NULL; --!_!not used in .Net code
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

---------------------------------------------
--     PROCEDURE Split_Sim_Series_For_Synch
---------------------------------------------
PROCEDURE Split_Sim_Series_For_Synch
(
  handle_tran             IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code              OUT NUMBER,
  p_sim_series_id_current IN SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_sim_series_id         OUT SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_split_imsi_number     IN SIM_SERIES.START_IMSI_NUMBER%TYPE,
  p_user_id_of_change     IN SIM_SERIES.USER_ID_OF_CHANGE%TYPE,
  p_optimize              IN CHAR DEFAULT RSIG_UTILS.c_OPTIMIZE_YES
) IS
  v_event_source          VARCHAR2(60) := 'RSIG_SIM_SERIES.Split_Sim_Series_For_Synch';
  v_start_imsi_number_old NUMBER;
  v_end_imsi_number_old   NUMBER;
  v_start_imsi_number_new NUMBER;
  v_end_imsi_number_new   NUMBER;
  v_host_id               host.host_id%TYPE;
  v_error_message         VARCHAR2(4000);
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint Split_Sim_Series_for_synch;
  END IF;

  select to_number(s.start_imsi_number),
         to_number(s.end_imsi_number),
         s.host_id
    into v_start_imsi_number_old,
         v_end_imsi_number_old,
         v_host_id
    from SIM_SERIES s
   where SIM_SERIES_ID = p_sim_series_id_current;

  -- this test is for choose smaller part of old serie to transform it into new one - it implies to smaller update of imported simcards
  IF ((to_number(p_split_imsi_number) - 1) - v_start_imsi_number_old) >
     (v_end_imsi_number_old - to_number(p_split_imsi_number))
     OR p_optimize <> RSIG_UTILS.c_OPTIMIZE_YES -- if is optimization off then new serie is the <split_num, old_end>
   THEN
    --serie <old_start,splitPoint> is bigger
    update SIM_SERIES
       set END_IMSI_NUMBER = lpad(to_char(to_number(p_split_imsi_number) - 1),
                                  length(p_split_imsi_number),
                                  '0')
     where SIM_SERIES_ID = p_sim_series_id_current;

    v_start_imsi_number_new := to_number(p_split_imsi_number);
    v_end_imsi_number_new   := v_end_imsi_number_old;

  ELSE
    --serie <splitPoint,old_end> is bigger
    update SIM_SERIES s
       set s.START_IMSI_NUMBER = p_split_imsi_number
     where SIM_SERIES_ID = p_sim_series_id_current;

    v_start_imsi_number_new := v_start_imsi_number_old;
    v_end_imsi_number_new   := to_number(p_split_imsi_number) - 1;

  END IF;

  select s_sim_series.nextval into p_sim_series_id from dual;

  insert into SIM_SERIES
             (SIM_SERIES_ID,
              START_IMSI_NUMBER,
              END_IMSI_NUMBER,
              DATE_OF_CHANGE,
              USER_ID_OF_CHANGE,
              SIM_CARD_TYPE_CODE,
              HOST_ID,
              NETWORK_OPERATOR_ID)
       select p_sim_series_id,
              lpad(to_char(v_start_imsi_number_new), length(p_split_imsi_number), '0'),
              lpad(to_char(v_end_imsi_number_new), length(p_split_imsi_number), '0'),
              sysdate,
              p_user_id_of_change,
              s.sim_card_type_code,
              s.host_id,
              s.network_operator_id
         from sim_series s
        where s.sim_series_id = p_sim_series_id_current;

  Copy_hosts_to_SIM_series(p_from_sim_series_id => p_sim_series_id_current,
                           p_to_sim_series_id   => p_sim_series_id,
                           p_user_id_of_change  => p_user_id_of_change,
                           p_raise_error        => rsig_utils.c_YES,
                           p_error_code         => error_code,
                           p_error_message      => v_error_message);

  insert into SIM_SERIES_STATUS_VALIDITY
              (STATUS_CODE,
               SIM_SERIES_ID,
               START_DATE,
               END_DATE,
               DATE_OF_CHANGE,
               USER_ID_OF_CHANGE)
        select v.status_code,
               p_sim_series_id,
               v.start_date,
               v.end_date,
               v.date_of_change,
               v.user_id_of_change
          from SIM_SERIES_STATUS_VALIDITY v
         where sim_series_id = p_sim_series_id_current;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint Split_Sim_Series_for_synch;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Split_Sim_Series_For_Synch;

---------------------------------------------
--     PROCEDURE Join_Sim_Series
---------------------------------------------

PROCEDURE Join_Sim_Series
(
  handle_tran         IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT NUMBER,
  p_sim_series_id_1   IN SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_sim_series_id_2   IN SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_user_id_of_change IN SIM_SERIES.USER_ID_OF_CHANGE%TYPE,
  p_deleted           IN SIM_SERIES.DELETED%TYPE
) IS
  v_event_source      VARCHAR2(60) := 'RSIG_SIM_SERIES.Join_Sim_Series';
  start_imsi_number_1 NUMBER;
  end_imsi_number_1   NUMBER;
  start_imsi_number_2 NUMBER;
  end_imsi_number_2   NUMBER;
  v_count             NUMBER;
  v_length            NUMBER;
  v_deleted           DATE;
  v_sysdate           DATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint join_sim_series_a;
  END IF;

  v_deleted := nvl(p_deleted, SYSDATE);
  v_sysdate := SYSDATE;
  Test_Row_For_Exist(p_sim_series_id_1);
  Test_Row_For_Exist(p_sim_series_id_2);

  FOR cur_sim_series_1 IN (select START_IMSI_NUMBER,
                                  END_IMSI_NUMBER,
                                  DELETED,
                                  SIM_CARD_TYPE_CODE,
                                  HOST_ID,
                                  NETWORK_OPERATOR_ID
                             from SIM_SERIES
                            where SIM_SERIES_ID = p_sim_series_id_1)
  LOOP
    FOR cur_sim_series_2 IN (select START_IMSI_NUMBER,
                                    END_IMSI_NUMBER,
                                    DELETED,
                                    SIM_CARD_TYPE_CODE,
                                    HOST_ID,
                                    NETWORK_OPERATOR_ID
                               from SIM_SERIES
                              where SIM_SERIES_ID = p_sim_series_id_2)
    LOOP
      IF cur_sim_series_1.HOST_ID != cur_sim_series_2.HOST_ID
         OR cur_sim_series_1.NETWORK_OPERATOR_ID != cur_sim_series_2.NETWORK_OPERATOR_ID
         OR TRIM(cur_sim_series_1.SIM_CARD_TYPE_CODE) != TRIM(cur_sim_series_2.SIM_CARD_TYPE_CODE) THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DIFFERENCE_VALUES, '');
      END IF;
      BEGIN
        start_imsi_number_1 := TO_NUMBER(cur_sim_series_1.START_IMSI_NUMBER);
        end_imsi_number_1   := TO_NUMBER(cur_sim_series_1.END_IMSI_NUMBER);
        start_imsi_number_2 := TO_NUMBER(cur_sim_series_2.START_IMSI_NUMBER);
        end_imsi_number_2   := TO_NUMBER(cur_sim_series_2.END_IMSI_NUMBER);
        v_length            := length(cur_sim_series_1.START_IMSI_NUMBER);
      EXCEPTION
        WHEN VALUE_ERROR THEN
          RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_IMSI_ERROR, '');
      END;
      IF (end_imsi_number_1 + 1) != start_imsi_number_2
         AND (end_imsi_number_2 + 1) != start_imsi_number_1 THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_IMSI_ERROR, '');
      END IF;
    END LOOP;
  END LOOP;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_BEFORE_LOOP,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  -- check if both series have the same history
  select count(*)
    into v_count
    from (select STATUS_CODE,
                 START_DATE,
                 END_DATE,
                 count(*)
            from SIM_SERIES_STATUS_VALIDITY sssv
           where sssv.SIM_SERIES_ID in (p_sim_series_id_1, p_sim_series_id_2)
           group by STATUS_CODE,
                    START_DATE,
                    END_DATE
          having count(*) <> 2);

  IF v_count <> 0 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DIFFERENCE_HISTORY, '');
  END IF;

  /*FOR cur_sim_se_stat_validity_1 IN (
    select STATUS_CODE,
           START_DATE,
           END_DATE
      from SIM_SERIES_STATUS_VALIDITY
      where SIM_SERIES_ID = p_sim_series_id_1) LOOP
      RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_IN_LOOP, RSIG_UTILS.c_DEBUG_LEVEL_3, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);
    sim_se_stat_validity_found := FALSE;
    RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_BEFORE_LOOP, RSIG_UTILS.c_DEBUG_LEVEL_2, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);
    FOR cur_sim_se_stat_validity_2 IN (
      select STATUS_CODE,
             START_DATE,
             END_DATE
        from SIM_SERIES_STATUS_VALIDITY
        where SIM_SERIES_ID = p_sim_series_id_2
          and START_DATE = cur_sim_se_stat_validity_1.START_DATE
          and END_DATE = cur_sim_se_stat_validity_1.END_DATE) LOOP
      RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_IN_LOOP, RSIG_UTILS.c_DEBUG_LEVEL_3, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);
      sim_se_stat_validity_found := TRUE;
    END LOOP;
    RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_AFTER_LOOP, RSIG_UTILS.c_DEBUG_LEVEL_2, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, v_event_source);
    IF NOT sim_se_stat_validity_found THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DIFFERENCE_HISTORY, '');
    END IF;
  END LOOP;*/

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_AFTER_LOOP,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  IF start_imsi_number_1 < start_imsi_number_2 THEN
    end_imsi_number_1 := end_imsi_number_2;
  ELSE
    start_imsi_number_1 := start_imsi_number_2;
  END IF;
  FOR cur_sim_series_1 IN (select SIM_CARD_TYPE_CODE,
                                  HOST_ID,
                                  NETWORK_OPERATOR_ID
                             from SIM_SERIES
                            where SIM_SERIES_ID = p_sim_series_id_1)
  LOOP
    update SIM_SERIES
       set START_IMSI_NUMBER   = lpad(start_imsi_number_1, v_length, '0'),
           END_IMSI_NUMBER     = lpad(end_imsi_number_1, v_length, '0'),
           DATE_OF_CHANGE      = v_sysdate,
           USER_ID_OF_CHANGE   = p_user_id_of_change,
           SIM_CARD_TYPE_CODE  = cur_sim_series_1.SIM_CARD_TYPE_CODE,
           HOST_ID             = cur_sim_series_1.HOST_ID,
           NETWORK_OPERATOR_ID = cur_sim_series_1.NETWORK_OPERATOR_ID
     where sim_series_id = p_sim_series_id_1;
  END LOOP;

  -- jho 040510
  UPDATE /*+ index(s I_SIMCARD_SIM_SERIES_ID)*/SIM_CARD s SET s.sim_series_id = p_sim_series_id_1 WHERE s.sim_series_id = p_sim_series_id_2;

  UPDATE /*+ index(s I_SIM_IMSI_SIM_SERIES_ID_IMSI)*/SIM_IMSI s SET s.sim_series_id = p_sim_series_id_1 WHERE s.sim_series_id = p_sim_series_id_2;

  -- jho
  update SIM_SERIES ss
     set SS.DELETED = v_deleted,
         SS.USER_ID_OF_CHANGE = p_user_id_of_change,
         SS.DATE_OF_CHANGE = v_sysdate
   where SIM_SERIES_ID = p_sim_series_id_2;

  IF SQL%NOTFOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
  END IF;

  update /*+ INDEX(ssh I_SSH_SIM_SERIES_ID)*/
         SIM_SERIES_HOST ssh
     set SSH.END_DATE = v_deleted,
         SSH.USER_ID_OF_CHANGE = p_user_id_of_change,
         SSH.DATE_OF_CHANGE = v_sysdate
   where ssh.sim_series_id = p_sim_series_id_2;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint join_sim_series_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Join_Sim_Series;

---------------------------------------------
--     PROCEDURE Get_Status_History
---------------------------------------------

PROCEDURE Get_Status_History
(
  error_code           OUT NUMBER,
  p_sim_series_id      IN SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_cur_status_history IN OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_SIM_SERIES.Get_Status_History';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF p_sim_series_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_BEFORE_SELECT,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_status_history FOR
    select aps.ap_prod_status_code,
           aps.ap_prod_status_name,
           sssv.START_DATE,
           sssv.END_DATE,
           sssv.DATE_OF_CHANGE
      from ap_prod_status aps
      join SIM_SERIES_STATUS_VALIDITY sssv on aps.ap_prod_status_code=sssv.STATUS_CODE
     where sssv.SIM_SERIES_ID = p_sim_series_id
     ORDER BY sssv.start_date DESC;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_AFTER_SELECT,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Get_Status_History;

---------------------------------------------
--     PROCEDURE Get_Sim_Cards_Serie_Detail
---------------------------------------------

PROCEDURE Get_Sim_Cards_Serie_Detail
(
  error_code      OUT NUMBER,
  p_sim_series_id IN SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_cur_sim_cards IN OUT RSIG_UTILS.REF_CURSOR -- cursor containing all series of given operator and phone number count for each serie
) IS
  v_event_source VARCHAR2(60) := 'RSIG_SIM_SERIES.Get_Sim_Cards_Serie_Detail';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_sim_cards FOR
    SELECT ss.sim_series_id,
           aps.ap_prod_status_name,
           h.host_name,
           sct.sim_card_type_name,
           (SELECT COUNT(*)
            FROM sim_card sc
            WHERE sc.sim_series_id=p_sim_series_id) AS sim_card_count,
           ss.date_of_change,
           u.user_name,
           ss.sim_card_type_code,
           aps.ap_prod_status_code,
           sh.host_name
      FROM sim_series ss
      JOIN sim_series_status_validity sssv ON ss.sim_series_id = sssv.sim_series_id
      JOIN ap_prod_status aps ON sssv.status_code=aps.ap_prod_status_code
      LEFT JOIN host h ON ss.host_id = h.host_id
      LEFT JOIN host sh ON ss.subhost_id = sh.host_id
      JOIN sim_card_type sct ON TRIM(ss.sim_card_type_code) = TRIM(sct.sim_card_type_code)
      JOIN users u ON ss.user_id_of_change = u.user_id
     WHERE (sysdate BETWEEN sssv.start_date AND nvl(sssv.end_date, sysdate))
       AND ss.sim_series_id = p_sim_series_id;

  error_code := RSIG_UTILS.c_OK;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(to_number(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Get_Sim_Cards_Serie_Detail;


---------------------------------------------
--     PROCEDURE Delete_Sim_Serie
---------------------------------------------

PROCEDURE Delete_Sim_Serie
(
  handle_tran         CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT NUMBER,
  p_sim_series_id     IN SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_deleted           IN SIM_SERIES.DELETED%TYPE,
  p_user_id_of_change IN SIM_SERIES.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source      VARCHAR2(60) := 'RSIG_SIM_SERIES.Delete_Sim_Serie';
  v_deleted           DATE;
  v_active_phone      INT :=0;
  --v_num_sim           INT :=0;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint delete_sim_serie;
  END IF;

  v_deleted := nvl(p_deleted, SYSDATE);

  Test_Row_For_Exist(p_sim_series_id);


  -- check for existence sim card linked with phone number
  BEGIN
    SELECT 1
    INTO v_active_phone
    FROM dual
    WHERE EXISTS(SELECT /*+ FIRST_ROWS INDEX(NAAP I_NETADDRACCPO_ACCESS_POINT_ID) INDEX (SC I_SIMCARD_SIM_SERIES_ID)*/
                        1
                 FROM sim_card sc
                 JOIN network_address_access_point naap ON naap.access_point_id=sc.access_point_id
                 WHERE sc.sim_series_id=p_sim_series_id
                   AND (naap.to_Date>= SYSDATE OR naap.To_Date IS NULL));
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_active_phone:=0;
  END;

  IF v_active_phone = 1 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_PHONE_IN_SIM_SERIE_USE, '');
  END IF;

  update SIM_SERIES
     set DELETED           = v_deleted,
         DATE_OF_CHANGE    = sysdate,
         USER_ID_OF_CHANGE = p_user_id_of_change
   where SIM_SERIES_ID = p_sim_series_id;

  update /*+ INDEX(ssh I_SSH_SIM_SERIES_ID)*/
         SIM_SERIES_HOST ssh
     set SSH.END_DATE = v_deleted ,
         SSH.USER_ID_OF_CHANGE = p_user_id_of_change,
         SSH.DATE_OF_CHANGE = SYSDATE
   where ssh.sim_series_id = p_sim_series_id;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint delete_sim_serie;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Delete_Sim_Serie;

---------------------------------------------
--     PROCEDURE Update_Sim_Series_Status
---------------------------------------------

PROCEDURE Update_Sim_Series_Status
(
  handle_tran         IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  error_code          OUT NUMBER,
  p_sim_series_id     IN SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_status_code       IN SIM_SERIES_STATUS_VALIDITY.STATUS_CODE%TYPE,
  p_start_date        IN SIM_SERIES_STATUS_VALIDITY.START_DATE%TYPE,
  p_user_id_of_change IN SIM_SERIES.USER_ID_OF_CHANGE%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_SIM_SERIES.Update_Sim_Series_Status';
  v_status_code  SIM_SERIES_STATUS_VALIDITY.STATUS_CODE%TYPE;
  v_start_date   DATE;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N)
     OR handle_tran IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    savepoint Update_Sim_Series_Status_a;
  END IF;

  IF TRIM(p_status_code) = TRIM(rsig_utils.c_PRODUCED) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_NOT_VALID_STATUS, '');
  END IF;

  /*    IF p_start_date IS NULL THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
      END IF;
  */

  v_start_date := nvl(p_start_date, SYSDATE);

  IF v_start_date < RSIG_UTILS.c_MIN_DATE THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_DATE, '');
  END IF;

  -- check interval Overlap. If interval overlap, it will generate exception.
  IF Is_Interval_Overlap(p_sim_series_id, v_start_date) = RSIG_UTILS.c_FALSE THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DATE_OVERLAP, '');
  END IF;

  select ss.STATUS_CODE
    into v_status_code
    from SIM_SERIES_STATUS_VALIDITY ss
   where SIM_SERIES_ID = p_sim_series_id
     and END_DATE is null;

  IF TRIM(v_status_code) = TRIM(rsig_utils.c_PRODUCED) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_STATUS_NOT_CHANGE, '');
  END IF;

  -- If  status validity not change, it will not insert new row
  if TRIM(v_status_code) <> TRIM(p_status_code) THEN
    update SIM_SERIES_STATUS_VALIDITY
       set END_DATE          = v_start_date - RSIG_UTILS.c_INTERVAL_DIFFERENCE,
           DATE_OF_CHANGE    = sysdate,
           USER_ID_OF_CHANGE = p_user_id_of_change
     where SIM_SERIES_ID = p_sim_series_id
       and END_DATE is null;

    insert into SIM_SERIES_STATUS_VALIDITY
      (STATUS_CODE,
       SIM_SERIES_ID,
       START_DATE,
       DATE_OF_CHANGE,
       USER_ID_OF_CHANGE,
       END_DATE)
    VALUES
      (p_status_code,
       p_sim_series_id,
       v_start_date,
       sysdate,
       p_user_id_of_change,
       null);
  end if;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    commit;
  END IF;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        rollback to savepoint Update_Sim_Series_Status_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        rollback;
      ELSE
        NULL;
    END CASE;
END Update_Sim_Series_Status;


----------------------------------------------------------------------------------------------------------------
--     PROCEDURE Get_Sim_Cards
----------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Sim_Cards(
  error_code            OUT NUMBER,
  p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_sim_series_id       IN SIM_SERIES.SIM_SERIES_ID%TYPE,
  p_imsi                IN SIM_CARD.IMSI%TYPE,
  p_in_row_count        IN NUMBER, -- <=     not null
  p_status_filter_l     IN t_code,
  p_trans_reason_l      IN t_code,
  p_prod_status_filtr   IN VARCHAR2,
  p_like                IN VARCHAR2, -- LIKE
  p_IMSI_search         IN CHAR, -- 'Y' => search by IMSI
  p_ICCID_search        IN CHAR, -- 'Y' => search by ICCID
  p_bind_phone_filter   IN NUMBER,
  p_cur_sim_series      OUT RSIG_UTILS.REF_CURSOR,
  p_cur_addit_imsi      OUT RSIG_UTILS.REF_CURSOR
)
IS
  v_event_source         VARCHAR2(60) := 'RSIG_SIM_SERIES.Get_Sim_Cards';
  v_select               VARCHAR2(4000);
  v_sysdate              DATE:=SYSDATE;
  v_status_not_filtered  BOOLEAN;


  v_imsi ct_varchar_s;
  v_sn ct_varchar;
  v_access_point_status_name ct_varchar;
  v_count ct_number;
  v_access_point_id ct_number;
  v_personal_account ct_number;
  v_ap_prod_status_code ct_varchar_s;
  v_ap_prod_status_name ct_varchar;
  v_authent_type ct_varchar_s;

  v_addition_imsi_count number;
  v_imsi_type_code_prefix varchar2(4) := 'IMSI';
  v_def_addition_imsi_count number := 0;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  IF p_in_row_count IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF p_IMSI_search = p_ICCID_search
     AND p_IMSI_search = RSIG_UTILS.c_YES THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'IMSI and ICCID search same');
  END IF;

  v_addition_imsi_count := install_pkg.nnget_option_num(c_opt_disp_addit_imsi_amount, v_def_addition_imsi_count);

  IF p_status_filter_l IS NULL OR
     p_status_filter_l.COUNT = 0 OR
     (p_status_filter_l.COUNT = 1 AND p_status_filter_l(p_status_filter_l.FIRST) IS NULL)
  THEN
    v_status_not_filtered := TRUE;
  ELSE
    v_status_not_filtered := FALSE;
  END IF;

  IF v_status_not_filtered AND
     p_prod_status_filtr IS NULL AND
     p_like IS NULL AND
     p_bind_phone_filter IS NULL
  THEN

    --OPEN p_cur_sim_series FOR
    SELECT *
    bulk collect into v_imsi,
                      v_sn,
                      v_access_point_status_name,
                      v_count,
                      v_access_point_id,
                      v_personal_account,
                      v_ap_prod_status_code,
                      v_ap_prod_status_name,
                      v_authent_type
    FROM(
    SELECT /*+ ORDERED use_nl(k apsh aps psh sssv ps) */
           k.imsi,
           k.sn,
           aps.ACCESS_POINT_STATUS_NAME,
           (SELECT COUNT(*)
            FROM network_address_access_point naap
            WHERE naap.access_point_id=k.access_point_id
              AND SYSDATE BETWEEN naap.from_date AND nvl(naap.to_date,SYSDATE)) COUNT,
            k.access_point_id,
            k.personal_account,
            ps.ap_prod_status_code,
            ps.ap_prod_status_name,
            k.authent_type
    FROM(SELECT /*+ index(sc I_SIMCARD_SIM_SERIES_ID) */
                sc.imsi,
                sc.sn,
                sc.access_point_id,
                sc.sim_series_id,
                sc.personal_account,
                sc.authent_type
         FROM sim_card sc
         WHERE sc.sim_series_id=p_sim_series_id
           AND (p_imsi IS NULL OR sc.imsi>p_imsi)) k
    JOIN access_point_status_history apsh ON apsh.access_point_id=k.access_point_id
         AND v_sysdate BETWEEN apsh.start_date AND nvl(apsh.end_date,v_sysdate)
    JOIN access_point_status aps ON trim(aps.ACCESS_POINT_STATUS_CODE)=trim(apsh.access_point_status_code)
    LEFT JOIN ap_prod_status_hist psh ON psh.access_point_id=k.access_point_id
         AND v_sysdate BETWEEN psh.start_date AND nvl(psh.end_date,v_sysdate)
    left JOIN sim_series_status_validity sssv ON sssv.sim_series_id=k.sim_series_id
          AND v_sysdate BETWEEN sssv.start_date AND nvl(sssv.end_date,v_sysdate)
    left JOIN ap_prod_status ps ON (ps.ap_prod_status_code=psh.ap_prod_status_code and
                                psh.ap_prod_status_code is not null) OR
                               (ps.ap_prod_status_code=sssv.status_code and
                                psh.ap_prod_status_code is null)
    ORDER BY k.imsi)
    WHERE rownum<=p_in_row_count;

  ELSE                              -- for advance filtr
    IF p_status_filter_l IS NOT NULL AND
       p_status_filter_l.COUNT > 0 AND
       p_status_filter_l(p_status_filter_l.FIRST) IS NOT NULL
    THEN
      IF p_trans_reason_l IS NULL OR
         p_trans_reason_l.COUNT = 0 OR
         (p_trans_reason_l.COUNT = 1 AND p_trans_reason_l(p_trans_reason_l.FIRST) IS NULL)
      THEN
          RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
      END IF;
      IF p_status_filter_l.COUNT <> p_trans_reason_l.COUNT
      THEN
          RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, '');
      END IF;
    END IF;

    v_select:='select * from (';
    v_select:=v_select || 'SELECT /*+ ORDERED use_nl(k apsh aps psh sssv ps) */ ' ||
           'k.imsi, ' ||
           'k.sn, ' ||
           'aps.ACCESS_POINT_STATUS_NAME, ' ||
           '(SELECT COUNT(*) ' ||
           'FROM network_address_access_point naap ' ||
           'WHERE naap.access_point_id=k.access_point_id ' ||
           '   AND SYSDATE BETWEEN naap.from_date AND nvl(naap.to_date,SYSDATE)) COUNT, ' ||
           ' k.access_point_id, ' ||
           ' k.personal_account, ' ||
           ' ps.ap_prod_status_code, ' ||
           ' ps.ap_prod_status_name, ' ||
           ' k.authent_type ' ||
    ' FROM(SELECT /*+ index(sc I_SIMCARD_SIM_SERIES_ID) */ ' ||
               ' sc.imsi, ' ||
               ' sc.sn, ' ||
               ' sc.access_point_id, ' ||
               ' sc.sim_series_id, ' ||
               ' sc.personal_account, ' ||
               ' sc.authent_type ' ||
        ' FROM sim_card sc ';
    IF p_sim_series_id IS NULL THEN
      v_select := v_select || ' join sim_series ss on ss.sim_series_id=sc.sim_series_id ';
    END IF;

    v_select:= v_select || ' WHERE 1=1 ';

    -- next page of sim cards
    IF p_imsi IS NOT NULL THEN
      v_select:= v_select || ' AND sc.imsi>' || p_imsi || ' ';
    END IF;

    -- condition for sim series
    IF p_sim_series_id IS NULL THEN -- picking from all series for current network operator
      v_select := v_select || ' and ss.network_operator_id=' || p_network_operator_id || ' ';
    ELSE -- picking only from current sim serie
      v_select := v_select || ' and sc.sim_series_id=' || p_sim_series_id || ' ';
    END IF;

    -- condition for sim search
    IF p_like IS NOT NULL THEN
      IF p_IMSI_search = Rsig_Utils.c_YES THEN -- picking according to IMSI
        v_select := v_select || ' and sc.imsi like ''' || p_like || ''' ';
      ELSIF p_ICCID_search = Rsig_Utils.c_YES THEN -- picking according to ICCID
        v_select := v_select || ' and sc.sn like ''' || p_like || ''' ';
      END IF;
    END IF;

    v_select:= v_select || ' ) k ' ||
    'JOIN access_point_status_history apsh ON apsh.access_point_id=k.access_point_id ' ||
    '    AND SYSDATE BETWEEN apsh.start_date AND nvl(apsh.end_date,SYSDATE) ' ||
    'JOIN access_point_status aps ON trim(aps.ACCESS_POINT_STATUS_CODE)=trim(apsh.access_point_status_code) ' ||
    'left JOIN ap_prod_status_hist psh ON psh.access_point_id=k.access_point_id
          AND sysdate BETWEEN psh.start_date AND nvl(psh.end_date,sysdate) ' ||
    'left JOIN sim_series_status_validity sssv ON sssv.sim_series_id=k.sim_series_id
          AND sysdate BETWEEN sssv.start_date AND nvl(sssv.end_date,sysdate) ' ||
    'left JOIN ap_prod_status ps ON (ps.ap_prod_status_code=psh.ap_prod_status_code and
                                psh.ap_prod_status_code is not null) OR
                               (ps.ap_prod_status_code=sssv.status_code and
                                psh.ap_prod_status_code is null) ' ||
    'WHERE 1=1 ';
    -- condition for access point production status
    IF p_prod_status_filtr IS NOT NULL THEN
      v_select:=v_select || ' AND ps.ap_prod_status_code in (' ||   p_prod_status_filtr || ') ';
    END IF;

    -- condition for access point status
    IF p_status_filter_l IS NOT NULL AND
       p_status_filter_l.COUNT > 0 AND
       p_status_filter_l(p_status_filter_l.FIRST) IS NOT NULL
    THEN
      v_select:=v_select || ' AND( ';

      FOR i IN p_status_filter_l.FIRST .. p_status_filter_l.LAST LOOP
        IF p_status_filter_l.FIRST=i THEN
          v_select:=v_select || ' (';
        ELSE
          v_select:=v_select || ' OR (';
        END IF;

        v_select := v_select || ' apsh.access_point_status_code=''' || p_status_filter_l(i) || '''';
        IF p_trans_reason_l(i) <> chr(32) THEN
          v_select := v_select || ' and apsh.AP_TRANS_REASON_CODE=''' || p_trans_reason_l(i) || '''';
        END IF;

        v_select:=v_select || ')';
      END LOOP;

      v_select:=v_select || ')';
    END IF;

    -- condition for number of network addresses linked to sim card
    IF p_bind_phone_filter IS NOT NULL THEN
      v_select:=v_select || ' AND (SELECT COUNT(*)
                                   FROM network_address_access_point naap
                                   WHERE naap.access_point_id=k.access_point_id
                                     AND SYSDATE BETWEEN naap.from_date AND nvl(naap.to_date,SYSDATE))=' ||
                             to_char(p_bind_phone_filter);
    END IF;

    v_select:=v_select || ' ORDER BY imsi) where rownum<=' || p_in_row_count;

    --DBMS_OUTPUT.PUT_LINE(v_select);

    --OPEN p_cur_sim_series FOR v_select;
    execute immediate v_select
    bulk collect into v_imsi,
                      v_sn,
                      v_access_point_status_name,
                      v_count,
                      v_access_point_id,
                      v_personal_account,
                      v_ap_prod_status_code,
                      v_ap_prod_status_name,
                      v_authent_type;
  END IF;

  open p_cur_sim_series for
    select /*+ ordered use_hash(ap s apn cn i pa psc psn at) full(ap) full(s) full(apn) full(cn) full(i) full(pa) full(psc) full(psn) full(at)*/
       i.imsi,
       s.sn,
       apn.access_point_status_name,
       cn.count,
       ap.access_point_id,
       pa.personal_account,
       psc.ap_prod_status_code,
       psn.ap_prod_status_name,
       at.authent_type
      from (select column_value access_point_id, rownum rn from table(cast(v_access_point_id as ct_number))) ap
      join (select column_value sn, rownum rn from table(cast(v_sn as ct_varchar))) s on s.rn = ap.rn
      join (select column_value access_point_status_name, rownum rn from table(cast(v_access_point_status_name as ct_varchar))) apn on apn.rn = ap.rn
      join (select column_value count, rownum rn from table(cast(v_count as ct_number))) cn on cn.rn = ap.rn
      join (select column_value imsi, rownum rn from table(cast(v_imsi as ct_varchar_s))) i on i.rn = ap.rn
      join (select column_value personal_account, rownum rn from table(cast(v_personal_account as ct_number))) pa on pa.rn = ap.rn
      join (select column_value ap_prod_status_code, rownum rn from table(cast(v_ap_prod_status_code as ct_varchar_s))) psc on psc.rn = ap.rn
      join (select column_value ap_prod_status_name, rownum rn from table(cast(v_ap_prod_status_name as ct_varchar))) psn on psn.rn = ap.rn
      join (select column_value authent_type, rownum rn from table(cast(v_authent_type as ct_varchar_s))) at on at.rn = ap.rn
    ;

  --v_addition_imsi_count
  open p_cur_addit_imsi  for
    select access_point_id,
           imsi,
           imsi_type_code
      from (select /*+ ordered use_hash(ap i) use_nl(ap si) full(ap) full(i) index(si I_SIM_IMSI_ACCESS_POINT_IMSI)*/
                ap.access_point_id,
                si.imsi,
                si.imsi_type_code,
                row_number() over(partition by ap.access_point_id order by to_number(substr(si.imsi_type_code, length(v_imsi_type_code_prefix) + 1))) rn
              from (select column_value access_point_id, rownum rn from table(cast(v_access_point_id as ct_number))) ap
              join (select column_value imsi, rownum rn from table(cast(v_imsi as ct_varchar_s))) i on i.rn = ap.rn
              join sim_imsi si on si.access_point_id = ap.access_point_id and si.imsi <> i.imsi
              )
     where rn <= v_addition_imsi_count
     order by access_point_id, rn
      ;

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Get_Sim_Cards;

---------------------------------------------
--     PROCEDURE Get_Sim_Series_For_Cache
---------------------------------------------

PROCEDURE Get_Sim_Series_For_Cache
(
  p_sim_card_type_code IN SIM_SERIES.SIM_CARD_TYPE_CODE%TYPE,
  p_raise_error        IN CHAR,
  ERROR_CODE           OUT NUMBER,
  error_message        OUT VARCHAR2,
  result_list          OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_SIM_SERIES.Get_Sim_Series_For_Cache';
  v_sqlcode      NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  OPEN result_list FOR
    SELECT ss.SIM_SERIES_ID,
           ss.START_IMSI_NUMBER,
           ss.END_IMSI_NUMBER,
           ss.NETWORK_OPERATOR_ID,
           no.NETWORK_OPERATOR_CODE,
           no.NETWORK_OPERATOR_NAME,
           (SELECT NO1.NETWORK_OPERATOR_ID
              FROM NETWORK_OPERATOR NO1
             WHERE NO1.NETWORK_OPERATOR_ID_UPPER IS NULL
             START WITH NO1.NETWORK_OPERATOR_ID = ss.NETWORK_OPERATOR_ID
            CONNECT BY PRIOR NO1.NETWORK_OPERATOR_ID_UPPER = NO1.NETWORK_OPERATOR_ID) TOP_PARENT_OP_ID,
           ss.HOST_ID,
           h.HOST_CODE,
           h.TIME_ZONE
      FROM SIM_SERIES ss
      JOIN NETWORK_OPERATOR no ON ss.NETWORK_OPERATOR_ID = no.NETWORK_OPERATOR_ID
      JOIN HOST h ON h.HOST_ID = ss.HOST_ID
     WHERE (ss.DELETED IS NULL OR ss.DELETED > SYSDATE)
       AND (TRIM(ss.SIM_CARD_TYPE_CODE) = TRIM(p_sim_card_type_code) OR p_sim_card_type_code IS NULL)
     ORDER BY ss.START_IMSI_NUMBER;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_Sim_Series_For_Cache;

---------------------------------------------
--     PROCEDURE Get_Filtered_SIM_Series
---------------------------------------------

PROCEDURE Get_Filtered_SIM_Series(p_raise_error IN CHAR, --Y - procedure ends with error in matter of failure (error code and error message will not be set)
                                  --N - procedure ends successfully in matter of failure (error code and error message is set)
                                  p_network_operator_id IN SIM_SERIES.NETWORK_OPERATOR_ID%TYPE,
                                  p_show_deleted        IN CHAR, --Y - deleted SIM series will be returned,N - deleted SIM series will not be returned
                                  p_host_id             IN VARCHAR2, --Identification of the host Number - concrete host id Null - SIM series having HOST_ID null % - HOST_ID not considered
                                  p_sim_card_type       IN SIM_CARD_TYPE.SIM_CARD_TYPE_CODE%TYPE,
                                  error_code            OUT NUMBER,
                                  p_error_message       OUT VARCHAR2,
                                  p_cur_sim_series      OUT RSIG_UTILS.REF_CURSOR) IS
  v_event_source VARCHAR2(60) := 'RSIG_SIM_SERIES.Get_Filtered_SIM_Series';
  --v_sql_string   VARCHAR2(600);
  v_host_id        host.host_id%TYPE;
  --v_use_host_id    INT;
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_BEFORE_SELECT,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF ((upper(p_raise_error) NOT IN ('Y', 'N')) OR (p_raise_error IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF ((upper(p_show_deleted) NOT IN ('Y', 'N')) OR (p_show_deleted IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, '');
  END IF;

  IF p_host_id = '%' THEN
    v_host_id:=NULL;
  ELSE
    v_host_id:=to_number(p_host_id);
  END IF;

  -- create sql string for open cursor

  OPEN p_cur_sim_series FOR
  SELECT ss.sim_series_id,
         ss.start_imsi_number,
         ss.end_imsi_number,
         ss.date_of_change,
         ss.user_id_of_change,
         ss.sim_card_type_code,
         ss.host_id,
         sssv.status_code,
         sssv.start_date,
         sssv.date_of_change STATUS_DATE_OF_CHANGE,
         sssv.user_id_of_change STATUS_USER_ID_OF_CHANGE,
         ss.deleted,
         ss.subhost_id
  FROM SIM_SERIES ss
  JOIN SIM_SERIES_STATUS_VALIDITY sssv ON sssv.sim_series_id = ss.sim_series_id
  WHERE SYSDATE BETWEEN sssv.start_date AND nvl(sssv.end_date,SYSDATE)
    and ss.network_operator_id = p_network_operator_id
    AND (p_show_deleted='Y' OR ss.deleted IS NULL)
    AND (p_sim_card_type='%' OR TRIM(ss.sim_card_type_code)=TRIM(p_sim_card_type))
    AND (p_host_id='%' OR ss.host_id = v_host_id OR (ss.host_id IS NULL AND v_host_id IS NULL))
  ORDER BY ss.start_imsi_number,ss.end_imsi_number,ss.deleted NULLS LAST;


EXCEPTION
  WHEN OTHERS THEN
    IF p_raise_error = 'N' THEN
      error_code      := RSIG_UTILS.Handle_Error(sqlcode);
      p_error_message := sqlerrm(sqlcode);
      RAISE;
    END IF;
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         'RSIG_SIM_SERIES.Get_Sim_Series_Operator');
END Get_Filtered_SIM_Series;

-----------------------------------------------------------------------------------------------------------------------------------------------------
--  Set_Host_Relation
-----------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Set_Host_Relation(
  p_sim_series_id         IN  sim_series.sim_series_id%TYPE,
  p_host_id               IN  host.host_id%TYPE,
  p_start_date            IN  DATE,
  p_end_date              IN  DATE,
  p_user_id_of_change     IN  NUMBER,
  handle_tran              IN  CHAR DEFAULT rsig_utils.c_HANDLE_TRAN_Y,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code              OUT NUMBER,
  error_message            OUT VARCHAR2
)
IS
  v_sqlcode                number;
  v_event_source          varchar2(60) :='RSIG_SIM_SERIES.Set_Host_Relation';
  v_host_type_code        host.host_type_code%TYPE;
  v_start_date            DATE;
  v_last_host             host.host_id%TYPE;
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE,'Invalid HANDLE_TRAN parameter!');
  END IF;

  IF p_host_id IS NULL OR  p_sim_series_id IS NULL OR p_user_id_of_change IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;


  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Set_Host_Relation_a;
  END IF;

  v_start_date:=nvl(p_start_date,SYSDATE);
-- start of the procedure body ----------------------------------------------------------------------------------------------------------------------
  -- find type of host for host
  BEGIN
    SELECT h.host_type_code
    INTO v_host_type_code
    FROM host h
    WHERE h.host_id=p_host_id
      AND (h.deleted IS NULL OR h.deleted>nvl(p_end_date,h.deleted));

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_HOST_DELETED, 'Host does not exist.');
  END;

  -- delete future intervals
  DELETE FROM sim_series_host ssh
  WHERE ssh.sim_series_id=p_sim_series_id
    AND ssh.host_type_code=v_host_type_code
    AND ssh.start_date>v_start_date;

  -- terminate last interval
  UPDATE sim_series_host ssh
  SET ssh.end_date=v_start_date - RSIG_UTILS.c_INTERVAL_DIFFERENCE,
      ssh.user_id_of_change=p_user_id_of_change,
      ssh.date_of_change=SYSDATE
  WHERE ssh.sim_series_id=p_sim_series_id
    AND ssh.host_type_code=v_host_type_code
    AND (v_start_date<=ssh.end_date OR ssh.end_date IS NULL)
    AND (p_end_date>=ssh.start_date OR p_end_date IS NULL)
  RETURNING ssh.host_id INTO v_last_host;

  IF v_last_host = p_host_id THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_SAME_HOST_SIM_SERIES, 'Same host as previous.');
  END IF;

  INSERT INTO sim_series_host
    (sim_series_id,
     host_type_code,
     host_id,
     start_date,
     end_date,
     date_of_change,
     user_id_of_change)
  VALUES
    (p_sim_series_id,
     v_host_type_code,
     p_host_id,
     v_start_date,
     p_end_date,
     SYSDATE,
     p_user_id_of_change);


-- end of the procedure body ------------------------------------------------------------------------------------------------------------------------

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode := sqlcode;
    error_message := sqlerrm;
--    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint Set_Host_Relation_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
      ELSE NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Set_Host_Relation;

------------------------------------------------------------------------------------------------------------------------------
--  Get_Relation_to_Host
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_Relation_to_Host(
  p_sim_series_id          IN  sim_series.sim_series_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
IS
  v_sqlcode                 number;
  v_event_source           varchar2(60) :='RSIG_SIM_SERIES.Get_Relation_to_Host';
BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
  -- check handle_tran parameter

  IF p_sim_series_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;


-- start of the procedure body --------------------------------------------------------------------------------------------------

  OPEN result_list FOR
  SELECT h.host_name,
         ht.HOST_TYPE_NAME,
         ssh.start_date,
         ssh.end_date,
         u.user_name,
         ssh.date_of_change,
         ssh.host_id
  FROM sim_series_host ssh
  JOIN host h ON h.host_id=ssh.host_id
  JOIN host_type ht ON ht.HOST_TYPE_CODE=ssh.host_type_code
  JOIN users u ON u.user_id=ssh.user_id_of_change
  WHERE ssh.sim_series_id=p_sim_series_id
  ORDER BY ssh.host_type_code,ssh.start_date;


-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode := sqlcode;
    error_message := sqlerrm;
--    DBMS_OUTPUT.PUT_LINE(error_message);
    error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
    OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_Relation_to_Host;

END;
/
