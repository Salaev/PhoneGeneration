CREATE PACKAGE BODY          "PBX" IS
------------------------------------------------------------------------------------------------------------------------------
--  Get_DDI_By_GDN_And_Ext_List
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_DDI_By_GDN_And_Ext_List(
   p_GDN_list            IN  t_PN,
   p_Extension_list      IN  t_port,
   p_date_list           IN  t_vdate,
   p_raise_error         IN  CHAR,
   error_code            OUT NUMBER,
   error_message         OUT VARCHAR2,
   result_list           OUT sys_refcursor
)
IS
	v_sqlcode	             number;
  v_event_source         varchar2(60) :='PBX.Get_DDI_By_GDN_And_Ext_List';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter
  --check p_GDN_list parameter
  IF (p_GDN_list.COUNT = 0) OR (p_GDN_list.COUNT = 1 AND p_GDN_list(p_GDN_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
  --check p_Extension_list parameter
  IF (p_Extension_list.COUNT = 0) OR (p_Extension_list.COUNT = 1 AND p_Extension_list(p_Extension_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;
    --check p_date_list parameter
  IF (p_date_list.COUNT = 0) OR (p_date_list.COUNT = 1 AND p_date_list(p_date_list.FIRST) IS NULL) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_MISSING_PARAMETER, 'Missing some mandatory parameter.');
  END IF;

	IF p_GDN_list.COUNT=0 OR p_GDN_list.COUNT<>p_Extension_list.COUNT OR
     p_Extension_list.COUNT<>p_date_list.COUNT
  THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;

  DELETE FROM tt_batch_na_ap;
-- start of the procedure body --------------------------------------------------------------------------------------------------
  FORALL i IN nvl(p_GDN_list.FIRST, 1) .. nvl(p_GDN_list.LAST, 0)
   INSERT INTO tt_batch_na_ap(international_format,exchange_port,validity_date)
   VALUES(p_GDN_list(i),p_Extension_list(i),nvl(p_date_list(i),SYSDATE));

  -- find DDI
  UPDATE tt_batch_na_ap tt
  SET tt.sn=(SELECT /*+ ordered use_nl(tt pn na naap aph h e ep naap2 na2 pn2) */
                    pn2.international_format
             FROM phone_number pn
             JOIN network_address_access_point naap ON naap.network_address_id=pn.network_address_id
             JOIN access_point_host aph ON aph.access_point_id=naap.access_point_id
             JOIN exchange e ON e.host_id=aph.host_id
             JOIN Exchange_Port ep ON ep.host_id=e.host_id
             JOIN network_address_access_point naap2 ON naap2.access_point_id=ep.access_point_id
             JOIN phone_number pn2 ON pn2.network_address_id=naap2.network_address_id
             WHERE ep.exchange_port_number=tt.exchange_port
               AND pn.international_format=tt.international_format
               AND tt.validity_date BETWEEN naap.from_date AND nvl(naap.To_Date,tt.validity_date)
               AND tt.validity_date BETWEEN aph.start_date AND nvl(aph.end_date,tt.validity_date)
               AND tt.validity_date BETWEEN naap2.from_date AND nvl(naap2.To_Date,tt.validity_date)
               AND e.exchange_usage_type_code=rsig_utils.c_Exchange_Usg_Type_PB
               AND pn.deleted IS NULL
               AND ep.deleted IS NULL);

  -- return result set
	OPEN result_list FOR
  SELECT tt.international_format GDN,
         tt.exchange_port Extension,
         tt.validity_date,
         tt.sn DDI
  FROM tt_batch_na_ap tt;

  COMMIT;

-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_DDI_By_GDN_And_Ext_List;

------------------------------------------------------------------------------------------------------------------------------
--  Get_PBX_Of_External_Operator
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Get_PBX_Of_External_Operator(
  p_network_operator_id    IN  network_operator.network_operator_id%TYPE,
  p_raise_error            IN  CHAR DEFAULT rsig_utils.c_NO,
  error_code               OUT NUMBER,
  error_message            OUT VARCHAR2,
  result_list              OUT sys_refcursor
)
IS
	v_sqlcode	               number;
  v_event_source           varchar2(60) :='PBX.Get_PBX_Of_External_Operator';
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

	IF p_network_operator_id IS NULL THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;


-- start of the procedure body --------------------------------------------------------------------------------------------------

  OPEN result_list FOR
	SELECT h.network_operator_id,
         h.host_id,
         h.host_code,
         h.host_name,
         h.host_address,
         h.host_location,
         h.date_of_change,
         u.user_name,
         h.deleted,
         h.time_zone,
         e.exchange_phone_prefix,
         e.commissioning_date,
         e.country_abbreviation,
         e.exchange_type_id,
         e.address_id,
         e.capacity
  FROM host h
  JOIN exchange e ON e.host_id=h.host_id
  JOIN network_operator n ON n.network_operator_id=h.network_operator_id
  JOIN users u ON u.user_id=h.user_id_of_change
  WHERE n.network_operator_type=rsig_utils.c_External_Net_Operator
    AND e.exchange_usage_type_code=rsig_utils.c_Exchange_Usg_Type_PB
    AND (p_network_operator_id IS NULL OR n.network_operator_id=p_network_operator_id);


-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
  error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
  WHEN OTHERS THEN
	  v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_PBX_Of_External_Operator;

END PBX;
/
