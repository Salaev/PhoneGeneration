CREATE PACKAGE BODY          "RSIG_EXCHANGE" IS

---------------------------------------------
--     PROCEDURE Test_Row_For_Exist_And_Deleted
---------------------------------------------

PROCEDURE Test_Row_For_Exist_And_Deleted(p_exchange_id IN NUMBER --cf* CFEXCHANGE.EXCHANGE_ID%TYPE
                                         ) IS
  v_deleted date; --cf* EXCHANGE.DELETED%TYPE;
BEGIN
  /*
  select DELETED
    into v_deleted
    from EXCHANGE
    where EXCHANGE_ID = p_exchange_id;

  IF v_deleted IS NOT NULL THEN
     IF v_deleted < sysdate THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
     END IF;
  END IF;
  */ --cf*
  select DELETED into v_deleted from HOST where HOST_ID = p_exchange_id;

  IF v_deleted IS NOT NULL THEN
    IF v_deleted < sysdate THEN
      RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
    END IF;
  END IF;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_ROW_NOT_FOUND, '');
END Test_Row_For_Exist_And_Deleted;

---------------------------------------------
--     PROCEDURE Test_Network_Operator_Deleted
---------------------------------------------

PROCEDURE Test_Network_Operator_Deleted(p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE) IS
  v_s VARCHAR2(1);
BEGIN
  select 'X'
    into v_s
    from NETWORK_OPERATOR
   where network_operator_id = p_network_operator_id
     and deleted is not null;

  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    NULL;
END Test_Network_Operator_Deleted;

---------------------------------------------
--     PROCEDURE Test_Exchange_Type_Deleted
---------------------------------------------

PROCEDURE Test_Exchange_Type_Deleted(p_exchange_type_id IN EXCHANGE_TYPE.EXCHANGE_TYPE_ID%TYPE) IS
  v_s VARCHAR2(1);
BEGIN
  select 'X'
    into v_s
    from EXCHANGE_TYPE
   where exchange_type_id = p_exchange_type_id
     and deleted is not null;

  RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_DELETED, '');
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    NULL;
END Test_Exchange_Type_Deleted;

---------------------------------------------
--     PROCEDURE Insert_Exchange
---------------------------------------------

PROCEDURE Insert_Exchange
(
  handle_tran                IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  ERROR_CODE                 OUT NUMBER,
  p_exchange_name            IN HOST.HOST_NAME%TYPE,
  p_exchange_phone_prefix    IN EXCHANGE.EXCHANGE_PHONE_PREFIX%TYPE,
  p_exchange_type_id         IN EXCHANGE.EXCHANGE_TYPE_ID%TYPE,
  p_exchange_usage_type_code IN EXCHANGE.EXCHANGE_USAGE_TYPE_CODE%TYPE,
  p_network_operator_id      IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_commissioning_date       IN EXCHANGE.COMMISSIONING_DATE%TYPE,
  p_country_abbreviation     IN EXCHANGE.COUNTRY_ABBREVIATION%TYPE,
  p_address_id               IN EXCHANGE.ADDRESS_ID%TYPE,
  p_user_id_of_change        IN NUMBER,
  p_host_code                IN HOST.HOST_CODE%TYPE,
  p_host_address             IN HOST.HOST_ADDRESS%TYPE,
  p_host_location            IN HOST.HOST_LOCATION%TYPE,
  p_host_type_code           IN HOST.HOST_TYPE_CODE%TYPE,
  p_exchange_id              OUT NUMBER
) IS
  v_event_source   VARCHAR2(60) := 'RSIG_EXCHANGE.Insert_Exchange';
  v_host_id        HOST.HOST_ID%TYPE;
  v_host_type_code HOST.HOST_TYPE_CODE%TYPE := RSIG_UTILS.c_HOST_TYPE_CODE_EX;
  --v_text           VARCHAR2(1000);
  ex_other EXCEPTION;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT insert_exchange_a;
  END IF;

  v_host_type_code := p_host_type_code;
  Test_Network_Operator_Deleted(p_network_operator_id);
  Test_Exchange_Type_Deleted(p_exchange_type_id);
  RSIG_HOST.Insert_Host(RSIG_Utils.Get_Handle_Tran_For_Call_Proc(handle_tran),
                        ERROR_CODE,
                        p_host_code,
                        p_exchange_name,
                        p_host_address,
                        p_host_location,
                        v_host_type_code,
                        p_network_operator_id,
                        p_user_id_of_change,
                        v_host_id);

  IF ERROR_CODE <> RSIG_UTILS.C_OK THEN
    IF ERROR_CODE = rsig_utils.c_ORA_UNIQ_KEY_HOST_CODE + 20000 THEN
      raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_CODE, '');
    ELSIF ERROR_CODE = rsig_utils.c_ORA_UNIQ_KEY_HOST_NAME + 20000 THEN
      raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_NAME, '');
    ELSE
      RAISE ex_other;
    END IF;
  END IF;

  p_exchange_id := v_host_id;
  INSERT INTO EXCHANGE
    (HOST_ID,
     EXCHANGE_PHONE_PREFIX,
     EXCHANGE_TYPE_ID,
     EXCHANGE_USAGE_TYPE_CODE,
     COMMISSIONING_DATE,
     COUNTRY_ABBREVIATION,
     ADDRESS_ID)
  VALUES
    (v_host_id,
     p_exchange_phone_prefix,
     p_exchange_type_id,
     p_exchange_usage_type_code,
     p_commissioning_date,
     p_country_abbreviation,
     p_address_id);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN ex_other THEN
    ERROR_CODE := RSIG_UTILS.Handle_Error(ERROR_CODE);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT insert_exchange_a;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;WHEN OTHERS THEN
    BEGIN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      --v_text     := SQLERRM;
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT insert_exchange_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
    END;
END Insert_Exchange;

---------------------------------------------
--     PROCEDURE Update_Exchange
---------------------------------------------

PROCEDURE Update_Exchange
(
  handle_tran                IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  ERROR_CODE                 OUT NUMBER,
  p_exchange_id              IN HOST.HOST_ID%TYPE,
  p_exchange_name            IN HOST.HOST_NAME%TYPE,
  p_exchange_phone_prefix    IN EXCHANGE.EXCHANGE_PHONE_PREFIX%TYPE,
  p_exchange_type_id         IN EXCHANGE.EXCHANGE_TYPE_ID%TYPE,
  p_exchange_usage_type_code IN EXCHANGE.EXCHANGE_USAGE_TYPE_CODE%TYPE,
  p_network_operator_id      IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_commissioning_date       IN EXCHANGE.COMMISSIONING_DATE%TYPE,
  p_country_abbreviation     IN EXCHANGE.COUNTRY_ABBREVIATION%TYPE,
  p_address_id               IN EXCHANGE.ADDRESS_ID%TYPE,
  p_host_address             IN HOST.HOST_ADDRESS%TYPE,
  p_host_location            IN HOST.HOST_LOCATION%TYPE,
  p_user_id_of_change        IN NUMBER
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE.Update_Exchange';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT update_exchange_a;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_exchange_id);
  Test_Network_Operator_Deleted(p_network_operator_id);
  Test_Exchange_Type_Deleted(p_exchange_type_id);

  UPDATE EXCHANGE
     SET EXCHANGE_PHONE_PREFIX    = p_exchange_phone_prefix,
         EXCHANGE_TYPE_ID         = p_exchange_type_id,
         EXCHANGE_USAGE_TYPE_CODE = p_exchange_usage_type_code,
         COMMISSIONING_DATE       = p_commissioning_date,
         COUNTRY_ABBREVIATION     = p_country_abbreviation,
         ADDRESS_ID               = p_address_id
   WHERE HOST_ID = p_exchange_id;

  UPDATE HOST
     SET HOST_NAME           = p_exchange_name,
         NETWORK_OPERATOR_ID = p_network_operator_id,
         HOST_ADDRESS        = p_host_address,
         HOST_LOCATION       = p_host_location,
         DATE_OF_CHANGE      = SYSDATE,
         USER_ID_OF_CHANGE   = p_user_id_of_change
   WHERE HOST_ID = p_exchange_id;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT update_exchange_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
    END;
END Update_Exchange;
/*
---------------------------------------------
--     PROCEDURE Delete_Exchange
---------------------------------------------

  PROCEDURE Delete_Exchange(
    handle_tran             IN    CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
    error_code              OUT   NUMBER,
    p_exchange_id           IN    NUMBER, --cf*EXCHANGE.EXCHANGE_ID%TYPE,
    p_deleted               IN    DATE, --cf*EXCHANGE.DELETED%TYPE,
    p_user_id_of_change     IN    NUMBER
  )
  IS
  BEGIN
    RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, 'RSIG_EXCHANGE.Close_Exchange');

    IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR (handle_tran IS NULL)) THEN
        RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
    END IF;

    IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
      savepoint delete_exchange_a;
    END IF;

    Test_Row_For_Exist_And_Deleted( p_exchange_id);
    update EXCHANGE
      set DELETED = p_deleted,
           DATE_OF_CHANGE = sysdate,
           USER_ID_OF_CHANGE = p_user_id_of_change
      where EXCHANGE_ID = p_exchange_id
     ;
    IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
      commit;
    END IF;

    error_code := RSIG_UTILS.c_OK; -- succesfully completed

    RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D, 'RSIG_EXCHANGE.Close_Exchange');

  EXCEPTION
    WHEN OTHERS THEN
    BEGIN
      error_code := RSIG_UTILS.Handle_Error(sqlcode);
      RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER, 'RSIG_EXCHANGE.Close_Exchange');
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN rollback to savepoint delete_exchange_a;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN rollback;
        ELSE NULL;
      END CASE;
    END;
  END;
*/

---------------------------------------------
--     PROCEDURE Get_Exchange
---------------------------------------------

PROCEDURE Get_Exchange
(
  ERROR_CODE            OUT NUMBER,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE, --NUMBER, --cf*EXCHANGE.NETWORK_OPERATOR_ID%TYPE,
  p_cur_exchange        OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE.Get_Exchange';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_exchange FOR
    SELECT h.HOST_ID,
           h.HOST_NAME,
           ex.EXCHANGE_PHONE_PREFIX,
           ex.EXCHANGE_TYPE_ID,
           ex_t.EXCHANGE_TYPE_CODE,
           ex.EXCHANGE_USAGE_TYPE_CODE,
           ex.COMMISSIONING_DATE,
           ex.COUNTRY_ABBREVIATION,
           ex.ADDRESS_ID,
           h.DATE_OF_CHANGE,
           h.USER_ID_OF_CHANGE,
           h.HOST_CODE,
           h.HOST_ADDRESS,
           h.HOST_LOCATION,
           h.HOST_TYPE_CODE,
           h.TIME_ZONE,
           h.DST_RULE_ID
      FROM EXCHANGE ex
      JOIN HOST h ON h.HOST_ID = ex.HOST_ID
      JOIN EXCHANGE_TYPE ex_t ON ex_t.exchange_type_id = ex.exchange_type_id
     WHERE (h.NETWORK_OPERATOR_ID = p_network_operator_id OR p_network_operator_id IS NULL)
       AND h.DELETED IS NULL
     ORDER BY ex_t.EXCHANGE_TYPE_CODE,
              h.HOST_NAME;


  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_Exchange;

---------------------------------------------
--     PROCEDURE Get_Exchange_NetHost
---------------------------------------------

PROCEDURE Get_Exchange_NetHost
(
  ERROR_CODE            OUT NUMBER,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE, --NUMBER, --cf*EXCHANGE.NETWORK_OPERATOR_ID%TYPE,
  p_host_type_code      IN HOST.HOST_TYPE_CODE%TYPE,
  p_cur_exchange        OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE.Get_Exchange_NetHost';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);


  OPEN p_cur_exchange FOR
    SELECT h.HOST_ID,
           h.HOST_NAME,
           ex.EXCHANGE_PHONE_PREFIX,
           ex.EXCHANGE_TYPE_ID,
           ex_t.EXCHANGE_TYPE_CODE,
           ex.EXCHANGE_USAGE_TYPE_CODE,
           ex.COMMISSIONING_DATE,
           ex.COUNTRY_ABBREVIATION,
           ex.ADDRESS_ID,
           h.DATE_OF_CHANGE,
           h.USER_ID_OF_CHANGE,
           h.HOST_CODE,
           h.HOST_ADDRESS,
           h.HOST_LOCATION,
           h.HOST_TYPE_CODE,
           h.TIME_ZONE,
           h.DST_RULE_ID
      FROM EXCHANGE ex
      JOIN HOST h ON h.HOST_ID = ex.HOST_ID
      JOIN EXCHANGE_TYPE ex_t ON ex_t.exchange_type_id = ex.exchange_type_id
     WHERE (h.NETWORK_OPERATOR_ID = p_network_operator_id OR p_network_operator_id IS NULL)
       AND TRIM(h.host_type_code) = TRIM(p_host_type_code)
       AND h.DELETED IS NULL
     ORDER BY ex_t.EXCHANGE_TYPE_CODE,
              h.HOST_NAME;

  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_Exchange_NetHost;

---------------------------------------------
--     PROCEDURE Get_Exchange_NetHost_All
---------------------------------------------

PROCEDURE Get_Exchange_NetHost_All(
  ERROR_CODE                   OUT NUMBER,
  p_network_operator_id        IN  network_operator.NETWORK_OPERATOR_ID%TYPE, --NUMBER, --cf*EXCHANGE.NETWORK_OPERATOR_ID%TYPE,
  p_host_type_code             IN  HOST.HOST_TYPE_CODE%TYPE,
  p_exchange_usage_type        IN  exchange.exchange_usage_type_code%TYPE,
  p_cur_exchange               OUT RSIG_UTILS.REF_CURSOR
)
IS
  v_event_source               VARCHAR2(60) := 'RSIG_EXCHANGE.Get_Exchange_NetHost_All';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_exchange FOR
    SELECT h.HOST_ID,
           h.HOST_NAME,
           ex.EXCHANGE_PHONE_PREFIX,
           ex.EXCHANGE_TYPE_ID,
           ex_t.EXCHANGE_TYPE_CODE,
           ex.EXCHANGE_USAGE_TYPE_CODE,
           ex.COMMISSIONING_DATE,
           ex.COUNTRY_ABBREVIATION,
           ex.ADDRESS_ID,
           h.DATE_OF_CHANGE,
           u.user_name,
           h.HOST_CODE,
           h.HOST_ADDRESS,
           h.HOST_LOCATION,
           h.HOST_TYPE_CODE,
           h.DELETED,
           h.TIME_ZONE,
           h.DST_RULE_ID
      FROM EXCHANGE ex
      JOIN HOST h ON h.HOST_ID = ex.HOST_ID
      JOIN USERS u ON u.user_id = h.user_id_of_change
      JOIN EXCHANGE_TYPE ex_t ON ex_t.exchange_type_id = ex.exchange_type_id
     WHERE (h.NETWORK_OPERATOR_ID = p_network_operator_id OR p_network_operator_id IS NULL)
       AND TRIM(h.host_type_code) = TRIM(p_host_type_code)
       AND (p_exchange_usage_type IS NULL OR TRIM(ex.exchange_usage_type_code)=p_exchange_usage_type)
     ORDER BY ex_t.EXCHANGE_TYPE_CODE,
              h.HOST_NAME;

  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_Exchange_NetHost_All;

---------------------------------------------
--     PROCEDURE Get_Exchange_All
---------------------------------------------

PROCEDURE Get_Exchange_All
(
  ERROR_CODE            OUT NUMBER,
  p_network_operator_id IN HOST.NETWORK_OPERATOR_ID%TYPE, --NUMBER, --cf*EXCHANGE.NETWORK_OPERATOR_ID%TYPE,
  p_cur_exchange        OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE.Get_Exchange_All';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_exchange FOR
    SELECT h.HOST_ID,
           h.HOST_NAME,
           ex.EXCHANGE_PHONE_PREFIX,
           ex.EXCHANGE_TYPE_ID,
           ex_t.EXCHANGE_TYPE_CODE,
           ex.EXCHANGE_USAGE_TYPE_CODE,
           ex.COMMISSIONING_DATE,
           ex.COUNTRY_ABBREVIATION,
           ex.ADDRESS_ID,
           h.DATE_OF_CHANGE,
           h.USER_ID_OF_CHANGE,
           h.HOST_CODE,
           h.HOST_ADDRESS,
           h.HOST_LOCATION,
           h.HOST_TYPE_CODE,
           h.DELETED,
           h.TIME_ZONE,
           h.DST_RULE_ID
      FROM EXCHANGE ex
      JOIN HOST h ON h.HOST_ID = ex.HOST_ID
      JOIN EXCHANGE_TYPE ex_t ON ex_t.exchange_type_id = ex.exchange_type_id
     WHERE (h.NETWORK_OPERATOR_ID = p_network_operator_id OR p_network_operator_id IS NULL)
     ORDER BY ex_t.EXCHANGE_TYPE_CODE,
              h.HOST_NAME;

  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
    END;
END Get_Exchange_All;

---------------------------------------------
--     PROCEDURE Insert_Exchange2
---------------------------------------------

PROCEDURE Insert_Exchange2
(
  handle_tran                IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  ERROR_CODE                 OUT NUMBER,
  p_exchange_name            IN HOST.HOST_NAME%TYPE,
  p_exchange_phone_prefix    IN EXCHANGE.EXCHANGE_PHONE_PREFIX%TYPE,
  p_exchange_type_id         IN EXCHANGE.EXCHANGE_TYPE_ID%TYPE,
  p_exchange_usage_type_code IN EXCHANGE.EXCHANGE_USAGE_TYPE_CODE%TYPE,
  p_network_operator_id      IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_commissioning_date       IN EXCHANGE.COMMISSIONING_DATE%TYPE,
  p_country_abbreviation     IN EXCHANGE.COUNTRY_ABBREVIATION%TYPE,
  p_address_id               IN EXCHANGE.ADDRESS_ID%TYPE,
  p_user_id_of_change        IN NUMBER,
  p_host_code                IN HOST.HOST_CODE%TYPE,
  p_host_address             IN HOST.HOST_ADDRESS%TYPE,
  p_host_location            IN HOST.HOST_LOCATION%TYPE,
  p_host_type_code           IN HOST.HOST_TYPE_CODE%TYPE,
  p_time_zone                IN HOST.TIME_ZONE%TYPE,
  p_dst_rule_id              IN NUMBER,
  p_exchange_id              OUT NUMBER
) IS
  v_event_source   VARCHAR2(60) := 'RSIG_EXCHANGE.Insert_Exchange2';
  v_host_id        HOST.HOST_ID%TYPE;
  v_host_type_code HOST.HOST_TYPE_CODE%TYPE := RSIG_UTILS.c_HOST_TYPE_CODE_EX;
  --v_text           VARCHAR2(1000);
  ex_other EXCEPTION;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT insert_exchange_a2;
  END IF;

  v_host_type_code := p_host_type_code;
  Test_Network_Operator_Deleted(p_network_operator_id);
  Test_Exchange_Type_Deleted(p_exchange_type_id);
  RSIG_HOST.Insert_Host2(RSIG_Utils.Get_Handle_Tran_For_Call_Proc(handle_tran),
                         ERROR_CODE,
                         p_host_code,
                         p_exchange_name,
                         p_host_address,
                         p_host_location,
                         v_host_type_code,
                         p_network_operator_id,
                         p_user_id_of_change,
                         p_time_zone,
                         p_dst_rule_id,
                         v_host_id);

  IF ERROR_CODE <> RSIG_UTILS.C_OK THEN
    IF ERROR_CODE = rsig_utils.c_ORA_UNIQ_KEY_HOST_CODE + 20000 THEN
      raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_CODE, '');
    ELSIF ERROR_CODE = rsig_utils.c_ORA_UNIQ_KEY_HOST_NAME + 20000 THEN
      raise_application_error(RSIG_UTILS.c_ORA_UNIQ_KEY_HOST_NAME, '');
    ELSE
      RAISE ex_other;
    END IF;
  END IF;

  p_exchange_id := v_host_id;
  INSERT INTO EXCHANGE
    (HOST_ID,
     EXCHANGE_PHONE_PREFIX,
     EXCHANGE_TYPE_ID,
     EXCHANGE_USAGE_TYPE_CODE,
     COMMISSIONING_DATE,
     COUNTRY_ABBREVIATION,
     ADDRESS_ID)
  VALUES
    (v_host_id,
     p_exchange_phone_prefix,
     p_exchange_type_id,
     p_exchange_usage_type_code,
     p_commissioning_date,
     p_country_abbreviation,
     p_address_id);

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN ex_other THEN
    ERROR_CODE := RSIG_UTILS.Handle_Error(ERROR_CODE);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT insert_exchange_a2;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;WHEN OTHERS THEN
    BEGIN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      --v_text     := SQLERRM;
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT insert_exchange_a2;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
    END;
END Insert_Exchange2;

---------------------------------------------
--     PROCEDURE Update_Exchange2
---------------------------------------------

PROCEDURE Update_Exchange2
(
  handle_tran                IN CHAR DEFAULT RSIG_UTILS.c_HANDLE_TRAN_Y,
  ERROR_CODE                 OUT NUMBER,
  p_exchange_id              IN HOST.HOST_ID%TYPE,
  p_exchange_name            IN HOST.HOST_NAME%TYPE,
  p_exchange_phone_prefix    IN EXCHANGE.EXCHANGE_PHONE_PREFIX%TYPE,
  p_exchange_type_id         IN EXCHANGE.EXCHANGE_TYPE_ID%TYPE,
  p_exchange_usage_type_code IN EXCHANGE.EXCHANGE_USAGE_TYPE_CODE%TYPE,
  p_network_operator_id      IN HOST.NETWORK_OPERATOR_ID%TYPE,
  p_commissioning_date       IN EXCHANGE.COMMISSIONING_DATE%TYPE,
  p_country_abbreviation     IN EXCHANGE.COUNTRY_ABBREVIATION%TYPE,
  p_address_id               IN EXCHANGE.ADDRESS_ID%TYPE,
  p_host_address             IN HOST.HOST_ADDRESS%TYPE,
  p_host_location            IN HOST.HOST_LOCATION%TYPE,
  p_user_id_of_change        IN NUMBER,
  p_time_zone                IN HOST.TIME_ZONE%TYPE,
  p_dst_rule_id              IN NUMBER
) IS
  v_event_source VARCHAR2(60) := 'RSIG_EXCHANGE.Update_Exchange2';
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  IF (handle_tran NOT IN (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.C_ORA_INVALID_HANDLE, '');
  END IF;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT update_exchange_a2;
  END IF;

  Test_Row_For_Exist_And_Deleted(p_exchange_id);
  Test_Network_Operator_Deleted(p_network_operator_id);
  Test_Exchange_Type_Deleted(p_exchange_type_id);

  UPDATE EXCHANGE
     SET EXCHANGE_PHONE_PREFIX    = p_exchange_phone_prefix,
         EXCHANGE_TYPE_ID         = p_exchange_type_id,
         EXCHANGE_USAGE_TYPE_CODE = p_exchange_usage_type_code,
         COMMISSIONING_DATE       = p_commissioning_date,
         COUNTRY_ABBREVIATION     = p_country_abbreviation,
         ADDRESS_ID               = p_address_id
   WHERE HOST_ID = p_exchange_id;

  UPDATE HOST
     SET HOST_NAME           = p_exchange_name,
         NETWORK_OPERATOR_ID = p_network_operator_id,
         HOST_ADDRESS        = p_host_address,
         HOST_LOCATION       = p_host_location,
         DATE_OF_CHANGE      = SYSDATE,
         USER_ID_OF_CHANGE   = p_user_id_of_change,
         TIME_ZONE           = p_time_zone,
         DST_RULE_ID         = p_dst_rule_id
   WHERE HOST_ID = p_exchange_id;

  IF (handle_tran = RSIG_UTILS.c_HANDLE_TRAN_Y) THEN
    COMMIT;
  END IF;

  ERROR_CODE := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      ERROR_CODE := RSIG_UTILS.Handle_Error(SQLCODE);
      RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                           RSIG_UTILS.c_DEBUG_LEVEL_0,
                           RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                           v_event_source);
      CASE handle_tran
        WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
          ROLLBACK TO SAVEPOINT update_exchange_a2;
        WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
          ROLLBACK;
        ELSE
          NULL;
      END CASE;
    END;
END Update_Exchange2;

---------------------------------------------
--     PROCEDURE Get_Phone_Ranges_By_IPs
---------------------------------------------

procedure Get_Phone_Ranges_By_IPs(
  p_validity_date  IN  Date,
  p_raise_error    IN  CHAR,
  error_code       OUT NUMBER,
  error_message    OUT VARCHAR2,
  result_list      OUT sys_refcursor
)
IS
	v_sqlcode	number;
  v_event_source   varchar2(60) :='RSIG_EXCHANGE.Get_Phone_Ranges_By_IPs';
  v_range_start    VARCHAR2(35);
  v_range_end      VARCHAR2(35);
  v_host_address   host.host_address%TYPE;


  CURSOR c_ranges IS
    SELECT h.host_address,
           pns.country_code || pns.area_code || pns.local_number_start range_start,
           pns.country_code || pns.area_code || pns.local_number_end range_end
    FROM host h
    JOIN phone_number_series pns ON pns.host_id=h.host_id
    WHERE h.host_address IS NOT NULL
      AND pns.deleted IS NULL
      AND h.deleted IS NULL
    GROUP BY h.host_address,
             pns.country_code || pns.area_code || pns.local_number_start,
             pns.country_code || pns.area_code || pns.local_number_end
    ORDER BY h.host_address,
             pns.country_code || pns.area_code || pns.local_number_start,
             pns.country_code || pns.area_code || pns.local_number_end;
BEGIN
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
	-- check handle_tran parameter

/*	IF test input parameters THEN
		RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
	END IF;
*/

-- start of the procedure body --------------------------------------------------------------------------------------------------

	FOR v_row IN c_ranges
  LOOP
    -- for same host address
    IF(v_row.host_address=v_host_address)THEN
      -- range is continue
      IF(to_number(v_row.range_start)=to_number(v_range_end)+1)THEN
        v_range_end:=v_row.range_end;
      ELSE -- start new range
        -- insert into temporary table
        INSERT INTO TT_HOST_PHONE_RANGE tt (host_address,range_start,range_end)
        VALUES(v_host_address,v_range_start,v_range_end);

        v_range_start:=v_row.range_start;
        v_range_end:=v_row.range_end;
      END IF;
    ELSE -- different host address
      IF(v_host_address IS NOT NULL) THEN
        -- insert into temporary table
        INSERT INTO TT_HOST_PHONE_RANGE tt (host_address,range_start,range_end)
        VALUES(v_host_address,v_range_start,v_range_end);
      END IF;
      v_range_start:=v_row.range_start;
      v_range_end:=v_row.range_end;
      v_host_address:=v_row.host_address;
    END IF;

  END LOOP;
  -- insert last record
  INSERT INTO TT_HOST_PHONE_RANGE tt (host_address,range_start,range_end)
  VALUES(v_host_address,v_range_start,v_range_end);


  OPEN result_list FOR
  SELECT tt.host_address,
         tt.range_start,
         tt.range_end
  FROM tt_host_phone_range tt;


-- end of the procedure body ----------------------------------------------------------------------------------------------------

  -- set error code to succesfully completed
	error_code := RSIG_UTILS.c_OK;
	RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
EXCEPTION
	WHEN OTHERS THEN
		v_sqlcode := sqlcode;
		error_message := sqlerrm;
--		DBMS_OUTPUT.PUT_LINE(error_message);
		error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
		RSIG_UTILS.Debug_Rsi (TO_CHAR(error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
		OPEN result_list FOR SELECT v_sqlcode,error_message FROM dual;
		IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
			RAISE;
		END IF;
END Get_phone_ranges_by_IPs;

END RSIG_EXCHANGE;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_EXCHANGE.pkb,v 1.17 2003/12/22 11:30:58 rhejduk Exp $
/
