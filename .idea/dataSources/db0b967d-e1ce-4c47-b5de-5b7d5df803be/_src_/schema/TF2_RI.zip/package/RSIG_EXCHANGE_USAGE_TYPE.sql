CREATE PACKAGE          "RSIG_EXCHANGE_USAGE_TYPE" is
/****************************************************************************
  <header>
    <name>              PACKAGE RSIG_EXCHANGE_USAGE_TYPE
    </name>

    <author>            Pavel Stengl
    </author>
    <version>           1.0.3   7.6.2005     Martin Zabka
                                ORDER BY added to Get_Exchange_usage_type
    </version>
    <version>           1.0.2   25.5.2004     Jaroslav Holub
                                fixed output cursor (not use *)
    </version>
    <version>           1.0.1   19.1.2004     Pavel Stengl
                                created first version
    </version>
    <Description>     Package contains procedure for managing exchange usage types.
    </Description>

    <Prerequisites>
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

  </header>
/****************************************************************************/

 /****************************************************************************
  <header>
    <name>              procedure Get_Exchange_usage_type
    </name>

    <author>            Pavel Stengl
    </author>

    <version>           1.0.3   7.6.2005     Martin Zabka
                                ORDER BY added to Get_Exchange_usage_type
    </version>
    <version>           1.0.2   25.5.2004     Jaroslav Holub
                                fixed output cursor (not use *)
    </version>
	<version>           1.0.1   19.1.2004     Pavel Stengl
                                created first version
    </version>

    <Description>     Procedure returns all exchange usage types in cursor.

    </Description>

    <Prerequisites>
                      Exists function:
                        RSIG_UTILS.Debug_Rsi
                        RSIG_UTILS.Handle_Error
                      Exists variable:
                        RSIG_UTILS.c_OK
                        RSIG_UTILS.c_ORA_MISSING_PARAMETER
                        RSIG_UTILS.c_ORA_INVALID_DATE
                        RSIG_UTILS.c_MIN_DATE
                      RSIG_UTILS.c_DEBUG_TEXT_START
                      RSIG_UTILS.c_DEBUG_TEXT_END
    </Prerequisites>

    <Application>       Resource Inventory
    </Application>

    <Parameters>        error_code            - Error code
                        p_validity_date       - Date for that it will be finds all zones.
                        p_operator_id         - Network_operation_id for that we want finds all zones
                        p_resul               - ref cursor (ZONE_CODE, ZONE_NAME, NETWORK_OPERATOR_NAME)
    </Parameters>

  </header>
/****************************************************************************/


PROCEDURE Get_Exchange_usage_type(
    error_code            OUT  NUMBER,
    p_result              OUT  RSIG_UTILS.REF_CURSOR
  );


PROCEDURE Get_Exchange_usage_type2(
    p_host_type_code      IN  VARCHAR2,
    error_code            OUT  NUMBER,
    p_result              OUT  RSIG_UTILS.REF_CURSOR
  );

end RSIG_EXCHANGE_USAGE_TYPE;

/
