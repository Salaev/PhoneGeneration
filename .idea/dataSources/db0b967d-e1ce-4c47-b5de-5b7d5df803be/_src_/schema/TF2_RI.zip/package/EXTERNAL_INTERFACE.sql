CREATE package external_interface is

----------------------------------!---------------------------------------------
  type t_sn is table of varchar2(60) index by binary_integer;
  type t_phone is table of varchar2(30) index by binary_integer;

----------------------------------!---------------------------------------------
  procedure link_phone_and_sim_2
  (
    p_phone_list t_phone,
    p_phone_linked_list t_phone,
    p_sn_list t_sn,
    p_link_type_code network_address_access_point.link_type_code%type,
    p_lnkd_ph_link_type_code network_address_access_point.link_type_code%type,
    p_from_date network_address_access_point.from_date%type,
    p_user_login varchar2,
    handle_tran char default rsig_utils.c_handle_tran_y,
    error_code out number,
    result_list out sys_refcursor,
    rejected_list out sys_refcursor
  );

----------------------------------!---------------------------------------------
  --!_!LEGACY for Scripts\8.20.501\CACHE_TIME_ZONE_OFFSET_base_filling.sql
  --!_!also in SUPS.cs
  --!_!move to API_RI_PKG

  procedure get_time_zone_offset_list_root
  (
    p_date_from date,
    p_date_to date,
    p_error_code out number,
    p_error_message out varchar2,
    p_time_zone_offset_list out sys_refcursor
  );

  procedure get_time_zone_offset_list
  (
    p_network_operator_code varchar2,
    p_date_from date,
    p_date_to date,
    p_error_code out number,
    p_error_message out varchar2,
    p_time_zone_offset_list out sys_refcursor
  );

----------------------------------!---------------------------------------------

end;
/
