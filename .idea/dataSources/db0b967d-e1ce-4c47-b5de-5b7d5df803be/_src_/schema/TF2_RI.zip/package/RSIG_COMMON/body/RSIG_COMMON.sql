CREATE PACKAGE BODY RSIG_COMMON IS

---------------------------------------------
--     FUNCTION Get_String_As_Table
---------------------------------------------

FUNCTION Get_String_As_Table
(
  in_string    VARCHAR2,
  in_delimiter CHAR
) RETURN table_of_string
  PIPELINED IS
  str         VARCHAR2(2000) := in_delimiter || in_string || in_delimiter;
  rest_of_str VARCHAR2(2000);
  position    INT;
BEGIN
  rest_of_str := in_string;
  LOOP
    EXIT WHEN rest_of_str IS NULL;
    position := instr(rest_of_str, in_delimiter); -- find position of delimiter
    IF position <> 0 THEN
      -- string contains delimiter
      str         := substr(rest_of_str, 1, position - 1); -- get current field
      rest_of_str := substr(rest_of_str, position + 1); -- get rest of string without current field
    ELSE
      -- string doesn't contain delimiter
      str         := rest_of_str; -- current field equals to rest of string
      rest_of_str := NULL; -- rest of string is null
    END IF;
    PIPE ROW(str); -- put current field into output
  END LOOP;
  RETURN;
END GET_STRING_AS_TABLE;

END RSIG_COMMON;
/
