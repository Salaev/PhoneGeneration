CREATE PACKAGE BODY RSIG_SIM_CARD_TYPE IS

---------------------------------------------
--     PROCEDURE Get_Sim_Card_Types
---------------------------------------------

PROCEDURE Get_Sim_Card_Types
(
  error_code           OUT NUMBER,
  p_cur_sim_card_types IN OUT RSIG_UTILS.REF_CURSOR
) IS
  v_event_source VARCHAR2(60) := 'RSIG_SIM_CARD_TYPE.Get_Sim_Card_Types';
BEGIN

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_BEFORE_SELECT,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  OPEN p_cur_sim_card_types FOR
    select SIM_CARD_TYPE_CODE,
           SIM_CARD_TYPE_NAME,
           DELETED,
           DATE_OF_CHANGE,
           USER_ID_OF_CHANGE
      from SIM_CARD_TYPE;

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_AFTER_SELECT,
                       RSIG_UTILS.c_DEBUG_LEVEL_2,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

  error_code := RSIG_UTILS.c_OK; -- succesfully completed

  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);

EXCEPTION
  WHEN OTHERS THEN
    error_code := RSIG_UTILS.Handle_Error(sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(error_code),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
END Get_Sim_Card_Types;
----------
END RSIG_SIM_CARD_TYPE;

-- CVS-INFO !!!NEMAZAT!!! $Id: RSIG_SIM_CARD_TYPE.pkb,v 1.16 2003/12/22 10:51:06 rhejduk Exp $
/
