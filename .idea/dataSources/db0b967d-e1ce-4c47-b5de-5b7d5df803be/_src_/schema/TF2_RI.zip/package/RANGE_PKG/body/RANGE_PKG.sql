CREATE package body RANGE_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_equivalent(p_item1 varchar2, p_item2 varchar2)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_item1 is null, 'p_item1');
  util_pkg.XCheck_Cond_Missing(p_item2 is null, 'p_item2');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(get_item_length(p_item1) != get_item_length(p_item2), 'p_item1.length != p_item2.length');
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_rangeable(p_item_from varchar2, p_item_to varchar2)
is
begin
  ------------------------------
  XCheck_equivalent(p_item_from, p_item_to);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(NOT is_rangeable(p_item_from, p_item_to), 'NOT p_item_from <= p_item_to');
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_3rangeable(p_item_from varchar2, p_item_between varchar2, p_item_to varchar2)
is
begin
  ------------------------------
  XCheck_equivalent(p_item_from, p_item_to);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(NOT is_3rangeable(p_item_from, p_item_between, p_item_to), 'NOT p_item_from <= p_item_between <= p_item_to');
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_3rangeable4split(p_item_from varchar2, p_item_between varchar2, p_item_to varchar2)
is
begin
  ------------------------------
  XCheck_3rangeable(p_item_from, p_item_between, p_item_to);
  util_pkg.XCheck_Cond_Invalid(is_equal(p_item_from, p_item_between), 'p_item1 = p_item_between');
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_t_range(p_range t_range, p_check_vals boolean)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_check_vals is null, 'p_check_vals');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_range.id is null, 'p_range.id');
  XCheck_rangeable(p_range.item_from, p_range.item_to);
  util_pkg.XCheck_Cond_Missing(p_check_vals and p_range.val1 is null, 'p_range.val1');
  util_pkg.XCheck_Cond_Missing(p_check_vals and p_range.val2 is null, 'p_range.val2');
  util_pkg.XCheck_Cond_Missing(p_check_vals and p_range.val3 is null, 'p_range.val3');
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_range_items(p_item_froms ct_varchar_s, p_item_tos ct_varchar_s)
is
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_item_froms);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_item_froms) != v_main_count, 'p_item_froms.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_item_tos) != v_main_count, 'p_item_tos.count != v_main_count');
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    XCheck_rangeable(p_item_froms(v_i), p_item_tos(v_i));
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_ranges_ordered(p_item_froms ct_varchar_s, p_item_tos ct_varchar_s)
is
  v_main_count number;
begin
  ------------------------------
  XCheck_range_items(p_item_froms, p_item_tos);
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_item_froms);
  ------------------------------
  for v_i in 1..v_main_count - 1
  loop
    ------------------------------
    XCheck_rangeable(p_item_froms(v_i), p_item_froms(v_i + 1));
    XCheck_rangeable(p_item_tos(v_i), p_item_tos(v_i + 1));
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_ranges_continuous(p_item_froms ct_varchar_s, p_item_tos ct_varchar_s)
is
  v_main_count number;
begin
  ------------------------------
  XCheck_ranges_ordered(p_item_froms, p_item_tos);
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_item_froms);
  ------------------------------
  for v_i in 1..v_main_count - 1
  loop
    ------------------------------
    util_pkg.XCheck_Cond_Invalid(NOT is_equal(p_item_tos(v_i), item2prev_item(p_item_froms(v_i + 1))), 'p_item_tos(' || util_pkg.number_to_char(v_i) ||') != p_item_froms(' || util_pkg.number_to_char(v_i + 1) ||')');
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function range_serialize(p_obj t_range, p_delim varchar2) return clob
is
  v_res clob;
  v_coll ct_varchar;
begin
  ------------------------------
  --!_!no check p_obj
  util_pkg.XCheck_Cond_Missing(p_delim is null, 'p_delim');
  ------------------------------
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.id));
  util_pkg.add_ct_varchar_val(v_coll, p_obj.item_from);
  util_pkg.add_ct_varchar_val(v_coll, p_obj.item_to);
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.val1));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.val2));
  util_pkg.add_ct_varchar_val(v_coll, util_pkg.number_to_char(p_obj.val3));
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) != c_srzi_count_range, 'Wrong format 001');
  ------------------------------
  v_res := to_clob(util_pkg.merge_string(v_coll, p_delim));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function range_deserialize(p_str clob, p_delim varchar2) return t_range
is
  v_res t_range;
  v_coll ct_varchar;
begin
  ------------------------------
  --!_!here no check p_str
  util_pkg.XCheck_Cond_Missing(p_delim is null, 'p_delim');
  ------------------------------
  v_coll := util_pkg.split_string(p_str, p_delim); --!_!clob to varchar2(???)
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar(v_coll) < c_srzi_count_range, 'Wrong format 001');
  ------------------------------
  v_res.id := util_pkg.char_to_number(v_coll(c_srzi_range_id));
  v_res.item_from := v_coll(c_srzi_range_item_from);
  v_res.item_to := v_coll(c_srzi_range_item_to);
  v_res.val1 := util_pkg.char_to_number(v_coll(c_srzi_range_val1));
  v_res.val2 := util_pkg.char_to_number(v_coll(c_srzi_range_val2));
  v_res.val3 := util_pkg.char_to_number(v_coll(c_srzi_range_val3));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_item_length(p_item varchar2) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_item is null, 'p_item');
  ------------------------------
  return util_pkg.str_length(p_item);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function calc_item_count(p_item_from varchar2, p_item_to varchar2) return integer
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_item_from is null, 'p_item_from');
  util_pkg.XCheck_Cond_Missing(p_item_to is null, 'p_item_to');
  ------------------------------
  XCheck_rangeable(p_item_from, p_item_to);
  ------------------------------
  return item2num(p_item_to) - item2num(p_item_from) + 1;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function num2item(p_item_num number, p_length number) return varchar2
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_item_num is null, 'p_item_num');
  util_pkg.XCheck_size(p_length, 'p_length');
  ------------------------------
  return lpad(util_pkg.number_to_char(p_item_num), p_length, '0');
  ------------------------------
end;

----------------------------------!---------------------------------------------
function item2num(p_item varchar2) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_item is null, 'p_item');
  ------------------------------
  --!_!return to_number(p_item, util_pkg.c_number_format2, util_pkg.c_number_nlsparam);
  return util_pkg.char_to_number(p_item);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_rangeable(p_item_from varchar2, p_item_to varchar2) return boolean
is
begin
  ------------------------------
  return is_less_eq(p_item_from, p_item_to);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_3rangeable(p_item_from varchar2, p_item_between varchar2, p_item_to varchar2) return boolean
is
begin
  ------------------------------
  if not is_rangeable(p_item_from, p_item_between)
  then
    return false;
  end if;
  ------------------------------
  if not is_rangeable(p_item_between, p_item_to)
  then
    return false;
  end if;
  ------------------------------
  if not is_rangeable(p_item_from, p_item_to)
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_equal(p_item1 varchar2, p_item2 varchar2) return boolean
is
begin
  ------------------------------
  return compare_items(p_item1, p_item2) = 0;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_greater(p_item1 varchar2, p_item2 varchar2) return boolean
is
begin
  ------------------------------
  return compare_items(p_item1, p_item2) > 0;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_greater_eq(p_item1 varchar2, p_item2 varchar2) return boolean
is
begin
  ------------------------------
  return compare_items(p_item1, p_item2) >= 0;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_less(p_item1 varchar2, p_item2 varchar2) return boolean
is
begin
  ------------------------------
  return compare_items(p_item1, p_item2) < 0;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_less_eq(p_item1 varchar2, p_item2 varchar2) return boolean
is
begin
  ------------------------------
  return compare_items(p_item1, p_item2) <= 0;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function compare_items(p_item1 varchar2, p_item2 varchar2) return number
is
begin
  ------------------------------
  XCheck_equivalent(p_item1, p_item2);
  ------------------------------
  return compare_items_num(item2num(p_item1), item2num(p_item2));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function compare_items_num(p_item_num1 number, p_item_num2 number) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_item_num1 is null, 'p_item_num1');
  util_pkg.XCheck_Cond_Missing(p_item_num2 is null, 'p_item_num2');
  ------------------------------
  return p_item_num1 - p_item_num2;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function shift_item(p_item varchar2, p_shift number) return varchar2
is
begin
  ------------------------------
  return num2item(shift_item_num(item2num(p_item), p_shift), get_item_length(p_item));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function shift_item_num(p_item_num number, p_shift number) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_item_num is null, 'p_item_num');
  util_pkg.XCheck_Cond_Missing(p_shift is null, 'p_shift');
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Invalid(p_shift <= 0, 'p_shift');
  ------------------------------
  return p_item_num + p_shift;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function item_from2item_to_limited(p_item_from varchar2, p_item_count number, p_item_to_limit varchar2) return varchar2
is
  v_res varchar2(50);
begin
  ------------------------------
  XCheck_rangeable(p_item_from, p_item_to_limit);
  ------------------------------
  v_res := item_from2item_to(p_item_from, p_item_count);
  ------------------------------
  if is_greater_eq(v_res, p_item_to_limit)
  then
    return p_item_to_limit;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function item_from2item_to(p_item_from varchar2, p_item_count number) return varchar2
is
begin
  ------------------------------
  return num2item(item_from_num2item_to_num(item2num(p_item_from), p_item_count), get_item_length(p_item_from));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function item_from_num2item_to_num(p_item_from_num number, p_item_count number) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_item_from_num is null, 'p_item_from_num');
  util_pkg.XCheck_size(p_item_count, 'p_item_count');
  ------------------------------
  return shift_item_num(p_item_from_num, p_item_count - 1);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function item2prev_item(p_item varchar2) return varchar2
is
begin
  ------------------------------
  return num2item(item_num2prev_item_num(item2num(p_item)), get_item_length(p_item));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function item2next_item(p_item varchar2) return varchar2
is
begin
  ------------------------------
  return num2item(item_num2next_item_num(item2num(p_item)), get_item_length(p_item));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function item_num2prev_item_num(p_item_num number) return number
is
begin
  ------------------------------
  return shift_item_num(p_item_num, -1);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function item_num2next_item_num(p_item_num number) return number
is
begin
  ------------------------------
  return shift_item_num(p_item_num, +1);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function calc_ranges_count
(
  p_item_from varchar2,
  p_item_to varchar2,
  p_range_size integer
) return integer
is
begin
  ------------------------------
  XCheck_rangeable(p_item_from, p_item_to);
  util_pkg.XCheck_size(p_range_size, 'p_range_size');
  ------------------------------
  return util_pkg.get_page_count(p_total_count => calc_item_count(p_item_from, p_item_to), p_page_size => p_range_size, p_always_have_first_page => FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function calc_range_index4item
(
  p_item_of_interest varchar2,
  p_range_size integer,
  p_ranges_item_from varchar2
) return integer
is
begin
  ------------------------------
  XCheck_rangeable(p_ranges_item_from, p_item_of_interest);
  util_pkg.XCheck_size(p_range_size, 'p_range_size');
  ------------------------------
  return util_pkg.get_page_number(p_common_index => item2num(p_item_of_interest), p_page_size => p_range_size, p_base_index => item2num(p_ranges_item_from));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_total_range_items
(
  p_item_froms ct_varchar_s,
  p_item_tos ct_varchar_s,
  p_total_item_from out varchar2,
  p_total_item_to out varchar2
)
is
begin
  ------------------------------
  XCheck_ranges_continuous(p_item_froms, p_item_tos);
  ------------------------------
  p_total_item_from := p_item_froms(p_item_froms.first);
  p_total_item_to := p_item_tos(p_item_tos.last);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure make_ranges
(
  p_item_from varchar2,
  p_item_to varchar2,
  p_range_size integer,
  p_range_item_froms out ct_varchar_s,
  p_range_item_tos out ct_varchar_s
)
is
  v_item_from varchar2(50);
  v_item_to varchar2(50);
begin
  ------------------------------
  XCheck_rangeable(p_item_from, p_item_to);
  util_pkg.XCheck_size(p_range_size, 'p_range_size');
  ------------------------------
  p_range_item_froms := null;
  p_range_item_tos := null;
  ------------------------------
  v_item_from := p_item_from;
  ------------------------------
  loop
    ------------------------------
    exit when compare_items(v_item_from, p_item_to) > 0;
    ------------------------------
    v_item_to := item_from2item_to_limited(p_item_from => v_item_from, p_item_count => p_range_size, p_item_to_limit => p_item_to);
    ------------------------------
    util_pkg.add_ct_varchar_s_val(p_range_item_froms, v_item_from);
    util_pkg.add_ct_varchar_s_val(p_range_item_tos, v_item_to);
    ------------------------------
    v_item_from := shift_item(v_item_from, p_range_size);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function associate_ranges
(
  p_item_from varchar2,
  p_item_to varchar2,
  p_range_size integer,
  p_range_numbers ct_number,
  p_range_item_counts ct_number
) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_range_count number;
begin
  ------------------------------
  XCheck_rangeable(p_item_from, p_item_to);
  util_pkg.XCheck_size(p_range_size, 'p_range_size');
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_range_numbers, 'p_range_numbers');
  util_pkg.XCheckP_FS_ct_number(p_range_item_counts, 'p_range_item_counts');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_range_numbers);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_range_numbers) != v_main_count, 'p_range_numbers.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_range_item_counts) != v_main_count, 'p_range_item_counts.count != v_main_count');
  ------------------------------
  v_range_count := calc_ranges_count
  (
    p_item_from => p_item_from,
    p_item_to => p_item_to,
    p_range_size => p_range_size
  );
  ------------------------------
  v_res := util_pkg.make_ct_number(v_range_count, 0);
  ------------------------------
  util_pkg.set_by_pos_ct_number(p_coll => v_res, p_vals => p_range_item_counts, p_positions => p_range_numbers);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure calc_dichotomic_counts
(
  p_boundary_index number,
  p_counts ct_number,
  p_count_before out number,
  p_count_boundary out number,
  p_count_after out number
)
is
  v_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_boundary_index is null, 'p_boundary_index');
  util_pkg.XCheckP_FS_ct_number(p_counts, 'p_counts');
  ------------------------------
  v_count := util_pkg.get_count_ct_number(p_counts);
  ------------------------------
  util_pkg.XCheck_index(p_boundary_index, v_count, 'p_boundary_index');
  ------------------------------
  p_count_before := 0;
  p_count_boundary := 0;
  p_count_after := 0;
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    if v_i < p_boundary_index
    then
      ------------------------------
      p_count_before := p_count_before + p_counts(v_i);
      ------------------------------
    elsif v_i > p_boundary_index
    then
      ------------------------------
      p_count_after := p_count_after + p_counts(v_i);
      ------------------------------
    else
      ------------------------------
      p_count_boundary := p_count_boundary + p_counts(v_i);
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure make_least_dichotomic_ranges
(
  p_item_boundary varchar2,
  p_item_from varchar2,
  p_item_to varchar2,
  p_range_size integer,
  p_range_item_real_counts_i ct_number,
  p_range_item_approx_counts_o out ct_number,
  p_range_item_froms out ct_varchar_s,
  p_range_item_tos out ct_varchar_s
)
is
  v_range_count integer;
  v_boundary_range_index number;
  v_boundary_index_in_range number;
  v_count_before number;
  v_count_boundary number;
  v_count_after number;
  v_old_range_index_from integer;
  v_new_range_count integer;
  v_new_range_index_to_modify integer;
begin
  ------------------------------
  XCheck_3rangeable4split(p_item_from, p_item_boundary, p_item_to);
  util_pkg.XCheck_size(p_range_size, 'p_range_size');
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_range_item_real_counts_i, 'p_range_item_real_counts_i');
  ------------------------------
  v_range_count := util_pkg.get_count_ct_number(p_range_item_real_counts_i);
  ------------------------------
  v_boundary_range_index := calc_range_index4item
  (
    p_item_of_interest => p_item_boundary,
    p_range_size => p_range_size,
    p_ranges_item_from => p_item_from
  );
  ------------------------------
  calc_dichotomic_counts
  (
    p_boundary_index => v_boundary_range_index,
    p_counts => p_range_item_real_counts_i,
    p_count_before => v_count_before,
    p_count_boundary => v_count_boundary,
    p_count_after => v_count_after
  );
  ------------------------------
  p_range_item_approx_counts_o := p_range_item_real_counts_i;
  ------------------------------
  make_ranges
  (
    p_item_from => p_item_from,
    p_item_to => p_item_to,
    p_range_size => p_range_size,
    p_range_item_froms => p_range_item_froms,
    p_range_item_tos => p_range_item_tos
  );
  ------------------------------
  if v_count_before <= v_count_after
  then
    ------------------------------
    v_old_range_index_from := 1;
    ------------------------------
    v_boundary_index_in_range := util_pkg.get_index_on_page(p_common_index => p_item_boundary, p_page_size => p_range_size, p_base_index => p_item_from);
    if v_boundary_index_in_range = 1
    then
      v_new_range_count := v_boundary_range_index - 1;
    else
      v_new_range_count := v_boundary_range_index;
    end if;
    ------------------------------
  else
    ------------------------------
    v_old_range_index_from := v_boundary_range_index;
    v_new_range_count := v_range_count - v_boundary_range_index + 1;
    ------------------------------
  end if;
  ------------------------------
  p_range_item_approx_counts_o := util_pkg.cut_ct_number(p_coll => p_range_item_approx_counts_o, p_count => v_new_range_count, p_start_pos => v_old_range_index_from);
  p_range_item_froms := util_pkg.cut_ct_varchar_s(p_coll => p_range_item_froms, p_count => v_new_range_count, p_start_pos => v_old_range_index_from);
  p_range_item_tos := util_pkg.cut_ct_varchar_s(p_coll => p_range_item_tos, p_count => v_new_range_count, p_start_pos => v_old_range_index_from);
  ------------------------------
  if v_count_before <= v_count_after
  then
    ------------------------------
    v_new_range_index_to_modify := v_new_range_count;
    ------------------------------
    p_range_item_tos(v_new_range_index_to_modify) := item2prev_item(p_item_boundary);
    ------------------------------
  else
    ------------------------------
    v_new_range_index_to_modify := 1;
    ------------------------------
    p_range_item_froms(v_new_range_index_to_modify) := p_item_boundary;
    ------------------------------
  end if;
  ------------------------------
  p_range_item_approx_counts_o(v_new_range_index_to_modify) := least(p_range_item_approx_counts_o(v_new_range_index_to_modify), calc_item_count(p_range_item_froms(v_new_range_index_to_modify), p_range_item_tos(v_new_range_index_to_modify)));
  ------------------------------
  --!_!p_range_item_approx_counts_o(v_new_range_index_to_modify) is GREATER (or equal) than REAL count; ignore this
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure break_down_ranges
(
  p_desired_range_count integer,
  p_range_item_counts ct_number,
  p_range_item_froms ct_varchar_s,
  p_range_item_tos ct_varchar_s,
  p_range_item_counts_o out ct_number,
  p_range_item_froms_o out ct_varchar_s,
  p_range_item_tos_o out ct_varchar_s
)
is
  lc_value_zero constant number := 0;
  v_main_count number;
  v_total_count number;
  v_desired_range_size number;
  v_sd_range_count number;
  v_sd_range_size number;
  v_sd_range_item_counts ct_number;
  v_sd_range_item_froms ct_varchar_s;
  v_sd_range_item_tos ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_size(p_desired_range_count, 'p_desired_range_count');
  util_pkg.XCheckP_FS_ct_number(p_range_item_counts, 'p_range_item_counts');
  util_pkg.XCheckP_FS_ct_varchar_s(p_range_item_froms, 'p_range_item_froms');
  util_pkg.XCheckP_FS_ct_varchar_s(p_range_item_tos, 'p_range_item_tos');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_range_item_counts);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_range_item_counts) != v_main_count, 'p_range_item_counts.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_range_item_froms) != v_main_count, 'p_range_item_froms.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_range_item_tos) != v_main_count, 'p_range_item_tos.count != v_main_count');
  ------------------------------
  v_total_count := util_pkg.get_sum_ct_number(p_range_item_counts);
  ------------------------------
  p_range_item_counts_o := null;
  p_range_item_froms_o := null;
  p_range_item_tos_o := null;
  ------------------------------
  if v_main_count = lc_value_zero
  then
    ------------------------------
    RETURN;
    ------------------------------
  end if;
  ------------------------------
  v_total_count := util_pkg.get_sum_ct_number(p_range_item_counts);
  ------------------------------
  if v_total_count = lc_value_zero
  then
    ------------------------------
    p_range_item_counts_o := p_range_item_counts;
    p_range_item_froms_o := p_range_item_froms;
    p_range_item_tos_o := p_range_item_tos;
    ------------------------------
    RETURN;
    ------------------------------
  end if;
  ------------------------------
  v_desired_range_size := util_pkg.get_page_size(p_total_count => v_total_count, p_page_count => p_desired_range_count, p_always_have_nonempty_page => TRUE);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if p_range_item_counts(v_i) > v_desired_range_size
    then
      ------------------------------
      v_sd_range_count := util_pkg.get_page_count(p_total_count => p_range_item_counts(v_i), p_page_size => v_desired_range_size, p_always_have_first_page => true);
      ------------------------------
      v_sd_range_size := util_pkg.get_page_size(p_total_count => calc_item_count(p_range_item_froms(v_i), p_range_item_tos(v_i)), p_page_count => v_sd_range_count, p_always_have_nonempty_page => TRUE);
      ------------------------------
      make_ranges
      (
        p_item_from => p_range_item_froms(v_i),
        p_item_to => p_range_item_tos(v_i),
        p_range_size => v_sd_range_size,
        p_range_item_froms => v_sd_range_item_froms,
        p_range_item_tos => v_sd_range_item_tos
      );
      ------------------------------
      --!_!v_sd_range_count CAN BE WRONG
      --!_!v_sd_range_item_counts := util_pkg.make_ct_number(p_count => v_sd_range_count, p_val => v_desired_range_size); --!_!
      v_sd_range_item_counts := util_pkg.make_ct_number(p_count => util_pkg.get_count_ct_varchar_s(v_sd_range_item_froms), p_val => v_desired_range_size); --!_!
      ------------------------------
      util_pkg.add_ct_number(p_range_item_counts_o, v_sd_range_item_counts);
      util_pkg.add_ct_varchar_s(p_range_item_froms_o, v_sd_range_item_froms);
      util_pkg.add_ct_varchar_s(p_range_item_tos_o, v_sd_range_item_tos);
      ------------------------------
    else
      ------------------------------
      util_pkg.add_ct_number_val(p_range_item_counts_o, p_range_item_counts(v_i));
      util_pkg.add_ct_varchar_s_val(p_range_item_froms_o, p_range_item_froms(v_i));
      util_pkg.add_ct_varchar_s_val(p_range_item_tos_o, p_range_item_tos(v_i));
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!results (_o) can be shorter than p_target_range_count for sum(p_range_item_counts) = 0; but 1 range in any case
procedure merge_ranges
(
  p_max_target_range_count integer,
  p_range_item_counts ct_number,
  p_range_item_froms ct_varchar_s,
  p_range_item_tos ct_varchar_s,
  p_range_item_counts_o out ct_number,
  p_range_item_froms_o out ct_varchar_s,
  p_range_item_tos_o out ct_varchar_s
)
is
  lc_count_one constant number := 1;
  lc_value_zero constant number := 0;
  v_main_count number;
  v_total_count number;
  v_range_size number;
  v_cur_count number;
  v_is_new_range boolean;
  v_item_from varchar2(50);
begin
  ------------------------------
  util_pkg.XCheck_size(p_max_target_range_count, 'p_max_target_range_count');
  util_pkg.XCheckP_FS_ct_number(p_range_item_counts, 'p_range_item_counts');
  util_pkg.XCheckP_FS_ct_varchar_s(p_range_item_froms, 'p_range_item_froms');
  util_pkg.XCheckP_FS_ct_varchar_s(p_range_item_tos, 'p_range_item_tos');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_range_item_counts);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_range_item_counts) != v_main_count, 'p_range_item_counts.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_range_item_froms) != v_main_count, 'p_range_item_froms.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_range_item_tos) != v_main_count, 'p_range_item_tos.count != v_main_count');
  ------------------------------
  p_range_item_counts_o := null;
  p_range_item_froms_o := null;
  p_range_item_tos_o := null;
  ------------------------------
  if v_main_count = lc_value_zero
  then
    ------------------------------
    RETURN;
    ------------------------------
  end if;
  ------------------------------
  v_total_count := util_pkg.get_sum_ct_number(p_range_item_counts);
  ------------------------------
  if v_total_count = lc_value_zero
  then
    ------------------------------
    p_range_item_counts_o := util_pkg.make_ct_number(lc_count_one, lc_value_zero);
    p_range_item_froms_o := util_pkg.make_ct_varchar_s(lc_count_one, p_range_item_froms(p_range_item_froms.first));
    p_range_item_tos_o := util_pkg.make_ct_varchar_s(lc_count_one, p_range_item_tos(p_range_item_tos.last));
    ------------------------------
    RETURN;
    ------------------------------
  end if;
  ------------------------------
  v_range_size := util_pkg.get_page_size(p_total_count => v_total_count, p_page_count => p_max_target_range_count, p_always_have_nonempty_page => TRUE);
  ------------------------------
  v_cur_count := 0;
  v_is_new_range := true;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if v_is_new_range
    then
      ------------------------------
      v_is_new_range := false;
      v_item_from := p_range_item_froms(v_i);
      ------------------------------
    end if;
    ------------------------------
    v_cur_count := v_cur_count + p_range_item_counts(v_i);
    ------------------------------
    if 1 = 0
      or v_cur_count >= v_range_size
      or (v_i = v_main_count and util_pkg.get_count_ct_varchar_s(p_range_item_froms_o) = 0)
    then
      ------------------------------
      util_pkg.add_ct_number_val(p_range_item_counts_o, v_cur_count);
      util_pkg.add_ct_varchar_s_val(p_range_item_froms_o, v_item_from);
      util_pkg.add_ct_varchar_s_val(p_range_item_tos_o, p_range_item_tos(v_i));
      ------------------------------
      v_cur_count := 0;
      v_is_new_range := true;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  if not is_equal(p_item1 => p_range_item_tos_o(p_range_item_tos_o.last), p_item2 => p_range_item_tos(p_range_item_tos.last))
  then
    ------------------------------
    p_range_item_tos_o(p_range_item_tos_o.last) := p_range_item_tos(p_range_item_tos.last);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure make_target_ranges_by_blocks
(
  p_item_boundary varchar2,
  p_item_from varchar2,
  p_item_to varchar2,
  p_block_size integer,
  p_block_numbers ct_number,
  p_block_item_counts ct_number,
  p_max_target_range_count integer,
  p_ranges_approx_count out ct_number,
  p_ranges_from out ct_varchar_s,
  p_ranges_to out ct_varchar_s
)
is
  lc_count_one constant number := 1;
  lc_value_one constant number := 1;
  v_main_count number;
  v_block_item_counts ct_number;
  v_block_item_froms ct_varchar_s;
  v_block_item_tos ct_varchar_s;
  v_total_item_from varchar2(50);
  v_total_item_to varchar2(50);
  v_item_from varchar2(50);
  v_item_to varchar2(50);
begin
  ------------------------------
  XCheck_3rangeable4split(p_item_from, p_item_boundary, p_item_to);
  util_pkg.XCheck_size(p_block_size, 'p_block_size');
  util_pkg.XCheck_size(p_max_target_range_count, 'p_max_target_range_count');
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_block_numbers, 'p_block_numbers');
  --!_!util_pkg.XCheckP_FS_ct_number(p_block_item_counts, 'p_block_item_counts');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_block_numbers);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_block_numbers) != v_main_count, 'p_block_numbers.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_block_item_counts) != v_main_count, 'p_block_item_counts.count != v_main_count');
  ------------------------------
  if v_main_count = 0 --!_!really empty range
  then
    ------------------------------
    if calc_item_count(p_item_from, item2prev_item(p_item_boundary)) < calc_item_count(p_item_boundary, p_item_to)
    then
      ------------------------------
      v_item_from := p_item_from;
      v_item_to := item2prev_item(p_item_boundary);
      ------------------------------
    else
      ------------------------------
      v_item_from := p_item_boundary;
      v_item_to := p_item_to;
      ------------------------------
    end if;
    ------------------------------
    p_ranges_approx_count := util_pkg.make_ct_number(lc_count_one, lc_value_one);
    p_ranges_from := util_pkg.make_ct_varchar_s(lc_count_one, v_item_from);
    p_ranges_to := util_pkg.make_ct_varchar_s(lc_count_one, v_item_to);
    ------------------------------
    RETURN;
    ------------------------------
  end if;
  ------------------------------
  v_block_item_counts := associate_ranges
  (
    p_item_from => p_item_from,
    p_item_to => p_item_to,
    p_range_size => p_block_size,
    p_range_numbers => p_block_numbers,
    p_range_item_counts => p_block_item_counts
  );
  ------------------------------
  --!_!p_range_item_counts(first) or p_range_item_counts(last) is GREATER (or equal) than REAL count; ignore this
  ------------------------------
  make_least_dichotomic_ranges
  (
    p_item_boundary => p_item_boundary,
    p_item_from => p_item_from,
    p_item_to => p_item_to,
    p_range_size => p_block_size,
    p_range_item_real_counts_i => v_block_item_counts,
    p_range_item_approx_counts_o => v_block_item_counts, --!_!approx
    p_range_item_froms => v_block_item_froms,
    p_range_item_tos => v_block_item_tos
  );
  ------------------------------
  break_down_ranges
  (
    p_desired_range_count => install_pkg.nnget_option_num(c_opt_break_down_desired_cnt, c_def_break_down_desired_cnt),
    p_range_item_counts => v_block_item_counts,
    p_range_item_froms => v_block_item_froms,
    p_range_item_tos => v_block_item_tos,
    p_range_item_counts_o => v_block_item_counts, --!_!approx
    p_range_item_froms_o => v_block_item_froms,
    p_range_item_tos_o => v_block_item_tos
  );
  ------------------------------
  --!_!results (_o) can be shorter than p_max_target_range_count for sum(p_range_item_counts) = 0; but 1 range in any case
  merge_ranges
  (
    p_max_target_range_count => p_max_target_range_count,
    p_range_item_counts => v_block_item_counts,
    p_range_item_froms => v_block_item_froms,
    p_range_item_tos => v_block_item_tos,
    p_range_item_counts_o => p_ranges_approx_count, --!_!approx
    p_range_item_froms_o => p_ranges_from,
    p_range_item_tos_o => p_ranges_to
  );
  ------------------------------
  --!_!self-check
  ------------------------------
  get_total_range_items
  (
    p_item_froms => p_ranges_from,
    p_item_tos => p_ranges_to,
    p_total_item_from => v_total_item_from,
    p_total_item_to => v_total_item_to
  );
  ------------------------------
  XCheck_rangeable(v_total_item_from, v_total_item_to);
  util_pkg.XCheck_Cond_Invalid(NOT is_equal(v_total_item_from, p_item_from) and NOT is_equal(v_total_item_from, p_item_boundary), 'total_item_from is bad');
  util_pkg.XCheck_Cond_Invalid(NOT is_equal(item2next_item(v_total_item_to), p_item_boundary) and NOT is_equal(v_total_item_to, p_item_to), 'total_item_to is bad');
  ------------------------------
end;

----------------------------------!---------------------------------------------
function calc_block_size
(
  p_item_from varchar2,
  p_item_to varchar2,
  p_block_count integer
) return integer
is
begin
  ------------------------------
  XCheck_rangeable(p_item_from, p_item_to);
  util_pkg.XCheck_size(p_block_count, 'p_block_count');
  ------------------------------
  return ceil(calc_item_count(p_item_from, p_item_to)/p_block_count);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_splitted_ranges_meta
(
  p_item_split_from varchar2,
  p_range t_range,
  p_range2change_item_from varchar2,
  p_range2change_item_to varchar2,
  p_range_to_creation_id number,
  p_range_to_truncation out t_range,
  p_range_to_creation out t_range
)
is
begin
  ------------------------------
  XCheck_t_range(p_range => p_range, p_check_vals => FALSE);
  XCheck_3rangeable4split(p_range.item_from, p_item_split_from, p_range.item_to);
  XCheck_rangeable(p_range2change_item_from, p_range2change_item_from);
  XCheck_3rangeable(p_range.item_from, p_range2change_item_from, p_range.item_to);
  XCheck_3rangeable(p_range.item_from, p_range2change_item_to, p_range.item_to);
  util_pkg.XCheck_Cond_Missing(p_range_to_creation_id is null, 'p_range_to_creation_id');
  ------------------------------
  ------------------------------
  p_range_to_truncation := NULL;
  p_range_to_truncation.id := p_range.id;
  ------------------------------
  if is_equal(p_range2change_item_from, p_item_split_from)
  then
    ------------------------------
    p_range_to_truncation.item_from := p_range.item_from;
    p_range_to_truncation.item_to := item2prev_item(p_item_split_from);
    ------------------------------
  else
    ------------------------------
    p_range_to_truncation.item_from := p_item_split_from;
    p_range_to_truncation.item_to := p_range.item_to;
    ------------------------------
  end if;
  ------------------------------
  p_range_to_truncation.val1 := p_range.val1;
  p_range_to_truncation.val2 := p_range.val2;
  p_range_to_truncation.val3 := p_range.val3;
  ------------------------------
  ------------------------------
  p_range_to_creation := NULL;
  p_range_to_creation.id := p_range_to_creation_id;
  p_range_to_creation.item_from := p_range2change_item_from;
  p_range_to_creation.item_to := p_range2change_item_to;
  p_range_to_creation.val1 := p_range.val1;
  p_range_to_creation.val2 := p_range.val2;
  p_range_to_creation.val3 := p_range.val3;
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xget_locker_id(p_range t_range) return number
is
begin
  ------------------------------
  XCheck_t_range(p_range => p_range, p_check_vals => FALSE);
  ------------------------------
  return locker_pkg.xl_latch_range2
  (
    p_type_id => c_locker_type,
    p_sn_from => p_range.item_from,
    p_sn_to => p_range.item_to
  ).locker_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_! different range1 range2 MUST be non-overlapped themselves
--!_! same range as range1 and range2 CAN be overlapped itself (MAGIC)
----------------------------------!---------------------------------------------
--!_! method is time-expensive
----------------------------------!---------------------------------------------
function make_unique_ranges
(
    p_range_with_length1 ct_range,
    p_range_with_length2 ct_range
) return ct_range
is
  v_res ct_range;
begin
  ------------------------------
  --!_!NO CHECKS - internal method
  ------------------------------
  with
  tt1 as
  (
    select
      val1 range_start,
      val2 range_end,
      num1 type_id,
      num2 value_len
      from table(p_range_with_length1)
  ),
  tt2 as
  (
    select
      val1 range_start,
      val2 range_end,
      num1 type_id,
      num2 value_len
      from table(p_range_with_length2)
  )
  select /*+ ordered use_hash(q2)*/
    ot_range
    (
      q1.range_start, --!_!val1
      q2.range_end, --!_!val2
      q1.type_id, --!_!num1
      q1.value_len, --!_!num2
      null, --!_!num3
      null, --!_!dat1
      null --!_!num4
    )
  bulk collect into
    v_res
  from
  (
    select
      type_id,
      value_len,
      range_start,
      row_number() over(partition by type_id, value_len order by range_start) rn
    from
    (
      select /*+ ordered use_hash(z2)*/
        z.type_id,
        z.value_len,
        z.range_start
      from tt1 z, tt2 z2
      where 1 = 1
        and z2.type_id(+) = z.type_id
        and z2.value_len(+) = z.value_len
        and z.range_start between z2.range_start(+) and z2.range_end(+)
        and z2.range_start(+) != z.range_start
        and z2.type_id is null
      UNION --!_! makes TOTAL distinct for query1 and query2
      select /*+ ordered use_hash(z2)*/
        z.type_id,
        z.value_len,
        z.range_start
      from tt2 z, tt1 z2
      where 1 = 1
        and z2.type_id(+) = z.type_id
        and z2.value_len(+) = z.value_len
        and z.range_start between z2.range_start(+) and z2.range_end(+)
        and z2.range_start(+) != z.range_start
        and z2.type_id is null
    )
  ) q1,
  (
    select
      type_id,
      value_len,
      range_end,
      row_number() over(partition by type_id, value_len order by range_end) rn
    from
    (
      select /*+ ordered use_hash(z2)*/
        z.type_id,
        z.value_len,
        z.range_end
      from tt1 z, tt2 z2
      where 1 = 1
        and z2.type_id(+) = z.type_id
        and z2.value_len(+) = z.value_len
        and z.range_end between z2.range_start(+) and z2.range_end(+)
        and z2.range_end(+) != z.range_end
        and z2.type_id is null
      UNION --!_! makes TOTAL distinct for query1 and query2
      select /*+ ordered use_hash(z2)*/
        z.type_id,
        z.value_len,
        z.range_end
      from tt2 z, tt1 z2
      where 1 = 1
        and z2.type_id(+) = z.type_id
        and z2.value_len(+) = z.value_len
        and z.range_end between z2.range_start(+) and z2.range_end(+)
        and z2.range_end(+) != z.range_end
        and z2.type_id is null
    )
  ) q2
  where 1 = 1
    and q1.type_id = q2.type_id
    and q1.value_len = q2.value_len
    and q1.rn = q2.rn
  order by
    q1.type_id,
    q1.value_len,
    q1.range_start,
    q2.range_end
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_unique_ranges2
(
    p_range_with_length ct_range
) return ct_range
is
begin
  ------------------------------
  return make_unique_ranges
  (
    p_range_with_length1 => p_range_with_length,
    p_range_with_length2 => p_range_with_length
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
