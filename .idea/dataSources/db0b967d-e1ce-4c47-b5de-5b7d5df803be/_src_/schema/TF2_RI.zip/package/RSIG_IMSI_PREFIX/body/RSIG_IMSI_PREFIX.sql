CREATE PACKAGE BODY RSIG_IMSI_PREFIX IS

---------------------------------------------
--     PROCEDURE Check_Interval_Overlap
---------------------------------------------

PROCEDURE Check_Interval_Overlap
(
  p_IMSI_prefix_id      IN IMSI_PREFIX.IMSI_PREFIX_ID%TYPE,
  p_start_date          IN DATE,
  p_end_date            IN DATE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IMSI_PREFIX.Check_Interval_Overlap';
  v_overlap      NUMBER;
  v_start_date   DATE;
  v_sysdate      DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  IF p_IMSI_prefix_id IS NULL  THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  v_sysdate    := SYSDATE;
  v_start_date := nvl(p_start_date, v_sysdate);

  -- procedure body here
  BEGIN
    SELECT 1
      INTO v_overlap
      FROM IMSI_PREFIX_NETWORK_OPERATOR ipno
     WHERE ipno.IMSI_PREFIX_ID = p_IMSI_prefix_id
       AND ipno.START_DATE <= nvl(p_end_date, v_sysdate)
       AND nvl(ipno.END_DATE, v_sysdate) >= v_start_date;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      NULL; -- interval not overlap existing - nothing to do
  END;
  IF v_overlap = 1 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_IMSI_PREFIX_EXISTS, 'Imsi prefix exists');
  END IF;

  -- set error code to succesfully completed
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
END Check_interval_overlap;

---------------------------------------------
--     PROCEDURE Insert_IMSI_Prefix
---------------------------------------------

PROCEDURE Insert_IMSI_Prefix
(
  p_IMSI_prefix       IN IMSI_PREFIX.IMSI_PREFIX%TYPE,
  handle_tran         IN CHAR,
  p_user_id_of_change IN NUMBER,
  p_raise_error       IN CHAR,
  ERROR_CODE          OUT NUMBER,
  error_message       OUT VARCHAR2,
  p_IMSI_prefix_id    OUT IMSI_PREFIX.IMSI_PREFIX_ID%TYPE
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IMSI_PREFIX.Insert_IMSI_Prefix';
  v_sqlcode      NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  IF p_IMSI_prefix IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Insert_IMSI_Prefix;
  END IF;

  -- procedure body here
  INSERT INTO IMSI_PREFIX
    (IMSI_PREFIX_ID,
     IMSI_PREFIX,
     USER_ID_OF_CHANGE,
     DATE_OF_CHANGE)
  VALUES
    (S_ACCESS_POINT.NEXTVAL,
     p_IMSI_prefix,
     p_user_id_of_change,
     SYSDATE)
  RETURNING IMSI_PREFIX_ID INTO p_IMSI_prefix_id;

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Insert_IMSI_Prefix;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Insert_IMSI_Prefix;

---------------------------------------------
--     PROCEDURE Update_IMSI_Prefix
---------------------------------------------

PROCEDURE Update_IMSI_Prefix
(
  p_IMSI_prefix_id    IN IMSI_PREFIX.IMSI_PREFIX_ID%TYPE,
  p_new_IMSI_prefix   IN IMSI_PREFIX.IMSI_PREFIX%TYPE,
  p_user_id_of_change IN NUMBER,
  handle_tran         IN CHAR,
  p_raise_error       IN CHAR,
  ERROR_CODE          OUT NUMBER,
  error_message       OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IMSI_PREFIX.Update_IMSI_Prefix';
  v_sqlcode      NUMBER;
  v_count        NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  IF p_IMSI_prefix_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Update_IMSI_Prefix;
  END IF;

  -- procedure body here
  SELECT COUNT(1)
    INTO v_count
    FROM IMSI_PREFIX ip
    JOIN IMSI_PREFIX_NETWORK_OPERATOR ipno ON ipno.IMSI_PREFIX_ID = ip.IMSI_PREFIX_ID
   WHERE ip.IMSI_PREFIX_ID = p_IMSI_prefix_id;

  IF v_count > 1 THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_Err_Update_IMSI_Prefix, 'More then one record in history!');
  END IF;

  UPDATE IMSI_PREFIX ip
     SET ip.IMSI_PREFIX       = p_new_IMSI_prefix,
         ip.USER_ID_OF_CHANGE = p_user_id_of_change,
         ip.DATE_OF_CHANGE    = SYSDATE
   WHERE ip.IMSI_PREFIX_ID = p_IMSI_prefix_id;

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Update_IMSI_Prefix;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Update_IMSI_Prefix;

---------------------------------------------
--     PROCEDURE Insert_Interval
---------------------------------------------

PROCEDURE Insert_Interval
(
  p_IMSI_prefix_id      IN IMSI_PREFIX.IMSI_PREFIX_ID%TYPE,
  p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_start_date          IN DATE,
  p_end_date            IN DATE,
  p_user_id_of_change   IN NUMBER,
  handle_tran           IN CHAR,
  p_raise_error         IN CHAR,
  ERROR_CODE            OUT NUMBER,
  error_message         OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IMSI_PREFIX.Insert_Interval';
  v_sqlcode      NUMBER;
  v_sysdate      DATE;
  v_start_date   DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  v_sysdate := SYSDATE;

  v_start_date := nvl(p_start_date, v_sysdate);

  Check_interval_overlap(p_IMSI_prefix_id,v_start_date, p_end_date);

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Insert_interval;
  END IF;

  -- procedure body here

  INSERT INTO IMSI_PREFIX_NETWORK_OPERATOR ipno
    (network_operator_id,
     imsi_prefix_id,
     start_date,
     end_date,
     user_id_of_change,
     date_of_change)
  VALUES
    (p_network_operator_id,
     p_IMSI_prefix_id,
     v_start_date,
     p_end_date,
     p_user_id_of_change,
     v_sysdate);

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Insert_interval;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Insert_interval;

---------------------------------------------
--     PROCEDURE Close_Interval
---------------------------------------------

PROCEDURE Close_Interval
(
  p_IMSI_prefix_id      IN IMSI_PREFIX.IMSI_PREFIX_ID%TYPE,
  p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_start_date          IN DATE,
  p_end_date            IN DATE,
  p_user_id_of_change   IN NUMBER,
  handle_tran           IN CHAR,
  p_raise_error         IN CHAR,
  ERROR_CODE            OUT NUMBER,
  error_message         OUT VARCHAR2
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IMSI_PREFIX.Close_Interval';
  v_sqlcode      NUMBER;
  v_end_date     DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Close_Interval;
  END IF;

  v_end_date:=nvl(p_end_date,SYSDATE);

  -- procedure body here
  UPDATE IMSI_PREFIX_NETWORK_OPERATOR ipno
     SET ipno.END_DATE          = v_end_date,
         ipno.USER_ID_OF_CHANGE = p_user_id_of_change,
         ipno.DATE_OF_CHANGE    = SYSDATE
   WHERE ipno.NETWORK_OPERATOR_ID = p_network_operator_id
     AND ipno.IMSI_PREFIX_ID = p_IMSI_prefix_id
     AND ipno.START_DATE = p_start_date;

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Close_Interval;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Close_Interval;

---------------------------------------------
--     PROCEDURE Close_Insert_Interval
---------------------------------------------

PROCEDURE Close_Insert_Interval
(
  p_IMSI_prefix_id          IN IMSI_PREFIX.IMSI_PREFIX_ID%TYPE,
  p_network_operator_id     IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_start_date              IN DATE,
  p_end_date                IN DATE,
  p_new_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_new_start_date          IN DATE,
  p_new_end_date            IN DATE,
  p_user_id_of_change       IN NUMBER,
  handle_tran               IN CHAR,
  p_raise_error             IN CHAR,
  ERROR_CODE                OUT NUMBER,
  error_message             OUT VARCHAR2
) IS
  v_event_source   VARCHAR2(60) := 'RSIG_IMSI_PREFIX.Close_Insert_Interval';
  v_sqlcode        NUMBER;
  v_end_date       DATE;
  v_new_start_date DATE;
  v_sysdate        DATE;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  IF p_IMSI_prefix_id IS NULL
     OR p_network_operator_id IS NULL
     OR p_start_date IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  v_sysdate := SYSDATE;
  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Close_Insert_interval;
  END IF;

  IF p_end_date IS NULL THEN
    IF p_new_start_date IS NULL THEN
      v_end_date := v_sysdate - RSIG_UTILS.c_INTERVAL_DIFFERENCE;
    ELSE
      v_end_date := p_new_start_date - RSIG_UTILS.c_INTERVAL_DIFFERENCE;
    END IF;
  ELSE
    v_end_date := p_end_date;
  END IF;

  v_new_start_date := v_sysdate;

  -- procedure body here
  Close_Interval(p_imsi_prefix_id,
                 p_network_operator_id,
                 p_start_date,
                 v_end_date,
                 p_user_id_of_change,
                 /*handle_tran*/
                 RSIG_UTILS.c_NO,
                 /*p_raise_error*/
                 RSIG_UTILS.c_YES,
                 ERROR_CODE,
                 error_message);

  Insert_interval(p_imsi_prefix_id,
                  p_new_network_operator_id,
                  v_new_start_date,
                  p_new_end_date,
                  p_user_id_of_change,
                  /*handle_tran*/
                  RSIG_UTILS.c_NO,
                  /*p_raise_error*/
                  RSIG_UTILS.c_YES,
                  ERROR_CODE,
                  error_message);

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Close_Insert_interval;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Close_Insert_interval;

---------------------------------------------
--     PROCEDURE Ins_IMSI_Prefix_And_Interval
---------------------------------------------

PROCEDURE Ins_IMSI_Prefix_And_Interval
(
  p_IMSI_prefix         IN IMSI_PREFIX.IMSI_PREFIX%TYPE,
  p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_start_date          IN DATE,
  p_end_date            IN DATE,
  p_user_id_of_change   IN NUMBER,
  handle_tran           IN CHAR,
  p_raise_error         IN CHAR,
  ERROR_CODE            OUT NUMBER,
  error_message         OUT VARCHAR2
) IS
  v_event_source   VARCHAR2(60) := 'RSIG_IMSI_PREFIX.Ins_IMSI_Prefix_And_Interval';
  v_sqlcode        NUMBER;
  v_start_date     DATE;
  v_imsi_prefix_id NUMBER;

BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter
  IF (upper(handle_tran) NOT IN
     (RSIG_UTILS.c_HANDLE_TRAN_S, RSIG_UTILS.c_HANDLE_TRAN_Y, RSIG_UTILS.c_HANDLE_TRAN_N) OR
     (handle_tran IS NULL)) THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_HANDLE, 'Invalid HANDLE_TRAN parameter!');
  END IF;

  IF p_IMSI_prefix IS NULL
     OR p_network_operator_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- set savepoint
  IF (upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_S) THEN
    SAVEPOINT Ins_IMSI_Prefix_and_Interval;
  END IF;

  v_start_date := nvl(p_start_date, SYSDATE);

  BEGIN
    SELECT ip.imsi_prefix_id
    INTO v_imsi_prefix_id
    FROM imsi_prefix ip
    WHERE ip.imsi_prefix=p_IMSI_prefix;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_imsi_prefix_id:=NULL;
  END;

  -- procedure body here
  IF v_imsi_prefix_id IS NULL THEN
    Insert_IMSI_Prefix(p_imsi_prefix,
                       /*handle_tran*/
                       RSIG_UTILS.c_NO,
                       p_user_id_of_change,
                       /*p_raise_error*/
                       RSIG_UTILS.c_YES,
                       ERROR_CODE,
                       error_message,
                       v_imsi_prefix_id);
  END IF;

  Insert_interval(v_imsi_prefix_id,
                  p_network_operator_id,
                  v_start_date,
                  p_end_date,
                  p_user_id_of_change,
                  /*handle_tran*/
                  RSIG_UTILS.c_NO,
                  /*p_raise_error*/
                  RSIG_UTILS.c_YES,
                  ERROR_CODE,
                  error_message);

  -- commit
  IF upper(handle_tran) = RSIG_UTILS.c_HANDLE_TRAN_Y THEN
    COMMIT;
  END IF;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    CASE handle_tran
      WHEN RSIG_UTILS.c_HANDLE_TRAN_S THEN
        ROLLBACK TO SAVEPOINT Ins_IMSI_Prefix_and_Interval;
      WHEN RSIG_UTILS.c_HANDLE_TRAN_Y THEN
        ROLLBACK;
      ELSE
        NULL;
    END CASE;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Ins_IMSI_Prefix_and_Interval;

---------------------------------------------
--     PROCEDURE Get_IMSI_Prefixes_By_Operator
---------------------------------------------

PROCEDURE Get_IMSI_Prefixes_By_Operator
(
  p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_start_date          IN DATE,
  p_raise_error         IN CHAR,
  ERROR_CODE            OUT NUMBER,
  error_message         OUT VARCHAR2,
  result_list           OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IMSI_PREFIX.Get_IMSI_Prefixes_By_Operator';
  v_sqlcode      NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  IF p_network_operator_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- procedure body here

  OPEN result_list FOR
    SELECT ipno.IMSI_PREFIX_ID,
           ip.IMSI_PREFIX /*,
                           ipno.START_DATE,
                           ipno.END_DATE*/
      FROM IMSI_PREFIX_NETWORK_OPERATOR ipno
      JOIN IMSI_PREFIX ip ON ipno.IMSI_PREFIX_ID = ip.IMSI_PREFIX_ID
    --    JOIN NETWORK_OPERATOR no ON no.NETWORK_OPERATOR_ID = ipno.NETWORK_OPERATOR_ID
     WHERE nvl(p_start_date, SYSDATE) BETWEEN ipno.START_DATE AND
           nvl(nvl(ipno.END_DATE, p_start_date), SYSDATE)
       AND p_network_operator_id = ipno.NETWORK_OPERATOR_ID
     ORDER BY ipno.NETWORK_OPERATOR_ID,
              ip.IMSI_PREFIX;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN result_list FOR
      SELECT v_sqlcode,
             error_message
        FROM dual;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END;

---------------------------------------------
--     PROCEDURE Get_IMSI_Prefixes_By_Op_EX
---------------------------------------------

PROCEDURE Get_IMSI_Prefixes_By_Op_EX
(
  p_network_operator_id IN NETWORK_OPERATOR.NETWORK_OPERATOR_ID%TYPE,
  p_start_date          IN DATE,
  p_get_history         IN CHAR,
  p_raise_error         IN CHAR,
  ERROR_CODE            OUT NUMBER,
  error_message         OUT VARCHAR2,
  result_list           OUT sys_refcursor
) IS
  v_event_source VARCHAR2(60) := 'RSIG_IMSI_PREFIX.Get_IMSI_Prefixes_By_Op_EX';
  v_sqlcode      NUMBER;
BEGIN
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_START,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
  -- check handle_tran parameter

  IF p_network_operator_id IS NULL THEN
    RAISE_APPLICATION_ERROR(RSIG_UTILS.c_ORA_INVALID_PARAMETER, 'Invalid input parameter');
  END IF;

  -- procedure body here

  OPEN result_list FOR
    SELECT ipno.IMSI_PREFIX_ID,
           ip.IMSI_PREFIX,
           ipno.START_DATE,
           ipno.END_DATE,
           ipno.DATE_OF_CHANGE,
           ipno.USER_ID_OF_CHANGE,
           u.USER_NAME
      FROM IMSI_PREFIX_NETWORK_OPERATOR ipno
      JOIN IMSI_PREFIX ip ON ipno.IMSI_PREFIX_ID = ip.IMSI_PREFIX_ID
      LEFT JOIN USERS u ON u.USER_ID = ipno.USER_ID_OF_CHANGE
    --    JOIN NETWORK_OPERATOR no ON no.NETWORK_OPERATOR_ID = ipno.NETWORK_OPERATOR_ID
     WHERE (nvl(p_start_date, SYSDATE) BETWEEN ipno.START_DATE AND
           nvl(nvl(ipno.END_DATE, p_start_date), SYSDATE) OR p_get_history = RSIG_UTILS.c_YES)
       AND p_network_operator_id = ipno.NETWORK_OPERATOR_ID
     ORDER BY ipno.NETWORK_OPERATOR_ID,
              ip.IMSI_PREFIX;

  -- set error code to succesfully completed
  ERROR_CODE := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi(RSIG_UTILS.c_DEBUG_TEXT_END,
                       RSIG_UTILS.c_DEBUG_LEVEL_1,
                       RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,
                       v_event_source);
EXCEPTION
  WHEN OTHERS THEN
    v_sqlcode     := SQLCODE;
    error_message := SQLERRM;
    --    DBMS_OUTPUT.PUT_LINE(error_message);
    ERROR_CODE := RSIG_UTILS.Handle_Error(v_sqlcode);
    RSIG_UTILS.Debug_Rsi(TO_CHAR(ERROR_CODE),
                         RSIG_UTILS.c_DEBUG_LEVEL_0,
                         RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,
                         v_event_source);
    OPEN result_list FOR
      SELECT v_sqlcode,
             error_message
        FROM dual;
    IF UPPER(p_raise_error) = RSIG_UTILS.c_YES THEN
      RAISE;
    END IF;
END Get_IMSI_Prefixes_By_Op_EX;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_imsi_prefix_id0(p_imsi ct_varchar_s, p_date ct_date, p_trim_empty boolean) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_max_imsi_length number;
  v_rn ct_number;
  v_tmp_rn ct_number;
  v_pivot_dev ct_number;
  v_imsi_sub_dev ct_varchar_s;
  v_date_dev ct_date;
  v_sub_len_dev ct_number;
  v_rn_dev ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_imsi) != v_main_count, 'p_imsi.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select max(length(q.imsi))
  into v_max_imsi_length
  from
    (select column_value imsi, rownum rn from table(cast(p_imsi as ct_varchar_s))) q
  ;
  ------------------------------
  v_pivot_dev := util_pkg.make_pivot(p_count => v_max_imsi_length);
  ------------------------------
select /*+ ordered use_hash(q q2 q3) full(q) full(q2) full(q3)*/
  substr(q.imsi, 1, q3.sub) imsi_sub, q2.validity_date, q.rn, q3.sub
  bulk collect into v_imsi_sub_dev, v_date_dev, v_rn_dev, v_sub_len_dev
  from
    (select column_value imsi, rownum rn from table(cast(p_imsi as ct_varchar_s))) q,
    (select column_value validity_date, rownum rn from table(cast(p_date as ct_date))) q2,
    (select column_value sub, rownum rn from table(cast(v_pivot_dev as ct_number))) q3
  where 1 = 1
  and q2.rn = q.rn
  and q3.sub <= length(q.imsi)
  ;
  ------------------------------
select qq.imsi_prefix_id, qq.rn
  bulk collect into v_res, v_rn
  from (
    select /*+ ordered use_hash(q q2 q3 q4 z1 z2) full(q) full(q2) full(q3) full(q4) full(z1) full(z2)*/
      z1.imsi_prefix_id, q4.imsi_rn rn,
      row_number() over (partition by q4.imsi_rn order by q3.sub_len desc) rnum
      from
        (select column_value imsi_sub, rownum rn from table(cast(v_imsi_sub_dev as ct_varchar_s))) q,
        (select column_value on_date, rownum rn from table(cast(v_date_dev as ct_date))) q2,
        (select column_value sub_len, rownum rn from table(cast(v_sub_len_dev as ct_number))) q3,
        (select column_value imsi_rn, rownum rn from table(cast(v_rn_dev as ct_number))) q4,
        imsi_prefix z1,
        imsi_prefix_network_operator z2
      where 1 = 1
      and q2.rn = q.rn
      and q3.rn = q.rn
      and q4.rn = q.rn
      and q.imsi_sub = z1.imsi_prefix
      and z2.imsi_prefix_id = z1.imsi_prefix_id
      and q2.on_date between z2.start_date and nvl(z2.end_date, q2.on_date)
    ) qq
  where 1 = 1
  and qq.rnum = 1
  order by qq.rn
  ;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_imsi_prefix_id(p_imsi ct_varchar_s, p_date date, p_trim_empty boolean) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_varchar_s(p_imsi));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_imsi_prefix_id0(p_imsi, v_date, p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_imsi_prefix_id2(p_imsi varchar2, p_date date) return number
is
  v_imsi ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_imsi, p_imsi);
  ------------------------------
  return get_imsi_prefix_id(v_imsi, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no4imsi_prefix_id0(p_imsi_prefix_id ct_number, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_imsi_prefix_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_imsi_prefix_id) != v_main_count, 'p_imsi_prefix_id.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_hash(q q2 z) full(q) full(q2) full(z)*/
    z.network_operator_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value imsi_prefix_id, rownum rn from table(cast(p_imsi_prefix_id as ct_number))) q,
    (select column_value on_date, rownum rn from table(cast(p_date as ct_date))) q2,
    imsi_prefix_network_operator z
  where 1 = 1
  and q2.rn = q.rn
  and z.imsi_prefix_id = q.imsi_prefix_id
  and q2.on_date between z.start_date and nvl(z.end_date, q2.on_date)
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'imsi_prefix_network_operator');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no4imsi_prefix_id(p_imsi_prefix_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_date ct_date;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  util_pkg.resize_ct_date(v_date, util_pkg.get_count_ct_number(p_imsi_prefix_id));
  util_pkg.fill_ct_date(v_date, p_date);
  ------------------------------
  return get_no4imsi_prefix_id0(p_imsi_prefix_id, v_date, p_trim_empty, p_xcheck_data);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_no4imsi_prefix_id2(p_imsi_prefix_id number, p_date date) return number
is
  v_imsi_prefix_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_imsi_prefix_id, p_imsi_prefix_id);
  ------------------------------
  return get_no4imsi_prefix_id(v_imsi_prefix_id, p_date, FALSE)(util_ri.c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_imsi_prefixes4imsi_list_i
(
  p_imsi ct_varchar_s,
  p_date ct_date,
  p_imsi_prefix_id out ct_number
)
is
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_imsi, 'p_imsi');
  util_pkg.XCheckP_FS_ct_date(p_date, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_imsi) != v_main_count, 'p_imsi.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  p_imsi_prefix_id := get_imsi_prefix_id0(p_imsi => p_imsi, p_date => p_date, p_trim_empty => false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_imsi_prefixes_by_imsi_list
(
  p_imsi_list util_pkg.cit_varchar_s,
  p_date_list util_pkg.cit_date,
  p_error_code out number,
  p_error_message out varchar2,
  p_result_list out sys_refcursor
)
is
  v_imsi ct_varchar_s;
  v_imsi_prefix_id ct_number;
  v_date ct_date;
  v_mark ct_number;
  v_pivot ct_number;
begin
  ------------------------------
  v_imsi := util_pkg.cast_cit2ct_varchar_s(p_coll => p_imsi_list, p_smart_cit => false);
  v_date := util_pkg.cast_cit2ct_date(p_coll => p_date_list, p_smart_cit => false);
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(v_imsi, 'v_imsi');
  util_pkg.XCheckP_ct_date(v_date, 'v_date');
  ------------------------------
  v_pivot := util_pkg.make_pivot(util_pkg.get_count_ct_date(v_date));
  v_mark := util_pkg.mark_val_ct_date(p_vals => v_date, p_marker_val => null, p_mark_value => util_pkg.c_true, p_unmark_value => util_pkg.c_false);
  v_pivot := util_pkg.get_marked_ct_number(p_vals => v_pivot, p_marks => v_mark, p_trim_empty => true, p_mark_value => util_pkg.c_true, p_no_value => null);
  util_pkg.set_val_by_pos2_ct_date(p_coll => v_date, p_val => sysdate, p_positions => v_pivot);
  ------------------------------
  get_imsi_prefixes4imsi_list_i
  (
    p_imsi => v_imsi,
    p_date => v_date,
    p_imsi_prefix_id => v_imsi_prefix_id
  );
  ------------------------------
  p_result_list := get_result_cursor01
  (
    p_imsi => v_imsi,
    p_date => v_date,
    p_imsi_prefix_id => v_imsi_prefix_id
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_roam_partner4imsi_list
(
    p_imsi ct_varchar_s,
    p_date ct_date,
    p_roam_partner_flag out ct_number
)
is
  v_main_count number;
  v_imsi_prefix_id ct_number;
  v_date ct_date;
  v_mark ct_number;
  v_pivot ct_number;
  v_network_operator_id ct_number;
  v_no_type ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_imsi, 'p_imsi');
  util_pkg.XCheckP_ct_date(p_date, 'p_date');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_imsi);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_imsi) != v_main_count, 'p_imsi.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_date) != v_main_count, 'p_date.count != v_main_count');
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  util_pkg.add_ct_date(v_date, p_date);
  v_mark := util_pkg.mark_val_ct_date(p_vals => v_date, p_marker_val => null, p_mark_value => util_pkg.c_true, p_unmark_value => util_pkg.c_false);
  v_pivot := util_pkg.get_marked_ct_number(p_vals => v_pivot, p_marks => v_mark, p_trim_empty => true, p_mark_value => util_pkg.c_true, p_no_value => null);
  util_pkg.set_val_by_pos2_ct_date(p_coll => v_date, p_val => sysdate, p_positions => v_pivot);
  ------------------------------
  get_imsi_prefixes4imsi_list_i
  (
    p_imsi => p_imsi,
    p_date => v_date,
    p_imsi_prefix_id => v_imsi_prefix_id
  );
  ------------------------------
  v_network_operator_id := get_no4imsi_prefix_id0
  (
    p_imsi_prefix_id => v_imsi_prefix_id,
    p_date => v_date,
    p_trim_empty => FALSE
  );
  ------------------------------
  v_no_type := util_ri.get_network_operator_type_x0(p_network_operator_id => v_network_operator_id, p_date => v_date, p_trim_empty => FALSE);
  ------------------------------
  p_roam_partner_flag := util_pkg.make_ct_number(v_main_count, c_not_roam_partner);
  v_pivot := util_pkg.make_pivot(v_main_count);
  v_mark := util_pkg.mark_val_ct_varchar_s(p_vals => v_no_type, p_marker_val => util_ri.c_NOPT_CODE_EXTERNAL, p_mark_value => util_pkg.c_true, p_unmark_value => util_pkg.c_false);
  v_pivot := util_pkg.get_marked_ct_number(p_vals => v_pivot, p_marks => v_mark, p_trim_empty => true, p_mark_value => util_pkg.c_true, p_no_value => null);
  util_pkg.set_val_by_pos2_ct_number(p_coll => p_roam_partner_flag, p_val => c_roam_partner, p_positions => v_pivot);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_result_cursor01(p_imsi ct_varchar_s, p_date ct_date, p_imsi_prefix_id ct_number) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q00 q01 q02 ip) full(ip)*/
      q00.imsi,
      q01.datetime,
      q02.imsi_prefix_id,
      ip.imsi_prefix imsi_prefix
    from
      (select column_value imsi, rownum rn from table(p_imsi)) q00,
      (select column_value datetime, rownum rn from table(p_date)) q01,
      (select column_value imsi_prefix_id, rownum rn from table(p_imsi_prefix_id)) q02,
      imsi_prefix ip
    where 1 = 1
      and q01.rn(+) = q00.rn
      and q02.rn(+) = q00.rn
      and ip.imsi_prefix_id(+) = q02.imsi_prefix_id
    order by q00.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor02(p_imsi ct_varchar_s, p_roam_partner_flag ct_number) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered use_hash(q00 q01)*/
      q00.imsi imsi,
      q01.roam_partner_flag IsRoamingPartner
    from
      (select column_value imsi, rownum rn from table(p_imsi)) q00,
      (select column_value roam_partner_flag, rownum rn from table(p_roam_partner_flag)) q01
    where 1 = 1
      and q01.rn(+) = q00.rn
    order by q00.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

END;
/
