CREATE PACKAGE BODY TIME_ZONE_OFFSET_PKG IS

PROCEDURE Get_date_from_dst_rule(
  p_year                        IN   VARCHAR2,
  p_dst_rule_mask               IN   VARCHAR2,
  p_dst_rule_date               IN   VARCHAR2,
  p_date                        OUT  DATE
)
IS
  v_event_source                varchar2(60) :='TIME_ZONE_OFFSET_PKG.Get_time_zone_offset_list';

  v_year                        VARCHAR2(100);
  v_day                         VARCHAR2(100);
  v_day_of_week                 NUMBER;
  v_date                        DATE;
  v_string                      VARCHAR2(100);
  v_rule_date                   VARCHAR2(100);
  v_day_of_month                VARCHAR2(100);
  v_number_of_week              NUMBER;

  v_counter                     NUMBER;
  v_flag                        NUMBER;

BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
  p_date := null;

  if p_year is null
  then
    v_year := TO_CHAR(SYSDATE, 'YYYY');
  else
    v_year := p_year;
  end if;

  if p_dst_rule_mask = UPPER('DATE')
  then
    --p_dst_rule_mask = DATE
    v_string := v_year || p_dst_rule_date;
    p_date := TO_DATE(v_string, 'YYYYDDMMHH24MISS');
    return;
  end if;

  --p_dst_rule_mask = WEEK_MONTH_WEEKDAY
  v_day_of_week := TO_NUMBER(substr(p_dst_rule_date, 1, 1));
  -- v_day_of_week
  -- 1 - Monday
  -- 2 - Tuesday
  -- 3 - Wednesday
  -- 4 - Thursday
  -- 5 - Friday
  -- 6 - Saturday
  -- 7 - Sunday
  v_day_of_week := v_day_of_week + 1;
  if v_day_of_week = 8
  then
    v_day_of_week := 1;
  end if;
  -- v_day_of_week
  -- 2 - Monday
  -- 3 - Tuesday
  -- 4 - Wednesday
  -- 5 - Thursday
  -- 6 - Friday
  -- 7 - Saturday
  -- 1 - Sunday

  v_number_of_week := 0;

  if substr(p_dst_rule_date, 2, 2) = '+1'
  then
    v_number_of_week := 1;
  end if;
  if substr(p_dst_rule_date, 2, 2) = '+2'
  then
    v_number_of_week := 2;
  end if;
  if substr(p_dst_rule_date, 2, 2) = '+3'
  then
    v_number_of_week := 3;
  end if;
  if substr(p_dst_rule_date, 2, 2) = '+4'
  then
    v_number_of_week := 4;
  end if;

  v_rule_date := substr(p_dst_rule_date, 4);

  v_counter := 0;
  v_flag := 0;
  v_day := '01';
  v_day_of_month := '01';

  loop

    v_string := v_year || v_day || v_rule_date;
    --dbms_output.put_line(v_string);
    begin
      v_date := TO_DATE(v_string, 'YYYYDDMMHH24MISS');
      v_string := TO_CHAR(v_date, 'D');
      --dbms_output.put_line(v_string);
    exception
      when others then
        exit;
    end;
    --dbms_output.put_line(v_string);

    if TO_NUMBER(v_string) = v_day_of_week
    then
      v_day_of_month := TO_CHAR(v_date, 'DD');
      v_counter := v_counter + 1;
      if v_counter = v_number_of_week
      then
        v_flag := 0;
        exit;
      end if;
    end if;

    v_day := v_day + 1;
    if v_day < 10
    then
      v_day := '0' || v_day;
    end if;

  end loop;

  v_string := v_year || v_day_of_month || v_rule_date;
  p_date := TO_DATE(v_string, 'YYYYDDMMHH24MISS');

  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);
END;

PROCEDURE Get_time_zone_offset_list_root(
  p_date_from                   IN   DATE,
  p_date_to                     IN   DATE,
  p_error_code                  OUT  NUMBER,
  p_error_message               OUT  VARCHAR2,
  p_time_zone_offset_list       OUT  SYS_REFCURSOR
)
IS
  v_sqlcode                 number;
  v_event_source            varchar2(60) :='TIME_ZONE_OFFSET_PKG.Get_time_zone_offset_list_root';

  v_number                  number;
  v_network_operator_code   varchar2(60);

BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  p_error_message := 'Successfully completed';
  p_error_code := RSIG_UTILS.c_OK;

  select count(1) into v_number
    from ri_settings rs
      where rs.setting_name = 'ROOT_NETWORK_OPERATOR_CODE';

  if v_number = 0
  then
    p_error_message := 'Setting with name ROOT_NETWORK_OPERATOR_CODE is not found in table RS_SETTINGS';
    p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
    RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
  end if;

  select rs.setting_value into v_network_operator_code
     from ri_settings rs
       where rs.setting_name = 'ROOT_NETWORK_OPERATOR_CODE';

  if v_network_operator_code is null
  then
    p_error_message := 'Value ROOT_NETWORK_OPERATOR_CODE is not specified in table RS_SETTINGS';
    p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
    RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
  end if;

  Get_time_zone_offset_list( v_network_operator_code,
                                                p_date_from,
                                                p_date_to,
                                                p_error_code,
                                                p_error_message,
                                                p_time_zone_offset_list );

  --set error code to succesfully completed
  --p_error_message := 'Successfully completed';
  --p_error_code := RSIG_UTILS.c_OK;

  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
    WHEN OTHERS THEN
        v_sqlcode := sqlcode;
        p_error_message := sqlerrm;
        --DBMS_OUTPUT.PUT_LINE(p_error_message);
        p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
        RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
        --OPEN p_result_list FOR SELECT v_sqlcode, p_error_message FROM dual;
END;

PROCEDURE Get_time_zone_offset_list(
  p_network_operator_code       IN   VARCHAR2,
  p_date_from                   IN   DATE,
  p_date_to                     IN   DATE,
  p_error_code                  OUT  NUMBER,
  p_error_message               OUT  VARCHAR2,
  p_time_zone_offset_list       OUT  SYS_REFCURSOR
)
IS
  v_sqlcode                 number;
  v_event_source            varchar2(60) :='TIME_ZONE_OFFSET_PKG.Get_time_zone_offset_list';

  v_country_code            varchar2(100);
  v_dst_name                varchar2(100);
  v_date_start_rule_mask    varchar2(100);
  v_date_start              varchar2(100);
  v_date_end_rule_mask      varchar2(100);
  v_date_end                varchar2(100);


  v_number                  number;

  v_dst_rule_id             number;
  v_network_operator_id     number;
  v_time_zone               number;

  v_year                    varchar2(100);
  v_year_from               varchar2(100);
  v_year_to                 varchar2(100);

  v_date                    date;
  v_date_start_rule         date;
  v_date_end_rule           date;

  v_date_from               date;
  v_date_to                 date;
  v_time_zone_offset        number;

  c_TIME_ZONE_MULTIPLIER    CONSTANT NUMBER(5) :=  1;
  c_TIME_ZONE_INCREASE      CONSTANT NUMBER(5) :=  60;

BEGIN
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_START, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

  p_error_message := 'Successfully completed';
  p_error_code := RSIG_UTILS.c_OK;

  --Check input parameters
  IF p_network_operator_code IS NULL
  THEN
    p_error_message := 'Invalid input parameter (p_network_operator_code is not specified)';
    p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
    RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
  END IF;

  IF p_date_from IS NULL
  THEN
    p_error_message := 'Invalid input parameter (p_date_from is not specified)';
    p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
    RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
  END IF;

  IF p_date_to IS NULL
  THEN
    p_error_message := 'Invalid input parameter (p_date_to is not specified)';
    p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
    RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
  END IF;

  IF p_date_from >= p_date_to
  THEN
    p_error_message := 'Invalid input parameter (p_date_from is bigger an p_date_to)';
    p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
    RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
  END IF;

  select count(1) into v_number
    from NETWORK_OPERATOR no where no.network_operator_code = p_network_operator_code;

  if v_number = 0
  then
    --network operator code is no found
    p_error_message := 'Network operator does not exist';
    p_error_code := RSIG_UTILS.c_ORA_NET_OPERATOR_NOT_EXIST;
    RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
  end if;

  --get network_operator_id by network_operator_code
  select no.network_operator_id into v_network_operator_id
    from NETWORK_OPERATOR no where no.network_operator_code = p_network_operator_code;

  --check cache table
  select count(1) into v_number
    from CACHE_TIME_ZONE_OFFSET ctzo
      where ctzo.query_date_from = p_date_from
        and ctzo.query_date_to = p_date_to
        and ctzo.network_operator_id = v_network_operator_id;

  --read from cache table
  if v_number <> 0
  then
     open p_time_zone_offset_list for
        select ctzo.date_from date_from,
               ctzo.date_to date_to,
               ctzo.time_zone_offset time_zone_offset
          from CACHE_TIME_ZONE_OFFSET ctzo
            where ctzo.query_date_from = p_date_from
              and ctzo.query_date_to = p_date_to
              and ctzo.network_operator_id = v_network_operator_id;
     goto end_procedure;
  end if;

  select no.dst_rule_id, no.time_zone into v_dst_rule_id, v_time_zone
    from NETWORK_OPERATOR no where no.network_operator_id = v_network_operator_id;

  if v_time_zone is null
  then
     --time zone is null (time zone is not specified)
    p_error_message := 'Time zone is null (time zone is not specified)';
    p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
    RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
  end if;

  if v_dst_rule_id is null
  then
    --DST rule is not specified
    open p_time_zone_offset_list for
      select p_date_from date_from,
             p_date_to date_to,
             v_time_zone * c_TIME_ZONE_MULTIPLIER time_zone_offset
          from dual;
    goto end_procedure;
  end if;

  select count(1) into v_number
    from DST_RULE dr where dr.dst_rule_id = v_dst_rule_id;

  if v_number = 0
  then
    --dst_rule_id is not found
    p_error_message := 'DST rule witch ID ' || v_dst_rule_id || ' is not found in DTS_RULE table';
    p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
    RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
  end if;

  select dr.country_code,
         dr.dst_name,
         dr.date_start_rule_mask,
         dr.date_start,
         dr.date_end_rule_mask,
         dr.date_end
    into v_country_code,
         v_dst_name,
         v_date_start_rule_mask,
         v_date_start,
         v_date_end_rule_mask,
         v_date_end
      from DST_RULE dr where dr.dst_rule_id = v_dst_rule_id;

  v_date_start_rule_mask := trim(v_date_start_rule_mask);
  v_date_start := trim(v_date_start);
  v_date_end_rule_mask := trim(v_date_end_rule_mask);
  v_date_end := trim(v_date_end);

  --check DST_RULE parameters
  if v_date_start_rule_mask is null or
     v_date_start_rule_mask <> UPPER('DATE') and
     v_date_start_rule_mask <> UPPER('WEEK_MONTH_WEEKDAY')
  then
    --date_start_rule_mask is not specified or incorrect
    p_error_message := 'DATE_START_RULE_MASK is not specified or incorrect for DST rule witch ID ' || v_dst_rule_id;
    p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
    RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
  end if;

  if v_date_start_rule_mask = UPPER('DATE')
  then
   --DATE_START_RULE_MASK = 'DATE'
    if v_date_start is null or length(v_date_start) <> 10
    then
      --date_start is not specified or incorrect
      p_error_message := 'DATE_START is not specified or incorrect for DST rule witch ID ' || v_dst_rule_id;
      p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
      RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
      return;
    end if;
    begin
      --check correct value date/time
      v_date := TO_DATE(v_date_start,'DDMMHH24MISS');
    exception
      when others then
        p_error_message := 'DATE_START is incorrect for DST rule witch ID ' || v_dst_rule_id;
        p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
        RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
    end;
  else
    --DATE_START_RULE_MASK = 'WEEK_MONTH_WEEKDAY'
    if v_date_start is null or length(v_date_start) <> 11
    then
      --date_start is not specified or incorrect
      p_error_message := 'DATE_START is not specified or incorrect for DST rule witch ID ' || v_dst_rule_id;
      p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
      RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
    end if;
    if substr(v_date_start, 1, 1) < 1 or substr(v_date_start, 1, 1) > 7
    then
      --Day of week day is incorrect
      p_error_message := 'Day of week is incorrect in DATE_START for DST rule witch ID ' || v_dst_rule_id;
      p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
      RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
    end if;
    if substr(v_date_start, 2, 2) <> '+1' and
       substr(v_date_start, 2, 2) <> '+2' and
       substr(v_date_start, 2, 2) <> '+3' and
       substr(v_date_start, 2, 2) <> '+4' and
       substr(v_date_start, 2, 2) <> '-1'
    then
      --Number of week is incorrect
      p_error_message := 'Number of week is incorrect in DATE_START for DST rule witch ID ' || v_dst_rule_id;
      p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
      RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
    end if;
    begin
      --check correct value date/time
      v_date := TO_DATE( SUBSTR(v_date_start, 4),'MMHH24MISS');
    exception
      when others then
        p_error_message := 'DATE_START is incorrect for DST rule witch ID ' || v_dst_rule_id;
        p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
        RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
    end;
  end if;

  if v_date_end_rule_mask is null or
     v_date_end_rule_mask <> UPPER('DATE') and
     v_date_end_rule_mask <> UPPER('WEEK_MONTH_WEEKDAY')
  then
    --date_end_rule_mask is not specified or incorrect
    p_error_message := 'DATE_END_RULE_MASK is not specified or incorrect for DST rule witch ID ' || v_dst_rule_id;
    p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
    RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
  end if;

  if v_date_end_rule_mask = UPPER('DATE')
  then
   --DATE_END_RULE_MASK = 'DATE'
    if v_date_end is null or length(v_date_end) <> 10
    then
      --date_end is not specified or incorrect
      p_error_message := 'DATE_END is not specified or incorrect for DST rule witch ID ' || v_dst_rule_id;
      p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
      RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
      return;
    end if;
    begin
      --check correct value date/time
      v_date := TO_DATE(v_date_end,'DDMMHH24MISS');
    exception
      when others then
        p_error_message := 'DATE_END is incorrect for DST rule witch ID ' || v_dst_rule_id;
        p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
        RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
    end;
  else
    --DATE_END_RULE_MASK = 'WEEK_MONTH_WEEKDAY'
    if v_date_end is null or length(v_date_end) <> 11
    then
     --date_end is not specified or incorrect
      p_error_message := 'DATE_END is not specified or incorrect for DST rule witch ID ' || v_dst_rule_id;
      p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
      RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
    end if;
    if substr(v_date_end, 1, 1) < 1 or substr(v_date_end, 1, 1) > 7
    then
      --Day of week day is incorrect
      p_error_message := 'Day of week is incorrect in DATE_END for DST rule witch ID ' || v_dst_rule_id;
      p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
      RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
    end if;
    if substr(v_date_end, 2, 2) <> '+1' and
       substr(v_date_end, 2, 2) <> '+2' and
       substr(v_date_end, 2, 2) <> '+3' and
       substr(v_date_end, 2, 2) <> '+4' and
       substr(v_date_end, 2, 2) <> '-1'
    then
      --Number of week is incorrect
      p_error_message := 'Number of week is incorrect in DATE_END for DST rule witch ID ' || v_dst_rule_id;
      p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
      RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
    end if;
    begin
      --check correct value date/time
      v_date := TO_DATE( SUBSTR(v_date_end, 4),'MMHH24MISS');
      util_loc_pkg.touch_date(v_date); --!_!
    exception
      when others then
        p_error_message := 'DATE_END is incorrect for DST rule witch ID ' || v_dst_rule_id;
        p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
        RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
    end;
  end if;

  Get_date_from_dst_rule(null, UPPER(v_date_start_rule_mask), v_date_start, v_date_start_rule);
  Get_date_from_dst_rule(null, UPPER(v_date_end_rule_mask), v_date_end, v_date_end_rule);

  if v_date_start_rule >= v_date_end_rule
  then
    p_error_message := 'DATE_START is bigger an DATE_END in DST rule witch ID ' || v_dst_rule_id;
    p_error_code := RSIG_UTILS.c_ORA_INVALID_PARAMETER;
    RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
  end if;

  v_year_from := TO_CHAR(p_date_from, 'YYYY');
  v_year_to := TO_CHAR(p_date_to, 'YYYY');
  util_loc_pkg.touch_varchar(v_year_to); --!_!

  v_year := v_year_from;
  v_date_from := p_date_from;

  --empty temporary table
  delete from tt_time_zone_offset;

  Get_date_from_dst_rule(v_year, UPPER(v_date_start_rule_mask), v_date_start, v_date_start_rule);
  v_date_start_rule := v_date_start_rule - (1 / (24 * 60 * 60));
  Get_date_from_dst_rule(v_year, UPPER(v_date_end_rule_mask), v_date_end, v_date_end_rule);
  v_date_end_rule := v_date_end_rule - (1 / (24 * 60 * 60));

  loop

    if v_date_start_rule > v_date_from and v_date_start_rule < p_date_to
    then
      --add interval
      insert into tt_time_zone_offset tzo
      (
        tzo.network_operator_id,
        tzo.date_from,
        tzo.date_to,
        tzo.time_zone_offset
      )
      values
      (
        v_network_operator_id,
        v_date_from,
        v_date_start_rule,
        v_time_zone * c_TIME_ZONE_MULTIPLIER
      );
      v_date_from :=  v_date_start_rule + (1 / (24 * 60 * 60));
      if v_date_end_rule > p_date_to and v_date_from <= p_date_to
      then
        --add interval
        insert into tt_time_zone_offset tzo
        (
          tzo.network_operator_id,
          tzo.date_from,
          tzo.date_to,
          tzo.time_zone_offset
        )
        values
        (
          v_network_operator_id,
          v_date_from,
          p_date_to,
          (v_time_zone + c_TIME_ZONE_INCREASE) * c_TIME_ZONE_MULTIPLIER
        );
        exit;
      end if;
    end if;

    if v_date_end_rule > v_date_from and v_date_end_rule < p_date_to
    then
      --add interval
      insert into tt_time_zone_offset tzo
      (
        tzo.network_operator_id,
        tzo.date_from,
        tzo.date_to,
        tzo.time_zone_offset
      )
      values
      (
        v_network_operator_id,
        v_date_from,
        v_date_end_rule,
        (v_time_zone + c_TIME_ZONE_INCREASE) * c_TIME_ZONE_MULTIPLIER
      );
      v_date_from :=  v_date_end_rule + (1 / (24 * 60 * 60));

      v_year := v_year + 1;

      Get_date_from_dst_rule(v_year, UPPER(v_date_start_rule_mask), v_date_start, v_date_start_rule);
      v_date_start_rule := v_date_start_rule - (1 / (24 * 60 * 60));
      Get_date_from_dst_rule(v_year, UPPER(v_date_end_rule_mask), v_date_end, v_date_end_rule);
      v_date_end_rule := v_date_end_rule - (1 / (24 * 60 * 60));

      if v_date_start_rule > p_date_to and v_date_from <= p_date_to
      then
        --add interval
        insert into tt_time_zone_offset tzo
        (
          tzo.network_operator_id,
          tzo.date_from,
          tzo.date_to,
          tzo.time_zone_offset
        )
        values
        (
          v_network_operator_id,
          v_date_from,
          p_date_to,
          v_time_zone * c_TIME_ZONE_MULTIPLIER
        );
        exit;
      end if;

    else
      exit;
    end if;

  end loop;

  open p_time_zone_offset_list for
  select tzo.date_from date_from,
         tzo.date_to date_to,
         tzo.time_zone_offset time_zone_offset
      from tt_time_zone_offset tzo;

  --fill cache table
  loop
    fetch p_time_zone_offset_list into
      v_date_from,
      v_date_to,
      v_time_zone_offset;

    exit when p_time_zone_offset_list%notfound;

    select count(1) into v_number
      from CACHE_TIME_ZONE_OFFSET ctzo
        where ctzo.query_date_from = p_date_from
          and ctzo.query_date_to = p_date_to
          and ctzo.network_operator_id = v_network_operator_id
          and ctzo.date_from = v_date_from
          and ctzo.date_to = v_date_to;

     if v_number = 0
     then
       insert into CACHE_TIME_ZONE_OFFSET ctzo
       (
         ctzo.query_date_from,
         ctzo.query_date_to,
         ctzo.network_operator_id,
         ctzo.date_from,
         ctzo.date_to,
         ctzo.time_zone_offset
       )
       values
       (
         p_date_from,
         p_date_to,
         v_network_operator_id,
         v_date_from,
         v_date_to,
         v_time_zone_offset
       );
     end if;

  end loop;

  open p_time_zone_offset_list for
  select tzo.date_from date_from,
         tzo.date_to date_to,
         tzo.time_zone_offset time_zone_offset
      from tt_time_zone_offset tzo;

<<end_procedure>>

  -- set error code to succesfully completed
  p_error_message := 'Successfully completed';
  p_error_code := RSIG_UTILS.c_OK;
  RSIG_UTILS.Debug_Rsi (RSIG_UTILS.c_DEBUG_TEXT_END, RSIG_UTILS.c_DEBUG_LEVEL_1, RSIG_UTILS.c_DEBUG_EVENT_TYPE_D,v_event_source);

EXCEPTION
    WHEN OTHERS THEN
        v_sqlcode := sqlcode;
        p_error_message := sqlerrm;
        --DBMS_OUTPUT.PUT_LINE(p_error_message);
        p_error_code := RSIG_UTILS.Handle_Error(v_sqlcode);
        RSIG_UTILS.Debug_Rsi (TO_CHAR(p_error_code), RSIG_UTILS.c_DEBUG_LEVEL_0, RSIG_UTILS.c_DEBUG_EVENT_TYPE_ER,v_event_source);
        --OPEN p_result_list FOR SELECT v_sqlcode, p_error_message FROM dual;
END;

END;
/
