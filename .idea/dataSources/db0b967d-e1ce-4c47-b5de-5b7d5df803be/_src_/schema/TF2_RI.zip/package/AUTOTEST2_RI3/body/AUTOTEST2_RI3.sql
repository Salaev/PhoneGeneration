CREATE package body AUTOTEST2_RI3 is

--------------- Наполнение таблицы свободных номеров
procedure fill_autotest2_phones
is
begin
for c in (select distinct d.host_id,d.phone_number_type_code from phone_number_series d)
loop
insert into autotest2_phones(PHONE_NUMBER,PHONE_NUMBER_TYPE_CODE,
                             salability_category_code, HLR)
select * from (
select pn.international_format PHONE_NUMBER,
pns.phone_number_type_code PHONE_NUMBER_TYPE_CODE,
pn.salability_category_code,
pns.host_id HLR
 from phone_number pn
join phone_number_series pns on pn.phone_number_series_id=pns.phone_number_series_id
where (select count(network_address_id)
       from network_address_access_point n
       where pn.network_address_id=n.network_address_id)=0
      and host_id=c.host_id
      and phone_number_type_code=c.phone_number_type_code
) where rownum<101
;
end loop;
commit;
end fill_autotest2_phones;
--------- получение атрибутов свободного номера
procedure fill_phones_attributes_RI(iPHONE_NUMBER varchar2, error out sys_refcursor)
is
begin
delete from autotest2_phones p where p.PHONE_NUMBER=iPHONE_NUMBER;

insert into autotest2_phones(PHONE_NUMBER,PHONE_NUMBER_TYPE_CODE,
                             salability_category_code, HLR)

select pn.international_format PHONE_NUMBER,
pns.phone_number_type_code PHONE_NUMBER_TYPE_CODE,
pn.salability_category_code,
pns.host_id HLR
 from phone_number pn
join phone_number_series pns on pn.phone_number_series_id=pns.phone_number_series_id
where (select count(network_address_id)
       from network_address_access_point n
       where pn.network_address_id=n.network_address_id)=0
and  rownum=1
and pn.international_format=iPHONE_NUMBER
;
if sql%rowcount=0
then
open error for select 'PHONE_NUMBER was not found in database or it is wrong' from dual;
return;
end if;
commit;
 open error for select 'NO ERRORS' from dual;
end fill_phones_attributes_RI;



--------------- Наполнение таблицы свободных сим
--- предварительно вызывается процедура TF2_STOCK.AUTOTEST2_STOCK.fill_autotest2_sim_stock
procedure fill_autotest2_sim_ri(istock_id number default null)
is
begin
if istock_id is null then
delete from autotest2_sim t
where (select personal_account from sim_card sc
                                where sc.sn=t.sim_number) is not  null
 or (select count(*) from network_address_access_point n
                     where n.access_point_id in (select access_point_id
                                                from sim_card sc
                                                where t.sim_number=sc.sn))>0
                                                  ;

update autotest2_sim t
set t.hlr=(select ss.host_id from sim_series ss
                         join sim_card sc
                         on ss.sim_series_id=sc.sim_series_id
                         where sc.sn=t.sim_number),
    t.imsi=(select sc.imsi from sim_series ss
                         join sim_card sc
                         on ss.sim_series_id=sc.sim_series_id
                         where sc.sn=t.sim_number),
     start_imsi_number =(select start_imsi_number from sim_series ss where ss.sim_series_id in
                        (select sim_series_id from sim_card sc
                        where sc.sn=t.sim_number))
     ,end_imsi_number =(select end_imsi_number from sim_series ss where ss.sim_series_id in
                        (select sim_series_id from sim_card sc
                        where sc.sn=t.sim_number))
     ,change_date=sysdate ;

    update autotest2_sim t
    set t.host_name=(select host_name
                 from host r where  r.host_id=t.hlr)
                         ;
commit;
else
delete from autotest2_sim t
where (select personal_account from sim_card sc
                                where sc.sn=t.sim_number) is not  null
 or (select count(*) from network_address_access_point n
                     where n.access_point_id in (select access_point_id
                                                from sim_card sc
                                                where t.sim_number=sc.sn))>0
and t.stock_id=istock_id;

update autotest2_sim t
set t.hlr=(select ss.host_id from sim_series ss
                         join sim_card sc
                         on ss.sim_series_id=sc.sim_series_id
                         where sc.sn=t.sim_number),
    t.imsi=(select sc.imsi from sim_series ss
                         join sim_card sc
                         on ss.sim_series_id=sc.sim_series_id
                         where sc.sn=t.sim_number),
     start_imsi_number =(select start_imsi_number from sim_series ss where ss.sim_series_id in
                        (select sim_series_id from sim_card sc
                        where sc.sn=t.sim_number))
     ,end_imsi_number =(select end_imsi_number from sim_series ss where ss.sim_series_id in
                        (select sim_series_id from sim_card sc
                        where sc.sn=t.sim_number))
     ,change_date=sysdate
where t.stock_id=istock_id;

    update autotest2_sim t
    set t.host_name=(select host_name
                 from host r where  r.host_id=t.hlr)
      ,change_date=sysdate
    where t.stock_id=istock_id;

commit;
end if;

    delete from autotest2_sim t
    where t.hlr is null;

--- удаляем, если симкарт в таблице с данным номером >1
    delete from autotest2_sim where sim_number in
    (select sim_number from (
    select count(*) over(partition by sim_number) cnt, sim_number
     from autotest2_sim
     )
     where cnt>1);
    delete from autotest2_stock;
    commit;
end fill_autotest2_sim_ri;

procedure fill_sim_attributes_ri(iSIM_NUMBER varchar2)
is
begin
/*delete from autotest2_sim t
where
(
(select personal_account from sim_card sc
                                where sc.sn=t.sim_number) is not  null
 or (select count(*) from network_address_access_point n
                     where n.access_point_id in (select access_point_id
                                                from sim_card sc

                                                where t.sim_number=sc.sn))>0
)
and t.sim_number=iSIM_NUMBER;*/

--
update autotest2_sim t
set t.hlr=(select ss.host_id from sim_series ss
                         join sim_card sc
                         on ss.sim_series_id=sc.sim_series_id
                         where sc.sn=t.sim_number),
    t.imsi=(select sc.imsi from sim_series ss
                         join sim_card sc
                         on ss.sim_series_id=sc.sim_series_id
                         where sc.sn=t.sim_number),
     start_imsi_number =(select start_imsi_number from sim_series ss where ss.sim_series_id in
                        (select sim_series_id from sim_card sc
                        where sc.sn=t.sim_number))
     ,end_imsi_number =(select end_imsi_number from sim_series ss where ss.sim_series_id in
                        (select sim_series_id from sim_card sc
                        where sc.sn=t.sim_number))
     ,change_date=sysdate
     ,t.host_name=(select host_name
                   from host r where  r.host_id=t.hlr)
     , is_used=null
    where
    (
      (select personal_account from sim_card sc
                                      where sc.sn=t.sim_number) is null
       and (select count(*) from network_address_access_point n
                           where n.access_point_id in (select access_point_id
                                                      from sim_card sc

                                                      where t.sim_number=sc.sn))=0
     )
     and t.sim_number=iSIM_NUMBER;
    if sql%rowcount=0 then -- Симка не найдена или непригодна для продажи
        packlog('FILL_SIM_ATTR:  SIM was used OR not FOUND: '||iSIM_NUMBER);
        return;
    else
        packlog('FILL_SIM_ATTR  OK:  SIM has beeen updated: '||iSIM_NUMBER);
    end if;

commit;


end fill_sim_attributes_ri;


/*procedure fill_autotest2_sim_ri_ID(istock_id number)
is
begin
delete from autotest2_sim t
where (select personal_account from sim_card sc
                                where sc.sn=t.sim_number) is not  null
 or (select count(*) from network_address_access_point n
                     where n.access_point_id in (select access_point_id
                                                from sim_card sc
                                                where t.sim_number=sc.sn))>0
and t.stock_id=istock_id;

update autotest2_sim t
set t.hlr=(select ss.host_id from sim_series ss
                         join sim_card sc
                         on ss.sim_series_id=sc.sim_series_id
                         where sc.sn=t.sim_number),
    t.imsi=(select sc.imsi from sim_series ss
                         join sim_card sc
                         on ss.sim_series_id=sc.sim_series_id
                         where sc.sn=t.sim_number),
     start_imsi_number =(select start_imsi_number from sim_series ss where ss.sim_series_id in
                        (select sim_series_id from sim_card sc
                        where sc.sn=t.sim_number))
     ,end_imsi_number =(select end_imsi_number from sim_series ss where ss.sim_series_id in
                        (select sim_series_id from sim_card sc
                        where sc.sn=t.sim_number))
where t.stock_id=istock_id;

    update autotest2_sim t
    set t.host_name=(select host_name
                 from host r where  r.host_id=t.hlr)
    where t.stock_id=istock_id;

    delete from autotest2_sim t
    where t.hlr is null;

--- удаляем, если симкарт в таблице с данным номером >1
    delete from autotest2_sim where sim_number in
    (select sim_number from (
    select count(*) over(partition by sim_number) cnt, sim_number
     from autotest2_sim
     )
     where cnt>1);
commit;

end fill_autotest2_sim_ri_ID;*/

procedure packlog(itext in varchar2, iTEST_ID number default null) is
    PRAGMA autonomous_transaction;
  begin
    insert into autotest2_debug_log
      (id, text, test_id, logdate)
    values
      (autotest2_debug_log_seq.nextval, to_char(itext), iTEST_ID, sysdate);
    commit;
  end packlog;

  end AUTOTEST2_RI3;
/
