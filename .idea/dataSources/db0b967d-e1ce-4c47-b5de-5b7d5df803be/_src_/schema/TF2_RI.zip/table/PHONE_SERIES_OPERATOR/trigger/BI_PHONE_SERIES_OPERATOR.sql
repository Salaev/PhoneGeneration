CREATE TRIGGER BI_PHONE_SERIES_OPERATOR
BEFORE INSERT
  ON PHONE_SERIES_OPERATOR
FOR EACH ROW
  DECLARE
  v_is_shared               VARCHAR2(1);
  v_num                     NUMBER;
BEGIN

  SELECT pnt.is_shared
  INTO v_is_shared
  FROM phone_number_series pns
  JOIN phone_number_type pnt ON trim(pnt.PHONE_NUMBER_TYPE_CODE)=pns.phone_number_type_code
  WHERE pns.phone_number_series_id=:NEW.phone_number_series_id;


  SELECT COUNT(*)
  INTO v_num
  FROM phone_series_operator pso
  WHERE pso.phone_number_series_id=:NEW.phone_number_series_id
    AND :NEW.start_date BETWEEN pso.start_date AND nvl(pso.end_date,:NEW.start_date);

  IF v_num>0 AND (v_is_shared<>rsig_utils.c_YES OR v_is_shared IS NULL) THEN
     RAISE_APPLICATION_ERROR(CONSTANTS.c_ERR_PS_CAN_NOT_BE_SHARED, 'This phone number series can not be shared by more then one network operator.');
  END IF;

END BIU_phone_series_operator;
/
