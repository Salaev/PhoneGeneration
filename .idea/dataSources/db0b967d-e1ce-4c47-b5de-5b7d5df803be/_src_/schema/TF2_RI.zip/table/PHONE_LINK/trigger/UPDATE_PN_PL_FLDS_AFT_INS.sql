CREATE TRIGGER UPDATE_PN_PL_FLDS_AFT_INS
AFTER INSERT
  ON PHONE_LINK
FOR EACH ROW
  declare
  v_old phone_link%rowtype;
  v_new phone_link%rowtype;
begin
  ------------------------------
  v_old.main_msisdn := :old.main_msisdn;
  v_old.linked_msisdn := :old.linked_msisdn;
  ------------------------------
  v_new.main_msisdn := :new.main_msisdn;
  v_new.linked_msisdn := :new.linked_msisdn;
  ------------------------------
  pn_life_pkg.update_pn_pl_flds_aft_ins(v_old, v_new);
  ------------------------------
end;
/
