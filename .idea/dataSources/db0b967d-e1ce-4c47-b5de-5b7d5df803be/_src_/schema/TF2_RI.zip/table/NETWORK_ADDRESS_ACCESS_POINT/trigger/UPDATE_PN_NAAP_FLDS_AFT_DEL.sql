CREATE TRIGGER UPDATE_PN_NAAP_FLDS_AFT_DEL
AFTER DELETE
  ON NETWORK_ADDRESS_ACCESS_POINT
FOR EACH ROW
  declare
  v_old network_address_access_point%rowtype;
  v_new network_address_access_point%rowtype;
begin
  ------------------------------
  v_old.access_point_id := :old.access_point_id;
  v_old.network_address_id := :old.network_address_id;
  v_old.link_type_code := :old.link_type_code;
  v_old.from_date := :old.from_date;
  v_old.to_date := :old.to_date;
  v_old.date_of_change := :old.date_of_change;
  v_old.user_id_of_change := :old.user_id_of_change;
  ------------------------------
  v_new.access_point_id := :new.access_point_id;
  v_new.network_address_id := :new.network_address_id;
  v_new.link_type_code := :new.link_type_code;
  v_new.from_date := :new.from_date;
  v_new.to_date := :new.to_date;
  v_new.date_of_change := :new.date_of_change;
  v_new.user_id_of_change := :new.user_id_of_change;
  ------------------------------
  pn_life_pkg.update_pn_naap_flds_aft_del(v_old, v_new);
  ------------------------------
end;
/
