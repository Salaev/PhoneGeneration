CREATE TRIGGER AUDI_HOST
AFTER INSERT OR UPDATE OR DELETE
  ON HOST
FOR EACH ROW
  DECLARE
  v_table_id       INT:=2;
  v_row_id         ROWID;
  v_operation      CHAR(1);
BEGIN
  IF INSERTING THEN
    v_row_id:=:NEW.ROWID;
    v_operation:='I';
  ELSIF UPDATING THEN
    v_row_id:=:NEW.ROWID;
    v_operation:='U';
  ELSE
    v_row_id:=:OLD.ROWID;
    v_operation:='D';
  END IF;

  INSERT INTO ROWS_TO_CACHE_BALANCE_STORAGE(id,table_id,row_id,operation_type)
  VALUES(s_rows_to_cache.nextval,v_table_id,v_row_id,v_operation);

END AUDI_HOST;
/
