CREATE TRIGGER UPDATE_PN_FLDS_BEF_INS
BEFORE INSERT
  ON PHONE_NUMBER
FOR EACH ROW
  declare
begin
  ------------------------------
  :new.naap_access_point_id := nvl(:new.naap_access_point_id, search_pkg.c_dummy_access_point_id);
  :new.naap_date_from := nvl(:new.naap_date_from, util_pkg.c_open_date_to);
  :new.pl_main_msisdn := nvl(:new.pl_main_msisdn, search_pkg.c_dummy_msisdn);
  :new.pl_linked_msisdn := nvl(:new.pl_linked_msisdn, search_pkg.c_dummy_msisdn);
  ------------------------------
end;
/
