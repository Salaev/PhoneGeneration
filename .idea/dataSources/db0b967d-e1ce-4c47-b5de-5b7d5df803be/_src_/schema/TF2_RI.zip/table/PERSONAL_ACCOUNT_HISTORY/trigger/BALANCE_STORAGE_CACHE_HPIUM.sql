CREATE TRIGGER BALANCE_STORAGE_CACHE_HPIUM
AFTER INSERT OR UPDATE
  ON PERSONAL_ACCOUNT_HISTORY
FOR EACH ROW
  declare
  ------------------------------
  v_old personal_account_history%rowtype;
  v_new personal_account_history%rowtype;
  ------------------------------
begin
  ------------------------------
  v_new.personal_account := :new.personal_account;
  v_new.start_date := :new.start_date;
  v_new.end_date := :new.end_date;
  v_new.balance_storage := :new.balance_storage;
  v_new.user_id_of_change := :new.user_id_of_change;
  v_new.date_of_changed := :new.date_of_changed;
  ------------------------------
  v_old.personal_account := :old.personal_account;
  v_old.start_date := :old.start_date;
  v_old.end_date := :old.end_date;
  v_old.balance_storage := :old.balance_storage;
  v_old.user_id_of_change := :old.user_id_of_change;
  v_old.date_of_changed := :old.date_of_changed;
  ------------------------------
  if inserting
  then
    hpium_cache_pkg.bs_cache_hpium_ins(v_old, v_new);
  elsif updating
  then
    hpium_cache_pkg.bs_cache_hpium_upd(v_old, v_new);
  else
    null;
  end if;
  ------------------------------
end;
/
