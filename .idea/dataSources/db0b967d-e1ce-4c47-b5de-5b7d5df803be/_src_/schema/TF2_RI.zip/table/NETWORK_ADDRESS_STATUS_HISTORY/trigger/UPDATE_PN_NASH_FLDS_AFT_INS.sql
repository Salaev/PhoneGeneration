CREATE TRIGGER UPDATE_PN_NASH_FLDS_AFT_INS
AFTER INSERT
  ON NETWORK_ADDRESS_STATUS_HISTORY
FOR EACH ROW
  declare
  v_old network_address_status_history%rowtype;
  v_new network_address_status_history%rowtype;
begin
  ------------------------------
  v_old.net_address_status_code := :old.net_address_status_code;
  v_old.network_address_id := :old.network_address_id;
  v_old.start_date := :old.start_date;
  v_old.date_of_change := :old.date_of_change;
  v_old.user_id_of_change := :old.user_id_of_change;
  v_old.end_date := :old.end_date;
  v_old.na_trans_reason_code := :old.na_trans_reason_code;
  ------------------------------
  v_new.net_address_status_code := :new.net_address_status_code;
  v_new.network_address_id := :new.network_address_id;
  v_new.start_date := :new.start_date;
  v_new.date_of_change := :new.date_of_change;
  v_new.user_id_of_change := :new.user_id_of_change;
  v_new.end_date := :new.end_date;
  v_new.na_trans_reason_code := :new.na_trans_reason_code;
  ------------------------------
  pn_life_pkg.update_pn_nash_flds_aft_ins(v_old, v_new);
  ------------------------------
end;
/
