CREATE TRIGGER AUDI_ZONE_BASE_STATION_CACHE
AFTER INSERT OR UPDATE OR DELETE
  ON ZONE_BASE_STATION
FOR EACH ROW
  DECLARE
  v_table_id       INT:=6;
  v_row_id         ROWID;
  v_operation      CHAR(1);
BEGIN
  IF INSERTING THEN
    v_row_id:=:NEW.ROWID;
    v_operation:='I';
  ELSIF UPDATING THEN
    v_row_id:=:NEW.ROWID;
    v_operation:='U';
  ELSE
    v_row_id:=:OLD.ROWID;
    v_operation:='D';
  END IF;

  INSERT INTO rows_to_cache_zones(id,table_id,row_id,operation_type)
  VALUES(s_rows_to_cache.nextval,v_table_id,v_row_id,v_operation);

END AUDI_zone_cache;
/
