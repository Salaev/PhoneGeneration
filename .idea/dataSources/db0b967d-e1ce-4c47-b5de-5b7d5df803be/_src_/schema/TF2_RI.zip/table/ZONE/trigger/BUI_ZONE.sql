CREATE TRIGGER BUI_ZONE
BEFORE INSERT OR UPDATE
  ON ZONE
FOR EACH ROW
  declare
  v_val varchar2(100);
begin
  ------------------------------
  v_val := translate(:new.ZONE_CODE, '_0123456789', '_');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_val is not null, 'ZONE_CODE contains not only numbers:' || v_val);
  ------------------------------
end;
/
