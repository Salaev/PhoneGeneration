CREATE TRIGGER PERSONAL_ACCOUNT_CACHE_HPIUM
AFTER UPDATE OF PERSONAL_ACCOUNT
  ON SIM_CARD
FOR EACH ROW
  declare
  ------------------------------
  v_old sim_card%rowtype;
  v_new sim_card%rowtype;
  ------------------------------
BEGIN
  ------------------------------
  v_new.access_point_id := :new.access_point_id;
  v_new.imsi := :new.imsi;
  v_new.sn := :new.sn;
  v_new.pin := :new.pin;
  v_new.pin2 := :new.pin2;
  v_new.puk2 := :new.puk2;
  v_new.puk := :new.puk;
  v_new.sim_series_id := :new.sim_series_id;
  v_new.msisdn_bound := :new.msisdn_bound;
  v_new.personal_account := :new.personal_account;
  v_new.user_id_of_change := :new.user_id_of_change;
  v_new.deleted := :new.deleted;
  v_new.date_of_change := :new.date_of_change;
  v_new.ki := :new.ki;
  v_new.adm1 := :new.adm1;
  v_new.access_control := :new.access_control;
  v_new.authent_type := :new.authent_type;
  ------------------------------
  v_old.access_point_id := :old.access_point_id;
  v_old.imsi := :old.imsi;
  v_old.sn := :old.sn;
  v_old.pin := :old.pin;
  v_old.pin2 := :old.pin2;
  v_old.puk2 := :old.puk2;
  v_old.puk := :old.puk;
  v_old.sim_series_id := :old.sim_series_id;
  v_old.msisdn_bound := :old.msisdn_bound;
  v_old.personal_account := :old.personal_account;
  v_old.user_id_of_change := :old.user_id_of_change;
  v_old.deleted := :old.deleted;
  v_old.date_of_change := :old.date_of_change;
  v_old.ki := :old.ki;
  v_old.adm1 := :old.adm1;
  v_old.access_control := :old.access_control;
  v_old.authent_type := :old.authent_type;
  ------------------------------
  hpium_cache_pkg.pa_cache_hpium_upd(v_old, v_new);
  ------------------------------
end;
/
