CREATE TRIGGER UPDATE_PN_PNSC_FLDS_AFT_DEL
AFTER DELETE
  ON PHONE_NUMBER_SALABILITY_CATEG
FOR EACH ROW
  declare
  v_old phone_number_salability_categ%rowtype;
  v_new phone_number_salability_categ%rowtype;
begin
  ------------------------------
  v_old.salability_category_code := :old.salability_category_code;
  v_old.network_address_id := :old.network_address_id;
  v_old.start_date := :old.start_date;
  v_old.date_of_change := :old.date_of_change;
  v_old.user_id_of_change := :old.user_id_of_change;
  v_old.end_date := :old.end_date;
  ------------------------------
  v_new.salability_category_code := :new.salability_category_code;
  v_new.network_address_id := :new.network_address_id;
  v_new.start_date := :new.start_date;
  v_new.date_of_change := :new.date_of_change;
  v_new.user_id_of_change := :new.user_id_of_change;
  v_new.end_date := :new.end_date;
  ------------------------------
  pn_life_pkg.update_pn_pnsc_flds_aft_del(v_old, v_new);
  ------------------------------
end;
/
