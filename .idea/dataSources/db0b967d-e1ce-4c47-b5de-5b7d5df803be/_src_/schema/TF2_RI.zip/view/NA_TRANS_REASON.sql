CREATE VIEW NA_TRANS_REASON AS SELECT na_trans_reason_code, na_trans_reason_name, na_status_trans_code, auto_trans_timeout,
                 DESCRIPTION, user_id_of_change, date_of_change, deleted, sn
          FROM na_trans_reason@cat


/
