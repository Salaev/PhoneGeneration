CREATE VIEW MR_HOME_MSC AS SELECT (pns.country_code || pns.area_code || pns.local_number_start
          ) "START_NUMBER",
          (pns.country_code || pns.area_code || pns.local_number_end
          ) "END_NUMBER",
          nto.network_operator_code, h.host_code
     FROM phone_number_series pns JOIN phone_series_operator pso ON pso.phone_number_series_id =
                                                                            pns.phone_number_series_id
          JOIN network_operator nto ON pso.network_operator_id =
                                                       nto.network_operator_id
          JOIN network_operator noup ON noup.network_operator_id =
                                                 nto.network_operator_id_upper
          JOIN HOST h ON h.network_operator_id = pso.network_operator_id
    WHERE host_type_code = 'VL'


/
