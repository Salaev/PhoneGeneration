CREATE VIEW COUNTRY AS SELECT country_id,
          country_code,
          country_name,
          user_id_of_change,
          deleted,
          date_of_change
     FROM TF2_CAT.COUNTRY

/
