CREATE VIEW FORIS_SIM_CARDS_1 AS select t.imsi,
       t.start_date,
       t.end_date,
       h.host_type_code BALANCE_STORAGE,
       t.To_Date,
       t.access_point_id,
       t.net_address_status_code
from naap_mv t
JOIN host h ON h.host_id=t.balance_storage
WHERE t.net_address_status_code<>'O'


/
