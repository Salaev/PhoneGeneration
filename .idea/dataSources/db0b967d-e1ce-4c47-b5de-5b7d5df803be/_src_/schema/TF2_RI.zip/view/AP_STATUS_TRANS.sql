CREATE VIEW AP_STATUS_TRANS AS SELECT ap_status_trans_code, status_code_from, status_code_to, is_bp_only, DESCRIPTION,
                 user_id_of_change, date_of_change, deleted, sn
          FROM ap_status_trans@cat


/
