CREATE VIEW FORIS_HPIUM_MV AS SELECT t.International_Format phone_number,
       t.imsi,
       pns.host_id,
       h.host_type_code balance_storage,
       t.from_date  naap_from_date,
       t.To_Date naap_to_date,
       t.start_date apsh_start_date,
       t.end_date   apsh_end_date
FROM naap_mv t
JOIN phone_number_series pns ON pns.phone_number_series_id=t.phone_number_series_id
JOIN host h ON h.host_id=t.balance_storage


/
