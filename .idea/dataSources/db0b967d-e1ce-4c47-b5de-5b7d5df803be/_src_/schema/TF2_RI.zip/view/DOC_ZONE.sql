CREATE VIEW DOC_ZONE AS SELECT z.zone_id,z.zone_code,z.zone_name,z.deleted
FROM ZONE z


/
