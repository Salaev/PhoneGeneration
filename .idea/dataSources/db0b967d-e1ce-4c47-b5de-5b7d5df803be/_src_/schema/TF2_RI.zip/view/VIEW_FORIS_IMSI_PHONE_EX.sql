CREATE VIEW VIEW_FORIS_IMSI_PHONE_EX AS SELECT sc.imsi imsi, sc.sn iccid, sc.access_point_id access_point_id,
          pn.international_format international_format,
          pn.network_address_id network_address_id,
          naap.from_date naap_start_date, naap.TO_DATE naap_end_date,
          naap.link_type_code naap_link_type_code
     FROM phone_number pn JOIN network_address_access_point naap ON pn.network_address_id =
                                                                      naap.network_address_id
          JOIN sim_card sc ON sc.access_point_id = naap.access_point_id


/
