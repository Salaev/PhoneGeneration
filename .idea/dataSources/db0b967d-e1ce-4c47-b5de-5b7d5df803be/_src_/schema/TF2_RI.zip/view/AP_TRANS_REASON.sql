CREATE VIEW AP_TRANS_REASON AS SELECT ap_trans_reason_code, ap_trans_reason_name, ap_status_trans_code, auto_trans_timeout,
                 DESCRIPTION, user_id_of_change, date_of_change, deleted, sn
          FROM ap_trans_reason@cat


/
