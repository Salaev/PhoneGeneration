CREATE VIEW PHONE_NUMBER_TYPE AS SELECT phone_number_type_code, phone_number_type_name, stand_alone, check_relation_to_host,
                 user_id_of_change, date_of_change, deleted, sn, is_shared
          FROM phone_number_type@cat


/
