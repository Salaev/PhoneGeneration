CREATE VIEW UMRS_HOSTTIMEZONES AS SELECT h.host_code,
       h.time_zone
FROM host h


/
