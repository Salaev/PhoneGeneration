CREATE VIEW ROAMING_PARTNER AS select
    z.zone_name roaming_zone_name,
    gd.id2 network_operator_id,
    gd.date_from,
    decode(gd.date_to, to_date('01.01.4000', 'dd.mm.yyyy'), to_date(null), gd.date_to) date_to
    from agroup_data gd, zone z
    where 1 = 1
    and gd.agroup_id = etc_pkg.xget_roam_part_agroup_id
    and z.zone_id = gd.id1
/
