CREATE VIEW NA_STATUS_TRANS AS SELECT na_status_trans_code, status_code_from, status_code_to, is_bp_only, DESCRIPTION,
                 user_id_of_change, date_of_change, deleted, sn
          FROM na_status_trans@cat


/
