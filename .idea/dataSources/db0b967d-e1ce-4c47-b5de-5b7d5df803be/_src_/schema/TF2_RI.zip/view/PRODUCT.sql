CREATE VIEW PRODUCT AS SELECT product_id, product_code, product_name, product_type_code, supplier_code, DESCRIPTION,
                 user_id_of_change, date_of_change, deleted, sn
          FROM product@cat


/
