CREATE VIEW PRODUCT_TYPE AS SELECT product_type_code, product_type_name, DESCRIPTION, user_id_of_change, date_of_change, deleted, sn
          FROM product_type@cat


/
