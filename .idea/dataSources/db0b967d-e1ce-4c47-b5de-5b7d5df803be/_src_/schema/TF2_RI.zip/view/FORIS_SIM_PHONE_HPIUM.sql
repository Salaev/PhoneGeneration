CREATE VIEW FORIS_SIM_PHONE_HPIUM AS SELECT   ss.sim_series_id, ss.start_imsi_number, ss.end_imsi_number,
            nto.network_operator_code, nto.network_operator_name,
            nto.network_operator_id, noup.network_operator_name megaregion,
            noup.network_operator_id ID
       FROM sim_series ss JOIN network_operator nto ON ss.network_operator_id =
                                                         nto.network_operator_id
            JOIN network_operator noup ON noup.network_operator_id =
                                                 nto.network_operator_id_upper
   ORDER BY noup.network_operator_id


/
