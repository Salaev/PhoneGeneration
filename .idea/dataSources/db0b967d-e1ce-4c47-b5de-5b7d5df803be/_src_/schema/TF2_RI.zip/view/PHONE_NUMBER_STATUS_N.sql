CREATE VIEW PHONE_NUMBER_STATUS_N AS SELECT /*+ index(p,i_phonenum_phone_num_series_id) index(n,i_netadstahi_nt_addr_stat_code)*/
          p.international_format
     FROM network_address_status_history n, phone_number p
    WHERE n.net_address_status_code = 'N'
      AND n.end_date IS NULL
      AND p.network_address_id = n.network_address_id


/
