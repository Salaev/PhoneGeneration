CREATE VIEW AP_PROD_STATUS_TRANS AS SELECT ap_prod_status_trans_code, status_code_from, status_code_to, is_bp_only, DESCRIPTION, user_id_of_change,
                 date_of_change, deleted, sn
          FROM ap_prod_status_trans@cat


/
