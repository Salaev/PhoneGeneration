CREATE VIEW AP_PROD_STATUS AS SELECT ap_prod_status_code, ap_prod_status_name, DESCRIPTION, user_id_of_change, date_of_change, deleted, sn
          FROM ap_prod_status@cat


/
