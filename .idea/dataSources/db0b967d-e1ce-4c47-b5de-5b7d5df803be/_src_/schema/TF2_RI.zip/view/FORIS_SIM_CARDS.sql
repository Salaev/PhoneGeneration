CREATE VIEW FORIS_SIM_CARDS AS SELECT imsi, start_date, end_date, balance_storage
     FROM foris_sim_cards_1
/*
UNION
select IMSI,START_DATE,END_DATE,NULL BALANCE_STORAGE
from FORIS_SIM_CARDS_2 */


/
