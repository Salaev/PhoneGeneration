CREATE VIEW FORIS_IMSI_PHONE AS SELECT /*+   USE_hash(s)
             USE_hash(naap)
             USE_hash(a,h)
             USE_hash(naap,p)
            */
          p.international_format phone_number, s.imsi
     FROM sim_card s JOIN access_point_status_history h ON s.access_point_id =
                                                             h.access_point_id
          JOIN access_point a ON a.access_point_id = s.access_point_id
          JOIN network_address_access_point naap ON naap.access_point_id =
                                                             a.access_point_id
          JOIN phone_number p ON p.network_address_id =
                                                       naap.network_address_id
    WHERE h.access_point_status_code <> 'O'
      AND SYSDATE BETWEEN h.start_date AND NVL (h.end_date, SYSDATE)
     -- AND a.personal_account IS NOT NULL
    --  AND (a.deleted >= SYSDATE OR a.deleted IS NULL)
      AND SYSDATE BETWEEN naap.from_date AND NVL (naap.TO_DATE, SYSDATE)
      AND NOT EXISTS (SELECT 1
                        FROM list_nums_for_ium
                       WHERE msisdn = SUBSTR (p.international_format, -10))



/
