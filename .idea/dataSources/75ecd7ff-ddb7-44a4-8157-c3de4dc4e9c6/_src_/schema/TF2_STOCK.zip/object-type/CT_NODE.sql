CREATE type CT_NODE is table of OT_NODE
/
