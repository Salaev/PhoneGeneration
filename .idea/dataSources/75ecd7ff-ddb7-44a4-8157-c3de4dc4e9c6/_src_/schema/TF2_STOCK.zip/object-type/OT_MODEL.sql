CREATE type OT_MODEL is object
(
  id number,
  code varchar2(15),
  type_id number,
  type_code varchar2(15),
  type_code2 nvarchar2(2),
  has_serial varchar2(1),
  allows_part varchar2(1),
  is_num_sn varchar2(1),
  is_pack varchar2(1)
)
/
