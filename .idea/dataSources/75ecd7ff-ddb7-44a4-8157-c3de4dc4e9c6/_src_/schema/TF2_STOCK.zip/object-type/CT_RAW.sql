CREATE type CT_RAW is table of RAW(9)
/
