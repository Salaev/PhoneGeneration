CREATE type CT_SERIES is table of OT_SERIES
/
