CREATE type CT_SIM is table of OT_SIM
/
