CREATE TYPE             "CT_STOCK_STATE"                                          IS TABLE OF ot_stock_state
/
