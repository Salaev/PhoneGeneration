CREATE type OT_SIM is object
(
  serial_number nvarchar2(50),
  model OT_MODEL
)
/
