CREATE TYPE             "T_V"                                          AS TABLE OF VARCHAR (256);
/
