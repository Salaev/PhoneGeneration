CREATE type OT_SERIES is object
(
  seria_start varchar2(50),
  seria_end varchar2(50)
)
/
