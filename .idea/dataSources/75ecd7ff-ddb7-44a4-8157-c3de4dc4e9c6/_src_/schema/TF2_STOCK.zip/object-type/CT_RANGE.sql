CREATE type CT_RANGE is table of OT_RANGE
/
