CREATE type CT_MODEL is table of OT_MODEL
/
