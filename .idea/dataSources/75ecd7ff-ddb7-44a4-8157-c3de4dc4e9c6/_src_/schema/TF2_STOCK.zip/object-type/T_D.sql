CREATE TYPE             "T_D"                                          AS TABLE OF DATE;
/
