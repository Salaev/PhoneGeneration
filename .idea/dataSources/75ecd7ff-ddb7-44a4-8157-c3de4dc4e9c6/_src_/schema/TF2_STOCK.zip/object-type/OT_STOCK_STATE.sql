CREATE TYPE             "OT_STOCK_STATE"                                          IS OBJECT (
   ID                    NUMBER,
   stock_id              NUMBER,
   equipment_model_id    NUMBER,
   seria_start           VARCHAR2 (50),
   seria_end             VARCHAR2 (50),
   quantity_onstock      NUMBER,
   quantity_reserved     NUMBER,
   quantity_announced    NUMBER,
   doc_header_id         NUMBER,
   create_date           DATE,
   status                NUMBER,
   equipment_type_id     NUMBER,
   reserved              VARCHAR2 (50),
   user_comment          VARCHAR2 (50),
   equipment_batch_id    NUMBER,
   is_nonsingle_series   NUMBER
)

/
