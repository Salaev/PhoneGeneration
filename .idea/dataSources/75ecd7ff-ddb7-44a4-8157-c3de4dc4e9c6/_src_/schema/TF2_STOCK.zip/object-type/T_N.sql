CREATE TYPE             "T_N"                                          AS TABLE OF NUMBER;
/
