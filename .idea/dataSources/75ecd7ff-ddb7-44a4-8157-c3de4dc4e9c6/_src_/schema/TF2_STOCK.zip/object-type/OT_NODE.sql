CREATE type OT_NODE is object
(
  id number,
  parent_id number,
  val number,
  type_id number
)
/
