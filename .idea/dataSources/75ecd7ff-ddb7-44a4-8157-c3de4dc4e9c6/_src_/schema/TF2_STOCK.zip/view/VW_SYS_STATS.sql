CREATE VIEW VW_SYS_STATS AS SELECT 'STAT...' || a.NAME NAME, b.VALUE
     FROM v$statname a, v$mystat b
    WHERE a.statistic# = b.statistic#
   UNION ALL
   SELECT 'LATCH..' || NAME, gets
     FROM v$latch
   UNION ALL
   SELECT 'STAT...Elapsed Time', hsecs
     FROM v$timer

/
