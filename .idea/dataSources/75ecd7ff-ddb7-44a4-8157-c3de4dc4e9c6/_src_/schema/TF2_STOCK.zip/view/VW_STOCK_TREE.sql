CREATE VIEW VW_STOCK_TREE AS SELECT   sg.stock_group_id, sg.ID, sg.NAME, s.ID, s.NAME, s.code, st.NAME, s.stock_owner,
            s.stock_manager, s.address, s.zip, s.tel, s.fax, s.email, s.description, s.deleted
       FROM stock_group sg LEFT OUTER JOIN stock s ON sg.ID = s.stock_group_id
            LEFT OUTER JOIN stock_type st ON s.stock_type = st.ID
   ORDER BY sg.stock_group_id, sg.ID, s.ID

/
