CREATE VIEW EQUIPMENT_MODEL AS SELECT equipment_model_id,
       equipment_model_code,
       equipment_model_name,
       user_id_of_change,
       date_of_change,
       deleted,
       producer_id,
       equipment_type_id,
       sn
   FROM cat_equipment_model

/
