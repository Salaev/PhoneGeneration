CREATE VIEW VW_SYS_SESSION_STATS AS SELECT b.SID, a.NAME, b.VALUE
     FROM v$statname a, v$mystat b
    WHERE a.statistic# = b.statistic#

/
