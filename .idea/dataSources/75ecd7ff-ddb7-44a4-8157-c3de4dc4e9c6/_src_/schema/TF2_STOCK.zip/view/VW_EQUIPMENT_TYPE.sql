CREATE VIEW VW_EQUIPMENT_TYPE AS SELECT e.equipment_type_id,
          e.equipment_type_code,
          e.equipment_type_name,
          e.user_id_of_change,
          e.date_of_change,
          e.deleted,
          e.system_type_code,
          s.has_serial_number,
          s.allows_partitioning,
          s.is_numeric_serial_number,
          s.is_package
   FROM cat_equipment_type e, equipment_system_type s
   WHERE e.system_type_code = s.equipment_system_type_code

/
