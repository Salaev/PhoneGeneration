CREATE VIEW VW_STOCK_STATE AS SELECT ss.stock_id, et.equipment_type_name, em.equipment_model_code, em.equipment_model_name,
          ss.quantity_onstock, ss.quantity_reserved, ss.quantity_announced, ss.equipment_type_id,
          ss.equipment_model_id, ss.seria_start, ss.seria_end, ss.status, ss.create_date,
          ss.user_comment, ss.reserved, ss.equipment_batch_id
     FROM stock_state ss, equipment_model em, equipment_type et
    WHERE ss.equipment_model_id = em.equipment_model_id
      AND ss.equipment_type_id = et.equipment_type_id

/
