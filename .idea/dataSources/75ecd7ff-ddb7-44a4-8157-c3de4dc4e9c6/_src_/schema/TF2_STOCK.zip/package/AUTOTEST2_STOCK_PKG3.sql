CREATE package AUTOTEST2_STOCK_PKG3 is
 --------------- Наполнение таблицы свободных сим
procedure fill_autotest2_sim_stock(istock_id number default null);

procedure fill_sim_attributes_stock (iSIM_NUMBER varchar2,
                               error out sys_refcursor);
procedure full_stock_path (isim_number varchar2,
                           full_path out sys_refcursor);
procedure fill_autotest2_sim_for_prepaid;
end AUTOTEST2_STOCK_PKG3;
/
