CREATE PACKAGE BODY pkg_out_stock
AS
--******************************************************************************
-- Author  : Skripnik Petr
-- Created : 16.10.2006 14:05
-- Purpose : Work with the stocks from external subsystems
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
--   ORA 20050-20100 Reserved
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ------------------------------------------
-- Petr Skripnik   09.11.2006  Изменен
-- Skripnik Petr   16.04.2007  version 1.11.8.2
-- Skripnik Petr   03.05.2007  version 1.11.8.3
-- Skripnik Petr   23.07.2007  version 1.11.8.4
-- Skripnik Petr   17.10.2007  version 1.11.9.0
--****************************************************************************--
   pkg_name   CONSTANT NVARCHAR2 (50) := 'pkg_out_stock.';

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 31.10.2007 13:03
-- Editor  :
-- Changed :
-- Purpose : Получает массив идентификаторов модели оборудования
--           по списку кодов оборудования
--------------------------------------------------------------------------------
   FUNCTION eqmidtab_by_eqmcodelist (p_equipment_code_list IN LONG, p_delimiter IN CHAR DEFAULT ',')
      RETURN pkg_common.t_num
   AS
      prc_name    CONSTANT NVARCHAR2 (100)  := pkg_name || 'eqmidtab_by_eqmcodelist';
      l_equipment_id_tab   pkg_common.t_num;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                         '(' || p_equipment_code_list || pkg_constants.c_delimiter || p_delimiter
                         || ')',
                         pkg_name
                        );

      SELECT equipment_model_id
      BULK COLLECT INTO l_equipment_id_tab
        FROM equipment_model
       WHERE p_equipment_code_list = '-1'
          OR INSTR (p_delimiter || p_equipment_code_list || p_delimiter,
                    p_delimiter || equipment_model_code || p_delimiter
                   ) <> 0;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      RETURN l_equipment_id_tab;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END eqmidtab_by_eqmcodelist;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 08.11.2007 13:38
-- Version :
--   1 08.11.2007
-- Modification :
-- Editor  :
-- Changed :
--   SP 13.03.2008 Удалил выходной курсор p_cur_stk_group
-- Purpose : Покажет движение оборудования
--------------------------------------------------------------------------------
   PROCEDURE equipment_move (
      p_doc_type           IN       NUMBER,   --101/102/103
      p_from_date          IN       DATE,   --any date
      p_to_date            IN       DATE,   --any date
      p_detailed           IN       NUMBER,   --1=TRUE/0=FALSE
      p_cur_eqm_move       OUT      sys_refcursor,
      p_eqm_code_list      IN       LONG DEFAULT '-1',   -- -1=все
      p_stk_code_out       IN       LONG DEFAULT '-1',   -- -1=все/NULL=неучитывать
      p_stk_group_id_out   IN       LONG DEFAULT NULL,   -- NULL=неучитывать
      p_stk_code_in        IN       LONG DEFAULT '-1',   -- -1=все/NULL=неучитывать
      p_stk_group_id_in    IN       LONG DEFAULT NULL,   -- NULL=неучитывать
      p_delimiter          IN       CHAR DEFAULT ','
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'equipment_move';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_doc_type
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_from_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_to_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_detailed
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || pkg_constants.c_delimiter
                         || p_eqm_code_list
                         || pkg_constants.c_delimiter
                         || p_stk_code_out
                         || pkg_constants.c_delimiter
                         || p_stk_group_id_out
                         || pkg_constants.c_delimiter
                         || p_stk_code_in
                         || pkg_constants.c_delimiter
                         || p_stk_group_id_in
                         || pkg_constants.c_delimiter
                         || p_delimiter
                         || ')',
                         pkg_name
                        );

      IF p_detailed > 0
      THEN
         pkg_report.equipment_move_group_by_series
            (p_doc_type                => p_doc_type,
             p_from_date               => p_from_date,
             p_to_date                 => p_to_date,
             p_equipment_model_id      => eqmidtab_by_eqmcodelist
                                                          (p_equipment_code_list      => p_eqm_code_list,
                                                           p_delimiter                => p_delimiter
                                                          ),
             p_cur_eqm_move            => p_cur_eqm_move,
             p_stock_id_out            => stockidtab_by_stockparamlist
                                                       (p_stock_code_list          => p_stk_code_out,
                                                        p_group_stock_id_list      => p_stk_group_id_out,
                                                        p_delimiter                => p_delimiter
                                                       ),
             p_stock_id_in             => stockidtab_by_stockparamlist
                                                        (p_stock_code_list          => p_stk_code_in,
                                                         p_group_stock_id_list      => p_stk_group_id_in,
                                                         p_delimiter                => p_delimiter
                                                        )
            );
      ELSE
         pkg_report.equipment_move_group_by_stocks
            (p_doc_type                => p_doc_type,
             p_from_date               => p_from_date,
             p_to_date                 => p_to_date,
             p_equipment_model_id      => eqmidtab_by_eqmcodelist
                                                          (p_equipment_code_list      => p_eqm_code_list,
                                                           p_delimiter                => p_delimiter
                                                          ),
             p_cur_eqm_move            => p_cur_eqm_move,
             p_stock_id_out            => stockidtab_by_stockparamlist
                                                       (p_stock_code_list          => p_stk_code_out,
                                                        p_group_stock_id_list      => p_stk_group_id_out,
                                                        p_delimiter                => p_delimiter
                                                       ),
             p_stock_id_in             => stockidtab_by_stockparamlist
                                                        (p_stock_code_list          => p_stk_code_in,
                                                         p_group_stock_id_list      => p_stk_group_id_in,
                                                         p_delimiter                => p_delimiter
                                                        )
            );
      END IF;
   END equipment_move;

-------------------------------------------------------------------------------
-- Author  : Anoev Maxim
-- Created : 03.05.2007 14:00
-- Version : 2
--   1 03.05.2007
--   2 17.10.2007
-- Modification : get_keo_logistic_on_period
-- Editor  : Skripnik Petr (SP)
-- Changed :
--   SP 15.05.2007 В получении p_cur_start_saldo заменил
--      (WHERE ts.create_date < p_from_date) -> (WHERE ts.create_date >= p_from_date)
--   SP 16.05.2007 В получении p_cur_start_saldo удалил (WHERE ts.create_date >= p_from_date)
--   SP 10.07.2007 В p_cur_activated добавил соеденение с tmp_ss1
--   SP 19.07.2007 В p_cur_activated поменял условия выборки.
--   SP 19.07.2007 Перенес stock_state_to_date_prepare в внутрь процедуры с доработками
--   SP 17.10.2007 Добавлен параметр p_equipment_code_list
--   SP 14.07.2008 Удалил упоминание quantity_reserved, quantity_announced
--   MV 06.08.2008 Расчет начального и конечного сальдо некорректно учитывал документы о разбиении
--   Victor Smirnov 24.08.2009 расчет начального сальдо, используя get_stock_state_on_date
--   SP 05.09.2012 1.Перенос заполнения tmp_ss1 в начало, из-за влияния на коллекции складов; 
--                 2.Применение "стандартного" мех-ма заполнения коллекций складов, правильная реакция на значение "-1";
--                 3.Изменения в "Проданные";
--                 4.Изменения в "Движение оборудование по документам до конечной даты".
-- Purpose : Получаем все движения оборудования на период времени
--           Отчет: Оборотная ведомость по проданным КЭО
--------------------------------------------------------------------------------
   PROCEDURE get_keo_logistic_on_period (
      p_from_date              IN       DATE,   --начальная дата
      p_to_date                IN       DATE,   --конечная дата
      p_stock_from_code_list   IN       LONG,   --склады-отправители
      p_stock_to_code_list     IN       LONG,   --склады-получатели
      p_equipment_code_list    IN       LONG,   --перечисления оборудования через разделитель (,)
      p_cur_start_saldo        OUT      sys_refcursor,   --начальное сальдо
      p_cur_sold               OUT      sys_refcursor,   --продано
      p_cur_activated          OUT      sys_refcursor,   --активировано
      p_cur_returned           OUT      sys_refcursor,   --возвращено
      p_cur_expired            OUT      sys_refcursor,   --просрочено
      p_cur_end_saldo          OUT      sys_refcursor,   --конечное сальдо
      p_cur_stock              OUT      sys_refcursor,   --группы складов
      p_delimiter              IN       VARCHAR2 DEFAULT ','
   )
   IS
      prc_name      CONSTANT NVARCHAR2 (100)  := pkg_name || 'get_keo_logistic_on_period';
      
      l_eqmmodelid_tab       pkg_common.t_num;   --числовая коллекция идентификаторов оборудования
      v_cur_state            sys_refcursor;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start);--, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_from_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_to_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_stock_from_code_list
                         || pkg_constants.c_delimiter
                         || p_stock_to_code_list
                         || pkg_constants.c_delimiter
                         || p_equipment_code_list
                         || ')'
                        --, pkg_name
                        );

      --Движение оборудование по документам до начальной даты
      DELETE FROM tmp_ss1;

      get_stock_state_on_date(p_date => p_from_date,
                                            p_group_stock_id_list => null,
                                            p_stock_code_list => p_stock_to_code_list,
                                            p_equipment_code_list => p_equipment_code_list,
                                            p_cur_state => v_cur_state,
                                            p_is_detailed => 1);

      --Парсим списки кодов складов, ищем их Id и помещаем в соотв. коллекции
      pkg_stock.set_stockid(p_stock_id_out => stockidtab_by_stockparamlist(p_stock_code_list => p_stock_from_code_list,
                                                                                         p_group_stock_id_list => NULL,
                                                                                         p_delimiter => p_delimiter),
                            p_stock_id_in  => stockidtab_by_stockparamlist(p_stock_code_list => p_stock_to_code_list,
                                                                                         p_group_stock_id_list => NULL,
                                                                                         p_delimiter => p_delimiter)
                           );

      --Все(отправители и получатели) указанные склады
      OPEN p_cur_stock FOR
         SELECT ID, NAME
           FROM stock,
                (SELECT --+ CARDINALITY(stk_all 2)
                        COLUMN_VALUE as stock_id
                   FROM TABLE(CAST(SET(pkg_stock.g_tab_id_out MULTISET UNION pkg_stock.g_tab_id_in)  AS ct_number))stk_all
                )
        WHERE 1=1
          AND id = stock_id;      
              
      --Если список идентификаторов кодов оборудования есть то...
      IF p_equipment_code_list IS NOT NULL
      THEN
         --Получим коллекцию идентификаторов оборудования по коду
         l_eqmmodelid_tab := eqmidtab_by_eqmcodelist(p_equipment_code_list => p_equipment_code_list);
         --Заполним коллекцию идентификаторов оборудования...
         pkg_equipment.set_modelid (p_model_id_1 => l_eqmmodelid_tab);
      --Если список идентификаторов кодов оборудования нет то...
      ELSE
         raise_application_error (-20001, 'Is not set parameters equipment model code list');
      END IF;

      --Начальное сальдо
      pkg_db_util.DEBUG (prc_name, 'Start saldo...', pkg_name);

      OPEN p_cur_start_saldo FOR
           SELECT et.equipment_type_code, et.equipment_type_name, em.equipment_model_code,
                  em.equipment_model_name, SUM (t.quantity_onstock) AS "QUANTITY"
             FROM tmp_ss1 t, equipment_model em, equipment_type et
            WHERE t.equipment_model_id = em.equipment_model_id
              AND em.equipment_type_id = et.equipment_type_id
         GROUP BY et.equipment_type_code,
                  et.equipment_type_name,
                  em.equipment_model_code,
                  em.equipment_model_name;

      --Проданные
      pkg_db_util.DEBUG (prc_name, 'Sold...', pkg_name);

      OPEN p_cur_sold FOR
         SELECT et.equipment_type_code, et.equipment_type_name, em.equipment_model_code,
                em.equipment_model_name, so.code AS "OUT_STOCK_CODE", so.NAME AS "OUT_STOCK_NAME",
                si.code AS "IN_STOCK_CODE", si.NAME AS "IN_STOCK_NAME", dh.doc_date AS create_date,
                dd.seria_start, dd.seria_end, dd.quantity
           FROM doc_header dh,
                doc_detail dd,
                equipment_model em,
                equipment_type et,
                stock so,
                stock si
          WHERE dh.stock_out_id IN (SELECT --+ CARDINALITY(stk 1)
                                           COLUMN_VALUE
                                      FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk)
            AND dh.stock_in_id IN (SELECT --+ CARDINALITY(stk2 1)
                                          COLUMN_VALUE
                                     FROM TABLE(CAST(pkg_stock.g_tab_id_out AS ct_number)) stk2)
            AND dh.doc_date BETWEEN p_from_date AND p_to_date
            AND dh.doc_type_id = 103
            AND dh.status_id = 1
            AND dh.ID = dd.doc_header_id
            AND dd.equipment_model_id IN (SELECT --+ CARDINALITY(eqm 2)
                                                 COLUMN_VALUE
                                            FROM TABLE(CAST(pkg_equipment.g_tab_model_id AS ct_number)) eqm)
            AND dd.equipment_model_id = em.equipment_model_id
            AND em.equipment_type_id = et.equipment_type_id
            AND et.equipment_type_id = 1
            AND dh.stock_out_id = so.ID
            AND dh.stock_in_id = si.ID;

      --Активированные
      pkg_db_util.DEBUG (prc_name, 'Activated...', pkg_name);

      OPEN p_cur_activated FOR
         SELECT et.equipment_type_code, et.equipment_type_name, em.equipment_model_code,
                em.equipment_model_name, so.code AS "STOCK_CODE", so.NAME AS "STOCK_NAME",
                b.doc_date AS create_date, b.seria_start, b.seria_end, b.quantity
           FROM (SELECT --+ INDEX(dh IDX_DOCHEADER_SO_DD_DMO)
                        dh.ID, dh.doc_date, dh.stock_out_id, dd.equipment_model_id, dd.seria_start,
                        dd.seria_end, dd.quantity
                   FROM doc_header dh, doc_detail dd, equipment_model em
                  WHERE dh.stock_out_id IN(SELECT --+ CARDINALITY(stk 1)
                                                  COLUMN_VALUE
                                             FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk)
                    AND dh.doc_date BETWEEN p_from_date AND p_to_date
                    AND dh.doc_type_id = 102
                    AND dh.status_id = 1
                    AND em.equipment_type_id = 1
                    AND dh.ID = dd.doc_header_id
                    AND dd.equipment_model_id IN(SELECT --+ CARDINALITY(eqm 2)
                                                        COLUMN_VALUE
                                                   FROM TABLE(CAST(pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                    AND dd.equipment_model_id = em.equipment_model_id
                    -- вместо EXISTS можно AND 0 = ( SELECT COUNT(*) FROM (...
                    AND EXISTS (
                           SELECT *
                             FROM (SELECT edh.stock_in_id AS stock_id, edd.equipment_model_id,
                                          edd.seria_start, edd.seria_end
                                     FROM doc_header edh, doc_detail edd, equipment_model eem
                                    WHERE edh.stock_in_id IN(SELECT --+ CARDINALITY(stk 1)
                                                                     COLUMN_VALUE
                                                               FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk)
                                      AND edh.stock_out_id IN(SELECT --+ CARDINALITY(stk2 1)
                                                                     COLUMN_VALUE
                                                                FROM TABLE(CAST(pkg_stock.g_tab_id_out AS ct_number)) stk2)
                                      AND edh.doc_date BETWEEN p_from_date AND p_to_date
                                      AND edh.doc_type_id = 103
                                      AND edh.status_id = 1
                                      AND eem.equipment_type_id = 1
                                      AND edh.ID = edd.doc_header_id
                                      AND edd.equipment_model_id IN(SELECT --+ CARDINALITY(eqm 2)
                                                                           COLUMN_VALUE
                                                                      FROM TABLE(CAST(pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                                      AND edd.equipment_model_id = eem.equipment_model_id
                                   UNION ALL
                                   SELECT stock_id, equipment_model_id, seria_start, seria_end
                                     FROM tmp_ss1) a
                            WHERE dh.stock_out_id = a.stock_id
                              AND dd.equipment_model_id = a.equipment_model_id
                              AND dd.seria_start <= a.seria_end
                              AND dd.seria_end >= a.seria_start)) b,
                equipment_model em,
                equipment_type et,
                stock so
          WHERE b.equipment_model_id = em.equipment_model_id
            AND em.equipment_type_id = et.equipment_type_id
            AND b.stock_out_id = so.ID;

      --Возвращённые
      pkg_db_util.DEBUG (prc_name, 'Returned...', pkg_name);

      OPEN p_cur_returned FOR
         SELECT et.equipment_type_code, et.equipment_type_name, em.equipment_model_code,
                em.equipment_model_name, so.code AS "OUT_STOCK_CODE", so.NAME AS "OUT_STOCK_NAME",
                si.code AS "IN_STOCK_CODE", si.NAME AS "IN_STOCK_NAME", dh.doc_date AS create_date,
                dd.seria_start, dd.seria_end, dd.quantity
           FROM doc_header dh,
                doc_detail dd,
                equipment_model em,
                equipment_type et,
                stock so,
                stock si
          WHERE dh.stock_out_id IN (SELECT --+ CARDINALITY(stk 1)
                                           COLUMN_VALUE
                                      FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk)
            AND dh.stock_in_id IN (SELECT --+ CARDINALITY(stk2 1)
                                          COLUMN_VALUE
                                     FROM TABLE(CAST(pkg_stock.g_tab_id_out AS ct_number)) stk2)
            AND dh.doc_date BETWEEN p_from_date AND p_to_date
            AND dh.doc_type_id = 103
            AND dh.status_id = 1
            AND dh.ID = dd.doc_header_id
            AND dd.equipment_model_id IN(SELECT --+ CARDINALITY(eqm 2)
                                                 COLUMN_VALUE
                                           FROM TABLE(CAST(pkg_equipment.g_tab_model_id AS ct_number)) eqm)
            AND dd.equipment_model_id = em.equipment_model_id
            AND em.equipment_type_id = et.equipment_type_id
            AND et.equipment_type_id = 1
            AND dh.stock_out_id = so.ID
            AND dh.stock_in_id = si.ID
            AND EXISTS(SELECT --+ ORDERED USE_NL(doc dtl)
                              NULL -- А есть ли Документ о поступлении оборудования со склада, на который возвращаем?
                         FROM doc_header doc JOIN
                              doc_detail dtl ON(doc.id = dtl.doc_header_id)
                        WHERE 1=1
                          AND doc.stock_in_id = dh.stock_out_id
                          AND doc.stock_out_id = dh.stock_in_id
                          AND dd.seria_start between dtl.seria_start and dtl.seria_end
                          AND dd.seria_end between dtl.seria_start and dtl.seria_end 
                          AND dtl.equipment_model_id = dd.equipment_model_id
                      );

      --Движение оборудование по документам до конечной даты
      DELETE FROM tmp_ss3;

      INSERT INTO tmp_ss3(stock_id,
                          equipment_model_id,
                          seria_start,
                          seria_end,
                          quantity_onstock,
                          valid_until,
                          equipment_batch_id)
           SELECT b.stock_id,
                  b.equipment_model_id,
                  b.seria_start,
                  b.seria_end,
                  SUM (b.quantity),
                  MAX (b.valid_until),
                  b.equipment_batch_id
             FROM (SELECT a.stock_id,
                          a.equipment_model_id,
                          a.seria_start,
                          a.seria_end,
                          a.quantity,
                          a.valid_until,
                          a.equipment_batch_id
                     FROM (SELECT --+ CARDINALITY(em 13)
                                  d.stock_id,
                                  dd.equipment_model_id,
                                  dd.seria_start,
                                  dd.seria_end,
                                  DECODE (d.quantity_sign,
                                          -1, -dd.quantity,
                                          dd.quantity
                                         ) AS quantity,
                                  dd.valid_until,
                                  dd.equipment_batch_id
                             FROM equipment_model em,
                                  doc_detail dd,
                                  (SELECT --+ INDEX(dh IDX_DOCHEADER_SO_DD_DMO)
                                          dh.ID,
                                          dh.stock_out_id AS stock_id,
                                          -1 AS quantity_sign
                                     FROM doc_header dh
                                    WHERE dh.status_id = 1
                                      AND dh.doc_type_id IN (102, 103)
                                      AND dh.doc_date >= p_from_date
                                      AND dh.doc_date < p_to_date
                                      AND (   dh.stock_out_id < dh.stock_in_id
                                           OR dh.stock_out_id > dh.stock_in_id
                                          )
                                      AND dh.stock_out_id IN(SELECT --+ CARDINALITY(stk 1)
                                                                    COLUMN_VALUE
                                                               FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk) --!
                                      AND (   dh.stock_in_id = 0
                                           OR dh.stock_in_id IN(SELECT --+ CARDINALITY(stk2 1)
                                                                       COLUMN_VALUE
                                                                  FROM TABLE(CAST(pkg_stock.g_tab_id_out AS ct_number)) stk2) --!
                                          )
                                   UNION ALL
                                   SELECT --  USE_CONCAT INDEX(dh IDX_DOCHEADER_SI_DD_DMI) INDEX(dh IDX_DOCHEADER_SO_DD_DMO)
                                          dh.ID,
                                          dh.stock_in_id AS stock_id,
                                          1 AS quantity_sign
                                     FROM doc_header dh
                                    WHERE dh.status_id = 1
                                      AND dh.doc_type_id IN (102, 103, 104, 105, 109)
                                      AND dh.doc_date >= p_from_date
                                      AND dh.doc_date < p_to_date
                                      AND (dh.stock_out_id IN(SELECT --+ CARDINALITY(stk2 1)
                                                                     COLUMN_VALUE
                                                                FROM TABLE(CAST(pkg_stock.g_tab_id_out AS ct_number)) stk2)
                                           OR dh.stock_out_id = dh.stock_in_id
                                          )
                                      AND dh.stock_in_id IN (SELECT --+ CARDINALITY(stk 1)
                                                                    COLUMN_VALUE
                                                               FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk)
                                   UNION ALL
                                   SELECT dh.ID,
                                          dh.stock_in_id AS stock_id,
                                          1 AS quantity_sign
                                     FROM doc_header dh
                                    WHERE dh.status_id = 1
                                      AND dh.doc_type_id = 108
                                      AND dh.doc_date >= p_from_date
                                      AND dh.doc_date < p_to_date
                                      AND dh.stock_out_id IN(SELECT --+ CARDINALITY(stk 1)
                                                                    COLUMN_VALUE
                                                               FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk)
                                      AND EXISTS(
                                                 SELECT NULL
                                                   FROM doc_detail dd, doc_detail dd2, doc_header dh2
                                                  WHERE dd.doc_header_id = dh.ID
                                                    AND dh2.status_id = 1
                                                    AND dd.quantity < 0
                                                    --AND dd2.seria_start = dd.seria_start
                                                    --AND dd2.seria_end = dd.seria_end

                                                    AND dd.seria_start between dd2.seria_start and dd2.seria_end
                                                    AND dd.seria_end between dd2.seria_start and dd2.seria_end

                                                    AND dh2.ID = dd2.doc_header_id
                                                    AND dh2.stock_out_id IN(SELECT --+ CARDINALITY(stk2 1)
                                                                                   COLUMN_VALUE
                                                                              FROM TABLE(CAST(pkg_stock.g_tab_id_out AS ct_number)) stk2)
                                                    AND dh2.stock_in_id = dh.stock_in_id
                                                    AND dh2.doc_type_id = 103
                                                    AND dh2.doc_date > pkg_constants.c_minsysdate
                                                    AND dh2.doc_date < dh.doc_date)
                                  ) d
                            WHERE em.equipment_type_id = 1
                              AND dd.equipment_model_id IN(SELECT --+ CARDINALITY(eqm 2)
                                                                  COLUMN_VALUE
                                                             FROM TABLE(CAST(pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                              AND dd.equipment_model_id = em.equipment_model_id
                              AND dd.doc_header_id = d.ID
                              ) a
                   UNION ALL
                   SELECT stock_id,
                          equipment_model_id,
                          seria_start,
                          seria_end,
                          quantity_onstock,
                          valid_until,
                          equipment_batch_id
                     FROM tmp_ss1) b
         GROUP BY b.stock_id, b.equipment_model_id, b.seria_start, b.seria_end,
                  b.equipment_batch_id
           HAVING SUM (b.quantity) > 0
           ;

      --С истёкшим сроком годности
      pkg_db_util.DEBUG (prc_name, 'Expired...', pkg_name);

      OPEN p_cur_expired FOR
           SELECT et.equipment_type_code, et.equipment_type_name, em.equipment_model_code,
                  em.equipment_model_name, st.code AS "STOCK_CODE", st.NAME AS "STOCK_NAME",
                  ts.valid_until AS "VALID_UNTIL", ts.seria_start AS "SERIA_START",
                  ts.seria_end AS "SERIA_END", SUM (ts.quantity_onstock) AS "QUANTITY"
             FROM tmp_ss3 ts, equipment_model em, equipment_type et, stock st
            WHERE ts.equipment_model_id = em.equipment_model_id
              AND em.equipment_type_id = et.equipment_type_id
              AND ts.stock_id = st.ID
              AND ts.valid_until >= p_from_date
              AND ts.valid_until < p_to_date
         GROUP BY ts.stock_id,
                  et.equipment_type_code,
                  et.equipment_type_name,
                  em.equipment_model_code,
                  em.equipment_model_name,
                  st.code,
                  st.NAME,
                  ts.valid_until,
                  ts.seria_start,
                  ts.seria_end,
                  ts.equipment_batch_id;

      --Конечное сальдо
      pkg_db_util.DEBUG (prc_name, 'End saldo...', pkg_name);

      OPEN p_cur_end_saldo FOR
           SELECT et.equipment_type_code, et.equipment_type_name, em.equipment_model_code,
                  em.equipment_model_name, SUM (ts.quantity_onstock) AS "QUANTITY"
             FROM tmp_ss3 ts, equipment_model em, equipment_type et
            WHERE ts.equipment_model_id = em.equipment_model_id
              AND em.equipment_type_id = et.equipment_type_id
         GROUP BY et.equipment_type_code,
                  et.equipment_type_name,
                  em.equipment_model_code,
                  em.equipment_model_name;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_keo_logistic_on_period;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 01.05.2007 14:00
-- Version :
--   1 01.05.2007
--   2 06.06.2007
-- Modification :
-- Editor  : Skripnik Petr (SP)
-- Changed :
--   SP 06.06.2007 Вместо report_management.reversebalancelist и pkg_stock.state_to_range_date
--                 вызывается pkg_report.reverse_balance_list
--   SP 06.11.2007 Добавлен курсор с списком складов
-- Purpose : Вернет курсора с состояниями скаладов на указанную дату и диапозона
--          дат (оборотно-сальдовая ведомость ОСВ)
--          При выборе всех складов\групп складов отчет вернет 0 строк, так как движения между всеми
--          складами в сумме вернет 0 (особенности ОСВ)
--------------------------------------------------------------------------------
   PROCEDURE get_reverse_balnce_list (
      p_from_date             IN       DATE,   --начальная дата диапазона
      p_to_date               IN       DATE,   --конечная дата диапазона
      p_equipment_code_list   IN       LONG,   --перечисления оборудования через разделитель (,)
      p_cur_state             OUT      sys_refcursor,   --курсор с состояниями скаладов на указанную дату
      p_cur_state_range       OUT      sys_refcursor,   --курсор с состояниями скаладов на диапазон дат
      p_cur_stocks            OUT      sys_refcursor,   --курсор всех складов
      p_group_stock_id_list   IN       LONG DEFAULT NULL,   --перечисления групп складов через разделитель (,)
      p_stock_code_list       IN       LONG DEFAULT NULL   --перечисления складов через разделитель (,)
   )
   IS
      prc_name    CONSTANT NVARCHAR2 (100)  := pkg_name || 'get_reverse_balnce_list';   --имя процедуры
      l_stockid_tab        pkg_common.t_num;   -- массив идентификаторов складов
      l_eqmmodelid_tab     pkg_common.t_num;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_from_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_to_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_equipment_code_list
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || pkg_constants.c_delimiter
                         || p_group_stock_id_list
                         || pkg_constants.c_delimiter
                         || p_stock_code_list
                         || ')',
                         pkg_name
                        );
      --Получим коллекцию идентификаторов складов по коду и группе
      l_stockid_tab :=
         stockidtab_by_stockparamlist (p_stock_code_list          => p_stock_code_list,
                                       p_group_stock_id_list      => p_group_stock_id_list,
                                       p_delimiter                => ','
                                      );
      --Получим коллекцию идентификаторов оборудования по коду
      l_eqmmodelid_tab := eqmidtab_by_eqmcodelist (p_equipment_code_list => p_equipment_code_list);
      --Получим оборотно-сальдовую ведомость
      reverse_balance (p_from_date               => p_from_date,
                       p_to_date                 => p_to_date,
                       p_cur_moveing             => p_cur_state_range,
                       p_cur_start_salda         => p_cur_state,
                       p_stock_id                => l_stockid_tab,
                       p_equipment_model_id      => l_eqmmodelid_tab
                      );

      OPEN p_cur_stocks FOR
         SELECT s.code
           FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk, stock s
          WHERE s.ID = stk.COLUMN_VALUE;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_reverse_balnce_list;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 16.10.2006 14:05
-- Version :
--   1 16.10.2006
--   2 13.03.2008
-- Editor  : Skripnik Petr
-- Changed :
--   SP 07.05.2007 Добавлен курсор с группами складов
--   SP 13.03.2008 Удалил выходной курсор p_cur_stk_group
--   SP 13.03.2008 Разделил get_stock_state_on_date и get_stock_state_on_date_t
--   SP 09.03.2008 Добавил вызов pkg_stock.state_prepare
--   SP 25.12.2008 Добавил p_is_detailed
-- Purpose : Вернет курсор с состояниями скаладов на указанную дату (инвентаризационная и складская ведомость)
--------------------------------------------------------------------------------
   PROCEDURE get_stock_state_on_date (
      p_date                  IN       DATE,   --дата состояния
      p_group_stock_id_list   IN       LONG,   --перечисления групп складов через (,)
      p_stock_code_list       IN       LONG,   --перечисления складов через (,)
      p_equipment_code_list   IN       LONG,   --перечисления оборудования через (,)
      p_cur_state             OUT      sys_refcursor,   --курсор с состояниями скаладов на указанную дату
      p_is_detailed           IN       NUMBER DEFAULT 1
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_stock_state_on_date';
      l_eqmmodelid_cnt    NUMBER;
      l_is_detailed       BOOLEAN;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_group_stock_id_list
                         || pkg_constants.c_delimiter
                         || p_stock_code_list
                         || pkg_constants.c_delimiter
                         || p_equipment_code_list
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || pkg_constants.c_delimiter
                         || p_is_detailed
                         || ')',
                         pkg_name
                        );
                        
      IF (p_group_stock_id_list = '-1')
      THEN
         raise_application_error (-20050, 'p_group_stock_id_list cannot be -1');
      END IF;
      
      IF (p_group_stock_id_list is not null and p_stock_code_list = '-1')
      THEN
         raise_application_error (-20050, 'if p_stock_code_list is -1 then p_group_stock_id_list must be null');
      END IF;
      
      --Заполним коллекцию идентификаторов складов...
      pkg_stock.set_stockid
         (p_stock_id      => stockidtab_by_stockparamlist
                                                    (p_stock_code_list          => p_stock_code_list,
                                                     p_group_stock_id_list      => p_group_stock_id_list,
                                                     p_delimiter                => ','
                                                    )
         );
      --Заполним коллекцию идентификаторов оборудования по коду...
      pkg_equipment.set_modelid
            (p_model_id_1      => eqmidtab_by_eqmcodelist
                                                     (p_equipment_code_list      => p_equipment_code_list)
            );
      l_eqmmodelid_cnt := pkg_equipment.g_tab_model_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'l_eqmmodelid_cnt : ' || l_eqmmodelid_cnt, pkg_name);

      --Сформируем состояние склада на дату
      IF p_is_detailed = 1
      THEN
         l_is_detailed := TRUE;
      ELSE
         l_is_detailed := FALSE;
      END IF;

      pkg_stock.state_prepare (p_date                         => p_date,
                               p_is_update_validity_date      => FALSE,
                               p_is_process_opened_doc        => TRUE,
                               p_is_detailed                  => l_is_detailed
                              );

      --Получим курсор
      OPEN p_cur_state FOR
         SELECT t.stock_id, s.code AS stock_code, s.NAME, t.equipment_model_id,
                em.equipment_model_name, em.equipment_model_code, et.equipment_type_id,
                et.equipment_type_name, t.equipment_batch_id, t.seria_start, t.seria_end,
                t.quantity_onstock + t.quantity_reserved AS quantity_onstock, t.quantity_reserved, 
                t.quantity_announced, NULL AS document_no,
                NULL AS vendor_doc, NULL AS product, NULL AS doc_header_id, t.valid_until,
                NULL AS status
           FROM tmp_ss1 t, stock s, equipment_model em, equipment_type et
          WHERE t.stock_id = s.ID
            AND t.equipment_model_id = em.equipment_model_id
            AND em.equipment_type_id = et.equipment_type_id;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_stock_state_on_date;

--------------------------------------------------------------------------------
-- Author  : Ermakov Sergey
-- Created : 17.04.2009 14:05
-- Version :
--   1 17.04.2009
--
-- Changed : 2 16.11.2009
--           Добавлен входной параметр p_to_date
--           Используется при детализации по срокам годности (p_detail = 1)
--   
-- Purpose : Вернет курсор с состояниями скаладов на указанную дату (инвентаризационная и складская ведомость) с заданным видом детализации
--------------------------------------------------------------------------------
   PROCEDURE get_stock_state_on_date_2 (
      p_date                  IN       DATE,   --дата состояния
      p_group_stock_id_list   IN       LONG,   --перечисления групп складов через (,)
      p_stock_code_list       IN       LONG,   --перечисления складов через (,)
      p_equipment_code_list   IN       LONG,   --перечисления оборудования через (,)
      p_detail                IN       NUMBER DEFAULT 0,  -- 0 - без детализации, 1 - по срокам годности,  2 - по складам, 3 - полная.      
      p_cur_state             OUT      sys_refcursor,   --курсор с состояниями скаладов на указанную дату
      p_to_date               IN       DATE DEFAULT NULL   --дата по...
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_stock_state_on_date_2';
      l_eqmmodelid_cnt    NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_group_stock_id_list
                         || pkg_constants.c_delimiter
                         || p_stock_code_list
                         || pkg_constants.c_delimiter
                         || p_equipment_code_list
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || pkg_constants.c_delimiter
                         || p_detail
                         || ')',
                         pkg_name
                        );
      --Заполним коллекцию идентификаторов складов...
      pkg_stock.set_stockid
         (p_stock_id      => stockidtab_by_stockparamlist
                                                    (p_stock_code_list          => p_stock_code_list,
                                                     p_group_stock_id_list      => p_group_stock_id_list,
                                                     p_delimiter                => ','
                                                    )
         );
      --Заполним коллекцию идентификаторов оборудования по коду...
      pkg_equipment.set_modelid
            (p_model_id_1      => eqmidtab_by_eqmcodelist
                                                     (p_equipment_code_list      => p_equipment_code_list)
            );
      l_eqmmodelid_cnt := pkg_equipment.g_tab_model_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'l_eqmmodelid_cnt : ' || l_eqmmodelid_cnt, pkg_name);

      --Сформируем состояние склада на дату
      pkg_stock.state_prepare (p_date                         => p_date,    --дата 
                               p_is_update_validity_date      => FALSE,     --флаг обработки документов об изменении срока годности оборудования
                               p_is_process_opened_doc        => TRUE,      --флаг обработки открытых документов
                               p_is_detailed                  => TRUE       --флаг получения детализированной информации
                              );
      
      IF p_detail = 0   --без детализации
      THEN
          --Получим курсор
          OPEN p_cur_state FOR
             SELECT et.equipment_type_name, em.equipment_model_code, em.equipment_model_name, 
                    NULL AS stock_code, NULL AS stock_name,
                    MAX(t.valid_until) AS valid_until, 
                    SUM(t.quantity_onstock) + SUM(t.quantity_reserved) AS quantity_onstock
               FROM tmp_ss1 t, stock s, equipment_model em, equipment_type et
              WHERE t.stock_id = s.ID
                AND t.equipment_model_id = em.equipment_model_id
                AND em.equipment_type_id = et.equipment_type_id
               GROUP BY et.equipment_type_name, em.equipment_model_code, em.equipment_model_name
               ORDER BY et.equipment_type_name, em.equipment_model_code, em.equipment_model_name;  
      END IF;

      IF p_detail = 1   --детализации по срокам годности
      THEN
          --Получим курсор
          IF p_to_date IS NULL
          THEN
            --Если не задана дата p_to_date (p_to_date IS NULL)          
            OPEN p_cur_state FOR
               SELECT et.equipment_type_name, em.equipment_model_code, em.equipment_model_name, 
                      NULL AS stock_code, NULL AS stock_name, 
                      t.valid_until, t.quantity_onstock + t.quantity_reserved AS quantity_onstock
                 FROM tmp_ss1 t, stock s, equipment_model em, equipment_type et
                WHERE t.stock_id = s.ID
                  AND t.equipment_model_id = em.equipment_model_id
                  AND em.equipment_type_id = et.equipment_type_id
                 ORDER BY et.equipment_type_name, em.equipment_model_code, em.equipment_model_name, t.valid_until;
          ELSE
            --Если задана дата p_to_date (p_to_date IS NOT NULL)          
            OPEN p_cur_state FOR
               SELECT et.equipment_type_name, em.equipment_model_code, em.equipment_model_name, 
                      NULL AS stock_code, NULL AS stock_name, 
                      t.valid_until, t.quantity_onstock + t.quantity_reserved AS quantity_onstock
                 FROM tmp_ss1 t, stock s, equipment_model em, equipment_type et
                WHERE t.stock_id = s.ID
                  AND t.equipment_model_id = em.equipment_model_id
                  AND em.equipment_type_id = et.equipment_type_id
                  AND t.valid_until <= p_to_date                  
                 ORDER BY et.equipment_type_name, em.equipment_model_code, em.equipment_model_name, t.valid_until;       
          END IF;       
      END IF;  
          
      IF p_detail = 2   --детализации по складам
      THEN
          --Получим курсор
          OPEN p_cur_state FOR
             SELECT et.equipment_type_name, em.equipment_model_code, em.equipment_model_name,
                    s.code AS stock_code, s.NAME AS stock_name,
                    MAX(t.valid_until) AS valid_until, 
                    SUM(t.quantity_onstock) + SUM(t.quantity_reserved) AS quantity_onstock
               FROM tmp_ss1 t, stock s, equipment_model em, equipment_type et
              WHERE t.stock_id = s.ID
                AND t.equipment_model_id = em.equipment_model_id
                AND em.equipment_type_id = et.equipment_type_id
               GROUP BY et.equipment_type_name, em.equipment_model_code, em.equipment_model_name, s.code, s.NAME
               ORDER BY et.equipment_type_name, em.equipment_model_code, em.equipment_model_name;
      END IF;         
                    
      IF p_detail = 3   --полная детализация
      THEN
          --Получим курсор
          OPEN p_cur_state FOR
             SELECT et.equipment_type_name, em.equipment_model_code, em.equipment_model_name, 
                    s.code AS stock_code, s.NAME AS stock_name, 
                    t.valid_until, t.quantity_onstock + t.quantity_reserved AS quantity_onstock
               FROM tmp_ss1 t, stock s, equipment_model em, equipment_type et
              WHERE t.stock_id = s.ID
                AND t.equipment_model_id = em.equipment_model_id
                AND em.equipment_type_id = et.equipment_type_id
               ORDER BY et.equipment_type_name, em.equipment_model_code, em.equipment_model_name, t.valid_until;
      END IF;
      
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;

   END get_stock_state_on_date_2;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 06.06.2007 12:56
-- Version : 1 06.06.2007
-- Modification : report_management.reversebalancelist -> pkg_report.reverse_balance
-- Editor  : Skripnik Petr (SP)
-- Changed :
--   SP 15.06.2007 Добавил GROUP BY для исключения оборудования с отрицательным количеством
--   SP 14.07.2006 IF pkg_stock.g_tab_id.COUNT = 0...
-- Purpose : Получаем состояние складов на указанную дату (Оборотно-сальдовая ведомость)
--------------------------------------------------------------------------------
   PROCEDURE reverse_balance (
      p_from_date            IN       DATE,
      p_to_date              IN       DATE,
      p_cur_moveing          OUT      sys_refcursor,
      p_cur_start_salda      OUT      sys_refcursor,
      p_stock_id             IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_equipment_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'reverse_balance';
      l_cnt_modelid       NUMBER          DEFAULT 0;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_from_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_to_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_stock_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_equipment_model_id.COUNT
                         || ')',
                         pkg_name
                        );
      --Заполним коллекцию идентификаторов складов...
      pkg_stock.set_stockid (p_stock_id => p_stock_id);
      --Заполним коллекцию идентификаторов оборудования...
      pkg_equipment.set_modelid (p_model_id_1 => p_equipment_model_id);
      l_cnt_modelid := pkg_equipment.g_tab_model_id.COUNT;

      OPEN p_cur_moveing FOR
         SELECT --+ PUSH_SUBQ ORDERED NO_MERGE(sq)
                sq.ID AS "Id", 
                sq.doc_no AS "Document No", 
                sq.status_id AS "Status Id",
                sq.stock_out_id AS "From Id", 
                sq.stock_in_id AS "To Id",
                sq.doc_date AS "Document date", 
                dd.equipment_model_id AS "Model Id",
                dd.seria_start AS "Seria From", 
                dd.seria_end AS "Seria To",
                dd.quantity AS "Quantity", 
                sq.vendor_doc AS "Vendor document",
                dd.product AS "Product", 
                sq.last_user AS "Last user",
                dd.valid_until AS "Valid until", 
                dd.status_id AS "Status",
                sq.doc_type_id AS "Document type",
                em.equipment_model_name AS "Equipment model name",
                em.equipment_model_code AS "Equipment model code",
                et.equipment_type_name AS "Equipment type name",
                et.equipment_type_code AS "Equipment type code",
                dd.equipment_batch_id AS "Equipment batch id"
           FROM (SELECT --+ CARDINALITY (stk 2) INDEX(dh IDX_DOCHEADER_SI_DD_DMI)
                        dh.ID, 
                        dh.doc_no, 
                        dh.status_id, 
                        dh.stock_out_id, 
                        dh.stock_in_id,
                        dh.vendor_doc, 
                        dh.doc_date, 
                        dh.last_user, 
                        dh.doc_type_id
                   FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk INNER JOIN doc_header dh
                        ON dh.stock_in_id = stk.COLUMN_VALUE
                  WHERE dh.doc_type_id IN (104, 105, 113)
                    AND dh.status_id = 1
                    AND dh.doc_date >= p_from_date
                    AND dh.doc_date < p_to_date
                 UNION ALL
                 SELECT --+ CARDINALITY (stk 2) INDEX(dh IDX_DOCHEADER_SI_DD_DMI) PUSH_SUBQ
                        dh.ID, 
                        dh.doc_no, 
                        dh.status_id, 
                        dh.stock_out_id, 
                        dh.stock_in_id,
                        dh.vendor_doc, 
                        dh.doc_date, 
                        dh.last_user, 
                        dh.doc_type_id
                   FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk INNER JOIN doc_header dh
                        ON dh.stock_in_id = stk.COLUMN_VALUE
                  WHERE dh.doc_type_id IN (101, 103, 106)
                    AND dh.status_id = 1
                    AND dh.doc_date >= p_from_date
                    AND dh.doc_date < p_to_date
                    AND dh.stock_out_id NOT IN (
                                              SELECT --+ CARDINALITY (stk 2) HASH_AJ
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk
                                               WHERE stk.COLUMN_VALUE <> dh.stock_in_id)
                 UNION ALL
                 SELECT --+ CARDINALITY (stk 2)INDEX(dh IDX_DOCHEADER_SO_DD_DMO) PUSH_SUBQ
                        dh.ID, 
                        dh.doc_no, 
                        dh.status_id, 
                        dh.stock_out_id, 
                        dh.stock_in_id,
                        dh.vendor_doc, 
                        dh.doc_date, 
                        dh.last_user, 
                        dh.doc_type_id
                   FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk INNER JOIN doc_header dh
                        ON dh.stock_out_id = stk.COLUMN_VALUE
                  WHERE dh.doc_type_id IN (102, 103, 107)
                    AND dh.status_id = 1
                    AND dh.doc_date >= p_from_date
                    AND dh.doc_date < p_to_date
                    AND dh.stock_in_id NOT IN (
                                              SELECT --+ CARDINALITY (stk 2) HASH_AJ
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk
                                               WHERE stk.COLUMN_VALUE <> dh.stock_out_id)) sq,
                doc_detail dd,
                equipment_model em,
                equipment_type et
          WHERE sq.ID = dd.doc_header_id
            AND (   EXISTS (SELECT --+ CARDINALITY(eqm 2)
                                   COLUMN_VALUE
                              FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm
                             WHERE em.equipment_model_id = eqm.COLUMN_VALUE)
                 OR (l_cnt_modelid = 0)
                )
            AND dd.equipment_model_id = em.equipment_model_id
            AND em.equipment_type_id = et.equipment_type_id;

      --Если складов нет вернем пустой курсор...
      IF pkg_stock.g_tab_id.COUNT = 0
      THEN
         OPEN p_cur_start_salda FOR
            SELECT NULL AS "Stock id", 
                   NULL AS "Equipment type name", 
                   NULL AS "Equipment code",
                   NULL AS "Equipment name", 
                   NULL AS "Quantity", 
                   NULL AS "Reserved",
                   NULL AS "Announced", 
                   NULL AS "Equipment type id", 
                   NULL AS "Equipment model id",
                   NULL AS "All onstock price"
              FROM DUAL;
      ELSE
         --Сформируем состояние склада на дату сгруппированнго по складу и оборудованию
         pkg_stock.state_prepare (p_date                         => p_from_date,
                                  p_is_update_validity_date      => FALSE,
                                  p_is_process_opened_doc        => TRUE
                                 );

         OPEN p_cur_start_salda FOR
            SELECT   t.stock_id AS "Stock id", 
                     MAX (et.equipment_type_name) AS "Equipment type name",
                     MAX (em.equipment_model_code) AS "Equipment code",
                     MAX (em.equipment_model_name) AS "Equipment name",
                     SUM (t.quantity_onstock) + SUM (t.quantity_reserved) AS "Quantity", 
                     SUM (t.quantity_reserved) AS "Reserved",
                     SUM (t.quantity_announced) AS "Announced",
                     et.equipment_type_id AS "Equipment type id",
                     em.equipment_model_id AS "Equipment model id",
                     SUM (t.quantity_onstock * b.price) AS "All onstock price"
                FROM tmp_ss1 t, equipment_model em, equipment_type et, equipment_batch b
               WHERE t.stock_id IN (SELECT --+ CARDINALITY(stk 20)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                 AND t.equipment_model_id = em.equipment_model_id(+)
                 AND em.equipment_type_id = et.equipment_type_id(+)
                 AND t.equipment_batch_id = b.equipment_batch_id(+)
            GROUP BY t.stock_id, em.equipment_model_id, et.equipment_type_id
              HAVING (SUM (t.quantity_onstock) + SUM (t.quantity_reserved) > 0)
                  OR (SUM (t.quantity_reserved) > 0)
                  OR (SUM (t.quantity_announced) > 0);
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END reverse_balance;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 31.10.2007 13:02
-- Editor  : SP
-- Changed :
--   SP 10.07.2008 Добавил AND PRIOR p.ID = p.ID
-- Purpose : Получает массив идентификаторов складов по списку кодов складов и идентификаторов групп
--------------------------------------------------------------------------------
   FUNCTION stockidtab_by_stockparamlist (
      p_stock_code_list       IN   LONG,
      p_group_stock_id_list   IN   LONG,
      p_delimiter             IN   CHAR DEFAULT ','
   )
      RETURN pkg_common.t_num
   AS
      prc_name   CONSTANT NVARCHAR2 (100)  := pkg_name || 'stockidtab_by_stockparamlist';
      l_stock_id_tab      pkg_common.t_num;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_stock_code_list
                         || pkg_constants.c_delimiter
                         || p_group_stock_id_list
                         || pkg_constants.c_delimiter
                         || p_delimiter
                         || ')',
                         pkg_name
                        );

      SELECT   -- USE_CONCAT
             DISTINCT ID
      BULK COLLECT INTO l_stock_id_tab
                 FROM stock s
                WHERE (s.stock_group_id IN (
                          SELECT     --+ USE_NL(p sg) INDEX(sg PK_STOCK_GROUP)
                                     sg.ID
                                FROM stock_group sg,
                                     (SELECT ID
                                        FROM stock_group
                                       WHERE INSTR (   p_delimiter
                                                    || p_group_stock_id_list
                                                    || p_delimiter,
                                                    p_delimiter || TO_CHAR (ID) || p_delimiter
                                                   ) <> 0) p
                          START WITH sg.ID = p.ID
                          CONNECT BY PRIOR sg.ID = sg.stock_group_id AND PRIOR p.ID = p.ID
                            GROUP BY sg.ID)
                      )
                   OR (   p_stock_code_list = '-1'
                       OR INSTR (p_delimiter || p_stock_code_list || p_delimiter,
                                 p_delimiter || code || p_delimiter
                                ) <> 0
                      );

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      RETURN l_stock_id_tab;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END stockidtab_by_stockparamlist;

--------------------------------------------------------------------------------
-- Author  : ???
-- Created :
-- Modification : ???.customer_report_stock.get_stock
-- Editor  : Skripnik Petr
-- Changed : 12.10.2007 12:41
-- Purpose : Получает курсор с инфоромации о складах существующих на указанную дату
--(без проверки прав пользователя)
--------------------------------------------------------------------------------
   PROCEDURE stocks_on_date (p_date_of_search IN DATE, p_cur_stocks OUT sys_refcursor)
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'stocks_on_date';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_date_of_search, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || ')',
                         pkg_name
                        );

      OPEN p_cur_stocks FOR
         SELECT   CASE
                     WHEN stock_code IS NULL
                        THEN 'StockGroup'
                     ELSE 'Stock'
                  END group_type,
                  CASE
                     WHEN stock_code IS NULL
                        THEN TO_CHAR (stock_group_id)
                     ELSE TO_CHAR (stock_code)
                  END stock_code2,
                  CASE
                     WHEN stock_code IS NULL
                        THEN stock_group_name
                     ELSE stock_name
                  END stock_name
             FROM (SELECT   sg.ID AS stock_group_id, sg.NAME AS stock_group_name,
                            s.code AS stock_code, s.NAME AS stock_name
                       FROM stock s, stock_group sg
                      WHERE s.stock_group_id = sg.ID
                        AND (s.deleted > p_date_of_search OR s.deleted IS NULL)
                   GROUP BY GROUPING SETS ((sg.ID, sg.NAME), (sg.ID, sg.NAME, s.code, s.NAME)))
         ORDER BY stock_group_id, stock_code NULLS FIRST;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END stocks_on_date;
   
--------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created :
-- Modification : 
-- Editor  : Pavel Vasiliev
-- Changed : 21.09.2010 
-- Purpose : Метод возвращает данные для отчета
--------------------------------------------------------------------------------
   PROCEDURE GetEquipmentListByStock 
     (p_date_of_serch         IN  DATE,
      p_detailed              IN  NUMBER,
      p_eqp_type_code_list    IN  t_varchar2,
      p_eqp_model_code_list   IN  t_varchar2,
      p_group_stock_id_list   IN  t_number,
      p_stock_code_list       IN  t_varchar2,
      p_valid_until           IN  DATE,
      p_ref                   OUT sys_refcursor,
      ResultCode              OUT NUMBER)
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'GetEquipmentListByStock';
      
      v_eqp_type_codes        CT_VARCHAR := CT_VARCHAR();
      v_eqp_model_codes       CT_VARCHAR := CT_VARCHAR();
      v_eqp_model_ids         pkg_common.t_num;
      v_stock_group_ids       CT_NUMBER := CT_NUMBER();
      v_stock_codes           CT_VARCHAR := CT_VARCHAR();
      v_stock_id              pkg_common.t_num;
      v_count                 NUMBER;
      v_date_of_serch         DATE := nvl(p_date_of_serch,SYSDATE);
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_date_of_serch
                         || pkg_constants.c_delimiter
                         || p_detailed
                         || pkg_constants.c_delimiter
                         || p_valid_until
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || ')',
                         pkg_name
                        );
      IF p_eqp_type_code_list IS NULL OR 
         p_eqp_type_code_list.COUNT = 0 OR
         (p_eqp_type_code_list.COUNT = 1 AND p_eqp_type_code_list(p_eqp_type_code_list.FIRST) IS NULL)
      THEN
        RAISE_APPLICATION_ERROR(-99999, 'Missing some mandatory parameter.');
      END IF;  
  
      ResultCode := 0;
      
      v_count := 0;     
      FOR i IN nvl(p_eqp_type_code_list.first,1) .. nvl(p_eqp_type_code_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_eqp_type_codes.Extend;
        v_eqp_type_codes(v_count):= p_eqp_type_code_list(i);
      END LOOP;
      
      v_count := 0;    
      FOR i IN nvl(p_eqp_model_code_list.first,1) .. nvl(p_eqp_model_code_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_eqp_model_codes.Extend;
        v_eqp_model_codes(v_count):= p_eqp_model_code_list(i);
      END LOOP;
      
      --Получим id всех моделей оборудывания
      
      IF (p_eqp_model_code_list IS NULL
        OR p_eqp_model_code_list.COUNT = 0 
        OR (p_eqp_model_code_list.COUNT = 1 AND p_eqp_model_code_list(p_eqp_model_code_list.first) IS NULL))
      THEN
        SELECT distinct em.equipment_model_id 
          BULK COLLECT INTO v_eqp_model_ids
          FROM EQUIPMENT_MODEL em 
               WHERE em.equipment_type_id IN (SELECT et.EQUIPMENT_TYPE_ID 
                                                     FROM EQUIPMENT_TYPE et
                                                     WHERE et.EQUIPMENT_TYPE_CODE IN (SELECT COLUMN_VALUE
                                                                                        FROM TABLE(CAST(v_eqp_type_codes as CT_VARCHAR))));
      ELSE
        SELECT distinct em.equipment_model_id 
          BULK COLLECT INTO v_eqp_model_ids
          FROM EQUIPMENT_MODEL em 
               WHERE em.equipment_type_id IN (SELECT et.EQUIPMENT_TYPE_ID 
                                                     FROM EQUIPMENT_TYPE et
                                                     WHERE et.EQUIPMENT_TYPE_CODE IN (SELECT COLUMN_VALUE
                                                                                        FROM TABLE(CAST(v_eqp_type_codes as CT_VARCHAR))))
                AND em.equipment_model_code IN(SELECT COLUMN_VALUE
                                                  FROM TABLE(CAST(v_eqp_model_codes as CT_VARCHAR)));
      END IF;
      
      v_count := v_eqp_model_ids.COUNT;
      --dbms_output.put_line('Count equipments: ' || v_count);
      pkg_db_util.DEBUG (prc_name, 'Count equipment = ' || v_count, pkg_name);
      IF v_count = 0 AND
           (NOT(p_eqp_type_code_list IS NULL OR 
             p_eqp_type_code_list.COUNT = 0 OR
             (p_eqp_type_code_list.COUNT = 1 AND p_eqp_type_code_list(p_eqp_type_code_list.FIRST) IS NULL))   
            OR 
            NOT(p_eqp_model_code_list IS NULL OR
             p_eqp_model_code_list.COUNT = 0 OR
             (p_eqp_model_code_list.COUNT = 1 AND p_eqp_model_code_list(p_eqp_model_code_list.first) IS NULL)))
      THEN
        -- if p_eqp_type_code_list is not empty or p_eqp_model_code_list is not epmty,
        -- bat v_eqp_model_ids is empty - v_date_to result is empty cursor
        OPEN p_ref FOR                   
            SELECT null as equipment_type_name, 
                   null as equipment_model_code, 
                   null as equipment_model_name,
                   null as quantity, 
                   null as stock_code, 
                   null as stock_name, 
                   null as valid_until  
               FROM DUAL
                 WHERE 1 <> 1; 
        pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
        RETURN;
      END IF;   

      v_count := 0;     
      FOR i IN nvl(p_group_stock_id_list.first,1) .. nvl(p_group_stock_id_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_stock_group_ids.Extend;
        v_stock_group_ids(v_count):= p_group_stock_id_list(i);
      END LOOP;
      
      v_count := 0;     
      FOR i IN nvl(p_stock_code_list.first,1) .. nvl(p_stock_code_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_stock_codes.Extend;
        v_stock_codes(v_count):= p_stock_code_list(i);
      END LOOP;
      
      -- Получим Id всех складов
      SELECT distinct s.id 
        BULK COLLECT INTO v_stock_id
        FROM stock s
        WHERE s.code IN (SELECT COLUMN_VALUE
                           FROM TABLE(CAST(v_stock_codes as CT_VARCHAR)))
        OR s.stock_group_id IN (SELECT distinct ID 
              FROM (SELECT t.ID, CONNECT_BY_ROOT t.id parent_group_id FROM stock_group t
                                CONNECT BY PRIOR t.ID = t.stock_group_id) 
             WHERE parent_group_id IN (SELECT COLUMN_VALUE
                                                  FROM TABLE(CAST(v_stock_group_ids as CT_NUMBER))));
      
      --Заполним коллекцию идентификаторов складов
      pkg_stock.set_stockid (p_stock_id => v_stock_id);
      --Заполним коллекцию идентификаторов оборудования...
      pkg_equipment.set_modelid (p_model_id_1 => v_eqp_model_ids);
      --Восстановим все движение оборудования на заданную дату
      stock_state_reverse (p_date_from => v_date_of_serch,
                               p_date_to=> SYSDATE
                              );
      IF (p_detailed = 1)
      THEN
        BEGIN
              OPEN p_ref FOR
                SELECT   et.equipment_type_name, 
                         em.equipment_model_code, 
                         em.equipment_model_name,
                         quantity, 
                         s.code as stock_code, 
                         s.name as stock_name, 
                         TO_DATE(null, util_pkg.c_date_format_full) as valid_until                 
                    FROM (SELECT   stock_id, equipment_model_id,
                                   SUM (quantity_from) AS quantity
                              FROM tmp_ss4
                             WHERE 1 = 1
                             AND (p_valid_until IS NULL OR p_valid_until >= valid_until)
                          GROUP BY stock_id,
                                   equipment_model_id) tmp
                         LEFT JOIN equipment_model em ON em.equipment_model_id = tmp.equipment_model_id
                         LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id
                         LEFT JOIN stock s ON s.id = tmp.stock_id
                         WHERE quantity <> 0
                ORDER BY tmp.equipment_model_id, tmp.stock_id;
        END;
      ELSE IF (p_detailed = 2)
        THEN
          BEGIN
              OPEN p_ref FOR
                SELECT   et.equipment_type_name, 
                         em.equipment_model_code, 
                         em.equipment_model_name,
                         quantity, 
                         null as stock_code, 
                         null as stock_name, 
                         tmp.valid_until                   
                    FROM (SELECT   equipment_model_id,
                                   SUM (quantity_from) AS quantity,
                                   valid_until
                              FROM tmp_ss4
                             WHERE 1 = 1
                             AND (p_valid_until IS NULL OR p_valid_until >= valid_until)
                          GROUP BY equipment_model_id,
                                   valid_until) tmp
                         LEFT JOIN equipment_model em ON em.equipment_model_id = tmp.equipment_model_id
                         LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id
                         WHERE quantity <> 0
                ORDER BY tmp.equipment_model_id, tmp.valid_until;
          END;
        ELSE IF (p_detailed = 3)
          THEN
            BEGIN
              OPEN p_ref FOR
                SELECT   et.equipment_type_name, 
                         em.equipment_model_code, 
                         em.equipment_model_name,
                         quantity, 
                         s.code as stock_code, 
                         s.name as stock_name, 
                         tmp.valid_until                   
                    FROM (SELECT   stock_id, equipment_model_id,
                                   SUM (quantity_from) AS quantity,
                                   valid_until
                              FROM tmp_ss4
                             WHERE 1 = 1
                             AND (p_valid_until IS NULL OR p_valid_until >= valid_until)
                          GROUP BY stock_id,
                                   equipment_model_id,
                                   valid_until) tmp
                         LEFT JOIN equipment_model em ON em.equipment_model_id = tmp.equipment_model_id
                         LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id
                         LEFT JOIN stock s ON s.id = tmp.stock_id
                         WHERE quantity <> 0
                ORDER BY tmp.equipment_model_id, tmp.stock_id, tmp.valid_until;
            END;
          ELSE
            BEGIN
              OPEN p_ref FOR
                SELECT   et.equipment_type_name, 
                         em.equipment_model_code, 
                         em.equipment_model_name,
                         quantity, 
                         null as stock_code, 
                         null as stock_name, 
                         TO_DATE(null, util_pkg.c_date_format_full) as valid_until                 
                    FROM (SELECT   equipment_model_id,
                                   SUM (quantity_from) AS quantity
                              FROM tmp_ss4
                             WHERE 1 = 1
                             AND (p_valid_until IS NULL OR p_valid_until >= valid_until)
                          GROUP BY equipment_model_id) tmp
                         LEFT JOIN equipment_model em ON em.equipment_model_id = tmp.equipment_model_id
                         LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id
                         WHERE quantity <> 0
                ORDER BY tmp.equipment_model_id;
            END;
          END IF;
        END IF;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         ResultCode := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END GetEquipmentListByStock;
   
   --------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created :
-- Modification : 
-- Editor  : Pavel Vasiliev
-- Changed : 21.09.2010 
-- Purpose : Метод возвращает данные для отчета
--------------------------------------------------------------------------------
   PROCEDURE GetInventaryByStock 
     (p_date_of_serch         IN  DATE,
      p_detailed              IN  NUMBER,
      p_eqp_type_code_list    IN  t_varchar2,
      p_eqp_model_code_list   IN  t_varchar2,
      p_group_stock_id_list   IN  t_number,
      p_stock_code_list       IN  t_varchar2,
      p_ref                   OUT sys_refcursor,
      ResultCode              OUT NUMBER)
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'GetInventaryByStock';
      
      v_eqp_type_codes        CT_VARCHAR := CT_VARCHAR();
      v_eqp_model_codes       CT_VARCHAR := CT_VARCHAR();
      v_eqp_model_ids         pkg_common.t_num;
      v_stock_group_ids       CT_NUMBER := CT_NUMBER();
      v_stock_codes           CT_VARCHAR := CT_VARCHAR();
      v_stock_id              pkg_common.t_num;
      v_count                 NUMBER;
      v_date_of_serch         DATE := nvl(p_date_of_serch,SYSDATE);
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_date_of_serch
                         || pkg_constants.c_delimiter
                         || p_detailed
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || ')',
                         pkg_name
                        );
      IF p_eqp_type_code_list IS NULL OR 
         p_eqp_type_code_list.COUNT = 0 OR
         (p_eqp_type_code_list.COUNT = 1 AND p_eqp_type_code_list(p_eqp_type_code_list.FIRST) IS NULL)
      THEN
        RAISE_APPLICATION_ERROR(-99999, 'Missing some mandatory parameter.');
      END IF;  
  
      ResultCode := 0;
      
      v_count := 0;     
      FOR i IN nvl(p_eqp_type_code_list.first,1) .. nvl(p_eqp_type_code_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_eqp_type_codes.Extend;
        v_eqp_type_codes(v_count):= p_eqp_type_code_list(i);
      END LOOP;
      
      v_count := 0;    
      FOR i IN nvl(p_eqp_model_code_list.first,1) .. nvl(p_eqp_model_code_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_eqp_model_codes.Extend;
        v_eqp_model_codes(v_count):= p_eqp_model_code_list(i);
      END LOOP;
      
      --Получим id всех моделей оборудывания
      
      IF (p_eqp_model_code_list IS NULL
        OR p_eqp_model_code_list.COUNT = 0 
        OR (p_eqp_model_code_list.COUNT = 1 AND p_eqp_model_code_list(p_eqp_model_code_list.first) IS NULL))
      THEN
        SELECT distinct em.equipment_model_id 
          BULK COLLECT INTO v_eqp_model_ids
          FROM EQUIPMENT_MODEL em 
               WHERE em.equipment_type_id IN (SELECT et.EQUIPMENT_TYPE_ID 
                                                     FROM EQUIPMENT_TYPE et
                                                     WHERE et.EQUIPMENT_TYPE_CODE IN (SELECT COLUMN_VALUE
                                                                                        FROM TABLE(CAST(v_eqp_type_codes as CT_VARCHAR))));
      ELSE
        SELECT distinct em.equipment_model_id 
          BULK COLLECT INTO v_eqp_model_ids
          FROM EQUIPMENT_MODEL em 
               WHERE em.equipment_type_id IN (SELECT et.EQUIPMENT_TYPE_ID 
                                                     FROM EQUIPMENT_TYPE et
                                                     WHERE et.EQUIPMENT_TYPE_CODE IN (SELECT COLUMN_VALUE
                                                                                        FROM TABLE(CAST(v_eqp_type_codes as CT_VARCHAR))))
                AND em.equipment_model_code IN(SELECT COLUMN_VALUE
                                                  FROM TABLE(CAST(v_eqp_model_codes as CT_VARCHAR)));
      END IF;
      
      v_count := v_eqp_model_ids.COUNT;
      --dbms_output.put_line('Count equipments: ' || v_count);
      pkg_db_util.DEBUG (prc_name, 'Count equipment = ' || v_count, pkg_name);
      IF v_count = 0 AND
           (NOT(p_eqp_type_code_list IS NULL OR 
             p_eqp_type_code_list.COUNT = 0 OR
             (p_eqp_type_code_list.COUNT = 1 AND p_eqp_type_code_list(p_eqp_type_code_list.FIRST) IS NULL))   
            OR 
            NOT(p_eqp_model_code_list IS NULL OR
             p_eqp_model_code_list.COUNT = 0 OR
             (p_eqp_model_code_list.COUNT = 1 AND p_eqp_model_code_list(p_eqp_model_code_list.first) IS NULL)))
      THEN
        -- if p_eqp_type_code_list is not empty or p_eqp_model_code_list is not epmty,
        -- bat v_eqp_model_ids is empty - v_date_to result is empty cursor
        OPEN p_ref FOR                   
            SELECT null as equipment_type_name, 
                   null as equipment_model_code, 
                   null as equipment_model_name,
                   null as stock_code, 
                   null as stock_name, 
                   null as quantity, 
                   null as seria_start, 
                   null as seria_end, 
                   TO_DATE(null, util_pkg.c_date_format_full) as valid_until 
               FROM DUAL
                 WHERE 1 <> 1; 
        pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
        RETURN;
      END IF;  

      v_count := 0;     
      FOR i IN nvl(p_group_stock_id_list.first,1) .. nvl(p_group_stock_id_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_stock_group_ids.Extend;
        v_stock_group_ids(v_count):= p_group_stock_id_list(i);
      END LOOP;
      
      v_count := 0;     
      FOR i IN nvl(p_stock_code_list.first,1) .. nvl(p_stock_code_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_stock_codes.Extend;
        v_stock_codes(v_count):= p_stock_code_list(i);
      END LOOP;
      
      -- Получим Id всех складов
      SELECT distinct s.id 
        BULK COLLECT INTO v_stock_id
        FROM stock s
        WHERE s.code IN (SELECT COLUMN_VALUE
                           FROM TABLE(CAST(v_stock_codes as CT_VARCHAR)))
        OR s.stock_group_id IN (SELECT distinct ID 
              FROM (SELECT t.ID, CONNECT_BY_ROOT t.id parent_group_id FROM stock_group t
                                CONNECT BY PRIOR t.ID = t.stock_group_id) 
             WHERE parent_group_id IN (SELECT COLUMN_VALUE
                                                  FROM TABLE(CAST(v_stock_group_ids as CT_NUMBER))));
      
      --Заполним коллекцию идентификаторов складов
      pkg_stock.set_stockid (p_stock_id => v_stock_id);
      --Заполним коллекцию идентификаторов оборудования...
      pkg_equipment.set_modelid (p_model_id_1 => v_eqp_model_ids);
       --Восстановим все движение оборудования на заданную дату
      stock_state_reverse (p_date_from => v_date_of_serch,
                               p_date_to=> SYSDATE
                              );
                
                /*      SELECT   et.equipment_type_name, em.equipment_model_code, em.equipment_model_name,
                     quantity, s.code, s.name, tmp.seria_start, tmp.seria_end, tmp.valid_until                   
                FROM (SELECT   b.stock_id, b.equipment_model_id, MIN (b.seria_start) AS seria_start,
                          MAX (b.seria_end) AS seria_end,
                          SUM (b.quantity_onstock) AS quantity_onstock,
                          SUM (b.quantity_reserved) AS quantity_reserved,
                          SUM (b.quantity_announced) AS quantity_announced
                     FROM (SELECT a.stock_id, a.equipment_model_id, a.seria_start, a.seria_end,
                                  a.quantity_onstock, a.quantity_reserved, a.quantity_announced,
                                  SUM (a.start_of_group) OVER (PARTITION BY a.equipment_model_id, a.stock_id ORDER BY a.seria_start)
                                                                                        AS group_no
                             FROM (SELECT --+ DYNAMIC_SAMPLING(t 2) CARDINALITY(vet 5) CARDINALITY(em 10)
                                          t.stock_id, t.equipment_model_id, t.seria_start,
                                          t.seria_end, t.quantity_onstock, t.quantity_reserved,
                                          t.quantity_announced,
                                          CASE
                                             WHEN (    vet.is_numeric_serial_number = 'Y'
                                                   AND vet.allows_partitioning = 'Y'
                                                  )
                                                THEN DECODE
                                                       (TO_NUMBER
                                                           (LAG (t.seria_end) OVER (PARTITION BY t.equipment_model_id, t.stock_id ORDER BY t.seria_start)
                                                           ),
                                                        TO_NUMBER (t.seria_start) - 1, NULL,
                                                        '1'
                                                       )
                                             ELSE '1'
                                          END start_of_group
                                     FROM tmp_ss1 t, vw_equipment_type vet, equipment_model em
                                    WHERE (   (    seria_start BETWEEN l_ss AND l_se
                                               AND seria_end BETWEEN l_ss AND l_se
                                               AND LENGTH (seria_start) = LENGTH (l_ss)
                                              )
                                           OR (l_ss = '0')
                                          )
                                      AND em.equipment_type_id = vet.equipment_type_id
                                      AND t.equipment_model_id = em.equipment_model_id) a) b
                 GROUP BY b.stock_id, b.equipment_model_id, b.group_no)  tmp
                         LEFT JOIN equipment_model em ON em.equipment_model_id = tmp.equipment_model_id
                         LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id
                         LEFT JOIN stock s ON s.id = tmp.stock_id
                ORDER BY tmp.stock_id, tmp.equipment_model_id;      */   
                              
      IF (p_detailed = 1)
      THEN
        BEGIN
          OPEN p_ref FOR                   
            SELECT et.equipment_type_name, 
                   em.equipment_model_code, 
                   em.equipment_model_name,
                   s.code as stock_code, 
                   s.name as stock_name, 
                   quantity, 
                   tmp.seria_start, 
                   tmp.seria_end, 
                   tmp.valid_until                   
                      FROM (SELECT   b.stock_id, b.equipment_model_id, MIN (b.seria_start) AS seria_start,
                                MAX (b.seria_end) AS seria_end,
                                SUM (b.quantity_from) AS quantity,
                                b.valid_until
                           FROM (SELECT a.stock_id, a.equipment_model_id, a.seria_start, a.seria_end,
                                        a.quantity_from,
                                        SUM (a.start_of_group) OVER (PARTITION BY a.equipment_model_id, a.stock_id ORDER BY a.seria_start)
                                                                                              AS group_no,
                                        a.valid_until
                                   FROM (SELECT --+ DYNAMIC_SAMPLING(t 2) CARDINALITY(vet 5) CARDINALITY(em 10)
                                                t.stock_id, t.equipment_model_id, t.seria_start,
                                                t.seria_end, t.quantity_from,
                                                t.valid_until,
                                                CASE
                                                   WHEN (    vet.is_numeric_serial_number = 'Y'
                                                         AND vet.allows_partitioning = 'Y'
                                                        )
                                                      THEN DECODE
                                                             (TO_NUMBER
                                                                 (LAG (t.seria_end) OVER (PARTITION BY t.equipment_model_id, t.stock_id ORDER BY t.seria_start)
                                                                 ),
                                                              TO_NUMBER (t.seria_start) - 1, NULL,
                                                              '1'
                                                             )
                                                   ELSE '1'
                                                END start_of_group
                                           FROM tmp_ss4 t, vw_equipment_type vet, equipment_model em
                                            WHERE em.equipment_type_id = vet.equipment_type_id
                                            AND t.equipment_model_id = em.equipment_model_id) a) b
                       GROUP BY b.stock_id, b.equipment_model_id, b.group_no,b.valid_until)  tmp
                               LEFT JOIN equipment_model em ON em.equipment_model_id = tmp.equipment_model_id
                               LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id
                               LEFT JOIN stock s ON s.id = tmp.stock_id
                         WHERE quantity <> 0
                      ORDER BY tmp.stock_id, tmp.equipment_model_id; 
        END;
      ELSE
        BEGIN
          OPEN p_ref FOR
            SELECT et.equipment_type_name, 
                   em.equipment_model_code, 
                   em.equipment_model_name,
                   s.code as stock_code, 
                   s.name as stock_name, 
                   quantity, 
                   null as seria_start, 
                   null as seria_end, 
                   TO_DATE(null, util_pkg.c_date_format_full) as valid_until                   
                FROM (SELECT   stock_id, equipment_model_id,
                                   SUM (quantity_from) AS quantity
                              FROM tmp_ss4
                          GROUP BY stock_id,
                                   equipment_model_id) tmp
                         LEFT JOIN equipment_model em ON em.equipment_model_id = tmp.equipment_model_id
                         LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id
                         LEFT JOIN stock s ON s.id = tmp.stock_id
                         WHERE quantity <> 0
                ORDER BY tmp.stock_id, tmp.equipment_model_id;
        END;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         ResultCode := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END GetInventaryByStock;
   
--------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created :
-- Modification : 
-- Editor  : Pavel Vasiliev
-- Changed : 21.09.2010 
-- Purpose : Метод возвращает данные для отчета
--------------------------------------------------------------------------------
   PROCEDURE GetReverseBalanceByStock 
     (p_date_from             IN  DATE,
      p_date_to               IN  DATE,
      p_detailed              IN  NUMBER,
      p_eqp_type_code_list    IN  t_varchar2,
      p_eqp_model_code_list   IN  t_varchar2,
      p_group_stock_id_list   IN  t_number,
      p_stock_code_list       IN  t_varchar2,
      p_ref                   OUT sys_refcursor,
      ResultCode              OUT NUMBER)
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'GetReverseBalanceByStock';
      
      v_eqp_type_codes        CT_VARCHAR := CT_VARCHAR();
      v_eqp_model_codes       CT_VARCHAR := CT_VARCHAR();
      v_eqp_model_ids         pkg_common.t_num;
      v_stock_group_ids       CT_NUMBER := CT_NUMBER();
      v_stock_codes           CT_VARCHAR := CT_VARCHAR();
      v_stock_id              pkg_common.t_num;
      v_count                 NUMBER;
      v_date_from             DATE := nvl(p_date_from, SYSDATE);
      v_date_to               DATE := nvl(p_date_to, SYSDATE);
      
   BEGIN
      ResultCode := 0;
   
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_date_from
                         || pkg_constants.c_delimiter
                         || p_date_to
                         || pkg_constants.c_delimiter
                         || p_detailed
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || ')',
                         pkg_name
                        );
                        
      IF v_date_from > v_date_to
      THEN
        -- if v_date_from > v_date_to result is empty cursor
        OPEN p_ref FOR                   
            SELECT null as equipment_type_name, 
                   null as equipment_model_code, 
                   null as equipment_model_name,
                   null as quantity_from, 
                   null as quantity_rec, 
                   null as quantity_ship, 
                   null as quantity_to,
                   TO_DATE(null, util_pkg.c_date_format_full) as doc_date, 
                   null as doc_number, 
                   null as seria_start, 
                   null as seria_end  
               FROM DUAL
                 WHERE 1 <> 1; 
        pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
        RETURN;
      END IF;
                              
      IF p_eqp_type_code_list IS NULL OR 
         p_eqp_type_code_list.COUNT = 0 OR
         (p_eqp_type_code_list.COUNT = 1 AND p_eqp_type_code_list(p_eqp_type_code_list.FIRST) IS NULL)
      THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_missing_parameter, 'Missing some mandatory parameter.');
      END IF;  
        
      v_count := 0;     
      FOR i IN nvl(p_eqp_type_code_list.first,1) .. nvl(p_eqp_type_code_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_eqp_type_codes.Extend;
        v_eqp_type_codes(v_count):= p_eqp_type_code_list(i);
      END LOOP;
      
      v_count := 0;    
      FOR i IN nvl(p_eqp_model_code_list.first,1) .. nvl(p_eqp_model_code_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_eqp_model_codes.Extend;
        v_eqp_model_codes(v_count):= p_eqp_model_code_list(i);
      END LOOP;
      
      --Получим id всех моделей оборудывания
      
      IF (p_eqp_model_code_list IS NULL
        OR p_eqp_model_code_list.COUNT = 0 
        OR (p_eqp_model_code_list.COUNT = 1 AND p_eqp_model_code_list(p_eqp_model_code_list.first) IS NULL))
      THEN
        SELECT distinct em.equipment_model_id 
          BULK COLLECT INTO v_eqp_model_ids
          FROM EQUIPMENT_MODEL em 
               WHERE em.equipment_type_id IN (SELECT et.EQUIPMENT_TYPE_ID 
                                                     FROM EQUIPMENT_TYPE et
                                                     WHERE et.EQUIPMENT_TYPE_CODE IN (SELECT COLUMN_VALUE
                                                                                        FROM TABLE(CAST(v_eqp_type_codes as CT_VARCHAR))));
      ELSE
        SELECT distinct em.equipment_model_id 
          BULK COLLECT INTO v_eqp_model_ids
          FROM EQUIPMENT_MODEL em 
               WHERE em.equipment_type_id IN (SELECT et.EQUIPMENT_TYPE_ID 
                                                     FROM EQUIPMENT_TYPE et
                                                     WHERE et.EQUIPMENT_TYPE_CODE IN (SELECT COLUMN_VALUE
                                                                                        FROM TABLE(CAST(v_eqp_type_codes as CT_VARCHAR))))
                AND em.equipment_model_code IN(SELECT COLUMN_VALUE
                                                  FROM TABLE(CAST(v_eqp_model_codes as CT_VARCHAR)));
      END IF;
      
      v_count := v_eqp_model_ids.COUNT;
      --dbms_output.put_line('Count equipments: ' || v_count);
      pkg_db_util.DEBUG (prc_name, 'Count equipment = ' || v_count, pkg_name);
      IF v_count = 0 AND
           (NOT(p_eqp_type_code_list IS NULL OR 
             p_eqp_type_code_list.COUNT = 0 OR
             (p_eqp_type_code_list.COUNT = 1 AND p_eqp_type_code_list(p_eqp_type_code_list.FIRST) IS NULL))   
            OR 
            NOT(p_eqp_model_code_list IS NULL OR
             p_eqp_model_code_list.COUNT = 0 OR
             (p_eqp_model_code_list.COUNT = 1 AND p_eqp_model_code_list(p_eqp_model_code_list.first) IS NULL)))
      THEN
        -- if p_eqp_type_code_list is not empty or p_eqp_model_code_list is not epmty,
        -- bat v_eqp_model_ids is empty - v_date_to result is empty cursor
        OPEN p_ref FOR                   
            SELECT null as equipment_type_name, 
                   null as equipment_model_code, 
                   null as equipment_model_name,
                   null as quantity_from, 
                   null as quantity_rec, 
                   null as quantity_ship, 
                   null as quantity_to,
                   TO_DATE(null, util_pkg.c_date_format_full) as doc_date, 
                   null as doc_number, 
                   null as seria_start, 
                   null as seria_end  
               FROM DUAL
                 WHERE 1 <> 1; 
        pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
        RETURN;
      END IF;
      
      v_count := 0;     
      FOR i IN nvl(p_group_stock_id_list.first,1) .. nvl(p_group_stock_id_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_stock_group_ids.Extend;
        v_stock_group_ids(v_count):= p_group_stock_id_list(i);
      END LOOP;
      
      v_count := 0;     
      FOR i IN nvl(p_stock_code_list.first,1) .. nvl(p_stock_code_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_stock_codes.Extend;
        v_stock_codes(v_count):= p_stock_code_list(i);
      END LOOP;
      
      -- Получим Id всех складов
      SELECT distinct s.id 
        BULK COLLECT INTO v_stock_id
        FROM stock s
        WHERE s.code IN (SELECT COLUMN_VALUE
                           FROM TABLE(CAST(v_stock_codes as CT_VARCHAR)))
        OR s.stock_group_id IN (SELECT distinct ID 
              FROM (SELECT t.ID, CONNECT_BY_ROOT t.id parent_group_id FROM stock_group t
                                CONNECT BY PRIOR t.ID = t.stock_group_id) 
             WHERE parent_group_id IN (SELECT COLUMN_VALUE
                                                  FROM TABLE(CAST(v_stock_group_ids as CT_NUMBER))));
      
      --Заполним коллекцию идентификаторов складов
      pkg_stock.set_stockid (p_stock_id => v_stock_id);
      --Заполним коллекцию идентификаторов оборудования...
      pkg_equipment.set_modelid (p_model_id_1 => v_eqp_model_ids);
      --Восстановим все движение оборудования на заданный период
      stock_state_reverse (p_date_from => v_date_from,
                               p_date_to=> v_date_to
                              );
   
     IF (p_detailed = 1)
      THEN
        BEGIN
          OPEN p_ref FOR  
          SELECT *  FROM
            (SELECT et.equipment_type_name, 
                   em.equipment_model_code, 
                   em.equipment_model_name,
                   tmp.quantity_from, 
                   tmp.quantity_rec, 
                   tmp.quantity_ship, 
                   tmp.quantity_to,
                   dh.doc_date, 
                   tmp.document_no as doc_number, 
                   tmp.seria_start, 
                   tmp.seria_end                   
                      FROM (SELECT   b.equipment_model_id, 
                                MIN (b.seria_start) AS seria_start,
                                MAX (b.seria_end) AS seria_end,
                                to_number(null) quantity_from,--SUM (b.quantity_from) as quantity_from,
                                SUM (b.quantity_rec) as quantity_rec,
                                SUM (b.quantity_ship) as quantity_ship,
                                to_number(null)  quantity_to,--SUM (b.quantity_to) as quantity_to,
                                b.valid_until, 
                                b.doc_header_id,
                                b.document_no
                           FROM (SELECT a.equipment_model_id, 
                                        a.seria_start, 
                                        a.seria_end,
                                        a.quantity_from, 
                                        a.quantity_rec,
                                        a.quantity_ship, 
                                        a.quantity_to,
                                        SUM (a.start_of_group) OVER (PARTITION BY a.equipment_model_id ORDER BY a.seria_start)
                                                                                              AS group_no,
                                        a.valid_until, 
                                        a.doc_header_id, 
                                        a.document_no
                                   FROM (SELECT --+ DYNAMIC_SAMPLING(t 2) CARDINALITY(vet 5) CARDINALITY(em 10)
                                                t.equipment_model_id, 
                                                t.seria_start,
                                                t.seria_end, 
                                                t.quantity_from, 
                                                t.quantity_rec,
                                                t.quantity_ship, 
                                                t.quantity_to,
                                                t.valid_until, 
                                                t.doc_header_id, 
                                                t.document_no,
                                                CASE
                                                   WHEN (    vet.is_numeric_serial_number = 'Y'
                                                         AND vet.allows_partitioning = 'Y'
                                                        )
                                                      THEN DECODE
                                                             (TO_NUMBER
                                                                 (LAG (t.seria_end) OVER (PARTITION BY t.equipment_model_id ORDER BY t.seria_start)
                                                                 ),
                                                              TO_NUMBER (t.seria_start) - 1, NULL,
                                                              '1'
                                                             )
                                                   ELSE '1'
                                                END start_of_group
                                           FROM tmp_ss4 t, vw_equipment_type vet, equipment_model em
                                            WHERE em.equipment_type_id = vet.equipment_type_id
                                            AND t.equipment_model_id = em.equipment_model_id
                                            AND t.doc_type_id IN (101, 102, 103, 106, 107)
                                            ) a) b
                       GROUP BY b.equipment_model_id, b.group_no,b.valid_until, b.doc_header_id,b.document_no) tmp
                               LEFT JOIN equipment_model em ON em.equipment_model_id = tmp.equipment_model_id
                               LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id
                               LEFT JOIN doc_header dh on dh.id = tmp.doc_header_id
                          WHERE NOT (tmp.quantity_from = 0 AND
                                     tmp.quantity_rec = 0 AND
                                     tmp.quantity_ship = 0 AND
                                     tmp.quantity_to = 0)      
                      ORDER BY tmp.equipment_model_id)
             union all
              select  --+ DYNAMIC_SAMPLING(t 2) CARDINALITY(vet 5) CARDINALITY(em 10)
                 et.equipment_type_name, 
                 em.equipment_model_code, 
                 em.equipment_model_name,
                 quantity_from, 
                 quantity_rec, 
                 quantity_ship, 
                 quantity_to,
                 doc_date, 
                 doc_number, 
                 seria_start, 
                 seria_end
                 from 
                (SELECT
                   sum(tmp2.quantity_from) quantity_from, 
                   to_number(null) quantity_rec, 
                   to_number(null) quantity_ship, 
                   sum(tmp2.quantity_to) quantity_to,
                   null doc_date, 
                   null doc_number, 
                   null seria_start, 
                   null seria_end,
                   tmp2.equipment_model_id   
                 FROM tmp_ss4 tmp2
                 group by tmp2.equipment_model_id) d
                 LEFT JOIN equipment_model em ON em.equipment_model_id = d.equipment_model_id
                 LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id;
        END;
      ELSE
        BEGIN
          OPEN p_ref FOR
             SELECT et.equipment_type_name, 
                    em.equipment_model_code, 
                    em.equipment_model_name,
                    quantity_from, 
                    quantity_rec, 
                    quantity_ship, 
                    quantity_to,
                    TO_DATE(null, util_pkg.c_date_format_full) as doc_date, 
                    null as doc_number, 
                    null as seria_start, 
                    null as seria_end                   
                      FROM (SELECT   equipment_model_id,
                                   SUM (quantity_from) as quantity_from,
                                   SUM (quantity_rec) as quantity_rec,
                                   SUM (quantity_ship) as quantity_ship,
                                   SUM (quantity_to) as quantity_to
                            FROM tmp_ss4 t
                                --WHERE t.doc_type_id IN (101, 102, 103, 106, 107)
                          GROUP BY equipment_model_id) tmp
                               LEFT JOIN equipment_model em ON em.equipment_model_id = tmp.equipment_model_id
                               LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id
                          WHERE NOT (tmp.quantity_from = 0 AND
                                     tmp.quantity_rec = 0 AND
                                     tmp.quantity_ship = 0 AND
                                     tmp. quantity_to = 0)    
                      ORDER BY tmp.equipment_model_id; 
        END;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      
   EXCEPTION
      WHEN OTHERS
      THEN
         ResultCode := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END GetReverseBalanceByStock;
   
--------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created :
-- Modification : 
-- Editor  : Pavel Vasiliev
-- Changed : 21.09.2010 
-- Purpose : Метод возвращает данные для отчета
--------------------------------------------------------------------------------
   PROCEDURE GetMoveOfEquipment 
     (p_date_from                IN  DATE,
      p_date_to                  IN  DATE,
      p_doc_type                 IN  NUMBER,
      p_detailed                 IN  NUMBER,
      p_eqp_model_code_list      IN  t_varchar2,
      p_group_stock_id_in_list   IN  t_number,
      p_stock_code_in_list       IN  t_varchar2,
      p_group_stock_id_out_list  IN  t_number,
      p_stock_code_out_list      IN  t_varchar2,
      p_cur_eqm_move             OUT sys_refcursor,
      ResultCode                 OUT NUMBER)
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'GetMoveOfEquipment';
      
      --v_eqp_type_codes        CT_VARCHAR := CT_VARCHAR();
      v_eqp_model_codes       CT_VARCHAR := CT_VARCHAR();
      v_eqp_model_ids         pkg_common.t_num;
      v_stock_group_in_ids    CT_NUMBER := CT_NUMBER();
      v_stock_in_codes        CT_VARCHAR := CT_VARCHAR();
      v_stock_in_id           pkg_common.t_num;
      v_stock_group_out_ids   CT_NUMBER := CT_NUMBER();
      v_stock_out_codes       CT_VARCHAR := CT_VARCHAR();
      v_stock_out_id          pkg_common.t_num;
      v_count                 NUMBER;
      v_date_from             DATE := nvl(p_date_from,SYSDATE);
      v_date_to               DATE := nvl(p_date_to,SYSDATE);
      v_errorM                VARCHAR2(1000);
   BEGIN
      ResultCode := 0;   
   
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_date_from
                         || pkg_constants.c_delimiter
                         || p_date_to
                         || pkg_constants.c_delimiter
                         || p_detailed
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || ')',
                         pkg_name
                        );
      
      IF v_date_from > v_date_to
      THEN
        -- if v_date_from > v_date_to result is empty cursor
        OPEN p_cur_eqm_move FOR                   
            SELECT null as equipment_type_code, 
                   null as equipment_type_name, 
                   null as equipment_model_code, 
                   null as equipment_model_name,
                   null as quantity, 
                   null as stock_in_code, 
                   null as stock_out_code, 
                   TO_DATE(null, util_pkg.c_date_format_full) as doc_date, 
                   null as seria_start, 
                   null as seria_end  
               FROM DUAL
                 WHERE 1 <> 1; 
        pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
        RETURN;
      END IF;
      
      IF p_eqp_model_code_list IS NULL OR 
         p_eqp_model_code_list.COUNT = 0 OR
         (p_eqp_model_code_list.COUNT = 1 AND p_eqp_model_code_list(p_eqp_model_code_list.FIRST) IS NULL)
      THEN
        --RAISE_APPLICATION_ERROR(-90006, 'Missing some mandatory parameter.');
         --Получим id всех моделей оборудования
        SELECT distinct em.equipment_model_id 
          BULK COLLECT INTO v_eqp_model_ids
          FROM EQUIPMENT_MODEL em;
      ELSE
        v_count := 0;  
        FOR i IN nvl(p_eqp_model_code_list.first,1) .. nvl(p_eqp_model_code_list.last,0)
        LOOP
          v_count := v_count + 1;
          v_eqp_model_codes.Extend;
          v_eqp_model_codes(v_count):= p_eqp_model_code_list(i);
        END LOOP; 
        --Получим id заданных моделей оборудования
        SELECT distinct em.equipment_model_id 
          BULK COLLECT INTO v_eqp_model_ids
          FROM EQUIPMENT_MODEL em 
               WHERE em.equipment_model_code IN(SELECT COLUMN_VALUE
                                                  FROM TABLE(CAST(v_eqp_model_codes as CT_VARCHAR)));
      END IF;   
      
      v_count := v_eqp_model_ids.COUNT;
      --dbms_output.put_line('Count equipments: ' || v_count);
      pkg_db_util.DEBUG (prc_name, 'Count equipment = ' || v_count, pkg_name);
      IF v_count = 0 AND
             NOT(p_eqp_model_code_list IS NULL OR
             p_eqp_model_code_list.COUNT = 0 OR
             (p_eqp_model_code_list.COUNT = 1 AND p_eqp_model_code_list(p_eqp_model_code_list.first) IS NULL))
      THEN
        -- if p_eqp_type_code_list is not empty or p_eqp_model_code_list is not epmty,
        -- bat v_eqp_model_ids is empty - v_date_to result is empty cursor
        OPEN p_cur_eqm_move FOR                   
            SELECT null as equipment_type_code, 
                   null as equipment_type_name, 
                   null as equipment_model_code, 
                   null as equipment_model_name,
                   null as quantity, 
                   null as stock_in_code, 
                   null as stock_out_code, 
                   TO_DATE(null, util_pkg.c_date_format_full) as doc_date, 
                   null as seria_start, 
                   null as seria_end  
               FROM DUAL
                 WHERE 1 <> 1; 
        pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
        RETURN;
      END IF;        

      v_count := 0;     
      FOR i IN nvl(p_group_stock_id_in_list.first,1) .. nvl(p_group_stock_id_in_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_stock_group_in_ids.Extend;
        v_stock_group_in_ids(v_count):= p_group_stock_id_in_list(i);
      END LOOP;
      
      v_count := 0;     
      FOR i IN nvl(p_stock_code_in_list.first,1) .. nvl(p_stock_code_in_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_stock_in_codes.Extend;
        v_stock_in_codes(v_count):= p_stock_code_in_list(i);
      END LOOP;
      
      -- Получим Id всех in складов
      SELECT distinct s.id 
        BULK COLLECT INTO v_stock_in_id
        FROM stock s
        WHERE s.code IN (SELECT COLUMN_VALUE
                           FROM TABLE(CAST(v_stock_in_codes as CT_VARCHAR)))
        OR s.stock_group_id IN (SELECT distinct ID 
              FROM (SELECT t.ID, CONNECT_BY_ROOT t.id parent_group_id FROM stock_group t
                                CONNECT BY PRIOR t.ID = t.stock_group_id) 
             WHERE parent_group_id IN (SELECT COLUMN_VALUE
                                                  FROM TABLE(CAST(v_stock_group_in_ids as CT_NUMBER))));
      
      IF v_stock_in_id.count = 0 and p_doc_type in (util_stock.c_Doc_Type_Receipt, util_stock.c_Doc_Type_Movement, util_stock.c_Doc_Type_Credit)
      THEN
         raise_application_error (util_pkg.c_ora_missing_parameter, 'Stock in not found');
      END IF;   
                                                  
      v_count := 0;     
      FOR i IN nvl(p_group_stock_id_out_list.first,1) .. nvl(p_group_stock_id_out_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_stock_group_out_ids.Extend;
        v_stock_group_out_ids(v_count):= p_group_stock_id_out_list(i);
      END LOOP;
      
      v_count := 0;     
      FOR i IN nvl(p_stock_code_out_list.first,1) .. nvl(p_stock_code_out_list.last,0)
      LOOP
        v_count := v_count + 1;
        v_stock_out_codes.Extend;
        v_stock_out_codes(v_count):= p_stock_code_out_list(i);
      END LOOP;
      
      -- Получим Id всех out складов
      SELECT distinct s.id 
        BULK COLLECT INTO v_stock_out_id
        FROM stock s
        WHERE s.code IN (SELECT COLUMN_VALUE
                           FROM TABLE(CAST(v_stock_out_codes as CT_VARCHAR)))
        OR s.stock_group_id IN (SELECT distinct ID 
              FROM (SELECT t.ID, CONNECT_BY_ROOT t.id parent_group_id FROM stock_group t
                                CONNECT BY PRIOR t.ID = t.stock_group_id) 
             WHERE parent_group_id IN (SELECT COLUMN_VALUE
                                                  FROM TABLE(CAST(v_stock_group_out_ids as CT_NUMBER))));       
      
      IF v_stock_out_id.count = 0 and p_doc_type in (util_stock.c_Doc_Type_Shippment, util_stock.c_Doc_Type_Movement, util_stock.c_Doc_Type_Debit)
      THEN
         raise_application_error (util_pkg.c_ora_missing_parameter, 'Stock out not found');
      END IF;                                                                                      
      
      --Заполним коллекцию идентификаторов складов
      pkg_stock.set_stockid (p_stock_id_out => v_stock_out_id,p_stock_id_in => v_stock_in_id);
      --Заполним коллекцию идентификаторов оборудования...
      pkg_equipment.set_modelid (p_model_id_1 => v_eqp_model_ids);
      --Восстановим все движение оборудования на заданную дату
      motion_of_equipment (p_date_from => v_date_from,
                               p_date_to=> v_date_to
                              );                           
       
      IF (p_detailed = 1)
      THEN
        BEGIN
          OPEN p_cur_eqm_move FOR
               SELECT et.equipment_type_code, 
                      et.equipment_type_name,
                      em.equipment_model_code,
                      em.equipment_model_name, 
                      tmp.quantity, 
                      sti.code as stock_in_code, 
                      sto.code as stock_out_code, 
                      tmp.doc_date, 
                      tmp.seria_start, 
                      tmp.seria_end--, 
                      --tmp.document_no                  
                      FROM (SELECT  b.stock_in_id, 
                                    b.stock_out_id, 
                                    b.equipment_model_id,
                                    MIN (b.seria_start) AS seria_start,
                                    MAX (b.seria_end) AS seria_end,
                                    SUM (b.quantity) as quantity,
                                    b.valid_until, 
                                    b.doc_header_id,
                                    b.document_no,
                                    b.doc_date
                           FROM (SELECT a.stock_in_id, 
                                        a.stock_out_id, 
                                        a.equipment_model_id, 
                                        a.seria_start, 
                                        a.seria_end,
                                        a.quantity,
                                        SUM (a.start_of_group) OVER (PARTITION BY a.equipment_model_id,a.stock_in_id, a.stock_out_id, a.doc_date ORDER BY a.seria_start)
                                                                                              AS group_no,
                                        a.valid_until, 
                                        a.doc_header_id, 
                                        a.document_no,                                        
                                        a.doc_date
                                   FROM (SELECT --+ DYNAMIC_SAMPLING(t 2) CARDINALITY(vet 5) CARDINALITY(em 10)
                                                t.stock_in_id, 
                                                t.stock_out_id, 
                                                t.equipment_model_id, 
                                                t.seria_start,
                                                t.seria_end, 
                                                t.quantity,
                                                t.valid_until, 
                                                t.doc_header_id, 
                                                t.document_no,                         
                                                dh.doc_date,
                                                CASE
                                                   WHEN (    vet.is_numeric_serial_number = 'Y'
                                                         AND vet.allows_partitioning = 'Y'
                                                        )
                                                      THEN DECODE
                                                             (TO_NUMBER
                                                                 (
                                                                    LAG (t.seria_end) OVER (PARTITION BY t.equipment_model_id,t.stock_in_id, t.stock_out_id, dh.doc_date ORDER BY t.seria_start)
                                                                 ),
                                                              TO_NUMBER (t.seria_start) - 1, NULL,
                                                              '1'
                                                             )
                                                   ELSE '1'
                                                END start_of_group
                                           FROM tmp_ss5 t, vw_equipment_type vet, equipment_model em,doc_header dh 
                                            WHERE t.doc_type_id = p_doc_type
                                            AND em.equipment_type_id = vet.equipment_type_id
                                            AND t.equipment_model_id = em.equipment_model_id 
                                            AND dh.id = t.doc_header_id) a) b
                       GROUP BY b.stock_in_id, b.stock_out_id, b.equipment_model_id, b.group_no,b.valid_until, b.doc_header_id,b.doc_date,b.document_no)  tmp
                               LEFT JOIN equipment_model em ON em.equipment_model_id = tmp.equipment_model_id
                               LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id
                               LEFT JOIN stock sti ON sti.id = tmp.stock_in_id
                               LEFT JOIN stock sto ON sto.id = tmp.stock_out_id
                         WHERE tmp.quantity <> 0
                      ORDER BY tmp.equipment_model_id;
        END;
      ELSE
        BEGIN
          OPEN p_cur_eqm_move FOR
             SELECT et.equipment_type_code, 
                    et.equipment_type_name, 
                    em.equipment_model_code, 
                    em.equipment_model_name,
                    tmp.quantity, 
                    null as stock_in_code, 
                    null as stock_out_code, 
                    TO_DATE(null, util_pkg.c_date_format_full) as doc_date, 
                    null as seria_start, 
                    null as seria_end              
                      FROM (SELECT   equipment_model_id,
                                   SUM (quantity) as quantity
                              FROM tmp_ss5
                              WHERE doc_type_id = p_doc_type
                         GROUP BY equipment_model_id)  tmp
                               LEFT JOIN equipment_model em ON em.equipment_model_id = tmp.equipment_model_id
                               LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id
                         WHERE tmp.quantity <> 0
                      ORDER BY tmp.equipment_model_id;
         END;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   
   EXCEPTION
      WHEN OTHERS
      THEN
         ResultCode := SQLCODE;
         v_errorM:=SQLERRM;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || v_errorM, pkg_name);

   END GetMoveOfEquipment;
   
-------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 23.09.2010
-- Version :
-- Modification : pkg_stock.state_prepare_reverse
-- Editor  : Pavel Vasiliev 
-- Changed :
-- Purpose : Получаем получаем состояния оборудования на указанные даты и
---         все движения оборудования на период времени.Состояние
--           строется от состояния на текущую дату по движению документов в обратном порядке
--------------------------------------------------------------------------------
   PROCEDURE stock_state_reverse (
      p_date_from                    IN   DATE,   --начальная дата диапазона
      p_date_to                      IN   DATE   --конечная дата диапазона
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'stock_state_reverse';
      l_cnt_stk           NUMBER;
      l_cnt_eqm           NUMBER;   --количество идентификаторов оборудования
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_date_from, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_date_to, 'dd.mm.yyyy')
                         || ')',
                         pkg_name
                        );

      --Чиститим
      DELETE FROM tmp_ss4;

      --Количество идентификаторов складов
      l_cnt_stk := pkg_stock.g_tab_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'Count stocks = ' || l_cnt_stk, pkg_name);

      IF l_cnt_stk = 0
      THEN
         raise_application_error (-20001, 'Stocks not found');
      END IF;

      --Установием количество идентификаторов оборудования
      l_cnt_eqm := pkg_equipment.g_tab_model_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'Count equipment = ' || l_cnt_eqm, pkg_name);

      
      
         --Получим записи по закрытым документам с определенным типом оборудования
       
            --Детализированная информация по закрытым документам
            INSERT INTO tmp_ss4
                        (stock_id, 
                         equipment_model_id, 
                         seria_start, 
                         seria_end, 
                         quantity_from,
                         quantity_rec, 
                         quantity_ship, 
                         quantity_to, 
                         valid_until, 
                         status,
                         doc_header_id, 
                         document_no, 
                         equipment_batch_id,
                         doc_type_id)
               SELECT   k.stock_id, 
                        k.equipment_model_id, 
                        k.seria_start, 
                        k.seria_end,
                        SUM (k.quantity_from), 
                        SUM (k.quantity_rec),
                        SUM (k.quantity_ship), 
                        SUM (k.quantity_to), 
                        MAX (k.valid_until) AS create_date,
                        MAX (k.status_id) AS status_id, 
                        k.doc_header_id, 
                        doc_no as document_no, 
                        k.equipment_batch_id,
                        k.doc_type_id
                   FROM (SELECT --+ PUSH_SUBQ ORDERED
                                sq.stock_id, 
                                dd.equipment_model_id, 
                                dd.seria_start, 
                                dd.seria_end,
                                DECODE (sq.quantity_sign,-1, -dd.quantity, dd.quantity) AS quantity_from,
                                CASE 
                                  WHEN (sq.doc_date>p_date_to) THEN 0
                                  ELSE DECODE (sq.quantity_sign, -1, dd.quantity, 0)
                                END AS quantity_rec,
                                CASE 
                                  WHEN (sq.doc_date>p_date_to) THEN 0
                                  ELSE DECODE (sq.quantity_sign, 1, dd.quantity, 0)
                                END AS quantity_ship,
                                CASE 
                                  WHEN (sq.doc_date<=p_date_to) THEN 0
                                  ELSE DECODE (sq.quantity_sign, -1, -dd.quantity, dd.quantity)
                                END AS quantity_to,
                                dd.valid_until, 
                                dd.status_id,
                                CASE 
                                  WHEN (sq.doc_date>p_date_to) THEN 0
                                  ELSE dd.doc_header_id
                                END as doc_header_id, 
                                CASE 
                                  WHEN (sq.doc_date>p_date_to) THEN NULL
                                  ELSE sq.doc_no
                                END as doc_no, 
                                dd.equipment_batch_id,
                                sq.doc_type_id
                           FROM (SELECT --+ CARDINALITY(stk 10) INDEX_DESC(dh IDX_DOCHEADER_SO_DD_DMO) NO_EXPAND
                                        dh.ID, 
                                        dh.stock_out_id AS stock_id, 
                                        1 AS quantity_sign,
                                        dh.doc_no, 
                                        dh.doc_date,
                                        dh.doc_type_id
                                   FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                        doc_header dh
                                  WHERE dh.stock_out_id = stk.COLUMN_VALUE
                                    AND dh.doc_date > p_date_from
                                    AND dh.doc_date <= SYSDATE
                                    AND dh.doc_type_id IN (102, 103, 107)
                                    AND dh.status_id = 1
                                 UNION ALL
                                 SELECT --+ CARDINALITY(stk 10) INDEX_DESC(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                        dh.ID, 
                                        dh.stock_in_id AS stock_id, 
                                        -1 AS quantity_sign,
                                        dh.doc_no, 
                                        dh.doc_date,
                                        dh.doc_type_id
                                   FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                        doc_header dh
                                  WHERE dh.stock_in_id = stk.COLUMN_VALUE
                                    AND dh.doc_date > p_date_from
                                    AND dh.doc_date <= SYSDATE
                                    AND dh.doc_type_id IN (101, 103, 104, 105, 106, 108, 109, 113)
                                    AND dh.status_id = 1) sq,
                                doc_detail dd
                          WHERE sq.ID = dd.doc_header_id
                            AND (   (dd.equipment_model_id IN (
                                        SELECT --+ CARDINALITY(eqm 2)
                                               COLUMN_VALUE
                                          FROM TABLE
                                                    (CAST (pkg_equipment.g_tab_model_id AS ct_number)
                                                    ) eqm)
                                    )
                                 OR (l_cnt_eqm = 0)
                                )
                         UNION ALL
                         SELECT --+ INDEX(ss I_STOCK_STATE_STOCK_ID)
                                ss.stock_id, 
                                ss.equipment_model_id, 
                                ss.seria_start, 
                                ss.seria_end,
                                (ss.quantity_onstock + ss.quantity_reserved) AS quantity_from,
                                0 AS quantity_rec,
                                0 AS quantity_ship,
                                (ss.quantity_onstock + ss.quantity_reserved) AS quantity_to, 
                                ss.create_date AS valid_until,
                                ss.status AS status_id, 
                                0 as doc_header_id, 
                                null as doc_no, 
                                ss.equipment_batch_id,
                                0 as doc_type_id
                           FROM stock_state ss
                          WHERE ss.stock_id IN (
                                              SELECT --+ CARDINALITY(stk 5)
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                            AND (ss.quantity_onstock > 0 or ss.quantity_reserved > 0)
                            AND l_cnt_eqm = 0
                         UNION ALL
                         SELECT --+ INDEX(ss I_STOCK_STATE_EQM)
                                ss.stock_id, 
                                ss.equipment_model_id, 
                                ss.seria_start, 
                                ss.seria_end,
                                (ss.quantity_onstock + ss.quantity_reserved) AS quantity_from,
                                0 AS quantity_rec,
                                0 AS quantity_ship,
                                (ss.quantity_onstock + ss.quantity_reserved) AS quantity_to, 
                                ss.create_date AS valid_until,
                                ss.status AS status_id, 
                                0 as doc_header_id, 
                                null as doc_no, 
                                ss.equipment_batch_id,
                                0 as doc_type_id
                           FROM stock_state ss
                          WHERE ss.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 2)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                            AND ss.stock_id IN (
                                              SELECT --+ CARDINALITY(stk 5)
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                            AND (ss.quantity_onstock > 0 or ss.quantity_reserved > 0)
                            AND l_cnt_eqm > 0) k
               GROUP BY k.stock_id,
                        k.equipment_model_id,
                        k.seria_start,
                        k.seria_end,
                        k.doc_header_id,
                        k.doc_no,
                        k.equipment_batch_id,
						k.doc_type_id
                -- HAVING SUM (k.quantity_onstock) <> 0
                ;

            pkg_db_util.DEBUG (prc_name,
                               'Inserted only closed documents with detailed = ' || SQL%ROWCOUNT,
                               pkg_name
                              );
         

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END stock_state_reverse;
   
----------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 23.09.2010
-- Version :
-- Modification : pkg_stock.state_prepare_reverse
-- Editor  : Pavel Vasiliev 
-- Changed :
-- Purpose : Получаем получаем состояния оборудования на указанные даты и
---         все движения оборудования на период времени.Состояние
--           строется от состояния на текущую дату по движению документов в обратном порядке
--------------------------------------------------------------------------------
   PROCEDURE motion_of_equipment (
      p_date_from                    IN   DATE,   --начальная дата диапазона
      p_date_to                      IN   DATE   --конечная дата диапазона
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'motion_of_equipment';
      l_cnt_stk_out       NUMBER;
      l_cnt_stk_in        NUMBER;
      l_cnt_eqm           NUMBER;   --количество идентификаторов оборудования
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_date_from, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_date_to, 'dd.mm.yyyy')
                         || ')',
                         pkg_name
                        );

      --Чиститим
      DELETE FROM tmp_ss5;

      --Количество идентификаторов складов
      l_cnt_stk_out := pkg_stock.g_tab_id_out.COUNT;
      pkg_db_util.DEBUG (prc_name, 'Count stocks = ' || l_cnt_stk_out, pkg_name);
      l_cnt_stk_in := pkg_stock.g_tab_id_in.COUNT;
      pkg_db_util.DEBUG (prc_name, 'Count stocks = ' || l_cnt_stk_in, pkg_name);

      IF l_cnt_stk_out = 0 AND l_cnt_stk_in = 0
      THEN
         raise_application_error (-20001, 'Stocks not found');
      END IF;

      --Установием количество идентификаторов оборудования
      l_cnt_eqm := pkg_equipment.g_tab_model_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'Count equipment = ' || l_cnt_eqm, pkg_name);

      IF l_cnt_eqm = 0
      THEN
         raise_application_error (-90006, 'Equipment not found');
      END IF;
      
      
         --Получим записи по закрытым документам с определенным типом оборудования
       
            --Детализированная информация по закрытым документам
            INSERT INTO tmp_ss5
                        (doc_type_id, stock_out_id, stock_in_id, equipment_model_id, 
                         seria_start, seria_end, quantity,
                         valid_until, status,
                        doc_header_id, document_no, equipment_batch_id)
                        SELECT   k.doc_type_id, k.stock_out_id, k.stock_in_id, 
                                 k.equipment_model_id, k.seria_start, k.seria_end,
                                 SUM (k.quantity) AS quantity,MAX (k.valid_until) AS valid_until,
                                 MAX (k.status_id) AS status_id, k.doc_header_id, doc_no as document_no, k.equipment_batch_id            
                                 FROM  (SELECT --+ PUSH_SUBQ ORDERED
                                                  sq.doc_type_id,sq.stock_out_id,stock_in_id,
                                                  dd.equipment_model_id, dd.seria_start, dd.seria_end,
                                                  dd.quantity,
                                                  dd.valid_until, dd.status_id ,
                                                  dd.doc_header_id, 
                                                  sq.doc_no, dd.equipment_batch_id
                                         FROM (/*SELECT --+ --+ CARDINALITY(stk_in 4) CARDINALITY(stk_out 4) INDEX_DESC(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                                          dh.ID, dh.doc_type_id, dh.stock_out_id, dh.stock_in_id,
                                                          dh.doc_no, dh.doc_date
                                                     FROM TABLE (CAST (pkg_stock.g_tab_id_in AS ct_number)) stk_in,
                                                          TABLE (CAST (pkg_stock.g_tab_id_out AS ct_number)) stk_out,
                                                          doc_header dh
                                                    WHERE (dh.stock_in_id = stk_in.COLUMN_VALUE OR dh.doc_type_id = 102)
                                                      AND (dh.stock_out_id = stk_out.COLUMN_VALUE OR dh.doc_type_id = 101)
                                                      AND dh.doc_date > p_date_from
                                                      AND dh.doc_date <= p_date_to
                                                      AND dh.doc_type_id  IN (101,102,103)
                                                      AND dh.status_id = 1*/
                                                 SELECT --+ CARDINALITY(stk_in 10) INDEX_DESC(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                                          dh.ID, dh.doc_type_id, dh.stock_out_id, dh.stock_in_id,
                                                          dh.doc_no, dh.doc_date
                                                     FROM TABLE (CAST (pkg_stock.g_tab_id_in AS ct_number)) stk_in,
                                                          doc_header dh
                                                    WHERE dh.stock_in_id = stk_in.COLUMN_VALUE
                                                      AND dh.doc_date > p_date_from
                                                      AND dh.doc_date <= p_date_to
                                                      AND dh.doc_type_id  = util_stock.c_Doc_Type_Receipt
                                                      AND dh.status_id = 1
                                                 UNION ALL
                                                 SELECT --+ CARDINALITY(stk_out 10)  INDEX_DESC(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                                          dh.ID, dh.doc_type_id, dh.stock_out_id, dh.stock_in_id,
                                                          dh.doc_no, dh.doc_date
                                                     FROM TABLE (CAST (pkg_stock.g_tab_id_out AS ct_number)) stk_out,
                                                          doc_header dh
                                                    WHERE dh.stock_out_id = stk_out.COLUMN_VALUE
                                                      AND dh.doc_date > p_date_from
                                                      AND dh.doc_date <= p_date_to
                                                      AND dh.doc_type_id = util_stock.c_Doc_Type_Shippment
                                                      AND dh.status_id = 1
                                                 UNION ALL
                                                 SELECT --+ CARDINALITY(stk_in 4) CARDINALITY(stk_out 4)  INDEX_DESC(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                                          dh.ID, dh.doc_type_id, dh.stock_out_id, dh.stock_in_id,
                                                          dh.doc_no, dh.doc_date
                                                     FROM TABLE (CAST (pkg_stock.g_tab_id_in AS ct_number)) stk_in,
                                                          TABLE (CAST (pkg_stock.g_tab_id_out AS ct_number)) stk_out,
                                                          doc_header dh
                                                    WHERE dh.stock_in_id = stk_in.COLUMN_VALUE
                                                      AND dh.stock_out_id = stk_out.COLUMN_VALUE
                                                      AND dh.doc_date > p_date_from
                                                      AND dh.doc_date <= p_date_to
                                                      AND dh.doc_type_id  = util_stock.c_Doc_Type_Movement
                                                      AND dh.status_id = 1
                                                 UNION ALL
                                                 SELECT --+ CARDINALITY(stk_in 10) INDEX_DESC(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                                          dh.ID, dh.doc_type_id, dh.stock_out_id, dh.stock_in_id,
                                                          dh.doc_no, dh.doc_date
                                                     FROM TABLE (CAST (pkg_stock.g_tab_id_in AS ct_number)) stk_in,
                                                          doc_header dh
                                                    WHERE dh.stock_in_id = stk_in.COLUMN_VALUE
                                                      AND dh.doc_date > p_date_from
                                                      AND dh.doc_date <= p_date_to
                                                      AND dh.doc_type_id  = util_stock.c_Doc_Type_Credit
                                                      AND dh.status_id = 1
                                                 UNION ALL
                                                 SELECT --+ CARDINALITY(stk_out 10)  INDEX_DESC(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                                          dh.ID, dh.doc_type_id, dh.stock_out_id, dh.stock_in_id,
                                                          dh.doc_no, dh.doc_date
                                                     FROM TABLE (CAST (pkg_stock.g_tab_id_out AS ct_number)) stk_out,
                                                          doc_header dh
                                                    WHERE dh.stock_out_id = stk_out.COLUMN_VALUE
                                                      AND dh.doc_date > p_date_from
                                                      AND dh.doc_date <= p_date_to
                                                      AND dh.doc_type_id = util_stock.c_Doc_Type_Debit
                                                      AND dh.status_id = 1) sq,
                                                  doc_detail dd
                                            WHERE sq.ID = dd.doc_header_id
                                              AND (dd.equipment_model_id IN (
                                                          SELECT --+ CARDINALITY(eqm 2)
                                                                 COLUMN_VALUE
                                                            FROM TABLE
                                                                      (CAST (pkg_equipment.g_tab_model_id AS ct_number)
                                                                      ) eqm))
                                                      ) k
                                 GROUP BY k.doc_type_id,
                                          k.stock_out_id,
                                          k.stock_in_id,
                                          k.equipment_model_id,
                                          k.seria_start,
                                          k.seria_end,
                                          k.doc_header_id,
                                          k.doc_no,
                                          k.equipment_batch_id
                -- HAVING SUM (k.quantity_onstock) <> 0
                ;

            pkg_db_util.DEBUG (prc_name,
                               'Inserted only closed documents with detailed = ' || SQL%ROWCOUNT,
                               pkg_name
                              );
         

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END motion_of_equipment;
   
END;
/
