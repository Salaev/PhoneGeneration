CREATE package equipment_pkg is

----------------------------------!---------------------------------------------
  type t_xyz_ssext is table of TT_XYZ_SSEXT_SER_DST%rowtype;
  type t_sims is table of SIMS%rowtype;

  type rt_in_data is record
  (
    m_range_start ct_nvarchar_s,
    m_range_end ct_nvarchar_s,
    m_quantity ct_number,
    m_model ct_model,
    m_valid_until ct_date,
    m_id_original ct_number,
    m_error_code util_pkg.cit_number,
    m_error_message util_pkg.cit_varchar
  );

  type t_ss_parameters is record
  (
    --document parameters
    m_doc_header                  doc_header%rowtype,
    m_doc_header_orig             doc_header%rowtype,

    --incoming data
    --!_! collections items order MUST be same for linked docs
    m_in_data_src                 rt_in_data,
    m_in_data_dst                 rt_in_data,
    m_in_data_ext_src             rt_in_data,
    m_in_data_ext_dst             rt_in_data,

    m_valid_until_common_nullable date, --may be null

    m_eq_status_final             number,

    --system parameters
    m_do_break_on_error           boolean,
    m_do_lock_document            boolean,
    m_do_lock_equipment           boolean,
    m_do_check_locking_document   boolean,
    m_do_check_locking_equipment  boolean,
    m_do_release_doc_locker       boolean,
    m_do_release_locker           boolean,

    --JOINT internal parameters
    m_locker_group                number,
    m_doc_locker_group            number,
    m_prev_doc_header_id          number,

    --INTERNAL parameters
    m_is_input_set                boolean,

    --sims parameters
    m_do_populate_sims            boolean,
    m_do_populate_sims_range      boolean,
    m_eq_types4populate_sims      ct_number,
    m_do_prematurely_populate     boolean
  );

----------------------------------!---------------------------------------------
  c_eq_qty_zero                  constant number := 0;
  c_eq_qty_one_item              constant number := 1;

  c_eq_status_not_spec           constant number := -1;
  c_eq_status_not_active         constant number := 0;
  c_eq_status_active             constant number := 1;

  c_def_ss_quantity              constant number := c_eq_qty_zero;
  c_def_ss_doc_header_id         constant stock_state.doc_header_id%type := null;
  c_def_ss_reserved              constant stock_state.reserved%type := null;
  c_def_ss_user_comment          constant stock_state.user_comment%type := null;
  c_def_ss_equipment_batch_id    constant stock_state.equipment_batch_id%type := null;

  lc_any_model_id                constant number := -100500;

  --!_! document operation type
  c_dot_create                   constant number := 0;
  c_dot_update                   constant number := 1;
  c_dot_finalize                 constant number := 2;

  --!_! document operation subtype
  c_dost_create                  constant number := 0;
  c_dost_update_add              constant number := 1;
  c_dost_update_remove           constant number := 2;
  c_dost_finalize                constant number := 3;

  --!_! document style
  c_doc_style_default            constant number := 0;
  c_doc_style_crm                constant number := 1;
  c_doc_style_gui                constant number := 2;

----------------------------------!---------------------------------------------
  v_use_stock_state_trigger      number := util_pkg.c_true;
  v_use_sims_trigger             number := util_pkg.c_true;

----------------------------------!---------------------------------------------
  c_def_range_side               constant number := 0;

  c_dummy_str                    constant varchar2(50) := 'QwErTYasdFGH';

  c_label_in_data_src            constant varchar2(50) := 'Input data SRC';
  c_label_in_data_dst            constant varchar2(50) := 'Input data DST';

----------------------------------!---------------------------------------------
  c_opt_max_serial_range_count   constant nvarchar2(50) := 'MAX_SERIAL_RANGE_COUNT';
  c_opt_valid_until_sh_days      constant nvarchar2(50) := 'VALID_UNTIL_SHIFT_DAYS';
  c_opt_populate_sims            constant nvarchar2(50) := 'POPULATE_SIMS';
  c_opt_populate_sims_range      constant nvarchar2(50) := 'POPULATE_SIMS_RANGE';
  c_opt_populate_sims_eqt        constant nvarchar2(50) := 'POPULATE_SIMS_EQUIPMENT_TYPES';

----------------------------------!---------------------------------------------
  c_def_max_serial_range_count   constant number := 100000;
  c_def_valid_until_sh_days      constant number := 365;
  c_def_populate_sims            constant boolean := true;
  c_def_populate_sims_range      constant boolean := false;
  c_def_populate_sims_eqt        constant varchar2(50) := c_dummy_str; --!_! '2,3'

----------------------------------!---------------------------------------------
  procedure XRestrict_Not_Implemented(p_label varchar2);
  procedure XRestrict_Wrong_Doc_State(p_id number);
  procedure XRestrict_Mandat_Value(p_label varchar2);

----------------------------------!---------------------------------------------
  procedure XCheck_Eq_Status(p_eq_status number, p_label varchar2 := null);
  procedure XCheck_Doc_Op_Type(p_document_operation_type number, p_label varchar2 := null);
  procedure XCheck_Doc_Op_Subtype(p_document_operation_subtype number, p_label varchar2 := null);
  procedure XCheck_Doc_Style(p_document_style number, p_label varchar2 := null);

----------------------------------!---------------------------------------------
  function GP_doc_header(p_params t_ss_parameters) return doc_header%rowtype;
  function GP_doc_header_orig(p_params t_ss_parameters) return doc_header%rowtype;
  function is_exists_document_orig(p_params t_ss_parameters) return boolean;
  function XGP_doc_header_id(p_params t_ss_parameters) return number;

----------------------------------!---------------------------------------------
  function XGP_last_user_id(p_params t_ss_parameters) return number;
  function XGP_document_date(p_params t_ss_parameters) return date;
  function XGP_document_type(p_params t_ss_parameters) return number;
  function XGP_doc_dir_type(p_params t_ss_parameters) return number;
  function XGP_document_number(p_params t_ss_parameters) return nvarchar2;
  function XGP_document_status(p_params t_ss_parameters) return number;
  function NLGP_document_status_orig(p_params t_ss_parameters) return number;
  function XGP_stock_id_out(p_params t_ss_parameters) return number;
  function XGP_stock_id_in(p_params t_ss_parameters) return number;
  function GP_valid_until_common_nullable(p_params t_ss_parameters) return date;
  function XGP_eq_status_initial(p_params t_ss_parameters) return number;
  function XGP_eq_status_final_NEUTRAL(p_params t_ss_parameters) return number;
  function XGP_eq_status_final_REAL(p_params t_ss_parameters) return number;

----------------------------------!---------------------------------------------
  function XGP_do_break_on_error(p_params t_ss_parameters) return boolean;
  function XGP_do_lock_document(p_params t_ss_parameters) return boolean;
  function XGP_do_lock_equipment(p_params t_ss_parameters) return boolean;
  function XGP_do_check_locking_document(p_params t_ss_parameters) return boolean;
  function XGP_do_check_locking_equipment(p_params t_ss_parameters) return boolean;
  function XGP_do_release_doc_locker(p_params t_ss_parameters) return boolean;
  function XGP_do_release_locker(p_params t_ss_parameters) return boolean;

----------------------------------!---------------------------------------------
  function XGP_do_populate_sims(p_params t_ss_parameters) return boolean;
  function XGP_do_populate_sims_range(p_params t_ss_parameters) return boolean;
  function NLGP_eq_types4populate_sims(p_params t_ss_parameters) return ct_number;
  function XGP_do_prematurely_populate(p_params t_ss_parameters) return boolean;

----------------------------------!---------------------------------------------
  function GP_locker_group(p_params t_ss_parameters) return number;
  procedure SP_locker_group(p_params in out nocopy t_ss_parameters, p_value number);
  function GP_doc_locker_group(p_params t_ss_parameters) return number;
  procedure SP_doc_locker_group(p_params in out nocopy t_ss_parameters, p_value number);
  function NLGP_prev_doc_header_id(p_params t_ss_parameters) return number;

----------------------------------!---------------------------------------------
  function XGP_is_input_set(p_params t_ss_parameters) return boolean;

----------------------------------!---------------------------------------------
  function GP_in_data_main_SRC(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_main_DST(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_main_ALL(p_params t_ss_parameters) return rt_in_data;

  function GP_in_data_main_SER_SRC(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_main_SER_DST(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_main_SER_ALL(p_params t_ss_parameters) return rt_in_data;

  function GP_in_data_main_NSER_SRC(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_main_NSER_DST(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_main_NSER_ALL(p_params t_ss_parameters) return rt_in_data;

  function GP_in_data_main_count_SER_ALL(p_params t_ss_parameters) return number;
  function GP_in_data_main_count_NSER_ALL(p_params t_ss_parameters) return number;

  function GP_err_id_only_main_ALL(p_params t_ss_parameters) return ct_number;

  function GP_in_data_ext_SRC(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_ext_DST(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_ext_ALL(p_params t_ss_parameters) return rt_in_data;

  function GP_in_data_ext_SER_SRC(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_ext_SER_DST(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_ext_SER_ALL(p_params t_ss_parameters) return rt_in_data;

  function GP_in_data_ext_NSER_SRC(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_ext_NSER_DST(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_ext_NSER_ALL(p_params t_ss_parameters) return rt_in_data;

  function GP_in_data_ext_count_SER_ALL(p_params t_ss_parameters) return number;
  function GP_in_data_ext_count_NSER_ALL(p_params t_ss_parameters) return number;

  function GP_in_data_ext_count_ALL(p_params t_ss_parameters) return number;
  function is_in_data_for_remove(p_params t_ss_parameters) return boolean;

  function GP_err_id_only_ext_ALL(p_params t_ss_parameters) return ct_number;

  function GP_in_data_mainext_SRC(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_mainext_DST(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_mainext_ALL(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_mainext_SER_ALL(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_mainext_NSER_SRC(p_params t_ss_parameters) return rt_in_data;
  function GP_in_data_mainext_NSER_DST(p_params t_ss_parameters) return rt_in_data;

----------------------------------!---------------------------------------------
  function GP_in_data4Latch_SER(p_params t_ss_parameters) return locker_pkg.t_locker_data;
  function GP_in_data4Latch_NSER(p_params t_ss_parameters) return locker_pkg.t_locker_data_eq;

----------------------------------!---------------------------------------------
  function EGP_in_data(p_params t_ss_parameters) return rt_in_data;
  function EGP_in_data_ext(p_params t_ss_parameters) return rt_in_data;
  function EGP_in_data_ALL(p_params t_ss_parameters) return rt_in_data;

  function EGP_error_count(p_params t_ss_parameters) return number;

----------------------------------!---------------------------------------------
  function EGP_series_start(p_params t_ss_parameters) return ct_nvarchar_s;
  function EGP_series_end(p_params t_ss_parameters) return ct_nvarchar_s;
  function EGP_models(p_params t_ss_parameters) return ct_model;
  function EGP_is_addition(p_params t_ss_parameters) return ct_number;
  function EGP_ids(p_params t_ss_parameters) return ct_number;
  function EGP_ids_original(p_params t_ss_parameters) return ct_number; --!_!

----------------------------------!---------------------------------------------
  function iget_id_orig_erroneous_only(p_in_data rt_in_data) return ct_number;
  function iget_error_code_only(p_in_data rt_in_data) return ct_number;
  function iget_error_message_only(p_in_data rt_in_data) return ct_varchar;

  function EGP_ids_erroneous_only(p_params t_ss_parameters) return ct_number;
  function EGP_error_codes_only(p_params t_ss_parameters) return ct_number;
  function EGP_error_messages_only(p_params t_ss_parameters) return ct_varchar;

----------------------------------!---------------------------------------------
  function get_ids_erroneous_full_size(p_ids_pivot ct_number, p_ids_erroneous_only ct_number) return ct_number;
  function get_ids_erroneous_full_size2(p_in_data rt_in_data) return ct_number;
  function GP_ids_erroneous_full_size(p_params t_ss_parameters) return ct_number;
  function Eget_ids_erroneous_full_size(p_ids_pivot ct_number, p_ids_erroneous_only ct_number) return ct_number;

  function get_error_code_full_size(p_error_codes_only ct_number, p_ids_pivot ct_number, p_ids_erroneous_only ct_number) return ct_number;
  function get_error_code_full_size2(p_in_data rt_in_data) return ct_number;
  function EGP_error_codes_full_size(p_params t_ss_parameters) return ct_number;
  function Eget_error_codes_full_size(p_error_codes_only ct_number, p_ids_pivot ct_number, p_ids_erroneous_only ct_number) return ct_number;

  function get_error_message_full_size(p_error_messages_only ct_varchar, p_ids_pivot ct_number, p_ids_erroneous_only ct_number) return ct_varchar;
  function get_error_message_full_size2(p_in_data rt_in_data) return ct_varchar;
  function EGP_error_messages_full_size(p_params t_ss_parameters) return ct_varchar;
  function Eget_error_messages_full_size(p_error_messages_only ct_varchar, p_ids_pivot ct_number, p_ids_erroneous_only ct_number) return ct_varchar;

----------------------------------!---------------------------------------------
  function GS_max_serial_range_count return number;
  function GS_populate_sims return boolean;
  function GS_populate_sims_range return boolean;
  function GS_populate_sims_eqt return varchar2;
  function GS_valid_until_sh_days return number;

----------------------------------!---------------------------------------------
  procedure setup_populate_sims(p_params in out nocopy t_ss_parameters);

----------------------------------!---------------------------------------------
  --!_!procedure setup_keys_by_ids(p_params in out nocopy t_ss_parameters);
  --!_!function get_no_by_id(p_params t_ss_parameters, p_id number) return number;
  --!_!function get_no_by_id_safe(p_params t_ss_parameters, p_id number) return number;
  --!_!function get_id_by_no(p_params t_ss_parameters, p_no number) return number;
  --!_!function get_id_by_no_safe(p_params t_ss_parameters, p_no number) return number;

----------------------------------!---------------------------------------------
  procedure set_error4id_original_i
  (
    p_in_data in out nocopy rt_in_data,
    p_id_original number,
    p_code number,
    p_message varchar2,
    p_force boolean
  );

  procedure set_error4id_original
  (
    p_params in out nocopy t_ss_parameters,
    p_id_original number,
    p_code number,
    p_message varchar2,
    p_force boolean
  );

  --!_!function get_pack_error_code(p_params t_ss_parameters, p_pack_id number) return number;
  --!_!function get_pack_error_message(p_params t_ss_parameters, p_pack_id number) return varchar2;
  --!_!procedure get_pack_error(p_params t_ss_parameters, p_pack_id number, p_code out number, p_message out varchar2);

----------------------------------!---------------------------------------------
  function map_dot2dost_main(p_document_operation_type number) return number;

----------------------------------!---------------------------------------------
  function get_result_cursor01_common
  (
    p_ids ct_number,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_is_addition ct_number,
    p_error_codes ct_number,
    p_error_messages ct_varchar,
    p_subst_ids ct_number,
    p_subst_exclusive boolean,
    p_subst_error_code number := null,
    p_subst_error_message varchar2 := null
  ) return sys_refcursor;

  function get_result_cursor01
  (
    p_params t_ss_parameters,
    p_subst_ids ct_number,
    p_subst_exclusive boolean,
    p_subst_error_code number := null,
    p_subst_error_message varchar2 := null
  ) return sys_refcursor;

  function get_result_cursor01_simple(p_params t_ss_parameters) return sys_refcursor;

  function get_result_cursor02_common
  (
    p_ids ct_number,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_is_addition ct_number,
    p_error_codes ct_number,
    p_error_messages ct_varchar,
    p_subst_ids ct_number,
    p_subst_exclusive boolean,
    p_subst_error_code number := null,
    p_subst_error_message varchar2 := null
  ) return sys_refcursor;

  function get_result_cursor02
  (
    p_params t_ss_parameters,
    p_subst_ids ct_number,
    p_subst_exclusive boolean,
    p_subst_error_code number := null,
    p_subst_error_message varchar2 := null
  ) return sys_refcursor;

  function get_result_cursor02_simple(p_params t_ss_parameters) return sys_refcursor;

----------------------------------!---------------------------------------------
--!_! Steps are mandatory and order is important
--!_! 1. setup_for_single/linked_doc
--!_! 2. setup_for_new/old_doc
--!_! 3. setup_additional
--!_! 4. setup_input
--!_! 5. (optional; mandatory for open linked documents) finalize_chain

----------------------------------!---------------------------------------------
  procedure init_doc_header(p_rec in out nocopy doc_header%rowtype);
  procedure init_rt_in_data(p_rec in out nocopy rt_in_data);

----------------------------------!---------------------------------------------
  procedure setup_params_init_i(p_params in out nocopy t_ss_parameters);
  procedure init_input_i(p_params in out nocopy t_ss_parameters);
  procedure setup_empty_doc_i(p_params in out nocopy t_ss_parameters);
  procedure link_params_i(p_params_from t_ss_parameters, p_params_to in out nocopy t_ss_parameters);

  procedure setup_for_single_doc(p_params in out nocopy t_ss_parameters);
  procedure setup_for_linked_doc_begin(p_params in out nocopy t_ss_parameters);
  procedure setup_for_linked_doc_continue(p_params_from t_ss_parameters, p_params_to in out nocopy t_ss_parameters, p_lock_doc_exist boolean, p_lock_eq_exist boolean);
  procedure setup_for_linked_doc_end(p_params_from t_ss_parameters, p_params_to in out nocopy t_ss_parameters, p_lock_doc_exist boolean, p_lock_eq_exist boolean);
  procedure finalize_chain(p_params in out nocopy t_ss_parameters, p_success boolean);

----------------------------------!---------------------------------------------
  function xget_eq_status_initial(p_doc_type_id number) return number;

  function is_doc_implemented(p_doc_type_id number) return boolean;
  function is_doc_mutating_range(p_doc_type_id number) return boolean;

  function is_operation_1_side(p_document_operation_subtype number) return boolean;
  function is_operation_2_side(p_document_operation_subtype number) return boolean;

  function is_operation_4_in_data_ext(p_document_operation_subtype number) return boolean;

----------------------------------!---------------------------------------------
  procedure setup_eq_status_final_i(p_params in out nocopy t_ss_parameters, p_eq_status_final number);
  procedure setup_doc_style(p_doc_style number, p_rec in out nocopy doc_header%rowtype);

  procedure setup_for_new_doc
  (
    p_params in out nocopy t_ss_parameters,
    p_doc_type_id doc_header.doc_type_id%type,
    p_doc_date doc_header.doc_date%type,
    p_status_id doc_header.status_id%type,
    p_stock_id_out doc_header.stock_out_id%type,
    p_stock_id_in doc_header.stock_in_id%type,
    p_user_id doc_header.user_id2%type,
    p_last_user_id doc_header.last_user_id2%type,
    p_vendor_doc doc_header.vendor_doc%type,
    p_description doc_header.description%type,
    p_user_comment doc_header.user_comment%type,
    p_vendor_id doc_header.vendor_id%type,
    p_doc_style number
  );

  procedure setup_for_old_doc
  (
    p_params in out nocopy t_ss_parameters,
    p_doc_header_from doc_header%rowtype,
    p_status_id doc_header.status_id%type,
    p_last_user_id doc_header.last_user_id2%type,
    p_doc_date doc_header.doc_date%type
  );

----------------------------------!---------------------------------------------
  procedure setup_additional_i
  (
    p_params in out nocopy t_ss_parameters,
    p_break_on_error boolean,
    p_eq_status_final number,
    p_valid_until_common_nullable date,
    p_prematurely_populate boolean
  );

  procedure setup_additional
  (
    p_params in out nocopy t_ss_parameters,
    p_break_on_error boolean,
    p_eq_status_final number,
    p_valid_until_common date,
    p_prematurely_populate boolean
  );

  procedure setup_additional2
  (
    p_params in out nocopy t_ss_parameters,
    p_break_on_error boolean,
    p_eq_status_final number,
    p_prematurely_populate boolean
  );

----------------------------------!---------------------------------------------
  procedure XCheck_range
  (
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_model ct_model
  );

  procedure XCheck_range_side
  (
    p_range_side ct_nvarchar_s,
    p_model ct_model
  );

  procedure XCheck_in_data_raw
  (
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_model ct_model,
    p_valid_until ct_date,
    p_is_addition ct_number
  );

  procedure XCheck_in_data_raw2
  (
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_model ct_model,
    p_is_addition ct_number
  );

  procedure XCheck_rt_in_data(p_in_data rt_in_data);

  function xmake_rt_in_data_i
  (
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_quantity ct_number,
    p_model ct_model,
    p_valid_until ct_date,
    p_id_original ct_number
  ) return rt_in_data;

  function xsmart_make_rt_in_data
  (
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_quantity ct_number,
    p_model ct_model,
    p_valid_until ct_date,
    p_id_original ct_number
  ) return rt_in_data;

----------------------------------!---------------------------------------------
  procedure make_in_data4input_normal
  (
    p_doc_type_id number,
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_quantity ct_number,
    p_model ct_model,
    p_valid_until ct_date,
    p_o_in_data_src out rt_in_data,
    p_o_in_data_dst out rt_in_data,
    p_o_in_data_ext_src out rt_in_data,
    p_o_in_data_ext_dst out rt_in_data
  );

  procedure make_in_data4input_set_op_eq
  (
    p_doc_type_id number,
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_quantity ct_number,
    p_model ct_model,
    p_valid_until ct_date,
    p_is_addition ct_number,
    p_o_in_data_src out rt_in_data,
    p_o_in_data_dst out rt_in_data,
    p_o_in_data_ext_src out rt_in_data,
    p_o_in_data_ext_dst out rt_in_data
  );

  procedure make_in_data4input_src_dst
  (
    p_doc_type_id number,
    p_range_start_src ct_nvarchar_s,
    p_range_end_src ct_nvarchar_s,
    p_quantity_src ct_number,
    p_model_src ct_model,
    p_valid_until_src ct_date,
    p_range_start_dst ct_nvarchar_s,
    p_range_end_dst ct_nvarchar_s,
    p_quantity_dst ct_number,
    p_model_dst ct_model,
    p_valid_until_dst ct_date,
    p_o_in_data_src out rt_in_data,
    p_o_in_data_dst out rt_in_data,
    p_o_in_data_ext_src out rt_in_data,
    p_o_in_data_ext_dst out rt_in_data
  );

----------------------------------!---------------------------------------------
  function xsmart_make_valid_until
  (
    p_valid_until_raw ct_date,
    p_main_count number,
    p_valid_until_common_nullable date
  ) return ct_date;

  function xsmart_make_valid_until2
  (
    p_main_count number,
    p_valid_until_common_nullable date
  ) return ct_date;

  function xsmart_make_is_addition
  (
    p_is_addition_raw ct_number,
    p_main_count number
  ) return ct_number;

  function invert_is_addition(p_coll ct_number) return ct_number;

  function smart_make_1_id_original
  (
    p_main_count number
  ) return ct_number;

  procedure smart_make_2_id_original
  (
    p_main_count1 number,
    p_main_count2 number,
    p_o_id_original1 out ct_number,
    p_o_id_original2 out ct_number
  );

  procedure smart_make_2_id_original2
  (
    p_main_count number,
    p_o_id_original1 out ct_number,
    p_o_id_original2 out ct_number
  );

  --!_!NOW is not used
  procedure smart_make_4_id_original
  (
    p_main_count1 number,
    p_main_count2 number,
    p_main_count3 number,
    p_main_count4 number,
    p_o_id_original1 out ct_number,
    p_o_id_original2 out ct_number,
    p_o_id_original3 out ct_number,
    p_o_id_original4 out ct_number
  );

  --!_!NOW is not used
  procedure smart_make_4_id_original2
  (
    p_main_count1 number,
    p_main_count2 number,
    p_o_id_original11 out ct_number,
    p_o_id_original12 out ct_number,
    p_o_id_original21 out ct_number,
    p_o_id_original22 out ct_number
  );

  function xsmart_make_quantity
  (
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model
  ) return ct_number;

  function xget_nonserial_quantity_legacy(p_seria_END_raw nvarchar2) return integer;

  procedure xsmart_make_ranges
  (
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model,
    p_o_range_start out ct_nvarchar_s,
    p_o_range_end out ct_nvarchar_s
  );

  procedure xsmart_make_range_and_quantity
  (
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model,
    p_o_range_start out ct_nvarchar_s,
    p_o_range_end out ct_nvarchar_s,
    p_o_quantity out ct_number
  );

----------------------------------!---------------------------------------------
  procedure setup_input_ii
  (
    p_params in out nocopy t_ss_parameters,
    p_in_data_src rt_in_data,
    p_in_data_dst rt_in_data,
    p_in_data_ext_src rt_in_data,
    p_in_data_ext_dst rt_in_data
  );

  procedure setup_input_normal_i
  (
    p_params in out nocopy t_ss_parameters,
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_quantity ct_number,
    p_model ct_model,
    p_valid_until ct_date
  );

  procedure legacy_setup_input_normal
  (
    p_params in out nocopy t_ss_parameters,
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model,
    p_valid_until_raw ct_date
  );

  procedure legacy_setup_input_normal2
  (
    p_params in out nocopy t_ss_parameters,
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model
  );

  procedure setup_input_set_op_eq_i
  (
    p_params in out nocopy t_ss_parameters,
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_quantity ct_number,
    p_model ct_model,
    p_valid_until ct_date,
    p_is_addition ct_number
    --!_!other side params would be usefull for open (non-finalized) 2 side documents: c_Doc_Type_SeriaPartition, c_Doc_Type_SeriaAssembling etc
    --!_!Now the method is used only for 1 side documents
  );

  procedure legacy_setup_input_set_op_eq
  (
    p_params in out nocopy t_ss_parameters,
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model,
    p_valid_until_raw ct_date,
    p_is_addition_raw ct_number
  );

  procedure legacy_setup_input_set_op_eq2
  (
    p_params in out nocopy t_ss_parameters,
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model,
    p_is_addition_raw ct_number
  );

  procedure setup_input_src_dst
  (
    p_params in out nocopy t_ss_parameters,
    p_range_start_src ct_nvarchar_s,
    p_range_end_src ct_nvarchar_s,
    p_quantity_src ct_number,
    p_model_src ct_model,
    p_valid_until_src ct_date,
    p_range_start_dst ct_nvarchar_s,
    p_range_end_dst ct_nvarchar_s,
    p_quantity_dst ct_number,
    p_model_dst ct_model,
    p_valid_until_dst ct_date
  );

  procedure setup_input_src_dst2
  (
    p_params in out nocopy t_ss_parameters,
    p_range_start_src ct_nvarchar_s,
    p_range_end_src ct_nvarchar_s,
    p_quantity_src ct_number,
    p_model_src ct_model,
    p_range_start_dst ct_nvarchar_s,
    p_range_end_dst ct_nvarchar_s,
    p_quantity_dst ct_number,
    p_model_dst ct_model
  );

  procedure setup_input_empty
  (
    p_params in out nocopy t_ss_parameters
  );

----------------------------------!---------------------------------------------
  --!_!used only for document finalization
  procedure setup_input_from_doc_detail(p_params in out nocopy t_ss_parameters);
  procedure setup_input_from_doc_detail01(p_params in out nocopy t_ss_parameters);
  procedure setup_input_from_doc_detail02(p_params in out nocopy t_ss_parameters);

----------------------------------!---------------------------------------------
  function get_default_eq_valid_until_i(p_params t_ss_parameters) return date;

----------------------------------!---------------------------------------------
  function get_equipment_i(p_serial_number ct_nvarchar_s, p_iccid ct_nvarchar_s, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_sim;
  function get_equipment_fuzzy(p_serial_number ct_nvarchar_s, p_iccid ct_nvarchar_s, p_date date) return ct_sim;
  function get_equipment_exact(p_serial_number ct_nvarchar_s, p_iccid ct_nvarchar_s, p_date date) return ct_sim;

----------------------------------!---------------------------------------------
  function get_count_t_xyz_ssext(p_coll t_xyz_ssext) return number;

  procedure fill_t_xyz_ssext(p_coll in out nocopy t_xyz_ssext, p_val TT_XYZ_SSEXT_SER_DST%rowtype);
  procedure resize_t_xyz_ssext(p_coll in out nocopy t_xyz_ssext, p_size number);
  function make_t_xyz_ssext(p_count number, p_val TT_XYZ_SSEXT_SER_DST%rowtype) return t_xyz_ssext;

  procedure add_t_xyz_ssext_val(p_coll in out nocopy t_xyz_ssext, p_val TT_XYZ_SSEXT_SER_DST%rowtype);

  function cast_t_xyz_ssext2ct_range(p_coll t_xyz_ssext) return ct_range;

  function filter_t_xyz_ssext
  (
    p_ssext t_xyz_ssext,
    p_id_original_black_list ct_number
  ) return t_xyz_ssext;

----------------------------------!---------------------------------------------
  function get_TT_SER_SRC_ranges return ct_range;

----------------------------------!---------------------------------------------
  function get_count_t_sims(p_coll t_sims) return number;

----------------------------------!---------------------------------------------
  function get_count_rt_in_data(p_rec rt_in_data) return number;

  procedure add_rt_in_data(p_rec_coll in out nocopy rt_in_data, p_rec_coll_add rt_in_data);

  function get_marked_rt_in_data(p_in_data rt_in_data, p_marks ct_number, p_trim_empty boolean, p_mark_value number := util_pkg.c_true) return rt_in_data;

----------------------------------!---------------------------------------------
  function get_count_ct_sim(p_coll ct_sim) return number;
  procedure XCheckP_ct_sim(p_param ct_sim, p_label varchar2 := null);
  function CheckP_ct_sim(p_param ct_sim) return boolean;
  function get_ct_sim_sns(p_coll ct_sim) return ct_nvarchar_s;
  function get_ct_sim_models(p_coll ct_sim) return ct_model;

----------------------------------!---------------------------------------------
  function get_in_data_ser_nser_i(p_in_data rt_in_data, p_serial boolean) return rt_in_data;

  function get_in_data_SER(p_in_data rt_in_data) return rt_in_data;
  function get_in_data_NSER(p_in_data rt_in_data) return rt_in_data;

----------------------------------!---------------------------------------------
  function get_model_id_with_ignorance(p_model ct_model) return ct_number;

----------------------------------!---------------------------------------------
  procedure normalize_ranges
  (
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_type_id ct_number,
    p_o_range_start out ct_nvarchar_s,
    p_o_range_end out ct_nvarchar_s,
    p_o_type_id out ct_number
  );

  function make_unique_ranges
  (
    p_range_with_length1 ct_range,
    p_range_with_length2 ct_range
  ) return ct_range;

  function make_unique_ranges2
  (
    p_range_with_length ct_range
  ) return ct_range;

  function make_range(p_in_data rt_in_data) return ct_range;
  function make_range_with_length(p_in_data rt_in_data) return ct_range;
  function make_range_with_id_original(p_in_data rt_in_data) return ct_range;
  function make_range_with_model_ignor(p_in_data rt_in_data) return ct_range;
  function make_range_with_all(p_in_data rt_in_data) return ct_range;

  --!_!left and right ranges must be 1) fully overlapped 2) overlapped only 1-time
  --!_!p_range(i) must be overlapped with EXACTLY ONE p_range_add(j)
  function apply_ranges01
  (
    p_range ct_range,
    p_range_add ct_range,
    p_ignore_num1 boolean
  ) return ct_range;

----------------------------------!---------------------------------------------
  function is_overlap_ranges
  (
    p_range1 ct_range,
    p_range2 ct_range,
    p_ignore_same_row_number boolean
  ) return boolean;

  procedure XCheck_overlap_ranges
  (
    p_range1 ct_range,
    p_range2 ct_range,
    p_ignore_same_row_number boolean,
    p_label varchar2
  );

  procedure XCheck_overlap_ranges_own
  (
    p_range ct_range,
    p_label varchar2
  );

----------------------------------!---------------------------------------------
  function is_invalid_ranges
  (
    p_range ct_range
  ) return boolean;

  procedure XCheck_invalid_ranges
  (
    p_range ct_range,
    p_label varchar2
  );

----------------------------------!---------------------------------------------
  procedure clear_work_tables;

----------------------------------!---------------------------------------------
  procedure Error_Range2Str
  (
    p_range_err ct_range,
    p_error_ranges_str out varchar2
  );

  procedure XHandle_Errors_Break
  (
    p_range_err ct_range,
    p_error_code number,
    p_error_message varchar2,
    p_label varchar2
  );

  procedure Handle_Errors_Set_Global
  (
    p_range_err ct_range,
    p_params in out nocopy t_ss_parameters,
    p_error_code number,
    p_error_message varchar2,
    p_label varchar2
  );

  procedure Handle_Errors_Smart
  (
    p_range_err ct_range,
    p_params in out nocopy t_ss_parameters,
    p_break_on_error boolean,
    p_error_code number,
    p_error_message varchar2,
    p_label varchar2
  );

  procedure Handle_Errors_Smart2
  (
    p_range_err ct_range,
    p_params in out nocopy t_ss_parameters,
    p_error_code number,
    p_error_message varchar2,
    p_label varchar2
  );

----------------------------------!---------------------------------------------
  function get_overlap_stock_state1
  (
    p_range ct_range,
    p_ignore_model boolean,
    p_doc_status_id number,
    p_prev_doc_header_id number,
    p_4_nl_max_row_count number
  ) return ct_range;

  function get_overlap_stock_state2
  (
    p_range ct_range,
    p_ignore_model boolean,
    p_doc_status_id number,
    p_prev_doc_header_id number
  ) return ct_range;

  function get_overlap_stock_state3
  (
    p_range ct_range,
    p_ignore_model boolean,
    p_doc_status_id number,
    p_prev_doc_header_id number
  ) return ct_range;

----------------------------------!---------------------------------------------
  function lock_stock_state_ser
  (
    p_range ct_range,
    p_stock_id number,
    p_4_nl_max_row_count number
  ) return t_xyz_ssext;

  function lock_stock_state_nser
  (
    p_range ct_range,
    p_stock_id number
  ) return t_xyz_ssext;

----------------------------------!---------------------------------------------
  function is_valid_stock_state_ser
  (
    P_REC TT_XYZ_SSEXT_SER_DST%rowtype,
    p_2_side_operation boolean,
    p_work_side_src boolean, --!_! SRC or DST
    p_eq_status_initial number,
    p_doc_header_id number
  ) return boolean;

  function is_new_stock_state_nser
  (
    P_REC TT_XYZ_SSEXT_SER_DST%rowtype,
    p_2_side_operation boolean,
    p_work_side_src boolean --!_! SRC or DST
  ) return boolean;

  function is_valid_stock_state_nser
  (
    P_REC TT_XYZ_SSEXT_SER_DST%rowtype,
    p_2_side_operation boolean,
    p_work_side_src boolean, --!_! SRC or DST
    p_eq_status_initial number
  ) return boolean;

----------------------------------!---------------------------------------------
  function Get_Error_Lock_SS_SER
  (
    p_ssext t_xyz_ssext,
    p_2_side_operation boolean,
    p_work_side_src boolean, --!_! SRC or DST
    p_eq_status_initial number,
    p_doc_header_id number
  ) return t_xyz_ssext;

  function Get_Error_Lock_SS_NSER
  (
    p_ssext t_xyz_ssext,
    p_2_side_operation boolean,
    p_work_side_src boolean, --!_! SRC or DST
    p_eq_status_initial number,
    p_o_ss_new out t_xyz_ssext
  ) return t_xyz_ssext;

----------------------------------!---------------------------------------------
  procedure Check_SS_SER_DST_Overlap_1S(p_params in out nocopy t_ss_parameters, p_document_operation_subtype number);

  procedure Lock_SS_Ser
  (
    p_params in out nocopy t_ss_parameters,
    p_2_side_operation boolean,
    p_lock_src boolean,
    p_lock_dst boolean,
    p_document_operation_subtype number
  );

  procedure Lock_SS_NSer
  (
    p_params in out nocopy t_ss_parameters,
    p_2_side_operation boolean,
    p_lock_src boolean,
    p_lock_dst boolean,
    p_document_operation_subtype number
  );

  procedure Smart_Insert_Absent_NSer
  (
    p_ssext_nser t_xyz_ssext,
    p_params t_ss_parameters,
    p_2_side_operation boolean,
    p_work_side_src boolean
  );

  procedure insert_stock_state(p_coll t_xyz_ssext);

----------------------------------!---------------------------------------------
  procedure XMatchSER_SSEXT4SS_2S(p_doc_header_id number);

  procedure XMatchSER_SSEXT_SRC4DST_2S;
  procedure XMatchSER_SSEXT_SRC4DST_PRT_2S;

----------------------------------!---------------------------------------------
  procedure Prep_SER_SSEXT_DST4LCKD_SRC_1S(p_params t_ss_parameters);
  procedure Prep_SER_SSEXT_DST4Input_1S(p_params t_ss_parameters, p_document_operation_subtype number);

----------------------------------!---------------------------------------------
  procedure get_1side_locks_src
  (
    p_doc_dir_type number,
    p_o_lock_src out boolean
  );

  procedure get_2side_locks_src_dst
  (
    p_doc_dir_type number,
    p_o_lock_src out boolean,
    p_o_lock_dst out boolean
  );

----------------------------------!---------------------------------------------
  procedure Prepare_Stock_State_1S
  (
    p_params in out nocopy t_ss_parameters,
    p_document_operation_subtype number
  );
  procedure Prepare_Stock_State_2S
  (
    p_params in out nocopy t_ss_parameters,
    p_input_from_doc_detail boolean,
    p_document_operation_subtype number
  );

  procedure Prepare_Stock_State
  (
    p_params in out nocopy t_ss_parameters,
    p_document_operation_subtype number
  );

----------------------------------!---------------------------------------------
  --!_!these methods are quiet for empty tables, i.e. doc with no dst-side also calls dst-method (but without payload)
----------------------------------!---------------------------------------------
  procedure i_Upd_SS_Delete_SER_SRC;
  procedure i_Upd_SS_Delete_SER_DST;
  procedure i_Upd_SS_Upd_Delay_SER_SRC(p_doc_header_id number);
  procedure i_Upd_SS_Upd_Apply_SER_DST;
  procedure i_Upd_SS_Upd_Cancel_SER_SRC;
  procedure i_Upd_SS_Insert_SER_DST
  (
    p_finalize boolean,
    p_doc_header_id number
  );

  procedure i_Upd_SS_Upd_Make_NSER_SRC;
  procedure i_Upd_SS_Upd_Make_NSER_DST;
  procedure i_Upd_SS_Upd_Delay_NSER_SRC;
  procedure i_Upd_SS_Upd_Delay_NSER_DST;
  procedure i_Upd_SS_Upd_Apply_NSER_SRC;
  procedure i_Upd_SS_Upd_Apply_NSER_DST;
  procedure i_Upd_SS_Upd_Cancel_NSER_SRC;
  procedure i_Upd_SS_Upd_Cancel_NSER_DST;

----------------------------------!---------------------------------------------
  procedure Update_SS_Ser_Make_1S;
  procedure Update_SS_Ser_Delay_1S(p_doc_header_id number);

  procedure Update_SS_Ser_Apply_2S;
  procedure Update_SS_Ser_Cancel_2S;

  procedure Update_SS_NSer_Make_1S;
  procedure Update_SS_NSer_Delay_1S;

  procedure Update_SS_NSer_Apply_2S;
  procedure Update_SS_NSer_Cancel_2S;

----------------------------------!---------------------------------------------
  procedure Update_SS_Ser_1S(p_params t_ss_parameters);
  procedure Update_SS_Ser_2S(p_params t_ss_parameters);

  procedure Update_SS_NSer_1S(p_params t_ss_parameters);
  procedure Update_SS_NSer_2S(p_params t_ss_parameters);

----------------------------------!---------------------------------------------
  procedure Update_Stock_State_1S(p_params t_ss_parameters);
  procedure Update_Stock_State_2S(p_params t_ss_parameters);

  procedure Update_Stock_State
  (
    p_params in out nocopy t_ss_parameters,
    p_document_operation_subtype number
  );

----------------------------------!---------------------------------------------
  --!!! Refresh_Sims
  procedure Populate_Sims
  (
    p_params t_ss_parameters,
    p_document_operation_subtype number
  );

  function make_sims
  (
    p_equipment_type ct_number,
    p_eq_status number
  ) return t_sims;

  procedure insert_sims(p_coll t_sims);

----------------------------------!---------------------------------------------
  procedure XCheck_Params
  (
    p_params t_ss_parameters
  );

  procedure XCheck_business_rules
  (
    p_params t_ss_parameters,
    p_document_operation_type number
  );

  procedure XCheck_Input_Data
  (
    p_params t_ss_parameters
  );

  procedure XRestrict_in_data_NSER(p_params t_ss_parameters);

  procedure XCheck_Document_Header
  (
    p_doc_header doc_header%rowtype,
    p_doc_type_id number,
    p_stock_id_out number,
    p_stock_id_in number,
    p_doc_status number
  );

  procedure XCheck_rt_in_data_Valid_Until
  (
    p_rt_in_data rt_in_data,
    p_label varchar2
  );

----------------------------------!---------------------------------------------
  procedure Latch_Input_Document
  (
    p_params in out nocopy t_ss_parameters,
    p_exclusive_doc_latch boolean
  );

  procedure Check_Latch_Input_Document(p_params in out nocopy t_ss_parameters);

  procedure Unlatch_Input_Document
  (
    p_params in out nocopy t_ss_parameters,
    p_force boolean
  );

  procedure Latch_Input_Data(p_params in out nocopy t_ss_parameters);
  procedure Check_Latch_Input_Data(p_params in out nocopy t_ss_parameters);

  procedure Unlatch_Input_Data
  (
    p_params in out nocopy t_ss_parameters,
    p_force boolean
  );

  procedure Latch
  (
    p_params in out nocopy t_ss_parameters,
    p_exclusive_doc_latch boolean
  );

  procedure Check_Latch(p_params in out nocopy t_ss_parameters);

  procedure Unlatch
  (
    p_params in out nocopy t_ss_parameters,
    p_force boolean
  );

  procedure Release_Latch(p_params in out nocopy t_ss_parameters);

----------------------------------!---------------------------------------------
  procedure Do_Operation_iii
  (
    p_params in out nocopy t_ss_parameters,
    p_document_operation_subtype number
  );

  procedure Do_Operation_ii
  (
    p_params in out nocopy t_ss_parameters,
    p_document_operation_subtype number
  );

  procedure Do_Operation_i
  (
    p_params in out nocopy t_ss_parameters,
    p_document_operation_type number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure Create_Operation_Int
  (
    p_params in out nocopy t_ss_parameters,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Set_Operation_Equipment_Int
  (
    p_params in out nocopy t_ss_parameters,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Change_Operation_State_Int
  (
    p_params in out nocopy t_ss_parameters,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------

end;
/
