CREATE PACKAGE BODY pkg_report
AS
--******************************************************************************
-- Author  : Skripnik Petr
-- Created : 06.06.2007 12:55
-- Modification : report_management
-- Purpose : Work with the reports
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person           Date        Comments
-- -------------    ------      ------------------------------------------
-- Skripnik Petr   10.07.2007  version 1.11.9.0
--****************************************************************************--
   pkg_name   CONSTANT NVARCHAR2 (50) := 'pkg_report.';

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 19.09.2007 10:31
-- Version :
--   1 19.09.2007
-- Modification : report_management.reversebalancelist -> pkg_out_stock.reverse_balance
-- Editor  :
-- Changed :
-- Purpose : Построение сальдовых ведомостей
-- Problems: IN-параметр p_group_by_stocks BOOLEAN не поддерживается клиентом
--------------------------------------------------------------------------------
   PROCEDURE balance (
      p_group_by_stocks      IN       NUMBER,
      p_from_date            IN       DATE,
      p_to_date              IN       DATE,
      p_cur_moving           OUT      sys_refcursor,
      p_cur_start_salda      OUT      sys_refcursor,
      p_stock_id             IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_equipment_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'balance';
      l_cnt_modelid       NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_group_by_stocks
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_from_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_to_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_stock_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_equipment_model_id.COUNT
                         || ')',
                         pkg_name
                        );
      --Заполним коллекцию идентификаторов складов...
      pkg_stock.set_stockid (p_stock_id => p_stock_id);
      --Заполним коллекцию идентификаторов оборудования...
      pkg_equipment.set_modelid (p_model_id_1 => p_equipment_model_id);
      l_cnt_modelid := pkg_equipment.g_tab_model_id.COUNT;

      IF p_group_by_stocks = 1
      THEN
         balance_group_by_stocks (p_from_date               => p_from_date,
                                             p_to_date                 => p_to_date,
                                             p_cur_moving              => p_cur_moving,
                                             p_stock_id                => p_stock_id,
                                             p_equipment_model_id      => p_equipment_model_id
                                            );
      ELSIF p_group_by_stocks = 0
      THEN
         balance_group_by_series (p_from_date               => p_from_date,
                                             p_to_date                 => p_to_date,
                                             p_cur_moving              => p_cur_moving,
                                             p_stock_id                => p_stock_id,
                                             p_equipment_model_id      => p_equipment_model_id
                                            );
      END IF;

      --Сформируем состояние склада на дату
      pkg_stock.state_prepare (p_date                         => p_from_date,
                               p_is_update_validity_date      => FALSE,
                               p_is_process_opened_doc        => TRUE,
                               p_is_detailed                  => FALSE
                              );

      OPEN p_cur_start_salda FOR
         SELECT e.equipment_model_id, a.quantity, a.total_price,
                SUM (a.quantity) OVER (PARTITION BY et.equipment_type_id) AS quantity_for_type,
                SUM (a.total_price) OVER (PARTITION BY et.equipment_type_id)
                                                                            AS total_price_for_type
           FROM (SELECT   sq.equipment_model_id, SUM (sq.quantity) AS quantity,
                          SUM (sq.quantity * eb.price) AS total_price
                     FROM (SELECT   --+ DYNAMIC_SAMPLING (t 2)
                                    t.equipment_model_id, SUM (t.quantity_onstock + t.quantity_reserved) AS quantity,
                                    t.equipment_batch_id
                               FROM tmp_ss1 t
                           GROUP BY t.equipment_model_id, t.equipment_batch_id
                                                                              --HAVING SUM (t.quantity_onstock) > 0
                                                                              --    OR SUM (t.quantity_reserved) > 0
                                                                              --    OR SUM (t.quantity_announced) > 0
                          ) sq,
                          equipment_batch eb
                    WHERE sq.equipment_batch_id = eb.equipment_batch_id(+)
                 GROUP BY sq.equipment_model_id) a,
                (SELECT equipment_model_id
                   FROM equipment_model em
                  WHERE (   equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 2)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                         OR l_cnt_modelid = 0
                        )) e,
                equipment_model em,
                equipment_type et
          WHERE a.equipment_model_id(+) = e.equipment_model_id
            AND em.equipment_model_id = e.equipment_model_id
            AND em.equipment_type_id = et.equipment_type_id;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END balance;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr (SP)
-- Created : 17.09.2007 16:17
-- Version : 1 17.09.2007
-- Modification : report_management.reversebalancelist -> pkg_out_stock.reverse_balance
-- Editor  : SP
-- Changed :
--    25.03.2008 TRUNC (b.doc_date) -> b.doc_date
--               из PARTITION BY убрал b.stock_out_id, b.stock_in_id,
-- Purpose : Построение сальдовых ведомостей сгруппирпованных по серии оборудования
--------------------------------------------------------------------------------
   PROCEDURE balance_group_by_series (
      p_from_date            IN       DATE,
      p_to_date              IN       DATE,
      p_cur_moving           OUT      sys_refcursor,
      p_stock_id             IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_equipment_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'balance_group_by_series';
      l_cnt_modelid       NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_from_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_to_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_stock_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_equipment_model_id.COUNT
                         || ')',
                         pkg_name
                        );
      l_cnt_modelid := pkg_equipment.g_tab_model_id.COUNT;

      OPEN p_cur_moving FOR
         SELECT d.doc_type_id, d.doc_date, d.doc_no, d.stock_out_id, d.stock_in_id,
                d.equipment_model_id, d.seria_start, d.seria_end, d.quantity, eb.price
           FROM (SELECT   MAX (c.doc_type_id) AS doc_type_id, c.doc_date, MAX (c.doc_no) AS doc_no,
                          c.stock_out_id, c.stock_in_id, c.equipment_model_id,
                          MIN (c.seria_start) AS seria_start, MAX (c.seria_end) AS seria_end,
                          SUM (c.quantity) AS quantity, c.equipment_batch_id
                     FROM (SELECT b.doc_type_id, b.doc_date, b.doc_no, b.stock_out_id,
                                  b.stock_in_id, b.equipment_model_id, b.seria_start, b.seria_end,
                                  b.quantity, b.equipment_batch_id,
                                  SUM (b.start_of_group) OVER (PARTITION BY b.ID, b.doc_date, b.equipment_model_id, b.equipment_batch_id ORDER BY b.seria_start)
                                                                                        AS group_no,
                                  b.signature
                             FROM (SELECT --+ NO_MERGE(a) PUSH_SUBQ
                                          a.ID, a.doc_type_id, a.doc_date, a.doc_no, a.stock_out_id,
                                          a.stock_in_id, dd.equipment_model_id, dd.seria_start,
                                          dd.seria_end, dd.quantity, dd.equipment_batch_id,
                                          CASE
                                             WHEN (    vet.is_numeric_serial_number = 'Y'
                                                   AND vet.allows_partitioning = 'Y'
                                                  )
                                                THEN DECODE
                                                       (TO_NUMBER
                                                           (LAG (dd.seria_end) OVER (PARTITION BY a.ID, a.doc_date, dd.equipment_model_id, dd.equipment_batch_id ORDER BY SIGN
                                                                                        (dd.quantity),
                                                             dd.seria_start)
                                                           ),
                                                        TO_NUMBER (dd.seria_start) - 1, NULL,
                                                        '1'
                                                       )
                                             ELSE '1'
                                          END start_of_group,
                                          SIGN (dd.quantity) AS signature
                                     FROM (SELECT --+ CARDINALITY (stk 2) INDEX(dh IDX_DOCHEADER_SI_DD_DMI)
                                                  dh.ID, dh.doc_no, dh.stock_out_id, dh.stock_in_id,
                                                  dh.doc_date, dh.doc_type_id
                                             FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                                  doc_header dh
                                            WHERE dh.doc_type_id IN (104, 105, 113)
                                              AND dh.status_id = 1
                                              AND dh.doc_date >= p_from_date
                                              AND dh.doc_date < p_to_date
                                              AND dh.stock_in_id = stk.COLUMN_VALUE
                                           UNION ALL
                                           SELECT --+ CARDINALITY (stk 2) INDEX(dh IDX_DOCHEADER_SI_DD_DMI) PUSH_SUBQ
                                                  dh.ID, dh.doc_no, dh.stock_out_id, dh.stock_in_id,
                                                  dh.doc_date, dh.doc_type_id
                                             FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                                  doc_header dh
                                            WHERE dh.doc_type_id IN (101, 103, 106)
                                              AND dh.status_id = 1
                                              AND dh.doc_date >= p_from_date
                                              AND dh.doc_date < p_to_date
                                              AND dh.stock_out_id NOT IN (
                                                     SELECT --+ CARDINALITY (stk 2) HASH_AJ
                                                            COLUMN_VALUE
                                                       FROM TABLE
                                                               (CAST
                                                                    (pkg_stock.g_tab_id AS ct_number)
                                                               ) stk
                                                      WHERE stk.COLUMN_VALUE <> dh.stock_in_id)
                                              AND dh.stock_in_id = stk.COLUMN_VALUE
                                           UNION ALL
                                           SELECT --+ CARDINALITY (stk 2)INDEX(dh IDX_DOCHEADER_SO_DD_DMO) PUSH_SUBQ
                                                  dh.ID, dh.doc_no, dh.stock_out_id, dh.stock_in_id,
                                                  dh.doc_date, dh.doc_type_id
                                             FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                                  doc_header dh
                                            WHERE dh.doc_type_id IN (102, 103, 107)
                                              AND dh.status_id = 1
                                              AND dh.doc_date >= p_from_date
                                              AND dh.doc_date < p_to_date
                                              AND dh.stock_in_id NOT IN (
                                                     SELECT --+ CARDINALITY (stk 2) HASH_AJ
                                                            COLUMN_VALUE
                                                       FROM TABLE
                                                               (CAST
                                                                    (pkg_stock.g_tab_id AS ct_number)
                                                               ) stk
                                                      WHERE stk.COLUMN_VALUE <> dh.stock_out_id)
                                              AND dh.stock_out_id = stk.COLUMN_VALUE) a,
                                          doc_detail dd,
                                          vw_equipment_type vet,
                                          equipment_model em
                                    WHERE a.ID = dd.doc_header_id
                                      AND (   dd.equipment_model_id IN (
                                                 SELECT --+ CARDINALITY(eqm 2)
                                                        COLUMN_VALUE
                                                   FROM TABLE
                                                           (CAST
                                                               (pkg_equipment.g_tab_model_id AS ct_number
                                                               )
                                                           ) eqm)
                                           OR (l_cnt_modelid = 0)
                                          )
                                      AND dd.equipment_model_id = em.equipment_model_id
                                      AND em.equipment_type_id = vet.equipment_type_id) b) c
                 GROUP BY c.doc_date,
                          c.stock_out_id,
                          c.stock_in_id,
                          c.equipment_model_id,
                          c.group_no,
                          c.equipment_batch_id,
                          c.signature) d,
                equipment_batch eb
          WHERE d.equipment_batch_id = eb.equipment_batch_id(+);

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END balance_group_by_series;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 17.09.2007 16:17
-- Version : 1 17.09.2007
-- Modification : report_management.reversebalancelist -> pkg_out_stock.reverse_balance
-- Editor  :
-- Changed :
-- Purpose : Построение сальдовых ведомостей сгруппирпованных по складу
--------------------------------------------------------------------------------
   PROCEDURE balance_group_by_stocks (
      p_from_date            IN       DATE,
      p_to_date              IN       DATE,
      p_cur_moving           OUT      sys_refcursor,
      p_stock_id             IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_equipment_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'balance_group_by_stocks';
      l_cnt_modelid       NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_from_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_to_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_stock_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_equipment_model_id.COUNT
                         || ')',
                         pkg_name
                        );
      l_cnt_modelid := pkg_equipment.g_tab_model_id.COUNT;

      OPEN p_cur_moving FOR
         SELECT b.doc_type_id, b.doc_date, b.doc_no, b.stock_out_id, b.stock_in_id,
                b.equipment_model_id, b.seria_start, b.seria_end, b.quantity, eb.price
           FROM (SELECT   --+ NO_MERGE(a) PUSH_SUBQ
                          a.doc_type_id, NULL AS doc_date, NULL AS doc_no, a.stock_out_id,
                          a.stock_in_id, dd.equipment_model_id, NULL AS seria_start,
                          NULL AS seria_end, SUM (dd.quantity) AS quantity, dd.equipment_batch_id
                     FROM (SELECT --+ CARDINALITY (stk 2) INDEX(dh IDX_DOCHEADER_SI_DD_DMI)
                                  dh.ID, dh.doc_no, dh.stock_out_id, dh.stock_in_id, dh.doc_date,
                                  dh.doc_type_id
                             FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk, doc_header dh
                            WHERE dh.doc_type_id IN (104, 105, 113)
                              AND dh.status_id = 1
                              AND dh.doc_date >= p_from_date
                              AND dh.doc_date < p_to_date
                              AND dh.stock_in_id = stk.COLUMN_VALUE
                           UNION ALL
                           SELECT --+ CARDINALITY (stk 2) INDEX(dh IDX_DOCHEADER_SI_DD_DMI) PUSH_SUBQ
                                  dh.ID, dh.doc_no, dh.stock_out_id, dh.stock_in_id, dh.doc_date,
                                  dh.doc_type_id
                             FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk, doc_header dh
                            WHERE dh.doc_type_id IN (101, 103, 106)
                              AND dh.status_id = 1
                              AND dh.doc_date >= p_from_date
                              AND dh.doc_date < p_to_date
                              AND dh.stock_out_id NOT IN (
                                              SELECT --+ CARDINALITY (stk 2) HASH_AJ
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk
                                               WHERE stk.COLUMN_VALUE <> dh.stock_in_id)
                              AND dh.stock_in_id = stk.COLUMN_VALUE
                           UNION ALL
                           SELECT --+ CARDINALITY (stk 2)INDEX(dh IDX_DOCHEADER_SO_DD_DMO) PUSH_SUBQ
                                  dh.ID, dh.doc_no, dh.stock_out_id, dh.stock_in_id, dh.doc_date,
                                  dh.doc_type_id
                             FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk, doc_header dh
                            WHERE dh.doc_type_id IN (102, 103, 107)
                              AND dh.status_id = 1
                              AND dh.doc_date >= p_from_date
                              AND dh.doc_date < p_to_date
                              AND dh.stock_in_id NOT IN (
                                              SELECT --+ CARDINALITY (stk 2) HASH_AJ
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk
                                               WHERE stk.COLUMN_VALUE <> dh.stock_out_id)
                              AND dh.stock_out_id = stk.COLUMN_VALUE) a,
                          doc_detail dd
                    WHERE a.ID = dd.doc_header_id
                      AND (   dd.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 2)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                           OR (l_cnt_modelid = 0)
                          )
                 GROUP BY a.doc_type_id,
                          a.stock_out_id,
                          a.stock_in_id,
                          dd.equipment_model_id,
                          dd.equipment_batch_id) b,
                equipment_batch eb
          WHERE b.equipment_batch_id = eb.equipment_batch_id(+);

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END balance_group_by_stocks;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 19.06.2007 10:39
-- Version :
--   1 19.06.2007
-- Modification : report_management.equipmentmotion -> pkg_report.equipment_move
-- Editor  :
-- Changed :
-- Purpose : Движение оборудования c группировкой последовательно идущих серий в
--           одну для одного дня,склада,партии
--------------------------------------------------------------------------------
   PROCEDURE equipment_move_group_by_series (
      p_doc_type             IN       NUMBER,
      p_from_date            IN       DATE,
      p_to_date              IN       DATE,
      p_equipment_model_id   IN       pkg_common.t_num,
      p_cur_eqm_move         OUT      sys_refcursor,
      p_stock_id_out         IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_stock_id_in          IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   )
   AS
      prc_name     CONSTANT NVARCHAR2 (100) := pkg_name || 'equipment_move_group_by_series';
      l_cnt_stk_out         NUMBER;
      l_cnt_stk_type_out    NUMBER;
      l_cnt_stk_owner_out   NUMBER;
      l_cnt_stk_in          NUMBER;
      l_cnt_stk_type_in     NUMBER;
      l_cnt_stk_owner_in    NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_doc_type
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_from_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_to_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_equipment_model_id.COUNT
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || pkg_constants.c_delimiter
                         || p_stock_id_out.COUNT
                         || pkg_constants.c_delimiter
                         || p_stock_id_in.COUNT
                         || ')',
                         pkg_name
                        );
      --Заполним коллекцию идентификаторов складов...
      pkg_stock.set_stockid (p_stock_id_out => p_stock_id_out, p_stock_id_in => p_stock_id_in);
      l_cnt_stk_out := pkg_stock.g_tab_id_out.COUNT;
      l_cnt_stk_in := pkg_stock.g_tab_id_in.COUNT;
      --Заполним коллекцию идентификаторов оборудования...
      pkg_equipment.set_modelid (p_model_id_1 => p_equipment_model_id);

      IF l_cnt_stk_out = 0
      THEN
         SELECT COUNT (*)
           INTO l_cnt_stk_type_out
           FROM tmp_stock_type;

         SELECT COUNT (*)
           INTO l_cnt_stk_owner_out
           FROM tmp_stock_owner;

         SELECT s.ID
         BULK COLLECT INTO pkg_stock.g_tab_id_out
           FROM stock s
          WHERE (s.stock_type IN (SELECT --+ DYNAMIC_SAMPLING (sto 2)
                                         *
                                    FROM tmp_stock_type sto) OR l_cnt_stk_type_out = 0)
            AND (s.stock_owner IN (SELECT --+ DYNAMIC_SAMPLING (soo 2)
                                          *
                                     FROM tmp_stock_owner soo) OR l_cnt_stk_owner_out = 0);
      END IF;

      IF l_cnt_stk_in = 0
      THEN
         SELECT COUNT (*)
           INTO l_cnt_stk_type_in
           FROM tmp_stock_type2;

         SELECT COUNT (*)
           INTO l_cnt_stk_owner_in
           FROM tmp_stock_owner2;

         SELECT s.ID
         BULK COLLECT INTO pkg_stock.g_tab_id_in
           FROM stock s
          WHERE (s.stock_type IN (SELECT --+ DYNAMIC_SAMPLING (sti 2)
                                         *
                                    FROM tmp_stock_type2 sti) OR l_cnt_stk_type_in = 0)
            AND (s.stock_owner IN (SELECT --+ DYNAMIC_SAMPLING (soi 2)
                                          *
                                     FROM tmp_stock_owner2 soi) OR l_cnt_stk_owner_in = 0);
      END IF;

      IF p_doc_type = 103
      THEN
         OPEN p_cur_eqm_move FOR
            SELECT c.doc_type_id, c.doc_date, c.stock_out_id, so.code AS stock_out_code,
                   c.stock_in_id, si.code AS stock_in_code, c.equipment_model_id, c.seria_start,
                   c.seria_end, c.quantity, c.equipment_batch_id, eb.price
              FROM (SELECT   MAX (b.doc_type_id) AS doc_type_id, MAX (b.doc_date) AS doc_date,
                             MAX (b.stock_out_id) AS stock_out_id,
                             MAX (b.stock_in_id) AS stock_in_id, b.equipment_model_id,
                             MIN (b.seria_start) AS seria_start, MAX (b.seria_end) AS seria_end,
                             SUM (b.quantity) AS quantity, b.equipment_batch_id
                        FROM (SELECT a.doc_header_id, a.doc_type_id, a.doc_date, a.stock_out_id,
                                     a.stock_in_id, a.equipment_model_id, a.seria_start,
                                     a.seria_end, a.quantity, a.equipment_batch_id,
                                     SUM (a.start_of_group) OVER (PARTITION BY a.doc_header_id, a.equipment_model_id, a.equipment_batch_id ORDER BY a.seria_start)
                                                                                        AS group_no
                                FROM (SELECT d.doc_header_id, d.doc_type_id, d.doc_date,
                                             d.stock_out_id, d.stock_in_id, d.equipment_model_id,
                                             d.seria_start, d.seria_end, d.quantity,
                                             d.equipment_batch_id,
                                             CASE
                                                WHEN (    vet.is_numeric_serial_number = 'Y'
                                                      AND vet.allows_partitioning = 'Y'
                                                     )
                                                   THEN DECODE
                                                          (TO_NUMBER
                                                              (LAG (d.seria_end) OVER (PARTITION BY doc_header_id, d.equipment_model_id, d.equipment_batch_id ORDER BY d.seria_start)
                                                              ),
                                                           TO_NUMBER (d.seria_start) - 1, NULL,
                                                           '1'
                                                          )
                                                ELSE '1'
                                             END start_of_group
                                        FROM (SELECT /*+ USE_NL(dh dd)
                                                         PUSH_SUBQ
                                                         INDEX(dh IDX_DOCHEADER_SO_DD_DMO) 
                                                         INDEX(dd IDX_DOCDETAIL_DHI_EMI_DMI_DMO)*/
                                                     dh.ID AS doc_header_id, dh.doc_type_id,
                                                     dh.doc_date, dh.stock_out_id, dh.stock_in_id,
                                                     dd.equipment_model_id, dd.seria_start,
                                                     dd.seria_end, dd.quantity,
                                                     dd.equipment_batch_id
                                                FROM doc_header dh, doc_detail dd
                                               WHERE dh.doc_type_id = p_doc_type
                                                 AND dh.status_id = 1
                                                 AND dh.doc_date >= p_from_date
                                                 AND dh.doc_date <= p_to_date
                                                 AND dh.stock_out_id IN (
                                                        SELECT --+ CARDINALITY (so 3)
                                                               COLUMN_VALUE
                                                          FROM TABLE
                                                                  (CAST
                                                                      (pkg_stock.g_tab_id_out AS ct_number
                                                                      )
                                                                  ) so)
                                                 AND dh.stock_in_id IN (
                                                        SELECT --+ CARDINALITY (si 5)
                                                               COLUMN_VALUE
                                                          FROM TABLE
                                                                  (CAST
                                                                      (pkg_stock.g_tab_id_in AS ct_number
                                                                      )
                                                                  ) si)
                                                 AND dd.equipment_model_id IN (
                                                        SELECT --+ CARDINALITY (eqm 10)
                                                               COLUMN_VALUE
                                                          FROM TABLE
                                                                  (CAST
                                                                      (pkg_equipment.g_tab_model_id AS ct_number
                                                                      )
                                                                  ) eqm)
                                                 AND dd.doc_header_id = dh.ID) d,
                                             vw_equipment_type vet,
                                             equipment_model em
                                       WHERE d.equipment_model_id = em.equipment_model_id
                                         AND em.equipment_type_id = vet.equipment_type_id) a) b
                    GROUP BY b.doc_header_id, b.equipment_model_id, b.group_no,
                             b.equipment_batch_id) c,
                   stock so,
                   stock si,
                   equipment_batch eb
             WHERE c.equipment_batch_id = eb.equipment_batch_id(+) AND c.stock_out_id = so.ID
                   AND c.stock_in_id = si.ID;
      ELSIF p_doc_type = 102
      THEN
         OPEN p_cur_eqm_move FOR
            SELECT c.doc_type_id, c.doc_date, c.stock_out_id, so.code AS stock_out_code,
                   NULL AS stock_in_id, NULL AS stock_in_code, c.equipment_model_id, c.seria_start,
                   c.seria_end, c.quantity, c.equipment_batch_id, eb.price
              FROM (SELECT   MAX (b.doc_type_id) AS doc_type_id, MAX (b.doc_date) AS doc_date,
                             MAX (b.stock_out_id) AS stock_out_id,
                             MAX (b.stock_in_id) AS stock_in_id, b.equipment_model_id,
                             MIN (b.seria_start) AS seria_start, MAX (b.seria_end) AS seria_end,
                             SUM (b.quantity) AS quantity, b.equipment_batch_id
                        FROM (SELECT a.doc_header_id, a.doc_type_id, a.doc_date, a.stock_out_id,
                                     a.stock_in_id, a.equipment_model_id, a.seria_start,
                                     a.seria_end, a.quantity, a.equipment_batch_id,
                                     SUM (a.start_of_group) OVER (PARTITION BY a.doc_header_id, a.equipment_model_id, a.equipment_batch_id ORDER BY a.seria_start)
                                                                                        AS group_no
                                FROM (SELECT d.doc_header_id, d.doc_type_id, d.doc_date,
                                             d.stock_out_id, d.stock_in_id, d.equipment_model_id,
                                             d.seria_start, d.seria_end, d.quantity,
                                             d.equipment_batch_id,
                                             CASE
                                                WHEN (    vet.is_numeric_serial_number = 'Y'
                                                      AND vet.allows_partitioning = 'Y'
                                                     )
                                                   THEN DECODE
                                                          (TO_NUMBER
                                                              (LAG (d.seria_end) OVER (PARTITION BY d.doc_header_id, d.equipment_model_id, d.equipment_batch_id ORDER BY d.seria_start)
                                                              ),
                                                           TO_NUMBER (d.seria_start) - 1, NULL,
                                                           '1'
                                                          )
                                                ELSE '1'
                                             END start_of_group
                                        FROM (SELECT /*+ USE_NL(dh dd)
                                                         PUSH_SUBQ
                                                         INDEX(dh IDX_DOCHEADER_SO_DD_DMO) 
                                                         INDEX(dd IDX_DOCDETAIL_DHI_EMI_DMI_DMO)*/
                                                     dh.ID AS doc_header_id, dh.doc_type_id,
                                                     dh.doc_date, dh.stock_out_id, dh.stock_in_id,
                                                     dd.equipment_model_id, dd.seria_start,
                                                     dd.seria_end, dd.quantity,
                                                     dd.equipment_batch_id
                                                FROM doc_header dh, doc_detail dd
                                               WHERE dh.doc_type_id = p_doc_type
                                                 AND dh.status_id = 1
                                                 AND dh.doc_date >= p_from_date
                                                 AND dh.doc_date <= p_to_date
                                                 AND dh.stock_out_id IN (
                                                        SELECT --+ CARDINALITY (so 5)
                                                               COLUMN_VALUE
                                                          FROM TABLE
                                                                  (CAST
                                                                      (pkg_stock.g_tab_id_out AS ct_number
                                                                      )
                                                                  ) so)
                                                 AND dd.equipment_model_id IN (
                                                        SELECT --+ CARDINALITY (eqm 10)
                                                               COLUMN_VALUE
                                                          FROM TABLE
                                                                  (CAST
                                                                      (pkg_equipment.g_tab_model_id AS ct_number
                                                                      )
                                                                  ) eqm)
                                                 AND dd.doc_header_id = dh.ID) d,
                                             vw_equipment_type vet,
                                             equipment_model em
                                       WHERE d.equipment_model_id = em.equipment_model_id
                                         AND em.equipment_type_id = vet.equipment_type_id) a) b
                    GROUP BY b.doc_header_id, b.equipment_model_id, b.group_no,
                             b.equipment_batch_id) c,
                   stock so,
                   equipment_batch eb
             WHERE c.equipment_batch_id = eb.equipment_batch_id(+) AND c.stock_out_id = so.ID;
      ELSIF p_doc_type = 101
      THEN
         OPEN p_cur_eqm_move FOR
            SELECT c.doc_type_id, c.doc_date, NULL AS stock_out_id, NULL AS stock_out_code,
                   c.stock_in_id, si.code AS stock_in_code, c.equipment_model_id, c.seria_start,
                   c.seria_end, c.quantity, c.equipment_batch_id, eb.price
              FROM (SELECT   MAX (b.doc_type_id) AS doc_type_id, MAX (b.doc_date) AS doc_date,
                             MAX (b.stock_out_id) AS stock_out_id,
                             MAX (b.stock_in_id) AS stock_in_id, b.equipment_model_id,
                             MIN (b.seria_start) AS seria_start, MAX (b.seria_end) AS seria_end,
                             SUM (b.quantity) AS quantity, b.equipment_batch_id
                        FROM (SELECT a.doc_header_id, a.doc_type_id, TRUNC (a.doc_date) AS doc_date,
                                     a.stock_out_id, a.stock_in_id, a.equipment_model_id,
                                     a.seria_start, a.seria_end, a.quantity, a.equipment_batch_id,
                                     SUM (a.start_of_group) OVER (PARTITION BY a.doc_header_id, a.equipment_model_id, a.equipment_batch_id ORDER BY a.seria_start)
                                                                                        AS group_no
                                FROM (SELECT d.doc_header_id, d.doc_type_id, d.doc_date,
                                             d.stock_out_id, d.stock_in_id, d.equipment_model_id,
                                             d.seria_start, d.seria_end, d.quantity,
                                             d.equipment_batch_id,
                                             CASE
                                                WHEN (    vet.is_numeric_serial_number = 'Y'
                                                      AND vet.allows_partitioning = 'Y'
                                                     )
                                                   THEN DECODE
                                                          (TO_NUMBER
                                                              (LAG (d.seria_end) OVER (PARTITION BY d.doc_header_id, d.equipment_model_id, d.equipment_batch_id ORDER BY d.seria_start)
                                                              ),
                                                           TO_NUMBER (d.seria_start) - 1, NULL,
                                                           '1'
                                                          )
                                                ELSE '1'
                                             END start_of_group
                                        FROM (SELECT /*+ USE_NL(dh dd)
                                                         PUSH_SUBQ
                                                         INDEX(dh IDX_DOCHEADER_SO_DD_DMO) 
                                                         INDEX(dd IDX_DOCDETAIL_DHI_EMI_DMI_DMO)*/
                                                     dh.ID AS doc_header_id, dh.doc_type_id,
                                                     dh.doc_date, dh.stock_out_id, dh.stock_in_id,
                                                     dd.equipment_model_id, dd.seria_start,
                                                     dd.seria_end, dd.quantity,
                                                     dd.equipment_batch_id
                                                FROM doc_header dh, doc_detail dd
                                               WHERE dh.doc_type_id = p_doc_type
                                                 AND dh.status_id = 1
                                                 AND dh.doc_date >= p_from_date
                                                 AND dh.doc_date <= p_to_date
                                                 AND dh.stock_in_id IN (
                                                        SELECT --+ CARDINALITY (si 5)
                                                               COLUMN_VALUE
                                                          FROM TABLE
                                                                  (CAST
                                                                      (pkg_stock.g_tab_id_in AS ct_number
                                                                      )
                                                                  ) si)
                                                 AND dd.equipment_model_id IN (
                                                        SELECT --+ CARDINALITY (eqm 10)
                                                               COLUMN_VALUE
                                                          FROM TABLE
                                                                  (CAST
                                                                      (pkg_equipment.g_tab_model_id AS ct_number
                                                                      )
                                                                  ) eqm)
                                                 AND dd.doc_header_id = dh.ID) d,
                                             vw_equipment_type vet,
                                             equipment_model em
                                       WHERE d.equipment_model_id = em.equipment_model_id
                                         AND em.equipment_type_id = vet.equipment_type_id) a) b
                    GROUP BY b.doc_header_id, b.equipment_model_id, b.group_no,
                             b.equipment_batch_id) c,
                   stock si,
                   equipment_batch eb
             WHERE c.equipment_batch_id = eb.equipment_batch_id(+) AND c.stock_in_id = si.ID;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END equipment_move_group_by_series;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 02.07.2007 15:44
-- Version :
--   1 02.07.2007
-- Modification : report_management.equipmentmotion -> pkg_report.equipment_move
-- Editor  :
-- Changed :
-- Purpose : Движение оборудования c группировкой по складам и модели оборудования
--------------------------------------------------------------------------------
   PROCEDURE equipment_move_group_by_stocks (
      p_doc_type             IN       NUMBER,
      p_from_date            IN       DATE,
      p_to_date              IN       DATE,
      p_equipment_model_id   IN       pkg_common.t_num,
      p_cur_eqm_move         OUT      sys_refcursor,
      p_stock_id_out         IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_stock_id_in          IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   )
   AS
      prc_name     CONSTANT NVARCHAR2 (100) := pkg_name || 'equipment_move_group_by_stocks';
      l_cnt_stk_out         NUMBER;
      l_cnt_stk_type_out    NUMBER;
      l_cnt_stk_owner_out   NUMBER;
      l_cnt_stk_in          NUMBER;
      l_cnt_stk_type_in     NUMBER;
      l_cnt_stk_owner_in    NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_doc_type
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_from_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_to_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_equipment_model_id.COUNT
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || pkg_constants.c_delimiter
                         || p_stock_id_out.COUNT
                         || pkg_constants.c_delimiter
                         || p_stock_id_in.COUNT
                         || ')',
                         pkg_name
                        );
      --Заполним коллекцию идентификаторов складов...
      pkg_stock.set_stockid (p_stock_id_out => p_stock_id_out, p_stock_id_in => p_stock_id_in);
      l_cnt_stk_out := pkg_stock.g_tab_id_out.COUNT;
      l_cnt_stk_in := pkg_stock.g_tab_id_in.COUNT;
      --Заполним коллекцию идентификаторов оборудования...
      pkg_equipment.set_modelid (p_model_id_1 => p_equipment_model_id);

      IF l_cnt_stk_out = 0
      THEN
         SELECT COUNT (*)
           INTO l_cnt_stk_type_out
           FROM tmp_stock_type;

         SELECT COUNT (*)
           INTO l_cnt_stk_owner_out
           FROM tmp_stock_owner;

         SELECT s.ID
         BULK COLLECT INTO pkg_stock.g_tab_id_out
           FROM stock s
          WHERE (s.stock_type IN (SELECT --+ DYNAMIC_SAMPLING (sto 2)
                                         *
                                    FROM tmp_stock_type sto) OR l_cnt_stk_type_out = 0)
            AND (s.stock_owner IN (SELECT --+ DYNAMIC_SAMPLING (soo 2)
                                          *
                                     FROM tmp_stock_owner soo) OR l_cnt_stk_owner_out = 0);
      END IF;

      IF l_cnt_stk_in = 0
      THEN
         SELECT COUNT (*)
           INTO l_cnt_stk_type_in
           FROM tmp_stock_type2;

         SELECT COUNT (*)
           INTO l_cnt_stk_owner_in
           FROM tmp_stock_owner2;

         SELECT s.ID
         BULK COLLECT INTO pkg_stock.g_tab_id_in
           FROM stock s
          WHERE (s.stock_type IN (SELECT --+ DYNAMIC_SAMPLING (sti 2)
                                         *
                                    FROM tmp_stock_type2 sti) OR l_cnt_stk_type_in = 0)
            AND (s.stock_owner IN (SELECT --+ DYNAMIC_SAMPLING (soi 2)
                                          *
                                     FROM tmp_stock_owner2 soi) OR l_cnt_stk_owner_in = 0);
      END IF;

      IF p_doc_type = 103
      THEN
         OPEN p_cur_eqm_move FOR
            SELECT p_doc_type AS doc_type_id, NULL AS doc_date, sq.stock_out_id,
                   so.code AS stock_out_code, sq.stock_in_id, si.code AS stock_in_code,
                   sq.equipment_model_id, NULL AS seria_start, NULL AS seria_end, sq.quantity,
                   NULL AS valid_until, sq.equipment_batch_id, sq.price
              FROM (SELECT   --+ USE_NL(dh dd) PUSH_SUBQ INDEX(dh IDX_DOCHEADER_SO_DD_DMO) INDEX(dd IDX_DOCDETAIL_DHI_EMI_DMI_DMO)
                             dh.stock_out_id, dh.stock_in_id, dd.equipment_model_id,
                             SUM (dd.quantity) AS quantity, dd.equipment_batch_id,
                             MAX (eb.price) AS price
                        FROM doc_header dh, doc_detail dd, equipment_batch eb
                       WHERE dh.doc_type_id = p_doc_type
                         AND dh.status_id = 1
                         AND dh.doc_date >= p_from_date
                         AND dh.doc_date <= p_to_date
                         AND dh.stock_out_id IN (
                                           SELECT --+ CARDINALITY (so 2)
                                                  COLUMN_VALUE
                                             FROM TABLE (CAST (pkg_stock.g_tab_id_out AS ct_number)) so)
                         AND dh.stock_in_id IN (
                                            SELECT --+ CARDINALITY (si 6)
                                                   COLUMN_VALUE
                                              FROM TABLE (CAST (pkg_stock.g_tab_id_in AS ct_number)) si)
                         AND dd.equipment_model_id IN (
                                    SELECT --+ CARDINALITY (eqm 3)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                         AND dd.doc_header_id = dh.ID
                         AND dd.equipment_batch_id = eb.equipment_batch_id(+)
                    GROUP BY dh.stock_out_id,
                             dh.stock_in_id,
                             dd.equipment_model_id,
                             dd.equipment_batch_id) sq,
                   stock so,
                   stock si
             WHERE sq.stock_out_id = so.ID AND sq.stock_in_id = si.ID;
      ELSIF p_doc_type = 102
      THEN
         OPEN p_cur_eqm_move FOR
            SELECT p_doc_type AS doc_type_id, NULL AS doc_date, sq.stock_out_id,
                   so.code AS stock_out_code, NULL AS stock_in_id, NULL AS stock_in_code,
                   sq.equipment_model_id, NULL AS seria_start, NULL AS seria_end, sq.quantity,
                   NULL AS valid_until, sq.equipment_batch_id, sq.price
              FROM (SELECT   --+ USE_NL(dh dd) PUSH_SUBQ INDEX(dh IDX_DOCHEADER_SO_DD_DMO) INDEX(dd IDX_DOCDETAIL_DHI_EMI_DMI_DMO)
                             dh.stock_out_id, dd.equipment_model_id, SUM (dd.quantity) AS quantity,
                             dd.equipment_batch_id, MAX (eb.price) AS price
                        FROM doc_header dh, doc_detail dd, equipment_batch eb
                       WHERE dh.doc_type_id = p_doc_type
                         AND dh.status_id = 1
                         AND dh.doc_date >= p_from_date
                         AND dh.doc_date <= p_to_date
                         AND dh.stock_out_id IN (
                                           SELECT --+ CARDINALITY (so 2)
                                                  COLUMN_VALUE
                                             FROM TABLE (CAST (pkg_stock.g_tab_id_out AS ct_number)) so)
                         AND dd.equipment_model_id IN (
                                    SELECT --+ CARDINALITY (eqm 5)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                         AND dd.doc_header_id = dh.ID
                         AND dd.equipment_batch_id = eb.equipment_batch_id(+)
                    GROUP BY dh.stock_out_id,
                             dh.stock_in_id,
                             dd.equipment_model_id,
                             dd.equipment_batch_id) sq,
                   stock so
             WHERE sq.stock_out_id = so.ID;
      ELSIF p_doc_type = 101
      THEN
         OPEN p_cur_eqm_move FOR
            SELECT p_doc_type AS doc_type_id, NULL AS doc_date, NULL AS stock_out_id,
                   NULL AS stock_out_code, sq.stock_in_id, si.code AS stock_in_code,
                   sq.equipment_model_id, NULL AS seria_start, NULL AS seria_end, sq.quantity,
                   NULL AS valid_until, sq.equipment_batch_id, sq.price
              FROM (SELECT   --+ USE_NL(dh dd) PUSH_SUBQ INDEX(dh IDX_DOCHEADER_SI_DD_DMI) NDEX(dd IDX_DOCDETAIL_DHI_EMI_DMI_DMO)
                             dh.stock_in_id, dd.equipment_model_id, SUM (dd.quantity) AS quantity,
                             dd.equipment_batch_id, MAX (eb.price) AS price
                        FROM doc_header dh, doc_detail dd, equipment_batch eb
                       WHERE dh.doc_type_id = p_doc_type
                         AND dh.status_id = 1
                         AND dh.doc_date >= p_from_date
                         AND dh.doc_date <= p_to_date
                         AND dh.stock_in_id IN (
                                            SELECT --+ CARDINALITY (si 5)
                                                   COLUMN_VALUE
                                              FROM TABLE (CAST (pkg_stock.g_tab_id_in AS ct_number)) si)
                         AND dd.equipment_model_id IN (
                                    SELECT --+ CARDINALITY (eqm 5)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                         AND dd.doc_header_id = dh.ID
                         AND dd.equipment_batch_id = eb.equipment_batch_id(+)
                    GROUP BY dh.stock_out_id,
                             dh.stock_in_id,
                             dd.equipment_model_id,
                             dd.equipment_batch_id) sq,
                   stock si
             WHERE sq.stock_in_id = si.ID;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END equipment_move_group_by_stocks;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 05.09.2007 14:08
-- Version : 1 05.09.2007
-- Modification : stock_management.stock_state__to_date_mega2 -> pkg_stock.state_on_date ->
--                -> pkg_stock.state_on_date + stock_management.stock_state__to_date_now ->
--                -> pkg_report.inventory
-- Editor  :
-- Changed :
-- Purpose : Получаем состояние складов на указанную дату объеденяя серии оборудования
--           учитывая партию и срок годности
--------------------------------------------------------------------------------
   PROCEDURE inventory_group_by_series (
      p_date                 IN       DATE,
      p_cur_inventory        OUT      sys_refcursor,
      p_stock_id             IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_equipment_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100)             := pkg_name || 'inventory_group_by_series';
      l_cnt_stockid       NUMBER;
      l_cnt_modelid       NUMBER;
      l_cnt_type          tmp_stock_type.ID%TYPE;
      l_cnt_owner         tmp_stock_owner.NAME%TYPE;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || pkg_constants.c_delimiter
                         || p_stock_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_equipment_model_id.COUNT
                         || ')',
                         pkg_name
                        );
      --Заполним коллекцию идентификаторов складов...
      pkg_stock.set_stockid (p_stock_id => p_stock_id);

      IF pkg_stock.g_tab_id.COUNT = 0
      THEN
         SELECT COUNT (*)
           INTO l_cnt_type
           FROM tmp_stock_type;

         SELECT COUNT (*)
           INTO l_cnt_owner
           FROM tmp_stock_owner;

         SELECT s.ID
         BULK COLLECT INTO pkg_stock.g_tab_id
           FROM stock s
          WHERE (s.stock_type IN (SELECT ID
                                    FROM tmp_stock_type) OR l_cnt_type = 0)
            AND (s.stock_owner IN (SELECT NAME
                                     FROM tmp_stock_owner) OR l_cnt_owner = 0);

         pkg_db_util.DEBUG (prc_name, 'l_cnt_stockid by type/owner =' || l_cnt_stockid, pkg_name);
      END IF;

      --Количество заданных складов
      l_cnt_stockid := pkg_stock.g_tab_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'l_cnt_stockid =' || l_cnt_stockid, pkg_name);

      IF l_cnt_stockid = 0
      THEN
         raise_application_error (-20001, 'Stocks not found');
      END IF;

      --Заполним коллекцию идентификаторов оборудования...
      pkg_equipment.set_modelid (p_model_id_1 => p_equipment_model_id);
      --Количество заданного оборудования
      l_cnt_modelid := pkg_equipment.g_tab_model_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'l_cnt_modelid =' || l_cnt_modelid, pkg_name);

      --Если задана текущая дата то...
      IF p_date IS NULL
      THEN
         OPEN p_cur_inventory FOR
            SELECT --+ NO_MERGE(cs)
                   cs.stock_id, s.code AS stock_code, s.NAME AS stock_name, cs.equipment_model_id,
                   cs.seria_start, cs.seria_end, cs.quantity, cs.create_date AS valid_until,
                   cs.equipment_batch_id, eb.price
              FROM (SELECT   b.stock_id, b.equipment_model_id, MIN (b.seria_start) AS seria_start,
                             MAX (b.seria_end) AS seria_end, SUM (b.quantity_onstock + b.quantity_reserved) AS quantity,
                             MAX (b.equipment_batch_id) AS equipment_batch_id,
                             MAX (b.create_date) AS create_date
                        FROM (SELECT a.stock_id, a.equipment_model_id, a.seria_start, a.seria_end,
                                     a.quantity_onstock, a.quantity_reserved, a.equipment_batch_id, a.create_date,
                                     SUM (a.start_of_group) OVER (PARTITION BY a.equipment_model_id, a.stock_id ORDER BY a.seria_start)
                                                                                        AS group_no
                                FROM (SELECT ss.stock_id, ss.equipment_model_id, ss.seria_start,
                                             ss.seria_end, ss.quantity_onstock, ss.quantity_reserved,
                                             ss.equipment_batch_id, ss.create_date,
                                             CASE
                                                WHEN (    vet.is_numeric_serial_number = 'Y'
                                                      AND vet.allows_partitioning = 'Y'
                                                     )
                                                   THEN DECODE
                                                          (TO_NUMBER
                                                              (LAG (ss.seria_end) OVER (PARTITION BY ss.equipment_model_id, ss.stock_id, ss.equipment_batch_id, TRUNC
                                                                                                                                                                  (ss.create_date
                                                                                                                                                                  ) ORDER BY ss.seria_start)
                                                              ),
                                                           TO_NUMBER (ss.seria_start) - 1, NULL,
                                                           '1'
                                                          )
                                                ELSE '1'
                                             END start_of_group
                                        FROM stock_state ss, vw_equipment_type vet
                                       WHERE ss.stock_id IN (
                                                SELECT --+ CARDINALITY(stk 5)
                                                       COLUMN_VALUE
                                                  FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                                         AND (   (ss.equipment_model_id IN (
                                                     SELECT --+ CARDINALITY(eqm 2)
                                                            COLUMN_VALUE
                                                       FROM TABLE
                                                               (CAST
                                                                   (pkg_equipment.g_tab_model_id AS ct_number
                                                                   )
                                                               ) eqm)
                                                 )
                                              OR (0 = l_cnt_modelid)
                                             )
                                         AND ss.equipment_type_id = vet.equipment_type_id
                                         AND (ss.quantity_onstock + ss.quantity_reserved) > 0) a) b
                    GROUP BY b.stock_id, b.equipment_model_id, b.group_no) cs,
                   stock s,
                   equipment_batch eb
             WHERE cs.stock_id = s.ID AND cs.equipment_batch_id = eb.equipment_batch_id(+);
      --Если задана любая дата кроме текущей то...
      ELSE
         pkg_stock.state_prepare (p_date                         => p_date,
                                  p_is_update_validity_date      => TRUE,
                                  p_is_process_opened_doc        => TRUE
                                 );

         OPEN p_cur_inventory FOR
            SELECT --+ NO_MERGE(cs)
                   cs.stock_id, s.code AS stock_code, s.NAME AS stock_name, cs.equipment_model_id,
                   cs.seria_start, cs.seria_end, cs.quantity, cs.valid_until, cs.equipment_batch_id,
                   eb.price
              FROM (SELECT   b.stock_id, b.equipment_model_id, MIN (b.seria_start) AS seria_start,
                             MAX (b.seria_end) AS seria_end, SUM (b.quantity_onstock + b.quantity_reserved) AS quantity,
                             MAX (b.equipment_batch_id) AS equipment_batch_id,
                             MAX (b.valid_until) AS valid_until
                        FROM (SELECT a.stock_id, a.equipment_model_id, a.seria_start, a.seria_end,
                                     a.quantity_onstock, a.quantity_reserved, a.equipment_batch_id, a.valid_until,
                                     SUM (a.start_of_group) OVER (PARTITION BY a.equipment_model_id, a.stock_id ORDER BY a.seria_start)
                                                                                        AS group_no
                                FROM (SELECT --+ DYNAMIC_SAMPLING(t 2) CARDINALITY(vet 3) CARDINALITY(em 7)
                                             t.stock_id, t.equipment_model_id, t.seria_start,
                                             t.seria_end, t.quantity_onstock, t.quantity_reserved, t.equipment_batch_id,
                                             t.valid_until,
                                             CASE
                                                WHEN (    vet.is_numeric_serial_number = 'Y'
                                                      AND vet.allows_partitioning = 'Y'
                                                     )
                                                   THEN DECODE
                                                          (TO_NUMBER
                                                              (LAG (t.seria_end) OVER (PARTITION BY t.equipment_model_id, t.stock_id, t.equipment_batch_id, TRUNC
                                                                                                                                                              (t.valid_until
                                                                                                                                                              ) ORDER BY t.seria_start)
                                                              ),
                                                           TO_NUMBER (t.seria_start) - 1, NULL,
                                                           '1'
                                                          )
                                                ELSE '1'
                                             END start_of_group
                                        FROM tmp_ss1 t, vw_equipment_type vet, equipment_model em
                                       WHERE em.equipment_type_id = vet.equipment_type_id
                                         AND t.equipment_model_id = em.equipment_model_id
                                         AND (t.quantity_onstock + t.quantity_reserved) > 0) a) b
                    GROUP BY b.stock_id, b.equipment_model_id, b.group_no) cs,
                   stock s,
                   equipment_batch eb
             WHERE cs.stock_id = s.ID AND cs.equipment_batch_id = eb.equipment_batch_id(+);
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END inventory_group_by_series;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 05.09.2007 14:30
-- Version : 1 05.09.2007
-- Modification : stock_management.stock_state__to_date_mega2 -> pkg_stock.state_on_date ->
--                -> pkg_stock.state_on_date + stock_management.stock_state__to_date_now ->
--                -> pkg_report.inventory
-- Editor  :
-- Changed :
-- Purpose : Получаем состояние складов на указанную дату объеденяя оборудования по партии
--------------------------------------------------------------------------------
   PROCEDURE inventory_group_by_stocks (
      p_date                 IN       DATE,
      p_cur_inventory        OUT      sys_refcursor,
      p_stock_id             IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_equipment_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100)             := pkg_name || 'inventory_group_by_stocks';
      l_cnt_stockid       NUMBER;
      l_cnt_modelid       NUMBER;
      l_cnt_type          tmp_stock_type.ID%TYPE;
      l_cnt_owner         tmp_stock_owner.NAME%TYPE;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || pkg_constants.c_delimiter
                         || p_stock_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_equipment_model_id.COUNT
                         || ')',
                         pkg_name
                        );
      --Заполним коллекцию идентификаторов складов...
      pkg_stock.set_stockid (p_stock_id => p_stock_id);

      IF pkg_stock.g_tab_id.COUNT = 0
      THEN
         SELECT COUNT (*)
           INTO l_cnt_type
           FROM tmp_stock_type;

         SELECT COUNT (*)
           INTO l_cnt_owner
           FROM tmp_stock_owner;

         SELECT s.ID
         BULK COLLECT INTO pkg_stock.g_tab_id
           FROM stock s
          WHERE (s.stock_type IN (SELECT ID
                                    FROM tmp_stock_type) OR l_cnt_type = 0)
            AND (s.stock_owner IN (SELECT NAME
                                     FROM tmp_stock_owner) OR l_cnt_owner = 0);

         pkg_db_util.DEBUG (prc_name, 'l_cnt_stockid by type/owner =' || l_cnt_stockid, pkg_name);
      END IF;

      --Количество заданных складов
      l_cnt_stockid := pkg_stock.g_tab_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'l_cnt_stockid =' || l_cnt_stockid, pkg_name);

      IF l_cnt_stockid = 0
      THEN
         raise_application_error (-20001, 'Stocks not found');
      END IF;

      --Заполним коллекцию идентификаторов оборудования...
      pkg_equipment.set_modelid (p_model_id_1 => p_equipment_model_id);
      --Количество заданного оборудования
      l_cnt_modelid := pkg_equipment.g_tab_model_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'l_cnt_modelid =' || l_cnt_modelid, pkg_name);

      --Если задана текущая дата то...
      IF p_date IS NULL
      THEN
         OPEN p_cur_inventory FOR
            SELECT   sq.stock_id, MAX (s.code) AS stock_code, MAX (s.NAME) AS stock_name,
                     sq.equipment_model_id, NULL AS seria_start, NULL AS seria_end,
                     SUM (sq.quantity_onstock + sq.quantity_reserved) AS quantity, MAX (sq.create_date) AS valid_until,
                     sq.equipment_batch_id, MAX (eb.price) AS price
                FROM (SELECT --+ CARDINALITY (stk 2) INDEX(ss I_STOCK_STATE_STOCK_ID) USE_NL(stk ss)
                             ss.stock_id, ss.equipment_model_id, ss.quantity_onstock, ss.quantity_reserved,
                             ss.create_date, ss.equipment_batch_id
                        FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk JOIN stock_state ss
                             ON ss.stock_id = stk.COLUMN_VALUE
                       WHERE (ss.quantity_onstock + ss.quantity_reserved) > 0 AND l_cnt_modelid = 0
                      UNION ALL
                      SELECT --+ INDEX(ss I_STOCK_STATE_EQM)
                             ss.stock_id, ss.equipment_model_id, ss.quantity_onstock, ss.quantity_reserved,
                             ss.create_date, ss.equipment_batch_id
                        FROM stock_state ss
                       WHERE ss.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 2)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                         AND ss.stock_id IN (SELECT --+ CARDINALITY (stk 2)
                                                    COLUMN_VALUE
                                               FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                         AND (ss.quantity_onstock + ss.quantity_reserved) > 0
                         AND l_cnt_modelid > 0) sq,
                     stock s,
                     equipment_batch eb
               WHERE sq.stock_id = s.ID AND sq.equipment_batch_id = eb.equipment_batch_id(+)
            GROUP BY sq.stock_id, sq.equipment_model_id, sq.equipment_batch_id;
      --Если задана любая дата кроме текущей то...
      ELSE
         pkg_stock.state_prepare (p_date                         => p_date,
                                  p_is_update_validity_date      => TRUE,
                                  p_is_process_opened_doc        => TRUE,
                                  p_is_detailed                  => FALSE
                                 );

         OPEN p_cur_inventory FOR
            SELECT sq.stock_id, s.code AS stock_code, s.NAME AS stock_name, sq.equipment_model_id,
                   NULL AS seria_start, NULL AS seria_end, (sq.quantity_onstock + sq.quantity_reserved) AS quantity,
                   sq.valid_until, sq.equipment_batch_id, eb.price
              FROM tmp_ss1 sq, stock s, equipment_batch eb
             WHERE sq.stock_id = s.ID AND sq.equipment_batch_id = eb.equipment_batch_id(+)
                AND (sq.quantity_onstock + sq.quantity_reserved) > 0;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END inventory_group_by_stocks;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 09.06.2007 12:40
-- Editor  :
-- Changed :
-- Purpose : Возвращает список всех складов системы
--------------------------------------------------------------------------------
   PROCEDURE list_of_stocks (p_cur_all_stocks OUT sys_refcursor)
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'list_of_stocks';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      OPEN p_cur_all_stocks FOR
         SELECT   parent_id, GROUP_ID, group_name, stock_id, stock_name, stock_code, stock_type,
                  owner, manager, address, zip, tel, fax, e_mail, description, deleted
             FROM vw_stock_tree
            WHERE deleted IS NULL
         ORDER BY GROUP_ID, stock_code;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END list_of_stocks;

END;
/
