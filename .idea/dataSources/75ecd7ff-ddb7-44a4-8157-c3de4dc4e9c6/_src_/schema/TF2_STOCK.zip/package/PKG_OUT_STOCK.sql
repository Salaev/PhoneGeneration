CREATE PACKAGE pkg_out_stock
AS

   TYPE t_number IS TABLE OF NUMBER
      INDEX BY BINARY_INTEGER;

   TYPE t_varchar2 IS TABLE OF VARCHAR2 (50)
      INDEX BY BINARY_INTEGER;
--******************************************************************************
-- Author  : Skripnik Petr
-- Created : 16.10.2006 14:05
-- Purpose : Work with the stocks from external subsystems
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ------------------------------------------
-- Petr Skripnik   09.11.2006  Изменен
-- Skripnik Petr   16.04.2007  version 1.11.8.2
-- Skripnik Petr   03.05.2007  version 1.11.8.3
-- Skripnik Petr   17.10.2007  version 1.11.9.0
--****************************************************************************--
--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 31.10.2007 13:03
-- Editor  :
-- Changed :
-- Purpose : Получает массив идентификаторов модели оборудования
--           по списку кодов оборудования
--------------------------------------------------------------------------------
   FUNCTION eqmidtab_by_eqmcodelist (p_equipment_code_list IN LONG, p_delimiter IN CHAR DEFAULT ',')
      RETURN pkg_common.t_num;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 08.11.2007 13:38
-- Version : 1
-- Modification :
-- Editor  :
-- Changed :
-- Purpose : Покажет движение оборудования
--------------------------------------------------------------------------------
   PROCEDURE equipment_move (
      p_doc_type           IN       NUMBER,   --101/102/103
      p_from_date          IN       DATE,   --any date
      p_to_date            IN       DATE,   --any date
      p_detailed           IN       NUMBER,   --1=TRUE/0=FALSE
      p_cur_eqm_move       OUT      sys_refcursor,
      p_eqm_code_list      IN       LONG DEFAULT '-1',
      p_stk_code_out       IN       LONG DEFAULT '-1',
      p_stk_group_id_out   IN       LONG DEFAULT NULL,
      p_stk_code_in        IN       LONG DEFAULT '-1',
      p_stk_group_id_in    IN       LONG DEFAULT NULL,
      p_delimiter          IN       CHAR DEFAULT ','
   );

-------------------------------------------------------------------------------
-- Author  : Anoev Maxim
-- Created : 03.05.2007 14:00
-- Version : 2
-- Modification : get_keo_logistic_on_period
-- Editor  : Skripnik Petr (SP)
-- Purpose : Получаем все движения оборудования на период времени
--           Отчет: Оборотная ведомость по проданным КЭО
--------------------------------------------------------------------------------
   PROCEDURE get_keo_logistic_on_period (
      p_from_date              IN       DATE,   --начальная дата
      p_to_date                IN       DATE,   --конечная дата
      p_stock_from_code_list   IN       LONG,   --склады-отправители
      p_stock_to_code_list     IN       LONG,   --склады-получатели
      p_equipment_code_list    IN       LONG,   --перечисления оборудования через разделитель (,)
      p_cur_start_saldo        OUT      sys_refcursor,   --начальное сальдо
      p_cur_sold               OUT      sys_refcursor,   --продано
      p_cur_activated          OUT      sys_refcursor,   --активировано
      p_cur_returned           OUT      sys_refcursor,   --возвращено
      p_cur_expired            OUT      sys_refcursor,   --просрочено
      p_cur_end_saldo          OUT      sys_refcursor,   --конечное сальдо
      p_cur_stock              OUT      sys_refcursor,   --группы складов
      p_delimiter              IN       VARCHAR2 DEFAULT ','
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 18.10.2006 14:00
-- Editor  :
-- Changed :
-- Purpose : Вернет курсора с состояниями скаладов на указанную дату и диапозона дат (оборотно-сальдовая ведомость)
--------------------------------------------------------------------------------
   PROCEDURE get_reverse_balnce_list (
      p_from_date             IN       DATE,   --начальная дата диапазона
      p_to_date               IN       DATE,   --конечная дата диапазона
      p_equipment_code_list   IN       LONG,   --перечисления оборудования через разделитель (,)
      p_cur_state             OUT      sys_refcursor,   --курсор с состояниями скаладов на указанную дату
      p_cur_state_range       OUT      sys_refcursor,   --курсор с состояниями скаладов на диапазон дат
      p_cur_stocks            OUT      sys_refcursor,   --курсор всех складов
      p_group_stock_id_list   IN       LONG DEFAULT NULL,   --перечисления групп складов через разделитель (,)
      p_stock_code_list       IN       LONG DEFAULT NULL
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 16.10.2006 14:05
-- Version : 2
-- Editor  :
-- Changed :
-- Purpose : Вернет курсор с состояниями скаладов на указанную дату (инвентаризационная и складская ведомость)
--------------------------------------------------------------------------------
   PROCEDURE get_stock_state_on_date (
      p_date                  IN       DATE,   --дата состояния
      p_group_stock_id_list   IN       LONG,   --перечисления групп складов через (,)
      p_stock_code_list       IN       LONG,   --перечисления складов через (,)
      p_equipment_code_list   IN       LONG,   --перечисления оборудования через (,)
      p_cur_state             OUT      sys_refcursor,   --курсор с состояниями скаладов на указанную дату
      p_is_detailed           IN       NUMBER DEFAULT 1
   );

--------------------------------------------------------------------------------
-- Author  : Ermakov Sergey
-- Created : 17.04.2009 14:05
-- Version : 1
-- Editor  :
-- Changed :
-- Purpose : Вернет курсор с состояниями скаладов на указанную дату (инвентаризационная и складская ведомость) с заданным видом детализации
--------------------------------------------------------------------------------
   PROCEDURE get_stock_state_on_date_2 (
      p_date                  IN       DATE,   --дата состояния
      p_group_stock_id_list   IN       LONG,   --перечисления групп складов через (,)
      p_stock_code_list       IN       LONG,   --перечисления складов через (,)
      p_equipment_code_list   IN       LONG,   --перечисления оборудования через (,)
      p_detail                IN       NUMBER DEFAULT 0,  -- 0 - без детализации, 1 - по срокам годности,  2 - по складам, 3 - полная.
      p_cur_state             OUT      sys_refcursor,   --курсор с состояниями скаладов на указанную дату
      p_to_date               IN       DATE DEFAULT NULL   --дата по...
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 06.06.2007 12:56
-- Version : 1 06.06.2007
-- Modification : report_management.reversebalancelist
-- Editor  :
-- Changed :
-- Purpose : Получаем состояние складов на указанную дату (Оборотно-сальдовая ведомость)
--------------------------------------------------------------------------------
   PROCEDURE reverse_balance (
      p_from_date            IN       DATE,
      p_to_date              IN       DATE,
      p_cur_moveing          OUT      sys_refcursor,
      p_cur_start_salda      OUT      sys_refcursor,
      p_stock_id             IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_equipment_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 31.10.2007 13:02
-- Editor  :
-- Changed :
-- Purpose : Получает массив идентификаторов складов по списку кодов складов и идентификаторов групп
--------------------------------------------------------------------------------
   FUNCTION stockidtab_by_stockparamlist (
      p_stock_code_list       IN   LONG,
      p_group_stock_id_list   IN   LONG,
      p_delimiter             IN   CHAR DEFAULT ','
   )
      RETURN pkg_common.t_num;

--------------------------------------------------------------------------------
-- Author  : ???
-- Created :
-- Modification : ???.customer_report_stock.get_stock
-- Editor  : Skripnik Petr
-- Changed : 12.10.2007 12:41
-- Purpose : Получает курсор с инфоромации о складах существующих на указанную дату
--(без проверки прав пользователя)
--------------------------------------------------------------------------------
   PROCEDURE stocks_on_date (p_date_of_search IN DATE, p_cur_stocks OUT sys_refcursor);
   
--------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created :
-- Modification : 
-- Editor  : Pavel Vasiliev
-- Changed : 21.09.2010 
-- Purpose : Метод возвращает данные для отчета
--------------------------------------------------------------------------------
   PROCEDURE GetEquipmentListByStock 
     (p_date_of_serch         IN  DATE,
      p_detailed              IN  NUMBER,
      p_eqp_type_code_list    IN  t_varchar2,
      p_eqp_model_code_list   IN  t_varchar2,
      p_group_stock_id_list   IN  t_number,
      p_stock_code_list       IN  t_varchar2,
      p_valid_until           IN  DATE,
      p_ref                   OUT sys_refcursor,
      ResultCode              OUT NUMBER);
   
--------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created :
-- Modification : 
-- Editor  : Pavel Vasiliev
-- Changed : 21.09.2010 
-- Purpose : Метод возвращает данные для отчета
--------------------------------------------------------------------------------
   PROCEDURE GetInventaryByStock 
     (p_date_of_serch         IN  DATE,
      p_detailed              IN  NUMBER,
      p_eqp_type_code_list    IN  t_varchar2,
      p_eqp_model_code_list   IN  t_varchar2,
      p_group_stock_id_list   IN  t_number,
      p_stock_code_list       IN  t_varchar2,
      p_ref                   OUT sys_refcursor,
      ResultCode              OUT NUMBER);
      
--------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created :
-- Modification : 
-- Editor  : Pavel Vasiliev
-- Changed : 21.09.2010 
-- Purpose : Метод возвращает данные для отчета
--------------------------------------------------------------------------------
   PROCEDURE GetReverseBalanceByStock 
     (p_date_from             IN  DATE,
      p_date_to               IN  DATE,
      p_detailed              IN  NUMBER,
      p_eqp_type_code_list    IN  t_varchar2,
      p_eqp_model_code_list   IN  t_varchar2,
      p_group_stock_id_list   IN  t_number,
      p_stock_code_list       IN  t_varchar2,
      p_ref                   OUT sys_refcursor,
      ResultCode              OUT NUMBER);

--------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created :
-- Modification : 
-- Editor  : Pavel Vasiliev
-- Changed : 21.09.2010 
-- Purpose : Метод возвращает данные для отчета
--------------------------------------------------------------------------------
   PROCEDURE GetMoveOfEquipment 
     (p_date_from                IN  DATE,
      p_date_to                  IN  DATE,
      p_doc_type                 IN  NUMBER,
      p_detailed                 IN  NUMBER,
      p_eqp_model_code_list      IN  t_varchar2,
      p_group_stock_id_in_list   IN  t_number,
      p_stock_code_in_list       IN  t_varchar2,
      p_group_stock_id_out_list  IN  t_number,
      p_stock_code_out_list      IN  t_varchar2,
      p_cur_eqm_move             OUT sys_refcursor,
      ResultCode                 OUT NUMBER);
      
-------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 23.09.2010
-- Version :
-- Modification : pkg_stock.state_prepare_reverse
-- Editor  : Pavel Vasiliev 
-- Changed :
-- Purpose : Получаем получаем состояния оборудования на указанные даты и
---         все движения оборудования на период времени.Состояние
--           строется от состояния на текущую дату по движению документов в обратном порядке
--------------------------------------------------------------------------------
   PROCEDURE stock_state_reverse (
      p_date_from                    IN   DATE,   --начальная дата диапазона
      p_date_to                      IN   DATE   --конечная дата диапазона
   );
   
----------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 23.09.2010
-- Version :
-- Modification : pkg_stock.state_prepare_reverse
-- Editor  : Pavel Vasiliev 
-- Changed :
-- Purpose : Получаем получаем состояния оборудования на указанные даты и
---         все движения оборудования на период времени.Состояние
--           строется от состояния на текущую дату по движению документов в обратном порядке
--------------------------------------------------------------------------------
   PROCEDURE motion_of_equipment (
      p_date_from                    IN   DATE,   --начальная дата диапазона
      p_date_to                      IN   DATE   --конечная дата диапазона
   );
      
END;
/
