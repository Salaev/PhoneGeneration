CREATE PACKAGE BODY bulk_insert_management
AS
--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 09.11.2006 12:09
-- Purpose : Пакет установки значений для общего использования коллекции и временных таблиц
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ----------------------------------------------
-- Skripnik Petr   10.11.2006  Изменен
-- Skripnik Petr   10.07.2007  version 1.11.9.0
--------------------------------------------------------------------------------
   pkg_name   CONSTANT NVARCHAR2 (50) := 'bulk_insert_management.';

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 09.11.2006 13:40
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_equipment_code (
      p_stock_id                   tmpeiid,
      p_equipment_model_id         tmpeiid,
      p_serial_number              tmpsccode,
      p_serial_number2             tmpsccode,
      p_valid_until                tmpvalid,
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   AS
      prc_name     CONSTANT NVARCHAR2 (100) := pkg_name || 'bulk_insert_tmp_equipment_code';   --имя процедуры
      vserial_number        NVARCHAR2 (50);
      vvalid_until          DATE;
      vequipment_model_id   NUMBER;
      vstock_id             NUMBER;
      vserial_number2       NVARCHAR2 (50);
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;
  
      --Очищаем коллекции
      --g_tab_stock_id := g_tab_empty_num;
      --g_tab_equipment_id := g_tab_empty_num;
      IF NOT(p_stock_id.count = 1 and p_stock_id(p_stock_id.first) is null)
      THEN
      FOR i IN p_stock_id.FIRST .. p_stock_id.LAST
      LOOP
         --Инкриментируем
         --g_tab_stock_id.EXTEND;
         --g_tab_equipment_id.EXTEND;

         --Устанавливаем значение склада
         IF NOT(p_stock_id.count = 1 and p_stock_id(p_stock_id.first) is null) and
            p_stock_id.EXISTS (i)
         THEN
            vstock_id := p_stock_id (i);
         --g_tab_stock_id (g_tab_stock_id.COUNT) := p_stock_id (i);
         ELSE
            vstock_id := NULL;
         --g_tab_stock_id (g_tab_stock_id.COUNT) := NULL;
         END IF;

         --Устанавливаем значение модели оборудования
         IF NOT(p_equipment_model_id.count = 1 and p_equipment_model_id(p_equipment_model_id.first) is null) and
         p_equipment_model_id.EXISTS (i)
         THEN
            vequipment_model_id := p_equipment_model_id (i);
         --g_tab_equipment_id (g_tab_equipment_id.COUNT) := p_equipment_model_id (i);
         ELSE
            vequipment_model_id := NULL;
         --g_tab_equipment_id (g_tab_equipment_id.COUNT) := NULL;
         END IF;

         --Устанавливаем значение серийного номера (1)
         IF NOT(p_serial_number.count = 1 and p_serial_number(p_serial_number.first) is null) and
         p_serial_number.EXISTS (i)
         THEN
            vserial_number := p_serial_number (i);
         ELSE
            vserial_number := NULL;
         END IF;

         --Устанавливаем значение серийного номера (2)
         IF NOT(p_serial_number2.count = 1 and p_serial_number2(p_serial_number2.first) is null) and
         p_serial_number2.EXISTS (i)
         THEN
            vserial_number2 := p_serial_number2 (i);
         ELSE
            vserial_number2 := NULL;
         END IF;

         --Устанавливаем значение срока годности
         IF NOT(p_valid_until.count = 1 and p_valid_until(p_valid_until.first) is null) and
         p_valid_until.EXISTS (i)
         THEN
            vvalid_until := p_valid_until (i);
         ELSE
            vvalid_until := NULL;
         END IF;

         INSERT INTO tmp_validity
                     (stock_id, equipment_model_id, serial_number, serial_number2, validity_date
                     )
              VALUES (vstock_id, vequipment_model_id, vserial_number, vserial_number2, vvalid_until
                     );
      END LOOP;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);


   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE p_handle_tran
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END bulk_insert_tmp_equipment_code;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_equipment_code (
      p_stock_id                   tmpeiid,
      p_equipment_model_id         tmpeiid,
      p_serial_number              tmpsccode,
      p_valid_until                tmpvalid,
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'bulk_insert_tmp_equipment_code';
      vserial_number        NVARCHAR2 (50);
      vvalid_until          DATE;
      vequipment_model_id   NUMBER;
      vstock_id             NUMBER;
   BEGIN
      p_error_code := 0;

      IF NOT(p_stock_id.count = 1 and p_stock_id(p_stock_id.first) is null)
      THEN
      FOR i IN p_stock_id.FIRST .. p_stock_id.LAST
      LOOP
         IF NOT(p_stock_id.count = 1 and p_stock_id(p_stock_id.first) is null) and
         p_stock_id.EXISTS (i)
         THEN
            vstock_id := p_stock_id (i);
         ELSE
            vstock_id := NULL;
         END IF;

         IF NOT(p_equipment_model_id.count = 1 and p_equipment_model_id(p_equipment_model_id.first) is null) and
         p_equipment_model_id.EXISTS (i)
         THEN
            vequipment_model_id := p_equipment_model_id (i);
         ELSE
            vequipment_model_id := NULL;
         END IF;

         IF NOT(p_serial_number.count = 1 and p_serial_number(p_serial_number.first) is null) and
         p_serial_number.EXISTS (i)
         THEN
            vserial_number := p_serial_number (i);
         ELSE
            vserial_number := NULL;
         END IF;

         IF NOT(p_valid_until.count = 1 and p_valid_until(p_valid_until.first) is null) and
         p_valid_until.EXISTS (i)
         THEN
            vvalid_until := p_valid_until (i);
         ELSE
            vvalid_until := NULL;
         END IF;

         INSERT INTO tmp_validity
                     (stock_id, equipment_model_id, serial_number, validity_date
                     )
              VALUES (vstock_id, vequipment_model_id, vserial_number, vvalid_until
                     );
      END LOOP;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);


   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END bulk_insert_tmp_equipment_code;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 09.11.2006 15:06
-- Purpose : Устанавливает коды оборудования
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_equipment_code (
      p_code                tmpeccode,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'bulk_insert_tmp_equipment_code';
      l_code              NVARCHAR2 (50);
   BEGIN
      --Устанавливаем отладчик
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Обнуляем ошибки
      p_error_code := 0;
      --Очищаем коллекцию
      g_tab_eqm_code := g_tab_empty_char;

      IF NOT(p_code.count = 1 and p_code(p_code.first) is null)
      THEN
      FOR i IN p_code.FIRST .. p_code.LAST
      LOOP
         g_tab_eqm_code.EXTEND;

         IF p_code.EXISTS (i)
         THEN
            l_code := p_code (i);
            g_tab_eqm_code (g_tab_eqm_code.COUNT) := p_code (i);
         ELSE
            l_code := NULL;
            g_tab_eqm_code (g_tab_eqm_code.COUNT) := NULL;
         END IF;

         pkg_db_util.DEBUG (prc_name, 'Insert: ' || l_code, pkg_name);

         INSERT INTO tmp_equipment_code
                     (code
                     )
              VALUES (l_code
                     );
      END LOOP;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE p_handle_tran
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END bulk_insert_tmp_equipment_code;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 09.11.2006 13:40
-- Purpose :
--
--  Процедура bulk_insert_tmp_equip_code_1 аналогична процедуре
--   PROCEDURE bulk_insert_tmp_equipment_code (
--      p_stock_id                   tmpeiid,
--      p_equipment_model_id         tmpeiid,
--      p_serial_number              tmpsccode,
--      p_serial_number2             tmpsccode,
--      p_valid_until                tmpvalid,
--      p_length                     NUMBER,
--      p_handle_tran                CHAR := 'Y',
--      p_error_code           OUT   NUMBER
--   )
--  Создана для поддержки FORIS.DataAccess     
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_equip_code_1 (
      p_stock_id                   tmpeiid,
      p_equipment_model_id         tmpeiid,
      p_serial_number              tmpsccode,
      p_serial_number2             tmpsccode,
      p_valid_until                tmpvalid,
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   AS
      prc_name     CONSTANT NVARCHAR2 (100) := pkg_name || 'bulk_insert_tmp_equipment_code_1';   --имя процедуры
      vserial_number        NVARCHAR2 (50);
      vvalid_until          DATE;
      vequipment_model_id   NUMBER;
      vstock_id             NUMBER;
      vserial_number2       NVARCHAR2 (50);
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      --Очищаем коллекции
      --g_tab_stock_id := g_tab_empty_num;
      --g_tab_equipment_id := g_tab_empty_num;
      IF NOT(p_stock_id.count = 1 and p_stock_id(p_stock_id.first) is null)
      THEN
      FOR i IN p_stock_id.FIRST .. p_stock_id.LAST
      LOOP
         --Инкриментируем
         --g_tab_stock_id.EXTEND;
         --g_tab_equipment_id.EXTEND;

         --Устанавливаем значение склада
         IF NOT(p_stock_id.count = 1 and p_stock_id(p_stock_id.first) is null) and
            p_stock_id.EXISTS (i)
         THEN
            vstock_id := p_stock_id (i);
         --g_tab_stock_id (g_tab_stock_id.COUNT) := p_stock_id (i);
         ELSE
            vstock_id := NULL;
         --g_tab_stock_id (g_tab_stock_id.COUNT) := NULL;
         END IF;

         --Устанавливаем значение модели оборудования
         IF NOT(p_equipment_model_id.count = 1 and p_equipment_model_id(p_equipment_model_id.first) is null) and
            p_equipment_model_id.EXISTS (i)
         THEN
            vequipment_model_id := p_equipment_model_id (i);
         --g_tab_equipment_id (g_tab_equipment_id.COUNT) := p_equipment_model_id (i);
         ELSE
            vequipment_model_id := NULL;
         --g_tab_equipment_id (g_tab_equipment_id.COUNT) := NULL;
         END IF;

         --Устанавливаем значение серийного номера (1)
         IF NOT(p_serial_number.count = 1 and p_serial_number(p_serial_number.first) is null) and
            p_serial_number.EXISTS (i)
         THEN
            vserial_number := p_serial_number (i);
         ELSE
            vserial_number := NULL;
         END IF;

         --Устанавливаем значение серийного номера (2)
         IF NOT(p_serial_number2.count = 1 and p_serial_number2(p_serial_number2.first) is null) and
            p_serial_number2.EXISTS (i)
         THEN
            vserial_number2 := p_serial_number2 (i);
         ELSE
            vserial_number2 := NULL;
         END IF;

         --Устанавливаем значение срока годности
         IF NOT(p_valid_until.count = 1 and p_valid_until(p_valid_until.first) is null) and
            p_valid_until.EXISTS (i)
         THEN
            vvalid_until := p_valid_until (i);
         ELSE
            vvalid_until := NULL;
         END IF;

         INSERT INTO tmp_validity
                     (stock_id, equipment_model_id, serial_number, serial_number2, validity_date
                     )
              VALUES (vstock_id, vequipment_model_id, vserial_number, vserial_number2, vvalid_until
                     );
      END LOOP;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE p_handle_tran
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END bulk_insert_tmp_equip_code_1;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 09.11.2006 15:06
-- Purpose : Устанавливает коды оборудования
--
--  Процедура bulk_insert_tmp_equip_code_3 аналогична процедуре
--   PROCEDURE bulk_insert_tmp_equipment_code (
--      p_code                tmpeccode,
--      p_length              NUMBER,
--      p_handle_tran         CHAR := 'Y',
--      p_error_code    OUT   NUMBER
--   )
--  Создана для поддержки FORIS.DataAccess    
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_equip_code_3 (
      p_code                tmpeccode,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'bulk_insert_tmp_equipment_code_3';
      l_code              NVARCHAR2 (50);
   BEGIN
      --Устанавливаем отладчик
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Обнуляем ошибки
      p_error_code := 0;
      --Очищаем коллекцию
      g_tab_eqm_code := g_tab_empty_char;

      IF NOT(p_code.count = 1 and p_code(p_code.first) is null)
      THEN
      FOR i IN p_code.FIRST .. p_code.LAST
      LOOP
         g_tab_eqm_code.EXTEND;

         IF p_code.EXISTS (i)
         THEN
            l_code := p_code (i);
            g_tab_eqm_code (g_tab_eqm_code.COUNT) := p_code (i);
         ELSE
            l_code := NULL;
            g_tab_eqm_code (g_tab_eqm_code.COUNT) := NULL;
         END IF;

         pkg_db_util.DEBUG (prc_name, 'Insert: ' || l_code, pkg_name);

         INSERT INTO tmp_equipment_code
                     (code
                     )
              VALUES (l_code
                     );
      END LOOP;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE p_handle_tran
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END bulk_insert_tmp_equip_code_3;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 18.10.2006 18:13
-- Purpose : Устанавливает идентификаторы оборудования
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_equipment_id (
      p_id                  tmpeiid,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100)  := pkg_name || 'bulk_insert_tmp_equipment_id';
      l_id                NUMBER;
      l_tab               pkg_common.t_num;
   BEGIN
      --устанавливаем отладчик
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --обнуляем ошибки
      p_error_code := 0;

      IF NOT(p_id.count = 1 and p_id(p_id.first) is null)
      THEN
      IF p_id.EXISTS (1)
      THEN
         FOR i IN p_id.FIRST .. p_id.LAST
         LOOP
            IF p_id.EXISTS (i)
            THEN
               l_id := p_id (i);
            ELSE
               l_id := NULL;
            END IF;

            INSERT INTO tmp_equipment_id
                        (ID
                        )
                 VALUES (l_id
                        );
         END LOOP;

         SELECT ID
         BULK COLLECT INTO l_tab
           FROM tmp_equipment_id;
      END IF;
      END IF;

      pkg_db_util.DEBUG (prc_name, 'Count: ' || l_tab.LAST, pkg_name);
      pkg_equipment.set_modelid (p_model_id_1 => l_tab);

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE p_handle_tran
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;

         RAISE;
   END bulk_insert_tmp_equipment_id;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 18.10.2006 15:48, 09.11.2006 15:12
-- Purpose : Устанавливает коды складов
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_stock_code (
      p_code                tmpsccode,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'bulk_insert_tmp_stock_code';
      l_code              NVARCHAR2 (50);
   BEGIN
      --Устанавливаем отладчик
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Обнуляем ошибки
      p_error_code := 0;
      --Очищаем коллекцию
      g_tab_stock_code := g_tab_empty_char;

      IF NOT(p_code.count = 1 and p_code(p_code.first) is null)
      THEN
      FOR i IN p_code.FIRST .. p_code.LAST
      LOOP
         g_tab_stock_code.EXTEND;

         IF p_code.EXISTS (i)
         THEN
            l_code := p_code (i);
            g_tab_stock_code (g_tab_stock_code.COUNT) := p_code (i);
         ELSE
            l_code := NULL;
            g_tab_stock_code (g_tab_stock_code.COUNT) := NULL;
         END IF;

         pkg_db_util.DEBUG (prc_name, 'Insert: ' || l_code, pkg_name);

         MERGE  INTO tmp_stock_code t1
            USING (SELECT l_code as code FROM DUAL) t2
            ON (t2.code = t1.code)
            WHEN NOT MATCHED THEN INSERT (code) VALUES (l_code);

      END LOOP;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE p_handle_tran
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END bulk_insert_tmp_stock_code;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 12.10.2006 14:48
-- Purpose : Устанавливает идентификаторы складов
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_stock_id (
      p_id                  tmpsidid,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100)  := pkg_name || 'bulk_insert_tmp_stock_id';
      l_id                NUMBER;
      l_tab               pkg_common.t_num;
   BEGIN
      --Устанавливаем отладчик
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Обнуляем ошибки
      p_error_code := 0;

      IF NOT(p_id.count = 1 and p_id(p_id.first) is null)
      THEN
      IF p_id.EXISTS (1)
      THEN
         FOR i IN p_id.FIRST .. p_id.LAST
         LOOP
            IF p_id.EXISTS (i)
            THEN
               l_id := p_id (i);
            ELSE
               l_id := NULL;
            END IF;

            INSERT INTO tmp_stock_id
                        (ID
                        )
                 VALUES (l_id
                        );
         END LOOP;

         SELECT ID
         BULK COLLECT INTO l_tab
           FROM tmp_stock_id;
      END IF;
      END IF;

      pkg_db_util.DEBUG (prc_name, 'Count: ' || l_tab.LAST, pkg_name);
      pkg_stock.set_stockid (p_stock_id            => l_tab,
                             p_flag_clear          => 'Y',
                             p_stock_id_out        => l_tab,
                             p_flag_clear_out      => 'Y'
                            );

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE p_handle_tran
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;

         RAISE;
   END bulk_insert_tmp_stock_id;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_stock_owner (
      p_name                tmpsoname,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   AS
      vname   NVARCHAR2 (50);
   BEGIN
      pkg_db_util.DEBUG (pkg_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      IF NOT(p_name.count = 1 and p_name(p_name.first) is null)
      THEN
      FOR i IN p_name.FIRST .. p_name.LAST
      LOOP
         IF p_name.EXISTS (i)
         THEN
            vname := p_name (i);
         ELSE
            vname := NULL;
         END IF;

         INSERT INTO tmp_stock_owner
                     (NAME
                     )
              VALUES (vname
                     );
      END LOOP;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (pkg_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := SQLCODE;
         END CASE;

         CASE p_handle_tran
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END bulk_insert_tmp_stock_owner;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_stock_owner2 (
      p_name                tmpsoname2,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   AS
      vname   NVARCHAR2 (50);
   BEGIN
      p_error_code := 0;

      IF NOT(p_name.count = 1 and p_name(p_name.first) is null)
      THEN
      FOR i IN p_name.FIRST .. p_name.LAST
      LOOP
         IF p_name.EXISTS (i)
         THEN
            vname := p_name (i);
         ELSE
            vname := NULL;
         END IF;

         INSERT INTO tmp_stock_owner2
                     (NAME
                     )
              VALUES (vname
                     );
      END LOOP;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END bulk_insert_tmp_stock_owner2;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 09.11.2006 15:40
-- Purpose : Устанавливает типы складов
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_stock_type (
      p_id                  tmpstid,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'bulk_insert_tmp_stock_type';
      l_id                NUMBER;
   BEGIN
      --Устанавливаем отладчик
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Обнуляем ошибки
      p_error_code := 0;
      --Очищаем коллекцию
      g_tab_stock_type_id := g_tab_empty_num;

      IF NOT(p_id.count = 1 and p_id(p_id.first) is null)
      THEN
      FOR i IN p_id.FIRST .. p_id.LAST
      LOOP
         g_tab_stock_type_id.EXTEND;

         IF p_id.EXISTS (i)
         THEN
            l_id := p_id (i);
            g_tab_stock_type_id (g_tab_stock_type_id.COUNT) := p_id (i);
         ELSE
            l_id := NULL;
            g_tab_stock_type_id (g_tab_stock_type_id.COUNT) := NULL;
         END IF;

         pkg_db_util.DEBUG (prc_name, 'Insert: ' || l_id, pkg_name);

         INSERT INTO tmp_stock_type
                     (ID
                     )
              VALUES (l_id
                     );
      END LOOP;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE p_handle_tran
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END bulk_insert_tmp_stock_type;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 09.11.2006 15:40
-- Purpose : Устанавливает типы складов
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_stock_type2 (
      p_id                  tmpstid2,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'bulk_insert_tmp_stock_type2';
      l_id                NUMBER;
   BEGIN
      --Устанавливаем отладчик
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Обнуляем ошибки
      p_error_code := 0;
      --Очищаем коллекцию
      g_tab_stock_type_id2 := g_tab_empty_num;

      IF NOT(p_id.count = 1 and p_id(p_id.first) is null)
      THEN
      FOR i IN p_id.FIRST .. p_id.LAST
      LOOP
         g_tab_stock_type_id2.EXTEND;

         IF p_id.EXISTS (i)
         THEN
            l_id := p_id (i);
            g_tab_stock_type_id2 (g_tab_stock_type_id2.COUNT) := p_id (i);
         ELSE
            l_id := NULL;
            g_tab_stock_type_id2 (g_tab_stock_type_id2.COUNT) := NULL;
         END IF;

         pkg_db_util.DEBUG (prc_name, 'Insert: ' || l_id, pkg_name);

         INSERT INTO tmp_stock_type2
                     (ID
                     )
              VALUES (l_id
                     );
      END LOOP;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE p_handle_tran
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END bulk_insert_tmp_stock_type2;

END;
/
