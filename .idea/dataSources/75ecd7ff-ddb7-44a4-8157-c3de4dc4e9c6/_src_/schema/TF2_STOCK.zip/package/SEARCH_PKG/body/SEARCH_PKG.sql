CREATE package body search_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure seek_eq_ii
(
    p_seria_start     ct_nvarchar_s,
    p_seria_end       ct_nvarchar_s,
    p_qty             ct_number,
    p_status          ct_number,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
)
is
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_start, 'p_seria_start');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_end, 'p_seria_end');
  util_pkg.XCheckP_ct_number(p_qty, 'p_qty');
  util_pkg.XCheckP_ct_number(p_status, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_count is null, 'p_count');
  ------------------------------
  v_main_count := p_seria_start.count;
  util_pkg.XCheck_Cond_Invalid(p_seria_start.count != v_main_count, 'p_seria_start.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_seria_end.count != v_main_count, 'p_seria_end.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_qty.count != v_main_count, 'p_qty.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_status.count != v_main_count, 'p_status.count != v_main_count');
  ------------------------------
select /*+ ordered use_hash(q, st, em) use_nl(ss) index_asc(ss, I_STOCK_STATE_SS)*/
    ss.id,
    st.stock_id,
    em.equipment_model_id
  bulk collect into
    p_ss_id,
    p_stock_id2,
    p_eq_model_id2
  from
    (

select /*+ ordered use_hash(s1, s2, qt, sa)*/
  s1.rn,
  s1.seria_start,
  s2.seria_end,
  qt.quantity,
  sa.status
  from
    (select column_value seria_start, rownum rn from table(p_seria_start)) s1,
    (select column_value seria_end, rownum rn from table(p_seria_end)) s2,
    (select column_value quantity, rownum rn from table(p_qty)) qt,
    (select column_value status, rownum rn from table(p_status)) sa
  where 1 = 1
  and s2.rn(+) = s1.rn
  and qt.rn(+) = s1.rn
  and sa.rn(+) = s1.rn

    ) q,
    stock_state ss,
    (select column_value stock_id from table(p_stock_id)) st,
    (select column_value equipment_model_id from table(p_eq_model_id)) em
  where 1 = 1
  and ss.seria_start(+) = q.seria_start
  and ss.seria_end(+) = q.seria_end
  and ss.quantity_onstock(+) = q.quantity
  and ss.status(+) = q.status
  and st.stock_id(+) = ss.stock_id
  and em.equipment_model_id(+) = ss.equipment_model_id
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(ss.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(st.stock_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(em.equipment_model_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and rownum <= decode(p_count, util_stock.c_any_count, rownum, p_count)
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure seek_single_eq_ii
(
    p_serial_number   ct_nvarchar_s,
    p_status          ct_number,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
)
is
  v_main_count number;
  v_qty ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_nvarchar_s(p_serial_number, 'p_serial_number');
  util_pkg.XCheckP_ct_number(p_status, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_count is null, 'p_count');
  ------------------------------
  v_main_count := p_serial_number.count;
  util_pkg.XCheck_Cond_Invalid(p_serial_number.count != v_main_count, 'p_serial_number.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_status.count != v_main_count, 'p_status.count != v_main_count');
  ------------------------------
  util_pkg.resize_ct_number(v_qty, v_main_count);
  util_pkg.fill_ct_number(v_qty, equipment_pkg.c_eq_qty_one_item);
  ------------------------------
  seek_eq_ii
  (
    p_seria_start => p_serial_number,
    p_seria_end => p_serial_number,
    p_qty => v_qty,
    p_status => p_status,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_trim_empty => p_trim_empty,
    p_ss_id => p_ss_id,
    p_stock_id2 => p_stock_id2,
    p_eq_model_id2 => p_eq_model_id2
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_single_eq_ii
(
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_status          number,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
)
is
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_main_count number;
  v_range ct_range;
begin
  ------------------------------
  util_pkg.XCheckP_ct_nvarchar_s(p_serial_number1, 'p_serial_number1');
  util_pkg.XCheckP_ct_nvarchar_s(p_serial_number2, 'p_serial_number2');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_count is null, 'p_count');
  ------------------------------
  v_main_count := p_serial_number1.count;
  util_pkg.XCheck_Cond_Invalid(p_serial_number1.count != v_main_count, 'p_serial_number1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_serial_number2.count != v_main_count, 'p_serial_number2.count != v_main_count');
  ------------------------------
  v_range := util_stock.make_ct_range1
  (
    p_val1 => p_serial_number1,
    p_val2 => p_serial_number2
  );
  ------------------------------
select /*+ ordered use_nl(ss) use_hash(st, em) index_asc(ss, I_STOCK_STATE_SS)*/
    distinct
    ss.id,
    ss.seria_start,
    st.stock_id,
    em.equipment_model_id
  bulk collect into
    p_ss_id,
    p_ss_serial_number,
    p_stock_id2,
    p_eq_model_id2
  from
    (select val1 serial_number1, val2 serial_number2 from table(v_range)) q,
    stock_state ss,
    (select column_value stock_id from table(p_stock_id)) st,
    (select column_value equipment_model_id from table(p_eq_model_id)) em
  where 1 = 1
  and ss.seria_start between q.serial_number1 and q.serial_number2
  and ss.seria_end = ss.seria_start
  and ss.quantity_onstock = equipment_pkg.c_eq_qty_one_item
  and ss.status = p_status
  and st.stock_id(+) = ss.stock_id
  and em.equipment_model_id(+) = ss.equipment_model_id
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(st.stock_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(em.equipment_model_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and rownum <= decode(p_count, util_stock.c_any_count, rownum, p_count)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_single_eq_stock_ii
(
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_status          number,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
)
is
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_main_count number;
  v_range ct_range;
begin
  ------------------------------
  util_pkg.XCheckP_ct_nvarchar_s(p_serial_number1, 'p_serial_number1');
  util_pkg.XCheckP_ct_nvarchar_s(p_serial_number2, 'p_serial_number2');
  util_pkg.XCheck_Cond_Missing(p_status is null, 'p_status');
  util_pkg.XCheck_Cond_Missing(p_count is null, 'p_count');
  ------------------------------
  v_main_count := p_serial_number1.count;
  util_pkg.XCheck_Cond_Invalid(p_serial_number1.count != v_main_count, 'p_serial_number1.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_serial_number2.count != v_main_count, 'p_serial_number2.count != v_main_count');
  ------------------------------
  v_range := util_stock.make_ct_range1
  (
    p_val1 => p_serial_number1,
    p_val2 => p_serial_number2
  );
  ------------------------------
select /*+ ordered use_nl(ss) use_merge(q) use_hash(em) index_asc(ss, I_STOCK_STATE_STOCK_ID)*/
    distinct
    ss.id,
    ss.seria_start,
    st.stock_id,
    em.equipment_model_id
  bulk collect into
    p_ss_id,
    p_ss_serial_number,
    p_stock_id2,
    p_eq_model_id2
  from
    (select column_value stock_id from table(p_stock_id)) st,
    stock_state ss,
    (select val1 serial_number1, val2 serial_number2 from table(v_range)) q,
    (select column_value equipment_model_id from table(p_eq_model_id)) em
  where 1 = 1
  and ss.stock_id = st.stock_id
  and ss.seria_end = ss.seria_start
  and ss.quantity_onstock = equipment_pkg.c_eq_qty_one_item
  and ss.status = p_status
  and ss.seria_start between q.serial_number1 and q.serial_number2
  and em.equipment_model_id(+) = ss.equipment_model_id
  --!_!and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(st.stock_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(em.equipment_model_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and rownum <= decode(p_count, util_stock.c_any_count, rownum, p_count)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure seek_active_single_eq_ii
(
    p_serial_number   ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
)
is
  v_main_count number;
  v_status ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_ct_nvarchar_s(p_serial_number, 'p_serial_number');
  util_pkg.XCheck_Cond_Missing(p_count is null, 'p_count');
  ------------------------------
  v_main_count := p_serial_number.count;
  util_pkg.resize_ct_number(v_status, v_main_count);
  util_pkg.fill_ct_number(v_status, equipment_pkg.c_eq_status_active);
  ------------------------------
  seek_single_eq_ii
  (
    p_serial_number => p_serial_number,
    p_status => v_status,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_trim_empty => p_trim_empty,
    p_ss_id => p_ss_id,
    p_stock_id2 => p_stock_id2,
    p_eq_model_id2 => p_eq_model_id2
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_active_single_eq_ii
(
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
)
is
begin
  ------------------------------
  util_pkg.XCheckP_ct_nvarchar_s(p_serial_number1, 'p_serial_number1');
  util_pkg.XCheckP_ct_nvarchar_s(p_serial_number2, 'p_serial_number2');
  util_pkg.XCheck_Cond_Missing(p_count is null, 'p_count');
  ------------------------------
  find_single_eq_ii
  (
    p_serial_number1 => p_serial_number1,
    p_serial_number2 => p_serial_number2,
    p_status => equipment_pkg.c_eq_status_active,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_trim_empty => p_trim_empty,
    p_ss_id => p_ss_id,
    p_ss_serial_number => p_ss_serial_number,
    p_stock_id2 => p_stock_id2,
    p_eq_model_id2 => p_eq_model_id2
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_active_single_eq_stock_ii
(
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
)
is
begin
  ------------------------------
  util_pkg.XCheckP_ct_nvarchar_s(p_serial_number1, 'p_serial_number1');
  util_pkg.XCheckP_ct_nvarchar_s(p_serial_number2, 'p_serial_number2');
  util_pkg.XCheck_Cond_Missing(p_count is null, 'p_count');
  ------------------------------
  find_single_eq_stock_ii
  (
    p_serial_number1 => p_serial_number1,
    p_serial_number2 => p_serial_number2,
    p_status => equipment_pkg.c_eq_status_active,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_trim_empty => p_trim_empty,
    p_ss_id => p_ss_id,
    p_ss_serial_number => p_ss_serial_number,
    p_stock_id2 => p_stock_id2,
    p_eq_model_id2 => p_eq_model_id2
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure seek_active_single_eq_i
(
    p_serial_number   ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number
)
is
  v_stock_id2 ct_number;
  v_eq_model_id2 ct_number;
begin
  ------------------------------
  seek_active_single_eq_ii
  (
    p_serial_number => p_serial_number,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_trim_empty => p_trim_empty,
    p_ss_id => p_ss_id,
    p_stock_id2 => v_stock_id2,
    p_eq_model_id2 => v_eq_model_id2
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure seek_active_single_eq2_i
(
    p_serial_number   ct_nvarchar_s,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_stock_id        out ct_number,
    p_eq_model_id     out ct_number
)
is
  v_date date := sysdate;
  v_stock_id ct_number;
  v_eq_model_id ct_number;
  v_count number;
begin
  ------------------------------
  v_count := util_pkg.get_count_ct_nvarchar_s(p_serial_number);
  v_stock_id := util_stock.get_stock_ids_all(v_date);
  v_eq_model_id := util_stock.get_equipment_model_ids_all(v_date);
  ------------------------------
  seek_active_single_eq_ii
  (
    p_serial_number => p_serial_number,
    p_stock_id => v_stock_id,
    p_eq_model_id => v_eq_model_id,
    p_count => v_count,
    p_trim_empty => p_trim_empty,
    p_ss_id => p_ss_id,
    p_stock_id2 => p_stock_id,
    p_eq_model_id2 => p_eq_model_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_active_single_eq_i
(
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s
)
is
  v_stock_id2 ct_number;
  v_eq_model_id2 ct_number;
begin
  ------------------------------
  find_active_single_eq_ii
  (
    p_serial_number1 => p_serial_number1,
    p_serial_number2 => p_serial_number2,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_trim_empty => p_trim_empty,
    p_ss_id => p_ss_id,
    p_ss_serial_number => p_ss_serial_number,
    p_stock_id2 => v_stock_id2,
    p_eq_model_id2 => v_eq_model_id2
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_active_single_eq_stock_i
(
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s
)
is
  v_stock_id2 ct_number;
  v_eq_model_id2 ct_number;
begin
  ------------------------------
  find_active_single_eq_stock_ii
  (
    p_serial_number1 => p_serial_number1,
    p_serial_number2 => p_serial_number2,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_trim_empty => p_trim_empty,
    p_ss_id => p_ss_id,
    p_ss_serial_number => p_ss_serial_number,
    p_stock_id2 => v_stock_id2,
    p_eq_model_id2 => v_eq_model_id2
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure seek_active_single_eq
(
    p_serial_number   ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number
)
is
begin
  ------------------------------
  seek_active_single_eq_i
  (
    p_serial_number => p_serial_number,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_trim_empty => TRUE,
    p_ss_id => p_ss_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure seek_active_single_eq2
(
    p_serial_number   ct_nvarchar_s,
    p_ss_id           out ct_number,
    p_stock_id        out ct_number,
    p_eq_model_id     out ct_number
)
is
begin
  ------------------------------
  seek_active_single_eq2_i
  (
    p_serial_number => p_serial_number,
    p_trim_empty => FALSE,
    p_ss_id => p_ss_id,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_active_single_eq
(
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s
)
is
begin
  ------------------------------
  find_active_single_eq_i
  (
    p_serial_number1 => p_serial_number1,
    p_serial_number2 => p_serial_number2,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_trim_empty => TRUE,
    p_ss_id => p_ss_id,
    p_ss_serial_number => p_ss_serial_number
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_active_single_eq_stock
(
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s
)
is
begin
  ------------------------------
  find_active_single_eq_stock_i
  (
    p_serial_number1 => p_serial_number1,
    p_serial_number2 => p_serial_number2,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_trim_empty => TRUE,
    p_ss_id => p_ss_id,
    p_ss_serial_number => p_ss_serial_number
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_1_active_single_eq
(
    p_serial_number1  nvarchar2,
    p_serial_number2  nvarchar2,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s
)
is
  v_serial_number1 ct_nvarchar_s;
  v_serial_number2 ct_nvarchar_s;
begin
  ------------------------------
  util_pkg.add_ct_nvarchar_s_val(v_serial_number1, p_serial_number1);
  util_pkg.add_ct_nvarchar_s_val(v_serial_number2, p_serial_number2);
  ------------------------------
  find_active_single_eq_i
  (
    p_serial_number1 => v_serial_number1,
    p_serial_number2 => v_serial_number2,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_trim_empty => TRUE,
    p_ss_id => p_ss_id,
    p_ss_serial_number => p_ss_serial_number
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_1_active_single_eq_stock
(
    p_serial_number1  nvarchar2,
    p_serial_number2  nvarchar2,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s
)
is
  v_serial_number1 ct_nvarchar_s;
  v_serial_number2 ct_nvarchar_s;
begin
  ------------------------------
  util_pkg.add_ct_nvarchar_s_val(v_serial_number1, p_serial_number1);
  util_pkg.add_ct_nvarchar_s_val(v_serial_number2, p_serial_number2);
  ------------------------------
  find_active_single_eq_stock_i
  (
    p_serial_number1 => v_serial_number1,
    p_serial_number2 => v_serial_number2,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_trim_empty => TRUE,
    p_ss_id => p_ss_id,
    p_ss_serial_number => p_ss_serial_number
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_active_single_eq2
(
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number
)
is
  v_ss_serial_number ct_nvarchar_s;
begin
  ------------------------------
  find_active_single_eq
  (
    p_serial_number1 => p_serial_number1,
    p_serial_number2 => p_serial_number2,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_ss_id => p_ss_id,
    p_ss_serial_number => v_ss_serial_number
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_active_single_eq2_stock
(
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number
)
is
  v_ss_serial_number ct_nvarchar_s;
begin
  ------------------------------
  find_active_single_eq_stock
  (
    p_serial_number1 => p_serial_number1,
    p_serial_number2 => p_serial_number2,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_ss_id => p_ss_id,
    p_ss_serial_number => v_ss_serial_number
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_1_active_single_eq2
(
    p_serial_number1  nvarchar2,
    p_serial_number2  nvarchar2,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number
)
is
  v_ss_serial_number ct_nvarchar_s;
begin
  ------------------------------
  find_1_active_single_eq
  (
    p_serial_number1 => p_serial_number1,
    p_serial_number2 => p_serial_number2,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_ss_id => p_ss_id,
    p_ss_serial_number => v_ss_serial_number
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_1_active_single_eq2_stock
(
    p_serial_number1  nvarchar2,
    p_serial_number2  nvarchar2,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number
)
is
  v_ss_serial_number ct_nvarchar_s;
begin
  ------------------------------
  find_1_active_single_eq_stock
  (
    p_serial_number1 => p_serial_number1,
    p_serial_number2 => p_serial_number2,
    p_stock_id => p_stock_id,
    p_eq_model_id => p_eq_model_id,
    p_count => p_count,
    p_ss_id => p_ss_id,
    p_ss_serial_number => v_ss_serial_number
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_result_cursor01
(
    p_ss_id ct_number,
    p_date date,
    p_count number,
    p_trim_empty boolean,
    p_result out sys_refcursor
)
is
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_count is null, 'p_count');
  ------------------------------
  open p_result for
select * from (

select /*+ driving_site(q0) ordered use_nl(q0, ss) use_hash(s, em)
  index_asc(ss, PK_STOCK_STATE)
  full(s)
  full(em)
  */
  ss.equipment_model_id "Equipment_model_ID",
  em.equipment_model_code "Equipment_model_code",
  ss.seria_start "Seria_number",
  ss.stock_id "Stock_ID",
  s.code "Stock_Code",
  s.name "Stock_Name"
  from
    (select column_value id, rownum rn from table(p_ss_id)) q0,
    stock_state ss,
    stock s,
    equipment_model em
  where 1 = 1
  and ss.id(+) = q0.id
  and s.id(+) = ss.stock_id
  and em.equipment_model_id(+) = ss.equipment_model_id
  and nvl(s.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  and nvl(em.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(ss.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(s.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(em.equipment_model_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  --!_!order by q0.rn
  order by s.code, ss.seria_start, q0.rn

  )
  where 1 = 1
  and rownum <= decode(p_count, util_stock.c_any_count, rownum, p_count)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor02
(
    p_ss_id ct_number,
    p_msisdn ct_varchar_s,
    p_linked boolean,
    p_date date,
    p_count number,
    p_trim_empty boolean,
    p_result out sys_refcursor
)
is
  v_linked number := util_pkg.bool_to_int_3val(p_linked);
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_count is null, 'p_count');
  ------------------------------
  open p_result for
select * from (

select /*+ driving_site(q0) ordered use_nl(ss, sm) use_hash(q1, s, em)
  index_asc(ss, PK_STOCK_STATE)
  index_asc(sm, AK_SIMS_SN)
  full(s)
  full(em)
  */
  sm.id "Equipment_ID",
  sm.full_number "ICCID",
  q1.msisdn "Phone_number",
  em.equipment_model_code "Equipment_Code",
  s.code "Stock_Code",
  s.name "Stock_Name"
  from
    (select column_value id, rownum rn from table(p_ss_id)) q0,
    (select column_value msisdn, rownum rn from table(p_msisdn)) q1,
    stock_state ss,
    sims sm,
    stock s,
    equipment_model em
  where 1 = 1
  and q1.rn(+) = q0.rn
  and ss.id(+) = q0.id
  and sm.serial_number(+) = ss.seria_start
  and s.id(+) = ss.stock_id
  and em.equipment_model_id(+) = ss.equipment_model_id
  and nvl(s.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  and nvl(em.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  and decode(v_linked,
    util_pkg.c_false, decode(q1.msisdn, null, util_pkg.c_true, util_pkg.c_false),
    util_pkg.c_true, decode(q1.msisdn, null, util_pkg.c_false, util_pkg.c_true),
    util_pkg.c_true
  ) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(ss.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(sm.serial_number, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(s.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(em.equipment_model_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  --!_!order by q0.rn
  order by s.code, sm.full_number, q0.rn

  )
  where 1 = 1
  and rownum <= decode(p_count, util_stock.c_any_count, rownum, p_count)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor03
(
    p_ss_id ct_number,
    p_msisdn ct_varchar_s,
    p_model ct_model,
    p_linked boolean,
    p_date date,
    p_trim_empty boolean,
    p_result out sys_refcursor
)
is
  v_linked number := util_pkg.bool_to_int_3val(p_linked);
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ driving_site(q0) ordered use_nl(ss, sm) use_hash(q1, s, md)
  index_asc(ss, PK_STOCK_STATE)
  index_asc(sm, AK_SIMS_SN)
  full(s)
  */
  md.type_code equipment_type_code,
  md.id equipment_model_id,
  md.code equipment_model_code,
  sm.serial_number,
  sm.full_number iccid,
  sm.control_number,
  q1.msisdn phone_number,
  s.code stock_code,
  s.name stock_name
  from
    (select column_value id, rownum rn from table(p_ss_id)) q0,
    (select column_value msisdn, rownum rn from table(p_msisdn)) q1,
    stock_state ss,
    sims sm,
    stock s,
    (select * from table(p_model)) md
  where 1 = 1
  and q1.rn(+) = q0.rn
  and ss.id(+) = q0.id
  and sm.serial_number(+) = ss.seria_start
  and s.id(+) = ss.stock_id
  and md.id(+) = ss.equipment_model_id
  and nvl(s.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  --!_!and nvl(md.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  and decode(v_linked,
    util_pkg.c_false, decode(q1.msisdn, null, util_pkg.c_true, util_pkg.c_false),
    util_pkg.c_true, decode(q1.msisdn, null, util_pkg.c_false, util_pkg.c_true),
    util_pkg.c_true
  ) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(ss.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(sm.serial_number, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(s.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(md.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  --!_!order by q0.rn
  order by s.code, sm.full_number, q0.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor07
(
    p_serial_number ct_nvarchar_s,
    p_ss_id ct_number,
    p_ss_stock_id ct_number,
    p_ss_model_id ct_number,
    p_model ct_model,
    p_date date,
    p_result out sys_refcursor
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select
  serial_number,
  decode(error_code, util_loc_pkg.c_ora_equipment_not_found, null, full_number) full_number,
  decode(error_code, util_loc_pkg.c_ora_equipment_not_found, null, stock_code) stock_code,
  decode(error_code, util_loc_pkg.c_ora_equipment_not_found, null, equipment_model_code) equipment_model_code
  from (

select /*+ driving_site(q0) ordered use_nl(ss, sm) use_hash(q0, q1, q2, q3, md, s)
  index_asc(ss, PK_STOCK_STATE)
  index_asc(sm, AK_SIMS_SN)
  full(s)
  */
  q0.serial_number,
  sm.full_number,
  s.code stock_code,
  md.code equipment_model_code,
  get_search_result_code02(q1.ss_id, q2.ss_stock_id, q3.ss_model_id, sm.id, p_date) error_code
  from
    (select column_value serial_number, rownum rn from table(p_serial_number)) q0,
    (select column_value ss_id, rownum rn from table(p_ss_id)) q1,
    (select column_value ss_stock_id, rownum rn from table(p_ss_stock_id)) q2,
    (select column_value ss_model_id, rownum rn from table(p_ss_model_id)) q3,
    stock_state ss,
    sims sm,
    (select * from table(p_model)) md,
    stock s
  where 1 = 1
  and q1.rn(+) = q0.rn
  and q2.rn(+) = q0.rn
  and q3.rn(+) = q0.rn
  and ss.id(+) = q1.ss_id
  and sm.serial_number(+) = ss.seria_start
  and md.id(+) = ss.equipment_model_id
  and s.id(+) = ss.stock_id
  --
  and nvl(s.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  --
  --!_!order by q0.rn
  order by s.code, sm.full_number, q0.rn

  )
  where 1 = 1
  and error_code = util_pkg.c_ora_ok
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor08
(
    p_serial_number ct_nvarchar_s,
    p_ss_id ct_number,
    p_ss_stock_id ct_number,
    p_ss_model_id ct_number,
    p_model ct_model,
    p_date date,
    p_result out sys_refcursor
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select
  serial_number,
  error_code,
  get_search_result_msg02(error_code) error_message
  from (

select /*+ driving_site(q0) ordered use_nl(ss, sm) use_hash(q0, q1, q2, q3, md, s)
  index_asc(ss, PK_STOCK_STATE)
  index_asc(sm, AK_SIMS_SN)
  full(s)
  */
  q0.serial_number,
  sm.full_number,
  s.code stock_code,
  md.code equipment_model_code,
  get_search_result_code02(q1.ss_id, q2.ss_stock_id, q3.ss_model_id, sm.id, p_date) error_code
  from
    (select column_value serial_number, rownum rn from table(p_serial_number)) q0,
    (select column_value ss_id, rownum rn from table(p_ss_id)) q1,
    (select column_value ss_stock_id, rownum rn from table(p_ss_stock_id)) q2,
    (select column_value ss_model_id, rownum rn from table(p_ss_model_id)) q3,
    stock_state ss,
    sims sm,
    (select * from table(p_model)) md,
    stock s
  where 1 = 1
  and q1.rn(+) = q0.rn
  and q2.rn(+) = q0.rn
  and q3.rn(+) = q0.rn
  and ss.id(+) = q1.ss_id
  and sm.serial_number(+) = ss.seria_start
  and md.id(+) = ss.equipment_model_id
  and s.id(+) = ss.stock_id
  --
  and nvl(s.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  --
  --!_!order by q0.rn
  order by s.code, sm.full_number, q0.rn

  )
  where 1 = 1
  and error_code != util_pkg.c_ora_ok
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_search_result_code02(p_ss_id number, p_ss_stock_id number, p_ss_model_id number, p_sm_id number, p_date date) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  if (1 = 0
    or p_ss_id is null
    or p_ss_model_id is null
    or p_sm_id is null
  )
  then
    return util_loc_pkg.c_ora_equipment_not_found;
  end if;
  ------------------------------
  if p_ss_stock_id is null
  then
    --!_!return util_loc_pkg.c_ora_access_denied_to_stock;
    return util_loc_pkg.c_ora_eq_not_exist_on_stock;
  end if;
  ------------------------------
  return util_pkg.c_ora_ok;
  ------------------------------
end;
----------------------------------!---------------------------------------------
function get_search_result_msg02(p_result_code number) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_result_code is null, 'p_result_code');
  ------------------------------
  if p_result_code = util_loc_pkg.c_ora_equipment_not_found
  then
    v_res := util_loc_pkg.c_msg_equipment_not_found;
  elsif p_result_code = util_loc_pkg.c_ora_access_denied_to_stock
  then
    v_res := util_loc_pkg.c_msg_access_denied_to_stock;
  elsif p_result_code = util_loc_pkg.c_ora_eq_not_exist_on_stock
  then
    v_res := util_loc_pkg.c_msg_eq_not_exist_on_stock;
  elsif p_result_code = util_stock.c_ec_OK
  then
    v_res := util_pkg.c_msg_ok;
  else
    v_res := util_pkg.c_msg_x_common;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
