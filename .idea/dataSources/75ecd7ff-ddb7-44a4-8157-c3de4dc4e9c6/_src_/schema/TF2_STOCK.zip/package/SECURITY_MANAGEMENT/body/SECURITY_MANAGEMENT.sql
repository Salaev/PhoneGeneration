CREATE package body security_management is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function validate_password(p_password users.password%type) return users.password%type
is
begin
  ------------------------------
  if p_password is null
  then
    return c_default_password;
  end if;
  ------------------------------
  return p_password;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_as_null_user_profile_id(p_user_profile_id users.user_profile_id%type) return users.user_profile_id%type
is
begin
  ------------------------------
  if p_user_profile_id = c_user_profile_id_empty
  then
    return NULL;
  end if;
  ------------------------------
  return p_user_profile_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_as_empty_user_profile_id(p_user_profile_id users.user_profile_id%type) return users.user_profile_id%type
is
begin
  ------------------------------
  if p_user_profile_id is NULL
  then
    return c_user_profile_id_empty;
  end if;
  ------------------------------
  return p_user_profile_id;
  ------------------------------
end;


----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_any_as_null(p_value number) return number
is
begin
  ------------------------------
  return nullif(p_value, util_stock.c_any_value_num);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_any_as_num(p_value number) return number
is
begin
  ------------------------------
  return nvl(p_value, util_stock.c_any_value_num);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_user_names_i
(
    p_date date,
    p_to_upper boolean,
    p_active boolean
) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_to_upper number := util_pkg.bool_to_int_2val(p_to_upper);
  v_is_active number := util_pkg.bool_to_int_3val(p_active);
begin
  ------------------------------
  util_loc_pkg.touch_date(p_date);
  ------------------------------
  select /*+ full(z)*/
    decode(v_to_upper, util_pkg.c_false, user_name, upper(user_name)) user_name
    bulk collect into v_res
    from users z
    where 1 = 1
    and (1 = 0
      or v_is_active is null
      or is_active = v_is_active
    )
    order by user_name
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ctl_users(p_coll ctl_users) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_users
(
    p_user_id users.user_id%type
) return ctl_users
is
  v_res ctl_users;
begin
  ------------------------------
  select /*+ index_asc(z, PK_USERS)*/
    * bulk collect into v_res
  from users z
  where 1 = 1
  and user_id = p_user_id
  order by user_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function users_ins_ii
(
    p_user_name users.user_name%type,
    p_user_profile_id users.user_profile_id%type,
    p_name users.name%type,
    p_surname users.surname%type,
    p_password users.password%type,
    p_home_stock_id users.home_stock_id%type,
    p_is_active users.is_active%type
) return users.user_id%type
is
  v_res users.user_id%type;
begin
  ------------------------------
  v_res := s_users.nextval;
  ------------------------------
  insert into users
  (
    user_name,
    user_profile_id,
    name,
    surname,
    password,
    home_stock_id,
    is_active,
    user_id,
    deleted
  )
  values
  (
    p_user_name,
    p_user_profile_id,
    p_name,
    p_surname,
    p_password,
    p_home_stock_id,
    p_is_active,
    v_res,
    null
  )
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_del_ii
(
    p_user_id users.user_id%type
)
is
begin
  ------------------------------
  delete from users where user_id = p_user_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_upd_ii
(
    p_user_id users.user_id%type,
    p_user_profile_id users.user_profile_id%type,
    p_name users.name%type,
    p_surname users.surname%type,
    p_password users.password%type
)
is
begin
  ------------------------------
  update users
  set
    user_profile_id = p_user_profile_id,
    name = p_name,
    surname = p_surname,
    password = p_password
  where 1 = 1
  and user_id = p_user_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_upd_is_active_ii
(
    p_user_id users.user_id%type,
    p_is_active users.is_active%type
)
is
begin
  ------------------------------
  update users
  set
    is_active = p_is_active
  where 1 = 1
  and user_id = p_user_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_upd_user_profile_id_ii
(
    p_user_id users.user_id%type,
    p_user_profile_id users.user_profile_id%type
)
is
begin
  ------------------------------
  update users
  set
    user_profile_id = p_user_profile_id
  where 1 = 1
  and user_id = p_user_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_upd_home_stock_id_ii
(
    p_user_id users.user_id%type,
    p_home_stock_id users.home_stock_id%type
)
is
begin
  ------------------------------
  update users
  set
    home_stock_id = p_home_stock_id
  where 1 = 1
  and user_id = p_user_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function user_profile_ins_ii
(
    p_name user_profile.name%type,
    p_description user_profile.description%type
) return user_profile.id%type
is
  v_res user_profile.id%type;
begin
  ------------------------------
  v_res := s_user_profile.nextval;
  ------------------------------
  insert into user_profile
  (
    id,
    name,
    description
  )
  values
  (
    v_res,
    p_name,
    p_description
  )
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure user_profile_del_ii
(
    p_id user_profile.id%type
)
is
begin
  ------------------------------
  delete from user_profile where id = p_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure user_profile_upd_ii
(
    p_id user_profile.id%type,
    p_name user_profile.name%type,
    p_description user_profile.description%type
)
is
begin
  ------------------------------
  update user_profile
  set
    name = p_name,
    description = p_description
  where 1 = 1
  and id = p_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function prog_obj_perm_ins_ii
(
    p_user_profile_id program_object_permission.user_profile_id%type,
    p_program_object_action_id program_object_permission.program_object_action_id%type,
    p_enabled program_object_permission.enabled%type
) return program_object_permission.id%type
is
  v_res program_object_permission.id%type;
begin
  ------------------------------
  v_res := s_program_object_permission.nextval;
  ------------------------------
  insert into program_object_permission
  (
    id,
    user_profile_id,
    program_object_action_id,
    enabled
  )
  values
  (
    v_res,
    p_user_profile_id,
    p_program_object_action_id,
    p_enabled
  )
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prog_obj_perm_ins2_ii
(
    p_user_profile_id program_object_permission.user_profile_id%type,
    p_enabled program_object_permission.enabled%type
)
is
begin
  ------------------------------
  insert into program_object_permission
  (
    id,
    user_profile_id,
    program_object_action_id,
    enabled
  )
  select
    s_program_object_permission.nextval id,
    p_user_profile_id user_profile_id,
    id program_object_action_id,
    p_enabled enabled
  from program_object_action
  where 1 = 1
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prog_obj_perm_del_ii
(
    p_id program_object_permission.id%type
)
is
begin
  ------------------------------
  delete from program_object_permission where id = p_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prog_obj_perm_del2_ii
(
    p_user_profile_id program_object_permission.user_profile_id%type
)
is
begin
  ------------------------------
  delete from program_object_permission where user_profile_id = p_user_profile_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prog_obj_perm_upd_ii
(
    p_id program_object_permission.id%type,
    p_enabled program_object_permission.enabled%type
)
is
begin
  ------------------------------
  update program_object_permission
  set
    enabled = p_enabled
  where 1 = 1
  and id = p_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prog_obj_perm_upd2_ii
(
    p_user_profile_id program_object_permission.user_profile_id%type,
    p_program_object_action_id program_object_permission.program_object_action_id%type,
    p_enabled program_object_permission.enabled%type
)
is
begin
  ------------------------------
  update program_object_permission
  set
    enabled = p_enabled
  where 1 = 1
  and user_profile_id = p_user_profile_id
  and program_object_action_id = p_program_object_action_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ctl_stock_group_perm(p_coll ctl_stock_group_permission) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_group_permission
(
    p_id stock_group_permission.id%type
) return ctl_stock_group_permission
is
  v_res ctl_stock_group_permission;
begin
  ------------------------------
  select /*+ index_asc(z, PK_STOCK_GROUP_PERMISSION)*/
    * bulk collect into v_res
  from stock_group_permission z
  where 1 = 1
  and id = p_id
  order by user_id, stock_group_id, stock_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_group_permission2
(
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type := null,
    p_stock_id stock_group_permission.stock_id%type := null
) return ctl_stock_group_permission
is
  v_res ctl_stock_group_permission;
begin
  ------------------------------
  select /*+ no_expand index_asc(z, I_SGP_U_SG_S)*/
    * bulk collect into v_res
  from stock_group_permission z
  where 1 = 1
  and user_id = p_user_id
  and stock_group_id = nvl(p_stock_group_id, stock_group_id)
  and stock_id = nvl(p_stock_id, stock_id)
  order by user_id, stock_group_id, stock_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function stock_group_perm_ins_ii
(
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_stock_id stock_group_permission.stock_id%type,
    p_permission_mask stock_group_permission.permission_mask%type
) return stock_group_permission.id%type
is
  v_res stock_group_permission.id%type;
begin
  ------------------------------
  v_res := s_stock_group_permission.nextval;
  ------------------------------
  insert into stock_group_permission
  (
    id,
    user_id,
    stock_group_id,
    stock_id,
    permission_mask
  )
  values
  (
    v_res,
    p_user_id,
    p_stock_group_id,
    p_stock_id,
    p_permission_mask
  )
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm_del_ii
(
    p_id stock_group_permission.id%type
)
is
begin
  ------------------------------
  delete from stock_group_permission where id = p_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm_del2_ii
(
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_stock_id stock_group_permission.stock_id%type
)
is
begin
  ------------------------------
  delete from stock_group_permission
  where 1 = 1
  and user_id = p_user_id
  and stock_group_id = p_stock_group_id
  and stock_id = p_stock_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm_del3_ii
(
    p_user_id stock_group_permission.user_id%type
)
is
begin
  ------------------------------
  delete from stock_group_permission where user_id = p_user_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm_del4_ii
(
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_with_stocks boolean
)
is
  v_with_stocks number := util_pkg.bool_to_int_2val(p_with_stocks);
begin
  ------------------------------
  delete from stock_group_permission
  where 1 = 1
  and user_id = p_user_id
  and stock_group_id = p_stock_group_id
  and stock_id = decode(v_with_stocks, util_pkg.c_false, util_stock.c_sgp_stock_id_for_group, stock_id)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm_del4_hier_ii
(
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_with_stocks boolean
)
is
  v_coll ct_node;
begin
  ------------------------------
  v_coll := util_stock.get_group_perms_i
  (
    p_user_id => p_user_id,
    p_date => sysdate,
    p_perm_mask => util_stock.c_perm_not_none,
    p_inclusive => true,
    p_start_group_id => p_stock_group_id,
    p_start_is_parent => false
  );
  ------------------------------
  if util_stock.get_count_ct_node(v_coll) = 0
  then
    return;
  end if;
  ------------------------------
  --!_! Here can be used forall with v_coll
  --!_! or single delete-SQL with table(v_coll)
  --!_! but now just enough this
  ------------------------------
  for v_i in v_coll.first..v_coll.last
  loop
    ------------------------------
    stock_group_perm_del4_ii
    (
      p_user_id => p_user_id,
      p_stock_group_id => v_coll(v_i).id,
      p_with_stocks => p_with_stocks
    );
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm_upd_ii
(
    p_id stock_group_permission.id%type,
    p_permission_mask stock_group_permission.permission_mask%type
)
is
begin
  ------------------------------
  update stock_group_permission
  set
    permission_mask = p_permission_mask
  where 1 = 1
  and id = p_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm_upd2_ii
(
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_stock_id stock_group_permission.stock_id%type,
    p_permission_mask stock_group_permission.permission_mask%type
)
is
begin
  ------------------------------
  update stock_group_permission
  set
    permission_mask = p_permission_mask
  where 1 = 1
  and user_id = p_user_id
  and stock_group_id = p_stock_group_id
  and stock_id = p_stock_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ctl_user_st_tm_priv(p_coll ctl_user_stock_time_privilege) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_stock_time_privilege
(
    p_id user_stock_time_privilege.id%type
) return ctl_user_stock_time_privilege
is
  v_res ctl_user_stock_time_privilege;
begin
  ------------------------------
  select /*+ index_asc(z, PK_USER_STOCK_TIME_PRIVILEGE)*/
    * bulk collect into v_res
  from user_stock_time_privilege z
  where 1 = 1
  and id = p_id
  order by stock_group_permission_id, start_date, end_date
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_stock_time_privilege2
(
    p_stock_group_permission_id user_stock_time_privilege.stock_group_permission_id%type,
    p_date date := null
) return ctl_user_stock_time_privilege
is
  v_res ctl_user_stock_time_privilege;
begin
  ------------------------------
  select /*+ index_asc(z, I_USER_STOCK_TIME_PRV)*/
    * bulk collect into v_res
  from user_stock_time_privilege z
  where 1 = 1
  and stock_group_permission_id = p_stock_group_permission_id
  and (1 = 0
    or p_date is null
    or p_date between start_date and end_date
  )
  order by stock_group_permission_id, start_date, end_date
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function user_stock_time_priv_ins_ii
(
    p_stock_group_permission_id user_stock_time_privilege.stock_group_permission_id%type,
    p_start_date user_stock_time_privilege.start_date%type,
    p_end_date user_stock_time_privilege.end_date%type,
    p_description user_stock_time_privilege.description%type
) return user_stock_time_privilege.id%type
is
  v_res user_stock_time_privilege.id%type;
begin
  ------------------------------
  v_res := s_user_stock_time_privilege.nextval;
  ------------------------------
  insert into user_stock_time_privilege
  (
    id,
    stock_group_permission_id,
    start_date,
    end_date,
    description
  )
  values
  (
    v_res,
    p_stock_group_permission_id,
    p_start_date,
    p_end_date,
    p_description
  )
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure user_stock_time_priv_del_ii
(
    p_id user_stock_time_privilege.id%type
)
is
begin
  ------------------------------
  delete from user_stock_time_privilege where id = p_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure user_stock_time_priv_upd_ii
(
    p_id user_stock_time_privilege.id%type,
    --!_!p_stock_group_permission_id user_stock_time_privilege.stock_group_permission_id%type,
    p_start_date user_stock_time_privilege.start_date%type,
    p_end_date user_stock_time_privilege.end_date%type,
    p_description user_stock_time_privilege.description%type
)
is
begin
  ------------------------------
  update user_stock_time_privilege
  set
    start_date = p_start_date,
    end_date = p_end_date,
    description = p_description
  where 1 = 1
  and id = p_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function users_ins_i
(
    p_sa_user_id users.user_id%type,
    p_user_name users.user_name%type,
    p_user_profile_id users.user_profile_id%type,
    p_name users.name%type,
    p_surname users.surname%type,
    p_password users.password%type,
    p_home_stock_id users.home_stock_id%type,
    p_is_active users.is_active%type
) return users.user_id%type
is
  v_res users.user_id%type;
  v_user_name users.user_name%type;
  v_user_profile_id users.user_profile_id%type;
  v_password users.password%type;
begin
  ------------------------------
  v_user_name := p_user_name; --!_! insert then not xget
  ------------------------------
  v_password := validate_password(p_password);
  ------------------------------
  v_user_profile_id := make_as_null_user_profile_id(p_user_profile_id);
  ------------------------------
  v_res := users_ins_ii
  (
    p_user_name => v_user_name,
    p_user_profile_id => v_user_profile_id,
    p_name => p_name,
    p_surname => p_surname,
    p_password => v_password,
    p_home_stock_id => p_home_stock_id,
    p_is_active => p_is_active
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_user_create, v_user_name, v_user_name || c_msg_delim || v_user_profile_id || c_msg_delim || p_name || c_msg_delim || p_surname);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_ins2_i
(
    p_sa_user_id users.user_id%type,
    p_user_name users.user_name%type,
    p_user_profile_id users.user_profile_id%type,
    p_name users.name%type
)
is
  v_id users.user_id%type;
begin
  ------------------------------
  v_id := users_ins_i
  (
    p_sa_user_id => p_sa_user_id,
    p_user_name => p_user_name,
    p_user_profile_id => p_user_profile_id,
    p_name => p_name,
    p_surname => null,
    p_password => null,
    p_home_stock_id => null,
    p_is_active => util_pkg.c_true
  );
  ------------------------------
  util_loc_pkg.touch_number(v_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_del_i
(
    p_sa_user_id users.user_id%type,
    p_user_id users.user_id%type
)
is
  v_user_name users.user_name%type;
begin
  ------------------------------
  v_user_name := util_stock.xget_user_name(p_user_id);
  ------------------------------
  stock_group_perm_del3_ii
  (
    p_user_id => p_user_id
  );
  ------------------------------
  users_del_ii
  (
    p_user_id => p_user_id
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_user_delete, v_user_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_upd_i
(
    p_sa_user_id users.user_id%type,
    p_user_id users.user_id%type,
    p_user_profile_id users.user_profile_id%type,
    p_name users.name%type,
    p_surname users.surname%type,
    p_password users.password%type
)
is
  v_user_name users.user_name%type;
  v_user_profile_id users.user_profile_id%type;
  v_password users.password%type;
begin
  ------------------------------
  v_user_name := util_stock.xget_user_name(p_user_id);
  ------------------------------
  v_password := validate_password(p_password);
  ------------------------------
  v_user_profile_id := make_as_null_user_profile_id(p_user_profile_id);
  ------------------------------
  users_upd_ii
  (
    p_user_id => p_user_id,
    p_user_profile_id => v_user_profile_id,
    p_name => p_name,
    p_surname => p_surname,
    p_password => v_password
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_user_modify, v_user_name, v_user_name || c_msg_delim || v_user_profile_id || c_msg_delim || p_name || c_msg_delim || p_surname);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_upd_is_active_i
(
    p_sa_user_id users.user_id%type,
    p_user_id users.user_id%type,
    p_is_active users.is_active%type
)
is
  v_user_name users.user_name%type;
begin
  ------------------------------
  v_user_name := util_stock.xget_user_name(p_user_id);
  ------------------------------
  users_upd_is_active_ii
  (
    p_user_id => p_user_id,
    p_is_active => p_is_active
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_user_modify, v_user_name, v_user_name || c_msg_delim || p_is_active);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_upd_user_profile_id_i
(
    p_sa_user_id users.user_id%type,
    p_user_id users.user_id%type,
    p_user_profile_id users.user_profile_id%type
)
is
  v_user_name users.user_name%type;
  v_user_profile_id users.user_profile_id%type;
begin
  ------------------------------
  v_user_name := util_stock.xget_user_name(p_user_id);
  ------------------------------
  v_user_profile_id := make_as_null_user_profile_id(p_user_profile_id);
  ------------------------------
  users_upd_user_profile_id_ii
  (
    p_user_id => p_user_id,
    p_user_profile_id => v_user_profile_id
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_user_modify, v_user_name, v_user_name || c_msg_delim || v_user_profile_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_upd_home_stock_id_i
(
    p_sa_user_id users.user_id%type,
    p_user_id users.user_id%type,
    p_home_stock_id users.home_stock_id%type
)
is
  v_user_name users.user_name%type;
begin
  ------------------------------
  v_user_name := util_stock.xget_user_name(p_user_id);
  ------------------------------
  users_upd_home_stock_id_ii
  (
    p_user_id => p_user_id,
    p_home_stock_id => p_home_stock_id
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_user_modify, v_user_name, v_user_name || c_msg_delim || p_home_stock_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function user_profile_ins_i
(
    p_sa_user_id users.user_id%type,
    p_name user_profile.name%type,
    p_description user_profile.description%type
) return user_profile.id%type
is
  v_res user_profile.id%type;
begin
  ------------------------------
  v_res := user_profile_ins_ii
  (
    p_name => p_name,
    p_description => p_description
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_profile_create, v_res, p_name || c_msg_delim || p_description);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure user_profile_del_i
(
    p_sa_user_id users.user_id%type,
    p_id user_profile.id%type
)
is
begin
  ------------------------------
  prog_obj_perm_del2_i
  (
    p_sa_user_id => p_sa_user_id,
    p_user_profile_id => p_id
  );
  ------------------------------
  user_profile_del_ii
  (
    p_id => p_id
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_profile_delete, p_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure user_profile_upd_i
(
    p_sa_user_id users.user_id%type,
    p_id user_profile.id%type,
    p_name user_profile.name%type,
    p_description user_profile.description%type
)
is
begin
  ------------------------------
  user_profile_upd_ii
  (
    p_id => p_id,
    p_name => p_name,
    p_description => p_description
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_profile_modify, p_id, p_name || c_msg_delim || p_description);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function prog_obj_perm_ins_i
(
    p_sa_user_id users.user_id%type,
    p_user_profile_id program_object_permission.user_profile_id%type,
    p_program_object_action_id program_object_permission.program_object_action_id%type,
    p_enabled program_object_permission.enabled%type
) return program_object_permission.id%type
is
  v_res program_object_permission.id%type;
begin
  ------------------------------
  v_res := prog_obj_perm_ins_ii
  (
    p_user_profile_id => p_user_profile_id,
    p_program_object_action_id => p_program_object_action_id,
    p_enabled => p_enabled
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_profile_privilege_create, v_res, p_user_profile_id || c_msg_delim || p_program_object_action_id || c_msg_delim || p_enabled);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prog_obj_perm_ins2_i
(
    p_sa_user_id users.user_id%type,
    p_user_profile_id program_object_permission.user_profile_id%type,
    p_enabled program_object_permission.enabled%type
)
is
begin
  ------------------------------
  prog_obj_perm_ins2_ii
  (
    p_user_profile_id => p_user_profile_id,
    p_enabled => p_enabled
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_profile_privilege_create, p_user_profile_id || c_msg_delim || p_enabled);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prog_obj_perm_del_i
(
    p_sa_user_id users.user_id%type,
    p_id program_object_permission.id%type
)
is
begin
  ------------------------------
  prog_obj_perm_del_ii
  (
    p_id => p_id
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_profile_privilege_delete, p_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prog_obj_perm_del2_i
(
    p_sa_user_id users.user_id%type,
    p_user_profile_id program_object_permission.user_profile_id%type
)
is
begin
  ------------------------------
  prog_obj_perm_del2_ii
  (
    p_user_profile_id => p_user_profile_id
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_profile_privilege_delete, p_user_profile_id, p_user_profile_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prog_obj_perm_upd_i
(
    p_sa_user_id users.user_id%type,
    p_id program_object_permission.id%type,
    p_enabled program_object_permission.enabled%type
)
is
begin
  ------------------------------
  prog_obj_perm_upd_ii
  (
    p_id => p_id,
    p_enabled => p_enabled
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_profile_privilege_modify, p_id, p_enabled);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prog_obj_perm_upd2_i
(
    p_sa_user_id users.user_id%type,
    p_user_profile_id program_object_permission.user_profile_id%type,
    p_program_object_action_id program_object_permission.program_object_action_id%type,
    p_enabled program_object_permission.enabled%type
)
is
begin
  ------------------------------
  prog_obj_perm_upd2_ii
  (
    p_user_profile_id => p_user_profile_id,
    p_program_object_action_id => p_program_object_action_id,
    p_enabled => p_enabled
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_profile_privilege_modify, p_user_profile_id, p_user_profile_id || c_msg_delim || p_program_object_action_id || c_msg_delim || p_enabled);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function stock_group_perm_ins_i
(
    p_sa_user_id users.user_id%type,
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_stock_id stock_group_permission.stock_id%type,
    p_permission_mask stock_group_permission.permission_mask%type,
    p_del_prev boolean
) return stock_group_permission.id%type
is
  v_res stock_group_permission.id%type;
  v_del_prev boolean := util_pkg.bool_to_bool_2val(p_del_prev);
  v_user_name users.user_name%type;
begin
  ------------------------------
  v_user_name := util_stock.xget_user_name(p_user_id);
  ------------------------------
  if v_del_prev
  then
    ------------------------------
    if p_stock_id = util_stock.c_sgp_stock_id_for_group
    then
      ------------------------------
      stock_group_perm_del4_hier_ii
      (
        p_user_id => p_user_id,
        p_stock_group_id => p_stock_group_id,
        p_with_stocks => TRUE
      );
      ------------------------------
    else
      ------------------------------
      stock_group_perm_del2_ii
      (
        p_user_id => p_user_id,
        p_stock_group_id => p_stock_group_id,
        p_stock_id => p_stock_id
      );
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  v_res := stock_group_perm_ins_ii
  (
    p_user_id => p_user_id,
    p_stock_group_id => p_stock_group_id,
    p_stock_id => p_stock_id,
    p_permission_mask => p_permission_mask
  );
  ------------------------------
  if p_stock_id = util_stock.c_sgp_stock_id_for_group
  then
    util_stock.log_log2(p_sa_user_id, util_stock.c_la_usgp_create, v_res, v_user_name || c_msg_delim || p_stock_group_id || c_msg_delim || p_permission_mask);
  else
    util_stock.log_log2(p_sa_user_id, util_stock.c_la_usp_create, v_res, v_user_name || c_msg_delim || p_stock_group_id || c_msg_delim || p_stock_id || c_msg_delim || p_permission_mask);
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm_del_i
(
    p_sa_user_id users.user_id%type,
    p_id stock_group_permission.id%type
)
is
  v_coll ctl_stock_group_permission;
  v_rec stock_group_permission%rowtype;
  v_user_name users.user_name%type;
begin
  ------------------------------
  v_coll := get_stock_group_permission(p_id);
  ------------------------------
  if get_count_ctl_stock_group_perm(v_coll) = 0
  then
    return;
  end if;
  ------------------------------
  v_rec := v_coll(v_coll.first);
  ------------------------------
  v_user_name := util_stock.xget_user_name(v_rec.user_id);
  ------------------------------
  stock_group_perm_del_ii
  (
    p_id => p_id
  );
  ------------------------------
  if v_rec.stock_id = util_stock.c_sgp_stock_id_for_group
  then
    util_stock.log_log2(p_sa_user_id, util_stock.c_la_usgp_delete, v_rec.id, v_user_name || c_msg_delim || v_rec.stock_group_id || c_msg_delim || v_rec.permission_mask);
  else
    util_stock.log_log2(p_sa_user_id, util_stock.c_la_usp_delete, v_rec.id, v_user_name || c_msg_delim || v_rec.stock_group_id || c_msg_delim || v_rec.stock_id || c_msg_delim || v_rec.permission_mask);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm_del2_i
(
    p_sa_user_id users.user_id%type,
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_stock_id stock_group_permission.stock_id%type
)
is
  v_coll ctl_stock_group_permission;
  v_rec stock_group_permission%rowtype;
  v_user_name users.user_name%type;
begin
  ------------------------------
  v_coll := get_stock_group_permission2
  (
    p_user_id => p_user_id,
    p_stock_group_id => p_stock_group_id,
    p_stock_id => p_stock_id
  );
  ------------------------------
  if get_count_ctl_stock_group_perm(v_coll) = 0
  then
    return;
  end if;
  ------------------------------
  v_rec := v_coll(v_coll.first);
  ------------------------------
  v_user_name := util_stock.xget_user_name(v_rec.user_id);
  ------------------------------
  stock_group_perm_del2_ii
  (
    p_user_id => p_user_id,
    p_stock_group_id => p_stock_group_id,
    p_stock_id => p_stock_id
  );
  ------------------------------
  if v_rec.stock_id = util_stock.c_sgp_stock_id_for_group
  then
    util_stock.log_log2(p_sa_user_id, util_stock.c_la_usgp_delete, v_rec.id, v_user_name || c_msg_delim || v_rec.stock_group_id || c_msg_delim || v_rec.permission_mask);
  else
    util_stock.log_log2(p_sa_user_id, util_stock.c_la_usp_delete, v_rec.id, v_user_name || c_msg_delim || v_rec.stock_group_id || c_msg_delim || v_rec.stock_id || c_msg_delim || v_rec.permission_mask);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm_upd_i
(
    p_sa_user_id users.user_id%type,
    p_id stock_group_permission.id%type,
    p_permission_mask stock_group_permission.permission_mask%type
)
is
  v_coll ctl_stock_group_permission;
  v_rec stock_group_permission%rowtype;
  v_user_name users.user_name%type;
begin
  ------------------------------
  v_coll := get_stock_group_permission(p_id);
  ------------------------------
  if get_count_ctl_stock_group_perm(v_coll) = 0
  then
    return;
  end if;
  ------------------------------
  v_rec := v_coll(v_coll.first);
  ------------------------------
  v_user_name := util_stock.xget_user_name(v_rec.user_id);
  ------------------------------
  stock_group_perm_upd_ii
  (
    p_id => p_id,
    p_permission_mask => p_permission_mask
  );
  ------------------------------
  if v_rec.stock_id = util_stock.c_sgp_stock_id_for_group
  then
    util_stock.log_log2(p_sa_user_id, util_stock.c_la_usgp_modify, v_rec.id, v_user_name || c_msg_delim || v_rec.stock_group_id || c_msg_delim || p_permission_mask);
  else
    util_stock.log_log2(p_sa_user_id, util_stock.c_la_usp_modify, v_rec.id, v_user_name || c_msg_delim || v_rec.stock_group_id || c_msg_delim || v_rec.stock_id || c_msg_delim || p_permission_mask);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm_upd2_i
(
    p_sa_user_id users.user_id%type,
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_stock_id stock_group_permission.stock_id%type,
    p_permission_mask stock_group_permission.permission_mask%type
)
is
  v_coll ctl_stock_group_permission;
  v_rec stock_group_permission%rowtype;
  v_user_name users.user_name%type;
begin
  ------------------------------
  v_coll := get_stock_group_permission2
  (
    p_user_id => p_user_id,
    p_stock_group_id => p_stock_group_id,
    p_stock_id => p_stock_id
  );
  ------------------------------
  if get_count_ctl_stock_group_perm(v_coll) = 0
  then
    return;
  end if;
  ------------------------------
  v_rec := v_coll(v_coll.first);
  ------------------------------
  v_user_name := util_stock.xget_user_name(v_rec.user_id);
  ------------------------------
  stock_group_perm_upd2_ii
  (
    p_user_id => p_user_id,
    p_stock_group_id => p_stock_group_id,
    p_stock_id => p_stock_id,
    p_permission_mask => p_permission_mask
  );
  ------------------------------
  if v_rec.stock_id = util_stock.c_sgp_stock_id_for_group
  then
    util_stock.log_log2(p_sa_user_id, util_stock.c_la_usgp_modify, v_rec.id, v_user_name || c_msg_delim || v_rec.stock_group_id || c_msg_delim || p_permission_mask);
  else
    util_stock.log_log2(p_sa_user_id, util_stock.c_la_usp_modify, v_rec.id, v_user_name || c_msg_delim || v_rec.stock_group_id || c_msg_delim || v_rec.stock_id || c_msg_delim || p_permission_mask);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm_copy_i
(
    p_sa_user_id users.user_id%type,
    p_user_id_from stock_group_permission.user_id%type,
    p_user_id_to stock_group_permission.user_id%type
)
is
  v_coll ctl_stock_group_permission;
  v_rec stock_group_permission%rowtype;
  v_id stock_group_permission.id%type;
  v_coll2 ctl_user_stock_time_privilege;
  v_rec2 user_stock_time_privilege%rowtype;
  v_id2 user_stock_time_privilege.id%type;
begin
  ------------------------------
  stock_group_perm_del2_i
  (
    p_sa_user_id => p_sa_user_id,
    p_user_id => p_user_id_to,
    p_stock_group_id => NULL,
    p_stock_id => NULL
  );
  ------------------------------
  v_coll := get_stock_group_permission2
  (
    p_user_id => p_user_id_from,
    p_stock_group_id => NULL,
    p_stock_id => NULL
  );
  ------------------------------
  if get_count_ctl_stock_group_perm(v_coll) = 0
  then
    return;
  end if;
  ------------------------------
  for v_i in v_coll.first..v_coll.last
  loop
    ------------------------------
    v_rec := v_coll(v_i);
    ------------------------------
    v_id := stock_group_perm_ins_i
    (
      p_sa_user_id => p_sa_user_id,
      p_user_id => p_user_id_to,
      p_stock_group_id => v_rec.stock_group_id,
      p_stock_id => v_rec.stock_id,
      p_permission_mask => v_rec.permission_mask,
      p_del_prev => FALSE
    );
    ------------------------------
    v_coll2 := get_user_stock_time_privilege2
    (
      p_stock_group_permission_id => v_rec.id,
      p_date => null
    );
    ------------------------------
    if get_count_ctl_user_st_tm_priv(v_coll2) = 0
    then
      continue;
    end if;
    ------------------------------
    for v_j in v_coll2.first..v_coll2.last
    loop
      ------------------------------
      v_rec2 := v_coll2(v_j);
      ------------------------------
      v_id2 := user_stock_time_priv_ins_i
      (
        p_sa_user_id => p_sa_user_id,
        p_stock_group_permission_id => v_id,
        p_start_date => v_rec2.start_date,
        p_end_date => v_rec2.end_date,
        p_description => v_rec2.description
      );
      ------------------------------
      util_loc_pkg.touch_number(v_id2);
      ------------------------------
    end loop;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function user_stock_time_priv_ins_i
(
    p_sa_user_id users.user_id%type,
    p_stock_group_permission_id user_stock_time_privilege.stock_group_permission_id%type,
    p_start_date user_stock_time_privilege.start_date%type,
    p_end_date user_stock_time_privilege.end_date%type,
    p_description user_stock_time_privilege.description%type
) return user_stock_time_privilege.id%type
is
  v_res user_stock_time_privilege.id%type;
begin
  ------------------------------
  v_res := user_stock_time_priv_ins_ii
  (
    p_stock_group_permission_id => p_stock_group_permission_id,
    p_start_date => p_start_date,
    p_end_date => p_end_date,
    p_description => p_description
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_user_time_priv_create, v_res,
    p_stock_group_permission_id || c_msg_delim
    || util_pkg.date_to_char(p_start_date) || c_msg_delim
    || util_pkg.date_to_char(p_end_date) || c_msg_delim
    || p_description
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure user_stock_time_priv_del_i
(
    p_sa_user_id users.user_id%type,
    p_id user_stock_time_privilege.id%type
)
is
  v_coll ctl_user_stock_time_privilege;
  v_rec user_stock_time_privilege%rowtype;
  v_coll2 ctl_stock_group_permission;
  v_rec2 stock_group_permission%rowtype;
  v_user_name users.user_name%type;
begin
  ------------------------------
  v_coll := get_user_stock_time_privilege(p_id);
  ------------------------------
  if get_count_ctl_user_st_tm_priv(v_coll) = 0
  then
    return;
  end if;
  ------------------------------
  v_rec := v_coll(v_coll.first);
  ------------------------------
  v_coll2 := get_stock_group_permission(v_rec.stock_group_permission_id);
  ------------------------------
  if get_count_ctl_stock_group_perm(v_coll2) = 0
  then
    util_pkg.raise_exception(util_pkg.c_ora_parent_object_not_found, util_pkg.c_msg_parent_object_not_found || util_pkg.c_msg_delim01
      || util_pkg.number_to_char(v_rec.id) || util_pkg.c_msg_delim02
      || util_pkg.number_to_char(v_rec.stock_group_permission_id)
    );
  end if;
  ------------------------------
  v_rec2 := v_coll2(v_coll2.first);
  ------------------------------
  v_user_name := util_stock.xget_user_name(v_rec2.user_id);
  ------------------------------
  user_stock_time_priv_del_ii
  (
    p_id => p_id
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_user_time_priv_delete, v_rec.id,
    v_user_name || c_msg_delim
    || v_rec2.stock_group_id || c_msg_delim
    || v_rec2.stock_id || c_msg_delim
    || v_rec2.permission_mask || c_msg_delim
    || util_pkg.date_to_char(v_rec.start_date) || c_msg_delim
    || util_pkg.date_to_char(v_rec.end_date)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure user_stock_time_priv_upd_i
(
    p_sa_user_id users.user_id%type,
    p_id user_stock_time_privilege.id%type,
    --!_!p_stock_group_permission_id user_stock_time_privilege.stock_group_permission_id%type,
    p_start_date user_stock_time_privilege.start_date%type,
    p_end_date user_stock_time_privilege.end_date%type,
    p_description user_stock_time_privilege.description%type
)
is
  v_coll ctl_user_stock_time_privilege;
  v_rec user_stock_time_privilege%rowtype;
  v_coll2 ctl_stock_group_permission;
  v_rec2 stock_group_permission%rowtype;
  v_user_name users.user_name%type;
begin
  ------------------------------
  v_coll := get_user_stock_time_privilege(p_id);
  ------------------------------
  if get_count_ctl_user_st_tm_priv(v_coll) = 0
  then
    return;
  end if;
  ------------------------------
  v_rec := v_coll(v_coll.first);
  ------------------------------
  v_coll2 := get_stock_group_permission(v_rec.stock_group_permission_id);
  ------------------------------
  if get_count_ctl_stock_group_perm(v_coll2) = 0
  then
    util_pkg.raise_exception(util_pkg.c_ora_parent_object_not_found, util_pkg.c_msg_parent_object_not_found || util_pkg.c_msg_delim01
      || util_pkg.number_to_char(v_rec.id) || util_pkg.c_msg_delim02
      || util_pkg.number_to_char(v_rec.stock_group_permission_id)
    );
  end if;
  ------------------------------
  v_rec2 := v_coll2(v_coll2.first);
  ------------------------------
  v_user_name := util_stock.xget_user_name(v_rec2.user_id);
  ------------------------------
  user_stock_time_priv_upd_ii
  (
    p_id => p_id,
    --!_!p_stock_group_permission_id => p_stock_group_permission_id,
    p_start_date => p_start_date,
    p_end_date => p_end_date,
    p_description => p_description
  );
  ------------------------------
  util_stock.log_log2(p_sa_user_id, util_stock.c_la_user_time_priv_modify, v_rec.id,
    v_user_name || c_msg_delim
    || v_rec2.stock_group_id || c_msg_delim
    || v_rec2.stock_id || c_msg_delim
    || v_rec2.permission_mask || c_msg_delim
    || util_pkg.date_to_char(p_start_date) || c_msg_delim
    || util_pkg.date_to_char(p_end_date) || c_msg_delim
    || util_pkg.date_to_char(v_rec.start_date) || c_msg_delim
    || util_pkg.date_to_char(v_rec.end_date)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure users__get
(
    p_user_name nvarchar2,
    p_active number,
    p_users_rec out sys_refcursor,
    p_error_code out number
)
is
  v_date date := sysdate;
  v_user_id users.user_id%type;
  v_is_active boolean := util_pkg.int_to_bool_3val(make_any_as_null(p_active));
begin
  ------------------------------
  if p_user_name is null
  then
    ------------------------------
    get_result_cursor009(v_date, v_is_active, p_users_rec);
    ------------------------------
  else
    ------------------------------
    --!_!v_user_id := util_stock.xget_user_id(p_user_name);
    v_user_id := util_stock.get_user_id(p_user_name);
    ------------------------------
    get_result_cursor008(v_user_id, v_date, v_is_active, p_users_rec);
    ------------------------------
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  --!_!raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users__get_2
(
    p_user_name nvarchar2,
    p_active number,
    p_users_rec out sys_refcursor,
    p_error_code out number
)
is
begin
  ------------------------------
  users__get
  (
    p_user_name => p_user_name,
    p_active => p_active,
    p_users_rec => p_users_rec,
    p_error_code => p_error_code
  );
  ------------------------------
end;
   
----------------------------------!---------------------------------------------
procedure users__get
(
    p_user_name nvarchar2,
    p_users_rec out sys_refcursor,
    p_error_code out number
)
is
begin
  ------------------------------
  users__get
  (
    p_user_name => p_user_name,
    p_active => util_stock.c_any_value_num,
    p_users_rec => p_users_rec,
    p_error_code => p_error_code
  );
  ------------------------------
end;
   
----------------------------------!---------------------------------------------
procedure users__get_1
(
    p_user_name nvarchar2,
    p_users_rec out sys_refcursor,
    p_error_code out number
)
is
begin
  ------------------------------
  users__get
  (
    p_user_name => p_user_name,
    p_users_rec => p_users_rec,
    p_error_code => p_error_code
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure users__ins
(
    p_sa nvarchar2,
    p_user_name nvarchar2,
    p_user_profile_id number,
    p_name nvarchar2,
    p_surname nvarchar2,
    p_password nvarchar2,
    p_active number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
  v_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  ------------------------------
  v_id := users_ins_i
  (
    p_sa_user_id => v_sa_user_id,
    p_user_name => p_user_name,
    p_user_profile_id => p_user_profile_id,
    p_name => p_name,
    p_surname => p_surname,
    p_password => p_password,
    p_home_stock_id => NULL,
    p_is_active => p_active
  );
  ------------------------------
  util_loc_pkg.touch_number(v_id);
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users__del
(
    p_sa nvarchar2,
    p_user_name nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
  v_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  v_user_id := util_stock.xget_user_id(p_user_name);
  ------------------------------
  users_del_i
  (
    p_sa_user_id => v_sa_user_id,
    p_user_id => v_user_id
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users__upd
(
    p_sa nvarchar2,
    p_user_name nvarchar2,
    p_user_profile_id number,
    p_name nvarchar2,
    p_surname nvarchar2,
    p_password nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
  v_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  v_user_id := util_stock.xget_user_id(p_user_name);
  ------------------------------
  users_upd_i
  (
    p_sa_user_id => v_sa_user_id,
    p_user_id => v_user_id,
    p_user_profile_id => p_user_profile_id,
    p_name => p_name,
    p_surname => p_surname,
    p_password => p_password
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users__upd_active
(
    p_sa nvarchar2,
    p_user_name nvarchar2,
    p_active number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
  v_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  v_user_id := util_stock.xget_user_id(p_user_name);
  ------------------------------
  users_upd_is_active_i
  (
    p_sa_user_id => v_sa_user_id,
    p_user_id => v_user_id,
    p_is_active => p_active
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users__upd_profile
(
    p_sa nvarchar2,
    p_user_name nvarchar2,
    p_user_profile_id number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
  v_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  v_user_id := util_stock.xget_user_id(p_user_name);
  ------------------------------
  users_upd_user_profile_id_i
  (
    p_sa_user_id => v_sa_user_id,
    p_user_id => v_user_id,
    p_user_profile_id => p_user_profile_id
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users__upd_homestock
(
    p_sa nvarchar2,
    p_user_name nvarchar2,
    p_home_stock_id number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
  v_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  v_user_id := util_stock.xget_user_id(p_user_name);
  ------------------------------
  users_upd_home_stock_id_i
  (
    p_sa_user_id => v_sa_user_id,
    p_user_id => v_user_id,
    p_home_stock_id => p_home_stock_id
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure user_profile__get
(
    p_id number,
    p_user_profile_rec out sys_refcursor,
    p_error_code out number
)
is
begin
  ------------------------------
  if make_as_empty_user_profile_id(p_id) = c_user_profile_id_empty
  then
    get_result_cursor012(p_user_profile_rec);
  else
    get_result_cursor011(p_id, p_user_profile_rec);
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  --!_!raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_profile_members_get
(
    p_user_profile number,
    p_active number,
    p_users_rec out sys_refcursor,
    p_error_code out number
)
is
  v_date date := sysdate;
  v_is_active boolean := util_pkg.int_to_bool_3val(make_any_as_null(p_active));
begin
  ------------------------------
  get_result_cursor010(p_user_profile, v_date, v_is_active, p_users_rec);
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure user_profile__ins
(
    p_sa nvarchar2,
    p_id out number,
    p_name nvarchar2,
    p_description nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  ------------------------------
  p_id := user_profile_ins_i
  (
    p_sa_user_id => v_sa_user_id,
    p_name => p_name,
    p_description => p_description
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure user_profile__del
(
    p_sa nvarchar2,
    p_id number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  ------------------------------
  user_profile_del_i
  (
    p_sa_user_id => v_sa_user_id,
    p_id => p_id
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure user_profile__upd
(
    p_sa nvarchar2,
    p_id number,
    p_name nvarchar2,
    p_description nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  ------------------------------
  user_profile_upd_i
  (
    p_sa_user_id => v_sa_user_id,
    p_id => p_id,
    p_name => p_name,
    p_description => p_description
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_program_object_ids
(
    p_id number,
    p_group_id number
) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  if p_id is not null
  then
    ------------------------------
    select /*+ no_expand index_asc(z, PK_PROGRAM_OBJECT)*/
  id
  bulk collect into v_res
  from program_object z
  where 1 = 1
  and id = p_id
  and program_object_group_id = nvl(p_group_id, program_object_group_id)
  order by id
    ------------------------------
    ;
  elsif p_group_id is not null
  then
    ------------------------------
    select /*+ index_asc(z, I_PROGRAM_OBJECT_GROUP_ID)*/
  id
  bulk collect into v_res
  from program_object z
  where 1 = 1
  --!_!and id = p_id
  and program_object_group_id = p_group_id
  order by id
    ------------------------------
    ;
  else
    ------------------------------
    select /*+ full(z)*/
  id
  bulk collect into v_res
  from program_object z
  where 1 = 1
  --!_!and id = p_id
  --!_!and program_object_group_id = p_group_id
  order by id
    ------------------------------
    ;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prog_obj__get
(
    p_id number,
    p_group_id number,
    p_program_object_rec out sys_refcursor,
    p_error_code out number
)
is
  v_id number := nullif(p_id, util_stock.c_any_value_old_school_num);
  v_group_id number := nullif(p_group_id, util_stock.c_any_value_old_school_num);
  v_ids ct_number;
begin
  ------------------------------
  v_ids := get_program_object_ids
  (
    p_id => v_id,
    p_group_id => v_group_id
  );
  ------------------------------
  get_result_cursor005(v_ids, p_program_object_rec);
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_program_object_action_ids
(
    p_id number,
    p_program_object_id number,
    p_action_id number
) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  if p_id is not null
  then
    ------------------------------
    select /*+ no_expand index_asc(z, PK_PROGRAM_OBJECT_ACTION)*/
  id
  bulk collect into v_res
  from program_object_action z
  where 1 = 1
  and id = p_id
  and program_object_id = nvl(p_program_object_id, program_object_id)
  and action_id = nvl(p_action_id, action_id)
  order by id
    ------------------------------
    ;
  elsif p_program_object_id is not null
  then
    ------------------------------
    select /*+ no_expand index_asc(z, I_PROG_OBJECT_ACTION)*/
  id
  bulk collect into v_res
  from program_object_action z
  where 1 = 1
  --!_!and id = p_id
  and program_object_id = p_program_object_id
  and action_id = nvl(p_action_id, action_id)
  order by id
    ------------------------------
    ;
  elsif p_action_id is not null
  then
    ------------------------------
    select /*+ full(z)*/
  id
  bulk collect into v_res
  from program_object_action z
  where 1 = 1
  --!_!and id = p_id
  --!_!and program_object_id = p_program_object_id
  and action_id = p_action_id
  order by id
    ------------------------------
    ;
  else
    ------------------------------
    select /*+ full(z)*/
  id
  bulk collect into v_res
  from program_object_action z
  where 1 = 1
  --!_!and id = p_id
  --!_!and program_object_id = p_program_object_id
  --!_!and action_id = p_action_id
  order by id
    ------------------------------
    ;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure user_permission__get
(
    p_user_profile number,
    p_program_object_id number,
    p_action_id number,
    p_object_permission_rec out sys_refcursor,
    p_error_code out number
)
is
  v_user_profile_id number := nullif(p_user_profile, util_stock.c_any_value_old_school_num);
  v_program_object_id number := nullif(p_program_object_id, util_stock.c_any_value_old_school_num);
  v_action_id number := nullif(p_action_id, util_stock.c_any_value_old_school_num);
  v_ids ct_number;
begin
  ------------------------------
  v_ids := get_program_object_action_ids
  (
    p_id => NULL,
    p_program_object_id => v_program_object_id,
    p_action_id => v_action_id
  );
  ------------------------------
  if v_user_profile_id is not null
  then
    get_result_cursor006(v_ids, v_user_profile_id, p_object_permission_rec);
  else
    get_result_cursor007(v_ids, p_object_permission_rec);
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure prog_obj_perm__ins
(
    p_sa nvarchar2,
    p_user_profile number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  ------------------------------
  prog_obj_perm_ins2_i
  (
    p_sa_user_id => v_sa_user_id,
    p_user_profile_id => p_user_profile,
    p_enabled => util_pkg.C_FALSE
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prog_obj_perm__del
(
    p_sa nvarchar2,
    p_user_profile number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  ------------------------------
  prog_obj_perm_del2_i
  (
    p_sa_user_id => v_sa_user_id,
    p_user_profile_id => p_user_profile
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prog_obj_perm__upd
(
    p_sa nvarchar2,
    p_user_profile number,
    p_prog_obj_action_id number,
    p_enabled number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  ------------------------------
  prog_obj_perm_upd2_i
  (
    p_sa_user_id => v_sa_user_id,
    p_user_profile_id => p_user_profile,
    p_program_object_action_id => p_prog_obj_action_id,
    p_enabled => p_enabled
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_stock_group_permission_ids
(
    p_id number,
    p_stock_id number,
    p_stock_group_id number,
    p_user_id stock_group_permission.user_id%type
) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  if p_id is not null
  then
    ------------------------------
    select /*+ no_expand index_asc(z, PK_STOCK_GROUP_PERMISSION)*/
  id
  bulk collect into v_res
  from stock_group_permission z
  where 1 = 1
  and id = p_id
  and stock_id = nvl(p_stock_id, stock_id)
  and stock_group_id = nvl(p_stock_group_id, stock_group_id)
  and user_id = nvl(p_user_id, user_id)
  order by id
    ;
    ------------------------------
  elsif p_stock_id is not null
  then
    ------------------------------
    select /*+ no_expand index_asc(z, I_SGP_S_U_SG)*/
  id
  bulk collect into v_res
  from stock_group_permission z
  where 1 = 1
  --!_!and id = p_id
  and stock_id = p_stock_id
  and stock_group_id = nvl(p_stock_group_id, stock_group_id)
  and user_id = nvl(p_user_id, user_id)
  order by id
    ;
    ------------------------------
  elsif p_stock_group_id is not null
  then
    ------------------------------
    select /*+ no_expand index_asc(z, I_SGP_SG_U_S)*/
  id
  bulk collect into v_res
  from stock_group_permission z
  where 1 = 1
  --!_!and id = p_id
  --!_!and stock_id = p_stock_id
  and stock_group_id = p_stock_group_id
  and user_id = nvl(p_user_id, user_id)
  order by id
    ;
    ------------------------------
  elsif p_user_id is not null
  then
    ------------------------------
    select /*+ no_expand index_asc(z, I_SGP_U_SG_S)*/
  id
  bulk collect into v_res
  from stock_group_permission z
  where 1 = 1
  --!_!and id = p_id
  --!_!and stock_id = p_stock_id
  --!_!and stock_group_id = p_stock_group_id
  and user_id = p_user_id
  order by id
    ;
    ------------------------------
  else
    ------------------------------
    select /*+ full(z)*/
  id
  bulk collect into v_res
  from stock_group_permission z
  where 1 = 1
  --!_!and id = p_id
  --!_!and stock_id = p_stock_id
  --!_!and stock_group_id = p_stock_group_id
  --!_!and user_id = p_user_id
  order by id
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm__get
(
    p_user_id nvarchar2, --!_!
    p_stock_group_id number,
    p_stock_id number,
    p_stock_permission_rec out sys_refcursor,
    p_error_code out number
)
is
  v_date date := sysdate;
  v_user_id users.user_id%type := null;
  v_stock_group_id number := make_any_as_null(p_stock_group_id);
  v_stock_id number := make_any_as_null(p_stock_id);
  v_ids ct_number;
  v_cnt_opt number;
  v_cnt_act number;
begin
  ------------------------------
  if p_user_id is not null
  then
    v_user_id := util_stock.xget_user_id(p_user_id);
  end if;
  ------------------------------
  v_cnt_opt := install_pkg.nnget_option_num(c_sett_perm_use_hash_threshold, c_def_perm_use_hash_threshold);
  ------------------------------
  v_ids := get_stock_group_permission_ids
  (
    p_id => NULL,
    p_stock_id => v_stock_id,
    p_stock_group_id => v_stock_group_id,
    p_user_id => v_user_id
  );
  ------------------------------
  v_cnt_act := util_pkg.get_count_ct_number(v_ids);
  ------------------------------
  if v_cnt_act >= v_cnt_opt
  then
    get_result_cursor002(v_ids, v_date, p_stock_permission_rec);
  else
    get_result_cursor001(v_ids, v_date, p_stock_permission_rec);
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure stock_group_perm__ins
(
    p_sa nvarchar2,
    p_user_id nvarchar2,
    p_stock_group_id number,
    p_stock_id number,
    p_permission_mask number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
  v_user_id users.user_id%type;
  v_id stock_group_permission.id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  v_user_id := util_stock.xget_user_id(p_user_id);
  ------------------------------
  v_id := stock_group_perm_ins_i
  (
    p_sa_user_id => v_sa_user_id,
    p_user_id => v_user_id,
    p_stock_group_id => p_stock_group_id,
    p_stock_id => p_stock_id,
    p_permission_mask => p_permission_mask,
    p_del_prev => TRUE
  );
  ------------------------------
  util_loc_pkg.touch_number(v_id);
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm__del
(
    p_sa nvarchar2,
    p_user_id nvarchar2,
    p_stock_group_id number,
    p_stock_id number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
  v_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  v_user_id := util_stock.xget_user_id(p_user_id);
  ------------------------------
  stock_group_perm_del2_i
  (
    p_sa_user_id => v_sa_user_id,
    p_user_id => v_user_id,
    p_stock_group_id => p_stock_group_id,
    p_stock_id => p_stock_id
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_perm__upd
(
    p_sa nvarchar2,
    p_user_id nvarchar2,
    p_stock_group_id number,
    p_stock_id number,
    p_permission_mask number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
  v_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  v_user_id := util_stock.xget_user_id(p_user_id);
  ------------------------------
  stock_group_perm_upd2_i
  (
    p_sa_user_id => v_sa_user_id,
    p_user_id => v_user_id,
    p_stock_group_id => p_stock_group_id,
    p_stock_id => p_stock_id,
    p_permission_mask => p_permission_mask
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users__copy_privileges
(
    p_sa nvarchar2,
    p_user_name_from nvarchar2,
    p_user_name_to nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
  v_user_id_from users.user_id%type;
  v_user_id_to users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  v_user_id_from := util_stock.xget_user_id(p_user_name_from);
  v_user_id_to := util_stock.xget_user_id(p_user_name_to);
  ------------------------------
  stock_group_perm_copy_i
  (
    p_sa_user_id => v_sa_user_id,
    p_user_id_from => v_user_id_from,
    p_user_id_to => v_user_id_to
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure stock_group_dperm__get
(
    p_user_id nvarchar2, --!_!
    p_stock_group_id number,
    p_stock_id number,
    p_stock_date_permission_rec out sys_refcursor,
    p_error_code out number
)
is
  v_date date := sysdate;
  v_user_id users.user_id%type := null;
  v_stock_group_id number := make_any_as_null(p_stock_group_id);
  v_stock_id number := make_any_as_null(p_stock_id);
  v_ids ct_number;
  v_cnt_opt number;
  v_cnt_act number;
begin
  ------------------------------
  if p_user_id is not null
  then
    v_user_id := util_stock.xget_user_id(p_user_id);
  end if;
  ------------------------------
  v_cnt_opt := install_pkg.nnget_option_num(c_sett_perm_use_hash_threshold, c_def_perm_use_hash_threshold);
  ------------------------------
  v_ids := get_stock_group_permission_ids
  (
    p_id => NULL,
    p_stock_id => v_stock_id,
    p_stock_group_id => v_stock_group_id,
    p_user_id => v_user_id
  );
  ------------------------------
  v_cnt_act := util_pkg.get_count_ct_number(v_ids);
  ------------------------------
  if v_cnt_act >= v_cnt_opt
  then
    get_result_cursor004(v_ids, v_date, p_stock_date_permission_rec);
  else
    get_result_cursor003(v_ids, v_date, p_stock_date_permission_rec);
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_dperm__get2
(
    p_user_id nvarchar2, --!_!
    p_stock_group_id number,
    p_stock_id number,
    p_stock_date_permission_rec out sys_refcursor,
    p_error_code out number
)
is
begin
  ------------------------------
  stock_group_dperm__get
  (
    p_user_id => p_user_id,
    p_stock_group_id => p_stock_group_id,
    p_stock_id => p_stock_id,
    p_stock_date_permission_rec => p_stock_date_permission_rec,
    p_error_code => p_error_code
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure stock_group_dperm__ins
(
    p_sa nvarchar2,
    p_stock_group_permission_id number,
    p_start_date date,
    p_end_date date,
    p_description nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
  v_id user_stock_time_privilege.id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  ------------------------------
  v_id := user_stock_time_priv_ins_i
  (
    p_sa_user_id => v_sa_user_id,
    p_stock_group_permission_id => p_stock_group_permission_id,
    p_start_date => p_start_date,
    p_end_date => p_end_date,
    p_description => p_description
  );
  ------------------------------
  util_loc_pkg.touch_number(v_id);
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_dperm__del
(
    p_sa nvarchar2,
    p_id number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  ------------------------------
  user_stock_time_priv_del_i
  (
    p_sa_user_id => v_sa_user_id,
    p_id => p_id
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure stock_group_dperm__upd
(
    p_sa nvarchar2,
    p_id number,
    p_start_date date,
    p_end_date date,
    p_description nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  ------------------------------
  user_stock_time_priv_upd_i
  (
    p_sa_user_id => v_sa_user_id,
    p_id => p_id,
    --!_!p_stock_group_permission_id => p_stock_group_permission_id,
    p_start_date => p_start_date,
    p_end_date => p_end_date,
    p_description => p_description
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure user_stocks__stockowners
(
    p_user_id nvarchar2,
    p_stock_owners_rec out sys_refcursor,
    p_error_code out number
)
is
  v_date date := sysdate;
  v_user_id users.user_id%type;
  v_stock_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user_id);
  ------------------------------
  --!_! util_stock.c_perm_view - JUST BECAUSE
  ------------------------------
  v_stock_ids := util_stock.get_avail_stock_ids(v_user_id, util_stock.c_perm_view, v_date);
  ------------------------------
  util_stock.get_result_cursor008(v_stock_ids, v_date, p_stock_owners_rec);
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  --!_!raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure user_stocks__get
(
    p_user_id nvarchar2,
    p_permission_mask number,
    p_user_stocks_rec out sys_refcursor,
    p_error_code out number
)
is
  v_date date := sysdate;
  v_user_id users.user_id%type;
  v_stock_perms ct_node;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_permission_mask is null, 'p_permission_mask');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user_id);
  ------------------------------
  --!_! c_perm_not_none = -1
  ------------------------------
  v_stock_perms := util_stock.get_stock_perms_i(v_user_id, v_date, p_permission_mask, TRUE);
  ------------------------------
  util_stock.get_result_cursor003(v_stock_perms, v_date, p_user_stocks_rec);
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_readable_stocks
(
    p_user_id nvarchar2,
    p_readable_stocks_rec out sys_refcursor,
    p_error_code out number
)
is
begin
  ------------------------------
  user_stocks__get
  (
    p_user_id => p_user_id,
    p_permission_mask => util_stock.c_perm_view,
    p_user_stocks_rec => p_readable_stocks_rec,
    p_error_code => p_error_code
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_stock_permissions_for_user
(
    p_stock_code util_pkg.cit_nvarchar_s,
    p_user_name varchar2,
    p_user_permis_stock_info out sys_refcursor,
    p_error_message out varchar2,
    p_error_code out number
)
is
  v_date date := sysdate;
  v_user_id users.user_id%type;
  v_stock_codes ct_nvarchar_s;
  v_stock_perms ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_cit_nvarchar_s(p_stock_code, 'p_stock_code');
  util_pkg.XCheck_Cond_Missing(p_user_name is null, 'p_user_name');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user_name);
  ------------------------------
  v_stock_codes := util_pkg.cast_cit2ct_nvarchar_s(p_stock_code, TRUE);
  ------------------------------
  v_stock_perms := util_stock.get_stock_perms2_exact(v_user_id, v_stock_codes, v_date);
  ------------------------------
  util_stock.get_result_cursor007(v_stock_codes, v_stock_perms, v_date, FALSE, p_user_permis_stock_info);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure user_update_profile_i
(
  p_user_id number,
  p_user_profile_id number,
  p_sa_user_id number
)
is
  v_uprofile_ids ct_number;
  --
  v_user_profile_id_tmp number;
  v_change_user_profile_id boolean;
begin
  ------------------------------
  v_uprofile_ids := get_profile_ids_i;
  ------------------------------
  if make_as_empty_user_profile_id(p_user_profile_id) = v_uprofile_ids(2) --!_!
  then
    ------------------------------
    v_user_profile_id_tmp := make_as_null_user_profile_id(v_uprofile_ids(2));
    v_change_user_profile_id := true;
    ------------------------------
  elsif make_as_empty_user_profile_id(p_user_profile_id) = v_uprofile_ids(2) --!_!
  then
    ------------------------------
    v_user_profile_id_tmp := make_as_null_user_profile_id(v_uprofile_ids(1));
    v_change_user_profile_id := true;
    ------------------------------
  else
    ------------------------------
    v_change_user_profile_id := false;
    ------------------------------
  end if;
  ------------------------------
  if v_change_user_profile_id
  then
    ------------------------------
    users_upd_user_profile_id_i
    (
      p_sa_user_id => p_sa_user_id,
      p_user_id => p_user_id,
      p_user_profile_id => v_user_profile_id_tmp
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_insert_i
(
    p_execute_user_id number,
    p_user_name nvarchar2,
    p_user_profile_id number,
    p_name nvarchar2
)
is
begin
  ------------------------------
  users_ins2_i
  (
    p_sa_user_id => p_execute_user_id,
    p_user_name => p_user_name,
    p_user_profile_id => p_user_profile_id,
    p_name => p_name
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_update_i
(
    p_execute_user_id number,
    p_user_id number,
    p_user_profile_id number,
    p_name nvarchar2
)
is
begin
  ------------------------------
  util_loc_pkg.touch_nvarchar(p_name);
  ------------------------------
  user_update_profile_i
  (
    p_user_id => p_user_id,
    p_user_profile_id => p_user_profile_id,
    p_sa_user_id => p_execute_user_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure users_update_is_active_i
(
    p_execute_user_id number,
    p_user_id number,
    p_is_active number
)
is
begin
  ------------------------------
  users_upd_is_active_i
  (
    p_sa_user_id => p_execute_user_id,
    p_user_id => p_user_id,
    p_is_active => p_is_active
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_user_profile_id_common return number
is
begin
  ------------------------------
  return make_as_empty_user_profile_id(install_pkg.nnget_option_num(c_sett_user_profile_id_common, c_def_user_profile_id_common));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_user_profile_id_crm return number
is
begin
  ------------------------------
  return install_pkg.xget_option_num(c_sett_user_profile_id_crm);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ctl_user_info(p_coll ctl_user_info) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user
(
    p_user_id number
) return ctl_users
is
begin
  ------------------------------
  return get_users(p_user_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_ctl_user_info(p_coll ctl_user_info, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(util_pkg.c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(util_pkg.c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(util_pkg.c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(util_pkg.c_msg_v_i || v_i || util_pkg.c_msg_delim02 || util_pkg.nchar_to_char(p_coll(v_i).user_name) || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_coll(v_i).user_profile_id) || util_pkg.c_msg_delim02 || util_pkg.nchar_to_char(p_coll(v_i).person_name));
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! p_map1 - user_types, p_map2 - user_profile_ids
function get_ctl_user_info(p_pivot_filter ct_number, p_map1 ct_number, p_map2 ct_number, p_user_types ct_number, p_user_names ct_nvarchar, p_person_names ct_nvarchar) return ctl_user_info
is
  v_res ctl_user_info;
  v_pivot ct_number;
  v_user_types ct_number;
  v_user_names ct_nvarchar;
  v_person_names ct_nvarchar;
  v_main_count number;
  v_main_count2 number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_user_types);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_user_types) != v_main_count, 'util_pkg.get_count_ct_number(p_user_types) != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar(p_user_names) != v_main_count, 'util_pkg.get_count_ct_nvarchar(p_user_names) != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar(p_person_names) != v_main_count, 'util_pkg.get_count_ct_nvarchar(p_person_names) != v_main_count');
  ------------------------------
  v_main_count2 := util_pkg.get_count_ct_number(p_map1);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_map1) != v_main_count2, 'util_pkg.get_count_ct_number(p_map1) != v_main_count2');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_map2) != v_main_count2, 'util_pkg.get_count_ct_number(p_map2) != v_main_count2');
  ------------------------------
  if v_main_count = 0
  then
    return v_res;
  end if;
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  v_user_types := util_pkg.filter_ct_number(p_user_types, v_pivot, p_pivot_filter, true);
  v_user_names := util_pkg.filter_ct_nvarchar(p_user_names, v_pivot, p_pivot_filter, true);
  v_person_names := util_pkg.filter_ct_nvarchar(p_person_names, v_pivot, p_pivot_filter, true);
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3, m1, m2)*/
    q2.user_name,
    make_as_null_user_profile_id(m2.val) user_profile_id,
    q3.person_name
    bulk collect into v_res
    from
      (select column_value user_type, rownum rn from table(v_user_types)) q1,
      (select column_value user_name, rownum rn from table(v_user_names)) q2,
      (select column_value person_name, rownum rn from table(v_person_names)) q3,
      (select column_value val, rownum rn from table(p_map1)) m1,
      (select column_value val, rownum rn from table(p_map2)) m2
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    and m1.val(+) = q1.user_type
    and m2.rn(+) = m1.rn
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure filter_users(p_filter_type number, p_types ct_number, p_vals ct_nvarchar, p_pivot out ct_number, p_vals_out out ct_nvarchar)
is
  lc_no_value constant nvarchar2(1) := NULL;
  v_marks ct_number;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_types);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_types) != v_main_count, 'util_pkg.get_count_ct_number(p_types) != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar(p_vals) != v_main_count, 'util_pkg.get_count_ct_nvarchar(p_vals) != v_main_count');
  ------------------------------
  p_pivot := null;
  p_vals_out := null;
  ------------------------------
  if v_main_count = 0
  then
    return;
  end if;
  ------------------------------
  p_pivot := util_pkg.make_pivot(util_pkg.get_count_ct_number(p_types));
  ------------------------------
  p_vals_out := util_pkg.upper_ct_nvarchar(p_vals); --!_! pivot is NOT changed
  ------------------------------
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_types, p_filter_type);
  ------------------------------
  p_pivot := util_pkg.get_marked_ct_number(p_pivot, v_marks, TRUE);
  p_vals_out := util_pkg.get_marked_ct_nvarchar(p_vals_out, v_marks, TRUE);
  ------------------------------
  ------------------------------
  p_vals_out := util_pkg.unique_ct_nvarchar(p_vals_out, TRUE, FALSE, lc_no_value); --!_! pivot IS CHANGED
  ------------------------------
  v_marks := util_pkg.mark_val_ct_nvarchar(p_vals_out, lc_no_value, util_pkg.C_FALSE, util_pkg.C_TRUE); --!_! reverse marking
  ------------------------------
  p_pivot := util_pkg.get_marked_ct_number(p_pivot, v_marks, TRUE);
  p_vals_out := util_pkg.get_marked_ct_nvarchar(p_vals_out, v_marks, TRUE);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_utypes_i return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_res, c_ext_user_type_COMMON);
  util_pkg.add_ct_number_val(v_res, c_ext_user_type_CRM);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_profile_ids_i return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_res, get_user_profile_id_common);
  util_pkg.add_ct_number_val(v_res, xget_user_profile_id_crm);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_users_i
(
  p_user_types ct_number,
  p_user_names ct_nvarchar,
  p_map1 out ct_number,
  p_map2 out ct_number,
  p_unames_uni_other out ct_nvarchar,
  p_pivot_other out ct_number
)
is
  v_main_count number;
  --
  v_utypes ct_number;
  v_uprofile_ids ct_number;
  --
  v_marks ct_number;
  --
  v_pivot_other_common ct_number;
  v_pivot_other_crm ct_number;
  --
  v_unames_uni_other_common ct_nvarchar;
  v_unames_uni_other_crm ct_nvarchar;
begin
  ------------------------------
  v_utypes := get_utypes_i;
  v_uprofile_ids := get_profile_ids_i;
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(v_utypes);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_utypes) != v_main_count, 'util_pkg.get_count_ct_number(v_utypes) != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_uprofile_ids) != v_main_count, 'util_pkg.get_count_ct_number(v_uprofile_ids) != v_main_count');
  ------------------------------
  filter_users(v_utypes(1), p_user_types, p_user_names, v_pivot_other_common, v_unames_uni_other_common);
  filter_users(v_utypes(2), p_user_types, p_user_names, v_pivot_other_crm, v_unames_uni_other_crm);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    util_pkg.add_ct_number_val(p_map1, v_utypes(v_i));
    util_pkg.add_ct_number_val(p_map2, v_uprofile_ids(v_i));
  end loop;
  ------------------------------
  --!_!v_unames_uni_other_common := util_pkg.filter_val_ct_nvarchar(v_unames_uni_other_common, v_unames_uni_other_crm, FALSE); --!_! ordered MULTISET EXCEPT DISTINCT
  v_marks := util_pkg.mark_ct_nvarchar(v_unames_uni_other_common, v_unames_uni_other_crm, util_pkg.C_FALSE, util_pkg.C_TRUE); --!_! reverse marking
  v_pivot_other_common := util_pkg.get_marked_ct_number(v_pivot_other_common, v_marks, TRUE);
  v_unames_uni_other_common := util_pkg.get_marked_ct_nvarchar(v_unames_uni_other_common, v_marks, TRUE); --!_! ordered MULTISET EXCEPT DISTINCT
  ------------------------------
  p_unames_uni_other := v_unames_uni_other_common;
  util_pkg.add_ct_nvarchar(p_unames_uni_other, v_unames_uni_other_crm); --!_! ordered MULTISET UNION ALL
  ------------------------------
  p_pivot_other := v_pivot_other_common;
  util_pkg.add_ct_number(p_pivot_other, v_pivot_other_crm); --!_! ordered MULTISET UNION ALL
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure synchronize_users_i
(
    p_execute_user_id users.user_id%type,
    p_user_types ct_number,
    p_user_names ct_nvarchar,
    p_person_names ct_nvarchar,
    p_new_users_pivot out ct_number,
    p_upd_users_pivot out ct_number,
    p_multiple_err_users_pivot out ct_number
)
is
  lc_no_value constant nvarchar2(1) := NULL;
  --
  v_unames_local ct_nvarchar;
  v_unames_local_mult ct_nvarchar;
  --
  v_pivot_other ct_number;
  v_unames_uni_other ct_nvarchar;
  v_unames_uni_local ct_nvarchar;
  --
  v_marks ct_number;
  --
  v_user_info ctl_user_info;
  v_map1 ct_number;
  v_map2 ct_number;
  --
  v_unames_tmp ct_nvarchar;
  v_users_tmp ctl_users;
  v_users_rec_tmp users%rowtype;
  v_user_id_tmp number;
  --
  v_main_count number;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_execute_user_id is null, 'p_execute_user_id');
  util_pkg.XCheckP_ct_number(p_user_types, 'p_user_types');
  util_pkg.XCheckP_ct_nvarchar(p_user_names, 'p_user_names');
  util_pkg.XCheckP_ct_nvarchar(p_person_names, 'p_person_names');
  ------------------------------
  v_main_count := p_user_types.count;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_user_types.count != v_main_count, 'p_user_types.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_user_names.count != v_main_count, 'p_user_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_person_names.count != v_main_count, 'p_person_names.count != v_main_count');
  ------------------------------
  util_stock.xcheck_user_id(p_execute_user_id);
  ------------------------------
  prepare_users_i(p_user_types, p_user_names, v_map1, v_map2, v_unames_uni_other, v_pivot_other);
  ------------------------------
  v_unames_local := get_user_names_i
  (
    p_date => sysdate,
    p_to_upper => TRUE, --!_!
    p_active => NULL
  );
  ------------------------------
  --!_! 0. errore when multiple present in local
  ------------------------------
  v_unames_uni_local := util_pkg.unique_ct_nvarchar(v_unames_local, TRUE, FALSE, lc_no_value);
  ------------------------------
  v_marks := util_pkg.mark_val_ct_nvarchar(v_unames_uni_local, lc_no_value, util_pkg.C_TRUE, util_pkg.C_FALSE);
  ------------------------------
  v_unames_local_mult := util_pkg.get_marked_ct_nvarchar(v_unames_local, v_marks, TRUE);
  ------------------------------
  if util_pkg.get_count_ct_nvarchar(v_unames_local_mult) > 0
  then
    ------------------------------
    v_marks := util_pkg.mark_ct_nvarchar(v_unames_uni_other, v_unames_local_mult, util_pkg.C_TRUE, util_pkg.C_FALSE);
    ------------------------------
    p_multiple_err_users_pivot := util_pkg.get_marked_ct_number(v_pivot_other, v_marks, TRUE);
    ------------------------------
    v_marks := util_pkg.mark_ct_nvarchar(v_unames_local, v_unames_local_mult, util_pkg.C_TRUE, util_pkg.C_FALSE);
    ------------------------------
    v_unames_uni_local := util_pkg.get_marked_ct_nvarchar(v_unames_local, v_marks, TRUE, util_pkg.C_FALSE);
    ------------------------------
  end if;
  ------------------------------
  --!_! 1. present in other, NOT present in local
  ------------------------------
  --!_!v_unames_uni_temp := util_pkg.filter_val_ct_nvarchar(v_unames_uni_other, v_unames_uni_local, FALSE); --!_! ordered MULTISET EXCEPT DISTINCT
  v_marks := util_pkg.mark_ct_nvarchar(v_unames_uni_other, v_unames_local, util_pkg.C_FALSE, util_pkg.C_TRUE); --!_! reverse marking
  p_new_users_pivot := util_pkg.get_marked_ct_number(v_pivot_other, v_marks, TRUE);
  ------------------------------
  v_user_info := get_ctl_user_info(p_new_users_pivot, v_map1, v_map2, p_user_types, p_user_names, p_person_names);
  ------------------------------
  if get_count_ctl_user_info(v_user_info) > 0
  then
    ------------------------------
    for v_i in v_user_info.first..v_user_info.last
    loop
      ------------------------------
      users_insert_i
      (
        p_execute_user_id => p_execute_user_id,
        p_user_name => v_user_info(v_i).user_name,
        p_user_profile_id => v_user_info(v_i).user_profile_id,
        p_name => v_user_info(v_i).person_name
      );
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
  --!_! 2. present in Other, present in local(and unique in local)
  ------------------------------
  --!_!v_unames_uni_temp := util_pkg.filter_val_ct_nvarchar(v_unames_uni_other, v_unames_uni_local, TRUE); --!_! ordered MULTISET INTERSECT DISTINCT
  v_marks := util_pkg.mark_ct_nvarchar(v_unames_uni_other, v_unames_uni_local, util_pkg.C_TRUE, util_pkg.C_FALSE); --!_! direct marking
  p_upd_users_pivot := util_pkg.get_marked_ct_number(v_pivot_other, v_marks, TRUE);
  ------------------------------
  v_user_info := get_ctl_user_info(p_upd_users_pivot, v_map1, v_map2, p_user_types, p_user_names, p_person_names);
  ------------------------------
  if get_count_ctl_user_info(v_user_info) > 0
  then
    ------------------------------
    for v_i in v_user_info.first..v_user_info.last
    loop
      ------------------------------
      v_user_id_tmp := util_stock.xget_user_id(v_user_info(v_i).user_name);
      ------------------------------
      v_users_tmp := get_user
      (
        p_user_id => v_user_id_tmp
      );
      ------------------------------
      if get_count_ctl_users(v_users_tmp) = 0
      then
        ------------------------------
        util_pkg.raise_exception(util_pkg.c_ora_user_not_found, util_pkg.c_msg_user_not_found || util_pkg.c_msg_delim01 || util_pkg.number_to_char(v_user_id_tmp));
        ------------------------------
      end if;
      ------------------------------
      v_users_rec_tmp := v_users_tmp(v_users_tmp.first);
      ------------------------------
      users_update_i
      (
        p_execute_user_id => p_execute_user_id,
        p_user_id => v_user_id_tmp,
        p_user_profile_id => v_user_info(v_i).user_profile_id,
        p_name => v_user_info(v_i).person_name
      );
      ------------------------------
      users_update_is_active_i
      (
        p_execute_user_id => p_execute_user_id,
        p_user_id => v_user_id_tmp,
        p_is_active => util_pkg.C_TRUE
      );
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
  --!_! 3. NOT present in Other, present in local(and uniq in local)
  ------------------------------
  --!_!v_unames_uni_temp := util_pkg.filter_val_ct_nvarchar(v_unames_uni_local, v_unames_uni_other, FALSE); --!_! ordered MULTISET EXCEPT DISTINCT
  v_marks := util_pkg.mark_ct_nvarchar(v_unames_uni_local, v_unames_uni_other, util_pkg.C_FALSE, util_pkg.C_TRUE); --!_! reverse marking
  v_unames_tmp := util_pkg.get_marked_ct_nvarchar(v_unames_uni_local, v_marks, TRUE);
  ------------------------------
  if util_pkg.get_count_ct_nvarchar(v_unames_tmp) > 0
  then
    ------------------------------
    for v_i in v_unames_tmp.first..v_unames_tmp.last
    loop
      ------------------------------
      users_update_is_active_i
      (
        p_execute_user_id => p_execute_user_id,
        p_user_id => util_stock.xget_user_id(v_unames_tmp(v_i)),
        p_is_active => util_pkg.C_FALSE
      );
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure synchronize_stock_users
(
    p_sa nvarchar2,
    p_user_types util_pkg.cit_number,
    p_user_names util_pkg.cit_nvarchar,
    p_person_names util_pkg.cit_nvarchar,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_sa_user_id users.user_id%type;
  v_main_count number;
  --
  v_new_users_pivot ct_number;
  V_upd_users_pivot ct_number;
  v_multiple_err_users_pivot ct_number;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_sa is null, 'p_sa');
  util_pkg.XCheckP_cit_number(p_user_types, 'p_user_types');
  util_pkg.XCheckP_cit_nvarchar(p_user_names, 'p_user_names');
  util_pkg.XCheckP_cit_nvarchar(p_person_names, 'p_person_names');
  ------------------------------
  v_main_count := p_user_types.count;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_user_types.count != v_main_count, 'p_user_types.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_user_names.count != v_main_count, 'p_user_names.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_person_names.count != v_main_count, 'p_person_names.count != v_main_count');
  ------------------------------
  v_sa_user_id := util_stock.xget_user_id(p_sa);
  ------------------------------
  synchronize_users_i
  (
    p_execute_user_id => v_sa_user_id,
    p_user_types => util_pkg.cast_cit2ct_number(p_user_types, true),
    p_user_names => util_pkg.cast_cit2ct_nvarchar(p_user_names, true),
    p_person_names => util_pkg.cast_cit2ct_nvarchar(p_person_names, true),
    p_new_users_pivot => v_new_users_pivot,
    p_upd_users_pivot => v_upd_users_pivot,
    p_multiple_err_users_pivot => v_multiple_err_users_pivot
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_result_cursor001(p_sgp_ids ct_number, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ ordered use_nl(q, sgp, u, sg, s)
  index_asc(sgp, PK_STOCK_GROUP_PERMISSION)
  index_asc(u, PK_USERS)
  index_asc(sg, PK_STOCK_GROUP)
  index_asc(s, PK_STOCK)
  */
  sgp.id,
  u.user_name user_id,
  sgp.stock_group_id,
  sgp.stock_id,
  sgp.permission_mask,
  u.surname || ' ' || u.name person_name,
  sg.name stock_group_name,
  s.name stock_name,
  sgp.user_id user_id2
  from
    (select column_value id, rownum rn from table(p_sgp_ids)) q,
    stock_group_permission sgp,
    users u,
    stock_group sg,
    stock s
  where 1 = 1
  and sgp.id(+) = q.id
  and u.user_id(+) = sgp.user_id
  and sg.id(+) = sgp.stock_group_id
  and s.id(+) = sgp.stock_id
  and nvl(u.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  and nvl(s.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor002(p_sgp_ids ct_number, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q, sgp, u, sg, s)
  full(sgp)
  full(u)
  full(sg)
  full(s)
  */
  sgp.id,
  u.user_name user_id,
  sgp.stock_group_id,
  sgp.stock_id,
  sgp.permission_mask,
  u.surname || ' ' || u.name person_name,
  sg.name stock_group_name,
  s.name stock_name,
  sgp.user_id user_id2
  from
    (select column_value id, rownum rn from table(p_sgp_ids)) q,
    stock_group_permission sgp,
    users u,
    stock_group sg,
    stock s
  where 1 = 1
  and sgp.id(+) = q.id
  and u.user_id(+) = sgp.user_id
  and sg.id(+) = sgp.stock_group_id
  and s.id(+) = sgp.stock_id
  and nvl(u.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  and nvl(s.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor003(p_sgp_ids ct_number, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ ordered use_nl(q, sgp, u, sg, s)
  index_asc(sgp, PK_STOCK_GROUP_PERMISSION)
  index_asc(u, PK_USERS)
  index_asc(sg, PK_STOCK_GROUP)
  index_asc(s, PK_STOCK)
  index_asc(ustp, I_USER_STOCK_TIME_PRV)
  */
  ustp.id "Id",
  u.user_name "Username",
  ustp.start_date "Start date",
  ustp.end_date "End date",
  ustp.description "Description",
  sgp.stock_group_id "Stock group id",
  sgp.stock_id "Stock id",
  sgp.permission_mask "Privilege mask"
  from
    (select column_value id, rownum rn from table(p_sgp_ids)) q,
    stock_group_permission sgp,
    users u,
    stock_group sg,
    stock s,
    user_stock_time_privilege ustp
  where 1 = 1
  and sgp.id(+) = q.id
  and u.user_id(+) = sgp.user_id
  and sg.id(+) = sgp.stock_group_id
  and s.id(+) = sgp.stock_id
  and ustp.stock_group_permission_id(+) = q.id
  and nvl(u.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  and nvl(s.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  --!_!and p_date between nvl(ustp.start_date, p_date) and nvl(ustp.end_date, p_date) --!_!not (+)
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor004(p_sgp_ids ct_number, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q, sgp, u, sg, s, ustp)
  full(sgp)
  full(u)
  full(sg)
  full(s)
  full(ustp)
  */
  ustp.id "Id",
  u.user_name "Username",
  ustp.start_date "Start date",
  ustp.end_date "End date",
  ustp.description "Description",
  sgp.stock_group_id "Stock group id",
  sgp.stock_id "Stock id",
  sgp.permission_mask "Privilege mask"
  from
    (select column_value id, rownum rn from table(p_sgp_ids)) q,
    stock_group_permission sgp,
    users u,
    stock_group sg,
    stock s,
    user_stock_time_privilege ustp
  where 1 = 1
  and sgp.id(+) = q.id
  and u.user_id(+) = sgp.user_id
  and sg.id(+) = sgp.stock_group_id
  and s.id(+) = sgp.stock_id
  and ustp.stock_group_permission_id(+) = q.id
  and nvl(u.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  and nvl(s.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  --!_!and p_date between nvl(ustp.start_date, p_date) and nvl(ustp.end_date, p_date) --!_!not (+)
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor005(p_po_ids ct_number, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_nl(q, po, pog) index_asc(po, PK_PROGRAM_OBJECT) index_asc(pog, PK_PROGRAM_OBJECT_GROUP)*/
  po.id "Id",
  po.name "Name",
  po.program_object_group_id "Group Id",
  pog.name "Group Name"
  from
    (select column_value id from table(p_po_ids)) q,
    program_object po,
    program_object_group pog
  where 1 = 1
  and po.id(+) = q.id
  and pog.id(+) = po.program_object_group_id
  --!_!order by q.rn
  order by po.program_object_group_id, po.name
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor006(p_poa_ids ct_number, p_user_profile_id number, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_nl(q, poa, pop) index_asc(poa, PK_PROGRAM_OBJECT_ACTION) index_asc(pop, I_PROGRAM_OBJECT_PERMISSION)*/
  pop.user_profile_id "User profile",
  poa.program_object_id "Object Id",
  poa.action_id "Action Id",
  pop.enabled "Enabled",
  pop.program_object_action_id "Program object action Id"
  from
    (select column_value id, p_user_profile_id user_profile_id, rownum rn from table(p_poa_ids)) q,
    program_object_action poa,
    program_object_permission pop
  where 1 = 1
  and poa.id(+) = q.id
  and pop.user_profile_id(+) = q.user_profile_id
  and pop.program_object_action_id(+) = q.id
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor007(p_poa_ids ct_number, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_nl(q, poa) use_hash(pop) index_asc(poa, PK_PROGRAM_OBJECT_ACTION) full(pop)*/
  pop.user_profile_id "User profile",
  poa.program_object_id "Object Id",
  poa.action_id "Action Id",
  pop.enabled "Enabled",
  pop.program_object_action_id "Program object action Id"
  from
    (select column_value id, rownum rn from table(p_poa_ids)) q,
    program_object_action poa,
    program_object_permission pop
  where 1 = 1
  and poa.id(+) = q.id
  --!_!and pop.user_profile_id(+) = q.user_profile_id
  and pop.program_object_action_id(+) = q.id
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor008(p_user_id number, p_date date, p_is_active boolean, p_result out sys_refcursor)
is
  v_is_active number := util_pkg.bool_to_int_3val(p_is_active);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ ordered use_nl(u, s, up)
  index_asc(u, PK_USERS)
  index_asc(s, PK_STOCK)
  index_asc(up, PK_USER_PROFILE)
  */
  u.user_name,
  u.user_profile_id,
  u.name,
  u.surname,
  u.password,
  u.home_stock_id,
  s.name home_stock_name,
  s.max_series_qty,
  s.alert_series_qnt,
  s.validation_date,
  s.fiscale_date,
  s.code home_stock_code,
  up.name user_profile_name,
  u.is_active active
  from users u, stock s, user_profile up
  where 1 = 1
  and u.user_id = p_user_id
  and (v_is_active is null or u.is_active = v_is_active)
  and s.id(+) = u.home_stock_id
  and up.id(+) = u.user_profile_id
  and nvl(u.deleted, p_date + util_stock.c_dummy_date_shift) > p_date
  and nvl(s.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  order by u.user_name
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor009(p_date date, p_is_active boolean, p_result out sys_refcursor)
is
  v_is_active number := util_pkg.bool_to_int_3val(p_is_active);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ ordered use_hash(u, s, up)
  full(u)
  full(s)
  full(up)
  */
  u.user_name,
  u.user_profile_id,
  u.name,
  u.surname,
  u.password,
  u.home_stock_id,
  s.name home_stock_name,
  s.max_series_qty,
  s.alert_series_qnt,
  s.validation_date,
  s.fiscale_date,
  s.code home_stock_code,
  up.name user_profile_name,
  u.is_active active
  from users u, stock s, user_profile up
  where 1 = 1
  and (v_is_active is null or u.is_active = v_is_active)
  and s.id(+) = u.home_stock_id
  and up.id(+) = u.user_profile_id
  and nvl(u.deleted, p_date + util_stock.c_dummy_date_shift) > p_date
  and nvl(s.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  order by u.user_name
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor010(p_up_id number, p_date date, p_is_active boolean, p_result out sys_refcursor)
is
  v_is_active number := util_pkg.bool_to_int_3val(p_is_active);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ index_asc(u, I_USERS_USER_PROFILE_ID)*/
  user_name,
  user_profile_id,
  name,
  surname,
  password,
  home_stock_id,
  is_active
  from users u
  where 1 = 1
  and user_profile_id = p_up_id
  and (v_is_active is null or is_active = v_is_active)
  and nvl(deleted, p_date + util_stock.c_dummy_date_shift) > p_date
  order by user_name
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor011(p_up_id number, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ index_asc(up, PK_USER_PROFILE)*/
  id,
  name,
  description
  from user_profile up
  where 1 = 1
  and id = p_up_id
  order by name
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor012(p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ full(up)*/
  id,
  name,
  description
  from user_profile up
  where 1 = 1
  order by name
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
