CREATE PACKAGE BODY pkg_services
IS
--******************************************************************************
-- Author  : Skripnik Petr
-- Created : 16.10.2006 14:05
-- Purpose : Cервисы периодических работ
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ----------------------------------------------
-- Petr Skripnik   09.11.2006  Изменен
-- Skripnik Petr   16.04.2007  version 1.11.8.2
-- Skripnik Petr   10.07.2007  version 1.11.9.0
--****************************************************************************--
   pkg_name   CONSTANT NVARCHAR2 (50) := 'pkg_services.';   --имя пакета

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 13.02.2007 11:42
-- Editor  :
-- Changed :
-- Purpose : Удалить формат выгрузки в файл
--------------------------------------------------------------------------------
   PROCEDURE del_format (p_id IN NUMBER, p_user IN NVARCHAR2)
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'del_format';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                         '(' || p_id || pkg_constants.c_delimiter || p_user || ')',
                         pkg_name
                        );

      DELETE FROM format
            WHERE ID = p_id;

      util_stock.log_log(p_user, util_stock.c_la_format_delete, p_id);

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END del_format;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 12.02.2007 15:56
-- Editor  :
-- Changed :
-- Purpose : Получить формат
--------------------------------------------------------------------------------
   PROCEDURE get_format (p_id IN NUMBER, p_cur OUT sys_refcursor, p_error_code OUT NUMBER)
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_format';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name, '(' || p_id || ')', pkg_name);
      --Установим код ошибки в ноль
      p_error_code := 0;

      OPEN p_cur FOR
         SELECT f.ID, NAME, f.description, f.equipment_type_id, f.TEMPLATE, et.equipment_type_name,
                et.system_type_code
           FROM format f, equipment_type et
          WHERE (f.ID = p_id OR p_id IS NULL) AND f.equipment_type_id = et.equipment_type_id;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_format;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 29.06.2007 12:36
-- Version :
--   1 29.06.2007
-- Modification : log_management.log__get
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE get_log (
      p_cur_log         OUT      sys_refcursor,
      p_user_id         IN       NVARCHAR2 DEFAULT NULL,
      p_tab_action_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_log';
      l_tab_action_id     ct_number       := ct_number ();
      l_cnt_action_id     NUMBER          DEFAULT 0;
      v_user_id number;
      v_user_name users.user_name%type;
      --v_user_name_obs log.user_id%type; --!_! don't work
      v_user_name_obs nvarchar2(50);
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || 'OUT'
                         || pkg_constants.c_delimiter
                         || p_user_id
                         || pkg_constants.c_delimiter
                         || p_tab_action_id.COUNT
                         || ')',
                         pkg_name
                        );

      util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id'); --!_! although DEFAULT NULL

      v_user_id := util_stock.xget_user_id(p_user_id);
      v_user_name := util_stock.xget_user_name(v_user_id);
      v_user_name_obs := util_stock.make_obsolete_user_name(v_user_name); --!_!

      IF p_tab_action_id.EXISTS (1)
      THEN
         FOR i IN p_tab_action_id.FIRST .. p_tab_action_id.LAST
         LOOP
            IF (p_tab_action_id.EXISTS (i)) AND (p_tab_action_id (i) IS NOT NULL)
            THEN
               l_tab_action_id.EXTEND;
               l_tab_action_id (l_tab_action_id.COUNT) := p_tab_action_id (i);
               pkg_db_util.DEBUG (prc_name, 'action_id = ' || p_tab_action_id (i), pkg_name);
            END IF;
         END LOOP;

         l_cnt_action_id := l_tab_action_id.COUNT;
      END IF;

      OPEN p_cur_log FOR
         SELECT /*+ ordered no_expand use_nl(l, la) index_asc(l, I_LOG_USER_ID) index_asc(la, PK_LOG_ACTION)*/
                l.ID "Id",
                l.log_date "Date",
                v_user_name "Administrator",
                la.NAME "Action",
                l.object_id "Object id",
                l.description "Description",
                l.action_id "Action id"
           FROM log l, log_action la
          WHERE 1 = 1
            AND l.user_id = v_user_name_obs
            AND nvl(l.user_id2, v_user_id) = v_user_id
            AND la.ID = l.action_id
            AND (l_cnt_action_id = 0 OR l.action_id IN (SELECT COLUMN_VALUE FROM TABLE (CAST (l_tab_action_id AS ct_number))))
          ORDER BY l.log_date DESC
      ;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_log;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 28.06.2007 13:14
-- Version :
--   1 28.06.2007
-- Modification : log_management.log__get_events
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE get_logaction (p_cur_logaction OUT sys_refcursor)
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_logaction';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      OPEN p_cur_logaction FOR
         SELECT ID, NAME
           FROM log_action;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_logaction;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 12.02.2007 15:56
-- Editor  :
-- Changed :
-- Purpose : Создает новый формат загрузки файла
--------------------------------------------------------------------------------
   PROCEDURE ins_format (
      p_name          IN       NVARCHAR2,
      p_description   IN       NVARCHAR2,
      p_eqm_type_id   IN       NUMBER,
      p_template      IN       NVARCHAR2,
      p_user          IN       NVARCHAR2,
      p_error_code    OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'ins_format';
      l_xmlrow            XMLTYPE;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_name
                         || pkg_constants.c_delimiter
                         || p_description
                         || pkg_constants.c_delimiter
                         || p_eqm_type_id
                         || pkg_constants.c_delimiter
                         || p_template
                         || pkg_constants.c_delimiter
                         || p_user
                         || ')',
                         pkg_name
                        );
      --Установим код ошибки в ноль
      p_error_code := 0;
      --Приведем строку к XML
      l_xmlrow := XMLTYPE.createxml (p_template);

      INSERT INTO format
                  (id, NAME, description, equipment_type_id, TEMPLATE
                  )
           VALUES (sq_format.nextval, p_name, p_description, p_eqm_type_id, l_xmlrow
                  );

      util_stock.log_log(p_user, util_stock.c_la_format_create, p_name);

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END ins_format;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 12.02.2007 15:56
-- Editor  :
-- Changed :
-- Purpose : Изменить формат выгрузки в файл
--------------------------------------------------------------------------------
   PROCEDURE upd_format (
      p_id            IN       NUMBER,
      p_name          IN       NVARCHAR2,
      p_description   IN       NVARCHAR2,
      p_eqm_type_id   IN       NUMBER,
      p_template      IN       NVARCHAR2,
      p_user          IN       NVARCHAR2,
      p_error_code    OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'upd_format';
      l_xmlrow            XMLTYPE;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_id
                         || pkg_constants.c_delimiter
                         || p_name
                         || pkg_constants.c_delimiter
                         || p_description
                         || pkg_constants.c_delimiter
                         || p_eqm_type_id
                         || pkg_constants.c_delimiter
                         || p_template
                         || pkg_constants.c_delimiter
                         || p_user
                         || ')',
                         pkg_name
                        );
      --Установим код ошибки в ноль
      p_error_code := 0;
      --Приведем строку к XML
      l_xmlrow := XMLTYPE.createxml (p_template);

      UPDATE format
         SET NAME = p_name,
             description = p_description,
             equipment_type_id = p_eqm_type_id,
             TEMPLATE = l_xmlrow
       WHERE ID = p_id;

      util_stock.log_log(p_user, util_stock.c_la_format_modify, p_id);

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END upd_format;
END;
/
