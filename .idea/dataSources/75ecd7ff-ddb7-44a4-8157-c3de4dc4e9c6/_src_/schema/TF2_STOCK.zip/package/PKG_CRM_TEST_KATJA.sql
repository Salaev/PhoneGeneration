CREATE PACKAGE             "PKG_CRM_TEST_KATJA" 
AS
--******************************************************************************
-- Author  : Skripnik Petr
-- Created : 22.06.2007 12:48
-- Modification : crm_management
-- Purpose : Work with the CRM
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ------------------------------------------
--******************************************************************************

   --------------------------------------------------------------------------------
-- Author  : Skripnik Petr (SP)
-- Created : 22.06.2007 11:53
-- Version : 1
-- Modification : crm_management.checksimcardsrange
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE check_sim_cards_range (
      p_stock_code    IN       NVARCHAR2,
      p_seria_start   IN       NVARCHAR2,
      p_seria_end     IN       NVARCHAR2,
      p_quantity      IN       NUMBER,
      p_range_found   OUT      NUMBER
   );

-------------------------------------------------------------------------------
-- Author  : Anoev Maxim
-- Created : 20.06.2007 14:00
-- Version : 1
-- Modification :
-- Editor  :
--   AM 20.07.2007 Crelice ao. drdelnd calincocernidia adodd neeraia ir ernnca
-- Changed :
-- Purpose : Dieo?rln neerau
--------------------------------------------------------------------------------
   PROCEDURE find_all_child_stocks (
      p_tab_stock_group_id   IN       pkg_common.t_num,
      p_user                 IN       NVARCHAR2,
      p_stock_rec            OUT      sys_refcursor,
      p_error_code           OUT      NUMBER
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.06.2007 15:10
-- Version : 1
-- Modification : stock_management.stock_group__get_child_groups
-- Editor  :
-- Changed :
-- Purpose : Dieo?rln adoddu neeraia ainnodiul dieuciarnlet a niinalnnnacc n ddrarec
--------------------------------------------------------------------------------
   PROCEDURE find_child_stock_groups (
      p_stock_group_id    IN       NUMBER,
      p_user              IN       NVARCHAR2,
      p_stock_group_rec   OUT      sys_refcursor,
      p_error_code        OUT      NUMBER
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.06.2007 15:00
-- Version : 1
-- Modification : stock_management.stock_group__get_stocks_2
-- Editor  :
-- Changed :
-- Purpose : Dieo?rln neerau ainnodiul dieuciarnlet a niinalnnnacc n ddrarec
--------------------------------------------------------------------------------
   PROCEDURE find_child_stocks (
      p_stock_group_id   IN       NUMBER,
      p_user             IN       NVARCHAR2,
      p_stock_rec        OUT      sys_refcursor,
      p_error_code       OUT      NUMBER
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 15.06.2007 14:57
-- Version : 1
-- Modification : crm_management.findequipment
-- Editor  :
-- Changed :
-- Purpose : Dicne iaidoaiaric? di oneiac?e a nleoule ninni?icc neerar
--------------------------------------------------------------------------------
   PROCEDURE find_equipment (
      p_seria_start        IN       NVARCHAR2,
      p_seria_end          IN       NVARCHAR2,
      p_comment_mask       IN       NVARCHAR2,
      p_min_val_date       IN       DATE,
      p_max_val_date       IN       DATE,
      p_equipment_number   IN       NUMBER,
      p_row_count          IN       NUMBER,
      p_unreserved         IN       NUMBER,
      p_cur_equipment      OUT      sys_refcursor,
      p_error_code         OUT      NUMBER
   );

-------------------------------------------------------------------------------
-- Author  : Anoev Maxim
-- Created : 27.10.2006 10:00
-- Version : 1
-- Modification :
-- Editor  :
-- Changed :
-- Purpose : Culn iaidoaiaricl di nleouleo ninni?ict neerar
--------------------------------------------------------------------------------
   PROCEDURE find_equipment_bulk (p_equipmenttable_rec OUT sys_refcursor, p_error_code OUT NUMBER);

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 08.11.2006 16:54
-- Version : 2
-- Modification :crm_management.find_sim_cards
-- Editor  :
-- Changed :
-- Purpose : Culn nce-erdnu di crariiue edcnldc?e
--------------------------------------------------------------------------------
   PROCEDURE find_sim_cards (
      p_user_name       IN       NVARCHAR2,
      p_only_free       IN       NUMBER,
      p_quantity        IN       NUMBER,
      p_seria_start     IN       NVARCHAR2,
      p_seria_end       IN       NVARCHAR2,
      p_cur_sim_cards   OUT      sys_refcursor,
      p_stock_code      IN       pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 08.11.2006 16:54
-- Version : 2
-- Modification :crm_management.find_sim_cards
-- Editor  :
-- Changed :
-- Purpose : Culn nce-erdnu di crariiue edcnldc?e
--
-- Ddiolaodr find_sim_cards_1 rireiac?ir ddiolaodl
--   PROCEDURE find_sim_cards (
--      p_user_name       IN       NVARCHAR2,
--      p_only_free       IN       NUMBER,
--      p_quantity        IN       NUMBER,
--      p_seria_start     IN       NVARCHAR2,
--      p_seria_end       IN       NVARCHAR2,
--      p_cur_sim_cards   OUT      sys_refcursor,
--      p_stock_code      IN       pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar
--   )
-- Nicarir ae? diaaldcec FORIS.DataAccess
--------------------------------------------------------------------------------
   PROCEDURE find_sim_cards_1 (
      p_user_name       IN       NVARCHAR2,
      p_only_free       IN       NUMBER,
      p_quantity        IN       NUMBER,
      p_seria_start     IN       NVARCHAR2,
      p_seria_end       IN       NVARCHAR2,
      p_cur_sim_cards   OUT      sys_refcursor,
      p_stock_code      IN       pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 25.06.2007 16:44
-- Version : 1
-- Modification :crm_management.sim_cards__find
-- Editor  :
-- Changed :
-- Purpose : Culn nce-erdnu di crariiue edcnldc?e
--------------------------------------------------------------------------------
   PROCEDURE find_sim_cards (
      p_only_free       IN       NUMBER,
      p_quantity        IN       NUMBER,
      p_seria_start     IN       NVARCHAR2,
      p_seria_end       IN       NVARCHAR2,
      p_stock_code      IN       NVARCHAR2,
      p_cur_sim_cards   OUT      sys_refcursor
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 25.06.2007 16:44
-- Version : 1
-- Modification :crm_management.sim_cards__find
-- Editor  :
-- Changed :
-- Purpose : Culn nce-erdnu di crariiue edcnldc?e
--
-- Ddiolaodr find_sim_cards_2 rireiac?ir ddiolaodl
--   PROCEDURE find_sim_cards (
--      p_only_free       IN       NUMBER,
--      p_quantity        IN       NUMBER,
--      p_seria_start     IN       NVARCHAR2,
--      p_seria_end       IN       NVARCHAR2,
--      p_stock_code      IN       NVARCHAR2,
--      p_cur_sim_cards   OUT      sys_refcursor
--   )
-- Nicarir ae? diaaldcec FORIS.DataAccess
--------------------------------------------------------------------------------
   PROCEDURE find_sim_cards_2 (
      p_only_free       IN       NUMBER,
      p_quantity        IN       NUMBER,
      p_seria_start     IN       NVARCHAR2,
      p_seria_end       IN       NVARCHAR2,
      p_stock_code      IN       NVARCHAR2,
      p_cur_sim_cards   OUT      sys_refcursor
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 26.06.2007 10:13
-- Version : 1
-- Modification :
-- Editor  :
-- Changed :
-- Purpose : Culn nce-erdnu di crariiue edcnldc?e
--------------------------------------------------------------------------------
   PROCEDURE find_sim_cards (
      p_tab_stock_id   IN       ct_number,
      p_only_free      IN       NUMBER,
      p_quantity       IN       NUMBER,
      p_seria_start    IN       NVARCHAR2,
      p_seria_end      IN       NVARCHAR2,
      p_cur_find       OUT      sys_refcursor
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 26.06.2007 10:13
-- Version :
--   1 26.06.2007
-- Modification :
-- Editor  :
-- Changed :
-- Purpose : Culn nce-erdnu di crariiue edcnldc?e
--
-- Ddiolaodr find_sim_cards_3 rireiac?ir ddiolaodl
--   PROCEDURE find_sim_cards (
--      p_tab_stock_id   IN       ct_number,
--      p_only_free      IN       NUMBER,
--      p_quantity       IN       NUMBER,
--      p_seria_start    IN       NVARCHAR2,
--      p_seria_end      IN       NVARCHAR2,
--      p_cur_find       OUT      sys_refcursor
--   )
-- Nicarir ae? diaaldcec FORIS.DataAccess
--------------------------------------------------------------------------------
PROCEDURE find_sim_cards_3 (
      p_tab_stock_id   IN       ct_number,
      p_only_free      IN       NUMBER,
      p_quantity       IN       NUMBER,
      p_seria_start    IN       NVARCHAR2,
      p_seria_end      IN       NVARCHAR2,
      p_cur_find       OUT      sys_refcursor
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 26.06.2007 10:13
-- Version : 1
-- Modification :
-- Editor  :
-- Changed :
-- Purpose : Culn nce-erdnu di crariiue edcnldc?e
-- Problems: tmp_series ia?crnleuii aiecir aunu ere VARCHAR2, n NAVARCHAR2 caln ddliadrciaricl
--------------------------------------------------------------------------------
   PROCEDURE find_sim_cards_free_or_link (
      p_user_name       IN       NVARCHAR2,
      p_status          IN       NUMBER,
      p_quantity        IN       NUMBER,
      p_seria_start     IN       pkg_common.t_varchar,
      p_seria_end       IN       pkg_common.t_varchar,
      p_cur_sim_cards   OUT      sys_refcursor,
      p_stock_code      IN       pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 10.05.2007 14:24
-- Version : 1
-- Modification :
-- Editor  :
-- Changed :
-- Purpose : Dieo?ce iaidoaiaricl di iieldo aieoelinr
--------------------------------------------------------------------------------
   PROCEDURE get_operation_equipment (
      p_doc_no       IN       VARCHAR2,
      p_cur          OUT      sys_refcursor,
      p_error_code   OUT      NUMBER
   );

-------------------------------------------------------------------------------
-- Author  : Smirnov Victor
-- Created : 07.05.2009
-- Version :
--   1 07.05.2009
-- Modification :
-- Editor  :
-- Changed :
-- Purpose : Culn nce-erdnu di crariiue edcnldc?e.
-- Problems:
--------------------------------------------------------------------------------
procedure find_sim_cards_free_or_link_2(
    p_stock_code        in  core.ti_nvarchar := core.empty_ti_nvarchar,
    p_status            in  number, --(0 - all, 1 - free, 2 - linked)
    p_user_name         in  nvarchar2,
    p_date_of_search    in  date,
    p_cur_sim_cards     out sys_refcursor
);

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 26.06.2007 10:13
-- Version : 1
-- Modification :
-- Editor  :
-- Changed :
-- Purpose : Culn nce-erdnu di crariiue edcnldc?e
-- Problems: tmp_series ia?crnleuii aiecir aunu ere VARCHAR2, n NAVARCHAR2 caln ddliadrciaricl
--------------------------------------------------------------------------------
   PROCEDURE find_sim_cards_free_or_link_3(
      p_user_name       IN       NVARCHAR2,
      p_status          IN       NUMBER,
      p_quantity        IN       NUMBER,
      p_seria_start     IN       pkg_common.t_varchar,
      p_seria_end       IN       pkg_common.t_varchar,
      p_cur_sim_cards   OUT      sys_refcursor,
      p_stock_code      IN       pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar
   );

-------------------------------------------------------------------------------
-- Author  : Sergey Ermakov
-- Created : 06.08.2010 10:13
-- Version : 1
-- Modification :
-- Editor  :
-- Changed :
-- Purpose : Dieo?rln cioideroct i nce-erdnro
--------------------------------------------------------------------------------
   PROCEDURE find_sim_cards_info (
      p_stock_code           IN       NVARCHAR2,
      p_seria_start          IN       pkg_common.t_varchar,
      p_seria_end            IN       pkg_common.t_varchar,
      p_only_free            IN       NUMBER,
      p_user_name            IN       NVARCHAR2,
      p_cur_sim_cards_info   OUT      sys_refcursor,
      p_error_message        OUT      VARCHAR2,
      p_error_code           OUT      NUMBER
   );
-------------------------------------------------------------------------------
-- Author  : Katerina Cerna
-- Created : 11.08.2010 14:13
-- Version : 1
-- Modification :
-- Editor  :
-- Changed :
-- Purpose : iddlalecnu, erecl o dieuciarnle? lnnu ddrar ir dldl?cneliiul neerau
--------------------------------------------------------------------------------   
   
   PROCEDURE get_stock_permitions_for_user(p_stock_code            IN pkg_common.t_varchar,
                                        p_user_name                IN  VARCHAR2,
                                        p_user_permis_stock_info   OUT SYS_REFCURSOR,
                                        p_stock_code_not_exist     OUT SYS_REFCURSOR,
                                        p_error_message            OUT VARCHAR2,
                                        p_error_code               OUT NUMBER);

END pkg_crm_test_katja;


/
