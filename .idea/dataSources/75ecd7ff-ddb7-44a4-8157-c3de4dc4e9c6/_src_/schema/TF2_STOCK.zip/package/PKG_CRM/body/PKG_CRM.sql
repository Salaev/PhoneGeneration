CREATE PACKAGE BODY pkg_crm AS

----------------------------------!---------------------------------------------
   pkg_name   CONSTANT NVARCHAR2 (50) := 'PKG_CRM.';

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure find_all_child_stocks
(
    p_tab_stock_group_id util_pkg.cit_number,
    p_user            nvarchar2,
    p_stock_rec       out sys_refcursor,
    p_error_code      out number
)
is
  v_date date := sysdate;
  v_user_id number;
  v_stock_ids ct_number;
  v_group_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_cit_number(p_tab_stock_group_id, 'p_tab_stock_group_id');
  util_pkg.XCheck_Cond_Missing(p_user is null, 'p_user');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user);
  ------------------------------
  v_group_ids := util_pkg.cast_cit2ct_number(p_tab_stock_group_id, true);
  ------------------------------
  v_stock_ids := util_stock.get_avail_stock_ids(v_user_id, util_stock.c_perm_not_none, v_date);
  ------------------------------
  --!_! this means filter by input groups
  if NOT v_group_ids(v_group_ids.first) = util_stock.c_empty_stock_group_id
  then
    ------------------------------
    v_group_ids := util_stock.get_groups_with_descendants_i(v_group_ids);
    ------------------------------
    v_stock_ids := util_stock.filter_stocks01(v_stock_ids, v_group_ids, v_date, true);
    ------------------------------
  end if;
  ------------------------------
  util_stock.get_result_cursor001(v_stock_ids, v_date, p_stock_rec);
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_child_stocks
(
    p_stock_group_id  number,
    p_user            nvarchar2,
    p_stock_rec       out sys_refcursor,
    p_error_code      out number
)
is
  v_date date := sysdate;
  v_user_id number;
  v_stock_ids ct_number;
  v_group_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_group_id is null, 'p_stock_group_id');
  util_pkg.XCheck_Cond_Missing(p_user is null, 'p_user');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user);
  ------------------------------
  util_pkg.add_ct_number_val(v_group_ids, p_stock_group_id);
  ------------------------------
  v_stock_ids := util_stock.get_avail_stock_ids(v_user_id, util_stock.c_perm_not_none, v_date);
  ------------------------------
  v_stock_ids := util_stock.filter_stocks01(v_stock_ids, v_group_ids, v_date, true);
  ------------------------------
  util_stock.get_result_cursor001(v_stock_ids, v_date, p_stock_rec);
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_all_child_stock_groups
(
    p_stock_group_id  number,
    p_user            nvarchar2,
    p_stock_group_rec out sys_refcursor,
    p_error_code      out number
)
is
  v_date date := sysdate;
  v_user_id number;
  v_group_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_group_id is null, 'p_stock_group_id');
  util_pkg.XCheck_Cond_Missing(p_user is null, 'p_user');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user);
  ------------------------------
  v_group_ids := util_stock.get_avail_group_ids(v_user_id, util_stock.c_perm_not_none, v_date, p_stock_group_id, TRUE);
  ------------------------------
  util_stock.get_result_cursor002(v_group_ids, p_stock_group_rec);
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_child_stock_groups
(
    p_stock_group_id  number,
    p_user            nvarchar2,
    p_stock_group_rec out sys_refcursor,
    p_error_code      out number
)
is
  v_date date := sysdate;
  v_user_id number;
  v_nodes ct_node;
  v_group_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_group_id is null, 'p_stock_group_id');
  util_pkg.XCheck_Cond_Missing(p_user is null, 'p_user');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user);
  ------------------------------
  v_nodes := util_stock.get_group_by_stock_perms_i(v_user_id, v_date, util_stock.c_perm_not_none, true, util_stock.c_parent_id_no_parent, true);
  ------------------------------
  select id bulk collect into v_group_ids from table(v_nodes);
  ------------------------------
  v_group_ids := util_stock.get_groups_with_ancestors_i(v_group_ids);
  ------------------------------
  v_group_ids := util_stock.filter_groups02(v_group_ids, p_stock_group_id, v_date, TRUE);
  ------------------------------
  util_stock.get_result_cursor002(v_group_ids, p_stock_group_rec);
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 15.06.2007 14:57
-- Version :
--   1 15.06.2007
-- Modification : crm_management.findequipment
-- Editor  :
-- Changed :
-- Purpose : Поиск оборудования по условиям в текущем состоянии склада
--------------------------------------------------------------------------------
   PROCEDURE find_equipment (
      p_seria_start        IN       NVARCHAR2,
      p_seria_end          IN       NVARCHAR2,
      p_comment_mask       IN       NVARCHAR2,
      p_min_val_date       IN       DATE,
      p_max_val_date       IN       DATE,
      p_equipment_number   IN       NUMBER,
      p_row_count          IN       NUMBER,
      p_unreserved         IN       NUMBER,
      p_cur_equipment      OUT      sys_refcursor,
      p_error_code         OUT      NUMBER
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'find_equipment';
      l_tab_stk_id        ct_number       := ct_number ();   --идентификаторы складов
      l_tab_eqm_id        ct_number       := ct_number ();   --идентификаторы оборудования
      l_eqm_cnt           NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_seria_start
                         || pkg_constants.c_delimiter
                         || p_seria_end
                         || pkg_constants.c_delimiter
                         || p_comment_mask
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_min_val_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_max_val_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_equipment_number
                         || pkg_constants.c_delimiter
                         || p_row_count
                         || pkg_constants.c_delimiter
                         || p_unreserved
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;

      SELECT ID
      BULK COLLECT INTO l_tab_stk_id
        FROM stock s
       WHERE s.code IN (SELECT --+ DYNAMIC_SAMPLING(c 2)
                               c.*
                          FROM tmp_stock_code c);

      SELECT equipment_model_id
      BULK COLLECT INTO l_tab_eqm_id
        FROM equipment_model em
       WHERE em.equipment_model_code IN (SELECT --+ DYNAMIC_SAMPLING(c 2)
                                                c.*
                                           FROM tmp_equipment_code c);

      l_eqm_cnt := l_tab_eqm_id.COUNT;

      OPEN p_cur_equipment FOR
         SELECT   --+ CARDINALITY (stk 2) PUSH_SUBQ ORDERED USE_NL(stk ss s)
                  s.code AS "StockCode", em.equipment_model_code AS "EquipmentCode",
                  ss.seria_start AS "StartSeriesNumber",
                  (CASE
                      WHEN ss.seria_end = '0'
                         THEN CAST (ss.quantity_onstock AS NVARCHAR2 (30))
                      ELSE ss.seria_end
                   END
                  ) AS "EndSeriesNumber",
                  ss.user_comment AS "Comment", ss.create_date AS "ValidityDate",
                  DECODE (ss.quantity_reserved, 0, 'F', 'R') AS "Status"
             FROM TABLE (CAST (l_tab_stk_id AS ct_number)) stk JOIN stock_state ss
                  ON stk.COLUMN_VALUE = ss.stock_id
                  JOIN stock s ON ss.stock_id = s.ID
                  JOIN equipment_model em ON ss.equipment_model_id = em.equipment_model_id
            WHERE (   ss.equipment_model_id IN (SELECT --+ CARDINALITY (eqm 1)
                                                       COLUMN_VALUE
                                                  FROM TABLE (CAST (l_tab_eqm_id AS ct_number)) eqm)
                   OR l_eqm_cnt = 0
                  )
              AND NOT (    ss.seria_start < NVL (p_seria_start, ss.seria_start)
                       AND ss.seria_end < NVL (p_seria_start, ss.seria_start)
                      )
              AND NOT (    ss.seria_start > NVL (p_seria_end, ss.seria_end)
                       AND ss.seria_end > NVL (p_seria_end, ss.seria_end)
                      )
              AND (   UPPER (ss.user_comment) LIKE '%' || UPPER (p_comment_mask) || '%'
                   OR p_comment_mask IS NULL
                  )
              AND (   (    p_unreserved = 1
                       AND (   (p_equipment_number = -1 AND ss.quantity_onstock > 0)
                            OR ss.quantity_onstock = p_equipment_number
                           )
                      )
                   OR (    p_unreserved = 0
                       AND (   (    p_equipment_number = -1
                                AND (ss.quantity_onstock > 0 OR ss.quantity_reserved > 0)
                               )
                            OR (   ss.quantity_onstock = p_equipment_number
                                OR ss.quantity_reserved = p_equipment_number
                               )
                           )
                      )
                  )
              AND ss.status = 1
              AND (p_min_val_date = pkg_constants.c_minexistsdate
                   OR ss.create_date >= p_min_val_date
                  )
              AND (p_max_val_date = pkg_constants.c_minexistsdate
                   OR ss.create_date <= p_max_val_date
                  )
              AND (p_row_count = -1 OR ROWNUM <= p_row_count)
         ORDER BY ss.seria_start;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END find_equipment;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure find_sim_cards_1
(
    p_user_name       nvarchar2,
    p_only_free       number,
    p_quantity        number,
    p_seria_start     nvarchar2,
    p_seria_end       nvarchar2,
    p_cur_sim_cards   out sys_refcursor,
    p_stock_code      util_pkg.cit_nvarchar_s := util_pkg.empty_cit_nvarchar_s
)
is
  v_date date := sysdate;
  v_user_id number;
  v_stock_codes ct_nvarchar_s;
  v_stock_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_name is null, 'p_user_name');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user_name);
  ------------------------------
  v_stock_codes := util_pkg.cast_cit2ct_nvarchar_s(p_stock_code, TRUE);
  ------------------------------
  if util_pkg.CheckP_ct_nvarchar_s(v_stock_codes)
  then
    ------------------------------
    v_stock_ids := util_stock.get_avail_stock_ids3(v_user_id, util_stock.c_perm_view, v_stock_codes, v_date);
    ------------------------------
  else
    ------------------------------
    v_stock_ids := util_stock.get_avail_stock_ids(v_user_id, util_stock.c_perm_view, v_date);
    ------------------------------
  end if;
  ------------------------------
  find_sim_cards
  (
    p_stock_ids => v_stock_ids,
    p_only_free => p_only_free,
    p_quantity => p_quantity,
    p_seria_start => p_seria_start,
    p_seria_end => p_seria_end,
    p_cur_find => p_cur_sim_cards
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! MAIN
procedure find_sim_cards
(
    p_stock_ids       ct_number,
    p_only_free       number,
    p_quantity        number,
    p_seria_start     nvarchar2,
    p_seria_end       nvarchar2,
    p_cur_find        out sys_refcursor
)
is
  v_serial_number1 nvarchar2(50) := p_seria_start;
  v_serial_number2 nvarchar2(50) := p_seria_end;
  v_date date := sysdate;
  v_linked boolean;
  v_model_ids ct_number;
  v_ss_ids ct_number;
  v_ss_sns ct_nvarchar_s;
  v_ss_fns ct_nvarchar_s;
  v_msisdns_ri ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_seria_start is null, 'p_seria_start');
  util_pkg.XCheck_Cond_Missing(p_seria_end is null, 'p_seria_end');
  ------------------------------
  if p_only_free = util_pkg.c_true
  then
    v_linked := false;
  else
    v_linked := null;
  end if;
  ------------------------------
  v_model_ids := util_stock.get_model_ids4type_code(util_stock.c_eq_type_code_sim01, v_date);
  ------------------------------
  util_stock.get_seria_not_null(v_serial_number1, v_serial_number2);
  ------------------------------
  search_pkg.find_1_active_single_eq
  (
    p_serial_number1 => v_serial_number1,
    p_serial_number2 => v_serial_number2,
    p_stock_id => p_stock_ids,
    p_eq_model_id => v_model_ids,
    p_count => util_stock.c_any_count, --!_!
    p_ss_id => v_ss_ids,
    p_ss_serial_number => v_ss_sns
  );
  ------------------------------
  v_ss_fns := util_stock.get_sims_full_number_i(v_ss_sns, FALSE, FALSE);
  ------------------------------
  v_msisdns_ri := util_stock.get_ri_phone_number_i(util_pkg.cast_ct_nvarchar_s2varchar_s(v_ss_fns), v_date, FALSE, FALSE);
  ------------------------------
  search_pkg.get_result_cursor02
  (
    p_ss_id => v_ss_ids,
    p_msisdn => v_msisdns_ri,
    p_linked => v_linked,
    p_date => v_date,
    p_count => p_quantity,
    p_trim_empty => TRUE,
    p_result => p_cur_find
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_sim_cards_4
(
    p_stock_code      util_pkg.cit_nvarchar_s := util_pkg.empty_cit_nvarchar_s,
    p_serial_number   util_pkg.cit_nvarchar_s := util_pkg.empty_cit_nvarchar_s,
    p_equipment_type_code util_pkg.cit_varchar_s := util_pkg.empty_cit_varchar_s,
    p_user_name       nvarchar2,
    p_cur_find_sim_cards out sys_refcursor,
    p_error_code      out number,
    p_error_message   out varchar2
)
is
  v_date date := sysdate;
  v_user_id number;
  v_stock_codes ct_nvarchar_s;
  v_stock_ids ct_number;
  v_serial_numbers ct_nvarchar_s;
  v_eq_type_codes ct_varchar_s;
  v_model_ids ct_number;
  v_models ct_model;
  v_ss_ids ct_number;
  v_ss_fns ct_nvarchar_s;
  v_msisdns_ri ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheckP_cit_nvarchar_s(p_serial_number, 'p_serial_number');
  util_pkg.XCheck_Cond_Missing(p_user_name is null, 'p_user_name');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user_name);
  ------------------------------
  v_stock_codes := util_pkg.cast_cit2ct_nvarchar_s(p_stock_code, TRUE);
  ------------------------------
  if util_pkg.CheckP_ct_nvarchar_s(v_stock_codes)
  then
    ------------------------------
    v_stock_ids := util_stock.get_avail_stock_ids3(v_user_id, util_stock.c_perm_view, v_stock_codes, v_date);
    ------------------------------
  else
    ------------------------------
    v_stock_ids := util_stock.get_avail_stock_ids(v_user_id, util_stock.c_perm_view, v_date);
    ------------------------------
  end if;
  ------------------------------
  v_serial_numbers := util_pkg.cast_cit2ct_nvarchar_s(p_serial_number, TRUE);
  ------------------------------
  v_eq_type_codes := util_pkg.cast_cit2ct_varchar_s(p_equipment_type_code, TRUE);
  ------------------------------
  if NOT util_pkg.CheckP_ct_varchar_s(v_eq_type_codes)
  then
    ------------------------------
    util_pkg.add_ct_varchar_s_val(v_eq_type_codes, util_stock.c_eq_type_code_sim01);
    util_pkg.add_ct_varchar_s_val(v_eq_type_codes, util_stock.c_eq_type_code_sim02);
    ------------------------------
  end if;
  ------------------------------
  v_model_ids := util_stock.get_model_ids4type_codes(v_eq_type_codes, v_date);
  v_models := util_stock.get_ct_model2_fuzzy(v_model_ids, v_date);
  ------------------------------
  search_pkg.seek_active_single_eq_i
  (
    p_serial_number => v_serial_numbers,
    p_stock_id => v_stock_ids,
    p_eq_model_id => v_model_ids,
    p_count => util_stock.c_any_count, --!_!
    p_trim_empty => FALSE,
    p_ss_id => v_ss_ids
  );
  ------------------------------
  v_ss_fns := util_stock.get_sims_full_number_i(v_serial_numbers, FALSE, FALSE);
  ------------------------------
  v_msisdns_ri := util_stock.get_ri_phone_number_i(util_pkg.cast_ct_nvarchar_s2varchar_s(v_ss_fns), v_date, FALSE, FALSE);
  ------------------------------
  search_pkg.get_result_cursor03
  (
    p_ss_id => v_ss_ids,
    p_msisdn => v_msisdns_ri,
    p_model => v_models,
    p_linked => FALSE, --!_!
    p_date => v_date,
    p_trim_empty => TRUE,
    p_result => p_cur_find_sim_cards
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure find_sim_cards_free_or_link
(
    p_user_name         nvarchar2,
    p_status            number, --!_!0 - all, 1 - free, 2 - linked
    p_quantity          number,
    p_seria_start       util_pkg.cit_nvarchar_s,
    p_seria_end         util_pkg.cit_nvarchar_s,
    p_cur_sim_cards     out sys_refcursor,
    p_stock_code        util_pkg.cit_nvarchar_s := util_pkg.empty_cit_nvarchar_s
)
is
  v_date date := sysdate;
  v_user_id number;
  v_linked boolean;
  v_stock_codes ct_nvarchar_s;
  v_stock_ids ct_number;
  --
  v_seria_start ct_nvarchar_s;
  v_seria_end ct_nvarchar_s;
  v_serial_numbers ct_nvarchar_s;
  --
  v_model_ids ct_number;
  v_ss_ids ct_number;
  v_ss_stock_ids ct_number;
  v_ss_model_ids ct_number;
  v_ss_fns ct_nvarchar_s;
  v_msisdns_ri ct_varchar_s;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_name is null, 'p_user_name');
  util_pkg.XCheckP_cit_nvarchar_s(p_seria_start, 'p_seria_start');
  util_pkg.XCheckP_cit_nvarchar_s(p_seria_end, 'p_seria_end');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_seria_start.count != p_seria_end.count, 'p_seria_start.count != p_seria_end.count');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user_name);
  ------------------------------
  v_linked := util_stock.map_link_status(p_status);
  ------------------------------
  util_loc_pkg.touch_number(p_quantity); --!_! really not used
  ------------------------------
  v_stock_codes := util_pkg.cast_cit2ct_nvarchar_s(p_stock_code, TRUE);
  ------------------------------
  if util_pkg.CheckP_ct_nvarchar_s(v_stock_codes)
  then
    ------------------------------
    v_stock_ids := util_stock.get_avail_stock_ids3(v_user_id, util_stock.c_perm_view, v_stock_codes, v_date);
    ------------------------------
  else
    ------------------------------
    v_stock_ids := util_stock.get_avail_stock_ids(v_user_id, util_stock.c_perm_view, v_date);
    ------------------------------
  end if;
  ------------------------------
  v_seria_start := util_pkg.cast_cit2ct_nvarchar_s(p_seria_start, TRUE);
  v_seria_end := util_pkg.cast_cit2ct_nvarchar_s(p_seria_end, TRUE);
  ------------------------------
  v_serial_numbers := util_stock.split_ranges3(v_seria_start, v_seria_end);
  ------------------------------
  v_model_ids := util_stock.get_model_ids4type_code(util_stock.c_eq_type_code_sim01, v_date);
  ------------------------------
  search_pkg.seek_active_single_eq_ii --!_!
  (
    p_serial_number => v_serial_numbers,
    p_stock_id => v_stock_ids,
    p_eq_model_id => v_model_ids,
    p_count => util_stock.c_any_count, --!_!
    p_trim_empty => FALSE, --!_!
    p_ss_id => v_ss_ids,
    p_stock_id2 => v_ss_stock_ids,
    p_eq_model_id2 => v_ss_model_ids
  );
  ------------------------------
  v_ss_fns := util_stock.get_sims_full_number_i(v_serial_numbers, FALSE, FALSE);
  ------------------------------
  v_msisdns_ri := util_stock.get_ri_phone_number_i(util_pkg.cast_ct_nvarchar_s2varchar_s(v_ss_fns), v_date, FALSE, FALSE);
  ------------------------------
  legacy_pkg.get_result_cursor04
  (
    p_serial_number => v_serial_numbers,
    p_ss_id => v_ss_ids,
    p_ss_stock_id => v_ss_stock_ids,
    p_ss_model_id => v_ss_model_ids,
    p_msisdn => v_msisdns_ri,
    p_linked => v_linked,
    p_date => v_date,
    p_result => p_cur_sim_cards
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_sim_cards_free_or_link_2
(
    p_stock_code        util_pkg.cit_nvarchar_s := util_pkg.empty_cit_nvarchar_s,
    p_status            number, --!_!0 - all, 1 - free, 2 - linked
    p_user_name         nvarchar2,
    p_date_of_search    date,
    p_cur_sim_cards     out sys_refcursor
)
is
  v_date date := sysdate;
  v_user_id number;
  v_stock_codes ct_nvarchar_s;
  v_stock_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_name is null, 'p_user_name');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user_name);
  ------------------------------
  v_stock_codes := util_pkg.cast_cit2ct_nvarchar_s(p_stock_code, TRUE);
  ------------------------------
  if util_pkg.CheckP_ct_nvarchar_s(v_stock_codes)
  then
    ------------------------------
    v_stock_ids := util_stock.get_avail_stock_ids3(v_user_id, util_stock.c_perm_view, v_stock_codes, v_date);
    ------------------------------
  else
    ------------------------------
    v_stock_ids := util_stock.get_avail_stock_ids(v_user_id, util_stock.c_perm_view, v_date);
    ------------------------------
  end if;
  ------------------------------
  delete from tmp_dh_dd_ss;
  ------------------------------
  insert into tmp_dh_dd_ss
  (
    type, stock_id, equipment_model_id, seria_start, seria_end, equipment_batch_id,
    quantity_onstock,
    min_dd1,
    max_dd1,
    min_dhid1,
    max_dhid1,
    min_dd2,
    max_dd2,
    min_dhid2,
    max_dhid2
  )
select
    1 type, stock_id, equipment_model_id, seria_start, seria_end, equipment_batch_id,
    sum(quantity_onstock) quantity_onstock,
    min(case when quantity_onstock >= 0 then doc_date else null end) min_dd1,
    max(case when quantity_onstock >= 0 then doc_date else null end) max_dd1,
    min(case when quantity_onstock >= 0 then dh_id else null end) min_dhid1,
    max(case when quantity_onstock >= 0 then dh_id else null end) max_dhid1,
    min(case when quantity_onstock < 0 then doc_date else null end) min_dd2,
    max(case when quantity_onstock < 0 then doc_date else null end) max_dd2,
    min(case when quantity_onstock < 0 then dh_id else null end) min_dhid2,
    max(case when quantity_onstock < 0 then dh_id else null end) max_dhid2
    from (
select /*+ ordered use_nl(sq, dd) index_asc(dd, IDX_DOCDETAIL_DHI_EMI_DMI_DMO)*/
    sq.stock_id, dd.equipment_model_id, dd.seria_start, dd.seria_end, dd.equipment_batch_id,
    decode(sq.quantity_sign, -1, -dd.quantity, dd.quantity) quantity_onstock,
    sq.doc_date, sq.dh_id
    from (
select /*+ ordered use_nl(dh) index_asc(dh, IDX_DOCHEADER_SO_DD_DMO)*/
    dh.id, dh.stock_out_id stock_id, -1 quantity_sign, dh.doc_date, dh.id dh_id
    from (
select distinct column_value stock_id
    from table(cast(v_stock_ids as ct_number))
    ) z, doc_header dh
    where 1 = 1
    and dh.stock_out_id = z.stock_id
    and dh.doc_date <= p_date_of_search
    and dh.doc_type_id in (102, 103, 107)
    and dh.status_id = 1
union all
select /*+ ordered use_nl(dh) index_asc(dh, IDX_DOCHEADER_SI_DD_DMI)*/
    dh.id, dh.stock_in_id stock_id, 1 quantity_sign, dh.doc_date, dh.id dh_id
    from (
select distinct column_value stock_id
    from table(cast(v_stock_ids as ct_number))
    ) z, doc_header dh
    where 1 = 1
    and dh.stock_in_id = z.stock_id
    and dh.doc_date <= p_date_of_search
    and dh.doc_type_id in (101, 103, 104, 105, 106, 108, 109, 113)
    and dh.status_id = 1
    ) sq, doc_detail dd
    where 1 = 1
    and dd.doc_header_id = sq.id
    ) k
    group by stock_id, equipment_model_id, seria_start, seria_end, equipment_batch_id
    having sum(quantity_onstock) <> 0
union all
select
    2 type, stock_id, equipment_model_id, seria_start, seria_end, equipment_batch_id,
    sum(quantity_onstock) quantity_onstock,
    /*min(case when quantity_onstock < 0 then doc_date else null end) min_dd1,
    max(case when quantity_onstock < 0 then doc_date else null end) max_dd1,
    min(case when quantity_onstock < 0 then dh_id else null end) min_dhid1,
    max(case when quantity_onstock < 0 then dh_id else null end) max_dhid1,
    min(case when quantity_onstock >= 0 then doc_date else null end) min_dd2,
    max(case when quantity_onstock >= 0 then doc_date else null end) max_dd2,
    min(case when quantity_onstock >= 0 then dh_id else null end) min_dhid2,
    max(case when quantity_onstock >= 0 then dh_id else null end) max_dhid2*/
    to_date(null, util_pkg.c_date_format_full) min_dd1,
    to_date(null, util_pkg.c_date_format_full) max_dd1,
    to_number(null) min_dhid1,
    to_number(null) max_dhid1,
    to_date(null, util_pkg.c_date_format_full) min_dd2,
    to_date(null, util_pkg.c_date_format_full) max_dd2,
    to_number(null) min_dhid2,
    to_number(null) max_dhid2
    from (
select /*+ ordered use_nl(ss) index_asc(ss, I_STOCK_STATE_STOCK_ID)*/
    ss.stock_id, ss.equipment_model_id, ss.seria_start, ss.seria_end, ss.equipment_batch_id,
    ss.quantity_onstock quantity_onstock,
    to_date(null, util_pkg.c_date_format_full) doc_date, to_number(null) dh_id
    from (
select distinct column_value stock_id
    from table(cast(v_stock_ids as ct_number))
    ) z, stock_state ss
    where 1 = 1
    and ss.stock_id = z.stock_id
    and ss.quantity_onstock > 0
union all
select /*+ ordered use_nl(sq, dd) index_asc(dd, IDX_DOCDETAIL_DHI_EMI_DMI_DMO)*/
    sq.stock_id, dd.equipment_model_id, dd.seria_start, dd.seria_end, dd.equipment_batch_id,
    decode(sq.quantity_sign, -1, -dd.quantity, dd.quantity) quantity_onstock,
    sq.doc_date, sq.dh_id
    from (
select /*+ ordered use_nl(dh) index_asc(dh, IDX_DOCHEADER_SO_DD_DMO)*/
    dh.id, dh.stock_out_id stock_id, 1 quantity_sign, dh.doc_date, dh.id dh_id
    from (
select distinct column_value stock_id
    from table(cast(v_stock_ids as ct_number))
    ) z, doc_header dh
    where 1 = 1
    and dh.stock_out_id = z.stock_id
    and dh.doc_date > p_date_of_search
    and dh.doc_date <= sysdate
    and dh.doc_type_id in (102, 103, 107)
    and dh.status_id = 1
union all
select /*+ ordered use_nl(dh) index_asc(dh, IDX_DOCHEADER_SI_DD_DMI)*/
    dh.id, dh.stock_in_id stock_id, -1 quantity_sign, dh.doc_date, dh.id dh_id
    from (
select distinct column_value stock_id
    from table(cast(v_stock_ids as ct_number))
    ) z, doc_header dh
    where 1 = 1
    and dh.stock_in_id = z.stock_id
    and dh.doc_date > p_date_of_search
    and dh.doc_date <= sysdate
    and dh.doc_type_id in (101, 103, 104, 105, 106, 108, 109, 113)
    and dh.status_id = 1
    ) sq, doc_detail dd
    where 1 = 1
    and dd.doc_header_id = sq.id
    ) k
    group by stock_id, equipment_model_id, seria_start, seria_end, equipment_batch_id
    having sum(quantity_onstock) <> 0
  ;
  ------------------------------
  open p_cur_sim_cards for
select /*+ driving_site(z) ordered use_nl(z, sm, sc, naap, pn, pns, pl, pn2, pso, no, pnt)
    full(z)
    index_asc(sm, AK_SIMS_SN)
    index_asc(sc, UK_SIM_SN)
    index_asc(naap, I_NETADDRACCPO_ACCESS_POINT_ID)
    index_asc(pn, PK_PHONE_NUMBER)
    index_asc(pns, PK_PHONE_NUMBER_SERIES)
    index_asc(pl, PK_PHONE_LINK)
    index_asc(pn2, UK_PHONE_NUM_PHONE_NUMBER)
    index_asc(pso, I_PHOSEOPER_PHO_NUM_SERIES_ID)
    index_asc(no, PK_NETWORK_OPERATOR)
    index_asc(pnt, PK_PHONE_NUMBER_TYPE)
    */
    sm.id equipment_id, sm.serial_number, sm.control_number,
    pn.international_format phone_number,
    --pns.phone_number_type_code phone_number_type,
    pnt.phone_number_type_name phone_number_type,
    pl.linked_msisdn linked_phone_number,
    no.network_operator_code linked_network_operator_code,
    z.date_enter_of_stock
    from (
select
    decode(z1.max_dd2, null, z1.min_dd1, z1.max_dd1) date_enter_of_stock,
    z1.*
    from tmp_dh_dd_ss z1
    where 1 = 1
    and z1.type = 1
union all
select /*+ ordered use_hash(z1, z2) full(z1) full(z2)*/
    pkg_constants.c_minexistsdate date_enter_of_stock,
    --to_date('01.01.0100 00:00:00', 'dd.mm.yyyy hh24:mi:ss') date_enter_of_stock,
    z1.*
    from tmp_dh_dd_ss z1, tmp_dh_dd_ss z2
    where 1 = 1
    and z1.type = 2
    and z2.type(+) = 1
    and z2.stock_id(+) = z1.stock_id
    and z2.equipment_model_id(+) = z1.equipment_model_id
    and z2.seria_start(+) = z1.seria_start
    and z2.seria_end(+) = z1.seria_end
    and nvl(z2.equipment_batch_id(+), -1) = nvl(z1.equipment_batch_id, -1)
    and z2.type is null
    ) z, sims sm,
        ri_sim_card sc, ri_naap naap, ri_phone_number pn, ri_phone_number_series pns,
        ri_phone_link pl, ri_phone_number pn2, ri_phone_series_operator pso, ri_network_operator no,
        cat_phone_number_type pnt
    where 1 = 1
    and sm.serial_number between z.seria_start and z.seria_end
    and sc.sn(+) = to_char(sm.serial_number || sm.control_number)
    and sc.deleted(+) is null
    and naap.access_point_id(+) = sc.access_point_id
    and p_date_of_search between naap.from_date(+) and nvl(naap.to_date(+), p_date_of_search)
    and naap.link_type_code(+) = util_stock.c_RI_MAIN_LINK_TYPE
    and pn.network_address_id(+) = naap.network_address_id
    and pn.deleted(+) is null
    and pns.phone_number_series_id(+) = pn.phone_number_series_id
    and pns.deleted(+) is null
    and pl.main_msisdn(+) = pn.international_format
    and pn2.international_format(+) = pl.linked_msisdn
    and pn2.deleted(+) is null
    and pso.phone_number_series_id(+) = pn2.phone_number_series_id
    and p_date_of_search between pso.start_date(+) and nvl(pso.end_date(+), p_date_of_search)
    and no.network_operator_id(+) = pso.network_operator_id
    and (no.network_operator_type is not null or no.network_operator_id is null)
    and no.deleted(+) is null
    and pnt.phone_number_type_code(+) = pns.phone_number_type_code
    and pnt.deleted(+) is null
    and (--(0 - all, 1 - free, 2 - linked)
        (p_status = util_stock.c_link_status_all)
        or (p_status = util_stock.c_link_status_free and pn.international_format is null)
        or (p_status = util_stock.c_link_status_linked and pn.international_format is not null)
    )
    order by date_enter_of_stock
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure find_equipments_info
(
    p_seria_start       util_pkg.cit_nvarchar_s,
    p_seria_end         util_pkg.cit_nvarchar_s,
    p_user_name         nvarchar2,
    p_cur_equipments_info out sys_refcursor,
    p_error_message     out varchar2,
    p_error_code        out number
)
is
  v_date date := sysdate;
  v_user_id number;
  v_linked boolean;
  v_stock_ids ct_number;
  --
  v_seria_start ct_nvarchar_s;
  v_seria_end ct_nvarchar_s;
  v_serial_numbers ct_nvarchar_s;
  --
  v_model_ids ct_number;
  v_models ct_model;
  v_ss_ids ct_number;
  v_ss_stock_ids ct_number;
  v_ss_model_ids ct_number;
  v_full_numbers ct_nvarchar_s;
  v_msisdns_ri ct_varchar_s;
  --
begin
  ------------------------------
  --!_!util_pkg.XCheckP_cit_nvarchar_s(p_stock_code, 'p_stock_code');
  util_pkg.XCheckP_cit_nvarchar_s(p_seria_start, 'p_seria_start');
  util_pkg.XCheckP_cit_nvarchar_s(p_seria_end, 'p_seria_end');
  util_pkg.XCheck_Cond_Missing(p_user_name is null, 'p_user_name');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_seria_start.count != p_seria_end.count, 'p_seria_start.count != p_seria_end.count');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user_name);
  ------------------------------
  v_linked := null; --!_!
  ------------------------------
  v_stock_ids := util_stock.get_avail_stock_ids(v_user_id, util_stock.c_perm_view, v_date); --!_!
  ------------------------------
  v_seria_start := util_pkg.cast_cit2ct_nvarchar_s(p_seria_start, TRUE);
  v_seria_end := util_pkg.cast_cit2ct_nvarchar_s(p_seria_end, TRUE);
  ------------------------------
  v_serial_numbers := util_stock.split_ranges3(v_seria_start, v_seria_end);
  ------------------------------
  v_model_ids := util_stock.get_equipment_model_ids_all(v_date);
  v_models := util_stock.get_ct_model2_fuzzy(v_model_ids, v_date);
  ------------------------------
  search_pkg.seek_active_single_eq_ii --!_!
  (
    p_serial_number => v_serial_numbers,
    p_stock_id => v_stock_ids,
    p_eq_model_id => v_model_ids,
    p_count => util_stock.c_any_count, --!_!
    p_trim_empty => FALSE, --!_!
    p_ss_id => v_ss_ids,
    p_stock_id2 => v_ss_stock_ids,
    p_eq_model_id2 => v_ss_model_ids
  );
  ------------------------------
  v_full_numbers := util_stock.get_sims_full_number_i(v_serial_numbers, FALSE, FALSE);
  ------------------------------
  v_msisdns_ri := util_stock.get_ri_phone_number_i(util_pkg.cast_ct_nvarchar_s2varchar_s(v_full_numbers), v_date, FALSE, FALSE);
  ------------------------------
  legacy_pkg.get_result_cursor06
  (
    p_serial_number => v_serial_numbers,
    p_ss_id => v_ss_ids,
    p_ss_stock_id => v_ss_stock_ids,
    p_ss_model_id => v_ss_model_ids,
    p_msisdn => v_msisdns_ri,
    p_model => v_models,
    p_linked => v_linked,
    p_date => v_date,
    p_result => p_cur_equipments_info
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure find_complects
(
    p_stock_code      util_pkg.cit_nvarchar_s := util_pkg.empty_cit_nvarchar_s,
    p_quantity        number,
    p_seria_start     nvarchar2,
    p_seria_end       nvarchar2,
    p_user_name       nvarchar2,
    p_cur_complects   out sys_refcursor
)
is
  v_serial_number1 nvarchar2(50) := p_seria_start;
  v_serial_number2 nvarchar2(50) := p_seria_end;
  --
  v_date date := sysdate;
  v_user_id number;
  v_stock_codes ct_nvarchar_s;
  v_stock_ids ct_number;
  --
  v_model_ids ct_number;
  --
  v_ss_ids ct_number;
  --
begin
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(p_seria_start is null, 'p_seria_start');
  --!_!util_pkg.XCheck_Cond_Missing(p_seria_end is null, 'p_seria_end');
  util_pkg.XCheck_Cond_Missing(p_user_name is null, 'p_user_name');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user_name);
  ------------------------------
  v_stock_codes := util_pkg.cast_cit2ct_nvarchar_s(p_stock_code, TRUE);
  ------------------------------
  if util_pkg.CheckP_ct_nvarchar_s(v_stock_codes)
  then
    ------------------------------
    v_stock_ids := util_stock.get_avail_stock_ids3(v_user_id, util_stock.c_perm_view, v_stock_codes, v_date);
    ------------------------------
  else
    ------------------------------
    v_stock_ids := util_stock.get_avail_stock_ids(v_user_id, util_stock.c_perm_view, v_date);
    ------------------------------
  end if;
  ------------------------------
  v_model_ids := util_stock.get_model_ids4type_code(util_stock.c_eq_type_code_sim02, v_date);
  ------------------------------
  util_stock.get_seria_not_null(v_serial_number1, v_serial_number2);
  ------------------------------
  search_pkg.find_1_active_single_eq2
  (
    p_serial_number1 => v_serial_number1,
    p_serial_number2 => v_serial_number2,
    p_stock_id => v_stock_ids,
    p_eq_model_id => v_model_ids,
    p_count => util_stock.c_any_count, --!_!
    p_ss_id => v_ss_ids
  );
  ------------------------------
  search_pkg.get_result_cursor01
  (
    p_ss_id => v_ss_ids,
    p_date => v_date,
    p_count => p_quantity,
    p_trim_empty => TRUE,
    p_result => p_cur_complects
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
-------------------------------------------------------------------------------
-- <name>          function get_HLR_Code
-- <author>        Pavel Vasiliev
-- <version>       1.0
-- <Description>   for find_sim_cards_range
-- <Prerequisites>
-- <Application>   Internal package use
-- <Parameters>    p_full_number varchar2 - icc_id
-------------------------------------------------------------------------------
   FUNCTION get_HLR_Code (p_full_number VARCHAR2)
      RETURN VARCHAR2
   IS
      v_if   VARCHAR2 (20);
   BEGIN
      SELECT host_code
        INTO v_if
        FROM (SELECT --+ driving_site(sc) index(sc uk_sim_sn) index(naap i_netaddraccpo_access_point_id) use_nl(sc, naap, p)
                     h.host_code
                FROM ri_sim_card sc, ri_sim_series ss, ri_host h
               WHERE sc.sn = p_full_number
                 AND sc.sim_series_id = ss.sim_series_id
                 AND h.host_id = ss.host_id)
       WHERE ROWNUM <= DECODE (1, -1, ROWNUM, 1);

      RETURN v_if;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END get_HLR_Code;

-------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 18.05.2010
-- Version :1
-- Modification :pcg_crm.find_sim_cards_range
-- Editor  : Pavel Vasiliev
-- Changed :
-- Purpose : Ищет сим-карты по заданным критериям и добавляет найденые сим-карты в документ на списание
--------------------------------------------------------------------------------
   PROCEDURE find_sim_cards_range (
      p_document_number IN       VARCHAR2,
      p_HLR_code        IN       VARCHAR2,
      p_user_name       IN       VARCHAR2,
      p_quantity        IN       NUMBER,
      p_seria_start     IN       VARCHAR2,
      p_seria_end       IN       VARCHAR2,
      p_handle_tran     IN       CHAR := 'Y',
      p_error_code      OUT      NUMBER
   )
   AS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'find_sim_cards_range';
      v_tmp            number;
      v_stock_id       number;
      v_doc_id         number;
      l_seria_start       stock_state.seria_start%TYPE;
      l_seria_end         stock_state.seria_end%TYPE;
      v_user_id number;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_HLR_code
                         || pkg_constants.c_delimiter
                         || p_user_name
                         || pkg_constants.c_delimiter
                         || p_quantity
                         || pkg_constants.c_delimiter
                         || p_seria_start
                         || pkg_constants.c_delimiter
                         || p_seria_end
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || ')',
                         pkg_name
                        );
        -- check input parameters
      IF p_HLR_code IS NULL
      THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_x_common, 'Missing some mandatory parameter(p_HLR_code).');
      END IF;

      IF p_document_number IS NULL
      THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_x_common, 'Missing some mandatory parameter(p_document_number).');
      END IF;

      v_user_id := util_stock.xget_user_id(p_user_name);

      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      --Проверяем что документ сушествует, это документ на списание и он открыт
      SELECT COUNT(1)
       INTO v_tmp
         FROM DOC_HEADER dh
         WHERE dh.doc_no = p_document_number
           AND dh.doc_type_id = 102
           AND dh.status_id = 0;

      IF v_tmp <> 1
      THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_x_common, 'Document error');
      END IF;

      SELECT dh.id , dh.stock_out_id
       INTO v_doc_id, v_stock_id
         FROM DOC_HEADER dh
         WHERE dh.doc_no = p_document_number
           AND dh.doc_type_id = 102
           AND dh.status_id = 0;

      --Устанавливаем серии оборудования
      l_seria_start := p_seria_start;
      l_seria_end := p_seria_end;
      --Установим диапазоны серий
      pkg_equipment.get_seria_not_null (l_seria_start, l_seria_end);

      util_stock.xis_avail_stock(v_user_id, util_stock.c_perm_change, v_stock_id, sysdate);

      DELETE FROM TMP_DOC_DETAIL;

      --Найдем подходящие сим-карты
      --OPEN p_cur_sim_cards FOR
      INSERT INTO  TMP_DOC_DETAIL(ID,
                                  DOC_HEADER_ID,
                                  EQUIPMENT_MODEL_ID,
                                  SERIA_START,
                                  SERIA_END,
                                  QUANTITY,
                                  STATUS_ID,
                                  PRODUCT,
                                  VALID_UNTIL)
         SELECT c.ID,
                v_doc_id,
                c.equipment_model_id,
                c.seria_start,
                c.seria_end,
                c.quantity,
                c.status,
                0,
                c.valid_until
           FROM (SELECT b.ID,
                        b.full_number,
                        b.phone_number,
                        b.stock_id,
                        b.equipment_model_id,
                        b.seria_start,
                        b.seria_end,
                        b.status,
                        b.quantity,
                        b.valid_until
                   FROM (SELECT a.ID,
                                a.full_number,
                                a.phone_number,
                                a.stock_id,
                                a.equipment_model_id,
                                a.seria_start,
                                a.seria_end,
                                a.status,
                                a.quantity,
                                a.valid_until
                           FROM (SELECT --+ PUSH_SUBQ NO_MERGE
                                        ss.ID, s.full_number,
                                        crm_management.get_phone_number(to_char(s.full_number)) phone_number,
                                        ss.stock_id, ss.equipment_model_id,
                                        ss.seria_start,
                                        ss.seria_end,
                                        ss.status,
                                        ss.quantity_onstock as quantity,
                                        ss.create_date as valid_until,
                                        PKG_CRM.get_HLR_Code(CAST (s.full_number AS VARCHAR2 (30))) AS host_code
                                   FROM stock_state ss, sims s
                                  WHERE ss.seria_start = s.serial_number
                                    AND ss.seria_start BETWEEN l_seria_start AND l_seria_end
                                    AND ss.seria_start = ss.seria_end
                                    AND ss.equipment_model_id IN (SELECT --+ CARDINALITY(em 2)
                                                                         em.equipment_model_id
                                                                    FROM equipment_model em
                                                                   WHERE em.equipment_type_id = 2)
                                    AND ss.stock_id = v_stock_id
                                    AND ss.quantity_onstock = 1
                                    AND ss.status = 1) a
                          WHERE a.phone_number IS NULL AND a.host_code = p_HLR_code) b
                  WHERE ROWNUM <= DECODE (p_quantity, -1, ROWNUM, p_quantity)) c,
                equipment_model em,
                stock s
          WHERE c.equipment_model_id = em.equipment_model_id AND c.stock_id = s.ID;

      INSERT INTO DOC_DETAIL(DOC_HEADER_ID,
                             EQUIPMENT_MODEL_ID,
                             SERIA_START,
                             SERIA_END,
                             QUANTITY,
                             STATUS_ID,
                             PRODUCT,
                             VALID_UNTIL)
                             SELECT tdd.doc_header_id,
                                    tdd.equipment_model_id,
                                    tdd.seria_start,
                                    tdd.seria_end,
                                    tdd.quantity,
                                    tdd.status_id,
                                    tdd.product,
                                    tdd.valid_until
                               FROM TMP_DOC_DETAIL tdd
                               WHERE tdd.doc_header_id = v_doc_id
                                 AND tdd.seria_start NOT IN (SELECT dd.seria_start
                                                               FROM DOC_DETAIL dd
                                                              WHERE dd.doc_header_id = v_doc_id);

      UPDATE
      (SELECT dd.quantity_reserved, tdd.quantity
         FROM STOCK_STATE dd, TMP_DOC_DETAIL tdd
        WHERE dd.id = tdd.id
      )
      SET quantity_reserved=quantity_reserved + quantity;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
        p_error_code := SQLCODE;
        pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

        CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
        END CASE;
   END find_sim_cards_range;

-------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 18.05.2010
-- Version :1
-- Modification :pcg_crm.check_sim_cards
-- Editor  : Pavel Vasiliev
-- Changed :
-- Purpose : Проверяет, что сим-карты удовлетворяют заданным критериям  и добавляет сим-карты в документ на списание
--------------------------------------------------------------------------------
   PROCEDURE check_sim_cards (
      p_document_number IN       VARCHAR2,
      p_HLR_code        IN       VARCHAR2,
      p_user_name       IN       VARCHAR2,
      p_sim_cards       IN       pkg_common.t_varchar,
      p_handle_tran     IN       CHAR := 'Y',
      p_error_code      OUT      NUMBER
   )

   AS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'check_sim_cards';
      v_tmp               number;
      v_stock_id          number;
      v_doc_id         number;
      v_sims              ct_varchar:= ct_varchar();
      v_user_id number;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_HLR_code
                         || pkg_constants.c_delimiter
                         || p_user_name
                         || pkg_constants.c_delimiter
                         || p_sim_cards.COUNT
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || ')',
                         pkg_name
                        );

        -- check input parameters
      IF p_HLR_code IS NULL
      THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_x_common, 'Missing some mandatory parameter(p_HLR_code).');
      END IF;

      IF p_document_number IS NULL
      THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_x_common, 'Missing some mandatory parameter(p_document_number).');
      END IF;

      IF (p_sim_cards IS NULL OR p_sim_cards.COUNT = 0 OR (p_sim_cards.COUNT = 1 AND p_sim_cards(p_sim_cards.FIRST) IS NULL))
      THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_x_common, 'Missing some mandatory parameter(p_sim_cards).');
      END IF;

      v_user_id := util_stock.xget_user_id(p_user_name);

      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      --Проверяем что документ сушествует, это документ на списание и он открыт
      SELECT COUNT(1)
       INTO v_tmp
         FROM DOC_HEADER dh
         WHERE dh.doc_no = p_document_number
           AND dh.doc_type_id = 102
           AND dh.status_id = 0;

      IF v_tmp <> 1
      THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_x_common, 'Document error');
      END IF;

      SELECT dh.id , dh.stock_out_id
       INTO v_doc_id, v_stock_id
         FROM DOC_HEADER dh
         WHERE dh.doc_no = p_document_number
           AND dh.doc_type_id = 102
           AND dh.status_id = 0;

      util_stock.xis_avail_stock(v_user_id, util_stock.c_perm_change, v_stock_id, sysdate);

      FOR i IN p_sim_cards.FIRST..p_sim_cards.LAST
      LOOP
        v_sims.EXTEND;
        v_sims (v_sims.LAST) :=p_sim_cards(i);
      END LOOP;


      DELETE FROM TMP_DOC_DETAIL;

      --Найдем подходящие сим-карты
      --OPEN p_cur_sim_cards FOR
      INSERT INTO  TMP_DOC_DETAIL(ID,
                                  DOC_HEADER_ID,
                                  EQUIPMENT_MODEL_ID,
                                  SERIA_START,
                                  SERIA_END,
                                  QUANTITY,
                                  STATUS_ID,
                                  PRODUCT,
                                  VALID_UNTIL)
       SELECT c.ID,
                v_doc_id,
                c.equipment_model_id,
                c.seria_start,
                c.seria_end,
                c.quantity,
                c.status,
                0,
                c.valid_until
           FROM (SELECT a.ID,
                        a.full_number,
                        a.phone_number,
                        a.stock_id,
                        a.equipment_model_id,
                        a.seria_start,
                        a.seria_end,
                        a.status,
                        a.quantity,
                        a.valid_until
                   FROM (SELECT --+ PUSH_SUBQ NO_MERGE
                                        ss.ID, s.full_number,
                                        crm_management.get_phone_number(to_char(s.full_number)) phone_number,
                                        ss.stock_id, ss.equipment_model_id,
                                        ss.seria_start,
                                        ss.seria_end,
                                        ss.status,
                                        ss.quantity_onstock as quantity,
                                        ss.create_date as valid_until,
                                        PKG_CRM.get_HLR_Code(CAST (s.full_number AS VARCHAR2 (30))) AS host_code
                                   FROM stock_state ss, sims s
                                  WHERE ss.seria_start = s.serial_number
                                    AND ss.seria_start IN (
                                                  SELECT --+ CARDINALITY(stk 5)
                                                         stk.COLUMN_VALUE
                                                    FROM TABLE (CAST (v_sims AS ct_varchar)) stk)
                                    AND ss.seria_start = ss.seria_end
                                    AND ss.equipment_model_id IN (SELECT --+ CARDINALITY(em 2)
                                                                         em.equipment_model_id
                                                                    FROM equipment_model em
                                                                   WHERE em.equipment_type_id = 2)
                                    AND ss.stock_id = v_stock_id
                                    AND ss.quantity_onstock = 1
                                    AND ss.status = 1) a
                          WHERE a.phone_number IS NULL AND a.host_code = p_HLR_code
                  ) c,
                equipment_model em,
                stock s
          WHERE c.equipment_model_id = em.equipment_model_id AND c.stock_id = s.ID;

      INSERT INTO DOC_DETAIL(DOC_HEADER_ID,
                             EQUIPMENT_MODEL_ID,
                             SERIA_START,
                             SERIA_END,
                             QUANTITY,
                             STATUS_ID,
                             PRODUCT,
                             VALID_UNTIL)
                             SELECT tdd.doc_header_id,
                                    tdd.equipment_model_id,
                                    tdd.seria_start,
                                    tdd.seria_end,
                                    tdd.quantity,
                                    tdd.status_id,
                                    tdd.product,
                                    tdd.valid_until
                               FROM TMP_DOC_DETAIL tdd
                               WHERE tdd.doc_header_id = v_doc_id
                                 AND tdd.seria_start NOT IN (SELECT dd.seria_start
                                                               FROM DOC_DETAIL dd
                                                              WHERE dd.doc_header_id = v_doc_id);

      UPDATE
      (SELECT dd.quantity_reserved, tdd.quantity
         FROM STOCK_STATE dd, TMP_DOC_DETAIL tdd
        WHERE dd.id = tdd.id
      )
      SET quantity_reserved=quantity_reserved + quantity;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
        p_error_code := SQLCODE;
        pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

        CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
        END CASE;
   END check_sim_cards;

  -------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 24.05.2010
-- Version :1
-- Modification :pcg_crm.find_sim_cards_range
-- Editor  : Pavel Vasiliev
-- Changed :
-- Purpose : Ищет сим-карты по заданным критериям  и добавляет найденые сим-карты в документ на списание
--           Удаляет из документа сим карты перечисленные в p_removing_sims
--------------------------------------------------------------------------------
   PROCEDURE set_operation_eqipment (
      p_document_number IN       VARCHAR2,
      p_HLR_code        IN       VARCHAR2,
      p_user_name       IN       VARCHAR2,
      p_quantity        IN       NUMBER,
      p_seria_start     IN       VARCHAR2,
      p_seria_end       IN       VARCHAR2,
      p_removing_sims   IN       pkg_common.t_varchar,
      p_handle_tran     IN       CHAR := 'Y',
      p_error_code      OUT      NUMBER
   )
     AS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'set_operation_eqipment';
      v_tmp            number;
      v_stock_id       number;
      v_doc_id         number;
      l_seria_start       stock_state.seria_start%TYPE;
      l_seria_end         stock_state.seria_end%TYPE;
      v_sims              ct_varchar:= ct_varchar();
      v_user_id number;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_HLR_code
                         || pkg_constants.c_delimiter
                         || p_user_name
                         || pkg_constants.c_delimiter
                         || p_quantity
                         || pkg_constants.c_delimiter
                         || p_seria_start
                         || pkg_constants.c_delimiter
                         || p_seria_end
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || ')',
                         pkg_name
                        );
        -- check input parameters
      IF p_HLR_code IS NULL
      THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_x_common, 'Missing some mandatory parameter(p_HLR_code).');
      END IF;

      IF p_document_number IS NULL
      THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_x_common, 'Missing some mandatory parameter(p_document_number).');
      END IF;

      v_user_id := util_stock.xget_user_id(p_user_name);

      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      --Проверяем что документ сушествует, это документ на списание и он открыт
      SELECT COUNT(1)
       INTO v_tmp
         FROM DOC_HEADER dh
         WHERE dh.doc_no = p_document_number
           AND dh.doc_type_id = 102
           AND dh.status_id = 0;

      IF v_tmp <> 1
      THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_x_common, 'Document error');
      END IF;

      SELECT dh.id , dh.stock_out_id
       INTO v_doc_id, v_stock_id
         FROM DOC_HEADER dh
         WHERE dh.doc_no = p_document_number
           AND dh.doc_type_id = 102
           AND dh.status_id = 0;

      --Устанавливаем серии оборудования
      l_seria_start := p_seria_start;
      l_seria_end := p_seria_end;
      --Установим диапазоны серий
      pkg_equipment.get_seria_not_null (l_seria_start, l_seria_end);

      util_stock.xis_avail_stock(v_user_id, util_stock.c_perm_change, v_stock_id, sysdate);

      DELETE FROM TMP_DOC_DETAIL;

      -- Добавляем в документ сим-карты

      --Найдем подходящие сим-карты
      --OPEN p_cur_sim_cards FOR
      INSERT INTO  TMP_DOC_DETAIL(ID,
                                  DOC_HEADER_ID,
                                  EQUIPMENT_MODEL_ID,
                                  SERIA_START,
                                  SERIA_END,
                                  QUANTITY,
                                  STATUS_ID,
                                  PRODUCT,
                                  VALID_UNTIL)
         SELECT c.ID,
                v_doc_id,
                c.equipment_model_id,
                c.seria_start,
                c.seria_end,
                c.quantity,
                c.status,
                0,
                c.valid_until
           FROM (SELECT b.ID,
                        b.full_number,
                        b.phone_number,
                        b.stock_id,
                        b.equipment_model_id,
                        b.seria_start,
                        b.seria_end,
                        b.status,
                        b.quantity,
                        b.valid_until
                   FROM (SELECT a.ID,
                                a.full_number,
                                a.phone_number,
                                a.stock_id,
                                a.equipment_model_id,
                                a.seria_start,
                                a.seria_end,
                                a.status,
                                a.quantity,
                                a.valid_until
                           FROM (SELECT --+ PUSH_SUBQ NO_MERGE
                                        ss.ID, s.full_number,
                                        crm_management.get_phone_number(to_char(s.full_number)) phone_number,
                                        ss.stock_id, ss.equipment_model_id,
                                        ss.seria_start,
                                        ss.seria_end,
                                        ss.status,
                                        ss.quantity_onstock as quantity,
                                        ss.create_date as valid_until,
                                        PKG_CRM.get_HLR_Code(CAST (s.full_number AS VARCHAR2 (30))) AS host_code
                                   FROM stock_state ss, sims s
                                  WHERE ss.seria_start = s.serial_number
                                    AND ss.seria_start BETWEEN l_seria_start AND l_seria_end
                                    AND ss.seria_start = ss.seria_end
                                    AND ss.equipment_model_id IN (SELECT --+ CARDINALITY(em 2)
                                                                         em.equipment_model_id
                                                                    FROM equipment_model em
                                                                   WHERE em.equipment_type_id = 2)
                                    AND ss.stock_id = v_stock_id
                                    AND ss.quantity_onstock = 1
                                    AND ss.status = 1) a
                          WHERE a.phone_number IS NULL AND a.host_code = p_HLR_code) b
                  WHERE ROWNUM <= DECODE (p_quantity, -1, ROWNUM, p_quantity)) c,
                equipment_model em,
                stock s
          WHERE c.equipment_model_id = em.equipment_model_id AND c.stock_id = s.ID;

      INSERT INTO DOC_DETAIL(DOC_HEADER_ID,
                             EQUIPMENT_MODEL_ID,
                             SERIA_START,
                             SERIA_END,
                             QUANTITY,
                             STATUS_ID,
                             PRODUCT,
                             VALID_UNTIL)
                             SELECT tdd.doc_header_id,
                                    tdd.equipment_model_id,
                                    tdd.seria_start,
                                    tdd.seria_end,
                                    tdd.quantity,
                                    tdd.status_id,
                                    tdd.product,
                                    tdd.valid_until
                               FROM TMP_DOC_DETAIL tdd
                               WHERE tdd.doc_header_id = v_doc_id
                                 AND tdd.seria_start NOT IN (SELECT dd.seria_start
                                                               FROM DOC_DETAIL dd
                                                              WHERE dd.doc_header_id = v_doc_id);

      UPDATE
      (SELECT dd.quantity_reserved, tdd.quantity
         FROM STOCK_STATE dd, TMP_DOC_DETAIL tdd
        WHERE dd.id = tdd.id
      )
      SET quantity_reserved=quantity_reserved + quantity;

      -- Удаляем оборудование из документа
      IF (p_removing_sims.COUNT >0 AND p_removing_sims(p_removing_sims.FIRST) IS NOT NULL)
      THEN
        FOR i IN p_removing_sims.FIRST..p_removing_sims.LAST
        LOOP
          v_sims.EXTEND;
          v_sims (v_sims.LAST) :=p_removing_sims(i);
        END LOOP;

        UPDATE
        (SELECT ss.quantity_reserved, dd.quantity
           FROM STOCK_STATE ss, DOC_DETAIL dd
          WHERE ss.seria_start = dd.seria_start
        )
        SET quantity_reserved=quantity_reserved - quantity;

        DELETE FROM DOC_DETAIL dd
         WHERE dd.doc_header_id = v_doc_id
           AND dd.seria_start IN (SELECT --+ CARDINALITY(stk 5)
                                         stk.COLUMN_VALUE
                                    FROM TABLE (CAST (v_sims AS ct_varchar)) stk);
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
        p_error_code := SQLCODE;
        pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

        CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
        END CASE;
   END set_operation_eqipment;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

END;
/
