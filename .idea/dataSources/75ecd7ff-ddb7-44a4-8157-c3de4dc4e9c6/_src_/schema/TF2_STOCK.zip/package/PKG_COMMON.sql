CREATE PACKAGE pkg_common
IS
--******************************************************************************
-- Author  : Skripnik Petr
-- Created : 16.10.2006 14:05
-- Purpose : Процедуры общего пользования
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ------------------------------------------
-- Petr Skripnik   09.11.2006  Изменен
-- Petr Skripnik   17.11.2006  Изменен
--******************************************************************************
   TYPE t_num IS TABLE OF NUMBER
      INDEX BY PLS_INTEGER;

   TYPE t_varchar IS TABLE OF VARCHAR2 (50)
      INDEX BY PLS_INTEGER;

   g_tab_empty_num    ct_number  := ct_number ();   --пустая числовая коллекция
   g_tab_empty_char   ct_varchar := ct_varchar ();   --пустая символьная коллекция

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 08.02.2007 11:54
-- Editor  :
-- Changed :
-- Purpose : Преобразует логический тип в символьный
--------------------------------------------------------------------------------
   FUNCTION boolean_to_char (p_value IN BOOLEAN)
      RETURN VARCHAR2;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.11.2006 10:16
-- Editor  :
-- Changed :
-- Purpose : Очищает контекст
--------------------------------------------------------------------------------
   PROCEDURE clear_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 12.02.2007 10:42
-- Editor  :
-- Changed :
-- Purpose : Возвращает пустой ассоциативный цифровой массив
--------------------------------------------------------------------------------
   FUNCTION empty_t_num
      RETURN pkg_common.t_num;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 12.02.2007 10:42
-- Editor  :
-- Changed :
-- Purpose : Возвращает пустой ассоциативный символьный массив
--------------------------------------------------------------------------------
   FUNCTION empty_t_varchar
      RETURN pkg_common.t_varchar;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.11.2006 10:16
-- Editor  :
-- Changed :
-- Purpose : Возвращает значение контекста
--------------------------------------------------------------------------------
   FUNCTION get_context (p_name VARCHAR2)
      RETURN VARCHAR2;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.10.2006 16:23
-- Editor  :
-- Changed :
-- Purpose : Получает значение глобальной переменной для всех сессий (таблица GLOBAL_VALUE)
--------------------------------------------------------------------------------
   FUNCTION get_global_val (p_name IN VARCHAR2)
      RETURN VARCHAR2;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 19.12.2006 14:35
-- Editor  :
-- Changed :
-- Purpose : Получает результаты работы таймера
--------------------------------------------------------------------------------
   FUNCTION get_timer_result (
      p_event_name_start   VARCHAR2 DEFAULT pkg_constants.c_flag_start,
      p_event_name_end     VARCHAR2 DEFAULT pkg_constants.c_flag_end
   )
      RETURN NUMBER;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.11.2006 10:16
-- Editor  :
-- Changed :
-- Purpose : Просмотрим контекст
--------------------------------------------------------------------------------
   PROCEDURE list_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 16.10.2006 16:50
-- Editor  :
-- Changed :
-- Purpose : Функция преобразовывает список с разделителями-запятыми в таблицу PL/SQL
--           Замена DBMS_UTILITY.COMMA_TO_TABLE которая недопускает цифр перед (,);
--------------------------------------------------------------------------------
   FUNCTION list_to_pltable_fn (p_list IN VARCHAR2, p_delimiter IN CHAR DEFAULT ',')
      RETURN ct_varchar;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 11.10.2006 16:35
-- Editor  : Skripnik Petr
-- Changed : 27.10.2006 11:57
-- Purpose : Переобразует строку LONG в VARCHAR2 (нерабочая!!!)
--------------------------------------------------------------------------------
   FUNCTION long2char (p_long LONG, p_char VARCHAR2 DEFAULT '')
      RETURN VARCHAR2;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 03.04.2007 16:27
-- Editor  :
-- Changed :
-- Purpose : Pipelined-функция. Использется, чтобы возвратить требуемое
-- количество записей типа даты
--------------------------------------------------------------------------------
   FUNCTION pivot_date (p_start IN DATE, p_limit IN NUMBER)
      RETURN ct_date PIPELINED;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 17.11.2006 13:27
-- Editor  :
-- Changed :
-- Purpose : Pipelined-функция. Использется, чтобы возвратить требуемое
-- количество записей чилового типа
--------------------------------------------------------------------------------
   FUNCTION pivot_num (p_start IN NUMBER, p_end IN NUMBER)
      RETURN ct_number PARALLEL_ENABLE PIPELINED;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 17.11.2006 13:32
-- Editor  :
-- Changed :
-- Purpose : Pipelined-функция. Использется, чтобы возвратить требуемое
-- количество записей типа RAW
--------------------------------------------------------------------------------
   FUNCTION pivot_raw (p_start IN NUMBER, p_end IN NUMBER)
      RETURN ct_raw PARALLEL_ENABLE PIPELINED;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 16.10.2006 16:50
-- Editor  :
-- Changed :
-- Purpose : Функция преобразовывает таблицу PL/SQL в список с разделителями-запятыми
--------------------------------------------------------------------------------
   FUNCTION pltable_to_list_fn (p_tbl IN ct_varchar, p_delimiter IN CHAR DEFAULT ',')
      RETURN VARCHAR2;

--------------------------------------------------------------------------------
-- Author  : http://www.oracle.com/technology/oramag/code/tips2004/050304.html
-- Created : 18.03.2008 10:31
-- Editor  :
-- Changed :
-- Purpose : Преобразовывает  строки в столбцы
--------------------------------------------------------------------------------
   FUNCTION rowtocol (p_slct IN VARCHAR2, p_dlmtr IN VARCHAR2 DEFAULT ',')
      RETURN VARCHAR2;   --AUTHID CURRENT_USER

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.11.2006 10:16
-- Editor  :
-- Changed :
-- Purpose : Задает значение контексту
--------------------------------------------------------------------------------
   PROCEDURE set_context (p_name IN VARCHAR2, p_value IN VARCHAR2);

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.10.2006 16:23
-- Editor  :
-- Changed :
-- Purpose : Устанавливает значение глобальной переменной для всех сессий (таблица GLOBAL_VALUE)
--------------------------------------------------------------------------------
   PROCEDURE set_global_val (p_name IN VARCHAR2, p_val IN VARCHAR2);

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 19.12.2006 14:35
-- Editor  :
-- Changed :
-- Purpose : Установка таймера
--------------------------------------------------------------------------------
   PROCEDURE SET_TIMER (p_event_name VARCHAR2 DEFAULT NULL);

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 06.06.2007 16:31
-- Editor  :
-- Changed :
-- Purpose : Переобразует тип pkg_common.t_num к ct_number
--------------------------------------------------------------------------------
   --FUNCTION t_num2ct_number (p_t_num IN t_num)
   --   RETURN ct_number;

   --------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 13.12.2006 15:50
-- Editor  :
-- Changed :
-- Purpose : Функция преобразовывает результат запроса к колонке таблицы в список с разделителями(запятыми)
--------------------------------------------------------------------------------
   FUNCTION table_column_to_list_fn (p_query IN LONG, p_delimiter IN VARCHAR2 DEFAULT ',')
      RETURN LONG;

-------------------------------------------------------------------------------
-- Author  : Sergey Ermakov
-- Created : 26.11.2010 14:35
-- Editor  :
-- Changed :
-- Purpose : Возвращает описание ошибки ORACLE по ее коду
--------------------------------------------------------------------------------
   PROCEDURE get_oracle_error_description (
      p_SQLCODE          IN   NUMBER,
      p_SQLERRM          OUT  VARCHAR2
   );

-------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 14.10.2011
-- Editor  :
-- Changed :
-- Purpose : Получает настройку 
--------------------------------------------------------------------------------
   FUNCTION get_setting(p_name VARCHAR2, p_default VARCHAR2 := NULL) RETURN NVARCHAR2;
   
--------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 10.10.2011
-- Editor  :
-- Changed :
-- Purpose : Wrapper over procedure raise_application_error
--------------------------------------------------------------------------------
  procedure Raise_exception(p_error_code number, p_message varchar2);

END;
/
