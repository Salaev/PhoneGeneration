CREATE package body api_stock_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Get_Operation_Equipment
(
    p_document_number nvarchar2,
    p_only_active char := util_stock.c_yes,
    p_cur out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  api_stock_i_pkg.Get_Operation_Equipment
  (
    p_document_number => p_document_number,
    p_only_active => util_stock.yesno_to_bool_2val(p_only_active),
    p_result => p_cur,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Get_Total_Equipment
(
    p_document_number nvarchar2,
    p_total_equipment out number,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  api_stock_i_pkg.Get_Total_Equipment
  (
    p_document_number => p_document_number,
    p_total_equipment => p_total_equipment,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Get_Doc_State_By_DocNo
(
    p_document_number nvarchar2,
    p_doc_state out number,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  api_stock_i_pkg.Get_Doc_State_By_DocNo
  (
    p_document_number => p_document_number,
    p_doc_state => p_doc_state,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Move_Range_Of_Equipment
(
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_model_codes util_pkg.cit_varchar_s,
    p_stock_out_code nvarchar2,
    p_stock_in_code nvarchar2,
    p_finish number,
    p_user_nt_name nvarchar2,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
begin
  ------------------------------
  api_stock_i_pkg.Move_Range_Of_Equipment
  (
    p_seria_starts => util_pkg.cast_cit2ct_nvarchar_s(p_series_start, true),
    p_seria_ends => util_pkg.cast_cit2ct_nvarchar_s(p_series_end, true),
    p_models => util_stock.get_ct_model_exact(util_pkg.cast_cit2ct_varchar_s(p_model_codes, true), v_date),
    p_stock_id_out => util_stock.get_stock_id2(p_stock_out_code, v_date),
    p_stock_id_in => util_stock.get_stock_id2(p_stock_in_code, v_date),
    p_finish => util_pkg.int_to_bool_2val(p_finish),
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_document_number => p_document_number,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('api_stock_i_pkg.Move_Range_Of_Equipment', p_error_code, p_error_message);
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Change_Model_Of_Equipment
(
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_model_codes_old util_pkg.cit_varchar_s,
    p_model_codes_new util_pkg.cit_varchar_s,
    p_valid_until_new date,
    p_stock_code_src nvarchar2,
    p_stock_code_dst nvarchar2,
    p_user_nt_name nvarchar2,
    p_debit_document_number out nvarchar2,
    p_credit_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
begin
  ------------------------------
  api_stock_i_pkg.Change_Model_Of_Equipment
  (
    p_seria_starts => util_pkg.cast_cit2ct_nvarchar_s(p_series_start, true),
    p_seria_ends => util_pkg.cast_cit2ct_nvarchar_s(p_series_end, true),
    p_models_out => util_stock.get_ct_model_exact(util_pkg.cast_cit2ct_varchar_s(p_model_codes_old, true), v_date),
    p_models_in => util_stock.get_ct_model_exact(util_pkg.cast_cit2ct_varchar_s(p_model_codes_new, true), v_date),
    p_stock_id_out => util_stock.get_stock_id2(p_stock_code_src, v_date),
    p_stock_id_in => util_stock.get_stock_id2(p_stock_code_dst, v_date),
    p_valid_until_new => p_valid_until_new,
    p_finish => TRUE,
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_document_number_out => p_debit_document_number,
    p_document_number_in => p_credit_document_number,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('api_stock_i_pkg.Change_Model_Of_Equipment', p_error_code, p_error_message);
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Create_Empty_Document
(
    p_doc_type_id number,
    p_stock_out_code nvarchar2,
    p_stock_in_code nvarchar2,
    p_user_nt_name nvarchar2,
    p_comment nvarchar2,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
begin
  ------------------------------
  api_stock_i_pkg.Create_Empty_Document
  (
    p_doc_type_id => p_doc_type_id,
    p_stock_id_out => util_stock.get_stock_id2_or_dummy(p_stock_out_code, v_date),
    p_stock_id_in => util_stock.get_stock_id2_or_dummy(p_stock_in_code, v_date),
    p_comment => p_comment,
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_document_number => p_document_number,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('api_stock_i_pkg.Create_Empty_Document', p_error_code, p_error_message);
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Create_Empty_Document_Lnk2
(
    p_doc_type_id1 number,
    p_doc_type_id2 number,
    p_stock_out_code1 nvarchar2,
    p_stock_out_code2 nvarchar2,
    p_stock_in_code1 nvarchar2,
    p_stock_in_code2 nvarchar2,
    p_user_nt_name nvarchar2,
    p_comment1 nvarchar2,
    p_comment2 nvarchar2,
    p_document_number1 out nvarchar2,
    p_document_number2 out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
begin
  ------------------------------
  api_stock_i_pkg.Create_Empty_Document_Lnk2
  (
    p_doc_type_id1 => p_doc_type_id1,
    p_doc_type_id2 => p_doc_type_id2,
    p_stock_id_out1 => util_stock.get_stock_id2_or_dummy(p_stock_out_code1, v_date),
    p_stock_id_out2 => util_stock.get_stock_id2_or_dummy(p_stock_out_code2, v_date),
    p_stock_id_in1 => util_stock.get_stock_id2_or_dummy(p_stock_in_code1, v_date),
    p_stock_id_in2 => util_stock.get_stock_id2_or_dummy(p_stock_in_code2, v_date),
    p_comment1 => p_comment1,
    p_comment2 => p_comment2,
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_document_number1 => p_document_number1,
    p_document_number2 => p_document_number2,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('api_stock_i_pkg.Create_Empty_Document_Lnk2', p_error_code, p_error_message);
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Set_Operation_Equipment
(
    p_document_number nvarchar2,
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_model_codes util_pkg.cit_varchar_s,
    p_is_addition util_pkg.cit_number,
    p_valid_until util_pkg.cit_date,
    p_user_nt_name nvarchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
begin
  ------------------------------
  api_stock_i_pkg.Set_Operation_Equipment1
  (
    p_document_number => p_document_number,
    p_seria_starts => util_pkg.cast_cit2ct_nvarchar_s(p_series_start, true),
    p_seria_ends => util_pkg.cast_cit2ct_nvarchar_s(p_series_end, true),
    p_models => util_stock.get_ct_model_exact(util_pkg.cast_cit2ct_varchar_s(p_model_codes, true), v_date),
    p_is_addition => util_pkg.cast_cit2ct_number(p_is_addition, true),
    p_valid_until => util_pkg.cast_cit2ct_date(p_valid_until, true),
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_break_on_error =>FALSE,
    p_result => p_result,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('api_stock_i_pkg.Set_Operation_Equipment1', p_error_code, p_error_message);
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Set_Op_Eq_Symmetric_Lnk2
(
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_model_codes1 util_pkg.cit_varchar_s,
    p_model_codes2 util_pkg.cit_varchar_s,
    p_is_addition util_pkg.cit_number,
    p_valid_until util_pkg.cit_date,
    p_user_nt_name nvarchar2,
    p_result1 out sys_refcursor,
    p_result2 out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
begin
  ------------------------------
  api_stock_i_pkg.Set_Op_Eq_Symmetric_Lnk2
  (
    p_document_number1 => p_document_number1,
    p_document_number2 => p_document_number2,
    p_seria_starts => util_pkg.cast_cit2ct_nvarchar_s(p_series_start, true),
    p_seria_ends => util_pkg.cast_cit2ct_nvarchar_s(p_series_end, true),
    p_models1 => util_stock.get_ct_model_exact(util_pkg.cast_cit2ct_varchar_s(p_model_codes1, true), v_date),
    p_models2 => util_stock.get_ct_model_exact(util_pkg.cast_cit2ct_varchar_s(p_model_codes2, true), v_date),
    p_is_addition => util_pkg.cast_cit2ct_number(p_is_addition, true),
    p_valid_until => util_pkg.cast_cit2ct_date(p_valid_until, true),
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_open_result => TRUE,
    p_break_on_error =>FALSE,
    p_result1 => p_result1,
    p_result2 => p_result2,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('api_stock_i_pkg.Set_Op_Eq_Symmetric_Lnk2', p_error_code, p_error_message);
  end if;
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Set_Op_Eq_Non_Symmetric_Lnk2
(
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_series_start1 util_pkg.cit_nvarchar_s,
    p_series_start2 util_pkg.cit_nvarchar_s,
    p_series_end1 util_pkg.cit_nvarchar_s,
    p_series_end2 util_pkg.cit_nvarchar_s,
    p_model_codes1 util_pkg.cit_varchar_s,
    p_model_codes2 util_pkg.cit_varchar_s,
    p_is_addition1 util_pkg.cit_number,
    p_is_addition2 util_pkg.cit_number,
    p_valid_until1 util_pkg.cit_date,
    p_valid_until2 util_pkg.cit_date,
    p_user_nt_name nvarchar2,
    p_result1 out sys_refcursor,
    p_result2 out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
begin
  ------------------------------
  api_stock_i_pkg.Set_Op_Eq_Non_Symmetric_Lnk2
  (
    p_document_number1 => p_document_number1,
    p_document_number2 => p_document_number2,
    p_seria_starts1 => util_pkg.cast_cit2ct_nvarchar_s(p_series_start1, true),
    p_seria_starts2 => util_pkg.cast_cit2ct_nvarchar_s(p_series_start2, true),
    p_seria_ends1 => util_pkg.cast_cit2ct_nvarchar_s(p_series_end1, true),
    p_seria_ends2 => util_pkg.cast_cit2ct_nvarchar_s(p_series_end2, true),
    p_models1 => util_stock.get_ct_model_exact(util_pkg.cast_cit2ct_varchar_s(p_model_codes1, true), v_date),
    p_models2 => util_stock.get_ct_model_exact(util_pkg.cast_cit2ct_varchar_s(p_model_codes2, true), v_date),
    p_is_addition1 => util_pkg.cast_cit2ct_number(p_is_addition1, true),
    p_is_addition2 => util_pkg.cast_cit2ct_number(p_is_addition2, true),
    p_valid_until1 => util_pkg.cast_cit2ct_date(p_valid_until1, true),
    p_valid_until2 => util_pkg.cast_cit2ct_date(p_valid_until2, true),
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_open_result => TRUE,
    p_break_on_error =>FALSE,
    p_result1 => p_result1,
    p_result2 => p_result2,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('api_stock_i_pkg.Set_Op_Eq_Non_Symmetric_Lnk2', p_error_code, p_error_message);
  end if;
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Finalize_Document
(
    p_document_number nvarchar2,
    p_user_nt_name nvarchar2 := null,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  api_stock_i_pkg.Finalize_Document
  (
    p_document_number => p_document_number,
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('api_stock_i_pkg.Finalize_Document', p_error_code, p_error_message);
  end if;
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Finalize_Document_Lnk2
(
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_user_nt_name nvarchar2 := null,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  api_stock_i_pkg.Finalize_Document_Lnk2
  (
    p_document_number1 => p_document_number1,
    p_document_number2 => p_document_number2,
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('api_stock_i_pkg.Finalize_Document_Lnk2', p_error_code, p_error_message);
  end if;
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Cancel_Document
(
    p_document_number nvarchar2,
    p_user_nt_name nvarchar2 := null,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  api_stock_i_pkg.Cancel_Document
  (
    p_document_number => p_document_number,
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('api_stock_i_pkg.Cancel_Document', p_error_code, p_error_message);
  end if;
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Cancel_Document_Lnk2
(
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_user_nt_name nvarchar2 := null,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  api_stock_i_pkg.Cancel_Document_Lnk2
  (
    p_document_number1 => p_document_number1,
    p_document_number2 => p_document_number2,
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('api_stock_i_pkg.Cancel_Document_Lnk2', p_error_code, p_error_message);
  end if;
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Set_Shipment_Sims
(
    p_document_number nvarchar2,
    p_serial_number util_pkg.cit_nvarchar_s,
    p_iccid util_pkg.cit_nvarchar_s,
    p_user_nt_name nvarchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  api_stock_i_pkg.Set_Shipment_Sims
  (
    p_document_number => p_document_number,
    p_serial_numbers => util_pkg.cast_cit2ct_nvarchar_s(p_serial_number, true),
    p_iccids => util_pkg.cast_cit2ct_nvarchar_s(p_iccid, true),
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_open_result => TRUE,
    p_result => p_result,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('api_stock_i_pkg.Set_Shipment_Sims', p_error_code, p_error_message);
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Receive_Single_Equipment
(
    p_stock_code nvarchar2,
    p_equipment_code varchar2,
    p_full_number nvarchar2,
    p_validity_date date,
    p_vendor_doc varchar2,
    p_user_nt_name nvarchar2,
    p_finish number,
    p_document_number out nvarchar2,
    p_equipment_id out number,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  legacy_pkg.Receive_Single_Equipment
  (
    p_stock_code => p_stock_code,
    p_equipment_code => p_equipment_code,
    p_full_number => p_full_number,
    p_validity_date => p_validity_date,
    p_vendor_doc => p_vendor_doc,
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_finish => util_pkg.int_to_bool_2val(p_finish),
    p_document_number => p_document_number,
    p_equipment_id => p_equipment_id,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('legacy_pkg.Receive_Single_Equipment', p_error_code, p_error_message);
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_stocks_by_codes
(
    p_stock_codes util_pkg.cit_nvarchar_s,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_stock_id ct_number;
  v_date date := sysdate;
begin
  ------------------------------
  v_stock_id := util_stock.get_stock_id_fuzzy
  (
    p_stock_code => util_pkg.cast_cit2ct_nvarchar_s(p_stock_codes, TRUE),
    p_date => v_date
  );
  ------------------------------
  p_result := get_result_cursor01(v_stock_id);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Put_Away_Equipment_Range1
(
    p_in_document_number nvarchar2,
    p_stock_code nvarchar2,
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_model_codes util_pkg.cit_varchar_s,
    p_user_nt_name nvarchar2,
    p_finish number,
    p_out_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  legacy_pkg.Put_Away_Equipment_Range1
  (
    p_in_document_number => p_in_document_number,
    p_stock_code => p_stock_code,
    p_series_start => util_pkg.cast_cit2ct_nvarchar_s(p_series_start, true),
    p_series_end => util_pkg.cast_cit2ct_nvarchar_s(p_series_end, true),
    p_model_codes => util_pkg.cast_cit2ct_varchar_s(p_model_codes, true),
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_finish => util_pkg.int_to_bool_2val(p_finish),
    p_out_document_number => p_out_document_number,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('legacy_pkg.Put_Away_Equipment_Range', p_error_code, p_error_message);
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Put_Away_Equipment_Range2
(
    p_in_document_number nvarchar2,
    p_stock_code nvarchar2,
    p_sim_ids util_pkg.cit_number,
    p_user_nt_name nvarchar2,
    p_finish number,
    p_result out sys_refcursor,
    p_out_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sim_ids ct_number;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  v_sim_ids := util_pkg.cast_cit2ct_number(p_sim_ids, true);
  ------------------------------
  legacy_pkg.Put_Away_Equipment_Range2
  (
    p_in_document_number => p_in_document_number,
    p_stock_code => p_stock_code,
    p_sim_ids => v_sim_ids,
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_finish => util_pkg.int_to_bool_2val(p_finish),
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages,
    p_out_document_number => p_out_document_number,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('legacy_pkg.Put_Away_Equipment_Range2', p_error_code, p_error_message);
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  p_result := get_result_cursor04
  (
    p_ids => v_sim_ids,
    p_error_codes=> v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
  p_result := get_result_cursor04
  (
    p_ids => v_sim_ids,
    p_error_codes=> v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_sim_cards_info
(
    p_stock_code nvarchar2,
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_only_free number,
    p_user_nt_name nvarchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_linked boolean;
begin
  ------------------------------
  if p_only_free = util_pkg.c_true
  then
    v_linked := false;
  else
    v_linked := null;
  end if;
  ------------------------------
  LEGACY_PKG.find_sim_cards_info
  (
    p_stock_code => p_stock_code,
    p_series_start => util_pkg.cast_cit2ct_nvarchar_s(p_series_start, true),
    p_series_end => util_pkg.cast_cit2ct_nvarchar_s(p_series_end, true),
    p_linked => v_linked,
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_result => p_result,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  )
  ;
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('LEGACY_PKG.find_sim_cards_info', p_error_code, p_error_message);
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure receive_eqm_by_iccid
(
    p_equipment_code util_pkg.cit_varchar_s,
    p_iccid util_pkg.cit_nvarchar_s,
    p_stock_code varchar2,
    p_valid_until date,
    p_user_name varchar2,
    p_finish integer,
    p_handle_tran char := util_stock.c_tran_yes,
    p_document_number out nvarchar2,
    p_error_msg out varchar2,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
    v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  api_stock_i_pkg.receive_eqm_by_iccid
  (
    p_equipment_code => util_pkg.cast_cit2ct_varchar_s(p_equipment_code, FALSE),
    p_iccid => util_pkg.cast_cit2ct_nvarchar_s(p_iccid, FALSE),
    p_stock_code => p_stock_code,
    p_valid_until => p_valid_until,
    p_user_id => util_stock.xget_user_id(p_user_name),
    p_finish => util_pkg.int_to_bool_2val(p_finish),
    p_document_number => p_document_number,
    p_error_code => p_error_code,
    p_error_message => p_error_msg
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_exception(p_error_code, p_error_msg);
  end if;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
     commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_msg);
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure find_stocks
(
    p_stock_groups util_pkg.cit_number,
    p_user_nt_name nvarchar2,
    p_result_stock_groups out sys_refcursor,
    p_result_stocks out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_stock_group_ids ct_number;
  v_stock_ids ct_number;
begin
  ------------------------------
  api_stock_i_pkg.find_stocks
  (
    p_stock_groups => util_pkg.cast_cit2ct_number(p_stock_groups, FALSE),
    p_user_id  => util_stock.xget_user_id(p_user_nt_name),
    p_stock_group_ids => v_stock_group_ids,
    p_stock_ids => v_stock_ids,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  p_result_stock_groups := get_result_cursor03(v_stock_group_ids);
  p_result_stocks := get_result_cursor02(v_stock_ids);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure series_partition
(
    p_series_start_src util_pkg.cit_nvarchar_s,
    p_series_end_src util_pkg.cit_nvarchar_s,
    p_model_codes_src util_pkg.cit_varchar_s,
    p_series_start_dst util_pkg.cit_nvarchar_s,
    p_series_end_dst util_pkg.cit_nvarchar_s,
    p_model_codes_dst util_pkg.cit_varchar_s,
    p_stock_code nvarchar2,
    p_user_nt_name nvarchar2,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
begin
  ------------------------------
  api_stock_i_pkg.series_distribution
  (
    p_partition => TRUE,
    p_seria_starts_src => util_pkg.cast_cit2ct_nvarchar_s(p_series_start_src, true),
    p_seria_ends_src => util_pkg.cast_cit2ct_nvarchar_s(p_series_end_src, true),
    p_models_src => util_stock.get_ct_model_exact(util_pkg.cast_cit2ct_varchar_s(p_model_codes_src, true), v_date),
    p_seria_starts_dst => util_pkg.cast_cit2ct_nvarchar_s(p_series_start_dst, true),
    p_seria_ends_dst => util_pkg.cast_cit2ct_nvarchar_s(p_series_end_dst, true),
    p_models_dst => util_stock.get_ct_model_exact(util_pkg.cast_cit2ct_varchar_s(p_model_codes_dst, true), v_date),
    p_stock_id => util_stock.get_stock_id2(p_stock_code, v_date),
    p_finish => TRUE,
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_document_number => p_document_number,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    ------------------------------
    rollback;
    ------------------------------
  else
    ------------------------------
    commit;
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure series_assembling
(
    p_series_start_src util_pkg.cit_nvarchar_s,
    p_series_end_src util_pkg.cit_nvarchar_s,
    p_model_codes_src util_pkg.cit_varchar_s,
    p_series_start_dst util_pkg.cit_nvarchar_s,
    p_series_end_dst util_pkg.cit_nvarchar_s,
    p_model_codes_dst util_pkg.cit_varchar_s,
    p_stock_code nvarchar2,
    p_user_nt_name nvarchar2,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
begin
  ------------------------------
  api_stock_i_pkg.series_distribution
  (
    p_partition => FALSE,
    p_seria_starts_src => util_pkg.cast_cit2ct_nvarchar_s(p_series_start_src, true),
    p_seria_ends_src => util_pkg.cast_cit2ct_nvarchar_s(p_series_end_src, true),
    p_models_src => util_stock.get_ct_model_exact(util_pkg.cast_cit2ct_varchar_s(p_model_codes_src, true), v_date),
    p_seria_starts_dst => util_pkg.cast_cit2ct_nvarchar_s(p_series_start_dst, true),
    p_seria_ends_dst => util_pkg.cast_cit2ct_nvarchar_s(p_series_end_dst, true),
    p_models_dst => util_stock.get_ct_model_exact(util_pkg.cast_cit2ct_varchar_s(p_model_codes_dst, true), v_date),
    p_stock_id => util_stock.get_stock_id2(p_stock_code, v_date),
    p_finish => TRUE,
    p_user_id => util_stock.xget_user_id(p_user_nt_name),
    p_document_number => p_document_number,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    ------------------------------
    rollback;
    ------------------------------
  else
    ------------------------------
    commit;
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure check_overlapped_stock_state
(
    p_pev_doc_header_id number,
    p_doc_type_id number,
    p_doc_status_id number,
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_model_ids util_pkg.cit_number,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  api_stock_i_pkg.check_overlapped_stock_state
  (
    p_pev_doc_header_id => p_pev_doc_header_id,
    p_doc_type_id => p_doc_type_id,
    p_doc_status_id => p_doc_status_id,
    p_series_start => util_pkg.cast_cit2ct_nvarchar_s(p_series_start, true),
    p_series_end => util_pkg.cast_cit2ct_nvarchar_s(p_series_end, true),
    p_model_ids => util_pkg.cast_cit2ct_number(p_model_ids, true),
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_result_cursor01(p_stock_id ct_number) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
select /*+ ordered use_nl(q z) full(q) index(z PK_STOCK)*/
    q.stock_id,
    z.code stock_code,
    z.name stock_name
  from (select column_value stock_id, rownum rn from table(p_stock_id)) q,stock z
  where 1 = 1
  and z.id = q.stock_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor02(p_stock_id ct_number) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
select /*+ ordered use_nl(q z) full(q) index(z PK_STOCK)*/
    q.stock_id,
    z.code stock_code,
    z.name stock_name,
    z.stock_group_id parent_id
  from (select column_value stock_id, rownum rn from table(p_stock_id)) q,stock z
  where 1 = 1
  and z.id = q.stock_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor03(p_stock_group_id ct_number) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
select /*+ ordered use_nl(q z) full(q) index(z PK_STOCK_GROUP)*/
    q.stock_group_id,
    z.name stock_group_name,
    z.stock_group_id parent_id,
    decode(q2.stock_group_id, null, util_pkg.c_true, util_pkg.c_false) is_root
  from
    (select column_value stock_group_id, rownum rn from table(p_stock_group_id)) q,
    stock_group z,
    (select column_value stock_group_id, rownum rn from table(p_stock_group_id)) q2
  where 1 = 1
  and z.id = q.stock_group_id
  and q2.stock_group_id(+) = z.stock_group_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor04
(
    p_ids ct_number,
    p_error_codes ct_number,
    p_error_messages ct_varchar
) return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
select /*+ ordered use_hash(q1, q2)*/
    q0.id EquipmentId,
    q1.error_message,
    q2.error_code
    from
        (select column_value id, rownum rn from table(p_ids)) q0,
        (select nvl(column_value, util_pkg.c_msg_ok) error_message, rownum rn from table(p_error_messages)) q1,
        (select nvl(column_value, util_pkg.c_ora_ok) error_code, rownum rn from table(p_error_codes)) q2
    where 1 = 1
    and q1.rn(+) = q0.rn
    and q2.rn(+) = q1.rn
    order by q0.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
end;
/
