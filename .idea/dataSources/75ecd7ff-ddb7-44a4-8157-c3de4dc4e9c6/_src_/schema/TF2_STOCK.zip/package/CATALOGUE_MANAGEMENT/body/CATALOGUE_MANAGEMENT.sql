CREATE PACKAGE BODY catalogue_management
AS
/*******************************************************************************
<name>          DOC_TYPE__Upd
<author>        Petar Ulic
<version>       1.1   06.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_name NVARCHAR2
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ------------------------------------------
-- Petr Skripnik   10.11.2006  Изменен
-- Skripnik Petr   10.07.2007  version 1.11.9.0
*******************************************************************************/
   pkg_name   CONSTANT NVARCHAR2 (50) := 'catalogue_management.';

/****************************************************************************
<name>          EQUIPMENT_MODEL__Get
<author>        Petar Ulic
<version>       1.1   06.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_type_id NUMBER
                p_equipment_model_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE equipment_model__get (
      p_id                          NUMBER,
      p_type_id                     NUMBER,
      p_equipment_model_rec   OUT   t_cursor,
      p_error_code            OUT   NUMBER
   )
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_equipment_model_rec FOR
         SELECT "Id", "Code", "Name", "Type Id", "Type Name", "Producer"
           FROM v_equipment_model
          WHERE (("Id" = p_id) OR (p_id = 0)) AND (("Type Id" = p_type_id) OR (p_type_id = 0));
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END equipment_model__get;

/****************************************************************************
<name>          EQUIPMENT_MODEL__Get_By_Type
<author>        Dejan Spegar
<version>       1.0   02.01.2004 basic Oracle implementation
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_code NVARCHAR2
                p_equipment_model_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE equipment_model__get_by_type (
      p_code                        NVARCHAR2,
      p_equipment_model_rec   OUT   t_cursor,
      p_error_code            OUT   NUMBER
   )
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_equipment_model_rec FOR
         SELECT *
           FROM v_equipment_model
          WHERE (("Code" = p_code) OR (p_code IS NULL));
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END equipment_model__get_by_type;

/****************************************************************************
<name>          EQUIPMENT_TYPE__Get
<author>        Petar Ulic
<version>       1.1   06.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_equipment_type_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE equipment_type__get (
      p_id                         NUMBER,
      p_equipment_type_rec   OUT   t_cursor,
      p_error_code           OUT   NUMBER
   )
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_equipment_type_rec FOR
         SELECT   *
             FROM equipment_type
            WHERE (deleted IS NULL) AND ((equipment_type_id = p_id) OR (p_id = 0))
         ORDER BY equipment_type_id;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END;

/****************************************************************************
<name>          STOCK_STATE__Get
<author>        Petar Ulic
<version>       1.1   06.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
-- 17.04.2007 Skripnik Petr Удалены колонки MIN_VALUE и ALARM_ID
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                 p_stock_state_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE stock_state__get (
      p_stock_id                NUMBER,
      p_status                  NUMBER,
      p_stock_state_rec   OUT   t_cursor,
      p_error_code        OUT   NUMBER
   )
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_stock_state_rec FOR
         SELECT "Id", "Equipment type name", "Equipment code", "Equipment name", "Quantity",
                "Reserved", "Announced", "Equipment type id", "Equipment model id", "Seria start",
                "Seria end", "Status", "Valid until", "User comment", "Reservation",
                "Equipment batch id"
           FROM vw_stock_state
          WHERE (("Status" = p_status) OR (p_status = -1)) AND "Id" = p_stock_id;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END stock_state__get;

/****************************************************************************
<name>          INVENTORY__Get
<author>        Dejan Spegar
<version>       1.0   20.01.2004 basic Oracle implementation
-- Changed : Skripnik Petr 26.04.2007 Заменил обращение к V_INVENTORY на локальный запрос
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                 p_stock_state_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE inventory__get (p_stock_id NUMBER, p_inventory_rec OUT t_cursor, p_error_code OUT NUMBER)
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'inventory__get';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name, '(' || p_stock_id || ')', pkg_name);
      p_error_code := 0;

      OPEN p_inventory_rec FOR
         SELECT ss.stock_id AS "Id", et.equipment_type_name AS "Equipment type name",
                em.equipment_model_code AS "Equipment code",
                em.equipment_model_name AS "Equipment name", ss.quantity AS "Quantity",
                ss.reserved AS "Reserved", ss.announced AS "Announced",
                ss.equipment_type_id AS "Equipment type id",
                ss.equipment_model_id AS "Equipment model id"
           FROM (SELECT   stock_id, SUM (quantity_onstock) AS quantity,
                          SUM (quantity_reserved) AS reserved, SUM (quantity_announced)
                                                                                       AS announced,
                          equipment_type_id, equipment_model_id
                     FROM stock_state
                    WHERE stock_id = p_stock_id
                 GROUP BY stock_id, equipment_type_id, equipment_model_id) ss,
                equipment_model em,
                equipment_type et
          WHERE ss.equipment_model_id = em.equipment_model_id
            AND ss.equipment_type_id = et.equipment_type_id;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := SQLCODE;
         END CASE;
   END inventory__get;

/****************************************************************************
<name>          COUNTRY__Get
<author>        Petar Ulic
<version>       1.1   06.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_country_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE country__get (p_id NUMBER, p_country_rec OUT t_cursor, p_error_code OUT NUMBER)
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_country_rec FOR
         SELECT *
           FROM country
          WHERE (deleted IS NULL) AND ((country_id = p_id) OR (p_id = 0));
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END country__get;

/****************************************************************************
<name>          EQUIPMENT_PRICE__Get
<author>        Igor Holod
<version>       1.0   22.10.2004 basic Oracle implementation
<Description>
<Prerequisites>
<Application>
<Parameters>    p_id NUMBER
                p_equipment_prices_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE equipment_price__get (
      p_id                           NUMBER,
      p_equipment_prices_rec   OUT   t_cursor,
      p_error_code             OUT   NUMBER
   )
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_equipment_prices_rec FOR
         SELECT e.ID, em.equipment_model_id, e.prices1, e.prices2, e.prices3,
                em.equipment_model_code, em.equipment_model_name, em.equipment_type_id,
                ety.equipment_type_name
           FROM equipment_model em LEFT OUTER JOIN equipment_prices e
                ON em.equipment_model_id = e.equipment_code
                , equipment_type ety
          WHERE (ID = p_id) OR (p_id = 0) AND (em.equipment_type_id = ety.equipment_type_id);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
   END equipment_price__get;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE configuration__get (p_configuration_rec OUT t_cursor, p_error_code OUT NUMBER)
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_configuration_rec FOR
         SELECT *
           FROM configuration;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
   END configuration__get;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 20.09.2006 10:10
-- Editor  : Skripnik Petr
-- Changed : 27.09.2006 15:41 | 27.10.2006 10:10
-- Purpose : Вносит запись о партии оборудования
--------------------------------------------------------------------------------
   PROCEDURE equipment_batch_ins (
      p_equipment_batch_code   IN       NVARCHAR2,   --мнемокод партии
      p_equipment_model_id     IN       NUMBER,   --модель оборудования
      p_price                  IN       NUMBER,   --цена за еденицу оборудования
      p_user_of_change         IN       NVARCHAR2,   --пользователь создавший партию
      p_handle_tran            IN       CHAR DEFAULT 'Y',
      p_error_code             OUT      NUMBER   --код ошибки
   )
   IS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'equipment_batch_ins';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      INSERT INTO equipment_batch
                  (equipment_batch_id, equipment_batch_code, equipment_model_id, price, user_of_change, date_of_create, date_of_change, date_of_close
                  )
           VALUES (sq_equipment_batch.nextval, p_equipment_batch_code, p_equipment_model_id, p_price, p_user_of_change, sysdate, sysdate, null
                  );

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END equipment_batch_ins;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 20.09.2006 10:10
-- Editor  : Skripnik Petr
-- Changed : 27.09.2006 15:41 | 27.10.2006 10:10
-- Purpose : Изменяет данные партии оборудования
--------------------------------------------------------------------------------
   PROCEDURE equipment_batch_upd (
      p_equipment_batch_id     IN       NUMBER,   --партия оборудования
      p_equipment_batch_code   IN       NVARCHAR2,   --код партии
      p_equipment_model_id     IN       NUMBER,   --модель
      p_price                  IN       NUMBER,   --цена за еденицу в партии
      p_user_of_change         IN       NVARCHAR2,   --пользователь изменивший информацию в партию
      p_date_of_close          IN       DATE,
      p_handle_tran            IN       CHAR DEFAULT 'Y',
      p_error_code             OUT      NUMBER   --код ошибки
   )
   IS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'equipment_batch_upd';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      UPDATE equipment_batch
         SET equipment_batch_code = p_equipment_batch_code,
             equipment_model_id = p_equipment_model_id,
             price = p_price,
             user_of_change = p_user_of_change,
             date_of_change = sysdate,
             date_of_close = p_date_of_close
       WHERE equipment_batch_id = p_equipment_batch_id;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END equipment_batch_upd;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 21.09.2006 10:50
-- Editor  : Skripnik Petr
-- Changed : 26.10.2006 14:15
-- Purpose : Информация о партиях оборудования
--!! Переделать чтобы на входе была коллекция оборудования..иначе траблы в клиенте
--------------------------------------------------------------------------------
   PROCEDURE get_batch_cur_by_model_cur (
      p_with_closed   IN       NUMBER,   --включать в результат закрытые партии или нет
      p_cur_batch     OUT      sys_refcursor,
      p_error_code    OUT      NUMBER
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_batch_cur_by_model_cur';
      l_cnt_eqm           NUMBER;   --Количество идентификаторов оборудования
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Установим код ошибки в ноль
      p_error_code := 0;

      --Ициализируем пустую коллекцию оборудования если она неициализирована
      IF pkg_equipment.g_tab_model_id IS NULL
      THEN
         pkg_equipment.g_tab_model_id := pkg_common.g_tab_empty_num;
      END IF;

      --Установием количество идентификаторов оборудования
      l_cnt_eqm := pkg_equipment.g_tab_model_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'l_cnt_eqm = ' || l_cnt_eqm, pkg_name);

      --Учитывать только незакрыте партии...
      IF p_with_closed = 0
      THEN
         OPEN p_cur_batch FOR
            SELECT a.equipment_batch_id, a.equipment_batch_code, a.equipment_model_id, a.price,
                   a.user_of_change, a.date_of_create, a.date_of_change, a.date_of_close
              FROM equipment_batch a
             WHERE (   (a.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 4)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                       )
                    OR (0 = l_cnt_eqm)
                   )
               AND a.date_of_close IS NULL;
      ELSE   --Все...
         OPEN p_cur_batch FOR
            SELECT a.equipment_batch_id, a.equipment_batch_code, a.equipment_model_id, a.price,
                   a.user_of_change, a.date_of_create, a.date_of_change, a.date_of_close
              FROM equipment_batch a
             WHERE (   (a.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 4)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                       )
                    OR (0 = l_cnt_eqm)
                   );
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END get_batch_cur_by_model_cur;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 29.09.2006 10:30
-- Editor  :
-- Changed :
-- Purpose : Возвращает партии и модели в партиях
--------------------------------------------------------------------------------
   PROCEDURE get_batch_model_cur (p_cur_batch_model OUT sys_refcursor, p_error_code OUT NUMBER)
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_batch_model_cur';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      -- Откроем курсор
      OPEN p_cur_batch_model FOR
         SELECT   b.equipment_batch_id, b.equipment_batch_code, b.price, m.equipment_model_id,
                  m.equipment_model_code, m.equipment_model_name, b.date_of_create,
                  b.date_of_close, b.date_of_change, user_of_change
             FROM equipment_batch b, equipment_model m
            WHERE b.equipment_model_id = m.equipment_model_id(+)
         ORDER BY b.equipment_batch_id;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END get_batch_model_cur;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 03.10.2006 13:49
-- Editor  :
-- Changed :
-- Purpose : Возвращает типы оборудования
--------------------------------------------------------------------------------
   PROCEDURE get_equipment_type_cur (p_cur_equipment_type OUT sys_refcursor, p_error_code OUT NUMBER)
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_equipment_type_cur';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      OPEN p_cur_equipment_type FOR
         SELECT equipment_type_id, equipment_type_code, equipment_type_name, user_id_of_change,
                date_of_change, deleted, system_type_code, has_serial_number, allows_partitioning,
                is_numeric_serial_number, is_package
           FROM vw_equipment_type;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END get_equipment_type_cur;

--------------------------------------------------------------------------------
-- Author  : Ermakov Sergey
-- Created : 17.05.2009 13:49
-- Editor  :
-- Changed :
-- Purpose : Возвращает список поставщиков
--------------------------------------------------------------------------------
   PROCEDURE get_vendor_cur (p_cur_vendor OUT sys_refcursor, p_error_code OUT NUMBER)
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_vendor_cur';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      OPEN p_cur_vendor FOR
         SELECT vendor_id, vendor_code, vendor_name, vendor_email, vendor_tin, vendor_cst, 
                vendor_description, deleted
           FROM v_vendor;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END get_vendor_cur;

END;
/
