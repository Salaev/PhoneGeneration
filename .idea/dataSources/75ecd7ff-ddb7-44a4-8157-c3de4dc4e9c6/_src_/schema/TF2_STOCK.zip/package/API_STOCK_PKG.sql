CREATE package api_stock_pkg is

----------------------------------!---------------------------------------------
  procedure Get_Operation_Equipment
  (
    p_document_number nvarchar2,
    p_only_active char := util_stock.c_yes,
    p_cur out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Get_Total_Equipment
  (
    p_document_number nvarchar2,
    p_total_equipment out number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure Get_Doc_State_By_DocNo
  (
    p_document_number nvarchar2,
    p_doc_state out number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure Move_Range_Of_Equipment
  (
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_model_codes util_pkg.cit_varchar_s,
    p_stock_out_code nvarchar2,
    p_stock_in_code nvarchar2,
    p_finish number,
    p_user_nt_name nvarchar2,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Change_Model_Of_Equipment
  (
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_model_codes_old util_pkg.cit_varchar_s,
    p_model_codes_new util_pkg.cit_varchar_s,
    p_valid_until_new date,
    p_stock_code_src nvarchar2,
    p_stock_code_dst nvarchar2,
    p_user_nt_name nvarchar2,
    p_debit_document_number out nvarchar2,
    p_credit_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure Create_Empty_Document
  (
    p_doc_type_id number,
    p_stock_out_code nvarchar2,
    p_stock_in_code nvarchar2,
    p_user_nt_name nvarchar2,
    p_comment nvarchar2,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Create_Empty_Document_Lnk2
  (
    p_doc_type_id1 number,
    p_doc_type_id2 number,
    p_stock_out_code1 nvarchar2,
    p_stock_out_code2 nvarchar2,
    p_stock_in_code1 nvarchar2,
    p_stock_in_code2 nvarchar2,
    p_user_nt_name nvarchar2,
    p_comment1 nvarchar2,
    p_comment2 nvarchar2,
    p_document_number1 out nvarchar2,
    p_document_number2 out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Set_Operation_Equipment
  (
    p_document_number nvarchar2,
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_model_codes util_pkg.cit_varchar_s,
    p_is_addition util_pkg.cit_number,
    p_valid_until util_pkg.cit_date,
    p_user_nt_name nvarchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Set_Op_Eq_Symmetric_Lnk2
  (
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_model_codes1 util_pkg.cit_varchar_s,
    p_model_codes2 util_pkg.cit_varchar_s,
    p_is_addition util_pkg.cit_number,
    p_valid_until util_pkg.cit_date,
    p_user_nt_name nvarchar2,
    p_result1 out sys_refcursor,
    p_result2 out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Set_Op_Eq_Non_Symmetric_Lnk2
  (
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_series_start1 util_pkg.cit_nvarchar_s,
    p_series_start2 util_pkg.cit_nvarchar_s,
    p_series_end1 util_pkg.cit_nvarchar_s,
    p_series_end2 util_pkg.cit_nvarchar_s,
    p_model_codes1 util_pkg.cit_varchar_s,
    p_model_codes2 util_pkg.cit_varchar_s,
    p_is_addition1 util_pkg.cit_number,
    p_is_addition2 util_pkg.cit_number,
    p_valid_until1 util_pkg.cit_date,
    p_valid_until2 util_pkg.cit_date,
    p_user_nt_name nvarchar2,
    p_result1 out sys_refcursor,
    p_result2 out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Finalize_Document
  (
    p_document_number nvarchar2,
    p_user_nt_name nvarchar2 := null,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Finalize_Document_Lnk2
  (
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_user_nt_name nvarchar2 := null,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Cancel_Document
  (
    p_document_number nvarchar2,
    p_user_nt_name nvarchar2 := null,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Cancel_Document_Lnk2
  (
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_user_nt_name nvarchar2 := null,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure Set_Shipment_Sims
  (
    p_document_number nvarchar2,
    p_serial_number util_pkg.cit_nvarchar_s,
    p_iccid util_pkg.cit_nvarchar_s,
    p_user_nt_name nvarchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure Receive_Single_Equipment
  (
    p_stock_code nvarchar2,
    p_equipment_code varchar2,
    p_full_number nvarchar2,
    p_validity_date date,
    p_vendor_doc varchar2,
    p_user_nt_name nvarchar2,
    p_finish number,
    p_document_number out nvarchar2,
    p_equipment_id out number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure get_stocks_by_codes
  (
    p_stock_codes util_pkg.cit_nvarchar_s,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure Put_Away_Equipment_Range1
  (
    p_in_document_number nvarchar2,
    p_stock_code nvarchar2,
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_model_codes util_pkg.cit_varchar_s,
    p_user_nt_name nvarchar2,
    p_finish number,
    p_out_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Put_Away_Equipment_Range2
  (
    p_in_document_number nvarchar2,
    p_stock_code nvarchar2,
    p_sim_ids util_pkg.cit_number,
    p_user_nt_name nvarchar2,
    p_finish number,
    p_result out sys_refcursor,
    p_out_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure find_sim_cards_info
  (
    p_stock_code nvarchar2,
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_only_free number,
    p_user_nt_name nvarchar2,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure receive_eqm_by_iccid
  (
    p_equipment_code util_pkg.cit_varchar_s,
    p_iccid util_pkg.cit_nvarchar_s,
    p_stock_code varchar2,
    p_valid_until date,
    p_user_name varchar2,
    p_finish integer,
    p_handle_tran char := util_stock.c_tran_yes,
    p_document_number out nvarchar2,
    p_error_msg out varchar2,
    p_error_code out number
  );

  procedure find_stocks
  (
    p_stock_groups util_pkg.cit_number,
    p_user_nt_name nvarchar2,
    p_result_stock_groups out sys_refcursor,
    p_result_stocks out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure series_partition
  (
    p_series_start_src util_pkg.cit_nvarchar_s,
    p_series_end_src util_pkg.cit_nvarchar_s,
    p_model_codes_src util_pkg.cit_varchar_s,
    p_series_start_dst util_pkg.cit_nvarchar_s,
    p_series_end_dst util_pkg.cit_nvarchar_s,
    p_model_codes_dst util_pkg.cit_varchar_s,
    p_stock_code nvarchar2,
    p_user_nt_name nvarchar2,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure series_assembling
  (
    p_series_start_src util_pkg.cit_nvarchar_s,
    p_series_end_src util_pkg.cit_nvarchar_s,
    p_model_codes_src util_pkg.cit_varchar_s,
    p_series_start_dst util_pkg.cit_nvarchar_s,
    p_series_end_dst util_pkg.cit_nvarchar_s,
    p_model_codes_dst util_pkg.cit_varchar_s,
    p_stock_code nvarchar2,
    p_user_nt_name nvarchar2,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure check_overlapped_stock_state
  (
    p_pev_doc_header_id number,
    p_doc_type_id number,
    p_doc_status_id number,
    p_series_start util_pkg.cit_nvarchar_s,
    p_series_end util_pkg.cit_nvarchar_s,
    p_model_ids util_pkg.cit_number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  function get_result_cursor01(p_stock_id ct_number) return sys_refcursor;
  function get_result_cursor02(p_stock_id ct_number) return sys_refcursor;
  function get_result_cursor03(p_stock_group_id ct_number) return sys_refcursor;

  function get_result_cursor04
  (
    p_ids ct_number,
    p_error_codes ct_number,
    p_error_messages ct_varchar
  ) return sys_refcursor;

----------------------------------!---------------------------------------------
end;
/
