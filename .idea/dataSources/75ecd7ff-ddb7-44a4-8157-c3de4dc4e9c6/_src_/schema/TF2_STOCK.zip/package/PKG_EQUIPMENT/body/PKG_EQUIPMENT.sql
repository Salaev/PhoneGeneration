CREATE PACKAGE BODY pkg_equipment
AS
--******************************************************************************
-- Author  : Skripnik Petr
-- Created : 18.12.2006 11:18
-- Modification :
-- Purpose : Work with the equipment
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ----------------------------------------------
-- Skripnik Petr   16.04.2007  version 1.11.8.2
-- Skripnik Petr   10.07.2007  version 1.11.9.0
--****************************************************************************--
   pkg_name   CONSTANT NVARCHAR2 (50) := 'pkg_equipment.';

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 13.09.2006 11:23
-- Editor  : Skripnik Petr
-- Changed : 12.10.2006 17:10
-- Purpose : Функция проверки обязательной установки серийного номера у определенного типа оборудования
--------------------------------------------------------------------------------
   FUNCTION chk_availability_sn (p_equipment_type_id IN NUMBER DEFAULT NULL)
      RETURN BOOLEAN
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'chk_availability_sn';
      l_result            BOOLEAN;
      l_has_sn            CHAR;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      IF p_equipment_type_id IS NULL
      THEN
         l_result := FALSE;   --серийный номер для оборудования не нужен
         RETURN l_result;
      ELSE
         SELECT has_serial_number
           INTO l_has_sn
           FROM vw_equipment_type
          WHERE equipment_type_id = NVL (p_equipment_type_id, util_stock.c_not_exists_num);

         IF l_has_sn = 'Y'
         THEN
            l_result := TRUE;   --серийный номер для оборудования нужен
         ELSE
            l_result := FALSE;   --серийный номер для оборудования не нужен
         END IF;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      RETURN l_result;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         l_result := FALSE;   --серийный номер для оборудования не нужен
         RETURN l_result;
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
	 RETURN FALSE;
   END chk_availability_sn;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.11.2006 14:33
-- Editor  :
-- Changed :
-- Purpose : Функция проверки пересечения серийных номеров оборудования
-- (во всех случаях включения\пересечения)
--------------------------------------------------------------------------------
   FUNCTION chk_cross_series_all (
      p_seria_start          IN   NVARCHAR2,
      p_seria_end            IN   NVARCHAR2,
      p_doc_header_id        IN   NUMBER,
      p_stock_id             IN   NUMBER DEFAULT NULL,
      p_equipment_model_id   IN   NUMBER DEFAULT NULL
   )
      RETURN BOOLEAN
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'chk_cross_series_all';
      l_bool              BOOLEAN;
   BEGIN
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_seria_start
                         || ','
                         || p_seria_end
                         || ','
                         || p_doc_header_id
                         || ','
                         || p_stock_id
                         || ','
                         || p_equipment_model_id
                         || ')',
                         pkg_name
                        );

      IF p_seria_start = p_seria_end   --Если проверяемая серия одиночная...
      THEN
         pkg_db_util.DEBUG (prc_name, 'check single series...', pkg_name);

         --Проверим пересечение с другими одиночными серями
         FOR cur IN (SELECT --+ FIRST_ROWS
                            ROWNUM
                       FROM stock_state
                      WHERE (seria_start = p_seria_start OR seria_end = p_seria_end)
                        AND (doc_header_id <> p_doc_header_id OR p_doc_header_id = 0)
                        AND ROWNUM = 1)
         LOOP
            pkg_db_util.DEBUG (prc_name, 'TRUE', pkg_name);
            RETURN TRUE;
         END LOOP;

         --Проверим пересечение\вхождение с неодиночными серями
         FOR cur IN (SELECT --+ FIRST_ROWS INDEX(stock_state IDX_STOCKSTATE_INS)
                            ROWNUM
                       FROM stock_state
                      WHERE p_seria_start BETWEEN seria_start AND seria_end
                        AND (doc_header_id <> p_doc_header_id OR p_doc_header_id = 0)
                        AND LENGTH (seria_start) = LENGTH (p_seria_start)
                        AND LENGTH (seria_end) = LENGTH (p_seria_end)
                        AND is_nonsingle_series >= 1
                        AND ROWNUM = 1)
         LOOP
            pkg_db_util.DEBUG (prc_name, 'TRUE', pkg_name);
            RETURN TRUE;
         END LOOP;
      ELSE   --Если проверяемая серия не одиночная...
         pkg_db_util.DEBUG (prc_name, 'check no single series...', pkg_name);
         --Проверим пересечение\вхождение с неодиночными серями где проверяемая
         --серия НЕ полностью лежит внутри существующего диапозона
         l_bool := chk_cross_series_outher (p_seria_start, p_seria_end, p_doc_header_id);

         IF NOT l_bool   --Если пересечение с серями ненайдено...
         THEN
            --Проверим пересечение\вхождение с неодиночными серями где проверяемая
            --серия полностью лежит внутри существующего диапозона
            l_bool := chk_cross_series_inner (p_seria_start, p_seria_end, p_doc_header_id);
         END IF;
      END IF;

      IF l_bool
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_common.boolean_to_char (l_bool), pkg_name);
         RETURN TRUE;   -- Есть пересечение серий
      END IF;

      pkg_db_util.DEBUG (prc_name, 'FALSE', pkg_name);
      RETURN FALSE;   -- Нет пересечения серий
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
      RETURN FALSE;
   END chk_cross_series_all;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 22.11.2006 13:24
-- Editor  :
-- Changed :
-- Purpose : Функция проверки пересечения серийных номеров оборудования
--(только параметров полностью лежащих внутри сушествующего диапозона не еденичных серий оборудования)
--------------------------------------------------------------------------------
   FUNCTION chk_cross_series_inner (
      p_seria_start          IN   NVARCHAR2,
      p_seria_end            IN   NVARCHAR2,
      p_doc_header_id        IN   NUMBER,
      p_stock_id             IN   NUMBER DEFAULT NULL,
      p_equipment_model_id   IN   NUMBER DEFAULT NULL
   )
      RETURN BOOLEAN
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'chk_cross_series_inner';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      util_loc_pkg.touch_number(p_stock_id);
      util_loc_pkg.touch_number(p_equipment_model_id);

      FOR cur IN (SELECT --+ INDEX(stock_state IDX_STOCKSTATE_INS)
                         ROWNUM
                    FROM stock_state
                   WHERE (   (p_seria_start BETWEEN seria_start AND seria_end)
                          OR (p_seria_end BETWEEN seria_start AND seria_end)
                         )
                     AND (doc_header_id <> p_doc_header_id OR p_doc_header_id = 0)
                     AND LENGTH (seria_start) = LENGTH (p_seria_start)
                     AND LENGTH (seria_end) = LENGTH (p_seria_end)
                     AND ROWNUM = 1
                     AND is_nonsingle_series >= 1)
      LOOP
         pkg_db_util.DEBUG (prc_name, 'TRUE', pkg_name);
         RETURN TRUE;   -- Есть пересечение серий
      END LOOP;

      pkg_db_util.DEBUG (prc_name, 'FALSE', pkg_name);
      RETURN FALSE;   -- Нет пересечения серий
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
      RETURN FALSE;
   END chk_cross_series_inner;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 22.11.2006 13:14
-- Editor  :
-- Changed :
-- Purpose : Функция проверки пересечения серийных номеров оборудования
--(кроме параметров полностью лежащих внутри сушествующего диапозона)
--------------------------------------------------------------------------------
   FUNCTION chk_cross_series_outher (
      p_seria_start          IN   NVARCHAR2,
      p_seria_end            IN   NVARCHAR2,
      p_doc_header_id        IN   NUMBER,
      p_stock_id             IN   NUMBER DEFAULT NULL,
      p_equipment_model_id   IN   NUMBER DEFAULT NULL
   )
      RETURN BOOLEAN
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'chk_cross_series_outher';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      util_loc_pkg.touch_number(p_stock_id);
      util_loc_pkg.touch_number(p_equipment_model_id);

      FOR cur IN (SELECT --+ INDEX(stock_state I_STOCK_STATE_SE) INDEX(stock_state I_STOCK_STATE_SS)
                         ROWNUM
                    FROM stock_state
                   WHERE (   (seria_start BETWEEN p_seria_start AND p_seria_end)
                          OR (seria_end BETWEEN p_seria_start AND p_seria_end)
                         )
                     AND (doc_header_id <> p_doc_header_id OR p_doc_header_id = 0)
                     AND LENGTH (seria_start) = LENGTH (p_seria_start)
                     AND LENGTH (seria_end) = LENGTH (p_seria_end)
                     AND ROWNUM <= 1)
      LOOP
         pkg_db_util.DEBUG (prc_name, 'TRUE', pkg_name);
         RETURN TRUE;   -- Есть пересечение серий
      END LOOP;

      pkg_db_util.DEBUG (prc_name, 'FALSE', pkg_name);
      RETURN FALSE;   -- Нет пересечения серий
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END chk_cross_series_outher;

--------------------------------------------------------------------------------
-- Author  : Anoev Maxim
-- Created : 20.03.2007 14:34
-- Editor  : Skripnik Petr
-- Changed : 02.04.2007 13:18
-- Purpose : Удалить пакет оборудования
--------------------------------------------------------------------------------
   PROCEDURE del_package (p_package_model_id IN NUMBER, p_user IN NVARCHAR2)
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'del_package';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                         '(' || p_package_model_id || pkg_constants.c_delimiter || p_user || ')',
                         pkg_name
                        );

      DELETE FROM equipment_package
            WHERE package_model_id = p_package_model_id;

      pkg_db_util.DEBUG (prc_name, 'Count: ' || SQL%ROWCOUNT, pkg_name);

      util_stock.log_log(p_user, util_stock.c_la_eq_pack_rem, p_package_model_id);

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END del_package;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 28.06.2007 11:37
-- Version :
--   1 28.06.2007
-- Modification : alarm_management.alarm__get
-- Editor  :
-- Changed :
-- Purpose : Получение записей о критических запасах оборудования на складе
--------------------------------------------------------------------------------
   PROCEDURE get_alarm (
      p_id                   IN       NUMBER,
      p_stock_id             IN       NUMBER,
      p_equipment_model_id   IN       NUMBER,
      p_alarm_rec            OUT      sys_refcursor
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_alarm';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_id
                         || pkg_constants.c_delimiter
                         || p_stock_id
                         || pkg_constants.c_delimiter
                         || p_equipment_model_id
                         || ')',
                         pkg_name
                        );

      OPEN p_alarm_rec FOR
         SELECT   a.ID AS "Id", a.stock_id AS "Stock Id", a.equipment_model_id AS "Item Id",
                  em.equipment_model_name AS "Item Name", a.min_value AS "Min. Value",
                  a.max_value AS "Max. Value", p.producer_name AS "Producer"
             FROM alarm a INNER JOIN equipment_model em ON a.equipment_model_id =
                                                                               em.equipment_model_id
                  LEFT OUTER JOIN producer p ON em.producer_id = p.producer_id
            WHERE a.ID = p_id
               OR a.stock_id = p_stock_id
               OR a.equipment_model_id = p_equipment_model_id
         ORDER BY a.equipment_model_id;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_alarm;

--------------------------------------------------------------------------------
-- Author  : Anoev Maxim
-- Created : 20.03.2007 14:34
-- Editor  : Skripnik Petr
-- Changed : 02.04.2007 13:13
-- Purpose : Возвращает все модели оборудования, на основе которого могут формироваться пакеты
--------------------------------------------------------------------------------
   PROCEDURE get_eqm_for_package (p_out_cur OUT sys_refcursor)
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_eqm_for_package';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      OPEN p_out_cur FOR
         SELECT em.equipment_model_id, em.equipment_model_code, em.equipment_model_name,
                em.equipment_type_id, et.system_type_code, ep.ID AS equipment_package_id,
                ep.base_model_id AS equipment_base_model_id,
                em2.equipment_model_code AS equipment_base_model_code,
                em2.equipment_model_name AS equipment_base_model_name, ep.description
           FROM equipment_model em, vw_equipment_type et, equipment_package ep,
                equipment_model em2
          WHERE em.equipment_type_id = et.equipment_type_id
            AND em.equipment_model_id = ep.package_model_id(+)
            AND em2.equipment_model_id(+) = ep.base_model_id
            AND et.is_package = 'Y'
            AND em.deleted IS NULL
            AND et.deleted IS NULL;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_eqm_for_package;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 27.12.2006 11:50
-- Editor  :
-- Changed :
-- Purpose : Получение идентификатора модели оборудования по коду модели оборудования
--------------------------------------------------------------------------------
   FUNCTION get_modelid_by_modelcode (p_equipment_model_code IN VARCHAR2)
      RETURN NUMBER
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_modelid_by_modelcode';
      l_result            NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      SELECT equipment_model_id
        INTO l_result
        FROM equipment_model
       WHERE equipment_model_code = TRIM (p_equipment_model_code);

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      RETURN l_result;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         --(* 2)временно пока -1 сравнивается как ВСЕ
         l_result := util_stock.c_not_exists_num * 2;
         RETURN l_result;
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_modelid_by_modelcode;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.03.2007 10:29
-- Editor  :
-- Changed :
-- Purpose : Возвращает пакеты оборудования
--------------------------------------------------------------------------------
   PROCEDURE get_package (p_package_model_id IN NUMBER, p_out_cur OUT sys_refcursor)
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_package';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      OPEN p_out_cur FOR
         SELECT p.ID, p.package_model_id, p.base_model_id, p.description, d.ID, d.package_id,
                d.equipment_model_id, d.quantity
           FROM equipment_package p, equipment_package_definition d
          WHERE p.ID = d.package_id(+) AND p.package_model_id = p_package_model_id;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_package;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 18.12.2006 11:18
-- Editor  :
-- Changed :
-- Purpose : Устанавливает максимальную или(и) минимальную серию оборудования определенной длинны
--------------------------------------------------------------------------------
   PROCEDURE get_seria_not_null (p_seria_start IN OUT NVARCHAR2, p_seria_end IN OUT NVARCHAR2)
   AS
      prc_name    CONSTANT NVARCHAR2 (100)                := pkg_name || 'get_seria_not_null';
      min_seria   CONSTANT NVARCHAR2 (50)                 := '0';
      max_seria   CONSTANT NVARCHAR2 (50)   := 'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz';
      l_seria_start        stock_state.seria_start%TYPE;
      l_seria_end          stock_state.seria_end%TYPE;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name, '(' || p_seria_start || ',' || p_seria_end || ')', pkg_name);
      --Устанавливаем серии оборудования
      l_seria_start := p_seria_start;
      l_seria_end := p_seria_end;

      IF (p_seria_start IS NULL) AND (p_seria_end IS NULL)
      THEN
         l_seria_start := min_seria;
         l_seria_end := max_seria;
      ELSIF (p_seria_start IS NULL)
      THEN
         l_seria_start := RPAD ('0', LENGTH (p_seria_end), '0');
      ELSIF (p_seria_end IS NULL)
      THEN
         l_seria_end := RPAD ('z', LENGTH (p_seria_start), 'z');
      END IF;

      p_seria_start := l_seria_start;
      p_seria_end := l_seria_end;
      pkg_db_util.DEBUG (prc_name, p_seria_start || ',' || p_seria_end, pkg_name);
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_seria_not_null;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr, Anoev Maxim
-- Created : 26.01.2007 14:46
-- Editor  :
-- Changed :
-- Purpose : Получим всю таблицу моделей оборудования
--------------------------------------------------------------------------------
   PROCEDURE get_tab_equipment_model (p_out_cur OUT sys_refcursor, p_error_code OUT NUMBER)
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_tab_equipment_model';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      OPEN p_out_cur FOR
         SELECT equipment_model_id, equipment_model_code, equipment_model_name, user_id_of_change,
                date_of_change, deleted, producer_id, equipment_type_id, sn,
                DECODE (NVL (sn, -1),
                        -1, equipment_model_code,
                        '[' || LPAD (sn, 8, '0') || ']' || equipment_model_code
                       ) AS sn_code
           FROM equipment_model;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_tab_equipment_model;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 06.10.2006 10:23
-- Editor  : Skripnik Petr
-- Changed :
--   Skripnik Petr 27.12.2006 Связал stock_state, equipment_model,equipment_type
--   Skripnik Petr 15.01.2007 11:17 Добавил поле Status в возвр. курсор
--   Skripnik Petr 15.01.2007 11:33 p_reserved(NVARCHAR2) -> p_unreserved(NUMBER)
--   Skripnik Petr 17.04.2007 11:27 Удалены колонки MIN_VALUE и ALARM_ID
--   Anoev Maxim 08.05.2007 Удалено DECODE (a.reserved, NULL, 'F', 'R') AS reserved_status
-- Purpose : Процедура возвращающая набор диапазонов для оборудования
--------------------------------------------------------------------------------
   PROCEDURE get_range_series (
      p_stock_id             IN       NUMBER,
      p_equipment_model_id   IN       NUMBER,
      p_seria_start          IN       NVARCHAR2,
      p_seria_end            IN       NVARCHAR2,
      p_quantity             IN       NUMBER,
      p_unreserved           IN       NUMBER,
      p_valid_until          IN       DATE,
      p_cur_emt_range        OUT      sys_refcursor,
      p_error_code           OUT      NUMBER
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_range_series';
      l_quantity          NUMBER;
   BEGIN
      l_quantity := p_quantity;
      p_error_code := 0;

      --Если заданы начало и конец диапазона, то параметр количество игнорируется
      IF (p_seria_start IS NOT NULL) AND (p_seria_end IS NOT NULL)
      THEN
         l_quantity := 0;   --обнуляем значение чтобы незашол в следующий цикл

         OPEN p_cur_emt_range FOR
            SELECT   a.stock_id, a.equipment_model_id, a.seria_start, a.seria_end,
                     a.quantity_onstock, a.quantity_reserved, a.quantity_announced,
                     a.doc_header_id, a.create_date, a.status, a.equipment_type_id, a.reserved,
                     a.user_comment, em.equipment_model_code, em.equipment_model_name,
                     a.equipment_batch_id,
                     DECODE (a.quantity_reserved, 0, 'F', 'R') AS reserved_status
                FROM (SELECT stock_id, equipment_model_id, seria_start, seria_end, quantity_onstock,
                             quantity_reserved, quantity_announced, doc_header_id, create_date,
                             status, equipment_type_id, reserved, user_comment, equipment_batch_id
                        FROM stock_state
                       WHERE (   seria_start >= p_seria_start
                              OR (p_seria_start BETWEEN seria_start AND seria_end)
                             )
                         AND LENGTH (seria_start) = LENGTH (p_seria_start)
                         AND stock_id = p_stock_id
                         AND equipment_model_id = p_equipment_model_id
                         AND create_date >= p_valid_until
                         AND status = 1
                         AND (   (p_unreserved = 1 AND quantity_onstock > 0)
                              OR (    p_unreserved = 0
                                  AND (quantity_onstock > 0 OR quantity_reserved > 0)
                                 )
                             )) a,
                     equipment_model em
               WHERE a.equipment_model_id = em.equipment_model_id
                 AND (   a.seria_end <= p_seria_end
                      OR (p_seria_end BETWEEN a.seria_start AND a.seria_end)
                     )
                 AND LENGTH (a.seria_end) = LENGTH (p_seria_end)
            ORDER BY a.seria_start;
      END IF;

      --Если задан начало диапазона и количество, то формируется партия с заданным
      --количеством оборудования начиная с заданного номера партии
      IF (p_seria_start IS NOT NULL) AND (l_quantity <> 0)
      THEN
         OPEN p_cur_emt_range FOR
            SELECT   a.stock_id, a.equipment_model_id, a.seria_start, a.seria_end,
                     a.quantity_onstock, a.quantity_reserved, a.quantity_announced,
                     a.doc_header_id, a.create_date, a.status, a.equipment_type_id, a.reserved,
                     a.user_comment, em.equipment_model_code, em.equipment_model_name,
                     a.equipment_batch_id, a.sum_quantity_onstock,
                     DECODE (a.quantity_reserved, 0, 'F', 'R') AS reserved_status
                FROM (SELECT   stock_id, equipment_model_id, seria_start, seria_end,
                               quantity_onstock, quantity_reserved, quantity_announced,
                               doc_header_id, create_date, status, equipment_type_id, reserved,
                               user_comment, equipment_batch_id,
                               SUM (quantity_onstock) OVER (PARTITION BY stock_id, equipment_model_id ORDER BY seria_start)
                                                                            AS sum_quantity_onstock
                          FROM stock_state
                         WHERE (   seria_start >= p_seria_start
                                OR (p_seria_start BETWEEN seria_start AND seria_end)
                               )
                           AND LENGTH (seria_start) = LENGTH (p_seria_start)
                           AND stock_id = p_stock_id
                           AND equipment_model_id = p_equipment_model_id
                           AND create_date >= p_valid_until
                           AND status = 1
                           AND (   (p_unreserved = 1 AND quantity_onstock > 0)
                                OR (    p_unreserved = 0
                                    AND (quantity_onstock > 0 OR quantity_reserved > 0)
                                   )
                               )
                      ORDER BY seria_start) a,
                     equipment_model em
               WHERE a.equipment_model_id = em.equipment_model_id
                 AND p_quantity > a.sum_quantity_onstock - a.quantity_onstock
            ORDER BY a.seria_start;
      END IF;

      --Если начало и конец диапазона не заданы но задано количество, то формируется
      --партия с заданным количеством оборудования начиная с наименьшего номера доступного оборудования.
      IF (p_seria_start IS NULL) AND (p_seria_end IS NULL) AND (p_quantity <> 0)
      THEN
         OPEN p_cur_emt_range FOR
            SELECT   a.stock_id, a.equipment_model_id, a.seria_start, a.seria_end,
                     a.quantity_onstock, a.quantity_reserved, a.quantity_announced,
                     a.doc_header_id, a.create_date, a.status, a.equipment_type_id, a.reserved,
                     a.user_comment, em.equipment_model_code, em.equipment_model_name,
                     a.equipment_batch_id, a.sum_quantity_onstock,
                     DECODE (a.quantity_reserved, 0, 'F', 'R') AS reserved_status
                FROM (SELECT   stock_id, equipment_model_id, seria_start, seria_end,
                               quantity_onstock, quantity_reserved, quantity_announced,
                               doc_header_id, create_date, status, equipment_type_id, reserved,
                               user_comment, equipment_batch_id,
                               SUM (quantity_onstock) OVER (PARTITION BY stock_id, equipment_model_id ORDER BY seria_start)
                                                                            AS sum_quantity_onstock
                          FROM stock_state
                         WHERE stock_id = p_stock_id
                           AND equipment_model_id = p_equipment_model_id
                           AND create_date >= p_valid_until
                           AND status = 1
                           AND (   (p_unreserved = 1 AND quantity_onstock > 0)
                                OR (    p_unreserved = 0
                                    AND (quantity_onstock > 0 OR quantity_reserved > 0)
                                   )
                               )
                      ORDER BY seria_start) a,
                     equipment_model em
               WHERE a.equipment_model_id = em.equipment_model_id
                 AND p_quantity > a.sum_quantity_onstock - a.quantity_onstock
            ORDER BY a.seria_start;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_range_series;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 22.11.2006 11:47
-- Editor  :
-- Changed :
-- Purpose : Получение идентификатора типа оборудования по идентификатору модели оборудования
--------------------------------------------------------------------------------
   FUNCTION get_typeid_by_modelid (p_equipment_model_id IN NUMBER)
      RETURN NUMBER
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_typeid_by_modelid';
      l_result            NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      SELECT equipment_type_id
        INTO l_result
        FROM equipment_model
       WHERE equipment_model_id = p_equipment_model_id;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      RETURN l_result;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         --(* 2)временно пока -1 сравнивается как ВСЕ ОБОРУДОВАНИЕ
         l_result := util_stock.c_not_exists_num * 2;
         RETURN l_result;
   END get_typeid_by_modelid;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 28.06.2007 12:49
-- Version :
--   1 28.06.2007
-- Modification : alarm_management.alarm__ins
-- Editor  :
-- Changed :
-- Purpose : Вставка записей о критических запасах оборудования на складе
--------------------------------------------------------------------------------
   PROCEDURE ins_alarm (
      p_stock_id             IN       NUMBER,
      p_equipment_model_id   IN       NUMBER,
      p_min_value            IN       NUMBER,
      p_max_value            IN       NUMBER,
      p_error_code           OUT      NUMBER
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'upd_alarm';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_stock_id
                         || pkg_constants.c_delimiter
                         || p_equipment_model_id
                         || pkg_constants.c_delimiter
                         || p_min_value
                         || pkg_constants.c_delimiter
                         || p_max_value
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;

      INSERT INTO alarm
                  (id, stock_id, equipment_model_id, min_value, max_value
                  )
           VALUES (s_alarm.nextval, p_stock_id, p_equipment_model_id, p_min_value, p_max_value
                  );

      pkg_db_util.DEBUG (prc_name, 'Count: ' || SQL%ROWCOUNT, pkg_name);
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END ins_alarm;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 18.12.2006 11:18
-- Editor  :
-- Changed :
-- Purpose : Просмотрим контекст
--------------------------------------------------------------------------------
   PROCEDURE list_context
   IS
      prc_name   CONSTANT NVARCHAR2 (100)           := pkg_name || 'list_context';
      l_list              DBMS_SESSION.appctxtabtyp;
      l_size              NUMBER;
      l_strline           NVARCHAR2 (255);
      l_loop              PLS_INTEGER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      DBMS_SESSION.list_context (l_list, l_size);

      FOR l_loop IN 1 .. l_list.COUNT
      LOOP
         l_strline :=
               l_list (l_loop).namespace
            || ': '
            || l_list (l_loop).ATTRIBUTE
            || '='
            || l_list (l_loop).VALUE;
      END LOOP;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END list_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 19.02.2008 15:52
-- Version :
--   1 19.02.2008
-- Modification :
-- Editor  :
-- Changed :
-- Purpose : Использется, чтобы возвратить требуемое количество серийных номеров
--           в порядке возрастания от указанного диапозона
--------------------------------------------------------------------------------
   FUNCTION pivot_serial (p_seria_start IN pkg_common.t_varchar, p_seria_end IN pkg_common.t_varchar)
      RETURN ct_varchar PIPELINED
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'pivot_serial';
      l_ss                NVARCHAR2 (50)  DEFAULT NULL;
      l_se                NVARCHAR2 (50)  DEFAULT NULL;
      l_length            NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      IF NOT(p_seria_start.COUNT = 1 AND p_seria_start(p_seria_start.FIRST) IS NULL) OR
         NOT(p_seria_end.COUNT = 1 AND p_seria_end(p_seria_end.FIRST) IS NULL)
      THEN
      FOR i IN 1 .. GREATEST (p_seria_start.COUNT, p_seria_end.COUNT)
      LOOP
         l_ss := p_seria_start (i);
         l_se := p_seria_end (i);
         l_length := LENGTH (l_ss);

         IF l_length <> LENGTH (l_se)
         THEN
            raise_application_error (-20001, 'Length error');
         ELSE
            FOR k IN TO_NUMBER (l_ss) .. TO_NUMBER (l_se)
            LOOP
               PIPE ROW (LPAD (TO_CHAR (k), l_length, '0'));
            END LOOP;
         END IF;
      END LOOP;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      RETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END pivot_serial;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.01.2007 15:34
-- Version :
--   1 23.01.2007
-- Modification : bulk_insert_management.bulk_insert_tmp_equipment_id
--              + bulk_insert_management.bulk_insert_tmp_equipment_id2
-- Editor  :
-- Changed :
-- Purpose : Устанавливает идентификаторы модели оборудования
-- Problems:
--   Не применять FOR i IN collection.FIRST .. collection.LAST при
--   возможности пустой коллекции
--------------------------------------------------------------------------------
   PROCEDURE set_modelid (
      p_model_id_1     IN   pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_flag_clear_1   IN   CHAR DEFAULT 'Y',
      p_model_id_2     IN   pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_flag_clear_2   IN   CHAR DEFAULT 'Y'
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'set_modelid';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      IF (p_flag_clear_1 = 'Y')   --Флаг предварительной очистки
      THEN
         --Чистим и инициализируем коллекцию идетификаторов складов
         g_tab_model_id := pkg_common.g_tab_empty_num;
         pkg_db_util.DEBUG (prc_name, 'clear collection equipment', pkg_name);
      END IF;

      IF NOT(p_model_id_1 IS NULL OR 
             p_model_id_1.COUNT = 0 OR
             (p_model_id_1.COUNT = 1 AND p_model_id_1(p_model_id_1.FIRST) IS NULL))
      THEN
          IF (p_model_id_1.EXISTS (1)) AND (p_model_id_1 (1) = util_stock.c_not_exists_num)
          --"Все оборудование" с установкой в коллекцию
          THEN
             SELECT equipment_model_id
             BULK COLLECT INTO g_tab_model_id
               FROM equipment_model;

             pkg_db_util.DEBUG (prc_name, 'all equipment insert into eqm collection', pkg_name);
          ELSIF p_model_id_1.EXISTS (1)
          THEN
             FOR i IN 1 .. p_model_id_1.COUNT
             LOOP
                IF (p_model_id_1.EXISTS (i)) AND (p_model_id_1 (i) IS NOT NULL)
                THEN
                   g_tab_model_id.EXTEND;
                   g_tab_model_id (g_tab_model_id.COUNT) := p_model_id_1 (i);
                   pkg_db_util.DEBUG (prc_name, 'eqm model = ' || p_model_id_1 (i), pkg_name);
                END IF;
             END LOOP;
          END IF;
      END IF;

      pkg_db_util.DEBUG (prc_name, 'eqm.COUNT ' || g_tab_model_id.COUNT, pkg_name);

      --Установим второй набор моделей оборудования
      IF (p_flag_clear_2 = 'Y')   --Флаг предварительной очистки
      THEN
         --Чистим и инициализируем коллекцию идетификаторов складов
         g_tab2_model_id := pkg_common.g_tab_empty_num;
         pkg_db_util.DEBUG (prc_name, 'clear collection equipment', pkg_name);
      END IF;

      IF NOT(p_model_id_2 IS NULL OR 
             p_model_id_2.COUNT = 0 OR
             (p_model_id_2.COUNT = 1 AND p_model_id_2(p_model_id_2.FIRST) IS NULL))
      THEN
          IF (p_model_id_2.EXISTS (1)) AND (p_model_id_2 (1) = util_stock.c_not_exists_num)
          --"Все оборудование" с установкой в коллекцию
          THEN
             SELECT equipment_model_id
             BULK COLLECT INTO g_tab2_model_id
               FROM equipment_model;

             pkg_db_util.DEBUG (prc_name, 'all equipment insert into eqm collection', pkg_name);
          ELSIF p_model_id_2.EXISTS (1)
          THEN
             FOR i IN 1 .. p_model_id_2.COUNT
             LOOP
                IF (p_model_id_2.EXISTS (i)) AND (p_model_id_2 (i) IS NOT NULL)
                THEN
                   g_tab2_model_id.EXTEND;
                   g_tab2_model_id (g_tab2_model_id.COUNT) := p_model_id_2 (i);
                   pkg_db_util.DEBUG (prc_name, 'eqm model 2 = ' || p_model_id_2 (i), pkg_name);
                END IF;
             END LOOP;
          END IF;
      END IF;

      pkg_db_util.DEBUG (prc_name, 'eqm2.COUNT ' || g_tab2_model_id.COUNT, pkg_name);
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END set_modelid;

--------------------------------------------------------------------------------
-- Author  : Anoev Maxim
-- Created : 20.03.2007 14:34
-- Editor  : Skripnik Petr
-- Changed :
--   Skripnik Petr 02.04.2007 DEBUG,FORALL
--   Skripnik Petr 23.04.2007 Добавил блок и его обработку - SAVE EXCEPTIONS
-- Purpose : Формирует пакет оборудования для заданной модели
--------------------------------------------------------------------------------
   PROCEDURE set_package (
      p_package_model_id   IN       NUMBER,
      p_base_model_id      IN       NUMBER,
      p_description        IN       NVARCHAR2,
      p_eqm_model          IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_eqm_quantity       IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_user               IN       NVARCHAR2,
      p_error_code         OUT      NUMBER
   )
   IS
      prc_name     CONSTANT NVARCHAR2 (100) := pkg_name || 'set_package';
      l_package_id          NUMBER;
      l_bulk_errors         EXCEPTION;
      PRAGMA EXCEPTION_INIT (l_bulk_errors, -24381);

      CURSOR l_cur (l_package_model_id IN NUMBER)
      IS
         SELECT ID
           FROM equipment_package
          WHERE package_model_id = l_package_model_id;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_package_model_id
                         || pkg_constants.c_delimiter
                         || p_base_model_id
                         || pkg_constants.c_delimiter
                         || p_description
                         || pkg_constants.c_delimiter
                         || p_eqm_model.COUNT
                         || pkg_constants.c_delimiter
                         || p_eqm_quantity.COUNT
                         || pkg_constants.c_delimiter
                         || p_user
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;

      OPEN l_cur (p_package_model_id);

      LOOP
         FETCH l_cur
          INTO l_package_id;

         EXIT WHEN l_cur%NOTFOUND;
         NULL;
      END LOOP;

      CLOSE l_cur;

      IF l_package_id IS NULL
      THEN
         l_package_id := sq_equipment_package.nextval;
         INSERT INTO equipment_package
                     (id, package_model_id, base_model_id, description
                     )
              VALUES (l_package_id, p_package_model_id, p_base_model_id, p_description
                     )
         ;
      ELSE
         --пакет сформирован, обновим
         UPDATE equipment_package
            SET base_model_id = p_base_model_id,
                description = p_description
          WHERE package_model_id = p_package_model_id;

         --удалим записи из описания пакета
         DELETE FROM equipment_package_definition
               WHERE package_id = l_package_id;
      END IF;

      IF NOT(p_eqm_model.COUNT = 1 AND p_eqm_model(p_eqm_model.FIRST) IS NULL) AND
         NOT(p_eqm_quantity.COUNT = 1 AND p_eqm_quantity(p_eqm_quantity.FIRST) IS NULL) AND
         p_eqm_model.EXISTS (1) AND p_eqm_quantity.EXISTS (1)
      THEN
         FORALL i IN p_eqm_model.FIRST .. p_eqm_model.LAST SAVE EXCEPTIONS
            INSERT INTO equipment_package_definition
                        (id, package_id, equipment_model_id, quantity
                        )
                 VALUES (sq_equipment_package_def.nextval, l_package_id, p_eqm_model (i), p_eqm_quantity (i)
                        );

         FOR i IN p_eqm_model.FIRST .. p_eqm_model.LAST
         LOOP
            pkg_db_util.DEBUG (prc_name,
                               'Iteration #' || i || ' inserted ' || SQL%BULK_ROWCOUNT (i)
                               || ' rows.',
                               pkg_name
                              );
         END LOOP;
      END IF;

      util_stock.log_log(p_user, util_stock.c_la_eq_pack_add, p_package_model_id);

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN l_bulk_errors
      THEN
         FOR i IN 1 .. SQL%BULK_EXCEPTIONS.COUNT
         LOOP
            pkg_db_util.DEBUG (prc_name,
                                  'Error '
                               || i
                               || ' occurred during '
                               || 'iteration '
                               || SQL%BULK_EXCEPTIONS (i).ERROR_INDEX
                               || ' inserting equipment_model_id to '
                               || p_eqm_model (SQL%BULK_EXCEPTIONS (i).ERROR_INDEX),
                               pkg_name
                              );
            pkg_db_util.DEBUG (prc_name,
                                  'Oracle error is '
                               || SQLERRM (-1 * SQL%BULK_EXCEPTIONS (i).ERROR_CODE),
                               pkg_name
                              );
         END LOOP;
      WHEN OTHERS
      THEN
         IF l_cur%ISOPEN
         THEN
            CLOSE l_cur;
         END IF;

         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END set_package;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 20.02.2007 14:34
-- Editor  :
-- Changed :
-- Purpose : Устанавливает два массива серии оборудования в один массив с двумя полями
--           обрабатывая NULL значения
--------------------------------------------------------------------------------
   PROCEDURE set_series (
      p_seria_start   IN   pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar,
      p_seria_end     IN   pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar,
      p_flag_clear    IN   CHAR DEFAULT 'Y'
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'set_series';
      l_ss                NVARCHAR2 (50)  DEFAULT NULL;
      l_se                NVARCHAR2 (50)  DEFAULT NULL;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_seria_start.COUNT)
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_seria_end.COUNT)
                         || ')',
                         pkg_name
                        );

      IF (p_flag_clear = 'Y') OR (g_tab_series IS NULL)
      THEN
         g_tab_series := g_tab_empty_series;
      END IF;

      IF ((p_seria_start.COUNT = 1 AND p_seria_start(p_seria_start.FIRST) IS NULL) AND
         (p_seria_end.COUNT = 1 AND p_seria_end(p_seria_end.FIRST) IS NULL)) OR
         ((NOT (p_seria_start.EXISTS (1))) AND (NOT (p_seria_end.EXISTS (1))))
      THEN
         --Все возможные серии
         g_tab_series := g_tab_empty_series;
      ELSE
         FOR i IN 1 .. GREATEST (p_seria_start.COUNT, p_seria_end.COUNT)
         LOOP
            g_tab_series.EXTEND;

            IF p_seria_start.EXISTS (i)
            THEN
               l_ss := p_seria_start (i);
            ELSE
               l_ss := NULL;
            END IF;

            IF p_seria_end.EXISTS (i)
            THEN
               l_se := p_seria_end (i);
            ELSE
               l_se := NULL;
            END IF;

            IF (l_ss IS NULL) OR (l_se IS NULL)
            THEN
               get_seria_not_null (l_ss, l_se);
            END IF;

            g_tab_series (g_tab_series.COUNT) := ot_series (l_ss, l_se);
         END LOOP;
      END IF;

      pkg_db_util.DEBUG (prc_name, 'Count: ' || g_tab_series.COUNT, pkg_name);
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END set_series;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 28.06.2007 12:44
-- Version :
--   1 28.06.2007
-- Modification : alarm_management.alarm__upd
-- Editor  :
-- Changed :
-- Purpose : Изменение записей о критических запасах оборудования на складе
--------------------------------------------------------------------------------
   PROCEDURE upd_alarm (
      p_id           IN       NUMBER,
      p_min_value    IN       NUMBER,
      p_max_value    IN       NUMBER,
      p_error_code   OUT      NUMBER
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'upd_alarm';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_id
                         || pkg_constants.c_delimiter
                         || p_min_value
                         || pkg_constants.c_delimiter
                         || p_max_value
                         || pkg_constants.c_delimiter
                         || 'OUT'
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;

      UPDATE alarm
         SET min_value = p_min_value,
             max_value = p_max_value
       WHERE ID = p_id;

      pkg_db_util.DEBUG (prc_name, 'Count: ' || SQL%ROWCOUNT, pkg_name);
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END upd_alarm;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Get_Equipment_List_By_Type
(
    p_equipment_type_code            varchar2,
    p_equipment_model_code           util_pkg.cit_varchar_s,
    p_seria_start                    util_pkg.cit_nvarchar_s,
    p_seria_end                      util_pkg.cit_nvarchar_s,
    p_stock_codes                    util_pkg.cit_nvarchar_s,
    p_quantity_equipment             number,
    p_is_detail_error                number,
    p_user_login                     users.user_name%type,
    p_error_code                     out number,
    p_error_message                  out varchar2,
    p_equipment_results              out sys_refcursor,
    p_equipment_errors               out sys_refcursor
)
is
  v_date date := sysdate;
  v_user_id number;
  v_quantity_equipment number := nvl(p_quantity_equipment, 0);
  --
  v_eq_type_code ct_varchar_s;
  v_equipment_model_code ct_varchar_s;
  v_models ct_model;
  v_model_ids ct_number;
  --
  v_seria_start ct_nvarchar_s;
  v_seria_end ct_nvarchar_s;
  --
  v_stock_codes ct_nvarchar_s;
  v_stock_ids ct_number;
  v_stock_codes_unavail ct_nvarchar_s;
  v_stock_codes_wrong ct_nvarchar_s;
  --
  v_message nvarchar2(2000);
  --
  v_serial_numbers ct_nvarchar_s;
  v_ss_ids ct_number;
  v_ss_stock_ids ct_number;
  v_ss_model_ids ct_number;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_equipment_type_code is null, 'p_equipment_type_code');
  util_pkg.XCheckP_cit_nvarchar_s(p_seria_start, 'p_seria_start');
  util_pkg.XCheckP_cit_nvarchar_s(p_seria_end, 'p_seria_end');
  --!_!util_pkg.XCheckP_cit_nvarchar_s(p_stock_codes, 'p_stock_codes');
  util_pkg.XCheck_Cond_Missing(p_user_login is null, 'p_user_login');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_seria_start.count != p_seria_end.count, 'p_seria_start.count != p_seria_end.count');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user_login);
  ------------------------------
  v_equipment_model_code := util_pkg.cast_cit2ct_varchar_s(p_equipment_model_code, TRUE);
  ------------------------------
  if util_pkg.CheckP_ct_varchar_s(v_equipment_model_code)
  then
    ------------------------------
    v_models := util_stock.get_ct_model_fuzzy(v_equipment_model_code, v_date);
    ------------------------------
  else
    ------------------------------
    v_models := util_stock.get_ct_model2_fuzzy(util_stock.get_equipment_model_ids_all(v_date), v_date);
    ------------------------------
  end if;
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_eq_type_code, p_equipment_type_code);
  v_models := util_stock.filter_ct_model02(v_models, v_eq_type_code, true);
  ------------------------------
  if NOT util_stock.CheckP_ct_model(v_models)
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_equipment_not_found, util_loc_pkg.c_msg_equipment_not_found);
  end if;
  ------------------------------
  v_model_ids := util_stock.get_ct_model_ids(v_models);
  ------------------------------
  v_seria_start := util_pkg.cast_cit2ct_nvarchar_s(p_seria_start, TRUE);
  v_seria_end := util_pkg.cast_cit2ct_nvarchar_s(p_seria_end, TRUE);
  ------------------------------
  v_stock_codes := util_pkg.cast_cit2ct_nvarchar_s(p_stock_codes, TRUE);
  ------------------------------
  if util_pkg.CheckP_ct_nvarchar_s(v_stock_codes)
  then
    ------------------------------
    v_stock_codes_wrong := util_stock.get_invalid_stock_codes(v_stock_codes, v_date);
    ------------------------------
    if util_pkg.CheckP_ct_nvarchar_s(v_stock_codes_wrong)
    then
      v_message := util_pkg.merge_nstring(util_pkg.cast_ct_nvarchar_s2nvarchar(v_stock_codes_wrong), ',');
      util_pkg.raise_exception(util_loc_pkg.c_ora_stock_not_exists, util_loc_pkg.c_msg_stock_not_exists || util_pkg.c_msg_delim01 || util_pkg.nchar_to_char(v_message));
    end if;
    ------------------------------
    v_stock_codes_unavail := util_stock.get_unavail_stock_codes2(v_user_id, util_stock.c_perm_view, v_stock_codes, v_date);
    ------------------------------
    if util_pkg.CheckP_ct_nvarchar_s(v_stock_codes_unavail)
    then
      v_message := util_pkg.merge_nstring(util_pkg.cast_ct_nvarchar_s2nvarchar(v_stock_codes_unavail), ',');
      util_pkg.raise_exception(util_loc_pkg.c_ora_access_denied_to_stock, util_loc_pkg.c_msg_access_denied_to_stock || util_pkg.c_msg_delim01 || util_pkg.nchar_to_char(v_message));
    end if;
    ------------------------------
    v_stock_ids := util_stock.get_avail_stock_ids3(v_user_id, util_stock.c_perm_view, v_stock_codes, v_date);
    ------------------------------
  else
    ------------------------------
    v_stock_ids := util_stock.get_avail_stock_ids(v_user_id, util_stock.c_perm_view, v_date);
    ------------------------------
  end if;
  ------------------------------
  if v_quantity_equipment <= 0
  then
    v_quantity_equipment := util_stock.c_any_count;
  end if;
  ------------------------------
  if (1 = 1
    and v_quantity_equipment <= 0
    and p_is_detail_error <> 0
  )
  then
    ------------------------------
    v_serial_numbers := util_stock.split_ranges3(v_seria_start, v_seria_end);
    ------------------------------
    search_pkg.seek_active_single_eq_ii
    (
      p_serial_number => v_serial_numbers,
      p_stock_id => v_stock_ids,
      p_eq_model_id => v_model_ids,
      p_count => v_quantity_equipment, --!_!
      p_trim_empty => FALSE, --!_!
      p_ss_id => v_ss_ids,
      p_stock_id2 => v_ss_stock_ids,
      p_eq_model_id2 => v_ss_model_ids
    );
    ------------------------------
  else
    ------------------------------
    if v_stock_ids is not null and v_stock_ids.count = 1
    then
      ------------------------------
      search_pkg.find_active_single_eq_stock_ii
      (
        p_serial_number1 => v_seria_start,
        p_serial_number2 => v_seria_end,
        p_stock_id => v_stock_ids,
        p_eq_model_id => v_model_ids,
        p_count => v_quantity_equipment, --!_!
        p_trim_empty => TRUE, --!_!
        p_ss_id => v_ss_ids,
        p_ss_serial_number => v_serial_numbers,
        p_stock_id2 => v_ss_stock_ids,
        p_eq_model_id2 => v_ss_model_ids
      );
      ------------------------------
    else
      ------------------------------
      search_pkg.find_active_single_eq_ii
      (
        p_serial_number1 => v_seria_start,
        p_serial_number2 => v_seria_end,
        p_stock_id => v_stock_ids,
        p_eq_model_id => v_model_ids,
        p_count => v_quantity_equipment, --!_!
        p_trim_empty => TRUE, --!_!
        p_ss_id => v_ss_ids,
        p_ss_serial_number => v_serial_numbers,
        p_stock_id2 => v_ss_stock_ids,
        p_eq_model_id2 => v_ss_model_ids
      );
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  search_pkg.get_result_cursor07
  (
    p_serial_number => v_serial_numbers,
    p_ss_id => v_ss_ids,
    p_ss_stock_id => v_ss_stock_ids,
    p_ss_model_id => v_ss_model_ids,
    p_model => v_models,
    p_date => v_date,
    p_result => p_equipment_results
  );
  ------------------------------
  search_pkg.get_result_cursor08
  (
    p_serial_number => v_serial_numbers,
    p_ss_id => v_ss_ids,
    p_ss_stock_id => v_ss_stock_ids,
    p_ss_model_id => v_ss_model_ids,
    p_model => v_models,
    p_date => v_date,
    p_result => p_equipment_errors
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  rollback;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

END;
/
