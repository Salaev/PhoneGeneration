CREATE PACKAGE             "CORE" 
AS
/*****************************************************************************
<header>
  <name>                package CORE
  </name>
  <author>              Birukov Pavel
  </author>
  <version>             Skripnik Petr 01.08.2008 - Has copied according to the
                                      standard of development
                        Skripnik Petr 04.09.2008 - Добавлены процедуры
  </version>
  <Description>
  </Description>
  <Prerequisites>
   Run AS SYS:
     GRANT CREATE ANY CONTEXT TO user_schema;
     GRANT EXECUTE ON SYS.DBMS_PIPE TO user_schema;
   Run AS current user:
   CREATE OR REPLACE TYPE t_n AS TABLE OF NUMBER;

   CREATE OR REPLACE TYPE t_v AS TABLE OF VARCHAR (256);

     CREATE OR REPLACE TYPE t_d AS TABLE OF DATE;

     CREATE OR REPLACE CONTEXT CTX_CORE_GLOBAL USING core ACCESSED GLOBALLY

     CREATE OR REPLACE CONTEXT CTX_CORE USING core

     CREATE TABLE log_event
      (event_id                       NUMBER NOT NULL,
       event_type                     CHAR(2) NOT NULL,
       event_source                   VARCHAR2(63) NOT NULL,
       event_message                  VARCHAR2(1000) NOT NULL,
       event_user                     VARCHAR2(256) NOT NULL,
       event_terminal                 VARCHAR2(256) NOT NULL,
       event_time                     DATE NOT NULL)
     NOCACHE
     NOMONITORING

     ALTER TABLE log_event ADD CONSTRAINT pk_log_event PRIMARY KEY (event_id)USING INDEX

     COMMENT ON COLUMN log_event.event_terminal IS 'Name or IP address of computer from which the event comes from.'
     COMMENT ON COLUMN log_event.event_id IS 'Event identification'
     COMMENT ON COLUMN log_event.event_message IS 'Message describing the event.'
     COMMENT ON COLUMN log_event.event_source IS 'Event source name like location, computer, application, stored procedure, etc.'
     COMMENT ON COLUMN log_event.event_time IS 'Time of the event.'
     COMMENT ON COLUMN log_event.event_type IS 'I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit'
     COMMENT ON COLUMN log_event.event_user IS 'Name of user, who run this program unit.'

     CREATE SEQUENCE log_event_seq
     INCREMENT BY 1
     START WITH 1
     MINVALUE 1
     MAXVALUE 999999999999999999999999999
     NOCYCLE
     NOORDER
     NOCACHE

     CREATE TABLE global_value
      (NAME                           VARCHAR2(50) NOT NULL,
       VALUE                          VARCHAR2(50) NOT NULL,
       comments                       VARCHAR2(100),
     CONSTRAINT pk_global_value PRIMARY KEY (NAME)) ORGANIZATION INDEX

     CREATE OR REPLACE TRIGGER biur_global_value
     BEFORE INSERT OR UPDATE
     ON global_value
     REFERENCING NEW AS NEW OLD AS OLD
     FOR EACH ROW
     BEGIN
     IF INSERTING
     THEN
      :NEW.NAME := TRIM (UPPER (:NEW.NAME));
     END IF;
     IF UPDATING
     THEN
      :NEW.NAME := :OLD.NAME;
     END IF;
     :NEW.VALUE := TRIM (UPPER (NVL (:NEW.VALUE, core.c_text_none)));
     END;

     COMMENT ON TABLE global_value IS 'Таблица глобальных параметров. Параметр устанавливается из любой сессии и виден всем сессиям сразу'
     COMMENT ON COLUMN global_value.comments IS 'Комментарий'
     COMMENT ON COLUMN global_value.NAME IS 'Имя глобального параметра'
     COMMENT ON COLUMN global_value.VALUE IS 'Значение глобального параметра'

     INSERT INTO global_value VALUES('CHANNEL', NULL, 'NONE/Имя схемы/Имя канала');
     INSERT INTO global_value VALUES('OUTPUT', 'NONE', 'NONE/TABLE/FILE/PIPE/BUFFER');
     INSERT INTO global_value VALUES('PROCEDURE', 'NONE', 'NONE/Имя пакета.Имя процедуры');
     INSERT INTO global_value VALUES('USER', 'NONE', 'NONE/Логин пользователя');

     COMMIT

  </Prerequisites>
  <Application>
  </Application>
  <Parameters>
  </Parameters>
</header>
******************************************************************************/

   --CONSTANTS
   c_debug_level_0                 CONSTANT NUMBER                    := 0;   -- constant representing value debug level
   c_debug_level_1                 CONSTANT NUMBER                    := 1;
   c_debug_level_2                 CONSTANT NUMBER                    := 2;
   c_debug_level_3                 CONSTANT NUMBER                    := 3;
   c_delimiter                     CONSTANT CHAR (1)                  := ',';
   c_event_type_i                  CONSTANT VARCHAR2 (2)              := 'I';   -- constant representing value debug event type
   c_event_type_w                  CONSTANT VARCHAR2 (2)              := 'W';
   c_event_type_er                 CONSTANT VARCHAR2 (2)              := 'Er';
   c_event_type_d                  CONSTANT VARCHAR2 (2)              := 'D';
   c_event_type_ex                 CONSTANT VARCHAR2 (2)              := 'Ex';
   c_event_type_a                  CONSTANT VARCHAR2 (2)              := 'A';
   c_text_start                    CONSTANT VARCHAR2 (5)              := 'start';
   c_text_end                      CONSTANT VARCHAR2 (3)              := 'end';
   c_text_true                     CONSTANT VARCHAR2 (6)              := 'TRUE';
   c_text_false                    CONSTANT VARCHAR2 (6)              := 'FALSE';
   c_text_yes                      CONSTANT VARCHAR2 (6)              := 'YES';
   c_text_no                       CONSTANT VARCHAR2 (6)              := 'NO';
   c_text_no_data_found            CONSTANT VARCHAR2 (18)             := 'NO_DATA_FOUND';
   c_text_none                     CONSTANT VARCHAR2 (4)              := 'NONE';
   c_output_to_buffer              CONSTANT VARCHAR2 (6)              := 'BUFFER';   -- constant informating that the debug output will be performed by DBMS_OUTPUT package
   c_output_to_file                CONSTANT VARCHAR2 (6)              := 'FILE';   -- constant informating that the debug output will be performed to a text file
   c_output_to_table               CONSTANT VARCHAR2 (6)              := 'TABLE';   -- constant informating that the debug output will be performed to a table
   c_output_to_pipe                CONSTANT VARCHAR2 (6)              := 'PIPE';   -- constant informating that the debug output will be performed to a pipe
   c_global_value_output           CONSTANT VARCHAR2 (6)              := 'OUTPUT';
   c_global_value_procedure        CONSTANT VARCHAR2 (18)             := 'PROCEDURE';
   c_global_value_channel          CONSTANT VARCHAR2 (18)             := 'CHANNEL';
   c_global_value_user             CONSTANT VARCHAR2 (6)              := 'USER';
   c_without_error                 CONSTANT NUMBER                    := 0;
   c_handle_tran_s                 CONSTANT CHAR (1)                  := 'S';   -- constant representing 'S' value of the handle_tran parameter
   c_handle_tran_y                 CONSTANT CHAR (1)                  := 'Y';   -- constant representing 'Y' value of the handle_tran parameter
   c_handle_tran_n                 CONSTANT CHAR (1)                  := 'N';   -- constant representing 'N' value of the handle_tran parameter
   c_maxsysdate                    CONSTANT DATE            := TO_DATE ('31.12.9999', 'dd.mm.yyyy');   -- максимальная дата в системе
   c_minsysdate                    CONSTANT DATE            := TO_DATE ('01.01.0100', 'dd.mm.yyyy');   -- минимальная сушествующая дата
   c_interval_difference           CONSTANT NUMBER                    := 1 / (24 * 60 * 60);   -- difference between end_date and start_date of the next interval
   c_yes                           CONSTANT CHAR (1)                  := 'Y';
   c_no                            CONSTANT CHAR (1)                  := 'N';
   --ORA ERRORS
   c_ora_resource_busy                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (c_ora_resource_busy, -54);
   c_ora_invalid_handle            CONSTANT NUMBER (5)                := -20999;   -- constant indicating that invalid handle_tran parameter was used
   c_ora_invalid_delimiter         CONSTANT NUMBER (5)                := -20998;   --Неверный символ разделителя
   c_ora_invalid_output            CONSTANT NUMBER (5)                := -20997;
   c_ora_start_and_end_reverse     CONSTANT NUMBER (5)                := -20996;   --Начальное значение диапазаона меньше конечного значения
   c_ora_mutually_exclusive_val    CONSTANT NUMBER (5)                := -20995;   --Взаимоисключающие друг друга параметры
   c_ora_various_number_elements   CONSTANT NUMBER (5)                := -20994;   --Различное число элементов в массиве
   c_ora_bulk_errors                        EXCEPTION;
   PRAGMA EXCEPTION_INIT (c_ora_bulk_errors, -24381);

   --COMMON TYPES
   TYPE ti_number IS TABLE OF NUMBER
      INDEX BY BINARY_INTEGER;

   TYPE ti_varchar IS TABLE OF VARCHAR2 (256)
      INDEX BY BINARY_INTEGER;

   TYPE ti_char IS TABLE OF CHAR (1)
      INDEX BY PLS_INTEGER;

   TYPE ti_nvarchar IS TABLE OF NVARCHAR2 (2000)
      INDEX BY BINARY_INTEGER;

   TYPE ti_date IS TABLE OF DATE
      INDEX BY BINARY_INTEGER;

   TYPE ti_nclob IS TABLE OF NCLOB
      INDEX BY BINARY_INTEGER;

   TYPE ti_blob IS TABLE OF BLOB
      INDEX BY BINARY_INTEGER;

   empty_ti_number                          ti_number;
   empty_ti_varchar                         ti_varchar;
   empty_ti_nvarchar                        ti_nvarchar;
   empty_ti_date                            ti_date;
   empty_ti_nclob                           ti_nclob;
   empty_ti_blob                            ti_blob;
   --VARIABLES
   g_debug_level                            NUMBER                    DEFAULT c_debug_level_0;
   g_debug_all_sessions                     VARCHAR2 (6)              DEFAULT c_text_no;
   g_log_output                             global_value.VALUE%TYPE   DEFAULT c_text_no;
   g_event_source                           VARCHAR2 (63)             DEFAULT c_text_no;
   g_pipe_channel                           VARCHAR2 (256)            DEFAULT c_text_no;
   g_timer                                  BOOLEAN                   DEFAULT FALSE;   --флаг установки таймера

   --FUNCTIONS AND PROCEDURES
   FUNCTION boolean_to_char (p_value IN BOOLEAN)
      RETURN VARCHAR2;

   PROCEDURE check_handle_tran (p_handle_tran IN CHAR, p_procedure IN VARCHAR2);

   PROCEDURE clear_context;

   PROCEDURE compile_pkg;

   PROCEDURE compile_schema;

   PROCEDURE do_ddl (p_stmt IN LONG, p_level IN NUMBER);

   PROCEDURE event_logger (
      p_message        IN   log_event.event_message%TYPE,   -- text to send to output
      p_level          IN   NUMBER,   -- level of debuging
      p_event_type     IN   log_event.event_type%TYPE,   -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
      p_event_source   IN   log_event.event_source%TYPE   -- name of the source where this calling is performed
   );

   FUNCTION get_t_v (pti_v core.ti_varchar)
      RETURN t_v;

   FUNCTION get_t_n (pti_n core.ti_number)
      RETURN t_n;

   FUNCTION get_ti_number (pti_number core.ti_number, p_result_length NUMBER)
      RETURN ti_number;

   FUNCTION get_ti_varchar (pti_varchar core.ti_varchar, p_result_length NUMBER)
      RETURN ti_varchar;

   FUNCTION get_ti_nvarchar (pti_nvarchar core.ti_nvarchar, p_result_length NUMBER)
      RETURN ti_nvarchar;

   FUNCTION get_ti_date (pti_date core.ti_date, p_result_length NUMBER)
      RETURN ti_date;

   FUNCTION func_empty_ti_number
      RETURN ti_number;

   FUNCTION func_empty_ti_varchar
      RETURN ti_varchar;

   FUNCTION get_context (p_name IN VARCHAR2)
      RETURN VARCHAR2;

   FUNCTION get_global_context (p_name IN VARCHAR2)
      RETURN VARCHAR2;

   FUNCTION get_timer_result (
      p_event_name_start   IN   VARCHAR2 DEFAULT c_text_start,
      p_event_name_end     IN   VARCHAR2 DEFAULT c_text_end
   )
      RETURN NUMBER;

   FUNCTION handle_error (
      p_ora_error_number   IN   NUMBER,
      p_handle_tran        IN   CHAR,
      p_package            IN   VARCHAR2,
      p_procedure          IN   VARCHAR2
   )
      RETURN NUMBER;

   FUNCTION handle_error (
      p_ora_error_number   IN   NUMBER,
      p_ora_message        IN   VARCHAR2,
      p_message            IN   VARCHAR2,
      p_handle_tran        IN   CHAR,
      p_package            IN   VARCHAR2,
      p_procedure          IN   VARCHAR2
   )
      RETURN NUMBER;

   PROCEDURE list_context;

   FUNCTION list_to_pltable (p_list IN VARCHAR2, p_delimiter IN CHAR DEFAULT ',')
      RETURN t_v;

   FUNCTION pivot_date (p_start IN DATE, p_limit IN NUMBER)
      RETURN t_d PIPELINED;

   FUNCTION pivot_num (p_start IN NUMBER, p_end IN NUMBER)
      RETURN t_n PARALLEL_ENABLE PIPELINED;

   FUNCTION pltable_to_list (p_tbl IN t_v, p_delimiter IN CHAR DEFAULT ',')
      RETURN VARCHAR2;

   FUNCTION row_to_col (p_slct IN VARCHAR2, p_dlmtr IN VARCHAR2 DEFAULT ',')
      RETURN VARCHAR2;

   PROCEDURE set_context (p_name IN VARCHAR2, p_value IN VARCHAR2);

   PROCEDURE set_global_context (p_name IN VARCHAR2, p_value IN VARCHAR2);

   PROCEDURE set_global_val (
      p_name      IN   VARCHAR2,
      p_value     IN   VARCHAR2,
      p_comment   IN   VARCHAR2 DEFAULT NULL
   );

   FUNCTION get_global_val (p_name IN VARCHAR2)
      RETURN VARCHAR2;

   PROCEDURE set_output (p_output IN VARCHAR2);

   PROCEDURE SET_TIMER (p_event_name IN VARCHAR2 DEFAULT NULL);

   FUNCTION table_column_to_list (p_query IN LONG, p_delimiter IN VARCHAR2 DEFAULT ',')
      RETURN LONG;
END core;


/
