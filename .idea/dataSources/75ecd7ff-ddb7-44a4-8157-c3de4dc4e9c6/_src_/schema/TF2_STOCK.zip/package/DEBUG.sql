CREATE PACKAGE             "DEBUG" 
AS
   TYPE argv IS TABLE OF VARCHAR2 (4000);

   emptydebugargv   argv;
   g_session_id     NUMBER;

   PROCEDURE init (
      p_modules       IN   VARCHAR2 DEFAULT 'ALL',
      p_dir           IN   VARCHAR2 DEFAULT 'TEMP',
      p_file          IN   VARCHAR2 DEFAULT USER || '.dbg',
      p_user          IN   VARCHAR2 DEFAULT USER,
      p_show_date     IN   VARCHAR2 DEFAULT 'YES',
      p_date_format   IN   VARCHAR2 DEFAULT 'MMDDYYYY HH24MISS',
      p_name_len      IN   NUMBER DEFAULT 30,
      p_show_sesid    IN   VARCHAR2 DEFAULT 'NO'
   );

   PROCEDURE CLEAR (
      p_user   IN   VARCHAR2 DEFAULT USER,
      p_dir    IN   VARCHAR2 DEFAULT NULL,
      p_file   IN   VARCHAR2 DEFAULT NULL
   );

   PROCEDURE f (
      p_message   IN   VARCHAR2,
      p_argl      IN   VARCHAR2 DEFAULT NULL,
      p_arg2      IN   VARCHAR2 DEFAULT NULL,
      p_arg3      IN   VARCHAR2 DEFAULT NULL,
      p_arg4      IN   VARCHAR2 DEFAULT NULL,
      p_arg5      IN   VARCHAR2 DEFAULT NULL,
      p_arg6      IN   VARCHAR2 DEFAULT NULL,
      p_arg7      IN   VARCHAR2 DEFAULT NULL,
      p_arg8      IN   VARCHAR2 DEFAULT NULL,
      p_arg9      IN   VARCHAR2 DEFAULT NULL,
      p_arglo     IN   VARCHAR2 DEFAULT NULL
   );

   PROCEDURE fa (p_message IN VARCHAR2, p_args IN argv DEFAULT emptydebugargv);

   PROCEDURE status (
      p_user   IN   VARCHAR2 DEFAULT USER,
      p_dir    IN   VARCHAR2 DEFAULT NULL,
      p_file   IN   VARCHAR2 DEFAULT NULL
   );
END DEBUG;


/
