CREATE package body LEGACY_PKG is

----------------------------------!---------------------------------------------
procedure find_sim_cards_info
(
    p_stock_code nvarchar2,
    p_series_start ct_nvarchar_s,
    p_series_end ct_nvarchar_s,
    p_linked boolean,
    p_user_id number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_error_code number;
begin
  ------------------------------
  api_stock_i_pkg.find_sim_cards_info
  (
    p_stock_code => p_stock_code,
    p_series_start => p_series_start,
    p_series_end => p_series_end,
    p_linked => p_linked,
    p_user_id => p_user_id,
    p_result => p_result,
    p_error_code => v_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  p_error_code := get_result_code02(v_error_code);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prod_check_sim_list
(
    p_host_id number,
    p_net_op_id number,
    p_iccid_without_control_digit ct_nvarchar_s,
    p_iccid out ct_nvarchar_s,
    p_imsi out ct_nvarchar_s,
    p_error_code out ct_number,
    p_error_message out ct_varchar
)
is
  v_error_code ct_number;
  v_mark ct_number;
  v_main_count number;
  v_pivot ct_number;
begin
  ------------------------------
  RI_PERSISTENT_INTERFACE_PKG.prod_check_sim_list
  (
    p_host_id => p_host_id,
    p_net_op_id => p_net_op_id,
    p_iccid_without_control_digit => p_iccid_without_control_digit,
    p_iccid => p_iccid,
    p_imsi => p_imsi,
    p_error_code => v_error_code,
    p_error_message => p_error_message
  );
  v_main_count := util_pkg.get_count_ct_number(v_error_code);
  ------------------------------
  if v_main_count > 0
  then
    ------------------------------
    v_pivot := util_pkg.make_pivot(v_main_count);
    ------------------------------
    util_pkg.add_ct_number(p_error_code, v_error_code);
    ------------------------------
    v_mark := util_pkg.mark_val_ct_number(v_error_code, c_ri_ora_sim_card_not_found, util_pkg.c_true, util_pkg.c_false);
    util_stock.setup_error_codes_by_marks0(v_mark, v_pivot, clg_ri_sim_card_not_exists, util_pkg.c_true, p_error_code);
    ------------------------------
    v_mark := util_pkg.mark_val_ct_number(v_error_code, c_ri_ora_wrong_host, util_pkg.c_true, util_pkg.c_false);
    util_stock.setup_error_codes_by_marks0(v_mark, v_pivot, clg_ri_sim_invalid_host, util_pkg.c_true, p_error_code);
    ------------------------------
    v_mark := util_pkg.mark_val_ct_number(v_error_code, c_ri_ora_wrong_no, util_pkg.c_true, util_pkg.c_false);
    util_stock.setup_error_codes_by_marks0(v_mark, v_pivot, clg_ri_sim_invalid_net_oper, util_pkg.c_true, p_error_code);
    ------------------------------
    v_mark := util_pkg.mark_val_ct_number(v_error_code, c_ri_ora_wrong_ap_status, util_pkg.c_true, util_pkg.c_false);
    util_stock.setup_error_codes_by_marks0(v_mark, v_pivot, clg_ri_sim_invalid_status, util_pkg.c_true, p_error_code);
    ------------------------------
    v_mark := util_pkg.mark_val_ct_number(v_error_code, c_ri_ora_already_linked, util_pkg.c_true, util_pkg.c_false);
    util_stock.setup_error_codes_by_marks0(v_mark, v_pivot, clg_ri_sim_have_phone_number, util_pkg.c_true, p_error_code);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Receive_Single_Equipment
(
    p_stock_code nvarchar2,
    p_equipment_code varchar2,
    p_full_number nvarchar2,
    p_validity_date date,
    p_vendor_doc nvarchar2,
    p_user_id number,
    p_finish boolean,
    p_document_number out nvarchar2,
    p_equipment_id out number,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_date date := sysdate;
  v_stock_id number;
--
  v_model_codes ct_varchar_s;
--
  v_seria_starts ct_nvarchar_s;
  v_seria_ends ct_nvarchar_s;
  v_models ct_model;
  v_valid_until ct_date;
--
  v_serial_number nvarchar2(50);
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_code is null, 'p_stock_code');
  util_pkg.XCheck_Cond_Missing(p_equipment_code is null, 'p_equipment_code');
  util_pkg.XCheck_Cond_Missing(p_full_number is null, 'p_full_number');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_finish is null, 'p_finish');
  ------------------------------
  v_stock_id := util_stock.get_stock_id2(p_stock_code, v_date);
  ------------------------------
  if v_stock_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || 'p_stock_code' || util_pkg.c_msg_delim02 || util_pkg.nchar_to_char(p_stock_code));
  end if;
  ------------------------------
  if p_vendor_doc is not null
  then
    p_document_number := document_pkg.get_doc_header_by_vendor_doc(v_stock_id, p_vendor_doc).doc_no;
  end if;
  ------------------------------
  v_serial_number := util_stock.make_sn_from_full_number2(p_full_number); --!_!
  util_pkg.add_ct_nvarchar_s_val(v_seria_starts, v_serial_number);
  util_pkg.add_ct_nvarchar_s_val(v_seria_ends, v_serial_number);
  util_pkg.add_ct_varchar_s_val(v_model_codes, p_equipment_code);
  v_models := util_stock.get_ct_model_exact(v_model_codes, v_date);
  util_pkg.add_ct_date_val(v_valid_until, trunc(p_validity_date, 'DD')); --!_!
  ------------------------------
  if p_document_number is null
  then
    ------------------------------
    api_stock_i_pkg.receive_equipment
    (
      p_seria_starts => v_seria_starts,
      p_seria_ends => v_seria_ends,
      p_models => v_models,
      p_validity_date => v_valid_until,
      p_stock_id => v_stock_id,
      p_vendor_doc => p_vendor_doc,
      p_finish => p_finish,
      p_user_id => p_user_id,
      p_document_number => p_document_number,
      p_error_code => p_error_code,
      p_error_message => p_error_message
    );
    ------------------------------
    if util_pkg.is_error(p_error_code)
    then
      util_pkg.raise_label_exception('api_stock_i_pkg.receive_equipment', p_error_code, p_error_message);
    end if;
    ------------------------------
  else
    ------------------------------
    api_stock_i_pkg.receive_equipment2
    (
      p_document_number => p_document_number,
      p_seria_starts => v_seria_starts,
      p_seria_ends => v_seria_ends,
      p_models => v_models,
      p_validity_date => v_valid_until,
      p_stock_id => v_stock_id,
      p_finish => p_finish,
      p_user_id => p_user_id,
      p_error_code => p_error_code,
      p_error_message => p_error_message
    );
    ------------------------------
    if util_pkg.is_error(p_error_code)
    then
      util_pkg.raise_label_exception('api_stock_i_pkg.receive_equipment2', p_error_code, p_error_message);
    end if;
    ------------------------------
  end if;
  ------------------------------
  p_equipment_id := util_stock.get_sims_id4serial_number2(v_serial_number);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Put_Away_Equipment_Range1
(
    p_in_document_number nvarchar2,
    p_stock_code nvarchar2,
    p_series_start ct_nvarchar_s,
    p_series_end ct_nvarchar_s,
    p_model_codes ct_varchar_s,
    p_user_id number,
    p_finish boolean,
    p_out_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_date date := sysdate;
  v_main_count number;
  v_stock_id number;
  v_models ct_model;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_code is null, 'p_stock_code');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_finish is null, 'p_finish');
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_model_codes, 'p_model_codes');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_series_start);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_series_start) != v_main_count, 'p_series_start.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_series_end) != v_main_count, 'p_series_end.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_model_codes) != v_main_count, 'p_model_codes.count != v_main_count');
  ------------------------------
  v_stock_id := util_stock.get_stock_id2(p_stock_code, v_date);
  ------------------------------
  if v_stock_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || 'p_stock_code' || util_pkg.c_msg_delim02 || util_pkg.nchar_to_char(p_stock_code));
  end if;
  ------------------------------
  v_models := util_stock.get_ct_model_exact(p_model_codes, v_date);
  if util_stock.is_nulls_ct_model(v_models)
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_equipment_not_found, util_loc_pkg.c_msg_equipment_not_found);
  end if;
  ------------------------------
  if p_in_document_number is null
  then
    ------------------------------
    api_stock_i_pkg.Put_Away_Equipment_Range11
    (
      p_stock_id => v_stock_id,
      p_series_start => p_series_start,
      p_series_end => p_series_end,
      p_models => v_models,
      p_user_id => p_user_id,
      p_finish => p_finish,
      p_document_number => p_out_document_number,
      p_error_codes => v_error_codes,
      p_error_messages => v_error_messages,
      p_error_code => p_error_code,
      p_error_message => p_error_message
    );
    ------------------------------
  else
    ------------------------------
    api_stock_i_pkg.Put_Away_Equipment_Range12
    (
      p_document_number => p_in_document_number,
      p_stock_id => v_stock_id,
      p_series_start => p_series_start,
      p_series_end => p_series_end,
      p_models => v_models,
      p_user_id => p_user_id,
      p_finish => p_finish,
      p_error_codes => v_error_codes,
      p_error_messages => v_error_messages,
      p_error_code => p_error_code,
      p_error_message => p_error_message
    );
    ------------------------------
    p_out_document_number := p_in_document_number;
    ------------------------------
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Put_Away_Equipment_Range2_i
(
    p_in_document_number nvarchar2,
    p_stock_code nvarchar2,
    p_sim_ids ct_number,
    p_user_id number,
    p_finish boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar,
    p_out_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_date date := sysdate;
  v_stock_id number;
  v_main_count number;
  v_series_start ct_nvarchar_s;
  v_models_id ct_number;
  v_models ct_model;
--
  v_mark_err ct_number;
  v_pivot ct_number;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_code is null, 'p_stock_code');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_finish is null, 'p_finish');
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_sim_ids, 'p_sim_ids');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_sim_ids);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_sim_ids) != v_main_count, 'p_sim_ids.count != v_main_count');
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  util_stock.setup_common_error(v_main_count, util_pkg.c_ora_ok, util_pkg.c_msg_ok, p_error_codes, p_error_messages);
  ------------------------------
  v_stock_id := util_stock.get_stock_id2(p_stock_code, v_date);
  ------------------------------
  if v_stock_id is null
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || 'p_stock_code' || util_pkg.c_msg_delim02 || util_pkg.nchar_to_char(p_stock_code));
  end if;
  ------------------------------
  v_series_start := util_pkg.cast_ct_varchar_s2nvarchar_s(util_stock.get_sims_sn(p_sim_ids, FALSE));
  v_mark_err := util_pkg.mark_val_ct_nvarchar_s(v_series_start, null, util_pkg.c_true, util_pkg.c_false);
  util_stock.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_equipment_not_found, util_loc_pkg.c_msg_equipment_not_found, util_pkg.c_true, p_error_codes, p_error_messages);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  v_models_id := util_stock.get_ss_model_id(v_series_start, FALSE);
  v_mark_err := util_pkg.mark_val_ct_number(v_models_id, null, util_pkg.c_true, util_pkg.c_false);
  util_stock.setup_error_by_marks0(v_mark_err, v_pivot, util_loc_pkg.c_ora_equipment_not_found, util_loc_pkg.c_msg_equipment_not_found, util_pkg.c_true, p_error_codes, p_error_messages);
  util_stock.xcheck_has_error(TRUE, p_error_codes, p_error_messages);
  ------------------------------
  v_models := util_stock.get_ct_model2_exact(v_models_id, v_date);
  ------------------------------
  if p_in_document_number is null
  then
    ------------------------------
    api_stock_i_pkg.Put_Away_Equipment_Range11
    (
      p_stock_id => v_stock_id,
      p_series_start => v_series_start,
      p_series_end => v_series_start,
      p_models => v_models,
      p_user_id => p_user_id,
      p_finish => p_finish,
      p_document_number => p_out_document_number,
      p_error_codes => p_error_codes,
      p_error_messages => p_error_messages,
      p_error_code => p_error_code,
      p_error_message => p_error_message
    );
    ------------------------------
  else
    ------------------------------
    api_stock_i_pkg.Put_Away_Equipment_Range12
    (
      p_document_number => p_in_document_number,
      p_stock_id => v_stock_id,
      p_series_start => v_series_start,
      p_series_end => v_series_start,
      p_models => v_models,
      p_user_id => p_user_id,
      p_finish => p_finish,
      p_error_codes => p_error_codes,
      p_error_messages => p_error_messages,
      p_error_code => p_error_code,
      p_error_message => p_error_message
    );
    ------------------------------
    p_out_document_number := p_in_document_number;
    ------------------------------
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure put_away_equipment_range2
(
    p_in_document_number nvarchar2,
    p_stock_code nvarchar2,
    p_sim_ids ct_number,
    p_user_id number,
    p_finish boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar,
    p_out_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_mark_err ct_number;
begin
  ------------------------------
  put_away_equipment_range2_i
  (
    p_in_document_number => p_in_document_number,
    p_stock_code => p_stock_code,
    p_sim_ids => p_sim_ids,
    p_user_id => p_user_id,
    p_finish => p_finish,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages,
    p_out_document_number => p_out_document_number,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  v_mark_err := util_pkg.mark_val_ct_number(p_error_codes, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
  ------------------------------
  util_stock.setup_error_by_marks(v_mark_err, clg_ora_equipment_not_exists, clg_msg_equipment_not_exists, util_pkg.c_true, p_error_codes, p_error_messages);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_result_cursor04
(
    p_serial_number ct_nvarchar_s,
    p_ss_id ct_number,
    p_ss_stock_id ct_number,
    p_ss_model_id ct_number,
    p_msisdn ct_varchar_s,
    p_linked boolean,
    p_date date,
    p_result out sys_refcursor
)
is
  v_linked number := util_pkg.bool_to_int_3val(p_linked);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select
  serial_number,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, equipment_id) equipment_id,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, iccid) iccid,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, phone_number) phone_number,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, phone_status) phone_status,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, salability_category) salability_category,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, user_id) user_id,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, date_link) date_link,
  result_code
  from (

select /*+ driving_site(q0) ordered use_nl(ss, sm, pn, naap) use_hash(q0, q1, q2, q3, q4)
  index_asc(ss, PK_STOCK_STATE)
  index_asc(sm, AK_SIMS_SN)
  index_asc(pn, UK_PHONE_NUM_PHONE_NUMBER)
  index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID)
  */
  q0.serial_number,
  sm.id equipment_id,
  sm.full_number iccid,
  q4.msisdn phone_number,
  pn.net_address_status_code phone_status,
  pn.salability_category_code salability_category,
  naap.user_id_of_change user_id,
  naap.date_of_change date_link,
  get_search_result_code01(q1.ss_id, q2.ss_stock_id, q3.ss_model_id, q4.msisdn, v_linked, p_date, util_pkg.c_false) result_code
  from
    (select column_value serial_number, rownum rn from table(p_serial_number)) q0,
    (select column_value ss_id, rownum rn from table(p_ss_id)) q1,
    (select column_value ss_stock_id, rownum rn from table(p_ss_stock_id)) q2,
    (select column_value ss_model_id, rownum rn from table(p_ss_model_id)) q3,
    (select column_value msisdn, rownum rn from table(p_msisdn)) q4,
    stock_state ss,
    sims sm,
    ri_phone_number pn,
    ri_naap naap
  where 1 = 1
  and q1.rn(+) = q0.rn
  and q2.rn(+) = q0.rn
  and q3.rn(+) = q0.rn
  and q4.rn(+) = q0.rn
  and ss.id(+) = q1.ss_id
  and sm.serial_number(+) = ss.seria_start
  and pn.international_format(+) = q4.msisdn
  and naap.network_address_id(+) = pn.network_address_id
  and naap.link_type_code(+) = util_stock.c_RI_MAIN_LINK_TYPE
  --
  and nvl(pn.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  and p_date between naap.from_date(+) and nvl(naap.to_date(+), p_date)
  --
  --!_!order by q0.rn
  order by ss.stock_id, sm.full_number, q0.rn

  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor05
(
    p_serial_number ct_nvarchar_s,
    p_ss_id ct_number,
    p_ss_stock_id ct_number,
    p_ss_model_id ct_number,
    p_msisdn ct_varchar_s,
    p_last_dh_id ct_number,
    p_model ct_model,
    p_linked boolean,
    p_date date,
    p_access_denied2not_found boolean,
    p_result out sys_refcursor
)
is
  v_linked number := util_pkg.bool_to_int_3val(p_linked);
  v_access_denied2not_found number := util_pkg.bool_to_int_2val(p_access_denied2not_found);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, equipment_model_code) equipment_model_code,
  serial_number,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, iccid) iccid,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, control_number) control_number,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, user_id) user_id,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, date_link) date_link,
  get_search_result_msg01(result_code) error_message,
  result_code
  from (

select /*+ driving_site(q0) ordered use_nl(ss, sm, dh) use_hash(q0, q1, q2, q3, q4, q5, md)
  index_asc(ss, PK_STOCK_STATE)
  index_asc(sm, AK_SIMS_SN)
  index_asc(dh, PK_DOC_HEADER)
  */
  md.code equipment_model_code,
  q0.serial_number,
  sm.full_number iccid,
  sm.control_number,
  dh.user_id,
  dh.create_date date_link,
  get_search_result_code01(q1.ss_id, q2.ss_stock_id, q3.ss_model_id, q4.msisdn, v_linked, p_date, v_access_denied2not_found) result_code
  from
    (select column_value serial_number, rownum rn from table(p_serial_number)) q0,
    (select column_value ss_id, rownum rn from table(p_ss_id)) q1,
    (select column_value ss_stock_id, rownum rn from table(p_ss_stock_id)) q2,
    (select column_value ss_model_id, rownum rn from table(p_ss_model_id)) q3,
    (select column_value msisdn, rownum rn from table(p_msisdn)) q4,
    (select column_value dh_id, rownum rn from table(p_last_dh_id)) q5,
    stock_state ss,
    sims sm,
    doc_header dh,
    (select * from table(p_model)) md
  where 1 = 1
  and q1.rn(+) = q0.rn
  and q2.rn(+) = q0.rn
  and q3.rn(+) = q0.rn
  and q4.rn(+) = q0.rn
  and q5.rn(+) = q0.rn
  and ss.id(+) = q1.ss_id
  and sm.serial_number(+) = ss.seria_start
  and dh.id(+) = q5.dh_id
  and md.id(+) = ss.equipment_model_id
  --
  --!_!order by q0.rn
  order by ss.stock_id, sm.full_number, q0.rn

  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor06
(
    p_serial_number ct_nvarchar_s,
    p_ss_id ct_number,
    p_ss_stock_id ct_number,
    p_ss_model_id ct_number,
    p_msisdn ct_varchar_s,
    p_model ct_model,
    p_linked boolean,
    p_date date,
    p_result out sys_refcursor
)
is
  v_linked number := util_pkg.bool_to_int_3val(p_linked);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select
  serial_number,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, iccid) iccid,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, control_number) control_number,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, equipment_id) equipment_id,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, equipment_type_id) equipment_type_id,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, equipment_type_code) equipment_type_code,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, equipment_model_id) equipment_model_id,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, equipment_model_code) equipment_model_code,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, stock_id) stock_id,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, stock_code) stock_code,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, stock_name) stock_name,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, phone_number) phone_number,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, phone_status) phone_status,
  decode(result_code, util_stock.c_ec_CRM_FIND_SIM_NOT_EX, null, salability_category) salability_category,
  get_search_result_msg01(result_code) error_message,
  result_code
  from (

select /*+ driving_site(q0) ordered use_nl(ss, sm, pn, naap) use_hash(q0, q1, q2, q3, q4, md, s)
  index_asc(ss, PK_STOCK_STATE)
  index_asc(sm, AK_SIMS_SN)
  index_asc(pn, UK_PHONE_NUM_PHONE_NUMBER)
  index_asc(naap, I_NETADDRACCPO_NET_ADDRESS_ID)
  full(s)
  */
  q0.serial_number,
  sm.full_number iccid,
  sm.control_number,
  sm.id equipment_id,
  md.type_id equipment_type_id,
  md.type_code equipment_type_code,
  md.id equipment_model_id,
  md.code equipment_model_code,
  ss.stock_id stock_id,
  s.code stock_code,
  s.name stock_name,
  q4.msisdn phone_number,
  pn.net_address_status_code phone_status,
  pn.salability_category_code salability_category,
  get_search_result_code01(q1.ss_id, q2.ss_stock_id, q3.ss_model_id, q4.msisdn, v_linked, p_date, util_pkg.c_false) result_code
  from
    (select column_value serial_number, rownum rn from table(p_serial_number)) q0,
    (select column_value ss_id, rownum rn from table(p_ss_id)) q1,
    (select column_value ss_stock_id, rownum rn from table(p_ss_stock_id)) q2,
    (select column_value ss_model_id, rownum rn from table(p_ss_model_id)) q3,
    (select column_value msisdn, rownum rn from table(p_msisdn)) q4,
    stock_state ss,
    sims sm,
    ri_phone_number pn,
    ri_naap naap,
    (select * from table(p_model)) md,
    stock s
  where 1 = 1
  and q1.rn(+) = q0.rn
  and q2.rn(+) = q0.rn
  and q3.rn(+) = q0.rn
  and q4.rn(+) = q0.rn
  and ss.id(+) = q1.ss_id
  and sm.serial_number(+) = ss.seria_start
  --
  and pn.international_format(+) = q4.msisdn
  and naap.network_address_id(+) = pn.network_address_id
  and naap.link_type_code(+) = util_stock.c_RI_MAIN_LINK_TYPE
  --
  and md.id(+) = ss.equipment_model_id
  and s.id(+) = ss.stock_id
  --
  and nvl(pn.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  and p_date between naap.from_date(+) and nvl(naap.to_date(+), p_date)
  and nvl(s.deleted(+), p_date + util_stock.c_dummy_date_shift) > p_date
  --
  --!_!order by q0.rn
  order by s.code, sm.full_number, q0.rn

  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_search_result_code01(p_ss_id number, p_ss_stock_id number, p_ss_model_id number, p_msisdn varchar2, p_linked number, p_date date, p_access_denied2not_found number) return number
is
  v_linked number := util_pkg.int_to_int_3val(p_linked);
  v_access_denied2not_found number := util_pkg.int_to_int_2val(p_access_denied2not_found);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  if (1 = 0
    or p_ss_id is null
    or p_ss_model_id is null
  )
  then
    return util_stock.c_ec_CRM_FIND_SIM_NOT_EX;
  end if;
  ------------------------------
  if p_ss_stock_id is null
  then
    if (v_access_denied2not_found = util_pkg.c_false)
    then
      return util_stock.c_ec_ACCESS_DENIED;
    --!_!return util_stock.c_ec_CRM_FIND_SIM_NOT_EX_ON_ST; --!_! to identify this case we must analyse and compare passed to method and all user stocks
    else
      return util_stock.c_ec_CRM_FIND_SIM_NOT_EX_ON_ST;
    end if;
  end if;
  ------------------------------
  if v_linked = util_pkg.c_false and p_msisdn is not null
  then
    return util_stock.c_ec_CRM_FIND_SIM_IS_LINKED;
  end if;
  ------------------------------
  if v_linked = util_pkg.c_true and p_msisdn is null
  then
    return util_stock.c_ec_CRM_FIND_SIM_IS_FREE;
  end if;
  ------------------------------
  return util_stock.c_ec_OK;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_code02(p_result_code number) return number
is
  v_res number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_result_code is null, 'p_result_code');
  ------------------------------
  if p_result_code = util_loc_pkg.c_ora_access_denied_to_stock
  then
    v_res := clg_ora_access_denied;
  elsif p_result_code = util_pkg.c_ora_object_not_found
  then
    v_res := clg_ora_stock_not_exists;
  elsif p_result_code = util_pkg.c_ora_invalid_parameter
  then
    v_res := clg_ora_invalid_parameter;
  elsif p_result_code = util_pkg.c_ora_missing_parameter
  then
    v_res := clg_ora_missing_parameter;
  else
    v_res := p_result_code;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_search_result_msg01(p_result_code number) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_result_code is null, 'p_result_code');
  ------------------------------
  if p_result_code = util_stock.c_ec_CRM_FIND_SIM_NOT_EX
  then
    v_res := 'Equipment not exists';
  elsif p_result_code = util_stock.c_ec_ACCESS_DENIED
  then
    v_res := 'Access is denied';
  elsif p_result_code = util_stock.c_ec_CRM_FIND_SIM_NOT_EX_ON_ST
  then
    v_res := 'Equipment not exists on stock';
  elsif p_result_code = util_stock.c_ec_CRM_FIND_SIM_IS_LINKED
  then
    v_res := 'Sim card is linked';
  elsif p_result_code = util_stock.c_ec_CRM_FIND_SIM_IS_FREE
  then
    v_res := 'Sim card is not linked';
  elsif p_result_code = util_stock.c_ec_OK
  then
    v_res := util_pkg.c_msg_ok;
  else
    v_res := util_pkg.c_msg_x_common;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
