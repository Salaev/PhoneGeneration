CREATE PACKAGE BODY pkg_common
IS
--******************************************************************************
-- Author  : Skripnik Petr
-- Created : 16.10.2006 14:05
-- Purpose : Процедуры общего пользования
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ------------------------------------------
-- Petr Skripnik   09.11.2006  Изменен
-- Petr Skripnik   17.11.2006  Изменен
-- Skripnik Petr   16.04.2007  version 1.11.8.2
-- Skripnik Petr   10.07.2007  version 1.11.9.0
--******************************************************************************
   pkg_name   CONSTANT NVARCHAR2 (50) := 'pkg_common.';
   ctx        CONSTANT VARCHAR2 (30)  := 'ctx_common' || pkg_constants.ctx_sufix;
   f_timer             BOOLEAN        DEFAULT FALSE;   --флаг установки таймера

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 08.02.2007 11:54
-- Editor  :
-- Changed :
-- Purpose : Преобразует логический тип в символьный
--------------------------------------------------------------------------------
   FUNCTION boolean_to_char (p_value IN BOOLEAN)
      RETURN VARCHAR2
   IS
      l_result   VARCHAR2 (5);
   BEGIN
      IF p_value
      THEN
         l_result := 'TRUE';
      ELSIF NOT p_value
      THEN
         l_result := 'FALSE';
      ELSE
         l_result := 'NULL';
      END IF;

      RETURN l_result;
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END boolean_to_char;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.11.2006 10:16
-- Editor  :
-- Changed :
-- Purpose : Очищает контекст
--------------------------------------------------------------------------------
   PROCEDURE clear_context
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'clear_context';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      DBMS_SESSION.clear_context (ctx, RTRIM (pkg_name, '.'));
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END clear_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 12.02.2007 10:42
-- Editor  :
-- Changed :
-- Purpose : Возвращает пустой ассоциативный цифровой массив
--------------------------------------------------------------------------------
   FUNCTION empty_t_num
      RETURN pkg_common.t_num
   IS
      emptyarray   pkg_common.t_num;
   BEGIN
      RETURN emptyarray;
   END empty_t_num;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 12.02.2007 10:42
-- Editor  :
-- Changed :
-- Purpose : Возвращает пустой ассоциативный символьный массив
--------------------------------------------------------------------------------
   FUNCTION empty_t_varchar
      RETURN pkg_common.t_varchar
   IS
      emptyarray   pkg_common.t_varchar;
   BEGIN
      RETURN emptyarray;
   END empty_t_varchar;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.11.2006 10:16
-- Editor  :
-- Changed :
-- Purpose : Возвращает значение контекста
--------------------------------------------------------------------------------
   FUNCTION get_context (p_name IN VARCHAR2)
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN SYS_CONTEXT (ctx, p_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END get_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.10.2006 16:23
-- Editor  :
-- Changed :
-- Purpose : Получает значение глобальной переменной для всех сессий (таблица GLOBAL_VALUE)
--------------------------------------------------------------------------------
   FUNCTION get_global_val (p_name IN VARCHAR2)
      RETURN VARCHAR2
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_global_val';
      l_result            VARCHAR2 (50);
   BEGIN
      --Незапускать отладчик!!!

      --Получим значение
      SELECT UPPER (VALUE)
        INTO l_result
        FROM global_value
       WHERE NAME = UPPER (p_name);

      RETURN l_result;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         l_result := 'NO_DATA_FOUND';
         RETURN l_result;
   END get_global_val;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 19.12.2006 14:35
-- Editor  :
-- Changed :
-- Purpose : Получает результаты работы таймера
--------------------------------------------------------------------------------
   FUNCTION get_timer_result (
      p_event_name_start   IN   VARCHAR2 DEFAULT pkg_constants.c_flag_start,
      p_event_name_end     IN   VARCHAR2 DEFAULT pkg_constants.c_flag_end
   )
      RETURN NUMBER
   AS
      l_s        NUMBER;   -- начало отсчета
      l_e        NUMBER;   -- конец отсчета
      l_result   NUMBER;   -- результат до сотых долей секунд
   BEGIN
      l_s := NVL (get_context ('timer' || p_event_name_start), 0);
      l_e := NVL (get_context ('timer' || p_event_name_end), 0);

      IF (l_s <> 0) AND (l_e <> 0)
      THEN
         l_result := (TO_NUMBER (l_e) - TO_NUMBER (l_s)) / 100;
      ELSE
         l_result := 0;
      END IF;

      RETURN l_result;
   EXCEPTION
      WHEN OTHERS
      THEN
         l_result := 0;
   END get_timer_result;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.11.2006 10:16
-- Editor  :
-- Changed :
-- Purpose : Просмотрим контекст
--------------------------------------------------------------------------------
   PROCEDURE list_context
   IS
      l_list              DBMS_SESSION.appctxtabtyp;
      l_size              NUMBER;
      l_strline           NVARCHAR2 (255);
      l_loop              PLS_INTEGER;
      prc_name   CONSTANT NVARCHAR2 (100)           := pkg_name || 'list_context';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      DBMS_SESSION.list_context (l_list, l_size);

      FOR l_loop IN 1 .. l_list.COUNT
      LOOP
         l_strline :=
               l_list (l_loop).namespace
            || ': '
            || l_list (l_loop).ATTRIBUTE
            || ' = '
            || l_list (l_loop).VALUE;
         pkg_db_util.DEBUG (prc_name, l_strline, pkg_name);
      END LOOP;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END list_context;

--------------------------------------------------------------------------------
   FUNCTION list_to_pltable_fn (p_list IN VARCHAR2, p_delimiter IN CHAR DEFAULT ',')
      RETURN ct_varchar
   IS
      prc_name    CONSTANT NVARCHAR2 (100)  := pkg_name || 'list_to_pltable_fn';
      l_string_tbl         ct_varchar       := ct_varchar ();
      l_start_position     NUMBER;
      l_end_postion        NUMBER;
      l_delimiter_length   NUMBER;
      l_expanded_list      VARCHAR2 (32767);
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                         '(' || p_list || pkg_constants.c_delimiter || p_delimiter || ')',
                         pkg_name
                        );

      IF p_delimiter IS NULL
      THEN
         raise_application_error (-20500, 'Invalid Delimiter');
      END IF;

      l_expanded_list := p_list || p_delimiter;
      l_delimiter_length := LENGTH (p_delimiter);
      l_end_postion := 1 - l_delimiter_length;

      LOOP
         l_start_position := l_end_postion + l_delimiter_length;
         l_end_postion := INSTR (l_expanded_list, p_delimiter, l_start_position);
         EXIT WHEN l_end_postion = 0;
         l_string_tbl.EXTEND;
         l_string_tbl (l_string_tbl.LAST) :=
                       SUBSTR (l_expanded_list, l_start_position, l_end_postion - l_start_position);
      END LOOP;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      RETURN l_string_tbl;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END list_to_pltable_fn;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 11.10.2006 16:35
-- Editor  : Skripnik Petr
-- Changed : 27.10.2006 11:57
-- Purpose : Переобразует строку LONG в VARCHAR2 (нерабочая!!!)
--------------------------------------------------------------------------------
   FUNCTION long2char (p_long IN LONG, p_char IN VARCHAR2 DEFAULT '')
      RETURN VARCHAR2
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'long2char';
      l_result            VARCHAR2 (1600);
   BEGIN
      SELECT p_long
        INTO l_result
        FROM DUAL;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      RETURN l_result || p_char;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END long2char;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 03.04.2007 16:27
-- Editor  :
-- Changed :
-- Purpose : Pipelined-функция. Использется, чтобы возвратить требуемое
-- количество записей типа даты
--------------------------------------------------------------------------------
   FUNCTION pivot_date (p_start IN DATE, p_limit IN NUMBER)
      RETURN ct_date PIPELINED
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'pivot_date';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      FOR i IN 0 .. p_limit - 1
      LOOP
         PIPE ROW (p_start + i);
      END LOOP;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      RETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 17.11.2006 13:27
-- Editor  :
-- Changed :
-- Purpose : Pipelined-функция. Использется, чтобы возвратить требуемое
-- количество записей чилового типа
--------------------------------------------------------------------------------
   FUNCTION pivot_num (p_start IN NUMBER, p_end IN NUMBER)
      RETURN ct_number PARALLEL_ENABLE PIPELINED
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'pivot_num';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      FOR i IN p_start .. p_end
      LOOP
         PIPE ROW (i);
      END LOOP;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      RETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END pivot_num;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 17.11.2006 13:32
-- Editor  :
-- Changed :
-- Purpose : Pipelined-функция. Использется, чтобы возвратить требуемое
-- количество записей типа RAW
--------------------------------------------------------------------------------
   FUNCTION pivot_raw (p_start IN NUMBER, p_end IN NUMBER)
      RETURN ct_raw PARALLEL_ENABLE PIPELINED
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'pivot_raw';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      FOR i IN p_start .. p_end
      LOOP
         PIPE ROW (UTL_RAW.cast_to_raw (i));
      END LOOP;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      RETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END pivot_raw;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 16.10.2006 16:50
-- Editor  :
-- Changed :
-- Purpose : Функция преобразовывает таблицу PL/SQL в список с разделителями-запятыми
--------------------------------------------------------------------------------
   FUNCTION pltable_to_list_fn (p_tbl IN ct_varchar, p_delimiter IN CHAR DEFAULT ',')
      RETURN VARCHAR2
   IS
      prc_name   CONSTANT NVARCHAR2 (100)  := pkg_name || 'pltable_to_list_fn';
      l_list              VARCHAR2 (32767);
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      IF p_delimiter IS NULL
      THEN
         raise_application_error (-20500, 'Invalid Delimiter');
      END IF;

      FOR i IN 1 .. p_tbl.LAST
      LOOP
         IF INSTR (p_tbl (i), p_delimiter) != 0
         THEN
            raise_application_error (-20500, 'Invalid Delimiter');
         END IF;

         IF i > 1
         THEN
            l_list := l_list || p_delimiter || p_tbl (i);
         ELSE
            l_list := l_list || p_tbl (i);
         END IF;
      END LOOP;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      RETURN l_list;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END pltable_to_list_fn;

--------------------------------------------------------------------------------
-- Author  : http://www.oracle.com/technology/oramag/code/tips2004/050304.html
-- Created : 18.03.2008 10:31
-- Editor  :
-- Changed :
-- Purpose : Преобразовывает  строки в столбцы
--------------------------------------------------------------------------------
   FUNCTION rowtocol (p_slct IN VARCHAR2, p_dlmtr IN VARCHAR2 DEFAULT ',')
      RETURN VARCHAR2   --AUTHID CURRENT_USER
   AS
      TYPE c_refcur IS REF CURSOR;

      lc_str      VARCHAR2 (4000);
      lc_colval   VARCHAR2 (4000);
      c_dummy     c_refcur;
      l           NUMBER;
   BEGIN
      OPEN c_dummy FOR p_slct;

      LOOP
         FETCH c_dummy
          INTO lc_colval;

         EXIT WHEN c_dummy%NOTFOUND;
         lc_str := lc_str || p_dlmtr || lc_colval;
      END LOOP;

      CLOSE c_dummy;

      RETURN SUBSTR (lc_str, 2);
   EXCEPTION
      WHEN OTHERS
      THEN
         lc_str := SQLERRM;

         IF c_dummy%ISOPEN
         THEN
            CLOSE c_dummy;
         END IF;

         RETURN lc_str;
   END rowtocol;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.11.2006 10:16
-- Editor  :
-- Changed :
-- Purpose : Задает значение контексту
--------------------------------------------------------------------------------
   PROCEDURE set_context (p_name IN VARCHAR2, p_value IN VARCHAR2)
   IS
   BEGIN
      DBMS_SESSION.set_context (ctx, p_name, p_value);
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END set_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.10.2006 16:23
-- Editor  :
-- Changed :
-- Purpose : Устанавливает значение глобальной переменной для всех сессий (таблица GLOBAL_VALUE)
--------------------------------------------------------------------------------
   PROCEDURE set_global_val (p_name IN VARCHAR2, p_val IN VARCHAR2)
   AS
      PRAGMA AUTONOMOUS_TRANSACTION;
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'set_global_val';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Апсерт
      MERGE INTO global_value t
         USING (SELECT UPPER (p_name) AS NAME, UPPER (p_val) AS VALUE, NULL AS comments
                  FROM DUAL) sq
         ON (t.NAME = sq.NAME)
         WHEN MATCHED THEN
            UPDATE
               SET t.VALUE = UPPER (sq.VALUE)
         WHEN NOT MATCHED THEN
            INSERT (t.NAME, t.VALUE, t.comments)
            VALUES (sq.NAME, sq.VALUE, sq.comments);
      --Применим изменения
      COMMIT;
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END set_global_val;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 19.12.2006 14:35
-- Editor  :
-- Changed :
-- Purpose : Установка таймера
--------------------------------------------------------------------------------
   PROCEDURE SET_TIMER (p_event_name IN VARCHAR2 DEFAULT NULL)
   AS
   BEGIN
      IF p_event_name IS NULL   --Если событие не заданно...
      THEN
         IF NOT f_timer
         THEN
            --Установим контекст с начальной точкой отсчета
            set_context ('timer' || pkg_constants.c_flag_start, DBMS_UTILITY.get_time);
            f_timer := TRUE;
         ELSE
            --Установим контекст с конечной точкой отсчета
            set_context ('timer' || pkg_constants.c_flag_end, DBMS_UTILITY.get_time);
            f_timer := FALSE;
         END IF;
      ELSE   --Если событие заданно...
         --Установим контекст с точкой отсчета для события
         set_context ('timer' || p_event_name, DBMS_UTILITY.get_time);
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line (SUBSTR ('Ошибка в PKG_COMMON.SET_TIMER :' || SQLERRM, 1, 255));
   END SET_TIMER;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 13.12.2006 15:50
-- Editor  :
-- Changed :
-- Purpose : Функция преобразовывает результат запроса к колонке таблицы в список с разделителями(запятыми)
--------------------------------------------------------------------------------
   FUNCTION table_column_to_list_fn (p_query IN LONG, p_delimiter IN VARCHAR2 DEFAULT ',')
      RETURN LONG
   IS
      prc_name   CONSTANT NVARCHAR2 (100)   := pkg_name || 'table_column_to_list_fn';
      l_list              LONG;   --строка с разделителями
      l_line              LONG;   --строка результата запроса подготовденная как XML
      l_col_i             PLS_INTEGER       DEFAULT 0;   --счетчик
      l_desctbl           DBMS_SQL.desc_tab;   --описательная таблица для полей
      l_col_val           VARCHAR2 (4000);   --значение столБца
      l_status            INTEGER;   --статус выполнения динамического запроса
      l_colcnt            NUMBER            DEFAULT 0;   --кол-во столбцов
      l_numstr            NUMBER            DEFAULT 0;   --кол-во строк
      l_thecursor         BINARY_INTEGER    DEFAULT DBMS_SQL.open_cursor;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Очистим возвращаемый список
      l_list := '';

      IF p_delimiter IS NULL
      THEN
         raise_application_error (-20500, 'Invalid Delimiter');
      END IF;

      --Разберем запрос
      DBMS_SQL.parse (l_thecursor, p_query, DBMS_SQL.native);
      --Опишем столбцы
      DBMS_SQL.describe_columns (l_thecursor, l_colcnt, l_desctbl);

      --Определяем столбцы
      FOR i IN 1 .. l_colcnt
      LOOP
         DBMS_SQL.define_column (l_thecursor, i, l_col_val, 4000);
         pkg_db_util.DEBUG (prc_name, '...Определили столбец: ' || l_desctbl (i).col_name,
                            pkg_name);
      END LOOP;

      --Выполняем оператор.
      l_status := DBMS_SQL.EXECUTE (l_thecursor);

      --Выбраем все строки.
      WHILE (DBMS_SQL.fetch_rows (l_thecursor) > 0)
      LOOP
         --Номер строки
         l_numstr := l_numstr + 1;
         l_line := '';

         --Получаем и обрабатываем данные столбцов.
         FOR i IN 1 .. l_colcnt
         LOOP
            DBMS_SQL.COLUMN_VALUE (l_thecursor, i, l_col_val);

            IF (l_desctbl (i).col_type = 12)   -- Тип данных DATE
            THEN
               l_col_val := REPLACE (l_col_val, '/', '.');   --т.к. "/" управляющий в XML
            END IF;

            --Значение первого столбца выведем в строку с разделителем
            IF i = 1
            THEN
               l_list := l_list || l_col_val || p_delimiter;
            END IF;

            --Все столбцы как строка
            l_line := l_line || l_col_val || '*';
         END LOOP;
      END LOOP;

      pkg_db_util.DEBUG (prc_name, l_list, pkg_name);
      --Закроем курсор
      DBMS_SQL.close_cursor (l_thecursor);
      --Вернем результат
      RETURN l_list;
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_SQL.close_cursor (l_thecursor);
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END table_column_to_list_fn;

-------------------------------------------------------------------------------
-- Author  : Sergey Ermakov
-- Created : 26.11.2010 14:35
-- Editor  :
-- Changed :
-- Purpose : Возвращает описание ошибки ORACLE по ее коду
--------------------------------------------------------------------------------
   PROCEDURE get_oracle_error_description (
      p_SQLCODE          IN   NUMBER,
      p_SQLERRM          OUT  VARCHAR2
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_oracle_error_description';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      
      p_SQLERRM := SQLERRM(p_SQLCODE);
      --DBMS_OUTPUT.PUT_LINE(p_SQLERRM);

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
         
   END get_oracle_error_description; 
   
   
-------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 14.10.2011
-- Editor  :
-- Changed :
-- Purpose : Получает настройку 
--------------------------------------------------------------------------------
  FUNCTION get_setting(p_name VARCHAR2, p_default VARCHAR2 := NULL) RETURN NVARCHAR2 IS
  v_res NVARCHAR2(4000);
  BEGIN
      SELECT /*+ full(z)*/ --need func index lower(db_parameter_name)
          z.VALUE INTO v_res FROM global_value z
          WHERE lower(z.NAME) = lower(p_name);
      RETURN v_res;
  EXCEPTION
  WHEN OTHERS THEN
      RETURN p_default;
  END;

--------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 10.10.2011
-- Editor  :
-- Changed :
-- Purpose : Wrapper over procedure raise_application_error
--------------------------------------------------------------------------------
  procedure Raise_exception(p_error_code number, p_message varchar2)
    is
      v_error_code number;
      v_message    varchar2(2048);
    begin
      case
        when p_error_code between -20999 and -20000
          then 
            v_error_code := p_error_code;
          else
            v_error_code := -20000;
      end case;
      if (LENGTH(p_message) > 2048)
        then
          v_message := SUBSTR(p_message, 0, 2048);
        else
          v_message := p_message;
      end if;
      raise_application_error(v_error_code, v_message);
    end Raise_exception;

END;
/
