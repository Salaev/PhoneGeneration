CREATE PACKAGE pkg_services
IS
--******************************************************************************
-- Author  : Skripnik Petr
-- Created : 16.10.2006 14:05
-- Purpose : Cервисы периодических работ
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ----------------------------------------------
-- Petr Skripnik   09.11.2006  Изменен
-- Skripnik Petr   16.04.2007  version 1.11.8.2
--****************************************************************************--
--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 13.02.2007 11:42
-- Editor  :
-- Changed :
-- Purpose : Удалить формат выгрузки в файл
--------------------------------------------------------------------------------
   PROCEDURE del_format (p_id IN NUMBER, p_user IN NVARCHAR2);

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 12.02.2007 15:56
-- Editor  :
-- Changed :
-- Purpose : Получить формат
--------------------------------------------------------------------------------
   PROCEDURE get_format (p_id IN NUMBER, p_cur OUT sys_refcursor, p_error_code OUT NUMBER);

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 29.06.2007 12:36
-- Version :
--   1 29.06.2007
-- Modification :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE get_log (
      p_cur_log         OUT      sys_refcursor,
      p_user_id         IN       NVARCHAR2 DEFAULT NULL,
      p_tab_action_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 28.06.2007 13:14
-- Version : 1
-- Modification : log_management.log__get_events
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE get_logaction (p_cur_logaction OUT sys_refcursor);

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 12.02.2007 15:56
-- Editor  :
-- Changed :
-- Purpose : Создает новый формат загрузки файла
--------------------------------------------------------------------------------
   PROCEDURE ins_format (
      p_name          IN       NVARCHAR2,
      p_description   IN       NVARCHAR2,
      p_eqm_type_id   IN       NUMBER,
      p_template      IN       NVARCHAR2,
      p_user          IN       NVARCHAR2,
      p_error_code    OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 12.02.2007 15:56
-- Editor  :
-- Changed :
-- Purpose : Изменить формат выгрузки в файл
--------------------------------------------------------------------------------
   PROCEDURE upd_format (
      p_id            IN       NUMBER,
      p_name          IN       NVARCHAR2,
      p_description   IN       NVARCHAR2,
      p_eqm_type_id   IN       NUMBER,
      p_template      IN       NVARCHAR2,
      p_user          IN       NVARCHAR2,
      p_error_code    OUT      NUMBER
   );
END;
/
