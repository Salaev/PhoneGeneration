CREATE package search_pkg is

----------------------------------!---------------------------------------------
  procedure seek_eq_ii
  (
    p_seria_start     ct_nvarchar_s,
    p_seria_end       ct_nvarchar_s,
    p_qty             ct_number,
    p_status          ct_number,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
  );

----------------------------------!---------------------------------------------
  procedure seek_single_eq_ii
  (
    p_serial_number   ct_nvarchar_s,
    p_status          ct_number,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
  );

  procedure find_single_eq_ii
  (
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_status          number,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
  );

  procedure find_single_eq_stock_ii
  (
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_status          number,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
  );

----------------------------------!---------------------------------------------
  procedure seek_active_single_eq_ii
  (
    p_serial_number   ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
  );

  procedure find_active_single_eq_ii
  (
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
  );

  procedure find_active_single_eq_stock_ii
  (
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s,
    p_stock_id2       out ct_number,
    p_eq_model_id2    out ct_number
  );

----------------------------------!---------------------------------------------
  procedure seek_active_single_eq_i
  (
    p_serial_number   ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number
  );

  procedure seek_active_single_eq2_i
  (
    p_serial_number   ct_nvarchar_s,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_stock_id        out ct_number,
    p_eq_model_id     out ct_number
  );

  procedure find_active_single_eq_i
  (
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s
  );

  procedure find_active_single_eq_stock_i
  (
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_trim_empty      boolean,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s
  );

----------------------------------!---------------------------------------------
  procedure seek_active_single_eq
  (
    p_serial_number   ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number
  );

  procedure seek_active_single_eq2
  (
    p_serial_number   ct_nvarchar_s,
    p_ss_id           out ct_number,
    p_stock_id        out ct_number,
    p_eq_model_id     out ct_number
  );

  procedure find_active_single_eq
  (
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s
  );

  procedure find_active_single_eq_stock
  (
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s
  );

  procedure find_1_active_single_eq
  (
    p_serial_number1  nvarchar2,
    p_serial_number2  nvarchar2,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s
  );

  procedure find_1_active_single_eq_stock
  (
    p_serial_number1  nvarchar2,
    p_serial_number2  nvarchar2,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number,
    p_ss_serial_number out ct_nvarchar_s
  );

  procedure find_active_single_eq2
  (
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number
  );

  procedure find_active_single_eq2_stock
  (
    p_serial_number1  ct_nvarchar_s,
    p_serial_number2  ct_nvarchar_s,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number
  );

  procedure find_1_active_single_eq2
  (
    p_serial_number1  nvarchar2,
    p_serial_number2  nvarchar2,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number
  );

  procedure find_1_active_single_eq2_stock
  (
    p_serial_number1  nvarchar2,
    p_serial_number2  nvarchar2,
    p_stock_id        ct_number,
    p_eq_model_id     ct_number,
    p_count           number,
    p_ss_id           out ct_number
  );

----------------------------------!---------------------------------------------
  procedure get_result_cursor01
  (
    p_ss_id ct_number,
    p_date date,
    p_count number,
    p_trim_empty boolean,
    p_result out sys_refcursor
  );

  procedure get_result_cursor02
  (
    p_ss_id ct_number,
    p_msisdn ct_varchar_s,
    p_linked boolean,
    p_date date,
    p_count number,
    p_trim_empty boolean,
    p_result out sys_refcursor
  );

  procedure get_result_cursor03
  (
    p_ss_id ct_number,
    p_msisdn ct_varchar_s,
    p_model ct_model,
    p_linked boolean,
    p_date date,
    p_trim_empty boolean,
    p_result out sys_refcursor
  );

  procedure get_result_cursor07
  (
    p_serial_number ct_nvarchar_s,
    p_ss_id ct_number,
    p_ss_stock_id ct_number,
    p_ss_model_id ct_number,
    p_model ct_model,
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_result_cursor08
  (
    p_serial_number ct_nvarchar_s,
    p_ss_id ct_number,
    p_ss_stock_id ct_number,
    p_ss_model_id ct_number,
    p_model ct_model,
    p_date date,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
  function get_search_result_code02(p_ss_id number, p_ss_stock_id number, p_ss_model_id number, p_sm_id number, p_date date) return number;

  function get_search_result_msg02(p_result_code number) return varchar2;

----------------------------------!---------------------------------------------

end;
/
