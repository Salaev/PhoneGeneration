CREATE PACKAGE pkg_db_util IS

   PROCEDURE DEBUG (p_prc_name VARCHAR2, p_info VARCHAR2, p_chanel VARCHAR2 DEFAULT '');

END;
/
