CREATE package body util_stock is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure log_log_i
(
    p_user_id number,
    p_user_name nvarchar2,
    p_action_id number,
    p_object_id nvarchar2,
    p_description nvarchar2
)
is
begin
  ------------------------------
  insert into log (id, log_date, user_id, action_id, object_id, description, user_id2)
  values (s_log.nextval, sysdate, make_obsolete_user_name(p_user_name), p_action_id, shrink_nchar(p_object_id, 255), shrink_nchar(p_description, 255), p_user_id)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure log_log
(
    p_user_name nvarchar2,
    p_action_id number,
    p_object_id nvarchar2,
    p_description nvarchar2 := null
)
is
  v_user_id users.user_id%type;
  v_user_name users.user_name%type;
begin
  ------------------------------
  v_user_id := xget_user_id(p_user_name);
  v_user_name := xget_user_name(v_user_id);
  ------------------------------
  log_log_i
  (
    p_user_id => v_user_id,
    p_user_name => v_user_name,
    p_action_id => p_action_id,
    p_object_id => p_object_id,
    p_description => p_description
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure log_log2
(
    p_user_id number,
    p_action_id number,
    p_object_id nvarchar2,
    p_description nvarchar2 := null
)
is
  v_user_name users.user_name%type;
begin
  ------------------------------
  v_user_name := xget_user_name(p_user_id);
  ------------------------------
  log_log_i
  (
    p_user_id => p_user_id,
    p_user_name => v_user_name,
    p_action_id => p_action_id,
    p_object_id => p_object_id,
    p_description => p_description
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function yesno_to_bool_2val(p_val varchar2) return boolean
is
begin
  ------------------------------
  return nvl(yesno_to_bool_3val(p_val), false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function yesno_to_bool_3val(p_val varchar2) return boolean
is
begin
  ------------------------------
  return yesno_to_bool(p_val);
  ------------------------------
exception
when others then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function yesno_to_bool(p_val varchar2) return boolean
is
begin
  ------------------------------
  if p_val = c_yes
  then
    return true;
  elsif p_val = c_no
  then
    return false;
  elsif p_val is null
  then
    return null;
  else
    util_pkg.raise_exception(util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter || util_pkg.c_msg_delim01 || p_val);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xyesno_to_bool(p_val varchar2) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_val is null, 'p_val');
  ------------------------------
  return yesno_to_bool(p_val);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function shrink_char(p_value varchar2, p_length number) return varchar2
is
begin
  ------------------------------
  return substrc(p_value, 1, p_length);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function shrink_nchar(p_value nvarchar2, p_length number) return nvarchar2
is
begin
  ------------------------------
  return substrc(p_value, 1, p_length);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_obsolete_user_name(p_user_name users.user_name%type) return users.user_name%type
is
begin
  ------------------------------
  return shrink_nchar(p_user_name, c_obsolete_user_name_len);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_user_id(p_user_id number)
is
begin
  ------------------------------
  install_pkg.xcheck_user_id(p_user_id, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_user_name(p_user_name users.user_name%type)
is
begin
  ------------------------------
  install_pkg.xcheck_user_name2(p_user_name, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_user_id(p_user_id number) return number
is
begin
  ------------------------------
  return install_pkg.check_user_id(p_user_id, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_user_name(p_user_name users.user_name%type) return number
is
begin
  ------------------------------
  return install_pkg.check_user_name2(p_user_name, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_user_id(p_user_name users.user_name%type) return number
is
begin
  ------------------------------
  return install_pkg.xget_user_id2(p_user_name, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_user_name(p_user_id number) return users.user_name%type
is
begin
  ------------------------------
  return install_pkg.xget_user_name2(p_user_id, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_id(p_user_name users.user_name%type) return number
is
begin
  ------------------------------
  return install_pkg.get_user_id2(p_user_name, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_name(p_user_id number) return users.user_name%type
is
begin
  ------------------------------
  return install_pkg.get_user_name2(p_user_id, sysdate);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function check_permission(p_perm_active number, p_perm_mask number) return number
is
  v_res number := util_pkg.c_false;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_perm_active is null, 'p_perm_active');
  util_pkg.XCheck_Cond_Missing(p_perm_mask is null, 'p_perm_mask');
  ------------------------------
  if (1 = 0
    or p_perm_mask = c_perm_any
    or (p_perm_mask = c_perm_none and p_perm_active = c_perm_none)
    or (p_perm_mask != c_perm_none and p_perm_active != c_perm_none and (p_perm_mask = c_perm_not_none or bitand(p_perm_active, p_perm_mask) = p_perm_mask))
  )
  then
    v_res := util_pkg.c_true;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_stock_group_own_perms_ii(p_user_id number, p_date date, p_stocks boolean, p_groups boolean, p_perm_mask number, p_inclusive boolean) return ct_node
is
  v_res ct_node;
  v_stocks number := util_pkg.bool_to_int_2val(p_stocks);
  v_groups number := util_pkg.bool_to_int_2val(p_groups);
  v_inclusive number := util_pkg.bool_to_int_2val(p_inclusive);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_stocks is null, 'p_stocks');
  util_pkg.XCheck_Cond_Missing(p_groups is null, 'p_groups');
  util_pkg.XCheck_Cond_Missing(p_perm_mask is null, 'p_perm_mask');
  util_pkg.XCheck_Cond_Missing(p_inclusive is null, 'p_inclusive');
  ------------------------------
select
  ot_node
  (
    id,
    parent_id,
    val,
    type_id
  ) obj
  bulk collect into v_res
  from (

select /*+ ordered use_nl(z, z2)
  index_asc(z, I_SGP_U_SG_S)
  index_asc(z2, I_USER_STOCK_TIME_PRV)
  */
  distinct
  decode(z.stock_id, c_sgp_stock_id_for_group, z.stock_group_id, z.stock_id) id,
  decode(z.stock_id, c_sgp_stock_id_for_group, c_parent_id_no_parent, z.stock_group_id) parent_id,
  nvl(z.permission_mask, c_perm_none) val,
  decode(z.stock_id, c_sgp_stock_id_for_group, c_type_perm_group, c_type_perm_stock) type_id
  from stock_group_permission z, user_stock_time_privilege z2
  where 1 = 1
  and z.user_id = p_user_id
  and z2.stock_group_permission_id(+) = z.id
  and p_date between nvl(z2.start_date, p_date) and nvl(z2.end_date, p_date)
  and (1 = 0
    or (z.stock_id = c_sgp_stock_id_for_group and v_groups = util_pkg.c_true)
    or (z.stock_id != c_sgp_stock_id_for_group and v_stocks = util_pkg.c_true)
  )

  ) zzz --!_! for zzz.obj.val; now this reference is not used
  where 1 = 1
  and check_permission(val, p_perm_mask) = v_inclusive
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_group_own_perms_i(p_user_id number, p_date date, p_perm_mask number, p_inclusive boolean) return ct_node
is
begin
  ------------------------------
  return get_stock_group_own_perms_ii(p_user_id, p_date, FALSE, TRUE, p_perm_mask, p_inclusive);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_own_perms_i(p_user_id number, p_date date, p_perm_mask number, p_inclusive boolean) return ct_node
is
begin
  ------------------------------
  return get_stock_group_own_perms_ii(p_user_id, p_date, TRUE, FALSE, p_perm_mask, p_inclusive);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_group_hier_perms_i(p_group_own_perms ct_node, p_perm_mask number, p_inclusive boolean) return ct_node
is
  v_res ct_node;
  v_inclusive number := util_pkg.bool_to_int_2val(p_inclusive);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_perm_mask is null, 'p_perm_mask');
  util_pkg.XCheck_Cond_Missing(p_inclusive is null, 'p_inclusive');
  ------------------------------
select
  *
  bulk collect into v_res
  from (

select
  ot_node
  (
    id,
    parent_id,
    nvl(to_number(substr(hpath, instr(hpath, '@', -1, 1) + 1)), c_perm_none), --val --!_! magic
    c_type_perm_group --type_id
  ) obj
  from (

select
  z.*,
  replace(sys_connect_by_path(decode(perm, null, null, '@' || perm), '/'), '/', '') hpath --!_! magic
  from (

select /*+ ordered use_hash(q1, q2) full(q1)*/
  q1.id,
  q1.stock_group_id parent_id,
  q2.val perm
  from
    stock_group q1,
    (select * from table(p_group_own_perms)) q2
  where 1 = 1
  and q2.id(+) = q1.id
  and q2.type_id(+) = c_type_perm_group

  ) z
  start with parent_id = c_parent_id_no_parent
  connect by prior id = parent_id
  order siblings by id

  )

  ) zzz --!_!
  where 1 = 1
  and check_permission(zzz.obj.val, p_perm_mask) = v_inclusive
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_group_by_stck_hier_perms_i(p_group_hier_perms ct_node, p_stock_hier_perms ct_node, p_date date, p_perm_mask number, p_inclusive boolean) return ct_node
is
  v_res ct_node;
  v_group_by_stock_perms ct_node;
  v_inclusive number := util_pkg.bool_to_int_2val(p_inclusive);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_perm_mask is null, 'p_perm_mask');
  util_pkg.XCheck_Cond_Missing(p_inclusive is null, 'p_inclusive');
  ------------------------------
  v_group_by_stock_perms := get_parent_max_val_ct_node(p_stock_hier_perms, NULL, c_type_perm_group);
  ------------------------------
select
  *
  bulk collect into v_res
  from (

select /*+ ordered use_hash(g, gs)*/
  ot_node
  (
    g.id,
    g.parent_id,
    greatest(nvl(gs.val, c_perm_none), nvl(g.val, c_perm_none)), --val
    c_type_perm_group --type_id
  ) obj
  from
    (select * from table(p_group_hier_perms)) g,
    (select * from table(v_group_by_stock_perms)) gs
  where 1 = 1
  and gs.id(+) = g.id
  --!_!and gs.type_id(+) = c_type_perm_group

  ) zzz --!_!
  where 1 = 1
  and check_permission(zzz.obj.val, p_perm_mask) = v_inclusive
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_hier_perms_i(p_group_hier_perms ct_node, p_stock_own_perms ct_node, p_date date, p_perm_mask number, p_inclusive boolean) return ct_node
is
  v_res ct_node;
  v_inclusive number := util_pkg.bool_to_int_2val(p_inclusive);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  util_pkg.XCheck_Cond_Missing(p_perm_mask is null, 'p_perm_mask');
  util_pkg.XCheck_Cond_Missing(p_inclusive is null, 'p_inclusive');
  ------------------------------
select
  *
  bulk collect into v_res
  from (

select /*+ ordered use_hash(g, s) use_nl(st) index_asc(st, I_STOCK_STOCK_GROUP)*/
  ot_node
  (
    st.id,
    st.stock_group_id, --parent_id
    nvl(s.val, nvl(g.val, c_perm_none)), --val
    c_type_perm_stock --type_id
  ) obj
  from
    (select * from table(p_group_hier_perms)) g,
    stock st,
    (select * from table(p_stock_own_perms)) s
  where 1 = 1
  and st.stock_group_id = g.id
  and nvl(st.deleted, p_date + c_dummy_date_shift) > p_date
  and s.id(+) = st.id
  and s.type_id(+) = c_type_perm_stock

  ) zzz --!_!
  where 1 = 1
  and check_permission(zzz.obj.val, p_perm_mask) = v_inclusive
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_parent_min_val_ct_node(p_coll ct_node, p_parent_id_new number, p_type_id_new number := null) return ct_node
is
  v_res ct_node;
begin
  ------------------------------
select
  ot_node(parent_id, p_parent_id_new, min(val), decode(p_type_id_new, null, type_id, p_type_id_new))
  bulk collect into v_res
  from table(p_coll) q
  group by decode(p_type_id_new, null, type_id, p_type_id_new), parent_id
  order by decode(p_type_id_new, null, type_id, p_type_id_new), parent_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_parent_max_val_ct_node(p_coll ct_node, p_parent_id_new number, p_type_id_new number := null) return ct_node
is
  v_res ct_node;
begin
  ------------------------------
select
  ot_node(parent_id, p_parent_id_new, max(val), decode(p_type_id_new, null, type_id, p_type_id_new))
  bulk collect into v_res
  from table(p_coll) q
  group by decode(p_type_id_new, null, type_id, p_type_id_new), parent_id
  order by decode(p_type_id_new, null, type_id, p_type_id_new), parent_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function walk_to_child_i(p_nodes ct_node, p_start_id number, p_start_is_parent boolean) return ct_node
is
  v_res ct_node;
  v_start_is_parent number := util_pkg.bool_to_int_2val(p_start_is_parent);
begin
  ------------------------------
select
  ot_node(id, parent_id, val, type_id)
  bulk collect into v_res
  from table(p_nodes) q
  start with (1 = 0
    or (v_start_is_parent = util_pkg.c_false and id = p_start_id)
    or (v_start_is_parent = util_pkg.c_true and parent_id = p_start_id)
  )
  connect by prior id = parent_id
  order siblings by id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_group_perms_i(p_user_id number, p_date date, p_perm_mask number, p_inclusive boolean, p_start_group_id number, p_start_is_parent boolean) return ct_node
is
  v_res ct_node;
  v_group_own ct_node;
begin
  ------------------------------
  xcheck_user_id(p_user_id);
  ------------------------------
  v_group_own := get_group_own_perms_i(p_user_id, p_date, c_perm_any, TRUE);
  ------------------------------
  v_res := get_group_hier_perms_i(v_group_own, p_perm_mask, p_inclusive);
  ------------------------------
  if (1 = 0
    or not p_start_is_parent
    or p_start_group_id != c_parent_id_no_parent
  )
  then
    v_res := walk_to_child_i(v_res, p_start_group_id, p_start_is_parent);
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_group_by_stock_perms_i(p_user_id number, p_date date, p_perm_mask number, p_inclusive boolean, p_start_group_id number, p_start_is_parent boolean) return ct_node
is
  v_res ct_node;
  v_stock_hier ct_node;
  v_group_hier ct_node;
begin
  ------------------------------
  xcheck_user_id(p_user_id);
  ------------------------------
  v_stock_hier := get_stock_perms_i(p_user_id, p_date, c_perm_any, TRUE);
  ------------------------------
  v_group_hier := get_group_perms_i(p_user_id, p_date, c_perm_any, TRUE, p_start_group_id, p_start_is_parent);
  ------------------------------
  v_res := get_group_by_stck_hier_perms_i(v_group_hier, v_stock_hier, p_date, p_perm_mask, p_inclusive);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_perms_i(p_user_id number, p_date date, p_perm_mask number, p_inclusive boolean) return ct_node
is
  v_res ct_node;
  v_stock_own ct_node;
  v_group_hier ct_node;
begin
  ------------------------------
  xcheck_user_id(p_user_id);
  ------------------------------
  v_stock_own := get_stock_own_perms_i(p_user_id, p_date, c_perm_any, TRUE);
  ------------------------------
  v_group_hier := get_group_perms_i(p_user_id, p_date, c_perm_any, TRUE, c_parent_id_no_parent, TRUE);
  ------------------------------
  v_res := get_stock_hier_perms_i(v_group_hier, v_stock_own, p_date, p_perm_mask, p_inclusive);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function iget_group_perms(p_user_id number, p_perm_mask number, p_date date, p_inclusive number, p_start_group_id number, p_start_is_parent number) return ct_node
is
begin
  ------------------------------
  return get_group_perms_i(p_user_id, p_date, p_perm_mask, util_pkg.int_to_bool_2val(p_inclusive), p_start_group_id, util_pkg.int_to_bool_2val(p_start_is_parent));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function iget_group_by_stock_perms(p_user_id number, p_perm_mask number, p_date date, p_inclusive number, p_start_group_id number, p_start_is_parent number) return ct_node
is
begin
  ------------------------------
  return get_group_by_stock_perms_i(p_user_id, p_date, p_perm_mask, util_pkg.int_to_bool_2val(p_inclusive), p_start_group_id, util_pkg.int_to_bool_2val(p_start_is_parent));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function iget_stock_perms(p_user_id number, p_perm_mask number, p_date date, p_inclusive number) return ct_node
is
begin
  ------------------------------
  return get_stock_perms_i(p_user_id, p_date, p_perm_mask, util_pkg.int_to_bool_2val(p_inclusive));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function iget_group_own_perms(p_user_id number, p_perm_mask number, p_date date, p_inclusive number) return ct_node
is
begin
  ------------------------------
  return get_group_own_perms_i(p_user_id, p_date, p_perm_mask, util_pkg.int_to_bool_2val(p_inclusive));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function iget_stock_own_perms(p_user_id number, p_perm_mask number, p_date date, p_inclusive number) return ct_node
is
begin
  ------------------------------
  return get_stock_own_perms_i(p_user_id, p_date, p_perm_mask, util_pkg.int_to_bool_2val(p_inclusive));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_groups_with_descendants_i(p_group_ids ct_number) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
select /*+ ordered use_merge(q, z) full(z)*/
  distinct z.id
  bulk collect into v_res
  from
    (select distinct column_value id from table(p_group_ids)) q,
    stock_group z
  start with z.id = q.id
  connect by prior z.id = z.stock_group_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_groups_descendants_i(p_group_ids ct_number) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
select /*+ ordered use_merge(q, z) full(z)*/
  distinct z.id
  bulk collect into v_res
  from
    (select distinct column_value id from table(p_group_ids)) q,
    stock_group z
  start with z.stock_group_id = q.id
  connect by prior z.id = z.stock_group_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_groups_with_ancestors_i(p_group_ids ct_number) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
select /*+ ordered use_merge(q, z) full(z)*/
  distinct z.id
  bulk collect into v_res
  from
    (select distinct column_value id from table(p_group_ids)) q,
    stock_group z
  start with z.id = q.id
  connect by prior z.stock_group_id = z.id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_groups_ancestors_i(p_group_ids ct_number) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
select /*+ ordered use_merge(q, z) full(z)*/
  distinct z.id
  bulk collect into v_res
  from
    (

select /*+ ordered use_nl(q2, z2) index_asc(z2, )*/
  distinct z2.stock_group_id id
  from
    (select distinct column_value id from table(p_group_ids)) q2,
    stock_group z2
  where 1 = 1
  and z2.id = q2.id

    ) q,
    stock_group z
  start with z.id = q.id
  connect by prior z.stock_group_id = z.id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_stock_ids_all(p_date date) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
select /*+ full(z)*/
  id
  bulk collect into v_res
  from stock z
  where 1 = 1
  and nvl(deleted, p_date + c_dummy_date_shift) > p_date
  order by id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_codes_all(p_date date) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
select /*+ full(z)*/
  code
  bulk collect into v_res
  from stock z
  where 1 = 1
  and nvl(deleted, p_date + c_dummy_date_shift) > p_date
  order by code
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_equipment_model_ids_all(p_date date) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
select /*+ full(z)*/
  equipment_model_id
  bulk collect into v_res
  from equipment_model z
  where 1 = 1
  and nvl(deleted, p_date + c_dummy_date_shift) > p_date
  order by equipment_model_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_equipment_model_codes_all(p_date date) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
select /*+ full(z)*/
  equipment_model_code
  bulk collect into v_res
  from equipment_model z
  where 1 = 1
  and nvl(deleted, p_date + c_dummy_date_shift) > p_date
  order by equipment_model_code
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_stock_id_i(p_code ct_nvarchar_s, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_number
is
  v_res ct_number;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_uniquelize boolean := util_pkg.bool_to_bool_2val(p_uniquelize);
  v_code ct_nvarchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  if v_uniquelize
  then
    v_code := util_pkg.unique_ct_nvarchar_s(p_code, FALSE);
  else
    v_code := p_code;
  end if;
  ------------------------------
select /*+ ordered use_nl(q, z) index_asc(z, UK_STOCK_CODE)*/
  z.id
  bulk collect into v_res
  from (select column_value code, rownum rn from table(v_code)) q, stock z
  where 1 = 1
  and z.code(+) = q.code
  and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.code, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_code_i(p_id ct_number, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_uniquelize boolean := util_pkg.bool_to_bool_2val(p_uniquelize);
  v_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  if v_uniquelize
  then
    v_id := util_pkg.unique_ct_number(p_id, FALSE);
  else
    v_id := p_id;
  end if;
  ------------------------------
select /*+ ordered use_nl(q, z) index_asc(z, PK_STOCK)*/
  z.code
  bulk collect into v_res
  from (select column_value id, rownum rn from table(v_id)) q, stock z
  where 1 = 1
  and z.id(+) = q.id
  and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_equipment_model_id_i(p_code ct_nvarchar_s, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_number
is
  v_res ct_number;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_uniquelize boolean := util_pkg.bool_to_bool_2val(p_uniquelize);
  v_code ct_nvarchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  if v_uniquelize
  then
    v_code := util_pkg.unique_ct_nvarchar_s(p_code, FALSE);
  else
    v_code := p_code;
  end if;
  ------------------------------
select /*+ ordered use_nl(q, z) index_asc(z, UK_EQUIPMENT_MODEL_CODE)*/
  z.equipment_model_id
  bulk collect into v_res
  from (select column_value code, rownum rn from table(v_code)) q, equipment_model z
  where 1 = 1
  and z.equipment_model_code(+) = q.code
  and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.equipment_model_code, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_equipment_model_code_i(p_id ct_number, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_uniquelize boolean := util_pkg.bool_to_bool_2val(p_uniquelize);
  v_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  if v_uniquelize
  then
    v_id := util_pkg.unique_ct_number(p_id, FALSE);
  else
    v_id := p_id;
  end if;
  ------------------------------
select /*+ ordered use_nl(q, z) index_asc(z, PK_EQUIPMENT_MODEL)*/
  z.equipment_model_code
  bulk collect into v_res
  from (select column_value id, rownum rn from table(v_id)) q, equipment_model z
  where 1 = 1
  and z.equipment_model_id(+) = q.id
  and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.equipment_model_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure xcheck_stock_id(p_stock_id number, p_allow_dummy boolean := false)
is
begin
  ------------------------------
  if check_stock_id(p_stock_id, util_pkg.bool_to_int_2val(p_allow_dummy)) = util_pkg.c_false
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || 'p_stock_id' || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_stock_id));
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_stock_code(p_stock_code nvarchar2)
is
begin
  ------------------------------
  if check_stock_code(p_stock_code) = util_pkg.c_false
  then
    util_pkg.raise_exception(util_pkg.c_ora_object_not_found, util_pkg.c_msg_object_not_found || util_pkg.c_msg_delim01 || 'p_stock_code' || util_pkg.c_msg_delim02 || util_pkg.nchar_to_char(p_stock_code));
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_stock_id(p_stock_id number, p_allow_dummy number) return number
is
  v_allow_dummy boolean := util_pkg.int_to_bool_2val(p_allow_dummy);
begin
  ------------------------------
  if v_allow_dummy and p_stock_id = c_dummy_stock_id
  then
    return util_pkg.c_true;
  end if;
  ------------------------------
  if get_stock_code2(p_stock_id, sysdate) is null
  then
    return util_pkg.c_false;
  end if;
  ------------------------------
  return util_pkg.c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_stock_code(p_stock_code nvarchar2) return number
is
begin
  ------------------------------
  if get_stock_id2(p_stock_code, sysdate) is null
  then
    return util_pkg.c_false;
  end if;
  ------------------------------
  return util_pkg.c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_id_fuzzy(p_stock_code ct_nvarchar_s, p_date date) return ct_number
is
begin
  ------------------------------
  return get_stock_id_i(p_stock_code, p_date, TRUE, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_code_fuzzy(p_stock_id ct_number, p_date date) return ct_nvarchar_s
is
begin
  ------------------------------
  return get_stock_code_i(p_stock_id, p_date, TRUE, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_id_exact(p_stock_code ct_nvarchar_s, p_date date) return ct_number
is
begin
  ------------------------------
  return get_stock_id_i(p_stock_code, p_date, FALSE, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_code_exact(p_stock_id ct_number, p_date date) return ct_nvarchar_s
is
begin
  ------------------------------
  return get_stock_code_i(p_stock_id, p_date, FALSE, FALSE);
  ------------------------------
end;

-----------------------------------------------------------------------------------------------------------------------------------------------------
function get_stock_id2(p_stock_code nvarchar2, p_date date) return number
is
  v_stock_code ct_nvarchar_s;
begin
  ------------------------------
  util_pkg.add_ct_nvarchar_s_val(v_stock_code, p_stock_code);
  ------------------------------
  return get_stock_id_exact(v_stock_code, p_date)(1);
  ------------------------------
end;

-----------------------------------------------------------------------------------------------------------------------------------------------------
function get_stock_id2_or_dummy(p_stock_code nvarchar2, p_date date) return number
is
begin
  ------------------------------
  if p_stock_code is null
  then
    return c_dummy_stock_id;
  end if;
  ------------------------------
  return get_stock_id2(p_stock_code, p_date);
  ------------------------------
end;

-----------------------------------------------------------------------------------------------------------------------------------------------------
function get_stock_code2(p_stock_id number, p_date date) return nvarchar2
is
  v_stock_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_stock_id, p_stock_id);
  ------------------------------
  return get_stock_code_exact(v_stock_id, p_date)(1);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function filter_stocks01(p_stock_ids ct_number, p_group_ids ct_number, p_date date, p_include_by_filter boolean) return ct_number
is
  v_res ct_number;
  v_include_by_filter number := util_pkg.bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ ordered use_hash(q, z, q2) full(z)*/
    q.id
    bulk collect into v_res
    from
      (select column_value id, rownum rn from table(p_stock_ids)) q,
      stock z,
      (select distinct column_value id from table(p_group_ids)) q2
    where 1 = 1
    and z.id = q.id
    and q2.id(+) = z.stock_group_id
    and decode(q2.id, null, util_pkg.c_false, util_pkg.c_true) = v_include_by_filter
    and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
    order by q.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function ifilter_stocks01(p_stock_ids ct_number, p_group_ids ct_number, p_date date, p_include_by_filter number) return ct_number
is
begin
  ------------------------------
  return filter_stocks01(p_stock_ids, p_group_ids, p_date, util_pkg.int_to_bool_2val(p_include_by_filter));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function filter_groups01(p_group_ids ct_number, p_parent_group_ids ct_number, p_date date, p_include_by_filter boolean) return ct_number
is
  v_res ct_number;
  v_include_by_filter number := util_pkg.bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  util_loc_pkg.touch_date(p_date);
  ------------------------------
  select /*+ ordered use_hash(q, z, q2) full(z)*/
    q.id
    bulk collect into v_res
    from
      (select column_value id, rownum rn from table(p_group_ids)) q,
      stock_group z,
      (select distinct column_value id from table(p_parent_group_ids)) q2
    where 1 = 1
    and z.id = q.id
    and q2.id(+) = z.stock_group_id
    and decode(q2.id, null, util_pkg.c_false, util_pkg.c_true) = v_include_by_filter
    --!_!and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
    order by q.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function ifilter_groups01(p_group_ids ct_number, p_parent_group_ids ct_number, p_date date, p_include_by_filter number) return ct_number
is
begin
  ------------------------------
  return filter_groups01(p_group_ids, p_parent_group_ids, p_date, util_pkg.int_to_bool_2val(p_include_by_filter));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_groups02(p_group_ids ct_number, p_parent_group_id number, p_date date, p_include_by_filter boolean) return ct_number
is
  v_parent_group_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_parent_group_id is null, 'p_parent_group_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  util_pkg.add_ct_number_val(v_parent_group_ids, p_parent_group_id);
  ------------------------------
  return filter_groups01(p_group_ids, v_parent_group_ids, p_date, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function ifilter_groups02(p_group_ids ct_number, p_parent_group_id number, p_date date, p_include_by_filter number) return ct_number
is
begin
  ------------------------------
  return filter_groups02(p_group_ids, p_parent_group_id, p_date, util_pkg.int_to_bool_2val(p_include_by_filter));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_stock_by_code(p_code nvarchar2, p_date date) return stock%rowtype
is
  v_res stock%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ index_asc(z, UK_STOCK_CODE)*/
    * into v_res
    from stock z
    where 1 = 1
    and code = p_code
    and nvl(deleted, p_date + c_dummy_date_shift) > p_date
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_by_id(p_id number, p_date date) return stock%rowtype
is
  v_res stock%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ index_asc(z, PK_STOCK)*/
    * into v_res
    from stock z
    where 1 = 1
    and id = p_id
    and nvl(deleted, p_date + c_dummy_date_shift) > p_date
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_doc_type_by_id(p_id number) return doc_type%rowtype
is
  v_res doc_type%rowtype;
begin
  ------------------------------
  select /*+ index_asc(z, PK_T_DOC_TYPE)*/
    * into v_res
    from doc_type z
    where 1 = 1
    and id = p_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_doc_dir_type(p_doc_type_id number) return number
is
  v_res number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  if p_doc_type_id in (
    --c_Doc_Type_Receipt,
    --c_Doc_Type_Shippment,
    c_Doc_Type_Movement,
    c_Doc_Type_Assembling,
    c_Doc_Type_Disassembling,
    --c_Doc_Type_Credit,
    --c_Doc_Type_Debit,
    c_Doc_Type_SeriaPartition,
    c_Doc_Type_SeriaAssembling,
    c_Doc_Type_OpenSeries,
    c_Doc_Type_CloseSeries,
    c_Doc_Type_Inventory,
    c_Doc_Type_ErrorReport,
    c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    v_res := c_Doc_Dir_Type_InOut;
    ------------------------------
  elsif p_doc_type_id in (
    c_Doc_Type_Receipt,
    c_Doc_Type_Credit
  )
  then
    ------------------------------
    v_res := c_Doc_Dir_Type_In;
    ------------------------------
  elsif p_doc_type_id in (
    c_Doc_Type_Shippment,
    c_Doc_Type_Debit
  )
  then
    ------------------------------
    v_res := c_Doc_Dir_Type_Out;
    ------------------------------
  else
    ------------------------------
    v_res := null;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_doc_dir_type(p_doc_type_id number) return number
is
  v_res number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  v_res := get_doc_dir_type(p_doc_type_id);
  ------------------------------
  XCheck_doc_dir_type(v_res);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_doc_only_for_ser(p_doc_type_id number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  if p_doc_type_id in
  (
    --!_!c_Doc_Type_Receipt,
    --!_!c_Doc_Type_Shippment,
    --!_!c_Doc_Type_Movement,
    --!_!c_Doc_Type_Assembling, --!_!mixed ser/nser
    --!_!c_Doc_Type_Disassembling, --!_!mixed ser/nser
    --!_!c_Doc_Type_Credit,
    --!_!c_Doc_Type_Debit,
    c_Doc_Type_SeriaPartition,
    c_Doc_Type_SeriaAssembling,
    c_Doc_Type_OpenSeries,
    c_Doc_Type_CloseSeries,
    --!_!c_Doc_Type_Inventory,
    --!_!c_Doc_Type_ErrorReport,
    c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_doc_changes_eq_status(p_doc_type_id number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  if p_doc_type_id in
  (
    --!_!c_Doc_Type_Receipt,
    --!_!c_Doc_Type_Shippment,
    --!_!c_Doc_Type_Movement,
    --!_!c_Doc_Type_Assembling,
    --!_!c_Doc_Type_Disassembling,
    --!_!c_Doc_Type_Credit,
    --!_!c_Doc_Type_Debit,
    --!_!c_Doc_Type_SeriaPartition,
    --!_!c_Doc_Type_SeriaAssembling,
    c_Doc_Type_OpenSeries,
    c_Doc_Type_CloseSeries--!_!,
    --!_!c_Doc_Type_Inventory,
    --!_!c_Doc_Type_ErrorReport,
    --!_!c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function has_doc_external_data(p_doc_type_id number) return boolean
is
begin
  ------------------------------
  XCheck_doc_type(p_doc_type_id);
  ------------------------------
  if p_doc_type_id in
  (
    c_Doc_Type_Receipt,
    --!_!c_Doc_Type_Shippment,
    --!_!c_Doc_Type_Movement,
    --!_!c_Doc_Type_Assembling,
    --!_!c_Doc_Type_Disassembling,
    c_Doc_Type_Credit,
    --!_!c_Doc_Type_Debit,
    --!_!c_Doc_Type_SeriaPartition,
    --!_!c_Doc_Type_SeriaAssembling,
    --!_!c_Doc_Type_OpenSeries,
    --!_!c_Doc_Type_CloseSeries,
    c_Doc_Type_Inventory, --!!! maybe need to get REAL new subranges for overlap check
    c_Doc_Type_ErrorReport--!_!, --!!! maybe need to get REAL new subranges for overlap check
    --!_!c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_doc_eq_kept_inside_ss(p_doc_type_id number) return boolean
is
begin
  ------------------------------
  XCheck_doc_type(p_doc_type_id);
  ------------------------------
  if p_doc_type_id in
  (
    --!_!c_Doc_Type_Receipt,
    --!_!c_Doc_Type_Shippment,
    c_Doc_Type_Movement,
    --!_!c_Doc_Type_Assembling,
    --!_!c_Doc_Type_Disassembling,
    --!_!c_Doc_Type_Credit,
    --!_!c_Doc_Type_Debit,
    --!_!c_Doc_Type_SeriaPartition,
    --!_!c_Doc_Type_SeriaAssembling,
    c_Doc_Type_OpenSeries,
    c_Doc_Type_CloseSeries,
    --!_!c_Doc_Type_Inventory,
    --!_!c_Doc_Type_ErrorReport,
    c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_doc_symmetric(p_doc_type_id number) return boolean
is
begin
  ------------------------------
  XCheck_doc_type(p_doc_type_id);
  ------------------------------
  if p_doc_type_id in
  (
    --!_!c_Doc_Type_Receipt,
    --!_!c_Doc_Type_Shippment,
    c_Doc_Type_Movement,
    --!_!c_Doc_Type_Assembling,
    --!_!c_Doc_Type_Disassembling,
    --!_!c_Doc_Type_Credit,
    --!_!c_Doc_Type_Debit,
    --!_!c_Doc_Type_SeriaPartition,
    --!_!c_Doc_Type_SeriaAssembling,
    c_Doc_Type_OpenSeries,
    c_Doc_Type_CloseSeries,
    --!_!c_Doc_Type_Inventory,
    --!_!c_Doc_Type_ErrorReport,
    c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_doc_partitioned(p_doc_type_id number) return boolean
is
begin
  ------------------------------
  XCheck_doc_type(p_doc_type_id);
  ------------------------------
  if p_doc_type_id in
  (
    --!_!c_Doc_Type_Receipt,
    --!_!c_Doc_Type_Shippment,
    --!_!c_Doc_Type_Movement,
    --!_!c_Doc_Type_Assembling,
    --!_!c_Doc_Type_Disassembling,
    --!_!c_Doc_Type_Credit,
    --!_!c_Doc_Type_Debit,
    c_Doc_Type_SeriaPartition,
    c_Doc_Type_SeriaAssembling--!_!,
    --!_!c_Doc_Type_OpenSeries,
    --!_!c_Doc_Type_CloseSeries,
    --!_!c_Doc_Type_Inventory,
    --!_!c_Doc_Type_ErrorReport,
    --!_!c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!remember CREATE UNIQUE INDEX I_STOCK_STATE_EQM ON STOCK_STATE (EQUIPMENT_MODEL_ID, STOCK_ID, SERIA_START, SERIA_END)
----------------------------------!---------------------------------------------
function is_doc_initially_finalized(p_doc_type_id number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  if p_doc_type_id in
  (
    --!_!c_Doc_Type_Receipt,
    --!_!c_Doc_Type_Shippment,
    --!_!c_Doc_Type_Movement,
    c_Doc_Type_Assembling,
    c_Doc_Type_Disassembling,
    --!_!c_Doc_Type_Credit,
    --!_!c_Doc_Type_Debit,
    --!_!c_Doc_Type_SeriaPartition,
    --!_!c_Doc_Type_SeriaAssembling,
    c_Doc_Type_OpenSeries,
    c_Doc_Type_CloseSeries,
    c_Doc_Type_Inventory,
    c_Doc_Type_ErrorReport,
    c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_doc_normal(p_doc_type_id number) return boolean
is
begin
  ------------------------------
  return NOT is_doc_src_dst(p_doc_type_id);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_doc_src_dst(p_doc_type_id number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  if p_doc_type_id in
  (
    --!_!c_Doc_Type_Receipt,
    --!_!c_Doc_Type_Shippment,
    --!_!c_Doc_Type_Movement,
    c_Doc_Type_Assembling,
    c_Doc_Type_Disassembling,
    --!_!c_Doc_Type_Credit,
    --!_!c_Doc_Type_Debit,
    c_Doc_Type_SeriaPartition,
    c_Doc_Type_SeriaAssembling,
    --!_!c_Doc_Type_OpenSeries,
    --!_!c_Doc_Type_CloseSeries,
    c_Doc_Type_Inventory,
    c_Doc_Type_ErrorReport--!_!,
    --!_!c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_doc_minus_src_detail(p_doc_type_id number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  if p_doc_type_id in
  (
    --!_!c_Doc_Type_Receipt,
    --!_!c_Doc_Type_Shippment,
    --!_!c_Doc_Type_Movement,
    c_Doc_Type_Assembling,
    c_Doc_Type_Disassembling,
    --!_!c_Doc_Type_Credit,
    --!_!c_Doc_Type_Debit,
    c_Doc_Type_SeriaPartition,
    c_Doc_Type_SeriaAssembling,
    --!_!c_Doc_Type_OpenSeries,
    --!_!c_Doc_Type_CloseSeries,
    --!_!c_Doc_Type_Inventory,  --!_! To inventory document doc_detail equipment placed "as is" in stock_state. No "-" for missing equipment
    c_Doc_Type_ErrorReport--!_!,
    --!_!c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_doc_sign_old(p_doc_type_id number, p_stock_id number, p_stock_id_out number) return number
is
  v_res number;
begin
  ------------------------------
  if (1 = 0
    or p_doc_type_id = c_Doc_Type_Shippment
    or (p_doc_type_id = c_Doc_Type_Movement and p_stock_id = p_stock_id_out)
    or p_doc_type_id = c_Doc_Type_Debit
  )
  then
    ------------------------------
    v_res := -1;
    ------------------------------
  else
    ------------------------------
    v_res := 1;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_valid_stock_ids(p_stock_codes ct_nvarchar_s, p_date date) return ct_number
is
begin
  ------------------------------
  return get_stock_id_fuzzy(p_stock_codes, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_valid_stock_codes(p_stock_codes ct_nvarchar_s, p_date date) return ct_nvarchar_s
is
begin
  ------------------------------
  return get_stock_code_fuzzy(get_stock_id_fuzzy(p_stock_codes, p_date), p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_invalid_stock_codes(p_stock_codes ct_nvarchar_s, p_date date) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_stock_codes ct_nvarchar_s;
  v_stock_ids ct_number;
  v_valid_stock_ids ct_number;
begin
  ------------------------------
  v_stock_codes := util_pkg.unique_ct_nvarchar_s(p_stock_codes, FALSE);
  ------------------------------
  v_stock_ids := get_stock_id_exact(v_stock_codes, p_date);
  v_valid_stock_ids := get_stock_id_i(v_stock_codes, p_date, TRUE, false);
  ------------------------------
  v_res := util_pkg.filter_ct_nvarchar_s(v_stock_codes, v_stock_ids, v_valid_stock_ids, FALSE);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_stock_perms_ii(p_user_id number, p_stock_ids ct_number, p_date date, p_perm_mask number, p_trim_empty boolean, p_uniquelize boolean, p_absence_is_none boolean) return ct_number
is
  v_res ct_number;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_uniquelize boolean := util_pkg.bool_to_bool_2val(p_uniquelize);
  v_absence_is_none number := util_pkg.bool_to_int_2val(p_absence_is_none);
  v_stock_ids ct_number;
  v_nodes ct_node;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  if v_uniquelize
  then
    v_stock_ids := util_pkg.unique_ct_number(p_stock_ids, FALSE);
  else
    v_stock_ids := p_stock_ids;
  end if;
  ------------------------------
  v_nodes := get_stock_perms_i(p_user_id, p_date, p_perm_mask, TRUE);
  ------------------------------
select /*+ ordered use_hash(q0, q1)*/
  decode(v_absence_is_none, util_pkg.c_false, q1.val, nvl(q1.val, c_perm_none)) val
  bulk collect into v_res
  from
    (select column_value id, rownum rn from table(v_stock_ids)) q0,
    (select * from table(v_nodes)) q1
  where 1 = 1
  and q1.id(+) = q0.id
  and q1.type_id(+) = c_type_perm_stock
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(q1.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q0.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function iget_stock_perms_ii(p_user_id number, p_stock_ids ct_number, p_date date, p_perm_mask number, p_trim_empty number, p_uniquelize number, p_absence_is_none number) return ct_number
is
begin
  ------------------------------
  return get_stock_perms_ii(p_user_id, p_stock_ids, p_date, p_perm_mask, util_pkg.int_to_bool_2val(p_trim_empty), util_pkg.int_to_bool_2val(p_uniquelize), util_pkg.int_to_bool_2val(p_absence_is_none));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_perms_exact(p_user_id number, p_stock_ids ct_number, p_date date) return ct_number
is
begin
  ------------------------------
  return get_stock_perms_ii(p_user_id, p_stock_ids, p_date, c_perm_any, FALSE, FALSE, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_perms2_exact(p_user_id number, p_stock_codes ct_nvarchar_s, p_date date) return ct_number
is
  v_stock_ids ct_number;
begin
  ------------------------------
  v_stock_ids := get_stock_id_exact(p_stock_codes, p_date);
  ------------------------------
  return get_stock_perms_exact(p_user_id, v_stock_ids, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_nnperms_exact(p_user_id number, p_stock_ids ct_number, p_date date) return ct_number
is
begin
  ------------------------------
  return get_stock_perms_ii(p_user_id, p_stock_ids, p_date, c_perm_any, FALSE, FALSE, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_nnperms2_exact(p_user_id number, p_stock_codes ct_nvarchar_s, p_date date) return ct_number
is
  v_stock_ids ct_number;
begin
  ------------------------------
  v_stock_ids := get_stock_id_exact(p_stock_codes, p_date);
  ------------------------------
  return get_stock_nnperms_exact(p_user_id, v_stock_ids, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_perm(p_user_id number, p_stock_id number, p_date date) return number
is
  v_stock_ids ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_stock_ids, p_stock_id);
  ------------------------------
  return get_stock_perms_exact(p_user_id, v_stock_ids, p_date)(1);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_perm2(p_user_id number, p_stock_code nvarchar2, p_date date) return number
is
  v_stock_codes ct_nvarchar_s;
begin
  ------------------------------
  util_pkg.add_ct_nvarchar_s_val(v_stock_codes, p_stock_code);
  ------------------------------
  return get_stock_perms2_exact(p_user_id, v_stock_codes, p_date)(1);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_nnperm(p_user_id number, p_stock_id number, p_date date) return number
is
  v_stock_ids ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_stock_ids, p_stock_id);
  ------------------------------
  return get_stock_nnperms_exact(p_user_id, v_stock_ids, p_date)(1);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_stock_nnperm2(p_user_id number, p_stock_code nvarchar2, p_date date) return number
is
  v_stock_codes ct_nvarchar_s;
begin
  ------------------------------
  util_pkg.add_ct_nvarchar_s_val(v_stock_codes, p_stock_code);
  ------------------------------
  return get_stock_nnperms2_exact(p_user_id, v_stock_codes, p_date)(1);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_avail_stock_ids(p_user_id number, p_perm_mask number, p_date date) return ct_number
is
  v_res ct_number;
  v_nodes ct_node;
begin
  ------------------------------
  v_nodes := get_stock_perms_i(p_user_id, p_date, p_perm_mask, TRUE);
  ------------------------------
  select id bulk collect into v_res from table(v_nodes);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_avail_stock_codes(p_user_id number, p_perm_mask number, p_date date) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_ids ct_number;
begin
  ------------------------------
  v_ids := get_avail_stock_ids(p_user_id, p_perm_mask, p_date);
  ------------------------------
  v_res := get_stock_code_fuzzy(v_ids, p_date);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_avail_stock_ids2(p_user_id number, p_perm_mask number, p_stock_ids ct_number, p_date date) return ct_number
is
  v_res ct_number;
  v_filter ct_number;
  v_all ct_number;
begin
  ------------------------------
  v_filter := util_pkg.unique_ct_number(p_stock_ids, FALSE);
  ------------------------------
  v_all := get_avail_stock_ids(p_user_id, p_perm_mask, p_date);
  ------------------------------
  v_res := util_pkg.filter_val_ct_number(v_all, v_filter, TRUE);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_avail_stock_codes2(p_user_id number, p_perm_mask number, p_stock_codes ct_nvarchar_s, p_date date) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_filter ct_nvarchar_s;
  v_all ct_nvarchar_s;
begin
  ------------------------------
  v_filter := util_pkg.unique_ct_nvarchar_s(p_stock_codes, FALSE);
  ------------------------------
  v_all := get_avail_stock_codes(p_user_id, p_perm_mask, p_date);
  ------------------------------
  v_res := util_pkg.filter_val_ct_nvarchar_s(v_all, v_filter, TRUE);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_avail_stock_ids3(p_user_id number, p_perm_mask number, p_stock_codes ct_nvarchar_s, p_date date) return ct_number
is
  v_stock_ids ct_number;
begin
  ------------------------------
  v_stock_ids := get_stock_id_fuzzy(p_stock_codes, p_date);
  ------------------------------
  return get_avail_stock_ids2(p_user_id, p_perm_mask, v_stock_ids, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_avail_stock_codes3(p_user_id number, p_perm_mask number, p_stock_ids ct_number, p_date date) return ct_nvarchar_s
is
  v_stock_codes ct_nvarchar_s;
begin
  ------------------------------
  v_stock_codes := get_stock_code_fuzzy(p_stock_ids, p_date);
  ------------------------------
  return get_avail_stock_codes2(p_user_id, p_perm_mask, v_stock_codes, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_avail_group_ids(p_user_id number, p_perm_mask number, p_date date, p_start_group_id number, p_start_is_parent boolean) return ct_number
is
  v_res ct_number;
  v_nodes ct_node;
begin
  ------------------------------
  v_nodes := get_group_perms_i(p_user_id, p_date, p_perm_mask, TRUE, p_start_group_id, p_start_is_parent);
  ------------------------------
  select id bulk collect into v_res from table(v_nodes);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_avail_group_ids2(p_user_id number, p_perm_mask number, p_date date) return ct_number
is
begin
  ------------------------------
  return get_avail_group_ids(p_user_id, p_perm_mask, p_date, c_parent_id_no_parent, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_avail_stock(p_user_id number, p_perm_mask number, p_stock_id number, p_date date) return boolean
is
  v_stock_ids ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_stock_ids, p_stock_id);
  ------------------------------
  v_stock_ids := get_avail_stock_ids2(p_user_id, p_perm_mask, v_stock_ids, p_date);
  ------------------------------
  if util_pkg.CheckP_ct_number(v_stock_ids)
  then
    return true;
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_avail_stock2(p_user_id number, p_perm_mask number, p_stock_code nvarchar2, p_date date) return boolean
is
  v_stock_codes ct_nvarchar_s;
begin
  ------------------------------
  util_pkg.add_ct_nvarchar_s_val(v_stock_codes, p_stock_code);
  ------------------------------
  v_stock_codes := get_avail_stock_codes2(p_user_id, p_perm_mask, v_stock_codes, p_date);
  ------------------------------
  if util_pkg.CheckP_ct_nvarchar_s(v_stock_codes)
  then
    return true;
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function iis_avail_stock(p_user_id number, p_perm_mask number, p_stock_id number, p_date date) return number
is
begin
  ------------------------------
  return util_pkg.bool_to_int_2val(is_avail_stock(p_user_id, p_perm_mask, p_stock_id, p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function iis_avail_stock2(p_user_id number, p_perm_mask number, p_stock_code nvarchar2, p_date date) return number
is
begin
  ------------------------------
  return util_pkg.bool_to_int_2val(is_avail_stock2(p_user_id, p_perm_mask, p_stock_code, p_date));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_avail_stock(p_user_id number, p_perm_mask number, p_stock_id number, p_date date)
is
begin
  ------------------------------
  if not is_avail_stock(p_user_id, p_perm_mask, p_stock_id, p_date)
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_access_denied_to_stock, util_loc_pkg.c_msg_access_denied_to_stock
      || util_pkg.c_msg_delim01 || 'p_stock_id=' || util_pkg.number_to_char(p_stock_id)
      || util_pkg.c_msg_delim02 || 'p_perm_mask=' || util_pkg.number_to_char(p_perm_mask)
    );
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_avail_stock2(p_user_id number, p_perm_mask number, p_stock_code nvarchar2, p_date date)
is
begin
  ------------------------------
  if not is_avail_stock2(p_user_id, p_perm_mask, p_stock_code, p_date)
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_access_denied_to_stock, util_loc_pkg.c_msg_access_denied_to_stock
      || util_pkg.c_msg_delim01 || 'p_stock_code=' || util_pkg.nchar_to_char(p_stock_code)
      || util_pkg.c_msg_delim02 || 'p_perm_mask=' || util_pkg.number_to_char(p_perm_mask)
    );
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_unavail_stock_ids(p_user_id number, p_perm_mask number, p_date date) return ct_number
is
  v_res ct_number;
  v_nodes ct_node;
begin
  ------------------------------
  v_nodes := get_stock_perms_i(p_user_id, p_date, p_perm_mask, FALSE);
  ------------------------------
  select id bulk collect into v_res from table(v_nodes);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unavail_stock_codes(p_user_id number, p_perm_mask number, p_date date) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_ids ct_number;
begin
  ------------------------------
  v_ids := get_unavail_stock_ids(p_user_id, p_perm_mask, p_date);
  ------------------------------
  v_res := get_stock_code_fuzzy(v_ids, p_date);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unavail_stock_ids2(p_user_id number, p_perm_mask number, p_stock_ids ct_number, p_date date) return ct_number
is
  v_res ct_number;
  v_filter ct_number;
  v_all ct_number;
begin
  ------------------------------
  v_filter := util_pkg.unique_ct_number(p_stock_ids, FALSE);
  ------------------------------
  v_all := get_unavail_stock_ids(p_user_id, p_perm_mask, p_date);
  ------------------------------
  v_res := util_pkg.filter_val_ct_number(v_all, v_filter, TRUE);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unavail_stock_codes2(p_user_id number, p_perm_mask number, p_stock_codes ct_nvarchar_s, p_date date) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_filter ct_nvarchar_s;
  v_all ct_nvarchar_s;
begin
  ------------------------------
  v_filter := util_pkg.unique_ct_nvarchar_s(p_stock_codes, FALSE);
  ------------------------------
  v_all := get_unavail_stock_codes(p_user_id, p_perm_mask, p_date);
  ------------------------------
  v_res := util_pkg.filter_val_ct_nvarchar_s(v_all, v_filter, TRUE);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unavail_stock_ids3(p_user_id number, p_perm_mask number, p_stock_codes ct_nvarchar_s, p_date date) return ct_number
is
  v_stock_ids ct_number;
begin
  ------------------------------
  v_stock_ids := get_stock_id_fuzzy(p_stock_codes, p_date);
  ------------------------------
  return get_unavail_stock_ids2(p_user_id, p_perm_mask, v_stock_ids, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unavail_stock_codes3(p_user_id number, p_perm_mask number, p_stock_ids ct_number, p_date date) return ct_nvarchar_s
is
  v_stock_codes ct_nvarchar_s;
begin
  ------------------------------
  v_stock_codes := get_stock_code_fuzzy(p_stock_ids, p_date);
  ------------------------------
  return get_unavail_stock_codes2(p_user_id, p_perm_mask, v_stock_codes, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function GS_check_stock_in_perm return boolean
is
begin
  ------------------------------
  return install_pkg.nnget_option_bool(c_sett_check_stock_in_perm, c_def_check_stock_in_perm);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GS_ignore_model_type return boolean
is
begin
  ------------------------------
  return install_pkg.nnget_option_bool(c_sett_ignore_model_type, c_def_ignore_model_type);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ct_model(p_coll ct_model) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_count_ct_node(p_coll ct_node) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_model_val(p_coll in out nocopy ct_model, p_val ot_model)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_model();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_node_val(p_coll in out nocopy ct_node, p_val ot_node)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_node();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_model(p_coll in out nocopy ct_model, p_coll_add ct_model)
is
  v_count number;
begin
  ------------------------------
  if get_count_ct_model(p_coll_add) = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_model();
  end if;
  ------------------------------
  v_count := p_coll.count;
  ------------------------------
  p_coll.extend(p_coll_add.count);
  ------------------------------
  for v_i in p_coll_add.first..p_coll_add.last
  loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_node(p_coll in out nocopy ct_node, p_coll_add ct_node)
is
  v_count number;
begin
  ------------------------------
  if get_count_ct_node(p_coll_add) = 0
  then
    return;
  end if;
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_node();
  end if;
  ------------------------------
  v_count := p_coll.count;
  ------------------------------
  p_coll.extend(p_coll_add.count);
  ------------------------------
  for v_i in p_coll_add.first..p_coll_add.last
  loop
    ------------------------------
    p_coll(v_count + v_i) := p_coll_add(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_ct_model(p_coll ct_model, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(util_pkg.c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(util_pkg.c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(util_pkg.c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(util_pkg.c_msg_v_i || v_i
      || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_coll(v_i).id)
      || util_pkg.c_msg_delim02 || p_coll(v_i).code
      || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_coll(v_i).type_id)
      || util_pkg.c_msg_delim02 || p_coll(v_i).type_code
      || util_pkg.c_msg_delim02 || util_pkg.nchar_to_char(p_coll(v_i).type_code2)
      || util_pkg.c_msg_delim02 || p_coll(v_i).has_serial
      || util_pkg.c_msg_delim02 || p_coll(v_i).allows_part
      || util_pkg.c_msg_delim02 || p_coll(v_i).is_num_sn
      || util_pkg.c_msg_delim02 || p_coll(v_i).is_pack
    );
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure dbg_ct_node(p_coll ct_node, p_label varchar2 := null)
is
  v_i number;
begin
  ------------------------------
  dbms_output.put_line(util_pkg.c_msg_label || p_label);
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    dbms_output.put_line(util_pkg.c_msg_p_coll_is_null);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  dbms_output.put_line(util_pkg.c_msg_p_coll_count || p_coll.count);
  ------------------------------
  if p_coll.count = 0
  then
    return;
  end if;
  ------------------------------
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    dbms_output.put_line(util_pkg.c_msg_v_i || v_i
      || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_coll(v_i).id)
      || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_coll(v_i).parent_id)
      || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_coll(v_i).val)
      || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_coll(v_i).type_id)
    );
    ------------------------------
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function filter_ct_model(p_vals ct_model, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_model
is
  v_res ct_model;
  v_include_by_filter number := util_pkg.bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if get_count_ct_model(p_vals) = 0
  then
    return v_res;
  end if;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_ids_pivot is null or p_ids_pivot.count != p_vals.count, 'p_ids_pivot is null or p_ids_pivot.count != p_vals.count');
  ------------------------------
  if util_pkg.get_count_ct_number(p_ids_filter) = 0
  then
    ------------------------------
    if v_include_by_filter = util_pkg.c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q1.val
    bulk collect into v_res
    from
        (select ot_model(id, code, type_id, type_code, type_code2, has_serial, allows_part, is_num_sn, is_pack) val, rownum rn from table(p_vals)) q1,
        (select column_value id, rownum rn from table(p_ids_pivot)) q2,
        (select column_value id from table(p_ids_filter)) q3
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.id(+) = q2.id
    and decode(q3.id, null, util_pkg.c_false, util_pkg.c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_node(p_vals ct_node, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_node
is
  v_res ct_node;
  v_include_by_filter number := util_pkg.bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if get_count_ct_node(p_vals) = 0
  then
    return v_res;
  end if;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_ids_pivot is null or p_ids_pivot.count != p_vals.count, 'p_ids_pivot is null or p_ids_pivot.count != p_vals.count');
  ------------------------------
  if util_pkg.get_count_ct_number(p_ids_filter) = 0
  then
    ------------------------------
    if v_include_by_filter = util_pkg.c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2, q3)*/
    q1.val
    bulk collect into v_res
    from
        (select ot_node(id, parent_id, val, type_id) val, rownum rn from table(p_vals)) q1,
        (select column_value id, rownum rn from table(p_ids_pivot)) q2,
        (select column_value id from table(p_ids_filter)) q3
    where 1 = 1
    and q2.rn(+) = q1.rn
    and q3.id(+) = q2.id
    and decode(q3.id, null, util_pkg.c_false, util_pkg.c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_model_1val(p_vals ct_model, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_model
is
  v_coll ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_coll, p_id_filter_val);
  ------------------------------
  return filter_ct_model(p_vals, p_ids_pivot, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_node_1val(p_vals ct_node, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_node
is
  v_coll ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_coll, p_id_filter_val);
  ------------------------------
  return filter_ct_node(p_vals, p_ids_pivot, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_model(p_vals ct_model, p_filter_vals ct_model, p_include_by_filter boolean) return ct_model
is
  v_res ct_model;
  v_include_by_filter number := util_pkg.bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if get_count_ct_model(p_vals) = 0
  then
    return v_res;
  end if;
  ------------------------------
  if get_count_ct_model(p_filter_vals) = 0
  then
    ------------------------------
    if v_include_by_filter = util_pkg.c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q1.val
    bulk collect into v_res
    from
      (select ot_model(id, code, type_id, type_code, type_code2, has_serial, allows_part, is_num_sn, is_pack) val, rownum rn from table(p_vals)) q1,
      (select ot_model(id, code, type_id, type_code, type_code2, has_serial, allows_part, is_num_sn, is_pack) val, rownum rn from table(p_filter_vals)) q2
    where 1 = 1
    and nvl2(q2.val(+), util_pkg.c_false, util_pkg.c_true) = nvl2(q1.val, util_pkg.c_false, util_pkg.c_true)
    and nvl(q2.val(+), c_no_value_not_null_ot_model) = nvl(q1.val, c_no_value_not_null_ot_model)
    and decode(q2.rn, null, util_pkg.c_false, util_pkg.c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_node(p_vals ct_node, p_filter_vals ct_node, p_include_by_filter boolean) return ct_node
is
  v_res ct_node;
  v_include_by_filter number := util_pkg.bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  if get_count_ct_node(p_vals) = 0
  then
    return v_res;
  end if;
  ------------------------------
  if get_count_ct_node(p_filter_vals) = 0
  then
    ------------------------------
    if v_include_by_filter = util_pkg.c_true
    then
      return v_res;
    else
      return p_vals;
    end if;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q1.val
    bulk collect into v_res
    from
      (select ot_node(id, parent_id, val, type_id) val, rownum rn from table(p_vals)) q1,
      (select ot_node(id, parent_id, val, type_id) val, rownum rn from table(p_filter_vals)) q2
    where 1 = 1
    and nvl2(q2.val(+), util_pkg.c_false, util_pkg.c_true) = nvl2(q1.val, util_pkg.c_false, util_pkg.c_true)
    and nvl(q2.val(+), c_no_value_not_null_ot_node) = nvl(q1.val, c_no_value_not_null_ot_node)
    and decode(q2.rn, null, util_pkg.c_false, util_pkg.c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_model_1val(p_vals ct_model, p_filter_val ot_model, p_include_by_filter boolean) return ct_model
is
  v_coll ct_model;
begin
  ------------------------------
  add_ct_model_val(v_coll, p_filter_val);
  ------------------------------
  return filter_val_ct_model(p_vals, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_node_1val(p_vals ct_node, p_filter_val ot_node, p_include_by_filter boolean) return ct_node
is
  v_coll ct_node;
begin
  ------------------------------
  add_ct_node_val(v_coll, p_filter_val);
  ------------------------------
  return filter_val_ct_node(p_vals, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_ct_model_has_serial(p_vals ct_model, p_marker_vals ct_varchar_s, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number
is
  v_res ct_number;
  v_main_count number;
begin
  ------------------------------
  v_main_count := get_count_ct_model(p_vals);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  if util_pkg.get_count_ct_varchar_s(p_marker_vals) = 0
  then
    ------------------------------
    v_res := util_pkg.make_ct_number(v_main_count, p_unmark_value);
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_unmark_value, p_mark_value) val
    bulk collect into v_res
    from
      (select has_serial val, rownum rn from table(p_vals)) q1,
      (select column_value val, rownum rn from table(p_marker_vals)) q2
    where 1 = 1
    and nvl2(q2.val(+), util_pkg.c_false, util_pkg.c_true) = nvl2(q1.val, util_pkg.c_false, util_pkg.c_true)
    and nvl(q2.val(+), util_pkg.c_no_value_not_null_varchar_s) = nvl(q1.val, util_pkg.c_no_value_not_null_varchar_s)
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function mark_val_ct_model_has_serial(p_vals ct_model, p_marker_val varchar2, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number
is
  v_marker_vals ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_marker_vals, p_marker_val);
  ------------------------------
  return mark_ct_model_has_serial(p_vals, v_marker_vals, p_mark_value, p_unmark_value);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ct_model(p_vals ct_model, p_marks ct_number, p_trim_empty boolean, p_mark_value number := util_pkg.c_true, p_no_value ot_model := null) return ct_model
is
  v_res ct_model;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_main_count number;
begin
  ------------------------------
  v_main_count := get_count_ct_model(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select ot_model(id, code, type_id, type_code, type_code2, has_serial, allows_part, is_num_sn, is_pack) val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(decode(q2.mark, p_mark_value, q1.val, p_no_value), p_no_value, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ct_node(p_vals ct_node, p_marks ct_number, p_trim_empty boolean, p_mark_value number := util_pkg.c_true, p_no_value ot_node := null) return ct_node
is
  v_res ct_node;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_main_count number;
begin
  ------------------------------
  v_main_count := get_count_ct_node(p_vals);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.mark, p_mark_value, q1.val, p_no_value) val
    bulk collect into v_res
    from
      (select ot_node(id, parent_id, val, type_id) val, rownum rn from table(p_vals)) q1,
      (select column_value mark, rownum rn from table(p_marks)) q2
    where 1 = 1
    and q2.rn = q1.rn
    and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(decode(q2.mark, p_mark_value, q1.val, p_no_value), p_no_value, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ct_model(p_vals ct_model, p_positions ct_number, p_trim_empty boolean, p_no_value ot_model := null) return ct_model
is
  v_res ct_model;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if util_pkg.get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value, q2.val) val
    bulk collect into v_res
    from
      (select column_value pos, rownum rn from table(p_positions)) q1,
      (select ot_model(id, code, type_id, type_code, type_code2, has_serial, allows_part, is_num_sn, is_pack) val, rownum rn from table(p_vals)) q2
    where 1 = 1
    and q2.rn(+) = q1.pos
    and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(q2.rn, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ct_node(p_vals ct_node, p_positions ct_number, p_trim_empty boolean, p_no_value ot_node := null) return ct_node
is
  v_res ct_node;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  if util_pkg.get_count_ct_number(p_positions) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    decode(q2.rn, null, p_no_value, q2.val) val
    bulk collect into v_res
    from
      (select column_value pos, rownum rn from table(p_positions)) q1,
      (select ot_node(id, parent_id, val, type_id) val, rownum rn from table(p_vals)) q2
    where 1 = 1
    and q2.rn(+) = q1.pos
    and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(q2.rn, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheckP_ct_model(p_param ct_model, p_label varchar2 := null)
is
begin
  ------------------------------
  if not CheckP_ct_model(p_param)
  then
    util_pkg.Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_ct_node(p_param ct_node, p_label varchar2 := null)
is
begin
  ------------------------------
  if not CheckP_ct_node(p_param)
  then
    util_pkg.Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_ct_model(p_param ct_model) return boolean
is
begin
  ------------------------------
  if get_count_ct_model(p_param) = 0
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_ct_node(p_param ct_node) return boolean
is
begin
  ------------------------------
  if get_count_ct_node(p_param) = 0
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FS_ct_model(p_param ct_model, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_ct_model(p_param, p_label);
  ------------------------------
  xis_nulls_ct_model(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_FS_ct_node(p_param ct_node, p_label varchar2 := null)
is
begin
  ------------------------------
  XCheckP_ct_node(p_param, p_label);
  ------------------------------
  xis_nulls_ct_node(p_param, p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_nulls_ct_model(p_vals ct_model) return boolean
is
  v_coll ct_model;
begin
  ------------------------------
  add_ct_model_val(v_coll, null);
  ------------------------------
  v_coll := filter_val_ct_model(p_vals, v_coll, true);
  ------------------------------
  return CheckP_ct_model(v_coll);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_nulls_ct_node(p_vals ct_node) return boolean
is
  v_coll ct_node;
begin
  ------------------------------
  add_ct_node_val(v_coll, null);
  ------------------------------
  v_coll := filter_val_ct_node(p_vals, v_coll, true);
  ------------------------------
  return CheckP_ct_node(v_coll);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_nulls_ct_model(p_vals ct_model, p_label varchar2 := null)
is
begin
  ------------------------------
  if is_nulls_ct_model(p_vals)
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_empty, util_pkg.c_msg_object_empty || util_pkg.c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xis_nulls_ct_node(p_vals ct_node, p_label varchar2 := null)
is
begin
  ------------------------------
  if is_nulls_ct_node(p_vals)
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_empty, util_pkg.c_msg_object_empty || util_pkg.c_msg_delim01 || p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_doc_type(p_doc_type_id number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  if p_doc_type_id in
  (
    c_Doc_Type_Receipt,
    c_Doc_Type_Shippment,
    c_Doc_Type_Movement,
    c_Doc_Type_Assembling,
    c_Doc_Type_Disassembling,
    c_Doc_Type_Credit,
    c_Doc_Type_Debit,
    c_Doc_Type_SeriaPartition,
    c_Doc_Type_SeriaAssembling,
    c_Doc_Type_OpenSeries,
    c_Doc_Type_CloseSeries,
    c_Doc_Type_Inventory,
    c_Doc_Type_ErrorReport,
    c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.Raise_exception(util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_doc_type_id));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_doc_dir_type(p_doc_dir_type number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_dir_type is null, 'p_doc_dir_type');
  ------------------------------
  if p_doc_dir_type in
  (
    c_Doc_Dir_Type_InOut,
    c_Doc_Dir_Type_In,
    c_Doc_Dir_Type_Out
  )
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.Raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_doc_dir_type));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_Stocks(p_doc_dir_type number, p_stock_id_out number, p_stock_id_in number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_dir_type is null, 'p_doc_dir_type');
  util_pkg.XCheck_Cond_Missing(p_stock_id_out is null, 'p_stock_id_out');
  util_pkg.XCheck_Cond_Missing(p_stock_id_in is null, 'p_stock_id_in');
  ------------------------------
  if (1 = 0
    or (p_doc_dir_type = c_Doc_Dir_Type_InOut
      and (p_stock_id_out = c_dummy_stock_id or p_stock_id_in = c_dummy_stock_id)
    )
    or (p_doc_dir_type = c_Doc_Dir_Type_In
      and (p_stock_id_out != c_dummy_stock_id or p_stock_id_in = c_dummy_stock_id)
    )
    or (p_doc_dir_type = c_Doc_Dir_Type_Out
      and (p_stock_id_out = c_dummy_stock_id or p_stock_id_in != c_dummy_stock_id)
    )
  )
  then
    ------------------------------
    util_pkg.Raise_exception(util_loc_pkg.c_ora_wrong_stock, util_loc_pkg.c_msg_wrong_stock
      || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_doc_dir_type)
      || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_stock_id_out)
      || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_stock_id_in)
    );
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_Stock_Perms(p_user_id number, p_stock_id number, p_perm_mask number)
is
  v_date date := sysdate;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  util_pkg.XCheck_Cond_Missing(p_perm_mask is null, 'p_perm_mask');
  ------------------------------
  xcheck_user_id(p_user_id);
  ------------------------------
  if p_stock_id = c_dummy_stock_id
  then
    return;
  end if;
  ------------------------------
  if NOT GS_check_stock_in_perm and p_perm_mask = c_perm_change_in
  then
    return;
  end if;
  ------------------------------
  xis_avail_stock(p_user_id, p_perm_mask, p_stock_id, v_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_Doc_Perms(p_user_id number, p_doc_type_id number, p_action_id number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  util_pkg.XCheck_Cond_Missing(p_action_id is null, 'p_action_id');
  ------------------------------
  xcheck_user_id(p_user_id);
  ------------------------------
  if check_user_doc_permitting(p_user_id, p_doc_type_id, p_action_id) <> util_pkg.c_true
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_access_denied_to_doc_act, util_loc_pkg.c_msg_access_denied_to_doc_act
      || util_pkg.c_msg_delim01 || 'p_doc_type_id=' || util_pkg.number_to_char(p_doc_type_id)
      || util_pkg.c_msg_delim02 || 'p_action_id=' || util_pkg.number_to_char(p_action_id)
    );
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_user_doc_permitting(p_user_id number, p_document_type_id number, p_action_id number) return number
is
  v_res number;
begin
  ------------------------------
select /*+ ordered use_nl(u, pop, poa)
  index_asc(u, PK_USERS)
  index_asc(pop, I_PROGRAM_OBJECT_PERMISSION)
  index_asc(poa, PK_PROGRAM_OBJECT_ACTION)
  */
  pop.enabled into v_res
  from
    users u,
    program_object_permission pop,
    program_object_action poa
  where 1 = 1
  and u.user_id = p_user_id
  and pop.user_profile_id = u.user_profile_id
  and poa.id = pop.program_object_action_id
  and poa.program_object_id = p_document_type_id
  and poa.action_id = p_action_id
  ;
  ------------------------------
  v_res := util_pkg.int_to_int_2val(v_res);
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return util_pkg.c_false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function XFinish_To_Doc_Status(p_finish boolean) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_finish is null, 'p_finish');
  ------------------------------
  if p_finish
  then
    return c_docstat_finished;
  end if;
  ------------------------------
  return c_docstat_open;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XPartition_To_Doc_Type(p_partition boolean) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_partition is null, 'p_partition');
  ------------------------------
  if p_partition
  then
    return c_Doc_Type_SeriaPartition;
  end if;
  ------------------------------
  return c_Doc_Type_SeriaAssembling;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_Models(p_models1 ct_model, p_models2 ct_model)
is
  v_empty1 boolean := false;
  v_empty2 boolean := false;
begin
  ------------------------------
  if p_models1 is null or p_models1.count = 0
  then
    v_empty1 := true;
  end if;
  if p_models2 is null or p_models2.count = 0
  then
    v_empty2 := true;
  end if;
  ------------------------------
  if v_empty1 and v_empty2
  then
    return;
  end if;
  ------------------------------
  if v_empty1 != v_empty2
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_incompatible_eq_type, util_loc_pkg.c_msg_incompatible_eq_type);
  end if;
  ------------------------------
  if p_models1.count != p_models2.count
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_incompatible_eq_type, util_loc_pkg.c_msg_incompatible_eq_type);
  end if;
  ------------------------------
  for v_i in p_models1.first..p_models1.last
  loop
    if p_models1(v_i).has_serial <> p_models2(v_i).has_serial
    then
      util_pkg.raise_exception(util_loc_pkg.c_ora_incompatible_eq_type, util_loc_pkg.c_msg_incompatible_eq_type);
    end if;
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xhas_model_serial(p_model ot_model) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_model is null, 'p_model');
  ------------------------------
  return xyesno_to_bool(p_model.has_serial);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_ct_model_i(p_code ct_varchar_s, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_model
is
  v_res ct_model;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_uniquelize boolean := util_pkg.bool_to_bool_2val(p_uniquelize);
  v_code ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  if v_uniquelize
  then
    v_code := util_pkg.unique_ct_varchar_s(p_code, FALSE);
  else
    v_code := p_code;
  end if;
  ------------------------------
  select /*+ driving_site(q) ordered use_hash(q, em, et, est) full(em) full(et) index_ffs(est PK_EQUIPMENT_SYSTEM_TYPE)*/
    ot_model(
      em.equipment_model_id,
      em.equipment_model_code,
      et.equipment_type_id,
      et.equipment_type_code,
      est.equipment_system_type_code,
      est.has_serial_number,
      est.allows_partitioning,
      est.is_numeric_serial_number,
      est.is_package
    )
    bulk collect into v_res
    from
      (select column_value code, rownum rn from table(v_code)) q,
      equipment_model em, equipment_type et, equipment_system_type est
    where 1 = 1
    and em.equipment_model_code(+) = q.code
    and et.equipment_type_id(+) = em.equipment_type_id
    and est.equipment_system_type_code(+) = et.system_type_code
    and nvl(em.deleted(+), p_date + c_dummy_date_shift) > p_date
    and nvl(et.deleted(+), p_date + c_dummy_date_shift) > p_date
    and nvl(est.deleted(+), p_date + c_dummy_date_shift) > p_date
    and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(est.equipment_system_type_code, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    order by q.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ct_model2_i(p_id ct_number, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_model
is
  v_res ct_model;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_uniquelize boolean := util_pkg.bool_to_bool_2val(p_uniquelize);
  v_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  if v_uniquelize
  then
    v_id := util_pkg.unique_ct_number(p_id, FALSE);
  else
    v_id := p_id;
  end if;
  ------------------------------
  select /*+ driving_site(q) ordered use_hash(q, em, et, est) full(em) full(et) index_ffs(est PK_EQUIPMENT_SYSTEM_TYPE)*/
    ot_model(
      em.equipment_model_id,
      em.equipment_model_code,
      et.equipment_type_id,
      et.equipment_type_code,
      est.equipment_system_type_code,
      est.has_serial_number,
      est.allows_partitioning,
      est.is_numeric_serial_number,
      est.is_package
    )
    bulk collect into v_res
    from
      (select column_value id, rownum rn from table(v_id)) q,
      equipment_model em, equipment_type et, equipment_system_type est
    where 1 = 1
    and em.equipment_model_id(+) = q.id
    and et.equipment_type_id(+) = em.equipment_type_id
    and est.equipment_system_type_code(+) = et.system_type_code
    and nvl(em.deleted(+), p_date + c_dummy_date_shift) > p_date
    and nvl(et.deleted(+), p_date + c_dummy_date_shift) > p_date
    and nvl(est.deleted(+), p_date + c_dummy_date_shift) > p_date
    and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(est.equipment_system_type_code, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    order by q.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ct_model_codes(p_coll ct_model) return ct_varchar_s
is
  v_res ct_varchar_s;
begin
  ------------------------------
  select
    val
    bulk collect into v_res
    from
      (select code val, rownum rn from table(p_coll)) q
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ct_model_ids(p_coll ct_model) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  select
    val
    bulk collect into v_res
    from
      (select id val, rownum rn from table(p_coll)) q
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ct_model_type_ids(p_coll ct_model) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  select
    val
    bulk collect into v_res
    from
      (select type_id val, rownum rn from table(p_coll)) q
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_ct_model_fuzzy(p_code ct_varchar_s, p_date date) return ct_model
is
begin
  ------------------------------
  return get_ct_model_i(p_code, p_date, TRUE, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ct_model2_fuzzy(p_id ct_number, p_date date) return ct_model
is
begin
  ------------------------------
  return get_ct_model2_i(p_id, p_date, TRUE, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ct_model_exact(p_code ct_varchar_s, p_date date) return ct_model
is
begin
  ------------------------------
  return get_ct_model_i(p_code, p_date, FALSE, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ct_model2_exact(p_id ct_number, p_date date) return ct_model
is
begin
  ------------------------------
  return get_ct_model2_i(p_id, p_date, FALSE, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ot_model(p_code varchar2, p_date date) return ot_model
is
  v_code ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_code, p_code);
  ------------------------------
  return get_ct_model_exact(v_code, p_date)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ot_model2(p_id number, p_date date) return ot_model
is
  v_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_id, p_id);
  ------------------------------
  return get_ct_model2_exact(v_id, p_date)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_model01(p_model ct_model, p_eq_type_id ct_number, p_include_by_filter boolean) return ct_model
is
  v_res ct_model;
  v_include_by_filter number := util_pkg.bool_to_int_2val(p_include_by_filter);
  v_eq_type_id ct_number;
begin
  ------------------------------
  v_eq_type_id := util_pkg.unique_ct_number(p_eq_type_id, FALSE);
  ------------------------------
  select /*+ ordered use_hash(q, q2)*/
    q.val
    bulk collect into v_res
    from
      (select ot_model(id, code, type_id, type_code, type_code2, has_serial, allows_part, is_num_sn, is_pack) val, rownum rn from table(p_model)) q,
      (select column_value id, rownum rn from table(v_eq_type_id)) q2
    where 1 = 1
    and q2.id(+) = q.val.type_id
    and decode(q2.id, null, util_pkg.c_false, util_pkg.c_true) = v_include_by_filter
    order by q.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_ct_model02(p_model ct_model, p_eq_type_code ct_varchar_s, p_include_by_filter boolean) return ct_model
is
  v_res ct_model;
  v_include_by_filter number := util_pkg.bool_to_int_2val(p_include_by_filter);
  v_eq_type_code ct_varchar_s;
begin
  ------------------------------
  v_eq_type_code := util_pkg.unique_ct_varchar_s(p_eq_type_code, FALSE);
  ------------------------------
  select /*+ ordered use_hash(q, q2)*/
    q.val
    bulk collect into v_res
    from
      (select ot_model(id, code, type_id, type_code, type_code2, has_serial, allows_part, is_num_sn, is_pack) val, rownum rn from table(p_model)) q,
      (select column_value code, rownum rn from table(v_eq_type_code)) q2
    where 1 = 1
    and q2.code(+) = q.val.type_code
    and decode(q2.code, null, util_pkg.c_false, util_pkg.c_true) = v_include_by_filter
    order by q.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_model_ids4type_codes(p_eq_type_codes ct_varchar_s, p_date date) return ct_number
is
  v_res ct_number;
  v_model ct_model;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_model := get_ct_model2_fuzzy(get_equipment_model_ids_all(p_date), p_date);
  v_model := filter_ct_model02(v_model, p_eq_type_codes, true);
  v_res := get_ct_model_ids(v_model);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_model_ids4type_code(p_eq_type_code varchar2, p_date date) return ct_number
is
  v_eq_type_codes ct_varchar_s;
begin
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_eq_type_codes, p_eq_type_code);
  ------------------------------
  return get_model_ids4type_codes(v_eq_type_codes, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_sn_from_full_number(p_full_number ct_nvarchar_s) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_main_count number;
  v_length number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_full_number);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.resize_ct_nvarchar_s(v_res, v_main_count);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_length := util_pkg.nstr_length(p_full_number(v_i));
    ------------------------------
    v_res(v_i) := shrink_nchar(p_full_number(v_i), v_length - c_control_number_length);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

function make_sn_from_full_number2(p_full_number nvarchar2) return nvarchar2
is
  v_full_number ct_nvarchar_s;
begin
  ------------------------------
  util_pkg.add_ct_nvarchar_s_val(v_full_number, p_full_number);
  ------------------------------
  return make_sn_from_full_number(v_full_number)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_sims_full_number_i(p_serial_number ct_nvarchar_s, p_trim_empty boolean, p_uniquelize boolean) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_uniquelize boolean := util_pkg.bool_to_bool_2val(p_uniquelize);
  v_serial_number ct_nvarchar_s;
begin
  ------------------------------
  if v_uniquelize
  then
    v_serial_number := util_pkg.unique_ct_nvarchar_s(p_serial_number, FALSE);
  else
    v_serial_number := p_serial_number;
  end if;
  ------------------------------
select /*+ ordered use_nl(q, z) index_asc(z, AK_SIMS_SN)*/
  z.full_number
  bulk collect into v_res
  from (select column_value serial_number, rownum rn from table(v_serial_number)) q, sims z
  where 1 = 1
  and z.serial_number(+) = q.serial_number
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.serial_number, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_sims_full_number(p_serial_number ct_nvarchar_s) return ct_nvarchar_s
is
begin
  ------------------------------
  return get_sims_full_number_i(p_serial_number, TRUE, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_sims_sn(p_sim_id ct_number, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_sim_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_sim_id) != v_main_count, 'p_sim_id.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_nl(z) index_asc(z, PK_SIMS)*/
  z.serial_number, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value id, rownum rn from table(p_sim_id)) q,
    sims z
  where 1 = 1
  and z.id = q.id
  --and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sims');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_varchar_s(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_sims_sn2(p_sim_id number) return varchar2
is
  v_sim_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_sim_id, p_sim_id);
  ------------------------------
  return get_sims_sn(v_sim_id, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_sims_id4serial_number(p_serial_number ct_nvarchar_s, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_serial_number);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_serial_number) != v_main_count, 'p_serial_number.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_nl(z) index_asc(z, AK_SIMS_SN)*/
  z.id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value serial_number, rownum rn from table(p_serial_number)) q,
    sims z
  where 1 = 1
  and z.serial_number = q.serial_number
  --and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'sims');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_sims_id4serial_number2(p_serial_number nvarchar2) return number
is
  v_serial_number ct_nvarchar_s;
begin
  ------------------------------
  util_pkg.add_ct_nvarchar_s_val(v_serial_number, p_serial_number);
  ------------------------------
  return get_sims_id4serial_number(v_serial_number, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_ss_model_id(p_seria_start ct_nvarchar_s, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_seria_start);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_start) != v_main_count, 'p_seria_start.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_nl(z) index_asc(z, I_STOCK_STATE_SS)*/
  z.equipment_model_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value seria_start, rownum rn from table(p_seria_start)) q,
    stock_state z
  where 1 = 1
  and z.seria_start = q.seria_start
  --and nvl(z.deleted, q2.validity_date + c_dummy_date_shift) > q2.validity_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'stock_state');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ss_model_id2(p_seria_start nvarchar2) return number
is
  v_seria_start ct_nvarchar_s;
begin
  ------------------------------
  util_pkg.add_ct_nvarchar_s_val(v_seria_start, p_seria_start);
  ------------------------------
  return get_ss_model_id(v_seria_start, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_model_type_id(p_model_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_res ct_number;
  v_main_count number;
  v_rn ct_number;
  v_tmp_rn ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  util_pkg.XCheck_Cond_Missing(p_xcheck_data is null, 'p_xcheck_data');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_model_id);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_model_id) != v_main_count, 'p_model_id.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
select /*+ ordered use_nl(z)*/
  z.equipment_type_id, q.rn
  bulk collect into v_res, v_rn
  from
    (select column_value equipment_model_id, rownum rn from table(p_model_id)) q,
    equipment_model z
  where 1 = 1
  and z.equipment_model_id = q.equipment_model_id
  and nvl(z.deleted, p_date + c_dummy_date_shift) > p_date
  order by q.rn
  ;
  ------------------------------
  if p_xcheck_data
  then
    ------------------------------
    util_pkg.xis_unique_ct_number(v_rn, 'equipment_model');
    ------------------------------
  end if;
  ------------------------------
  if not p_trim_empty
  then
    ------------------------------
    v_tmp_rn := util_pkg.make_pivot(v_main_count);
    ------------------------------
    v_res := util_pkg.join2pivot_ct_number(v_res, v_tmp_rn, v_rn);
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_model_type_id2(p_model_id number, p_date date) return varchar2
is
  v_model_id ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_model_id, p_model_id);
  ------------------------------
  return get_model_type_id(v_model_id, p_date, FALSE)(c_index_one);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_serial_number(p_serial_number nvarchar2, p_label varchar2 := null)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_serial_number is null, util_pkg.smart_label1(p_label, 'p_serial_number'));
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(NOT is_serial_only_digits(p_serial_number), util_pkg.smart_label2(p_label, 'p_serial_number', ' NOT is_serial_only_digits' || util_pkg.c_msg_delim02 || util_pkg.nchar_to_char(p_serial_number)));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_seria(p_seria_start nvarchar2, p_seria_end nvarchar2)
is
begin
  ------------------------------
  XCheck_serial_number(p_seria_start, 'p_seria_start');
  XCheck_serial_number(p_seria_end, 'p_seria_end');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.nstr_length(p_seria_start) != util_pkg.nstr_length(p_seria_end), 'p_seria_start.length != p_seria_end.length');
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_serial_non_digits(p_serial_number nvarchar2) return nvarchar2
is
begin
  ------------------------------
  return translate(p_serial_number, '_0123456789', '_');
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_serial_only_digits(p_serial_number nvarchar2) return boolean
is
begin
  ------------------------------
  return (get_serial_non_digits(p_serial_number) is null);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_serial_as_number(p_serial_number nvarchar2) return integer
is
begin
  ------------------------------
  return util_pkg.char_to_number(util_pkg.nchar_to_char(p_serial_number));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_seria_quantity(p_seria_start nvarchar2, p_seria_end nvarchar2) return integer
is
  v_seria_start_n integer;
  v_seria_end_n integer;
begin
  ------------------------------
  XCheck_seria(p_seria_start, p_seria_end);
  ------------------------------
  v_seria_start_n := get_serial_as_number(p_seria_start);
  v_seria_end_n := get_serial_as_number(p_seria_end);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_seria_start_n > v_seria_end_n, 'p_seria_start > p_seria_end');
  ------------------------------
  return (v_seria_end_n - v_seria_start_n + 1);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function split_ranges_i(p_begin ct_number, p_end ct_number, p_uniquelize boolean) return ct_number
is
  v_res ct_number;
  v_uniquelize boolean := util_pkg.bool_to_bool_2val(p_uniquelize);
  v_cnt_null number;
  v_cnt_not_int number;
  v_len_min number;
  v_len_max number;
  --!_!v_main_count number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_begin, 'p_begin');
  --!_!util_pkg.XCheckP_FS_ct_number(p_end, 'p_end');
  ------------------------------
  --!_!v_main_count := util_pkg.get_count_ct_number(p_begin);
  --!_!util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_begin) != v_main_count, 'p_begin.count != v_main_count');
  --!_!util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_end) != v_main_count, 'p_end.count != v_main_count');
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    sum(decode(q1.val_from, null, 1, 0) + decode(q2.val_to, null, 1, 0)) cnt_null,
    sum(decode(q1.val_from - floor(q1.val_from), 0, 0, 1) + decode(q2.val_to - floor(q2.val_to), 0, 0, 1)) cnt_not_int,
    min(q2.val_to - q1.val_from + 1) len_min,
    max(q2.val_to - q1.val_from + 1) len_max
  into
    v_cnt_null,
    v_cnt_not_int,
    v_len_min,
    v_len_max
  from
    (select column_value val_from, rownum rn from table(p_begin)) q1,
    (select column_value val_to, rownum rn from table(p_end)) q2
  where 1 = 1
    and q2.rn(+) = q1.rn
  ;
  ------------------------------
  if v_cnt_null > 0
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'there is nulls');
    ------------------------------
  end if;
  ------------------------------
  if v_cnt_not_int > 0
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'there is not integer');
    ------------------------------
  end if;
  ------------------------------
  if v_len_min <= 0
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || 'there is p_begin > p_end');
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2) use_nl(z)*/
    q1.val_from + z.val - 1 val
  bulk collect into
    v_res
  from
    (select column_value val_from, rownum rn from table(p_begin)) q1,
    (select column_value val_to, rownum rn from table(p_end)) q2,
    (select rownum val from dual connect by level <= v_len_max) z
  where 1 = 1
    and q2.rn = q1.rn
    and (q2.val_to - q1.val_from + 1) >= z.val
  order by
    q1.rn
  ;
  ------------------------------
  if v_uniquelize
  then
    v_res := util_pkg.unique_ct_number(v_res, FALSE);
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!function split_ranges(p_begin ct_number, p_end ct_number) return ct_number
--!_!all checks and return split_ranges_i(p_begin, p_end, TRUE);

----------------------------------!---------------------------------------------
--!_!function split_ranges2(p_begin ct_varchar_s, p_end ct_varchar_s) return ct_varchar_s
--!_!same as split_ranges3 and lpad(TO_CHAR(val), v_i.len, c_range_padding_CHAR) val

----------------------------------!---------------------------------------------
function split_ranges3(p_begin ct_nvarchar_s, p_end ct_nvarchar_s) return ct_nvarchar_s
is
  v_main_count number;
  v_cnt_not_eq number;
  --
  v_marks ct_number;
  --
  v_lens ct_number;
  v_begin ct_nvarchar_s;
  v_end ct_nvarchar_s;
  v_single ct_nvarchar_s;
  v_single_tmp ct_nvarchar_s;
  v_begin_n ct_number;
  v_end_n ct_number;
  v_single_n ct_number;
  --
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_nvarchar_s(p_begin, 'p_begin');
  util_pkg.XCheckP_FS_ct_nvarchar_s(p_end, 'p_end');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_begin);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_begin) != v_main_count, 'p_begin.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_end) != v_main_count, 'p_end.count != v_main_count');
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    sum(decode(length(q1.val_from) - length(q2.val_to), 0, 0, 1)) cnt_not_eq
  into
    v_cnt_not_eq
  from
    (select column_value val_from, rownum rn from table(p_begin)) q1,
    (select column_value val_to, rownum rn from table(p_end)) q2
  where 1 = 1
    and q2.rn(+) = q1.rn
  ;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_cnt_not_eq > 0, 'length(p_begin) != length(p_end)');
  ------------------------------
  select
    length(val) len
  bulk collect into
    v_lens
  from
    (select column_value val, rownum rn from table(p_begin)) q
  where 1 = 1
  order by
    rn
  ;
  ------------------------------
  v_single := null;
  ------------------------------
  for v_i in
  (
    select
      len
    from
      (select column_value len, rownum rn from table(v_lens)) q
    where 1 = 1
    group by
      len
    order by
      len
  )
  loop
    ------------------------------
    v_marks := util_pkg.mark_val_ct_number(v_lens, v_i.len);
    ------------------------------
    v_begin := util_coll_pkg.get_marked_ol_ct_nvarchar_s(p_begin, v_marks);
    v_end := util_coll_pkg.get_marked_ol_ct_nvarchar_s(p_end, v_marks);
    ------------------------------
    v_begin_n := util_pkg.cast_ct_nvarchar_s2ct_number(p_coll => v_begin, p_raise => TRUE);
    v_end_n := util_pkg.cast_ct_nvarchar_s2ct_number(p_coll => v_end, p_raise => TRUE);
    ------------------------------
    v_single_n := split_ranges_i(p_begin => v_begin_n, p_end => v_end_n, p_uniquelize => TRUE);
    ------------------------------
    select
      lpad(TO_NCHAR(val), v_i.len, c_range_padding_NCHAR) val
    bulk collect into
      v_single_tmp
    from
      (select column_value val, rownum rn from table(v_single_n)) q
    where 1 = 1
    order by
      rn
    ;
    ------------------------------
    util_pkg.add_ct_nvarchar_s(v_single, v_single_tmp);
    ------------------------------
  end loop;
  ------------------------------
  return v_single;
  ------------------------------
end;

----------------------------------!---------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------
function validate_link_status(p_link_status number) return number
is
  v_res number;
begin
  ------------------------------
  if p_link_status = c_link_status_free
  then
    v_res := c_link_status_free;
  elsif p_link_status = c_link_status_linked
  then
    v_res := c_link_status_linked;
  else
    v_res := c_link_status_all;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

-----------------------------------------------------------------------------------------------------------------------------------------------------
function map_link_status(p_link_status number) return boolean
is
  v_res boolean;
  v_link_status number;
begin
  ------------------------------
  v_link_status := validate_link_status(p_link_status);
  ------------------------------
  if v_link_status = c_link_status_free
  then
    v_res := false;
  elsif v_link_status = c_link_status_linked
  then
    v_res := true;
  else
    v_res := null;
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_seria_not_null(p_seria_start in out nocopy nvarchar2, p_seria_end in out nocopy nvarchar2)
is
begin
  ------------------------------
  pkg_equipment.get_seria_not_null(p_seria_start, p_seria_end);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_ri_phone_number_i(p_full_number ct_varchar_s, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_uniquelize boolean := util_pkg.bool_to_bool_2val(p_uniquelize);
  v_full_number ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  if v_uniquelize
  then
    v_full_number := util_pkg.unique_ct_varchar_s(p_full_number, FALSE);
  else
    v_full_number := p_full_number;
  end if;
  ------------------------------
  select
    msisdn
    bulk collect into v_res
    from (

select /*+ driving_site(sc) ordered use_nl(q, sc, naap, pn) index_asc(sc, UK_SIM_SN) index_asc(naap, I_NETADDRACCPO_ACCESS_POINT_ID) index_asc(pn, PK_PHONE_NUMBER)*/
  q.rn,
  pn.international_format msisdn,
  row_number() over (partition by q.full_number
    order by decode(trim(naap.link_type_code),
      c_RI_MAIN_LINK_TYPE, 1,
      c_RI_SECOND_LINK_TYPE, 2,
      99)
  ) rn_part
  from (select column_value full_number, rownum rn from table(v_full_number)) q, ri_sim_card sc, ri_naap naap, ri_phone_number pn
  where 1 = 1
  and sc.sn(+) = q.full_number
  and nvl(sc.deleted(+), p_date + c_dummy_date_shift) > p_date
  and naap.access_point_id(+) = sc.access_point_id
  and p_date between naap.from_date(+) and nvl(naap.to_date(+), p_date)
  and pn.network_address_id(+) = naap.network_address_id
  and nvl(pn.deleted(+), p_date + c_dummy_date_shift) > p_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(pn.network_address_id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true

    )
    where 1 = 1
    and rn_part = 1
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ri_phone_number(p_full_number ct_varchar_s, p_date date) return ct_varchar_s
is
begin
  ------------------------------
  return get_ri_phone_number_i(p_full_number, p_date, TRUE, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ri_phone_number2(p_full_number varchar2, p_date date) return varchar2
is
  v_full_number ct_varchar_s;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_full_number is null, 'p_full_number');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  util_pkg.add_ct_varchar_s_val(v_full_number, p_full_number);
  ------------------------------
  return get_ri_phone_number_i(v_full_number, p_date, FALSE, FALSE)(1);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function iget_ri_phone_number2(p_full_number varchar2, p_date date) return varchar2
is
  v_res varchar2(20);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_full_number is null, 'p_full_number');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select
    msisdn into v_res
    from (

select /*+ driving_site(sc) ordered use_nl(sc, naap, pn) index_asc(sc, UK_SIM_SN) index_asc(naap, I_NETADDRACCPO_ACCESS_POINT_ID) index_asc(pn, PK_PHONE_NUMBER)*/
  pn.international_format msisdn,
  row_number() over (partition by p_full_number
    order by decode(trim(naap.link_type_code),
      c_RI_MAIN_LINK_TYPE, 1,
      c_RI_SECOND_LINK_TYPE, 2,
      99)
  ) rn_part
  from ri_sim_card sc, ri_naap naap, ri_phone_number pn
  where 1 = 1
  and sc.sn = p_full_number
  and nvl(sc.deleted, p_date + c_dummy_date_shift) > p_date
  and naap.access_point_id = sc.access_point_id
  and p_date between naap.from_date and nvl(naap.to_date, p_date)
  and pn.network_address_id = naap.network_address_id
  and nvl(pn.deleted, p_date + c_dummy_date_shift) > p_date

    )
    where 1 = 1
    and rn_part = 1
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_last_dh_i(p_seria_start ct_nvarchar_s, p_seria_end ct_nvarchar_s, p_trim_empty boolean) return ct_number
is
  v_res ct_number;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_main_count number;
  v_range ct_range;
begin
  ------------------------------
  v_main_count := p_seria_start.count;
  util_pkg.XCheck_Cond_Invalid(p_seria_start.count != v_main_count, 'p_seria_start.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_seria_end.count != v_main_count, 'p_seria_end.count != v_main_count');
  ------------------------------
  v_range := make_ct_range1
  (
    p_val1 => p_seria_start,
    p_val2 => p_seria_end
  );
  ------------------------------
  select
    doc_header_id
    bulk collect into v_res
    from (

select /*+ ordered use_nl(dd, dh)
  index_asc(dd, DOC_DETAIL_SS_SE)
  index_asc(dh, PK_DOC_HEADER)
  */
  q.rn,
  dh.id doc_header_id,
  row_number() over (partition by q.rn
    order by dh.create_date desc, dh.id desc
  ) rn_part
  from
    (select val1 seria_start, val2 seria_end, rownum rn from table(v_range)) q,
    doc_detail dd, doc_header dh
  where 1 = 1
  and dd.seria_start(+) = q.seria_start
  and dd.seria_end(+) = q.seria_end
  and dh.id(+) = dd.doc_header_id
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(dh.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true

    )
    where 1 = 1
    and rn_part = 1
    order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_last_dh2_i(p_serial_number ct_nvarchar_s, p_trim_empty boolean) return ct_number
is
begin
  ------------------------------
  return get_last_dh_i(p_serial_number, p_serial_number, p_trim_empty);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_last_dh(p_seria_start ct_nvarchar_s, p_seria_end ct_nvarchar_s) return ct_number
is
begin
  ------------------------------
  return get_last_dh_i(p_seria_start, p_seria_end, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_last_dh2(p_serial_number ct_nvarchar_s) return ct_number
is
begin
  ------------------------------
  return get_last_dh2_i(p_serial_number, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function iget_last_dh(p_seria_start ct_nvarchar_s, p_seria_end ct_nvarchar_s, p_trim_empty number) return ct_number
is
begin
  ------------------------------
  return get_last_dh_i(p_seria_start, p_seria_end, util_pkg.int_to_bool_2val(p_trim_empty));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function iget_last_dh2(p_serial_number ct_nvarchar_s, p_trim_empty number) return ct_number
is
begin
  ------------------------------
  return get_last_dh2_i(p_serial_number, util_pkg.int_to_bool_2val(p_trim_empty));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ct_range(p_coll ct_range) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_ct_range(p_coll in out nocopy ct_range, p_val ot_range)
is
begin
  ------------------------------
  if get_count_ct_range(p_coll) = 0
  then
    return;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    p_coll(v_i) := p_val;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_ct_range(p_coll in out nocopy ct_range, p_size number)
is
  v_dif number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_range();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_range(p_count number, p_val ot_range) return ct_range
is
  v_res ct_range;
begin
  ------------------------------
  resize_ct_range(v_res, p_count);
  fill_ct_range(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_ct_range_val(p_coll in out nocopy ct_range, p_val ot_range)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := ct_range();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_range(p_vals ct_range, p_filter_vals ct_range, p_include_by_filter boolean) return ct_range
is
  v_res ct_range;
  v_include_by_filter number := util_pkg.bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_include_by_filter is null, 'p_include_by_filter');
  ------------------------------
  if get_count_ct_range(p_vals) = 0
  then
    return v_res;
  end if;
  ------------------------------
  if get_count_ct_range(p_filter_vals) = 0
  then
    ------------------------------
    if p_include_by_filter
    then
      return v_res;
    else
      return p_vals;
    end if;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q1.val
    bulk collect into v_res
    from
      (select ot_range(val1, val2, num1, num2, num3, dat1, num4) val, rownum rn from table(p_vals)) q1,
      (select ot_range(val1, val2, num1, num2, num3, dat1, num4) val, rownum rn from table(p_filter_vals)) q2
    where 1 = 1
    and nvl2(q2.val(+), util_pkg.c_false, util_pkg.c_true) = nvl2(q1.val, util_pkg.c_false, util_pkg.c_true)
    and nvl(q2.val(+), c_no_value_not_null_ot_range) = nvl(q1.val, c_no_value_not_null_ot_range)
    and decode(q2.rn, null, util_pkg.c_false, util_pkg.c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_range_1val(p_vals ct_range, p_filter_val ot_range, p_include_by_filter boolean) return ct_range
is
  v_coll ct_range;
begin
  ------------------------------
  add_ct_range_val(v_coll, p_filter_val);
  ------------------------------
  return filter_val_ct_range(p_vals, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_range_num2(p_vals ct_range, p_filter_vals ct_number, p_include_by_filter boolean) return ct_range
is
  v_res ct_range;
  v_include_by_filter number := util_pkg.bool_to_int_2val(p_include_by_filter);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_include_by_filter is null, 'p_include_by_filter');
  ------------------------------
  if get_count_ct_range(p_vals) = 0
  then
    return v_res;
  end if;
  ------------------------------
  if util_pkg.get_count_ct_number(p_filter_vals) = 0
  then
    ------------------------------
    if p_include_by_filter
    then
      return v_res;
    else
      return p_vals;
    end if;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_hash(q1, q2)*/
    q1.val
    bulk collect into v_res
    from
      (select ot_range(val1, val2, num1, num2, num3, dat1, num4) val, rownum rn from table(p_vals)) q1,
      (select column_value val_num2, rownum rn from table(p_filter_vals)) q2
    where 1 = 1
    and nvl2(q2.val_num2(+), util_pkg.c_false, util_pkg.c_true) = nvl2(q1.val.num2, util_pkg.c_false, util_pkg.c_true)
    and nvl(q2.val_num2(+), util_pkg.c_no_value_not_null_number) = nvl(q1.val.num2, util_pkg.c_no_value_not_null_number)
    and decode(q2.rn, null, util_pkg.c_false, util_pkg.c_true) = v_include_by_filter
    order by q1.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_val_ct_range_num2_1val(p_vals ct_range, p_filter_val number, p_include_by_filter boolean) return ct_range
is
  v_coll ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_coll, p_filter_val);
  ------------------------------
  return filter_val_ct_range_num2(p_vals, v_coll, p_include_by_filter);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ot_range
(
    p_val1 nvarchar2,
    p_val2 nvarchar2,
    p_num1 number,
    p_num2 number,
    p_num3 number,
    p_dat1 date,
    p_num4 number
) return ot_range
is
begin
  ------------------------------
  return ot_range
  (
    p_val1,
    p_val2,
    p_num1,
    p_num2,
    p_num3,
    p_dat1,
    p_num4
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ot_range1
(
    p_range_start nvarchar2,
    p_range_end nvarchar2,
    p_model_id number,
    p_id_original number,
    p_quantity number,
    p_valid_until date
) return ot_range
is
begin
  ------------------------------
  return make_ot_range
  (
    p_val1 => p_range_start,
    p_val2 => p_range_end,
    p_num1 => p_model_id,
    p_num2 => p_id_original,
    p_num3 => p_quantity,
    p_dat1 => p_valid_until,
    p_num4 => null
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_range0
(
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s,
    p_num1 ct_number,
    p_num2 ct_number,
    p_num3 ct_number,
    p_dat1 ct_date,
    p_num4 ct_number
) return ct_range
is
  v_res ct_range;
begin
  ------------------------------
select /*+ ordered use_hash(q0, q1, q2, q3, q4, q5, q6)*/
  ot_range
  (
    q0.val1,
    q1.val2,
    q2.num1,
    q3.num2,
    q4.num3,
    q5.dat1,
    q6.num4
  ) val
  bulk collect into v_res
  from
    (select column_value val1, rownum rn from table(p_val1)) q0,
    (select column_value val2, rownum rn from table(p_val2)) q1,
    (select column_value num1, rownum rn from table(p_num1)) q2,
    (select column_value num2, rownum rn from table(p_num2)) q3,
    (select column_value num3, rownum rn from table(p_num3)) q4,
    (select column_value dat1, rownum rn from table(p_dat1)) q5,
    (select column_value num4, rownum rn from table(p_num4)) q6
  where 1 = 1
  and q1.rn(+) = q0.rn
  and q2.rn(+) = q0.rn
  and q3.rn(+) = q0.rn
  and q4.rn(+) = q0.rn
  and q5.rn(+) = q0.rn
  and q6.rn(+) = q0.rn
  order by q0.rn, q1.rn, q2.rn, q3.rn, q4.rn, q5.rn, q6.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_range1
(
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s
) return ct_range
is
begin
  ------------------------------
  return make_ct_range2
  (
    p_val1 => p_val1,
    p_val2 => p_val2,
    p_num1 => null
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_range2
(
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s,
    p_num1 ct_number
) return ct_range
is
begin
  ------------------------------
  return make_ct_range3
  (
    p_val1 => p_val1,
    p_val2 => p_val2,
    p_num1 => p_num1,
    p_num2 => null
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_range3
(
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s,
    p_num1 ct_number,
    p_num2 ct_number
) return ct_range
is
begin
  ------------------------------
  return make_ct_range0
  (
    p_val1 => p_val1,
    p_val2 => p_val2,
    p_num1 => p_num1,
    p_num2 => p_num2,
    p_num3 => null,
    p_dat1 => null,
    p_num4 => null
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_ct_range_with_length
(
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s,
    p_num1 ct_number
) return ct_range
is
  v_length ct_number;
begin
  ------------------------------
  v_length := util_loc_pkg.obtain_length_ct_nvarchar_s(p_val1);
  ------------------------------
  return make_ct_range3
  (
    p_val1 => p_val1,
    p_val2 => p_val2,
    p_num1 => p_num1,
    p_num2 => v_length
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_first_error_pos(p_error_code ct_number) return number
is
begin
  ------------------------------
  return nullif(util_pkg.index_of_ct_number(p_error_code, util_pkg.c_ora_ok, 1, util_pkg.C_FALSE), util_pkg.c_index_not_found);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_first_error(p_error_code ct_number, p_error_message ct_varchar, p_error_code2 out number, p_error_message2 out varchar2)
is
  v_index number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_error_code) != util_pkg.get_count_ct_varchar(p_error_message), 'p_error_code.count != p_error_message.count');
  ------------------------------
  util_pkg.set_ok(p_error_code2, p_error_message2);
  ------------------------------
  v_index := get_first_error_pos(p_error_code);
  ------------------------------
  if v_index is not null
  then
    ------------------------------
    p_error_code2 := p_error_code(v_index);
    p_error_message2 := p_error_message(v_index);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_common_error(p_main_count number, p_error_code number, p_error_message varchar2, p_error_code2 out ct_number, p_error_message2 out ct_varchar, p_allow_nulls boolean := false)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_main_count is null, 'p_main_count');
  util_pkg.XCheck_Cond_Missing(p_allow_nulls is null, 'p_allow_nulls');
  ------------------------------
  util_pkg.XCheck_Cond_Missing(NOT p_allow_nulls and p_error_code is null, 'p_error_code');
  util_pkg.XCheck_Cond_Missing(NOT p_allow_nulls and p_error_message is null, 'p_error_message');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_main_count <= 0, 'p_main_count <= 0');
  ------------------------------
  p_error_code2 := util_pkg.make_ct_number(p_main_count, p_error_code);
  p_error_message2 := util_pkg.make_ct_varchar(p_main_count, util_pkg.cut_err_msg(p_error_message));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_group_error_message
(
    p_problem_id number,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on id=' || util_pkg.number_to_char(p_problem_id)
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_group_error_message2
(
    p_problem_id number,
    p_problem_code varchar2,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on id=' || util_pkg.number_to_char(p_problem_id)
    || util_pkg.c_msg_delim02 || 'code=' || p_problem_code
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_group_error_message3
(
    p_problem_id number,
    p_problem_code varchar2,
    p_problem_name varchar2,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on id=' || util_pkg.number_to_char(p_problem_id)
    || util_pkg.c_msg_delim02 || 'code=' || p_problem_code
    || util_pkg.c_msg_delim02 || 'name=' || p_problem_name
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_group_error_message4
(
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_error_message4val_char
(
    p_problem_value varchar2,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on value=' || p_problem_value
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_error_message4val_char2
(
    p_problem_value1 varchar2,
    p_problem_value2 varchar2,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on value1=' || p_problem_value1
    || util_pkg.c_msg_delim02 || 'value2=' || p_problem_value2
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_error_message4val_num
(
    p_problem_value number,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on value=' || util_pkg.number_to_char(p_problem_value)
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_error_message4val_num2
(
    p_problem_value1 number,
    p_problem_value2 number,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  v_res := util_pkg.cut_err_msg('error on value1=' || util_pkg.number_to_char(p_problem_value1)
    || util_pkg.c_msg_delim02 || 'value2=' || util_pkg.number_to_char(p_problem_value2)
    || util_pkg.c_msg_delim02 || 'index=' || util_pkg.number_to_char(p_problem_index)
    || util_pkg.c_msg_delim02 || util_pkg.number_to_char(p_group_error_code)
    || util_pkg.c_msg_delim02 || p_group_error_message
  );
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_group_error_params
(
    p_problem_id number,
    p_problem_index number,
    p_group_start number,
    p_group_size number,
    p_group_error_code number,
    p_group_error_message varchar2,
    p_error_code ct_number,
    p_error_message ct_varchar,
    p_main_count out number
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_problem_id is null, 'p_problem_id');
  util_pkg.XCheck_Cond_Missing(p_problem_index is null, 'p_problem_index');
  util_pkg.XCheck_Cond_Missing(p_group_start is null, 'p_group_start');
  util_pkg.XCheck_Cond_Missing(p_group_size is null, 'p_group_size');
  util_pkg.XCheck_Cond_Missing(p_group_error_code is null, 'p_group_error_code');
  util_pkg.XCheck_Cond_Missing(p_group_error_message is null, 'p_group_error_message');
  util_pkg.XCheckP_ct_number(p_error_code, 'p_error_code');
  util_pkg.XCheckP_ct_varchar(p_error_message, 'p_error_message');
  ------------------------------
  p_main_count := p_error_code.count;
  util_pkg.XCheck_Cond_Invalid(p_error_code.count != p_main_count, 'p_error_code.count != p_main_count');
  util_pkg.XCheck_Cond_Invalid(p_error_message.count != p_main_count, 'p_error_message.count != p_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_problem_index not between 1 and p_main_count, 'p_problem_index not between 1 and p_main_count');
  util_pkg.XCheck_Cond_Invalid(p_group_start not between 1 and p_main_count, 'p_group_start not between 1 and p_main_count');
  util_pkg.XCheck_Cond_Invalid(p_group_size not between 1 and p_main_count, 'p_group_size not between 1 and p_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_problem_index < p_group_start, 'p_problem_index < p_group_start');
  util_pkg.XCheck_Cond_Invalid(p_problem_index > p_group_start + p_group_size - 1, 'p_problem_index > p_group_start + p_group_size - 1');
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_group_error_for_grp_head
(
    p_problem_id number,
    p_problem_index number,
    p_group_start number,
    p_group_size number,
    p_group_error_code number,
    p_group_error_message varchar2,
    p_error_code in out nocopy ct_number,
    p_error_message in out nocopy ct_varchar
)
is
  v_main_count number;
  v_msg varchar2(4000);
begin
  ------------------------------
  xcheck_group_error_params
  (
    p_problem_id => p_problem_id,
    p_problem_index => p_problem_index,
    p_group_start => p_group_start,
    p_group_size => p_group_size,
    p_group_error_code => p_group_error_code,
    p_group_error_message => p_group_error_message,
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_main_count => v_main_count
  );
  ------------------------------
  v_msg := make_group_error_message
  (
    p_problem_id => p_problem_id,
    p_problem_index => p_problem_index,
    p_group_error_code => p_group_error_code,
    p_group_error_message => p_group_error_message
  );
  ------------------------------
  for v_i in p_group_start..p_problem_index - 1
  loop
    ------------------------------
    p_error_code(v_i) := p_group_error_code;
    p_error_message(v_i) := v_msg;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_group_error_for_all
(
    p_problem_id number,
    p_problem_index number,
    p_group_start number,
    p_group_size number,
    p_group_error_code number,
    p_group_error_message varchar2,
    p_error_code in out nocopy ct_number,
    p_error_message in out nocopy ct_varchar
)
is
  v_main_count number;
  v_msg varchar2(4000);
begin
  ------------------------------
  xcheck_group_error_params
  (
    p_problem_id => p_problem_id,
    p_problem_index => p_problem_index,
    p_group_start => p_group_start,
    p_group_size => p_group_size,
    p_group_error_code => p_group_error_code,
    p_group_error_message => p_group_error_message,
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_main_count => v_main_count
  );
  ------------------------------
  v_msg := make_group_error_message
  (
    p_problem_id => p_problem_id,
    p_problem_index => p_problem_index,
    p_group_error_code => p_group_error_code,
    p_group_error_message => p_group_error_message
  );
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if v_i between p_group_start and p_group_start + p_group_size
    then
      ------------------------------
      p_error_message(v_i) := util_pkg.cut_err_msg(v_msg);
      p_error_code(v_i) := p_group_error_code;
      ------------------------------
    elsif v_i < p_problem_index
    then
      ------------------------------
      p_error_message(v_i) := util_pkg.cut_err_msg(util_pkg.c_msg_rolled_back || util_pkg.c_msg_delim01 || v_msg);
      p_error_code(v_i) := util_pkg.c_ora_rolled_back;
      ------------------------------
    else
      ------------------------------
      p_error_message(v_i) := util_pkg.cut_err_msg(util_pkg.c_msg_not_executed || util_pkg.c_msg_delim01 || v_msg);
      p_error_code(v_i) := util_pkg.c_ora_not_executed;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_error_by_marks0
(
    p_marks ct_number,
    p_pivot ct_number,
    p_error_code number,
    p_error_message varchar2,
    p_mark_value number := util_pkg.c_true,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
)
is
  v_map ct_number;
begin
  ------------------------------
  if 1 = 1
    and not util_pkg.CheckP_ct_number(p_marks)
    and not util_pkg.CheckP_ct_number(p_pivot)
    and not util_pkg.CheckP_ct_number(p_error_codes)
    and not util_pkg.CheckP_ct_varchar(p_error_messages)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  if (1 = 0
    or not util_pkg.CheckP_ct_number(p_marks)
    or not util_pkg.CheckP_ct_number(p_pivot)
    or not util_pkg.CheckP_ct_number(p_error_codes)
    or not util_pkg.CheckP_ct_varchar(p_error_messages)
  )
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter || util_pkg.c_msg_delim01 || 'p_marks, p_pivot, p_error_codes, p_error_messages');
    ------------------------------
  end if;
  ------------------------------
  v_map := util_pkg.get_marked_ct_number(p_pivot, p_marks, true, p_mark_value, null);
  ------------------------------
  if util_pkg.get_count_ct_number(v_map) > 0
  then
    ------------------------------
    util_pkg.set_val_by_pos_ct_number(p_error_codes, p_error_code, v_map);
    util_pkg.set_val_by_pos_ct_varchar(p_error_messages, p_error_message, v_map);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_error_by_marks
(
    p_marks ct_number,
    p_error_code number,
    p_error_message varchar2,
    p_mark_value number := util_pkg.c_true,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
)
is
  v_main_count number;
  v_pivot ct_number;
begin
  ------------------------------
  if 1 = 1
    and not util_pkg.CheckP_ct_number(p_marks)
    and not util_pkg.CheckP_ct_number(p_error_codes)
    and not util_pkg.CheckP_ct_varchar(p_error_messages)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  if (1 = 0
    or (not util_pkg.CheckP_ct_number(p_marks))
    or (not util_pkg.CheckP_ct_number(p_error_codes))
    or (not util_pkg.CheckP_ct_varchar(p_error_messages))
  )
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter || util_pkg.c_msg_delim01 || 'p_marks, p_error_codes, p_error_messages');
    ------------------------------
  end if;
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_marks);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  setup_error_by_marks0(p_marks, v_pivot, p_error_code, p_error_message, p_mark_value, p_error_codes, p_error_messages);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_error_codes_by_marks0
(
    p_marks ct_number,
    p_pivot ct_number,
    p_error_code number,
    p_mark_value number := util_pkg.c_true,
    p_error_codes in out nocopy ct_number
)
is
  v_map ct_number;
begin
  ------------------------------
  if 1 = 1
    and not util_pkg.CheckP_ct_number(p_marks)
    and not util_pkg.CheckP_ct_number(p_pivot)
    and not util_pkg.CheckP_ct_number(p_error_codes)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  if (1 = 0
    or not util_pkg.CheckP_ct_number(p_marks)
    or not util_pkg.CheckP_ct_number(p_pivot)
    or not util_pkg.CheckP_ct_number(p_error_codes)
  )
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter || util_pkg.c_msg_delim01 || 'p_marks, p_pivot, p_error_codes');
    ------------------------------
  end if;
  ------------------------------
  v_map := util_pkg.get_marked_ct_number(p_pivot, p_marks, true, p_mark_value, null);
  ------------------------------
  if util_pkg.get_count_ct_number(v_map) > 0
  then
    ------------------------------
    util_pkg.set_val_by_pos_ct_number(p_error_codes, p_error_code, v_map);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_error_codes_by_marks
(
    p_marks ct_number,
    p_error_code number,
    p_mark_value number := util_pkg.c_true,
    p_error_codes in out nocopy ct_number
)
is
  v_main_count number;
  v_pivot ct_number;
begin
  ------------------------------
  if 1 = 1
    and not util_pkg.CheckP_ct_number(p_marks)
    and not util_pkg.CheckP_ct_number(p_error_codes)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  if (1 = 0
    or (not util_pkg.CheckP_ct_number(p_marks))
    or (not util_pkg.CheckP_ct_number(p_error_codes))
  )
  then
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter || util_pkg.c_msg_delim01 || 'p_marks, p_error_codes');
    ------------------------------
  end if;
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_marks);
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  setup_error_codes_by_marks0(p_marks, v_pivot, p_error_code, p_mark_value, p_error_codes);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xcheck_has_error
(
    p_break_on_error boolean,
    p_error_codes ct_number,
    p_error_messages ct_varchar
)
is
  v_err_idx number;
begin
  ------------------------------
  if p_break_on_error
  then
    ------------------------------
    v_err_idx := get_first_error_pos(p_error_codes);
    ------------------------------
    if v_err_idx is not null
    then
      ------------------------------
      util_pkg.raise_exception(util_pkg.c_ora_x_common, make_group_error_message4(v_err_idx, p_error_codes(v_err_idx), p_error_messages(v_err_idx)));
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function Handle_Wrong_Equipment_Str(p_seria_start varchar2, p_seria_end varchar2, p_equipment_model_id varchar2, p_label varchar2) return varchar2
is
begin
  ------------------------------
  return '(' || p_seria_start || ',' || p_seria_end || ',' || p_equipment_model_id || case when p_label is null then '' else ',' || p_label end || ')' || ',';
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_result_cursor001(p_stock_ids ct_number, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q, z) full(z)*/
  z.code, z.name, q.id
  from
    (select column_value id, rownum rn from table(p_stock_ids)) q,
    stock z
  where 1 = 1
  and z.id(+) = q.id
  and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  --order by q.rn
  order by q.id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor002(p_group_ids ct_number, p_result out sys_refcursor)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q, z) full(z)*/
  q.id, z.name
  from
    (select column_value id, rownum rn from table(p_group_ids)) q,
    stock_group z
  where 1 = 1
  and z.id(+) = q.id
  --and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor003(p_stock_perms ct_node, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q, z) full(z)*/
  z.stock_group_id, q.id, z.name, z.code, q.val permission_mask, z.deleted
  from
    (select id, val, rownum rn from table(p_stock_perms)) q,
    stock z
  where 1 = 1
  and z.id(+) = q.id
  and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor004(p_stock_ids ct_number, p_stock_perms ct_number, p_user_id number, p_date date, p_trim_empty boolean, p_result out sys_refcursor)
is
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_user_name users.user_name%type;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  v_user_name := xget_user_name(p_user_id);
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q0, q1, z) full(z)*/
  z.stock_group_id, q0.id, z.name, z.code, q1.val permission_mask, v_user_name user_name
  from
    (select column_value id, rownum rn from table(p_stock_ids)) q0,
    (select column_value val, rownum rn from table(p_stock_perms)) q1,
    stock z
  where 1 = 1
  and q1.rn(+) = q0.rn
  and z.id(+) = q0.id
  and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(q1.val, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q0.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor005(p_stock_id number, p_stock_perm number, p_user_id number, p_result out sys_refcursor)
is
  v_stock_ids ct_number;
  v_stock_perms ct_number;
begin
  ------------------------------
  util_pkg.add_ct_number_val(v_stock_ids, p_stock_id);
  util_pkg.add_ct_number_val(v_stock_perms, p_stock_perm);
  ------------------------------
  get_result_cursor004(v_stock_ids, v_stock_perms, p_user_id, sysdate, true, p_result);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor007(p_stock_codes ct_nvarchar_s, p_stock_perms ct_number, p_date date, p_trim_empty boolean, p_result out sys_refcursor)
is
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q0, q1, z) full(z)*/
  q0.code stock_code,
  z.name stock_name,
  decode(q1.val, null, null, check_permission(q1.val, c_perm_change)) permission_modify,
  decode(q1.val, null, null, check_permission(q1.val, c_perm_view)) permission_read
  from
    (select column_value code, rownum rn from table(p_stock_codes)) q0,
    (select column_value val, rownum rn from table(p_stock_perms)) q1,
    stock z
  where 1 = 1
  and q1.rn(+) = q0.rn
  and z.code(+) = q0.code
  and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(q1.val, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true --!_!q1.val - NOT NULL
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(z.code, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q0.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor008(p_stock_ids ct_number, p_date date, p_result out sys_refcursor)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q, z) full(z)*/
  DISTINCT z.stock_owner
  from
    (select column_value id, rownum rn from table(p_stock_ids)) q,
    stock z
  where 1 = 1
  and z.id(+) = q.id
  and nvl(z.deleted(+), p_date + c_dummy_date_shift) > p_date
  --order by q.rn
  order by z.stock_owner
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
