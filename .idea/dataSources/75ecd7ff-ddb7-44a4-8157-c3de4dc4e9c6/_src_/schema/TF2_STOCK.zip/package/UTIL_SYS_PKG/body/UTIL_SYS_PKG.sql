CREATE package body UTIL_SYS_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_str_tail(p_val varchar2, p_length integer) return varchar2
is
  v_length number;
  v_val varchar2(4000);
begin
  ------------------------------
  --!_! util_pkg.XCheck_Cond_Missing(p_val is null, 'p_val');
  util_pkg.XCheck_Cond_Missing(p_length is null, 'p_length');
  util_pkg.XCheck_Cond_Invalid(p_length <= 0, 'p_length');
  ------------------------------
  if p_val is null
  then
    return v_val;
  end if;
  ------------------------------
  v_length := util_pkg.str_length(p_val);
  ------------------------------
  if v_length <= p_length
  then
    return p_val; --!_!
  end if;
  ------------------------------
  v_val := substr(p_val, - p_length);
  ------------------------------
  return v_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_savepoint_enumerator return varchar2
is
  v_seq number;
  v_val varchar2(28);
begin
  ------------------------------
  v_seq := sq_savepoint_name.nextval;
  ------------------------------
  v_val := get_str_tail(util_pkg.number_to_char(v_seq), c_max_sp_enumerator_length);
  ------------------------------
  return v_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_unique_savepoint_name return varchar2
is
  v_savepoint_name varchar2(30);
begin
  ------------------------------
  v_savepoint_name := c_savepoint_name_prefix || get_savepoint_enumerator;
  ------------------------------
  return v_savepoint_name;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_savepoint return varchar2
is
  v_savepoint_name varchar2(30);
begin
  ------------------------------
  v_savepoint_name := make_unique_savepoint_name;
  ------------------------------
  dbms_transaction.savepoint(v_savepoint_name);
  ------------------------------
  return v_savepoint_name;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure rollback_savepoint(p_savepoint_name varchar2)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_savepoint_name is null, 'p_savepoint_name');
  ------------------------------
  dbms_transaction.rollback_savepoint(p_savepoint_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
