CREATE PACKAGE stock_management
AS
/****************************************************************************
<name>          package_
<author>        Petar Ulic
<version>       1.0   04.12.2003 basic Oracle implementation
<Description>   Package contains functions and procedures for stock and stock
                groups management in Stock system
<Application>   Stock Management
-- Purpose : Предназначен для работы с STOCK-ом из внешних подсистем
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ------------------------------------------
-- Petr Skripnik   09.11.2006  Изменен
-- Petr Skripnik   08.06.2007  Удалет тип aadocumentno
****************************************************************************/
   TYPE t_cursor IS REF CURSOR;

   TYPE aaid IS TABLE OF stock_state.ID%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aastock IS TABLE OF stock_state.stock_id%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aaeqmodelid IS TABLE OF stock_state.equipment_model_id%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aastartseries IS TABLE OF stock_state.seria_start%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aaendseries IS TABLE OF stock_state.seria_end%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aaonstock IS TABLE OF stock_state.quantity_onstock%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aareserved IS TABLE OF stock_state.quantity_reserved%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aaannounced IS TABLE OF stock_state.quantity_announced%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aadocheaderid IS TABLE OF stock_state.doc_header_id%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aacreatedate IS TABLE OF stock_state.create_date%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aastatus IS TABLE OF stock_state.status%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aaequipmentbatchid IS TABLE OF stock_state.equipment_batch_id%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE t_varchar IS TABLE OF VARCHAR2 (100)
      INDEX BY PLS_INTEGER;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_is_unused (p_id NUMBER, p_handle_tran CHAR := 'Y', p_error_code OUT NUMBER);

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_group__ins (
      p_sa                     NVARCHAR2,
      p_stock_group_id         NUMBER,
      p_name                   NVARCHAR2,
      p_description            NVARCHAR2,
      p_handle_tran            CHAR := 'Y',
      p_error_code       OUT   NUMBER,
      p_id               OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_group__upd (
      p_sa                  NVARCHAR2,
      p_id_old              NUMBER,
      p_id                  NUMBER,
      p_name                NVARCHAR2,
      p_description         NVARCHAR2,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_group__del (
      p_sa                  NVARCHAR2,
      p_id                  NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_group__get (p_id NUMBER, p_stock_group_rec OUT t_cursor, p_error_code OUT NUMBER);

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock__ins_ext (
      p_sa                     NVARCHAR2,
      p_id               OUT   NUMBER,
      p_stock_group_id         NUMBER,
      p_name                   NVARCHAR2,
      p_tel                    NVARCHAR2,
      p_fax                    NVARCHAR2,
      p_email                  NVARCHAR2,
      p_address                NVARCHAR2,
      p_zip                    NVARCHAR2,
      p_description            NVARCHAR2,
      p_code                   NVARCHAR2,
      p_crm_unique             NVARCHAR2,
      p_stock_type             NUMBER,
      p_stock_owner            NVARCHAR2,
      p_stock_manager          NVARCHAR2,
      p_doc_valid_days         NUMBER,
      p_handle_tran            CHAR := 'Y',
      p_error_code       OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock__upd_ext (
      p_sa                     NVARCHAR2,
      p_id_old                 NVARCHAR2,
      p_id                     NVARCHAR2,
      p_stock_group_id         NUMBER,
      p_name                   NVARCHAR2,
      p_tel                    NVARCHAR2,
      p_fax                    NVARCHAR2,
      p_email                  NVARCHAR2,
      p_address                NVARCHAR2,
      p_zip                    NVARCHAR2,
      p_description            NVARCHAR2,
      p_inherited              NUMBER,
      p_crm_unique             NVARCHAR2,
      p_stock_type             NUMBER,
      p_stock_owner            NVARCHAR2,
      p_stock_manager          NVARCHAR2,
      p_doc_valid_days         NUMBER,
      p_handle_tran            CHAR := 'Y',
      p_error_code       OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock__set_constants (
      p_stock_id                 NUMBER,
      p_max_series_qty           NUMBER,
      p_alert_series_qty         NUMBER,
      p_validation_date          NUMBER,
      p_fiscale_date             DATE,
      p_handle_tran              CHAR := 'Y',
      p_error_code         OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock__del (
      p_sa                  NVARCHAR2,
      p_id                  NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock__rest (
      p_sa                  NVARCHAR2,
      p_id                  NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock__get (p_id NUMBER, p_stock_rec OUT t_cursor, p_error_code OUT NUMBER);

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock__get_tree (p_stock_tree_rec OUT t_cursor, p_error_code OUT NUMBER);

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock__get_code (
      p_id                 NUMBER,
      p_code               NVARCHAR2,
      p_stock_rec    OUT   t_cursor,
      p_error_code   OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE distribution_template__ins (
      p_home_stock_id             NUMBER,
      p_distribution_name         NVARCHAR2,
      p_description               NVARCHAR2,
      p_handle_tran               CHAR := 'Y',
      p_error_code          OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE distribution_template__del (
      p_id                    NUMBER,
      p_home_stock_id         NUMBER,
      p_handle_tran           CHAR := 'Y',
      p_error_code      OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE distribution_template__get (
      p_home_stock_id                     NUMBER,
      p_distribution_template_rec   OUT   t_cursor,
      p_error_code                  OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE dist_template_detail__ins (
      p_distribution_id              NUMBER,
      p_destination_stock_id         NUMBER,
      p_percentage                   NUMBER,
      p_quantity                     NUMBER,
      p_handle_tran                  CHAR := 'Y',
      p_error_code             OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE dist_template_detail__del (
      p_id                      NUMBER,
      p_distribution_id         NUMBER,
      p_handle_tran             CHAR := 'Y',
      p_error_code        OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE dist_template_detail__get (
      p_distribution_id                  NUMBER,
      p_dist_detail_template_rec   OUT   t_cursor,
      p_error_code                 OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_type__get (p_stock_type_rec OUT t_cursor, p_error_code OUT NUMBER);

--------------------------------------------------------------------------------
-- Author  : gsavic
-- Created : 25.1.2006
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_state__get_for_equpm (
      p_stock_id                 NUMBER,
      p_stock_state3_rec   OUT   t_cursor,
      p_error_code         OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : gsavic
-- Created : 25.1.2006
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_state__get_for_st_eq2 (
      p_seria_start               VARCHAR2,
      p_seria_end                 VARCHAR2,
      p_stock_id                  NUMBER,
      p_equipment_type_id         NUMBER,
      p_equipment_code            VARCHAR2,
      p_quantity                  NUMBER,
      p_status                    NUMBER,
      p_stock_state3_rec    OUT   t_cursor,
      p_error_code          OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_state__bulk_ins (
      p_id                         aaid,
      p_stock_id                   aastock,
      p_equipment_model_id         aaeqmodelid,
      p_seria_start                aastartseries,
      p_seria_end                  aaendseries,
      p_quantity_onstock           aaonstock,
      p_quantity_reserved          aareserved,
      p_quantity_announced         aaannounced,
      p_doc_header_id              aadocheaderid,
      p_create_date                aacreatedate,
      p_status                     aastatus,
      p_equipment_batch_id         aaequipmentbatchid,
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed :
--   Skripnik Petr 14.10.2006
--   Skripnik Petr 06.12.2006
--   Skripnik Petr 17.04.2007 Удалены колонки MIN_VALUE и ALARM_ID
--   Skripnik Petr 18.06.2007 Удалены колонки document_no
--   Skripnik Petr 27.04.2007 Добавил FOR delstockrows IN (...FOR UPDATE NOWAIT);
--   Anoev Maxim 08.05.2007 Удалил AND reserved IS NULL;
-- Purpose : Синхронизация таблицы STOCK_STATE
--------------------------------------------------------------------------------
   PROCEDURE stock_state__bulk_ins_2 (
      p_id                         aaid,
      p_stock_id                   aastock,
      p_equipment_model_id         aaeqmodelid,
      p_seria_start                t_varchar,
      p_seria_end                  t_varchar,
      p_quantity_onstock           aaonstock,
      p_quantity_reserved          aareserved,
      p_quantity_announced         aaannounced,
      p_doc_header_id              aadocheaderid,
      p_create_date                aacreatedate,
      p_status                     aastatus,
      p_equipment_batch_id         aaequipmentbatchid,   -- в массиве значение "-1" есть NULL
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : Eugene Solovyov
-- Created : 8.6.2010
-- Editor  :
-- Changed :
-- Purpose : Синхронизация таблицы STOCK_STATE для документа разбивающего диапазон на индивидуальные ренжи
--------------------------------------------------------------------------------
   PROCEDURE stock_state__split_card_range(
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                varchar,
      p_seria_end                  varchar,
      p_single_item                t_varchar,
      p_length                     NUMBER,
      p_create_date                DATE,
      p_status                     NUMBER,
      p_equipment_batch_id         NUMBER,   -- в массиве значение "-1" есть NULL
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

END;
/
