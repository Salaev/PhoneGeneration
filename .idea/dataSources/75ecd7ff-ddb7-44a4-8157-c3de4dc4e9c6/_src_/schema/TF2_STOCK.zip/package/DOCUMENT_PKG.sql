CREATE package document_pkg is

----------------------------------!---------------------------------------------
  type t_doc_locker is table of doc_locker%rowtype;

----------------------------------!---------------------------------------------
  c_crm                          constant varchar2(200) := 'CRM:';
  c_exclusive_lock               constant number := 1;
  c_shared_lock                  constant number := 0;

  c_doc_header_description_size  constant number := 255;

  c_def_dd_id                    constant doc_detail.id%type := null;
  c_def_dd_product               constant doc_detail.product%type := 0;
  c_def_dd_unit                  constant doc_detail.unit%type := null;

  c_def_stock_doc_valid_days     constant number := -1;

----------------------------------!---------------------------------------------
  c_date_format_short_NOT_USE    constant varchar2(30) := 'dd.mm.yyyy';
  c_date_format_full_NOT_USE     constant varchar2(30) := 'dd.mm.yyyy hh24:mi:ss';

----------------------------------!---------------------------------------------
  v_use_doc_header_trigger       number := util_pkg.c_true;
  v_use_doc_detail_trigger       number := util_pkg.c_true;

----------------------------------!---------------------------------------------
  c_opt_doc_locker_exp_per_sec   constant nvarchar2(50) := 'DOC_LOCKER_EXPIRE_PERIOD';
  c_opt_doc_locker_wait_sec      constant nvarchar2(50) := 'DOC_LOCKER_WAIT_SEC';
  c_opt_max_valid_until          constant nvarchar2(50) := 'MAX_VALID_UNTIL';

----------------------------------!---------------------------------------------
  c_def_doc_locker_exp_per_sec   constant number := 1800;
  c_def_doc_locker_wait_sec      constant number := 60;
  c_def_max_valid_until          constant date := to_date('31.12.9999', c_date_format_short_NOT_USE);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function get_count_t_doc_locker(p_coll t_doc_locker) return number;

----------------------------------!---------------------------------------------
  function GS_doc_locker_exp_per_sec return number;
  function GS_doc_locker_wait_sec return number;
  function GS_max_valid_until return date;

----------------------------------!---------------------------------------------
  procedure Raise_Document_NotFound(p_label varchar2);
  procedure XCheck_Document_NotFound(p_raise_condition boolean, p_label varchar2);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure release_expired_doc_locker;

  function create_exclusive_doc_locker(p_doc_header_id number, p_doc_locker_group number default null) return doc_locker_groups%rowtype;
  function create_shared_doc_locker(p_doc_header_id number, p_doc_locker_group number default null) return doc_locker_groups%rowtype;
  function shared_to_exclusive_doc_locker(p_doc_locker doc_locker_groups%rowtype) return doc_locker_groups%rowtype;
  function check_doc_locker_group(p_doc_locker_group_id number) return number;
  procedure close_group_doc_locker(p_doc_locker_group_id number);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function get_doc_header_by_id(p_id number) return doc_header%rowtype;
  function get_doc_header_by_doc_no(p_doc_no nvarchar2) return doc_header%rowtype;
  function get_doc_header_by_vendor_doc(p_stock_in_id number, p_vendor_doc nvarchar2) return doc_header%rowtype;

  function xget_doc_header_by_id(p_id number) return doc_header%rowtype;
  function xget_doc_header_by_doc_no(p_doc_no nvarchar2) return doc_header%rowtype;
  function xget_doc_header_by_doc_no2(p_doc_no nvarchar2, p_doc_status_id number) return doc_header%rowtype;
  function xget_doc_header_by_vendor_doc(p_stock_in_id number, p_vendor_doc nvarchar2) return doc_header%rowtype;

----------------------------------!---------------------------------------------
  function Get_Stock_Doc_Valid_Days(p_stock_id number, p_date date) return date;

----------------------------------!---------------------------------------------
  procedure Get_Operation_Equipment(p_doc_header_id number, p_cur out sys_refcursor);
  procedure Get_Total_Equipment(p_doc_header_id number, p_total_equipment out number);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function get_new_docnum(p_stock_id nvarchar2, p_doc_type_id number) return nvarchar2;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure setup_doc_header(p_rec in out nocopy doc_header%rowtype, p_force boolean);

  procedure setup_smart_doc_header
  (
    p_rec in out nocopy doc_header%rowtype,
    p_doc_type_id doc_header.doc_type_id%type,
    p_doc_date doc_header.doc_date%type,
    p_status_id doc_header.status_id%type,
    p_stock_out_id doc_header.stock_out_id%type,
    p_stock_in_id doc_header.stock_in_id%type,
    p_user_id doc_header.user_id2%type,
    p_last_user_id doc_header.last_user_id2%type,
    p_vendor_doc doc_header.vendor_doc%type,
    p_description doc_header.description%type,
    p_user_comment doc_header.user_comment%type,
    p_vendor_id doc_header.vendor_id%type
  );

  procedure setup_desc_for_doc_header(p_rec in out nocopy doc_header%rowtype);
  procedure setup_for_crm_doc_header(p_rec in out nocopy doc_header%rowtype);
  procedure setup_for_gui_doc_header(p_rec in out nocopy doc_header%rowtype);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure i_Insert_Doc_Header(p_doc_header doc_header%rowtype);
  procedure Update_Doc_Header(p_doc_header doc_header%rowtype);

----------------------------------!---------------------------------------------
  procedure i_Update_Doc_Header_State
  (
    p_doc_header_id number,
    p_status_id number,
    p_last_user_id number,
    p_doc_date date
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure i_Clear_tt_Doc_Detail_table;

  procedure i_Prepare_Doc_Detail_SRC(p_doc_header doc_header%rowtype);
  procedure i_Prepare_Doc_Detail_DST(p_doc_header doc_header%rowtype);
  procedure i_Prepare_Doc_Details(p_doc_header doc_header%rowtype);

----------------------------------!---------------------------------------------
  procedure i_Insert_Serial_Equipment;
  procedure i_Insert_Non_Serial_Equipment;
  procedure i_Remove_Serial_Equipment;
  procedure i_Remove_Non_Serial_Equipment;

----------------------------------!---------------------------------------------
  procedure i_Insert_Doc_Details(p_doc_header doc_header%rowtype);
  procedure i_Remove_Doc_Details(p_doc_header doc_header%rowtype);

----------------------------------!---------------------------------------------
  procedure Retrieve_Doc_Equipment(p_doc_header_id number);

----------------------------------!---------------------------------------------
  procedure Create_Doc_From_SSEXT
  (
    p_rec doc_header%rowtype
  );

  procedure Update_Doc_From_SSEXT
  (
    p_doc_header_id number,
    p_last_user_id number,
    p_remove_eq boolean
  );

  procedure Update_Doc_State
  (
    p_doc_header_id number,
    p_status_id number,
    p_last_user_id number,
    p_doc_date date
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
