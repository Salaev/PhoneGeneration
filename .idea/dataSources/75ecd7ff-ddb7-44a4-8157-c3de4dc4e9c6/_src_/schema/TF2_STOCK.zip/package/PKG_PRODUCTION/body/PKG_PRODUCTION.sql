CREATE package body PKG_PRODUCTION is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function cast_t_varchar2ct_nvarchar_s(p_coll pkg_common.t_varchar) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  if (p_coll is null or p_coll.count = 0)
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in 1..p_coll.count
  loop
    ------------------------------
    util_pkg.add_ct_nvarchar_s_val(v_res, util_pkg.char_to_nchar(p_coll(v_i)));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_t_varchar2ct_nvarchar_s2(p_coll t_varchar) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  if (p_coll is null or p_coll.count = 0)
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in 1..p_coll.count
  loop
    ------------------------------
    util_pkg.add_ct_nvarchar_s_val(v_res, util_pkg.char_to_nchar(p_coll(v_i)));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_t_ri_icc_id2ct_nvarchar_s(p_coll t_ri_icc_id) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  if (p_coll is null or p_coll.count = 0)
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in 1..p_coll.count
  loop
    ------------------------------
    util_pkg.add_ct_nvarchar_s_val(v_res, util_pkg.char_to_nchar(p_coll(v_i)));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_nvarchar_s2t_imsi(p_coll ct_nvarchar_s) return RI_RSIG_SIM_CARD#PCK.t_imsi
is
  v_count number;
  v_res RI_RSIG_SIM_CARD#PCK.t_imsi;
begin
  ------------------------------
  v_count := util_pkg.get_count_ct_nvarchar_s(p_coll);
  ------------------------------
  if v_count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in 1..v_count
  loop
    ------------------------------
    v_res(v_i) := util_pkg.nchar_to_char(p_coll(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure SetOperationEquipment
(
    p_document_number varchar2,
    p_host_id number,
    p_user_name varchar2,
    p_quantity number,
    p_seria_start varchar2,
    p_seria_end varchar2,
    p_removing_sims pkg_common.t_varchar,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_error_message varchar2(4000);
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
     v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  set_operation_equipment_i (
    p_document_number => p_document_number,
    p_host_id => p_host_id,
    p_user_id => util_stock.xget_user_id(p_user_name),
    p_quantity => p_quantity,
    p_seria_start => p_seria_start,
    p_seria_end => p_seria_end,
    p_removing_sims => cast_t_varchar2ct_nvarchar_s(p_removing_sims),
    p_error_code => p_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_exception(p_error_code, v_error_message);
  end if;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
     commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_operation_equipment_i
(
    p_document_number varchar2,
    p_host_id number,
    p_user_id number,
    p_quantity number,
    p_seria_start varchar2,
    p_seria_end varchar2,
    p_removing_sims ct_nvarchar_s,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_doc_header doc_header%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.xcheck_cond_missing(p_document_number is null, 'p_document_number');
  util_pkg.xcheck_cond_missing(p_host_id is not null, 'p_host_id');
  util_pkg.xcheck_cond_missing(p_host_id is not null, 'p_host_id');
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  v_doc_header := document_pkg.xget_doc_header_by_doc_no2(p_document_number, util_stock.c_docstat_open);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_doc_header.doc_type_id <> util_stock.c_Doc_Type_Shippment, 'doc_type_id');
  util_pkg.XCheck_Cond_Invalid(v_doc_header.stock_in_id <> util_stock.c_dummy_stock_id, 'stock_id_in');
  util_pkg.XCheck_Cond_Invalid(v_doc_header.status_id <> util_stock.c_docstat_open, 'doc_status');
  ------------------------------
  if NOT util_stock.is_avail_stock(p_user_id, util_stock.c_perm_change, v_doc_header.stock_out_id, sysdate)
  then
    raise_application_error(c_ORA_ACCESS_DENIED, c_em_ACCESS_DENIED);
  end if;
  ------------------------------
  add_operation_equipment_i
  (
    p_document_number => v_doc_header.doc_no,
    p_host_id => p_host_id,
    p_user_id => p_user_id,
    p_quantity => p_quantity,
    p_seria_start => p_seria_start,
    p_seria_end => p_seria_end,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_exception(p_error_code, p_error_message);
  end if;
  ------------------------------
  remove_operation_equipment_i
  (
    p_document_number => v_doc_header.doc_no,
    p_user_id => p_user_id,
    p_removing_sims => p_removing_sims,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_exception(p_error_code, p_error_message);
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
end ;

----------------------------------!---------------------------------------------
procedure add_operation_equipment_i
(
    p_document_number varchar2,
    p_host_id number,
    p_user_id number,
    p_quantity number,
    p_seria_start varchar2,
    p_seria_end varchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  util_pkg.xcheck_cond_missing(p_document_number is null, 'p_document_number');
  util_pkg.xcheck_cond_missing(p_host_id is null and p_seria_start is not null, 'p_host_id');
  util_pkg.xcheck_cond_missing(p_user_id is null, 'p_user_id');
  ------------------------------
  --!_! Not Implemented
  if p_host_id is not null
  or p_quantity is not null
  or p_seria_start is not null
  or p_seria_end is not null
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_not_implemented_code, util_loc_pkg.c_msg_not_implemented_code);
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end ;

----------------------------------!---------------------------------------------
procedure remove_operation_equipment_i
(
    p_document_number varchar2,
    p_user_id number,
    p_removing_sims ct_nvarchar_s,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
  v_sims ct_nvarchar_s;
  v_models ct_model;
  v_models_id ct_number;
  v_is_addition ct_number;
  v_rsim_count number;
begin
  ------------------------------
  util_pkg.xcheck_cond_missing(p_document_number is null, 'p_document_number');
  util_pkg.xcheck_cond_missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_rsim_count := util_pkg.get_count_ct_nvarchar_s(p_removing_sims);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  if v_rsim_count > 0
  then
    ------------------------------
    v_sims := util_stock.make_sn_from_full_number(p_removing_sims);
    v_models_id := util_stock.get_ss_model_id(v_sims, FALSE);
    v_models := util_stock.get_ct_model2_exact(v_models_id, v_date);
    ------------------------------
    v_is_addition := util_pkg.make_ct_number(v_rsim_count, util_pkg.c_false);
    ------------------------------
    api_stock_i_pkg.Set_Operation_Equipment2
    (
      p_document_number => p_document_number,
      p_seria_starts => v_sims,
      p_seria_ends => v_sims,
      p_models => v_models,
      p_is_addition => v_is_addition,
      p_valid_until => null,
      p_user_id => p_user_id,
      p_break_on_error => TRUE,
      p_error_code => p_error_code,
      p_error_message => p_error_message
    );
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end ;

----------------------------------!---------------------------------------------
procedure FinishOperation
(
    p_document_number varchar2,
    p_user_id varchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
)
is
  v_sp_name varchar2(30);
  v_error_message varchar2(4000);
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
     v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
 api_stock_i_pkg.Finalize_Document
  (
      p_document_number => util_pkg.nchar_to_char(p_document_number),
      p_user_id => util_stock.xget_user_id(p_user_id),
      p_error_code => p_error_code,
      p_error_message => v_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_exception(p_error_code, v_error_message);
  end if;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
     commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prod_check_sim_cards_i
(
    p_sn ct_nvarchar_s,
    p_host_id number,
    p_net_op_id number,
    p_stock_id number,
    p_must_be_on_stock boolean,
    p_iccid out ct_nvarchar_s,
    p_imsi out ct_nvarchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_main_count number;
  v_ss_id ct_number;
  v_stock_id ct_number;
  v_eq_model_id ct_number;
  v_pivot ct_number;
  v_mark_err ct_number;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_nvarchar_s(p_sn, 'p_sn');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_sn);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_sn) != v_main_count, 'p_sn.count != v_main_count');
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  LEGACY_PKG.prod_check_sim_list
  (
    p_host_id => p_host_id,
    p_net_op_id => p_net_op_id,
    p_iccid_without_control_digit => p_sn,
    p_iccid => p_iccid,
    p_imsi => p_imsi,
    p_error_code => p_error_codes,
    p_error_message => p_error_messages
  );
  ------------------------------
  v_mark_err := util_pkg.mark_val_ct_number(p_error_codes, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  ------------------------------
  search_pkg.seek_active_single_eq2
  (
    p_serial_number => p_sn,
    p_ss_id => v_ss_id,
    p_stock_id => v_stock_id,
    p_eq_model_id => v_eq_model_id
  );
  ------------------------------
  if p_must_be_on_stock
  then
    ------------------------------
    v_mark_err := util_pkg.mark_val_ct_number(v_stock_id, null, util_pkg.c_true, util_pkg.c_false);
    util_stock.setup_error_by_marks0(v_mark_err, v_pivot, legacy_pkg.clg_ora_find_sim_not_exist, legacy_pkg.clg_msg_find_sim_not_exist, util_pkg.c_true, p_error_codes, p_error_messages);
    v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
    ------------------------------
    v_mark_err := util_pkg.mark_val_ct_number(v_stock_id, p_stock_id, util_pkg.c_false, util_pkg.c_true);
    util_stock.setup_error_by_marks0(v_mark_err, v_pivot, legacy_pkg.clg_ora_find_sim_not_on_stock, legacy_pkg.clg_msg_find_sim_not_on_stock, util_pkg.c_true, p_error_codes, p_error_messages);
    --v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
    ------------------------------
  else
    ------------------------------
    v_mark_err := util_pkg.mark_val_ct_number(v_stock_id, null, util_pkg.c_false, util_pkg.c_true);
    util_stock.setup_error_by_marks0(v_mark_err, v_pivot, legacy_pkg.clg_ora_duplicated_equipment, legacy_pkg.clg_msg_duplicated_equipment, util_pkg.c_true, p_error_codes, p_error_messages);
    --v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prod_check_sim_cards_list_i
(
    p_sn ct_nvarchar_s,
    p_network_operator_code varchar2,
    p_host_id number,
    p_stock_code varchar2,
    p_document_number in out varchar2,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2,
    p_iccid out ct_nvarchar_s,
    p_imsi out ct_nvarchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_date date := sysdate;
  v_stock_id number;
  v_network_operator_id number;
  v_sn2 ct_nvarchar_s;
  v_pivot ct_number;
  v_mark_err ct_number;
  v_pivot2 ct_number;
  v_models_id ct_number;
  v_models ct_model;
  v_is_addition ct_number;
  v_error_codes2 ct_number;
  v_error_messages2 ct_varchar;
  v_count2 number;
  v_doc_header doc_header%rowtype;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  util_pkg.xcheck_cond_missing(p_stock_code is null, 'p_stock_code');
  ------------------------------
  util_pkg.XCheckP_FSU_ct_nvarchar_s(p_sn, 'p_sn');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_sn);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_sn) != v_main_count, 'p_sn.count != v_main_count');
  ------------------------------
  v_pivot := util_pkg.make_pivot(v_main_count);
  ------------------------------
  v_stock_id := util_stock.get_stock_id2(p_stock_code, sysdate);
  if v_stock_id is null
  then
    util_pkg.raise_exception(c_ORA_STOCK_NOT_EXISTS, c_em_STOCK_OUT_NOT_EXISTS);
  end if;
  ------------------------------
  if NOT util_stock.is_avail_stock(p_user_id, util_stock.c_perm_change, v_stock_id, sysdate)
  then
    util_pkg.raise_exception(c_ORA_ACCESS_DENIED, c_em_ACCESS_DENIED);
  end if;
  ------------------------------
  v_network_operator_id := RI_PERSISTENT_INTERFACE_PKG.get_network_operator_id2(p_network_operator_code, v_date);
  ------------------------------
  IF v_network_operator_id is null
  THEN
    util_pkg.raise_exception(c_ORA_NET_OP_NOT_EXIST, c_em_NET_OP_NOT_EXIST);
  END IF;
  ------------------------------
  prod_check_sim_cards_i
  (
    p_sn => p_sn,
    p_host_id => p_host_id,
    p_net_op_id => v_network_operator_id,
    p_stock_id => v_stock_id,
    p_must_be_on_stock => TRUE,
    p_iccid => p_iccid,
    p_imsi => p_imsi,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
  v_mark_err := util_pkg.mark_val_ct_number(p_error_codes, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
  v_pivot := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, FALSE, util_pkg.c_false, NULL);
  v_pivot2 := util_pkg.get_marked_ct_number(v_pivot, v_mark_err, TRUE, util_pkg.c_false, NULL);
  v_count2 := util_pkg.get_count_ct_number(v_pivot2);
  if v_count2 > 0
  then
    ------------------------------
    v_sn2 := util_pkg.get_by_pos_ct_nvarchar_s(p_sn, v_pivot2, FALSE);
    ------------------------------
    if p_document_number is null
    then
      ------------------------------
      api_stock_i_pkg.Create_Empty_Document
      (
        p_doc_type_id => util_stock.c_Doc_Type_Shippment,
        p_stock_id_out => v_stock_id,
        p_stock_id_in => util_stock.c_dummy_stock_id,
        p_comment => null,
        p_user_id => p_user_id,
        p_document_number => p_document_number,
        p_error_code => p_error_code,
        p_error_message => p_error_message
      );
      ------------------------------
      if util_pkg.is_error(p_error_code)
      then
        util_pkg.raise_label_exception('api_stock_i_pkg.Create_Empty_Document', p_error_code, p_error_message);
      end if;
      ------------------------------
    else
      ------------------------------
      v_doc_header := document_pkg.xget_doc_header_by_doc_no(p_document_number);
      ------------------------------
      equipment_pkg.XCheck_Document_Header
      (
          p_doc_header => v_doc_header,
          p_doc_type_id => util_stock.c_Doc_Type_Shippment,
          p_stock_id_out => v_stock_id,
          p_stock_id_in => util_stock.c_dummy_stock_id,
          p_doc_status => util_stock.c_docstat_open
      );
      ------------------------------
    end if;
    ------------------------------
    v_models_id := util_stock.get_ss_model_id(v_sn2, FALSE);
    v_models := util_stock.get_ct_model2_exact(v_models_id, v_date);
    ------------------------------
    v_is_addition := util_pkg.make_ct_number(v_count2, util_pkg.c_true);
    ------------------------------
    api_stock_i_pkg.Set_Operation_Equipment3
    (
      p_document_number => p_document_number,
      p_seria_starts => v_sn2,
      p_seria_ends => v_sn2,
      p_models => v_models,
      p_is_addition => v_is_addition,
      p_valid_until =>  null,
      p_user_id => p_user_id,
      p_break_on_error => FALSE,
      p_error_codes => v_error_codes2,
      p_error_messages => v_error_messages2,
      p_error_code => p_error_code,
      p_error_message => p_error_message
    );
    ------------------------------
    if util_pkg.is_error(p_error_code)
    then
      util_pkg.raise_label_exception('api_stock_i_pkg.Set_Operation_Equipment3', p_error_code, p_error_message);
    end if;
    ------------------------------
    util_pkg.set_by_pos_ct_number(p_error_codes, v_error_codes2, v_pivot2);
    util_pkg.set_by_pos_ct_varchar(p_error_messages, v_error_messages2, v_pivot2);
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prod_check_sim_cards_range
(
    p_seria_start t_varchar,
    p_seria_end t_varchar,
    p_network_operator_code varchar2,
    p_host_id number,
    p_stock_code varchar2,
    p_document_number in out varchar2,
    p_user_name varchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number,
    p_error_message out varchar2,
    p_sn_passed out sys_refcursor,
    p_sn_not_passed out sys_refcursor
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_series_start ct_nvarchar_s;
  v_series_end ct_nvarchar_s;
  v_sn ct_nvarchar_s;
  v_iccid ct_nvarchar_s;
  v_imsi ct_nvarchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  v_mark_err ct_number;
  v_sn2 ct_nvarchar_s;
  v_iccid2 ct_nvarchar_s;
  v_imsi2 ct_nvarchar_s;
  v_sn3 ct_nvarchar_s;
  v_error_codes3 ct_number;
  v_error_messages3 ct_varchar;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
     v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_series_start := cast_t_varchar2ct_nvarchar_s2(p_seria_start);
  v_series_end := cast_t_varchar2ct_nvarchar_s2(p_seria_end);
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(v_series_start);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(v_series_start) != v_main_count, 'v_series_start.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(v_series_end) != v_main_count, 'v_series_end.count != v_main_count');
  ------------------------------
  v_sn := util_stock.split_ranges3(v_series_start, v_series_end);
  ------------------------------
  prod_check_sim_cards_list_i(
    p_sn => v_sn,
    p_network_operator_code => p_network_operator_code,
    p_host_id => p_host_id,
    p_stock_code => p_stock_code,
    p_document_number => p_document_number,
    p_user_id => util_stock.xget_user_id(p_user_name),
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_iccid => v_iccid,
    p_imsi => v_imsi,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_exception(p_error_code, p_error_message);
  end if;
  ------------------------------
  v_mark_err := util_pkg.mark_val_ct_number(v_error_codes, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
  v_sn2 := util_pkg.get_marked_ct_nvarchar_s(v_sn, v_mark_err, TRUE, util_pkg.c_false);
  v_iccid2 := util_pkg.get_marked_ct_nvarchar_s(v_iccid, v_mark_err, TRUE, util_pkg.c_false);
  v_imsi2 := util_pkg.get_marked_ct_nvarchar_s(v_imsi, v_mark_err, TRUE, util_pkg.c_false);
  v_sn3 := util_pkg.get_marked_ct_nvarchar_s(v_sn, v_mark_err, TRUE, util_pkg.c_true);
  v_error_codes3 := util_pkg.get_marked_ct_number(v_error_codes, v_mark_err, TRUE, util_pkg.c_true);
  v_error_messages3 := util_pkg.get_marked_ct_varchar(v_error_messages, v_mark_err, TRUE, util_pkg.c_true);
  ------------------------------
  fill_tmp_sims01(v_iccid2); --!_! full sn 20 digits
  fill_tmp_rejected_sims01(v_sn3, v_error_codes3); --!_! short sn 19 digits without control number
  ------------------------------
  get_success_result_cursor01
  (
    p_sn => v_sn2,
    p_iccid => v_iccid2,
    p_imsi => v_imsi2,
    p_result => p_sn_passed
  );
  ------------------------------
  get_error_result_cursor01
  (
    p_sn  => v_sn3,
    p_error_codes => v_error_codes3,
    p_error_messages => v_error_messages3,
    p_result => p_sn_not_passed
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
     commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prod_check_sim_listnotstock_i
(
    p_sn ct_nvarchar_s,
    p_network_operator_code varchar2,
    p_host_id number,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2,
    p_iccid out ct_nvarchar_s,
    p_imsi out ct_nvarchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
)
IS
  v_sp_name varchar2(30);
  v_date date := sysdate;
  v_network_operator_id number;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_loc_pkg.touch_number(p_user_id);
  ------------------------------
  v_network_operator_id := RI_PERSISTENT_INTERFACE_PKG.get_network_operator_id2(p_network_operator_code, v_date);
  ------------------------------
  IF v_network_operator_id is null
  THEN
    util_pkg.raise_exception(c_ORA_NET_OP_NOT_EXIST, c_em_NET_OP_NOT_EXIST);
  END IF;
  ------------------------------
  prod_check_sim_cards_i
  (
    p_sn => p_sn,
    p_host_id => p_host_id,
    p_net_op_id => v_network_operator_id,
    p_stock_id => null,
    p_must_be_on_stock => FALSE,
    p_iccid => p_iccid,
    p_imsi => p_imsi,
    p_error_codes => p_error_codes,
    p_error_messages => p_error_messages
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prod_check_sim_listnotinstock
(
    p_iccid t_ri_icc_id,
    p_network_operator_code varchar2,
    p_host_id number,
    p_user_name varchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number,
    p_error_message out varchar2,
    p_sn_passed out sys_refcursor,
    p_sn_not_passed out sys_refcursor
)
is
  v_sp_name varchar2(30);
  v_sn ct_nvarchar_s;
  v_iccid ct_nvarchar_s;
  v_imsi ct_nvarchar_s;
  v_error_codes ct_number;
  v_error_messages ct_varchar;
  v_mark_err ct_number;
  v_sn2 ct_nvarchar_s;
  v_iccid2 ct_nvarchar_s;
  v_imsi2 ct_nvarchar_s;
  v_sn3 ct_nvarchar_s;
  v_error_codes3 ct_number;
  v_error_messages3 ct_varchar;
begin
  ------------------------------
  if p_handle_tran = util_stock.c_tran_savepoint
  then
     v_sp_name := util_sys_pkg.make_savepoint;
  end if;
  ------------------------------
  v_sn := cast_t_ri_icc_id2ct_nvarchar_s(p_iccid);
  ------------------------------
  prod_check_sim_listnotstock_i
  (
    p_sn => v_sn,
    p_network_operator_code => p_network_operator_code,
    p_host_id => p_host_id,
    p_user_id => util_stock.xget_user_id(p_user_name),
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_iccid => v_iccid,
    p_imsi => v_imsi,
    p_error_codes => v_error_codes,
    p_error_messages => v_error_messages
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_exception(p_error_code, p_error_message);
  end if;
  ------------------------------
  v_mark_err := util_pkg.mark_val_ct_number(v_error_codes, util_pkg.c_ora_ok, util_pkg.c_false, util_pkg.c_true);
  ------------------------------
  v_sn2 := util_pkg.get_marked_ct_nvarchar_s(v_sn, v_mark_err, TRUE, util_pkg.c_false, null);
  v_iccid2 := util_pkg.get_marked_ct_nvarchar_s(v_iccid, v_mark_err, TRUE, util_pkg.c_false, null);
  v_imsi2 := util_pkg.get_marked_ct_nvarchar_s(v_imsi, v_mark_err, TRUE, util_pkg.c_false, null);
  ------------------------------
  v_sn3 := util_pkg.get_marked_ct_nvarchar_s(v_sn, v_mark_err, TRUE, util_pkg.c_true, null);
  v_error_codes3 := util_pkg.get_marked_ct_number(v_error_codes, v_mark_err, TRUE, util_pkg.c_true, null);
  v_error_messages3 := util_pkg.get_marked_ct_varchar(v_error_messages, v_mark_err, TRUE, util_pkg.c_true, null);
  ------------------------------
  fill_tmp_sims01(v_iccid2); --!_! full sn 20 digits
  fill_tmp_rejected_sims01(v_sn3, v_error_codes3); --!_! short sn 19 digits without control number
  ------------------------------
  get_success_result_cursor01
  (
    p_sn => v_sn2,
    p_iccid => v_iccid2,
    p_imsi => v_imsi2,
    p_result => p_sn_passed
  );
  ------------------------------
  get_error_result_cursor01
  (
    p_sn  => v_sn3,
    p_error_codes => v_error_codes3,
    p_error_messages => v_error_messages3,
    p_result => p_sn_not_passed
  );
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
     commit;
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    rollback;
  elsif p_handle_tran = util_stock.c_tran_savepoint
  then
    util_sys_pkg.rollback_savepoint(v_sp_name);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure fill_tmp_sims01(p_sn ct_nvarchar_s)
is
begin
  ------------------------------
  delete from tmp_sims;
  ------------------------------
  insert into tmp_sims(iccid)
    select
       q0.serial_number
      from
        (select column_value serial_number, rownum rn from table(p_sn)) q0
      where 1 = 1
      order by q0.rn;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_tmp_rejected_sims01(p_sn ct_nvarchar_s, p_error_codes ct_number)
is
begin
  ------------------------------
  delete from tmp_rejected_sims;
  ------------------------------
  insert into tmp_rejected_sims(iccid,result)
    select /*+ ordered use_hash(q0 q1) full(q0) full(q1) */
        q0.serial_number,
        q1.error_code
      from
        (select column_value serial_number, rownum rn from table(p_sn)) q0,
        (select column_value error_code, rownum rn from table(p_error_codes)) q1
      where 1 = 1
      and q1.rn(+) = q0.rn
      order by q0.rn
      ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_success_result_cursor01
(
    p_sn ct_nvarchar_s,
    p_iccid ct_nvarchar_s,
    p_imsi ct_nvarchar_s,
    p_result out sys_refcursor
)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q1, q2) full(q0) full(q1) full(q2) */
    q0.serial_number,
    q1.iccid,
    q2.imsi
  from
    (select column_value serial_number, rownum rn from table(p_sn)) q0,
    (select column_value iccid, rownum rn from table(p_iccid)) q1,
    (select column_value imsi, rownum rn from table(p_imsi)) q2
  where 1 = 1
  and q1.rn(+) = q0.rn
  and q2.rn(+) = q0.rn
  order by q0.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_error_result_cursor01
(
    p_sn ct_nvarchar_s,
    p_error_codes ct_number,
    p_error_messages ct_varchar,
    p_result out sys_refcursor
)
is
begin
  ------------------------------
  open p_result for
select /*+ ordered use_hash(q1, q2) full(q0) full(q1) full(q2) */
    q0.serial_number,
    q1.error_code,
    q2.error_message
  from
    (select column_value serial_number, rownum rn from table(p_sn)) q0,
    (select column_value error_code, rownum rn from table(p_error_codes)) q1,
    (select column_value error_message, rownum rn from table(p_error_messages)) q2
  where 1 = 1
  and q1.rn(+) = q0.rn
  and q2.rn(+) = q0.rn
  order by q0.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
end;
/
