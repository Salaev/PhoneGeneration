CREATE PACKAGE pkg_crm AS

----------------------------------!---------------------------------------------
  c_no_value_not_null_number     constant number := util_pkg.c_false;
  c_no_value_not_null_date       constant date := util_pkg.c_minus_infinity;
  c_no_value_not_null_varchar_s  constant varchar2(50) := 'qwerty';
  c_no_value_not_null_varchar    constant varchar2(4000) := 'qwerty';
  c_no_value_not_null_nvarchar_s constant nvarchar2(50) := 'qwerty';
  c_no_value_not_null_nvarchar   constant nvarchar2(2000) := 'qwerty';

----------------------------------!---------------------------------------------
  procedure find_all_child_stocks
  (
    p_tab_stock_group_id util_pkg.cit_number,
    p_user            nvarchar2,
    p_stock_rec       out sys_refcursor,
    p_error_code      out number
  );

  procedure find_child_stocks
  (
    p_stock_group_id  number,
    p_user            nvarchar2,
    p_stock_rec       out sys_refcursor,
    p_error_code      out number
  );

  procedure find_all_child_stock_groups
  (
    p_stock_group_id  number,
    p_user            nvarchar2,
    p_stock_group_rec out sys_refcursor,
    p_error_code      out number
  );

  procedure find_child_stock_groups
  (
    p_stock_group_id  number,
    p_user            nvarchar2,
    p_stock_group_rec out sys_refcursor,
    p_error_code      out number
  );

----------------------------------!---------------------------------------------
-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 15.06.2007 14:57
-- Version : 1
-- Modification : crm_management.findequipment
-- Editor  :
-- Changed :
-- Purpose : Поиск оборудования по условиям в текущем состоянии склада
--------------------------------------------------------------------------------
   PROCEDURE find_equipment (
      p_seria_start        IN       NVARCHAR2,
      p_seria_end          IN       NVARCHAR2,
      p_comment_mask       IN       NVARCHAR2,
      p_min_val_date       IN       DATE,
      p_max_val_date       IN       DATE,
      p_equipment_number   IN       NUMBER,
      p_row_count          IN       NUMBER,
      p_unreserved         IN       NUMBER,
      p_cur_equipment      OUT      sys_refcursor,
      p_error_code         OUT      NUMBER
   );

----------------------------------!---------------------------------------------
  procedure find_sim_cards_1
  (
    p_user_name       nvarchar2,
    p_only_free       number,
    p_quantity        number,
    p_seria_start     nvarchar2,
    p_seria_end       nvarchar2,
    p_cur_sim_cards   out sys_refcursor,
    p_stock_code      util_pkg.cit_nvarchar_s := util_pkg.empty_cit_nvarchar_s
  );

  --!_! MAIN
  procedure find_sim_cards
  (
    p_stock_ids       ct_number,
    p_only_free       number,
    p_quantity        number,
    p_seria_start     nvarchar2,
    p_seria_end       nvarchar2,
    p_cur_find        out sys_refcursor
  );

  procedure find_sim_cards_4
  (
    p_stock_code      util_pkg.cit_nvarchar_s := util_pkg.empty_cit_nvarchar_s,
    p_serial_number   util_pkg.cit_nvarchar_s := util_pkg.empty_cit_nvarchar_s,
    p_equipment_type_code util_pkg.cit_varchar_s := util_pkg.empty_cit_varchar_s,
    p_user_name       nvarchar2,
    p_cur_find_sim_cards out sys_refcursor,
    p_error_code      out number,
    p_error_message   out varchar2
  );

----------------------------------!---------------------------------------------
  procedure find_sim_cards_free_or_link
  (
    p_user_name         nvarchar2,
    p_status            number, --!_!0 - all, 1 - free, 2 - linked
    p_quantity          number,
    p_seria_start       util_pkg.cit_nvarchar_s,
    p_seria_end         util_pkg.cit_nvarchar_s,
    p_cur_sim_cards     out sys_refcursor,
    p_stock_code        util_pkg.cit_nvarchar_s := util_pkg.empty_cit_nvarchar_s
  );

  procedure find_sim_cards_free_or_link_2
  (
    p_stock_code        util_pkg.cit_nvarchar_s := util_pkg.empty_cit_nvarchar_s,
    p_status            number, --!_!0 - all, 1 - free, 2 - linked
    p_user_name         nvarchar2,
    p_date_of_search    date,
    p_cur_sim_cards     out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure find_equipments_info
  (
    p_seria_start       util_pkg.cit_nvarchar_s,
    p_seria_end         util_pkg.cit_nvarchar_s,
    p_user_name         nvarchar2,
    p_cur_equipments_info out sys_refcursor,
    p_error_message     out varchar2,
    p_error_code        out number
  );

----------------------------------!---------------------------------------------
  procedure find_complects
  (
    p_stock_code      util_pkg.cit_nvarchar_s := util_pkg.empty_cit_nvarchar_s,
    p_quantity        number,
    p_seria_start     nvarchar2,
    p_seria_end       nvarchar2,
    p_user_name       nvarchar2,
    p_cur_complects   out sys_refcursor
  );

----------------------------------!---------------------------------------------
--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   FUNCTION get_HLR_Code (p_full_number VARCHAR2)
      RETURN VARCHAR2;
-------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 18.05.2010
-- Version :1
-- Modification :pcg_crm.find_sim_cards_range
-- Editor  : Pavel Vasiliev
-- Changed :
-- Purpose : Ищет сим-карты по заданным критериям  и добавляет найденые сим-карты в документ на списание
--------------------------------------------------------------------------------
   PROCEDURE find_sim_cards_range (
      p_document_number IN       VARCHAR2,
      p_HLR_code        IN       VARCHAR2,
      p_user_name       IN       VARCHAR2,
      p_quantity        IN       NUMBER,
      p_seria_start     IN       VARCHAR2,
      p_seria_end       IN       VARCHAR2,
      p_handle_tran     IN       CHAR := 'Y',
      p_error_code      OUT      NUMBER
   );

-------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 18.05.2010
-- Version :1
-- Modification :pcg_crm.check_sim_cards
-- Editor  : Pavel Vasiliev
-- Changed :
-- Purpose : Проверяет, что сим-карты удовлетворяют заданным критериям и добавляет сим-карты в документ на списание
--------------------------------------------------------------------------------
   PROCEDURE check_sim_cards (
      p_document_number IN       VARCHAR2,
      p_HLR_code        IN       VARCHAR2,
      p_user_name       IN       VARCHAR2,
      p_sim_cards       IN       pkg_common.t_varchar,
      p_handle_tran     IN       CHAR := 'Y',
      p_error_code      OUT      NUMBER
   );

-------------------------------------------------------------------------------
-- Author  : Pavel Vasiliev
-- Created : 24.05.2010
-- Version :1
-- Modification :pcg_crm.find_sim_cards_range
-- Editor  : Pavel Vasiliev
-- Changed :
-- Purpose : Ищет сим-карты по заданным критериям  и добавляет найденые сим-карты в документ  на списание
--           Удаляет из документа сим карты перечисленные в p_removing_sims
--------------------------------------------------------------------------------
   PROCEDURE set_operation_eqipment (
      p_document_number IN       VARCHAR2,
      p_HLR_code        IN       VARCHAR2,
      p_user_name       IN       VARCHAR2,
      p_quantity        IN       NUMBER,
      p_seria_start     IN       VARCHAR2,
      p_seria_end       IN       VARCHAR2,
      p_removing_sims   IN       pkg_common.t_varchar,
      p_handle_tran     IN       CHAR := 'Y',
      p_error_code      OUT      NUMBER
   );

----------------------------------!---------------------------------------------

END;
/
