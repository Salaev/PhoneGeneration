CREATE PACKAGE PKG_DOC
AS
----------------------------------!---------------------------------------------
   g_upd_dd_row_out   NUMBER    DEFAULT 0;   -- кол-во измененых строк для склада отправителя при выполнениии upd_doc_detail_date_of_move
   g_upd_dd_row_in    NUMBER    DEFAULT 0;   -- кол-во измененых строк для склада получателя при выполнениии upd_doc_detail_date_of_move
   g_upd_dh_row_out   NUMBER    DEFAULT 0;   -- кол-во измененых строк для склада отправителя при выполнениии upd_doc_header_date_of_move
   g_upd_dh_row_in    NUMBER    DEFAULT 0;   -- кол-во измененых строк для склада получателя при выполнениии upd_doc_header_date_of_move
   g_tab_type_id      ct_number;   --коллекция типов документа

----------------------------------!---------------------------------------------
   PROCEDURE docheader_filtered_1 (
      p_stock_id        IN       NUMBER,
      p_type            IN       NUMBER,
      p_status_id       IN       NUMBER,
      p_from_date       IN       DATE,
      p_to_date         IN       DATE,
      p_cur_docheader   OUT      sys_refcursor,
      p_error_code      OUT      NUMBER
   );

   PROCEDURE docheader_filtered_2 (
      p_stock_id        IN       NUMBER,
      p_type            IN       NUMBER,
      p_status_id       IN       NUMBER,
      p_cur_docheader   OUT      sys_refcursor,
      p_error_code      OUT      NUMBER
   );

   PROCEDURE docheader_last_n_count (
      p_stock_id        IN       NUMBER,
      p_type            IN       NUMBER,
      p_status_id       IN       NUMBER,
      p_count           IN       NUMBER,
      p_cur_docheader   OUT      sys_refcursor,
      p_error_code      OUT      NUMBER
   );

   PROCEDURE get_history (
      p_seria_start    IN       NVARCHAR2,
      p_seria_end      IN       NVARCHAR2,
      p_model_id       IN       NUMBER,
      p_date_from      IN       DATE DEFAULT pkg_constants.c_minsysdate,
      p_date_to        IN       DATE DEFAULT pkg_constants.c_maxsysdate,
      p_document_rec   OUT      sys_refcursor,
      p_error_code     OUT      NUMBER
   );

   PROCEDURE get_new_docnum (
      p_stock_id      IN       NUMBER,
      p_doc_type_id   IN       NUMBER,
      p_new_docnum    OUT      VARCHAR2,
      p_error_code    OUT      NUMBER
   );

   PROCEDURE search (
      p_doc_type_id      IN       pkg_common.t_num,
      p_date_from        IN       DATE,
      p_date_to          IN       DATE,
      p_doc_header_rec   OUT      sys_refcursor,
      p_error_code       OUT      NUMBER,
      p_stock_out        IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_stock_in         IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_eqm_model_id     IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   );

   PROCEDURE set_typeid (
      p_type_id      IN   pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_flag_clear   IN   CHAR DEFAULT 'Y'
   );

   FUNCTION sq_next_docnum (p_stock_id IN NUMBER, p_doc_type_id IN NUMBER, p_year IN NUMBER)
      RETURN NUMBER;

   PROCEDURE upd_docheader_status (
      p_id            IN       NUMBER,
      p_status_id     IN       NUMBER,
      p_user_id       IN       NVARCHAR2,
      p_handle_tran   IN       CHAR := 'Y',
      p_error_code    OUT      NUMBER
   );

----------------------------------!---------------------------------------------
END;
/
