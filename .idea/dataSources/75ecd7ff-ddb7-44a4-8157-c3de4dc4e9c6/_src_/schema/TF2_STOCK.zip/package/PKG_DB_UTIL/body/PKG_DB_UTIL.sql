CREATE PACKAGE BODY pkg_db_util IS

PROCEDURE DEBUG (p_prc_name VARCHAR2, p_info VARCHAR2, p_chanel VARCHAR2 DEFAULT '')
IS
   PRAGMA AUTONOMOUS_TRANSACTION;
   l_chnl                VARCHAR2 (50);   --канал для PIPE
   l_globalval_output    global_value.VALUE%TYPE     DEFAULT NULL;   --ресурс вывода отладочной информации
   l_globalval_prcname   global_value.VALUE%TYPE     DEFAULT NULL;   --имя процедуры для отладки
   l_globalval_chanel    global_value.VALUE%TYPE     DEFAULT NULL;   --имя канала отладки
   l_timer_value         debug_log.time_exec%TYPE    DEFAULT NULL;   --значение времени в сек.
   l_info                debug_log.debug_info%TYPE   DEFAULT NULL;   --строка информации с именем ПК и временем вызова
   l_comp                NVARCHAR2 (50)              DEFAULT NULL;   --компьютер пользователя
   --!_!l_user                NVARCHAR2 (50)              DEFAULT NULL;   --пользователь
   l_schema              NVARCHAR2 (50)              DEFAULT NULL;   --текущая схема
   l_date                NVARCHAR2 (50)              DEFAULT NULL;   --дата
   l_file_handle         UTL_FILE.file_type;
BEGIN
   util_loc_pkg.touch_varchar(p_chanel);

   --Получим ресурс вывода отладочной информации
   l_globalval_output := pkg_common.get_global_val ('DEBUG_OUTPUT');

   IF l_globalval_output NOT IN ('NO_DATA_FOUND', 'NONE', 'OFF')
   THEN
      --Получим системную информацию
      l_comp := SYS_CONTEXT ('USERENV', 'TERMINAL');
      --!_!l_user := SYS_CONTEXT ('USERENV', 'OS_USER');
      l_schema := SYS_CONTEXT ('USERENV', 'CURRENT_SCHEMA');
      l_date := TO_CHAR (CURRENT_TIMESTAMP, 'DD.MM.YYYY HH24:MI:SSxFF');
      --Получим имя процедуры для отладки
      l_globalval_prcname := pkg_common.get_global_val ('DEBUG_PROC');

      --Время выполнения процедуры
      IF ((UPPER (p_prc_name) = l_globalval_prcname) AND (p_info = pkg_constants.c_flag_start))
      THEN
         pkg_common.SET_TIMER (pkg_constants.c_flag_start || SUBSTR (l_globalval_prcname, -15));   --тк контекст недает установить более 26 символов
         l_timer_value := NULL;
      ELSIF ((UPPER (p_prc_name) = l_globalval_prcname) AND (p_info = pkg_constants.c_flag_end))
      THEN
         pkg_common.SET_TIMER (pkg_constants.c_flag_end || SUBSTR (l_globalval_prcname, -15));   --тк контекст недает установить более 26 символов
         l_timer_value :=
            pkg_common.get_timer_result (   pkg_constants.c_flag_start
                                         || SUBSTR (l_globalval_prcname, -15),
                                            pkg_constants.c_flag_end
                                         || SUBSTR (l_globalval_prcname, -15)
                                        );
      END IF;

      --Информация от процедуры
      l_info :=
         l_comp || ' ' || l_date || ' : ' || p_prc_name || '->' || p_info || ' ' || l_timer_value;

      --Куда выводим отладочную информацию
      CASE l_globalval_output
         WHEN 'PIPE'   --канал
         THEN
            IF ((UPPER (p_prc_name) = l_globalval_prcname) OR (l_globalval_prcname = 'NONE'))
            THEN
               l_globalval_chanel := pkg_common.get_global_val ('DEBUG_CHANEL');

               IF l_globalval_chanel <> 'NO_DATA_FOUND'
               THEN
                  l_chnl := l_globalval_chanel;   --канал заданный в таблице гл.параметров
               ELSE
                  l_chnl := l_schema;   --канал по умолчанию
               END IF;

               DBMS_PIPE.pack_message (l_info);   --упаковываем

               IF DBMS_PIPE.send_message (l_chnl, 3) > 0
               THEN
                  DBMS_PIPE.PURGE (l_chnl);
               END IF;
            END IF;
         WHEN 'BUFFER'   --буффер
         THEN
            BEGIN
               IF ((UPPER (p_prc_name) = l_globalval_prcname) OR (l_globalval_prcname = 'NONE')
                  )
               THEN
                  IF LENGTH (l_info) >= 255
                  THEN
                     DBMS_OUTPUT.put_line (SUBSTR (l_info, 1, 250) || '...');
                  ELSE
                     DBMS_OUTPUT.put_line (l_info);
                  END IF;
               END IF;
            END;
         WHEN 'TABLE'   --таблица
         THEN
            BEGIN
               IF ((UPPER (p_prc_name) = l_globalval_prcname) OR (l_globalval_prcname = 'NONE')
                  )
               THEN
                  INSERT INTO debug_log
                       VALUES (l_schema, l_comp, CURRENT_TIMESTAMP, p_prc_name, '', p_info,
                               l_timer_value);
               END IF;
            END;
         WHEN 'FILE'   --файл
         THEN
            BEGIN
               IF ((UPPER (p_prc_name) = l_globalval_prcname) OR (l_globalval_prcname = 'NONE')
                  )
               THEN
                  LOOP
                     l_file_handle :=
                        UTL_FILE.fopen ('STOCK_DEBUG', 'debug_' || LOWER (l_comp) || '.log',
                                        'a');

                     IF UTL_FILE.is_open (l_file_handle)
                     THEN
                        IF LENGTH (l_info) >= 1022
                        THEN
                           UTL_FILE.put_line (l_file_handle, SUBSTR (l_info, 1, 1019) || '...');   --MAX 1023 B
                        ELSE
                           UTL_FILE.put_line (l_file_handle, l_info);
                        END IF;

                        UTL_FILE.fclose (l_file_handle);
                        EXIT;
                     END IF;
                  END LOOP;
               END IF;
            END;
      END CASE;
   END IF;

   COMMIT;   --если PRAGMA AUTONOMOUS_TRANSACTION;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.put_line (SUBSTR ('Ошибка в PKG_DB_UTIL.DEBUG :' || SQLERRM, 1, 255));
      COMMIT;   --если PRAGMA AUTONOMOUS_TRANSACTION;

      IF l_globalval_output = 'FILE'
      THEN
         IF UTL_FILE.is_open (l_file_handle)
         THEN
            UTL_FILE.fclose (l_file_handle);
         END IF;
      END IF;
END;

END;
/
