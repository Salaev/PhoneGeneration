CREATE PACKAGE pkg_equipment
AS
--******************************************************************************
-- Author  : Skripnik Petr
-- Created : 18.12.2006 11:18
-- Modification :
-- Purpose : Work with the equipment
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ----------------------------------------------
-- Skripnik Petr   23.01.2007  t_num
-- Skripnik Petr   16.04.2007  version 1.11.8.2
--******************************************************************************
   g_tab_model_id       ct_number := ct_number ();   --идентификаторы оборудования №1
   g_tab2_model_id      ct_number := ct_number ();   --идентификаторы оборудования №2
   g_tab_series         ct_series := ct_series ();   --серии оборудования
   g_tab_empty_series   ct_series := ct_series ();   --пустая серия оборудования

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 13.09.2006 11:23
-- Editor  :
-- Changed :
-- Purpose : Функция проверки обязательной установки серийного номера у определенного типа оборудования
--------------------------------------------------------------------------------
   FUNCTION chk_availability_sn (p_equipment_type_id IN NUMBER DEFAULT NULL)
      RETURN BOOLEAN;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.11.2006 14:33
-- Editor  :
-- Changed :
-- Purpose : Функция проверки пересечения серийных номеров оборудования
-- (во всех случаях включения\пересечения)
--------------------------------------------------------------------------------
   FUNCTION chk_cross_series_all (
      p_seria_start          IN   NVARCHAR2,
      p_seria_end            IN   NVARCHAR2,
      p_doc_header_id        IN   NUMBER,
      p_stock_id             IN   NUMBER DEFAULT NULL,
      p_equipment_model_id   IN   NUMBER DEFAULT NULL
   )
      RETURN BOOLEAN;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 22.11.2006 13:24
-- Editor  :
-- Changed :
-- Purpose : Функция проверки пересечения серийных номеров оборудования
--(только параметров полностью лежащих внутри сушествующего диапозона не еденичных серий оборудования)
--------------------------------------------------------------------------------
   FUNCTION chk_cross_series_inner (
      p_seria_start          IN   NVARCHAR2,
      p_seria_end            IN   NVARCHAR2,
      p_doc_header_id        IN   NUMBER,
      p_stock_id             IN   NUMBER DEFAULT NULL,
      p_equipment_model_id   IN   NUMBER DEFAULT NULL
   )
      RETURN BOOLEAN;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 22.11.2006 13:14
-- Editor  :
-- Changed :
-- Purpose : Функция проверки пересечения серийных номеров оборудования
--(кроме параметров полностью лежащих внутри сушествующего диапозона)
--------------------------------------------------------------------------------
   FUNCTION chk_cross_series_outher (
      p_seria_start          IN   NVARCHAR2,
      p_seria_end            IN   NVARCHAR2,
      p_doc_header_id        IN   NUMBER,
      p_stock_id             IN   NUMBER DEFAULT NULL,
      p_equipment_model_id   IN   NUMBER DEFAULT NULL
   )
      RETURN BOOLEAN;

--------------------------------------------------------------------------------
-- Author  : Anoev Maxim
-- Created : 20.03.2007 14:34
-- Editor  : Skripnik Petr
-- Changed : 02.04.2007 13:18
-- Purpose : Удалить пакет оборудования
--------------------------------------------------------------------------------
   PROCEDURE del_package (p_package_model_id IN NUMBER, p_user IN NVARCHAR2);

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 28.06.2007 11:37
-- Version : 1
-- Modification : alarm_management.alarm__get
-- Editor  :
-- Changed :
-- Purpose : Получение записей о критических запасах оборудования на складе
--------------------------------------------------------------------------------
   PROCEDURE get_alarm (
      p_id                   IN       NUMBER,
      p_stock_id             IN       NUMBER,
      p_equipment_model_id   IN       NUMBER,
      p_alarm_rec            OUT      sys_refcursor
   );

--------------------------------------------------------------------------------
-- Author  : Anoev Maxim
-- Created : 20.03.2007 14:34
-- Editor  : Skripnik Petr
-- Changed : 02.04.2007 13:13
-- Purpose : Возвращает все модели оборудования, на основе которого могут формироваться пакеты
--------------------------------------------------------------------------------
   PROCEDURE get_eqm_for_package (p_out_cur OUT sys_refcursor);

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 27.12.2006 11:50
-- Editor  :
-- Changed :
-- Purpose : Получение идентификатора модели оборудования по коду модели оборудования
--------------------------------------------------------------------------------
   FUNCTION get_modelid_by_modelcode (p_equipment_model_code IN VARCHAR2)
      RETURN NUMBER;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.03.2007 10:29
-- Editor  :
-- Changed :
-- Purpose : Возвращает пакеты оборудования
--------------------------------------------------------------------------------
   PROCEDURE get_package (p_package_model_id IN NUMBER, p_out_cur OUT sys_refcursor);

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 06.10.2006 10:23
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 15.01.2007 p_reserved(NVARCHAR2) -> p_unreserved(NUMBER)
-- Purpose : Процедура возвращающая набор диапазонов для оборудования
--------------------------------------------------------------------------------
   PROCEDURE get_range_series (
      p_stock_id             IN       NUMBER,
      p_equipment_model_id   IN       NUMBER,
      p_seria_start          IN       NVARCHAR2,
      p_seria_end            IN       NVARCHAR2,
      p_quantity             IN       NUMBER,
      p_unreserved           IN       NUMBER,
      p_valid_until          IN       DATE,
      p_cur_emt_range        OUT      sys_refcursor,
      p_error_code           OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 18.12.2006 11:18
-- Editor  :
-- Changed :
-- Purpose : Устанавливает максимальную или(и) минимальную серию оборудования определенной длинны
--------------------------------------------------------------------------------
   PROCEDURE get_seria_not_null (p_seria_start IN OUT NVARCHAR2, p_seria_end IN OUT NVARCHAR2);

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 18.12.2006 11:18
-- Editor  :
-- Changed :
-- Purpose : Таблица максимальных или(и) минимальных серии оборудования всех длинн
--------------------------------------------------------------------------------
--PROCEDURE get_series_not_null (p_series OUT ct_series);
--
--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 26.01.2007 14:46
-- Editor  :
-- Changed :
-- Purpose : Получим всю таблицу моделей оборудования
--------------------------------------------------------------------------------
   PROCEDURE get_tab_equipment_model (p_out_cur OUT sys_refcursor, p_error_code OUT NUMBER);

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 22.11.2006 11:47
-- Editor  :
-- Changed :
-- Purpose : Получение идентификатора типа оборудования по идентификатору модели оборудования
--------------------------------------------------------------------------------
   FUNCTION get_typeid_by_modelid (p_equipment_model_id IN NUMBER)
      RETURN NUMBER;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 28.06.2007 12:49
-- Version : 1
-- Modification : alarm_management.alarm__ins
-- Editor  :
-- Changed :
-- Purpose : Вставка записей о критических запасах оборудования на складе
--------------------------------------------------------------------------------
   PROCEDURE ins_alarm (
      p_stock_id             IN       NUMBER,
      p_equipment_model_id   IN       NUMBER,
      p_min_value            IN       NUMBER,
      p_max_value            IN       NUMBER,
      p_error_code           OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 18.12.2006 11:18
-- Editor  :
-- Changed :
-- Purpose : Просмотрим контекст
--------------------------------------------------------------------------------
   PROCEDURE list_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 19.02.2008 15:52
-- Version : 1
-- Modification :
-- Editor  :
-- Changed :
-- Purpose : Использется, чтобы возвратить требуемое количество серийных номеров
--           в порядке возрастания от указанного диапозона
--------------------------------------------------------------------------------
   FUNCTION pivot_serial (p_seria_start IN pkg_common.t_varchar, p_seria_end IN pkg_common.t_varchar)
      RETURN ct_varchar PIPELINED;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.01.2007 15:34
-- Editor  : Skripnik Petr (SP)
-- Changed :
--   SP 22.05.2007 (+) p_model_id_2,p_flag_clear_2
-- Purpose : Устанавливает идентификаторы модели оборудования
-- (Модификация bulk_insert_management.bulk_insert_tmp_equipment_id)
-- (Модификация bulk_insert_management.bulk_insert_tmp_equipment_id2)
--------------------------------------------------------------------------------
   PROCEDURE set_modelid (
      p_model_id_1     IN   pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_flag_clear_1   IN   CHAR DEFAULT 'Y',
      p_model_id_2     IN   pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_flag_clear_2   IN   CHAR DEFAULT 'Y'
   );

--------------------------------------------------------------------------------
-- Author  : Anoev Maxim
-- Created : 20.03.2007 14:34
-- Editor  : Skripnik Petr
-- Changed : 02.04.2007 13:17
-- Purpose : Формирует пакет оборудования для заданной модели
--------------------------------------------------------------------------------
   PROCEDURE set_package (
      p_package_model_id   IN       NUMBER,
      p_base_model_id      IN       NUMBER,
      p_description        IN       NVARCHAR2,
      p_eqm_model          IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_eqm_quantity       IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_user               IN       NVARCHAR2,
      p_error_code         OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 20.02.2007 14:34
-- Editor  :
-- Changed :
-- Purpose : Устанавливает серии оборудования
--------------------------------------------------------------------------------
   PROCEDURE set_series (
      p_seria_start   IN   pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar,
      p_seria_end     IN   pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar,
      p_flag_clear    IN   CHAR DEFAULT 'Y'
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 28.06.2007 12:44
-- Version : 1
-- Modification : alarm_management.alarm__upd
-- Editor  :
-- Changed :
-- Purpose : Изменение записей о критических запасах оборудования на складе
--------------------------------------------------------------------------------
   PROCEDURE upd_alarm (
      p_id           IN       NUMBER,
      p_min_value    IN       NUMBER,
      p_max_value    IN       NUMBER,
      p_error_code   OUT      NUMBER
   );

----------------------------------!---------------------------------------------
  procedure Get_Equipment_List_By_Type
  (
    p_equipment_type_code            varchar2,
    p_equipment_model_code           util_pkg.cit_varchar_s,
    p_seria_start                    util_pkg.cit_nvarchar_s,
    p_seria_end                      util_pkg.cit_nvarchar_s,
    p_stock_codes                    util_pkg.cit_nvarchar_s,
    p_quantity_equipment             number,
    p_is_detail_error                number,
    p_user_login                     users.user_name%type,
    p_error_code                     out number,
    p_error_message                  out varchar2,
    p_equipment_results              out sys_refcursor,
    p_equipment_errors               out sys_refcursor
  );

----------------------------------!---------------------------------------------

END;
/
