CREATE package install_loc_pkg is

----------------------------------!---------------------------------------------
  function get_option1(p_option_name varchar2, p_default varchar2) return varchar2;
  function get_option2(p_option_name varchar2, p_default varchar2) return varchar2;

  procedure ins_option1_str(p_option_name varchar2, p_option_value varchar2, p_option_dsc varchar2/*, p_user_id number, p_change_date date*/);
  procedure upd_option1_value_str(p_option_name varchar2, p_option_value varchar2/*, p_user_id number, p_change_date date*/);
  procedure upd_option1_dsc(p_option_name varchar2, p_option_dsc varchar2/*, p_user_id number, p_change_date date*/);
  procedure del_option1(p_option_name varchar2/*, p_user_id number, p_change_date date*/);

  procedure ins_option2_str(p_option_name varchar2, p_option_value varchar2, p_option_dsc varchar2, p_user_id number, p_change_date date);
  procedure upd_option2_value_str(p_option_name varchar2, p_option_value varchar2, p_user_id number, p_change_date date);
  procedure upd_option2_dsc(p_option_name varchar2, p_option_dsc varchar2, p_user_id number, p_change_date date);
  procedure del_option2(p_option_name varchar2, p_user_id number, p_change_date date);

----------------------------------!---------------------------------------------
  function check_user(p_user_id number, p_date date := sysdate) return number;
  function check_user_name(p_user_name varchar2, p_date date := sysdate) return number;
  function check_user_name2(p_user_name nvarchar2, p_date date := sysdate) return number;

  function get_user_name(p_user_id number, p_date date := sysdate) return varchar2;
  function get_user_name2(p_user_id number, p_date date := sysdate) return nvarchar2;
  function get_user_id(p_user_name varchar2, p_date date := sysdate) return number;
  function get_user_id2(p_user_name nvarchar2, p_date date := sysdate) return number;

----------------------------------!---------------------------------------------

end;
/
