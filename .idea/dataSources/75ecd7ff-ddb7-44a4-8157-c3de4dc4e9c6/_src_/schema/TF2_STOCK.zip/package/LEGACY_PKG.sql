CREATE package LEGACY_PKG is

----------------------------------!---------------------------------------------
  clg_ri_sim_card_not_exists     constant number(5) := -134;
  clg_ri_sim_invalid_host        constant number(5) := -231;
  clg_ri_sim_invalid_net_oper    constant number(5) := -232;
  clg_ri_sim_invalid_status      constant number(5) := -224;
  clg_ri_sim_have_phone_number   constant number(5) := -147;

  c_ri_ora_sim_card_not_found    constant number(5) := -20521;
  c_ri_ora_wrong_host            constant number(5) := -20547;
  c_ri_ora_wrong_no              constant number(5) := -20548;
  c_ri_ora_wrong_ap_status       constant number(5) := -20523;
  c_ri_ora_already_linked        constant number(5) := -20534;

----------------------------------!---------------------------------------------
  clg_ora_ok                     constant number(5) := 0;
  clg_ora_access_denied          constant number(5) := -90001;
  clg_ora_stock_not_exists       constant number(5) := -90005;
  clg_ora_equipment_not_exists   constant number(5) := -90006;
  clg_ora_duplicated_equipment   constant number(5) := -90030;
  clg_ora_find_sim_not_exist     constant number(5) := -90070;
  clg_ora_find_sim_not_on_stock  constant number(5) := -90071;
  clg_ora_find_sim_is_linked     constant number(5) := -90072;
  clg_ora_find_sim_is_free       constant number(5) := -90073;
  clg_ora_invalid_parameter      constant number(5) := -90667;
  clg_ora_missing_parameter      constant number(5) := -90668;

----------------------------------!---------------------------------------------
  clg_msg_ok                    constant varchar2(200) := util_pkg.c_msg_ok;
  clg_msg_access_denied         constant varchar2(200) := util_loc_pkg.c_msg_access_denied_to_stock;
  clg_msg_stock_not_exists      constant varchar2(200) := util_loc_pkg.c_msg_stock_not_exists;
  clg_msg_equipment_not_exists  constant varchar2(200) := util_loc_pkg.c_msg_equipment_not_found;
  clg_msg_duplicated_equipment  constant varchar2(200) := util_loc_pkg.c_msg_duplicated_value;
  clg_msg_find_sim_not_exist    constant varchar2(200) := util_loc_pkg.c_msg_equipment_not_found;
  clg_msg_find_sim_not_on_stock constant varchar2(200) := util_loc_pkg.c_msg_eq_not_exist_on_stock;
  clg_msg_find_sim_is_linked    constant varchar2(200) := 'Sim is linked';
  clg_msg_find_sim_is_free      constant varchar2(200) := 'Sim is free';
  clg_msg_invalid_parameter     constant varchar2(200) := util_pkg.c_msg_invalid_parameter;
  clg_msg_missing_parameter     constant varchar2(200) := util_pkg.c_msg_missing_parameter;

----------------------------------!---------------------------------------------
  procedure find_sim_cards_info
  (
    p_stock_code nvarchar2,
    p_series_start ct_nvarchar_s,
    p_series_end ct_nvarchar_s,
    p_linked boolean,
    p_user_id number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure prod_check_sim_list
  (
    p_host_id number,
    p_net_op_id number,
    p_iccid_without_control_digit ct_nvarchar_s,
    p_iccid out ct_nvarchar_s,
    p_imsi out ct_nvarchar_s,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  );

  procedure Receive_Single_Equipment
  (
    p_stock_code nvarchar2,
    p_equipment_code varchar2,
    p_full_number nvarchar2,
    p_validity_date date,
    p_vendor_doc nvarchar2,
    p_user_id number,
    p_finish boolean,
    p_document_number out nvarchar2,
    p_equipment_id out number,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Put_Away_Equipment_Range1
  (
    p_in_document_number nvarchar2,
    p_stock_code nvarchar2,
    p_series_start ct_nvarchar_s,
    p_series_end ct_nvarchar_s,
    p_model_codes ct_varchar_s,
    p_user_id number,
    p_finish boolean,
    p_out_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Put_Away_Equipment_Range2_i
  (
    p_in_document_number nvarchar2,
    p_stock_code nvarchar2,
    p_sim_ids ct_number,
    p_user_id number,
    p_finish boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar,
    p_out_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure put_away_equipment_range2
  (
    p_in_document_number nvarchar2,
    p_stock_code nvarchar2,
    p_sim_ids ct_number,
    p_user_id number,
    p_finish boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar,
    p_out_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure get_result_cursor04
  (
    p_serial_number ct_nvarchar_s,
    p_ss_id ct_number,
    p_ss_stock_id ct_number,
    p_ss_model_id ct_number,
    p_msisdn ct_varchar_s,
    p_linked boolean,
    p_date date,
    p_result out sys_refcursor
  );

  procedure get_result_cursor05
  (
    p_serial_number ct_nvarchar_s,
    p_ss_id ct_number,
    p_ss_stock_id ct_number,
    p_ss_model_id ct_number,
    p_msisdn ct_varchar_s,
    p_last_dh_id ct_number,
    p_model ct_model,
    p_linked boolean,
    p_date date,
    p_access_denied2not_found boolean,
    p_result out sys_refcursor
  );

  procedure get_result_cursor06
  (
    p_serial_number ct_nvarchar_s,
    p_ss_id ct_number,
    p_ss_stock_id ct_number,
    p_ss_model_id ct_number,
    p_msisdn ct_varchar_s,
    p_model ct_model,
    p_linked boolean,
    p_date date,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------
  function get_search_result_code01(p_ss_id number, p_ss_stock_id number, p_ss_model_id number, p_msisdn varchar2, p_linked number, p_date date, p_access_denied2not_found number) return number;
  function get_result_code02(p_result_code number) return number;

  function get_search_result_msg01(p_result_code number) return varchar2;
----------------------------------!---------------------------------------------

end ;
/
