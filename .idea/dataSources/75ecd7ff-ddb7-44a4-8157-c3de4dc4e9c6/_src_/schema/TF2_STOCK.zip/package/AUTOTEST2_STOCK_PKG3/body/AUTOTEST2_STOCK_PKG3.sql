CREATE package body AUTOTEST2_STOCK_PKG3 is
--------------- Iaiieiaiea oaaeeou naiaiaiuo nei
procedure fill_autotest2_sim_stock(istock_id number default null)
is
x_stock_path varchar2(4000);
s_gr varchar2(256);
begin
if (istock_id is null) then
 for c in (select distinct stock_id from stock_state
  /*where stock_id in (
                                                       select id from stock
                                                                    where name like 'Iineaa%SIM%')*/
     )
 loop
    insert into autotest2_stock(ID,STOCK_ID,EQUIPMENT_MODEL_ID,SERIA_START,SERIA_END,
                                    QUANTITY_ONSTOCK,
                                    QUANTITY_RESERVED,
                                    QUANTITY_ANNOUNCED,
                                    DOC_HEADER_ID,
                                    CREATE_DATE,
                                    STATUS,
                                    EQUIPMENT_TYPE_ID,
                                    RESERVED,
                                    USER_COMMENT,
                                    EQUIPMENT_BATCH_ID,
                                    IS_NONSINGLE_SERIES, name,stock_code)
    select * from (
      select s.*,'X','C' from  stock_state s
      where 1=1 and s.stock_id=c.stock_id and quantity_onstock>=1
      ) where rownum<100001;
    commit;
 end loop;

 update autotest2_stock t
set name=(select name from stock st where st.id=t.stock_id),
    stock_code=(select code from stock st where st.id=t.stock_id);
commit;

for c in (select * from autotest2_stock)
loop
insert into autotest2_sim(stock_id,stock_name,stock_code,
                             seria_start
                             ,sim_number,equipment_model_id)
select c.stock_id,c.name,c.stock_code,c.seria_start, si.full_number,c.equipment_model_id
from sims si
where si.serial_number >= to_char(c.seria_start) and si.serial_number<=to_char(c.seria_end)
;
commit;
end loop;

--- Iieiue ioou e neeaao
for c in (select distinct s.stock_id from autotest2_sim s)
loop
begin
select stock_group_id into s_gr from stock where id=c.stock_id;
exception
 when others
 then continue;
end;
x_stock_path:='';
  for cur2 in (select level, s.* from stock_group s  --where stock_group_id=3
              connect by prior stock_group_id=id
              start with id=s_gr
              order by level desc)
   loop
      x_stock_path:=x_stock_path||'\'||cur2.name;
   end loop;
  update autotest2_sim s
  set s.stock_path=x_stock_path
  where s.stock_id=c.stock_id;
  commit;
end loop;
else
      insert into autotest2_stock
        (ID,
         STOCK_ID,
         EQUIPMENT_MODEL_ID,
         SERIA_START,
         SERIA_END,
         QUANTITY_ONSTOCK,
         QUANTITY_RESERVED,
         QUANTITY_ANNOUNCED,
         DOC_HEADER_ID,
         CREATE_DATE,
         STATUS,
         EQUIPMENT_TYPE_ID,
         RESERVED,
         USER_COMMENT,
         EQUIPMENT_BATCH_ID,
         IS_NONSINGLE_SERIES,
         name,
         stock_code)
        select *
          from (select s.*, 'X', 'C'
                  from stock_state s
                 where 1 = 1
                   and s.stock_id = istock_id
                   and quantity_onstock >= 1)
         where rownum < 100001;
      commit;


    update autotest2_stock t
       set name       = (select name from stock st where st.id = t.stock_id),
           stock_code = (select code from stock st where st.id = t.stock_id)
      where t.stock_id=istock_id;
    commit;

    for c in (select * from autotest2_stock where stock_id=istock_id) loop
      insert into autotest2_sim
        (stock_id, stock_name, stock_code, seria_start, sim_number, equipment_model_id)
        select c.stock_id,
               c.name,
               c.stock_code,
               c.seria_start,
               si.full_number,
               c.equipment_model_id
          from sims si
         where si.serial_number >= to_char(c.seria_start)
           and si.serial_number <= to_char(c.seria_end)
           ;
      commit;
    end loop;

     select stock_group_id into s_gr from stock where id = istock_id;
      x_stock_path := '';
      for cur2 in (select level, s.*
                     from stock_group s
                   connect by prior stock_group_id = id
                    start with id = s_gr
                    order by level desc) loop
        x_stock_path := x_stock_path || '\' || cur2.name;
      end loop;
      update autotest2_sim s
         set s.stock_path = x_stock_path
       where s.stock_id = istock_id;
      commit;
end if;
end fill_autotest2_sim_stock;


procedure fill_sim_attributes_stock (iSIM_NUMBER varchar2,
                               error out sys_refcursor)
is
x_stock_path varchar2(4000);
s_gr varchar2(256);
x_id number(30);
x_seria_start varchar2(50);
x_seria_end varchar2(50);
begin
select id, seria_start, seria_end
into x_id,x_seria_start,x_seria_end from stock_state
where substr(iSIM_NUMBER,1,19)>=seria_start
      and substr(iSIM_NUMBER,1,19)<=seria_end;
if sql%rowcount=0
then
open error for
select 'There is no sim number:'||iSIM_NUMBER||' in stock_state'
from dual;
return;
end if;
---- oaaeei neiea?oo, anee iia auea
delete from  autotest2_stock
where id=x_id
or (substr(iSIM_NUMBER,1,19)>=seria_start
      and substr(iSIM_NUMBER,1,19)<=seria_end);
----
   insert into autotest2_stock(ID,STOCK_ID,EQUIPMENT_MODEL_ID,SERIA_START,SERIA_END,
                                    QUANTITY_ONSTOCK,
                                    QUANTITY_RESERVED,
                                    QUANTITY_ANNOUNCED,
                                    DOC_HEADER_ID,
                                    CREATE_DATE,
                                    STATUS,
                                    EQUIPMENT_TYPE_ID,
                                    RESERVED,
                                    USER_COMMENT,
                                    EQUIPMENT_BATCH_ID,
                                    IS_NONSINGLE_SERIES, name,stock_code)
      select s.*,'X','C' from  stock_state s
      where 1=1
      --and s.stock_id=c.stock_id
      --and quantity_onstock>=1
      and substr(iSIM_NUMBER,1,19)>=seria_start
      and substr(iSIM_NUMBER,1,19)<=seria_end
      and rownum=1;

 update autotest2_stock t
set name=(select name from stock st where st.id=t.stock_id),
    stock_code=(select code from stock st where st.id=t.stock_id)
where id=x_id;

for c in (select * from autotest2_stock where id=x_id)
loop
delete from  autotest2_sim  s where s.sim_number=iSIM_NUMBER;
insert into autotest2_sim(stock_id,stock_name,stock_code,
                             seria_start
                             ,sim_number,equipment_model_id)
select c.stock_id,c.name,c.stock_code,c.seria_start, si.full_number,c.equipment_model_id
from sims si
where si.serial_number >= x_seria_start and si.serial_number<=x_seria_end
;
end loop;



--- Iieiue ioou e neeaao
for c in (select distinct s.stock_id from autotest2_sim s
where s.SIM_NUMBER=iSIM_NUMBER)
loop
select stock_group_id into s_gr from stock where id=c.stock_id;
x_stock_path:='';
  for cur2 in (select level, s.* from stock_group s  --where stock_group_id=3
              connect by prior stock_group_id=id
              start with id=s_gr
              order by level desc)
   loop
      x_stock_path:=x_stock_path||'\'||cur2.name;
   end loop;
  update autotest2_sim s
  set s.stock_path=x_stock_path
  where s.SIM_NUMBER=iSIM_NUMBER;

end loop;

commit;

open error for
select 'NO ERRORS'
from dual;

exception
when no_data_found
then
open error for
select 'There is no sim number:'||iSIM_NUMBER||' in stock_state'
from dual;

end fill_sim_attributes_stock;


procedure full_stock_path (isim_number varchar2,
                           full_path out sys_refcursor)
is
xStock_id number(30);
s_gr number(30);
x_stock_path varchar2(512);
x_stock_name varchar2(512);
begin
select /*+first_rows(1)*/ stock_id into xStock_id
from stock_state where (seria_start<=substr(isim_number,1,19)
                 and seria_end>=substr(isim_number,1,19))
 and substr(seria_start,1,5)= substr(isim_number,1,5)
and rownum=1
;

select stock_group_id,s.name into s_gr,x_stock_name from stock s where id=xStock_id;
x_stock_path:='';
  for cur2 in (select level, s.* from stock_group s
              connect by prior stock_group_id=id
              start with id=s_gr
              order by level desc)
   loop
      x_stock_path:=x_stock_path||'\'||cur2.name;
   end loop;
open full_path for select x_stock_path full_path,x_stock_name stock_name from dual;
end full_stock_path;
-- iaiieiyai oaaeeoo neiea?oaie aey i?aai?iaa?iee
--- Yoeo neiea?o iao ia neeaaao - a oaaeeoa sims
procedure fill_autotest2_sim_for_prepaid
is
x number(5,0);
begin
for c in (select * from sim_card#at
where msisdn_bound is null and personal_account is null)
loop
  x:=0;
  select count(*) into x
  from sims where serial_number=c.sn;
  if x=0 then
    insert into autotest2_sim(seria_start, hlr, sim_number, imsi,host_name,stock_code,change_date)
    select 'seria_start', ss.host_id,c.sn,c.imsi,h.host_name,'-1',sysdate
    from sim_series#at ss, host#at h
    where ss.sim_series_id=c.sim_series_id
    and h.host_id=ss.host_id;
    commit;
  end if;
end loop;
end fill_autotest2_sim_for_prepaid;


/*procedure fill_autotest2_sim_stock_ID(istock_id number) is
    x_stock_path varchar2(4000);
    s_gr         varchar2(256);
  begin
\*    for c in (select distinct stock_id
                from stock_state
              where stock_id=istock_id
              ) loop*\
      insert into autotest2_stock
        (ID,
         STOCK_ID,
         EQUIPMENT_MODEL_ID,
         SERIA_START,
         SERIA_END,
         QUANTITY_ONSTOCK,
         QUANTITY_RESERVED,
         QUANTITY_ANNOUNCED,
         DOC_HEADER_ID,
         CREATE_DATE,
         STATUS,
         EQUIPMENT_TYPE_ID,
         RESERVED,
         USER_COMMENT,
         EQUIPMENT_BATCH_ID,
         IS_NONSINGLE_SERIES,
         name,
         stock_code)
        select *
          from (select s.*, 'X', 'C'
                  from stock_state s
                 where 1 = 1
                   and s.stock_id = istock_id
                   and quantity_onstock >= 1)
         where rownum < 100001;
      commit;
\*    end loop;*\

    update autotest2_stock t
       set name       = (select name from stock st where st.id = t.stock_id),
           stock_code = (select code from stock st where st.id = t.stock_id)
      where t.stock_id=istock_id;
    commit;

    for c in (select * from autotest2_stock where stock_id=istock_id) loop
      insert into autotest2_sim
        (stock_id, stock_name, stock_code, seria_start, sim_number)
        select c.stock_id,
               c.name,
               c.stock_code,
               c.seria_start,
               si.full_number
          from sims si
         where si.serial_number >= to_char(c.seria_start)
           and si.serial_number <= to_char(c.seria_end);
      commit;
    end loop;

    --- Iieiue ioou e neeaao
\*    for c in (select distinct s.stock_id from autotest2_sim s) loop*\
      select stock_group_id into s_gr from stock where id = istock_id;
      x_stock_path := '';
      for cur2 in (select level, s.*
                     from stock_group s --where stock_group_id=3
                   connect by prior stock_group_id = id
                    start with id = s_gr
                    order by level desc) loop
        x_stock_path := x_stock_path || '\' || cur2.name;
      end loop;
      update autotest2_sim s
         set s.stock_path = x_stock_path
       where s.stock_id = istock_id;
      commit;
\*    end loop;*\
  end fill_autotest2_sim_stock_ID;*/


end AUTOTEST2_STOCK_PKG3;
/
