CREATE package util_coll_pkg is

----------------------------------!---------------------------------------------
  function get_marked_ol_ct_number(p_vals ct_number, p_marks ct_number) return ct_number;
  function get_marked_ol_ct_date(p_vals ct_date, p_marks ct_number) return ct_date;
  function get_marked_ol_ct_varchar_s(p_vals ct_varchar_s, p_marks ct_number) return ct_varchar_s;
  function get_marked_ol_ct_varchar(p_vals ct_varchar, p_marks ct_number) return ct_varchar;
  function get_marked_ol_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marks ct_number) return ct_nvarchar_s;
  function get_marked_ol_ct_nvarchar(p_vals ct_nvarchar, p_marks ct_number) return ct_nvarchar;

  function get_unmarked_ol_ct_number(p_vals ct_number, p_marks ct_number) return ct_number;
  function get_unmarked_ol_ct_date(p_vals ct_date, p_marks ct_number) return ct_date;
  function get_unmarked_ol_ct_varchar_s(p_vals ct_varchar_s, p_marks ct_number) return ct_varchar_s;
  function get_unmarked_ol_ct_varchar(p_vals ct_varchar, p_marks ct_number) return ct_varchar;
  function get_unmarked_ol_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marks ct_number) return ct_nvarchar_s;
  function get_unmarked_ol_ct_nvarchar(p_vals ct_nvarchar, p_marks ct_number) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function get_by_pos_ol_ct_number(p_vals ct_number, p_positions ct_number) return ct_number;
  function get_by_pos_ol_ct_date(p_vals ct_date, p_positions ct_number) return ct_date;
  function get_by_pos_ol_ct_varchar_s(p_vals ct_varchar_s, p_positions ct_number) return ct_varchar_s;
  function get_by_pos_ol_ct_varchar(p_vals ct_varchar, p_positions ct_number) return ct_varchar;
  function get_by_pos_ol_ct_nvarchar_s(p_vals ct_nvarchar_s, p_positions ct_number) return ct_nvarchar_s;
  function get_by_pos_ol_ct_nvarchar(p_vals ct_nvarchar, p_positions ct_number) return ct_nvarchar;

----------------------------------!---------------------------------------------
  function trim_ct_varchar_s(p_coll ct_varchar_s) return ct_varchar_s;
  function trim_ct_varchar(p_coll ct_varchar) return ct_varchar;
  function trim_ct_nvarchar_s(p_coll ct_nvarchar_s) return ct_nvarchar_s;
  function trim_ct_nvarchar(p_coll ct_nvarchar) return ct_nvarchar;

----------------------------------!---------------------------------------------

end;
/
