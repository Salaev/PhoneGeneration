CREATE package PKG_PRODUCTION is

  c_SIM_CARD_NOT_EXISTS               CONSTANT NUMBER(5) := -134;  -- constant indicating that given sim card does not exist
  c_SIM_ACTIVATED                     CONSTANT NUMBER(5) := -210;    -- Some of the SIM cards are in status activated.
  c_SIM_HAVE_PHONE_NUMBER             CONSTANT NUMBER(5) := -147;  -- constant informating, that the sim card already have assigned phone number
  c_NOT_SAME_HOST_ID                  CONSTANT NUMBER(5) := -80;  -- constant indicating that phone and sim are not on same host

  c_ORA_ACCESS_DENIED                 CONSTANT NUMBER(5) := -20001;
  c_ORA_STOCK_NOT_EXISTS              CONSTANT NUMBER(5) := -20002;
  c_ORA_INVALID_DOC_NUMBER            CONSTANT NUMBER(5) := -20009;
  c_ORA_INVLD_DOC_NOT_SAME_STOCK      CONSTANT NUMBER(5) := -20010;
  c_ORA_NOT_SAME_OPERATORS            CONSTANT NUMBER(5) := -20119;  -- constant indicating that the joined series are owned by different operators, so they cannot be joined
  c_ORA_NET_OP_NOT_EXIST              CONSTANT NUMBER(5) := -20150;
  c_ORA_BAD_PHONE_RANGE               CONSTANT NUMBER(5) := -20151;  --instead of c_INVALID_INTERVAL

  c_dt_Receipt constant number := 101;
  c_dt_Shippment constant number := 102;
  c_dt_Movement constant number := 103;
  c_dt_Assembling constant number := 104;
  c_dt_Disassembling constant number := 105;
  c_dt_Credit constant number := 106;
  c_dt_Debit constant number := 107;
  c_dt_SeriaPartition constant number := 108;
  c_dt_SeriaAssembilng constant number := 109;
  c_dt_OpenSeries constant number := 110;
  c_dt_CloseSeries constant number := 111;
  c_dt_Inventory constant number := 112;
  c_dt_ErrorReport constant number := 113;
  c_dt_EquipmentValidUntil constant number := 114;

  c_dt_mask01 constant varchar2(30):= 'dd.mm.yyyy hh24:mi:ss';
  c_delim01 constant varchar2(10):= '->';
  c_delim02 constant varchar2(10):= ', ';
  c_STOCK_ID_EMPTY constant number := 0;
  c_STOCK_CODE_EMPTY constant nvarchar2(50) := 'unknown';
  c_ec_SUCCESS constant number := 0;
  c_ec_ACCESS_DENIED constant number := -90001;
  c_ec_STOCK_OUT_NOT_EXISTS constant number := -90005;
  c_ec_EQUIPMENT_NOT_EXISTS constant number := -90006;
  c_ec_STOCK_IN_NOT_EXISTS constant number := -90008;
  c_ec_STORED_PROCEDURE_ERROR constant number := -99999;
  c_em_SUCCESS constant varchar2(2048) := '';
  c_em_ACCESS_DENIED constant varchar2(2048) := 'Access denied';
  c_em_STOCK_OUT_NOT_EXISTS constant varchar2(2048) := 'Output stock not exists';
  c_em_EQUIPMENT_NOT_EXISTS constant varchar2(2048) := 'Equipment not exists';
  c_em_STOCK_IN_NOT_EXISTS constant varchar2(2048) := 'Input stock not exists';
  c_em_STORED_PROCEDURE_ERROR constant varchar2(2048) := 'Stored procedure call error';

  c_em_INVALID_DOC_NUMBER constant varchar2(2048) := 'Document error';
  c_em_INVLD_DOC_NOT_SAME_STOCK constant varchar2(2048) := 'Document error(not same stock id)';
  c_em_NET_OP_NOT_EXIST constant varchar2(2048) := 'Network operator not exist';
  c_em_BAD_PHONE_RANGE constant varchar2(2048) := 'Bad phone range';

  TYPE t_varchar IS TABLE OF VARCHAR2 (100)
      INDEX BY PLS_INTEGER;

  SUBTYPE t_ri_icc_id IS RI_RSIG_SIM_CARD#PCK.t_IMSI;


----------------------------------!---------------------------------------------
  function cast_t_varchar2ct_nvarchar_s(p_coll pkg_common.t_varchar) return ct_nvarchar_s;
  function cast_t_varchar2ct_nvarchar_s2(p_coll t_varchar) return ct_nvarchar_s;
  function cast_t_ri_icc_id2ct_nvarchar_s(p_coll t_ri_icc_id) return ct_nvarchar_s;
  function cast_ct_nvarchar_s2t_imsi(p_coll ct_nvarchar_s) return RI_RSIG_SIM_CARD#PCK.t_imsi;

----------------------------------!---------------------------------------------
  procedure SetOperationEquipment (
    p_document_number varchar2,
    p_host_id number,
    p_user_name varchar2,
    p_quantity number,
    p_seria_start varchar2,
    p_seria_end varchar2,
    p_removing_sims pkg_common.t_varchar,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure set_operation_equipment_i (
    p_document_number varchar2,
    p_host_id number,
    p_user_id number,
    p_quantity number,
    p_seria_start varchar2,
    p_seria_end varchar2,
    p_removing_sims ct_nvarchar_s,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure add_operation_equipment_i
  (
    p_document_number varchar2,
    p_host_id number,
    p_user_id number,
    p_quantity number,
    p_seria_start varchar2,
    p_seria_end varchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure remove_operation_equipment_i
  (
    p_document_number varchar2,
    p_user_id number,
    p_removing_sims ct_nvarchar_s,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure FinishOperation (
    p_document_number varchar2,
    p_user_id varchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  procedure prod_check_sim_cards_i(
    p_sn ct_nvarchar_s,
    p_host_id number,
    p_net_op_id number,
    p_stock_id number,
    p_must_be_on_stock boolean,
    p_iccid out ct_nvarchar_s,
    p_imsi out ct_nvarchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure prod_check_sim_cards_list_i
  (
    p_sn ct_nvarchar_s,
    p_network_operator_code varchar2,
    p_host_id number,
    p_stock_code varchar2,
    p_document_number in out varchar2,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2,
    p_iccid out ct_nvarchar_s,
    p_imsi out ct_nvarchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure prod_check_sim_cards_range
  (
    p_seria_start t_varchar,
    p_seria_end t_varchar,
    p_network_operator_code varchar2,
    p_host_id number,
    p_stock_code varchar2,
    p_document_number in out varchar2,
    p_user_name varchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number,
    p_error_message out varchar2,
    p_sn_passed out sys_refcursor,
    p_sn_not_passed out sys_refcursor
  );

  procedure prod_check_sim_listnotstock_i
  (
    p_sn ct_nvarchar_s,
    p_network_operator_code varchar2,
    p_host_id number,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2,
    p_iccid out ct_nvarchar_s,
    p_imsi out ct_nvarchar_s,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar
  );

  procedure prod_check_sim_listnotinstock
  (
    p_iccid t_ri_icc_id,
    p_network_operator_code varchar2,
    p_host_id number,
    p_user_name varchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number,
    p_error_message out varchar2,
    p_sn_passed out sys_refcursor,
    p_sn_not_passed out sys_refcursor
  );

----------------------------------!---------------------------------------------
  procedure fill_tmp_sims01(p_sn ct_nvarchar_s);
  procedure fill_tmp_rejected_sims01(p_sn ct_nvarchar_s, p_error_codes ct_number);

----------------------------------!---------------------------------------------
  procedure get_success_result_cursor01
  (
    p_sn ct_nvarchar_s,
    p_iccid ct_nvarchar_s,
    p_imsi ct_nvarchar_s,
    p_result out sys_refcursor
  );

  procedure get_error_result_cursor01
  (
    p_sn ct_nvarchar_s,
    p_error_codes ct_number,
    p_error_messages ct_varchar,
    p_result out sys_refcursor
  );

----------------------------------!---------------------------------------------

end;
/
