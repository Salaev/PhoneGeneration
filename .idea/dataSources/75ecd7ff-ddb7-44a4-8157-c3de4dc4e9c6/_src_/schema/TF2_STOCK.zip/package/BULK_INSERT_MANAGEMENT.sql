CREATE PACKAGE bulk_insert_management
AS
--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 09.11.2006 12:09
-- Purpose : Пакет установки значений для общего использования коллекции и временных таблиц
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ----------------------------------------------
-- Petr Skripnik   10.11.2006  Изменен
--------------------------------------------------------------------------------
   TYPE tmpvalid IS TABLE OF tmp_validity.validity_date%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE tmpeccode IS TABLE OF tmp_equipment_code.code%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE tmpeiid IS TABLE OF tmp_equipment_id.ID%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE tmpeiid2 IS TABLE OF tmp_equipment_id2.ID%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE tmpsccode IS TABLE OF tmp_stock_code.code%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE tmpsidid IS TABLE OF tmp_stock_id.ID%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE tmpsidid2 IS TABLE OF tmp_stock_id2.ID%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE tmpdtidid IS TABLE OF tmp_doc_type_id.ID%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE tmpsoname IS TABLE OF tmp_stock_owner.NAME%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE tmpsoname2 IS TABLE OF tmp_stock_owner2.NAME%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE tmpstid IS TABLE OF tmp_stock_type.ID%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE tmpstid2 IS TABLE OF tmp_stock_type2.ID%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE tmpetiid IS TABLE OF tmp_equipment_type_id.ID%TYPE
      INDEX BY BINARY_INTEGER;

   g_tab_empty_num        ct_number  := ct_number ();   --пустая коллекция NUMBER
   g_tab_empty_char       ct_varchar := ct_varchar ();   --пустая коллекция CHAR
   g_tab_empty_date       ct_date    := ct_date ();   --пустая коллекция DATE
   g_tab_doc_type_id      ct_number;   --идентификаторы типов документов
   g_tab_eqm_code         ct_varchar;   --коды оборудования
   g_tab_eqm_type_id      ct_number;   --идентификаторы типов оборудования
   g_tab_stock_code       ct_varchar;   --коды складов
   g_tab_stock_type_id    ct_number;   --идентификаторы типов складов
   g_tab_stock_type_id2   ct_number;   --идентификаторы типов складов (2)

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose : Устанавливает коды оборудования
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_equipment_code (
      p_stock_id                   tmpeiid,
      p_equipment_model_id         tmpeiid,
      p_serial_number              tmpsccode,
      p_serial_number2             tmpsccode,
      p_valid_until                tmpvalid,
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose : Устанавливает коды оборудования
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_equipment_code (
      p_stock_id                   tmpeiid,
      p_equipment_model_id         tmpeiid,
      p_serial_number              tmpsccode,
      p_valid_until                tmpvalid,
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 09.11.2006 15:06
-- Purpose : Устанавливает коды оборудования
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_equipment_code (
      p_code                tmpeccode,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 09.11.2006 13:40
-- Purpose :
--
--  Процедура bulk_insert_tmp_equip_code_1 аналогична процедуре
--   PROCEDURE bulk_insert_tmp_equipment_code (
--      p_stock_id                   tmpeiid,
--      p_equipment_model_id         tmpeiid,
--      p_serial_number              tmpsccode,
--      p_serial_number2             tmpsccode,
--      p_valid_until                tmpvalid,
--      p_length                     NUMBER,
--      p_handle_tran                CHAR := 'Y',
--      p_error_code           OUT   NUMBER
--   )
--  Создана для поддержки FORIS.DataAccess     
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_equip_code_1 (
      p_stock_id                   tmpeiid,
      p_equipment_model_id         tmpeiid,
      p_serial_number              tmpsccode,
      p_serial_number2             tmpsccode,
      p_valid_until                tmpvalid,
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );
   
--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 09.11.2006 15:06
-- Purpose : Устанавливает коды оборудования
--
--  Процедура bulk_insert_tmp_equip_code_3 аналогична процедуре
--   PROCEDURE bulk_insert_tmp_equipment_code (
--      p_code                tmpeccode,
--      p_length              NUMBER,
--      p_handle_tran         CHAR := 'Y',
--      p_error_code    OUT   NUMBER
--   )
--  Создана для поддержки FORIS.DataAccess    
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_equip_code_3 (
      p_code                tmpeccode,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );      

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 18.10.2006 18:13
-- Purpose : Устанавливает идентификаторы оборудования
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_equipment_id (
      p_id                  tmpeiid,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose : Устанавливает коды складов
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_stock_code (
      p_code                tmpsccode,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose : Устанавливает идентификаторы складов
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_stock_id (
      p_id                  tmpsidid,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_stock_owner (
      p_name                tmpsoname,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_stock_owner2 (
      p_name                tmpsoname2,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose : Устанавливает типы складов
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_stock_type (
      p_id                  tmpstid,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose : Устанавливает типы складов
--------------------------------------------------------------------------------
   PROCEDURE bulk_insert_tmp_stock_type2 (
      p_id                  tmpstid2,
      p_length              NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

END;
/
