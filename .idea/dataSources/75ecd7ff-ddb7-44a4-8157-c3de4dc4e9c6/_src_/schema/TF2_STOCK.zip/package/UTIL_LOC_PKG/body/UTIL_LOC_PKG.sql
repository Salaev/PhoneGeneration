CREATE package body util_loc_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure log_clob(p_log_clob_type_id number, p_dsc clob)
is
pragma autonomous_transaction;
begin
  ------------------------------
  insert into log_clob(log_clob_id, log_clob_type_id, dt, dsc) values(sq_log_clob.nextval, p_log_clob_type_id, sysdate, p_dsc);
  ------------------------------
  commit;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure touch_number(p_value number)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_varchar(p_value varchar2)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_nvarchar(p_value nvarchar2)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_date(p_value date)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_boolean(p_value boolean)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Save_Flag_number(p_value number, p_slot in out nocopy number, p_flag in out nocopy boolean) is
begin
  ------------------------------
  p_slot := p_value;
  ------------------------------
  p_flag := true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Restore_Flag_number(p_value in out nocopy number, p_slot number, p_flag in out nocopy boolean) is
begin
  ------------------------------
  if nvl(p_flag, false)
  then
    p_value := p_slot;
  end if;
  ------------------------------
  p_flag := false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function values2keys_ct_number(p_values ct_number, p_ids ct_number, p_skip_value number := null) return util_pkg.cit_number
is
  v_res util_pkg.cit_number := util_pkg.empty_cit_number;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_number(p_values);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != v_main_count, 'p_ids.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_ids, 'p_ids');
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if NOT util_pkg.is_eq_null_vals_number(p_values(v_i), p_skip_value)
    then
      ------------------------------
      v_res(p_ids(v_i)) := p_values(v_i);
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function values2keys_ct_varchar(p_values ct_varchar, p_ids ct_number, p_skip_value varchar := null) return util_pkg.cit_varchar
is
  v_res util_pkg.cit_varchar := util_pkg.empty_cit_varchar;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar(p_values);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_ids) != v_main_count, 'p_ids.count != v_main_count');
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FSU_ct_number(p_ids, 'p_ids');
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if NOT util_pkg.is_eq_null_vals_varchar(p_values(v_i), p_skip_value)
    then
      ------------------------------
      v_res(p_ids(v_i)) := p_values(v_i);
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function ids2keys(p_coll ct_number) return util_pkg.cit_number
is
  v_res util_pkg.cit_number := util_pkg.empty_cit_number;
begin
  ------------------------------
  if util_pkg.get_count_ct_number(p_coll) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    if (1 = 0
      or not p_coll.exists(v_i)
      or p_coll(v_i) is null
    )
    then
      ------------------------------
      util_pkg.raise_exception(c_ora_mandatory_value_nspec, c_msg_mandatory_value_nspec || util_pkg.c_msg_delim01 || util_pkg.number_to_char(v_i));
      ------------------------------
    end if;
    ------------------------------
    if v_res.exists(p_coll(v_i))
    then
      ------------------------------
      util_pkg.raise_exception(c_ora_duplicated_value, c_msg_duplicated_value || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_coll(v_i)) || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_i));
      ------------------------------
    end if;
    ------------------------------
    v_res(p_coll(v_i)) := v_i;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function keys2ids(p_coll util_pkg.cit_number) return ct_number
is
  v_res ct_number;
  v_delta number;
  v_i number;
begin
  ------------------------------
  if util_pkg.get_count_cit_number(p_coll) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := ct_number();
  v_i := p_coll.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    if (1 = 0
      or not p_coll.exists(v_i)
      or p_coll(v_i) is null
    )
    then
      ------------------------------
      util_pkg.raise_exception(c_ora_mandatory_value_nspec, c_msg_mandatory_value_nspec || util_pkg.c_msg_delim01 || util_pkg.number_to_char(v_i));
      ------------------------------
    end if;
    ------------------------------
    v_delta := p_coll(v_i) - v_res.count;
    ------------------------------
    if v_delta > 0
    then
      ------------------------------
      v_res.extend(v_delta);
      ------------------------------
    end if;
    ------------------------------
    if 1 = 1
      and v_res.exists(p_coll(v_i))
      and v_res(p_coll(v_i)) is not null
    then
      ------------------------------
      util_pkg.raise_exception(c_ora_duplicated_value, c_msg_duplicated_value || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_coll(v_i)) || util_pkg.c_msg_delim02 || util_pkg.number_to_char(v_i));
      ------------------------------
    end if;
    ------------------------------
    v_res(p_coll(v_i)) := v_i;
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function keys2simple(p_coll util_pkg.cit_number, p_master_count number := null) return ct_number
is
  v_res ct_number;
  v_count number;
  v_i number;
  v_j number;
begin
  ------------------------------
  if nvl(p_master_count, 0) > 0
  then
    ------------------------------
    v_count := p_master_count;
    ------------------------------
  elsif util_pkg.get_count_cit_number(p_coll) > 0
  then
    ------------------------------
    v_count := p_coll.count;
    ------------------------------
  else
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := ct_number();
  v_res.extend(v_count);
  v_i := p_coll.first;
  v_j := 0;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    if not p_coll.exists(v_i) or p_coll(v_i) is null
    then
      ------------------------------
      util_pkg.raise_exception(c_ora_mandatory_value_nspec, c_msg_mandatory_value_nspec || util_pkg.c_msg_delim01 || util_pkg.number_to_char(v_i));
      ------------------------------
    end if;
    ------------------------------
    v_j := v_j + 1;
    v_res(v_j) := v_i;
    v_i := p_coll.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function restore_ids_from_keys(p_coll util_pkg.cit_number, p_first_id number, p_last_id number, p_empty_val number) return ct_number
is
  v_res ct_number;
  v_count number;
  v_j number;
  v_first_id number := p_first_id;
  v_last_id number := p_last_id;
begin
  ------------------------------
  if util_pkg.get_count_cit_number(p_coll) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  if v_first_id is null
  then
    ------------------------------
    v_first_id := p_coll.first;
    ------------------------------
  end if;
  ------------------------------
  if v_last_id is null
  then
    ------------------------------
    v_last_id := p_coll.last;
    ------------------------------
  end if;
  ------------------------------
  v_count := v_last_id - v_first_id + 1;
  ------------------------------
  if v_count <= 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := ct_number();
  v_res.extend(v_count);
  ------------------------------
  for v_i in v_first_id..v_last_id
  loop
    ------------------------------
    v_j := v_i - v_first_id + 1;
    ------------------------------
    if p_coll.exists(v_i)
    then
      ------------------------------
      v_res(v_j) := v_i;
      ------------------------------
    else
      ------------------------------
      v_res(v_j) := p_empty_val;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure add_save_ind_cit_number(p_coll in out nocopy util_pkg.cit_number, p_coll_add util_pkg.cit_number)
is
  v_i number;
begin
  ------------------------------
  if util_pkg.get_count_cit_number(p_coll_add) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    p_coll := util_pkg.empty_cit_number;
    ------------------------------
  end if;
  ------------------------------
  v_i := p_coll_add.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    if NOT p_coll.exists(v_i)
    then
      ------------------------------
      p_coll(v_i) := p_coll_add(v_i);
      ------------------------------
    end if;
    ------------------------------
    v_i := p_coll_add.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_save_ind_cit_varchar(p_coll in out nocopy util_pkg.cit_varchar, p_coll_add util_pkg.cit_varchar)
is
  v_i number;
begin
  ------------------------------
  if util_pkg.get_count_cit_varchar(p_coll_add) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  if p_coll is null
  then
    ------------------------------
    p_coll := util_pkg.empty_cit_varchar;
    ------------------------------
  end if;
  ------------------------------
  v_i := p_coll_add.first;
  ------------------------------
  while v_i is not null
  loop
    ------------------------------
    if NOT p_coll.exists(v_i)
    then
      ------------------------------
      p_coll(v_i) := p_coll_add(v_i);
      ------------------------------
    end if;
    ------------------------------
    v_i := p_coll_add.next(v_i);
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function make_control_digit(p_iccid varchar2) return varchar2
is
  v_res varchar2(1);
  v_sum number := 0;
  v_num number;
  v_i number;
  v_len number;
begin
  ------------------------------
  --Luhn algorithm
  --http://en.wikipedia.org/wiki/Luhn
  --http://ru.wikipedia.org/wiki/%C0%EB%E3%EE%F0%E8%F2%EC_%CB%F3%ED%E0
  ------------------------------
  v_len := length(p_iccid);
  ------------------------------
  for v_i in 1 .. v_len
  loop
    ------------------------------
    v_num := substr(p_iccid, v_len - v_i + 1, 1);
    ------------------------------
    if mod(v_i, 2) = 1
    then
      ------------------------------
      --even position from RIGHT to left
      ------------------------------
      v_num := v_num * 2;
      ------------------------------
      if v_num > 9
      then
        ------------------------------
        v_num := v_num - 9;
        ------------------------------
      end if;
      ------------------------------
    end if;
    ------------------------------
    v_sum := v_sum + v_num;
    ------------------------------
  end loop;
  ------------------------------
  v_sum := mod(10 - mod(v_sum, 10), 10);
  ------------------------------
  v_res := util_pkg.number_to_char(v_sum);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function obtain_length_ct_varchar_s(p_val ct_varchar_s) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
select
  length(val) val_len
  bulk collect into v_res
  from 
    (select column_value val, rownum rn from table(p_val)) q
  order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function obtain_length_ct_varchar(p_val ct_varchar) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
select
  length(val) val_len
  bulk collect into v_res
  from 
    (select column_value val, rownum rn from table(p_val)) q
  order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function obtain_length_ct_nvarchar_s(p_val ct_nvarchar_s) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
select
  length(val) val_len
  bulk collect into v_res
  from 
    (select column_value val, rownum rn from table(p_val)) q
  order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function obtain_length_ct_nvarchar(p_val ct_nvarchar) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
select
  length(val) val_len
  bulk collect into v_res
  from 
    (select column_value val, rownum rn from table(p_val)) q
  order by rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
