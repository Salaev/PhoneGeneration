CREATE package util_stock is

----------------------------------!---------------------------------------------
  --c_ora_                         constant number(5) := -20999;

----------------------------------!---------------------------------------------
  --c_msg_                         constant varchar2(200) := '';

----------------------------------!---------------------------------------------
  --c_lct_!_!_pkg                  constant number := 1;

  c_perm_any                     constant number := -2;
  c_perm_not_none                constant number := -1;
  c_perm_none                    constant number := 0;
  c_perm_change_out              constant number := 2;
  c_perm_change                  constant number := c_perm_change_out;
  c_perm_change_in               constant number := 4;
  c_perm_view                    constant number := 8;

  c_type_perm_stock              constant number := 0;
  c_type_perm_group              constant number := 1;

  c_sgp_stock_id_for_group       constant number := 0;

  c_parent_id_no_parent          constant number := 0;

  c_empty_stock_group_id         constant number := 0;

  c_obsolete_user_name_len       constant number := 50;

  c_is_nonsingle_ser_false_NULL  constant number := null;
  c_is_nonsingle_ser_true        constant number := 1;

  c_control_number_length        constant number := 1;

  --!_!c_range_padding_CHAR           constant varchar2(1) := '0';
  c_range_padding_NCHAR          constant nvarchar2(1) := '0';

----------------------------------!---------------------------------------------
  c_dummy_date_shift             constant number := 1234;

  c_index_one                    constant number := 1;

  c_dummy_stock_id               constant number := 0;
  c_dummy_stock_code             constant nvarchar2(50) := 'unknown';

  c_no_value_not_null_varchar1   constant varchar2(2) := 'q';
  c_no_value_not_null_varchar2   constant varchar2(2) := 'qw';

  c_no_value_not_null_ot_model   constant ot_model := ot_model
  (
    util_pkg.c_no_value_not_null_number,
    util_pkg.c_no_value_not_null_nvarchar_s,
    util_pkg.c_no_value_not_null_number,
    util_pkg.c_no_value_not_null_nvarchar_s,
    c_no_value_not_null_varchar2,
    c_no_value_not_null_varchar1,
    c_no_value_not_null_varchar1,
    c_no_value_not_null_varchar1,
    c_no_value_not_null_varchar1
  )
  ;

  c_no_value_not_null_ot_node    constant ot_node := ot_node
  (
    util_pkg.c_no_value_not_null_number,
    util_pkg.c_no_value_not_null_number,
    util_pkg.c_no_value_not_null_number,
    util_pkg.c_no_value_not_null_number
  )
  ;

  c_no_value_not_null_ot_range   constant ot_range := ot_range
  (
    util_pkg.c_no_value_not_null_nvarchar_s,
    util_pkg.c_no_value_not_null_nvarchar_s,
    util_pkg.c_no_value_not_null_number,
    util_pkg.c_no_value_not_null_number,
    util_pkg.c_no_value_not_null_number,
    util_pkg.c_no_value_not_null_date,
    util_pkg.c_no_value_not_null_number
  )
  ;

----------------------------------!---------------------------------------------
  c_sett_check_stock_in_perm     constant nvarchar2(50) := 'CHECK_STOCK_IN_PERM';
  c_sett_ignore_model_type       constant nvarchar2(50) := 'IGNORE_MODEL_TYPE';   -- Флаг игнорирования модели оборудования при блокировке

----------------------------------!---------------------------------------------
  c_def_check_stock_in_perm      constant boolean := false;
  c_def_ignore_model_type        constant boolean := true;

----------------------------------!---------------------------------------------
  c_action_Create                constant number := 1;
  c_action_Change                constant number := 2;
  c_action_Delete                constant number := 3; --!_!
  c_action_View                  constant number := 4;
  c_action_Print                 constant number := 5;
  c_action_Cancel                constant number := 8;

  c_Doc_Dir_Type_InOut           constant number := 0;
  c_Doc_Dir_Type_In              constant number := 1;
  c_Doc_Dir_Type_Out           constant number := 2;

  c_Doc_Type_Receipt             constant number := 101;
  c_Doc_Type_Shippment           constant number := 102;
  c_Doc_Type_Movement          constant number := 103;
  c_Doc_Type_Assembling          constant number := 104;
  c_Doc_Type_Disassembling       constant number := 105;
  c_Doc_Type_Credit              constant number := 106;
  c_Doc_Type_Debit               constant number := 107;
  c_Doc_Type_SeriaPartition      constant number := 108;
  c_Doc_Type_SeriaAssembling   constant number := 109;
  c_Doc_Type_OpenSeries          constant number := 110;
  c_Doc_Type_CloseSeries       constant number := 111;
  c_Doc_Type_Inventory           constant number := 112;
  c_Doc_Type_ErrorReport       constant number := 113;
  c_Doc_Type_EquipmentValidUntil constant number := 114;

  c_docstat_error                constant number := -2;
  c_docstat_canceled             constant number := -1;
  c_docstat_open                 constant number := 0;
  c_docstat_finished             constant number := 1;

----------------------------------!---------------------------------------------
  --!_! char(1)
  c_RI_MAIN_LINK_TYPE            constant char(1) := 'M';
  c_RI_SECOND_LINK_TYPE          constant char(1) := 'S';

  c_link_status_all              constant number := 0;
  c_link_status_free             constant number := 1;
  c_link_status_linked           constant number := 2;

  c_no                           constant varchar2(1) := 'N';
  c_yes                          constant varchar2(1) := 'Y';

  c_tran_no                      constant varchar2(1) := c_no;
  c_tran_yes                     constant varchar2(1) := c_yes;
  c_tran_savepoint               constant varchar2(1) := 'S';

  c_eq_type_code_sim01           constant varchar2(50) := '2'; --sim-карта
  c_eq_type_code_sim02           constant varchar2(50) := '3'; --комплект с sim-картой

  c_any_value_num                constant number := -1;
  c_any_value_old_school_num     constant number := 0;
  c_any_value_status_id_num      constant number := -2;

  c_any_count                    constant number := c_any_value_num;
  c_any_qty                      constant number := c_any_count;

  c_not_exists_num               constant number := -1; --Флаг несуществующего номера

----------------------------------!---------------------------------------------
  --!_! not exist in enum ErrorCodeEnum
  c_ec_OK                          constant number := 0;

  --!_! c# constants enum ErrorCodeEnum
  --
  --c_ec_HOME_STOCK_ERROR          constant number := -88888;
  c_ec_ACCESS_DENIED             constant number := -90001;
  --c_ec_STOCK_STATE_RUNNING       constant number := -90002;
  --c_ec_STOCK_OUT_NOT_EXISTS      constant number := -90005;
  --c_ec_EQUIPMENT_NOT_EXISTS      constant number := -90006;
  --c_ec_EQ_NOT_ENOUGH_QUANTITY    constant number := -90007;
  --c_ec_STOCK_IN_NOT_EXISTS       constant number := -90008;
  --c_ec_INVALID_DOC_NUMBER        constant number := -90009;
  --c_ec_SAME_STOCKOUT_STOCKIN     constant number := -90011;
  --c_ec_DUPLICATES_IN_INPUT_PARAM constant number := -90012;
  --c_ec_BULK_INS_ERR              constant number := -90020;
  --c_ec_BULK_INS_DOC_DETAIL_ERR   constant number := -90021;
  --c_ec_BULK_INS_STOCK_STATE_ERR  constant number := -90022;
  --c_ec_BULK_INS_SIMS_ERR         constant number := -90023;
  --c_ec_BULK_INS_UPD_VALID_ERR    constant number := -90024;
  --c_ec_BULK_INS_UPD_STATUS_ERR   constant number := -90025;
  --c_ec_DUPLICATED_EQUIPMENT      constant number := -90030;
  --c_ec_EQ_NOT_EXIST_RES          constant number := -90031;
  --c_ec_NOT_ENOUGH_EQ_RES         constant number := -90032;
  --c_ec_EQ_NOT_EXIST_RES_NO_SER   constant number := -90033;
  --c_ec_NOT_ENOUGH_EQ_RES_NO_SER  constant number := -90034;
  --c_ec_EQ_NOT_EXIST_FROM_STOCK   constant number := -90035;
  --c_ec_NOT_ENOUGH_EQ_FROM_ST     constant number := -90036;
  --c_ec_NOT_EN_EQ_FROM_ST_NO_SER  constant number := -90037;
  --c_ec_EMPTY_USER                constant number := -90050;
  --c_ec_EQUIPMENT_RES             constant number := -90060;
  --c_ec_EQUIPMENT_RES_BY_OTHER    constant number := -90061;
  --c_ec_EQUIPMENT_ALLREADY_RES    constant number := -90062;
  --c_ec_EQUIPMENT_RES_BY_MORE     constant number := -90063;
  --c_ec_EQUIPMENT_NOT_RES         constant number := -90064;
  c_ec_CRM_FIND_SIM_NOT_EX       constant number := -90070;
  c_ec_CRM_FIND_SIM_NOT_EX_ON_ST constant number := -90071;
  c_ec_CRM_FIND_SIM_IS_LINKED    constant number := -90072;
  c_ec_CRM_FIND_SIM_IS_FREE      constant number := -90073;
  --c_ec_NOT_ALL_DATA_RETURNED     constant number := -90666;
  --c_ec_INVALID_ARGUMENTS         constant number := -90667;
  --c_ec_INPUT_PARAMS_IS_NOT_SPEC  constant number := -90668;
  --c_ec_UNIQUE_CONSTRAIN_VIOLATED constant number := -99997;
  --c_ec_FOREIGN_KEY_VIOLATED      constant number := -99998;
  --c_ec_STORED_PROCEDURE_ERROR    constant number := -99999;
  --c_ec_DB_ERROR_UNABLE_EXT_INDEX constant number := -1654;

----------------------------------!---------------------------------------------
  --log_action table
  c_la_stock_group_create        constant number := 1; --Stock group create
  c_la_stock_group_modify        constant number := 2; --Stock group modify
  c_la_stock_group_delete        constant number := 3; --Stock group delete
  c_la_stock_create              constant number := 11; --Stock create
  c_la_stock_modify              constant number := 12; --Stock modify
  c_la_stock_delete              constant number := 13; --Stock delete
  c_la_stock_restore             constant number := 14; --Stock restore
  c_la_profile_privilege_create  constant number := 21; --Profile object privilege create
  c_la_profile_privilege_modify  constant number := 22; --Profile object privilege modify
  c_la_profile_privilege_delete  constant number := 23; --Profile object privilege delete
  c_la_usgp_create               constant number := 31; --User stock group privilege create
  c_la_usgp_modify               constant number := 32; --User stock group privilege modify
  c_la_usgp_delete               constant number := 33; --User stock group privilege delete
  c_la_usp_create                constant number := 41; --User stock privilege create
  c_la_usp_modify                constant number := 42; --User stock privilege modify
  c_la_usp_delete                constant number := 43; --User stock privilege delete
  c_la_user_create               constant number := 51; --User create
  c_la_user_modify               constant number := 52; --User modify
  c_la_user_delete               constant number := 53; --User delete
  c_la_profile_create            constant number := 61; --Profile create
  c_la_profile_modify            constant number := 62; --Profile modify
  c_la_profile_delete            constant number := 63; --Profile delete
  c_la_user_in_profile_create    constant number := 71; --User in profile create
  c_la_user_in_profile_modify    constant number := 72; --User in profile modify
  c_la_user_in_profile_delete    constant number := 73; --User in profile delete
  c_la_user_time_priv_create     constant number := 81; --User time privilege create
  c_la_user_time_priv_modify     constant number := 82; --User time privilege modify
  c_la_user_time_priv_delete     constant number := 83; --User time privilege delete
  c_la_eq_pack_add               constant number := 91; --Equipment added to package content
  c_la_eq_pack_rem               constant number := 92; --Equipment removed from package content
  c_la_format_create             constant number := 93; --Format create
  c_la_format_modify             constant number := 94; --Format modify
  c_la_format_delete             constant number := 95; --Format delete

----------------------------------!---------------------------------------------
  c_msg_stock                    constant varchar2(200) := 'STOCK';
  c_msg_doc_header               constant varchar2(200) := 'DOC_HEADER';
  c_msg_eq_status_initial        constant varchar2(200) := 'EQ_STATUS_INITIAL';
  c_msg_eq_status_final          constant varchar2(200) := 'EQ_STATUS_FINAL';
  c_msg_lock_type                constant varchar2(200) := 'LOCK_TYPE';
  c_msg_locker_group             constant varchar2(200) := 'LOCKER_GROUP';
  c_msg_doc_locker_group         constant varchar2(200) := 'DOC_LOCKER_GROUP';
  c_msg_serial_eq_count          constant varchar2(200) := 'SERIAL_EQ_COUNT';
  c_msg_from_doc_detail          constant varchar2(200) := 'FROM_DOC_DETAIL';
  c_msg_valid_until              constant varchar2(200) := 'VALID_UNTIL';
  c_msg_doc_type                 constant varchar2(200) := 'DOC_TYPE';

----------------------------------!---------------------------------------------
  procedure log_log_i
  (
    p_user_id number,
    p_user_name nvarchar2,
    p_action_id number,
    p_object_id nvarchar2,
    p_description nvarchar2
  );

  --!_! OBSOLETE
  procedure log_log
  (
    p_user_name nvarchar2,
    p_action_id number,
    p_object_id nvarchar2,
    p_description nvarchar2 := null
  );
  --!_! OBSOLETE

  procedure log_log2
  (
    p_user_id number,
    p_action_id number,
    p_object_id nvarchar2,
    p_description nvarchar2 := null
  );

----------------------------------!---------------------------------------------
  function yesno_to_bool_2val(p_val varchar2) return boolean;
  function yesno_to_bool_3val(p_val varchar2) return boolean;
  function yesno_to_bool(p_val varchar2) return boolean;
  function xyesno_to_bool(p_val varchar2) return boolean;

----------------------------------!---------------------------------------------
  function shrink_char(p_value varchar2, p_length number) return varchar2;
  function shrink_nchar(p_value nvarchar2, p_length number) return nvarchar2;

----------------------------------!---------------------------------------------
  function make_obsolete_user_name(p_user_name users.user_name%type) return users.user_name%type;

  procedure xcheck_user_id(p_user_id number);
  procedure xcheck_user_name(p_user_name users.user_name%type);
  function check_user_id(p_user_id number) return number;
  function check_user_name(p_user_name users.user_name%type) return number;

  function xget_user_id(p_user_name users.user_name%type) return number;
  function xget_user_name(p_user_id number) return users.user_name%type;
  function get_user_id(p_user_name users.user_name%type) return number;
  function get_user_name(p_user_id number) return users.user_name%type;

----------------------------------!---------------------------------------------
  function check_permission(p_perm_active number, p_perm_mask number) return number;

----------------------------------!---------------------------------------------
  function get_stock_group_own_perms_ii(p_user_id number, p_date date, p_stocks boolean, p_groups boolean, p_perm_mask number, p_inclusive boolean) return ct_node;
  function get_group_own_perms_i(p_user_id number, p_date date, p_perm_mask number, p_inclusive boolean) return ct_node;
  function get_stock_own_perms_i(p_user_id number, p_date date, p_perm_mask number, p_inclusive boolean) return ct_node;

  function get_group_hier_perms_i(p_group_own_perms ct_node, p_perm_mask number, p_inclusive boolean) return ct_node;
  function get_group_by_stck_hier_perms_i(p_group_hier_perms ct_node, p_stock_hier_perms ct_node, p_date date, p_perm_mask number, p_inclusive boolean) return ct_node;
  function get_stock_hier_perms_i(p_group_hier_perms ct_node, p_stock_own_perms ct_node, p_date date, p_perm_mask number, p_inclusive boolean) return ct_node;

----------------------------------!---------------------------------------------
  function get_parent_min_val_ct_node(p_coll ct_node, p_parent_id_new number, p_type_id_new number := null) return ct_node;
  function get_parent_max_val_ct_node(p_coll ct_node, p_parent_id_new number, p_type_id_new number := null) return ct_node;

  function walk_to_child_i(p_nodes ct_node, p_start_id number, p_start_is_parent boolean) return ct_node;
  function get_group_perms_i(p_user_id number, p_date date, p_perm_mask number, p_inclusive boolean, p_start_group_id number, p_start_is_parent boolean) return ct_node;
  function get_group_by_stock_perms_i(p_user_id number, p_date date, p_perm_mask number, p_inclusive boolean, p_start_group_id number, p_start_is_parent boolean) return ct_node;
  function get_stock_perms_i(p_user_id number, p_date date, p_perm_mask number, p_inclusive boolean) return ct_node;

----------------------------------!---------------------------------------------
  function iget_group_perms(p_user_id number, p_perm_mask number, p_date date, p_inclusive number, p_start_group_id number, p_start_is_parent number) return ct_node;
  function iget_group_by_stock_perms(p_user_id number, p_perm_mask number, p_date date, p_inclusive number, p_start_group_id number, p_start_is_parent number) return ct_node;
  function iget_stock_perms(p_user_id number, p_perm_mask number, p_date date, p_inclusive number) return ct_node;

  function iget_group_own_perms(p_user_id number, p_perm_mask number, p_date date, p_inclusive number) return ct_node;
  function iget_stock_own_perms(p_user_id number, p_perm_mask number, p_date date, p_inclusive number) return ct_node;

----------------------------------!---------------------------------------------
  function get_groups_with_descendants_i(p_group_ids ct_number) return ct_number;
  function get_groups_descendants_i(p_group_ids ct_number) return ct_number;
  function get_groups_with_ancestors_i(p_group_ids ct_number) return ct_number;
  function get_groups_ancestors_i(p_group_ids ct_number) return ct_number;

----------------------------------!---------------------------------------------
  function get_stock_ids_all(p_date date) return ct_number;
  function get_stock_codes_all(p_date date) return ct_nvarchar_s;

----------------------------------!---------------------------------------------
  function get_equipment_model_ids_all(p_date date) return ct_number;
  function get_equipment_model_codes_all(p_date date) return ct_nvarchar_s;

----------------------------------!---------------------------------------------
  function get_stock_id_i(p_code ct_nvarchar_s, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_number;
  function get_stock_code_i(p_id ct_number, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_nvarchar_s;

----------------------------------!---------------------------------------------
  function get_equipment_model_id_i(p_code ct_nvarchar_s, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_number;
  function get_equipment_model_code_i(p_id ct_number, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_nvarchar_s;

----------------------------------!---------------------------------------------
  procedure xcheck_stock_id(p_stock_id number, p_allow_dummy boolean := false);
  procedure xcheck_stock_code(p_stock_code nvarchar2);
  function check_stock_id(p_stock_id number, p_allow_dummy number) return number;
  function check_stock_code(p_stock_code nvarchar2) return number;

  function get_stock_id_fuzzy(p_stock_code ct_nvarchar_s, p_date date) return ct_number;
  function get_stock_code_fuzzy(p_stock_id ct_number, p_date date) return ct_nvarchar_s;

  function get_stock_id_exact(p_stock_code ct_nvarchar_s, p_date date) return ct_number;
  function get_stock_code_exact(p_stock_id ct_number, p_date date) return ct_nvarchar_s;

  function get_stock_id2(p_stock_code nvarchar2, p_date date) return number;
  function get_stock_id2_or_dummy(p_stock_code nvarchar2, p_date date) return number;
  function get_stock_code2(p_stock_id number, p_date date) return nvarchar2;

----------------------------------!---------------------------------------------
  function filter_stocks01(p_stock_ids ct_number, p_group_ids ct_number, p_date date, p_include_by_filter boolean) return ct_number;
  function ifilter_stocks01(p_stock_ids ct_number, p_group_ids ct_number, p_date date, p_include_by_filter number) return ct_number;

----------------------------------!---------------------------------------------
  function filter_groups01(p_group_ids ct_number, p_parent_group_ids ct_number, p_date date, p_include_by_filter boolean) return ct_number;
  function ifilter_groups01(p_group_ids ct_number, p_parent_group_ids ct_number, p_date date, p_include_by_filter number) return ct_number;

  function filter_groups02(p_group_ids ct_number, p_parent_group_id number, p_date date, p_include_by_filter boolean) return ct_number;
  function ifilter_groups02(p_group_ids ct_number, p_parent_group_id number, p_date date, p_include_by_filter number) return ct_number;

----------------------------------!---------------------------------------------
  function get_stock_by_code(p_code nvarchar2, p_date date) return stock%rowtype;
  function get_stock_by_id(p_id number, p_date date) return stock%rowtype;

  function get_doc_type_by_id(p_id number) return doc_type%rowtype;

----------------------------------!---------------------------------------------
  function get_doc_dir_type(p_doc_type_id number) return number;
  function xget_doc_dir_type(p_doc_type_id number) return number;

  function is_doc_only_for_ser(p_doc_type_id number) return boolean;
  function is_doc_changes_eq_status(p_doc_type_id number) return boolean;
  function has_doc_external_data(p_doc_type_id number) return boolean;
  function is_doc_eq_kept_inside_ss(p_doc_type_id number) return boolean;
  function is_doc_symmetric(p_doc_type_id number) return boolean;
  function is_doc_partitioned(p_doc_type_id number) return boolean;

  function is_doc_initially_finalized(p_doc_type_id number) return boolean;

  function is_doc_normal(p_doc_type_id number) return boolean;
  function is_doc_src_dst(p_doc_type_id number) return boolean;

  function is_doc_minus_src_detail(p_doc_type_id number) return boolean;

  --!_! OBSOLETE
  function get_doc_sign_old(p_doc_type_id number, p_stock_id number, p_stock_id_out number) return number;

----------------------------------!---------------------------------------------
  function get_valid_stock_codes(p_stock_codes ct_nvarchar_s, p_date date) return ct_nvarchar_s;
  function get_valid_stock_ids(p_stock_codes ct_nvarchar_s, p_date date) return ct_number;
  function get_invalid_stock_codes(p_stock_codes ct_nvarchar_s, p_date date) return ct_nvarchar_s;

----------------------------------!---------------------------------------------
  function get_stock_perms_ii(p_user_id number, p_stock_ids ct_number, p_date date, p_perm_mask number, p_trim_empty boolean, p_uniquelize boolean, p_absence_is_none boolean) return ct_number;
  function iget_stock_perms_ii(p_user_id number, p_stock_ids ct_number, p_date date, p_perm_mask number, p_trim_empty number, p_uniquelize number, p_absence_is_none number) return ct_number;

  function get_stock_perms_exact(p_user_id number, p_stock_ids ct_number, p_date date) return ct_number;
  function get_stock_perms2_exact(p_user_id number, p_stock_codes ct_nvarchar_s, p_date date) return ct_number;
  function get_stock_nnperms_exact(p_user_id number, p_stock_ids ct_number, p_date date) return ct_number;
  function get_stock_nnperms2_exact(p_user_id number, p_stock_codes ct_nvarchar_s, p_date date) return ct_number;

  function get_stock_perm(p_user_id number, p_stock_id number, p_date date) return number;
  function get_stock_perm2(p_user_id number, p_stock_code nvarchar2, p_date date) return number;
  function get_stock_nnperm(p_user_id number, p_stock_id number, p_date date) return number;
  function get_stock_nnperm2(p_user_id number, p_stock_code nvarchar2, p_date date) return number;

----------------------------------!---------------------------------------------
  function get_avail_stock_ids(p_user_id number, p_perm_mask number, p_date date) return ct_number;
  function get_avail_stock_codes(p_user_id number, p_perm_mask number, p_date date) return ct_nvarchar_s;
  function get_avail_stock_ids2(p_user_id number, p_perm_mask number, p_stock_ids ct_number, p_date date) return ct_number;
  function get_avail_stock_codes2(p_user_id number, p_perm_mask number, p_stock_codes ct_nvarchar_s, p_date date) return ct_nvarchar_s;
  function get_avail_stock_ids3(p_user_id number, p_perm_mask number, p_stock_codes ct_nvarchar_s, p_date date) return ct_number;
  function get_avail_stock_codes3(p_user_id number, p_perm_mask number, p_stock_ids ct_number, p_date date) return ct_nvarchar_s;

----------------------------------!---------------------------------------------
  function get_avail_group_ids(p_user_id number, p_perm_mask number, p_date date, p_start_group_id number, p_start_is_parent boolean) return ct_number;
  function get_avail_group_ids2(p_user_id number, p_perm_mask number, p_date date) return ct_number;

----------------------------------!---------------------------------------------
  function is_avail_stock(p_user_id number, p_perm_mask number, p_stock_id number, p_date date) return boolean;
  function is_avail_stock2(p_user_id number, p_perm_mask number, p_stock_code nvarchar2, p_date date) return boolean;

  function iis_avail_stock(p_user_id number, p_perm_mask number, p_stock_id number, p_date date) return number;
  function iis_avail_stock2(p_user_id number, p_perm_mask number, p_stock_code nvarchar2, p_date date) return number;

  procedure xis_avail_stock(p_user_id number, p_perm_mask number, p_stock_id number, p_date date);
  procedure xis_avail_stock2(p_user_id number, p_perm_mask number, p_stock_code nvarchar2, p_date date);

----------------------------------!---------------------------------------------
  function get_unavail_stock_ids(p_user_id number, p_perm_mask number, p_date date) return ct_number;
  function get_unavail_stock_codes(p_user_id number, p_perm_mask number, p_date date) return ct_nvarchar_s;
  function get_unavail_stock_ids2(p_user_id number, p_perm_mask number, p_stock_ids ct_number, p_date date) return ct_number;
  function get_unavail_stock_codes2(p_user_id number, p_perm_mask number, p_stock_codes ct_nvarchar_s, p_date date) return ct_nvarchar_s;
  function get_unavail_stock_ids3(p_user_id number, p_perm_mask number, p_stock_codes ct_nvarchar_s, p_date date) return ct_number;
  function get_unavail_stock_codes3(p_user_id number, p_perm_mask number, p_stock_ids ct_number, p_date date) return ct_nvarchar_s;

----------------------------------!---------------------------------------------
  function GS_check_stock_in_perm return boolean;
  function GS_ignore_model_type return boolean;

----------------------------------!---------------------------------------------
  function get_count_ct_model(p_coll ct_model) return number;
  function get_count_ct_node(p_coll ct_node) return number;

  procedure add_ct_model_val(p_coll in out nocopy ct_model, p_val ot_model);
  procedure add_ct_node_val(p_coll in out nocopy ct_node, p_val ot_node);

  procedure add_ct_model(p_coll in out nocopy ct_model, p_coll_add ct_model);
  procedure add_ct_node(p_coll in out nocopy ct_node, p_coll_add ct_node);

  procedure dbg_ct_model(p_coll ct_model, p_label varchar2 := null);
  procedure dbg_ct_node(p_coll ct_node, p_label varchar2 := null);

----------------------------------!---------------------------------------------
  function filter_ct_model(p_vals ct_model, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_model;
  function filter_ct_node(p_vals ct_node, p_ids_pivot ct_number, p_ids_filter ct_number, p_include_by_filter boolean) return ct_node;

  function filter_ct_model_1val(p_vals ct_model, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_model;
  function filter_ct_node_1val(p_vals ct_node, p_ids_pivot ct_number, p_id_filter_val number, p_include_by_filter boolean) return ct_node;

  function filter_val_ct_model(p_vals ct_model, p_filter_vals ct_model, p_include_by_filter boolean) return ct_model;
  function filter_val_ct_node(p_vals ct_node, p_filter_vals ct_node, p_include_by_filter boolean) return ct_node;

  function filter_val_ct_model_1val(p_vals ct_model, p_filter_val ot_model, p_include_by_filter boolean) return ct_model;
  function filter_val_ct_node_1val(p_vals ct_node, p_filter_val ot_node, p_include_by_filter boolean) return ct_node;

  function mark_ct_model_has_serial(p_vals ct_model, p_marker_vals ct_varchar_s, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number;

  function mark_val_ct_model_has_serial(p_vals ct_model, p_marker_val varchar2, p_mark_value number := util_pkg.c_true, p_unmark_value number := util_pkg.c_false) return ct_number;

  function get_marked_ct_model(p_vals ct_model, p_marks ct_number, p_trim_empty boolean, p_mark_value number := util_pkg.c_true, p_no_value ot_model := null) return ct_model;
  function get_marked_ct_node(p_vals ct_node, p_marks ct_number, p_trim_empty boolean, p_mark_value number := util_pkg.c_true, p_no_value ot_node := null) return ct_node;

  function get_by_pos_ct_model(p_vals ct_model, p_positions ct_number, p_trim_empty boolean, p_no_value ot_model := null) return ct_model;
  function get_by_pos_ct_node(p_vals ct_node, p_positions ct_number, p_trim_empty boolean, p_no_value ot_node := null) return ct_node;

----------------------------------!---------------------------------------------
  procedure XCheckP_ct_model(p_param ct_model, p_label varchar2 := null);
  procedure XCheckP_ct_node(p_param ct_node, p_label varchar2 := null);

  function CheckP_ct_model(p_param ct_model) return boolean;
  function CheckP_ct_node(p_param ct_node) return boolean;

  procedure XCheckP_FS_ct_model(p_param ct_model, p_label varchar2 := null);
  procedure XCheckP_FS_ct_node(p_param ct_node, p_label varchar2 := null);

  function is_nulls_ct_model(p_vals ct_model) return boolean;
  function is_nulls_ct_node(p_vals ct_node) return boolean;

  procedure xis_nulls_ct_model(p_vals ct_model, p_label varchar2 := null);
  procedure xis_nulls_ct_node(p_vals ct_node, p_label varchar2 := null);

----------------------------------!---------------------------------------------
  procedure XCheck_doc_type(p_doc_type_id number);
  procedure XCheck_doc_dir_type(p_doc_dir_type number);
  procedure XCheck_Stocks(p_doc_dir_type number, p_stock_id_out number, p_stock_id_in number);

----------------------------------!---------------------------------------------
  procedure XCheck_Stock_Perms(p_user_id number, p_stock_id number, p_perm_mask number);
  procedure XCheck_Doc_Perms(p_user_id number, p_doc_type_id number, p_action_id number);

  function check_user_doc_permitting(p_user_id number, p_document_type_id number, p_action_id number) return number;

----------------------------------!---------------------------------------------
  function XFinish_To_Doc_Status(p_finish boolean) return number;
  function XPartition_To_Doc_Type(p_partition boolean) return number;
  procedure XCheck_Models(p_models1 ct_model, p_models2 ct_model);

  function xhas_model_serial(p_model ot_model) return boolean;

----------------------------------!---------------------------------------------
  function get_ct_model_i(p_code ct_varchar_s, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_model;
  function get_ct_model2_i(p_id ct_number, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_model;

  function get_ct_model_codes(p_coll ct_model) return ct_varchar_s;
  function get_ct_model_ids(p_coll ct_model) return ct_number;
  function get_ct_model_type_ids(p_coll ct_model) return ct_number;

----------------------------------!---------------------------------------------
  function get_ct_model_fuzzy(p_code ct_varchar_s, p_date date) return ct_model;
  function get_ct_model2_fuzzy(p_id ct_number, p_date date) return ct_model;

  function get_ct_model_exact(p_code ct_varchar_s, p_date date) return ct_model;
  function get_ct_model2_exact(p_id ct_number, p_date date) return ct_model;

  function get_ot_model(p_code varchar2, p_date date) return ot_model;
  function get_ot_model2(p_id number, p_date date) return ot_model;

  function filter_ct_model01(p_model ct_model, p_eq_type_id ct_number, p_include_by_filter boolean) return ct_model;
  function filter_ct_model02(p_model ct_model, p_eq_type_code ct_varchar_s, p_include_by_filter boolean) return ct_model;

----------------------------------!---------------------------------------------
  function get_model_ids4type_codes(p_eq_type_codes ct_varchar_s, p_date date) return ct_number;
  function get_model_ids4type_code(p_eq_type_code varchar2, p_date date) return ct_number;

----------------------------------!---------------------------------------------
  function make_sn_from_full_number(p_full_number ct_nvarchar_s) return ct_nvarchar_s;
  function make_sn_from_full_number2(p_full_number nvarchar2) return nvarchar2;

  function get_sims_full_number_i(p_serial_number ct_nvarchar_s, p_trim_empty boolean, p_uniquelize boolean) return ct_nvarchar_s;

  function get_sims_full_number(p_serial_number ct_nvarchar_s) return ct_nvarchar_s;

  function get_sims_sn(p_sim_id ct_number, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_varchar_s;
  function get_sims_sn2(p_sim_id number) return varchar2;

  function get_sims_id4serial_number(p_serial_number ct_nvarchar_s, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_sims_id4serial_number2(p_serial_number nvarchar2) return number;

  function get_ss_model_id(p_seria_start ct_nvarchar_s, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_ss_model_id2(p_seria_start nvarchar2) return number;

----------------------------------!---------------------------------------------
  procedure XCheck_serial_number(p_serial_number nvarchar2, p_label varchar2 := null);
  procedure XCheck_seria(p_seria_start nvarchar2, p_seria_end nvarchar2);

  function get_serial_non_digits(p_serial_number nvarchar2) return nvarchar2;
  function is_serial_only_digits(p_serial_number nvarchar2) return boolean;
  function get_serial_as_number(p_serial_number nvarchar2) return integer;

  function xget_seria_quantity(p_seria_start nvarchar2, p_seria_end nvarchar2) return integer;

----------------------------------!---------------------------------------------
  function get_model_type_id(p_model_id ct_number, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_model_type_id2(p_model_id number, p_date date) return varchar2;

----------------------------------!---------------------------------------------
  function split_ranges_i(p_begin ct_number, p_end ct_number, p_uniquelize boolean) return ct_number;

  --!_!function split_ranges(p_begin ct_number, p_end ct_number) return ct_number;
  --!_!function split_ranges2(p_begin ct_varchar_s, p_end ct_varchar_s) return ct_varchar_s;
  function split_ranges3(p_begin ct_nvarchar_s, p_end ct_nvarchar_s) return ct_nvarchar_s;

----------------------------------!---------------------------------------------
  function validate_link_status(p_link_status number) return number;
  function map_link_status(p_link_status number) return boolean;

----------------------------------!---------------------------------------------
  procedure get_seria_not_null(p_seria_start in out nocopy nvarchar2, p_seria_end in out nocopy nvarchar2);

----------------------------------!---------------------------------------------
  function get_ri_phone_number_i(p_full_number ct_varchar_s, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_varchar_s;
  function get_ri_phone_number(p_full_number ct_varchar_s, p_date date) return ct_varchar_s;
  function get_ri_phone_number2(p_full_number varchar2, p_date date) return varchar2;
  function iget_ri_phone_number2(p_full_number varchar2, p_date date) return varchar2;

----------------------------------!---------------------------------------------
  function get_last_dh_i(p_seria_start ct_nvarchar_s, p_seria_end ct_nvarchar_s, p_trim_empty boolean) return ct_number;
  function get_last_dh2_i(p_serial_number ct_nvarchar_s, p_trim_empty boolean) return ct_number;

  function get_last_dh(p_seria_start ct_nvarchar_s, p_seria_end ct_nvarchar_s) return ct_number;
  function get_last_dh2(p_serial_number ct_nvarchar_s) return ct_number;

----------------------------------!---------------------------------------------
  function iget_last_dh(p_seria_start ct_nvarchar_s, p_seria_end ct_nvarchar_s, p_trim_empty number) return ct_number;
  function iget_last_dh2(p_serial_number ct_nvarchar_s, p_trim_empty number) return ct_number;

----------------------------------!---------------------------------------------
  function get_count_ct_range(p_coll ct_range) return number;

  procedure fill_ct_range(p_coll in out nocopy ct_range, p_val ot_range);
  procedure resize_ct_range(p_coll in out nocopy ct_range, p_size number);
  function make_ct_range(p_count number, p_val ot_range) return ct_range;
  procedure add_ct_range_val(p_coll in out nocopy ct_range, p_val ot_range);

  function filter_val_ct_range(p_vals ct_range, p_filter_vals ct_range, p_include_by_filter boolean) return ct_range;
  function filter_val_ct_range_1val(p_vals ct_range, p_filter_val ot_range, p_include_by_filter boolean) return ct_range;

  function filter_val_ct_range_num2(p_vals ct_range, p_filter_vals ct_number, p_include_by_filter boolean) return ct_range;
  function filter_val_ct_range_num2_1val(p_vals ct_range, p_filter_val number, p_include_by_filter boolean) return ct_range;

  function make_ot_range
  (
    p_val1 nvarchar2,
    p_val2 nvarchar2,
    p_num1 number,
    p_num2 number,
    p_num3 number,
    p_dat1 date,
    p_num4 number
  ) return ot_range;

  function make_ot_range1
  (
    p_range_start nvarchar2,
    p_range_end nvarchar2,
    p_model_id number,
    p_id_original number,
    p_quantity number,
    p_valid_until date
  ) return ot_range;

  function make_ct_range0
  (
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s,
    p_num1 ct_number,
    p_num2 ct_number,
    p_num3 ct_number,
    p_dat1 ct_date,
    p_num4 ct_number
  ) return ct_range;

  function make_ct_range1
  (
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s
  ) return ct_range;

  function make_ct_range2
  (
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s,
    p_num1 ct_number
  ) return ct_range;

  function make_ct_range3
  (
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s,
    p_num1 ct_number,
    p_num2 ct_number
  ) return ct_range;

  function make_ct_range_with_length
  (
    p_val1 ct_nvarchar_s,
    p_val2 ct_nvarchar_s,
    p_num1 ct_number
  ) return ct_range;

----------------------------------!---------------------------------------------
  function get_first_error_pos(p_error_code ct_number) return number;
  procedure get_first_error(p_error_code ct_number, p_error_message ct_varchar, p_error_code2 out number, p_error_message2 out varchar2);

  procedure setup_common_error(p_main_count number, p_error_code number, p_error_message varchar2, p_error_code2 out ct_number, p_error_message2 out ct_varchar, p_allow_nulls boolean := false);

  function make_group_error_message
  (
    p_problem_id number,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_group_error_message2
  (
    p_problem_id number,
    p_problem_code varchar2,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_group_error_message3
  (
    p_problem_id number,
    p_problem_code varchar2,
    p_problem_name varchar2,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_group_error_message4
  (
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_error_message4val_char
  (
    p_problem_value varchar2,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_error_message4val_char2
  (
    p_problem_value1 varchar2,
    p_problem_value2 varchar2,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_error_message4val_num
  (
    p_problem_value number,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  function make_error_message4val_num2
  (
    p_problem_value1 number,
    p_problem_value2 number,
    p_problem_index number,
    p_group_error_code number,
    p_group_error_message varchar2
  ) return varchar2;

  procedure xcheck_group_error_params
  (
    p_problem_id number,
    p_problem_index number,
    p_group_start number,
    p_group_size number,
    p_group_error_code number,
    p_group_error_message varchar2,
    p_error_code ct_number,
    p_error_message ct_varchar,
    p_main_count out number
  );

  procedure setup_group_error_for_grp_head
  (
    p_problem_id number,
    p_problem_index number,
    p_group_start number,
    p_group_size number,
    p_group_error_code number,
    p_group_error_message varchar2,
    p_error_code in out nocopy ct_number,
    p_error_message in out nocopy ct_varchar
  );

  procedure setup_group_error_for_all
  (
    p_problem_id number,
    p_problem_index number,
    p_group_start number,
    p_group_size number,
    p_group_error_code number,
    p_group_error_message varchar2,
    p_error_code in out nocopy ct_number,
    p_error_message in out nocopy ct_varchar
  );

  procedure setup_error_by_marks0
  (
    p_marks ct_number,
    p_pivot ct_number,
    p_error_code number,
    p_error_message varchar2,
    p_mark_value number := util_pkg.c_true,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
  );

  procedure setup_error_by_marks
  (
    p_marks ct_number,
    p_error_code number,
    p_error_message varchar2,
    p_mark_value number := util_pkg.c_true,
    p_error_codes in out nocopy ct_number,
    p_error_messages in out nocopy ct_varchar
  );

  procedure setup_error_codes_by_marks0
  (
    p_marks ct_number,
    p_pivot ct_number,
    p_error_code number,
    p_mark_value number := util_pkg.c_true,
    p_error_codes in out nocopy ct_number
  );

  procedure setup_error_codes_by_marks
  (
    p_marks ct_number,
    p_error_code number,
    p_mark_value number := util_pkg.c_true,
    p_error_codes in out nocopy ct_number
  );

  procedure xcheck_has_error
  (
      p_break_on_error boolean,
      p_error_codes ct_number,
      p_error_messages ct_varchar
  );

----------------------------------!---------------------------------------------
  function Handle_Wrong_Equipment_Str(p_seria_start varchar2, p_seria_end varchar2, p_equipment_model_id varchar2, p_label varchar2) return varchar2;

----------------------------------!---------------------------------------------
  procedure get_result_cursor001(p_stock_ids ct_number, p_date date, p_result out sys_refcursor);
  procedure get_result_cursor002(p_group_ids ct_number, p_result out sys_refcursor);
  procedure get_result_cursor003(p_stock_perms ct_node, p_date date, p_result out sys_refcursor);
  procedure get_result_cursor004(p_stock_ids ct_number, p_stock_perms ct_number, p_user_id number, p_date date, p_trim_empty boolean, p_result out sys_refcursor);
  procedure get_result_cursor005(p_stock_id number, p_stock_perm number, p_user_id number, p_result out sys_refcursor);
  procedure get_result_cursor007(p_stock_codes ct_nvarchar_s, p_stock_perms ct_number, p_date date, p_trim_empty boolean, p_result out sys_refcursor);
  procedure get_result_cursor008(p_stock_ids ct_number, p_date date, p_result out sys_refcursor);

----------------------------------!---------------------------------------------

end;
/
