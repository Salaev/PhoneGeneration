CREATE PACKAGE BODY pkg_constants
IS
--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 25.09.2006 17:13
-- Purpose : Используемые в исходном коде константы
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ----------------------------------------------
-- Petr Skripnik   09.11.2006  Изменен
-- Petr Skripnik   14.11.2006  Изменен
-- Skripnik Petr   16.04.2007  version 1.11.8.2
-- Skripnik Petr   10.07.2007  version 1.11.9.0
--------------------------------------------------------------------------------
   --имя пакета
   pkg_name     CONSTANT NVARCHAR2 (50) := 'pkg_constants.';
   --имя контекста
   ctx          CONSTANT VARCHAR2 (50)  := 'ctx_constants' || pkg_constants.ctx_sufix;
   --имя контекста для получения констант видимых для всех сессий
   ctx_global   CONSTANT VARCHAR2 (50)  := 'ctx_constants_global' || pkg_constants.ctx_sufix;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.10.2006 10:34
-- Editor  :
-- Changed :
-- Purpose : Задает значение контексту
--------------------------------------------------------------------------------
   PROCEDURE set_context (p_name IN VARCHAR2, p_value IN VARCHAR2)
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'set_context';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      DBMS_SESSION.set_context (ctx, p_name, p_value);
      pkg_db_util.DEBUG (prc_name, p_name || ' := ' || p_value, pkg_name);
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END set_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 21.05.2007 11:44
-- Editor  :
-- Changed :
-- Purpose : Задает значение контексту
--------------------------------------------------------------------------------
   PROCEDURE set_context_global (p_name IN VARCHAR2, p_value IN VARCHAR2)
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'set_context_global';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      DBMS_SESSION.set_context (ctx_global, p_name, p_value);
      pkg_db_util.DEBUG (prc_name, p_name || ' := ' || p_value, pkg_name);
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END set_context_global;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.10.2006 10:34
-- Editor  :
-- Changed :
-- Purpose : Возвращает значение контекста
--------------------------------------------------------------------------------
   FUNCTION get_context (p_name IN VARCHAR2)
      RETURN VARCHAR2
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_context';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      RETURN SYS_CONTEXT (ctx, p_name);
      pkg_db_util.DEBUG (prc_name, p_name, pkg_name);
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 11.05.2007 11:45
-- Editor  :
-- Changed :
-- Purpose : Возвращает значение контекста
--------------------------------------------------------------------------------
   FUNCTION get_context_global (p_name IN VARCHAR2)
      RETURN VARCHAR2
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_context_global';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      RETURN SYS_CONTEXT (ctx_global, p_name);
      pkg_db_util.DEBUG (prc_name, p_name, pkg_name);
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_context_global;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.10.2006 10:34
-- Editor  :
-- Changed :
-- Purpose : Очищает контекст
--------------------------------------------------------------------------------
   PROCEDURE clear_context
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'clear_context';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      DBMS_SESSION.clear_context (ctx, RTRIM (pkg_name, '.'));
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END clear_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 11.05.2007 11:54
-- Editor  :
-- Changed :
-- Purpose : Очищает контекст
--------------------------------------------------------------------------------
   PROCEDURE clear_context_global
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'clear_context_global';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      DBMS_SESSION.clear_context (ctx_global, RTRIM (pkg_name, '.'));
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END clear_context_global;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.10.2006 10:34
-- Editor  :
-- Changed :
-- Purpose : Просмотрим контекст
--------------------------------------------------------------------------------
   PROCEDURE list_context
   IS
      l_list              DBMS_SESSION.appctxtabtyp;
      l_size              NUMBER;
      l_strline           NVARCHAR2 (255);
      i                   PLS_INTEGER;
      prc_name   CONSTANT NVARCHAR2 (100)           := pkg_name || 'list_context';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      DBMS_SESSION.list_context (l_list, l_size);

      FOR i IN 1 .. l_list.COUNT
      LOOP
         l_strline :=
                    l_list (i).namespace || ': ' || l_list (i).ATTRIBUTE || '=' || l_list (i).VALUE;
         pkg_db_util.DEBUG (prc_name, l_strline, pkg_name);
      END LOOP;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END list_context;
END;
/
