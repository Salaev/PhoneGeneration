CREATE package body util_coll_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_marked_ol_ct_number(p_vals ct_number, p_marks ct_number) return ct_number
is
begin
  ------------------------------
  return util_pkg.get_marked_ct_number(p_vals => p_vals, p_marks => p_marks, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ol_ct_date(p_vals ct_date, p_marks ct_number) return ct_date
is
begin
  ------------------------------
  return util_pkg.get_marked_ct_date(p_vals => p_vals, p_marks => p_marks, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ol_ct_varchar_s(p_vals ct_varchar_s, p_marks ct_number) return ct_varchar_s
is
begin
  ------------------------------
  return util_pkg.get_marked_ct_varchar_s(p_vals => p_vals, p_marks => p_marks, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ol_ct_varchar(p_vals ct_varchar, p_marks ct_number) return ct_varchar
is
begin
  ------------------------------
  return util_pkg.get_marked_ct_varchar(p_vals => p_vals, p_marks => p_marks, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ol_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marks ct_number) return ct_nvarchar_s
is
begin
  ------------------------------
  return util_pkg.get_marked_ct_nvarchar_s(p_vals => p_vals, p_marks => p_marks, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_ol_ct_nvarchar(p_vals ct_nvarchar, p_marks ct_number) return ct_nvarchar
is
begin
  ------------------------------
  return util_pkg.get_marked_ct_nvarchar(p_vals => p_vals, p_marks => p_marks, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unmarked_ol_ct_number(p_vals ct_number, p_marks ct_number) return ct_number
is
begin
  ------------------------------
  return util_pkg.get_marked_ct_number(p_vals => p_vals, p_marks => p_marks, p_trim_empty => true, p_mark_value => util_pkg.c_false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unmarked_ol_ct_date(p_vals ct_date, p_marks ct_number) return ct_date
is
begin
  ------------------------------
  return util_pkg.get_marked_ct_date(p_vals => p_vals, p_marks => p_marks, p_trim_empty => true, p_mark_value => util_pkg.c_false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unmarked_ol_ct_varchar_s(p_vals ct_varchar_s, p_marks ct_number) return ct_varchar_s
is
begin
  ------------------------------
  return util_pkg.get_marked_ct_varchar_s(p_vals => p_vals, p_marks => p_marks, p_trim_empty => true, p_mark_value => util_pkg.c_false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unmarked_ol_ct_varchar(p_vals ct_varchar, p_marks ct_number) return ct_varchar
is
begin
  ------------------------------
  return util_pkg.get_marked_ct_varchar(p_vals => p_vals, p_marks => p_marks, p_trim_empty => true, p_mark_value => util_pkg.c_false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unmarked_ol_ct_nvarchar_s(p_vals ct_nvarchar_s, p_marks ct_number) return ct_nvarchar_s
is
begin
  ------------------------------
  return util_pkg.get_marked_ct_nvarchar_s(p_vals => p_vals, p_marks => p_marks, p_trim_empty => true, p_mark_value => util_pkg.c_false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_unmarked_ol_ct_nvarchar(p_vals ct_nvarchar, p_marks ct_number) return ct_nvarchar
is
begin
  ------------------------------
  return util_pkg.get_marked_ct_nvarchar(p_vals => p_vals, p_marks => p_marks, p_trim_empty => true, p_mark_value => util_pkg.c_false);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_by_pos_ol_ct_number(p_vals ct_number, p_positions ct_number) return ct_number
is
begin
  ------------------------------
  return util_pkg.get_by_pos_ct_number(p_vals => p_vals, p_positions => p_positions, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ol_ct_date(p_vals ct_date, p_positions ct_number) return ct_date
is
begin
  ------------------------------
  return util_pkg.get_by_pos_ct_date(p_vals => p_vals, p_positions => p_positions, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ol_ct_varchar_s(p_vals ct_varchar_s, p_positions ct_number) return ct_varchar_s
is
begin
  ------------------------------
  return util_pkg.get_by_pos_ct_varchar_s(p_vals => p_vals, p_positions => p_positions, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ol_ct_varchar(p_vals ct_varchar, p_positions ct_number) return ct_varchar
is
begin
  ------------------------------
  return util_pkg.get_by_pos_ct_varchar(p_vals => p_vals, p_positions => p_positions, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ol_ct_nvarchar_s(p_vals ct_nvarchar_s, p_positions ct_number) return ct_nvarchar_s
is
begin
  ------------------------------
  return util_pkg.get_by_pos_ct_nvarchar_s(p_vals => p_vals, p_positions => p_positions, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_by_pos_ol_ct_nvarchar(p_vals ct_nvarchar, p_positions ct_number) return ct_nvarchar
is
begin
  ------------------------------
  return util_pkg.get_by_pos_ct_nvarchar(p_vals => p_vals, p_positions => p_positions, p_trim_empty => true);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function trim_ct_varchar_s(p_coll ct_varchar_s) return ct_varchar_s
is
  v_res ct_varchar_s;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_coll);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := p_coll;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := trim(v_res(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function trim_ct_varchar(p_coll ct_varchar) return ct_varchar
is
  v_res ct_varchar;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar(p_coll);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := p_coll;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := trim(v_res(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function trim_ct_nvarchar_s(p_coll ct_nvarchar_s) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_coll);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := p_coll;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := trim(v_res(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function trim_ct_nvarchar(p_coll ct_nvarchar) return ct_nvarchar
is
  v_res ct_nvarchar;
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar(p_coll);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := p_coll;
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i) := trim(v_res(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
