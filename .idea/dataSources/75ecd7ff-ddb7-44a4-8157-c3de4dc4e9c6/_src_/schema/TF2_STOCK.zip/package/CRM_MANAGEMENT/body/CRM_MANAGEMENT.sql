CREATE PACKAGE BODY crm_management IS
/*******************************************************************************
   <name>          EQUIPMENT_MODEL__Get
   <author>        Petar Ulic
   <version>       1.1   06.12.2003 basic Oracle implementation
                   1.0   10.11.2003 basic MS SQL version
   <Description>
   <Prerequisites>
   <Application>   Stock Management
   <Parameters>    p_id NUMBER
                   p_type_id NUMBER
                   p_equipment_model_rec OUT sys_refcursor
                   p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                              - else returns error identification
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ------------------------------------------
-- Petr Skripnik   10.11.2006  Изменен
-- Skripnik Petr   10.07.2007  version 1.11.9.0
*******************************************************************************/
   pkg_name   CONSTANT NVARCHAR2 (50) := 'crm_management.';

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE equipment_model__get (
      p_id                          NUMBER,
      p_type_id                     NUMBER,
      p_equipment_model_rec   OUT   sys_refcursor,
      p_error_code            OUT   NUMBER
   )
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_equipment_model_rec FOR
         SELECT "Code" "EquipmentCode", "Name" "EquipmentName"
           FROM v_equipment_model
          WHERE (("Id" = p_id) OR (p_id = 0)) AND (("Type Id" = p_type_id) OR (p_type_id = 0));
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END equipment_model__get;

/****************************************************************************
<name>          SIMS__Ins
<author>        Dejan Spegar
    Olga Petrova
<version>   3.0 Dejan Spegar
        2.0   21.03.2005 Petrova rewrite
    1.0   10.02.2004 basic Oracle implementation
Skripnik Petr 09.04.2007 (SELECT COUNT (ID)INTO p_stockcount...)->(IF pkg_equipment.chk_cross_series_all...)
<Description>   Bulk Insert sim card into SIMS table
<Prerequisites>
<Application>   crm_management
<Parameters>
****************************************************************************/
   PROCEDURE sims__bulk_ins (
      p_serial_number               aaserialnum,
      p_control_number              aacontrolnum,
      p_status                      aastatus,
      p_single_equipment_id   OUT   aaeqid,
      p_length                      NUMBER,
      p_handle_tran                 CHAR := 'Y',
      p_error_code            OUT   NUMBER
   )
   IS
      p_curr_sim     NUMBER;
      p_count        NUMBER;
   BEGIN
      p_error_code := 0;

      util_loc_pkg.touch_number(p_status.count);

      FOR i IN 1 .. p_length
      LOOP
         SELECT COUNT (*)
           INTO p_count
           FROM sims
          WHERE serial_number = p_serial_number (i);

         -- dspegar 20.12.2005: removed
         -- AND    EQUIPMENT_CODE=p_Equipment_code(i);
         IF p_count > 0
         THEN
            --Added 09.04.2007 Skripnik Petr
            --Проверяем пересечение серий оборудования
            IF pkg_equipment.chk_cross_series_all (p_serial_number (i), p_serial_number (i), 0)
            THEN
               p_curr_sim := 0;
               p_error_code := 1;
            ELSE
               UPDATE sims
                  SET status = 1
                WHERE serial_number = p_serial_number (i);

               SELECT ID
                 INTO p_curr_sim
                 FROM sims
                WHERE serial_number = p_serial_number (i);
            END IF;
         ELSE
            INSERT INTO sims
                 VALUES (0, p_serial_number (i), p_control_number (i), 1,
                         p_serial_number (i) || p_control_number (i));

            SELECT s_sims.CURRVAL
              INTO p_curr_sim
              FROM DUAL;
         END IF;

         p_single_equipment_id (i) := p_curr_sim;
      END LOOP;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   END sims__bulk_ins;

/****************************************************************************
<name>          STOCK_STATE__Get_Equipment
<author>        Dejan Spegar
    Olga Petrova
<version>       2.0   23.03.2005 Petrova - rewrite
    1.0   16.03.2004 basic Oracle implementation
-- 17.04.2007 Skripnik Petr Удалены колонки MIN_VALUE e ALARM_ID
-- 08.05.2007 Anoev Maxim удалены AND (reserved = p_reserved OR reserved IS NULL)
<Description>   Gets specified number of equipment
<Prerequisites>
<Application>   crm_management
<Parameters>    p_stock_code NVARCHAR2
                p_equipment_code NVARCHAR2
                p_quantity NUMBER
                p_stock_state_rec OUT sys_refcursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE stock_state__get_equipment (
      p_stock_code              NVARCHAR2,
      p_equipment_code          NVARCHAR2,
      p_quantity                NUMBER,
      p_reserved                NVARCHAR2,
      p_stock_state_rec   OUT   sys_refcursor,
      p_error_code        OUT   NUMBER
   )
   IS
      equipmentid   NUMBER;
      stockid       NUMBER;
   BEGIN
      p_error_code := 0;
      util_loc_pkg.touch_varchar(p_reserved);
      equipmentid := -1;
      stockid := -1;

      IF p_stock_code IS NOT NULL
      THEN
         SELECT NVL((SELECT ID
                        FROM stock
                       WHERE code = p_stock_code), NULL)
           INTO stockid
           FROM DUAL;
      END IF;

      IF p_equipment_code IS NOT NULL
      THEN
         SELECT NVL((SELECT equipment_model_id
                        FROM equipment_model
                       WHERE equipment_model_code = p_equipment_code), NULL)
           INTO equipmentid
           FROM DUAL;
      END IF;

      IF stockid = -1
      THEN
         p_error_code := 90005;
      END IF;

      IF (equipmentid = -1) AND (p_equipment_code IS NOT NULL)
      THEN
         p_error_code := 90006;
      END IF;

      IF p_error_code = 0
      THEN
         OPEN p_stock_state_rec FOR
            SELECT ID, stock_id, equipment_model_id, seria_start, seria_end, quantity_onstock,
                   quantity_reserved, quantity_announced, doc_header_id, create_date, status,
                   equipment_type_id, reserved, user_comment, equipment_batch_id,
                   is_nonsingle_series
              FROM stock_state
             WHERE equipment_model_id = equipmentid
               AND stock_id = stockid
               AND quantity_onstock = 1
               AND status = 1
               AND ROWNUM <= p_quantity;
      ELSE
         OPEN p_stock_state_rec FOR
            SELECT *
              FROM DUAL;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END stock_state__get_equipment;

/****************************************************************************
<name>          SIMS_Upd_Code
<author>        Igor Holod
    Olga Petrova
<version>       2.0    23.03.2005 Petrova changed
    1.0   30.11.2004 basic Oracle implementation
-- Editor  : 05.02.2007 Skripnik Petr
-- Changed : 05.02.2007 TO_NUMBER (p_seria_start) -> p_seria_start.
--           For support of equipment with non-numeric serial numbers
-- 13.07.2009 Smirnov Victor - hints (index_asc(ss, I_STOCK_STATE_STOCK_ID) etc)
<Description>
<Prerequisites>
<Application>   crm_management
<Parameters>
****************************************************************************/
   PROCEDURE scratchcardexist (
      p_stockid             NVARCHAR2,
      p_seria_start         NVARCHAR2,
      p_seria_end           NVARCHAR2,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   AS
      v_sp_name varchar2(30);
      keocardmodelcount   NUMBER;
      keocardcount        NUMBER;
      stockid             NUMBER;
   BEGIN
      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      p_error_code := 0;

      IF p_seria_start > p_seria_end
      THEN
         p_error_code := 11;
      ELSE
         SELECT NVL((SELECT ID
                        FROM stock
                       WHERE code = p_stockid), NULL)
           INTO stockid
           FROM DUAL;

         IF stockid IS NULL
         THEN
            p_error_code := 12;
         END IF;
      END IF;

      IF p_error_code = 0
      THEN
         SELECT COUNT (*)
           INTO keocardmodelcount
           FROM (SELECT /*+ index_asc(ss, I_STOCK_STATE_STOCK_ID)*/
                          equipment_model_id
                     FROM stock_state ss
                    WHERE stock_id = stockid
                      AND seria_start BETWEEN p_seria_start AND p_seria_end
                      AND LENGTH (seria_start) = LENGTH (p_seria_start)
                      AND LENGTH (seria_start) = LENGTH (p_seria_end)
                      AND quantity_onstock = 1
                      AND (equipment_type_id = 1 OR equipment_type_id = 7)
                 GROUP BY equipment_model_id);

         IF keocardmodelcount <> 1
         THEN
            p_error_code := 14;
         ELSE
            SELECT /*+ index_asc(ss, I_STOCK_STATE_STOCK_ID)*/
                   SUM (quantity_onstock)
              INTO keocardcount
              FROM stock_state ss
             WHERE stock_id = stockid
               AND seria_start BETWEEN p_seria_start AND p_seria_end
               AND LENGTH (seria_start) = LENGTH (p_seria_start)
               AND LENGTH (seria_start) = LENGTH (p_seria_end)
               AND quantity_onstock = 1
               AND (equipment_type_id = 1 OR equipment_type_id = 7);

            --Так как идет работа с картами преобразование в нумбер - валидно
            IF (TO_NUMBER (p_seria_end) - TO_NUMBER (p_seria_start) + 1) <> keocardcount
            THEN
               p_error_code := 13;
            END IF;
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END scratchcardexist;

/****************************************************************************
<name>          SIMS_Upd_Code
<author>        Igor Holod
    Olga Petrova
<version>       2.0    23.03.2005 Petrova changed
    1.0   30.11.2004 basic Oracle implementation
-- Editor  : 27.12.2006 05.02.2007 Skripnik Petr
-- Changed : 27.12.2006 Связал stock_state и equipment_model для получения equipment_model_code
--           05.02.2007 TO_NUMBER (p_seria_start) -> p_seria_start.
--           For support of equipment with non-numeric serial numbers
-- 13.07.2009 Smirnov Victor - hints (index_asc(ss, I_STOCK_STATE_STOCK_ID) etc)
<Description>
<Prerequisites>
<Application>   crm_management
<Parameters>
****************************************************************************/
   PROCEDURE getscratchcardequipmentcode (
      p_stockid               NVARCHAR2,
      p_seria_start           NVARCHAR2,
      p_seria_end             NVARCHAR2,
      p_keo_cards_rec   OUT   sys_refcursor,
      p_error_code      OUT   NUMBER
   )
   AS
      keocardmodelcount   NUMBER;
      stockid             NUMBER;
   BEGIN
      p_error_code := 0;

      OPEN p_keo_cards_rec FOR
         SELECT 'X'
           FROM DUAL;

      IF p_seria_start > p_seria_end
      THEN
         p_error_code := 25;
      ELSE
         SELECT NVL((SELECT ID
                        FROM stock
                       WHERE code = p_stockid), NULL)
           INTO stockid
           FROM DUAL;

         IF stockid IS NULL
         THEN
            p_error_code := 23;
         END IF;
      END IF;

      IF p_error_code = 0
      THEN
         SELECT COUNT (*)
           INTO keocardmodelcount
           FROM (SELECT /*+ index_asc(ss, I_STOCK_STATE_STOCK_ID)*/
                        DISTINCT equipment_model_id, create_date
                            FROM stock_state ss
                           WHERE stock_id = stockid
                             AND seria_start BETWEEN p_seria_start AND p_seria_end
                             AND LENGTH (seria_start) = LENGTH (p_seria_start)
                             AND LENGTH (seria_start) = LENGTH (p_seria_end)
                             AND quantity_onstock = 1
                             AND (equipment_type_id = 1 OR equipment_type_id = 7));

         IF keocardmodelcount <> 1
         THEN
            p_error_code := 21;
         ELSE
            OPEN p_keo_cards_rec FOR
               SELECT /*+ driving_site(ss) ordered use_nl(ss, em) index_asc(em, PK_EQUIPMENT_MODEL)*/
                      ss.quantity_onstock, em.equipment_model_code, ss.create_date
                 FROM (SELECT /*+ index_asc(ss, I_STOCK_STATE_STOCK_ID)*/
                                SUM (quantity_onstock) AS quantity_onstock, equipment_model_id,
                                create_date
                           FROM stock_state ss
                          WHERE stock_id = stockid
                            AND seria_start BETWEEN p_seria_start AND p_seria_end
                            AND LENGTH (seria_start) = LENGTH (p_seria_start)
                            AND LENGTH (seria_start) = LENGTH (p_seria_end)
                            AND quantity_onstock = 1
                            AND (equipment_type_id = 1 OR equipment_type_id = 7)
                       GROUP BY equipment_model_id, create_date) ss,
                      equipment_model em
                WHERE ss.equipment_model_id = em.equipment_model_id;
         /*
               if TO_NUMBER(p_seria_end) - TO_NUMBER(p_seria_start) + 1 <> keocardcount then
                  p_error_code := 13;
               end if;
         */
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END getscratchcardequipmentcode;

/****************************************************************************
<name>          function get_phone_number
<author>        Olga Petrova
<version>       2.0   20.04.2005 added check for phone_number_type
    1.0   09.03.2005
-- Editor  : Skripnik Petr
-- Changed : 23.11.2006 17:16
<Description>   for sim_cards__find
<Prerequisites>
<Application>   Internal package use
<Parameters>    p_full_number varchar2 - icc_id
****************************************************************************/
   FUNCTION get_phone_number (p_full_number VARCHAR2)
      RETURN VARCHAR2
   IS
      v_if   VARCHAR2 (20);
   BEGIN
      SELECT international_format
        INTO v_if
        FROM (SELECT --+ driving_site(sc) index(sc uk_sim_sn) index(naap i_netaddraccpo_access_point_id) use_nl(sc, naap, p)
                     p.international_format,
                     ROW_NUMBER () OVER (PARTITION BY naap.access_point_id ORDER BY DECODE
                                                                     (TRIM (naap.link_type_code),
                                                                      util_stock.c_RI_MAIN_LINK_TYPE, 1,
                                                                      util_stock.c_RI_SECOND_LINK_TYPE, 2,
                                                                      3
                                                                     )) rn
                FROM ri_sim_card sc, ri_naap naap, ri_phone_number p
               WHERE sc.sn = p_full_number
                 AND sc.access_point_id = naap.access_point_id
                 AND SYSDATE BETWEEN naap.from_date AND NVL(naap.TO_DATE, SYSDATE)
                 AND naap.network_address_id = p.network_address_id)
       WHERE rn = 1;

      RETURN v_if;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END get_phone_number;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed :
--   Skripnik Petr 24.10.2006 15:40
--   Skripnik Petr 23.11.2006 17:16
--   Skripnik Petr 27.12.2006 Получение equipment_model_id
--   Anoev Maxim 08.05.2007 удалено AND (reserved = p_reserved OR reserved IS NULL)
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE getscratchcardsbycount (
      p_stock_code                 NVARCHAR2,
      p_equipment_code             NVARCHAR2,
      p_equipment_quantity         NUMBER,
      p_reserved                   NVARCHAR2,
      p_keo_cards_rec        OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   )
   IS
      prc_name    CONSTANT NVARCHAR2 (100) := pkg_name || 'getscratchcardsbycount';
      cur                  sys_refcursor;
      l_seria_start        NVARCHAR2 (50);
      l_seria_end          NVARCHAR2 (50);
      l_quantity_onstock   NUMBER;
      l_create_date        DATE;
      l_eqm_batch_id       NUMBER;
      l_eqm_model_id       NUMBER;
      s                    NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := -90006;

      util_loc_pkg.touch_varchar(p_reserved);

      DELETE FROM tmp_seria_result;

      --Получим идентификатор модели оборудования
      l_eqm_model_id := pkg_equipment.get_modelid_by_modelcode (p_equipment_code);

      OPEN cur FOR
         SELECT   ss.seria_start, ss.seria_end, ss.quantity_onstock, ss.create_date,
                  ss.equipment_batch_id
             FROM stock_state ss INNER JOIN stock s ON ss.stock_id = s.ID
            WHERE code = p_stock_code
              AND equipment_model_id = l_eqm_model_id
              AND quantity_onstock > 0
              AND status = 1
         ORDER BY quantity_onstock, seria_start;

      s := 0;

      LOOP
         l_quantity_onstock := 0;

         FETCH cur
          INTO l_seria_start, l_seria_end, l_quantity_onstock, l_create_date, l_eqm_batch_id;

         EXIT WHEN cur%NOTFOUND;

         IF NOT cur%NOTFOUND
         THEN
            s := s + l_quantity_onstock;

            INSERT INTO tmp_seria_result
                 VALUES (l_seria_start, l_seria_end, l_quantity_onstock, l_create_date,
                         l_eqm_batch_id);
         END IF;

         IF s >= p_equipment_quantity
         THEN
            p_error_code := 0;
         END IF;

         EXIT WHEN s >= p_equipment_quantity;
      END LOOP;

      OPEN p_keo_cards_rec FOR
         SELECT seria_start, seria_end, quantity_onstock, valid_until, equipment_batch_id
           FROM tmp_seria_result;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END getscratchcardsbycount;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed :
--   Skripnik Petr 24.10.2006 17:48
--   Skripnik Petr 27.12.2006 Получение equipment_model_id
--   Anoev Maxim 08.05.2007 удалено AND (reserved = p_reserved OR reserved IS NULL)
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE getscratchcardsbycount2 (
      p_stock_code                    NVARCHAR2,
      p_equipment_code                NVARCHAR2,
      p_equipment_quantity            NUMBER,
      p_equipment_valid_until         DATE,
      p_reserved                      NVARCHAR2,
      p_keo_cards_rec           OUT   sys_refcursor,
      p_error_code              OUT   NUMBER
   )
   IS
      prc_name    CONSTANT NVARCHAR2 (100) := pkg_name || 'getscratchcardsbycount2';
      cur                  sys_refcursor;
      l_seria_start        NVARCHAR2 (50);
      l_seria_end          NVARCHAR2 (50);
      l_quantity_onstock   NUMBER;
      l_create_date        DATE;
      l_eqm_batch_id       NUMBER;
      l_eqm_model_id       NUMBER;
      s                    NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      util_loc_pkg.touch_varchar(p_reserved);

      DELETE FROM tmp_seria_result;

      --Получим идентификатор модели оборудования
      l_eqm_model_id := pkg_equipment.get_modelid_by_modelcode (p_equipment_code);

      OPEN cur FOR
         SELECT   ss.seria_start, ss.seria_end, ss.quantity_onstock, ss.create_date,
                  ss.equipment_batch_id
             FROM stock_state ss INNER JOIN stock s ON ss.stock_id = s.ID
            WHERE s.code = p_stock_code
              AND ss.equipment_model_id = l_eqm_model_id
              AND ss.quantity_onstock > 0
              AND ss.status = 1
              AND ss.create_date >= p_equipment_valid_until
         ORDER BY ss.quantity_onstock;

      s := 0;

      LOOP
         FETCH cur
          INTO l_seria_start, l_seria_end, l_quantity_onstock, l_create_date, l_eqm_batch_id;

         IF NOT cur%NOTFOUND
         THEN
            s := s + l_quantity_onstock;

            INSERT INTO tmp_seria_result
                 VALUES (l_seria_start, l_seria_end, l_quantity_onstock, l_create_date,
                         l_eqm_batch_id);
         END IF;

         EXIT WHEN cur%NOTFOUND OR s >= p_equipment_quantity;
      END LOOP;

      IF s < p_equipment_quantity
      THEN
         p_error_code := -90006;
      END IF;

      OPEN p_keo_cards_rec FOR
         SELECT seria_start, seria_end, quantity_onstock, valid_until, equipment_batch_id
           FROM tmp_seria_result;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END getscratchcardsbycount2;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 25.10.2006 09:43
-- Purpose : Находит симкарТЫ на складАХ на текущий момент времени
--------------------------------------------------------------------------------
   PROCEDURE findequipment (p_equipmenttable_rec OUT sys_refcursor, p_error_code OUT NUMBER)
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'findequipment';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      OPEN p_equipmenttable_rec FOR
         SELECT --+ CARDINALITY(eqm 40)
                eqm.COLUMN_VALUE AS equipmentid, s.serial_number, ss.equipment_model_id,
                ss.create_date AS "Valid until", ss.stock_id, ss.quantity_onstock, ss.status,
                ss.equipment_batch_id
           FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm LEFT OUTER JOIN sims s
                ON eqm.COLUMN_VALUE = s.ID   --??
                LEFT OUTER JOIN stock_state ss ON ss.seria_start = s.serial_number
                ;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END findequipment;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 24.10.2006 15:00
--           Skripnik Petr 10.04.2007 16:55 Соеденение с equipment_model для исключения получения кода из sims
-- Purpose : Находит симкарТЫ на складЕ на текущий момент времени
--------------------------------------------------------------------------------
   PROCEDURE findequipment (
      p_single_equipment_id   IN       NUMBER,
      p_stock_id              IN       NVARCHAR2,
      p_equipmenttable_rec    OUT      sys_refcursor,
      p_error_code            OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := 'findequipment';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      util_loc_pkg.touch_varchar(p_stock_id);

      OPEN p_equipmenttable_rec FOR
         SELECT s.ID AS equipment_id, em.equipment_model_code, s.serial_number, ss.stock_id,
                ss.equipment_model_id, ss.create_date "Valid until", ss.equipment_batch_id
           FROM sims s INNER JOIN stock_state ss ON ss.seria_start = s.serial_number
                INNER JOIN equipment_model em ON ss.equipment_model_id = em.equipment_model_id
          WHERE s.ID = p_single_equipment_id AND ss.quantity_onstock = 1 AND ss.status = 1;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END findequipment;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Ermakov Sergey
-- Changed : Ermakov Sergey 13.03.2009 20:22
-- Purpose : Находит одну заданную симкарту на всех складах на текущий момент времени
--------------------------------------------------------------------------------
   PROCEDURE findequipment (
      p_single_equipment_id   IN       NUMBER,
      p_equipmenttable_rec    OUT      sys_refcursor,
      p_error_code            OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := 'findequipment';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      OPEN p_equipmenttable_rec FOR
         SELECT s.ID AS equipment_id, em.equipment_model_code, s.serial_number, ss.stock_id,
                ss.equipment_model_id, ss.create_date "Valid until", ss.equipment_batch_id
           FROM sims s INNER JOIN stock_state ss ON ss.seria_start = s.serial_number
                INNER JOIN equipment_model em ON ss.equipment_model_id = em.equipment_model_id
          WHERE s.ID = p_single_equipment_id AND ss.quantity_onstock = 1 AND ss.status = 1;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END findequipment;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Ermakov Sergey and Victor Smirnov
-- Changed : Ermakov Sergey and Victor Smirnov 20.03.2009 21:02
-- Purpose : Находит несколько заданные симкарты на всех складах на текущий момент времени
--------------------------------------------------------------------------------
   PROCEDURE findequipment (
      p_tab_equipment_id     IN       pkg_common.t_num,
      p_equipmenttable_rec   OUT      sys_refcursor,
      p_error_code           OUT      NUMBER
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'findequipment';
      l_tab_id            ct_number       := ct_number ();
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_tab_equipment_id.COUNT
                         || pkg_constants.c_delimiter
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;

       -- check input parameters
      IF (p_tab_equipment_id.COUNT = 0) OR (p_tab_equipment_id.COUNT = 1 AND p_tab_equipment_id(p_tab_equipment_id.first) IS NULL) THEN
        RAISE_APPLICATION_ERROR(-99999, 'Missing some mandatory parameter(p_tab_equipment_id).');
      END IF;

      FOR i IN p_tab_equipment_id.FIRST .. p_tab_equipment_id.LAST
      LOOP
         l_tab_id.EXTEND;
         l_tab_id (l_tab_id.COUNT) := p_tab_equipment_id (i);
      END LOOP;

       IF l_tab_id.COUNT > 0
       THEN
          OPEN p_equipmenttable_rec FOR
             SELECT /*+ ordered use_nl(s, ss, em) index_asc(s, PK_SIMS) index_asc(ss, I_STOCK_STATE_SS) index_asc(em, PK_EQUIPMENT_MODEL)*/
			        s.ID AS equipment_id, em.equipment_model_code,
                    s.serial_number, ss.stock_id, ss.equipment_model_id,
                    ss.create_date "Valid until", ss.equipment_batch_id
               FROM sims s INNER JOIN stock_state ss ON ss.seria_start = s.serial_number
                    INNER JOIN equipment_model em ON ss.equipment_model_id = em.equipment_model_id
              WHERE s.ID IN
			        (SELECT column_value
							FROM TABLE (CAST (l_tab_id AS ct_number)))
                 	AND ss.quantity_onstock = 1
                	AND ss.status = 1;
       END IF;
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name,
                            pkg_constants.c_flag_err || ':' || SQLERRM,
                            pkg_name
                           );
   END findequipment;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 24.10.2006 15:00
--           Skripnik Petr 10.04.2007 16:55 Соеденение с equipment_model для исключения получения кода из sims
-- Purpose : Находит симкарТЫ на складЕ на текущий момент времени
--
--  Процедура findequipment_2 аналогична процедуре
--   PROCEDURE findequipment (
--      p_single_equipment_id   IN       NUMBER,
--      p_stock_id              IN       NVARCHAR2,
--      p_equipmenttable_rec    OUT      sys_refcursor,
--      p_error_code            OUT      NUMBER
--   )
--  Создана для поддержки FORIS.DataAccess
--------------------------------------------------------------------------------
   PROCEDURE findequipment_2 (
      p_single_equipment_id   IN       NUMBER,
      p_stock_id              IN       NVARCHAR2,
      p_equipmenttable_rec    OUT      sys_refcursor,
      p_error_code            OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := 'findequipment_2';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      util_loc_pkg.touch_varchar(p_stock_id);

      OPEN p_equipmenttable_rec FOR
         SELECT s.ID AS equipment_id, em.equipment_model_code, s.serial_number, ss.stock_id,
                ss.equipment_model_id, ss.create_date "Valid until", ss.equipment_batch_id
           FROM sims s INNER JOIN stock_state ss ON ss.seria_start = s.serial_number
                INNER JOIN equipment_model em ON ss.equipment_model_id = em.equipment_model_id
          WHERE s.ID = p_single_equipment_id AND ss.quantity_onstock = 1 AND ss.status = 1;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END findequipment_2;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Ermakov Sergey and Victor Smirnov
-- Changed : Ermakov Sergey and Victor Smirnov 20.03.2009 21:02
-- Purpose : Находит несколько заданные симкарты на всех складах на текущий момент времени
--
--  Процедура findequipment_4 аналогична процедуре
--   PROCEDURE findequipment (
--      p_tab_equipment_id     IN       pkg_common.t_num,
--      p_equipmenttable_rec   OUT      sys_refcursor,
--      p_error_code           OUT      NUMBER
--   )
--  Создана для поддержки FORIS.DataAccess
--------------------------------------------------------------------------------
   PROCEDURE findequipment_4 (
      p_tab_equipment_id     IN       pkg_common.t_num,
      p_equipmenttable_rec   OUT      sys_refcursor,
      p_error_code           OUT      NUMBER
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'findequipment_4';
      l_tab_id            ct_number       := ct_number ();
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_tab_equipment_id.COUNT
                         || pkg_constants.c_delimiter
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;

       -- check input parameters
      IF (p_tab_equipment_id.COUNT = 0) OR (p_tab_equipment_id.COUNT = 1 AND p_tab_equipment_id(p_tab_equipment_id.first) IS NULL) THEN
        RAISE_APPLICATION_ERROR(-99999, 'Missing some mandatory parameter(p_tab_equipment_id).');
      END IF;

      FOR i IN p_tab_equipment_id.FIRST .. p_tab_equipment_id.LAST
      LOOP
         l_tab_id.EXTEND;
         l_tab_id (l_tab_id.COUNT) := p_tab_equipment_id (i);
      END LOOP;

       IF l_tab_id.COUNT > 0
       THEN
          OPEN p_equipmenttable_rec FOR
             SELECT /*+ ordered use_nl(s, ss, em) index_asc(s, PK_SIMS) index_asc(ss, I_STOCK_STATE_SS) index_asc(em, PK_EQUIPMENT_MODEL)*/
                    s.ID AS equipment_id, em.equipment_model_code,
                    s.serial_number, ss.stock_id, ss.equipment_model_id,
                    ss.create_date "Valid until", ss.equipment_batch_id
               FROM sims s INNER JOIN stock_state ss ON ss.seria_start = s.serial_number
                    INNER JOIN equipment_model em ON ss.equipment_model_id = em.equipment_model_id
              WHERE s.ID IN
                    (SELECT column_value
                            FROM TABLE (CAST (l_tab_id AS ct_number)))
                     AND ss.quantity_onstock = 1
                    AND ss.status = 1;
       END IF;

       pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name,
                            pkg_constants.c_flag_err || ':' || SQLERRM,
                            pkg_name
                           );
   END findequipment_4;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Ermakov Sergey
-- Changed : Ermakov Sergey 03.02.2010 20:22
-- Purpose : Находит склад, на котором находтится оборудование заданного типа с указанным серийным нромером
--
--------------------------------------------------------------------------------
   PROCEDURE findequipment_5 (
      p_equipment_type_id     IN       NUMBER,
      p_serial_number         IN       VARCHAR2,
      p_equipment_table_rec   OUT      sys_refcursor,
      p_error_code            OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := 'findequipment_5';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      OPEN p_equipment_table_rec FOR
         SELECT em."Code" AS equipment_model_code,
                ss.seria_start AS serial_number,
                ss.create_date AS valid_until,
                ss.stock_id,
                st.code AS stock_code,
                ss.equipment_batch_id
           FROM stock_state ss
             INNER JOIN v_equipment_model em ON em."Id" = ss.equipment_model_id
             INNER JOIN stock st ON ss.stock_id = st.id
          WHERE em."Type Id" = p_equipment_type_id
            AND p_serial_number BETWEEN ss.seria_start AND ss.seria_end
            AND LENGTH (p_serial_number) = LENGTH (seria_start)
            AND LENGTH (p_serial_number) = LENGTH (seria_end)
            AND ss.quantity_onstock > 0
            AND ss.status = 1;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END findequipment_5;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Ermakov Sergey
-- Changed : Ermakov Sergey 03.02.2010 20:22
-- Purpose : Находит склад, на котором находтится оборудование заданной модели с указанным серийным нромером
--
--------------------------------------------------------------------------------
   PROCEDURE findequipment_6 (
      p_equipment_model_id    IN       NUMBER,
      p_serial_number         IN       VARCHAR2,
      p_equipment_table_rec   OUT      sys_refcursor,
      p_error_code            OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := 'findequipment_6';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      OPEN p_equipment_table_rec FOR
         SELECT em."Code" AS equipment_model_code,
                ss.seria_start AS serial_number,
                ss.create_date AS valid_until,
                ss.stock_id,
                st.code AS stock_code,
                ss.equipment_batch_id
           FROM stock_state ss
             INNER JOIN v_equipment_model em ON em."Id" = ss.equipment_model_id
             INNER JOIN stock st ON ss.stock_id = st.id
          WHERE em."Id" = p_equipment_model_id
            AND p_serial_number BETWEEN ss.seria_start AND ss.seria_end
            AND LENGTH (p_serial_number) = LENGTH (seria_start)
            AND LENGTH (p_serial_number) = LENGTH (seria_end)
            AND ss.quantity_onstock > 0
            AND ss.status = 1;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END findequipment_6;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Ermakov Sergey
-- Changed : Ermakov Sergey 12.10.2010 20:22
-- Purpose : Находит склад, на котором находтится оборудование заданного типа с указанным серийным нромером
--
--------------------------------------------------------------------------------
   PROCEDURE findequipment_7 (
      p_equipment_type_id     IN       NUMBER,
      p_serial_number         IN       aaseriastart,
      p_equipment_table_rec   OUT      sys_refcursor,
      p_error_message         OUT      VARCHAR2,
      p_error_code            OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := 'findequipment_7';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      p_error_message := 'Successfully completed';
      p_error_code := 0;

      -- check input parameters

      IF p_equipment_type_id IS NULL THEN
        p_error_code := util_pkg.c_ora_missing_parameter;
        p_error_message := 'Missing some mandatory parameter (p_equipment_type_id).';
        RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
      END IF;

      IF (p_serial_number.COUNT = 0) OR (p_serial_number.COUNT = 1 AND p_serial_number(p_serial_number.FIRST) IS NULL) THEN
        p_error_code := util_pkg.c_ora_missing_parameter;
        p_error_message := 'Missing some mandatory parameter (p_seria_start).';
        RAISE_APPLICATION_ERROR(p_error_code, p_error_message);
      END IF;

      --Очистить временные таблицы
      DELETE FROM tmp_series;

      --Заполним таблицу серий
      FOR i IN 1 .. p_serial_number.COUNT
      LOOP
         BEGIN
           INSERT INTO tmp_series(seria_start)
           VALUES (p_serial_number(i));
         EXCEPTION
           WHEN OTHERS
           THEN
               pkg_db_util.DEBUG (prc_name,
                                'Error occurred during '
                             || 'iteration '
                             || i
                             || ' inserting serial number to '
                             || p_serial_number (i) ,
                             pkg_name
                            );
               pkg_db_util.DEBUG (prc_name,
                                'Oracle error is '
                             || SQLERRM ,
                             pkg_name
                            );
            END;
      END LOOP;

      OPEN p_equipment_table_rec FOR
           SELECT s1."Code" AS equipment_model_code,
                ts.seria_start AS serial_number,
                s1.create_date AS valid_until,
                s1.stock_id,
                s1.code AS stock_code,
                s1.equipment_batch_id,
                CASE
                   WHEN stock_id IS NULL
                      THEN 'Equipment not exist'
                   ELSE 'Successfully completed'
                END error_message,
                CASE
                   WHEN stock_id IS NULL
                      THEN -90070
                   ELSE 0
                END result_code
         FROM (SELECT seria_start FROM tmp_series) ts
          LEFT JOIN
           (SELECT *
             FROM stock_state ss
               INNER JOIN v_equipment_model em ON em."Id" = ss.equipment_model_id
               INNER JOIN stock st ON ss.stock_id = st.id
             WHERE em."Type Id" = p_equipment_type_id
              AND ss.quantity_onstock > 0
              AND ss.status = 1) s1
            ON s1.seria_start = ts.seria_start;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END findequipment_7;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr (SP)
-- Changed :
--   SP 17.04.2007 Skripnik Petr Удалены колонки MIN_VALUE e ALARM_ID
--   SP 08.06.2007 Skripnik Petr Удалены колонки document_no
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findequipmentrange (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_valid_until                DATE,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   )
   AS
   BEGIN
      p_error_code := 0;

      OPEN p_equipmenttable_rec FOR
         SELECT ID, stock_id, equipment_model_id, seria_start, seria_end, quantity_onstock,
                quantity_reserved, quantity_announced, doc_header_id, create_date, status,
                equipment_type_id, reserved, user_comment, equipment_batch_id, is_nonsingle_series
           FROM stock_state
          WHERE stock_id = p_stock_id
            AND equipment_model_id = p_equipment_model_id
            AND seria_start = p_seria_start
            AND seria_end = p_seria_end
            AND create_date >= p_valid_until
            AND status = 1
            AND quantity_onstock > 0;
   END;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 24.10.2006 15:35
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findequipmentrange_bulk (p_equipmenttable_rec OUT sys_refcursor, p_error_code OUT NUMBER)
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := 'findequipmentrange_bulk';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      OPEN p_equipmenttable_rec FOR
         SELECT tv.stock_id, tv.equipment_model_id, tv.serial_number, tv.serial_number2,
                tv.validity_date, ss.create_date, ss.status, ss.quantity_onstock,
                ss.equipment_batch_id
           FROM tmp_validity tv LEFT OUTER JOIN stock_state ss
                ON tv.stock_id = ss.stock_id
              AND tv.equipment_model_id = ss.equipment_model_id
              AND tv.serial_number = ss.seria_start
              AND tv.serial_number2 = ss.seria_end
                ;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END findequipmentrange_bulk;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed :
--   SP 08.06.2007 Skripnik Petr Удалены колонки document_no
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findequipmentrangebetween (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_valid_until                DATE,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   )
   AS
   BEGIN
      p_error_code := 0;

      OPEN p_equipmenttable_rec FOR
         SELECT   ID, stock_id, equipment_model_id, seria_start, seria_end, quantity_onstock,
                  quantity_reserved, quantity_announced, doc_header_id, create_date, status,
                  equipment_type_id, reserved, user_comment, equipment_batch_id,
                  is_nonsingle_series
             FROM stock_state
            WHERE stock_id = p_stock_id
              AND equipment_model_id = p_equipment_model_id
              AND seria_start >= p_seria_start
              AND seria_end <= p_seria_end
              AND LENGTH (seria_start) = LENGTH (p_seria_start)
              AND LENGTH (seria_end) = LENGTH (p_seria_end)
              AND create_date >= p_valid_until
              AND status = 1
              AND quantity_onstock > 0
         ORDER BY seria_start;
   END;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function find_equipment_model
(
  p_equipment_model_code nvarchar2,
  p_equipment_model_name_mask nvarchar2,
  p_date date
) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Missing(p_equipment_model_code is null, 'p_equipment_model_code');
  --!_!util_pkg.XCheck_Cond_Missing(p_equipment_model_name_mask is null, 'p_equipment_model_name_mask');
  util_pkg.XCheck_Cond_Missing(p_date is null, 'p_date');
  ------------------------------
  select /*+ full(z)*/
    equipment_model_id
    bulk collect into v_res
  from equipment_model z
  where 1 = 1
    and (p_equipment_model_code is null or equipment_model_code = p_equipment_model_code)
    and (p_equipment_model_name_mask is null or equipment_model_name like p_equipment_model_name_mask)
    and nvl(deleted, p_date + util_stock.c_dummy_date_shift) > p_date
  order by equipment_model_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure findequipmentinventory
(
  p_equipment_code nvarchar2,
  p_equipment_name nvarchar2,
  p_equipmenttable_rec out sys_refcursor,
  p_error_code out number
)
is
  v_date date := sysdate;
  v_model_ids ct_number;
  v_range ct_range;
begin
  ------------------------------
  v_model_ids := find_equipment_model
  (
    p_equipment_model_code => p_equipment_code,
    p_equipment_model_name_mask => p_equipment_name || '%',
    p_date => v_date
  );
  ------------------------------
  select /*+ ordered use_nl(s) use_hash(em) index_asc(s UK_STOCK_CODE) full(em)*/
    ot_range
    (
      val1 => s.code,
      val2 => em.equipment_model_code,
      num1 => s.id,
      num2 => em.equipment_model_id,
      num3 => null,
      dat1 => null,
      num4 => null
    )
    bulk collect into v_range
  from
    (
      select /*+ ordered use_merge(te) full(te) full(ts)*/
        te.column_value equipment_model_id,
        ts.code stock_code
      from tmp_stock_code ts, table(v_model_ids) te
    ) t,
    stock s,
    equipment_model em
  where 1 = 1
    and s.code = t.stock_code
    and em.equipment_model_id = t.equipment_model_id
  ;
  ------------------------------
  open p_equipmenttable_rec for
  select /*+ ordered use_nl(s) use_hash(em) index_asc(s PK_STOCK) full(em)*/
    em.equipment_model_id "EquipmentModelID",
    em.equipment_model_code "EquipmentCode",
    em.equipment_model_name "EquipmentName",
    s.code "StockCode",
    s.name "StockName",
    z.quantity "Quantity"
  from
  (
    select /*+ ordered use_nl(ss) index_asc(ss I_STOCK_STATE_EQM)*/
      q.stock_id,
      q.equipment_model_id,
      sum(ss.quantity_onstock) quantity
    from
      (select val1 stock_code, val2 equipment_model_code, num1 stock_id, num2 equipment_model_id, rownum rn from table(v_range)) q,
      stock_state ss
    where 1 = 1
      and ss.stock_id = q.stock_id
      and ss.equipment_model_id = q.equipment_model_id
      --!_!and ss.status = equipment_pkg.c_eq_status_active
    group by
      q.stock_id,
      q.equipment_model_id
  ) z,
    stock s,
    equipment_model em
  where 1 = 1
    and z.quantity > equipment_pkg.c_eq_qty_zero
    and s.id = z.stock_id
    and em.equipment_model_id = z.equipment_model_id
    --!_!and nvl(s.deleted, v_date + util_stock.c_dummy_date_shift) > v_date
    --!_!and nvl(em.deleted, v_date + util_stock.c_dummy_date_shift) > v_date
  order by
    em.equipment_model_code,
    s.code
  ;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Anoev Maxim
-- Changed : Anoev Maxim 08.05.2007 удалено AND("Reservation" IS NULL OR "Reservation" = p_reserved);
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findequipmentinventorybetween (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_valid_until                DATE,
      p_reserved                   NVARCHAR2,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   )
   AS
   BEGIN
      p_error_code := 0;

      util_loc_pkg.touch_varchar(p_reserved);

      OPEN p_equipmenttable_rec FOR
         SELECT *
           FROM vw_stock_state
          WHERE "Equipment model id" = p_equipment_model_id
            AND "Id" = p_stock_id
            AND "Quantity" > 0
            AND "Status" = 1
            AND "Seria start" BETWEEN p_seria_start AND p_seria_end
            AND "Seria end" BETWEEN p_seria_start AND p_seria_end
            AND LENGTH ("Seria start") = LENGTH (p_seria_start)
            AND LENGTH ("Seria start") = LENGTH (p_seria_end)
            AND LENGTH ("Seria end") = LENGTH (p_seria_start)
            AND LENGTH ("Seria end") = LENGTH (p_seria_end)
            AND "Valid until" >= p_valid_until;
   END;

-------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Version :
-- Modification :
-- Editor  : Skripnik Petr (SP)
-- Changed :
--   SP 27.12.2006 Связал stock_state и equipment_model для получения equipment_model_code
--   SP 03.04.2006 --+ LEADING(s)
--   SP 24.04.2006 Прикрутил коллекцию
--   SP 08.06.2007 (-)l_from := p_iccid_from || '0'; l_to := p_iccid_to || '9';
--                 AND s.full_number BETWEEN (<>) AND s.serial_number
--                 AND LENGTH (s.full_number) (<>) AND LENGTH (s.serial_number)
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findjeanspackages (
      p_validity_date              DATE,
      p_quantity                   NUMBER,
      p_iccid_from                 NVARCHAR2,
      p_iccid_to                   NVARCHAR2,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'findjeanspackages';
      l_from              VARCHAR2 (50);
      l_to                VARCHAR2 (50);
      l_cnt_eqm           NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_validity_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_quantity
                         || pkg_constants.c_delimiter
                         || p_iccid_from
                         || pkg_constants.c_delimiter
                         || p_iccid_to
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;
      l_from := p_iccid_from;
      l_to := p_iccid_to;

      SELECT COUNT (*)
        INTO l_cnt_eqm
        FROM tmp_equipment_code;

      IF l_cnt_eqm = 0
      THEN
         SELECT em.equipment_model_id
         BULK COLLECT INTO pkg_equipment.g_tab_model_id
           FROM equipment_model em
          WHERE em.equipment_type_id = 3;
      ELSE
         SELECT em.equipment_model_id
         BULK COLLECT INTO pkg_equipment.g_tab_model_id
           FROM equipment_model em, tmp_equipment_code t
          WHERE em.equipment_type_id = 3 AND em.equipment_model_code = t.code;
      END IF;

      IF p_iccid_to IS NULL OR p_iccid_from IS NULL
      THEN
         OPEN p_equipmenttable_rec FOR
            SELECT   --+ DYNAMIC_SAMPLING (ts 2)
                     s.ID AS "EQUIPMENT_ID", st.code "STOCKCODE", st.NAME "STOCKNAME",
                     em.equipment_model_code "EQUIPMENTCODE",
                     em.equipment_model_name "EQUIPMENTNAME", s.full_number "ICCID",
                     crm_management.get_phone_number(to_char(s.full_number)) phone_number,
                     ss.create_date "VALIDITYDATE"
                FROM tmp_stock_code ts JOIN stock st ON ts.code = st.code
                     JOIN stock_state ss ON st.ID = ss.stock_id
                     JOIN sims s ON s.serial_number = ss.seria_start
                     JOIN equipment_model em ON ss.equipment_model_id = em.equipment_model_id
               WHERE ss.quantity_onstock = 1
                 AND ss.status = 1
                 AND ss.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 20)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                 AND (   ss.create_date <= p_validity_date
                      OR p_validity_date = pkg_constants.c_minexistsdate
                     )
                 AND (ROWNUM <= p_quantity OR p_quantity = -1)
            ORDER BY s.ID;
      ELSE
         --l_from := p_iccid_from || '0';
         --l_to := p_iccid_to || '9';
         OPEN p_equipmenttable_rec FOR
            SELECT   --+ LEADING(s) DYNAMIC_SAMPLING(ts 2)
                     s.ID AS "EQUIPMENT_ID", st.code "STOCKCODE", st.NAME "STOCKNAME",
                     em.equipment_model_code "EQUIPMENTCODE",
                     em.equipment_model_name "EQUIPMENTNAME", s.full_number "ICCID",
                     crm_management.get_phone_number(to_char(s.full_number)) phone_number,
                     ss.create_date "VALIDITYDATE"
                FROM tmp_stock_code ts JOIN stock st ON ts.code = st.code
                     JOIN stock_state ss ON st.ID = ss.stock_id
                     JOIN sims s ON s.serial_number = ss.seria_start
                     JOIN equipment_model em ON ss.equipment_model_id = em.equipment_model_id
               WHERE ss.quantity_onstock = 1
                 AND ss.status = 1
                 AND ss.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 20)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                 AND (   ss.create_date <= p_validity_date
                      OR p_validity_date = pkg_constants.c_minexistsdate
                     )
                 AND (ROWNUM <= p_quantity OR p_quantity = -1)
                 AND s.serial_number BETWEEN l_from AND l_to
                 AND LENGTH (s.serial_number) = LENGTH (l_from)
                 AND LENGTH (s.serial_number) = LENGTH (l_to)
            ORDER BY s.ID;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END findjeanspackages;

-------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Version :
-- Modification :
-- Editor  : Skripnik Petr (SP)
-- Changed :
--   SP 27.12.2006 Связал stock_state и equipment_model для получения equipment_model_code
--   SP 03.04.2006 --+ LEADING(s)
--   SP 24.04.2006 Прикрутил коллекцию
--   SP 08.06.2007 (-)l_from := p_iccid_from || '0'; l_to := p_iccid_to || '9';
--                 AND s.full_number BETWEEN (<>) AND s.serial_number
--                 AND LENGTH (s.full_number) (<>) AND LENGTH (s.serial_number)
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findjeanspackagesnophonenumber (
      p_validity_date              DATE,
      p_quantity                   NUMBER,
      p_iccid_from                 NVARCHAR2,
      p_iccid_to                   NVARCHAR2,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'findjeanspackagesnophonenumber';
      l_from              VARCHAR2 (50);
      l_to                VARCHAR2 (50);
      l_cnt_eqm           NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_validity_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_quantity
                         || pkg_constants.c_delimiter
                         || p_iccid_from
                         || pkg_constants.c_delimiter
                         || p_iccid_to
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;
      l_from := p_iccid_from;
      l_to := p_iccid_to;

      SELECT COUNT (*)
        INTO l_cnt_eqm
        FROM tmp_equipment_code;

      IF l_cnt_eqm = 0
      THEN
         SELECT em.equipment_model_id
         BULK COLLECT INTO pkg_equipment.g_tab_model_id
           FROM equipment_model em
          WHERE em.equipment_type_id = 3;
      ELSE
         SELECT em.equipment_model_id
         BULK COLLECT INTO pkg_equipment.g_tab_model_id
           FROM equipment_model em, tmp_equipment_code t
          WHERE em.equipment_type_id = 3 AND em.equipment_model_code = t.code;
      END IF;

      IF p_iccid_to IS NULL OR p_iccid_from IS NULL
      THEN
         OPEN p_equipmenttable_rec FOR
            SELECT   --+ DYNAMIC_SAMPLING (ts 2)
                     s.ID AS "EQUIPMENT_ID", st.code "STOCKCODE", st.NAME "STOCKNAME",
                     em.equipment_model_code "EQUIPMENTCODE",
                     em.equipment_model_name "EQUIPMENTNAME", s.full_number "ICCID",
                     ss.create_date "VALIDITYDATE"
                FROM tmp_stock_code ts JOIN stock st ON ts.code = st.code
                     JOIN stock_state ss ON st.ID = ss.stock_id
                     JOIN sims s ON s.serial_number = ss.seria_start
                     JOIN equipment_model em ON em.equipment_model_id = ss.equipment_model_id
               WHERE ss.quantity_onstock = 1
                 AND ss.status = 1
                 AND ss.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 20)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                 AND (   ss.create_date <= p_validity_date
                      OR p_validity_date = pkg_constants.c_minexistsdate
                     )
                 AND (ROWNUM <= p_quantity OR p_quantity = -1)
            ORDER BY s.ID;
      ELSE
         --l_from := p_iccid_from || '0';
         --l_to := p_iccid_to || '9';
         OPEN p_equipmenttable_rec FOR
            SELECT   --+ LEADING(s) DYNAMIC_SAMPLING (ts 2)
                     s.ID AS "EQUIPMENT_ID", st.code "STOCKCODE", st.NAME "STOCKNAME",
                     em.equipment_model_code "EQUIPMENTCODE",
                     em.equipment_model_name "EQUIPMENTNAME", s.full_number "ICCID",
                     ss.create_date "VALIDITYDATE"
                FROM tmp_stock_code ts JOIN stock st ON ts.code = st.code
                     JOIN stock_state ss ON st.ID = ss.stock_id
                     JOIN sims s ON s.serial_number = ss.seria_start
                     JOIN equipment_model em ON em.equipment_model_id = ss.equipment_model_id
               WHERE ss.quantity_onstock = 1
                 AND ss.status = 1
                 AND ss.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 20)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                 AND (   ss.create_date <= p_validity_date
                      OR p_validity_date = pkg_constants.c_minexistsdate
                     )
                 AND (ROWNUM <= p_quantity OR p_quantity = -1)
                 AND s.serial_number BETWEEN l_from AND l_to
                 AND LENGTH (s.serial_number) = LENGTH (l_from)
                 AND LENGTH (s.serial_number) = LENGTH (l_to)
            ORDER BY s.ID;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END findjeanspackagesnophonenumber;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:34 Связал stock_state и equipment_model для получения equipment_model_code
--           Anoev Maksim  26.03.2007 Добавил связку с заданными кодами складов
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findscratchcard (
      p_serial_number              NVARCHAR2,
      p_valid_until                DATE,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   )
   AS
      l_cnt   NUMBER;
   BEGIN
      p_error_code := 0;

      SELECT COUNT (*)
        INTO l_cnt
        FROM tmp_stock_code;

      OPEN p_equipmenttable_rec FOR
         SELECT seria_start AS "SerialNumber", em.equipment_model_code AS "EquipmentCode",
                s.code AS "StockCode", crm_unique_number AS "PersonalAccount"
           FROM stock_state ss INNER JOIN stock s ON ss.stock_id = s.ID
                JOIN equipment_model em ON ss.equipment_model_id = em.equipment_model_id
          WHERE (ss.equipment_type_id = 1 OR ss.equipment_type_id = 7)
            AND ss.seria_start = p_serial_number
            AND ss.create_date >= p_valid_until
            AND ss.status = 1
            AND ss.quantity_onstock > 0
            AND (s.code IN (SELECT code
                              FROM tmp_stock_code) OR (l_cnt = 0));
   END;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Anoev Maxim
-- Changed :
--   Anoev Maxim 08.05.2007 удалены AND (reserved = p_reserved OR reserved IS NULL)
-- Purpose : Текущее состояние склада по определенному открытому оборудованию с количеством
--------------------------------------------------------------------------------
   PROCEDURE findequipmenttoremove (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_reserved                   NVARCHAR2,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := 'findequipmenttoremove';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Установим код ошибки в ноль
      p_error_code := 0;

      util_loc_pkg.touch_varchar(p_reserved);

      OPEN p_equipmenttable_rec FOR
         SELECT   s.equipment_model_id "Equipment model id", s.seria_start "Seria start",
                  s.seria_end "Seria end", s.quantity_onstock "Quantity", s.status "Status",
                  s.create_date "Valid until", s.equipment_batch_id
             FROM stock_state s
            WHERE s.equipment_model_id = p_equipment_model_id
              AND s.stock_id = p_stock_id
              AND s.status = 1
              AND s.quantity_onstock > 0
         ORDER BY s.quantity_onstock;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END findequipmenttoremove;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 06.02.2007 Add "IF SQL%ROWCOUNT = 0"
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stockstatedelete (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   AS
      v_sp_name varchar2(30);
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      DELETE FROM stock_state
            WHERE stock_id = p_stock_id
              AND equipment_model_id = p_equipment_model_id
              AND seria_start = p_seria_start
              AND seria_end = p_seria_end;

      IF SQL%ROWCOUNT = 0
      THEN
         p_error_code := -90006;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 06.02.2007 Add "IF SQL%ROWCOUNT = 0"
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stockstateupdate (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   AS
      v_sp_name varchar2(30);
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      UPDATE stock_state
         SET quantity_reserved = quantity_onstock,
             quantity_onstock = 0
       WHERE stock_id = p_stock_id
         AND equipment_model_id = p_equipment_model_id
         AND seria_start = p_seria_start
         AND seria_end = p_seria_end;

      IF SQL%ROWCOUNT = 0
      THEN
         p_error_code := -90006;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed :
--   SP 08.06.2007 Skripnik Petr Удалена колонка document_no
-- Purpose : Вставляет запись в текущее состояние склада
--------------------------------------------------------------------------------
   PROCEDURE stockstateinsert (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity_onstock           NUMBER,
      p_quantity_reserved          NUMBER,
      p_quantity_announced         NUMBER,
      p_doc_header_id              NUMBER,
      p_create_date                DATE,
      p_status                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   AS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := 'stockstateinsert';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Установим код ошибки в ноль
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      INSERT INTO stock_state
                  (stock_id, equipment_model_id, seria_start, seria_end,
                   quantity_onstock, quantity_reserved, quantity_announced, doc_header_id,
                   create_date, status
                  )
           VALUES (p_stock_id, p_equipment_model_id, p_seria_start, p_seria_end,
                   p_quantity_onstock, p_quantity_reserved, p_quantity_announced, p_doc_header_id,
                   p_create_date, p_status
                  );

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stockstateinsert;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.10.2006 15:00
-- Editor  : Skripnik Petr
-- Changed :
--   SP 08.06.2007 Skripnik Petr Удалена колонка document_no
-- Purpose : Вставляет запись в текущее состояние склада
--------------------------------------------------------------------------------
   PROCEDURE stockstateinsert (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity_onstock           NUMBER,
      p_quantity_reserved          NUMBER,
      p_quantity_announced         NUMBER,
      p_doc_header_id              NUMBER,
      p_create_date                DATE,
      p_status                     NUMBER,
      p_equipment_batch_id         NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   AS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := 'stockstateinsert';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Установим код ошибки в ноль
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      INSERT INTO stock_state
                  (stock_id, equipment_model_id, seria_start, seria_end,
                   quantity_onstock, quantity_reserved, quantity_announced, doc_header_id,
                   create_date, status, equipment_batch_id
                  )
           VALUES (p_stock_id, p_equipment_model_id, p_seria_start, p_seria_end,
                   p_quantity_onstock, p_quantity_reserved, p_quantity_announced, p_doc_header_id,
                   p_create_date, p_status, p_equipment_batch_id
                  );

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stockstateinsert;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.10.2006 15:00
-- Editor  : Skripnik Petr
-- Changed :
--   SP 08.06.2007 Skripnik Petr Удалена колонка document_no
-- Purpose : Вставляет запись в текущее состояние склада
--
--  Процедура stockstateinsert_2 аналогична процедуре
--   PROCEDURE stockstateinsert (
--      p_stock_id                   NUMBER,
--      p_equipment_model_id         NUMBER,
--      p_seria_start                NVARCHAR2,
--      p_seria_end                  NVARCHAR2,
--      p_quantity_onstock           NUMBER,
--      p_quantity_reserved          NUMBER,
--      p_quantity_announced         NUMBER,
--      p_doc_header_id              NUMBER,
--      p_create_date                DATE,
--      p_status                     NUMBER,
--      p_equipment_batch_id         NUMBER,
--      p_handle_tran                CHAR := 'Y',
--      p_error_code           OUT   NUMBER
--     )
--  Создана для поддержки FORIS.DataAccess
--------------------------------------------------------------------------------
   PROCEDURE stockstateinsert_2 (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity_onstock           NUMBER,
      p_quantity_reserved          NUMBER,
      p_quantity_announced         NUMBER,
      p_doc_header_id              NUMBER,
      p_create_date                DATE,
      p_status                     NUMBER,
      p_equipment_batch_id         NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   AS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := 'stockstateinsert';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Установим код ошибки в ноль
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      INSERT INTO stock_state
                  (stock_id, equipment_model_id, seria_start, seria_end,
                   quantity_onstock, quantity_reserved, quantity_announced, doc_header_id,
                   create_date, status, equipment_batch_id
                  )
           VALUES (p_stock_id, p_equipment_model_id, p_seria_start, p_seria_end,
                   p_quantity_onstock, p_quantity_reserved, p_quantity_announced, p_doc_header_id,
                   p_create_date, p_status, p_equipment_batch_id
                  );

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stockstateinsert_2;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure finduserstocks_2
(
    p_user_id users.user_name%type,
    p_stock_code stock.code%type,
    p_stocktable_rec out sys_refcursor,
    p_error_code out number
)
is
  v_date date := sysdate;
  v_user_id number;
  v_stock_id number;
  v_stock_perm number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_stock_code is null, 'p_stock_code');
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user_id);
  ------------------------------
  v_stock_id := util_stock.get_stock_id2(p_stock_code, v_date);
  ------------------------------
  v_stock_perm := util_stock.get_stock_perm(v_user_id, v_stock_id, v_date);
  ------------------------------
  util_stock.get_result_cursor005(v_stock_id, v_stock_perm, v_user_id, p_stocktable_rec);
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function getequipmentcount01 return sys_refcursor
is
  v_res sys_refcursor;
  v_range ct_range;
begin
  ------------------------------
  select /*+ ordered use_nl(s) use_hash(em) index_asc(s, UK_STOCK_CODE) full(em)*/
    ot_range
    (
      val1 => t.stock_code,
      val2 => t.equipment_model_code,
      num1 => s.id, --!_!stock_id
      num2 => em.equipment_model_id,
      num3 => null,
      dat1 => null,
      num4 => null
    )
    bulk collect into v_range
  from
    (
      select /*+ ordered use_merge(te) full(te) full(ts)*/
        te.code equipment_model_code,
        ts.code stock_code
      from tmp_stock_code ts, tmp_equipment_code te
    ) t,
    stock s,
    equipment_model em
  where 1 = 1
    and s.code = t.stock_code
    and em.equipment_model_code = t.equipment_model_code
  ;
  ------------------------------
  open v_res for
  select /*+ ordered use_nl(ss) index_asc(ss, I_STOCK_STATE_EQM)*/
    q.stock_code "StockCode",
    q.equipment_model_code "EquipmentCode",
    nvl(sum(ss.quantity_onstock), equipment_pkg.c_eq_qty_zero) "Count"
  from
    (select val1 stock_code, val2 equipment_model_code, num1 stock_id, num2 equipment_model_id, rownum rn from table(v_range)) q,
    stock_state ss
  where 1 = 1
    and ss.stock_id(+) = q.stock_id
    and ss.equipment_model_id(+) = q.equipment_model_id
    and ss.status = equipment_pkg.c_eq_status_active
  group by q.stock_code, q.equipment_model_code
  order by q.stock_code, q.equipment_model_code
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function getequipmentcount02 return sys_refcursor
is
  v_res sys_refcursor;
begin
  ------------------------------
  open v_res for
  select /*+ ordered driving_site(q) use_nl(ss, em) index_asc(ss, I_STOCK_STATE_STOCK_ID) index_asc(em, PK_EQUIPMENT_MODEL)*/
    q.stock_code "StockCode",
    em.equipment_model_code "EquipmentCode",
    nvl(sum(ss.quantity_onstock), equipment_pkg.c_eq_qty_zero) "Count"
  from
    (
    select /*+ ordered use_nl(s) index_asc(s, UK_STOCK_CODE)*/
      s.id stock_id,
      t.stock_code
    from
      (
        select /*+ full(ts)*/
          ts.code stock_code
        from tmp_stock_code ts
      ) t,
      stock s
    where 1 = 1
      and s.code = t.stock_code
    ) q,
    stock_state ss,
    equipment_model em
  where 1 = 1
    and ss.stock_id = q.stock_id
    and ss.status = equipment_pkg.c_eq_status_active
    and ss.quantity_onstock > equipment_pkg.c_eq_qty_zero
    and em.equipment_model_id = ss.equipment_model_id
  group by q.stock_code, em.equipment_model_code
  order by q.stock_code, em.equipment_model_code
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure getequipmentcount
(
  p_equipmenttable_rec out sys_refcursor,
  p_error_code out number
)
is
  v_cnt number;
begin
  ------------------------------
  select count(1) into v_cnt from tmp_equipment_code;
  ------------------------------
  if v_cnt > 0
  then
    ------------------------------
    p_equipmenttable_rec := getequipmentcount01;
    ------------------------------
  else
    ------------------------------
    p_equipmenttable_rec := getequipmentcount02;
    ------------------------------
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 03.10.2006 14:36
-- Purpose : Возвращает тип оборудования и его ID по коду
--------------------------------------------------------------------------------
   PROCEDURE findequipmenttypeandidbycode (
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   )
   AS
   BEGIN
      p_error_code := 0;

      OPEN p_equipmenttable_rec FOR
         SELECT em.equipment_model_code, em.equipment_model_id, em.equipment_type_id,
                et.system_type_code, et.has_serial_number
           FROM equipment_model em, vw_equipment_type et, tmp_equipment_code tec
          WHERE em.equipment_type_id = et.equipment_type_id AND em.equipment_model_code = tec.code;
   END findequipmenttypeandidbycode;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure SetEquipmentComment
(
  p_stock_id number,
  p_equipment_model_id number,
  p_seria_start nvarchar2,
  p_seria_end nvarchar2,
  p_user_comment nvarchar2,
  p_handle_tran char := util_stock.c_tran_yes,
  p_error_code out number
)
is
  v_sp_name varchar2(30);
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  if p_seria_start = p_seria_end
  then
    ------------------------------
    update /*+ index(z I_STOCK_STATE_EQM) */
      stock_state z
    set
      user_comment = p_user_comment
    where 1 = 1
      and equipment_model_id = p_equipment_model_id
      and stock_id = p_stock_id
      and seria_start = p_seria_start
      and seria_end = p_seria_start
    ;
    ------------------------------
    if sql%rowcount = 0
    then
      ------------------------------
      update /*+ index(z I_STOCK_STATE_EQM) */
        stock_state z
      set
        user_comment = p_user_comment
      where 1 = 1
        and equipment_model_id = p_equipment_model_id
        and stock_id = p_stock_id
        and p_seria_start between seria_start and seria_end
        and length(p_seria_start) = length(z.seria_start)
      ;
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    update /*+ index(z I_STOCK_STATE_EQM) */
      stock_state z
    set
      user_comment = p_user_comment
    where 1 = 1
      and equipment_model_id = p_equipment_model_id
      and stock_id = p_stock_id
      and seria_start between nvl(p_seria_start, seria_start) and nvl(p_seria_end, seria_end)
      and seria_end between nvl(p_seria_start, seria_start) and nvl(p_seria_end, seria_end)
    ;
    ------------------------------
  end if;
  ------------------------------
  if p_handle_tran = util_stock.c_tran_yes
  then
    commit;
  end if;
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
exception
when others then
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  p_error_code := util_pkg.get_err_code;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE setequipmentreservation (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity                   NUMBER,
      p_reserved                   NVARCHAR2,
      p_reserve                    NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   IS
      v_count              NUMBER;
      reservation_count    NUMBER;
      reservation_person   NVARCHAR2 (50);
   BEGIN
      p_error_code := 0;

      IF (p_seria_start IS NOT NULL AND p_seria_start <> '0' AND p_seria_end IS NOT NULL)
      THEN   -- series
         IF p_reserve = 1
         THEN   -- Reserve
            UPDATE /*+ index(ss I_STOCK_STATE_EQM) */stock_state ss
               SET ss.reserved = p_reserved
             WHERE ss.stock_id = p_stock_id
               AND ss.equipment_model_id = p_equipment_model_id
               AND ss.seria_start BETWEEN p_seria_start AND p_seria_end
               AND ss.seria_end BETWEEN p_seria_start AND p_seria_end
               AND ss.reserved IS NULL;

            IF SQL%NOTFOUND
            THEN   -- series does not exist or are already reserved
               p_error_code := -90062;
            END IF;
         ELSE   -- Unreserve
            BEGIN
               SELECT          /*+ index(ss I_STOCK_STATE_EQM) */
                      DISTINCT reserved
                          INTO reservation_person
                          FROM stock_state ss
                         WHERE stock_id = p_stock_id
                           AND equipment_model_id = p_equipment_model_id
                           AND seria_start BETWEEN p_seria_start AND p_seria_end
                           AND seria_end BETWEEN p_seria_start AND p_seria_end;

               IF reservation_person IS NOT NULL
               THEN
                  IF reservation_person = p_reserved
                  THEN   -- same user
                     UPDATE /*+ index(ss I_STOCK_STATE_EQM) */stock_state ss
                        SET ss.reserved = NULL
                      WHERE ss.stock_id = p_stock_id
                        AND ss.equipment_model_id = p_equipment_model_id
                        AND ss.seria_start BETWEEN p_seria_start AND p_seria_end
                        AND ss.seria_end BETWEEN p_seria_start AND p_seria_end;
                  ELSE
                     p_error_code := -90061;
                  END IF;
               END IF;
            EXCEPTION
               WHEN TOO_MANY_ROWS
               THEN   -- series reserved by more than one user
                  p_error_code := -90063;
               WHEN NO_DATA_FOUND
               THEN
                  p_error_code := -90063;
            END;
         END IF;
      ELSE   -- equipment without sn
         IF p_reserve = 1
         THEN   -- reserve
            SELECT NVL(SUM (quantity_onstock), 0)
              INTO v_count
              FROM stock_state
             WHERE stock_id = p_stock_id AND equipment_model_id = p_equipment_model_id;

            SELECT NVL(SUM (quantity), 0)
              INTO reservation_count
              FROM equipment_reservation
             WHERE stock_id = p_stock_id AND equipment_model_id = p_equipment_model_id;

            IF v_count - reservation_count >= p_quantity
            THEN
               UPDATE equipment_reservation   -- update quantity
                  SET quantity = quantity + p_quantity
                WHERE stock_id = p_stock_id
                  AND equipment_model_id = p_equipment_model_id
                  AND user_id = p_reserved;

               IF SQL%NOTFOUND
               THEN   -- when equipment not found
                  INSERT INTO equipment_reservation
                              (stock_id, equipment_model_id, user_id, quantity
                              )
                       VALUES (p_stock_id, p_equipment_model_id, p_reserved, p_quantity
                              );
               END IF;
            ELSE
               p_error_code := -90006;
            END IF;
         ELSE   -- remove reservation
            SELECT NVL(SUM (quantity), 0)
              INTO v_count
              FROM equipment_reservation
             WHERE stock_id = p_stock_id
               AND equipment_model_id = p_equipment_model_id
               AND user_id = p_reserved;

            IF v_count > p_quantity
            THEN
               UPDATE equipment_reservation
                  SET quantity = quantity - p_quantity
                WHERE stock_id = p_stock_id
                  AND equipment_model_id = p_equipment_model_id
                  AND user_id = p_reserved;
            ELSIF v_count = p_quantity
            THEN
               DELETE FROM equipment_reservation
                     WHERE stock_id = p_stock_id
                       AND equipment_model_id = p_equipment_model_id
                       AND user_id = p_reserved;
            END IF;
         END IF;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   END;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed :
--           Skripnik Petr 10.04.2007 16:55 Соеденение с equipment_model для исключения получения кода из sims
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findsimcardsiccidsonly (
      p_stock_code            NVARCHAR2,
      p_iccid_from            NVARCHAR2,
      p_iccid_to              NVARCHAR2,
      p_quantity              NUMBER,
      p_sim_cards_rec   OUT   sys_refcursor,
      p_error_code      OUT   NUMBER
   )
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_sim_cards_rec FOR
         SELECT --+ NO_EXPAND
                sq.full_number "ICCID", em.equipment_model_code AS "Equipment_Code"
           FROM (SELECT s.full_number, ss.equipment_model_id
                   FROM stock_state ss, sims s, stock st
                  WHERE ss.seria_start BETWEEN NVL(p_iccid_from, ss.seria_start)
                                           AND NVL(p_iccid_to, ss.seria_end)
                    AND ss.quantity_onstock = 1
                    AND ss.status = 1
                    AND ss.equipment_type_id = 2
                    AND ss.seria_start = s.serial_number
                    AND ss.stock_id = st.ID
                    AND st.code = p_stock_code) sq,
                equipment_model em
          WHERE ROWNUM <= DECODE (p_quantity, -1, ROWNUM, p_quantity)
            AND sq.equipment_model_id = em.equipment_model_id;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END findsimcardsiccidsonly;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Orlenko Olga
-- Changed : 25.01.2010
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE lockequipmentrange (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_valid_until                DATE,
      p_error_code           OUT   NUMBER
   )
   AS
   v_ID NUMBER;
   BEGIN
      p_error_code := 0;

      SELECT /*+ index(ss I_STOCK_STATE_EQM) */ ID
      INTO v_ID
      FROM stock_state
      WHERE stock_id = p_stock_id
        AND equipment_model_id = p_equipment_model_id
        AND seria_start = p_seria_start
        AND seria_end = p_seria_end
        AND create_date >= p_valid_until
        AND status = 1
        AND quantity_onstock > 0
       FOR UPDATE NOWAIT;

   EXCEPTION
      WHEN OTHERS
      THEN
         IF (SQLCODE = -54) THEN p_error_code := -90040;
         ELSE p_error_code := SQLCODE;
         END IF;
   END;


-------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Version :
-- Modification :
-- Editor  : Vasiliev Pavel
-- Changed :
--   SP 19.01.2012 за основу взята findjeanspackagesnophonenumber
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findjeanspackagesnophonenum2 (
      p_validity_date              DATE,
      p_quantity                   NUMBER,
      p_stock_codes                aaseriastart,
      p_equipment_codes            aaseriastart,
      p_iccid_from                 aaseriastart,
      p_iccid_to                   aaseriastart,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'findjeanspackagesnophonenum2';
      l_cnt_eqm           NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_validity_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_quantity
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;

      if (p_iccid_from.Count <> p_iccid_to.Count or
          (p_iccid_from is null and p_iccid_to is not null) or
          (p_iccid_from is not null and p_iccid_to is null) ) then
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter);
      end if;

      delete from tmp_series;
      delete from tmp_equipment_id;
      delete from tmp_equipment_code;
      delete from tmp_stock_code;

      forall i in nvl(p_iccid_from.first, 1) .. nvl(p_iccid_from.last, 0)
        insert into tmp_series(seria_start,seria_end)
          values (p_iccid_from(i), p_iccid_to(i));

      forall i in nvl(p_equipment_codes.first, 1) .. nvl(p_equipment_codes.last, 0)
        insert into tmp_equipment_code(code)
          values (p_equipment_codes(i));

      forall i in nvl(p_stock_codes.first, 1) .. nvl(p_stock_codes.last, 0)
        insert into tmp_stock_code(code)
          values (p_stock_codes(i));

      SELECT COUNT (*)
        INTO l_cnt_eqm
        FROM tmp_equipment_code;

      IF p_equipment_codes.count = 0
      THEN
         insert into tmp_equipment_id(id)
         SELECT em.equipment_model_id
           FROM equipment_model em
          WHERE em.equipment_type_id = 3;
      ELSE
         insert into tmp_equipment_id(id)
         SELECT em.equipment_model_id
           FROM equipment_model em, tmp_equipment_code t
          WHERE em.equipment_type_id = 3 AND em.equipment_model_code = t.code;
      END IF;



      IF p_iccid_to IS NULL OR p_iccid_from IS NULL or p_iccid_from.Count = 0
      or (p_iccid_from.Count = 1 and (p_iccid_from(p_iccid_from.first) is null or p_iccid_to(p_iccid_to.first) is null))
      THEN
        OPEN p_equipmenttable_rec FOR
          select /*+ ordered use_nl(stk ss s ) use_hash(tem em) full(tt) full(tem) index(stk UK_STOCK_CODE) index(ss I_STOCK_STATE_EQM) index(s AK_SIMS_SN) full(em)*/
                 s.ID AS "EQUIPMENT_ID",
                 stk.code "STOCKCODE",
                 stk.NAME "STOCKNAME",
                 em.equipment_model_code "EQUIPMENTCODE",
                 em.equipment_model_name "EQUIPMENTNAME",
                 s.full_number "ICCID",
                 ss.create_date "VALIDITYDATE"
            from tmp_stock_code tt
            join tmp_equipment_id tem on 1 = 1
            join stock stk on stk.code = tt.code
            join stock_state ss on ss.stock_id = stk.id
                                and ss.equipment_model_id = tem.id
                                and (ss.create_date <= p_validity_date
                                     or p_validity_date = pkg_constants.c_minexistsdate)
            join sims s on s.serial_number = ss.seria_start
            join equipment_model em on em.equipment_model_id = ss.equipment_model_id
           where (rownum <= p_quantity or p_quantity = -1)
            order by s.id;
      ELSE
        OPEN p_equipmenttable_rec FOR
          select /*+ ordered use_nl(ss stk s) use_hash(tstk tem em) full(tt) index(ss I_STOCK_STATE_SS) index(stk PK_STOCK) index(s AK_SIMS_SN) full(tstk) full(tem) full(em)*/
                 s.ID AS "EQUIPMENT_ID",
                 stk.code "STOCKCODE",
                 stk.name "STOCKNAME",
                 em.equipment_model_code "EQUIPMENTCODE",
                 em.equipment_model_name "EQUIPMENTNAME",
                 s.full_number "ICCID",
                 ss.create_date "VALIDITYDATE"
            from tmp_series tt
            join stock_state ss on ss.seria_start between tt.seria_start and tt.seria_end
                                and length(ss.seria_start) = length(tt.seria_start)
                                and (ss.create_date <= p_validity_date
                                    or p_validity_date = pkg_constants.c_minexistsdate)
            join stock stk on stk.id = ss.stock_id
            join sims s on s.serial_number = ss.seria_start
            join tmp_stock_code tstk on tstk.code = stk.code
            join tmp_equipment_id tem on tem.id = ss.equipment_model_id
            join equipment_model em on em.equipment_model_id = ss.equipment_model_id
           where ss.seria_start = ss.seria_end
             and (rownum <= p_quantity or p_quantity = -1)
           order by s.ID;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END;
END;
/
