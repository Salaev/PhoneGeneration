CREATE PACKAGE BODY pkg_stock
AS
--******************************************************************************
-- Author  : Skripnik Petr
-- Created : 07.12.2006 10:35
-- Modification : stock_management
-- Purpose : Work with the stocks
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ----------------------------------------------
-- Skripnik Petr   16.04.2007  version 1.11.8.2
-- Skripnik Petr   10.07.2007  version 1.11.9.0
--****************************************************************************--
   pkg_name   CONSTANT NVARCHAR2 (50) := 'pkg_stock.';

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 05.04.2007 10:43
-- Editor  :
-- Changed :
-- Purpose : Проверяет наличие оборудования определенной модели в текущем состоянии склада
-- Problems:
--   OracleProvider не поддерживает тип BOOLEAN
--------------------------------------------------------------------------------
   PROCEDURE chk_modelid_in_stockstate (p_equipment_model_id IN NUMBER, p_result OUT NUMBER)
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'chk_modelid_in_stockstate';
      l_cnt               NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_result := 0;

      SELECT COUNT (ID)
        INTO l_cnt
        FROM stock_state
       WHERE equipment_model_id = p_equipment_model_id AND ROWNUM = 1;

      IF l_cnt > 0
      THEN
         p_result := 1;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         p_result := 0;
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END chk_modelid_in_stockstate;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 07.05.2007 09:31
-- Version :
--   1 07.05.2007
-- Modification : bulk_insert_management.bulk_insert_tmp_stock_id
--              + bulk_insert_management.bulk_insert_tmp_stock_id2
-- Editor  :
-- Changed :
-- Purpose : Устанавливает идентификаторы складов
-- Problems:
--   Не применять FOR i IN collection.FIRST .. collection.LAST при
--   возможности пустой коллекции
--------------------------------------------------------------------------------
   PROCEDURE set_stockid (
      p_stock_id         IN   pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_flag_clear       IN   CHAR DEFAULT 'Y',
      p_stock_id_out     IN   pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_flag_clear_out   IN   CHAR DEFAULT 'Y',
      p_stock_id_in      IN   pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_flag_clear_in    IN   CHAR DEFAULT 'Y'
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'set_stockid';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      --Склады
      IF p_flag_clear = 'Y'
      THEN
         --Чистим и инициализируем коллекцию идетификаторов складов
         g_tab_id := pkg_common.g_tab_empty_num;
         pkg_db_util.DEBUG (prc_name, 'clear collection stocks', pkg_name);
      END IF;

      IF NOT(p_stock_id.COUNT = 1 AND p_stock_id(p_stock_id.FIRST) IS NULL)
      THEN
      IF (p_stock_id.EXISTS (1)) AND (p_stock_id (1) = util_stock.c_not_exists_num)
      --"Все склады" с установкой в коллекцию
      THEN
         SELECT ID
         BULK COLLECT INTO g_tab_id
           FROM stock;

         pkg_db_util.DEBUG (prc_name, 'all stocks insert into stock collection', pkg_name);
      ELSIF p_stock_id.EXISTS (1)
      THEN
         FOR i IN 1 .. p_stock_id.COUNT
         LOOP
            IF (p_stock_id.EXISTS (i)) AND (p_stock_id (i) IS NOT NULL)
            THEN
               g_tab_id.EXTEND;
               g_tab_id (g_tab_id.COUNT) := p_stock_id (i);
               pkg_db_util.DEBUG (prc_name, 'stock = ' || p_stock_id (i), pkg_name);
            END IF;
         END LOOP;
      END IF;
      END IF;

      pkg_db_util.DEBUG (prc_name, 'stock.COUNT ' || g_tab_id.COUNT, pkg_name);

      --Склады отправители
      IF p_flag_clear_out = 'Y'
      THEN
         --Чистим и инициализируем коллекцию идетификаторов складов
         g_tab_id_out := pkg_common.g_tab_empty_num;
         pkg_db_util.DEBUG (prc_name, 'clear collection stocks out', pkg_name);
      END IF;

      IF NOT(p_stock_id_out.COUNT = 1 AND p_stock_id_out(p_stock_id_out.FIRST) IS NULL)
      THEN
      IF (p_stock_id_out.EXISTS (1)) AND (p_stock_id_out (1) = util_stock.c_not_exists_num)
      --"Все склады" с установкой в коллекцию
      THEN
         SELECT ID
         BULK COLLECT INTO g_tab_id_out
           FROM stock;

         pkg_db_util.DEBUG (prc_name, 'all stocks insert into stock out collection', pkg_name);
      ELSIF p_stock_id_out.EXISTS (1)
      THEN
         FOR i IN 1 .. p_stock_id_out.COUNT
         LOOP
            IF (p_stock_id_out.EXISTS (i)) AND (p_stock_id_out (i) IS NOT NULL)
            THEN
               g_tab_id_out.EXTEND;
               g_tab_id_out (g_tab_id_out.COUNT) := p_stock_id_out (i);
               pkg_db_util.DEBUG (prc_name, 'stock out = ' || p_stock_id_out (i), pkg_name);
            END IF;
         END LOOP;
      END IF;
      END IF;

      pkg_db_util.DEBUG (prc_name, 'stock out.COUNT ' || g_tab_id_out.COUNT, pkg_name);

      --Склады получатели
      IF (p_flag_clear_in = 'Y')   --Флаг предварительной очистки
      THEN
         --Чистим и инициализируем коллекцию идетификаторов складов
         g_tab_id_in := pkg_common.g_tab_empty_num;
         pkg_db_util.DEBUG (prc_name, 'clear collection stocks in', pkg_name);
      END IF;

      IF NOT(p_stock_id_in.COUNT = 1 AND p_stock_id_in(p_stock_id_in.FIRST) IS NULL)
      THEN
      IF (p_stock_id_in.EXISTS (1)) AND (p_stock_id_in (1) = util_stock.c_not_exists_num)
      --"Все склады" с установкой в коллекцию
      THEN
         SELECT ID
         BULK COLLECT INTO g_tab_id_in
           FROM stock;

         pkg_db_util.DEBUG (prc_name, 'all stocks insert into stock in collection', pkg_name);
      ELSIF p_stock_id_in.EXISTS (1)
      THEN
         FOR i IN 1 .. p_stock_id_in.COUNT
         LOOP
            IF (p_stock_id_in.EXISTS (i)) AND (p_stock_id_in (i) IS NOT NULL)
            THEN
               g_tab_id_in.EXTEND;
               g_tab_id_in (g_tab_id_in.COUNT) := p_stock_id_in (i);
               pkg_db_util.DEBUG (prc_name, 'stock in = ' || p_stock_id_in (i), pkg_name);
            END IF;
         END LOOP;
      END IF;
      END IF;

      pkg_db_util.DEBUG (prc_name, 'stock in.COUNT ' || g_tab_id_in.COUNT, pkg_name);
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END set_stockid;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 09.02.2007 10:34
-- Editor  : Maslennikov Sergey
-- Changed : 22.03.2007; 26.03.2007
-- 1. Добавлен join с таблицей equipment_batch для получения полей
-- equipment_batch_code и price
-- 2. Вывод поля "Код склада"
-- Purpose : Получаем детальное состояние складов по наборам оборудования
--           серийных номеров(для малой размерности)
--------------------------------------------------------------------------------
   PROCEDURE state_detalied (
      p_stock_id       IN       pkg_common.t_num,
      p_eqm_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_seria_start    IN       pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar,
      p_seria_end      IN       pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar,
      p_cur            OUT      sys_refcursor,
      p_error_code     OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'state_detalied';
      l_cnt_eqm           NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_stock_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_eqm_model_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_seria_start.COUNT
                         || pkg_constants.c_delimiter
                         || p_seria_end.COUNT
                         || ')',
                         pkg_name
                        );
      --Установим код ошибки в ноль
      p_error_code := 0;
      --Заполним коллекцию идентификаторов складов
      pkg_stock.set_stockid (p_stock_id);
      --Заполним коллекцию идентификаторов оборудования...
      pkg_equipment.set_modelid (p_eqm_model_id);
      l_cnt_eqm := pkg_equipment.g_tab_model_id.COUNT;
      --Заполним коллекцию серийных номеров
      pkg_equipment.set_series (p_seria_start, p_seria_end);

      IF pkg_equipment.g_tab_series.COUNT = 0
      THEN
         OPEN p_cur FOR
            SELECT   ss.ID, ss.stock_id, ss.equipment_model_id, em.equipment_model_code,
                     em.equipment_model_name, ss.seria_start, ss.seria_end, ss.quantity_onstock,
                     ss.quantity_reserved, ss.quantity_announced, ss.doc_header_id, ss.create_date,
                     ss.status, ss.equipment_type_id, et.equipment_type_name, ss.reserved,
                     ss.user_comment, ss.equipment_batch_id, ss.is_nonsingle_series,
                     eb.equipment_batch_code, eb.price, st.code AS stock_code,
                     st.NAME AS stock_name
                FROM stock_state ss,
                     equipment_type et,
                     equipment_model em,
                     equipment_batch eb,
                     stock st
               WHERE ss.stock_id IN (SELECT --+ CARDINALITY(stk 5)
                                            COLUMN_VALUE
                                       FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                 AND (   (ss.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 2)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                         )
                      OR l_cnt_eqm = 0
                     )
                 AND ss.equipment_type_id = et.equipment_type_id
                 AND ss.equipment_model_id = em.equipment_model_id
                 AND ss.equipment_batch_id = eb.equipment_batch_id(+)
                 AND ss.stock_id = st.ID
            ORDER BY ss.stock_id, ss.equipment_model_id, ss.seria_start, ss.seria_end;
      ELSE
         OPEN p_cur FOR
            SELECT   --+ CARDINALITY(ts 10)
                     ss.ID, ss.stock_id, ss.equipment_model_id, em.equipment_model_code,
                     em.equipment_model_name, ss.seria_start, ss.seria_end, ss.quantity_onstock,
                     ss.quantity_reserved, ss.quantity_announced, ss.doc_header_id, ss.create_date,
                     ss.status, ss.equipment_type_id, et.equipment_type_name, ss.reserved,
                     ss.user_comment, ss.equipment_batch_id, ss.is_nonsingle_series,
                     eb.equipment_batch_code, eb.price, st.code AS stock_code,
                     st.NAME AS stock_name
                FROM stock_state ss,
                     TABLE (CAST (pkg_equipment.g_tab_series AS ct_series)) ts,
                     equipment_type et,
                     equipment_model em,
                     equipment_batch eb,
                     stock st
               WHERE ss.seria_start BETWEEN ts.seria_start AND ts.seria_end
                 AND ss.seria_end BETWEEN ts.seria_start AND ts.seria_end
                 AND LENGTH (ss.seria_start) = LENGTH (ts.seria_start)
                 AND ss.stock_id IN (SELECT --+ CARDINALITY(stk 5)
                                            COLUMN_VALUE
                                       FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                 AND (   (ss.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 2)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                         )
                      OR l_cnt_eqm = 0
                     )
                 AND ss.equipment_type_id = et.equipment_type_id
                 AND ss.equipment_model_id = em.equipment_model_id
                 AND ss.equipment_batch_id = eb.equipment_batch_id(+)
                 AND ss.stock_id = st.ID
            ORDER BY ss.stock_id, ss.equipment_model_id, ss.seria_start, ss.seria_end;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END state_detalied;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.01.2007 13:28
-- Version : 1
-- Modification : catalogue_management.inventory__get
-- Editor  : Skripnik Petr (SP)
-- Changed :
--   SP 17.04.2007 Удалены колонки MIN_VALUE и ALARM_ID
-- Purpose : Получаем состояние склада сгруппированного по оборудованию
--------------------------------------------------------------------------------
   PROCEDURE state_group_by_eqm (
      p_stock_id          IN       pkg_common.t_num,
      p_groupby_eqm_cur   OUT      sys_refcursor,
      p_error_code        OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'state_group_by_eqm';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name, '(' || p_stock_id.COUNT || ')', pkg_name);
      --Установим код ошибки в ноль
      p_error_code := 0;
      --Заполним коллекцию идентификаторов складов
      pkg_stock.set_stockid (p_stock_id);

      OPEN p_groupby_eqm_cur FOR
         SELECT --+ NO_MERGE(ss)
                ss.stock_id, et.equipment_type_id, et.equipment_type_name, ss.equipment_model_id,
                em.equipment_model_code, em.equipment_model_name, ss.quantity_onstock,
                ss.quantity_reserved, ss.quantity_announced
           FROM (SELECT   stock_id, SUM (quantity_onstock) AS quantity_onstock,
                          SUM (quantity_reserved) AS quantity_reserved,
                          SUM (quantity_announced) AS quantity_announced, equipment_model_id
                     FROM stock_state
                    WHERE stock_id IN (SELECT --+ CARDINALITY(stk 1)
                                              COLUMN_VALUE
                                         FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                 GROUP BY stock_id, equipment_model_id) ss,
                equipment_model em,
                equipment_type et
          WHERE ss.equipment_model_id = em.equipment_model_id
            AND em.equipment_type_id = et.equipment_type_id;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END state_group_by_eqm;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.01.2007 13:36
-- Editor  : Maslennikov Sergey (MS), Skripnik Petr (SP)
-- Changed :
--   MS 27.03.2007 Вывод поля "Код склада"
--   SP 17.04.2007 (-) MIN_VALUE,ALARM_ID
--   SP 08.06.2007 (-) document_no
-- Purpose : Получаем состояние склада сгруппированного по непрерывным сериям оборудования
-- Problems:
--   При указании l_ss и l_se как NVARCHAR2 не срабатывает часть:
--   "AND ss.seria_start BETWEEN l_ss AND l_se AND ss.seria_end BETWEEN l_ss AND l_se"
--------------------------------------------------------------------------------
   PROCEDURE state_group_by_series (
      p_stock_id             IN       pkg_common.t_num,
      p_eqm_model_id         IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_seria_start          IN       NVARCHAR2 DEFAULT NULL,
      p_seria_end            IN       NVARCHAR2 DEFAULT NULL,
      p_groupby_series_cur   OUT      sys_refcursor,
      p_error_code           OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'state_group_by_series_3';
      l_cnt_eqm           NUMBER;
      l_ss                VARCHAR2 (50);   -- начало серии
      l_se                VARCHAR2 (50);   -- конец серии
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_stock_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_eqm_model_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_seria_start
                         || pkg_constants.c_delimiter
                         || p_seria_end
                         || ')',
                         pkg_name
                        );
      --Установим код ошибки в ноль
      p_error_code := 0;
      --Заполним коллекцию идентификаторов складов
      pkg_stock.set_stockid (p_stock_id);
      --Установим модели оборудования
      pkg_equipment.set_modelid (p_eqm_model_id);
      --Определим количество заданных идентификаторов моделей оборудования
      l_cnt_eqm := pkg_equipment.g_tab_model_id.COUNT;
      --Определим серию
      l_ss := p_seria_start;
      l_se := p_seria_end;
      --Установим недостающую границу серии
      pkg_equipment.get_seria_not_null (l_ss, l_se);

      OPEN p_groupby_series_cur FOR
         SELECT --+ NO_MERGE(cs)
                cs.stock_id, et.equipment_type_id, et.equipment_type_name, cs.equipment_model_id,
                em.equipment_model_code, em.equipment_model_name, cs.seria_start, cs.seria_end,
                cs.quantity_onstock, cs.quantity_reserved, cs.quantity_announced,
                st.code AS stock_code, st.NAME AS stock_name
           FROM (SELECT   b.stock_id, b.equipment_model_id, MIN (b.seria_start) AS seria_start,
                          MAX (b.seria_end) AS seria_end,
                          SUM (b.quantity_onstock) AS quantity_onstock,
                          SUM (b.quantity_reserved) AS quantity_reserved,
                          SUM (b.quantity_announced) AS quantity_announced
                     FROM (SELECT a.stock_id, a.equipment_model_id, a.seria_start, a.seria_end,
                                  a.quantity_onstock, a.quantity_reserved, a.quantity_announced,
                                  SUM (a.start_of_group) OVER (PARTITION BY a.equipment_model_id, a.stock_id ORDER BY a.seria_start)
                                                                                        AS group_no
                             FROM (SELECT ss.stock_id, ss.equipment_model_id, ss.seria_start,
                                          ss.seria_end, ss.quantity_onstock, ss.quantity_reserved,
                                          ss.quantity_announced,
                                          CASE
                                             WHEN (    vet.is_numeric_serial_number = 'Y'
                                                   AND vet.allows_partitioning = 'Y'
                                                  )
                                                THEN DECODE
                                                       (TO_NUMBER
                                                           (LAG (ss.seria_end) OVER (PARTITION BY ss.equipment_model_id, ss.stock_id ORDER BY ss.seria_start)
                                                           ),
                                                        TO_NUMBER (ss.seria_start) - 1, NULL,
                                                        '1'
                                                       )
                                             ELSE '1'
                                          END start_of_group
                                     FROM stock_state ss, vw_equipment_type vet
                                    WHERE ss.stock_id IN (
                                              SELECT --+ CARDINALITY(stk 5)
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                                      AND (   (ss.equipment_model_id IN (
                                                  SELECT --+ CARDINALITY(eqm 2)
                                                         COLUMN_VALUE
                                                    FROM TABLE
                                                            (CAST
                                                                (pkg_equipment.g_tab_model_id AS ct_number
                                                                )
                                                            ) eqm)
                                              )
                                           OR (0 = l_cnt_eqm)
                                          )
                                      AND (   (    ss.seria_start BETWEEN l_ss AND l_se
                                               AND ss.seria_end BETWEEN l_ss AND l_se
                                               AND LENGTH (ss.seria_start) = LENGTH (l_ss)
                                              )
                                           OR (l_ss = '0')
                                          )
                                      AND ss.equipment_type_id = vet.equipment_type_id) a) b
                 GROUP BY b.stock_id, b.equipment_model_id, b.group_no) cs,
                equipment_model em,
                equipment_type et,
                stock st
          WHERE cs.equipment_model_id = em.equipment_model_id
            AND em.equipment_type_id = et.equipment_type_id
            AND cs.stock_id = st.ID;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 31.01.2007 14:46
-- Version : 2
-- Modification :
-- Editor  : Maslennikov Sergey (MS)
-- Changed :
--   MS 22.03.2007 (+)join с таблицей equipment_batch для получения полей equipment_batch_code и price
-- Purpose : Получаем детальное состояние складов на дату по наборам оборудования,серийных номеров
--------------------------------------------------------------------------------
   PROCEDURE state_on_date_detalied (
      p_date           IN       DATE,
      p_stock_id       IN       pkg_common.t_num,
      p_eqm_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_seria_start    IN       pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar,
      p_seria_end      IN       pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar,
      p_cur            OUT      sys_refcursor,
      p_error_code     OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'state_on_date_detalied';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_stock_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_eqm_model_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_seria_start.COUNT
                         || pkg_constants.c_delimiter
                         || p_seria_end.COUNT
                         || ')',
                         pkg_name
                        );
      --Установим код ошибки в ноль
      p_error_code := 0;
      --Заполним коллекцию идентификаторов складов
      pkg_stock.set_stockid (p_stock_id => p_stock_id);
      --Заполним коллекцию идентификаторов оборудования...
      pkg_equipment.set_modelid (p_model_id_1 => p_eqm_model_id);
      --Заполним коллекцию серийных номеров
      pkg_equipment.set_series (p_seria_start, p_seria_end);
      --Восстановим все движение оборудования на заданную дату
      pkg_stock.state_prepare (p_date                         => p_date,
                               p_is_update_validity_date      => FALSE,
                               p_is_process_opened_doc        => TRUE
                              );

      IF pkg_equipment.g_tab_series.COUNT = 0
      THEN
         OPEN p_cur FOR
            SELECT   NULL AS ID, tmp.stock_id, tmp.equipment_model_id, em.equipment_model_code,
                     em.equipment_model_name, tmp.seria_start, tmp.seria_end, tmp.quantity_onstock,
                     tmp.quantity_reserved, tmp.quantity_announced, tmp.doc_header_id,
                     tmp.create_date, tmp.status, tmp.equipment_type_id, et.equipment_type_name,
                     NULL AS min_value, NULL AS alarm_id, NULL AS reserved, NULL AS user_comment,
                     tmp.equipment_batch_id, NULL AS is_nonsingle_series, eb.equipment_batch_code,
                     eb.price
                FROM (SELECT   stock_id, equipment_model_id, seria_start, seria_end,
                               SUM (quantity_onstock) AS quantity_onstock,
                               SUM (quantity_reserved) AS quantity_reserved,
                               SUM (quantity_announced) AS quantity_announced,
                               MAX (document_no) AS document_no, MAX (vendor_doc) AS vendor_doc,
                               MAX (product) AS product, MAX (doc_header_id) AS doc_header_id,
                               MAX (valid_until) AS create_date, MAX (status) AS status,
                               MAX (equipment_type_id) AS equipment_type_id, equipment_batch_id
                          FROM tmp_ss1
                      GROUP BY stock_id,
                               equipment_model_id,
                               seria_start,
                               seria_end,
                               equipment_batch_id) tmp,
                     equipment_type et,
                     equipment_model em,
                     equipment_batch eb
               WHERE et.equipment_type_id = em.equipment_type_id
                 AND tmp.equipment_model_id = em.equipment_model_id
                 AND tmp.equipment_batch_id = eb.equipment_batch_id(+)
            ORDER BY tmp.stock_id, tmp.equipment_model_id, tmp.seria_start, tmp.seria_end;
      ELSE
         --Если не все модели оборудования...
         OPEN p_cur FOR
            SELECT   NULL AS ID, tmp.stock_id, tmp.equipment_model_id, em.equipment_model_code,
                     em.equipment_model_name, tmp.seria_start, tmp.seria_end, tmp.quantity_onstock,
                     tmp.quantity_reserved, tmp.quantity_announced, tmp.doc_header_id,
                     tmp.create_date, tmp.status, tmp.equipment_type_id, et.equipment_type_name,
                     NULL AS min_value, NULL AS alarm_id, NULL AS reserved, NULL AS user_comment,
                     tmp.equipment_batch_id, NULL AS is_nonsingle_series, eb.equipment_batch_code,
                     eb.price
                FROM (SELECT   stock_id, equipment_model_id, seria_start, seria_end,
                               SUM (quantity_onstock) AS quantity_onstock,
                               SUM (quantity_reserved) AS quantity_reserved,
                               SUM (quantity_announced) AS quantity_announced,
                               MAX (document_no) AS document_no, MAX (vendor_doc) AS vendor_doc,
                               MAX (product) AS product, MAX (doc_header_id) AS doc_header_id,
                               MAX (valid_until) AS create_date, MAX (status) AS status,
                               MAX (equipment_type_id) AS equipment_type_id, equipment_batch_id
                          FROM tmp_ss1
                      GROUP BY stock_id,
                               equipment_model_id,
                               seria_start,
                               seria_end,
                               equipment_batch_id) tmp,
                     TABLE (CAST (pkg_equipment.g_tab_series AS ct_series)) ts,
                     equipment_type et,
                     equipment_model em,
                     equipment_batch eb
               WHERE tmp.seria_start BETWEEN ts.seria_start AND ts.seria_end
                 AND tmp.seria_end BETWEEN ts.seria_start AND ts.seria_end
                 AND LENGTH (tmp.seria_start) = LENGTH (ts.seria_start)
                 AND et.equipment_type_id = em.equipment_type_id
                 AND tmp.equipment_model_id = em.equipment_model_id
                 AND tmp.equipment_batch_id = eb.equipment_batch_id(+)
            ORDER BY tmp.stock_id, tmp.equipment_model_id, tmp.seria_start, tmp.seria_end;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END state_on_date_detalied;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.01.2007 13:28
-- Version : 1
-- Modification : catalogue_management.inventory__get
-- Editor  :
-- Changed :
-- Purpose : Получаем состояние склада сгруппированного по оборудованию
--------------------------------------------------------------------------------
   PROCEDURE state_on_date_group_by_eqm (
      p_date              IN       DATE,
      p_stock_id          IN       pkg_common.t_num,
      p_groupby_eqm_cur   OUT      sys_refcursor,
      p_error_code        OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'state_on_date_group_by_eqm';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_stock_id.COUNT
                         || ')',
                         pkg_name
                        );
      --Установим код ошибки в ноль
      p_error_code := 0;
      --Заполним коллекцию идентификаторов складов
      pkg_stock.set_stockid (p_stock_id => p_stock_id);
      --Заполним коллекцию идентификаторов оборудования...
      pkg_equipment.set_modelid;
      --Восстановим все движение оборудования на заданную дату
      pkg_stock.state_prepare (p_date                         => p_date,
                               p_is_update_validity_date      => FALSE,
                               p_is_process_opened_doc        => TRUE,
                               p_is_detailed                  => FALSE
                              );

      OPEN p_groupby_eqm_cur FOR
         SELECT tmp.stock_id, tmp.equipment_type_id, et.equipment_type_name, tmp.equipment_model_id,
                em.equipment_model_code, em.equipment_model_name, tmp.quantity_onstock,
                tmp.quantity_reserved, tmp.quantity_announced, NULL AS min_value, NULL AS alarm_id
           FROM tmp_ss1 tmp, equipment_model em, equipment_type et
          WHERE tmp.equipment_model_id = em.equipment_model_id
            AND et.equipment_type_id = em.equipment_type_id;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END state_on_date_group_by_eqm;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.01.2007 13:36
-- Version :
--   1 23.01.2007
-- Modification :
-- Editor  :
-- Changed :
-- Purpose : Получаем состояние склада сгруппированного по непрерывным сериям оборудования
-- Problems:
--   При указании l_ss и l_se как NVARCHAR2 не срабатывает
--   "AND ss.seria_start BETWEEN l_ss AND l_se AND ss.seria_end BETWEEN l_ss AND l_se"
--------------------------------------------------------------------------------
   PROCEDURE state_on_date_group_by_series (
      p_date                 IN       DATE,
      p_stock_id             IN       pkg_common.t_num,
      p_eqm_model_id         IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_seria_start          IN       NVARCHAR2 DEFAULT NULL,
      p_seria_end            IN       NVARCHAR2 DEFAULT NULL,
      p_groupby_series_cur   OUT      sys_refcursor,
      p_error_code           OUT      NUMBER
   )
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'state_on_date_group_by_series';
      l_ss                VARCHAR2 (50);   -- начало серии
      l_se                VARCHAR2 (50);   -- конец серии
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_stock_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_eqm_model_id.COUNT
                         || pkg_constants.c_delimiter
                         || p_seria_start
                         || pkg_constants.c_delimiter
                         || p_seria_end
                         || ')',
                         pkg_name
                        );
      --Установим код ошибки в ноль
      p_error_code := 0;
      --Определим серию
      l_ss := p_seria_start;
      l_se := p_seria_end;
      --Установим недостающую границу серии
      pkg_equipment.get_seria_not_null (l_ss, l_se);
      --Заполним коллекцию идентификаторов складов
      pkg_stock.set_stockid (p_stock_id => p_stock_id);
      --Установим модели оборудования
      pkg_equipment.set_modelid (p_model_id_1 => p_eqm_model_id);
      --Восстановим все движение оборудования на заданную дату
      pkg_stock.state_prepare (p_date                         => p_date,
                               p_is_update_validity_date      => FALSE,
                               p_is_process_opened_doc        => TRUE
                              );

      OPEN p_groupby_series_cur FOR
         SELECT --+ NO_MERGE(cs)
                cs.stock_id, et.equipment_type_id, et.equipment_type_name, cs.equipment_model_id,
                em.equipment_model_code, em.equipment_model_name, cs.seria_start, cs.seria_end,
                cs.quantity_onstock, cs.quantity_reserved, cs.quantity_announced
           FROM (SELECT   b.stock_id, b.equipment_model_id, MIN (b.seria_start) AS seria_start,
                          MAX (b.seria_end) AS seria_end,
                          SUM (b.quantity_onstock) AS quantity_onstock,
                          SUM (b.quantity_reserved) AS quantity_reserved,
                          SUM (b.quantity_announced) AS quantity_announced
                     FROM (SELECT a.stock_id, a.equipment_model_id, a.seria_start, a.seria_end,
                                  a.quantity_onstock, a.quantity_reserved, a.quantity_announced,
                                  SUM (a.start_of_group) OVER (PARTITION BY a.equipment_model_id, a.stock_id ORDER BY a.seria_start)
                                                                                        AS group_no
                             FROM (SELECT --+ DYNAMIC_SAMPLING(t 2) CARDINALITY(vet 5) CARDINALITY(em 10)
                                          t.stock_id, t.equipment_model_id, t.seria_start,
                                          t.seria_end, t.quantity_onstock, t.quantity_reserved,
                                          t.quantity_announced,
                                          CASE
                                             WHEN (    vet.is_numeric_serial_number = 'Y'
                                                   AND vet.allows_partitioning = 'Y'
                                                  )
                                                THEN DECODE
                                                       (TO_NUMBER
                                                           (LAG (t.seria_end) OVER (PARTITION BY t.equipment_model_id, t.stock_id ORDER BY t.seria_start)
                                                           ),
                                                        TO_NUMBER (t.seria_start) - 1, NULL,
                                                        '1'
                                                       )
                                             ELSE '1'
                                          END start_of_group
                                     FROM tmp_ss1 t, vw_equipment_type vet, equipment_model em
                                    WHERE (   (    seria_start BETWEEN l_ss AND l_se
                                               AND seria_end BETWEEN l_ss AND l_se
                                               AND LENGTH (seria_start) = LENGTH (l_ss)
                                              )
                                           OR (l_ss = '0')
                                          )
                                      AND em.equipment_type_id = vet.equipment_type_id
                                      AND t.equipment_model_id = em.equipment_model_id) a) b
                 GROUP BY b.stock_id, b.equipment_model_id, b.group_no) cs,
                equipment_model em,
                equipment_type et
          WHERE cs.equipment_model_id = em.equipment_model_id
            AND et.equipment_type_id = em.equipment_type_id;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END state_on_date_group_by_series;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 14.09.2007 12:54
-- Version :
--   1 14.09.2007
-- Modification :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE state_prepare (
      p_date                      IN   DATE,
      p_is_update_validity_date   IN   BOOLEAN,   --флаг обработки документов об изменении срока годности оборудования
      p_is_process_opened_doc     IN   BOOLEAN,   --флаг обработки открытых документов
      p_is_detailed               IN   BOOLEAN DEFAULT TRUE
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'state_prepare';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || pkg_common.boolean_to_char (p_is_update_validity_date)
                         || pkg_constants.c_delimiter
                         || pkg_common.boolean_to_char (p_is_process_opened_doc)
                         || pkg_constants.c_delimiter
                         || pkg_common.boolean_to_char (p_is_detailed)
                         || ')',
                         pkg_name
                        );

      IF pkg_common.get_global_val ('FLAG_PROC_PREPARE') = 'NONE'
      THEN
         pkg_stock.state_prepare_direct (p_date                         => p_date,
                                         p_is_update_validity_date      => p_is_update_validity_date,
                                         p_is_process_opened_doc        => p_is_process_opened_doc,
                                         p_is_detailed                  => p_is_detailed
                                        );
      ELSE
         pkg_stock.state_prepare_reverse (p_date                         => p_date,
                                          p_is_update_validity_date      => p_is_update_validity_date,
                                          p_is_process_opened_doc        => p_is_process_opened_doc,
                                          p_is_detailed                  => p_is_detailed
                                         );
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END state_prepare;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.05.2007 13:45
-- Version :
--   3 23.05.2007
--   4 10.07.2007
--   5 23.07.2007
-- Modification : stock_management.stock_state_to_date_prepare ->
--                -> pkg_stock.state_prepare
-- Editor  : Skripnik Petr (SP)
-- Changed :
--   SP 15.06.2007 Добавил DISTINCT dh.ID для исключения оборудования с отрицательным количеством
--   SP 02.07.2007 DISTINCT dh.ID (<>) DISTINCT TRUNC (dh.doc_date, 'MI')
--                 для исключения оборудования с отрицательным количеством
--   SP 02.07.2007(-) DISTINCT TRUNC (dh.doc_date, 'MI') т.к. раньше даты простовлялись
--                 без часов\минут\секунд и оборудование в день могло
--                 списатся-прийти-списатся, а запись на списание в итоге будет только одна.
-- Purpose : Получаем все движения оборудования на период времени.Состояние
--           строется от первого документа до даты указанной в параметре
--------------------------------------------------------------------------------
   PROCEDURE state_prepare_direct (
      p_date                      IN   DATE,   --конечная дата диапазона
      p_is_update_validity_date   IN   BOOLEAN,   --флаг обработки документов об изменении срока годности оборудования
      p_is_process_opened_doc     IN   BOOLEAN,   --флаг обработки открытых документов
      p_is_detailed               IN   BOOLEAN DEFAULT TRUE
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'state_prepare_direct';
      l_cnt_stk           NUMBER;
      l_cnt_eqm           NUMBER;   --количество идентификаторов оборудования
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || pkg_common.boolean_to_char (p_is_update_validity_date)
                         || pkg_constants.c_delimiter
                         || pkg_common.boolean_to_char (p_is_process_opened_doc)
                         || pkg_constants.c_delimiter
                         || pkg_common.boolean_to_char (p_is_detailed)
                         || ')',
                         pkg_name
                        );

      --Чиститим
      DELETE FROM tmp_ss1;

      --Количество идентификаторов складов
      l_cnt_stk := pkg_stock.g_tab_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'Count stocks = ' || l_cnt_stk, pkg_name);

      IF l_cnt_stk = 0
      THEN
         raise_application_error (-20001, 'Stocks not found');
      END IF;

      --Установием количество идентификаторов оборудования
      l_cnt_eqm := pkg_equipment.g_tab_model_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'Count equipment = ' || l_cnt_eqm, pkg_name);

      IF p_is_process_opened_doc
      THEN
         --Получим записи по открытым и закрытым документам с определенным типом оборудования
         IF p_is_detailed
         THEN
            --Детализированная информация по открытым и закрытым документам
            INSERT INTO tmp_ss1
                        (stock_id, equipment_model_id, seria_start, seria_end, quantity_onstock,
                         quantity_reserved, quantity_announced, valid_until, status,
                         equipment_batch_id)
               SELECT   k.stock_id, k.equipment_model_id, k.seria_start, k.seria_end,
                        SUM (k.quantity_onstock), SUM (k.quantity_reserved),
                        SUM (k.quantity_announced), MAX (k.valid_until), MAX (status_id),
                        k.equipment_batch_id
                   FROM (SELECT --+ NO_MERGE(sq) PUSH_SUBQ
                                sq.stock_id, dd.equipment_model_id, dd.seria_start, dd.seria_end,
                                CASE
                                   WHEN (sq.quantity_sign = -1)
                                      THEN -dd.quantity
                                   WHEN (sq.quantity_sign = 1) AND (sq.stat = 1)
                                      THEN dd.quantity
                                   ELSE 0
                                END quantity_onstock,
                                CASE
                                   WHEN (sq.quantity_sign = -1)
                                        AND (sq.stat = 0)
                                      THEN dd.quantity
                                   ELSE 0
                                END quantity_reserved,
                                CASE
                                   WHEN (sq.quantity_sign = 1)
                                   AND (sq.stat = 0)
                                      THEN dd.quantity
                                   ELSE 0
                                END quantity_announced,
                                dd.valid_until, dd.status_id, dd.equipment_batch_id
                           FROM (SELECT --+ CARDINALITY(stk 10) INDEX(dh IDX_DOCHEADER_SO_DD_DMO) NO_EXPAND
                                        dh.ID, dh.stock_out_id AS stock_id, -1 AS quantity_sign,
                                        dh.status_id AS stat
                                   FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                        doc_header dh
                                  WHERE dh.stock_out_id = stk.COLUMN_VALUE
                                    AND dh.doc_date > pkg_constants.c_minsysdate
                                    AND dh.doc_date <= p_date
                                    AND dh.doc_type_id IN (102, 103, 107)
                                    AND dh.status_id IN (0, 1)
                                 UNION ALL
                                 SELECT --+ CARDINALITY(stk 10) INDEX(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                        dh.ID, dh.stock_in_id AS stock_id, 1 AS quantity_sign,
                                        dh.status_id AS stat
                                   FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                        doc_header dh
                                  WHERE dh.stock_in_id = stk.COLUMN_VALUE
                                    AND dh.doc_date > pkg_constants.c_minsysdate
                                    AND dh.doc_date <= p_date
                                    AND dh.doc_type_id IN (101, 103, 104, 105, 106, 108, 109, 113)
                                    AND dh.status_id IN (0, 1)) sq,
                                doc_detail dd
                          WHERE sq.ID = dd.doc_header_id
                            AND (   (dd.equipment_model_id IN (
                                        SELECT --+ CARDINALITY(eqm 2)
                                               COLUMN_VALUE
                                          FROM TABLE
                                                    (CAST (pkg_equipment.g_tab_model_id AS ct_number)
                                                    ) eqm)
                                    )
                                 OR (l_cnt_eqm = 0)
                                )) k
               GROUP BY k.stock_id,
                        k.equipment_model_id,
                        k.seria_start,
                        k.seria_end,
                        k.equipment_batch_id
                 HAVING SUM (k.quantity_onstock) <> 0
                     OR SUM (k.quantity_reserved) <> 0
                     OR SUM (k.quantity_announced) <> 0;

            pkg_db_util.DEBUG (prc_name,
                                  'Inserted count open and closed documents with detailed = '
                               || SQL%ROWCOUNT,
                               pkg_name
                              );
         ELSIF NOT p_is_detailed
         THEN
            --Не детализированная информация по открытым и закрытым документам
            INSERT INTO tmp_ss1
                        (stock_id, equipment_model_id, quantity_onstock, quantity_reserved,
                         quantity_announced, equipment_batch_id)
               SELECT   k.stock_id, k.equipment_model_id, SUM (k.quantity_onstock),
                        SUM (k.quantity_reserved), SUM (k.quantity_announced),
                        k.equipment_batch_id
                   FROM (SELECT --+ NO_MERGE(sq) PUSH_SUBQ
                                sq.stock_id, dd.equipment_model_id, dd.seria_start, dd.seria_end,
                                CASE
                                   WHEN (sq.quantity_sign = -1)
                                      THEN -dd.quantity
                                   WHEN (sq.quantity_sign = 1) AND (sq.stat = 1)
                                      THEN dd.quantity
                                   ELSE 0
                                END quantity_onstock,
                                CASE
                                   WHEN (sq.quantity_sign = -1)
                                        AND (sq.stat = 0)
                                      THEN dd.quantity
                                   ELSE 0
                                END quantity_reserved,
                                CASE
                                   WHEN (sq.quantity_sign = 1)
                                   AND (sq.stat = 0)
                                      THEN dd.quantity
                                   ELSE 0
                                END quantity_announced,
                                dd.valid_until, dd.status_id, dd.equipment_batch_id
                           FROM (SELECT --+ CARDINALITY(stk 10) INDEX(dh IDX_DOCHEADER_SO_DD_DMO) NO_EXPAND
                                        dh.ID, dh.stock_out_id AS stock_id, -1 AS quantity_sign,
                                        dh.status_id AS stat
                                   FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                        doc_header dh
                                  WHERE dh.stock_out_id = stk.COLUMN_VALUE
                                    AND dh.doc_date > pkg_constants.c_minsysdate
                                    AND dh.doc_date <= p_date
                                    AND dh.doc_type_id IN (102, 103, 107)
                                    AND dh.status_id IN (0, 1)
                                 UNION ALL
                                 SELECT --+ CARDINALITY(stk 10) INDEX(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                        dh.ID, dh.stock_in_id AS stock_id, 1 AS quantity_sign,
                                        dh.status_id AS stat
                                   FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                        doc_header dh
                                  WHERE dh.stock_in_id = stk.COLUMN_VALUE
                                    AND dh.doc_date > pkg_constants.c_minsysdate
                                    AND dh.doc_date <= p_date
                                    AND dh.doc_type_id IN (101, 103, 104, 105, 106, 108, 109, 113)
                                    AND dh.status_id IN (0, 1)) sq,
                                doc_detail dd
                          WHERE sq.ID = dd.doc_header_id
                            AND (   (dd.equipment_model_id IN (
                                        SELECT --+ CARDINALITY(eqm 2)
                                               COLUMN_VALUE
                                          FROM TABLE
                                                    (CAST (pkg_equipment.g_tab_model_id AS ct_number)
                                                    ) eqm)
                                    )
                                 OR (l_cnt_eqm = 0)
                                )) k
               GROUP BY k.stock_id, k.equipment_model_id, k.equipment_batch_id
                 HAVING SUM (k.quantity_onstock) <> 0
                     OR SUM (k.quantity_reserved) <> 0
                     OR SUM (k.quantity_announced) <> 0;

            pkg_db_util.DEBUG (prc_name,
                                  'Inserted count open and closed documents with grouping = '
                               || SQL%ROWCOUNT,
                               pkg_name
                              );
         END IF;
      ELSIF NOT p_is_process_opened_doc
      THEN
         --Получим записи по закрытым документам с определенным типом оборудования
         IF p_is_detailed
         THEN
            --Детализированная информация по закрытым документам
            INSERT INTO tmp_ss1
                        (stock_id, equipment_model_id, seria_start, seria_end, quantity_onstock,
                         quantity_reserved, quantity_announced, valid_until, status,
                         equipment_batch_id)
               SELECT   --+ PUSH_SUBQ NO_MERGE(sq)
                        sq.stock_id, dd.equipment_model_id, dd.seria_start, dd.seria_end,
                        SUM (DECODE (sq.quantity_sign, -1, -dd.quantity, dd.quantity)
                            ) AS quantity_onstock,
                        0 AS quantity_reserved, 0 AS quantity_announced, MAX (dd.valid_until),
                        MAX (dd.status_id), dd.equipment_batch_id
                   FROM (SELECT --+ CARDINALITY(stk 10) INDEX(dh IDX_DOCHEADER_SO_DD_DMO) NO_EXPAND
                                dh.ID, dh.stock_out_id AS stock_id, -1 AS quantity_sign
                           FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk, doc_header dh
                          WHERE dh.stock_out_id = stk.COLUMN_VALUE
                            AND dh.doc_date > pkg_constants.c_minsysdate
                            AND dh.doc_date <= p_date
                            AND dh.doc_type_id IN (102, 103, 107)
                            AND dh.status_id = 1
                         UNION ALL
                         SELECT --+ CARDINALITY(stk 10) INDEX(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                dh.ID, dh.stock_in_id AS stock_id, 1 AS quantity_sign
                           FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk, doc_header dh
                          WHERE dh.stock_in_id = stk.COLUMN_VALUE
                            AND dh.doc_date > pkg_constants.c_minsysdate
                            AND dh.doc_date <= p_date
                            AND dh.doc_type_id IN (101, 103, 104, 105, 106, 108, 109, 113)
                            AND dh.status_id = 1) sq,
                        doc_detail dd
                  WHERE sq.ID = dd.doc_header_id
                    AND (   (dd.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 2)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                            )
                         OR (l_cnt_eqm = 0)
                        )
               GROUP BY sq.stock_id,
                        dd.equipment_model_id,
                        dd.seria_start,
                        dd.seria_end,
                        dd.equipment_batch_id
                 HAVING SUM (DECODE (sq.quantity_sign, -1, -dd.quantity, dd.quantity)) <> 0;

            pkg_db_util.DEBUG (prc_name,
                                  'Inserted count only closed documents with detailed = '
                               || SQL%ROWCOUNT,
                               pkg_name
                              );
         ELSIF NOT p_is_detailed
         THEN
            --Не детализированная информация по закрытым документам
            INSERT INTO tmp_ss1
                        (stock_id, equipment_model_id, quantity_onstock, quantity_reserved,
                         quantity_announced, equipment_batch_id)
               SELECT   --+ PUSH_SUBQ NO_MERGE(sq)
                        sq.stock_id, dd.equipment_model_id,
                        SUM (DECODE (sq.quantity_sign, -1, -dd.quantity, dd.quantity)
                            ) AS quantity_onstock,
                        0 AS quantity_reserved, 0 AS quantity_announced, dd.equipment_batch_id
                   FROM (SELECT --+ CARDINALITY(stk 10) INDEX(dh IDX_DOCHEADER_SO_DD_DMO) NO_EXPAND
                                dh.ID, dh.stock_out_id AS stock_id, -1 AS quantity_sign
                           FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk, doc_header dh
                          WHERE dh.stock_out_id = stk.COLUMN_VALUE
                            AND dh.doc_date > pkg_constants.c_minsysdate
                            AND dh.doc_date <= p_date
                            AND dh.doc_type_id IN (102, 103, 107)
                            AND dh.status_id = 1
                         UNION ALL
                         SELECT --+ CARDINALITY(stk 10) INDEX(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                dh.ID, dh.stock_in_id AS stock_id, 1 AS quantity_sign
                           FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk, doc_header dh
                          WHERE dh.stock_in_id = stk.COLUMN_VALUE
                            AND dh.doc_date > pkg_constants.c_minsysdate
                            AND dh.doc_date <= p_date
                            AND dh.doc_type_id IN (101, 103, 104, 105, 106, 108, 109, 113)
                            AND dh.status_id = 1) sq,
                        doc_detail dd
                  WHERE sq.ID = dd.doc_header_id
                    AND (   (dd.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 2)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                            )
                         OR (l_cnt_eqm = 0)
                        )
               GROUP BY sq.stock_id, dd.equipment_model_id, dd.equipment_batch_id
                 HAVING SUM (DECODE (sq.quantity_sign, -1, -dd.quantity, dd.quantity)) <> 0;

            pkg_db_util.DEBUG (prc_name,
                                  'Inserted count only closed documents with grouping = '
                               || SQL%ROWCOUNT,
                               pkg_name
                              );
         END IF;
      END IF;

      --Изменим срок годности оборудования для документов типа 114
      --При этом документе склады отправители = складам получателям
      IF p_is_update_validity_date AND p_is_detailed
      THEN
         MERGE INTO tmp_ss1 t
            USING (SELECT   --+ CARDINALITY(stk 10) INDEX(dh I_DOC_HEADER_DOCNO) INDEX(dd IDX_DOCDETAIL_DHI_EMI_DMI_DMO)
                            dh.stock_out_id, dd.equipment_model_id, dd.seria_start, dd.seria_end,
                            MAX (dd.valid_until) AS valid_until
                       FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                            doc_header dh,
                            doc_detail dd
                      WHERE dh.status_id IN (0, 1)
                        AND dh.doc_no LIKE 'EVU-%'
                        AND dh.stock_out_id = stk.COLUMN_VALUE   --INDEX(dh IDX_DOCHEADER_SO_DD_DMO)
                        AND dh.doc_type_id = 114
                        AND dh.doc_date > pkg_constants.c_minsysdate
                        AND dh.doc_date <= p_date
                        AND dh.ID = dd.doc_header_id
                   GROUP BY dh.stock_out_id, dd.equipment_model_id, dd.seria_start, dd.seria_end) sq
            ON (    t.stock_id = sq.stock_out_id
                AND t.equipment_model_id = sq.equipment_model_id
                AND t.seria_start = sq.seria_start
                AND t.seria_end = sq.seria_end)
            WHEN MATCHED THEN
               UPDATE
                  SET t.valid_until = sq.valid_until
            WHEN NOT MATCHED THEN
               INSERT (t.stock_id, t.equipment_model_id, t.quantity_onstock, t.quantity_reserved,
                       t.quantity_announced)
               VALUES (0, 0, 0, 0, 0);
         pkg_db_util.DEBUG (prc_name, 'Merged counts documents = ' || SQL%ROWCOUNT, pkg_name);

         DELETE FROM tmp_ss1 t
               WHERE t.stock_id = 0 AND t.equipment_model_id = 0;

         pkg_db_util.DEBUG (prc_name, 'Deleted counts documents = ' || SQL%ROWCOUNT, pkg_name);
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END state_prepare_direct;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 03.04.2007 10:12
-- Version :
--   1 03.04.2007
--   5 24.07.2007
-- Modification : pkg_stock.state_prepare
-- Editor  : Skripnik Petr (SP)
-- Changed :
-- Purpose : Получаем все движения оборудования на период времени.Состояние
--           строется от состояния на текущую дату по движению документов в обратном порядке
--------------------------------------------------------------------------------
   PROCEDURE state_prepare_reverse (
      p_date                      IN   DATE,   --конечная дата диапазона
      p_is_update_validity_date   IN   BOOLEAN,   --флаг обработки документов об изменении срока годности оборудования
      p_is_process_opened_doc     IN   BOOLEAN,   --флаг обработки открытых документов
      p_is_detailed               IN   BOOLEAN DEFAULT TRUE
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'state_prepare_reverse_5';
      l_cnt_stk           NUMBER;
      l_cnt_eqm           NUMBER;   --количество идентификаторов оборудования
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || pkg_common.boolean_to_char (p_is_update_validity_date)
                         || pkg_constants.c_delimiter
                         || pkg_common.boolean_to_char (p_is_process_opened_doc)
                         || pkg_constants.c_delimiter
                         || pkg_common.boolean_to_char (p_is_detailed)
                         || ')',
                         pkg_name
                        );

      --Чиститим
      DELETE FROM tmp_ss1;

      --Количество идентификаторов складов
      l_cnt_stk := pkg_stock.g_tab_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'Count stocks = ' || l_cnt_stk, pkg_name);

      IF l_cnt_stk = 0
      THEN
         raise_application_error (-20001, 'Stocks not found');
      END IF;

      --Установием количество идентификаторов оборудования
      l_cnt_eqm := pkg_equipment.g_tab_model_id.COUNT;
      pkg_db_util.DEBUG (prc_name, 'Count equipment = ' || l_cnt_eqm, pkg_name);

      IF p_is_process_opened_doc
      THEN
         --Получим записи по открытым и закрытым документам с определенным типом оборудования
         IF p_is_detailed
         THEN
            --Детализированная информация по открытым и закрытым документам
            INSERT INTO tmp_ss1
                        (stock_id, equipment_model_id, seria_start, seria_end, quantity_onstock,
                         quantity_reserved, quantity_announced, valid_until, status,
                         equipment_batch_id)
               SELECT   a.stock_id, a.equipment_model_id, a.seria_start, a.seria_end,
                        SUM (a.quantity_onstock), SUM (a.quantity_reserved),
                        SUM (a.quantity_announced), MAX (a.valid_until), MAX (status_id),
                        a.equipment_batch_id
                   FROM (SELECT d.stock_id, d.equipment_model_id, d.seria_start, d.seria_end,
                                d.quantity_onstock, d.quantity_reserved, d.quantity_announced,
                                d.valid_until, status_id, d.equipment_batch_id
                           FROM (SELECT --+ NO_MERGE(sq) PUSH_SUBQ
                                        sq.stock_id, dd.equipment_model_id, dd.seria_start,
                                        dd.seria_end,
                                        CASE
                                           WHEN (sq.quantity_sign = 1)
                                              THEN dd.quantity
                                           WHEN (sq.quantity_sign = -1)
                                           AND (sq.stat = 1)
                                              THEN -dd.quantity
                                           ELSE 0
                                        END quantity_onstock,
                                        CASE
                                           WHEN (sq.quantity_sign = 1)
                                           AND (sq.stat = 0)
                                              THEN -dd.quantity
                                           ELSE 0
                                        END quantity_reserved,
                                        CASE
                                           WHEN (sq.quantity_sign = -1)
                                           AND (sq.stat = 0)
                                              THEN -dd.quantity
                                           ELSE 0
                                        END quantity_announced,
                                        dd.valid_until, dd.status_id, dd.equipment_batch_id
                                   FROM (SELECT --+ CARDINALITY(stk 10) INDEX_DESC(dh IDX_DOCHEADER_SO_DD_DMO) NO_EXPAND
                                                dh.ID, dh.stock_out_id AS stock_id,
                                                1 AS quantity_sign, dh.status_id AS stat
                                           FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                                doc_header dh
                                          WHERE dh.stock_out_id = stk.COLUMN_VALUE
                                            AND dh.doc_date > p_date
                                            AND dh.doc_date <= SYSDATE
                                            AND dh.doc_type_id IN (102, 103, 107)
                                            AND dh.status_id IN (0, 1)
                                         UNION ALL
                                         SELECT --+ CARDINALITY(stk 10) INDEX_DESC(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                                dh.ID, dh.stock_in_id AS stock_id,
                                                -1 AS quantity_sign, dh.status_id AS stat
                                           FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                                doc_header dh
                                          WHERE dh.stock_in_id = stk.COLUMN_VALUE
                                            AND dh.doc_date > p_date
                                            AND dh.doc_date <= SYSDATE
                                            AND dh.doc_type_id IN
                                                           (101, 103, 104, 105, 106, 108, 109, 113)
                                            AND dh.status_id IN (0, 1)) sq,
                                        doc_detail dd
                                  WHERE sq.ID = dd.doc_header_id
                                    AND (   (dd.equipment_model_id IN (
                                                SELECT --+ CARDINALITY(eqm 2)
                                                       COLUMN_VALUE
                                                  FROM TABLE
                                                          (CAST
                                                              (pkg_equipment.g_tab_model_id AS ct_number
                                                              )
                                                          ) eqm)
                                            )
                                         OR (l_cnt_eqm = 0)
                                        )) d
                         UNION ALL
                         SELECT --+ INDEX(ss I_STOCK_STATE_STOCK_ID)
                                ss.stock_id, ss.equipment_model_id, ss.seria_start, ss.seria_end,
                                ss.quantity_onstock, ss.quantity_reserved, ss.quantity_announced,
                                ss.create_date AS valid_until, ss.status AS status_id,
                                ss.equipment_batch_id
                           FROM stock_state ss
                          WHERE ss.stock_id IN (
                                              SELECT --+ CARDINALITY(stk 5)
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                            AND l_cnt_eqm = 0
                         UNION ALL
                         SELECT --+ INDEX(ss I_STOCK_STATE_EQM)
                                ss.stock_id, ss.equipment_model_id, ss.seria_start, ss.seria_end,
                                ss.quantity_onstock, ss.quantity_reserved, ss.quantity_announced,
                                ss.create_date AS valid_until, ss.status AS status_id,
                                ss.equipment_batch_id
                           FROM stock_state ss
                          WHERE ss.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 2)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                            AND ss.stock_id IN (
                                              SELECT --+ CARDINALITY(stk 5)
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                            AND l_cnt_eqm > 0) a
               GROUP BY a.stock_id,
                        a.equipment_model_id,
                        a.seria_start,
                        a.seria_end,
                        a.equipment_batch_id
                 HAVING SUM (a.quantity_onstock) <> 0
                     OR SUM (a.quantity_reserved) <> 0
                     OR SUM (a.quantity_announced) <> 0;

            pkg_db_util.DEBUG (prc_name,
                                  'Inserted open and closed documents with detailed = '
                               || SQL%ROWCOUNT,
                               pkg_name
                              );
         ELSIF NOT p_is_detailed
         THEN
            --Не детализированная информация по открытым и закрытым документам
            INSERT INTO tmp_ss1
                        (stock_id, equipment_model_id, quantity_onstock, quantity_reserved,
                         quantity_announced, equipment_batch_id)
               SELECT   a.stock_id, a.equipment_model_id, SUM (a.quantity_onstock),
                        SUM (a.quantity_reserved), SUM (a.quantity_announced),
                        a.equipment_batch_id
                   FROM (SELECT d.stock_id, d.equipment_model_id, d.quantity_onstock,
                                d.quantity_reserved, d.quantity_announced, d.equipment_batch_id
                           FROM (SELECT --+ NO_MERGE(sq) PUSH_SUBQ
                                        sq.stock_id, dd.equipment_model_id,
                                        CASE
                                           WHEN (sq.quantity_sign = 1)
                                              THEN dd.quantity
                                           WHEN (sq.quantity_sign = -1)
                                           AND (sq.stat = 1)
                                              THEN -dd.quantity
                                           ELSE 0
                                        END quantity_onstock,
                                        CASE
                                           WHEN (sq.quantity_sign = 1)
                                           AND (sq.stat = 0)
                                              THEN -dd.quantity
                                           ELSE 0
                                        END quantity_reserved,
                                        CASE
                                           WHEN (sq.quantity_sign = -1)
                                           AND (sq.stat = 0)
                                              THEN -dd.quantity
                                           ELSE 0
                                        END quantity_announced,
                                        dd.equipment_batch_id
                                   FROM (SELECT --+ CARDINALITY(stk 10) INDEX_DESC(dh IDX_DOCHEADER_SO_DD_DMO) NO_EXPAND
                                                dh.ID, dh.stock_out_id AS stock_id,
                                                1 AS quantity_sign, dh.status_id AS stat
                                           FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                                doc_header dh
                                          WHERE dh.stock_out_id = stk.COLUMN_VALUE
                                            AND dh.doc_date > p_date
                                            AND dh.doc_date <= SYSDATE
                                            AND dh.doc_type_id IN (102, 103, 107)
                                            AND dh.status_id IN (0, 1)
                                         UNION ALL
                                         SELECT --+ CARDINALITY(stk 10) INDEX_DESC(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                                dh.ID, dh.stock_in_id AS stock_id,
                                                -1 AS quantity_sign, dh.status_id AS stat
                                           FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                                doc_header dh
                                          WHERE dh.stock_in_id = stk.COLUMN_VALUE
                                            AND dh.doc_date > p_date
                                            AND dh.doc_date <= SYSDATE
                                            AND dh.doc_type_id IN
                                                           (101, 103, 104, 105, 106, 108, 109, 113)
                                            AND dh.status_id IN (0, 1)) sq,
                                        doc_detail dd
                                  WHERE sq.ID = dd.doc_header_id
                                    AND (   (dd.equipment_model_id IN (
                                                SELECT --+ CARDINALITY(eqm 2)
                                                       COLUMN_VALUE
                                                  FROM TABLE
                                                          (CAST
                                                              (pkg_equipment.g_tab_model_id AS ct_number
                                                              )
                                                          ) eqm)
                                            )
                                         OR (l_cnt_eqm = 0)
                                        )) d
                         UNION ALL
                         SELECT --+ INDEX(ss I_STOCK_STATE_STOCK_ID)
                                ss.stock_id, ss.equipment_model_id, ss.quantity_onstock,
                                ss.quantity_reserved, ss.quantity_announced, ss.equipment_batch_id
                           FROM stock_state ss
                          WHERE ss.stock_id IN (
                                              SELECT --+ CARDINALITY(stk 5)
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                            AND l_cnt_eqm = 0
                         UNION ALL
                         SELECT --+ INDEX(ss I_STOCK_STATE_EQM)
                                ss.stock_id, ss.equipment_model_id, ss.quantity_onstock,
                                ss.quantity_reserved, ss.quantity_announced, ss.equipment_batch_id
                           FROM stock_state ss
                          WHERE ss.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 2)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                            AND ss.stock_id IN (
                                              SELECT --+ CARDINALITY(stk 5)
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                            AND l_cnt_eqm > 0) a
               GROUP BY a.stock_id, a.equipment_model_id, a.equipment_batch_id
                 HAVING SUM (a.quantity_onstock) <> 0
                     OR SUM (a.quantity_reserved) <> 0
                     OR SUM (a.quantity_announced) <> 0;

            pkg_db_util.DEBUG (prc_name,
                                  'Inserted open and closed documents with grouping = '
                               || SQL%ROWCOUNT,
                               pkg_name
                              );
         END IF;
      ELSIF NOT p_is_process_opened_doc
      THEN
         --Получим записи по закрытым документам с определенным типом оборудования
         IF p_is_detailed
         THEN
            --Детализированная информация по закрытым документам
            INSERT INTO tmp_ss1
                        (stock_id, equipment_model_id, seria_start, seria_end, quantity_onstock,
                         quantity_reserved, quantity_announced, valid_until, status,
                         equipment_batch_id)
               SELECT   k.stock_id, k.equipment_model_id, k.seria_start, k.seria_end,
                        SUM (k.quantity_onstock) AS quantity_onstock, 0 AS quantity_reserved,
                        0 AS quantity_announced, MAX (k.valid_until) AS create_date,
                        MAX (status_id) AS status_id, k.equipment_batch_id
                   FROM (SELECT --+ PUSH_SUBQ ORDERED
                                sq.stock_id, dd.equipment_model_id, dd.seria_start, dd.seria_end,
                                DECODE (sq.quantity_sign,
                                        -1, -dd.quantity,
                                        dd.quantity
                                       ) AS quantity_onstock,
                                dd.valid_until, dd.status_id, dd.equipment_batch_id
                           FROM (SELECT --+ CARDINALITY(stk 10) INDEX_DESC(dh IDX_DOCHEADER_SO_DD_DMO) NO_EXPAND
                                        dh.ID, dh.stock_out_id AS stock_id, 1 AS quantity_sign
                                   FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                        doc_header dh
                                  WHERE dh.stock_out_id = stk.COLUMN_VALUE
                                    AND dh.doc_date > p_date
                                    AND dh.doc_date <= SYSDATE
                                    AND dh.doc_type_id IN (102, 103, 107)
                                    AND dh.status_id = 1
                                 UNION ALL
                                 SELECT --+ CARDINALITY(stk 10) INDEX_DESC(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                        dh.ID, dh.stock_in_id AS stock_id, -1 AS quantity_sign
                                   FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                        doc_header dh
                                  WHERE dh.stock_in_id = stk.COLUMN_VALUE
                                    AND dh.doc_date > p_date
                                    AND dh.doc_date <= SYSDATE
                                    AND dh.doc_type_id IN (101, 103, 104, 105, 106, 108, 109, 113)
                                    AND dh.status_id = 1) sq,
                                doc_detail dd
                          WHERE sq.ID = dd.doc_header_id
                            AND (   (dd.equipment_model_id IN (
                                        SELECT --+ CARDINALITY(eqm 2)
                                               COLUMN_VALUE
                                          FROM TABLE
                                                    (CAST (pkg_equipment.g_tab_model_id AS ct_number)
                                                    ) eqm)
                                    )
                                 OR (l_cnt_eqm = 0)
                                )
                         UNION ALL
                         SELECT --+ INDEX(ss I_STOCK_STATE_STOCK_ID)
                                ss.stock_id, ss.equipment_model_id, ss.seria_start, ss.seria_end,
                                ss.quantity_onstock AS quantity, ss.create_date AS valid_until,
                                ss.status AS status_id, ss.equipment_batch_id
                           FROM stock_state ss
                          WHERE ss.stock_id IN (
                                              SELECT --+ CARDINALITY(stk 5)
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                            AND ss.quantity_onstock > 0
                            AND l_cnt_eqm = 0
                         UNION ALL
                         SELECT --+ INDEX(ss I_STOCK_STATE_EQM)
                                ss.stock_id, ss.equipment_model_id, ss.seria_start, ss.seria_end,
                                ss.quantity_onstock AS quantity, ss.create_date AS valid_until,
                                ss.status AS status_id, ss.equipment_batch_id
                           FROM stock_state ss
                          WHERE ss.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 2)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                            AND ss.stock_id IN (
                                              SELECT --+ CARDINALITY(stk 5)
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                            AND ss.quantity_onstock > 0
                            AND l_cnt_eqm > 0) k
               GROUP BY k.stock_id,
                        k.equipment_model_id,
                        k.seria_start,
                        k.seria_end,
                        k.equipment_batch_id
                 HAVING SUM (k.quantity_onstock) <> 0;

            pkg_db_util.DEBUG (prc_name,
                               'Inserted only closed documents with detailed = ' || SQL%ROWCOUNT,
                               pkg_name
                              );
         ELSIF NOT p_is_detailed
         THEN
            --Не детализированная информация по закрытым документам
            INSERT INTO tmp_ss1
                        (stock_id, equipment_model_id, quantity_onstock, quantity_reserved,
                         quantity_announced, equipment_batch_id)
               SELECT   k.stock_id, k.equipment_model_id,
                        SUM (k.quantity_onstock) AS quantity_onstock, 0 AS quantity_reserved,
                        0 AS quantity_announced, k.equipment_batch_id
                   FROM (SELECT --+ PUSH_SUBQ ORDERED
                                sq.stock_id, dd.equipment_model_id,
                                DECODE (sq.quantity_sign,
                                        -1, -dd.quantity,
                                        dd.quantity
                                       ) AS quantity_onstock,
                                dd.equipment_batch_id
                           FROM (SELECT --+ CARDINALITY(stk 10) INDEX_DESC(dh IDX_DOCHEADER_SO_DD_DMO) NO_EXPAND
                                        dh.ID, dh.stock_out_id AS stock_id, 1 AS quantity_sign
                                   FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                        doc_header dh
                                  WHERE dh.stock_out_id = stk.COLUMN_VALUE
                                    AND dh.doc_date > p_date
                                    AND dh.doc_date <= SYSDATE
                                    AND dh.doc_type_id IN (102, 103, 107)
                                    AND dh.status_id = 1
                                 UNION ALL
                                 SELECT --+ CARDINALITY(stk 10) INDEX_DESC(dh IDX_DOCHEADER_SI_DD_DMI) NO_EXPAND
                                        dh.ID, dh.stock_in_id AS stock_id, -1 AS quantity_sign
                                   FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                        doc_header dh
                                  WHERE dh.stock_in_id = stk.COLUMN_VALUE
                                    AND dh.doc_date > p_date
                                    AND dh.doc_date <= SYSDATE
                                    AND dh.doc_type_id IN (101, 103, 104, 105, 106, 108, 109, 113)
                                    AND dh.status_id = 1) sq,
                                doc_detail dd
                          WHERE sq.ID = dd.doc_header_id
                            AND (   (dd.equipment_model_id IN (
                                        SELECT --+ CARDINALITY(eqm 2)
                                               COLUMN_VALUE
                                          FROM TABLE
                                                    (CAST (pkg_equipment.g_tab_model_id AS ct_number)
                                                    ) eqm)
                                    )
                                 OR (l_cnt_eqm = 0)
                                )
                         UNION ALL
                         SELECT --+ INDEX(ss I_STOCK_STATE_STOCK_ID)
                                ss.stock_id, ss.equipment_model_id, ss.quantity_onstock AS quantity,
                                ss.equipment_batch_id
                           FROM stock_state ss
                          WHERE ss.stock_id IN (
                                              SELECT --+ CARDINALITY(stk 5)
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                            AND ss.quantity_onstock > 0
                            AND l_cnt_eqm = 0
                         UNION ALL
                         SELECT --+ INDEX(ss I_STOCK_STATE_EQM)
                                ss.stock_id, ss.equipment_model_id, ss.quantity_onstock AS quantity,
                                ss.equipment_batch_id
                           FROM stock_state ss
                          WHERE ss.equipment_model_id IN (
                                    SELECT --+ CARDINALITY(eqm 2)
                                           COLUMN_VALUE
                                      FROM TABLE (CAST (pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                            AND ss.stock_id IN (
                                              SELECT --+ CARDINALITY(stk 5)
                                                     COLUMN_VALUE
                                                FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk)
                            AND ss.quantity_onstock > 0
                            AND l_cnt_eqm > 0) k
               GROUP BY k.stock_id, k.equipment_model_id, k.equipment_batch_id
                 HAVING SUM (k.quantity_onstock) <> 0;

            pkg_db_util.DEBUG (prc_name,
                               'Inserted only closed documents with grouping = ' || SQL%ROWCOUNT,
                               pkg_name
                              );
         END IF;
      END IF;

      --Изменим срок годности оборудования для документов типа 114
      --При этом документе склады отправители = складам получателям
      IF p_is_update_validity_date AND p_is_detailed
      THEN
         MERGE INTO tmp_ss1 t
            USING (SELECT   --+ CARDINALITY(stk 10) INDEX(dh I_DOC_HEADER_DOCNO) INDEX(dd IDX_DOCDETAIL_DHI_EMI_DMI_DMO)
                            dh.stock_out_id, dd.equipment_model_id, dd.seria_start, dd.seria_end,
                            MAX (dd.valid_until) AS valid_until
                       FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                            doc_header dh,
                            doc_detail dd
                      WHERE dh.status_id IN (0, 1)
                        AND dh.doc_no LIKE 'EVU-%'
                        AND dh.stock_out_id = stk.COLUMN_VALUE   --INDEX(dh IDX_DOCHEADER_SO_DD_DMO)
                        AND dh.doc_type_id = 114
                        AND dh.doc_date > pkg_constants.c_minsysdate
                        AND dh.doc_date <= p_date
                        AND dh.ID = dd.doc_header_id
                   GROUP BY dh.stock_out_id, dd.equipment_model_id, dd.seria_start, dd.seria_end) sq
            ON (    t.stock_id = sq.stock_out_id
                AND t.equipment_model_id = sq.equipment_model_id
                AND t.seria_start = sq.seria_start
                AND t.seria_end = sq.seria_end)
            WHEN MATCHED THEN
               UPDATE
                  SET t.valid_until = sq.valid_until
            WHEN NOT MATCHED THEN
               INSERT (t.stock_id, t.equipment_model_id, t.quantity_onstock, t.quantity_reserved,
                       t.quantity_announced)
               VALUES (0, 0, 0, 0, 0);
         pkg_db_util.DEBUG (prc_name, 'Merged counts documents = ' || SQL%ROWCOUNT, pkg_name);

         DELETE FROM tmp_ss1 t
               WHERE t.stock_id = 0 AND t.equipment_model_id = 0;

         pkg_db_util.DEBUG (prc_name, 'Deleted counts documents = ' || SQL%ROWCOUNT, pkg_name);
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END state_prepare_reverse;

END;
/
