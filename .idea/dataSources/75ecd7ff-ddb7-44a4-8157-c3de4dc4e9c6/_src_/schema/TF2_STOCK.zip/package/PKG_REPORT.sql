CREATE PACKAGE pkg_report
AS
--******************************************************************************
-- Author  : Skripnik Petr
-- Created : 06.06.2007 12:55
-- Modification : report_management
-- Purpose : Work with the reports
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ------------------------------------------
--****************************************************************************--
--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 19.09.2007 10:31
-- Version : 1
-- Modification : report_management.reversebalancelist -> pkg_out_stock.reverse_balance
-- Editor  :
-- Changed :
-- Purpose : Построение сальдовых ведомостей
-- Problems: IN-параметр p_group_by_stocks BOOLEAN не поддерживается клиентом
--------------------------------------------------------------------------------
   PROCEDURE balance (
      p_group_by_stocks      IN       NUMBER,
      p_from_date            IN       DATE,
      p_to_date              IN       DATE,
      p_cur_moving           OUT      sys_refcursor,
      p_cur_start_salda      OUT      sys_refcursor,
      p_stock_id             IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_equipment_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 17.09.2007 16:17
-- Version : 1 17.09.2007
-- Modification : report_management.reversebalancelist -> pkg_out_stock.reverse_balance
-- Editor  :
-- Changed :
-- Purpose : Построение сальдовых ведомостей сгруппирпованных по серии оборудования
--------------------------------------------------------------------------------
   PROCEDURE balance_group_by_series (
      p_from_date            IN       DATE,
      p_to_date              IN       DATE,
      p_cur_moving           OUT      sys_refcursor,
      p_stock_id             IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_equipment_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 17.09.2007 16:17
-- Version : 1 17.09.2007
-- Modification : report_management.reversebalancelist -> pkg_out_stock.reverse_balance
-- Editor  :
-- Changed :
-- Purpose : Построение сальдовых ведомостей сгруппирпованных по складу
--------------------------------------------------------------------------------
   PROCEDURE balance_group_by_stocks (
      p_from_date            IN       DATE,
      p_to_date              IN       DATE,
      p_cur_moving           OUT      sys_refcursor,
      p_stock_id             IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_equipment_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 19.06.2007 10:39
-- Version : 1
-- Modification : report_management.equipmentmotion -> pkg_report.equipment_move
-- Editor  :
-- Changed :
-- Purpose : Движение оборудования c группировкой последовательно идущих серий в
--           одну для одного дня,склада,партии
--------------------------------------------------------------------------------
   PROCEDURE equipment_move_group_by_series (
      p_doc_type             IN       NUMBER,
      p_from_date            IN       DATE,
      p_to_date              IN       DATE,
      p_equipment_model_id   IN       pkg_common.t_num,
      p_cur_eqm_move         OUT      sys_refcursor,
      p_stock_id_out         IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_stock_id_in          IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 02.07.2007 15:44
-- Version : 1
-- Modification : report_management.equipmentmotion -> pkg_report.equipment_move
-- Editor  :
-- Changed :
-- Purpose : Движение оборудования c группировкой по складам и модели оборудования
--------------------------------------------------------------------------------
   PROCEDURE equipment_move_group_by_stocks (
      p_doc_type             IN       NUMBER,
      p_from_date            IN       DATE,
      p_to_date              IN       DATE,
      p_equipment_model_id   IN       pkg_common.t_num,
      p_cur_eqm_move         OUT      sys_refcursor,
      p_stock_id_out         IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_stock_id_in          IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 05.09.2007 14:08
-- Version : 1 05.09.2007
-- Modification : stock_management.stock_state__to_date_mega2 -> pkg_stock.state_on_date ->
--                -> pkg_stock.state_on_date + stock_management.stock_state__to_date_now ->
--                -> pkg_report.inventory
-- Editor  :
-- Changed :
-- Purpose : Получаем состояние складов на указанную дату объеденяя серии оборудования
--           учитывая партию и срок годности
--------------------------------------------------------------------------------
   PROCEDURE inventory_group_by_series (
      p_date                 IN       DATE,
      p_cur_inventory        OUT      sys_refcursor,
      p_stock_id             IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_equipment_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 05.09.2007 14:30
-- Version : 1 05.09.2007
-- Modification : stock_management.stock_state__to_date_mega2 -> pkg_stock.state_on_date ->
--                -> pkg_stock.state_on_date + stock_management.stock_state__to_date_now ->
--                -> pkg_report.inventory
-- Editor  :
-- Changed :
-- Purpose : Получаем состояние складов на указанную дату объеденяя оборудования по партии
--------------------------------------------------------------------------------
   PROCEDURE inventory_group_by_stocks (
      p_date                 IN       DATE,
      p_cur_inventory        OUT      sys_refcursor,
      p_stock_id             IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_equipment_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 09.06.2007 12:40
-- Editor  :
-- Changed :
-- Purpose : Возвращает список всех складов системы
--------------------------------------------------------------------------------
   PROCEDURE list_of_stocks (p_cur_all_stocks OUT sys_refcursor);
END;
/
