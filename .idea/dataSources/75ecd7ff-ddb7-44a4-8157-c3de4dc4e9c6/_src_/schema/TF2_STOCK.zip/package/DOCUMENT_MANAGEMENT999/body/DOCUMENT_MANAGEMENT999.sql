CREATE PACKAGE BODY document_management999
AS
/****************************************************************************
<name> document_management package
<author>        Petar Ulic
<version>       1.0   04.12.2003 basic Oracle implementation
<Description>   Package contains functions and procedures for document
                management in Stock system
<Application>   Stock Management

-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------       ------      ------------------------------------------
-- Petr Skripnik   09.11.2006  Изменен
-- Skripnik Petr   10.07.2007  version 1.11.9.0
****************************************************************************/
   pkg_name   CONSTANT NVARCHAR2 (50) := 'document_management.';

/****************************************************************************
<name>          DOC_DETAIL__Get
<author>        Petar Ulic
<version>       1.1   04.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
-- [srg] 2007 03 22
-- Добавлен join с таблицей equipment_batch для получения полей
-- equipment_batch_code и price
-- SP 08.06.2007 Заменил вызов вью на селект
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_doc_header_id NUMBER
                p_doc_detail_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE doc_detail__get (
      p_doc_header_id          NUMBER,
      p_doc_detail_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   )
   IS
   BEGIN
      p_error_code := 0;

  ------------------------------
  --!!!
  util_pkg.XCheck_Cond_Missing(true, 'p_doc_header_id');
  ------------------------------
      OPEN p_doc_detail_rec FOR
         SELECT dd.doc_header_id AS "Header Id", dd.ID AS "Id",
                em.equipment_model_code AS "Item code", em.equipment_model_name AS "Item Name",
                dd.seria_start AS "Seria From", dd.seria_end AS "Seria To",
                dd.quantity AS "Quantity", dd.status_id AS "Status", dd.valid_until AS "Valid",
                dd.product AS "Product", em.equipment_type_id AS "Equipment type id",
                em.equipment_model_id AS "Equipment id",
                dd.equipment_batch_id AS "Equipment batch id", eb.equipment_batch_code, eb.price
           FROM doc_detail dd, equipment_model em, equipment_batch eb
          WHERE dd.equipment_model_id = em.equipment_model_id
            AND dd.doc_header_id = p_doc_header_id
            AND dd.equipment_batch_id = eb.equipment_batch_id(+);
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END doc_detail__get;

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  : Skripnik Petr
   -- Changed : 14.12.2006 16:34 Удалил хинт. Перечислил поля в SELECT
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_detail__get_simple (
      p_doc_header_id          NUMBER,
      p_doc_detail_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   )
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_doc_detail_rec FOR
         SELECT ID, doc_header_id, equipment_model_id, seria_start, seria_end, quantity, unit,
                status_id, product, valid_until, equipment_batch_id, date_of_move_out,
                date_of_move_in
           FROM doc_detail
          WHERE doc_header_id = p_doc_header_id;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END doc_detail__get_simple;

/****************************************************************************
<name>          DOC_DETAIL__Ins
<author>        Petar Ulic
-- Editor  : Skripnik Petr
-- Changed : 24.10.2006 15:20
<version>       1.2   05.12.2003 error handling implementation
                1.1   04.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_doc_header_id NUMBER
                p_equipment_model_id NUMBER
                p_seria_start NVARCHAR2
                p_seria_end NVARCHAR2
                p_quantity NUMBER
                p_status_id NUMBER
                p_product NUMBER
                p_valid_until DATE
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE doc_detail__ins (
      p_doc_header_id              NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity                   NUMBER,
      p_status_id                  NUMBER,
      p_product                    NUMBER,
      p_valid_until                DATE,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := 'doc_detail__ins';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Установим код ошибки в ноль
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      INSERT INTO doc_detail
                  (doc_header_id, equipment_model_id, seria_start, seria_end, quantity,
                   status_id, product, valid_until
                  )
           VALUES (p_doc_header_id, p_equipment_model_id, p_seria_start, p_seria_end, p_quantity,
                   p_status_id, p_product, p_valid_until
                  );

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END doc_detail__ins;

--------------------------------------------------------------------------------
   -- Author  : Skripnik Petr
   -- Created : 24.10.2006 16:14
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_detail__ins (
      p_doc_header_id              NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity                   NUMBER,
      p_status_id                  NUMBER,
      p_product                    NUMBER,
      p_valid_until                DATE,
      p_equipment_batch_id         NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := 'doc_detail__ins';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Установим код ошибки в ноль
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      INSERT INTO doc_detail
                  (doc_header_id, equipment_model_id, seria_start, seria_end, quantity,
                   status_id, product, valid_until, equipment_batch_id
                  )
           VALUES (p_doc_header_id, p_equipment_model_id, p_seria_start, p_seria_end, p_quantity,
                   p_status_id, p_product, p_valid_until, p_equipment_batch_id
                  );

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END doc_detail__ins;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.10.2006 16:14
-- Editor  :
-- Changed :
-- Purpose :
--
--   Процедура doc_detail__ins_2 аналогична процедуре
--   PROCEDURE doc_detail__ins (
--      p_doc_header_id              NUMBER,
--      p_equipment_model_id         NUMBER,
--      p_seria_start                NVARCHAR2,
--      p_seria_end                  NVARCHAR2,
--      p_quantity                   NUMBER,
--      p_status_id                  NUMBER,
--      p_product                    NUMBER,
--      p_valid_until                DATE,
--      p_equipment_batch_id         NUMBER,
--      p_handle_tran                CHAR := 'Y',
--      p_error_code           OUT   NUMBER
--   )
--  Создана для поддержки FORIS.DataAccess
--------------------------------------------------------------------------------
   PROCEDURE doc_detail__ins_2 (
      p_doc_header_id              NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity                   NUMBER,
      p_status_id                  NUMBER,
      p_product                    NUMBER,
      p_valid_until                DATE,
      p_equipment_batch_id         NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := 'doc_detail__ins_2';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Установим код ошибки в ноль
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      INSERT INTO doc_detail
                  (doc_header_id, equipment_model_id, seria_start, seria_end, quantity,
                   status_id, product, valid_until, equipment_batch_id
                  )
           VALUES (p_doc_header_id, p_equipment_model_id, p_seria_start, p_seria_end, p_quantity,
                   p_status_id, p_product, p_valid_until, p_equipment_batch_id
                  );

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);


   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END doc_detail__ins_2;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 03.05.2007 FOR -> FORALL
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_detail__bulk_ins (
      p_doc_header_id              aadocheaderid,
      p_equipment_model_id         aaeqmodelid,
      p_seria_start                aastartseries,
      p_seria_end                  aaendseries,
      p_quantity                   aaquantity,
      p_status_id                  aastatus,
      p_product                    aaproduct,
      p_valid_until                aavaliduntil,
      p_equipment_batch_id         aaequipmentbatchid,   -- в массиве значение "-1" есть NULL
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := 'doc_detail__bulk_ins';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      FORALL i IN 1 .. p_length
         INSERT INTO doc_detail
                     (doc_header_id, equipment_model_id, seria_start,
                      seria_end, quantity, status_id, product,
                      valid_until,
                      equipment_batch_id
                     )
              VALUES (p_doc_header_id (i), p_equipment_model_id (i), p_seria_start (i),
                      p_seria_end (i), p_quantity (i), p_status_id (i), p_product (i),
                      p_valid_until (i),
                      DECODE (p_equipment_batch_id (i), -1, NULL, p_equipment_batch_id (i))
                     );

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := SQLCODE; --999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END doc_detail__bulk_ins;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 03.05.2007 FOR -> FORALL
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_detail__bulk_ins_2 (
      p_doc_header_id              aadocheaderid,
      p_equipment_model_id         aaeqmodelid,
      p_seria_start                t_varchar,
      p_seria_end                  t_varchar,
      p_quantity                   aaquantity,
      p_status_id                  aastatus,
      p_product                    aaproduct,
      p_valid_until                aavaliduntil,
      p_equipment_batch_id         aaequipmentbatchid,   -- в массиве значение "-1" есть NULL
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := 'doc_detail__bulk_ins_2';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      FORALL i IN 1 .. p_length
         INSERT INTO doc_detail
                     (doc_header_id, equipment_model_id, seria_start,
                      seria_end, quantity, status_id, product,
                      valid_until,
                      equipment_batch_id
                     )
              VALUES (p_doc_header_id (i), p_equipment_model_id (i), p_seria_start (i),
                      p_seria_end (i), p_quantity (i), p_status_id (i), p_product (i),
                      p_valid_until (i),
                      DECODE (p_equipment_batch_id (i), -1, NULL, p_equipment_batch_id (i))
                     );

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := SQLCODE; --999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END doc_detail__bulk_ins_2;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure doc_header__get_1
(
    p_id number,
    p_doc_header_rec out sys_refcursor,
    p_error_code out number
)
is
  v_dh_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
  util_pkg.add_ct_number_val(v_dh_ids, p_id);
  ------------------------------
  get_result_cursor003(v_dh_ids, TRUE, p_doc_header_rec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure doc_header__get_2
(
    p_doc_num nvarchar2,
    p_doc_header_rec out sys_refcursor,
    p_error_code out number
)
is
  v_rec_dh doc_header%rowtype;
  v_dh_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_num is null, 'p_doc_num');
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
  v_rec_dh := document_pkg.get_doc_header_by_doc_no(p_doc_num);
  ------------------------------
  util_pkg.add_ct_number_val(v_dh_ids, v_rec_dh.id);
  ------------------------------
  get_result_cursor003(v_dh_ids, TRUE, p_doc_header_rec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure doc_header__get_simple
(
    p_id number,
    p_doc_header_rec out sys_refcursor,
    p_error_code out number
)
is
  v_dh_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
  util_pkg.add_ct_number_val(v_dh_ids, p_id);
  ------------------------------
  get_result_cursor001(v_dh_ids, TRUE, p_doc_header_rec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure doc_header__get_vendor_doc
(
    p_stock_id number,
    p_vendor_doc nvarchar2,
    p_doc_header_rec out sys_refcursor,
    p_error_code out number
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_vendor_doc is null, 'p_vendor_doc');
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
  get_result_cursor002(p_stock_id, p_vendor_doc, p_doc_header_rec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
/****************************************************************************
<name>          DOC_HEADER__Ins
<author>        Petar Ulic
<version>       1.3   08.01.2004  producer_id replaced with p_vendor_doc
                1.2   05.12.2003  error handling implementation
                1.1   04.12.2003  basic Oracle implementation
                1.0   10.11.2003  basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_user_id NVARCHAR2
                p_create_date DATE
                p_create_time DATE
                p_document_type_id NUMBER
                p_document_no NVARCHAR2
                p_status_id NUMBER
                p_stock_out_id NUMBER
                p_stock_in_id NUMBER
                p_vendor_doc NVARCHAR2
                p_valid_until DATE
                p_description NVARCHAR2
                p_user_comment NVARCHAR2
                p_last_user NVARCHAR2
                p_id OUT NUMBER
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
                p_vendor_id NUMBER
****************************************************************************/
   PROCEDURE doc_header__ins (
      p_user_id                  NVARCHAR2,
      p_create_date              DATE,
      p_create_time              DATE,
      p_document_type_id         NUMBER,
      p_document_no              NVARCHAR2,
      p_status_id                NUMBER,
      p_stock_out_id             NUMBER,
      p_stock_in_id              NUMBER,
      p_vendor_doc               NVARCHAR2,
      p_valid_until              DATE,
      p_description              NVARCHAR2 := NULL,
      p_user_comment             NVARCHAR2,
      p_last_user                NVARCHAR2,
      p_id                 OUT   NUMBER,
      p_handle_tran              CHAR := 'Y',
      p_error_code         OUT   NUMBER,
      p_vendor_id                NUMBER
   )
   IS
      --!_!v_sp_name varchar2(30);
      v_user_id number;
      v_last_user_id number;
      v_user_name_obs nvarchar2(50);
      v_last_user_name_obs nvarchar2(50);
      --
      stockincode     NVARCHAR2 (50);
      stockoutcode    NVARCHAR2 (50);
      l_valid_until   doc_header.valid_until%TYPE;
   BEGIN
      p_error_code := 0;

      util_loc_pkg.touch_varchar(p_description);

      v_user_id := util_stock.xget_user_id(p_user_id);
      v_last_user_id := util_stock.xget_user_id(p_last_user);

      v_user_name_obs := util_stock.make_obsolete_user_name(p_user_id);
      v_last_user_name_obs := util_stock.make_obsolete_user_name(p_last_user);

      --!_!IF p_handle_tran = 'S'
      --!_!THEN
      --!_!   v_sp_name := util_sys_pkg.make_savepoint;
      --!_!END IF;

      IF p_stock_in_id <> 0
      THEN
         SELECT code
           INTO stockincode
           FROM stock
          WHERE ID = p_stock_in_id;
      ELSE
         stockincode := 'unknown';
      END IF;

      IF p_stock_out_id <> 0
      THEN
         SELECT code
           INTO stockoutcode
           FROM stock
          WHERE ID = p_stock_out_id;
      ELSE
         stockoutcode := 'unknown';
      END IF;

      IF TRUNC (p_valid_until) = pkg_constants.c_maxsysdate
      THEN
         l_valid_until := NULL;
      ELSE
         l_valid_until := p_valid_until;
      END IF;

      INSERT INTO doc_header
                  (user_id, create_date, doc_date, doc_type_id, doc_no,
                   status_id, stock_out_id, stock_in_id, vendor_doc, vendor_id, valid_until,
                   description,
                   user_comment, last_user,
                   user_id2, last_user_id2
                  )
           VALUES (v_user_name_obs, p_create_date, p_create_time, p_document_type_id, p_document_no,
                   p_status_id, p_stock_out_id, p_stock_in_id, p_vendor_doc, p_vendor_id, l_valid_until,
                      v_user_name_obs
                   || ', '
                   || TO_CHAR (SYSDATE, 'dd.mm.yyyy hh24:mi:ss')
                   || ', '
                   || stockoutcode
                   || '->'
                   || stockincode,
                   p_user_comment, v_last_user_name_obs,
                   v_user_id, v_last_user_id
                  );

      SELECT s_doc_header.CURRVAL
        INTO p_id
        FROM DUAL;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

   END doc_header__ins;

/****************************************************************************
<name>          DOC_HEADER__Del
<author>        Dejan Spegar
<version>       1.0   05.07.2004 basic Oracle implementation
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_doc_header_id NUMBER
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE doc_header__del (
      p_doc_header_id         NUMBER,
      p_handle_tran           CHAR := 'Y',
      p_error_code      OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      DELETE FROM doc_header
            WHERE ID = p_doc_header_id;

      DELETE FROM stock_state
            WHERE doc_header_id = p_doc_header_id;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END doc_header__del;

/****************************************************************************
<name>          DOC_HEADER_user_comment__Upd
<author>        Sergey Ermakov
<version>       1.0   08.04.2009
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_user_comment NVARCHAR2
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE doc_header_user_comment__upd (
      p_id                        NUMBER,
      p_user_comment              NVARCHAR2,
      p_handle_tran               CHAR := 'Y',
      p_error_code       OUT      NUMBER
   )
   AS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := 'doc_header_user_comment__upd';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Reset error code
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      UPDATE doc_header
         SET user_comment = p_user_comment
       WHERE id = p_id;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
        pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
               --p_error_code := SQLCODE;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;

   END doc_header_user_comment__upd;

/****************************************************************************
<name>          DOC_HEADER_user_comment__Upd
<author>        Sergey Ermakov
<version>       1.0   08.04.2009
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_doc_num NVARCHAR2
                p_user_comment NVARCHAR2
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE doc_header_user_comment__upd (
      p_doc_no                    NVARCHAR2,
      p_user_comment              NVARCHAR2,
      p_handle_tran               CHAR := 'Y',
      p_error_code       OUT      NUMBER
   )
   AS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := 'doc_header_user_comment__upd';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Reset error code
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      UPDATE doc_header
         SET user_comment = p_user_comment
       WHERE doc_no = p_doc_no;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
        pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
               --p_error_code := SQLCODE;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;

   END doc_header_user_comment__upd;

/****************************************************************************
<name>          DOC_HEADER_user_comment__Upd_1
<author>        Sergey Ermakov
<version>       1.0   08.04.2009
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_user_comment NVARCHAR2
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification

  Процедура doc_header_user_comment__upd_1 аналогична процедуре
   PROCEDURE doc_header_user_comment__upd (
      p_id                        NUMBER,
      p_user_comment              NVARCHAR2,
      p_handle_tran               CHAR := 'Y',
      p_error_code       OUT      NUMBER
   )
  Создана для поддержки FORIS.DataAccess
****************************************************************************/
   PROCEDURE doc_header_user_comment__upd_1 (
      p_id                        NUMBER,
      p_user_comment              NVARCHAR2,
      p_handle_tran               CHAR := 'Y',
      p_error_code       OUT      NUMBER
   )
   AS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := 'doc_header_user_comment__upd_1';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Reset error code
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      UPDATE doc_header
         SET user_comment = p_user_comment
       WHERE id = p_id;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
        pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
               --p_error_code := SQLCODE;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;

   END doc_header_user_comment__upd_1;

/****************************************************************************
<name>          DOC_HEADER_user_comment__Upd_2
<author>        Sergey Ermakov
<version>       1.0   08.04.2009
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_doc_num NVARCHAR2
                p_user_comment NVARCHAR2
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification

  Процедура doc_header_user_comment__upd_2 аналогична процедуре
   PROCEDURE doc_header_user_comment__upd (
      p_doc_no                    NVARCHAR2,
      p_user_comment              NVARCHAR2,
      p_handle_tran               CHAR := 'Y',
      p_error_code       OUT      NUMBER
   )
  Создана для поддержки FORIS.DataAccess
****************************************************************************/
   PROCEDURE doc_header_user_comment__upd_2 (
      p_doc_no                    NVARCHAR2,
      p_user_comment              NVARCHAR2,
      p_handle_tran               CHAR := 'Y',
      p_error_code       OUT      NUMBER
   )
   AS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100) := 'doc_header_user_comment__upd_2';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      --Reset error code
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      UPDATE doc_header
         SET user_comment = p_user_comment
       WHERE doc_no = p_doc_no;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
        pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
               --p_error_code := SQLCODE;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;

   END doc_header_user_comment__upd_2;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function seek_doc_header_so
(
    p_stock_id number,
    p_doc_type_id number,
    p_status_id number,
    p_doc_date1 date,
    p_doc_date2 date
) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  ------------------------------
select /*+ no_expand index_asc(z, IDX_DOCHEADER_SO_DD_DMO)*/
  id
  bulk collect into v_res
  from doc_header z
  where 1 = 1
  and stock_out_id = p_stock_id
  and doc_type_id = nvl(p_doc_type_id, doc_type_id)
  and status_id = nvl(p_status_id, status_id)
  and doc_date >= nvl(p_doc_date1, doc_date)
  and doc_date <= nvl(p_doc_date2, doc_date)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function seek_doc_header_si
(
    p_stock_id number,
    p_doc_type_id number,
    p_status_id number,
    p_doc_date1 date,
    p_doc_date2 date
) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  ------------------------------
select /*+ no_expand index_asc(z, IDX_DOCHEADER_SI_DD_DMI)*/
  id
  bulk collect into v_res
  from doc_header z
  where 1 = 1
  and stock_in_id = p_stock_id
  and doc_type_id = nvl(p_doc_type_id, doc_type_id)
  and status_id = nvl(p_status_id, status_id)
  and doc_date >= nvl(p_doc_date1, doc_date)
  and doc_date <= nvl(p_doc_date2, doc_date)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure doc_header__rpt1
(
    p_id number,
    p_stock_id number,
    p_type number,
    p_status_id number,
    p_date_start date,
    p_date_end date,
    p_filter nvarchar2,
    p_model_id number,
    p_seria_start nvarchar2,
    p_seria_end nvarchar2,
    p_doc_report_1_rec out sys_refcursor,
    p_error_code out number
)
is
  v_doc_type_id number := nullif(p_type, util_stock.c_any_value_old_school_num);
  v_status_id number := nullif(p_status_id, util_stock.c_any_value_status_id_num);
  v_doc_date1 date := p_date_start;
  v_doc_date2 date := p_date_end;
  --
  v_model_id number := nullif(p_model_id, util_stock.c_any_value_num);
  v_seria_start nvarchar2(50) := p_seria_start;
  v_seria_end nvarchar2(50) := p_seria_end;
  --
  v_dh_ids_so ct_number;
  v_dh_ids_si ct_number;
  v_dh_ids ct_number;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
  util_loc_pkg.touch_number(p_id);
  util_loc_pkg.touch_varchar(p_filter); --!_! not used in dotnet
  ------------------------------
  v_dh_ids_so := seek_doc_header_so
  (
    p_stock_id => p_stock_id,
    p_doc_type_id => v_doc_type_id,
    p_status_id => v_status_id,
    p_doc_date1 => v_doc_date1,
    p_doc_date2 => v_doc_date2
  );
  ------------------------------
  v_dh_ids_si := seek_doc_header_si
  (
    p_stock_id => p_stock_id,
    p_doc_type_id => v_doc_type_id,
    p_status_id => v_status_id,
    p_doc_date1 => v_doc_date1,
    p_doc_date2 => v_doc_date2
  );
  ------------------------------
  select
    column_value
    bulk collect into v_dh_ids
    from table(v_dh_ids_so)
  union --!_! NOT all, unique
  select
    column_value
    from table(v_dh_ids_si)
  ;
  ------------------------------
  get_result_cursor005(v_dh_ids, TRUE, p_stock_id, v_model_id, v_seria_start, v_seria_end, p_doc_report_1_rec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure doc_report1_i
(
    p_dh_id number,
    p_result out sys_refcursor
)
is
  v_dh_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_dh_id is null, 'p_dh_id');
  ------------------------------
  util_pkg.add_ct_number_val(v_dh_ids, p_dh_id);
  ------------------------------
  get_result_cursor004(v_dh_ids, TRUE, p_result);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure doc_report2_i
(
    p_doc_num nvarchar2,
    p_result out sys_refcursor
)
is
  v_rec_dh doc_header%rowtype;
  v_dh_ids ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_num is null, 'p_doc_num');
  ------------------------------
  v_rec_dh := document_pkg.get_doc_header_by_doc_no(p_doc_num);
  ------------------------------
  util_pkg.add_ct_number_val(v_dh_ids, v_rec_dh.id);
  ------------------------------
  get_result_cursor004(v_dh_ids, TRUE, p_result);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure v_doc_report_1__get
(
    p_doc_header_id number,
    p_doc_number nvarchar2,
    p_doc_report_1_rec out sys_refcursor,
    p_error_code out number
)
is
begin
  ------------------------------
  p_error_code := util_pkg.c_ora_ok;
  ------------------------------
  if p_doc_header_id <= 0
  then
    ------------------------------
    doc_report2_i
    (
      p_doc_num => p_doc_number,
      p_result => p_doc_report_1_rec
    );
    ------------------------------
  else
    ------------------------------
    doc_report1_i
    (
      p_dh_id => p_doc_header_id,
      p_result => p_doc_report_1_rec
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
/****************************************************************************
<name>          DOC_NUMBER_year__Get
<author>        Petar Ulic
<version>       1.1   04.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_year OUT NUMBER
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE doc_number_year__get (p_year OUT NUMBER, p_error_code OUT NUMBER)
   IS
   BEGIN
      p_error_code := 0;

      SELECT MAX ("YEAR")
        INTO p_year
        FROM doc_number;

      IF p_year IS NULL
      THEN
         SELECT TO_NUMBER (TO_CHAR (SYSDATE, 'YYYY'))
           INTO p_year
           FROM DUAL;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END;

/****************************************************************************
<name>          DOC_NUMBER_stock__Ins
<author>        Petar Ulic
<version>       1.2   05.12.2003 error handling implementation
                1.1   04.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_stock_id NUMBER
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE doc_number_stock__ins (
      p_stock_id            NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      p_year   NUMBER;
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      --Get current/active year
      doc_number_year__get (p_year => p_year, p_error_code => p_error_code);

      IF p_error_code = 0
      THEN
         INSERT INTO doc_number
                     ("STOCK_ID", "DOC_TYPE_ID", "NO", "YEAR")
            SELECT p_stock_id, "ID", 0, p_year
              FROM doc_type;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END;

/****************************************************************************
<name>          SERIA__Set_status
<author>        Dejan Spegar
-- Editor  :    Skripnik Petr
-- Changed :    09.10.2006 12:23
<version>       1.0   22.01.2004 basic oracle implementation
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_stock_id NUMBER
                p_equipment_model_id NUMBER
                p_seria_start NVARCHAR2
                p_seria_end NVARCHAR2
                p_status NUMBER
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE seria__set_status (
      p_stock_id                   aastockid,
      p_equipment_model_id         aaequipmentmodelid,
      p_seria_start                aaseriastart,
      p_seria_end                  aaseriaend,
      p_status                     aastatus,
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      l_stock_id             NUMBER;
      l_equipment_model_id   NUMBER;
      l_seria_start          NVARCHAR2 (50);
      l_seria_end            NVARCHAR2 (50);
      l_status               NUMBER;
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      FOR i IN 1 .. p_length
      LOOP
         IF p_stock_id.EXISTS (i)
         THEN
            l_stock_id := p_stock_id (i);
         ELSE
            l_stock_id := NULL;
         END IF;

         IF p_equipment_model_id.EXISTS (i)
         THEN
            l_equipment_model_id := p_equipment_model_id (i);
         ELSE
            l_equipment_model_id := NULL;
         END IF;

         IF p_seria_start.EXISTS (i)
         THEN
            l_seria_start := p_seria_start (i);
         ELSE
            l_seria_start := NULL;
         END IF;

         IF p_seria_end.EXISTS (i)
         THEN
            l_seria_end := p_seria_end (i);
         ELSE
            l_seria_end := NULL;
         END IF;

         IF p_status.EXISTS (i)
         THEN
            l_status := p_status (i);
         ELSE
            l_status := NULL;
         END IF;

         -- Kornev B.A. 12.12.2005 added hint
         UPDATE --+ index(stock_state I_STOCK_STATE_EQM)
                stock_state
            SET status = l_status
          WHERE stock_id = l_stock_id
            AND equipment_model_id = l_equipment_model_id
            AND seria_start = l_seria_start
            AND seria_end = l_seria_end;
      END LOOP;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END seria__set_status;

/****************************************************************************
<name>          EQUIPMENT__Upd_valid_until
<author>        Dejan Spegar
<version>       1.0   12.03.2004 basic oracle implementation
-- Editor  :    Skripnik Petr
-- Changed :    09.10.2006 11:22
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_equipment_model_id NUMBER
                p_seria_start NVARCHAR2
                p_seria_end NVARCHAR2
                p_valid_until DATE
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE equipment__upd_valid_until (
      p_stock_id                   aastockid,
      p_equipment_model_id         aaequipmentmodelid,
      p_seria_start                aaseriastart,
      p_seria_end                  aaseriaend,
      p_valid_until                aavaliduntil,
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      l_stock_id             NUMBER;
      l_equipment_model_id   NUMBER;
      l_seria_start          NVARCHAR2 (50);
      l_seria_end            NVARCHAR2 (50);
      l_valid_until          DATE;
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      FOR i IN 1 .. p_length
      LOOP
         IF p_stock_id.EXISTS (i)
         THEN
            l_stock_id := p_stock_id (i);
         ELSE
            l_stock_id := NULL;
         END IF;

         IF p_equipment_model_id.EXISTS (i)
         THEN
            l_equipment_model_id := p_equipment_model_id (i);
         ELSE
            l_equipment_model_id := NULL;
         END IF;

         IF p_seria_start.EXISTS (i)
         THEN
            l_seria_start := p_seria_start (i);
         ELSE
            l_seria_start := NULL;
         END IF;

         IF p_seria_end.EXISTS (i)
         THEN
            l_seria_end := p_seria_end (i);
         ELSE
            l_seria_end := NULL;
         END IF;

         IF p_valid_until.EXISTS (i)
         THEN
            l_valid_until := p_valid_until (i);
         ELSE
            l_valid_until := NULL;
         END IF;

         -- Kornev B.A. 12.12.2005 added hint
         UPDATE --+ index(stock_state I_STOCK_STATE_EQM)
                stock_state
            SET create_date = l_valid_until
          WHERE stock_id = l_stock_id
            AND equipment_model_id = l_equipment_model_id
            AND seria_start = l_seria_start
            AND seria_end = l_seria_end;
      END LOOP;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END equipment__upd_valid_until;

/****************************************************************************
<name>          DOC_HEADER__Get_filtered
<author>        Goran Savic
<version>       1.0   16.01.2006 basic oracle implementation
Skripnik Petr 13.04.2007 --Удалил параметр p_no_stock_keyword и все что с ним связано
Skripnik Petr 25.04.2007 --
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_no_stock_keyword NUMBER
                p_date_begin DATE
    p_date_end DATE
                p_doc_header_rec OUT t_cursor
    p_error_code OUT NUMBER
****************************************************************************/
   PROCEDURE doc_header__get_filtered (
      p_date_begin             DATE,
      p_date_end               DATE,
      p_doc_header_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   )
   IS

      tmp_stock_id_num       NUMBER;
      tmp_equipment_id_num   NUMBER;
   BEGIN
      SELECT COUNT (ID)
        INTO tmp_equipment_id_num
        FROM tmp_equipment_id;

      SELECT COUNT (ID)
        INTO tmp_stock_id_num
        FROM tmp_stock_id;

      p_error_code := 0;

      DELETE FROM TT_WAREHOUSE_ACC_DET;
     -- OPEN p_doc_header_rec FOR
  INSERT INTO TT_WAREHOUSE_ACC_DET( doc_id,
                                    doc_date,
                                    doc_no,
                                    doc_type,
                                    stock_from_id,
                                    stock_from_name,
                                    stock_to_id,
                                    stock_to_name,
                                    equipment_model_id,
                                    quantity)
         SELECT   /*+ ordered use_nl(d, dd, s1, s2) index_asc(d, IDX_DOCHEADER_DT_DD) index_asc(dd, IDX_DOCDETAIL_DHI_EMI_DMI_DMO) index_asc(s1, PK_STOCK) index_asc(s2, PK_STOCK)*/
                  d.ID AS "Id",
                  d.doc_date AS "Document date",
                  d.doc_no AS "No",
                  d.doc_type_id AS "Type",
                  d.stock_out_id AS "From Id",
                  s2.NAME AS "From Stock",
                  d.stock_in_id AS "To Id",
                  s1.NAME AS "To Stock",
                  dd.equipment_model_id,
                  SUM (dd.quantity) AS "Quantity"
             FROM doc_header d INNER JOIN doc_detail dd ON d.ID = dd.doc_header_id
                  LEFT OUTER JOIN stock s1 ON d.stock_in_id = s1.ID
                  LEFT OUTER JOIN stock s2 ON d.stock_out_id = s2.ID
            WHERE d.doc_type_id IN (util_stock.c_Doc_Type_Receipt, util_stock.c_Doc_Type_Shippment, util_stock.c_Doc_Type_Movement, util_stock.c_Doc_Type_Assembling, util_stock.c_Doc_Type_Disassembling, util_stock.c_Doc_Type_Credit, util_stock.c_Doc_Type_Debit, util_stock.c_Doc_Type_ErrorReport)
              AND (   (   (d.stock_out_id IN (SELECT /*+ index_asc(z, I_TMP_STOCK_ID)*/*
                                                FROM tmp_stock_id z))
                       OR (d.stock_in_id IN (SELECT /*+ index_asc(z, I_TMP_STOCK_ID)*/*
                                               FROM tmp_stock_id z))
                      )
                   OR (tmp_stock_id_num = 0)
                  )
              AND ((dd.equipment_model_id IN (SELECT /*+ index_asc(z, I_TMP_EQUIPMENT_ID)*/*
                                                FROM tmp_equipment_id z))
                   OR (tmp_equipment_id_num = 0)
                  )
              AND d.doc_date <= p_date_end
              AND d.doc_date >= p_date_begin
              AND d.status_id = util_stock.c_docstat_finished
         GROUP BY d.ID,
                  d.doc_date,
                  d.doc_no,
                  d.doc_type_id,
                  d.stock_out_id,
                  s2.NAME,
                  d.stock_in_id,
                  s1.NAME,
                  dd.equipment_model_id;

     UPDATE /*+ full(tt)*/TT_WAREHOUSE_ACC_DET tt
        SET tt.operation_direction = GetEquipmentMoveDirection(p_doc_type_id => tt.doc_type,
                                                               p_all_stocks => 0,
                                                               p_from_stock_id => tt.stock_from_id,
                                                               p_to_stock_id => tt.stock_to_id);

     OPEN p_doc_header_rec FOR
       SELECT /*+ full(tt)*/
              tt.doc_id "Id",
              tt.doc_date "Document date",
              tt.doc_no "No",
              tt.doc_type "Type",
              tt.stock_from_code "Code From",
              tt.stock_from_name "From Stock",
              tt.stock_to_code "Code To",
              tt.stock_to_name "To Stock",
              tt.equipment_model_id,
              tt.quantity "Quantity",
              tt.operation_direction "Direction"
         FROM TT_WAREHOUSE_ACC_DET tt;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END doc_header__get_filtered;

/****************************************************************************
<name>          DDOC_HEADER__Get_filtered_prev_state
<author>        Goran Savic
<version>       1.0   16.01.2006
Skripnik Petr 13.04.2007 --Удалил параметр p_no_stock_keyword и все что с ним связано
<Description>   This query is called with "DOC_HEADER__Get_filtered" procedure from C# code
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_no_stock_keyword NUMBER
                p_date_begin DATE
    p_date_end DATE
                p_doc_header_rec OUT t_cursor
    p_error_code OUT NUMBER
****************************************************************************/
   PROCEDURE doc_header__get_prev_state (
      p_date_begin             DATE,
      p_date_end               DATE,
      p_doc_header_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   )
   IS
   BEGIN
    p_error_code := 0;

    util_loc_pkg.touch_date(p_date_end);

    pkg_stock.state_prepare(
        p_date => p_date_begin,
        p_is_update_validity_date => false,
        p_is_process_opened_doc => false,
        p_is_detailed => false
    );

    OPEN p_doc_header_rec FOR
select
    equipment_model_id, sum(quantity_onstock) "Quantity"
    from tmp_ss1
    group by equipment_model_id
    order by equipment_model_id
    ;

   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END doc_header__get_prev_state;

/****************************************************************************
<name>          DDOC_HEADER__Get_filtered_prev_state_2
<author>        Goran Savic
<version>       1.0   16.01.2006
Skripnik Petr 13.04.2007 --Удалил параметр p_no_stock_keyword и все что с ним связано
Victor Smirnov 29.11.2011 --Все по-другому
<Description>   This query is called with "DOC_HEADER__Get_filtered" procedure from C# code
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_no_stock_keyword NUMBER
                p_date_begin DATE
    p_date_end DATE
                p_doc_header_rec OUT t_cursor
    p_error_code OUT NUMBER
****************************************************************************/
   PROCEDURE doc_header__get_prev_state_2 (
      p_serial_number          NVARCHAR2,
      p_equipment_id           NUMBER,
      p_date_begin             DATE,
      p_date_end               DATE,
      p_doc_header_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   )
   IS
  v_tmp_stock_id_num number;
  v_date date := p_date_begin;

   BEGIN
      p_error_code := 0;

      util_loc_pkg.touch_varchar(p_serial_number);
      util_loc_pkg.touch_number(p_equipment_id);
      util_loc_pkg.touch_date(p_date_end);

      SELECT COUNT (ID)
        INTO v_tmp_stock_id_num
        FROM tmp_stock_id;

      --!!! requires previous call of prepare_doc_detail_by_sn

      OPEN p_doc_header_rec FOR
        with t_dd as
            (
               select /*+ ordered use_nl(q, dd, dh) index_asc(dd, PK_DOC_DETAIL) index_asc(dh, PK_DOC_HEADER)*/
                  dh.doc_type_id, dh.stock_out_id, dh.stock_in_id, dd.equipment_model_id, dd.quantity,dh.status_id
                  from tt_id q, doc_detail dd, doc_header dh
                  where 1 = 1
                  and dd.id = q.id
                  and dh.id = dd.doc_header_id
                  and dh.doc_date < v_date
                  --and dh.status_id = util_stock.c_docstat_finished
                  --and dd.equipment_model_id in (p_equipment_id)
            )
        select
            equipment_model_id, sum(quantity) "Quantity"
            from (
        select
            stock_out_id stock_id, equipment_model_id, -sum(quantity) quantity
            from t_dd q
            where 1 = 1
            and status_id = util_stock.c_docstat_finished
            and doc_type_id in (util_stock.c_Doc_Type_Shippment, util_stock.c_Doc_Type_Movement, util_stock.c_Doc_Type_Debit)
            group by stock_out_id, equipment_model_id
        union all
        select
            stock_in_id stock_id, equipment_model_id, sum(quantity) quantity
            from t_dd q
            where 1 = 1
            and status_id = util_stock.c_docstat_finished
            and doc_type_id in (util_stock.c_Doc_Type_Receipt, util_stock.c_Doc_Type_Movement, util_stock.c_Doc_Type_Assembling, util_stock.c_Doc_Type_Disassembling, util_stock.c_Doc_Type_Credit, util_stock.c_Doc_Type_ErrorReport)
            group by stock_in_id, equipment_model_id
            ) z
            where 1 = 1
            and (1 = 0
                or v_tmp_stock_id_num = 0
                or exists (select /*+ index_asc(t, I_TMP_STOCK_ID)*/1 from tmp_stock_id t where id = z.stock_id)
            )
            group by equipment_model_id
            order by equipment_model_id
              ;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END doc_header__get_prev_state_2;

/****************************************************************************
<name>          DOC_HEADER__Get_filtered_4
<author>        Goran Savic
<version>       1.0   16.01.2006 basic oracle implementation
-- Editor  : Skripnik Petr
Skripnik Petr 15.01.2007 d.stock_in_id, d.stock_out_id -> s1.code, s2.code в возвращаемом курсоре
Skripnik Petr 13.04.2007 --Удалил параметр p_no_stock_keyword и все что с ним связано
Victor Smirnov 29.11.2011 --Все по-другому
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_no_stock_keyword NUMBER
                p_serial_number NVARCHAR2
    p_equipment_id NUMBER
                p_date_begin DATE
    p_date_end DATE
                p_doc_header_rec OUT t_cursor
    p_error_code OUT NUMBER
****************************************************************************/
   PROCEDURE doc_header__get_filtered_4 (
      p_serial_number          NVARCHAR2,
      p_equipment_id           NUMBER,
      p_date_begin             DATE,
      p_date_end               DATE,
      p_doc_header_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   )
   IS
  v_tmp_stock_id_num number;

   BEGIN
      p_error_code := 0;

      util_loc_pkg.touch_varchar(p_serial_number);
      util_loc_pkg.touch_number(p_equipment_id);

      SELECT COUNT (ID)
        INTO v_tmp_stock_id_num
        FROM tmp_stock_id;

      --!!! requires previous call of prepare_doc_detail_by_sn
  DELETE FROM TT_WAREHOUSE_ACC_DET;
     -- OPEN p_doc_header_rec FOR
  INSERT INTO TT_WAREHOUSE_ACC_DET( doc_id,
                                    doc_date,
                                    doc_no,
                                    doc_type,
                                    stock_from_id,
                                    stock_from_code,
                                    stock_from_name,
                                    stock_to_id,
                                    stock_to_code,
                                    stock_to_name,
                                    equipment_model_id,
                                    quantity)
      with t_dd as
          (
      select /*+ ordered use_nl(q, dd, dh) index_asc(dd, PK_DOC_DETAIL) index_asc(dh, PK_DOC_HEADER)*/
          dh.id, dh.doc_date, dh.doc_no, dh.doc_type_id, dh.stock_out_id, dh.stock_in_id, dd.equipment_model_id, dd.quantity, dh.status_id
          from tt_id q, doc_detail dd, doc_header dh
          where 1 = 1
          and dd.id = q.id
          and dh.id = dd.doc_header_id
          and dh.doc_date between p_date_begin and p_date_end
          --!_!and dh.status_id = util_stock.c_docstat_finished
          --!_!and dd.equipment_model_id in (p_equipment_id)
          )
      select /*+ ordered use_nl(z, s1, s2)*/
          z.id "Id",
          z.doc_date "Document date",
          z.doc_no "No",
          z.doc_type_id "Type",
          z.stock_out_id,
          s1.code "Code From",
          s1.name "From Stock",
          z.stock_in_id,
          s2.code "Code To",
          s2.name "To Stock",
          z.equipment_model_id,
          sum(z.quantity) "Quantity"
          from t_dd z, stock s1, stock s2
          where 1 = 1
          and s1.id(+) = z.stock_out_id
          and s2.id(+) = z.stock_in_id
          and z.doc_type_id in (util_stock.c_Doc_Type_Receipt, util_stock.c_Doc_Type_Shippment, util_stock.c_Doc_Type_Movement, util_stock.c_Doc_Type_Assembling, util_stock.c_Doc_Type_Disassembling, util_stock.c_Doc_Type_Credit, util_stock.c_Doc_Type_Debit, util_stock.c_Doc_Type_ErrorReport)
          and (1 = 0
              or v_tmp_stock_id_num = 0
              or exists (select /*+ index_asc(t, I_TMP_STOCK_ID)*/1 from tmp_stock_id t where id = z.stock_out_id)
              or exists (select /*+ index_asc(t, I_TMP_STOCK_ID)*/1 from tmp_stock_id t where id = z.stock_in_id)
          )
          and z.status_id = util_stock.c_docstat_finished
          group by
              z.id, z.doc_date, z.doc_no, z.doc_type_id,
              z.stock_out_id, s1.code, s1.name,
              z.stock_in_id, s2.code, s2.name,
              z.equipment_model_id
            ;

    if (v_tmp_stock_id_num = 0)
    then
     UPDATE /*+ full(tt)*/TT_WAREHOUSE_ACC_DET tt
        SET tt.operation_direction = GetEquipmentMoveDirection(p_doc_type_id => tt.doc_type,
                                                               p_all_stocks => 1,
                                                               p_from_stock_id => tt.stock_from_id,
                                                               p_to_stock_id => tt.stock_to_id);
    else
     UPDATE /*+ full(tt)*/TT_WAREHOUSE_ACC_DET tt
        SET tt.operation_direction = GetEquipmentMoveDirection(p_doc_type_id => tt.doc_type,
                                                               p_all_stocks => 0,
                                                               p_from_stock_id => tt.stock_from_id,
                                                               p_to_stock_id => tt.stock_to_id);
     end if;

     OPEN p_doc_header_rec FOR
       SELECT /*+ full(tt)*/
              tt.doc_id "Id",
              tt.doc_date "Document date",
              tt.doc_no "No",
              tt.doc_type "Type",
              tt.stock_from_code "Code From",
              tt.stock_from_name "From Stock",
              tt.stock_to_code "Code To",
              tt.stock_to_name "To Stock",
              tt.equipment_model_id,
              tt.quantity "Quantity",
              tt.operation_direction "Direction"
         FROM TT_WAREHOUSE_ACC_DET tt;

   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
   END doc_header__get_filtered_4;

   PROCEDURE doc_header_auto_action__ins (
      p_doc_header_id         NUMBER,
      p_action_id             NUMBER,
      p_handle_tran           CHAR := 'Y',
      p_error_code      OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      INSERT INTO doc_header_auto_action
                  (doc_header_id, action_id
                  )
           VALUES (p_doc_header_id, p_action_id
                  );

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END doc_header_auto_action__ins;

   PROCEDURE doc_header_auto_action__del (
      p_doc_header_id         NUMBER,
      p_handle_tran           CHAR := 'Y',
      p_error_code      OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      DELETE FROM doc_header_auto_action
            WHERE doc_header_id = p_doc_header_id;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END doc_header_auto_action__del;

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_header_auto_action__get (
      p_doc_header_id          NUMBER,
      p_doc_header_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   )
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_doc_header_rec FOR
         SELECT *
           FROM doc_header_auto_action
          WHERE doc_header_id = p_doc_header_id;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END doc_header_auto_action__get;

/****************************************************************************
<name>          get_doc_types
<author>        Sergey Ermakov
<version>       1.0   10.09.2010 First version

<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_doc_types_rec   OUT t_cursor
                p_error_code      OUT NUMBER    - 0  procedure was finished successfully,
                                                - else returns error identification
****************************************************************************/
   PROCEDURE get_doc_types (
      p_doc_types_rec     OUT   t_cursor,
      p_error_code        OUT   NUMBER
   )
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_doc_types_rec FOR
         SELECT * FROM doc_type;

   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END get_doc_types;

   PROCEDURE prepare_doc_detail_by_sn (
      p_serial_number          NVARCHAR2
   )
   IS
  v_threshold number;
  v_sn doc_detail.seria_start%type;
  v_length number;
  v_ss doc_detail.seria_start%type;
  v_se doc_detail.seria_end%type;

  --future pkg_constants
  c_setting_dd_by_qty_threshold  constant nvarchar2(50) := 'DD_BY_QTY_THRESHOLD';
  c_dsetting_dd_by_qty_threshold constant number := 2000;

  FUNCTION get_setting_num(p_name VARCHAR2, p_default NUMBER := NULL) RETURN NUMBER IS
  v_res NUMBER;
  BEGIN
      SELECT /*+ full(z)*/ --need func index lower(db_parameter_name)
          z.VALUE INTO v_res FROM global_value z
          WHERE lower(z.NAME) = lower(p_name);
      RETURN v_res;
  EXCEPTION
  WHEN OTHERS THEN
      RETURN p_default;
  END;

   BEGIN
      v_threshold := install_pkg.nnget_option_num(c_setting_dd_by_qty_threshold, c_dsetting_dd_by_qty_threshold);
      if translate(p_serial_number, '_0123456789', '_') is not null then
          raise_application_error(util_pkg.c_ora_invalid_parameter, 'Not implemented for non-numeric serial nummbers!');
      end if;
      v_sn := p_serial_number;
      v_length := length(v_sn);
      v_ss := lpad(to_nchar(greatest(to_number(v_sn) - v_threshold, 0)), v_length, '0');
      v_se := lpad(to_nchar(least(to_number(v_sn) + v_threshold, to_number(lpad('9', v_length, '9')))), v_length, '0');

      delete from tt_id;

      insert into tt_id(id)
select /*+ ordered use_nl(z) index_asc(z, PK_DOC_DETAIL)*/
    q.id
    from (
select /*+ index_asc(z, DOC_DETAIL_SS)*/
    id
    from doc_detail z
    where 1 = 1
    and length(seria_start) = v_length
    and seria_start between v_ss and v_se
intersect
select /*+ index_asc(z, DOC_DETAIL_SE)*/
    id
    from doc_detail z
    where 1 = 1
    and length(seria_end) = v_length
    and seria_end between v_ss and v_se
    ) q, doc_detail z
    where 1 = 1
    and z.id = q.id
    and v_sn between z.seria_start and z.seria_end
    and length(z.seria_start) = v_length
    and length(z.seria_end) = v_length
      ;

      insert into tt_id(id)
select /*+ index_asc(z, IDX_DOCDETAIL_QUANTITY)*/
    id
    from doc_detail z
    where 1 = 1
    and case when quantity between -1 and 1 then null else quantity end > v_threshold
    and length(seria_start) = v_length
    and v_sn between seria_start and seria_end
    and not exists (select /*+ hash_sj full(t)*/1 from tt_id t where id = z.id)
      ;

      insert into tt_id(id)
select /*+ index_asc(z, IDX_DOCDETAIL_QUANTITY)*/
    id
    from doc_detail z
    where 1 = 1
    and case when quantity between -1 and 1 then null else quantity end < v_threshold
    and length(seria_start) = v_length
    and v_sn between seria_start and seria_end
    and not exists (select /*+ hash_sj full(t)*/1 from tt_id t where id = z.id)
      ;

   END prepare_doc_detail_by_sn;


   function GetEquipmentMoveDirection(
     p_doc_type_id         number,
     p_all_stocks          number,
     p_from_stock_id       number,
     p_to_stock_id         number
     )
     return number
   is
    v_result number;
   begin
     if (p_all_stocks = 0)
     then
       case p_doc_type_id
         when util_stock.c_Doc_Type_Receipt then
           v_result := 1;
         when util_stock.c_Doc_Type_Shippment then
           v_result := -1;
         when util_stock.c_Doc_Type_Movement then
           select nvl(sum(cnt),0)
             into v_result
             from (select /*+  index_asc(t, I_TMP_STOCK_ID)*/
                          distinct -1 cnt
                     from tmp_stock_id t
                    where t.id = p_from_stock_id
                   union
                   select /*+  index_asc(t, I_TMP_STOCK_ID)*/
                          distinct 1 cnt
                     from tmp_stock_id t
                    where t.id = p_to_stock_id);
         when util_stock.c_Doc_Type_Assembling then
           v_result := 0;
         when util_stock.c_Doc_Type_Disassembling then
           v_result := 0;
         when util_stock.c_Doc_Type_Credit then
           v_result := 1;
         when util_stock.c_Doc_Type_Debit then
           v_result := -1;
         when util_stock.c_Doc_Type_ErrorReport then
           v_result := -1;
       else
         raise_application_error(util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type);
       end case;
     else
       case p_doc_type_id
         when util_stock.c_Doc_Type_Receipt then
           v_result := 1;
         when util_stock.c_Doc_Type_Shippment then
           v_result := -1;
         when util_stock.c_Doc_Type_Movement then
           v_result := 0;
         when util_stock.c_Doc_Type_Assembling then
           v_result := 0;
         when util_stock.c_Doc_Type_Disassembling then
           v_result := 0;
         when util_stock.c_Doc_Type_Credit then
           v_result := 1;
         when util_stock.c_Doc_Type_Debit then
           v_result := -1;
         when util_stock.c_Doc_Type_ErrorReport then
           v_result := -1;
       else
         raise_application_error(util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type);
       end case;
     end if;

     return v_result;
   end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_result_cursor001(p_dh_ids ct_number, p_trim_empty boolean, p_result out sys_refcursor)
is
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  open p_result for
select /*+ ordered no_expand use_nl(q, dh, u, lu)
  index_asc(dh, PK_DOC_HEADER)
  index_asc(u, PK_USERS)
  index_asc(lu, PK_USERS)
  */
  dh.id,
  nvl(u.user_name, dh.user_id) user_id,
  dh.create_date,
  dh.doc_date,
  dh.doc_type_id,
  dh.doc_no,
  dh.status_id,
  dh.stock_out_id,
  dh.stock_in_id,
  dh.vendor_doc,
  dh.valid_until,
  dh.description,
  dh.user_comment,
  nvl(lu.user_name, dh.last_user) last_user,
  dh.date_of_move_in,
  dh.date_of_move_out,
  dh.vendor_id
  from
    (select column_value id, rownum rn from table(p_dh_ids)) q,
    doc_header dh,
    users u,
    users lu
  where 1 = 1
  and dh.id(+) = q.id
  and u.user_id(+) = dh.user_id2
  and lu.user_id(+) = dh.last_user_id2
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(dh.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_result_cursor002(p_stock_in_id number, p_vendor_doc nvarchar2, p_result out sys_refcursor)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_in_id is null, 'p_stock_in_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_vendor_doc is null, 'p_vendor_doc');
  ------------------------------
  open p_result for
select /*+ ordered no_expand use_nl(dh, u, lu)
  index_asc(dh, IDX_DOCHEADER_SI_DD_DMI)
  index_asc(u, PK_USERS)
  index_asc(lu, PK_USERS)
  */
  dh.id,
  nvl(u.user_name, dh.user_id) user_id,
  dh.create_date,
  dh.doc_date,
  dh.doc_type_id,
  dh.doc_no,
  dh.status_id,
  dh.stock_out_id,
  dh.stock_in_id,
  dh.vendor_doc,
  dh.valid_until,
  dh.description,
  dh.user_comment,
  nvl(lu.user_name, dh.last_user) last_user,
  dh.date_of_move_in,
  dh.date_of_move_out,
  dh.vendor_id
  from
    doc_header dh,
    users u,
    users lu
  where 1 = 1
  and dh.stock_in_id = p_stock_in_id
  and dh.vendor_doc = nvl(p_vendor_doc, dh.vendor_doc)
  and u.user_id(+) = dh.user_id2
  and lu.user_id(+) = dh.last_user_id2
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! ex-view V_DOC_HEADER
----------------------------------!---------------------------------------------
procedure get_result_cursor003(p_dh_ids ct_number, p_trim_empty boolean, p_result out sys_refcursor)
is
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  open p_result for
select /*+ ordered no_expand use_nl(q, dh, u, lu, so, si)
  index_asc(dh, PK_DOC_HEADER)
  index_asc(u, PK_USERS)
  index_asc(lu, PK_USERS)
  index_asc(so, PK_STOCK)
  index_asc(si, PK_STOCK)
  */
  dh.id "Id",
  nvl(u.user_name, dh.user_id) "User",
  dh.create_date "Date",
  dh.doc_date "Document date",
  dh.doc_type_id "Type",
  dh.doc_no "No",
  dh.status_id "Status Id",
  dh.vendor_doc "Vendor document",
  dh.stock_out_id "From Id",
  so.name "From Stock",
  dh.stock_in_id "To Id",
  si.name "To Stock",
  dh.valid_until "Valid",
  dh.description "Description",
  dh.user_comment "Comment",
  nvl(lu.user_name, dh.last_user) "Last user",
  (select /*+ index_asc(dh2, DOC_HEADER_UC_ID)*/count(1) from doc_header dh2 where user_comment = dh.doc_no) "Linked documents"
  from
    (select column_value id, rownum rn from table(p_dh_ids)) q,
    doc_header dh,
    users u,
    users lu,
    stock so,
    stock si
  where 1 = 1
  and dh.id(+) = q.id
  and u.user_id(+) = dh.user_id2
  and lu.user_id(+) = dh.last_user_id2
  and so.id(+) = dh.stock_out_id
  and si.id(+) = dh.stock_in_id
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(dh.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! ex-view VW_DOC_REPORT_1
----------------------------------!---------------------------------------------
procedure get_result_cursor004(p_dh_ids ct_number, p_trim_empty boolean, p_result out sys_refcursor)
is
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  open p_result for
select /*+ driving_site(q) ordered no_expand use_nl(q, dh, u, lu, so, si, pr, dd, em, et, ct, vd)
  index_asc(dh, PK_DOC_HEADER)
  index_asc(u, PK_USERS)
  index_asc(lu, PK_USERS)
  index_asc(so, PK_STOCK)
  index_asc(si, PK_STOCK)
  index_asc(pr, PK_PRODUCER)
  index_asc(dd, IDX_DOCDETAIL_DHI_EMI_DMI_DMO)
  index_asc(em, PK_EQUIPMENT_MODEL)
  index_asc(et, PK_EQUIPMENT_TYPE)
  index_asc(ct, PK_COUNTRY)
  index_asc(vd, PK_VENDOR)
  */
  dh.id "Id",
  nvl(u.user_name, dh.user_id) "User",
  dh.create_date "Date",
  dh.doc_date "Document date",
  dh.doc_type_id "Type",
  dh.doc_no "No",
  dh.status_id "Status Id",
  dh.stock_out_id "From Id",
  dh.stock_in_id "To Id",
  pr.producer_name "Producer",
  dh.valid_until "Document Valid",
  dh.description "Description",
  dh.user_comment "Comment",
  --nvl(lu.user_name, dh.last_user) "Last user",
  dd.equipment_model_id "Model Id",
  em.equipment_model_name "Model Name",
  dd.seria_start "Seria From",
  dd.seria_end "Seria To",
  dd.quantity "Quantity",
  dd.unit "Unit",
  dd.valid_until "Valid",
  dh.vendor_doc "Vendor document",
  et.equipment_type_name "Equipment name",
  si.name "Stock in",
  so.name "Stock out",
  em.equipment_model_code "Equipment code",
  ct.country_name "Country",
  dd.equipment_batch_id "Equipment batch id",
  vd.vendor_name "Vendor name",
  vd.vendor_code "Vendor code",
  si.address "Stock in address",
  so.address "Stock out address",
  si.stock_manager "Stock in stock manager",
  so.stock_manager "Stock out stock manager",
  si.stock_owner "Stock in stock owner",
  so.stock_owner "Stock out stock owner"
  from
    (select column_value id, rownum rn from table(p_dh_ids)) q,
    doc_header dh,
    users u,
    --users lu,
    stock so,
    stock si,
    producer pr,
    doc_detail dd,
    equipment_model em,
    equipment_type et,
    country ct,
    v_vendor vd
  where 1 = 1
  and dh.id(+) = q.id
  and u.user_id(+) = dh.user_id2
  --and lu.user_id(+) = dh.last_user_id2
  and so.id(+) = dh.stock_out_id
  and si.id(+) = dh.stock_in_id
  and pr.producer_id(+) = em.producer_id
  and dd.doc_header_id(+) = dh.id
  and em.equipment_model_id(+) = dd.equipment_model_id
  and et.equipment_type_id(+) = em.equipment_type_id
  and ct.country_id(+) = pr.country_id
  and vd.vendor_id(+) = dh.vendor_id
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(dh.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(dd.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
  --!_!and u.deleted(+)
  --!_!and lu.deleted(+)
  --!_!and so.deleted(+)
  --!_!and si.deleted(+)
  --!_!and em.deleted(+)
  --!_!and et.deleted(+)
  --!_!and pr.deleted(+)
  --!_!and cr.deleted(+)
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! ex-view VW_DOC_REPORT_1
----------------------------------!---------------------------------------------
procedure get_result_cursor005(p_dh_ids ct_number, p_trim_empty boolean, p_stock_id number, p_model_id number, p_seria_start nvarchar2, p_seria_end nvarchar2, p_result out sys_refcursor)
is
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  ------------------------------
  open p_result for
select /*+ driving_site(q) ordered no_expand use_nl(q, dh, u, lu, so, si, pr, dd, em, et, ct, vd)
  index_asc(dh, PK_DOC_HEADER)
  index_asc(u, PK_USERS)
  index_asc(lu, PK_USERS)
  index_asc(so, PK_STOCK)
  index_asc(si, PK_STOCK)
  index_asc(pr, PK_PRODUCER)
  index_asc(dd, IDX_DOCDETAIL_DHI_EMI_DMI_DMO)
  index_asc(em, PK_EQUIPMENT_MODEL)
  index_asc(et, PK_EQUIPMENT_TYPE)
  index_asc(ct, PK_COUNTRY)
  index_asc(vd, PK_VENDOR)
  */
  dh.id "Id",
  nvl(u.user_name, dh.user_id) "User",
  dh.create_date "Date",
  dh.doc_date "Document date",
  dh.doc_type_id "Type",
  dh.doc_no "No",
  dh.status_id "Status Id",
  dh.stock_out_id "From Id",
  dh.stock_in_id "To Id",
  pr.producer_name "Producer",
  dh.valid_until "Document Valid",
  dh.description "Description",
  dh.user_comment "Comment",
  --nvl(lu.user_name, dh.last_user) "Last user",
  dd.equipment_model_id "Model Id",
  em.equipment_model_name "Model Name",
  dd.seria_start "Seria From",
  dd.seria_end "Seria To",
  util_stock.get_doc_sign_old(dh.doc_type_id, p_stock_id, dh.stock_out_id) * dd.quantity "Quantity", --!_!
  dd.unit "Unit",
  dd.valid_until "Valid",
  --!_!dh.vendor_doc "Vendor document",
  et.equipment_type_name "Equipment name",
  si.name "Stock in",
  so.name "Stock out",
  --!_!em.equipment_model_code "Equipment code",
  --!_!ct.country_name "Country",
  --!_!dd.equipment_batch_id "Equipment batch id",
  vd.vendor_name "Vendor name",
  vd.vendor_code "Vendor code",
  si.address "Stock in address",
  so.address "Stock out address",
  si.stock_manager "Stock in stock manager",
  so.stock_manager "Stock out stock manager",
  si.stock_owner "Stock in stock owner",
  so.stock_owner "Stock out stock owner"
  from
    (select column_value id, rownum rn from table(p_dh_ids)) q,
    doc_header dh,
    users u,
    --users lu,
    stock so,
    stock si,
    producer pr,
    doc_detail dd,
    equipment_model em,
    equipment_type et,
    --!_!country ct,
    v_vendor vd
  where 1 = 1
  --
  and dd.equipment_model_id = nvl(p_model_id, dd.equipment_model_id)
  and dd.seria_start = nvl(p_seria_start, dd.seria_start)
  and dd.seria_end = nvl(p_seria_end, dd.seria_end)
  --
  and dh.id(+) = q.id
  and u.user_id(+) = dh.user_id2
  --and lu.user_id(+) = dh.last_user_id2
  and so.id(+) = dh.stock_out_id
  and si.id(+) = dh.stock_in_id
  and pr.producer_id(+) = em.producer_id
  --!_!and dd.doc_header_id(+) = dh.id
  and dd.doc_header_id = dh.id
  and em.equipment_model_id(+) = dd.equipment_model_id
  and et.equipment_type_id(+) = em.equipment_type_id
  --!_!and ct.country_id(+) = pr.country_id
  and vd.vendor_id(+) = dh.vendor_id
  and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(dh.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  --!_!and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(dd.id, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
  order by q.rn
  ;
  ------------------------------
  --!_!and u.deleted(+)
  --!_!and lu.deleted(+)
  --!_!and so.deleted(+)
  --!_!and si.deleted(+)
  --!_!and em.deleted(+)
  --!_!and et.deleted(+)
  --!_!and pr.deleted(+)
  --!_!and cr.deleted(+)
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

END;

/
