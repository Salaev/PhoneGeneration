CREATE PACKAGE crm_management IS
/*******************************************************************************
   <name>          EQUIPMENT_MODEL__Get
   <author>        Petar Ulic
   <version>       1.1   06.12.2003 basic Oracle implementation
                   1.0   10.11.2003 basic MS SQL version
   <Description>
   <Prerequisites>
   <Application>   Stock Management
   <Parameters>    p_id NUMBER
                   p_type_id NUMBER
                   p_equipment_model_rec OUT sys_refcursor
                   p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                              - else returns error identification
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ------------------------------------------
-- Petr Skripnik   10.11.2006  Изменен
*******************************************************************************/

   TYPE aaserialnum IS TABLE OF sims.serial_number%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aacontrolnum IS TABLE OF sims.control_number%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aastatus IS TABLE OF sims.status%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aaeqid IS TABLE OF sims.ID%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aadocheaderid IS TABLE OF doc_detail.doc_header_id%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aastock IS TABLE OF stock.ID%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aaseriastart IS TABLE OF stock_state.seria_start%TYPE
      INDEX BY BINARY_INTEGER;

   --имя пакета

   --------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE equipment_model__get (
      p_id                          NUMBER,
      p_type_id                     NUMBER,
      p_equipment_model_rec   OUT   sys_refcursor,
      p_error_code            OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_state__get_equipment (
      p_stock_code              NVARCHAR2,
      p_equipment_code          NVARCHAR2,
      p_quantity                NUMBER,
      p_reserved                NVARCHAR2,
      p_stock_state_rec   OUT   sys_refcursor,
      p_error_code        OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE sims__bulk_ins (
      p_serial_number               aaserialnum,
      p_control_number              aacontrolnum,
      p_status                      aastatus,
      p_single_equipment_id   OUT   aaeqid,
      p_length                      NUMBER,
      p_handle_tran                 CHAR := 'Y',
      p_error_code            OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE scratchcardexist (
      p_stockid             NVARCHAR2,
      p_seria_start         NVARCHAR2,
      p_seria_end           NVARCHAR2,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE getscratchcardequipmentcode (
      p_stockid               NVARCHAR2,
      p_seria_start           NVARCHAR2,
      p_seria_end             NVARCHAR2,
      p_keo_cards_rec   OUT   sys_refcursor,
      p_error_code      OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   FUNCTION get_phone_number (p_full_number VARCHAR2)
      RETURN VARCHAR2;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE getscratchcardsbycount (
      p_stock_code                 NVARCHAR2,
      p_equipment_code             NVARCHAR2,
      p_equipment_quantity         NUMBER,
      p_reserved                   NVARCHAR2,
      p_keo_cards_rec        OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE getscratchcardsbycount2 (
      p_stock_code                    NVARCHAR2,
      p_equipment_code                NVARCHAR2,
      p_equipment_quantity            NUMBER,
      p_equipment_valid_until         DATE,
      p_reserved                      NVARCHAR2,
      p_keo_cards_rec           OUT   sys_refcursor,
      p_error_code              OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose : Находит симкарТЫ на складАХ на текущий момент времени
--------------------------------------------------------------------------------
   PROCEDURE findequipment (p_equipmenttable_rec OUT sys_refcursor, p_error_code OUT NUMBER);

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose : Находит симкарТЫ на складЕ на текущий момент времени
--------------------------------------------------------------------------------
   PROCEDURE findequipment (
      p_single_equipment_id   IN       NUMBER,
      p_stock_id              IN       NVARCHAR2,
      p_equipmenttable_rec    OUT      sys_refcursor,
      p_error_code            OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Ermakov Sergey
-- Changed : Ermakov Sergey 13.03.2009 20:22 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose : Находит одну заданную симкарту на всех складах на текущий момент времени
--------------------------------------------------------------------------------
   PROCEDURE findequipment (
      p_single_equipment_id   IN       NUMBER,
      p_equipmenttable_rec    OUT      sys_refcursor,
      p_error_code            OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Ermakov Sergey and Victor Smirnov
-- Changed : Ermakov Sergey and Victor Smirnov 20.03.2009 21:02
-- Purpose : Находит несколько заданных симкарт на всех складах на текущий момент времени
--------------------------------------------------------------------------------
   PROCEDURE findequipment (
      p_tab_equipment_id   	 IN       pkg_common.t_num,
      p_equipmenttable_rec   OUT      sys_refcursor,
      p_error_code           OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 24.10.2006 15:00
--           Skripnik Petr 10.04.2007 16:55 Соеденение с equipment_model для исключения получения кода из sims
-- Purpose : Находит симкарТЫ на складЕ на текущий момент времени
--
--  Процедура findequipment_2 аналогична процедуре
--   PROCEDURE findequipment (
--      p_single_equipment_id   IN       NUMBER,
--      p_stock_id              IN       NVARCHAR2,
--      p_equipmenttable_rec    OUT      sys_refcursor,
--      p_error_code            OUT      NUMBER
--   )
--  Создана для поддержки FORIS.DataAccess
--------------------------------------------------------------------------------
   PROCEDURE findequipment_2 (
      p_single_equipment_id   IN       NUMBER,
      p_stock_id              IN       NVARCHAR2,
      p_equipmenttable_rec    OUT      sys_refcursor,
      p_error_code            OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Ermakov Sergey and Victor Smirnov
-- Changed : Ermakov Sergey and Victor Smirnov 20.03.2009 21:02
-- Purpose : Находит несколько заданные симкарты на всех складах на текущий момент времени
--
--  Процедура findequipment_4 аналогична процедуре
--   PROCEDURE findequipment (
--      p_tab_equipment_id     IN       pkg_common.t_num,
--      p_equipmenttable_rec   OUT      sys_refcursor,
--      p_error_code           OUT      NUMBER
--   )
--  Создана для поддержки FORIS.DataAccess
--------------------------------------------------------------------------------
   PROCEDURE findequipment_4 (
      p_tab_equipment_id     IN       pkg_common.t_num,
      p_equipmenttable_rec   OUT      sys_refcursor,
      p_error_code           OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Ermakov Sergey
-- Changed : Ermakov Sergey 03.02.2010 20:22
-- Purpose : Находит склад, на котором находтится оборудование заданного типа с указанным серийным нромером
--
--------------------------------------------------------------------------------
   PROCEDURE findequipment_5 (
      p_equipment_type_id     IN       NUMBER,
      p_serial_number         IN       VARCHAR2,
      p_equipment_table_rec   OUT      sys_refcursor,
      p_error_code            OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Ermakov Sergey
-- Changed : Ermakov Sergey 03.02.2010 20:22
-- Purpose : Находит склад, на котором находтится оборудование заданноq модели с указанным серийным нромером
--
--------------------------------------------------------------------------------
   PROCEDURE findequipment_6 (
      p_equipment_model_id    IN       NUMBER,
      p_serial_number         IN       VARCHAR2,
      p_equipment_table_rec   OUT      sys_refcursor,
      p_error_code            OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Ermakov Sergey
-- Changed : Ermakov Sergey 12.10.2010 20:22
-- Purpose : Находит склад, на котором находтится оборудование заданного типа с указанным серийным нромером
--
--------------------------------------------------------------------------------
   PROCEDURE findequipment_7 (
      p_equipment_type_id     IN       NUMBER,
      p_serial_number         IN       aaseriastart,
      p_equipment_table_rec   OUT      sys_refcursor,
      p_error_message         OUT      VARCHAR2,
      p_error_code            OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findequipmentrange (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_valid_until                DATE,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findequipmentrange_bulk (
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findequipmentrangebetween (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_valid_until                DATE,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function find_equipment_model
  (
    p_equipment_model_code nvarchar2,
    p_equipment_model_name_mask nvarchar2,
    p_date date
  ) return ct_number;

  procedure findequipmentinventory
  (
    p_equipment_code nvarchar2,
    p_equipment_name nvarchar2,
    p_equipmenttable_rec out sys_refcursor,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findequipmentinventorybetween (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_valid_until                DATE,
      p_reserved                   NVARCHAR2,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findjeanspackages (
      p_validity_date              DATE,
      p_quantity                   NUMBER,
      p_iccid_from                 NVARCHAR2,
      p_iccid_to                   NVARCHAR2,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findjeanspackagesnophonenumber (
      p_validity_date              DATE,
      p_quantity                   NUMBER,
      p_iccid_from                 NVARCHAR2,
      p_iccid_to                   NVARCHAR2,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findscratchcard (
      p_serial_number              NVARCHAR2,
      p_valid_until                DATE,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose : Текущее состояние склада по определенному открытому оборудованию с количеством
--------------------------------------------------------------------------------
   PROCEDURE findequipmenttoremove (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_reserved                   NVARCHAR2,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stockstatedelete (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stockstateupdate (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : 24.10.2006 15:00
--   SP 08.06.2007 Skripnik Petr Удален параметр document_no
-- Purpose : Вставляет запись в текущее состояние склада
--------------------------------------------------------------------------------
   PROCEDURE stockstateinsert (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity_onstock           NUMBER,
      p_quantity_reserved          NUMBER,
      p_quantity_announced         NUMBER,
      p_doc_header_id              NUMBER,
      p_create_date                DATE,
      p_status                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.10.2006 15:00
-- Editor  : Skripnik Petr
-- Changed :
--   SP 08.06.2007 Skripnik Petr Удален параметр document_no
-- Purpose : Вставляет запись в текущее состояние склада
--------------------------------------------------------------------------------
   PROCEDURE stockstateinsert (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity_onstock           NUMBER,
      p_quantity_reserved          NUMBER,
      p_quantity_announced         NUMBER,
      p_doc_header_id              NUMBER,
      p_create_date                DATE,
      p_status                     NUMBER,
      p_equipment_batch_id         NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.10.2006 15:00
-- Editor  : Skripnik Petr
-- Changed :
--   SP 08.06.2007 Skripnik Petr Удалена колонка document_no
-- Purpose : Вставляет запись в текущее состояние склада
--
--  Процедура stockstateinsert_2 аналогична процедуре
--   PROCEDURE stockstateinsert (
--      p_stock_id                   NUMBER,
--      p_equipment_model_id         NUMBER,
--      p_seria_start                NVARCHAR2,
--      p_seria_end                  NVARCHAR2,
--      p_quantity_onstock           NUMBER,
--      p_quantity_reserved          NUMBER,
--      p_quantity_announced         NUMBER,
--      p_doc_header_id              NUMBER,
--      p_create_date                DATE,
--      p_status                     NUMBER,
--      p_equipment_batch_id         NUMBER,
--      p_handle_tran                CHAR := 'Y',
--      p_error_code           OUT   NUMBER
--     )
--  Создана для поддержки FORIS.DataAccess
--------------------------------------------------------------------------------
   PROCEDURE stockstateinsert_2 (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity_onstock           NUMBER,
      p_quantity_reserved          NUMBER,
      p_quantity_announced         NUMBER,
      p_doc_header_id              NUMBER,
      p_create_date                DATE,
      p_status                     NUMBER,
      p_equipment_batch_id         NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure finduserstocks_2
  (
    p_user_id users.user_name%type,
    p_stock_code stock.code%type,
    p_stocktable_rec out sys_refcursor,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  function getequipmentcount01 return sys_refcursor;
  function getequipmentcount02 return sys_refcursor;

  procedure getequipmentcount
  (
    p_equipmenttable_rec out sys_refcursor,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findequipmenttypeandidbycode (
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure SetEquipmentComment
  (
    p_stock_id number,
    p_equipment_model_id number,
    p_seria_start nvarchar2,
    p_seria_end nvarchar2,
    p_user_comment nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE setequipmentreservation (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity                   NUMBER,
      p_reserved                   NVARCHAR2,
      p_reserve                    NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 27.12.2006 12:55 Тип OUT с sys_refcursor -> sys_refcursor
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findsimcardsiccidsonly (
      p_stock_code            NVARCHAR2,
      p_iccid_from            NVARCHAR2,
      p_iccid_to              NVARCHAR2,
      p_quantity              NUMBER,
      p_sim_cards_rec   OUT   sys_refcursor,
      p_error_code      OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Orlenko Olga
-- Changed : 25.01.2010
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE lockequipmentrange (
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_valid_until                DATE,
      p_error_code           OUT   NUMBER
   );

-------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Version :
-- Modification :
-- Editor  : Vasiliev Pavel
-- Changed :
--   SP 19.01.2012 за основу взята findjeanspackagesnophonenumber
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE findjeanspackagesnophonenum2 (
      p_validity_date              DATE,
      p_quantity                   NUMBER,
      p_stock_codes                aaseriastart,
      p_equipment_codes            aaseriastart,
      p_iccid_from                 aaseriastart,
      p_iccid_to                   aaseriastart,
      p_equipmenttable_rec   OUT   sys_refcursor,
      p_error_code           OUT   NUMBER
   );
END;
/
