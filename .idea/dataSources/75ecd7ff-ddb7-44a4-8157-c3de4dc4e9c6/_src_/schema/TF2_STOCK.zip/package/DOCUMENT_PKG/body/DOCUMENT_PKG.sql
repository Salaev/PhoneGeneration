CREATE package body document_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_t_doc_locker(p_coll t_doc_locker) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function GS_doc_locker_exp_per_sec return number
is
begin
  ------------------------------
  return install_pkg.nnget_option_num(c_opt_doc_locker_exp_per_sec, c_def_doc_locker_exp_per_sec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GS_doc_locker_wait_sec return number
is
begin
  ------------------------------
  return install_pkg.nnget_option_num(c_opt_doc_locker_wait_sec, c_def_doc_locker_wait_sec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GS_max_valid_until return date
is
begin
  ------------------------------
  return install_pkg.nnget_option_date(c_opt_max_valid_until, c_def_max_valid_until);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Raise_Document_NotFound(p_label varchar2)
is
begin
  ------------------------------
  util_pkg.Raise_exception(util_loc_pkg.c_ora_document_not_found, util_loc_pkg.c_msg_document_not_found || util_pkg.c_msg_delim01 || p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_Document_NotFound(p_raise_condition boolean, p_label varchar2)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_raise_condition is null, 'p_raise_condition');
  --!_!util_pkg.XCheck_Cond_Missing(p_label is null, 'p_label');
  ------------------------------
  if p_raise_condition
  then
    ------------------------------
    Raise_Document_NotFound(p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure release_expired_doc_locker
is
  pragma autonomous_transaction;
  v_doc_locker_ids ct_number;
  v_doc_locker_group_ids ct_number;
  v_expire_period number;
  v_expiration_date date;
begin
  ------------------------------
  v_expire_period := GS_doc_locker_exp_per_sec;
  ------------------------------
  v_expiration_date := SYSDATE - v_expire_period * util_pkg.c_second;
  ------------------------------
  select /*+ ordered use_nl(dl) index(dl I_DOC_LOCKER_DATE) index(dlg I_DOC_LOCKER_GROUP_DH_DL_DT)*/
         dlg.doc_locker_group_id
    bulk collect into v_doc_locker_group_ids
    from doc_locker dl
    join doc_locker_groups dlg on dlg.doc_header_id = dl.doc_header_id
                               and dlg.doc_locker_id = dl.doc_locker_id
                               and dlg.doc_locker_type = dl.doc_locker_type
   where dl.date_from <= v_expiration_date
     and not exists (select /*+ ordered use_nl(dl1) index(dlg1 I_DOC_LOCKER_GROUP) index(dl1 PK_DOC_LOCKER)*/
                            1
                      from doc_locker_groups dlg1
                      join doc_locker dl1 on dl1.doc_header_id = dlg1.doc_header_id
                                         and dl1.doc_locker_id = dlg1.doc_locker_id
                                         and dl1.doc_locker_type = dlg1.doc_locker_type
                     where dlg1.doc_locker_group_id = dlg.doc_locker_group_id
                       and dl1.date_from > v_expiration_date)
  ;
  ------------------------------
  if util_pkg.get_count_ct_number(v_doc_locker_group_ids) > 0
  then
    ------------------------------
    for i in v_doc_locker_group_ids.first..v_doc_locker_group_ids.last
    loop
      ------------------------------
      close_group_doc_locker(v_doc_locker_group_ids(i));
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
  --Release not grouped lockers
  select /*+ index(dl I_DOC_LOCKER_DATE)*/
         dl.doc_header_id
    bulk collect into v_doc_locker_ids
    from doc_locker dl
   where dl.date_from <= v_expiration_date
     and not exists(select /*+ index(dlg I_DOC_LOCKER_GROUP_DH_DL_DT)*/
                           1
                      from doc_locker_groups dlg
                     where dlg.doc_header_id = dl.doc_header_id
                       and dlg.doc_locker_id = dl.doc_locker_id
                       and dlg.doc_locker_type = dl.doc_locker_type)
     for update skip locked --!_!
  ;
  ------------------------------
  if util_pkg.get_count_ct_number(v_doc_locker_ids) > 0
  then
    ------------------------------
    forall i in v_doc_locker_ids.first..v_doc_locker_ids.last
      delete /*+ index(dl PK_DOC_LOCKER)*/
        from doc_locker dl
        where doc_header_id = v_doc_locker_ids(i)
    ;
    ------------------------------
  end if;
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function create_exclusive_doc_locker(p_doc_header_id number, p_doc_locker_group number default null) return doc_locker_groups%rowtype
is
  pragma autonomous_transaction;
  v_doc_locker doc_locker%rowtype;
  v_doc_locker_group doc_locker_groups%rowtype;
  v_doc_locker_id number;
  v_doc_locker_group_id number;
  v_cnt number;
  v_label varchar2(30);
begin
  ------------------------------
  if p_doc_header_id is null
  then
    ------------------------------
    rollback;
    ------------------------------
    util_pkg.Raise_exception(util_loc_pkg.c_ora_doc_header_id_not_set, util_loc_pkg.c_msg_doc_header_id_not_set);
    ------------------------------
  end if;
  ------------------------------
  release_expired_doc_locker;
  ------------------------------
  if p_doc_locker_group is not null
  then
    select /*+ index(dlg I_DOC_LOCKER_GROUP)*/
           count(1) into v_cnt
      from doc_locker_groups dlg
     where doc_locker_group_id = p_doc_locker_group
    ;
    ------------------------------
    if v_cnt = 0
    then
      ------------------------------
      rollback;
      ------------------------------
      util_pkg.Raise_exception(util_loc_pkg.c_ora_doc_locker_group_not_fnd, util_loc_pkg.c_msg_doc_locker_group_not_fnd || util_pkg.c_msg_delim01 || to_char(p_doc_header_id) || util_pkg.c_msg_delim02 || to_char(p_doc_locker_group));
      ------------------------------
    end if;
    ------------------------------
    v_doc_locker_group_id := p_doc_locker_group;
    ------------------------------
  else
    ------------------------------
    v_doc_locker_group_id := s_doc_locker_group.nextval;
    ------------------------------
  end if;
  ------------------------------
  v_doc_locker_id := s_doc_locker.nextval;
  ------------------------------
  v_label := 'doc_locker';
  ------------------------------
  insert into doc_locker (doc_header_id, doc_locker_id, doc_locker_type, owner_count, date_from)
    values (p_doc_header_id, v_doc_locker_id, c_exclusive_lock, 1, sysdate)
    returning doc_header_id, doc_locker_id, doc_locker_type, owner_count, date_from
    into v_doc_locker
  ;
  ------------------------------
  v_label := 'doc_locker_groups';
  ------------------------------
  insert into doc_locker_groups (doc_header_id, doc_locker_id, doc_locker_type, doc_locker_group_id)
    values (v_doc_locker.doc_header_id, v_doc_locker.doc_locker_id, v_doc_locker.doc_locker_type, v_doc_locker_group_id)
    returning doc_header_id, doc_locker_id, doc_locker_type, doc_locker_group_id
    into v_doc_locker_group
  ;
  ------------------------------
  commit;
  ------------------------------
  return v_doc_locker_group;
  ------------------------------
exception
when util_pkg.unique_exception then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.Raise_exception(util_loc_pkg.c_ora_doc_already_locked, util_loc_pkg.c_msg_doc_already_locked || util_pkg.c_msg_delim01 || v_label || util_pkg.c_msg_delim02 || to_char(p_doc_header_id) || util_pkg.c_msg_delim02 || to_char(p_doc_locker_group));
  ------------------------------
when others then
  ------------------------------
  rollback;
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_and_get_doc_locker(p_doc_header_id number) return doc_locker%rowtype
is
  v_res doc_locker%rowtype;
  v_wait_sec number;
  v_sql_text varchar2(32767);
begin
  ------------------------------
  v_wait_sec := GS_doc_locker_wait_sec;
  ------------------------------
  v_sql_text := q'{select /*+ index(z PK_DOC_LOCKER)*/
  *
  from doc_locker z
  where 1 = 1
  and doc_header_id = :p_doc_header_id
  for update wait :p_wait_sec
}'
  ;
  ------------------------------
  v_sql_text := replace(v_sql_text, ':p_wait_sec', to_char(v_wait_sec));
  ------------------------------
  execute immediate v_sql_text into v_res using p_doc_header_id;
  ------------------------------
  return v_res;
  ------------------------------
exception
when util_pkg.lock_wait_exception then
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_object_locked, util_pkg.c_msg_object_locked || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_doc_header_id));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function create_shared_doc_locker(p_doc_header_id number, p_doc_locker_group number default null) return doc_locker_groups%rowtype
is
  pragma autonomous_transaction;
  v_doc_locker doc_locker%rowtype;
  v_doc_locker_group doc_locker_groups%rowtype;
  v_doc_locker_id number;
  v_doc_locker_group_id number;
  v_cnt number;
begin
  ------------------------------
  if p_doc_header_id is null
  then
    ------------------------------
    rollback;
    ------------------------------
    util_pkg.Raise_exception(util_loc_pkg.c_ora_doc_header_id_not_set, util_loc_pkg.c_msg_doc_header_id_not_set);
    ------------------------------
  end if;
  ------------------------------
  release_expired_doc_locker;
  ------------------------------
  if p_doc_locker_group is not null
  then
    ------------------------------
    select /*+ index(dlg I_DOC_LOCKER_GROUP)*/
      count(1) into v_cnt
      from doc_locker_groups dlg
      where dlg.doc_locker_group_id = p_doc_locker_group
    ;
    ------------------------------
    if v_cnt = 0
    then
      ------------------------------
      rollback;
      ------------------------------
      util_pkg.Raise_exception(util_loc_pkg.c_ora_doc_locker_group_not_fnd, util_loc_pkg.c_msg_doc_locker_group_not_fnd || util_pkg.c_msg_delim01 || to_char(p_doc_header_id) || util_pkg.c_msg_delim02 || to_char(p_doc_locker_group));
      ------------------------------
    end if;
    ------------------------------
    v_doc_locker_group_id := p_doc_locker_group;
    ------------------------------
  else
    ------------------------------
    v_doc_locker_group_id := s_doc_locker_group.nextval;
    ------------------------------
  end if;
  ------------------------------
  v_doc_locker_id := s_doc_locker.nextval;
  ------------------------------
  begin
    insert into doc_locker (doc_header_id, doc_locker_id, doc_locker_type, owner_count, date_from)
      values (p_doc_header_id, v_doc_locker_id, c_shared_lock, 0, sysdate)
    ;
  exception
  when util_pkg.unique_exception then
    null;
  end;
  ------------------------------
  v_doc_locker := lock_and_get_doc_locker(p_doc_header_id);
  ------------------------------
  if v_doc_locker.doc_locker_type <> c_shared_lock
  then
    ------------------------------
    rollback;
    ------------------------------
    util_pkg.Raise_exception(util_loc_pkg.c_ora_wrong_doc_locker_type, util_loc_pkg.c_msg_wrong_doc_locker_type || util_pkg.c_msg_delim01 || to_char(p_doc_header_id) || util_pkg.c_msg_delim02 || to_char(p_doc_locker_group) || util_pkg.c_msg_delim02 || to_char(v_doc_locker.doc_locker_type));
    ------------------------------
  end if;
  ------------------------------
  v_doc_locker.owner_count := v_doc_locker.owner_count + 1;
  v_doc_locker.date_from := sysdate;
  ------------------------------
  update /*+ index(dl PK_DOC_LOCKER)*/
    doc_locker dl
    set owner_count = v_doc_locker.owner_count,
        date_from = v_doc_locker.date_from
    where doc_header_id = v_doc_locker.doc_header_id
  ;
  ------------------------------
  insert into doc_locker_groups(doc_header_id, doc_locker_id, doc_locker_type, doc_locker_group_id)
    values (v_doc_locker.doc_header_id, v_doc_locker.doc_locker_id, v_doc_locker.doc_locker_type, v_doc_locker_group_id)
    returning doc_header_id, doc_locker_id, doc_locker_type, doc_locker_group_id
    into v_doc_locker_group
  ;
  ------------------------------
  commit;
  ------------------------------
  return v_doc_locker_group;
  ------------------------------
exception
when util_pkg.unique_exception then
  ------------------------------
  rollback;
  ------------------------------
  util_pkg.Raise_exception(util_loc_pkg.c_ora_doc_already_locked, util_loc_pkg.c_msg_doc_already_locked || util_pkg.c_msg_delim01 || to_char(p_doc_header_id) || util_pkg.c_msg_delim02 || to_char(p_doc_locker_group));
  ------------------------------
when others then
  ------------------------------
  rollback;
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function shared_to_exclusive_doc_locker(p_doc_locker doc_locker_groups%rowtype) return doc_locker_groups%rowtype
is
  pragma autonomous_transaction;
  v_doc_locker doc_locker%rowtype;
  v_doc_locker_group doc_locker_groups%rowtype;
  v_cnt number;
begin
  ------------------------------
  v_doc_locker_group := p_doc_locker;
  ------------------------------
  if p_doc_locker.doc_header_id is null
    or p_doc_locker.doc_locker_id is null
    or p_doc_locker.doc_locker_type is null
    or p_doc_locker.doc_locker_type <> c_shared_lock
  then
    ------------------------------
    rollback;
    ------------------------------
    util_pkg.Raise_exception(util_loc_pkg.c_ora_doc_header_id_not_set, util_loc_pkg.c_msg_doc_header_id_not_set);
    ------------------------------
  end if;
  ------------------------------
  select /*+ index(dlg I_DOC_LOCKER_GROUP)*/
    count(1) into v_cnt
    from doc_locker_groups dlg
    where 1 = 1
    and doc_locker_group_id = p_doc_locker.doc_locker_group_id
    and doc_header_id = p_doc_locker.doc_header_id
    and doc_locker_id = p_doc_locker.doc_locker_id
    and doc_locker_type = p_doc_locker.doc_locker_type
  ;
  ------------------------------
  if v_cnt = 0
  then
    ------------------------------
    rollback;
    ------------------------------
    util_pkg.Raise_exception(util_loc_pkg.c_ora_doc_locker_group_not_fnd, util_loc_pkg.c_msg_doc_locker_group_not_fnd
      || util_pkg.c_msg_delim01 || to_char(p_doc_locker.doc_header_id)
      || util_pkg.c_msg_delim02 || to_char(p_doc_locker.doc_locker_group_id)
      || util_pkg.c_msg_delim02 || to_char(p_doc_locker.doc_locker_id)
      || util_pkg.c_msg_delim02 || to_char(p_doc_locker.doc_locker_type)
    );
    ------------------------------
  end if;
  ------------------------------
  v_doc_locker := lock_and_get_doc_locker(p_doc_locker.doc_header_id);
  ------------------------------
  if v_doc_locker.doc_locker_type <> c_shared_lock
    or v_doc_locker.doc_locker_id <> p_doc_locker.doc_locker_id
    or v_doc_locker.owner_count <> 1
  then
    ------------------------------
    rollback;
    ------------------------------
    util_pkg.Raise_exception(util_loc_pkg.c_ora_wrong_doc_locker_type, util_loc_pkg.c_msg_wrong_doc_locker_type
      || util_pkg.c_msg_delim01 || to_char(p_doc_locker.doc_header_id)
      || util_pkg.c_msg_delim02 || to_char(p_doc_locker.doc_locker_group_id)
      || util_pkg.c_msg_delim02 || to_char(p_doc_locker.doc_locker_id)
      || util_pkg.c_msg_delim02 || to_char(p_doc_locker.doc_locker_type)
    );
    ------------------------------
  end if;
  ------------------------------
  v_doc_locker.owner_count := 1;
  v_doc_locker.date_from := sysdate;
  v_doc_locker.doc_locker_type := c_exclusive_lock;
  ------------------------------
  update /*+ index(dl PK_DOC_LOCKER)*/
    doc_locker dl
    set owner_count = v_doc_locker.owner_count,
        date_from = v_doc_locker.date_from,
        doc_locker_type = v_doc_locker.doc_locker_type
    where doc_header_id = v_doc_locker.doc_header_id
  ;
  ------------------------------
  update /*+ index(dlg I_DOC_LOCKER_GROUP)*/
    doc_locker_groups dlg
    set doc_locker_type = v_doc_locker.doc_locker_type
    where 1 = 1
    and doc_locker_group_id = p_doc_locker.doc_locker_group_id
    and doc_header_id = p_doc_locker.doc_header_id
    and doc_locker_id = p_doc_locker.doc_locker_id
    and doc_locker_type = p_doc_locker.doc_locker_type
  ;
  ------------------------------
  v_doc_locker_group.doc_locker_type := v_doc_locker.doc_locker_type;
  ------------------------------
  commit;
  ------------------------------
  return v_doc_locker_group;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_doc_locker_group(p_doc_locker_group_id number) return number
is
  pragma autonomous_transaction;
  v_doc_lockers t_doc_locker;
begin
  ------------------------------
  select /*+ ordered use_nl(dl) index(dlg I_DOC_LOCKER_GROUP) index(dl PK_DOC_LOCKER)*/
         dl.*
    bulk collect into v_doc_lockers
    from doc_locker_groups dlg
    left join doc_locker dl on dl.doc_header_id = dlg.doc_header_id
                           and dl.doc_locker_id = dlg.doc_locker_id
                           and dl.doc_locker_type = dlg.doc_locker_type
                           and dl.owner_count > 0
   where dlg.doc_locker_group_id = p_doc_locker_group_id
  ;
  ------------------------------
  commit;
  ------------------------------
  if get_count_t_doc_locker(v_doc_lockers) = 0 and p_doc_locker_group_id is not null
  then
    return util_pkg.c_false;
  end if;
  ------------------------------
  if get_count_t_doc_locker(v_doc_lockers) > 0
  then
    ------------------------------
    for i in v_doc_lockers.first..v_doc_lockers.last
    loop
      ------------------------------
      if v_doc_lockers(i).doc_header_id is null
      then
        return util_pkg.c_false;
      end if;
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
  return util_pkg.c_true;
  ------------------------------
exception
when NO_DATA_FOUND then
  ------------------------------
  rollback;
  ------------------------------
  return util_pkg.c_false;
  ------------------------------
when others then
  ------------------------------
  rollback;
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure close_doc_locker(p_doc_locker doc_locker%rowtype)
is
  v_cnt number;
begin
  ------------------------------
  if p_doc_locker.doc_header_id is null
  then
    return;
  end if;
  ------------------------------
  update /*+ index(dl PK_DOC_LOCKER)*/
    doc_locker dl
    set owner_count = owner_count - 1,
        date_from = sysdate
    where doc_header_id = p_doc_locker.doc_header_id
    returning owner_count into v_cnt
  ;
  ------------------------------
  if v_cnt < 1
  then
    delete /*+ index(dl PK_DOC_LOCKER)*/
      from doc_locker dl
      where 1 = 1
      and doc_header_id = p_doc_locker.doc_header_id
    ;
  end if;
  ------------------------------
exception
when NO_DATA_FOUND then
  ------------------------------
  null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_and_get_doc_locker_by_gr(p_doc_locker_group_id number) return t_doc_locker
is
  v_res t_doc_locker;
  v_wait_sec number;
  v_sql_text varchar2(32767);
begin
  ------------------------------
  v_wait_sec := GS_doc_locker_wait_sec;
  ------------------------------
  v_sql_text := q'{select /*+ ordered use_nl(dl) index(dlg I_DOC_LOCKER_GROUP) index(dl PK_DOC_LOCKER)*/
         dl.*
    from doc_locker_groups dlg
    left join doc_locker dl on dl.doc_header_id = dlg.doc_header_id and dl.doc_locker_id = dlg.doc_locker_id
   where 1 = 1
     and dlg.doc_locker_group_id = :p_doc_locker_group_id
     for update wait :p_wait_sec
}'
  ;
  ------------------------------
  v_sql_text := replace(v_sql_text, ':p_wait_sec', to_char(v_wait_sec));
  ------------------------------
  execute immediate v_sql_text bulk collect into v_res using p_doc_locker_group_id;
  ------------------------------
  return v_res;
  ------------------------------
exception
when util_pkg.lock_wait_exception then
  ------------------------------
  util_pkg.raise_exception(util_pkg.c_ora_object_locked, util_pkg.c_msg_object_locked || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_doc_locker_group_id));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure close_group_doc_locker(p_doc_locker_group_id number)
is
  pragma autonomous_transaction;
  v_doc_locker t_doc_locker;
begin
  ------------------------------
  if p_doc_locker_group_id is null
  then
    ------------------------------
    rollback;
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  v_doc_locker := lock_and_get_doc_locker_by_gr(p_doc_locker_group_id);
  ------------------------------
  if get_count_t_doc_locker(v_doc_locker) > 0
  then
    ------------------------------
    for i in v_doc_locker.first..v_doc_locker.last
    loop
      ------------------------------
      close_doc_locker(v_doc_locker(i));
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
  delete /*+ index(dlg I_DOC_LOCKER_GROUP)*/
    from doc_locker_groups dlg
    where doc_locker_group_id = p_doc_locker_group_id
  ;
  ------------------------------
  commit;
  ------------------------------
exception
when others then
  ------------------------------
  rollback;
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_doc_header_by_id(p_id number) return doc_header%rowtype
is
  v_res doc_header%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id is null, 'p_id');
  ------------------------------
  select /*+ index(z PK_DOC_HEADER)*/
    *
    into v_res
    from doc_header z
    where id = p_id
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when NO_DATA_FOUND then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! I_DOC_HEADER_DOCNO is NOT unique, but assume that doc_no IS UNIQUE
----------------------------------!---------------------------------------------
function get_doc_header_by_doc_no(p_doc_no nvarchar2) return doc_header%rowtype
is
  v_res doc_header%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_no is null, 'p_doc_no');
  ------------------------------
  select /*+ index(z I_DOC_HEADER_DOCNO)*/
    *
    into v_res
    from doc_header z
    where doc_no = p_doc_no
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when NO_DATA_FOUND then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_doc_header_by_vendor_doc(p_stock_in_id number, p_vendor_doc nvarchar2) return doc_header%rowtype
is
  v_res doc_header%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_in_id is null, 'p_stock_in_id');
  util_pkg.XCheck_Cond_Missing(p_vendor_doc is null, 'p_vendor_doc');
  ------------------------------
  select /*+ index(z IDX_DOCHEADER_SI_DD_DMI)*/
    *
    into v_res
    from doc_header z
    where 1 = 1
    and stock_in_id = p_stock_in_id
    and vendor_doc = p_vendor_doc
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when NO_DATA_FOUND then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_doc_header_by_id(p_id number) return doc_header%rowtype
is
  v_res doc_header%rowtype;
begin
  ------------------------------
  v_res := get_doc_header_by_id(p_id);
  ------------------------------
  XCheck_Document_NotFound(v_res.id is null, util_pkg.number_to_char(p_id));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_doc_header_by_doc_no(p_doc_no nvarchar2) return doc_header%rowtype
is
  v_res doc_header%rowtype;
begin
  ------------------------------
  v_res := get_doc_header_by_doc_no(p_doc_no);
  ------------------------------
  XCheck_Document_NotFound(v_res.id is null, util_pkg.nchar_to_char(p_doc_no));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_doc_header_by_doc_no2(p_doc_no nvarchar2, p_doc_status_id number) return doc_header%rowtype
is
  v_res doc_header%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_no is null, 'p_doc_no');
  util_pkg.XCheck_Cond_Missing(p_doc_status_id is null, 'p_doc_status_id');
  ------------------------------
  v_res := xget_doc_header_by_doc_no(p_doc_no);
  ------------------------------
  XCheck_Document_NotFound(v_res.status_id != p_doc_status_id, util_pkg.nchar_to_char(p_doc_no));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_doc_header_by_vendor_doc(p_stock_in_id number, p_vendor_doc nvarchar2) return doc_header%rowtype
is
  v_res doc_header%rowtype;
begin
  ------------------------------
  v_res := get_doc_header_by_vendor_doc(p_stock_in_id, p_vendor_doc);
  ------------------------------
  XCheck_Document_NotFound(v_res.id is null, util_pkg.number_to_char(p_stock_in_id) || util_pkg.c_msg_delim02 || util_pkg.nchar_to_char(p_vendor_doc));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function Get_Stock_Doc_Valid_Days(p_stock_id number, p_date date) return date
is
  v_valid_date date;
  v_days_num number;
  v_max_valid_until date;
begin
  ------------------------------
  v_max_valid_until := GS_max_valid_until;
  ------------------------------
  v_days_num := nvl(util_stock.get_stock_by_id(p_stock_id, p_date).doc_valid_days, c_def_stock_doc_valid_days);
  ------------------------------
  if v_days_num = c_def_stock_doc_valid_days
  then
    v_valid_date := v_max_valid_until;
  else
    v_valid_date := p_date + v_days_num;
  end if;
  ------------------------------
  return v_valid_date;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Get_Operation_Equipment(p_doc_header_id number, p_cur out sys_refcursor)
is
begin
  ------------------------------
  open p_cur for
  select /*+ ordered use_hash(em) index(dd IDX_DOCDETAIL_DHI_EMI_DMI_DMO) full(em)*/
         em.equipment_model_code "EquipmentCode",
         dd.seria_start AS "StartSeriesNumber",
         dd.seria_end AS "EndSeriesNumber",
         dd.quantity "Quantity"
    from doc_detail dd
    join equipment_model em on em.equipment_model_id = dd.equipment_model_id
   where dd.doc_header_id = p_doc_header_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Get_Total_Equipment(p_doc_header_id number, p_total_equipment out number)
is
begin
  ------------------------------
  select /*+ index(z IDX_DOCDETAIL_DHI_EMI_DMI_DMO)*/
    sum(quantity) into p_total_equipment
    from doc_detail z
    where doc_header_id = p_doc_header_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_new_docnum(p_stock_id nvarchar2, p_doc_type_id number) return nvarchar2
is
  v_year number;
  v_number number;
  v_rec_doc_type doc_type%rowtype;
  v_code stock.code%type;
  v_docnum nvarchar2(35);
  v_error_code number;
begin
  ------------------------------
  v_rec_doc_type := util_stock.get_doc_type_by_id(p_doc_type_id);
  ------------------------------
  if v_rec_doc_type.id is null or v_rec_doc_type.prefix is null
  then
    util_pkg.Raise_exception(util_loc_pkg.c_ora_doc_type_not_found, util_loc_pkg.c_msg_doc_type_not_found || util_pkg.c_msg_delim01 || to_char(p_doc_type_id));
  end if;
  ------------------------------
  v_code := util_stock.get_stock_code2(p_stock_id, sysdate);
  ------------------------------
  if v_code is null
  then
    util_pkg.Raise_exception(util_loc_pkg.c_ora_stock_not_exists, util_loc_pkg.c_msg_stock_not_exists || util_pkg.c_msg_delim01 || to_char(p_stock_id));
  end if;
  ------------------------------
  --Get current/active year
  document_management.doc_number_year__get(v_year, v_error_code);
  ------------------------------
  --Получим следующий за максимальным номером документа(аналог триггера)
  v_number := PKG_DOC.sq_next_docnum(p_stock_id, p_doc_type_id, v_year);
  ------------------------------
  v_docnum := substr(v_rec_doc_type.prefix || '-' || v_code || ' ' || to_char(v_number) || '/' || to_char(v_year), 1, 35);
  ------------------------------
  return v_docnum;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure setup_doc_header(p_rec in out nocopy doc_header%rowtype, p_force boolean)
is
  v_sysdate date := sysdate;
begin
  ------------------------------
  if p_force or p_rec.id is null
  then
    p_rec.id := S_DOC_HEADER.NEXTVAL;
  end if;
  ------------------------------
  if p_force or p_rec.user_id is null
  then
    p_rec.user_id := null;
  end if;
  ------------------------------
  if p_force or p_rec.create_date is null
  then
    p_rec.create_date := v_sysdate;
  end if;
  ------------------------------
  if p_force or p_rec.doc_date is null
  then
    p_rec.doc_date := v_sysdate;
  end if;
  ------------------------------
  if p_force or p_rec.doc_type_id is null
  then
    p_rec.doc_type_id := null;
  end if;
  ------------------------------
  if p_force or p_rec.doc_no is null
  then
    p_rec.doc_no := null;
  end if;
  ------------------------------
  if p_force or p_rec.status_id is null
  then
    p_rec.status_id := null;
  end if;
  ------------------------------
  if p_force or p_rec.stock_out_id is null
  then
    p_rec.stock_out_id := util_stock.c_dummy_stock_id;
  end if;
  ------------------------------
  if p_force or p_rec.stock_in_id is null
  then
    p_rec.stock_in_id := util_stock.c_dummy_stock_id;
  end if;
  ------------------------------
  if p_force or p_rec.vendor_doc is null
  then
    p_rec.vendor_doc := null;
  end if;
  ------------------------------
  if p_force or p_rec.valid_until is null
  then
    p_rec.valid_until := null;
  end if;
  ------------------------------
  if p_force or p_rec.description is null
  then
    p_rec.description := null;
  end if;
  ------------------------------
  if p_force or p_rec.user_comment is null
  then
    p_rec.user_comment := null;
  end if;
  ------------------------------
  if p_force or p_rec.last_user is null
  then
    p_rec.last_user := null;
  end if;
  ------------------------------
  if p_force or p_rec.date_of_move_in is null
  then
    p_rec.date_of_move_in := null;
  end if;
  ------------------------------
  if p_force or p_rec.date_of_move_out is null
  then
    p_rec.date_of_move_out := null;
  end if;
  ------------------------------
  if p_force or p_rec.vendor_id is null
  then
    p_rec.vendor_id := null;
  end if;
  ------------------------------
  if p_force or p_rec.user_id2 is null
  then
    p_rec.user_id2 := null;
  end if;
  ------------------------------
  if p_force or p_rec.last_user_id2 is null
  then
    p_rec.last_user_id2 := null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_smart_doc_header
(
    p_rec in out nocopy doc_header%rowtype,
    p_doc_type_id doc_header.doc_type_id%type,
    p_doc_date doc_header.doc_date%type,
    p_status_id doc_header.status_id%type,
    p_stock_out_id doc_header.stock_out_id%type,
    p_stock_in_id doc_header.stock_in_id%type,
    p_user_id doc_header.user_id2%type,
    p_last_user_id doc_header.last_user_id2%type,
    p_vendor_doc doc_header.vendor_doc%type,
    p_description doc_header.description%type,
    p_user_comment doc_header.user_comment%type,
    p_vendor_id doc_header.vendor_id%type
)
is
  v_stock_id number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  util_pkg.XCheck_Cond_Missing(p_doc_date is null, 'p_doc_date');
  util_pkg.XCheck_Cond_Missing(p_status_id is null, 'p_status_id');
  util_pkg.XCheck_Cond_Missing(p_stock_out_id is null, 'p_stock_out_id');
  util_pkg.XCheck_Cond_Missing(p_stock_in_id is null, 'p_stock_in_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_last_user_id is null, 'p_last_user_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_vendor_doc is null, 'p_vendor_doc');
  --!_!util_pkg.XCheck_Cond_Missing(p_description is null, 'p_description');
  --!_!util_pkg.XCheck_Cond_Missing(p_user_comment is null, 'p_user_comment');
  --!_!util_pkg.XCheck_Cond_Missing(p_vendor_id is null, 'p_vendor_id');
  ------------------------------
  setup_doc_header(p_rec, true);
  ------------------------------
  p_rec.user_id2 := p_user_id;
  p_rec.last_user_id2 := p_last_user_id;
  ------------------------------
  --id
  p_rec.user_id := util_stock.make_obsolete_user_name(util_stock.xget_user_name(p_rec.user_id2));
  --create_date
  p_rec.doc_date := p_doc_date;
  p_rec.doc_type_id := p_doc_type_id;
  --!_!p_rec.doc_no
  p_rec.status_id := p_status_id;
  p_rec.stock_out_id := nvl(p_stock_out_id, util_stock.c_dummy_stock_id);
  p_rec.stock_in_id := nvl(p_stock_in_id, util_stock.c_dummy_stock_id);
  p_rec.vendor_doc := p_vendor_doc;
  --!_!valid_until
  p_rec.description := p_description;
  p_rec.user_comment := p_user_comment;
  p_rec.last_user := util_stock.make_obsolete_user_name(util_stock.xget_user_name(p_rec.last_user_id2));
  --date_of_move_in
  --date_of_move_out
  p_rec.vendor_id := p_vendor_id;
  --!_!user_id2
  --!_!last_user_id2
  ------------------------------
  if p_rec.stock_out_id != util_stock.c_dummy_stock_id
  then
    v_stock_id := p_rec.stock_out_id;
  else
    v_stock_id := p_rec.stock_in_id;
  end if;
  ------------------------------
  p_rec.doc_no := get_new_docnum(v_stock_id, p_rec.doc_type_id);
  p_rec.valid_until := Get_Stock_Doc_Valid_Days(v_stock_id, p_rec.doc_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_desc_for_doc_header(p_rec in out nocopy doc_header%rowtype)
is
  v_date date := sysdate;
  v_stock_out stock.code%type;
  v_stock_in stock.code%type;
begin
  ------------------------------
  v_stock_out := nvl(util_stock.get_stock_code2(p_rec.stock_out_id, v_date), util_stock.c_dummy_stock_code);
  v_stock_in := nvl(util_stock.get_stock_code2(p_rec.stock_in_id, v_date), util_stock.c_dummy_stock_code);
  ------------------------------
  p_rec.description := util_stock.shrink_nchar(util_stock.xget_user_name(p_rec.user_id2) || ', ' || util_pkg.date_to_char(p_rec.doc_date) || ', ' || v_stock_out || '->' || v_stock_in || p_rec.description,
    c_doc_header_description_size
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_for_crm_doc_header(p_rec in out nocopy doc_header%rowtype)
is
begin
  ------------------------------
  setup_desc_for_doc_header(p_rec);
  ------------------------------
  if p_rec.vendor_doc is null
  then
    p_rec.vendor_doc := c_crm || util_stock.xget_user_name(p_rec.user_id2) || ', ' || util_pkg.date_to_char(p_rec.doc_date);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_for_gui_doc_header(p_rec in out nocopy doc_header%rowtype)
is
begin
  ------------------------------
  setup_desc_for_doc_header(p_rec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure i_Insert_Doc_Header(p_doc_header doc_header%rowtype)
is
  v_slot_use_trg number;
  v_flag_use_trg boolean := false;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header.stock_out_id is null, 'p_doc_header.stock_out_id');
  util_pkg.XCheck_Cond_Missing(p_doc_header.stock_in_id is null, 'p_doc_header.stock_in_id');
  ------------------------------
  util_loc_pkg.Save_Flag_number(v_use_doc_header_trigger, v_slot_use_trg, v_flag_use_trg);
  v_use_doc_header_trigger := util_pkg.c_false;
  ------------------------------
  insert into DOC_HEADER values p_doc_header;
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_header_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
exception
when others then
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_header_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_Doc_Header(p_doc_header doc_header%rowtype)
is
  v_slot_use_trg number;
  v_flag_use_trg boolean := false;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header.stock_out_id is null, 'p_doc_header.stock_out_id');
  util_pkg.XCheck_Cond_Missing(p_doc_header.stock_in_id is null, 'p_doc_header.stock_in_id');
  ------------------------------
  util_loc_pkg.Save_Flag_number(v_use_doc_header_trigger, v_slot_use_trg, v_flag_use_trg);
  v_use_doc_header_trigger := util_pkg.c_false;
  ------------------------------
  update /*+ index(z PK_DOC_HEADER)*/
    DOC_HEADER z
    set row = p_doc_header
    where id = p_doc_header.id
  ;
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_header_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
exception
when others then
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_header_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure i_Update_Doc_Header_State
(
    p_doc_header_id number,
    p_status_id number,
    p_last_user_id number,
    p_doc_date date
)
is
  v_slot_use_trg number;
  v_flag_use_trg boolean := false;
  v_user_name users.user_name%type;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header_id is null, 'p_doc_header_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_status_id is null, 'p_status_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_last_user_id is null, 'p_last_user_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_doc_date is null, 'p_doc_date');
  ------------------------------
  util_loc_pkg.Save_Flag_number(v_use_doc_header_trigger, v_slot_use_trg, v_flag_use_trg);
  v_use_doc_header_trigger := util_pkg.c_false;
  ------------------------------
  v_user_name := util_stock.make_obsolete_user_name(util_stock.get_user_name(p_last_user_id));
  ------------------------------
  update /*+ index(z PK_DOC_HEADER)*/
    DOC_HEADER z
  set
    doc_date = nvl(p_doc_date, doc_date),
    status_id = nvl(p_status_id, status_id),
    last_user = nvl(v_user_name, last_user),
    last_user_id2 = nvl(p_last_user_id, last_user_id2)
  where id = p_doc_header_id
  ;
  ------------------------------
  if sql%rowcount = 0
  then
    ------------------------------
    raise NO_DATA_FOUND;
    ------------------------------
  end if;
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_header_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
exception
when others then
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_header_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure i_Clear_tt_Doc_Detail_table
is
begin
  ------------------------------
  delete from tt_doc_detail_serial;
  delete from tt_doc_detail_non_serial;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Prepare_Doc_Detail_SRC(p_doc_header doc_header%rowtype)
is
  v_is_minus number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header.id is null, 'p_doc_header.id');
  --!_!util_pkg.XCheck_Cond_Missing(p_doc_header.date_of_move_in is null, 'p_doc_header.date_of_move_in');
  --!_!util_pkg.XCheck_Cond_Missing(p_doc_header.date_of_move_out is null, 'p_doc_header.date_of_move_out');
  ------------------------------
  if util_stock.get_doc_dir_type(p_doc_header.doc_type_id) = util_stock.c_Doc_Dir_Type_In
  then
    return;
  end if;
  ------------------------------
  if util_stock.is_doc_eq_kept_inside_ss(p_doc_header.doc_type_id)
  then
    return;
  end if;
  ------------------------------
  v_is_minus := util_pkg.bool_to_int_2val(util_stock.is_doc_minus_src_detail(p_doc_header.doc_type_id));
  ------------------------------
  insert into tt_doc_detail_serial
  (
    id,
    doc_header_id,
    equipment_model_id,
    seria_start,
    seria_end,
    quantity,
    unit,
    status_id,
    product,
    valid_until,
    equipment_batch_id,
    date_of_move_in,
    date_of_move_out
  )
  select
    c_def_dd_id id,
    p_doc_header.id doc_header_id,
    equipment_model_id,
    seria_start,
    seria_end,
    decode(v_is_minus, util_pkg.c_false, inp_quantity, -inp_quantity) quantity,
    c_def_dd_unit unit,
    status status_id,
    c_def_dd_product product,
    create_date valid_until,
    equipment_batch_id,
    p_doc_header.date_of_move_in date_of_move_in,
    p_doc_header.date_of_move_out date_of_move_out
    from TT_XYZ_SSEXT_SER_SRC z
  ;
  ------------------------------
  insert into tt_doc_detail_non_serial
  (
    id,
    doc_header_id,
    equipment_model_id,
    seria_start,
    seria_end,
    quantity,
    unit,
    status_id,
    product,
    valid_until,
    equipment_batch_id,
    date_of_move_in,
    date_of_move_out
  )
  select
    c_def_dd_id id,
    p_doc_header.id doc_header_id,
    equipment_model_id,
    seria_start,
    seria_end,
    decode(v_is_minus, util_pkg.c_false, inp_quantity, -inp_quantity) quantity,
    c_def_dd_unit unit,
    status status_id,
    c_def_dd_product product,
    create_date valid_until,
    equipment_batch_id,
    p_doc_header.date_of_move_in date_of_move_in,
    p_doc_header.date_of_move_out date_of_move_out
    from TT_XYZ_SSEXT_NSER_SRC z
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Prepare_Doc_Detail_DST(p_doc_header doc_header%rowtype)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header.id is null, 'p_doc_header.id');
  --!_!util_pkg.XCheck_Cond_Missing(p_doc_header.date_of_move_in is null, 'p_doc_header.date_of_move_in');
  --!_!util_pkg.XCheck_Cond_Missing(p_doc_header.date_of_move_out is null, 'p_doc_header.date_of_move_out');
  ------------------------------
  if util_stock.get_doc_dir_type(p_doc_header.doc_type_id) = util_stock.c_Doc_Dir_Type_Out
  then
    return;
  end if;
  ------------------------------
  insert into tt_doc_detail_serial
  (
    id,
    doc_header_id,
    equipment_model_id,
    seria_start,
    seria_end,
    quantity,
    unit,
    status_id,
    product,
    valid_until,
    equipment_batch_id,
    date_of_move_in,
    date_of_move_out
  )
  select
    c_def_dd_id id,
    p_doc_header.id doc_header_id,
    equipment_model_id,
    seria_start,
    seria_end,
    inp_quantity quantity,
    c_def_dd_unit unit,
    status status_id,
    c_def_dd_product product,
    create_date valid_until,
    equipment_batch_id,
    p_doc_header.date_of_move_in date_of_move_in,
    p_doc_header.date_of_move_out date_of_move_out
    from TT_XYZ_SSEXT_SER_DST z
  ;
  ------------------------------
  insert into tt_doc_detail_non_serial
  (
    id,
    doc_header_id,
    equipment_model_id,
    seria_start,
    seria_end,
    quantity,
    unit,
    status_id,
    product,
    valid_until,
    equipment_batch_id,
    date_of_move_in,
    date_of_move_out
  )
  select
    c_def_dd_id id,
    p_doc_header.id doc_header_id,
    equipment_model_id,
    seria_start,
    seria_end,
    inp_quantity quantity,
    c_def_dd_unit unit,
    status status_id,
    c_def_dd_product product,
    create_date valid_until,
    equipment_batch_id,
    p_doc_header.date_of_move_in date_of_move_in,
    p_doc_header.date_of_move_out date_of_move_out
    from TT_XYZ_SSEXT_NSER_DST z
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Prepare_Doc_Details(p_doc_header doc_header%rowtype)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header.id is null, 'p_doc_header.id');
  --!_!util_pkg.XCheck_Cond_Missing(p_doc_header.date_of_move_in is null, 'p_doc_header.date_of_move_in');
  --!_!util_pkg.XCheck_Cond_Missing(p_doc_header.date_of_move_out is null, 'p_doc_header.date_of_move_out');
  ------------------------------
  i_Clear_tt_Doc_Detail_table;
  ------------------------------
  i_Prepare_Doc_Detail_SRC(p_doc_header);
  ------------------------------
  i_Prepare_Doc_Detail_DST(p_doc_header);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure i_Insert_Serial_Equipment
is
  v_slot_use_trg number;
  v_flag_use_trg boolean := false;
begin
  ------------------------------
  util_loc_pkg.Save_Flag_number(v_use_doc_detail_trigger, v_slot_use_trg, v_flag_use_trg);
  v_use_doc_detail_trigger := util_pkg.c_false;
  ------------------------------
  insert into DOC_DETAIL
  (
    id,
    doc_header_id,
    equipment_model_id,
    seria_start,
    seria_end,
    quantity,
    unit,
    status_id,
    product,
    valid_until,
    equipment_batch_id,
    date_of_move_in,
    date_of_move_out
  )
  select /*+ full(z)*/
    s_doc_detail.nextval id,
    doc_header_id,
    equipment_model_id,
    seria_start,
    seria_end,
    quantity,
    unit,
    status_id,
    product,
    valid_until,
    equipment_batch_id,
    date_of_move_in,
    date_of_move_out
    from tt_doc_detail_serial z
  ;
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_detail_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
exception
when others then
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_detail_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Insert_Non_Serial_Equipment
is
  v_slot_use_trg number;
  v_flag_use_trg boolean := false;
begin
  ------------------------------
  update /*+ full(t)*/
    tt_doc_detail_non_serial t
  set
    id = (
      select /*+ index(dd IDX_DOCDETAIL_DHI_EMI_DMI_DMO)*/
        id
        from doc_detail dd
        where 1 = 1
        and doc_header_id = t.doc_header_id
        and equipment_model_id = t.equipment_model_id
    )
  ;
  ------------------------------
  util_loc_pkg.Save_Flag_number(v_use_doc_detail_trigger, v_slot_use_trg, v_flag_use_trg);
  v_use_doc_detail_trigger := util_pkg.c_false;
  ------------------------------
  insert into DOC_DETAIL
  (
    id,
    doc_header_id,
    equipment_model_id,
    seria_start,
    seria_end,
    quantity,
    unit,
    status_id,
    product,
    valid_until,
    equipment_batch_id,
    date_of_move_in,
    date_of_move_out
  )
  select /*+ full(z)*/
    s_doc_detail.nextval id,
    doc_header_id,
    equipment_model_id,
    seria_start,
    seria_end,
    quantity,
    unit,
    status_id,
    product,
    valid_until,
    equipment_batch_id,
    date_of_move_in,
    date_of_move_out
    from tt_doc_detail_non_serial z
    where 1 = 1
    and id is null
  ;
  ------------------------------
  update /*+ index(dd PK_DOC_DETAIL)*/
    DOC_DETAIL dd
  set
    quantity = quantity + (
      select /*+ full(t)*/
        sum(quantity) quantity
        from tt_doc_detail_non_serial t
        where 1 = 1
        and id = dd.id
    )
  where 1 = 1
  and id in (
    select /*+ full(t)*/
      id
      from tt_doc_detail_non_serial t
    where 1 = 1
    and id is not null
  )
  ;
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_detail_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
exception
when others then
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_detail_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Remove_Serial_Equipment
is
  v_slot_use_trg number;
  v_flag_use_trg boolean := false;
begin
  ------------------------------
  update /*+ full(t)*/
    tt_doc_detail_serial t
  set
    id = (
      select /*+ index(dd DOC_DETAIL_SS_SE)*/
        id
        from doc_detail dd
        where 1 = 1
        and doc_header_id = t.doc_header_id
        and equipment_model_id = t.equipment_model_id
        and seria_start = t.seria_start
        and seria_end = t.seria_end
    )
  ;
  ------------------------------
  util_loc_pkg.Save_Flag_number(v_use_doc_detail_trigger, v_slot_use_trg, v_flag_use_trg);
  v_use_doc_detail_trigger := util_pkg.c_false;
  ------------------------------
  delete /*+ ordered use_nl(dd) index(dd PK_DOC_DETAIL)*/
    from DOC_DETAIL dd
  where 1 = 1
  and id in (
    select /*+ full(t)*/
      id
      from tt_doc_detail_serial t
      where 1 = 1
      and id is not null
  )
  ;
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_detail_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
exception
when others then
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_detail_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Remove_Non_Serial_Equipment
is
  v_slot_use_trg number;
  v_flag_use_trg boolean := false;
begin
  ------------------------------
  update /*+ ordered full(t)*/
    tt_doc_detail_non_serial t
  set
    (id, quantity) = (
      select /*+ index(dd IDX_DOCDETAIL_DHI_EMI_DMI_DMO)*/
        id,
        quantity - t.quantity quantity
        from doc_detail dd
        where 1 = 1
        and doc_header_id = t.doc_header_id
        and equipment_model_id = t.equipment_model_id
        and seria_start = t.seria_start
        and seria_end = t.seria_end
    )
  ;
  ------------------------------
  util_loc_pkg.Save_Flag_number(v_use_doc_detail_trigger, v_slot_use_trg, v_flag_use_trg);
  v_use_doc_detail_trigger := util_pkg.c_false;
  ------------------------------
  delete /*+ ordered use_nl(dd) index(dd PK_DOC_DETAIL)*/
    from DOC_DETAIL dd
  where 1 = 1
  and id in (
    select /*+ full(t)*/
      id
      from tt_doc_detail_non_serial t
      where 1 = 1
      and id is not null
      and quantity <= 0
  )
  ;
  ------------------------------
  update /*+ index(dd PK_DOC_DETAIL)*/
    DOC_DETAIL dd
  set
    quantity = (
      select /*+ full(t)*/
        quantity
        from tt_doc_detail_non_serial t
        where 1 = 1
        and id = dd.id
        and quantity > 0
    )
  where 1 = 1
  and id in (
    select /*+ full(t)*/
      id
      from tt_doc_detail_non_serial t
      where 1 = 1
      and id is not null
      and quantity > 0
  )
  ;
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_detail_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
exception
when others then
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_doc_detail_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure i_Insert_Doc_Details(p_doc_header doc_header%rowtype)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header.id is null, 'p_doc_header.id');
  --!_!util_pkg.XCheck_Cond_Missing(p_doc_header.date_of_move_in is null, 'p_doc_header.date_of_move_in');
  --!_!util_pkg.XCheck_Cond_Missing(p_doc_header.date_of_move_out is null, 'p_doc_header.date_of_move_out');
  ------------------------------
  i_Prepare_Doc_Details(p_doc_header);
  ------------------------------
  i_Insert_Serial_Equipment;
  ------------------------------
  i_Insert_Non_Serial_Equipment;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Remove_Doc_Details(p_doc_header doc_header%rowtype)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header.id is null, 'p_doc_header.id');
  --!_!util_pkg.XCheck_Cond_Missing(p_doc_header.date_of_move_in is null, 'p_doc_header.date_of_move_in');
  --!_!util_pkg.XCheck_Cond_Missing(p_doc_header.date_of_move_out is null, 'p_doc_header.date_of_move_out');
  ------------------------------
  i_Prepare_Doc_Details(p_doc_header);
  ------------------------------
  i_Remove_Serial_Equipment;
  ------------------------------
  i_Remove_Non_Serial_Equipment;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Retrieve_Doc_Equipment(p_doc_header_id number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header_id is null, 'p_doc_header_id');
  ------------------------------
  i_Clear_tt_Doc_Detail_table;
  ------------------------------
  insert all

  when has_serial_number = util_stock.c_YES
  then into
    tt_doc_detail_serial
    (
      id,
      doc_header_id,
      equipment_model_id,
      seria_start,
      seria_end,
      quantity,
      unit,
      status_id,
      product,
      valid_until,
      equipment_batch_id,
      date_of_move_in,
      date_of_move_out
    )
    values
    (
      id,
      doc_header_id,
      equipment_model_id,
      seria_start,
      seria_end,
      quantity,
      unit,
      status_id,
      product,
      valid_until,
      equipment_batch_id,
      date_of_move_in,
      date_of_move_out
    )

  else
  into
    tt_doc_detail_non_serial
    (
      id,
      doc_header_id,
      equipment_model_id,
      seria_start,
      seria_end,
      quantity,
      unit,
      status_id,
      product,
      valid_until,
      equipment_batch_id,
      date_of_move_in,
      date_of_move_out
    )
    values
    (
      id,
      doc_header_id,
      equipment_model_id,
      seria_start,
      seria_end,
      quantity,
      unit,
      status_id,
      product,
      valid_until,
      equipment_batch_id,
      date_of_move_in,
      date_of_move_out
    )

  select /*+ ordered use_hash(em et es) index(dd IDX_DOCDETAIL_DHI_EMI_DMI_DMO) full(em) full(et) full(es)*/
    dd.*,
    es.has_serial_number
    from
      doc_detail dd,
      equipment_model em,
      equipment_type et,
      equipment_system_type es
    where 1 = 1
    and dd.doc_header_id = p_doc_header_id
    and em.equipment_model_id(+) = dd.equipment_model_id
    and et.equipment_type_id(+) = em.equipment_type_id
    and es.equipment_system_type_code(+) = et.system_type_code
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Create_Doc_From_SSEXT
(
    p_rec doc_header%rowtype
)
is
begin
  ------------------------------
  i_Insert_Doc_Header(p_rec);
  ------------------------------
  i_Insert_Doc_Details(p_rec);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_Doc_From_SSEXT
(
    p_doc_header_id number,
    p_last_user_id number,
    p_remove_eq boolean
)
is
  v_doc_header doc_header%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header_id is null, 'p_doc_header_id');
  util_pkg.XCheck_Cond_Missing(p_last_user_id is null, 'p_last_user_id');
  util_pkg.XCheck_Cond_Missing(p_remove_eq is null, 'p_remove_eq');
  ------------------------------
  i_Update_Doc_Header_State
  (
    p_doc_header_id => p_doc_header_id,
    p_status_id => NULL,
    p_last_user_id => p_last_user_id,
    p_doc_date => NULL
  );
  ------------------------------
  v_doc_header := xget_doc_header_by_id(p_doc_header_id);
  ------------------------------
  if p_remove_eq
  then
    ------------------------------
    i_Remove_Doc_Details(v_doc_header);
    ------------------------------
  else
    ------------------------------
    i_Insert_Doc_Details(v_doc_header);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_Doc_State
(
    p_doc_header_id number,
    p_status_id number,
    p_last_user_id number,
    p_doc_date date
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header_id is null, 'p_doc_header_id');
  util_pkg.XCheck_Cond_Missing(p_status_id is null, 'p_status_id');
  util_pkg.XCheck_Cond_Missing(p_last_user_id is null, 'p_last_user_id');
  util_pkg.XCheck_Cond_Missing(p_doc_date is null, 'p_doc_date');
  ------------------------------
  i_Update_Doc_Header_State
  (
    p_doc_header_id => p_doc_header_id,
    p_status_id => p_status_id,
    p_last_user_id => p_last_user_id,
    p_doc_date => p_doc_date
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
