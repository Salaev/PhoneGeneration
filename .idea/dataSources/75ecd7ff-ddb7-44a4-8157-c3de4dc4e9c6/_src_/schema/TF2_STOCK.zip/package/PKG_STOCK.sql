CREATE PACKAGE pkg_stock
AS
--******************************************************************************
-- Author  : Skripnik Petr
-- Created : 07.12.2006 10:35
-- Modification : stock_management
-- Purpose : Work with the stocks
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ----------------------------------------------
-- Skripnik Petr   23.01.2007  + t_num
-- Skripnik Petr   16.04.2007  version 1.11.8.2
--****************************************************************************--
   g_tab_id       ct_number := ct_number ();   --идентификаторы складов
   g_tab_id_out   ct_number := ct_number ();   --идентификаторы складов отправителей
   g_tab_id_in    ct_number := ct_number ();   --идентификаторы складов получателей

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 05.04.2007 10:43
-- Editor  :
-- Changed :
-- Purpose : Проверяет наличие оборудования определенной модели в текущем состоянии склада
-- Problems:
--   OracleProvider не поддерживает тип BOOLEAN
--------------------------------------------------------------------------------
   PROCEDURE chk_modelid_in_stockstate (p_equipment_model_id IN NUMBER, p_result OUT NUMBER);

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 07.05.2007 09:31
-- Version : 1
-- Modification : bulk_insert_management.bulk_insert_tmp_stock_id,bulk_insert_management.bulk_insert_tmp_stock_id2
-- Editor  :
-- Changed :
-- Purpose : Устанавливает идентификаторы складов
--------------------------------------------------------------------------------
   PROCEDURE set_stockid (
      p_stock_id         IN   pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_flag_clear       IN   CHAR DEFAULT 'Y',
      p_stock_id_out     IN   pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_flag_clear_out   IN   CHAR DEFAULT 'Y',
      p_stock_id_in      IN   pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_flag_clear_in    IN   CHAR DEFAULT 'Y'
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 09.02.2007 10:34
-- Editor  :
-- Changed :
-- Purpose : Получаем детальное состояние складов по наборам оборудования
--           серийных номеров(для малой размерности)
--------------------------------------------------------------------------------
   PROCEDURE state_detalied (
      p_stock_id       IN       pkg_common.t_num,
      p_eqm_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_seria_start    IN       pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar,
      p_seria_end      IN       pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar,
      p_cur            OUT      sys_refcursor,
      p_error_code     OUT      NUMBER
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.01.2007 13:28
-- Version : 1
-- Modification : catalogue_management.inventory__get
-- Editor  :
-- Changed :
-- Purpose : Получаем состояние склада сгруппированного по оборудованию
--------------------------------------------------------------------------------
   PROCEDURE state_group_by_eqm (
      p_stock_id          IN       pkg_common.t_num,
      p_groupby_eqm_cur   OUT      sys_refcursor,
      p_error_code        OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.01.2007 13:36
-- Editor  :
-- Changed :
-- Purpose : Получаем состояние склада сгруппированного по непрерывным сериям оборудования
--------------------------------------------------------------------------------
   PROCEDURE state_group_by_series (
      p_stock_id             IN       pkg_common.t_num,
      p_eqm_model_id         IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_seria_start          IN       NVARCHAR2 DEFAULT NULL,
      p_seria_end            IN       NVARCHAR2 DEFAULT NULL,
      p_groupby_series_cur   OUT      sys_refcursor,
      p_error_code           OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 31.01.2007 14:46
-- Editor  :
-- Changed :
-- Purpose : Получаем детальное состояние складов на дату по наборам оборудования,серийных номеров
--------------------------------------------------------------------------------
   PROCEDURE state_on_date_detalied (
      p_date           IN       DATE,
      p_stock_id       IN       pkg_common.t_num,
      p_eqm_model_id   IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_seria_start    IN       pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar,
      p_seria_end      IN       pkg_common.t_varchar DEFAULT pkg_common.empty_t_varchar,
      p_cur            OUT      sys_refcursor,
      p_error_code     OUT      NUMBER
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.01.2007 13:28
-- Version : 1
-- Modification : catalogue_management.inventory__get
-- Editor  :
-- Changed :
-- Purpose : Получаем состояние склада сгруппированного по оборудованию
--------------------------------------------------------------------------------
   PROCEDURE state_on_date_group_by_eqm (
      p_date              IN       DATE,
      p_stock_id          IN       pkg_common.t_num,
      p_groupby_eqm_cur   OUT      sys_refcursor,
      p_error_code        OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.01.2007 13:36
-- Editor  :
-- Changed :
-- Purpose : Получаем состояние склада сгруппированного по непрерывным сериям оборудования
--------------------------------------------------------------------------------
   PROCEDURE state_on_date_group_by_series (
      p_date                 IN       DATE,
      p_stock_id             IN       pkg_common.t_num,
      p_eqm_model_id         IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_seria_start          IN       NVARCHAR2 DEFAULT NULL,
      p_seria_end            IN       NVARCHAR2 DEFAULT NULL,
      p_groupby_series_cur   OUT      sys_refcursor,
      p_error_code           OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 14.09.2007 12:54
-- Version :
--   1 14.09.2007
-- Modification :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE state_prepare (
      p_date                      IN   DATE,
      p_is_update_validity_date   IN   BOOLEAN,   --флаг обработки документов об изменении срока годности оборудования
      p_is_process_opened_doc     IN   BOOLEAN,   --флаг обработки открытых документов
      p_is_detailed               IN   BOOLEAN DEFAULT TRUE
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.05.2007 13:45
-- Version : 4
-- Modification : stock_management.stock_state_to_date_prepare ->
--                -> pkg_stock.state_prepare
-- Editor  : Skripnik Petr (SP)
-- Changed :
-- Purpose : Получаем все движения оборудования на период времени.Состояние
--           строется от первого документа до даты указанной в параметре
--------------------------------------------------------------------------------
   PROCEDURE state_prepare_direct (
      p_date                      IN   DATE,
      p_is_update_validity_date   IN   BOOLEAN,
      p_is_process_opened_doc     IN   BOOLEAN,
      p_is_detailed               IN   BOOLEAN DEFAULT TRUE
   );

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 03.04.2007 10:12
-- Version :
--   1 03.04.2007 10:12
-- Modification : pkg_stock.state_prepare
-- Editor  : Skripnik Petr (SP)
-- Changed :
-- Purpose : Получаем все движения оборудования на период времени.Состояние
--           строется от состояния на текущую дату по движению документов в обратном порядке
--------------------------------------------------------------------------------
   PROCEDURE state_prepare_reverse (
      p_date                      IN   DATE,
      p_is_update_validity_date   IN   BOOLEAN,
      p_is_process_opened_doc     IN   BOOLEAN,
      p_is_detailed               IN   BOOLEAN DEFAULT TRUE
   );
END;
/
