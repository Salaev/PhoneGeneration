CREATE package body persistent_interface is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure prepare_user_stock_perms(p_user_name users.user_name%type, p_perm_view boolean, p_perm_change boolean, p_stock_group_id number, p_cursor OUT sys_refcursor)
is
  v_user_id number;
  v_user_name users.user_name%type;
  v_perm_view boolean := util_pkg.bool_to_bool_2val(p_perm_view);
  v_perm_change boolean := util_pkg.bool_to_bool_2val(p_perm_change);
  v_date date := sysdate;
  v_stock_ids ct_node;
  v_perm_mask number := util_stock.c_perm_none;
begin
  ------------------------------
  v_user_id := util_stock.xget_user_id(p_user_name);
  v_user_name := util_stock.xget_user_name(v_user_id);
  ------------------------------
  if v_perm_view
  then
    v_perm_mask := v_perm_mask + util_stock.c_perm_view;
  end if;
  ------------------------------
  if v_perm_change
  then
    v_perm_mask := v_perm_mask + util_stock.c_perm_change;
  end if;
  ------------------------------
  v_stock_ids := util_stock.get_stock_perms_i(v_user_id, v_date, v_perm_mask, true);
  ------------------------------
  open p_cursor for
select /*+ ordered use_nl(q, z) index_asc(z, UK_STOCK_CODE)*/
  v_user_name user_name, z.stock_group_id sg_id, z.id s_id, z.code s_code, z.name s_name, q.val perm
  from (select id, val from table(v_stock_ids)) q, stock z
  where 1 = 1
  and z.id = q.id
  and nvl(z.deleted, v_date + util_stock.c_dummy_date_shift) > v_date
  and (p_stock_group_id is null or z.stock_group_id = p_stock_group_id)
  order by q.id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure prepare_user_stock_perms_wrp(p_user_name users.user_name%type, p_perm_view number, p_perm_change number, p_stock_group_id number, p_cursor OUT sys_refcursor)
is
  v_perm_view boolean := util_pkg.int_to_bool_2val(p_perm_view);
  v_perm_change boolean := util_pkg.int_to_bool_2val(p_perm_change);
begin
  ------------------------------
  prepare_user_stock_perms(p_user_name, v_perm_view, v_perm_change, p_stock_group_id, p_cursor);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
