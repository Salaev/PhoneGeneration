CREATE package body api_stock_i_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Get_Operation_Equipment
(
    p_document_number nvarchar2,
    p_only_active boolean,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_doc_header doc_header%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_document_number is null, 'p_document_number');
  util_pkg.XCheck_Cond_Missing(p_only_active is null, 'p_only_active');
  ------------------------------
  if p_only_active
  then
    ------------------------------
    v_doc_header := document_pkg.xget_doc_header_by_doc_no2(p_document_number, util_stock.c_docstat_open);
    ------------------------------
  else
    ------------------------------
    v_doc_header := document_pkg.xget_doc_header_by_doc_no(p_document_number);
    ------------------------------
  end if;
  ------------------------------
  document_pkg.Get_Operation_Equipment(v_doc_header.id, p_result);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Get_Total_Equipment
(
    p_document_number nvarchar2,
    p_total_equipment out number,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_doc_header doc_header%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_document_number is null, 'p_document_number');
  ------------------------------
  v_doc_header := document_pkg.xget_doc_header_by_doc_no(p_document_number);
  ------------------------------
  document_pkg.Get_Total_Equipment(v_doc_header.id, p_total_equipment);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Get_Doc_State_By_DocNo
(
    p_document_number nvarchar2,
    p_doc_state out number,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_doc_header doc_header%rowtype;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_document_number is null, 'p_document_number');
  ------------------------------
  v_doc_header := document_pkg.xget_doc_header_by_doc_no(p_document_number);
  ------------------------------
  p_doc_state := v_doc_header.status_id;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Move_Range_Of_Equipment
(
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_stock_id_out number,
    p_stock_id_in number,
    p_finish boolean,
    p_user_id number,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_doc_date date := sysdate;
  v_ss_parameters equipment_pkg.t_ss_parameters;
  v_doc_status_id number;
  v_main_count number;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_starts, 'p_seria_starts');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_ends, 'p_seria_ends');
  util_stock.XCheckP_ct_model(p_models, 'p_models');
  util_pkg.XCheck_Cond_Missing(p_stock_id_out is null, 'p_stock_id_out');
  util_pkg.XCheck_Cond_Missing(p_stock_id_in is null, 'p_stock_id_in');
  util_pkg.XCheck_Cond_Missing(p_finish is null, 'p_finish');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_seria_starts);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_starts) != v_main_count, 'p_seria_starts.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_ends) != v_main_count, 'p_seria_ends.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_stock.get_count_ct_model(p_models) != v_main_count, 'p_models.count != v_main_count');
  ------------------------------
  util_stock.xcheck_stock_id(p_stock_id_out);
  util_stock.xcheck_stock_id(p_stock_id_in);
  util_stock.xcheck_user_id(p_user_id);
  ------------------------------
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id_out, util_stock.c_perm_change_out);
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id_in, util_stock.c_perm_change_in);
  ------------------------------
  util_stock.XCheck_Doc_Perms(p_user_id, util_stock.c_Doc_Type_Movement, util_stock.c_action_Create);
  ------------------------------
  v_doc_status_id := util_stock.XFinish_To_Doc_Status(p_finish);
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_single_doc(v_ss_parameters);
  ------------------------------
  equipment_pkg.setup_for_new_doc
  (
    p_params => v_ss_parameters,
    p_doc_type_id => util_stock.c_Doc_Type_Movement,
    p_doc_date => v_doc_date,
    p_status_id => v_doc_status_id,
    p_stock_id_out => p_stock_id_out,
    p_stock_id_in => p_stock_id_in,
    p_user_id => p_user_id,
    p_last_user_id => p_user_id,
    p_vendor_doc => null,
    p_description => null,
    p_user_comment => null,
    p_vendor_id => null,
    p_doc_style => equipment_pkg.c_doc_style_crm
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters,
    p_break_on_error => true,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => false
  );
  ------------------------------
  equipment_pkg.legacy_setup_input_normal2
  (
    p_params => v_ss_parameters,
    p_range_start_raw => p_seria_starts,
    p_range_end_raw => p_seria_ends,
    p_model => p_models
  );
  ------------------------------
  equipment_pkg.Create_Operation_Int(v_ss_parameters, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Create_Operation_Int', p_error_code, p_error_message);
  end if;
  ------------------------------
  p_document_number := equipment_pkg.XGP_document_number(v_ss_parameters);
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  p_document_number := null;
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Change_Model_Of_Equipment
(
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models_out ct_model,
    p_models_in ct_model,
    p_stock_id_out number,
    p_stock_id_in number,
    p_valid_until_new date,
    p_finish boolean,
    p_user_id number,
    p_document_number_out out nvarchar2,
    p_document_number_in out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_ss_parameters1 equipment_pkg.t_ss_parameters;
  v_ss_parameters2 equipment_pkg.t_ss_parameters;
  v_doc_status_id number;
  v_doc_date1 date := sysdate;
  v_doc_date2 date := v_doc_date1 + util_pkg.c_dt_dif;
  v_main_count number;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_starts, 'p_seria_starts');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_ends, 'p_seria_ends');
  util_stock.XCheckP_ct_model(p_models_out, 'p_models_out');
  util_stock.XCheckP_ct_model(p_models_in, 'p_models_in');
  util_pkg.XCheck_Cond_Missing(p_stock_id_out is null, 'p_stock_id_out');
  util_pkg.XCheck_Cond_Missing(p_stock_id_in is null, 'p_stock_id_in');
  util_pkg.XCheck_Cond_Missing(p_valid_until_new is null, 'p_valid_until_new');
  util_pkg.XCheck_Cond_Missing(p_finish is null, 'p_finish');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_seria_starts);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_starts) != v_main_count, 'p_seria_starts.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_ends) != v_main_count, 'p_seria_ends.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_stock.get_count_ct_model(p_models_out) != v_main_count, 'p_models_out.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_stock.get_count_ct_model(p_models_in) != v_main_count, 'p_models_in.count != v_main_count');
  ------------------------------
  util_stock.xcheck_stock_id(p_stock_id_out);
  util_stock.xcheck_stock_id(p_stock_id_in);
  util_stock.xcheck_user_id(p_user_id);
  ------------------------------
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id_out, util_stock.c_perm_change_out);
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id_in, util_stock.c_perm_change_in);
  ------------------------------
  util_stock.XCheck_Doc_Perms(p_user_id, util_stock.c_Doc_Type_Debit, util_stock.c_action_Create);
  util_stock.XCheck_Doc_Perms(p_user_id, util_stock.c_Doc_Type_Credit, util_stock.c_action_Create);
  ------------------------------
  v_doc_status_id := util_stock.XFinish_To_Doc_Status(p_finish);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_valid_until_new <= v_doc_date2, 'p_valid_until_new <= v_doc_date2');
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_linked_doc_begin(v_ss_parameters1);
  ------------------------------
  equipment_pkg.setup_for_new_doc
  (
    p_params => v_ss_parameters1,
    p_doc_type_id => util_stock.c_Doc_Type_Debit,
    p_doc_date => v_doc_date1,
    p_status_id => v_doc_status_id,
    p_stock_id_out => p_stock_id_out,
    p_stock_id_in => util_stock.c_dummy_stock_id,
    p_user_id => p_user_id,
    p_last_user_id => p_user_id,
    p_vendor_doc => null,
    p_description => null,
    p_user_comment => null,
    p_vendor_id => null,
    p_doc_style => equipment_pkg.c_doc_style_crm
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters1,
    p_break_on_error => true,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => false
  );
  ------------------------------
  equipment_pkg.legacy_setup_input_normal2
  (
    p_params => v_ss_parameters1,
    p_range_start_raw => p_seria_starts,
    p_range_end_raw => p_seria_ends,
    p_model => p_models_out
  );
  ------------------------------
  equipment_pkg.Create_Operation_Int(v_ss_parameters1, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Create_Operation_Int1', p_error_code, p_error_message);
  end if;
  ------------------------------
  p_document_number_out := equipment_pkg.XGP_document_number(v_ss_parameters1);
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_linked_doc_end(v_ss_parameters1, v_ss_parameters2, false, true);
  ------------------------------
  equipment_pkg.setup_for_new_doc
  (
    p_params => v_ss_parameters2,
    p_doc_type_id => util_stock.c_Doc_Type_Credit,
    p_doc_date => v_doc_date2,
    p_status_id => v_doc_status_id,
    p_stock_id_out => util_stock.c_dummy_stock_id,
    p_stock_id_in => p_stock_id_in,
    p_user_id => p_user_id,
    p_last_user_id => p_user_id,
    p_vendor_doc => null,
    p_description => null,
    p_user_comment => null,
    p_vendor_id => null,
    p_doc_style => equipment_pkg.c_doc_style_crm
  );
  ------------------------------
  equipment_pkg.setup_additional
  (
    p_params => v_ss_parameters2,
    p_break_on_error => true,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_valid_until_common => p_valid_until_new,
    p_prematurely_populate => false
  );
  ------------------------------
  equipment_pkg.legacy_setup_input_normal2
  (
    p_params => v_ss_parameters2,
    p_range_start_raw => p_seria_starts,
    p_range_end_raw => p_seria_ends,
    p_model => p_models_in
  );
  ------------------------------
  equipment_pkg.Create_Operation_Int(v_ss_parameters2, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Create_Operation_Int2', p_error_code, p_error_message);
  end if;
  ------------------------------
  p_document_number_in := equipment_pkg.XGP_document_number(v_ss_parameters2);
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  p_document_number_out := null;
  p_document_number_in := null;
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Create_Empty_Document
(
    p_doc_type_id number,
    p_stock_id_out number,
    p_stock_id_in number,
    p_comment nvarchar2,
    p_user_id number,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_doc_date date := sysdate;
  v_ss_parameters equipment_pkg.t_ss_parameters;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  util_pkg.XCheck_Cond_Missing(p_stock_id_out is null, 'p_stock_id_out');
  util_pkg.XCheck_Cond_Missing(p_stock_id_in is null, 'p_stock_id_in');
  --!_!util_pkg.XCheck_Cond_Missing(p_comment is null, 'p_comment');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_stock.xcheck_stock_id(p_stock_id_out, TRUE);
  util_stock.xcheck_stock_id(p_stock_id_in, TRUE);
  util_stock.xcheck_user_id(p_user_id);
  ------------------------------
  if 1 = 1
    and p_stock_id_out = util_stock.c_dummy_stock_id
    and p_doc_type_id not in
  (
    util_stock.c_Doc_Type_Receipt,
    util_stock.c_Doc_Type_Credit
  )
  then
    util_pkg.Raise_exception(util_loc_pkg.c_ora_stock_out_nspec, util_loc_pkg.c_msg_stock_out_nspec);
  end if;
  ------------------------------
  if 1 = 1
    and p_stock_id_in = util_stock.c_dummy_stock_id
    and p_doc_type_id not in
  (
    util_stock.c_Doc_Type_Shippment,
    util_stock.c_Doc_Type_Debit
  )
  then
    util_pkg.Raise_exception(util_loc_pkg.c_ora_stock_in_nspec, util_loc_pkg.c_msg_stock_in_nspec);
  end if;
  ------------------------------
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id_out, util_stock.c_perm_change_out);
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id_in, util_stock.c_perm_change_in);
  ------------------------------
  util_stock.XCheck_Doc_Perms(p_user_id, p_doc_type_id, util_stock.c_action_Create);
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_single_doc(v_ss_parameters);
  ------------------------------
  equipment_pkg.setup_for_new_doc
  (
    p_params => v_ss_parameters,
    p_doc_type_id => p_doc_type_id,
    p_doc_date => v_doc_date,
    p_status_id => util_stock.c_docstat_open,
    p_stock_id_out => p_stock_id_out,
    p_stock_id_in => p_stock_id_in,
    p_user_id => p_user_id,
    p_last_user_id => p_user_id,
    p_vendor_doc => null,
    p_description => null,
    p_user_comment => p_comment,
    p_vendor_id => null,
    p_doc_style => equipment_pkg.c_doc_style_crm
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters,
    p_break_on_error => true,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => false
  );
  ------------------------------
  equipment_pkg.setup_input_empty
  (
    p_params => v_ss_parameters
  );
  ------------------------------
  equipment_pkg.Create_Operation_Int(v_ss_parameters, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Create_Operation_Int', p_error_code, p_error_message);
  end if;
  ------------------------------
  p_document_number := equipment_pkg.XGP_document_number(v_ss_parameters);
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  p_document_number := null;
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Create_Empty_Document_Lnk2
(
    p_doc_type_id1 number,
    p_doc_type_id2 number,
    p_stock_id_out1 number,
    p_stock_id_out2 number,
    p_stock_id_in1 number,
    p_stock_id_in2 number,
    p_comment1 nvarchar2,
    p_comment2 nvarchar2,
    p_user_id number,
    p_document_number1 out nvarchar2,
    p_document_number2 out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_doc_date1 date := sysdate;
  v_doc_date2 date := v_doc_date1 + util_pkg.c_dt_dif;
  v_ss_parameters1 equipment_pkg.t_ss_parameters;
  v_ss_parameters2 equipment_pkg.t_ss_parameters;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id1 is null, 'p_doc_type_id1');
  util_pkg.XCheck_Cond_Missing(p_doc_type_id2 is null, 'p_doc_type_id2');
  util_pkg.XCheck_Cond_Missing(p_stock_id_out1 is null, 'p_stock_id_out1');
  util_pkg.XCheck_Cond_Missing(p_stock_id_out2 is null, 'p_stock_id_out2');
  util_pkg.XCheck_Cond_Missing(p_stock_id_in1 is null, 'p_stock_id_in1');
  util_pkg.XCheck_Cond_Missing(p_stock_id_in2 is null, 'p_stock_id_in2');
  --!_!util_pkg.XCheck_Cond_Missing(p_comment1 is null, 'p_comment1');
  --!_!util_pkg.XCheck_Cond_Missing(p_comment2 is null, 'p_comment2');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_stock.xcheck_stock_id(p_stock_id_out1, TRUE);
  util_stock.xcheck_stock_id(p_stock_id_out2, TRUE);
  util_stock.xcheck_stock_id(p_stock_id_in1, TRUE);
  util_stock.xcheck_stock_id(p_stock_id_in2, TRUE);
  util_stock.xcheck_user_id(p_user_id);
  ------------------------------
  if 1 = 1
    and p_stock_id_out1 = util_stock.c_dummy_stock_id
    and p_doc_type_id1 not in
  (
    util_stock.c_Doc_Type_Receipt,
    util_stock.c_Doc_Type_Credit
  )
  then
    util_pkg.Raise_exception(util_loc_pkg.c_ora_stock_out_nspec, util_loc_pkg.c_msg_stock_out_nspec);
  end if;
  ------------------------------
  if 1 = 1
    and p_stock_id_out2 = util_stock.c_dummy_stock_id
    and p_doc_type_id2 not in
  (
    util_stock.c_Doc_Type_Receipt,
    util_stock.c_Doc_Type_Credit
  )
  then
    util_pkg.Raise_exception(util_loc_pkg.c_ora_stock_out_nspec, util_loc_pkg.c_msg_stock_out_nspec);
  end if;
  ------------------------------
  if 1 = 1
    and p_stock_id_in1 = util_stock.c_dummy_stock_id
    and p_doc_type_id1 not in
  (
    util_stock.c_Doc_Type_Shippment,
    util_stock.c_Doc_Type_Debit
  )
  then
    util_pkg.Raise_exception(util_loc_pkg.c_ora_stock_in_nspec, util_loc_pkg.c_msg_stock_in_nspec);
  end if;
  ------------------------------
  if 1 = 1
    and p_stock_id_in2 = util_stock.c_dummy_stock_id
    and p_doc_type_id2 not in
  (
    util_stock.c_Doc_Type_Shippment,
    util_stock.c_Doc_Type_Debit
  )
  then
    util_pkg.Raise_exception(util_loc_pkg.c_ora_stock_in_nspec, util_loc_pkg.c_msg_stock_in_nspec);
  end if;
  ------------------------------
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id_out1, util_stock.c_perm_change_out);
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id_out2, util_stock.c_perm_change_out);
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id_in1, util_stock.c_perm_change_in);
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id_in2, util_stock.c_perm_change_in);
  ------------------------------
  util_stock.XCheck_Doc_Perms(p_user_id, p_doc_type_id1, util_stock.c_action_Create);
  util_stock.XCheck_Doc_Perms(p_user_id, p_doc_type_id2, util_stock.c_action_Create);
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_linked_doc_begin(v_ss_parameters1);
  ------------------------------
  equipment_pkg.setup_for_new_doc
  (
    p_params => v_ss_parameters1,
    p_doc_type_id => p_doc_type_id1,
    p_doc_date => v_doc_date1,
    p_status_id => util_stock.c_docstat_open,
    p_stock_id_out => p_stock_id_out1,
    p_stock_id_in => p_stock_id_in1,
    p_user_id => p_user_id,
    p_last_user_id => p_user_id,
    p_vendor_doc => null,
    p_description => null,
    p_user_comment => p_comment1,
    p_vendor_id => null,
    p_doc_style => equipment_pkg.c_doc_style_crm
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters1,
    p_break_on_error => true,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => false
  );
  ------------------------------
  equipment_pkg.setup_input_empty
  (
    p_params => v_ss_parameters1
  );
  ------------------------------
  equipment_pkg.Create_Operation_Int(v_ss_parameters1, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Create_Operation_Int1', p_error_code, p_error_message);
  end if;
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_linked_doc_end(v_ss_parameters1, v_ss_parameters2, false, true);
  ------------------------------
  equipment_pkg.setup_for_new_doc
  (
    p_params => v_ss_parameters2,
    p_doc_type_id => p_doc_type_id2,
    p_doc_date => v_doc_date2,
    p_status_id => util_stock.c_docstat_open,
    p_stock_id_out => p_stock_id_out2,
    p_stock_id_in => p_stock_id_in2,
    p_user_id => p_user_id,
    p_last_user_id => p_user_id,
    p_vendor_doc => null,
    p_description => null,
    p_user_comment => p_comment2,
    p_vendor_id => null,
    p_doc_style => equipment_pkg.c_doc_style_crm
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters2,
    p_break_on_error => true,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => false
  );
  ------------------------------
  equipment_pkg.setup_input_empty
  (
    p_params => v_ss_parameters2
  );
  ------------------------------
  equipment_pkg.Create_Operation_Int(v_ss_parameters2, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Create_Operation_Int2', p_error_code, p_error_message);
  end if;
  ------------------------------
  p_document_number1 := equipment_pkg.XGP_document_number(v_ss_parameters1);
  p_document_number2 := equipment_pkg.XGP_document_number(v_ss_parameters2);
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  p_document_number1 := null;
  p_document_number2 := null;
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Set_Operation_Equipment_i
(
    p_document_number nvarchar2,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_is_addition ct_number,
    p_valid_until ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_ss_parameters out equipment_pkg.t_ss_parameters,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_doc_header doc_header%rowtype;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_document_number is null, 'p_document_number');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_starts, 'p_seria_starts');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_ends, 'p_seria_ends');
  util_stock.XCheckP_ct_model(p_models, 'p_models');
  --!_!util_pkg.XCheckP_ct_number(p_is_addition, 'p_is_addition');
  --!_!util_pkg.XCheckP_ct_date(p_valid_until, 'p_valid_until');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  ------------------------------
  v_main_count := p_seria_starts.count;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_seria_starts.count != v_main_count, 'p_seria_starts.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_seria_ends.count != v_main_count, 'p_seria_ends.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(p_models.count != v_main_count, 'p_models.count != v_main_count');
  ------------------------------
  util_stock.xcheck_user_id(p_user_id);
  ------------------------------
  v_doc_header := document_pkg.xget_doc_header_by_doc_no2(p_document_number, util_stock.c_docstat_open);
  ------------------------------
  --!_!not verified for other doc types therefore restricted
  ------------------------------
  if v_doc_header.doc_type_id not in
  (
    util_stock.c_Doc_Type_Receipt,
    util_stock.c_Doc_Type_Shippment,
    util_stock.c_Doc_Type_Movement,
    util_stock.c_Doc_Type_Credit,
    util_stock.c_Doc_Type_Debit
  )
  then
    util_pkg.raise_label_exception('v_doc_header.doc_type_id', util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || v_doc_header.doc_type_id);
  end if;
  ------------------------------
  util_stock.XCheck_Stock_Perms(p_user_id, v_doc_header.stock_out_id, util_stock.c_perm_change_out);
  util_stock.XCheck_Stock_Perms(p_user_id, v_doc_header.stock_in_id, util_stock.c_perm_change_in);
  ------------------------------
  util_stock.XCheck_Doc_Perms(p_user_id, v_doc_header.doc_type_id, util_stock.c_action_Change);
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_single_doc(p_ss_parameters);
  ------------------------------
  equipment_pkg.setup_for_old_doc
  (
    p_params => p_ss_parameters,
    p_doc_header_from => v_doc_header,
    p_status_id => v_doc_header.status_id, --!_!util_stock.c_docstat_open,
    p_last_user_id => p_user_id,
    p_doc_date => null
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => p_ss_parameters,
    p_break_on_error => p_break_on_error,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => true
  );
  ------------------------------
  equipment_pkg.legacy_setup_input_set_op_eq
  (
    p_params => p_ss_parameters,
    p_range_start_raw => p_seria_starts,
    p_range_end_raw => p_seria_ends,
    p_model => p_models,
    p_valid_until_raw => p_valid_until,
    p_is_addition_raw => p_is_addition
  );
  ------------------------------
  equipment_pkg.Set_Operation_Equipment_Int(p_ss_parameters, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Set_Operation_Equipment_Int', p_error_code, p_error_message);
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Set_Operation_Equipment1
(
    p_document_number nvarchar2,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_is_addition ct_number,
    p_valid_until ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_ss_parameters equipment_pkg.t_ss_parameters;
begin
  ------------------------------
  Set_Operation_Equipment_i
  (
    p_document_number => p_document_number,
    p_seria_starts => p_seria_starts,
    p_seria_ends => p_seria_ends,
    p_models => p_models,
    p_is_addition => p_is_addition,
    p_valid_until => p_valid_until,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_ss_parameters => v_ss_parameters,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  p_result := equipment_pkg.get_result_cursor01_simple(v_ss_parameters);
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
  if p_result%isopen
  then
    close p_result;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Set_Operation_Equipment2
(
    p_document_number nvarchar2,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_is_addition ct_number,
    p_valid_until ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_ss_parameters equipment_pkg.t_ss_parameters;
begin
  ------------------------------
  Set_Operation_Equipment_i
  (
    p_document_number => p_document_number,
    p_seria_starts => p_seria_starts,
    p_seria_ends => p_seria_ends,
    p_models => p_models,
    p_is_addition => p_is_addition,
    p_valid_until => p_valid_until,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_ss_parameters => v_ss_parameters,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Set_Operation_Equipment3
(
    p_document_number nvarchar2,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_is_addition ct_number,
    p_valid_until ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_ss_parameters equipment_pkg.t_ss_parameters;
  v_mark_ok ct_number;
begin
  ------------------------------
  Set_Operation_Equipment_i
  (
    p_document_number => p_document_number,
    p_seria_starts => p_seria_starts,
    p_seria_ends => p_seria_ends,
    p_models => p_models,
    p_is_addition => p_is_addition,
    p_valid_until => p_valid_until,
    p_user_id => p_user_id,
    p_break_on_error => p_break_on_error,
    p_ss_parameters => v_ss_parameters,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  p_error_codes := equipment_pkg.EGP_error_codes_full_size(v_ss_parameters);
  p_error_messages := equipment_pkg.EGP_error_messages_full_size(v_ss_parameters);
  ------------------------------
  v_mark_ok := util_pkg.mark_val_ct_number(p_error_codes, null, util_pkg.c_true, util_pkg.c_false);
  util_stock.setup_error_by_marks(v_mark_ok, util_pkg.c_ora_ok, util_pkg.c_msg_ok, util_pkg.c_true, p_error_codes, p_error_messages);
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Set_Operation_Equipment_Lnk2
(
    p_symmetric boolean,
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_seria_starts1 ct_nvarchar_s,
    p_seria_starts2 ct_nvarchar_s,
    p_seria_ends1 ct_nvarchar_s,
    p_seria_ends2 ct_nvarchar_s,
    p_models1 ct_model,
    p_models2 ct_model,
    p_is_addition1 ct_number,
    p_is_addition2 ct_number,
    p_valid_until1 ct_date,
    p_valid_until2 ct_date,
    p_user_id number,
    p_open_result boolean,
    p_break_on_error boolean,
    p_result1 out sys_refcursor,
    p_result2 out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_ss_parameters1 equipment_pkg.t_ss_parameters;
  v_ss_parameters2 equipment_pkg.t_ss_parameters;
  v_ss_parameters3 equipment_pkg.t_ss_parameters;
  v_main_count1 number;
  v_main_count2 number;
  v_doc_header1 doc_header%rowtype;
  v_doc_header2 doc_header%rowtype;
  v_last_in_chain number := 0;
  --
  v_seria_starts2 ct_nvarchar_s;
  v_seria_ends2 ct_nvarchar_s;
  v_models2 ct_model;
  v_is_addition2 ct_number;
  v_valid_until2 ct_date;
  --
  v_seria_starts3 ct_nvarchar_s;
  v_seria_ends3 ct_nvarchar_s;
  v_models3 ct_model;
  v_is_addition3 ct_number;
  --!_!v_valid_until3 ct_date;
  --
  v_mark1 ct_number;
  v_mark2 ct_number;
  v_pos_ok1 ct_number;
  v_pos1_for_err2 ct_number;
  --
  v_ids1 ct_number;
  v_ids_err1 ct_number;
  v_ids1_for_err2 ct_number := NULL;
  --
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_symmetric is null, 'p_symmetric');
  util_pkg.XCheck_Cond_Missing(p_document_number1 is null, 'p_document_number1');
  util_pkg.XCheck_Cond_Missing(p_document_number2 is null, 'p_document_number2');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_starts1, 'p_seria_starts1');
  --!_!util_pkg.XCheckP_ct_nvarchar_s(p_seria_starts2, 'p_seria_starts2');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_ends1, 'p_seria_ends1');
  --!_!util_pkg.XCheckP_ct_nvarchar_s(p_seria_ends2, 'p_seria_ends2');
  util_stock.XCheckP_ct_model(p_models1, 'p_models1');
  util_stock.XCheckP_ct_model(p_models2, 'p_models2'); --!_!
  --!_!util_pkg.XCheckP_ct_number(p_is_addition1, 'p_is_addition1');
  --!_!util_pkg.XCheckP_ct_number(p_is_addition2, 'p_is_addition2');
  --!_!util_pkg.XCheckP_ct_date(p_valid_until1, 'p_valid_until1');
  --!_!util_pkg.XCheckP_ct_date(p_valid_until2, 'p_valid_until2');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_open_result is null, 'p_open_result');
  ------------------------------
  if p_symmetric
  then
    ------------------------------
    null;
    ------------------------------
  else
    ------------------------------
    util_pkg.XCheckP_ct_nvarchar_s(p_seria_starts2, 'p_seria_starts2');
    util_pkg.XCheckP_ct_nvarchar_s(p_seria_ends2, 'p_seria_ends2');
    --!_!--!_!util_stock.XCheckP_ct_model(p_models2, 'p_models2');
    --!_!util_pkg.XCheckP_ct_number(p_is_addition2, 'p_is_addition2');
    --!_!util_pkg.XCheckP_ct_date(p_valid_until2, 'p_valid_until2');
    ------------------------------
  end if;
  ------------------------------
  v_main_count1 := util_pkg.get_count_ct_nvarchar_s(p_seria_starts1);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_starts1) != v_main_count1, 'p_seria_starts1.count != v_main_count1');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_ends1) != v_main_count1, 'p_seria_ends1.count != v_main_count1');
  util_pkg.XCheck_Cond_Invalid(util_stock.get_count_ct_model(p_models1) != v_main_count1, 'p_models1.count != v_main_count1');
  ------------------------------
  if p_symmetric
  then
    ------------------------------
    --!_!v_main_count2 := v_main_count1;
    ------------------------------
    util_pkg.XCheck_Cond_Invalid(util_stock.get_count_ct_model(p_models2) != v_main_count1, 'p_models2.count != v_main_count1');
    ------------------------------
  else
    ------------------------------
    v_main_count2 := util_pkg.get_count_ct_nvarchar_s(p_seria_starts2);
    ------------------------------
    util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_starts2) != v_main_count2, 'p_seria_starts2.count != v_main_count2');
    util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_ends2) != v_main_count2, 'p_seria_ends2.count != v_main_count2');
    util_pkg.XCheck_Cond_Invalid(util_stock.get_count_ct_model(p_models2) != v_main_count2, 'p_models2.count != v_main_count2');
    ------------------------------
  end if;
  ------------------------------
  util_stock.xcheck_user_id(p_user_id);
  ------------------------------
  v_doc_header1 := document_pkg.xget_doc_header_by_doc_no2(p_document_number1, util_stock.c_docstat_open);
  ------------------------------
  --!_!not verified for other doc types therefore restricted
  ------------------------------
  if v_doc_header1.doc_type_id not in
  (
    util_stock.c_Doc_Type_Receipt,
    util_stock.c_Doc_Type_Shippment,
    util_stock.c_Doc_Type_Movement,
    util_stock.c_Doc_Type_Credit,
    util_stock.c_Doc_Type_Debit
  )
  then
    util_pkg.raise_label_exception('v_doc_header1.doc_type_id', util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || v_doc_header1.doc_type_id);
  end if;
  ------------------------------
  v_doc_header2 := document_pkg.xget_doc_header_by_doc_no2(p_document_number2, util_stock.c_docstat_open);
  ------------------------------
  --!_!not verified for other doc types therefore restricted
  ------------------------------
  if v_doc_header2.doc_type_id not in
  (
    util_stock.c_Doc_Type_Receipt,
    util_stock.c_Doc_Type_Shippment,
    util_stock.c_Doc_Type_Movement,
    util_stock.c_Doc_Type_Credit,
    util_stock.c_Doc_Type_Debit
  )
  then
    util_pkg.raise_label_exception('v_doc_header2.doc_type_id', util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || v_doc_header2.doc_type_id);
  end if;
  ------------------------------
  util_stock.XCheck_Stock_Perms(p_user_id, v_doc_header1.stock_out_id, util_stock.c_perm_change_out);
  util_stock.XCheck_Stock_Perms(p_user_id, v_doc_header2.stock_out_id, util_stock.c_perm_change_out);
  util_stock.XCheck_Stock_Perms(p_user_id, v_doc_header1.stock_in_id, util_stock.c_perm_change_in);
  util_stock.XCheck_Stock_Perms(p_user_id, v_doc_header2.stock_in_id, util_stock.c_perm_change_in);
  ------------------------------
  util_stock.XCheck_Doc_Perms(p_user_id, v_doc_header1.doc_type_id, util_stock.c_action_Change);
  util_stock.XCheck_Doc_Perms(p_user_id, v_doc_header2.doc_type_id, util_stock.c_action_Change);
  ------------------------------
  if p_symmetric
  then
    ------------------------------
    v_seria_starts2 := p_seria_starts1;
    v_seria_ends2 := p_seria_ends1;
    v_is_addition2 := p_is_addition1;
    v_valid_until2 := p_valid_until1;
    ------------------------------
  else
    ------------------------------
    v_seria_starts2 := p_seria_starts2;
    v_seria_ends2 := p_seria_ends2;
    v_is_addition2 := p_is_addition2;
    v_valid_until2 := p_valid_until2;
    ------------------------------
  end if;
  ------------------------------
  v_models2 := p_models2; --!_!
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_linked_doc_begin(v_ss_parameters1);
  ------------------------------
  equipment_pkg.setup_for_old_doc
  (
    p_params => v_ss_parameters1,
    p_doc_header_from => v_doc_header1,
    p_status_id => v_doc_header1.status_id, --!_!util_stock.c_docstat_open,
    p_last_user_id => p_user_id,
    p_doc_date => null
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters1,
    p_break_on_error => p_break_on_error,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => true
  );
  ------------------------------
  equipment_pkg.legacy_setup_input_set_op_eq
  (
    p_params => v_ss_parameters1,
    p_range_start_raw => p_seria_starts1,
    p_range_end_raw => p_seria_ends1,
    p_model => p_models1,
    p_valid_until_raw => p_valid_until1,
    p_is_addition_raw => p_is_addition1
  );
  ------------------------------
  equipment_pkg.Set_Operation_Equipment_Int(v_ss_parameters1, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Set_Operation_Equipment_Int1', p_error_code, p_error_message);
  end if;
  ------------------------------
  v_last_in_chain := 1;
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_linked_doc_continue(v_ss_parameters1, v_ss_parameters2, false,  true);
  ------------------------------
  equipment_pkg.setup_for_old_doc
  (
    p_params => v_ss_parameters2,
    p_doc_header_from => v_doc_header2,
    p_status_id => v_doc_header2.status_id, --!_!util_stock.c_docstat_open,
    p_last_user_id => p_user_id,
    p_doc_date => null
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters2,
    p_break_on_error => p_break_on_error,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => true
  );
  ------------------------------
  if 1 = 1
    and p_symmetric
    and equipment_pkg.EGP_error_count(v_ss_parameters1) > 0
  then
    ------------------------------
    v_valid_until2 := equipment_pkg.xsmart_make_valid_until
    (
      p_valid_until_raw => v_valid_until2,
      p_main_count => v_main_count1, --!_!
      p_valid_until_common_nullable => equipment_pkg.GP_valid_until_common_nullable(v_ss_parameters2)
    );
    ------------------------------
    v_is_addition2 := equipment_pkg.xsmart_make_is_addition
    (
      p_is_addition_raw => v_is_addition2,
      p_main_count => v_main_count1 --!_!
    );
    ------------------------------
    equipment_pkg.XCheck_in_data_raw
    (
      p_range_start => v_seria_starts2,
      p_range_end => v_seria_ends2,
      p_model => v_models2,
      p_valid_until => v_valid_until2,
      p_is_addition => v_is_addition2
    );
    ------------------------------
    --!_!mark errors in v_ss_parameters1 and EXclude erroneous data from v_ss_parameters2
    ------------------------------
    v_mark1 := util_pkg.mark_ct_number(equipment_pkg.EGP_ids(v_ss_parameters1), equipment_pkg.EGP_ids_erroneous_only(v_ss_parameters1), util_pkg.C_FALSE); --!_!reverse
    ------------------------------
    util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_mark1) != v_main_count1, 'v_mark1.count != v_main_count1');
    ------------------------------
    v_seria_starts2 := util_pkg.get_marked_ct_nvarchar_s(v_seria_starts2, v_mark1, TRUE);
    v_seria_ends2 := util_pkg.get_marked_ct_nvarchar_s(v_seria_ends2, v_mark1, TRUE);
    v_models2 := util_stock.get_marked_ct_model(v_models2, v_mark1, TRUE);
    v_valid_until2 := util_pkg.get_marked_ct_date(v_valid_until2, v_mark1, TRUE);
    v_is_addition2 := util_pkg.get_marked_ct_number(v_is_addition2, v_mark1, TRUE);
    ------------------------------
    v_pos_ok1 := util_pkg.mark2pos(v_mark1, TRUE);
    ------------------------------
  end if;
  ------------------------------
  equipment_pkg.legacy_setup_input_set_op_eq
  (
    p_params => v_ss_parameters2,
    p_range_start_raw => v_seria_starts2,
    p_range_end_raw => v_seria_ends2,
    p_model => v_models2,
    p_valid_until_raw => v_valid_until2,
    p_is_addition_raw => v_is_addition2
  );
  ------------------------------
  equipment_pkg.Set_Operation_Equipment_Int(v_ss_parameters2, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Set_Operation_Equipment_Int2', p_error_code, p_error_message);
  end if;
  ------------------------------
  v_last_in_chain := 2;
  ------------------------------
  if 1 = 1
    and p_symmetric
    and equipment_pkg.EGP_error_count(v_ss_parameters2) > 0
  then
    ------------------------------
    equipment_pkg.setup_for_linked_doc_continue(v_ss_parameters2, v_ss_parameters3, true, true);
    ------------------------------
    equipment_pkg.setup_for_old_doc
    (
      p_params => v_ss_parameters3,
      p_doc_header_from => v_doc_header1,
      p_status_id => v_doc_header1.status_id, --!_!util_stock.c_docstat_open,
      p_last_user_id => p_user_id,
      p_doc_date => null
    );
    ------------------------------
    equipment_pkg.setup_additional2
    (
      p_params => v_ss_parameters3,
      p_break_on_error => TRUE,
      p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
      p_prematurely_populate => true
    );
    ------------------------------
    v_is_addition3 := equipment_pkg.xsmart_make_is_addition
    (
      p_is_addition_raw => equipment_pkg.invert_is_addition(p_is_addition1),
      p_main_count => v_main_count1 --!_!
    );
    ------------------------------
    equipment_pkg.XCheck_in_data_raw2
    (
      p_range_start => p_seria_starts1,
      p_range_end => p_seria_ends1,
      p_model => p_models1,
      p_is_addition => v_is_addition3
    );
    ------------------------------
    --!_!mark errors in v_ss_parameters2 and INclude erroneous data in v_ss_parameters3 to rollback their results from v_ss_parameters1
    ------------------------------
    v_mark2 := util_pkg.mark_ct_number(equipment_pkg.EGP_ids(v_ss_parameters2), equipment_pkg.EGP_ids_erroneous_only(v_ss_parameters2), util_pkg.C_TRUE); --!_!direct
    v_pos1_for_err2 := util_pkg.get_marked_ct_number(v_pos_ok1, v_mark2, TRUE);
    ------------------------------
    v_mark2 := util_pkg.make_ct_number(v_main_count1, util_pkg.C_FALSE);
    util_pkg.set_val_by_pos2_ct_number(v_mark2, util_pkg.C_TRUE, v_pos1_for_err2);
    ------------------------------
    v_ids1 := equipment_pkg.EGP_ids(v_ss_parameters1);
    ------------------------------
    util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_mark2) != v_main_count1, 'v_mark2.count != v_main_count1');
    util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(v_ids1) != v_main_count1, 'v_ids1.count != v_main_count1');
    ------------------------------
    v_ids1_for_err2 := util_pkg.get_marked_ct_number(v_ids1, v_mark2, TRUE);
    ------------------------------
    v_seria_starts3 := util_pkg.get_marked_ct_nvarchar_s(p_seria_starts1, v_mark2, TRUE);
    v_seria_ends3 := util_pkg.get_marked_ct_nvarchar_s(p_seria_ends1, v_mark2, TRUE);
    v_models3 := util_stock.get_marked_ct_model(p_models1, v_mark2, TRUE);
    --!_!v_valid_until3 := util_pkg.get_marked_ct_date(p_valid_until1, v_mark2, TRUE);
    v_is_addition3 := util_pkg.get_marked_ct_number(v_is_addition3, v_mark1, TRUE);
    ------------------------------
    equipment_pkg.legacy_setup_input_set_op_eq2
    (
      p_params => v_ss_parameters3,
      p_range_start_raw => v_seria_starts3,
      p_range_end_raw => v_seria_ends3,
      p_model => v_models3,
      p_is_addition_raw => v_is_addition3
    );
    ------------------------------
    equipment_pkg.Set_Operation_Equipment_Int(v_ss_parameters3, p_error_code, p_error_message);
    ------------------------------
    if util_pkg.is_error(p_error_code)
    then
      util_pkg.raise_label_exception('Set_Operation_Equipment_Int3', p_error_code, p_error_message);
    end if;
    ------------------------------
    v_last_in_chain := 3;
    ------------------------------
    equipment_pkg.finalize_chain(v_ss_parameters3, true);
    ------------------------------
  else
    ------------------------------
    equipment_pkg.finalize_chain(v_ss_parameters2, true);
    ------------------------------
  end if;
  ------------------------------
  v_last_in_chain := 0;
  ------------------------------
  if p_open_result
  then
    ------------------------------
    if p_symmetric
    then
      ------------------------------
      p_result1 := equipment_pkg.get_result_cursor01
      (
        p_params => v_ss_parameters1,
        p_subst_ids => v_ids1_for_err2,
        p_subst_exclusive => false,
        p_subst_error_code => util_loc_pkg.c_ora_linked_error,
        p_subst_error_message => util_loc_pkg.c_msg_linked_error
      );
      ------------------------------
      v_ids1 := equipment_pkg.EGP_ids(v_ss_parameters1);
      v_ids_err1 := equipment_pkg.EGP_ids_erroneous_only(v_ss_parameters1);
      ------------------------------
      --!_! full_size = v_ids1.count
      ------------------------------
      p_result2 := equipment_pkg.get_result_cursor01_common
      (
        p_ids => v_ids1, --!_!p_symmetric
        p_seria_starts => p_seria_starts1, --!_!p_symmetric
        p_seria_ends => p_seria_ends1, --!_!p_symmetric
        p_models => p_models2, --!_!
        p_is_addition => p_is_addition1, --!_!p_symmetric
        p_error_codes => equipment_pkg.Eget_error_codes_full_size(equipment_pkg.EGP_error_codes_only(v_ss_parameters2), v_ids1, v_ids1_for_err2), --!_!p_symmetric
        p_error_messages => equipment_pkg.Eget_error_messages_full_size(equipment_pkg.EGP_error_messages_only(v_ss_parameters2), v_ids1, v_ids1_for_err2), --!_!p_symmetric
        p_subst_ids => v_ids_err1, --!_!p_symmetric
        p_subst_exclusive => false,
        p_subst_error_code => util_loc_pkg.c_ora_linked_error,
        p_subst_error_message => util_loc_pkg.c_msg_linked_error
      );
      ------------------------------
    else
      ------------------------------
      p_result1 := equipment_pkg.get_result_cursor01_simple(v_ss_parameters1);
      ------------------------------
      p_result2 := equipment_pkg.get_result_cursor01_simple(v_ss_parameters2);
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  if v_last_in_chain = 1
  then
    ------------------------------
    equipment_pkg.finalize_chain(v_ss_parameters1, false);
    ------------------------------
  elsif v_last_in_chain = 2
  then
    ------------------------------
    equipment_pkg.finalize_chain(v_ss_parameters2, false);
    ------------------------------
  elsif v_last_in_chain = 3
  then
    ------------------------------
    equipment_pkg.finalize_chain(v_ss_parameters3, false);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
  if p_result1%isopen
  then
    close p_result1;
  end if;
  ------------------------------
  if p_result2%isopen
  then
    close p_result2;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Set_Op_Eq_Symmetric_Lnk2
(
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models1 ct_model,
    p_models2 ct_model,
    p_is_addition ct_number,
    p_valid_until ct_date,
    p_user_id number,
    p_open_result boolean,
    p_break_on_error boolean,
    p_result1 out sys_refcursor,
    p_result2 out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  Set_Operation_Equipment_Lnk2
  (
    p_symmetric => true,
    p_document_number1 => p_document_number1,
    p_document_number2 => p_document_number2,
    p_seria_starts1 => p_seria_starts,
    p_seria_starts2 => null,
    p_seria_ends1 => p_seria_ends,
    p_seria_ends2 => null,
    p_models1 => p_models1,
    p_models2 => p_models2,
    p_is_addition1 => p_is_addition,
    p_is_addition2 => null,
    p_valid_until1 => p_valid_until,
    p_valid_until2 => null,
    p_user_id => p_user_id,
    p_open_result => p_open_result,
    p_break_on_error => p_break_on_error,
    p_result1 => p_result1,
    p_result2 => p_result2,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Set_Operation_Equipment_Lnk2', p_error_code, p_error_message);
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  --!_! no rollback
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Set_Op_Eq_Non_Symmetric_Lnk2
(
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_seria_starts1 ct_nvarchar_s,
    p_seria_starts2 ct_nvarchar_s,
    p_seria_ends1 ct_nvarchar_s,
    p_seria_ends2 ct_nvarchar_s,
    p_models1 ct_model,
    p_models2 ct_model,
    p_is_addition1 ct_number,
    p_is_addition2 ct_number,
    p_valid_until1 ct_date,
    p_valid_until2 ct_date,
    p_user_id number,
    p_open_result boolean,
    p_break_on_error boolean,
    p_result1 out sys_refcursor,
    p_result2 out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  Set_Operation_Equipment_Lnk2
  (
    p_symmetric => false,
    p_document_number1 => p_document_number1,
    p_document_number2 => p_document_number2,
    p_seria_starts1 => p_seria_starts1,
    p_seria_starts2 => p_seria_starts2,
    p_seria_ends1 => p_seria_ends1,
    p_seria_ends2 => p_seria_ends2,
    p_models1 => p_models1,
    p_models2 => p_models2,
    p_is_addition1 => p_is_addition1,
    p_is_addition2 => p_is_addition2,
    p_valid_until1 => p_valid_until1,
    p_valid_until2 => p_valid_until2,
    p_user_id => p_user_id,
    p_open_result => p_open_result,
    p_break_on_error => p_break_on_error,
    p_result1 => p_result1,
    p_result2 => p_result2,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Set_Operation_Equipment_Lnk2', p_error_code, p_error_message);
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  --!_! no rollback
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Change_Operation_State
(
    p_document_number nvarchar2,
    p_doc_status_id number,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_doc_date date := sysdate;
  v_ss_parameters equipment_pkg.t_ss_parameters;
  v_doc_header doc_header%rowtype;
  v_user_id number;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_document_number is null, 'p_document_number');
  util_pkg.XCheck_Cond_Missing(p_doc_status_id is null, 'p_doc_status_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  --!_!util_stock.xcheck_user_id(p_user_id);
  ------------------------------
  if p_doc_status_id not in
  (
    util_stock.c_docstat_finished,
    util_stock.c_docstat_canceled
  )
  then
    util_pkg.raise_label_exception('p_doc_status_id', util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter || util_pkg.c_msg_delim01 || p_doc_status_id);
  end if;
  ------------------------------
  v_doc_header := document_pkg.xget_doc_header_by_doc_no2(p_document_number, util_stock.c_docstat_open);
  ------------------------------
  if util_stock.is_doc_initially_finalized(v_doc_header.doc_type_id)
  then
    ------------------------------
    util_pkg.raise_label_exception('v_doc_header.doc_type_id', util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || v_doc_header.doc_type_id);
    ------------------------------
  end if;
  ------------------------------
  if p_user_id is null
  then
    ------------------------------
    v_user_id := v_doc_header.user_id;
    ------------------------------
  else
    ------------------------------
    util_stock.xcheck_user_id(p_user_id);
    ------------------------------
    v_user_id := p_user_id;
    ------------------------------
    util_stock.XCheck_Stock_Perms(v_user_id, v_doc_header.stock_out_id, util_stock.c_perm_change_out);
    util_stock.XCheck_Stock_Perms(v_user_id, v_doc_header.stock_in_id, util_stock.c_perm_change_in);
    ------------------------------
    util_stock.XCheck_Doc_Perms(v_user_id, v_doc_header.doc_type_id, util_stock.c_action_Change);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_single_doc(v_ss_parameters);
  ------------------------------
  equipment_pkg.setup_for_old_doc
  (
    p_params => v_ss_parameters,
    p_doc_header_from => v_doc_header,
    p_status_id => p_doc_status_id,
    p_last_user_id => v_user_id,
    p_doc_date => v_doc_date
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters,
    p_break_on_error => true,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => false
  );
  ------------------------------
  equipment_pkg.setup_input_from_doc_detail
  (
    p_params => v_ss_parameters
  );
  ------------------------------
  equipment_pkg.Change_Operation_State_Int(v_ss_parameters, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Change_Operation_State_Int', p_error_code, p_error_message);
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Change_Operation_State_Lnk2
(
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_doc_status_id number,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_doc_date1 date := sysdate;
  v_doc_date2 date := v_doc_date1 + util_pkg.c_dt_dif;
  v_ss_parameters1 equipment_pkg.t_ss_parameters;
  v_ss_parameters2 equipment_pkg.t_ss_parameters;
  v_doc_header1 doc_header%rowtype;
  v_doc_header2 doc_header%rowtype;
  v_user_id number;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_document_number1 is null, 'p_document_number1');
  util_pkg.XCheck_Cond_Missing(p_document_number2 is null, 'p_document_number2');
  util_pkg.XCheck_Cond_Missing(p_doc_status_id is null, 'p_doc_status_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  --!_!util_stock.xcheck_user_id(p_user_id);
  ------------------------------
  if p_doc_status_id not in
  (
    util_stock.c_docstat_finished,
    util_stock.c_docstat_canceled
  )
  then
    util_pkg.raise_label_exception('p_doc_status_id', util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter || util_pkg.c_msg_delim01 || p_doc_status_id);
  end if;
  ------------------------------
  v_doc_header1 := document_pkg.xget_doc_header_by_doc_no2(p_document_number1, util_stock.c_docstat_open);
  ------------------------------
  --!_!not verified for other doc types therefore restricted
  ------------------------------
  if v_doc_header1.doc_type_id not in
  (
    util_stock.c_Doc_Type_Receipt,
    util_stock.c_Doc_Type_Shippment,
    util_stock.c_Doc_Type_Movement,
    util_stock.c_Doc_Type_Credit,
    util_stock.c_Doc_Type_Debit
  )
  then
    util_pkg.raise_label_exception('v_doc_header1.doc_type_id', util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || v_doc_header1.doc_type_id);
  end if;
  ------------------------------
  v_doc_header2 := document_pkg.xget_doc_header_by_doc_no2(p_document_number2, util_stock.c_docstat_open);
  ------------------------------
  --!_!not verified for other doc types therefore restricted
  ------------------------------
  if v_doc_header2.doc_type_id not in
  (
    util_stock.c_Doc_Type_Receipt,
    util_stock.c_Doc_Type_Shippment,
    util_stock.c_Doc_Type_Movement,
    util_stock.c_Doc_Type_Credit,
    util_stock.c_Doc_Type_Debit
  )
  then
    util_pkg.raise_label_exception('v_doc_header2.doc_type_id', util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || v_doc_header2.doc_type_id);
  end if;
  ------------------------------
  if p_user_id is null
  then
    ------------------------------
    v_user_id := v_doc_header1.user_id;
    --!_!v_user_id := v_doc_header2.user_id;
    ------------------------------
  else
    ------------------------------
    util_stock.xcheck_user_id(p_user_id);
    ------------------------------
    v_user_id := p_user_id;
    ------------------------------
    util_stock.XCheck_Stock_Perms(v_user_id, v_doc_header1.stock_out_id, util_stock.c_perm_change_out);
    util_stock.XCheck_Stock_Perms(v_user_id, v_doc_header2.stock_out_id, util_stock.c_perm_change_out);
    util_stock.XCheck_Stock_Perms(v_user_id, v_doc_header1.stock_in_id, util_stock.c_perm_change_in);
    util_stock.XCheck_Stock_Perms(v_user_id, v_doc_header2.stock_in_id, util_stock.c_perm_change_in);
    ------------------------------
    util_stock.XCheck_Doc_Perms(v_user_id, v_doc_header1.doc_type_id, util_stock.c_action_Change);
    util_stock.XCheck_Doc_Perms(v_user_id, v_doc_header2.doc_type_id, util_stock.c_action_Change);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_linked_doc_begin(v_ss_parameters1);
  ------------------------------
  equipment_pkg.setup_for_old_doc
  (
    p_params => v_ss_parameters1,
    p_doc_header_from => v_doc_header1,
    p_status_id => p_doc_status_id,
    p_last_user_id => v_user_id,
    p_doc_date => v_doc_date1
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters1,
    p_break_on_error => true,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => false
  );
  ------------------------------
  equipment_pkg.setup_input_from_doc_detail
  (
    p_params => v_ss_parameters1
  );
  ------------------------------
  equipment_pkg.Change_Operation_State_Int(v_ss_parameters1, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Change_Operation_State_Int1', p_error_code, p_error_message);
  end if;
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_linked_doc_end(v_ss_parameters1, v_ss_parameters2, false, true);
  ------------------------------
  equipment_pkg.setup_for_old_doc
  (
    p_params => v_ss_parameters2,
    p_doc_header_from => v_doc_header2,
    p_status_id => p_doc_status_id,
    p_last_user_id => v_user_id,
    p_doc_date => v_doc_date2
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters2,
    p_break_on_error => true,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => false
  );
  ------------------------------
  equipment_pkg.setup_input_from_doc_detail
  (
    p_params => v_ss_parameters2
  );
  ------------------------------
  equipment_pkg.Change_Operation_State_Int(v_ss_parameters2, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Change_Operation_State_Int2', p_error_code, p_error_message);
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Finalize_Document
(
    p_document_number nvarchar2,
    p_user_id number := null,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  Change_Operation_State
  (
    p_document_number => p_document_number,
    p_doc_status_id => util_stock.c_docstat_finished,
    p_user_id => p_user_id,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Change_Operation_State', p_error_code, p_error_message);
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  --!_! no rollback
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Finalize_Document_Lnk2
(
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_user_id number := null,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  Change_Operation_State_Lnk2
  (
    p_document_number1 => p_document_number1,
    p_document_number2 => p_document_number2,
    p_doc_status_id => util_stock.c_docstat_finished,
    p_user_id => p_user_id,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Change_Operation_State_Lnk2', p_error_code, p_error_message);
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  --!_! no rollback
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Cancel_Document
(
    p_document_number nvarchar2,
    p_user_id number := null,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  Change_Operation_State
  (
    p_document_number => p_document_number,
    p_doc_status_id => util_stock.c_docstat_canceled,
    p_user_id => p_user_id,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Change_Operation_State', p_error_code, p_error_message);
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  --!_! no rollback
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Cancel_Document_Lnk2
(
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_user_id number := null,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  Change_Operation_State_Lnk2
  (
    p_document_number1 => p_document_number1,
    p_document_number2 => p_document_number2,
    p_doc_status_id => util_stock.c_docstat_canceled,
    p_user_id => p_user_id,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Change_Operation_State_Lnk2', p_error_code, p_error_message);
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  --!_! no rollback
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure receive_equipment
(
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_validity_date ct_date,
    p_stock_id number,
    p_vendor_doc nvarchar2,
    p_finish boolean,
    p_user_id number,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_doc_date date := sysdate;
  v_ss_parameters equipment_pkg.t_ss_parameters;
  v_doc_status_id number;
  v_main_count number;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_starts, 'p_seria_starts');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_ends, 'p_seria_ends');
  util_stock.XCheckP_ct_model(p_models, 'p_models');
  util_pkg.XCheckP_ct_date(p_validity_date, 'p_validity_date');
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  util_pkg.XCheck_Cond_Missing(p_finish is null, 'p_finish');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_seria_starts);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_starts) != v_main_count, 'p_seria_starts.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_ends) != v_main_count, 'p_seria_ends.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_stock.get_count_ct_model(p_models) != v_main_count, 'p_models.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_validity_date) != v_main_count, 'p_validity_date.count != v_main_count');
  ------------------------------
  util_stock.xcheck_stock_id(p_stock_id);
  util_stock.xcheck_user_id(p_user_id);
  ------------------------------
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id, util_stock.c_perm_change_in);
  ------------------------------
  util_stock.XCheck_Doc_Perms(p_user_id, util_stock.c_Doc_Type_Receipt, util_stock.c_action_Create);
  ------------------------------
  v_doc_status_id := util_stock.XFinish_To_Doc_Status(p_finish);
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_single_doc(v_ss_parameters);
  ------------------------------
  equipment_pkg.setup_for_new_doc
  (
    p_params => v_ss_parameters,
    p_doc_type_id => util_stock.c_Doc_Type_Receipt,
    p_doc_date => v_doc_date,
    p_status_id => v_doc_status_id,
    p_stock_id_out => util_stock.c_dummy_stock_id,
    p_stock_id_in => p_stock_id,
    p_user_id => p_user_id,
    p_last_user_id => p_user_id,
    p_vendor_doc => p_vendor_doc,
    p_description => null,
    p_user_comment => null,
    p_vendor_id => null,
    p_doc_style => equipment_pkg.c_doc_style_crm
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters,
    p_break_on_error => true,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => true
  );
  ------------------------------
  equipment_pkg.legacy_setup_input_normal
  (
    p_params => v_ss_parameters,
    p_range_start_raw => p_seria_starts,
    p_range_end_raw => p_seria_ends,
    p_model => p_models,
    p_valid_until_raw => p_validity_date
  );
  ------------------------------
  equipment_pkg.Create_Operation_Int(v_ss_parameters, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('equipment_pkg.Create_Operation_Int', p_error_code, p_error_message);
  end if;
  ------------------------------
  p_document_number := equipment_pkg.XGP_document_number(v_ss_parameters);
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  p_document_number := null;
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure receive_equipment2
(
    p_document_number nvarchar2,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_validity_date ct_date,
    p_stock_id number,
    p_finish boolean,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_ss_parameters equipment_pkg.t_ss_parameters;
  v_doc_header doc_header%rowtype;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_document_number is null, 'p_document_number');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_starts, 'p_seria_starts');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_ends, 'p_seria_ends');
  util_stock.XCheckP_ct_model(p_models, 'p_models');
  util_pkg.XCheckP_ct_date(p_validity_date, 'p_validity_date');
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  util_pkg.XCheck_Cond_Missing(p_finish is null, 'p_finish');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_seria_starts);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_starts) != v_main_count, 'p_seria_starts.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_ends) != v_main_count, 'p_seria_ends.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_stock.get_count_ct_model(p_models) != v_main_count, 'p_models.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_validity_date) != v_main_count, 'p_validity_date.count != v_main_count');
  ------------------------------
  util_stock.xcheck_stock_id(p_stock_id);
  util_stock.xcheck_user_id(p_user_id);
  ------------------------------
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id, util_stock.c_perm_change_in);
  ------------------------------
  util_stock.XCheck_Doc_Perms(p_user_id, util_stock.c_Doc_Type_Receipt, util_stock.c_action_Change);
  ------------------------------
  v_doc_header := document_pkg.xget_doc_header_by_doc_no(p_document_number);
  ------------------------------
  equipment_pkg.XCheck_Document_Header
  (
      p_doc_header => v_doc_header,
      p_doc_type_id => util_stock.c_Doc_Type_Receipt,
      p_stock_id_out => util_stock.c_dummy_stock_id,
      p_stock_id_in => p_stock_id,
      p_doc_status => util_stock.c_docstat_open
  );
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_single_doc(v_ss_parameters);
  ------------------------------
  equipment_pkg.setup_for_old_doc
  (
    p_params => v_ss_parameters,
    p_doc_header_from => v_doc_header,
    p_status_id => util_stock.c_docstat_open,
    p_last_user_id => p_user_id,
    p_doc_date => null
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters,
    p_break_on_error => true,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => true
  );
  ------------------------------
  equipment_pkg.legacy_setup_input_normal
  (
    p_params => v_ss_parameters,
    p_range_start_raw => p_seria_starts,
    p_range_end_raw => p_seria_ends,
    p_model => p_models,
    p_valid_until_raw => p_validity_date
  );
  ------------------------------
  equipment_pkg.Set_Operation_Equipment_Int(v_ss_parameters, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('equipment_pkg.Create_Operation_Int', p_error_code, p_error_message);
  end if;
  ------------------------------
  if p_finish
  then
    ------------------------------
    Change_Operation_State
    (
      p_document_number => p_document_number,
      p_doc_status_id => util_stock.c_docstat_finished,
      p_user_id => p_user_id,
      p_error_code => p_error_code,
      p_error_message => p_error_message
    );
    ------------------------------
  end if;
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Change_Operation_State', p_error_code, p_error_message);
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Set_Shipment_Sims
(
    p_document_number nvarchar2,
    p_serial_numbers ct_nvarchar_s,
    p_iccids ct_nvarchar_s,
    p_user_id number,
    p_open_result boolean,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_date date := sysdate;
  --
  v_ss_parameters equipment_pkg.t_ss_parameters;
  --!_!v_main_count number;
  v_doc_header doc_header%rowtype;
  --
  v_sims ct_sim;
  v_seria_starts ct_nvarchar_s;
  v_seria_ends ct_nvarchar_s;
  v_models ct_model;
  v_is_addition ct_number;
  --
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_document_number is null, 'p_document_number');
  util_pkg.XCheck_Cond_Missing(NOT util_pkg.CheckP_ct_nvarchar_s(p_serial_numbers) and NOT util_pkg.CheckP_ct_nvarchar_s(p_iccids), 'NOT util_pkg.CheckP_ct_nvarchar_s(p_serial_numbers) and NOT util_pkg.CheckP_ct_nvarchar_s(p_iccids)');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_open_result is null, 'p_open_result');
  ------------------------------
  --!_!v_main_count := p_serial_numbers.count;
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Invalid(p_serial_numbers.count != v_main_count, 'p_serial_numbers.count != v_main_count');
  --!_!util_pkg.XCheck_Cond_Invalid(p_iccids.count != v_main_count, 'p_iccids.count != v_main_count');
  ------------------------------
  util_stock.xcheck_user_id(p_user_id);
  ------------------------------
  v_doc_header := document_pkg.xget_doc_header_by_doc_no2(p_document_number, util_stock.c_docstat_open);
  ------------------------------
  --!_!not verified for other doc types therefore restricted
  ------------------------------
  if v_doc_header.doc_type_id not in
  (
    util_stock.c_Doc_Type_Receipt,
    util_stock.c_Doc_Type_Shippment,
    util_stock.c_Doc_Type_Movement,
    util_stock.c_Doc_Type_Credit,
    util_stock.c_Doc_Type_Debit
  )
  then
    util_pkg.raise_label_exception('v_doc_header.doc_type_id', util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || v_doc_header.doc_type_id);
  end if;
  ------------------------------
  util_stock.XCheck_Stock_Perms(p_user_id, v_doc_header.stock_out_id, util_stock.c_perm_change_out);
  util_stock.XCheck_Stock_Perms(p_user_id, v_doc_header.stock_in_id, util_stock.c_perm_change_in);
  ------------------------------
  util_stock.XCheck_Doc_Perms(p_user_id, v_doc_header.doc_type_id, util_stock.c_action_Change);
  ------------------------------
  ------------------------------
  v_sims := equipment_pkg.get_equipment_exact(p_serial_numbers, p_iccids, v_date);
  ------------------------------
  v_seria_starts := equipment_pkg.get_ct_sim_sns(v_sims);
  v_seria_ends := equipment_pkg.get_ct_sim_sns(v_sims);
  v_models := equipment_pkg.get_ct_sim_models(v_sims);
  ------------------------------
  v_is_addition := equipment_pkg.xsmart_make_is_addition
  (
    p_is_addition_raw => NULL,
    p_main_count => util_pkg.get_count_ct_nvarchar_s(v_seria_starts)
  );
  ------------------------------
  equipment_pkg.setup_for_single_doc(v_ss_parameters);
  ------------------------------
  equipment_pkg.setup_for_old_doc
  (
    p_params => v_ss_parameters,
    p_doc_header_from => v_doc_header,
    p_status_id => v_doc_header.status_id, --!_!util_stock.c_docstat_open,
    p_last_user_id => p_user_id,
    p_doc_date => null
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters,
    p_break_on_error => false,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => true
  );
  ------------------------------
  equipment_pkg.legacy_setup_input_set_op_eq2
  (
    p_params => v_ss_parameters,
    p_range_start_raw => v_seria_starts,
    p_range_end_raw => v_seria_ends,
    p_model => v_models,
    p_is_addition_raw => v_is_addition
  );
  ------------------------------
  equipment_pkg.Set_Operation_Equipment_Int(v_ss_parameters, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Set_Operation_Equipment_Int', p_error_code, p_error_message);
  end if;
  ------------------------------
  if p_open_result
  then
    p_result := equipment_pkg.get_result_cursor02_simple(v_ss_parameters);
  end if;
  ------------------------------
  --!_! no commit
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
  if p_result%isopen
  then
    close p_result;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Put_Away_Equipment_Range11
(
    p_stock_id number,
    p_series_start ct_nvarchar_s,
    p_series_end ct_nvarchar_s,
    p_models ct_model,
    p_user_id number,
    p_finish boolean,
    p_document_number out nvarchar2,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_doc_date date := sysdate;
  v_main_count number;
  v_ss_parameters equipment_pkg.t_ss_parameters;
  v_doc_status_id number;
  v_mark_ok ct_number;
--
  --v_valid_until ct_date;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_finish is null, 'p_finish');
  ------------------------------
  util_stock.XCheckP_ct_model(p_models, 'p_models');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_series_start);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_series_start) != v_main_count, 'p_series_start.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_series_end) != v_main_count, 'p_series_end.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_stock.get_count_ct_model(p_models) != v_main_count, 'p_models.count != v_main_count');
  ------------------------------
  util_stock.xcheck_stock_id(p_stock_id);
  util_stock.xcheck_user_id(p_user_id);
  ------------------------------
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id, util_stock.c_perm_change_out);
  ------------------------------
  util_stock.XCheck_Doc_Perms(p_user_id, util_stock.c_Doc_Type_Shippment, util_stock.c_action_Create);
  ------------------------------
  v_doc_status_id := util_stock.XFinish_To_Doc_Status(p_finish);
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_single_doc(v_ss_parameters);
  ------------------------------
  equipment_pkg.setup_for_new_doc
  (
    p_params => v_ss_parameters,
    p_doc_type_id => util_stock.c_Doc_Type_Shippment,
    p_doc_date => v_doc_date,
    p_status_id => v_doc_status_id,
    p_stock_id_out => p_stock_id,
    p_stock_id_in => util_stock.c_dummy_stock_id,
    p_user_id => p_user_id,
    p_last_user_id => p_user_id,
    p_vendor_doc => null,
    p_description => null,
    p_user_comment => null,
    p_vendor_id => null,
    p_doc_style => equipment_pkg.c_doc_style_crm
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters,
    p_break_on_error => FALSE,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => false
  );
  ------------------------------
  equipment_pkg.legacy_setup_input_normal2
  (
    p_params => v_ss_parameters,
    p_range_start_raw => p_series_start,
    p_range_end_raw => p_series_end,
    p_model => p_models
  );
  ------------------------------
  equipment_pkg.Create_Operation_Int(v_ss_parameters, p_error_code, p_error_message);
  ------------------------------
  p_error_codes := equipment_pkg.EGP_error_codes_full_size(v_ss_parameters);
  p_error_messages := equipment_pkg.EGP_error_messages_full_size(v_ss_parameters);
  ------------------------------
  v_mark_ok := util_pkg.mark_val_ct_number(p_error_codes, null, util_pkg.c_true, util_pkg.c_false);
  util_stock.setup_error_by_marks(v_mark_ok, util_pkg.c_ora_ok, util_pkg.c_msg_ok, util_pkg.c_true, p_error_codes, p_error_messages);
  ------------------------------
  util_stock.xcheck_has_error(TRUE, p_error_codes, p_error_messages);
  ------------------------------
  p_document_number := equipment_pkg.XGP_document_number(v_ss_parameters);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Put_Away_Equipment_Range12
(
    p_document_number nvarchar2,
    p_stock_id number,
    p_series_start ct_nvarchar_s,
    p_series_end ct_nvarchar_s,
    p_models ct_model,
    p_user_id number,
    p_finish boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_ss_parameters equipment_pkg.t_ss_parameters;
  v_doc_header doc_header%rowtype;
  v_mark_ok ct_number;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_document_number is null, 'p_document_number');
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_finish is null, 'p_finish');
  ------------------------------
  util_stock.XCheckP_ct_model(p_models, 'p_models');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_series_start);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_series_start) != v_main_count, 'p_series_start.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_series_end) != v_main_count, 'p_series_end.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_stock.get_count_ct_model(p_models) != v_main_count, 'p_models.count != v_main_count');
  ------------------------------
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id, util_stock.c_perm_change_out);
  ------------------------------
  util_stock.XCheck_Doc_Perms(p_user_id, util_stock.c_Doc_Type_Shippment, util_stock.c_action_Change);
  ------------------------------
  v_doc_header := document_pkg.xget_doc_header_by_doc_no(p_document_number);
  ------------------------------
  equipment_pkg.setup_for_single_doc(v_ss_parameters);
  ------------------------------
  equipment_pkg.XCheck_Document_Header
  (
      p_doc_header => v_doc_header,
      p_doc_type_id => util_stock.c_Doc_Type_Shippment,
      p_stock_id_out => p_stock_id,
      p_stock_id_in => util_stock.c_dummy_stock_id,
      p_doc_status => util_stock.c_docstat_open
  );
  ------------------------------
  equipment_pkg.setup_for_old_doc
  (
    p_params => v_ss_parameters,
    p_doc_header_from => v_doc_header,
    p_status_id => util_stock.c_docstat_open,
    p_last_user_id => p_user_id,
    p_doc_date => null
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters,
    p_break_on_error => FALSE,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => false
  );
  ------------------------------
  equipment_pkg.legacy_setup_input_normal2
  (
    p_params => v_ss_parameters,
    p_range_start_raw => p_series_start,
    p_range_end_raw => p_series_end,
    p_model => p_models
  );
  ------------------------------
  equipment_pkg.Set_Operation_Equipment_Int(v_ss_parameters, p_error_code, p_error_message);
  ------------------------------
  p_error_codes := equipment_pkg.EGP_error_codes_full_size(v_ss_parameters);
  p_error_messages := equipment_pkg.EGP_error_messages_full_size(v_ss_parameters);
  ------------------------------
  v_mark_ok := util_pkg.mark_val_ct_number(p_error_codes, null, util_pkg.c_true, util_pkg.c_false);
  util_stock.setup_error_by_marks(v_mark_ok, util_pkg.c_ora_ok, util_pkg.c_msg_ok, util_pkg.c_true, p_error_codes, p_error_messages);
  ------------------------------
  util_stock.xcheck_has_error(TRUE, p_error_codes, p_error_messages);
  ------------------------------
  if p_finish
  then
    ------------------------------
    Change_Operation_State
    (
      p_document_number => p_document_number,
      p_doc_status_id => util_stock.c_docstat_finished,
      p_user_id => p_user_id,
      p_error_code => p_error_code,
      p_error_message => p_error_message
    );
    ------------------------------
  end if;
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    util_pkg.raise_label_exception('Change_Operation_State', p_error_code, p_error_message);
  end if;
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_sim_cards_info
(
    p_stock_code nvarchar2,
    p_series_start ct_nvarchar_s,
    p_series_end ct_nvarchar_s,
    p_linked boolean,
    p_user_id number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
  v_stock_id number;
  v_stock_ids ct_number;
  v_serial_numbers ct_nvarchar_s;
  v_main_count number;
  --
  v_model_ids ct_number;
  v_models ct_model;
  v_ss_ids ct_number;
  v_ss_stock_ids ct_number;
  v_ss_model_ids ct_number;
  v_full_numbers ct_nvarchar_s;
  v_msisdns_ri ct_varchar_s;
  --
  v_dh_ids ct_number;
  --
  v_access_denied2not_found boolean;
  --
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_stock_code is null, 'p_stock_code');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_pkg.XCheckP_FS_ct_nvarchar_s(p_series_start, 'p_series_start');
  ------------------------------
  v_access_denied2not_found := install_pkg.nnget_option_bool(c_opt_access_denied2not_found, true);
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_series_start);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_series_start) != v_main_count, 'p_series_start.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_series_end) != v_main_count, 'p_series_end.count != v_main_count');
  ------------------------------
  v_stock_id := util_stock.get_stock_id2(p_stock_code, v_date);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_stock_id is null, 'p_stock_code');
  ------------------------------
  util_stock.xis_avail_stock(p_user_id, util_stock.c_perm_view, v_stock_id, v_date);
  ------------------------------
  util_pkg.add_ct_number_val(v_stock_ids, v_stock_id);
  ------------------------------
  v_serial_numbers := util_stock.split_ranges3(p_series_start, p_series_end);
  ------------------------------
  v_model_ids := util_stock.get_equipment_model_ids_all(v_date);
  v_models := util_stock.get_ct_model2_fuzzy(v_model_ids, v_date);
  ------------------------------
  search_pkg.seek_active_single_eq_ii --!_!
  (
    p_serial_number => v_serial_numbers,
    p_stock_id => v_stock_ids,
    p_eq_model_id => v_model_ids,
    p_count => util_stock.c_any_count, --!_!
    p_trim_empty => FALSE, --!_!
    p_ss_id => v_ss_ids,
    p_stock_id2 => v_ss_stock_ids,
    p_eq_model_id2 => v_ss_model_ids
  );
  ------------------------------
  v_full_numbers := util_stock.get_sims_full_number_i(v_serial_numbers, FALSE, FALSE);
  ------------------------------
  v_msisdns_ri := util_stock.get_ri_phone_number_i(util_pkg.cast_ct_nvarchar_s2varchar_s(v_full_numbers), v_date, FALSE, FALSE);
  ------------------------------
  v_dh_ids := util_stock.get_last_dh2_i(v_serial_numbers, FALSE);
  ------------------------------
  legacy_pkg.get_result_cursor05
  (
    p_serial_number => v_serial_numbers,
    p_ss_id => v_ss_ids,
    p_ss_stock_id => v_ss_stock_ids,
    p_ss_model_id => v_ss_model_ids,
    p_msisdn => v_msisdns_ri,
    p_last_dh_id => v_dh_ids,
    p_model => v_models,
    p_linked => p_linked,
    p_date => v_date,
    p_access_denied2not_found => v_access_denied2not_found,
    p_result => p_result
  );
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;
----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure receive_eqm_by_iccid
(
    p_equipment_code ct_varchar_s,
    p_iccid ct_nvarchar_s,
    p_stock_code varchar2,
    p_valid_until date,
    p_user_id number,
    p_finish boolean,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_main_count number;
  v_date date := sysdate;
  v_valid_until ct_date;
  v_stock_id number;
  v_sn ct_nvarchar_s;
  v_models ct_model;
begin
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
  util_pkg.XCheckP_FS_ct_varchar_s(p_equipment_code, 'p_equipment_code');
  util_pkg.XCheckP_FSU_ct_nvarchar_s(p_iccid, 'p_iccid');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_varchar_s(p_equipment_code);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_varchar_s(p_equipment_code) != v_main_count, 'p_equipment_code.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_iccid) != v_main_count, 'p_iccid.count != v_main_count');
  ------------------------------
  v_stock_id := util_stock.get_stock_id2(p_stock_code, sysdate);
  if v_stock_id is null
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_stock_not_exists, util_loc_pkg.c_msg_stock_not_exists);
  end if;
  ------------------------------
  util_stock.xis_avail_stock(p_user_id, util_stock.c_perm_change, v_stock_id, sysdate);
  ------------------------------
  v_sn := util_stock.make_sn_from_full_number(p_iccid);
  v_models := util_stock.get_ct_model_exact(p_equipment_code, v_date);
  ------------------------------
  if util_stock.is_nulls_ct_model(v_models)
  then
    util_pkg.raise_exception(util_loc_pkg.c_ora_equipment_not_found, util_loc_pkg.c_msg_equipment_not_found);
  end if;
  ------------------------------
  v_valid_until := util_pkg.make_ct_date(v_main_count, p_valid_until);
  ------------------------------
  receive_equipment
  (
    p_seria_starts => v_sn,
    p_seria_ends => v_sn,
    p_models => v_models,
    p_validity_date => v_valid_until,
    p_stock_id => v_stock_id,
    p_vendor_doc => null,
    p_finish => p_finish,
    p_user_id => p_user_id,
    p_document_number => p_document_number,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure find_stocks
(
    p_stock_groups ct_number,
    p_user_id number,
    p_stock_group_ids out ct_number,
    p_stock_ids out ct_number,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_date date := sysdate;
  v_stocks ct_node;
  v_group_ids ct_number;
  v_stock_ids ct_number;

  v_group_ids02 ct_number;
  v_group_ids03 ct_number;
  v_mark ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_stock_groups);
  ------------------------------
  v_stocks := util_stock.get_stock_perms_i(p_user_id, v_date, util_stock.c_perm_not_none, true);
  ------------------------------
  select id, parent_id bulk collect into v_stock_ids, v_group_ids from table(v_stocks);
  ------------------------------
  v_group_ids02 := util_stock.get_groups_with_ancestors_i(v_group_ids);
  ------------------------------
  v_group_ids03 := util_stock.get_groups_with_descendants_i(p_stock_groups);
  ------------------------------
  p_stock_group_ids := util_pkg.filter_val_ct_number(v_group_ids02, v_group_ids03, TRUE);
  ------------------------------
  v_mark := util_pkg.mark_ct_number(v_group_ids, p_stock_group_ids);
  p_stock_ids := util_pkg.get_marked_ct_number(v_stock_ids, v_mark, TRUE);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure series_distribution
(
    p_partition boolean,
    p_seria_starts_src ct_nvarchar_s,
    p_seria_ends_src ct_nvarchar_s,
    p_models_src ct_model,
    p_seria_starts_dst ct_nvarchar_s,
    p_seria_ends_dst ct_nvarchar_s,
    p_models_dst ct_model,
    p_stock_id number,
    p_finish boolean,
    p_user_id number,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_sp_name varchar2(30);
  v_doc_date date := sysdate;
  v_ss_parameters equipment_pkg.t_ss_parameters;
  v_doc_status_id number;
  v_main_count1 number;
  v_main_count2 number;
  v_doc_type_id number;
  v_range_start_src ct_nvarchar_s;
  v_range_end_src ct_nvarchar_s;
  v_quantity_src ct_number;
  v_range_start_dst ct_nvarchar_s;
  v_range_end_dst ct_nvarchar_s;
  v_quantity_dst ct_number;
begin
  ------------------------------
  ------------------------------
  v_sp_name := util_sys_pkg.make_savepoint;
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_partition is null, 'p_partition');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_starts_src, 'p_seria_starts_src');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_ends_src, 'p_seria_ends_src');
  util_stock.XCheckP_ct_model(p_models_src, 'p_models_src');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_starts_dst, 'p_seria_starts_dst');
  util_pkg.XCheckP_ct_nvarchar_s(p_seria_ends_dst, 'p_seria_ends_dst');
  util_stock.XCheckP_ct_model(p_models_dst, 'p_models_dst');
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  util_pkg.XCheck_Cond_Missing(p_finish is null, 'p_finish');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  ------------------------------
  v_main_count1 := util_pkg.get_count_ct_nvarchar_s(p_seria_starts_src);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_starts_src) != v_main_count1, 'p_seria_starts_src.count != v_main_count1');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_ends_src) != v_main_count1, 'p_seria_ends_src.count != v_main_count1');
  util_pkg.XCheck_Cond_Invalid(util_stock.get_count_ct_model(p_models_src) != v_main_count1, 'p_models_src.count != v_main_count1');
  ------------------------------
  v_main_count2 := util_pkg.get_count_ct_nvarchar_s(p_seria_starts_dst);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_starts_dst) != v_main_count2, 'p_seria_starts_dst.count != v_main_count2');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_seria_ends_dst) != v_main_count2, 'p_seria_ends_dst.count != v_main_count2');
  util_pkg.XCheck_Cond_Invalid(util_stock.get_count_ct_model(p_models_dst) != v_main_count2, 'p_models_dst.count != v_main_count2');
  ------------------------------
  util_stock.xcheck_stock_id(p_stock_id);
  util_stock.xcheck_user_id(p_user_id);
  ------------------------------
  util_stock.XCheck_Stock_Perms(p_user_id, p_stock_id, util_stock.c_perm_change);
  ------------------------------
  v_doc_type_id := util_stock.XPartition_To_Doc_Type(p_partition);
  ------------------------------
  util_stock.XCheck_Doc_Perms(p_user_id, util_stock.c_Doc_Type_Movement, util_stock.c_action_Create);
  ------------------------------
  v_doc_status_id := util_stock.XFinish_To_Doc_Status(p_finish);
  ------------------------------
  ------------------------------
  equipment_pkg.setup_for_single_doc(v_ss_parameters);
  ------------------------------
  equipment_pkg.xsmart_make_range_and_quantity
  (
    p_range_start_raw => p_seria_starts_src,
    p_range_end_raw => p_seria_ends_src,
    p_model => p_models_src,
    p_o_range_start => v_range_start_src,
    p_o_range_end => v_range_end_src,
    p_o_quantity => v_quantity_src
  );
  ------------------------------
  equipment_pkg.xsmart_make_range_and_quantity
  (
    p_range_start_raw => p_seria_starts_dst,
    p_range_end_raw => p_seria_ends_dst,
    p_model => p_models_dst,
    p_o_range_start => v_range_start_dst,
    p_o_range_end => v_range_end_dst,
    p_o_quantity => v_quantity_dst
  );
  ------------------------------
  equipment_pkg.setup_for_new_doc
  (
    p_params => v_ss_parameters,
    p_doc_type_id => v_doc_type_id,
    p_doc_date => v_doc_date,
    p_status_id => v_doc_status_id,
    p_stock_id_out => p_stock_id,
    p_stock_id_in => p_stock_id,
    p_user_id => p_user_id,
    p_last_user_id => p_user_id,
    p_vendor_doc => null,
    p_description => null,
    p_user_comment => null,
    p_vendor_id => null,
    p_doc_style => equipment_pkg.c_doc_style_gui
  );
  ------------------------------
  equipment_pkg.setup_additional2
  (
    p_params => v_ss_parameters,
    p_break_on_error => true,
    p_eq_status_final => equipment_pkg.c_eq_status_not_spec,
    p_prematurely_populate => false
  );
  ------------------------------
  equipment_pkg.setup_input_src_dst2
  (
    p_params => v_ss_parameters,
    p_range_start_src => v_range_start_src,
    p_range_end_src => v_range_end_src,
    p_quantity_src => v_quantity_src,
    p_model_src => p_models_src,
    p_range_start_dst => v_range_start_dst,
    p_range_end_dst => v_range_end_dst,
    p_quantity_dst => v_quantity_dst,
    p_model_dst => p_models_dst
  );
  ------------------------------
  equipment_pkg.Create_Operation_Int(v_ss_parameters, p_error_code, p_error_message);
  ------------------------------
  if util_pkg.is_error(p_error_code)
  then
    ------------------------------
    p_document_number := null;
    ------------------------------
    ------------------------------
    util_sys_pkg.rollback_savepoint(v_sp_name);
    ------------------------------
    ------------------------------
  else
    ------------------------------
    p_document_number := equipment_pkg.XGP_document_number(v_ss_parameters);
      ------------------------------
    --!_! no commit
    ------------------------------
  end if;
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  p_document_number := null;
  ------------------------------
  ------------------------------
  util_sys_pkg.rollback_savepoint(v_sp_name);
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure check_overlapped_stock_state
(
    p_pev_doc_header_id number,
    p_doc_type_id number,
    p_doc_status_id number,
    p_series_start ct_nvarchar_s,
    p_series_end ct_nvarchar_s,
    p_model_ids ct_number,
    p_error_code out number,
    p_error_message out varchar2
)
is
  v_range_check ct_range;
  v_range_err ct_range;
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  util_pkg.XCheck_Cond_Missing(p_doc_status_id is null, 'p_doc_status_id');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_series_start);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_series_start) != v_main_count, 'p_series_start.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_series_end) != v_main_count, 'p_model_codes.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_model_ids) != v_main_count, 'p_model_ids.count != v_main_count');
  ------------------------------
  v_range_check := util_stock.make_ct_range2
  (
    p_val1 => p_series_start,
    p_val2 => p_series_end,
    p_num1 => p_model_ids
  );
  ------------------------------
  if p_doc_type_id = util_stock.c_Doc_Type_Receipt
  then
    ------------------------------
    v_range_err := equipment_pkg.get_overlap_stock_state1
    (
      p_range => v_range_check,
      p_ignore_model => util_stock.GS_ignore_model_type,
      p_doc_status_id => p_doc_status_id,
      p_prev_doc_header_id => p_pev_doc_header_id,
      p_4_nl_max_row_count => equipment_pkg.GS_max_serial_range_count
    );
    ------------------------------
    if util_stock.get_count_ct_range(v_range_err) > 0
    then
      ------------------------------
      p_error_code := legacy_pkg.clg_ora_duplicated_equipment;
      ------------------------------
      equipment_pkg.Error_Range2Str
      (
        p_range_err => v_range_err,
        p_error_ranges_str => p_error_message
      );
      ------------------------------
      return;
      ------------------------------
    end if;
    ------------------------------
    v_range_err := equipment_pkg.get_overlap_stock_state2
    (
      p_range => v_range_err,
      p_ignore_model => util_stock.GS_ignore_model_type,
      p_doc_status_id => p_doc_status_id,
      p_prev_doc_header_id => p_pev_doc_header_id
    );
    ------------------------------
    if util_stock.get_count_ct_range(v_range_err) > 0
    then
      ------------------------------
      p_error_code := legacy_pkg.clg_ora_duplicated_equipment;
      ------------------------------
      equipment_pkg.Error_Range2Str
      (
        p_range_err => v_range_err,
        p_error_ranges_str => p_error_message
      );
      ------------------------------
      return;
      ------------------------------
    end if;
    ------------------------------
    v_range_err := equipment_pkg.get_overlap_stock_state3
    (
      p_range => v_range_check,
      p_ignore_model => util_stock.GS_ignore_model_type,
      p_doc_status_id => p_doc_status_id,
      p_prev_doc_header_id => p_pev_doc_header_id
    );
    ------------------------------
    if util_stock.get_count_ct_range(v_range_err) > 0
    then
      ------------------------------
      p_error_code := legacy_pkg.clg_ora_duplicated_equipment;
      ------------------------------
      equipment_pkg.Error_Range2Str
      (
        p_range_err => v_range_err,
        p_error_ranges_str => p_error_message
      );
      ------------------------------
      return;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
