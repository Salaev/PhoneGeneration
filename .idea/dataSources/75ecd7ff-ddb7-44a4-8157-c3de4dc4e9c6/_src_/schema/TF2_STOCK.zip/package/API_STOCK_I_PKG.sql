CREATE package api_stock_i_pkg is

----------------------------------!---------------------------------------------
  c_opt_access_denied2not_found  constant nvarchar2(50) := 'ACCESS_DENIED2NOT_FOUND_ON_STOCK';
----------------------------------!---------------------------------------------
  procedure Get_Operation_Equipment
  (
    p_document_number nvarchar2,
    p_only_active boolean,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Get_Total_Equipment
  (
    p_document_number nvarchar2,
    p_total_equipment out number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure Get_Doc_State_By_DocNo
  (
    p_document_number nvarchar2,
    p_doc_state out number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure Move_Range_Of_Equipment
  (
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_stock_id_out number,
    p_stock_id_in number,
    p_finish boolean,
    p_user_id number,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Change_Model_Of_Equipment
  (
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models_out ct_model,
    p_models_in ct_model,
    p_stock_id_out number,
    p_stock_id_in number,
    p_valid_until_new date,
    p_finish boolean,
    p_user_id number,
    p_document_number_out out nvarchar2,
    p_document_number_in out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure Create_Empty_Document
  (
    p_doc_type_id number,
    p_stock_id_out number,
    p_stock_id_in number,
    p_comment nvarchar2,
    p_user_id number,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Create_Empty_Document_Lnk2
  (
    p_doc_type_id1 number,
    p_doc_type_id2 number,
    p_stock_id_out1 number,
    p_stock_id_out2 number,
    p_stock_id_in1 number,
    p_stock_id_in2 number,
    p_comment1 nvarchar2,
    p_comment2 nvarchar2,
    p_user_id number,
    p_document_number1 out nvarchar2,
    p_document_number2 out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Set_Operation_Equipment_i
  (
    p_document_number nvarchar2,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_is_addition ct_number,
    p_valid_until ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_ss_parameters out equipment_pkg.t_ss_parameters,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Set_Operation_Equipment1
  (
    p_document_number nvarchar2,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_is_addition ct_number,
    p_valid_until ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Set_Operation_Equipment2
  (
    p_document_number nvarchar2,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_is_addition ct_number,
    p_valid_until ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Set_Operation_Equipment3
  (
    p_document_number nvarchar2,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_is_addition ct_number,
    p_valid_until ct_date,
    p_user_id number,
    p_break_on_error boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Set_Operation_Equipment_Lnk2
  (
    p_symmetric boolean,
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_seria_starts1 ct_nvarchar_s,
    p_seria_starts2 ct_nvarchar_s,
    p_seria_ends1 ct_nvarchar_s,
    p_seria_ends2 ct_nvarchar_s,
    p_models1 ct_model,
    p_models2 ct_model,
    p_is_addition1 ct_number,
    p_is_addition2 ct_number,
    p_valid_until1 ct_date,
    p_valid_until2 ct_date,
    p_user_id number,
    p_open_result boolean,
    p_break_on_error boolean,
    p_result1 out sys_refcursor,
    p_result2 out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Set_Op_Eq_Symmetric_Lnk2
  (
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models1 ct_model,
    p_models2 ct_model,
    p_is_addition ct_number,
    p_valid_until ct_date,
    p_user_id number,
    p_open_result boolean,
    p_break_on_error boolean,
    p_result1 out sys_refcursor,
    p_result2 out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Set_Op_Eq_Non_Symmetric_Lnk2
  (
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_seria_starts1 ct_nvarchar_s,
    p_seria_starts2 ct_nvarchar_s,
    p_seria_ends1 ct_nvarchar_s,
    p_seria_ends2 ct_nvarchar_s,
    p_models1 ct_model,
    p_models2 ct_model,
    p_is_addition1 ct_number,
    p_is_addition2 ct_number,
    p_valid_until1 ct_date,
    p_valid_until2 ct_date,
    p_user_id number,
    p_open_result boolean,
    p_break_on_error boolean,
    p_result1 out sys_refcursor,
    p_result2 out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Change_Operation_State
  (
    p_document_number nvarchar2,
    p_doc_status_id number,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Change_Operation_State_Lnk2
  (
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_doc_status_id number,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Finalize_Document
  (
    p_document_number nvarchar2,
    p_user_id number := null,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Finalize_Document_Lnk2
  (
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_user_id number := null,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Cancel_Document
  (
    p_document_number nvarchar2,
    p_user_id number := null,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Cancel_Document_Lnk2
  (
    p_document_number1 nvarchar2,
    p_document_number2 nvarchar2,
    p_user_id number := null,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure receive_equipment
  (
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_validity_date ct_date,
    p_stock_id number,
    p_vendor_doc nvarchar2,
    p_finish boolean,
    p_user_id number,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure receive_equipment2
  (
    p_document_number nvarchar2,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_validity_date ct_date,
    p_stock_id number,
    p_finish boolean,
    p_user_id number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure Set_Shipment_Sims
  (
    p_document_number nvarchar2,
    p_serial_numbers ct_nvarchar_s,
    p_iccids ct_nvarchar_s,
    p_user_id number,
    p_open_result boolean,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure Put_Away_Equipment_Range11
  (
    p_stock_id number,
    p_series_start ct_nvarchar_s,
    p_series_end ct_nvarchar_s,
    p_models ct_model,
    p_user_id number,
    p_finish boolean,
    p_document_number out nvarchar2,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure Put_Away_Equipment_Range12
  (
    p_document_number nvarchar2,
    p_stock_id number,
    p_series_start ct_nvarchar_s,
    p_series_end ct_nvarchar_s,
    p_models ct_model,
    p_user_id number,
    p_finish boolean,
    p_error_codes out ct_number,
    p_error_messages out ct_varchar,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure find_sim_cards_info
  (
    p_stock_code nvarchar2,
    p_series_start ct_nvarchar_s,
    p_series_end ct_nvarchar_s,
    p_linked boolean,
    p_user_id number,
    p_result out sys_refcursor,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure receive_eqm_by_iccid
  (
    p_equipment_code ct_varchar_s,
    p_iccid ct_nvarchar_s,
    p_stock_code varchar2,
    p_valid_until date,
    p_user_id number,
    p_finish boolean,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

  procedure find_stocks
  (
    p_stock_groups ct_number,
    p_user_id number,
    p_stock_group_ids out ct_number,
    p_stock_ids out ct_number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure series_distribution
  (
    p_partition boolean,
    p_seria_starts_src ct_nvarchar_s,
    p_seria_ends_src ct_nvarchar_s,
    p_models_src ct_model,
    p_seria_starts_dst ct_nvarchar_s,
    p_seria_ends_dst ct_nvarchar_s,
    p_models_dst ct_model,
    p_stock_id number,
    p_finish boolean,
    p_user_id number,
    p_document_number out nvarchar2,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
  procedure check_overlapped_stock_state
  (
    p_pev_doc_header_id number,
    p_doc_type_id number,
    p_doc_status_id number,
    p_series_start ct_nvarchar_s,
    p_series_end ct_nvarchar_s,
    p_model_ids ct_number,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
end;
/
