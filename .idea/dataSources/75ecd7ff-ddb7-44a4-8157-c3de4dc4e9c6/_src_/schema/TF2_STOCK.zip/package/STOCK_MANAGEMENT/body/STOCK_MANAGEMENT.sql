CREATE PACKAGE BODY stock_management
AS
/****************************************************************************
<name>          package_
<author>        Petar Ulic
<version>       1.0   04.12.2003 basic Oracle implementation
<Description>   Package contains functions and procedures for stock and stock
                groups management in Stock system
<Application>   Stock Management
-- Purpose : Предназначен для работы с STOCK-ом
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ------------------------------------------
-- Petr Skripnik   09.11.2006  Изменен
-- Skripnik Petr   10.07.2007  version 1.11.9.0
****************************************************************************/
   pkg_name   CONSTANT NVARCHAR2 (50) := 'stock_management.';   --имя пакета

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_is_unused (p_id NUMBER, p_handle_tran CHAR := 'Y', p_error_code OUT NUMBER)
   AS
      p_count1   NUMBER;
   BEGIN
      util_loc_pkg.touch_varchar(p_handle_tran);

      SELECT COUNT (*)
        INTO p_count1
        FROM stock_state
       WHERE stock_id = p_id;

      IF p_count1 > 0
      THEN
         p_error_code := -88888;
      ELSE
         p_error_code := 0;
      END IF;
   END;

/****************************************************************************
<name>          STOCK_GROUP__Ins
<author>        Petar Ulic
<version>       1.1   06.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_stock_group_id NUMBER
                p_name NVARCHAR2
                p_description NVARCHAR2
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
                p_id OUT NUMBER
****************************************************************************/
--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_group__ins (
      p_sa                     NVARCHAR2,
      p_stock_group_id         NUMBER,
      p_name                   NVARCHAR2,
      p_description            NVARCHAR2,
      p_handle_tran            CHAR := 'Y',
      p_error_code       OUT   NUMBER,
      p_id               OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      description   NVARCHAR2 (255);
   BEGIN
      p_error_code := 0;
      p_id := s_stock_group.nextval;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      INSERT INTO stock_group
           VALUES (p_id, p_stock_group_id, p_name, p_description, 0);

      SELECT p_name || ';' || p_description
        INTO description
        FROM DUAL;

      util_stock.log_log(p_sa, util_stock.c_la_stock_group_create, p_id, description);

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stock_group__ins;

/****************************************************************************
<name>          STOCK_GROUP__Upd
<author>        Petar Ulic
<version>       1.1   06.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id_old NUMBER
                p_id NUMBER
                p_name NVARCHAR2
                p_description NVARCHAR2
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE stock_group__upd (
      p_sa                  NVARCHAR2,
      p_id_old              NUMBER,
      p_id                  NUMBER,
      p_name                NVARCHAR2,
      p_description         NVARCHAR2,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      description   NVARCHAR2 (255);
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      UPDATE stock_group
         SET ID = p_id,
             NAME = p_name,
             description = p_description
       WHERE ID = p_id_old;

      SELECT p_id || ';' || p_name || ';' || p_description
        INTO description
        FROM DUAL;

      util_stock.log_log(p_sa, util_stock.c_la_stock_group_modify, p_id_old, description);

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stock_group__upd;

/****************************************************************************
<name>          STOCK_GROUP__Del
<author>        Petar Ulic
<version>       1.1   06.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE stock_group__del (
      p_sa                  NVARCHAR2,
      p_id                  NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      p_name   NVARCHAR2 (255);
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      SELECT NAME
        INTO p_name
        FROM stock_group
       WHERE ID = p_id;

      DELETE FROM stock_group_permission
            WHERE stock_group_id = p_id;

      DELETE FROM stock_group
            WHERE ID = p_id;

      util_stock.log_log(p_sa, util_stock.c_la_stock_group_delete, p_id, p_name);

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stock_group__del;

/****************************************************************************
<name>          STOCK_GROUP__Get
<author>        Petar Ulic
<version>       1.1   06.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_stock_group_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE stock_group__get (p_id NUMBER, p_stock_group_rec OUT t_cursor, p_error_code OUT NUMBER)
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_stock_group_rec FOR
         SELECT *
           FROM stock_group
          WHERE (ID = p_id) OR (p_id = 0);
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END stock_group__get;

/****************************************************************************
<name>          STOCK__Ins_Ext
<author>        Dejan Spegar
<version>       1.0   06.04.2004 basic Oracle implementation
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id OUT NUMBER
                p_stock_group_id NUMBER
                p_name NVARCHAR2
                p_tel NVARCHAR2
                p_fax NVARCHAR2
                p_email NVARCHAR2
                p_address NVARCHAR2
                p_zip NVARCHAR2
                p_description NVARCHAR2
                p_code NVARCHAR2
                p_crm_unique NVARCHAR2
                p_stock_type NUMBER
                p_stock_owner NVARCHAR2
                p_stock_manager NVARCHAR2
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE stock__ins_ext (
      p_sa                     NVARCHAR2,
      p_id               OUT   NUMBER,
      p_stock_group_id         NUMBER,
      p_name                   NVARCHAR2,
      p_tel                    NVARCHAR2,
      p_fax                    NVARCHAR2,
      p_email                  NVARCHAR2,
      p_address                NVARCHAR2,
      p_zip                    NVARCHAR2,
      p_description            NVARCHAR2,
      p_code                   NVARCHAR2,
      p_crm_unique             NVARCHAR2,
      p_stock_type             NUMBER,
      p_stock_owner            NVARCHAR2,
      p_stock_manager          NVARCHAR2,
      p_doc_valid_days         NUMBER,
      p_handle_tran            CHAR := 'Y',
      p_error_code       OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      description   NVARCHAR2 (255);
      gname         NVARCHAR2 (255);
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      INSERT INTO stock
                  (ID, stock_group_id, NAME, tel, fax, email, address, zip,
                   description, inherited, code, crm_unique_number, stock_type, stock_owner,
                   stock_manager, doc_valid_days
                  )
           VALUES (p_id, p_stock_group_id, p_name, p_tel, p_fax, p_email, p_address, p_zip,
                   p_description, 0, p_code, p_crm_unique, p_stock_type, p_stock_owner,
                   p_stock_manager, p_doc_valid_days
                  );

      SELECT s_stock.CURRVAL
        INTO p_id
        FROM DUAL;

      SELECT NAME
        INTO gname
        FROM stock_group
       WHERE ID = p_stock_group_id;

      SELECT p_id || ';' || p_code || ';' || gname || ';' || p_name || ';' || p_description
        INTO description
        FROM DUAL;

      util_stock.log_log(p_sa, util_stock.c_la_stock_create, p_id, description);

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stock__ins_ext;

/****************************************************************************
<name>          STOCK__Upd_Ext
<author>        Dejan Spegar
<version>       1.0   06.04.2004 basic Oracle implementation
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id_old NUMBER
                p_id NUMBER
                p_stock_group_id NUMBER
                p_name NVARCHAR2
                p_tel NVARCHAR2
                p_fax NVARCHAR2
                p_email NVARCHAR2
                p_address NVARCHAR2
                p_zip NVARCHAR2
                p_description NVARCHAR2
                p_inherited NUMBER
                p_crm_unique NVARCHAR2
                p_stock_type NUMBER
                p_stock_owner NVARCHAR2
                p_stock_manager NVARCHAR2
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE stock__upd_ext (
      p_sa                     NVARCHAR2,
      p_id_old                 NVARCHAR2,
      p_id                     NVARCHAR2,
      p_stock_group_id         NUMBER,
      p_name                   NVARCHAR2,
      p_tel                    NVARCHAR2,
      p_fax                    NVARCHAR2,
      p_email                  NVARCHAR2,
      p_address                NVARCHAR2,
      p_zip                    NVARCHAR2,
      p_description            NVARCHAR2,
      p_inherited              NUMBER,
      p_crm_unique             NVARCHAR2,
      p_stock_type             NUMBER,
      p_stock_owner            NVARCHAR2,
      p_stock_manager          NVARCHAR2,
      p_doc_valid_days         NUMBER,
      p_handle_tran            CHAR := 'Y',
      p_error_code       OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      p_sid         NUMBER;
      gname         NVARCHAR2 (255);
      description   NVARCHAR2 (255);
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      SELECT ID
        INTO p_sid
        FROM stock
       WHERE code = p_id_old;

      UPDATE stock
         SET stock_group_id = p_stock_group_id,
             NAME = p_name,
             tel = p_tel,
             fax = p_fax,
             email = p_email,
             address = p_address,
             zip = p_zip,
             description = p_description,
             inherited = p_inherited,
             crm_unique_number = p_crm_unique,
             stock_type = p_stock_type,
             stock_owner = p_stock_owner,
             stock_manager = p_stock_manager,
             doc_valid_days = p_doc_valid_days
       WHERE code = p_id;

      -- update STOCK_GROUP_PERMISSIONS
      UPDATE stock_group_permission
         SET stock_group_id = p_stock_group_id
       WHERE stock_id = p_sid;

      SELECT NAME
        INTO gname
        FROM stock_group
       WHERE ID = p_stock_group_id;

      SELECT p_sid || ';' || p_id || ';' || gname || ';' || p_name || ';' || p_description
        INTO description
        FROM DUAL;

      util_stock.log_log(p_sa, util_stock.c_la_stock_modify, p_sid, description);

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stock__upd_ext;

/****************************************************************************
<name>          STOCK__Set_Constants
<author>        Dejan Spegar
<version>       1.0   17.01.2004 basic Oracle implementation
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_stock_id NUMBER
                p_max_series_qty NUMBER
                p_alert_series_qty NUMBER
                p_validation_date NUMBER
                p_fiscale_date DATE
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE stock__set_constants (
      p_stock_id                 NUMBER,
      p_max_series_qty           NUMBER,
      p_alert_series_qty         NUMBER,
      p_validation_date          NUMBER,
      p_fiscale_date             DATE,
      p_handle_tran              CHAR := 'Y',
      p_error_code         OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      UPDATE stock
         SET max_series_qty = p_max_series_qty,
             alert_series_qnt = p_alert_series_qty,
             validation_date = p_validation_date,
             fiscale_date = p_fiscale_date
       WHERE ID = p_stock_id;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stock__set_constants;

/****************************************************************************
<name>          STOCK__Del
<author>        Petar Ulic
<version>       1.3   12.10.2004 added deletion of alarm record related to stock
                        1.2   25.12.2003 added deleting related records from stock group premissions
                1.1   06.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE stock__del (
      p_sa                  NVARCHAR2,
      p_id                  NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      sname              NVARCHAR2 (255);
      scode              NVARCHAR2 (255);
      gname              NVARCHAR2 (255);
      p_stock_group_id   NUMBER;
      description        NVARCHAR2 (255);
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      SELECT NAME, code, stock_group_id
        INTO sname, scode, p_stock_group_id
        FROM stock
       WHERE ID = p_id;

      SELECT NAME
        INTO gname
        FROM stock_group
       WHERE ID = p_stock_group_id;

      IF p_error_code = 0
      THEN
         UPDATE stock
            SET deleted = CURRENT_TIMESTAMP
          WHERE ID = p_id;

         SELECT p_id || ';' || scode || ';' || gname || ';' || sname
           INTO description
           FROM DUAL;

         util_stock.log_log(p_sa, util_stock.c_la_stock_delete, p_id, description);

         IF p_handle_tran = 'Y'
         THEN
            COMMIT;
         END IF;
      ELSE
         ROLLBACK;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stock__del;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock__rest (
      p_sa                  NVARCHAR2,
      p_id                  NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
      sname              NVARCHAR2 (255);
      scode              NVARCHAR2 (255);
      gname              NVARCHAR2 (255);
      p_stock_group_id   NUMBER;
      description        NVARCHAR2 (255);
   BEGIN
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      SELECT NAME, code, stock_group_id
        INTO sname, scode, p_stock_group_id
        FROM stock
       WHERE ID = p_id;

      SELECT NAME
        INTO gname
        FROM stock_group
       WHERE ID = p_stock_group_id;

      IF p_error_code = 0
      THEN
         UPDATE stock
            SET deleted = NULL
          WHERE ID = p_id;

         SELECT p_id || ';' || scode || ';' || gname || ';' || sname
           INTO description
           FROM DUAL;

         util_stock.log_log(p_sa, util_stock.c_la_stock_restore, p_id, description);

         IF p_handle_tran = 'Y'
         THEN
            COMMIT;
         END IF;
      ELSE
         ROLLBACK;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stock__rest;

/****************************************************************************
<name>          STOCK__Get
<author>        Petar Ulic
<version>       1.1   06.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_stock_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE stock__get (p_id NUMBER, p_stock_rec OUT t_cursor, p_error_code OUT NUMBER)
   IS
   BEGIN
      p_error_code := 0;

      IF p_id = 0
      THEN
         OPEN p_stock_rec FOR
            SELECT ID, stock_group_id, NAME, tel, fax, email, address, zip, description, inherited,
                   max_series_qty, alert_series_qnt, validation_date, fiscale_date, code,
                   crm_unique_number, stock_type, stock_owner, stock_manager, deleted,
                   doc_valid_days, is_processed
              FROM stock
             WHERE deleted IS NULL;
      ELSE
         OPEN p_stock_rec FOR
            SELECT /*+ INDEX(STOCK PK_STOCK) */
                   *
              FROM stock
             WHERE ID = p_id AND deleted IS NULL;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END stock__get;

/****************************************************************************
<name>          STOCK__Get_Tree
<author>        Petar Ulic
<version>       1.1   06.12.2003 basic Oracle implementation
                1.0   10.11.2003 basic MS SQL version
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_stock_tree_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE stock__get_tree (p_stock_tree_rec OUT t_cursor, p_error_code OUT NUMBER)
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_stock_tree_rec FOR
         SELECT parent_id, GROUP_ID, group_name, stock_id, stock_name, stock_code, stock_type,
                owner, manager, address, zip, tel, fax, e_mail, description, deleted
           FROM vw_stock_tree;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END stock__get_tree;

/****************************************************************************
<name>          STOCK__Get_Code
<author>        Dejan Spegar
<version>       1.1   20.2.2004 basic Oracle implementation
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_code NVARCHAR2
                p_stock_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE stock__get_code (
      p_id                 NUMBER,
      p_code               NVARCHAR2,
      p_stock_rec    OUT   t_cursor,
      p_error_code   OUT   NUMBER
   )
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_stock_rec FOR
         SELECT ID, stock_group_id, NAME, tel, fax, email, address, zip, description, inherited,
                max_series_qty, alert_series_qnt, validation_date, fiscale_date, code,
                crm_unique_number, stock_type, stock_owner, stock_manager, deleted, doc_valid_days,
                is_processed
           FROM stock
          WHERE ((ID = p_id) OR (p_id = -1))
            AND ((code = p_code) OR (p_code IS NULL))
            AND deleted IS NULL;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;
   END stock__get_code;

-- Distribution templates
   /****************************************************************************
<name>          DISTRIBUTION_TEMPLATE__Ins
<author>        Dejan Spegar
<version>       1.0   25.06.2004 basic Oracle implementation
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_home_stock_id NUMBER
                p_distribution_name NVARCHAR2
                p_description NVARCHAR2
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE distribution_template__ins (
      p_home_stock_id             NUMBER,
      p_distribution_name         NVARCHAR2,
      p_description               NVARCHAR2,
      p_handle_tran               CHAR := 'Y',
      p_error_code          OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
   BEGIN
      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      p_error_code := 0;

      INSERT INTO distribution_template (id, home_stock_id, distribution_name, description)
           VALUES (S_DISTRIBUTION_TEMPLATE.nextval, p_home_stock_id, p_distribution_name, p_description);

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END distribution_template__ins;

/****************************************************************************
<name>          DISTRIBUTION_TEMPLATE__Del
<author>        Dejan Spegar
<version>       1.0   25.06.2004 basic Oracle implementation
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_home_stock_id NUMBER
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE distribution_template__del (
      p_id                    NUMBER,
      p_home_stock_id         NUMBER,
      p_handle_tran           CHAR := 'Y',
      p_error_code      OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
   BEGIN
      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      p_error_code := 0;

      IF p_id > 0
      THEN
         DELETE FROM distribution_template
               WHERE ID = p_id;
      ELSE
         DELETE FROM distribution_template
               WHERE home_stock_id = p_home_stock_id;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END distribution_template__del;

/****************************************************************************
<name>          DISTRIBUTION_TEMPLATE__Get
<author>        Dejan Spegar
<version>       1.0   25.06.2004 basic Oracle implementation
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_home_stock_id NUMBER
                p_jeans_package_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE distribution_template__get (
      p_home_stock_id                     NUMBER,
      p_distribution_template_rec   OUT   t_cursor,
      p_error_code                  OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
   BEGIN
      p_error_code := 0;
      v_sp_name := util_sys_pkg.make_savepoint;

      OPEN p_distribution_template_rec FOR
         SELECT *
           FROM distribution_template
          WHERE (home_stock_id = p_home_stock_id) OR (p_home_stock_id = -1);
   EXCEPTION
      WHEN OTHERS
      THEN
         util_sys_pkg.rollback_savepoint(v_sp_name);
   END distribution_template__get;

/****************************************************************************
<name>          DIST_TEMPLATE_DETAIL__Ins
<author>        Dejan Spegar
<version>       1.0   25.06.2004 basic Oracle implementation
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_distribution_id NUMBER
                p_destination_stock_id NUMBER
                p_equipment_model_id NUMBER
                p_percentage NUMBER
                p_quantity NUMBER
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE dist_template_detail__ins (
      p_distribution_id              NUMBER,
      p_destination_stock_id         NUMBER,
      p_percentage                   NUMBER,
      p_quantity                     NUMBER,
      p_handle_tran                  CHAR := 'Y',
      p_error_code             OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
   BEGIN
      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      p_error_code := 0;

      INSERT INTO distribution_template_detail (id, distribution_id, destination_stock_id, percentage, quantity)
           VALUES (S_DIST_TEMPLATE_DETAIL.nextval, p_distribution_id, p_destination_stock_id, p_percentage, p_quantity);

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END dist_template_detail__ins;

/****************************************************************************
<name>          DIST_TEMPLATE_DETAIL__Del
<author>        Dejan Spegar
<version>       1.0   25.06.2004 basic Oracle implementation
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_distribution_id NUMBER
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE dist_template_detail__del (
      p_id                      NUMBER,
      p_distribution_id         NUMBER,
      p_handle_tran             CHAR := 'Y',
      p_error_code        OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
   BEGIN
      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      p_error_code := 0;

      IF p_id > 0
      THEN
         DELETE FROM distribution_template_detail
               WHERE ID = p_id;
      ELSE
         DELETE FROM distribution_template_detail
               WHERE distribution_id = p_distribution_id;
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            ELSE
               p_error_code := 999;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END dist_template_detail__del;

/****************************************************************************
<name>          DIST_TEMPLATE_DETAIL__Get
<author>        Dejan Spegar
<version>       1.0   25.06.2004 basic Oracle implementation
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_home_stock_id NUMBER
                p_jeans_package_rec OUT t_cursor
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification
****************************************************************************/
   PROCEDURE dist_template_detail__get (
      p_distribution_id                  NUMBER,
      p_dist_detail_template_rec   OUT   t_cursor,
      p_error_code                 OUT   NUMBER
   )
   IS
      v_sp_name varchar2(30);
   BEGIN
      p_error_code := 0;
      v_sp_name := util_sys_pkg.make_savepoint;

      OPEN p_dist_detail_template_rec FOR
         SELECT dtd.ID AS "Id", dt.ID AS "Distribution id", s.NAME AS "Destination stock name",
                s.code AS "Destination stock code", s.ID AS "Destination stock id",
                dtd.percentage AS "Rate", dtd.quantity AS "Quantity"
           FROM distribution_template dt INNER JOIN distribution_template_detail dtd
                ON dt.ID = dtd.distribution_id
                INNER JOIN stock s ON dtd.destination_stock_id = s.ID
          WHERE ((dt.ID = p_distribution_id) OR (p_distribution_id = -1));
   EXCEPTION
      WHEN OTHERS
      THEN
         util_sys_pkg.rollback_savepoint(v_sp_name);
   END dist_template_detail__get;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_type__get (p_stock_type_rec OUT t_cursor, p_error_code OUT NUMBER)
   IS
   BEGIN
      p_error_code := 0;

      OPEN p_stock_type_rec FOR
         SELECT *
           FROM stock_type;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
   END stock_type__get;

--------------------------------------------------------------------------------
-- Author  : gsavic
-- Created : 25.1.2006
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_state__get_for_equpm (
      p_stock_id                 NUMBER,
      p_stock_state3_rec   OUT   t_cursor,
      p_error_code         OUT   NUMBER
   )
   IS
      tmp_equipment_id_num   NUMBER;
   BEGIN
      p_error_code := 0;

      SELECT COUNT (ID)
        INTO tmp_equipment_id_num
        FROM tmp_equipment_id;

      OPEN p_stock_state3_rec FOR
         SELECT stock.code "Stock Code", stock.NAME "Stock name", vw_stock_state.*
           FROM vw_stock_state INNER JOIN stock ON vw_stock_state."Id" = stock.ID
          WHERE "Id" = p_stock_id
            AND (("Equipment model id" IN (SELECT *
                                             FROM tmp_equipment_id)) OR (0 = tmp_equipment_id_num));
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
   END stock_state__get_for_equpm;

--------------------------------------------------------------------------------
-- Author  : gsavic
-- Created : 25.1.2006
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_state__get_for_st_eq2 (
      p_seria_start               VARCHAR2,
      p_seria_end                 VARCHAR2,
      p_stock_id                  NUMBER,
      p_equipment_type_id         NUMBER,
      p_equipment_code            VARCHAR2,
      p_quantity                  NUMBER,
      p_status                    NUMBER,
      p_stock_state3_rec    OUT   t_cursor,
      p_error_code          OUT   NUMBER
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'stock_state__get_for_st_eq2';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_seria_start
                         || pkg_constants.c_delimiter
                         || p_seria_end
                         || pkg_constants.c_delimiter
                         || p_stock_id
                         || pkg_constants.c_delimiter
                         || p_equipment_type_id
                         || pkg_constants.c_delimiter
                         || p_equipment_code
                         || pkg_constants.c_delimiter
                         || p_quantity
                         || pkg_constants.c_delimiter
                         || p_status
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;

      IF (p_seria_start IS NOT NULL AND p_seria_end IS NOT NULL)
      THEN
         OPEN p_stock_state3_rec FOR
            SELECT *
              FROM vw_stock_state
             WHERE "Id" = p_stock_id
               AND (("Equipment type id" = p_equipment_type_id) OR (p_equipment_type_id = -1))
               AND ("Equipment code" = p_equipment_code OR p_equipment_code IS NULL)
               AND (("Quantity" > p_quantity) OR (p_quantity = -1))
               AND (("Status" = p_status) OR (p_status = -1))
               AND "Seria start" BETWEEN p_seria_start AND p_seria_end
               AND "Seria end"  BETWEEN p_seria_start AND p_seria_end;
      ELSIF (p_seria_start IS NOT NULL AND p_seria_end IS NULL)
      THEN
         OPEN p_stock_state3_rec FOR
            SELECT *
              FROM vw_stock_state
             WHERE "Id" = p_stock_id
               AND (("Equipment type id" = p_equipment_type_id) OR (p_equipment_type_id = -1))
               AND ("Equipment code" = p_equipment_code OR p_equipment_code IS NULL)
               AND (("Quantity" > p_quantity) OR (p_quantity = -1))
               AND (("Status" = p_status) OR (p_status = -1))
               AND "Seria start" = p_seria_start;
      ELSIF (p_seria_start IS NULL AND p_seria_end IS NOT NULL)
      THEN
         OPEN p_stock_state3_rec FOR
            SELECT *
              FROM vw_stock_state
             WHERE "Id" = p_stock_id
               AND (("Equipment type id" = p_equipment_type_id) OR (p_equipment_type_id = -1))
               AND ("Equipment code" = p_equipment_code OR p_equipment_code IS NULL)
               AND (("Quantity" > p_quantity) OR (p_quantity = -1))
               AND (("Status" = p_status) OR (p_status = -1))
               AND "Seria end" = p_seria_end;
      ELSE
         OPEN p_stock_state3_rec FOR
            SELECT *
              FROM vw_stock_state
             WHERE "Id" = p_stock_id
               AND (("Equipment type id" = p_equipment_type_id) OR (p_equipment_type_id = -1))
               AND ("Equipment code" = p_equipment_code OR p_equipment_code IS NULL)
               AND (("Quantity" > p_quantity) OR (p_quantity = -1))
               AND (("Status" = p_status) OR (p_status = -1));
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END stock_state__get_for_st_eq2;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed :
--   Skripnik Petr 14.10.2006
--   Skripnik Petr 06.12.2006
--   Skripnik Petr 17.04.2007 Удалены колонки MIN_VALUE и ALARM_ID
--   Skripnik Petr 18.06.2007 Удалены колонки document_no
--   Skripnik Petr 27.04.2007 Добавил FOR delstockrows IN (...FOR UPDATE NOWAIT);
--   Anoev Maxim 08.05.2007 Удалил AND reserved IS NULL;
-- Purpose : Синхронизация таблицы STOCK_STATE
--------------------------------------------------------------------------------
   PROCEDURE stock_state__bulk_ins (
      p_id                         aaid,
      p_stock_id                   aastock,
      p_equipment_model_id         aaeqmodelid,
      p_seria_start                aastartseries,
      p_seria_end                  aaendseries,
      p_quantity_onstock           aaonstock,
      p_quantity_reserved          aareserved,
      p_quantity_announced         aaannounced,
      p_doc_header_id              aadocheaderid,
      p_create_date                aacreatedate,
      p_status                     aastatus,
      p_equipment_batch_id         aaequipmentbatchid,   -- в массиве значение "-1" есть NULL
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   AS
      v_sp_name varchar2(30);
      prc_name        CONSTANT NVARCHAR2 (100) := pkg_name || 'stock_state__bulk_ins';
      p_equipment_type_id      NUMBER;
      p_doc_header             NUMBER;
      p_count                  NUMBER;
      p_founded                NUMBER;
      p_user_comment           NVARCHAR2 (50);
      p_quantity               NUMBER;
      x                        VARCHAR2 (500);
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      util_loc_pkg.touch_number(p_id.count);

      IF p_handle_tran = 'Y'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      FOR i IN 1 .. p_length
      LOOP
         --Установим код ошибки в ноль
         p_error_code := 0;
         p_count := 1;

         IF p_doc_header_id (i) IS NULL
         THEN
            p_doc_header := 0;
         ELSE
            p_doc_header := p_doc_header_id (i);
         END IF;

         SELECT equipment_type_id
           INTO p_equipment_type_id
           FROM equipment_model
          WHERE equipment_model_id = p_equipment_model_id (i);

         pkg_db_util.DEBUG (prc_name,
                               'anounced:'
                            || p_quantity_announced (i)
                            || ', reserved:'
                            || p_quantity_reserved (i)
                            || ', onstock:'
                            || p_quantity_onstock (i),
                            pkg_name
                           );
         pkg_db_util.DEBUG (prc_name,
                               'stock_id=:'
                            || p_stock_id (i)
                            || ', seria_start:'
                            || p_seria_start (i)
                            || ', seria_end:'
                            || p_seria_end (i)
                            || ', equipment_model:'
                            || p_equipment_model_id (i),
                            pkg_name
                           );

         SELECT    'In table anounced:'
                || SUM (ss.quantity_announced)
                || ', reserved:'
                || SUM (ss.quantity_reserved)
                || ', onstock:'
                || SUM (ss.quantity_onstock)
           INTO x
           FROM stock_state ss
          WHERE ss.stock_id = p_stock_id (i)
            AND ss.seria_start = p_seria_start (i)
            AND ss.seria_end = p_seria_end (i)
            AND ss.equipment_model_id = p_equipment_model_id (i);

         pkg_db_util.DEBUG (prc_name, x, pkg_name);

         IF p_quantity_onstock (i) > 0 OR p_quantity_announced (i) > 0
         THEN
            IF NOT pkg_equipment.chk_availability_sn (p_equipment_type_id)
            THEN
               SELECT MAX (ID)
                 INTO p_founded
                 FROM stock_state
                WHERE equipment_model_id = p_equipment_model_id (i) AND stock_id = p_stock_id (i);

               IF p_founded IS NOT NULL
               THEN
                  UPDATE stock_state
                     SET quantity_onstock = quantity_onstock + p_quantity_onstock (i),
                         quantity_announced = quantity_announced + p_quantity_announced (i),
                         quantity_reserved = quantity_reserved + p_quantity_reserved (i)
                   WHERE ID = p_founded;
               ELSE
                  INSERT INTO stock_state
                              (ID, stock_id, equipment_model_id, seria_start,
                               seria_end, quantity_onstock, quantity_reserved,
                               quantity_announced, doc_header_id, create_date,
                               status, equipment_type_id,
                               equipment_batch_id
                              )
                       VALUES (0, p_stock_id (i), p_equipment_model_id (i), p_seria_start (i),
                               p_seria_end (i), p_quantity_onstock (i), p_quantity_reserved (i),
                               p_quantity_announced (i), p_doc_header, p_create_date (i),
                               p_status (i), p_equipment_type_id,
                               DECODE (p_equipment_batch_id (i), -1, NULL, p_equipment_batch_id (i))
                              );
               END IF;
            ELSE
               SELECT --+ index(s i_stock_state_ss)
                      COUNT (*)
                 INTO p_count
                 FROM stock_state s
                WHERE equipment_model_id = p_equipment_model_id (i)
                  AND seria_start = p_seria_start (i)
                  AND seria_end = p_seria_end (i);

               IF p_count > 0
               THEN
                  SELECT --+ index(s i_stock_state_ss)
                         user_comment
                    INTO p_user_comment
                    FROM stock_state s
                   WHERE equipment_model_id = p_equipment_model_id (i)
                     AND seria_start = p_seria_start (i)
                     AND seria_end = p_seria_end (i);
               ELSE
                  p_user_comment := NULL;
               END IF;

               INSERT INTO stock_state
                           (ID, stock_id, equipment_model_id, seria_start,
                            seria_end, quantity_onstock, quantity_reserved,
                            quantity_announced, doc_header_id, create_date,
                            status, equipment_type_id, user_comment,
                            equipment_batch_id
                           )
                    VALUES (0, p_stock_id (i), p_equipment_model_id (i), p_seria_start (i),
                            p_seria_end (i), p_quantity_onstock (i), p_quantity_reserved (i),
                            p_quantity_announced (i), p_doc_header, p_create_date (i),
                            p_status (i), p_equipment_type_id, p_user_comment,
                            DECODE (p_equipment_batch_id (i), -1, NULL, p_equipment_batch_id (i))
                           );
            END IF;
         END IF;

         IF p_quantity_reserved (i) > 0
         THEN
            IF pkg_equipment.chk_availability_sn (p_equipment_type_id)
            THEN
               SELECT --+ index(s i_stock_state_eqm)
                      MAX (ID), MAX (quantity_onstock)
                 INTO p_founded, p_count
                 FROM stock_state s
                WHERE equipment_model_id = p_equipment_model_id (i)
                  AND stock_id = p_stock_id (i)
                  AND seria_start = p_seria_start (i)
                  AND seria_end = p_seria_end (i);

               IF p_founded IS NOT NULL
               THEN
                  IF p_count = p_quantity_reserved (i)
                  THEN
                     UPDATE stock_state
                        SET quantity_onstock = quantity_onstock - p_quantity_reserved (i),
                            quantity_reserved = quantity_reserved + p_quantity_reserved (i),
                            doc_header_id = p_doc_header_id (i)
                      WHERE ID = p_founded;
                  ELSE
                     p_error_code := -90032;
                  END IF;
               ELSIF p_count > 1
               THEN
                  p_error_code := -90030;
               ELSE
                  p_error_code := -90031;
               END IF;
            ELSE
               SELECT SUM (quantity)
                 INTO p_quantity
                 FROM equipment_reservation
                WHERE equipment_model_id = p_equipment_model_id (i) AND stock_id = p_stock_id (i);

               IF p_quantity IS NULL
               THEN
                  p_quantity := 0;
               END IF;

               SELECT MAX (ID), MAX (quantity_onstock)
                 INTO p_founded, p_count
                 FROM stock_state
                WHERE equipment_model_id = p_equipment_model_id (i) AND stock_id = p_stock_id (i);

               IF p_count IS NOT NULL
               THEN
                  IF p_count - p_quantity >= p_quantity_reserved (i)
                  THEN
                     UPDATE stock_state
                        SET quantity_onstock = quantity_onstock - p_quantity_reserved (i),
                            quantity_reserved = quantity_reserved + p_quantity_reserved (i),
                            doc_header_id = p_doc_header_id (i)
                      WHERE ID = p_founded;
                  ELSE
                     p_error_code := -90034;
                  END IF;
               ELSIF p_count > 1
               THEN
                  p_error_code := -90030;
               ELSE
                  p_error_code := -90033;
               END IF;
            END IF;

            EXIT WHEN p_error_code <> 0;
         END IF;

         IF (p_quantity_onstock (i) < 0) AND (p_error_code = 0)
         THEN
            IF pkg_equipment.chk_availability_sn (p_equipment_type_id)
            THEN
               SELECT --+ index(s i_stock_state_eqm)
                      MAX (ID), MAX (quantity_onstock)
                 INTO p_founded, p_count
                 FROM stock_state s
                WHERE equipment_model_id = p_equipment_model_id (i)
                  AND stock_id = p_stock_id (i)
                  AND seria_start = p_seria_start (i)
                  AND seria_end = p_seria_end (i);

               IF p_founded IS NOT NULL
               THEN
                  IF p_count = -p_quantity_onstock (i)
                  THEN
                     SELECT --+ index(s i_stock_state_ss)
                            COUNT (*)
                       INTO p_count
                       FROM stock_state s
                      WHERE equipment_model_id = p_equipment_model_id (i)
                        AND seria_start = p_seria_start (i)
                        AND seria_end = p_seria_end (i);

                     IF p_count > 0
                     THEN
                        SELECT --+ index(s i_stock_state_ss)
                               user_comment
                          INTO p_user_comment
                          FROM stock_state s
                         WHERE equipment_model_id = p_equipment_model_id (i)
                           AND seria_start = p_seria_start (i)
                           AND seria_end = p_seria_end (i);

                        INSERT INTO tmp_seria_comment
                             VALUES (p_seria_start (i), p_seria_end (i), p_equipment_model_id (i),
                                     p_user_comment);
                     END IF;

                     FOR delstockrows IN (SELECT     ID
                                                FROM stock_state
                                               WHERE ID = p_founded
                                          FOR UPDATE NOWAIT)
                     LOOP
                        DELETE FROM stock_state
                              WHERE ID = delstockrows.ID;
                     END LOOP;
                  ELSE
                     p_error_code := -90036;
                  END IF;
               ELSIF p_count > 1
               THEN
                  p_error_code := -90030;
               ELSE
                  p_error_code := -90035;
               END IF;
            ELSE
               SELECT SUM (quantity)
                 INTO p_quantity
                 FROM equipment_reservation
                WHERE equipment_model_id = p_equipment_model_id (i) AND stock_id = p_stock_id (i);

               IF p_quantity IS NULL
               THEN
                  p_quantity := 0;
               END IF;

               SELECT MAX (ID), MAX (quantity_onstock)
                 INTO p_founded, p_count
                 FROM stock_state
                WHERE equipment_model_id = p_equipment_model_id (i) AND stock_id = p_stock_id (i);

               IF p_founded IS NOT NULL
               THEN
                  IF p_count - p_quantity > -p_quantity_onstock (i)
                  THEN
                     UPDATE stock_state
                        SET quantity_onstock = quantity_onstock + p_quantity_onstock (i)
                      WHERE ID = p_founded;
                  ELSIF p_count = -p_quantity_onstock (i) AND p_quantity = 0
                  THEN
                     DELETE FROM stock_state
                           WHERE ID = p_founded AND quantity_reserved = 0
                                 AND quantity_announced = 0;

                     UPDATE stock_state
                        SET quantity_onstock = 0
                      WHERE ID = p_founded AND (quantity_reserved <> 0 OR quantity_announced <> 0);
                  ELSE
                     p_error_code := -90037;
                  END IF;
               END IF;
            END IF;

            EXIT WHEN p_error_code <> 0;
         END IF;

      END LOOP;

      FOR cur_row IN (SELECT seria_start, seria_end, equipment_model_id, user_comment
                        FROM tmp_seria_comment)
      LOOP
         UPDATE /*+ no_index(ss I_STOCK_STATE_EQM) */
            stock_state ss
            SET ss.user_comment = cur_row.user_comment
          WHERE ss.seria_start = cur_row.seria_start
            AND ss.seria_end = cur_row.seria_end
            AND ss.equipment_model_id = cur_row.equipment_model_id;
      END LOOP;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            WHEN -20001
            THEN
               p_error_code := -90030;
            WHEN -54
            THEN
               p_error_code := -90040;
            ELSE
               p_error_code := SQLCODE;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stock_state__bulk_ins;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed :
--   Skripnik Petr 14.10.2006
--   Skripnik Petr 06.12.2006
--   Skripnik Petr 17.04.2007 Удалены колонки MIN_VALUE и ALARM_ID
--   Skripnik Petr 18.06.2007 Удалены колонки document_no
--   Skripnik Petr 27.04.2007 Добавил FOR delstockrows IN (...FOR UPDATE NOWAIT);
--   Anoev Maxim 08.05.2007 Удалил AND reserved IS NULL;
-- Purpose : Синхронизация таблицы STOCK_STATE
--------------------------------------------------------------------------------
   PROCEDURE stock_state__bulk_ins_2 (
      p_id                         aaid,
      p_stock_id                   aastock,
      p_equipment_model_id         aaeqmodelid,
      p_seria_start                t_varchar,
      p_seria_end                  t_varchar,
      p_quantity_onstock           aaonstock,
      p_quantity_reserved          aareserved,
      p_quantity_announced         aaannounced,
      p_doc_header_id              aadocheaderid,
      p_create_date                aacreatedate,
      p_status                     aastatus,
      p_equipment_batch_id         aaequipmentbatchid,   -- в массиве значение "-1" есть NULL
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   AS
      v_sp_name varchar2(30);
      prc_name        CONSTANT NVARCHAR2 (100) := pkg_name || 'stock_state__bulk_ins_2';
      p_equipment_type_id      NUMBER;
      p_doc_header             NUMBER;
      p_count                  NUMBER;
      p_founded                NUMBER;
      p_user_comment           NVARCHAR2 (50);
      p_quantity               NUMBER;
      x                        VARCHAR2 (500);

      v_is_single_series       NUMBER;

   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      util_loc_pkg.touch_number(p_id.count);

       -- check input parameters
      IF (p_equipment_model_id.COUNT = 0) OR (p_equipment_model_id.COUNT = 1 AND p_equipment_model_id(p_equipment_model_id.first) IS NULL) THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_missing_parameter, 'Missing some mandatory parameter (p_equipment_model_id).');
      END IF;

      IF (p_seria_start.COUNT = 0) OR (p_seria_start.COUNT = 1 AND p_seria_start(p_seria_start.first) IS NULL) THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_missing_parameter, 'Missing some mandatory parameter (p_seria_start).');
      END IF;

      IF (p_seria_end.COUNT = 0) OR (p_seria_end.COUNT = 1 AND p_seria_end(p_seria_end.first) IS NULL) THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_missing_parameter, 'Missing some mandatory parameter (p_seria_end).');
      END IF;

      IF (p_quantity_onstock.COUNT = 0) OR (p_quantity_onstock.COUNT = 1 AND p_quantity_onstock(p_quantity_onstock.first) IS NULL) THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_missing_parameter, 'Missing some mandatory parameter (p_quantity_onstock).');
      END IF;

      IF (p_quantity_reserved.COUNT = 0) OR (p_quantity_reserved.COUNT = 1 AND p_quantity_reserved(p_quantity_reserved.first) IS NULL) THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_missing_parameter, 'Missing some mandatory parameter (p_quantity_reserved).');
      END IF;

      IF (p_quantity_announced.COUNT = 0) OR (p_quantity_announced.COUNT = 1 AND p_quantity_announced(p_quantity_announced.first) IS NULL) THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_missing_parameter, 'Missing some mandatory parameter (p_quantity_announced).');
      END IF;

      IF p_equipment_model_id.COUNT <> p_seria_start.COUNT OR
         p_equipment_model_id.COUNT <> p_seria_end.COUNT OR
         p_equipment_model_id.COUNT <> p_quantity_onstock.COUNT OR
         p_equipment_model_id.COUNT <> p_quantity_reserved.COUNT OR
         p_equipment_model_id.COUNT <> p_quantity_announced.COUNT
      THEN
        RAISE_APPLICATION_ERROR(util_pkg.c_ora_invalid_parameter, util_pkg.c_msg_invalid_parameter);
      END IF;

      IF p_handle_tran = 'Y'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      FOR i IN 1 .. p_length
      LOOP
         --Установим код ошибки в ноль
         p_error_code := 0;
         p_count := 1;

         IF p_doc_header_id (i) IS NULL
         THEN
            p_doc_header := 0;
         ELSE
            p_doc_header := p_doc_header_id (i);
         END IF;

         SELECT equipment_type_id
           INTO p_equipment_type_id
           FROM equipment_model
          WHERE equipment_model_id = p_equipment_model_id (i);

         pkg_db_util.DEBUG (prc_name,
                            'anounced:'
                            || p_quantity_announced (i)
                            || ', reserved:'
                            || p_quantity_reserved (i)
                            || ', onstock:'
                            || p_quantity_onstock (i),
                            pkg_name
                           );
         pkg_db_util.DEBUG (prc_name,
                               'stock_id=:'
                            || p_stock_id (i)
                            || ', seria_start:'
                            || p_seria_start (i)
                            || ', seria_end:'
                            || p_seria_end (i)
                            || ', equipment_model:'
                            || p_equipment_model_id (i),
                            pkg_name
                           );

         SELECT 'In table anounced:'
                  || SUM (ss.quantity_announced)
                  || ', reserved:'
                  || SUM (ss.quantity_reserved)
                  || ', onstock:'
                  || SUM (ss.quantity_onstock)
           INTO x
             FROM stock_state ss
            WHERE ss.stock_id = p_stock_id (i)
              AND ss.seria_start = p_seria_start (i)
              AND ss.seria_end = p_seria_end (i)
              AND ss.equipment_model_id = p_equipment_model_id (i);

         v_is_single_series := null;
         if p_seria_start(i) = p_seria_end(i) then
            v_is_single_series := -1;
         end if;

         pkg_db_util.DEBUG (prc_name, x, pkg_name);

         IF p_quantity_onstock (i) > 0 OR p_quantity_announced (i) > 0
         THEN
            IF NOT pkg_equipment.chk_availability_sn (p_equipment_type_id)
            THEN
               SELECT MAX (ID)
                 INTO p_founded
                 FROM stock_state
                WHERE equipment_model_id = p_equipment_model_id (i) AND stock_id = p_stock_id (i);

               IF p_founded IS NOT NULL
               THEN
                  UPDATE stock_state
                     SET quantity_onstock = quantity_onstock + p_quantity_onstock (i),
                         quantity_announced = quantity_announced + p_quantity_announced (i),
                         quantity_reserved = quantity_reserved + p_quantity_reserved (i)
                   WHERE ID = p_founded;
               ELSE
                  INSERT INTO stock_state
                              (ID, stock_id, equipment_model_id, seria_start,
                               seria_end, quantity_onstock, quantity_reserved,
                               quantity_announced, doc_header_id, create_date,
                               status, equipment_type_id,
                               equipment_batch_id
                              )
                       VALUES (0, p_stock_id (i), p_equipment_model_id (i), p_seria_start (i),
                               p_seria_end (i), p_quantity_onstock (i), p_quantity_reserved (i),
                               p_quantity_announced (i), p_doc_header, p_create_date (i),
                               p_status (i), p_equipment_type_id,
                               DECODE (p_equipment_batch_id (i), -1, NULL, p_equipment_batch_id (i))
                              );
               END IF;
            ELSE
               SELECT --+ index(s i_stock_state_ss)
                      COUNT (*)
                 INTO p_count
                 FROM stock_state s
                WHERE equipment_model_id = p_equipment_model_id (i)
                  AND seria_start = p_seria_start (i)
                  AND seria_end = p_seria_end (i);

               IF p_count > 0
               THEN
                  SELECT --+ index(s i_stock_state_ss)
                         user_comment
                    INTO p_user_comment
                    FROM stock_state s
                   WHERE equipment_model_id = p_equipment_model_id (i)
                     AND seria_start = p_seria_start (i)
                     AND seria_end = p_seria_end (i);
               ELSE
                  p_user_comment := NULL;
               END IF;

               INSERT INTO stock_state
                           (ID, stock_id, equipment_model_id, seria_start,
                            seria_end, quantity_onstock, quantity_reserved,
                            quantity_announced, doc_header_id, create_date,
                            status, equipment_type_id, user_comment,
                            equipment_batch_id,
                            is_nonsingle_series
                           )
                    VALUES (0, p_stock_id (i), p_equipment_model_id (i), p_seria_start (i),
                            p_seria_end (i), p_quantity_onstock (i), p_quantity_reserved (i),
                            p_quantity_announced (i), p_doc_header, p_create_date (i),
                            p_status (i), p_equipment_type_id, p_user_comment,
                            DECODE (p_equipment_batch_id (i), -1, NULL, p_equipment_batch_id (i)),
                            v_is_single_series
                           );
            END IF;
         END IF;

         IF p_quantity_reserved (i) > 0
         THEN
            IF pkg_equipment.chk_availability_sn (p_equipment_type_id)
            THEN
               SELECT --+ index(s i_stock_state_eqm)
                      MAX (ID), MAX (quantity_onstock)
                 INTO p_founded, p_count
                 FROM stock_state s
                WHERE equipment_model_id = p_equipment_model_id (i)
                  AND stock_id = p_stock_id (i)
                  AND seria_start = p_seria_start (i)
                  AND seria_end = p_seria_end (i);

               IF p_founded IS NOT NULL
               THEN
                  IF p_count = p_quantity_reserved (i)
                  THEN
                     UPDATE stock_state
                        SET quantity_onstock = quantity_onstock - p_quantity_reserved (i),
                            quantity_reserved = quantity_reserved + p_quantity_reserved (i),
                            doc_header_id = p_doc_header_id (i),
                            is_nonsingle_series = v_is_single_series
                      WHERE ID = p_founded;
                  ELSE
                     --NOT_ENOUGH_EQUIPMENT_RESERVED = -90032
                     p_error_code := -90032;
                  END IF;
               ELSIF p_count > 1
               THEN
                  --DUPLICATED_EQUIPMENT = -90030
                  p_error_code := -90030;
               ELSE
                  --EQUIPMENT_NOT_EXIST_RESERVED = -90031
                  p_error_code := -90031;
               END IF;
            ELSE
               SELECT SUM (quantity)
                 INTO p_quantity
                 FROM equipment_reservation
                WHERE equipment_model_id = p_equipment_model_id (i) AND stock_id = p_stock_id (i);

               IF p_quantity IS NULL
               THEN
                  p_quantity := 0;
               END IF;

               SELECT MAX (ID), MAX (quantity_onstock)
                 INTO p_founded, p_count
                 FROM stock_state
                WHERE equipment_model_id = p_equipment_model_id (i) AND stock_id = p_stock_id (i);

               IF p_count IS NOT NULL
               THEN
                  IF p_count - p_quantity >= p_quantity_reserved (i)
                  THEN
                     UPDATE stock_state
                        SET quantity_onstock = quantity_onstock - p_quantity_reserved (i),
                            quantity_reserved = quantity_reserved + p_quantity_reserved (i),
                            doc_header_id = p_doc_header_id (i)
                      WHERE ID = p_founded;
                  ELSE
                     p_error_code := -90034;
                  END IF;
               ELSIF p_count > 1
               THEN
                  p_error_code := -90030;
               ELSE
                  p_error_code := -90033;
               END IF;
            END IF;

            EXIT WHEN p_error_code <> 0;
         END IF;

         IF (p_quantity_onstock (i) < 0) AND (p_error_code = 0)
         THEN
            IF pkg_equipment.chk_availability_sn (p_equipment_type_id)
            THEN
               SELECT --+ index(s i_stock_state_eqm)
                      MAX (ID), MAX (quantity_onstock)
                 INTO p_founded, p_count
                 FROM stock_state s
                WHERE equipment_model_id = p_equipment_model_id (i)
                  AND stock_id = p_stock_id (i)
                  AND seria_start = p_seria_start (i)
                  AND seria_end = p_seria_end (i);

               IF p_founded IS NOT NULL
               THEN
                  IF p_count = -p_quantity_onstock (i)
                  THEN
                     SELECT --+ index(s i_stock_state_ss)
                            COUNT (*)
                       INTO p_count
                       FROM stock_state s
                      WHERE equipment_model_id = p_equipment_model_id (i)
                        AND seria_start = p_seria_start (i)
                        AND seria_end = p_seria_end (i);

                     IF p_count > 0
                     THEN
                        SELECT --+ index(s i_stock_state_ss)
                               user_comment
                          INTO p_user_comment
                          FROM stock_state s
                         WHERE equipment_model_id = p_equipment_model_id (i)
                           AND seria_start = p_seria_start (i)
                           AND seria_end = p_seria_end (i);

                        INSERT INTO tmp_seria_comment
                             VALUES (p_seria_start (i), p_seria_end (i), p_equipment_model_id (i),
                                     p_user_comment);
                     END IF;

                     FOR delstockrows IN (SELECT     ID
                                                FROM stock_state
                                               WHERE ID = p_founded
                                          FOR UPDATE NOWAIT)
                     LOOP
                        DELETE FROM stock_state
                              WHERE ID = delstockrows.ID;
                     END LOOP;
                  ELSE
                     --NOT_ENOUGH_EQUIPMENT_FROM_STOCK = -90036
                     p_error_code := -90036;
                  END IF;
               ELSIF p_count > 1
               THEN
                  --DUPLICATED_EQUIPMENT = -90030
                  p_error_code := -90030;
               ELSE
                  --EQUIPMENT_NOT_EXIST_FROM_STOCK = -90035
                  p_error_code := -90035;
               END IF;
            ELSE
               SELECT SUM (quantity)
                 INTO p_quantity
                 FROM equipment_reservation
                WHERE equipment_model_id = p_equipment_model_id (i) AND stock_id = p_stock_id (i);

               IF p_quantity IS NULL
               THEN
                  p_quantity := 0;
               END IF;

               SELECT MAX (ID), MAX (quantity_onstock)
                 INTO p_founded, p_count
                 FROM stock_state
                WHERE equipment_model_id = p_equipment_model_id (i) AND stock_id = p_stock_id (i);

               IF p_founded IS NOT NULL
               THEN
                  IF p_count - p_quantity > -p_quantity_onstock (i)
                  THEN
                     UPDATE stock_state
                        SET quantity_onstock = quantity_onstock + p_quantity_onstock (i)
                      WHERE ID = p_founded;
                  ELSIF p_count = -p_quantity_onstock (i) AND p_quantity = 0
                  THEN
                     DELETE FROM stock_state
                           WHERE ID = p_founded AND quantity_reserved = 0
                                 AND quantity_announced = 0;

                     UPDATE stock_state
                        SET quantity_onstock = 0
                      WHERE ID = p_founded AND (quantity_reserved <> 0 OR quantity_announced <> 0);
                  ELSE
                     --NOT_ENOUGH_EQUIPMENT_FROM_STOCK_NO_SERIAL = -90037
                     p_error_code := -90037;
                  END IF;
               END IF;
            END IF;

            EXIT WHEN p_error_code <> 0;
         END IF;

      END LOOP;

      FOR cur_row IN (SELECT seria_start, seria_end, equipment_model_id, user_comment
                        FROM tmp_seria_comment)
      LOOP
         UPDATE /*+ no_index(ss I_STOCK_STATE_EQM) */
		    stock_state ss
            SET ss.user_comment = cur_row.user_comment
          WHERE ss.seria_start = cur_row.seria_start
            AND ss.seria_end = cur_row.seria_end
            AND ss.equipment_model_id = cur_row.equipment_model_id;
      END LOOP;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            WHEN -20001
            THEN
               --DUPLICATED_EQUIPMENT = -90030
               p_error_code := -90030;
            WHEN -54
            THEN
               --resource busy and acquire with NOWAIT specified or timeout expired
               p_error_code := -90040;
            ELSE
               p_error_code := SQLCODE;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stock_state__bulk_ins_2;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed :
--
-- Purpose : stock_state__split_card_range
--------------------------------------------------------------------------------
   PROCEDURE stock_state__split_card_range(
      p_stock_id                   NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                varchar,
      p_seria_end                  varchar,
      p_single_item                t_varchar,
      p_length                     NUMBER,
      p_create_date                DATE,
      p_status                     NUMBER,
      p_equipment_batch_id         NUMBER,   -- в массиве значение "-1" есть NULL
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   )
   AS
      v_sp_name varchar2(30);
      prc_name        CONSTANT NVARCHAR2 (100) := pkg_name || 'stock_state__split_card_range';
      p_equipment_type_id      NUMBER;
      p_doc_header             NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      IF p_handle_tran = 'Y'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      SELECT equipment_type_id
           INTO p_equipment_type_id
        FROM equipment_model
          WHERE equipment_model_id = p_equipment_model_id;

      IF NOT pkg_equipment.chk_availability_sn (p_equipment_type_id) THEN
         p_error_code := -90032;
         return;
      END IF;

      --Установим код ошибки в ноль
      p_error_code := 0;
      p_doc_header := 0;

      IF p_seria_start <> p_seria_end THEN
        FOR i IN 1 .. p_length
        LOOP

           INSERT INTO stock_state
               (
                 stock_id,
                 equipment_model_id,
                 seria_start,
                 seria_end,
                 quantity_onstock,
                 quantity_reserved,
                 quantity_announced,
                 doc_header_id,
                 create_date,
                 status, equipment_type_id,
                 user_comment,
                 equipment_batch_id,
                 is_nonsingle_series
               )
           VALUES
               (
                 p_stock_id,
                 p_equipment_model_id,
                 p_single_item(i),
                 p_single_item(i),
                 1,
                 0,
                 0,
                 p_doc_header,
                 p_create_date,
                 p_status,
                 p_equipment_type_id,
                 NULL,
                 DECODE (p_equipment_batch_id, -1, NULL, p_equipment_batch_id),
                 -1
               );
        END LOOP;

        FOR delstockrows IN (
          SELECT --+ index(s i_stock_state_eqm)
            ID
          FROM stock_state s
            WHERE equipment_model_id = p_equipment_model_id
              AND stock_id = p_stock_id
              AND seria_start = p_seria_start
              AND seria_end = p_seria_end
          FOR UPDATE NOWAIT)
        LOOP
          DELETE FROM stock_state
          WHERE ID = delstockrows.ID;
        END LOOP;

        UPDATE stock_state s SET s.seria_start = p_seria_end + 1
          WHERE s.equipment_model_id = p_equipment_model_id
              AND s.stock_id = p_stock_id
              AND s.seria_start = p_seria_start
              AND s.seria_start <> s.seria_end;

      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);

   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE SQLCODE
            WHEN -1
            THEN
               p_error_code := 1;
            WHEN -2291
            THEN
               p_error_code := 2;
            WHEN -20001
            THEN
               p_error_code := -90030;
            WHEN -54
            THEN
               p_error_code := -90040;
            ELSE
               p_error_code := SQLCODE;
         END CASE;

         CASE p_handle_tran
            WHEN 'S'
            THEN
               util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;
   END stock_state__split_card_range;

END;
/
