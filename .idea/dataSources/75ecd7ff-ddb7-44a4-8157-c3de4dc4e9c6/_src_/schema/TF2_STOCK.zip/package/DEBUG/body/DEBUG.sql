CREATE PACKAGE BODY             "DEBUG" 
AS
   FUNCTION file_it (
      p_file      IN   debugtab.filename%TYPE,
      p_dir       IN   debugtab.dir%TYPE,
      p_message   IN   VARCHAR2
   )
      RETURN BOOLEAN
   IS
      l_handle   UTL_FILE.file_type;
   BEGIN
      l_handle :=
         UTL_FILE.fopen (LOCATION          => p_dir,
                         filename          => p_file,
                         open_mode         => 'a',
                         max_linesize      => 32767
                        );
      UTL_FILE.put (l_handle, '');
      UTL_FILE.put_line (l_handle, p_message);
      UTL_FILE.fclose (l_handle);
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS
      THEN
         IF UTL_FILE.is_open (l_handle)
         THEN
            UTL_FILE.fclose (l_handle);
         END IF;

         RETURN FALSE;
   END;

   FUNCTION build_it (
      p_debug_row   IN   debugtab%ROWTYPE,
      p_owner       IN   VARCHAR2,
      p_object      IN   VARCHAR2,
      p_lineno           NUMBER
   )
      RETURN VARCHAR2
   IS
      l_header   LONG := NULL;
   BEGIN
      IF p_debug_row.session_id = 'YES'
      THEN
         l_header := g_session_id || ' - ';
      END IF;

      IF p_debug_row.show_date = 'YES'
      THEN
         l_header :=
                  l_header || TO_CHAR (SYSDATE, NVL (p_debug_row.DATE_FORMAT, 'MMDDYYYY HH24MISS'));
      END IF;

      l_header :=
            l_header
         || '('
         || LPAD (SUBSTR (p_owner || '.' || p_object,
                          GREATEST (1,
                                      LENGTH (p_owner || '.' || p_object)
                                    - LEAST (p_debug_row.name_length, 61)
                                    + 1
                                   )
                         ),
                  LEAST (p_debug_row.name_length, 61)
                 )
         || LPAD (p_lineno, 5)
         || ') ';
      RETURN l_header;
   END build_it;

   PROCEDURE who_called_me (o_owner OUT VARCHAR2, o_object OUT VARCHAR2, o_lineno OUT NUMBER)
   IS
      l_call_stack   LONG            DEFAULT DBMS_UTILITY.format_call_stack;
      l_line         VARCHAR2 (4000);
   BEGIN
      FOR i IN 1 .. 6
      LOOP
         l_call_stack := SUBSTR (l_call_stack, INSTR (l_call_stack, CHR (10)) + 1);
      END LOOP;

      l_line := LTRIM (SUBSTR (l_call_stack, 1, INSTR (l_call_stack, CHR (10)) - 1));
      l_line := LTRIM (SUBSTR (l_line, INSTR (l_line, ' ')));
      o_lineno := TO_NUMBER (SUBSTR (l_line, 1, INSTR (l_line, ' ')));
      l_line := LTRIM (SUBSTR (l_line, INSTR (l_line, ' ')));
      l_line := LTRIM (SUBSTR (l_line, INSTR (l_line, ' ')));

      IF l_line LIKE 'block.%' OR l_line LIKE 'body%'
      THEN
         l_line := LTRIM (SUBSTR (l_line, INSTR (l_line, ' ')));
      END IF;

      o_owner := LTRIM (RTRIM (SUBSTR (l_line, 1, INSTR (l_line, '.') - 1)));
      o_object := LTRIM (RTRIM (SUBSTR (l_line, INSTR (l_line, '.') + 1)));

      IF o_owner IS NULL
      THEN
         o_owner := USER;
         o_object := 'ANONYMOUS BLOCK';
      END IF;
   END who_called_me;

   FUNCTION parse_it (p_message IN VARCHAR2, p_argv IN argv, p_header_length IN NUMBER)
      RETURN VARCHAR2
   IS
      l_message   LONG   := NULL;
      l_str       LONG   := p_message;
      l_idx       NUMBER := 1;
      l_ptr       NUMBER := 1;
   BEGIN
      IF NVL (INSTR (p_message, '%'), 0) = 0 AND NVL (INSTR (p_message, '\'), 0) = 0
      THEN
         RETURN p_message;
      END IF;

      LOOP
         l_ptr := INSTR (l_str, '%');
         EXIT WHEN l_ptr = 0 OR l_ptr IS NULL;
         l_message := l_message || SUBSTR (l_str, 1, l_ptr - 1);
         l_str := SUBSTR (l_str, l_ptr + 1);

         IF SUBSTR (l_str, 1, 1) = 's'
         THEN
            l_message := l_message || p_argv (l_idx);
            l_idx := l_idx + 1;
            l_str := SUBSTR (l_str, 2);
         ELSIF SUBSTR (l_str, 1, 1) = '%'
         THEN
            l_message := l_message || '%';
            l_str := SUBSTR (l_str, 2);
         ELSE
            l_message := l_message || '%';
         END IF;
      END LOOP;

      l_str := l_message || l_str;
      l_message := NULL;

      LOOP
         l_ptr := INSTR (l_str, '\');
         EXIT WHEN l_ptr = 0 OR l_ptr IS NULL;
         l_message := l_message || SUBSTR (l_str, 1, l_ptr - 1);
         l_str := SUBSTR (l_str, l_ptr + 1);

         IF SUBSTR (l_str, 1, 1) = 'n'
         THEN
            l_message := l_message || CHR (10) || RPAD (' ', p_header_length, ' ');
            l_str := SUBSTR (l_str, 2);
         ELSIF SUBSTR (l_str, 1, 1) = 't'
         THEN
            l_message := l_message || CHR (9);
            l_str := SUBSTR (l_str, 2);
         ELSIF SUBSTR (l_str, 1, 1) = 't'
         THEN
            l_message := l_message || CHR (9);
            l_str := SUBSTR (l_str, 2);
         ELSE
            l_message := l_message || '\';
         END IF;
      END LOOP;

      RETURN l_message || l_str;
   END;

   PROCEDURE debug_it (р_message IN VARCHAR2, p_argv IN argv)
   IS
      l_message            LONG           := NULL;
      l_header             LONG           := NULL;
      call_who_called_me   BOOLEAN        := TRUE;
      l_owner              VARCHAR2 (255);
      l_object             VARCHAR2 (255);
      l_lineno             NUMBER;
      l_dummy              BOOLEAN;
   BEGIN
      FOR сur IN (SELECT userid, dir, filename, modules, show_date, DATE_FORMAT, name_length,
                         session_id
                    FROM debugtab
                   WHERE userid = USER)
      LOOP
         IF call_who_called_me
         THEN
            who_called_me (l_owner, l_object, l_lineno);
            call_who_called_me := FALSE;
         END IF;

         IF INSTR (',' || сur.modules || ',', ',' || l_object || ',') <> 0 OR сur.modules = 'ALL'
         THEN
            l_header := build_it (сur, l_owner, l_object, l_lineno);
            l_message := parse_it (l_message, p_argv, LENGTH (l_header));
            l_dummy := file_it (сur.dir, сur.filename, l_header || l_message);
         END IF;
      END LOOP;
   END debug_it;

   PROCEDURE init (
      p_modules       IN   VARCHAR2 DEFAULT 'ALL',
      p_dir           IN   VARCHAR2 DEFAULT 'TEMP',
      p_file          IN   VARCHAR2 DEFAULT USER || '.dbg',
      p_user          IN   VARCHAR2 DEFAULT USER,
      p_show_date     IN   VARCHAR2 DEFAULT 'YES',
      p_date_format   IN   VARCHAR2 DEFAULT 'MMDDYYYY HH24MISS',
      p_name_len      IN   NUMBER DEFAULT 30,
      p_show_sesid    IN   VARCHAR2 DEFAULT 'NO'
   )
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
      debugtab_rec   debugtab%ROWTYPE;
      l_message      LONG;
   BEGIN
      DELETE FROM debugtab
            WHERE userid = p_user AND filename = p_file AND dir = p_dir;

      INSERT INTO debugtab
                  (userid, modules, dir, filename, show_date, DATE_FORMAT, name_length,
                   session_id
                  )
           VALUES (p_user, p_modules, p_dir, p_file, p_show_date, p_date_format, p_name_len,
                   p_show_sesid
                  )
        RETURNING userid, modules, dir,
                  filename, show_date, DATE_FORMAT,
                  name_length, session_id
             INTO debugtab_rec.userid, debugtab_rec.modules, debugtab_rec.dir,
                  debugtab_rec.filename, debugtab_rec.show_date, debugtab_rec.DATE_FORMAT,
                  debugtab_rec.name_length, debugtab_rec.session_id;

      l_message :=
            CHR (10)
         || 'Debug parameters initialized on '
         || TO_CHAR (SYSDATE, 'dd-MON-yyyy hh24:mi:ss')
         || CHR (10);
      l_message := l_message || '     USER: ' || debugtab_rec.userid || CHR (10);
      l_message := l_message || '     MODULES: ' || debugtab_rec.modules || CHR (10);
      l_message := l_message || '     DIRECTORY: ' || debugtab_rec.dir || CHR (10);
      l_message := l_message || '     FILENAME: ' || debugtab_rec.filename || CHR (10);
      l_message := l_message || '     SHOW DATE: ' || debugtab_rec.show_date || CHR (10);
      l_message := l_message || '     DATE FORMAT: ' || debugtab_rec.DATE_FORMAT || CHR (10);
      l_message := l_message || '     NAME LENGTH: ' || debugtab_rec.name_length || CHR (10);
      l_message := l_message || '     SHOW SESSION ID: ' || debugtab_rec.session_id || CHR (10);

      IF NOT file_it (debugtab_rec.filename, debugtab_rec.dir, l_message)
      THEN
         ROLLBACK;
         raise_application_error (-20001, 'Can not open file "' || debugtab_rec.filename || '"');
      END IF;

      COMMIT;
   END init;

   PROCEDURE CLEAR (
      p_user   IN   VARCHAR2 DEFAULT USER,
      p_dir    IN   VARCHAR2 DEFAULT NULL,
      p_file   IN   VARCHAR2 DEFAULT NULL
   )
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      DELETE FROM debugtab
            WHERE userid = p_user AND dir = NVL (p_dir, dir) AND filename = NVL (p_file, filename);

      COMMIT;
   END CLEAR;

   PROCEDURE status (
      p_user   IN   VARCHAR2 DEFAULT USER,
      p_dir    IN   VARCHAR2 DEFAULT NULL,
      p_file   IN   VARCHAR2 DEFAULT NULL
   )
   IS
      l_found   BOOLEAN := FALSE;
   BEGIN
      DBMS_OUTPUT.put_line (CHR (10));
      DBMS_OUTPUT.put_line ('Debug info for ' || p_user);

      FOR cur IN (SELECT userid, dir, filename, modules, show_date, DATE_FORMAT, name_length,
                         session_id
                    FROM debugtab
                   WHERE userid = p_user
                     AND dir = NVL (p_dir, dir)
                     AND NVL (p_file, filename) = filename)
      LOOP
         l_found := TRUE;
         DBMS_OUTPUT.put_line (' ' || RPAD ('-', LENGTH (p_user), '-'));
         DBMS_OUTPUT.put_line ('USER: ' || cur.userid);
         DBMS_OUTPUT.put_line ('MODULES: ' || cur.modules);
         DBMS_OUTPUT.put_line ('DIRECTORY: ' || cur.dir);
         DBMS_OUTPUT.put_line ('FILENAME: ' || cur.filename);
         DBMS_OUTPUT.put_line ('SHOW DATE: ' || cur.show_date);
         DBMS_OUTPUT.put_line ('DATE FORMAT: ' || cur.DATE_FORMAT);
         DBMS_OUTPUT.put_line ('NAME LENGTH: ' || cur.name_length);
         DBMS_OUTPUT.put_line ('SHOW SESSION ID: ' || cur.session_id);
         DBMS_OUTPUT.put_line (' ');
      END LOOP;

      IF NOT l_found
      THEN
         DBMS_OUTPUT.put_line ('No debug setup.');
      END IF;
   END status;

   PROCEDURE f (
      p_message   IN   VARCHAR2,
      p_argl      IN   VARCHAR2 DEFAULT NULL,
      p_arg2      IN   VARCHAR2 DEFAULT NULL,
      p_arg3      IN   VARCHAR2 DEFAULT NULL,
      p_arg4      IN   VARCHAR2 DEFAULT NULL,
      p_arg5      IN   VARCHAR2 DEFAULT NULL,
      p_arg6      IN   VARCHAR2 DEFAULT NULL,
      p_arg7      IN   VARCHAR2 DEFAULT NULL,
      p_arg8      IN   VARCHAR2 DEFAULT NULL,
      p_arg9      IN   VARCHAR2 DEFAULT NULL,
      p_arglo     IN   VARCHAR2 DEFAULT NULL
   )
   IS
   BEGIN
      debug_it (p_message,
                argv (SUBSTR (p_argl, 1, 4000),
                      SUBSTR (p_arg2, 1, 4000),
                      SUBSTR (p_arg3, 1, 4000),
                      SUBSTR (p_arg4, 1, 4000),
                      SUBSTR (p_arg5, 1, 4000),
                      SUBSTR (p_arg6, 1, 4000),
                      SUBSTR (p_arg7, 1, 4000),
                      SUBSTR (p_arg8, 1, 4000),
                      SUBSTR (p_arg9, 1, 4000),
                      SUBSTR (p_arglo, 1, 4000)
                     )
               );
   END f;

   PROCEDURE fa (p_message IN VARCHAR2, p_args IN argv DEFAULT emptydebugargv)
   IS
   BEGIN
      debug_it (p_message, p_args);
   END fa;
BEGIN
   g_session_id := USERENV ('SESSIONID');
END DEBUG;
/
