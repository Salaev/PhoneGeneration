CREATE package RI_PERSISTENT_INTERFACE_PKG is

----------------------------------!---------------------------------------------
  function get_network_operator_id0(p_network_operator_code ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_network_operator_id(p_network_operator_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number;
  function get_network_operator_id2(p_network_operator_code varchar2, p_date date) return number;

----------------------------------!---------------------------------------------
  procedure prod_check_sim_list
  (
    p_host_id number,
    p_net_op_id number,
    p_iccid_without_control_digit ct_nvarchar_s,
    p_iccid out ct_nvarchar_s,
    p_imsi out ct_nvarchar_s,
    p_error_code out ct_number,
    p_error_message out ct_varchar
  );

----------------------------------!---------------------------------------------
end;
/
