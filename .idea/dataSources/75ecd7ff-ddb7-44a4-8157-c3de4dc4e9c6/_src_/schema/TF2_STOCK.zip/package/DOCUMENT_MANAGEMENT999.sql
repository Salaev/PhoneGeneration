CREATE PACKAGE document_management999
AS
/****************************************************************************
<name> document_management package
<author>        Petar Ulic
<version>       1.0   04.12.2003 basic Oracle implementation
<Description>   Package contains functions and procedures for document
                management in Stock system
<Application>   Stock Management

   -- MODIFICATION HISTORY
   -- Person          Date        Comments
   -- ---------       ------      ------------------------------------------
   -- Petr Skripnik   09.11.2006  Изменен
****************************************************************************/
   TYPE t_cursor IS REF CURSOR;

   TYPE aadocheaderid IS TABLE OF doc_detail.doc_header_id%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aaeqmodelid IS TABLE OF doc_detail.equipment_model_id%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aastartseries IS TABLE OF doc_detail.seria_start%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aaendseries IS TABLE OF doc_detail.seria_end%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aaquantity IS TABLE OF doc_detail.quantity%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aastatus IS TABLE OF doc_detail.status_id%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aaproduct IS TABLE OF doc_detail.product%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aavaliduntil IS TABLE OF doc_detail.valid_until%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aaequipmentbatchid IS TABLE OF doc_detail.equipment_batch_id%TYPE
      INDEX BY BINARY_INTEGER;

   TYPE aastockid IS TABLE OF stock_state.stock_id%TYPE
      INDEX BY PLS_INTEGER;

   TYPE aaequipmentmodelid IS TABLE OF stock_state.equipment_model_id%TYPE
      INDEX BY PLS_INTEGER;

   TYPE aaseriastart IS TABLE OF stock_state.seria_start%TYPE
      INDEX BY PLS_INTEGER;

   TYPE aaseriaend IS TABLE OF stock_state.seria_end%TYPE
      INDEX BY PLS_INTEGER;

   TYPE t_varchar IS TABLE OF VARCHAR2 (100)
      INDEX BY PLS_INTEGER;

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_detail__get (
      p_doc_header_id          NUMBER,
      p_doc_detail_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_detail__get_simple (
      p_doc_header_id          NUMBER,
      p_doc_detail_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  : Skripnik Petr
   -- Changed : 24.10.2006 15:20
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_detail__ins (
      p_doc_header_id              NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity                   NUMBER,
      p_status_id                  NUMBER,
      p_product                    NUMBER,
      p_valid_until                DATE,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  : Skripnik Petr
   -- Created : 24.10.2006 16:14
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_detail__ins (
      p_doc_header_id              NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity                   NUMBER,
      p_status_id                  NUMBER,
      p_product                    NUMBER,
      p_valid_until                DATE,
      p_equipment_batch_id         NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.10.2006 16:14
-- Editor  :
-- Changed :
-- Purpose :
--
--   Процедура doc_detail__ins_2 аналогична процедуре
--   PROCEDURE doc_detail__ins (
--      p_doc_header_id              NUMBER,
--      p_equipment_model_id         NUMBER,
--      p_seria_start                NVARCHAR2,
--      p_seria_end                  NVARCHAR2,
--      p_quantity                   NUMBER,
--      p_status_id                  NUMBER,
--      p_product                    NUMBER,
--      p_valid_until                DATE,
--      p_equipment_batch_id         NUMBER,
--      p_handle_tran                CHAR := 'Y',
--      p_error_code           OUT   NUMBER
--   )
--  Создана для поддержки FORIS.DataAccess
--------------------------------------------------------------------------------
   PROCEDURE doc_detail__ins_2 (
      p_doc_header_id              NUMBER,
      p_equipment_model_id         NUMBER,
      p_seria_start                NVARCHAR2,
      p_seria_end                  NVARCHAR2,
      p_quantity                   NUMBER,
      p_status_id                  NUMBER,
      p_product                    NUMBER,
      p_valid_until                DATE,
      p_equipment_batch_id         NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

----------------------------------!---------------------------------------------
  procedure doc_header__get_1
  (
    p_id number,
    p_doc_header_rec out sys_refcursor,
    p_error_code out number
  );

  procedure doc_header__get_2
  (
    p_doc_num nvarchar2,
    p_doc_header_rec out sys_refcursor,
    p_error_code out number
  );

  procedure doc_header__get_simple
  (
    p_id number,
    p_doc_header_rec out sys_refcursor,
    p_error_code out number
  );

  procedure doc_header__get_vendor_doc
  (
    p_stock_id number,
    p_vendor_doc nvarchar2,
    p_doc_header_rec out sys_refcursor,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_header__ins (
      p_user_id                  NVARCHAR2,
      p_create_date              DATE,
      p_create_time              DATE,
      p_document_type_id         NUMBER,
      p_document_no              NVARCHAR2,
      p_status_id                NUMBER,
      p_stock_out_id             NUMBER,
      p_stock_in_id              NUMBER,
      p_vendor_doc               NVARCHAR2,
      p_valid_until              DATE,
      p_description              NVARCHAR2 := NULL,
      p_user_comment             NVARCHAR2,
      p_last_user                NVARCHAR2,
      p_id                 OUT   NUMBER,
      p_handle_tran              CHAR := 'Y',
      p_error_code         OUT   NUMBER,
      p_vendor_id                NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_header__del (
      p_doc_header_id         NUMBER,
      p_handle_tran           CHAR := 'Y',
      p_error_code      OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_header_user_comment__upd (
      p_id                       NUMBER,
      p_user_comment             NVARCHAR2,
      p_handle_tran              CHAR := 'Y',
      p_error_code       OUT     NUMBER
      );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_header_user_comment__upd (
      p_doc_no                   NVARCHAR2,
      p_user_comment             NVARCHAR2,
      p_handle_tran              CHAR := 'Y',
      p_error_code       OUT     NUMBER
      );

/****************************************************************************
<name>          DOC_HEADER_user_comment__Upd_1
<author>        Sergey Ermakov
<version>       1.0   08.04.2009
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_id NUMBER
                p_user_comment NVARCHAR2
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification

  Процедура doc_header_user_comment__upd_1 аналогична процедуре
   PROCEDURE doc_header_user_comment__upd (
      p_id                        NUMBER,
      p_user_comment              NVARCHAR2,
      p_handle_tran               CHAR := 'Y',
      p_error_code       OUT      NUMBER
   )
  Создана для поддержки FORIS.DataAccess
****************************************************************************/
   PROCEDURE doc_header_user_comment__upd_1 (
      p_id                        NUMBER,
      p_user_comment              NVARCHAR2,
      p_handle_tran               CHAR := 'Y',
      p_error_code       OUT      NUMBER
   );

/****************************************************************************
<name>          DOC_HEADER_user_comment__Upd_2
<author>        Sergey Ermakov
<version>       1.0   08.04.2009
<Description>
<Prerequisites>
<Application>   Stock Management
<Parameters>    p_doc_num NVARCHAR2
                p_user_comment NVARCHAR2
                p_handle_tran CHAR := 'Y'  -'Y' procedure starts, commits or rollbacks a transaction
                                           -'N' no transaction handling
                                           -'S' procedure sets a savepoint/rollbacks to savepoint
                p_error_code OUT NUMBER    - 0  procedure was finished successfully,
                                           - else returns error identification

  Процедура doc_header_user_comment__upd_2 аналогична процедуре
   PROCEDURE doc_header_user_comment__upd (
      p_doc_no                    NVARCHAR2,
      p_user_comment              NVARCHAR2,
      p_handle_tran               CHAR := 'Y',
      p_error_code       OUT      NUMBER
   )
  Создана для поддержки FORIS.DataAccess
****************************************************************************/
   PROCEDURE doc_header_user_comment__upd_2 (
      p_doc_no                    NVARCHAR2,
      p_user_comment              NVARCHAR2,
      p_handle_tran               CHAR := 'Y',
      p_error_code       OUT      NUMBER
   );

----------------------------------!---------------------------------------------
  function seek_doc_header_so
  (
    p_stock_id number,
    p_doc_type_id number,
    p_status_id number,
    p_doc_date1 date,
    p_doc_date2 date
  ) return ct_number;

  function seek_doc_header_si
  (
    p_stock_id number,
    p_doc_type_id number,
    p_status_id number,
    p_doc_date1 date,
    p_doc_date2 date
  ) return ct_number;

  procedure doc_header__rpt1
  (
    p_id number,
    p_stock_id number,
    p_type number,
    p_status_id number,
    p_date_start date,
    p_date_end date,
    p_filter nvarchar2,
    p_model_id number,
    p_seria_start nvarchar2,
    p_seria_end nvarchar2,
    p_doc_report_1_rec out sys_refcursor,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  procedure doc_report1_i
  (
    p_dh_id number,
    p_result out sys_refcursor
  );

  procedure doc_report2_i
  (
    p_doc_num nvarchar2,
    p_result out sys_refcursor
  );

  procedure v_doc_report_1__get
  (
    p_doc_header_id number,
    p_doc_number nvarchar2,
    p_doc_report_1_rec out sys_refcursor,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_number_year__get (p_year OUT NUMBER, p_error_code OUT NUMBER);

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_number_stock__ins (
      p_stock_id            NUMBER,
      p_handle_tran         CHAR := 'Y',
      p_error_code    OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  : Skripnik Petr
   -- Changed : 09.10.2006 12:28
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE seria__set_status (
      p_stock_id                   aastockid,
      p_equipment_model_id         aaequipmentmodelid,
      p_seria_start                aaseriastart,
      p_seria_end                  aaseriaend,
      p_status                     aastatus,
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  : Skripnik Petr
   -- Changed : 09.10.2006 11:44
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE equipment__upd_valid_until (
      p_stock_id                   aastockid,
      p_equipment_model_id         aaequipmentmodelid,
      p_seria_start                aaseriastart,
      p_seria_end                  aaseriaend,
      p_valid_until                aavaliduntil,
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_detail__bulk_ins (
      p_doc_header_id              aadocheaderid,
      p_equipment_model_id         aaeqmodelid,
      p_seria_start                aastartseries,
      p_seria_end                  aaendseries,
      p_quantity                   aaquantity,
      p_status_id                  aastatus,
      p_product                    aaproduct,
      p_valid_until                aavaliduntil,
      p_equipment_batch_id         aaequipmentbatchid,
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  : Skripnik Petr
-- Changed : Skripnik Petr 03.05.2007 FOR -> FORALL
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_detail__bulk_ins_2 (
      p_doc_header_id              aadocheaderid,
      p_equipment_model_id         aaeqmodelid,
      p_seria_start                t_varchar,
      p_seria_end                  t_varchar,
      p_quantity                   aaquantity,
      p_status_id                  aastatus,
      p_product                    aaproduct,
      p_valid_until                aavaliduntil,
      p_equipment_batch_id         aaequipmentbatchid,   -- в массиве значение "-1" есть NULL
      p_length                     NUMBER,
      p_handle_tran                CHAR := 'Y',
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_header__get_filtered (
      p_date_begin             DATE,
      p_date_end               DATE,
      p_doc_header_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_header__get_prev_state (
      p_date_begin             DATE,
      p_date_end               DATE,
      p_doc_header_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_header__get_prev_state_2 (
      p_serial_number          NVARCHAR2,
      p_equipment_id           NUMBER,
      p_date_begin             DATE,
      p_date_end               DATE,
      p_doc_header_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_header__get_filtered_4 (
      p_serial_number          NVARCHAR2,
      p_equipment_id           NUMBER,
      p_date_begin             DATE,
      p_date_end               DATE,
      p_doc_header_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_header_auto_action__ins (
      p_doc_header_id         NUMBER,
      p_action_id             NUMBER,
      p_handle_tran           CHAR := 'Y',
      p_error_code      OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_header_auto_action__del (
      p_doc_header_id         NUMBER,
      p_handle_tran           CHAR := 'Y',
      p_error_code      OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE doc_header_auto_action__get (
      p_doc_header_id          NUMBER,
      p_doc_header_rec   OUT   t_cursor,
      p_error_code       OUT   NUMBER
   );

--------------------------------------------------------------------------------
   -- Author  :
   -- Created :
   -- Editor  :
   -- Changed :
   -- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE get_doc_types (
      p_doc_types_rec     OUT   t_cursor,
      p_error_code        OUT   NUMBER
   );

   PROCEDURE prepare_doc_detail_by_sn (
      p_serial_number          NVARCHAR2
   );

   function GetEquipmentMoveDirection(
     p_doc_type_id         number,
     p_all_stocks          number,
     p_from_stock_id       number,
     p_to_stock_id         number
     ) return number;

----------------------------------!---------------------------------------------
  procedure get_result_cursor001(p_dh_ids ct_number, p_trim_empty boolean, p_result out sys_refcursor);
  procedure get_result_cursor002(p_stock_in_id number, p_vendor_doc nvarchar2, p_result out sys_refcursor);
  procedure get_result_cursor003(p_dh_ids ct_number, p_trim_empty boolean, p_result out sys_refcursor);

  --!_! ex-view VW_DOC_REPORT_1
  procedure get_result_cursor004(p_dh_ids ct_number, p_trim_empty boolean, p_result out sys_refcursor);
  --!_! ex-view VW_DOC_REPORT_1
  procedure get_result_cursor005(p_dh_ids ct_number, p_trim_empty boolean, p_stock_id number, p_model_id number, p_seria_start nvarchar2, p_seria_end nvarchar2, p_result out sys_refcursor);

----------------------------------!---------------------------------------------

END;

/
