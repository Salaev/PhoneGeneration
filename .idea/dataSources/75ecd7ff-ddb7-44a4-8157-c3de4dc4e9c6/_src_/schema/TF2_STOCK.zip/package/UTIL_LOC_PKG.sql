CREATE package util_loc_pkg is

----------------------------------!---------------------------------------------
  c_ora_eq_not_exist_on_stock    constant number(5) := -20135;

  c_ora_locker_session_not_fnd   constant number(5) := -20500;
  c_ora_table_is_empty           constant number(5) := -20501;
  c_ora_incorrect_sn             constant number(5) := -20502;
  c_ora_mutex_timeout            constant number(5) := -20503;
  c_ora_ranges_intersection_lck  constant number(5) := -20504;
  c_ora_locker_id_broken         constant number(5) := -20505;
  c_ora_doc_locker_is_broken     constant number(5) := -20506;
  c_ora_doc_locker_group_not_fnd constant number(5) := -20507;
  c_ora_ranges_intersection_ss   constant number(5) := -20508;
  
  c_ora_doc_header_id_not_set    constant number(5) := -20510;
  c_ora_doc_already_locked       constant number(5) := -20511;
  c_ora_wrong_doc_locker_type    constant number(5) := -20512;
  c_ora_wrong_eq_operation       constant number(5) := -20513;
  
  c_ora_wrong_doc_type           constant number(5) := -20520;
  c_ora_document_not_found       constant number(5) := -20521;
  c_ora_failed_lock              constant number(5) := -20522;
  c_ora_wrong_doc_state          constant number(5) := -20523;
  c_ora_wrong_doc_details        constant number(5) := -20524;
  c_ora_doc_type_not_found       constant number(5) := -20525;
  
  c_ora_stock_not_exists         constant number(5) := -20530;
  
  c_ora_access_denied_to_stock   constant number(5) := -20600;
  c_ora_access_denied_to_doc_act constant number(5) := -20601;

  --!_!
  c_ora_equipment_not_found      constant number(5) := -20603; --!_! USE WITH CAUTION; interferes with util_pkg.c_ora_table_not_found (-20603)
  --!_!

  c_ora_eqipment_absent_in_ss    constant number(5) := -20605;

  c_ora_incompatible_eq_type     constant number(5) := -20608;
  c_ora_stock_out_nspec          constant number(5) := -20609;
  c_ora_stock_in_nspec           constant number(5) := -20610;
  c_ora_mandatory_value_nspec    constant number(5) := -20611;
  c_ora_wrong_eq_state           constant number(5) := -20612;
  c_ora_wrong_stock              constant number(5) := -20613;
  c_ora_linked_error             constant number(5) := -20614;
  c_ora_duplicated_value         constant number(5) := -20615;
  c_ora_incompatible_data        constant number(5) := -20616;
  
  c_ora_not_implemented_code     constant number(5) := -20999;
  
----------------------------------!---------------------------------------------
  c_msg_eq_not_exist_on_stock    constant varchar2(200) := 'Equipment not exists on stock';

  c_msg_locker_session_not_fnd   constant varchar2(200) := 'Locker session not found';
  c_msg_table_is_empty           constant varchar2(200) := 'Input table TT_LOCKER_DATA is empty(need commit data in TT_LOCKER_DATA_RANGE)';
  c_msg_eq_table_is_empty        constant varchar2(200) := 'Input table TT_LOCKER_DATA_EQ is empty(need commit data in TT_LOCKER_DATA_EQ)';
  c_msg_incorrect_sn             constant varchar2(200) := 'Incorrect sn number or it''s length in ranges:';
  c_msg_mutex_timeout            constant varchar2(200) := 'The waiting time of switching of a mutex is exceeded';
  c_msg_ranges_intersection_lck  constant varchar2(200) := 'Ranges intersection is found in locker in:';
  c_msg_locker_id_broken         constant varchar2(200) := 'Locker is broken';
  c_msg_doc_locker_is_broken     constant varchar2(200) := 'Doc locker is broken';
  c_msg_doc_locker_group_not_fnd constant varchar2(200) := 'Doc locker group not found';
  c_msg_ranges_intersection_ss   constant varchar2(200) := 'Ranges intersection is found in stock_state in:';
  
  c_msg_doc_header_id_not_set    constant varchar2(200) := 'Doc header id not set';
  c_msg_doc_already_locked       constant varchar2(200) := 'Doc already locked';
  c_msg_wrong_doc_locker_type    constant varchar2(200) := 'Wrong doc locker type';
  c_msg_wrong_eq_operation       constant varchar2(200) := 'Wrong equipment operation';
  
  c_msg_wrong_doc_type           constant varchar2(200) := 'Wrong document type';
  c_msg_document_not_found       constant varchar2(200) := 'Document not found';
  c_msg_failed_lock              constant varchar2(200) := 'Failed lock: resource busy';
  c_msg_wrong_doc_state          constant varchar2(200) := 'Wrong document state';
  c_msg_wrong_doc_details        constant varchar2(200) := 'Wrong document details';
  c_msg_doc_type_not_found       constant varchar2(200) := 'Document type not found';
  
  c_msg_stock_not_exists         constant varchar2(200) := 'Stock not exist';
  
  c_msg_access_denied_to_stock   constant varchar2(200) := 'Access to stock denied or stock not found';
  c_msg_access_denied_to_doc_act constant varchar2(200) := 'Access to create movement document is denied';

  --!_!
  c_msg_equipment_not_found      constant varchar2(200) := 'Equipment not found'; --!_! -20603
  --!_!

  c_msg_eqipment_absent_in_ss    constant varchar2(200) := 'Equipment is absent in stock state';

  c_msg_incompatible_eq_type     constant varchar2(200) := 'Incompatible equipment type';
  c_msg_stock_out_nspec          constant varchar2(200) := 'Outgoing stock is not specified';
  c_msg_stock_in_nspec           constant varchar2(200) := 'Incoming stock is not specified';
  c_msg_mandatory_value_nspec    constant varchar2(200) := 'Mandatory value is not specified';
  c_msg_wrong_eq_state           constant varchar2(200) := 'Wrong equipment state';
  c_msg_wrong_stock              constant varchar2(200) := 'Wrong stock';
  c_msg_linked_error             constant varchar2(200) := 'Linked error';
  c_msg_duplicated_value         constant varchar2(200) := 'Duplicated value';
  c_msg_incompatible_data        constant varchar2(200) := 'Incompatible data';
  
  c_msg_not_implemented_code     constant varchar2(200) := 'Not implemented.';

----------------------------------!---------------------------------------------
  procedure log_clob(p_log_clob_type_id number, p_dsc clob);

----------------------------------!---------------------------------------------
  procedure touch_number(p_value number);
  procedure touch_varchar(p_value varchar2);
  procedure touch_nvarchar(p_value nvarchar2);
  procedure touch_date(p_value date);
  procedure touch_boolean(p_value boolean);

----------------------------------!---------------------------------------------
  procedure Save_Flag_number(p_value number, p_slot in out nocopy number, p_flag in out nocopy boolean);
  procedure Restore_Flag_number(p_value in out nocopy number, p_slot number, p_flag in out nocopy boolean);

----------------------------------!---------------------------------------------
  function values2keys_ct_number(p_values ct_number, p_ids ct_number, p_skip_value number := null) return util_pkg.cit_number;
  function values2keys_ct_varchar(p_values ct_varchar, p_ids ct_number, p_skip_value varchar := null) return util_pkg.cit_varchar;

----------------------------------!---------------------------------------------
  function ids2keys(p_coll ct_number) return util_pkg.cit_number;
  function keys2ids(p_coll util_pkg.cit_number) return ct_number;
  function keys2simple(p_coll util_pkg.cit_number, p_master_count number := null) return ct_number;
  function restore_ids_from_keys(p_coll util_pkg.cit_number, p_first_id number, p_last_id number, p_empty_val number := null) return ct_number;

----------------------------------!---------------------------------------------
  procedure add_save_ind_cit_number(p_coll in out nocopy util_pkg.cit_number, p_coll_add util_pkg.cit_number);
  procedure add_save_ind_cit_varchar(p_coll in out nocopy util_pkg.cit_varchar, p_coll_add util_pkg.cit_varchar);

----------------------------------!---------------------------------------------
  function make_control_digit(p_iccid varchar2) return varchar2;

----------------------------------!---------------------------------------------
  function obtain_length_ct_varchar_s(p_val ct_varchar_s) return ct_number;
  function obtain_length_ct_varchar(p_val ct_varchar) return ct_number;
  function obtain_length_ct_nvarchar_s(p_val ct_nvarchar_s) return ct_number;
  function obtain_length_ct_nvarchar(p_val ct_nvarchar) return ct_number;

----------------------------------!---------------------------------------------

end;
/
