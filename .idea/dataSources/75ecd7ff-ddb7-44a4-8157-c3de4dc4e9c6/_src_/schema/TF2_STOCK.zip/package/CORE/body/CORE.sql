CREATE PACKAGE BODY             "CORE" 
AS
   pkg_name          CONSTANT VARCHAR2 (5)  := 'core';
   ctx_name          CONSTANT VARCHAR2 (8)  := 'ctx_core';
   ctx_name_global   CONSTANT VARCHAR2 (15) := 'ctx_core_global';

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Преобразует логический тип в символьный
--------------------------------------------------------------------------------
   FUNCTION boolean_to_char (p_value IN BOOLEAN)
      RETURN VARCHAR2
   IS
      l_result   VARCHAR2 (5);
   BEGIN
      IF p_value
      THEN
         l_result := 'TRUE';
      ELSIF NOT p_value
      THEN
         l_result := 'FALSE';
      ELSE
         l_result := 'NULL';
      END IF;

      RETURN l_result;
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END boolean_to_char;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 08.09.2008
-- Version :
-- Modification :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE check_handle_tran (p_handle_tran IN CHAR, p_procedure IN VARCHAR2)
   IS
   BEGIN
      IF    p_handle_tran NOT IN (c_handle_tran_s, c_handle_tran_y, c_handle_tran_n)
         OR p_handle_tran IS NULL
      THEN
         raise_application_error (c_ora_invalid_handle, 'Invalid handle transaction parameter.');
      END IF;

      IF p_handle_tran = c_handle_tran_s
      THEN
         EXECUTE IMMEDIATE 'SAVEPOINT ' || p_procedure || 'S';
      END IF;
   END check_handle_tran;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.11.2006 10:16
-- Editor  :
-- Changed :
-- Purpose : Очищает контекст
--------------------------------------------------------------------------------
   PROCEDURE clear_context
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'clear_context';
   BEGIN
      DBMS_SESSION.clear_context (ctx_name, RTRIM (pkg_name, '.'));
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END clear_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Version :
-- Modification :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE compile_pkg
   IS
      v_result   BOOLEAN := TRUE;
   BEGIN
      FOR cv_record IN (SELECT    'alter '
                               || REPLACE (object_type, 'BODY')
                               || ' '
                               || owner
                               || '.'
                               || object_name
                               || ' compile '
                               || DECODE (object_type, 'PACKAGE BODY', 'BODY') strsql,
                               object_name
                          FROM all_objects
                         WHERE status = 'INVALID' AND owner = USER AND object_name NOT LIKE 'BIN$%')
      LOOP
         BEGIN
            DBMS_OUTPUT.put_line (cv_record.strsql);
            DBMS_UTILITY.exec_ddl_statement (cv_record.strsql);
            DBMS_OUTPUT.put_line (RPAD (cv_record.object_name, 30) || ' - ' || 'OK!');
         EXCEPTION
            WHEN OTHERS
            THEN
               v_result := FALSE;
               DBMS_OUTPUT.put_line (RPAD (cv_record.object_name, 30) || ' - ' || SQLERRM (SQLCODE));
         END;
      END LOOP;

      IF v_result
      THEN
         DBMS_OUTPUT.put_line ('Ok');
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         NULL;
   END compile_pkg;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Version :
-- Modification :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE compile_schema
   IS
      v_result   BOOLEAN := TRUE;
   BEGIN
      DBMS_UTILITY.compile_schema (SYS_CONTEXT ('USERENV', 'CURRENT_SCHEMA'));
   EXCEPTION
      WHEN OTHERS
      THEN
         NULL;
   END compile_schema;

--------------------------------------------------------------------------------
-- Author  : Tomas Kyte http://www.dbgroup.ru/v19.html
-- Created :
-- Editor  :
-- Changed :
-- Purpose : Выполнение DDL
--------------------------------------------------------------------------------
   PROCEDURE do_ddl (p_stmt IN LONG, p_level IN NUMBER)
   IS
   BEGIN
      DBMS_OUTPUT.put_line (RPAD (CHR (9), p_level - 1, CHR (9)) || p_stmt);

      EXECUTE IMMEDIATE p_stmt;
   END do_ddl;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Version :
-- Modification :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE event_logger (
      p_message        IN   log_event.event_message%TYPE,   -- text to send to output
      p_level          IN   NUMBER,   -- level of debuging
      p_event_type     IN   log_event.event_type%TYPE,   -- event type: I - Information, W - Warning, Er - Error, D - Debug, Ex - External, A - Audit
      p_event_source   IN   log_event.event_source%TYPE   -- name of the source where this calling is performed
   )
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
      v_user          log_event.event_user%TYPE;   -- name of the user who runs this procedure
      v_terminal      log_event.event_terminal%TYPE;   -- name of the computer this procedure is run at
      v_file_handle   UTL_FILE.file_type;   -- file handle of OS flat file
      v_message       VARCHAR2 (2000);
      v_schema        VARCHAR2 (50);
      v_date_string   VARCHAR2 (50);
   BEGIN
      IF g_log_output IN
                       (c_output_to_pipe, c_output_to_buffer, c_output_to_table, c_output_to_file)
      THEN
         --Получим системную информацию
         v_terminal := SYS_CONTEXT ('USERENV', 'TERMINAL');
         v_user := SYS_CONTEXT ('USERENV', 'OS_USER');
         v_schema := SYS_CONTEXT ('USERENV', 'CURRENT_SCHEMA');
         v_date_string := TO_CHAR (CURRENT_TIMESTAMP, 'DD.MM.YYYY HH24:MI:SSxFF');
         v_message :=
            (   'Date: '
             || v_date_string
             || ' User: '
             || v_user
             || ' Computer: '
             || v_terminal
             || ' Called in: '
             || p_event_source
             || ' Text: '
             || p_message
            );

         CASE g_log_output
            WHEN c_output_to_pipe
            THEN
               DBMS_PIPE.pack_message (v_message);

               IF DBMS_PIPE.send_message (g_pipe_channel, 3) > 0
               THEN
                  DBMS_PIPE.PURGE (g_pipe_channel);
               END IF;
            WHEN c_output_to_buffer
            THEN
               IF LENGTH (p_event_source || ': ' || p_message) >= 255
               THEN
                  DBMS_OUTPUT.put_line (SUBSTR (p_event_source || ': ' || p_message, 1, 250)
                                        || '...'
                                       );
               ELSE
                  DBMS_OUTPUT.put_line (p_event_source || ': ' || p_message);
               END IF;
            WHEN c_output_to_file
            THEN
               LOOP
                  v_file_handle :=
                            UTL_FILE.fopen (v_schema, 'debug_' || LOWER (v_terminal) || '.log',
                                            'a');

                  IF UTL_FILE.is_open (v_file_handle)
                  THEN
                     IF LENGTH (v_message) >= 1022
                     THEN
                        UTL_FILE.put_line (v_file_handle, SUBSTR (v_message, 1, 1019) || '...');   --MAX 1023 B
                     ELSE
                        UTL_FILE.put_line (v_file_handle, v_message);
                     END IF;

                     UTL_FILE.fclose (v_file_handle);
                     EXIT;
                  END IF;
               END LOOP;
            WHEN c_output_to_table
            THEN
               BEGIN
                  INSERT INTO log_event
                              (event_id, event_type, event_source, event_message,
                               event_user, event_terminal, event_time
                              )
                       VALUES (log_event_seq.NEXTVAL, p_event_type, p_event_source, p_message,
                               v_user, v_terminal, SYSDATE
                              );
               END;
         END CASE;
      END IF;

      COMMIT;
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line (SUBSTR ('Ошибка в core.event_logger :' || SQLERRM, 1, 255));
         ROLLBACK;

         IF g_log_output = c_output_to_file
         THEN
            IF UTL_FILE.is_open (v_file_handle)
            THEN
               UTL_FILE.fclose (v_file_handle);
            END IF;
         END IF;
   END event_logger;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Возвращает пустой ассоциативный цифровой массив
--------------------------------------------------------------------------------
   FUNCTION func_empty_ti_number
      RETURN ti_number
   IS
   BEGIN
      RETURN empty_ti_number;
   END func_empty_ti_number;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Возвращает пустой ассоциативный символьный массив
--------------------------------------------------------------------------------
   FUNCTION func_empty_ti_varchar
      RETURN ti_varchar
   IS
   BEGIN
      RETURN empty_ti_varchar;
   END func_empty_ti_varchar;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Возвращает значение контекста
--------------------------------------------------------------------------------
   FUNCTION get_context (p_name IN VARCHAR2)
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN SYS_CONTEXT (ctx_name, p_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END get_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Возвращает значение контекста
--------------------------------------------------------------------------------
   FUNCTION get_global_context (p_name IN VARCHAR2)
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN SYS_CONTEXT (ctx_name_global, p_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END get_global_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 05.09.2008
-- Editor  :
-- Changed :
-- Purpose : Получает значение глобальной переменной для всех сессий (таблица GLOBAL_VALUE)
--!!         Незапускать отладчик в этой процедуре
--------------------------------------------------------------------------------
   FUNCTION get_global_val (p_name IN VARCHAR2)
      RETURN VARCHAR2
   AS
      prc_name   CONSTANT VARCHAR2 (31)             := 'get_global_val';
      v_result            global_value.VALUE%TYPE;
   BEGIN
      --Получим значение
      SELECT UPPER (VALUE)
        INTO v_result
        FROM global_value
       WHERE NAME = UPPER (p_name);

      RETURN v_result;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         v_result := c_text_no_data_found;
         RETURN v_result;
   END get_global_val;

--
--
--
   FUNCTION get_t_v (pti_v core.ti_varchar)
      RETURN t_v
   IS
      vt_res   t_v := t_v ();
   BEGIN
      FOR i IN 1 .. pti_v.COUNT
      LOOP
         IF pti_v (i) IS NOT NULL
         THEN
            vt_res.EXTEND;
            vt_res (vt_res.COUNT) := pti_v (i);
         END IF;
      END LOOP;

      RETURN vt_res;
   END get_t_v;

--
--
--
   FUNCTION get_t_n (pti_n core.ti_number)
      RETURN t_n
   IS
      vt_res   t_n := t_n ();
   BEGIN
      FOR i IN 1 .. pti_n.COUNT
      LOOP
         IF pti_n (i) IS NOT NULL
         THEN
            vt_res.EXTEND;
            vt_res (vt_res.COUNT) := pti_n (i);
         END IF;
      END LOOP;

      RETURN vt_res;
   END get_t_n;

--
--
--
   FUNCTION get_ti_number (pti_number core.ti_number, p_result_length NUMBER)
      RETURN ti_number
   IS
      prc_name   CONSTANT VARCHAR2 (31)  := 'get_ti_number';
      v_event_source      VARCHAR2 (63);
      vti_res             core.ti_number;
   BEGIN
      v_event_source := pkg_name || '.' || prc_name;
      core.event_logger (core.c_text_start,
                         core.c_debug_level_1,
                         core.c_event_type_d,
                         v_event_source
                        );

      FOR i IN 1 .. p_result_length
      LOOP
         IF pti_number.EXISTS (i)
         THEN
            vti_res (i) := pti_number (i);
         ELSE
            vti_res (i) := NULL;
         END IF;

         core.event_logger (vti_res (i), core.c_debug_level_1, core.c_event_type_d, v_event_source);
      END LOOP;

      core.event_logger (core.c_text_end, core.c_debug_level_1, core.c_event_type_d, v_event_source);
      RETURN vti_res;
   END get_ti_number;

--
--
--
   FUNCTION get_ti_varchar (pti_varchar core.ti_varchar, p_result_length NUMBER)
      RETURN ti_varchar
   IS
      prc_name   CONSTANT VARCHAR2 (31)   := 'get_ti_varchar';
      v_event_source      VARCHAR2 (63);
      vti_res             core.ti_varchar;
   BEGIN
      v_event_source := pkg_name || '.' || prc_name;
      core.event_logger (core.c_text_start,
                         core.c_debug_level_1,
                         core.c_event_type_d,
                         v_event_source
                        );

      FOR i IN 1 .. p_result_length
      LOOP
         IF pti_varchar.EXISTS (i)
         THEN
            vti_res (i) := pti_varchar (i);
         ELSE
            vti_res (i) := NULL;
         END IF;

         core.event_logger (vti_res (i), core.c_debug_level_1, core.c_event_type_d, v_event_source);
      END LOOP;

      core.event_logger (core.c_text_end, core.c_debug_level_1, core.c_event_type_d, v_event_source);
      RETURN vti_res;
   END get_ti_varchar;

--
--
--
   FUNCTION get_ti_nvarchar (pti_nvarchar core.ti_nvarchar, p_result_length NUMBER)
      RETURN ti_nvarchar
   IS
      vti_res   core.ti_nvarchar;
   BEGIN
      FOR i IN 1 .. p_result_length
      LOOP
         IF pti_nvarchar.EXISTS (i)
         THEN
            vti_res (i) := pti_nvarchar (i);
         ELSE
            vti_res (i) := NULL;
         END IF;
      END LOOP;

      RETURN vti_res;
   END get_ti_nvarchar;

--
--
--
   FUNCTION get_ti_date (pti_date core.ti_date, p_result_length NUMBER)
      RETURN ti_date
   IS
      vti_res   core.ti_date;
   BEGIN
      FOR i IN 1 .. p_result_length
      LOOP
         IF pti_date.EXISTS (i)
         THEN
            vti_res (i) := pti_date (i);
         ELSE
            vti_res (i) := NULL;
         END IF;
      END LOOP;

      RETURN vti_res;
   END get_ti_date;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Получает результаты работы таймера
--------------------------------------------------------------------------------
   FUNCTION get_timer_result (
      p_event_name_start   IN   VARCHAR2 DEFAULT c_text_start,
      p_event_name_end     IN   VARCHAR2 DEFAULT c_text_end
   )
      RETURN NUMBER
   AS
      v_s        NUMBER;   -- начало отсчета
      v_e        NUMBER;   -- конец отсчета
      v_result   NUMBER;   -- результат до сотых долей секунд
   BEGIN
      v_s := NVL (get_context ('timer ' || p_event_name_start), 0);
      v_e := NVL (get_context ('timer ' || p_event_name_end), 0);

      IF (v_s <> 0) AND (v_e <> 0)
      THEN
         v_result := (TO_NUMBER (v_e) - TO_NUMBER (v_s)) / 100;
      ELSE
         v_result := 0;
      END IF;

      RETURN v_result;
   EXCEPTION
      WHEN OTHERS
      THEN
         v_result := 0;
   END get_timer_result;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Version :
-- Modification :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   FUNCTION handle_error (
      p_ora_error_number   IN   NUMBER,
      p_handle_tran        IN   CHAR,
      p_package            IN   VARCHAR2,
      p_procedure          IN   VARCHAR2
   )
      RETURN NUMBER
   IS
      v_error_code     NUMBER;
      v_event_source   VARCHAR2 (63);
   BEGIN
      v_event_source := p_package || '.' || p_procedure;

      IF (p_ora_error_number <= -20000)
      THEN
         v_error_code := p_ora_error_number + 20000;
      ELSE
         v_error_code := p_ora_error_number;
      END IF;

      CASE p_handle_tran
         WHEN c_handle_tran_s
         THEN
            EXECUTE IMMEDIATE 'ROLLBACK TO SAVEPOINT ' || p_procedure || 'S';
         WHEN c_handle_tran_y
         THEN
            ROLLBACK;
         ELSE
            NULL;
      END CASE;

      event_logger (TO_NUMBER (v_error_code), c_debug_level_0, c_event_type_er, v_event_source);
      RETURN v_error_code;
   END handle_error;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Version :
-- Modification :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   FUNCTION handle_error (
      p_ora_error_number   IN   NUMBER,
      p_ora_message        IN   VARCHAR2,
      p_message            IN   VARCHAR2,
      p_handle_tran        IN   CHAR,
      p_package            IN   VARCHAR2,
      p_procedure          IN   VARCHAR2
   )
      RETURN NUMBER
   IS
      v_error_code      NUMBER;
      v_event_source    VARCHAR2 (60);
      v_error_message   VARCHAR2 (4000);
   BEGIN
      v_event_source := p_package || '.' || p_procedure;

      IF (p_ora_error_number <= -20000)
      THEN
         v_error_code := p_ora_error_number + 20000;
      ELSE
         v_error_code := p_ora_error_number;
      END IF;

      CASE p_handle_tran
         WHEN c_handle_tran_s
         THEN
            EXECUTE IMMEDIATE 'ROLLBACK TO SAVEPOINT ' || p_procedure || 'S';
         WHEN c_handle_tran_y
         THEN
            ROLLBACK;
         ELSE
            NULL;
      END CASE;

      -- create error message
      v_error_message :=
         SUBSTR (   'Error number: '
                 || TO_CHAR (p_ora_error_number)
                 || CHR (10)
                 || 'Error message: '
                 || p_ora_message
                 || CHR (10)
                 || p_message,
                 1,
                 4000
                );
      event_logger (v_error_message, c_debug_level_0, c_event_type_er, v_event_source);
      RETURN v_error_code;
   END handle_error;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Просмотрим контекст
--------------------------------------------------------------------------------
   PROCEDURE list_context
   IS
      prc_name   CONSTANT VARCHAR2 (100)            := 'list_context';
      v_list              DBMS_SESSION.appctxtabtyp;
      v_size              NUMBER;
      v_strline           VARCHAR2 (255);
      v_loop              PLS_INTEGER;
   BEGIN
      DBMS_SESSION.list_context (v_list, v_size);

      FOR v_loop IN 1 .. v_list.COUNT
      LOOP
         v_strline :=
               v_list (v_loop).namespace
            || ': '
            || v_list (v_loop).ATTRIBUTE
            || ' = '
            || v_list (v_loop).VALUE;
      END LOOP;
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END list_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Возвращает значение контекста
--------------------------------------------------------------------------------
   FUNCTION list_to_pltable (p_list IN VARCHAR2, p_delimiter IN CHAR DEFAULT ',')
      RETURN t_v
   IS
      prc_name    CONSTANT NVARCHAR2 (100)  := 'list_to_pltable';
      v_string_tbl         t_v              := t_v ();
      v_start_position     NUMBER;
      v_end_postion        NUMBER;
      v_delimiter_length   NUMBER;
      v_expanded_list      VARCHAR2 (32767);
   BEGIN
      IF p_delimiter IS NULL
      THEN
         raise_application_error (c_ora_invalid_delimiter, 'Invalid Delimiter');
      END IF;

      v_expanded_list := p_list || p_delimiter;
      v_delimiter_length := LENGTH (p_delimiter);
      v_end_postion := 1 - v_delimiter_length;

      LOOP
         v_start_position := v_end_postion + v_delimiter_length;
         v_end_postion := INSTR (v_expanded_list, p_delimiter, v_start_position);
         EXIT WHEN v_end_postion = 0;
         v_string_tbl.EXTEND;
         v_string_tbl (v_string_tbl.LAST) :=
                       SUBSTR (v_expanded_list, v_start_position, v_end_postion - v_start_position);
      END LOOP;

      RETURN v_string_tbl;
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END list_to_pltable;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Pipelined-функция. Использется, чтобы возвратить требуемое
-- количество записей типа даты
--------------------------------------------------------------------------------
   FUNCTION pivot_date (p_start IN DATE, p_limit IN NUMBER)
      RETURN t_d PIPELINED
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := 'pivot_date';
   BEGIN
      FOR i IN 0 .. p_limit - 1
      LOOP
         PIPE ROW (p_start + i);
      END LOOP;

      RETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END pivot_date;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Pipelined-функция. Использется, чтобы возвратить требуемое
-- количество записей чилового типа
--------------------------------------------------------------------------------
   FUNCTION pivot_num (p_start IN NUMBER, p_end IN NUMBER)
      RETURN t_n PARALLEL_ENABLE PIPELINED
   AS
      prc_name   CONSTANT NVARCHAR2 (100) := 'pivot_num';
   BEGIN
      FOR i IN p_start .. p_end
      LOOP
         PIPE ROW (i);
      END LOOP;

      RETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END pivot_num;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Функция преобразовывает таблицу PL/SQL в список с разделителями-запятыми
--------------------------------------------------------------------------------
   FUNCTION pltable_to_list (p_tbl IN t_v, p_delimiter IN CHAR DEFAULT ',')
      RETURN VARCHAR2
   IS
      prc_name   CONSTANT NVARCHAR2 (100)  := pkg_name || 'pltable_to_list_fn';
      v_list              VARCHAR2 (32767);
   BEGIN
      IF p_delimiter IS NULL
      THEN
         raise_application_error (c_ora_invalid_delimiter, 'Invalid Delimiter');
      END IF;

      FOR i IN 1 .. p_tbl.LAST
      LOOP
         IF INSTR (p_tbl (i), p_delimiter) != 0
         THEN
            raise_application_error (c_ora_invalid_delimiter, 'Invalid Delimiter');
         END IF;

         IF i > 1
         THEN
            v_list := v_list || p_delimiter || p_tbl (i);
         ELSE
            v_list := v_list || p_tbl (i);
         END IF;
      END LOOP;

      RETURN v_list;
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END pltable_to_list;

--------------------------------------------------------------------------------
-- Author  : http://www.oracle.com/technology/oramag/code/tips2004/050304.html
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Преобразовывает  строки в столбцы
--------------------------------------------------------------------------------
   FUNCTION row_to_col (p_slct IN VARCHAR2, p_dlmtr IN VARCHAR2 DEFAULT ',')
      RETURN VARCHAR2   --AUTHID CURRENT_USER
   AS
      TYPE c_refcur IS REF CURSOR;

      v_str      VARCHAR2 (4000);
      v_colval   VARCHAR2 (4000);
      c_dummy    c_refcur;
      l          NUMBER;
   BEGIN
      OPEN c_dummy FOR p_slct;

      LOOP
         FETCH c_dummy
          INTO v_colval;

         EXIT WHEN c_dummy%NOTFOUND;
         v_str := v_str || p_dlmtr || v_colval;
      END LOOP;

      CLOSE c_dummy;

      RETURN SUBSTR (v_str, 2);
   EXCEPTION
      WHEN OTHERS
      THEN
         v_str := SQLERRM;

         IF c_dummy%ISOPEN
         THEN
            CLOSE c_dummy;
         END IF;

         RETURN v_str;
   END row_to_col;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Задает значение контексту
--!!         Констекст позволяет ввсети до 26 символов
--------------------------------------------------------------------------------
   PROCEDURE set_context (p_name IN VARCHAR2, p_value IN VARCHAR2)
   IS
   BEGIN
      DBMS_SESSION.set_context (ctx_name, SUBSTR (p_name, 1, 26), SUBSTR (p_value, 1, 26));
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END set_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE set_debug (
      p_output               IN   VARCHAR2,
      p_procedure_name       IN   VARCHAR2 DEFAULT NULL,
      p_pipe_channel         IN   VARCHAR2 DEFAULT NULL,
      p_debug_all_sessions   IN   BOOLEAN DEFAULT FALSE
   )
   AS
   BEGIN
      IF UPPER (TRIM (p_output)) NOT IN
                       (c_output_to_buffer, c_output_to_file, c_output_to_table, c_output_to_pipe)
      THEN
         raise_application_error (c_ora_invalid_output, 'c_ora_invalid_output');
      ELSE
         IF p_debug_all_sessions
         THEN
            set_global_context ('g_debug_all_sessions', c_text_true);
         ELSE
            NULL;
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END set_debug;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Задает значение контексту
--------------------------------------------------------------------------------
   PROCEDURE set_global_context (p_name IN VARCHAR2, p_value IN VARCHAR2)
   IS
   BEGIN
      DBMS_SESSION.set_context (ctx_name_global, p_name, p_value);
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END set_global_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 24.10.2006 16:23
-- Editor  :
-- Changed :
-- Purpose : Устанавливает значение глобальной переменной для всех сессий (таблица GLOBAL_VALUE)
--------------------------------------------------------------------------------
   PROCEDURE set_global_val (
      p_name      IN   VARCHAR2,
      p_value     IN   VARCHAR2,
      p_comment   IN   VARCHAR2 DEFAULT NULL
   )
   AS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      MERGE INTO global_value t
         USING (SELECT SUBSTR (UPPER (p_name), 1, 50) AS NAME,
                       SUBSTR (UPPER (p_value), 1, 50) AS VALUE,
                       SUBSTR (p_comment, 1, 100) AS comments
                  FROM DUAL) sq
         ON (t.NAME = sq.NAME)
         WHEN MATCHED THEN
            UPDATE
               SET t.VALUE = UPPER (sq.VALUE)
         WHEN NOT MATCHED THEN
            INSERT (t.NAME, t.VALUE, t.comments)
            VALUES (sq.NAME, sq.VALUE, sq.comments);
      COMMIT;
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.put_line (SUBSTR ('Ошибка в core.set_global_val :' || SQLERRM, 1, 250)
                               || '...');
         RAISE;
   END set_global_val;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Version :
-- Modification :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE set_level (p_level IN VARCHAR2)
   IS
   BEGIN
      g_debug_level := p_level;
   END set_level;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Version :
-- Modification :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE set_output (p_output IN VARCHAR2)
   IS
   BEGIN
      g_log_output := p_output;
   END set_output;

-------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Установка таймера
--------------------------------------------------------------------------------
   PROCEDURE SET_TIMER (p_event_name IN VARCHAR2 DEFAULT NULL)
   AS
   BEGIN
      IF p_event_name IS NULL   --Если событие не заданно...
      THEN
         IF NOT g_timer
         THEN
            --Установим контекст с начальной точкой отсчета
            set_context ('timer' || c_text_start, DBMS_UTILITY.get_time);
            g_timer := TRUE;
         ELSE
            --Установим контекст с конечной точкой отсчета
            set_context ('timer' || c_text_end, DBMS_UTILITY.get_time);
            g_timer := FALSE;
         END IF;
      ELSE   --Если событие заданно...
         --Установим контекст с точкой отсчета для события
         set_context ('timer' || p_event_name, DBMS_UTILITY.get_time);
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE;
   END SET_TIMER;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 04.09.2008
-- Editor  :
-- Changed :
-- Purpose : Функция преобразовывает результат запроса к колонке таблицы в список с разделителями(запятыми)
--------------------------------------------------------------------------------
   FUNCTION table_column_to_list (p_query IN LONG, p_delimiter IN VARCHAR2 DEFAULT ',')
      RETURN LONG
   IS
      prc_name   CONSTANT NVARCHAR2 (100)   := 'table_column_to_list';
      v_list              LONG;   --строка с разделителями
      v_line              LONG;   --строка результата запроса подготовденная как XML
      v_col_i             PLS_INTEGER       DEFAULT 0;   --счетчик
      v_desctbl           DBMS_SQL.desc_tab;   --описательная таблица для полей
      v_col_val           VARCHAR2 (4000);   --значение столБца
      v_status            INTEGER;   --статус выполнения динамического запроса
      v_col_cnt           NUMBER            DEFAULT 0;   --кол-во столбцов
      v_str_cnt           NUMBER            DEFAULT 0;   --кол-во строк
      v_thecursor         BINARY_INTEGER    DEFAULT DBMS_SQL.open_cursor;
   BEGIN
      --Очистим возвращаемый список
      v_list := '';

      IF p_delimiter IS NULL
      THEN
         raise_application_error (c_ora_invalid_delimiter, 'Invalid Delimiter');
      END IF;

      --Разберем запрос
      DBMS_SQL.parse (v_thecursor, p_query, DBMS_SQL.native);
      --Опишем столбцы
      DBMS_SQL.describe_columns (v_thecursor, v_col_cnt, v_desctbl);

      --Определяем столбцы
      FOR i IN 1 .. v_col_cnt
      LOOP
         DBMS_SQL.define_column (v_thecursor, i, v_col_val, 4000);
      END LOOP;

      --Выполняем оператор.
      v_status := DBMS_SQL.EXECUTE (v_thecursor);

      --Выбраем все строки.
      WHILE (DBMS_SQL.fetch_rows (v_thecursor) > 0)
      LOOP
         --Номер строки
         v_str_cnt := v_str_cnt + 1;
         v_line := '';

         --Получаем и обрабатываем данные столбцов.
         FOR i IN 1 .. v_col_cnt
         LOOP
            DBMS_SQL.COLUMN_VALUE (v_thecursor, i, v_col_val);

            IF (v_desctbl (i).col_type = 12)   -- Тип данных DATE
            THEN
               v_col_val := REPLACE (v_col_val, '/', '.');   --т.к. "/" управляющий в XML
            END IF;

            --Значение первого столбца выведем в строку с разделителем
            IF i = 1
            THEN
               v_list := v_list || v_col_val || p_delimiter;
            END IF;

            --Все столбцы как строка
            v_line := v_line || v_col_val || '*';
         END LOOP;
      END LOOP;

      --Закроем курсор
      DBMS_SQL.close_cursor (v_thecursor);
      --Вернем результат
      RETURN v_list;
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_SQL.close_cursor (v_thecursor);
   END table_column_to_list;
--Начальные установки
BEGIN
   g_log_output := get_global_val (c_global_value_output);
   g_pipe_channel := get_global_val (c_global_value_channel);
END core;
/
