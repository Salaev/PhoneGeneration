CREATE package locker_pkg is

----------------------------------!---------------------------------------------
  type t_locker_data is table of TT_LOCKER_DATA_RANGE%rowtype;
  type t_locker_data_eq is table of TT_LOCKER_DATA_EQ%rowtype;

  type t_locker is record
  (
    locker_group_id             number,
    locker_id                   number
  );

  type t_locker_parameters is record
  (
    locker                      t_locker,
    ignore_type                 number,
    split_batch_count_limit     number,
    count_of_single             number,
    count_of_short_range        number,
    count_of_big_range          number
  );

----------------------------------!---------------------------------------------
  c_mutex_locker_data_lr         constant number := 1; --Mutex for LOCKER_DATA_LR

  c_def_data_type                constant number := 0;

----------------------------------!---------------------------------------------
  c_opt_mutex_timeout_sec        constant nvarchar2(50) := 'MUTEX_TIMEOUT';
  c_opt_max_size_split_range     constant nvarchar2(50) := 'MAX_SIZE_SPLITTABLE_RANGE';
  c_opt_locker_expire_period_sec constant nvarchar2(50) := 'LOCKER_EXPIRE_PERIOD';

----------------------------------!---------------------------------------------
  c_def_mutex_timeout_sec        constant number := 60;
  c_def_max_size_split_range     constant number := 10000;
  c_def_locker_expire_period_sec constant number := 36000;

----------------------------------!---------------------------------------------
  function get_count_t_locker_data(p_coll t_locker_data) return number;
  function get_count_t_locker_data_eq(p_coll t_locker_data_eq) return number;

----------------------------------!---------------------------------------------
  function GS_locker_expire_period_sec return number;
  function GS_mutex_timeout_sec return number;
  function GS_ignore_model_type return boolean;
  function GS_max_size_split_range return number;

----------------------------------!---------------------------------------------
  function get_long_range_data return ct_range;
  procedure set_long_range_data(p_range ct_range);

----------------------------------!---------------------------------------------
  function Get_Locker(p_locker_id number) return locker%rowtype;
  function Create_Locker(p_locker_group_id number := null) return t_locker;
  procedure Set_Locker_Finished(p_locker_param t_locker_parameters);
  procedure Add_Mutex(p_mutex_id number);
  procedure Switch_On_Mutex(p_mutex_id number);

----------------------------------!---------------------------------------------
  procedure Handle_Wrong_Equipment(p_locker_error t_locker_data, p_error_code number, p_error_message varchar2, p_label varchar2 := '');

----------------------------------!---------------------------------------------
--!_!Lock_Data
  procedure Insert_Locker_Data(p_locker_data t_locker_data);
  procedure Check_Locker_Data(p_allow_non_digit_sn boolean := false);
  procedure Clear_Temporary_Tables;
  procedure Fill_Temporary_Tables(p_locker_param t_locker_parameters, p_allow_input_overlap boolean);
  procedure Make_Uniq_TT_LONG_RANGE_DATA;
  procedure Check_TT_LONG_RANGE_DATA;
  procedure Lock_Single_Short_Rg_Data(p_locker_param t_locker_parameters, p_allow_input_overlap boolean);
  procedure Lock_Big_Range_Data(p_locker_param t_locker_parameters);
  procedure Check_Locker_Data_SR;
  procedure Check_Locker_Data_LR(p_locker_param t_locker_parameters);

----------------------------------!---------------------------------------------
--!_!Lock_Equipment_On_Stock
  procedure Insert_Locker_Data_Eq(p_locker_data_eq t_locker_data_eq);
  procedure Check_Locker_Eq_Data;
  procedure Lock_Equipment_Data(p_locker_param t_locker_parameters);

----------------------------------!---------------------------------------------
--!_!interface
  procedure Release_Locker_Group(p_locker_group_id number);
  procedure Release_Locker(p_locker_id number);
  procedure Release_Expired_Lockers;

----------------------------------!---------------------------------------------
  function Check_Locker(p_locker_id number) return number;
  function Check_Locker_Group(p_locker_group_id number) return number;

----------------------------------!---------------------------------------------
  function Lock_Data
  (
    p_locker_data t_locker_data,
    p_locker_group_id number,
    p_allow_non_digit_sn boolean,
    p_allow_input_overlap boolean
  ) return t_locker;

  function Lock_Equipment_On_Stock(p_locker_data_eq t_locker_data_eq, p_locker_group_id number := null) return t_locker;
  function Lock_Single_Equipment_On_Stock(p_type_id number, p_stock_id number, p_locker_group_id number := null) return t_locker;

----------------------------------!---------------------------------------------
  function get_locker_by_stock_and_type(p_rec tt_locker_data_eq%rowtype) return t_locker;
  function Get_Lockers_Eq_Contents(p_locker t_locker) return t_locker_data_eq;
  function Get_Lockers_Sr_Contents(p_locker t_locker) return t_locker_data;
  function Get_Lockers_Lr_Contents(p_locker t_locker) return t_locker_data;

--!_!interface
----------------------------------!---------------------------------------------

end;
/
