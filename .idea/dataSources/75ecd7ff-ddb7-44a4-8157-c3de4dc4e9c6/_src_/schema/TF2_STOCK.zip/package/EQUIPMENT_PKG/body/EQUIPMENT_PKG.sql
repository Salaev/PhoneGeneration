CREATE package body equipment_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XRestrict_Not_Implemented(p_label varchar2)
is
begin
  ------------------------------
  util_pkg.Raise_exception(util_loc_pkg.c_ora_not_implemented_code, util_loc_pkg.c_msg_not_implemented_code || util_pkg.c_msg_delim01 || p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XRestrict_Wrong_Doc_State(p_id number)
is
begin
  ------------------------------
  util_pkg.Raise_exception(util_loc_pkg.c_ora_wrong_doc_state, util_loc_pkg.c_msg_wrong_doc_state || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_id));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XRestrict_Mandat_Value(p_label varchar2)
is
begin
  ------------------------------
  util_pkg.Raise_exception(util_loc_pkg.c_ora_mandatory_value_nspec, util_loc_pkg.c_msg_mandatory_value_nspec || util_pkg.c_msg_delim01 || p_label);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_Eq_Status(p_eq_status number, p_label varchar2 := null)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_eq_status is null, util_pkg.smart_label1(p_label, 'p_eq_status'));
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_eq_status not in (c_eq_status_not_spec, c_eq_status_not_active, c_eq_status_active), util_pkg.smart_label2(p_label, 'p_eq_status', ' not in (c_eq_status_not_spec, c_eq_status_not_active, c_eq_status_active)'));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_Doc_Op_Type(p_document_operation_type number, p_label varchar2 := null)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_document_operation_type is null, util_pkg.smart_label1(p_label, 'p_document_operation_type'));
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_document_operation_type not in (c_dot_create, c_dot_update, c_dot_finalize), util_pkg.smart_label2(p_label, 'p_document_operation_type', ' not in (c_dot_create, c_dot_update, c_dot_finalize)'));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_Doc_Op_Subtype(p_document_operation_subtype number, p_label varchar2 := null)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_document_operation_subtype is null, util_pkg.smart_label1(p_label, 'p_document_operation_subtype'));
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_document_operation_subtype not in (c_dost_create, c_dost_update_add, c_dost_update_remove, c_dost_finalize), util_pkg.smart_label2(p_label, 'p_document_operation_subtype', ' not in (c_dost_create, c_dost_update_add, c_dost_update_remove, c_dost_finalize)'));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_Doc_Style(p_document_style number, p_label varchar2 := null)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_document_style is null, util_pkg.smart_label1(p_label, 'p_document_style'));
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_document_style not in (c_doc_style_default, c_doc_style_crm, c_doc_style_gui), util_pkg.smart_label2(p_label, 'p_document_style', ' not in (c_doc_stype_default, c_doc_style_crm, c_doc_style_gui)'));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function GP_doc_header(p_params t_ss_parameters) return doc_header%rowtype
is
begin
  ------------------------------
  return p_params.m_doc_header;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_doc_header_orig(p_params t_ss_parameters) return doc_header%rowtype
is
begin
  ------------------------------
  return p_params.m_doc_header_orig;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_exists_document_orig(p_params t_ss_parameters) return boolean
is
begin
  ------------------------------
  return (p_params.m_doc_header_orig.id is NOT null);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_doc_header_id(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_doc_header.id is null, 'p_params.m_doc_header.id is null');
  ------------------------------
  return p_params.m_doc_header.id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function XGP_last_user_id(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_doc_header.last_user_id2 is null, 'p_params.m_doc_header.last_user_id2 is null');
  ------------------------------
  return p_params.m_doc_header.last_user_id2;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_document_date(p_params t_ss_parameters) return date
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_doc_header.doc_date is null, 'p_params.m_doc_header.doc_date is null');
  ------------------------------
  return p_params.m_doc_header.doc_date;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_document_type(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_doc_header.doc_type_id is null, 'm_doc_header.doc_type_id is null');
  ------------------------------
  util_stock.XCheck_doc_type(p_params.m_doc_header.doc_type_id);
  ------------------------------
  return p_params.m_doc_header.doc_type_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_doc_dir_type(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  return util_stock.xget_doc_dir_type(XGP_document_type(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_document_number(p_params t_ss_parameters) return nvarchar2
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_doc_header.doc_no is null, 'm_doc_header.doc_no is null');
  ------------------------------
  return p_params.m_doc_header.doc_no;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_document_status(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_doc_header.status_id is null, 'm_doc_header.status_id is null');
  ------------------------------
  return p_params.m_doc_header.status_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function NLGP_document_status_orig(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  if NOT is_exists_document_orig(p_params)
  then
    ------------------------------
    return NULL;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_doc_header_orig.status_id is null, 'm_doc_header_orig.status_id is null');
  ------------------------------
  return p_params.m_doc_header_orig.status_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_stock_id_out(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_doc_header.stock_out_id is null, 'p_params.m_doc_header.stock_out_id is null');
  ------------------------------
  return p_params.m_doc_header.stock_out_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_stock_id_in(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_doc_header.stock_in_id is null, 'p_params.m_doc_header.stock_in_id is null');
  ------------------------------
  return p_params.m_doc_header.stock_in_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_valid_until_common_nullable(p_params t_ss_parameters) return date
is
begin
  ------------------------------
  return p_params.m_valid_until_common_nullable;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_eq_status_initial(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  return xget_eq_status_initial(XGP_document_type(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_eq_status_final_NEUTRAL(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_eq_status_final is null, 'p_params.m_eq_status_final is null');
  ------------------------------
  return p_params.m_eq_status_final;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_eq_status_final_REAL(p_params t_ss_parameters) return number
is
  v_eq_status_final number;
begin
  ------------------------------
  v_eq_status_final := XGP_eq_status_final_NEUTRAL(p_params);
  ------------------------------
  if v_eq_status_final = c_eq_status_not_spec
  then
    ------------------------------
    return c_eq_status_active;
    ------------------------------
  end if;
  ------------------------------
  return v_eq_status_final;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function XGP_do_break_on_error(p_params t_ss_parameters) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_do_break_on_error is null, 'p_params.m_do_break_on_error is null');
  ------------------------------
  return p_params.m_do_break_on_error;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_do_lock_document(p_params t_ss_parameters) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_do_lock_document is null, 'p_params.m_do_lock_document is null');
  ------------------------------
  return p_params.m_do_lock_document;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_do_lock_equipment(p_params t_ss_parameters) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_do_lock_equipment is null, 'p_params.m_do_lock_equipment is null');
  ------------------------------
  return p_params.m_do_lock_equipment;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_do_check_locking_document(p_params t_ss_parameters) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_do_check_locking_document is null, 'p_params.m_do_check_locking_document is null');
  ------------------------------
  return p_params.m_do_check_locking_document;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_do_check_locking_equipment(p_params t_ss_parameters) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_do_check_locking_equipment is null, 'p_params.m_do_check_locking_equipment is null');
  ------------------------------
  return p_params.m_do_check_locking_equipment;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_do_release_doc_locker(p_params t_ss_parameters) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_do_release_doc_locker is null, 'p_params.m_do_release_doc_locker is null');
  ------------------------------
  return p_params.m_do_release_doc_locker;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_do_release_locker(p_params t_ss_parameters) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_do_release_locker is null, 'p_params.m_do_release_locker is null');
  ------------------------------
  return p_params.m_do_release_locker;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function XGP_do_populate_sims(p_params t_ss_parameters) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_do_populate_sims is null, 'p_params.m_do_populate_sims is null');
  ------------------------------
  return p_params.m_do_populate_sims;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_do_populate_sims_range(p_params t_ss_parameters) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_do_populate_sims_range is null, 'p_params.m_do_populate_sims_range is null');
  ------------------------------
  return p_params.m_do_populate_sims_range;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function NLGP_eq_types4populate_sims(p_params t_ss_parameters) return ct_number
is
begin
  ------------------------------
  return p_params.m_eq_types4populate_sims;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function XGP_do_prematurely_populate(p_params t_ss_parameters) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_do_prematurely_populate is null, 'p_params.m_do_prematurely_populate is null');
  ------------------------------
  return p_params.m_do_prematurely_populate;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function GP_locker_group(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  return p_params.m_locker_group;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure SP_locker_group(p_params in out nocopy t_ss_parameters, p_value number)
is
begin
  ------------------------------
  p_params.m_locker_group := p_value;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_doc_locker_group(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  return p_params.m_doc_locker_group;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure SP_doc_locker_group(p_params in out nocopy t_ss_parameters, p_value number)
is
begin
  ------------------------------
  p_params.m_doc_locker_group := p_value;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function NLGP_prev_doc_header_id(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  return p_params.m_prev_doc_header_id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function XGP_is_input_set(p_params t_ss_parameters) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_params.m_is_input_set is null, 'p_params.m_is_input_set is null');
  ------------------------------
  return p_params.m_is_input_set;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function GP_in_data_main_SRC(p_params t_ss_parameters) return rt_in_data
is
  v_res rt_in_data;
begin
  ------------------------------
  add_rt_in_data(v_res, p_params.m_in_data_src);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_main_DST(p_params t_ss_parameters) return rt_in_data
is
  v_res rt_in_data;
begin
  ------------------------------
  add_rt_in_data(v_res, p_params.m_in_data_dst);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_main_ALL(p_params t_ss_parameters) return rt_in_data
is
  v_res rt_in_data;
begin
  ------------------------------
  add_rt_in_data(v_res, GP_in_data_main_SRC(p_params));
  add_rt_in_data(v_res, GP_in_data_main_DST(p_params));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_main_SER_SRC(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_SER(GP_in_data_main_SRC(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_main_SER_DST(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_SER(GP_in_data_main_DST(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_main_SER_ALL(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_SER(GP_in_data_main_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_main_NSER_SRC(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_NSER(GP_in_data_main_SRC(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_main_NSER_DST(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_NSER(GP_in_data_main_DST(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_main_NSER_ALL(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_NSER(GP_in_data_main_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_main_count_SER_ALL(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  return get_count_rt_in_data(GP_in_data_main_SER_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_main_count_NSER_ALL(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  return get_count_rt_in_data(GP_in_data_main_NSER_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_err_id_only_main_ALL(p_params t_ss_parameters) return ct_number
is
begin
  ------------------------------
  return iget_id_orig_erroneous_only(GP_in_data_main_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_ext_SRC(p_params t_ss_parameters) return rt_in_data
is
  v_res rt_in_data;
begin
  ------------------------------
  add_rt_in_data(v_res, p_params.m_in_data_ext_src);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_ext_DST(p_params t_ss_parameters) return rt_in_data
is
  v_res rt_in_data;
begin
  ------------------------------
  add_rt_in_data(v_res, p_params.m_in_data_ext_dst);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_ext_ALL(p_params t_ss_parameters) return rt_in_data
is
  v_res rt_in_data;
begin
  ------------------------------
  add_rt_in_data(v_res, GP_in_data_ext_SRC(p_params));
  add_rt_in_data(v_res, GP_in_data_ext_DST(p_params));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_ext_SER_SRC(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_SER(GP_in_data_ext_SRC(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_ext_SER_DST(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_SER(GP_in_data_ext_DST(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_ext_SER_ALL(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_SER(GP_in_data_ext_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_ext_NSER_SRC(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_NSER(GP_in_data_ext_SRC(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_ext_NSER_DST(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_NSER(GP_in_data_ext_DST(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_ext_NSER_ALL(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_NSER(GP_in_data_ext_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_ext_count_SER_ALL(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  return get_count_rt_in_data(GP_in_data_ext_SER_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_ext_count_NSER_ALL(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  return get_count_rt_in_data(GP_in_data_ext_NSER_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_ext_count_ALL(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  return get_count_rt_in_data(GP_in_data_ext_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_in_data_for_remove(p_params t_ss_parameters) return boolean
is
begin
  ------------------------------
  return (GP_in_data_ext_count_ALL(p_params) > 0);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_err_id_only_ext_ALL(p_params t_ss_parameters) return ct_number
is
begin
  ------------------------------
  return iget_id_orig_erroneous_only(GP_in_data_ext_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_mainext_SRC(p_params t_ss_parameters) return rt_in_data
is
  v_res rt_in_data;
begin
  ------------------------------
  add_rt_in_data(v_res, GP_in_data_main_SRC(p_params));
  add_rt_in_data(v_res, GP_in_data_ext_SRC(p_params));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_mainext_DST(p_params t_ss_parameters) return rt_in_data
is
  v_res rt_in_data;
begin
  ------------------------------
  add_rt_in_data(v_res, GP_in_data_main_DST(p_params));
  add_rt_in_data(v_res, GP_in_data_ext_DST(p_params));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_mainext_ALL(p_params t_ss_parameters) return rt_in_data
is
  v_res rt_in_data;
begin
  ------------------------------
  add_rt_in_data(v_res, GP_in_data_main_ALL(p_params));
  add_rt_in_data(v_res, GP_in_data_ext_ALL(p_params));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_mainext_SER_ALL(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_SER(GP_in_data_mainext_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_mainext_NSER_SRC(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_NSER(GP_in_data_mainext_SRC(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data_mainext_NSER_DST(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_NSER(GP_in_data_mainext_DST(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function GP_in_data4Latch_SER(p_params t_ss_parameters) return locker_pkg.t_locker_data
is
  v_res locker_pkg.t_locker_data;
  v_range ct_range;
  v_main_count number;
begin
  ------------------------------
  v_range := make_range_with_length(GP_in_data_mainext_SER_ALL(p_params));
  ------------------------------
  v_main_count := util_stock.get_count_ct_range(v_range);
  ------------------------------
  if v_main_count < 1
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := locker_pkg.t_locker_data();
  ------------------------------
  v_res.extend(v_main_count);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    v_res(v_i).type_id := v_range(v_i).num1; --!_!
    v_res(v_i).sn_from := v_range(v_i).val1;
    v_res(v_i).sn_to := v_range(v_i).val2;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_in_data4Latch_NSER(p_params t_ss_parameters) return locker_pkg.t_locker_data_eq
is
  v_res locker_pkg.t_locker_data_eq;
  v_stock_id_src number;
  v_stock_id_dst number;
  v_in_data_src rt_in_data;
  v_in_data_dst rt_in_data;
  v_model_id_src ct_number;
  v_model_id_dst ct_number;
  v_main_count number;
  v_main_count_src number;
  v_main_count_dst number;
begin
  ------------------------------
  v_stock_id_src := XGP_stock_id_out(p_params);
  v_stock_id_dst := XGP_stock_id_in(p_params);
  ------------------------------
  v_in_data_src := GP_in_data_mainext_NSER_SRC(p_params);
  v_in_data_dst := GP_in_data_mainext_NSER_DST(p_params);
  ------------------------------
  v_model_id_src := util_stock.get_ct_model_ids(v_in_data_src.m_model);
  v_model_id_dst := util_stock.get_ct_model_ids(v_in_data_dst.m_model);
  ------------------------------
  v_model_id_src := util_pkg.unique_ct_number(v_model_id_src, TRUE, TRUE);
  v_model_id_dst := util_pkg.unique_ct_number(v_model_id_dst, TRUE, TRUE);
  ------------------------------
  v_main_count_src := util_pkg.get_count_ct_number(v_model_id_src);
  v_main_count_dst := util_pkg.get_count_ct_number(v_model_id_dst);
  v_main_count := v_main_count_src + v_main_count_dst;
  ------------------------------
  if v_main_count < 1
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := locker_pkg.t_locker_data_eq();
  ------------------------------
  v_res.extend(v_main_count);
  ------------------------------
  for v_i in 1..v_main_count_src
  loop
    ------------------------------
    v_res(v_i).type_id := v_model_id_src(v_i);
    v_res(v_i).stock_id := v_stock_id_src;
    ------------------------------
  end loop;
  ------------------------------
  for v_i in 1..v_main_count_dst
  loop
    ------------------------------
    v_res(v_main_count_src + v_i).type_id := v_model_id_dst(v_i);
    v_res(v_main_count_src + v_i).stock_id := v_stock_id_dst;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function EGP_in_data(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  if get_count_rt_in_data(p_params.m_in_data_src) > 0
  then
    ------------------------------
    return p_params.m_in_data_src;
    ------------------------------
  end if;
  ------------------------------
  return p_params.m_in_data_dst;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function EGP_in_data_ext(p_params t_ss_parameters) return rt_in_data
is
begin
  ------------------------------
  if get_count_rt_in_data(p_params.m_in_data_ext_src) > 0
  then
    ------------------------------
    return p_params.m_in_data_ext_src;
    ------------------------------
  end if;
  ------------------------------
  return p_params.m_in_data_ext_dst;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function EGP_in_data_ALL(p_params t_ss_parameters) return rt_in_data
is
  v_res rt_in_data;
begin
  ------------------------------
  add_rt_in_data(v_res, EGP_in_data(p_params));
  add_rt_in_data(v_res, EGP_in_data_ext(p_params));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function EGP_error_count(p_params t_ss_parameters) return number
is
begin
  ------------------------------
  return util_pkg.get_count_cit_number(EGP_in_data_ALL(p_params).m_error_code);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function EGP_series_start(p_params t_ss_parameters) return ct_nvarchar_s
is
begin
  ------------------------------
  return EGP_in_data_ALL(p_params).m_range_start;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function EGP_series_end(p_params t_ss_parameters) return ct_nvarchar_s
is
begin
  ------------------------------
  return EGP_in_data_ALL(p_params).m_range_end;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function EGP_models(p_params t_ss_parameters) return ct_model
is
begin
  ------------------------------
  return EGP_in_data_ALL(p_params).m_model;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function EGP_is_addition(p_params t_ss_parameters) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  v_res := util_pkg.make_ct_number(get_count_rt_in_data(EGP_in_data(p_params)), util_pkg.c_true);
  ------------------------------
  util_pkg.add_ct_number(v_res, util_pkg.make_ct_number(get_count_rt_in_data(EGP_in_data_ext(p_params)), util_pkg.c_false));
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function EGP_ids(p_params t_ss_parameters) return ct_number
is
begin
  ------------------------------
  return EGP_ids_original(p_params);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! WRONG behaviour for setup_input_src_dst: INDEPENDENT id_original is placed in m_in_data_src and m_in_data_dst
----------------------------------!---------------------------------------------
function EGP_ids_original(p_params t_ss_parameters) return ct_number
is
begin
  ------------------------------
  return EGP_in_data_ALL(p_params).m_id_original;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function iget_id_orig_erroneous_only(p_in_data rt_in_data) return ct_number
is
begin
  ------------------------------
  return util_loc_pkg.keys2simple(p_in_data.m_error_code);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function iget_error_code_only(p_in_data rt_in_data) return ct_number
is
begin
  ------------------------------
  return util_pkg.cast_cit2ct_number(p_in_data.m_error_code, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function iget_error_message_only(p_in_data rt_in_data) return ct_varchar
is
begin
  ------------------------------
  return util_pkg.cast_cit2ct_varchar(p_in_data.m_error_message, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function EGP_ids_erroneous_only(p_params t_ss_parameters) return ct_number
is
begin
  ------------------------------
  return iget_id_orig_erroneous_only(EGP_in_data_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function EGP_error_codes_only(p_params t_ss_parameters) return ct_number
is
begin
  ------------------------------
  return iget_error_code_only(EGP_in_data_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function EGP_error_messages_only(p_params t_ss_parameters) return ct_varchar
is
begin
  ------------------------------
  return iget_error_message_only(EGP_in_data_ALL(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_ids_erroneous_full_size(p_ids_pivot ct_number, p_ids_erroneous_only ct_number) return ct_number
is
begin
  ------------------------------
  return util_pkg.join2pivot_ct_number(p_ids_erroneous_only, p_ids_pivot, p_ids_erroneous_only);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ids_erroneous_full_size2(p_in_data rt_in_data) return ct_number
is
  v_id_erroneous_only ct_number;
begin
  ------------------------------
  v_id_erroneous_only := iget_id_orig_erroneous_only(p_in_data);
  ------------------------------
  return get_ids_erroneous_full_size(p_in_data.m_id_original, v_id_erroneous_only);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GP_ids_erroneous_full_size(p_params t_ss_parameters) return ct_number
is
begin
  ------------------------------
  return get_ids_erroneous_full_size(EGP_ids(p_params), EGP_ids_erroneous_only(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function Eget_ids_erroneous_full_size(p_ids_pivot ct_number, p_ids_erroneous_only ct_number) return ct_number
is
begin
  ------------------------------
  return get_ids_erroneous_full_size(p_ids_pivot, p_ids_erroneous_only);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_error_code_full_size(p_error_codes_only ct_number, p_ids_pivot ct_number, p_ids_erroneous_only ct_number) return ct_number
is
begin
  ------------------------------
  return util_pkg.join2pivot_ct_number(p_error_codes_only, p_ids_pivot, p_ids_erroneous_only);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_error_code_full_size2(p_in_data rt_in_data) return ct_number
is
  v_res ct_number;
  v_id_erroneous_only ct_number;
begin
  ------------------------------
  v_id_erroneous_only := iget_id_orig_erroneous_only(p_in_data);
  ------------------------------
  v_res := iget_error_code_only(p_in_data);
  ------------------------------
  v_res := get_error_code_full_size(v_res, p_in_data.m_id_original, v_id_erroneous_only);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function EGP_error_codes_full_size(p_params t_ss_parameters) return ct_number
is
begin
  ------------------------------
  return get_error_code_full_size(EGP_error_codes_only(p_params), EGP_ids(p_params), EGP_ids_erroneous_only(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function Eget_error_codes_full_size(p_error_codes_only ct_number, p_ids_pivot ct_number, p_ids_erroneous_only ct_number) return ct_number
is
begin
  ------------------------------
  return get_error_code_full_size(p_error_codes_only, p_ids_pivot, p_ids_erroneous_only);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_error_message_full_size(p_error_messages_only ct_varchar, p_ids_pivot ct_number, p_ids_erroneous_only ct_number) return ct_varchar
is
begin
  ------------------------------
  return util_pkg.join2pivot_ct_varchar(p_error_messages_only, p_ids_pivot, p_ids_erroneous_only);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_error_message_full_size2(p_in_data rt_in_data) return ct_varchar
is
  v_res ct_varchar;
  v_id_erroneous_only ct_number;
begin
  ------------------------------
  v_id_erroneous_only := iget_id_orig_erroneous_only(p_in_data);
  ------------------------------
  v_res := iget_error_message_only(p_in_data);
  ------------------------------
  v_res := get_error_message_full_size(v_res, p_in_data.m_id_original, v_id_erroneous_only);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function EGP_error_messages_full_size(p_params t_ss_parameters) return ct_varchar
is
begin
  ------------------------------
  return get_error_message_full_size(EGP_error_messages_only(p_params), EGP_ids(p_params), EGP_ids_erroneous_only(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function Eget_error_messages_full_size(p_error_messages_only ct_varchar, p_ids_pivot ct_number, p_ids_erroneous_only ct_number) return ct_varchar
is
begin
  ------------------------------
  return get_error_message_full_size(p_error_messages_only, p_ids_pivot, p_ids_erroneous_only);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function GS_max_serial_range_count return number
is
begin
  ------------------------------
  return install_pkg.nnget_option_num(c_opt_max_serial_range_count, c_def_max_serial_range_count);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GS_populate_sims return boolean
is
begin
  ------------------------------
  return install_pkg.nnget_option_bool(c_opt_populate_sims, c_def_populate_sims);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GS_populate_sims_range return boolean
is
begin
  ------------------------------
  return install_pkg.nnget_option_bool(c_opt_populate_sims_range, c_def_populate_sims_range);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GS_populate_sims_eqt return varchar2
is
begin
  ------------------------------
  return install_pkg.nnget_option_str(c_opt_populate_sims_eqt, null, c_def_populate_sims_eqt);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function GS_valid_until_sh_days return number
is
begin
  ------------------------------
  return install_pkg.nnget_option_num(c_opt_valid_until_sh_days, c_def_valid_until_sh_days);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure setup_populate_sims(p_params in out nocopy t_ss_parameters)
is
  v_value_str varchar2(50);
  v_coll ct_varchar;
begin
  ------------------------------
  --sims parameters
  ------------------------------
  p_params.m_do_populate_sims := GS_populate_sims;
  ------------------------------
  p_params.m_do_populate_sims_range := GS_populate_sims_range;
  ------------------------------
  p_params.m_eq_types4populate_sims := null;
  ------------------------------
  v_value_str := GS_populate_sims_eqt;
  ------------------------------
  if v_value_str != c_def_populate_sims_eqt
  then
    ------------------------------
    v_coll := util_pkg.split_string(v_value_str, install_pkg.c_opt_delim01);
    ------------------------------
    if util_pkg.get_count_ct_varchar(v_coll) > 0
    then
      ------------------------------
      p_params.m_eq_types4populate_sims := util_pkg.make_ct_number(util_pkg.get_count_ct_varchar(v_coll), null);
      ------------------------------
      for v_i in v_coll.first..v_coll.last
      loop
        ------------------------------
        p_params.m_eq_types4populate_sims(v_i) := util_pkg.char_to_number(v_coll(v_i));
        ------------------------------
      end loop;
      ------------------------------
    end if;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_!procedure setup_keys_by_ids(p_params in out nocopy t_ss_parameters)
--!_!is
--!_!begin
--!_!  ------------------------------
--!_!  p_params.m_nos := util_loc_pkg.ids2keys(p_params.m_ids);
--!_!  ------------------------------
--!_!end;

----------------------------------!---------------------------------------------
--!_!function get_no_by_id(p_params t_ss_parameters, p_id number) return number
--!_!is
--!_!begin
--!_!  ------------------------------
--!_!  return p_params.m_nos(p_id);
--!_!  ------------------------------
--!_!end;

----------------------------------!---------------------------------------------
--!_!function get_no_by_id_safe(p_params t_ss_parameters, p_id number) return number
--!_!is
--!_!begin
--!_!  ------------------------------
--!_!  return get_no_by_id(p_params, p_id);
--!_!  ------------------------------
--!_!exception
--!_!when others then
--!_!  ------------------------------
--!_!  return null;
--!_!  ------------------------------
--!_!end;

----------------------------------!---------------------------------------------
--!_!function get_id_by_no(p_params t_ss_parameters, p_no number) return number
--!_!is
--!_!begin
--!_!  ------------------------------
--!_!  return p_params.m_ids(p_no);
--!_!  ------------------------------
--!_!end;

----------------------------------!---------------------------------------------
--!_!function get_id_by_no_safe(p_params t_ss_parameters, p_no number) return number
--!_!is
--!_!begin
--!_!  ------------------------------
--!_!  return get_id_by_no(p_params, p_no);
--!_!  ------------------------------
--!_!exception
--!_!when others then
--!_!  ------------------------------
--!_!  return null;
--!_!  ------------------------------
--!_!end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure set_error4id_original_i
(
    p_in_data in out nocopy rt_in_data,
    p_id_original number,
    p_code number,
    p_message varchar2,
    p_force boolean
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_id_original is null, 'p_id_original');
  util_pkg.XCheck_Cond_Missing(p_code is null, 'p_code');
  util_pkg.XCheck_Cond_Missing(p_message is null, 'p_message');
  util_pkg.XCheck_Cond_Missing(p_force is null, 'p_force');
  ------------------------------
  if (1 = 0
    or p_force
    or NOT p_in_data.m_error_code.exists(p_id_original)
  )
  then
    ------------------------------
    p_in_data.m_error_code(p_id_original) := p_code;
    ------------------------------
    p_in_data.m_error_message(p_id_original) := util_pkg.cut_err_msg(p_message);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure set_error4id_original
(
    p_params in out nocopy t_ss_parameters,
    p_id_original number,
    p_code number,
    p_message varchar2,
    p_force boolean
)
is
begin
  ------------------------------
  set_error4id_original_i
  (
    p_in_data => p_params.m_in_data_src,
    p_id_original => p_id_original,
    p_code => p_code,
    p_message => p_message,
    p_force => p_force
  );
  ------------------------------
  set_error4id_original_i
  (
    p_in_data => p_params.m_in_data_dst,
    p_id_original => p_id_original,
    p_code => p_code,
    p_message => p_message,
    p_force => p_force
  );
  ------------------------------
  set_error4id_original_i
  (
    p_in_data => p_params.m_in_data_ext_src,
    p_id_original => p_id_original,
    p_code => p_code,
    p_message => p_message,
    p_force => p_force
  );
  ------------------------------
  set_error4id_original_i
  (
    p_in_data => p_params.m_in_data_ext_dst,
    p_id_original => p_id_original,
    p_code => p_code,
    p_message => p_message,
    p_force => p_force
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!function get_pack_error_code(p_params t_ss_parameters, p_pack_id number) return number
--!_!is
--!_!  v_res number;
--!_!begin
--!_!  ------------------------------
--!_!  util_pkg.XCheck_Cond_Missing(p_pack_id is null, 'p_pack_id');
--!_!  ------------------------------
--!_!  if get_no_by_id_safe(p_params, p_pack_id) is null
--!_!  then
--!_!    return null;
--!_!  end if;
--!_!  ------------------------------
--!_!  if p_params.m_error_codes is not null and p_params.m_error_codes.exists(p_pack_id)
--!_!  then
--!_!    v_res := p_params.m_error_codes(p_pack_id);
--!_!  end if;
--!_!  ------------------------------
--!_!  return nvl(v_res, util_pkg.c_ora_ok);
--!_!  ------------------------------
--!_!end;

----------------------------------!---------------------------------------------
--!_!function get_pack_error_message(p_params t_ss_parameters, p_pack_id number) return varchar2
--!_!is
--!_!  v_res varchar2(4000);
--!_!begin
--!_!  ------------------------------
--!_!  util_pkg.XCheck_Cond_Missing(p_pack_id is null, 'p_pack_id');
--!_!  ------------------------------
--!_!  if get_no_by_id_safe(p_params, p_pack_id) is null
--!_!  then
--!_!    return null;
--!_!  end if;
--!_!  ------------------------------
--!_!  if p_params.m_error_messages is not null and p_params.m_error_messages.exists(p_pack_id)
--!_!  then
--!_!    v_res := p_params.m_error_messages(p_pack_id);
--!_!  end if;
--!_!  ------------------------------
--!_!  return nvl(v_res, util_pkg.c_msg_ok);
--!_!  ------------------------------
--!_!end;

----------------------------------!---------------------------------------------
--!_!procedure get_pack_error(p_params t_ss_parameters, p_pack_id number, p_code out number, p_message out varchar2)
--!_!is
--!_!begin
--!_!  ------------------------------
--!_!  p_code := get_pack_error_code(p_params, p_pack_id);
--!_!  ------------------------------
--!_!  p_message := get_pack_error_message(p_params, p_pack_id);
--!_!  ------------------------------
--!_!end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function map_dot2dost_main(p_document_operation_type number) return number
is
begin
  ------------------------------
  XCheck_Doc_Op_Type(p_document_operation_type, 'p_document_operation_type');
  ------------------------------
  case p_document_operation_type
  when c_dot_create
  then
    ------------------------------
    return c_dost_create;
    ------------------------------
  when c_dot_update
  then
    ------------------------------
    return c_dost_update_add; --!_!not c_dost_update_remove
    ------------------------------
  when c_dot_finalize
  then
    ------------------------------
    return c_dost_finalize;
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_document_operation_type));
    ------------------------------
  end case;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_result_cursor01_common
(
    p_ids ct_number,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_is_addition ct_number,
    p_error_codes ct_number,
    p_error_messages ct_varchar,
    p_subst_ids ct_number,
    p_subst_exclusive boolean,
    p_subst_error_code number := null,
    p_subst_error_message varchar2 := null
) return sys_refcursor
is
  v_res sys_refcursor;
  v_subst_exclusive number := util_pkg.bool_to_int(nvl(p_subst_exclusive, false));
begin
  ------------------------------
  open v_res for
select /*+ ordered use_hash(q0, q00, q1, q2, q3, q4, q5, q6)*/
    q3.equipment_model_code EquipmentCode,
    q1.seria_start StartSeriesNumber,
    q2.seria_end EndSeriesNumber,
    q4.is_addition IsAdd,
    nvl(decode(v_subst_exclusive,
        util_pkg.c_false, decode(q00.pack_id, null, q6.error_message, p_subst_error_message),
        decode(q00.pack_id, null, p_subst_error_message, q6.error_message)
    ), util_pkg.c_msg_ok) error_message,
    nvl(decode(v_subst_exclusive,
        util_pkg.c_false, decode(q00.pack_id, null, q5.error_code, p_subst_error_code),
        decode(q00.pack_id, null, p_subst_error_code, q5.error_code)
    ), util_pkg.c_ora_ok) error_code
    from
        (select column_value pack_id, rownum rn from table(p_ids)) q0,
        (select column_value pack_id, rownum rn from table(p_subst_ids)) q00,
        (select column_value seria_start, rownum rn from table(p_seria_starts)) q1,
        (select column_value seria_end, rownum rn from table(p_seria_ends)) q2,
        (select code equipment_model_code, rownum rn from table(p_models)) q3,
        (select column_value is_addition, rownum rn from table(p_is_addition)) q4,
        (select nvl(column_value, util_pkg.c_ora_ok) error_code, rownum rn from table(p_error_codes)) q5,
        (select nvl(column_value, util_pkg.c_msg_ok) error_message, rownum rn from table(p_error_messages)) q6
    where 1 = 1
    and q00.pack_id(+) = q0.pack_id
    and q1.rn(+) = q0.rn
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    and q4.rn(+) = q1.rn
    and q5.rn(+) = q1.rn
    and q6.rn(+) = q1.rn
    order by q0.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor01
(
    p_params t_ss_parameters,
    p_subst_ids ct_number,
    p_subst_exclusive boolean,
    p_subst_error_code number := null,
    p_subst_error_message varchar2 := null
) return sys_refcursor
is
begin
  ------------------------------
  return get_result_cursor01_common
  (
    p_ids => EGP_ids(p_params),
    p_seria_starts => EGP_series_start(p_params),
    p_seria_ends => EGP_series_end(p_params),
    p_models => EGP_models(p_params),
    p_is_addition => EGP_is_addition(p_params),
    p_error_codes => EGP_error_codes_full_size(p_params),
    p_error_messages => EGP_error_messages_full_size(p_params),
    p_subst_ids => p_subst_ids,
    p_subst_exclusive => p_subst_exclusive,
    p_subst_error_code => p_subst_error_code,
    p_subst_error_message => p_subst_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor01_simple(p_params t_ss_parameters) return sys_refcursor
is
begin
  ------------------------------
  return get_result_cursor01
  (
    p_params => p_params,
    p_subst_ids => null,
    p_subst_exclusive => null,
    p_subst_error_code => null,
    p_subst_error_message => null
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor02_common
(
    p_ids ct_number,
    p_seria_starts ct_nvarchar_s,
    p_seria_ends ct_nvarchar_s,
    p_models ct_model,
    p_is_addition ct_number,
    p_error_codes ct_number,
    p_error_messages ct_varchar,
    p_subst_ids ct_number,
    p_subst_exclusive boolean,
    p_subst_error_code number := null,
    p_subst_error_message varchar2 := null
) return sys_refcursor
is
  v_res sys_refcursor;
  v_subst_exclusive number := util_pkg.bool_to_int(nvl(p_subst_exclusive, false));
begin
  ------------------------------
  open v_res for
select /*+ ordered use_hash(q0, q00, q1, q2, q3, q4, q5, q6) use_nl(s) index(s, AK_SIMS_SN)*/
    q3.equipment_model_code EquipmentCode,
    q1.seria_start StartSeriesNumber,
    q2.seria_end EndSeriesNumber,
    s.full_number iccid,
    nvl(decode(v_subst_exclusive,
        util_pkg.c_false, decode(q00.pack_id, null, q6.error_message, p_subst_error_message),
        decode(q00.pack_id, null, p_subst_error_message, q6.error_message)
    ), util_pkg.c_msg_ok) error_message,
    nvl(decode(v_subst_exclusive,
        util_pkg.c_false, decode(q00.pack_id, null, q5.error_code, p_subst_error_code),
        decode(q00.pack_id, null, p_subst_error_code, q5.error_code)
    ), util_pkg.c_ora_ok) error_code
    from
        (select column_value pack_id, rownum rn from table(p_ids)) q0,
        (select column_value pack_id, rownum rn from table(p_subst_ids)) q00,
        (select column_value seria_start, rownum rn from table(p_seria_starts)) q1,
        (select column_value seria_end, rownum rn from table(p_seria_ends)) q2,
        (select code equipment_model_code, rownum rn from table(p_models)) q3,
        (select column_value is_addition, rownum rn from table(p_is_addition)) q4,
        (select nvl(column_value, util_pkg.c_ora_ok) error_code, rownum rn from table(p_error_codes)) q5,
        (select nvl(column_value, util_pkg.c_msg_ok) error_message, rownum rn from table(p_error_messages)) q6,
        sims s
    where 1 = 1
    and q00.pack_id(+) = q0.pack_id
    and q1.rn(+) = q0.rn
    and q2.rn(+) = q1.rn
    and q3.rn(+) = q1.rn
    and q4.rn(+) = q1.rn
    and q5.rn(+) = q1.rn
    and q6.rn(+) = q1.rn
    and s.serial_number(+) = q1.seria_start
    order by q0.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor02
(
    p_params t_ss_parameters,
    p_subst_ids ct_number,
    p_subst_exclusive boolean,
    p_subst_error_code number := null,
    p_subst_error_message varchar2 := null
) return sys_refcursor
is
begin
  ------------------------------
  return get_result_cursor02_common
  (
    p_ids => EGP_ids(p_params),
    p_seria_starts => EGP_series_start(p_params),
    p_seria_ends => EGP_series_end(p_params),
    p_models => EGP_models(p_params),
    p_is_addition => EGP_is_addition(p_params),
    p_error_codes => EGP_error_codes_full_size(p_params),
    p_error_messages => EGP_error_messages_full_size(p_params),
    p_subst_ids => p_subst_ids,
    p_subst_exclusive => p_subst_exclusive,
    p_subst_error_code => p_subst_error_code,
    p_subst_error_message => p_subst_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_result_cursor02_simple(p_params t_ss_parameters) return sys_refcursor
is
begin
  ------------------------------
  return get_result_cursor02
  (
    p_params => p_params,
    p_subst_ids => null,
    p_subst_exclusive => null,
    p_subst_error_code => null,
    p_subst_error_message => null
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure init_doc_header(p_rec in out nocopy doc_header%rowtype)
is
begin
  ------------------------------
  p_rec := null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure init_rt_in_data(p_rec in out nocopy rt_in_data)
is
begin
  ------------------------------
  p_rec := null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure setup_params_init_i(p_params in out nocopy t_ss_parameters)
is
begin
  ------------------------------
  --document parameters
  ------------------------------
  init_doc_header(p_params.m_doc_header);
  init_doc_header(p_params.m_doc_header_orig);
  ------------------------------
  --incoming data
  ------------------------------
  init_input_i(p_params);
  ------------------------------
  p_params.m_eq_status_final := null;
  ------------------------------
  --system parameters
  ------------------------------
  p_params.m_do_break_on_error := true;
  p_params.m_do_lock_document := true;
  p_params.m_do_lock_equipment := true;
  p_params.m_do_check_locking_document := true;
  p_params.m_do_check_locking_equipment := true;
  p_params.m_do_release_doc_locker := true;
  p_params.m_do_release_locker := true;
  ------------------------------
  --JOINT internal parameters
  ------------------------------
  p_params.m_locker_group := null;
  p_params.m_doc_locker_group := null;
  p_params.m_prev_doc_header_id := null;
  ------------------------------
  --INTERNAL parameters
  ------------------------------
  p_params.m_is_input_set := null;
  ------------------------------
  --sims parameters
  ------------------------------
  setup_populate_sims(p_params);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure init_input_i(p_params in out nocopy t_ss_parameters)
is
begin
  ------------------------------
  init_rt_in_data(p_params.m_in_data_src);
  init_rt_in_data(p_params.m_in_data_dst);
  init_rt_in_data(p_params.m_in_data_ext_src);
  init_rt_in_data(p_params.m_in_data_ext_dst);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_empty_doc_i(p_params in out nocopy t_ss_parameters)
is
begin
  ------------------------------
  init_input_i(p_params);
  ------------------------------
  p_params.m_is_input_set := TRUE;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_for_single_doc(p_params in out nocopy t_ss_parameters)
is
begin
  ------------------------------
  setup_params_init_i(p_params);
  ------------------------------
  --system parameters
  ------------------------------
  p_params.m_do_lock_document := true;
  p_params.m_do_lock_equipment := true;
  p_params.m_do_check_locking_document := true;
  p_params.m_do_check_locking_equipment := true;
  p_params.m_do_release_doc_locker := true;
  p_params.m_do_release_locker := true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure link_params_i(p_params_from t_ss_parameters, p_params_to in out nocopy t_ss_parameters)
is
begin
  ------------------------------
  p_params_to.m_locker_group := p_params_from.m_locker_group;
  p_params_to.m_doc_locker_group := p_params_from.m_doc_locker_group;
  p_params_to.m_prev_doc_header_id := p_params_from.m_doc_header.id;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_for_linked_doc_begin(p_params in out nocopy t_ss_parameters)
is
begin
  ------------------------------
  setup_params_init_i(p_params);
  ------------------------------
  --system parameters
  ------------------------------
  p_params.m_do_lock_document := true;
  p_params.m_do_lock_equipment := true;
  p_params.m_do_check_locking_document := true;
  p_params.m_do_check_locking_equipment := true;
  p_params.m_do_release_doc_locker := false;
  p_params.m_do_release_locker := false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_for_linked_doc_continue(p_params_from t_ss_parameters, p_params_to in out nocopy t_ss_parameters, p_lock_doc_exist boolean, p_lock_eq_exist boolean)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_lock_doc_exist is null, 'p_lock_doc_exist');
  util_pkg.XCheck_Cond_Missing(p_lock_eq_exist is null, 'p_lock_eq_exist');
  ------------------------------
  setup_params_init_i(p_params_to);
  ------------------------------
  --system parameters
  ------------------------------
  if p_lock_doc_exist
  then
    ------------------------------
    p_params_to.m_do_lock_document := false;
    ------------------------------
  else
    ------------------------------
    p_params_to.m_do_lock_document := true;
    ------------------------------
  end if;
  ------------------------------
  if p_lock_eq_exist
  then
    ------------------------------
    p_params_to.m_do_lock_equipment := false;
    ------------------------------
  else
    ------------------------------
    p_params_to.m_do_lock_equipment := true;
    ------------------------------
  end if;
  ------------------------------
  p_params_to.m_do_check_locking_document := true;
  p_params_to.m_do_check_locking_equipment := true;
  p_params_to.m_do_release_doc_locker := false;
  p_params_to.m_do_release_locker := false;
  ------------------------------
  link_params_i(p_params_from, p_params_to);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_for_linked_doc_end(p_params_from t_ss_parameters, p_params_to in out nocopy t_ss_parameters, p_lock_doc_exist boolean, p_lock_eq_exist boolean)
is
begin
  ------------------------------
  setup_for_linked_doc_continue(p_params_from, p_params_to, p_lock_doc_exist, p_lock_eq_exist);
  ------------------------------
  --system parameters
  ------------------------------
  p_params_to.m_do_release_doc_locker := true;
  p_params_to.m_do_release_locker := true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure finalize_chain(p_params in out nocopy t_ss_parameters, p_success boolean)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_success is null, 'p_success');
  ------------------------------
  if p_success
  then
    ------------------------------
    --system parameters
    ------------------------------
    p_params.m_do_release_doc_locker := true;
    p_params.m_do_release_locker := true;
    ------------------------------
    Release_Latch(p_params);
    ------------------------------
  else
    ------------------------------
    Unlatch
    (
      p_params => p_params,
      p_force => TRUE
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xget_eq_status_initial(p_doc_type_id number) return number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  util_stock.XCheck_doc_type(p_doc_type_id);
  ------------------------------
  if p_doc_type_id in
  (
    util_stock.c_Doc_Type_Receipt,
    util_stock.c_Doc_Type_Shippment,
    util_stock.c_Doc_Type_Movement,
    util_stock.c_Doc_Type_Assembling,
    util_stock.c_Doc_Type_Disassembling,
    --!_!util_stock.c_Doc_Type_Credit,
    --!_!util_stock.c_Doc_Type_Debit,
    util_stock.c_Doc_Type_SeriaPartition,
    util_stock.c_Doc_Type_SeriaAssembling,
    --!_!util_stock.c_Doc_Type_OpenSeries,
    util_stock.c_Doc_Type_CloseSeries--!_!,
    --!_!util_stock.c_Doc_Type_Inventory,
    --!_!util_stock.c_Doc_Type_ErrorReport,
    --!_!util_stock.c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    return c_eq_status_active;
    ------------------------------
  elsif p_doc_type_id in
  (
    util_stock.c_Doc_Type_OpenSeries
  )
  then
    ------------------------------
    return c_eq_status_not_active;
    ------------------------------
  else --!_!if p_doc_type_id in
  --!_!(
  --!_!  util_stock.c_Doc_Type_Credit,
  --!_!  util_stock.c_Doc_Type_Debit,
  --!_!  util_stock.c_Doc_Type_Inventory,
  --!_!  util_stock.c_Doc_Type_ErrorReport,
  --!_!  util_stock.c_Doc_Type_EquipmentValidUntil
  --!_!)
  --!_!then
    ------------------------------
    return c_eq_status_not_spec;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_doc_implemented(p_doc_type_id number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  util_stock.XCheck_doc_type(p_doc_type_id);
  ------------------------------
  if p_doc_type_id in
  (
    util_stock.c_Doc_Type_Receipt,
    util_stock.c_Doc_Type_Shippment,
    util_stock.c_Doc_Type_Movement,
    --!_!util_stock.c_Doc_Type_Assembling,
    --!_!util_stock.c_Doc_Type_Disassembling,
    util_stock.c_Doc_Type_Credit,
    util_stock.c_Doc_Type_Debit,
    util_stock.c_Doc_Type_SeriaPartition,
    util_stock.c_Doc_Type_SeriaAssembling,
    util_stock.c_Doc_Type_OpenSeries,
    util_stock.c_Doc_Type_CloseSeries,
    --!_!util_stock.c_Doc_Type_Inventory,
    --!_!util_stock.c_Doc_Type_ErrorReport,
    util_stock.c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_doc_mutating_range(p_doc_type_id number) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  util_stock.XCheck_doc_type(p_doc_type_id);
  ------------------------------
  if p_doc_type_id in
  (
    --!_!util_stock.c_Doc_Type_Receipt,
    --!_!util_stock.c_Doc_Type_Shippment,
    --!_!util_stock.c_Doc_Type_Movement,
    --!_!util_stock.c_Doc_Type_Assembling,
    --!_!util_stock.c_Doc_Type_Disassembling,
    --!_!util_stock.c_Doc_Type_Credit,
    --!_!util_stock.c_Doc_Type_Debit,
    util_stock.c_Doc_Type_SeriaPartition,
    util_stock.c_Doc_Type_SeriaAssembling--!_!,
    --!_!util_stock.c_Doc_Type_OpenSeries,
    --!_!util_stock.c_Doc_Type_CloseSeries,
    --!_!util_stock.c_Doc_Type_Inventory,
    --!_!util_stock.c_Doc_Type_ErrorReport,
    --!_!util_stock.c_Doc_Type_EquipmentValidUntil
  )
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_operation_1_side(p_document_operation_subtype number) return boolean
is
begin
  ------------------------------
  return NOT is_operation_2_side(p_document_operation_subtype);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_operation_2_side(p_document_operation_subtype number) return boolean
is
begin
  ------------------------------
  XCheck_Doc_Op_Subtype(p_document_operation_subtype, 'p_document_operation_subtype');
  ------------------------------
  if p_document_operation_subtype in
  (
    c_dost_update_remove,
    c_dost_finalize
  )
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_operation_4_in_data_ext(p_document_operation_subtype number) return boolean
is
begin
  ------------------------------
  XCheck_Doc_Op_Subtype(p_document_operation_subtype, 'p_document_operation_subtype');
  ------------------------------
  if p_document_operation_subtype in
  (
    c_dost_update_remove
  )
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure setup_eq_status_final_i(p_params in out nocopy t_ss_parameters, p_eq_status_final number)
is
  v_doc_type number;
begin
  ------------------------------
  XCheck_Eq_Status(p_eq_status_final);
  ------------------------------
  v_doc_type := XGP_document_type(p_params);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(v_doc_type = util_stock.c_Doc_Type_OpenSeries and p_eq_status_final != c_eq_status_active, 'v_doc_type = util_stock.c_Doc_Type_OpenSeries and p_eq_status_final != c_eq_status_active');
  util_pkg.XCheck_Cond_Invalid(v_doc_type = util_stock.c_Doc_Type_CloseSeries and p_eq_status_final != c_eq_status_not_active, 'v_doc_type = util_stock.c_Doc_Type_CloseSeries and p_eq_status_final != c_eq_status_not_active');
  ------------------------------
  p_params.m_eq_status_final := p_eq_status_final;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_doc_style(p_doc_style number, p_rec in out nocopy doc_header%rowtype)
is
begin
  ------------------------------
  XCheck_Doc_Style(p_doc_style, 'p_doc_style');
  ------------------------------
  case p_doc_style
  when c_doc_style_default
  then
    ------------------------------
    null;
    ------------------------------
  when c_doc_style_crm
  then
    ------------------------------
    document_pkg.setup_for_crm_doc_header(p_rec);
    ------------------------------
  when c_doc_style_gui
  then
    ------------------------------
    document_pkg.setup_for_gui_doc_header(p_rec);
    ------------------------------
  else
    ------------------------------
    util_pkg.raise_exception(util_pkg.c_ora_object_wrong, util_pkg.c_msg_object_wrong || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_doc_style));
    ------------------------------
  end case;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_for_new_doc
(
    p_params in out nocopy t_ss_parameters,
    p_doc_type_id doc_header.doc_type_id%type,
    p_doc_date doc_header.doc_date%type,
    p_status_id doc_header.status_id%type,
    p_stock_id_out doc_header.stock_out_id%type,
    p_stock_id_in doc_header.stock_in_id%type,
    p_user_id doc_header.user_id2%type,
    p_last_user_id doc_header.last_user_id2%type,
    p_vendor_doc doc_header.vendor_doc%type,
    p_description doc_header.description%type,
    p_user_comment doc_header.user_comment%type,
    p_vendor_id doc_header.vendor_id%type,
    p_doc_style number
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  util_pkg.XCheck_Cond_Missing(p_doc_date is null, 'p_doc_date');
  util_pkg.XCheck_Cond_Missing(p_status_id is null, 'p_status_id');
  util_pkg.XCheck_Cond_Missing(p_stock_id_out is null, 'p_stock_id_out');
  util_pkg.XCheck_Cond_Missing(p_stock_id_in is null, 'p_stock_id_in');
  util_pkg.XCheck_Cond_Missing(p_user_id is null, 'p_user_id');
  util_pkg.XCheck_Cond_Missing(p_last_user_id is null, 'p_last_user_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_vendor_doc is null, 'p_vendor_doc');
  --!_!util_pkg.XCheck_Cond_Missing(p_description is null, 'p_description');
  --!_!util_pkg.XCheck_Cond_Missing(p_user_comment is null, 'p_user_comment');
  --!_!util_pkg.XCheck_Cond_Missing(p_vendor_id is null, 'p_vendor_id');
  XCheck_Doc_Style(p_doc_style, 'p_doc_style');
  ------------------------------
  document_pkg.setup_smart_doc_header
  (
    p_rec => p_params.m_doc_header,
    p_doc_type_id => p_doc_type_id,
    p_doc_date => p_doc_date,
    p_status_id => p_status_id,
    p_stock_out_id => p_stock_id_out,
    p_stock_in_id => p_stock_id_in,
    p_user_id => p_user_id,
    p_last_user_id => p_last_user_id,
    p_vendor_doc => p_vendor_doc,
    p_description => p_description,
    p_user_comment => p_user_comment,
    p_vendor_id => p_vendor_id
  );
  ------------------------------
  setup_doc_style(p_doc_style, p_params.m_doc_header);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_for_old_doc
(
    p_params in out nocopy t_ss_parameters,
    p_doc_header_from doc_header%rowtype,
    p_status_id doc_header.status_id%type,
    p_last_user_id doc_header.last_user_id2%type,
    p_doc_date doc_header.doc_date%type
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header_from.id is null, 'p_doc_header_from.id');
  util_pkg.XCheck_Cond_Missing(p_status_id is null, 'p_status_id');
  util_pkg.XCheck_Cond_Missing(p_last_user_id is null, 'p_last_user_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_doc_date is null, 'p_doc_date');
  ------------------------------
  p_params.m_doc_header_orig := p_doc_header_from;
  p_params.m_doc_header := p_doc_header_from;
  ------------------------------
  p_params.m_doc_header.status_id := p_status_id;
  p_params.m_doc_header.last_user_id2 := p_last_user_id;
  p_params.m_doc_header.last_user := util_stock.make_obsolete_user_name(util_stock.xget_user_name(p_last_user_id));
  ------------------------------
  if p_doc_date is NOT null
  then
    ------------------------------
    p_params.m_doc_header.doc_date := p_doc_date; --!_! it changes p_doc_header_from.doc_date
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure setup_additional_i
(
    p_params in out nocopy t_ss_parameters,
    p_break_on_error boolean,
    p_eq_status_final number,
    p_valid_until_common_nullable date,
    p_prematurely_populate boolean
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_break_on_error is null, 'p_break_on_error');
  util_pkg.XCheck_Cond_Missing(p_eq_status_final is null, 'p_eq_status_final');
  --!_!util_pkg.XCheck_Cond_Missing(p_valid_until_common_nullable is null, 'p_valid_until_common_nullable');
  util_pkg.XCheck_Cond_Missing(p_prematurely_populate is null, 'p_prematurely_populate');
  ------------------------------
  XCheck_Eq_Status(p_eq_status_final);
  ------------------------------
  p_params.m_do_break_on_error := p_break_on_error;
  ------------------------------
  setup_eq_status_final_i(p_params, p_eq_status_final);
  ------------------------------
  p_params.m_valid_until_common_nullable := p_valid_until_common_nullable;
  ------------------------------
  p_params.m_do_prematurely_populate := p_prematurely_populate;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_additional
(
    p_params in out nocopy t_ss_parameters,
    p_break_on_error boolean,
    p_eq_status_final number,
    p_valid_until_common date,
    p_prematurely_populate boolean
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_valid_until_common is null, 'p_valid_until_common');
  ------------------------------
  setup_additional_i
  (
    p_params => p_params,
    p_break_on_error => p_break_on_error,
    p_eq_status_final => p_eq_status_final,
    p_valid_until_common_nullable => p_valid_until_common,
    p_prematurely_populate => p_prematurely_populate
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_additional2
(
    p_params in out nocopy t_ss_parameters,
    p_break_on_error boolean,
    p_eq_status_final number,
    p_prematurely_populate boolean
)
is
begin
  ------------------------------
  setup_additional_i
  (
    p_params => p_params,
    p_break_on_error => p_break_on_error,
    p_eq_status_final => p_eq_status_final,
    p_valid_until_common_nullable => NULL,
    p_prematurely_populate => p_prematurely_populate
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_range
(
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_model ct_model
)
is
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_range_start);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_range_start) != v_main_count, 'p_range_start.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_range_end) != v_main_count, 'p_range_end.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_stock.get_count_ct_model(p_model) != v_main_count, 'p_model.count != v_main_count');
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_range_side
(
    p_range_side ct_nvarchar_s,
    p_model ct_model
)
is
begin
  ------------------------------
  XCheck_range
  (
    p_range_start => p_range_side,
    p_range_end => p_range_side, --!_!same p_range_side; dirty hack
    p_model => p_model
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_in_data_raw
(
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_model ct_model,
    p_valid_until ct_date,
    p_is_addition ct_number
)
is
  v_main_count number;
begin
  ------------------------------
  XCheck_range
  (
    p_range_start => p_range_start,
    p_range_end => p_range_end,
    p_model => p_model
  );
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_range_start);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_valid_until) != v_main_count, 'p_valid_until.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_is_addition) != v_main_count, 'p_is_addition.count != v_main_count');
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_in_data_raw2
(
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_model ct_model,
    p_is_addition ct_number
)
is
  v_main_count number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_range_start);
  ------------------------------
  XCheck_in_data_raw
  (
    p_range_start => p_range_start,
    p_range_end => p_range_end,
    p_model => p_model,
    p_valid_until => util_pkg.make_ct_date(v_main_count, null), --!_!no need; dirty hack
    p_is_addition => p_is_addition
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_rt_in_data(p_in_data rt_in_data)
is
  v_main_count number;
begin
  ------------------------------
  XCheck_range
  (
    p_range_start => p_in_data.m_range_start,
    p_range_end => p_in_data.m_range_end,
    p_model => p_in_data.m_model
  );
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_in_data.m_range_start);
  ------------------------------
  --!_!m_range_start, m_range_end, m_model
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_in_data.m_quantity) != v_main_count, 'm_quantity.count != v_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_in_data.m_valid_until) != v_main_count, 'm_valid_until.count != v_main_count');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_in_data.m_id_original) != v_main_count, 'm_id_original.count != v_main_count');
  ------------------------------
  --!_!util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_cit_number(p_in_data.m_error_code) != v_main_count, 'm_error_code.count != v_main_count');
  --!_!util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_cit_varchar(p_in_data.m_error_message) != v_main_count, 'm_error_message.count != v_main_count');
  ------------------------------
  if v_main_count < 1
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheckP_FS_ct_nvarchar_s(p_in_data.m_range_start, 'm_range_start');
  util_pkg.XCheckP_FS_ct_nvarchar_s(p_in_data.m_range_end, 'm_range_end');
  util_pkg.XCheckP_FS_ct_number(p_in_data.m_quantity, 'm_quantity');
  util_stock.XCheckP_FS_ct_model(p_in_data.m_model, 'm_model');
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_date(p_in_data.m_valid_until, 'm_valid_until'); --!_! NULLABLE items
  ------------------------------
  util_pkg.XCheckP_FS_ct_number(p_in_data.m_id_original, 'm_id_original');
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xmake_rt_in_data_i
(
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_quantity ct_number,
    p_model ct_model,
    p_valid_until ct_date,
    p_id_original ct_number
) return rt_in_data
is
  v_res rt_in_data;
begin
  ------------------------------
  v_res.m_range_start := p_range_start;
  v_res.m_range_end := p_range_end;
  v_res.m_quantity := p_quantity;
  v_res.m_model := p_model;
  ------------------------------
  v_res.m_valid_until := p_valid_until;
  ------------------------------
  v_res.m_id_original := p_id_original;
  ------------------------------
  v_res.m_error_code := util_pkg.empty_cit_number;
  v_res.m_error_message := util_pkg.empty_cit_varchar;
  ------------------------------
  XCheck_rt_in_data(v_res);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xsmart_make_rt_in_data
(
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_quantity ct_number,
    p_model ct_model,
    p_valid_until ct_date,
    p_id_original ct_number
) return rt_in_data
is
begin
  ------------------------------
  --!_!if there's some errors below then internal XCheck_rt_in_data raises exxception
  ------------------------------
  return xmake_rt_in_data_i
  (
    p_range_start => p_range_start, --!_!must be NO nulls, legacy values ALREADY must be translated to normal
    p_range_end => p_range_end, --!_!must be NO nulls, legacy values ALREADY must be translated to normal
    p_quantity => p_quantity, --!_!must be NO nulls
    p_model => p_model, --!_!must be NO nulls
    p_valid_until => p_valid_until, --!_!MAY be nulls AS business rules
    p_id_original => p_id_original --!_!must be NO nulls
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure make_in_data4input_normal
(
    p_doc_type_id number,
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_quantity ct_number,
    p_model ct_model,
    p_valid_until ct_date,
    p_o_in_data_src out rt_in_data,
    p_o_in_data_dst out rt_in_data,
    p_o_in_data_ext_src out rt_in_data,
    p_o_in_data_ext_dst out rt_in_data
)
is
  v_doc_dir_type number;
  v_main_count number;
  v_id_original ct_number;
  v_id_original2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  if NOT util_stock.is_doc_normal(p_doc_type_id)
  then
    ------------------------------
    util_pkg.raise_exception(util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_doc_type_id));
    ------------------------------
  end if;
  ------------------------------
  v_doc_dir_type := util_stock.xget_doc_dir_type(p_doc_type_id);
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_range_start);
  ------------------------------
  p_o_in_data_src := NULL;
  p_o_in_data_dst := NULL;
  ------------------------------
  p_o_in_data_ext_src := NULL; --!_! for this case
  p_o_in_data_ext_dst := NULL; --!_! for this case
  ------------------------------
  if v_doc_dir_type = util_stock.c_Doc_Dir_Type_Out
  then
    ------------------------------
    v_id_original := smart_make_1_id_original
    (
      p_main_count => v_main_count
    );
    ------------------------------
    p_o_in_data_src := xsmart_make_rt_in_data
    (
      p_range_start => p_range_start,
      p_range_end => p_range_end,
      p_quantity => p_quantity,
      p_model => p_model,
      p_valid_until => p_valid_until,
      p_id_original => v_id_original
    );
    ------------------------------
  elsif v_doc_dir_type = util_stock.c_Doc_Dir_Type_In
  then
    ------------------------------
    v_id_original := smart_make_1_id_original
    (
      p_main_count => v_main_count
    );
    ------------------------------
    p_o_in_data_dst := xsmart_make_rt_in_data
    (
      p_range_start => p_range_start,
      p_range_end => p_range_end,
      p_quantity => p_quantity,
      p_model => p_model,
      p_valid_until => p_valid_until,
      p_id_original => v_id_original
    );
    ------------------------------
  else --!_!really only c_Doc_Type_Movement
    ------------------------------
    smart_make_2_id_original2
    (
      p_main_count => v_main_count,
      p_o_id_original1 => v_id_original,
      p_o_id_original2 => v_id_original2
    );
    ------------------------------
    p_o_in_data_src := xsmart_make_rt_in_data
    (
      p_range_start => p_range_start,
      p_range_end => p_range_end,
      p_quantity => p_quantity,
      p_model => p_model,
      p_valid_until => p_valid_until,
      p_id_original => v_id_original
    );
    ------------------------------
    p_o_in_data_dst := xsmart_make_rt_in_data
    (
      p_range_start => p_range_start,
      p_range_end => p_range_end,
      p_quantity => p_quantity,
      p_model => p_model,
      p_valid_until => p_valid_until,
      p_id_original => v_id_original2
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure make_in_data4input_set_op_eq
(
    p_doc_type_id number,
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_quantity ct_number,
    p_model ct_model,
    p_valid_until ct_date,
    p_is_addition ct_number,
    p_o_in_data_src out rt_in_data,
    p_o_in_data_dst out rt_in_data,
    p_o_in_data_ext_src out rt_in_data,
    p_o_in_data_ext_dst out rt_in_data
)
is
  v_doc_dir_type number;
  v_marks ct_number;
  v_range_start ct_nvarchar_s;
  v_range_end ct_nvarchar_s;
  v_quantity ct_number;
  v_model ct_model;
  v_valid_until ct_date;
  v_range_start_ext ct_nvarchar_s;
  v_range_end_ext ct_nvarchar_s;
  v_quantity_ext ct_number;
  v_model_ext ct_model;
  v_valid_until_ext ct_date;
  v_main_count number;
  v_main_count2 number;
  v_main_count2_ext number;
  v_id_original ct_number;
  --!_!v_id_original2 ct_number;
  v_id_original_ext ct_number;
  --!_!v_id_original_ext2 ct_number;
  v_pivot ct_number;
  v_pivot2 ct_number;
  v_pivot2_ext ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  if util_stock.is_doc_initially_finalized(p_doc_type_id)
  then
    ------------------------------
    util_pkg.raise_exception(util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_doc_type_id));
    ------------------------------
  end if;
  ------------------------------
  --!_!util_pkg.XCheckP_FS_ct_number(p_is_addition, 'p_is_addition');
  ------------------------------
  v_marks := util_pkg.mark_val_ct_number(p_is_addition, util_pkg.c_true);
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_range_start);
  ------------------------------
  v_pivot := util_pkg.make_pivot_or_empty(v_main_count);
  ------------------------------
  v_pivot2 := util_pkg.get_marked_ct_number(v_pivot, v_marks, TRUE);
  v_pivot2_ext := util_pkg.get_marked_ct_number(v_pivot, v_marks, TRUE, util_pkg.c_false);
  ------------------------------
  v_range_start := util_pkg.get_by_pos_ct_nvarchar_s(p_range_start, v_pivot2, FALSE);
  v_range_end := util_pkg.get_by_pos_ct_nvarchar_s(p_range_end, v_pivot2, FALSE);
  v_quantity := util_pkg.get_by_pos_ct_number(p_quantity, v_pivot2, FALSE);
  v_model := util_stock.get_by_pos_ct_model(p_model, v_pivot2, FALSE);
  v_valid_until := util_pkg.get_by_pos_ct_date(p_valid_until, v_pivot2, FALSE);
  ------------------------------
  v_range_start_ext := util_pkg.get_by_pos_ct_nvarchar_s(p_range_start, v_pivot2_ext, FALSE);
  v_range_end_ext := util_pkg.get_by_pos_ct_nvarchar_s(p_range_end, v_pivot2_ext, FALSE);
  v_quantity_ext := util_pkg.get_by_pos_ct_number(p_quantity, v_pivot2_ext, FALSE);
  v_model_ext := util_stock.get_by_pos_ct_model(p_model, v_pivot2_ext, FALSE);
  v_valid_until_ext := util_pkg.get_by_pos_ct_date(p_valid_until, v_pivot2_ext, FALSE);
  ------------------------------
  v_doc_dir_type := util_stock.xget_doc_dir_type(p_doc_type_id);
  ------------------------------
  v_main_count2 := util_pkg.get_count_ct_nvarchar_s(v_range_start);
  v_main_count2_ext := util_pkg.get_count_ct_nvarchar_s(v_range_start_ext);
  ------------------------------
  p_o_in_data_src := NULL;
  p_o_in_data_dst := NULL;
  ------------------------------
  p_o_in_data_ext_src := NULL;
  p_o_in_data_ext_dst := NULL;
  ------------------------------
  if v_doc_dir_type = util_stock.c_Doc_Dir_Type_Out
  then
    ------------------------------
    smart_make_2_id_original
    (
      p_main_count1 => v_main_count2,
      p_main_count2 => v_main_count2_ext,
      p_o_id_original1 => v_id_original,
      p_o_id_original2 => v_id_original_ext
    );
    ------------------------------
    p_o_in_data_src := xsmart_make_rt_in_data
    (
      p_range_start => v_range_start,
      p_range_end => v_range_end,
      p_quantity => v_quantity,
      p_model => v_model,
      p_valid_until => v_valid_until,
      p_id_original => v_id_original
    );
    ------------------------------
    p_o_in_data_ext_src := xsmart_make_rt_in_data
    (
      p_range_start => v_range_start_ext,
      p_range_end => v_range_end_ext,
      p_quantity => v_quantity_ext,
      p_model => v_model_ext,
      p_valid_until => v_valid_until_ext,
      p_id_original => v_id_original_ext
    );
    ------------------------------
  elsif v_doc_dir_type = util_stock.c_Doc_Dir_Type_In
  then
    ------------------------------
    smart_make_2_id_original
    (
      p_main_count1 => v_main_count2,
      p_main_count2 => v_main_count2_ext,
      p_o_id_original1 => v_id_original,
      p_o_id_original2 => v_id_original_ext
    );
    ------------------------------
    p_o_in_data_dst := xsmart_make_rt_in_data
    (
      p_range_start => v_range_start,
      p_range_end => v_range_end,
      p_quantity => v_quantity,
      p_model => v_model,
      p_valid_until => v_valid_until,
      p_id_original => v_id_original
    );
    ------------------------------
    p_o_in_data_ext_dst := xsmart_make_rt_in_data
    (
      p_range_start => v_range_start_ext,
      p_range_end => v_range_end_ext,
      p_quantity => v_quantity_ext,
      p_model => v_model_ext,
      p_valid_until => v_valid_until_ext,
      p_id_original => v_id_original_ext
    );
    ------------------------------
  else --!_!really only c_Doc_Type_Movement
    ------------------------------
    --!_!smart_make_4_id_original2
    --!_!(
    --!_!  p_main_count1 => v_main_count2,
    --!_!  p_main_count2 => v_main_count2_ext,
    --!_!  p_o_id_original11 => v_id_original,
    --!_!  p_o_id_original12 => v_id_original2,
    --!_!  p_o_id_original21 => v_id_original_ext,
    --!_!  p_o_id_original22 => v_id_original_ext2
    --!_!);
    smart_make_2_id_original
    (
      p_main_count1 => v_main_count2,
      p_main_count2 => v_main_count2_ext,
      p_o_id_original1 => v_id_original,
      p_o_id_original2 => v_id_original_ext
    );
    ------------------------------
    p_o_in_data_src := xsmart_make_rt_in_data
    (
      p_range_start => v_range_start,
      p_range_end => v_range_end,
      p_quantity => v_quantity,
      p_model => v_model,
      p_valid_until => v_valid_until,
      p_id_original => v_id_original
    );
    ------------------------------
    p_o_in_data_dst := xsmart_make_rt_in_data
    (
      p_range_start => v_range_start,
      p_range_end => v_range_end,
      p_quantity => v_quantity,
      p_model => v_model,
      p_valid_until => v_valid_until,
      p_id_original => v_id_original --!_!v_id_original2
    );
    ------------------------------
    p_o_in_data_ext_src := xsmart_make_rt_in_data
    (
      p_range_start => v_range_start_ext,
      p_range_end => v_range_end_ext,
      p_quantity => v_quantity_ext,
      p_model => v_model_ext,
      p_valid_until => v_valid_until_ext,
      p_id_original => v_id_original_ext
    );
    ------------------------------
    p_o_in_data_dst := xsmart_make_rt_in_data
    (
      p_range_start => v_range_start_ext,
      p_range_end => v_range_end_ext,
      p_quantity => v_quantity_ext,
      p_model => v_model_ext,
      p_valid_until => v_valid_until_ext,
      p_id_original => v_id_original_ext --!_!v_id_original_ext2
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure make_in_data4input_src_dst
(
    p_doc_type_id number,
    p_range_start_src ct_nvarchar_s,
    p_range_end_src ct_nvarchar_s,
    p_quantity_src ct_number,
    p_model_src ct_model,
    p_valid_until_src ct_date,
    p_range_start_dst ct_nvarchar_s,
    p_range_end_dst ct_nvarchar_s,
    p_quantity_dst ct_number,
    p_model_dst ct_model,
    p_valid_until_dst ct_date,
    p_o_in_data_src out rt_in_data,
    p_o_in_data_dst out rt_in_data,
    p_o_in_data_ext_src out rt_in_data,
    p_o_in_data_ext_dst out rt_in_data
)
is
  v_main_count_src number;
  v_main_count_dst number;
  v_id_original_src ct_number;
  v_id_original_dst ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  ------------------------------
  if NOT util_stock.is_doc_src_dst(p_doc_type_id)
  then
    ------------------------------
    util_pkg.raise_exception(util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || util_pkg.number_to_char(p_doc_type_id));
    ------------------------------
  end if;
  ------------------------------
  v_main_count_src := util_pkg.get_count_ct_nvarchar_s(p_range_start_src);
  v_main_count_dst := util_pkg.get_count_ct_nvarchar_s(p_range_start_dst);
  ------------------------------
  p_o_in_data_src := NULL;
  p_o_in_data_dst := NULL;
  ------------------------------
  p_o_in_data_ext_src := NULL; --!_! for this case
  p_o_in_data_ext_dst := NULL; --!_! for this case
  ------------------------------
  smart_make_2_id_original
  (
    p_main_count1 => v_main_count_src,
    p_main_count2 => v_main_count_dst,
    p_o_id_original1 => v_id_original_src,
    p_o_id_original2 => v_id_original_dst
  );
  ------------------------------
  p_o_in_data_src := xsmart_make_rt_in_data
  (
    p_range_start => p_range_start_src,
    p_range_end => p_range_end_src,
    p_quantity => p_quantity_src,
    p_model => p_model_src,
    p_valid_until => p_valid_until_src,
    p_id_original => v_id_original_src
  );
  ------------------------------
  p_o_in_data_dst := xsmart_make_rt_in_data
  (
    p_range_start => p_range_start_dst,
    p_range_end => p_range_end_dst,
    p_quantity => p_quantity_dst,
    p_model => p_model_dst,
    p_valid_until => p_valid_until_dst,
    p_id_original => v_id_original_dst
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function xsmart_make_valid_until
(
    p_valid_until_raw ct_date,
    p_main_count number,
    p_valid_until_common_nullable date
) return ct_date
is
  v_res ct_date;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_ct_date(p_valid_until_raw, 'p_valid_until_raw');
  util_pkg.XCheck_Cond_Missing(p_main_count is null, 'p_main_count');
  --!_!util_pkg.XCheck_Cond_Missing(p_valid_until_common_nullable is null, 'p_valid_until_common_nullable');
  ------------------------------
  if p_valid_until_raw is null
  then
    ------------------------------
    v_res := util_pkg.make_ct_date(p_main_count, p_valid_until_common_nullable);
    ------------------------------
  else
    ------------------------------
    util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_date(p_valid_until_raw) != p_main_count, 'p_valid_until_raw.count != p_main_count');
    ------------------------------
    --!_!util_pkg.XCheckP_FS_ct_date(p_valid_until_raw, 'p_valid_until_raw');
    ------------------------------
    v_res := p_valid_until_raw;
    ------------------------------
    for v_i in 1..p_main_count
    loop
      ------------------------------
      v_res(v_i) := nvl(v_res(v_i), p_valid_until_common_nullable);
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xsmart_make_valid_until2
(
    p_main_count number,
    p_valid_until_common_nullable date
) return ct_date
is
begin
  ------------------------------
  return xsmart_make_valid_until
  (
    p_valid_until_raw => NULL,
    p_main_count => p_main_count,
    p_valid_until_common_nullable => p_valid_until_common_nullable
  );
  ------------------------------
end;


----------------------------------!---------------------------------------------
function xsmart_make_is_addition
(
    p_is_addition_raw ct_number,
    p_main_count number
) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  --!_!util_pkg.XCheckP_ct_number(p_is_addition_raw, 'p_is_addition_raw');
  util_pkg.XCheck_Cond_Missing(p_main_count is null, 'p_main_count');
  ------------------------------
  if p_is_addition_raw is null
  then
    ------------------------------
    v_res := util_pkg.make_ct_number(p_main_count, util_pkg.c_true); --!_! default is add
    ------------------------------
  else
    ------------------------------
    util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_is_addition_raw) != p_main_count, 'p_is_addition_raw.count != p_main_count');
    ------------------------------
    --!_!util_pkg.XCheckP_FS_ct_number(p_is_addition_raw, 'p_is_addition_raw');
    ------------------------------
    v_res := p_is_addition_raw;
    ------------------------------
    for v_i in 1..p_main_count
    loop
      ------------------------------
      v_res(v_i) := nvl(v_res(v_i), util_pkg.c_true); --!_! default is add
      ------------------------------
    end loop;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function invert_is_addition(p_coll ct_number) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  v_res := p_coll;
  ------------------------------
  if util_pkg.get_count_ct_number(v_res) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  for v_i in v_res.first..v_res.last
  loop
    ------------------------------
    if v_res(v_i) = util_pkg.c_true
    then
      ------------------------------
      v_res(v_i) := util_pkg.c_false;
      ------------------------------
    else
      ------------------------------
      v_res(v_i) := util_pkg.c_true;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function smart_make_1_id_original
(
    p_main_count number
) return ct_number
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_main_count is null, 'p_main_count');
  ------------------------------
  return util_pkg.make_pivot_or_empty(p_main_count);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure smart_make_2_id_original
(
    p_main_count1 number,
    p_main_count2 number,
    p_o_id_original1 out ct_number,
    p_o_id_original2 out ct_number
)
is
  lc_id_start constant number := 1;
  lc_id_step constant number := 1;
  v_id_start number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_main_count1 is null, 'p_main_count1');
  util_pkg.XCheck_Cond_Missing(p_main_count2 is null, 'p_main_count2');
  ------------------------------
  v_id_start := lc_id_start;
  ------------------------------
  p_o_id_original1 := util_pkg.make_pivot_or_empty(p_main_count1, v_id_start);
  ------------------------------
  if util_pkg.get_count_ct_number(p_o_id_original1) > 0
  then
    ------------------------------
    v_id_start := p_o_id_original1.last + lc_id_step;
    ------------------------------
  end if;
  ------------------------------
  p_o_id_original2 := util_pkg.make_pivot_or_empty(p_main_count2, v_id_start);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure smart_make_2_id_original2
(
    p_main_count number,
    p_o_id_original1 out ct_number,
    p_o_id_original2 out ct_number
)
is
begin
  ------------------------------
  smart_make_2_id_original
  (
    p_main_count1 => p_main_count,
    p_main_count2 => p_main_count,
    p_o_id_original1 => p_o_id_original1,
    p_o_id_original2 => p_o_id_original2
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!NOW is not used
----------------------------------!---------------------------------------------
procedure smart_make_4_id_original
(
    p_main_count1 number,
    p_main_count2 number,
    p_main_count3 number,
    p_main_count4 number,
    p_o_id_original1 out ct_number,
    p_o_id_original2 out ct_number,
    p_o_id_original3 out ct_number,
    p_o_id_original4 out ct_number
)
is
  lc_id_start constant number := 1;
  lc_id_step constant number := 1;
  v_id_start number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_main_count1 is null, 'p_main_count1');
  util_pkg.XCheck_Cond_Missing(p_main_count2 is null, 'p_main_count2');
  util_pkg.XCheck_Cond_Missing(p_main_count3 is null, 'p_main_count3');
  util_pkg.XCheck_Cond_Missing(p_main_count4 is null, 'p_main_count4');
  ------------------------------
  v_id_start := lc_id_start;
  ------------------------------
  p_o_id_original1 := util_pkg.make_pivot_or_empty(p_main_count1, v_id_start);
  ------------------------------
  if util_pkg.get_count_ct_number(p_o_id_original1) > 0
  then
    ------------------------------
    v_id_start := p_o_id_original1.last + lc_id_step;
    ------------------------------
  end if;
  ------------------------------
  p_o_id_original2 := util_pkg.make_pivot_or_empty(p_main_count2, v_id_start);
  ------------------------------
  if util_pkg.get_count_ct_number(p_o_id_original2) > 0
  then
    ------------------------------
    v_id_start := p_o_id_original2.last + lc_id_step;
    ------------------------------
  end if;
  ------------------------------
  p_o_id_original3 := util_pkg.make_pivot_or_empty(p_main_count3, v_id_start);
  ------------------------------
  if util_pkg.get_count_ct_number(p_o_id_original3) > 0
  then
    ------------------------------
    v_id_start := p_o_id_original3.last + lc_id_step;
    ------------------------------
  end if;
  ------------------------------
  p_o_id_original4 := util_pkg.make_pivot_or_empty(p_main_count4, v_id_start);
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!NOW is not used
----------------------------------!---------------------------------------------
procedure smart_make_4_id_original2
(
    p_main_count1 number,
    p_main_count2 number,
    p_o_id_original11 out ct_number,
    p_o_id_original12 out ct_number,
    p_o_id_original21 out ct_number,
    p_o_id_original22 out ct_number
)
is
begin
  ------------------------------
  smart_make_4_id_original
  (
    p_main_count1 => p_main_count1,
    p_main_count2 => p_main_count1,
    p_main_count3 => p_main_count2,
    p_main_count4 => p_main_count2,
    p_o_id_original1 => p_o_id_original11,
    p_o_id_original2 => p_o_id_original12,
    p_o_id_original3 => p_o_id_original21,
    p_o_id_original4 => p_o_id_original22
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xsmart_make_quantity
(
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model
) return ct_number
is
  v_res ct_number;
  v_main_count number;
begin
  ------------------------------
  XCheck_range
  (
    p_range_start => p_range_start_raw,
    p_range_end => p_range_end_raw,
    p_model => p_model
  );
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_range_start_raw);
  ------------------------------
  if v_main_count < 1
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  --!_!util_stock.XCheckP_FS_ct_model(p_model, 'p_model'); --!_!reduces performance; exception will be in xhas_model_serial
  ------------------------------
  v_res := util_pkg.make_ct_number(v_main_count, null);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if util_stock.xhas_model_serial(p_model(v_i))
    then
      ------------------------------
      v_res(v_i) := util_stock.xget_seria_quantity(p_range_start_raw(v_i), p_range_end_raw(v_i));
      ------------------------------
    else
      ------------------------------
      v_res(v_i) := xget_nonserial_quantity_legacy(p_range_END_raw(v_i));
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function xget_nonserial_quantity_legacy(p_seria_END_raw nvarchar2) return integer
is
begin
  ------------------------------
  util_stock.XCheck_serial_number(p_seria_END_raw, 'p_seria_END_raw');
  ------------------------------
  return util_stock.get_serial_as_number(p_seria_END_raw);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xsmart_make_ranges
(
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model,
    p_o_range_start out ct_nvarchar_s,
    p_o_range_end out ct_nvarchar_s
)
is
  v_main_count number;
begin
  ------------------------------
  XCheck_range
  (
    p_range_start => p_range_start_raw,
    p_range_end => p_range_end_raw,
    p_model => p_model
  );
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_range_start_raw);
  ------------------------------
  if v_main_count < 1
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  --!_!util_stock.XCheckP_FS_ct_model(p_model, 'p_model'); --!_!reduces performance; exception will be in xhas_model_serial
  ------------------------------
  p_o_range_start := util_pkg.make_ct_nvarchar_s(v_main_count, null);
  p_o_range_end := util_pkg.make_ct_nvarchar_s(v_main_count, null);
  ------------------------------
  for v_i in 1..v_main_count
  loop
    ------------------------------
    if util_stock.xhas_model_serial(p_model(v_i))
    then
      ------------------------------
      util_stock.XCheck_seria(p_range_start_raw(v_i), p_range_end_raw(v_i));
      ------------------------------
      p_o_range_start(v_i) := p_range_start_raw(v_i);
      p_o_range_end(v_i) := p_range_end_raw(v_i);
      ------------------------------
    else
      ------------------------------
      p_o_range_start(v_i) := c_def_range_side;
      p_o_range_end(v_i) := c_def_range_side;
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure xsmart_make_range_and_quantity
(
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model,
    p_o_range_start out ct_nvarchar_s,
    p_o_range_end out ct_nvarchar_s,
    p_o_quantity out ct_number
)
is
begin
  ------------------------------
  xsmart_make_ranges
  (
    p_range_start_raw => p_range_start_raw,
    p_range_end_raw => p_range_end_raw,
    p_model => p_model,
    p_o_range_start => p_o_range_start,
    p_o_range_end => p_o_range_end
  );
  ------------------------------
  p_o_quantity := xsmart_make_quantity
  (
    p_range_start_raw => p_range_start_raw, --!_!raw to preserve legacy
    p_range_end_raw => p_range_end_raw, --!_!raw to preserve legacy
    p_model => p_model
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure setup_input_ii
(
    p_params in out nocopy t_ss_parameters,
    p_in_data_src rt_in_data,
    p_in_data_dst rt_in_data,
    p_in_data_ext_src rt_in_data,
    p_in_data_ext_dst rt_in_data
)
is
begin
  ------------------------------
  --!_! xcheck is placed in xsmart_make_rt_in_data
  --!_!XCheck_rt_in_data(p_in_data_src);
  --!_!XCheck_rt_in_data(p_in_data_dst);
  --!_!XCheck_rt_in_data(p_in_data_ext_src);
  --!_!XCheck_rt_in_data(p_in_data_ext_dst);
  ------------------------------
  if 1 = 1
    and get_count_rt_in_data(p_in_data_src) = 0
    and get_count_rt_in_data(p_in_data_dst) = 0
    and get_count_rt_in_data(p_in_data_ext_src) = 0
    and get_count_rt_in_data(p_in_data_ext_dst) = 0
  then
    ------------------------------
    setup_empty_doc_i(p_params);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  p_params.m_in_data_src := p_in_data_src;
  p_params.m_in_data_dst := p_in_data_dst;
  p_params.m_in_data_ext_src := p_in_data_ext_src;
  p_params.m_in_data_ext_dst := p_in_data_ext_dst;
  ------------------------------
  p_params.m_is_input_set := TRUE;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_input_normal_i
(
    p_params in out nocopy t_ss_parameters,
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_quantity ct_number,
    p_model ct_model,
    p_valid_until ct_date
)
is
  v_doc_type_id number;
begin
  ------------------------------
  v_doc_type_id := XGP_document_type(p_params);
  ------------------------------
  if NOT util_stock.is_doc_normal(v_doc_type_id)
  then
    ------------------------------
    util_pkg.raise_exception(util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || util_pkg.number_to_char(v_doc_type_id));
    ------------------------------
  end if;
  ------------------------------
  make_in_data4input_normal
  (
    p_doc_type_id => v_doc_type_id,
    p_range_start => p_range_start,
    p_range_end => p_range_end,
    p_quantity => p_quantity,
    p_model => p_model,
    p_valid_until => p_valid_until,
    p_o_in_data_src => p_params.m_in_data_src,
    p_o_in_data_dst => p_params.m_in_data_dst,
    p_o_in_data_ext_src => p_params.m_in_data_ext_src,
    p_o_in_data_ext_dst => p_params.m_in_data_ext_dst
  );
  ------------------------------
  setup_input_ii
  (
    p_params => p_params,
    p_in_data_src => p_params.m_in_data_src,
    p_in_data_dst => p_params.m_in_data_dst,
    p_in_data_ext_src => p_params.m_in_data_ext_src,
    p_in_data_ext_dst => p_params.m_in_data_ext_dst
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure legacy_setup_input_normal
(
    p_params in out nocopy t_ss_parameters,
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model,
    p_valid_until_raw ct_date
)
is
  v_main_count number;
  v_range_start ct_nvarchar_s;
  v_range_end ct_nvarchar_s;
  v_quantity ct_number;
  v_valid_until ct_date;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_range_start_raw);
  ------------------------------
  xsmart_make_range_and_quantity
  (
    p_range_start_raw => p_range_start_raw,
    p_range_end_raw => p_range_end_raw,
    p_model => p_model,
    p_o_range_start => v_range_start,
    p_o_range_end => v_range_end,
    p_o_quantity => v_quantity
  );
  ------------------------------
  v_valid_until := xsmart_make_valid_until
  (
    p_valid_until_raw => p_valid_until_raw,
    p_main_count => v_main_count,
    p_valid_until_common_nullable => GP_valid_until_common_nullable(p_params)
  );
  ------------------------------
  setup_input_normal_i
  (
    p_params => p_params,
    p_range_start => v_range_start,
    p_range_end => v_range_end,
    p_quantity => v_quantity,
    p_model => p_model,
    p_valid_until => v_valid_until
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure legacy_setup_input_normal2
(
    p_params in out nocopy t_ss_parameters,
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model
)
is
begin
  ------------------------------
  legacy_setup_input_normal
  (
    p_params => p_params,
    p_range_start_raw => p_range_start_raw,
    p_range_end_raw => p_range_end_raw,
    p_model => p_model,
    p_valid_until_raw => NULL
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_input_set_op_eq_i
(
    p_params in out nocopy t_ss_parameters,
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_quantity ct_number,
    p_model ct_model,
    p_valid_until ct_date,
    p_is_addition ct_number
    --!_!other side params would be usefull for open (non-finalized) 2 side documents: c_Doc_Type_SeriaPartition, c_Doc_Type_SeriaAssembling etc
    --!_!Now the method is used only for 1 side documents
)
is
  v_doc_type_id number;
begin
  ------------------------------
  v_doc_type_id := XGP_document_type(p_params);
  ------------------------------
  if util_stock.is_doc_initially_finalized(v_doc_type_id)
  then
    ------------------------------
    util_pkg.raise_exception(util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || util_pkg.number_to_char(v_doc_type_id));
    ------------------------------
  end if;
  ------------------------------
  make_in_data4input_set_op_eq
  (
    p_doc_type_id => v_doc_type_id,
    p_range_start => p_range_start,
    p_range_end => p_range_end,
    p_quantity => p_quantity,
    p_model => p_model,
    p_valid_until => p_valid_until,
    p_is_addition => p_is_addition,
    p_o_in_data_src => p_params.m_in_data_src,
    p_o_in_data_dst => p_params.m_in_data_dst,
    p_o_in_data_ext_src => p_params.m_in_data_ext_src,
    p_o_in_data_ext_dst => p_params.m_in_data_ext_dst
  );
  ------------------------------
  setup_input_ii
  (
    p_params => p_params,
    p_in_data_src => p_params.m_in_data_src,
    p_in_data_dst => p_params.m_in_data_dst,
    p_in_data_ext_src => p_params.m_in_data_ext_src,
    p_in_data_ext_dst => p_params.m_in_data_ext_dst
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure legacy_setup_input_set_op_eq
(
    p_params in out nocopy t_ss_parameters,
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model,
    p_valid_until_raw ct_date,
    p_is_addition_raw ct_number
)
is
  v_main_count number;
  v_range_start ct_nvarchar_s;
  v_range_end ct_nvarchar_s;
  v_quantity ct_number;
  v_valid_until ct_date;
  v_is_addition ct_number;
begin
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_range_start_raw);
  ------------------------------
  xsmart_make_range_and_quantity
  (
    p_range_start_raw => p_range_start_raw,
    p_range_end_raw => p_range_end_raw,
    p_model => p_model,
    p_o_range_start => v_range_start,
    p_o_range_end => v_range_end,
    p_o_quantity => v_quantity
  );
  ------------------------------
  v_valid_until := xsmart_make_valid_until
  (
    p_valid_until_raw => p_valid_until_raw,
    p_main_count => v_main_count,
    p_valid_until_common_nullable => GP_valid_until_common_nullable(p_params)
  );
  ------------------------------
  v_is_addition := xsmart_make_is_addition
  (
    p_is_addition_raw => p_is_addition_raw,
    p_main_count => v_main_count
  );
  ------------------------------
  setup_input_set_op_eq_i
  (
    p_params => p_params,
    p_range_start => v_range_start,
    p_range_end => v_range_end,
    p_quantity => v_quantity,
    p_model => p_model,
    p_valid_until => v_valid_until,
    p_is_addition => v_is_addition
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure legacy_setup_input_set_op_eq2
(
    p_params in out nocopy t_ss_parameters,
    p_range_start_raw ct_nvarchar_s,
    p_range_end_raw ct_nvarchar_s,
    p_model ct_model,
    p_is_addition_raw ct_number
)
is
begin
  ------------------------------
  legacy_setup_input_set_op_eq
  (
    p_params => p_params,
    p_range_start_raw => p_range_start_raw,
    p_range_end_raw => p_range_end_raw,
    p_model => p_model,
    p_valid_until_raw => NULL, --!_! proper value for xsmart_make_valid_until
    p_is_addition_raw => p_is_addition_raw
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!NO raw params cause new method
----------------------------------!---------------------------------------------
procedure setup_input_src_dst
(
    p_params in out nocopy t_ss_parameters,
    p_range_start_src ct_nvarchar_s,
    p_range_end_src ct_nvarchar_s,
    p_quantity_src ct_number,
    p_model_src ct_model,
    p_valid_until_src ct_date,
    p_range_start_dst ct_nvarchar_s,
    p_range_end_dst ct_nvarchar_s,
    p_quantity_dst ct_number,
    p_model_dst ct_model,
    p_valid_until_dst ct_date
)
is
  v_doc_type_id number;
begin
  ------------------------------
  v_doc_type_id := XGP_document_type(p_params);
  ------------------------------
  if NOT util_stock.is_doc_src_dst(v_doc_type_id)
  then
    ------------------------------
    util_pkg.raise_exception(util_loc_pkg.c_ora_wrong_doc_type, util_loc_pkg.c_msg_wrong_doc_type || util_pkg.c_msg_delim01 || util_pkg.number_to_char(v_doc_type_id));
    ------------------------------
  end if;
  ------------------------------
  make_in_data4input_src_dst
  (
    p_doc_type_id => v_doc_type_id,
    p_range_start_src => p_range_start_src,
    p_range_end_src => p_range_end_src,
    p_quantity_src => p_quantity_src,
    p_model_src => p_model_src,
    p_valid_until_src => p_valid_until_src,
    p_range_start_dst => p_range_start_dst,
    p_range_end_dst => p_range_end_dst,
    p_quantity_dst => p_quantity_dst,
    p_model_dst => p_model_dst,
    p_valid_until_dst => p_valid_until_dst,
    p_o_in_data_src => p_params.m_in_data_src,
    p_o_in_data_dst => p_params.m_in_data_dst,
    p_o_in_data_ext_src => p_params.m_in_data_ext_src,
    p_o_in_data_ext_dst => p_params.m_in_data_ext_dst
  );
  ------------------------------
  setup_input_ii
  (
    p_params => p_params,
    p_in_data_src => p_params.m_in_data_src,
    p_in_data_dst => p_params.m_in_data_dst,
    p_in_data_ext_src => p_params.m_in_data_ext_src,
    p_in_data_ext_dst => p_params.m_in_data_ext_dst
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_input_src_dst2
(
    p_params in out nocopy t_ss_parameters,
    p_range_start_src ct_nvarchar_s,
    p_range_end_src ct_nvarchar_s,
    p_quantity_src ct_number,
    p_model_src ct_model,
    p_range_start_dst ct_nvarchar_s,
    p_range_end_dst ct_nvarchar_s,
    p_quantity_dst ct_number,
    p_model_dst ct_model
)
is
  v_valid_until_src ct_date;
  v_valid_until_dst ct_date;
begin
  ------------------------------
  v_valid_until_src := xsmart_make_valid_until2
  (
    p_main_count => util_pkg.get_count_ct_nvarchar_s(p_range_start_src),
    p_valid_until_common_nullable => GP_valid_until_common_nullable(p_params)
  );
  ------------------------------
  v_valid_until_dst := xsmart_make_valid_until2
  (
    p_main_count => util_pkg.get_count_ct_nvarchar_s(p_range_start_dst),
    p_valid_until_common_nullable => GP_valid_until_common_nullable(p_params)
  );
  ------------------------------
  setup_input_src_dst
  (
    p_params => p_params,
    p_range_start_src => p_range_start_src,
    p_range_end_src => p_range_end_src,
    p_quantity_src => p_quantity_src,
    p_model_src => p_model_src,
    p_valid_until_src => v_valid_until_src,
    p_range_start_dst => p_range_start_dst,
    p_range_end_dst => p_range_end_dst,
    p_quantity_dst => p_quantity_dst,
    p_model_dst => p_model_dst,
    p_valid_until_dst => v_valid_until_dst
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_input_empty
(
    p_params in out nocopy t_ss_parameters
)
is
begin
  ------------------------------
  setup_input_ii
  (
    p_params => p_params,
    p_in_data_src => null,
    p_in_data_dst => null,
    p_in_data_ext_src => null,
    p_in_data_ext_dst => null
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!_!used only for document finalization
procedure setup_input_from_doc_detail(p_params in out nocopy t_ss_parameters)
is
begin
  ------------------------------
  if util_stock.is_doc_minus_src_detail(XGP_document_type(p_params))
  then
    ------------------------------
    setup_input_from_doc_detail01(p_params);
    ------------------------------
  else
    ------------------------------
    setup_input_from_doc_detail02(p_params);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_input_from_doc_detail01(p_params in out nocopy t_ss_parameters)
is
  v_doc_header_id number;
  v_date date := sysdate;
  --
  v_pos_range_start ct_nvarchar_s;
  v_pos_range_end ct_nvarchar_s;
  v_pos_quantity ct_number;
  v_pos_model_id ct_number;
  --
  v_neg_range_start ct_nvarchar_s;
  v_neg_range_end ct_nvarchar_s;
  v_neg_quantity ct_number;
  v_neg_model_id ct_number;
begin
  ------------------------------
  v_doc_header_id := XGP_doc_header_id(p_params);
  ------------------------------
  select /*+ index_asc(z IDX_DOCDETAIL_DHI_EMI_DMI_DMO)*/
    seria_start,
    seria_end,
    quantity,
    equipment_model_id--!_!,
    --!_!valid_until --!_! nullable field in doc_detail but it's nonsense
  bulk collect into
    v_pos_range_start,
    v_pos_range_end,
    v_pos_quantity,
    v_pos_model_id
  from doc_detail z
  where 1 = 1
    and doc_header_id = v_doc_header_id
    and quantity >= 0
  ;
  ------------------------------
  select /*+ index_asc(z IDX_DOCDETAIL_DHI_EMI_DMI_DMO)*/
    seria_start,
    seria_end,
    -quantity, --!_!must be POSITIVE
    equipment_model_id--!_!,
    --!_!valid_until --!_! nullable field in doc_detail but it's nonsense
  bulk collect into
    v_neg_range_start,
    v_neg_range_end,
    v_neg_quantity,
    v_neg_model_id
  from doc_detail z
  where 1 = 1
    and doc_header_id = v_doc_header_id
    and quantity < 0
  ;
  ------------------------------
  if 1 = 1
    and util_pkg.get_count_ct_nvarchar_s(v_pos_range_start) = 0
    and util_pkg.get_count_ct_nvarchar_s(v_neg_range_start) = 0
  then
    ------------------------------
    setup_empty_doc_i(p_params);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  setup_input_src_dst2
  (
    p_params          => p_params,
    p_range_start_src => v_neg_range_start,
    p_range_end_src   => v_neg_range_end,
    p_quantity_src    => v_neg_quantity,
    p_model_src       => util_stock.get_ct_model2_exact(v_neg_model_id, v_date),
    p_range_start_dst => v_pos_range_start,
    p_range_end_dst   => v_pos_range_end,
    p_quantity_dst    => v_pos_quantity,
    p_model_dst       => util_stock.get_ct_model2_exact(v_pos_model_id, v_date)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure setup_input_from_doc_detail02(p_params in out nocopy t_ss_parameters)
is
  v_doc_header_id number;
  v_date date := sysdate;
  v_range_start ct_nvarchar_s;
  v_range_end ct_nvarchar_s;
  v_quantity ct_number;
  v_model_id ct_number;
  v_model ct_model;
  v_valid_until ct_date;
  v_main_count number;
begin
  ------------------------------
  v_doc_header_id := XGP_doc_header_id(p_params);
  ------------------------------
  select /*+ index_asc(z IDX_DOCDETAIL_DHI_EMI_DMI_DMO)*/
    seria_start,
    seria_end,
    quantity,
    equipment_model_id--!_!,
    --!_!valid_until --!_! nullable field in doc_detail but it's nonsense
  bulk collect into
    v_range_start,
    v_range_end,
    v_quantity,
    v_model_id
  from doc_detail z
  where 1 = 1
    and doc_header_id = v_doc_header_id
  ;
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(v_range_start);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    setup_empty_doc_i(p_params);
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  v_model := util_stock.get_ct_model2_exact(v_model_id, v_date);
  ------------------------------
  v_valid_until := xsmart_make_valid_until2
  (
    p_main_count => v_main_count,
    p_valid_until_common_nullable => GP_valid_until_common_nullable(p_params)
  );
  ------------------------------
  setup_input_normal_i
  (
    p_params => p_params,
    p_range_start => v_range_start,
    p_range_end => v_range_end,
    p_quantity => v_quantity,
    p_model => v_model,
    p_valid_until => v_valid_until
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_default_eq_valid_until_i(p_params t_ss_parameters) return date
is
  v_res date := null; --!_!
  v_doc_dir_type number;
  v_doc_date date;
  v_shift number;
begin
  ------------------------------
  v_doc_dir_type := XGP_doc_dir_type(p_params);
  ------------------------------
  v_doc_date := XGP_document_date(p_params);
  ------------------------------
  v_shift := GS_valid_until_sh_days;
  ------------------------------
  if v_doc_dir_type in (util_stock.c_Doc_Dir_Type_In, util_stock.c_Doc_Dir_Type_InOut)
  then
    ------------------------------
    v_res := v_doc_date + v_shift;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_equipment_i(p_serial_number ct_nvarchar_s, p_iccid ct_nvarchar_s, p_date date, p_trim_empty boolean, p_uniquelize boolean) return ct_sim
is
  v_res ct_sim;
  v_trim_empty number := util_pkg.bool_to_int_2val(p_trim_empty);
  v_uniquelize boolean := util_pkg.bool_to_bool_2val(p_uniquelize);
  v_serial_number ct_nvarchar_s;
begin
  ------------------------------
  if v_uniquelize
  then
    ------------------------------
    select
      distinct serial_number
      bulk collect into v_serial_number
      from
      (
        select column_value serial_number from table(p_serial_number)
        union
        select substrc(column_value, 1, lengthc(column_value) - 1) serial_number from table(p_iccid)
      )
    ;
    ------------------------------
  else
    ------------------------------
    select
      serial_number
      bulk collect into v_serial_number
      from
      (
        select column_value serial_number, rownum rn, 1 type from table(p_serial_number)
        union all
        select substrc(column_value, 1, lengthc(column_value) - 1) serial_number, rownum rn, 2 type from table(p_iccid)
      )
      order by type, rn
    ;
    ------------------------------
  end if;
  ------------------------------
  select /*+ driving_site(w) ordered use_hash(w, em, et, est) full(em) full(et) index_ffs(est PK_EQUIPMENT_SYSTEM_TYPE)*/
    ot_sim
    (
      w.serial_number,
      ot_model
      (
        w.equipment_model_id,
        em.equipment_model_code,
        et.equipment_type_id,
        et.equipment_type_code,
        est.equipment_system_type_code,
        est.has_serial_number,
        est.allows_partitioning,
        est.is_numeric_serial_number,
        est.is_package
      )
    )
    bulk collect into v_res
    from (

  select /*+ ordered use_nl(q, s, ss) index_asc(s, AK_SIMS_SN) index_asc(ss, I_STOCK_STATE_SS)*/
    q.serial_number, q.rn, ss.equipment_model_id
    from
      (select column_value serial_number, rownum rn from table(v_serial_number)) q,
      sims s,
      stock_state ss
    where 1 = 1
    and s.serial_number(+) = q.serial_number
    and ss.seria_start(+) = s.serial_number

    ) w, equipment_model em, equipment_type et, equipment_system_type est
    where 1 = 1
    and em.equipment_model_id(+) = w.equipment_model_id
    and et.equipment_type_id(+) = em.equipment_type_id
    and est.equipment_system_type_code(+) = et.system_type_code
    and decode(p_date, null, sysdate + util_stock.c_dummy_date_shift, nvl(em.deleted(+), p_date + util_stock.c_dummy_date_shift)) > decode(p_date, null, sysdate, p_date)
    and decode(p_date, null, sysdate + util_stock.c_dummy_date_shift, nvl(et.deleted(+), p_date + util_stock.c_dummy_date_shift)) > decode(p_date, null, sysdate, p_date)
    and decode(p_date, null, sysdate + util_stock.c_dummy_date_shift, nvl(est.deleted(+), p_date + util_stock.c_dummy_date_shift)) > decode(p_date, null, sysdate, p_date)
    and decode(v_trim_empty, util_pkg.c_false, util_pkg.c_true, decode(est.equipment_system_type_code, null, util_pkg.c_false, util_pkg.c_true)) = util_pkg.c_true
    order by w.rn
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_equipment_fuzzy(p_serial_number ct_nvarchar_s, p_iccid ct_nvarchar_s, p_date date) return ct_sim
is
begin
  ------------------------------
  return get_equipment_i(p_serial_number, p_iccid, p_date, TRUE, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_equipment_exact(p_serial_number ct_nvarchar_s, p_iccid ct_nvarchar_s, p_date date) return ct_sim
is
begin
  ------------------------------
  return get_equipment_i(p_serial_number, p_iccid, p_date, FALSE, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_t_xyz_ssext(p_coll t_xyz_ssext) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure fill_t_xyz_ssext(p_coll in out nocopy t_xyz_ssext, p_val TT_XYZ_SSEXT_SER_DST%rowtype)
is
begin
  ------------------------------
  if get_count_t_xyz_ssext(p_coll) = 0
  then
    return;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    p_coll(v_i) := p_val;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure resize_t_xyz_ssext(p_coll in out nocopy t_xyz_ssext, p_size number)
is
  v_dif number;
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := t_xyz_ssext();
  end if;
  ------------------------------
  v_dif := p_size - p_coll.count;
  ------------------------------
  if v_dif > 0
  then
    p_coll.extend(v_dif);
  elsif v_dif < 0
  then
    p_coll.trim(-v_dif);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_t_xyz_ssext(p_count number, p_val TT_XYZ_SSEXT_SER_DST%rowtype) return t_xyz_ssext
is
  v_res t_xyz_ssext;
begin
  ------------------------------
  resize_t_xyz_ssext(v_res, p_count);
  fill_t_xyz_ssext(v_res, p_val);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_t_xyz_ssext_val(p_coll in out nocopy t_xyz_ssext, p_val TT_XYZ_SSEXT_SER_DST%rowtype)
is
begin
  ------------------------------
  if p_coll is null
  then
    p_coll := t_xyz_ssext();
  end if;
  ------------------------------
  p_coll.extend;
  p_coll(p_coll.last) := p_val;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_t_xyz_ssext2ct_range(p_coll t_xyz_ssext) return ct_range
is
  v_res ct_range;
  v_main_count number;
begin
  ------------------------------
  v_main_count := get_count_t_xyz_ssext(p_coll);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  v_res := util_stock.make_ct_range(v_main_count, null);
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    ------------------------------
    v_res(v_i) := util_stock.make_ot_range1
    (
      p_range_start => p_coll(v_i).inp_seria_start,
      p_range_end => p_coll(v_i).inp_seria_end,
      p_model_id => p_coll(v_i).inp_equipment_model_id,
      p_id_original => p_coll(v_i).inp_id_original,
      p_quantity => p_coll(v_i).inp_quantity,
      p_valid_until => p_coll(v_i).inp_valid_until
      --!_!NO p_equipment_type_id
    );
    ------------------------------
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function filter_t_xyz_ssext
(
    p_ssext t_xyz_ssext,
    p_id_original_black_list ct_number
) return t_xyz_ssext
is
  v_res t_xyz_ssext;
begin
  ------------------------------
  if get_count_t_xyz_ssext(p_ssext) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  if util_pkg.get_count_ct_number(p_id_original_black_list) = 0
  then
    ------------------------------
    return p_ssext;
    ------------------------------
  end if;
  ------------------------------
  delete from TT_XYZ_SSEXT_TMP;
  ------------------------------
  --!_!forall v_i in INDICES OF p_ssext --!_!not sparse, no need
  forall v_i in p_ssext.first..p_ssext.last
    insert into TT_XYZ_SSEXT_TMP
    values p_ssext(v_i)
  ;
  ------------------------------
  select
    *
    bulk collect into v_res
    from TT_XYZ_SSEXT_TMP tt
    where not exists (select /*+ hash_aj*/1 from table(cast(p_id_original_black_list as ct_number)) where column_value = tt.inp_id_original)
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_TT_SER_SRC_ranges return ct_range
is
  v_res ct_range;
begin
  ------------------------------
  select
    ot_range
    (
      val1 => seria_start,
      val2 => seria_end,
      num1 => equipment_model_id,
      num2 => NULL, --!_!NOT inp_id_original
      num3 => NULL, --!_!NOT inp_quantity
      dat1 => create_date,
      num4 => equipment_type_id
    )
  bulk collect into
    v_res
  from
    TT_XYZ_SSEXT_SER_SRC z
  where 1 = 1
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_t_sims(p_coll t_sims) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_rt_in_data(p_rec rt_in_data) return number
is
begin
  ------------------------------
  if p_rec.m_range_start is null
  then
    return 0;
  end if;
  ------------------------------
  return p_rec.m_range_start.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure add_rt_in_data(p_rec_coll in out nocopy rt_in_data, p_rec_coll_add rt_in_data)
is
begin
  ------------------------------
  if get_count_rt_in_data(p_rec_coll_add) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.add_ct_nvarchar_s(p_rec_coll.m_range_start, p_rec_coll_add.m_range_start);
  util_pkg.add_ct_nvarchar_s(p_rec_coll.m_range_end, p_rec_coll_add.m_range_end);
  util_pkg.add_ct_number(p_rec_coll.m_quantity, p_rec_coll_add.m_quantity);
  util_stock.add_ct_model(p_rec_coll.m_model, p_rec_coll_add.m_model);
  util_pkg.add_ct_date(p_rec_coll.m_valid_until, p_rec_coll_add.m_valid_until);
  util_pkg.add_ct_number(p_rec_coll.m_id_original, p_rec_coll_add.m_id_original);
  ------------------------------
  util_loc_pkg.add_save_ind_cit_number(p_rec_coll.m_error_code, p_rec_coll_add.m_error_code);
  util_loc_pkg.add_save_ind_cit_varchar(p_rec_coll.m_error_message, p_rec_coll_add.m_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_marked_rt_in_data(p_in_data rt_in_data, p_marks ct_number, p_trim_empty boolean, p_mark_value number := util_pkg.c_true) return rt_in_data
is
  v_res rt_in_data;
  v_main_count number;
  v_error_code ct_number;
  v_error_message ct_varchar;
  v_pivot ct_number;
  v_pivot2 ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_trim_empty is null, 'p_trim_empty');
  ------------------------------
  XCheck_rt_in_data(p_in_data);
  ------------------------------
  v_main_count := get_count_rt_in_data(p_in_data);
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_marks) != v_main_count, 'p_marks.count != v_main_count');
  ------------------------------
  v_pivot := util_pkg.make_pivot_or_empty(v_main_count);
  ------------------------------
  v_pivot2 := util_pkg.get_marked_ct_number(v_pivot, p_marks, p_trim_empty, p_mark_value);
  ------------------------------
  v_error_code := get_error_code_full_size2(p_in_data);
  v_error_message := get_error_message_full_size2(p_in_data);
  ------------------------------
  v_res.m_range_start := util_pkg.get_by_pos_ct_nvarchar_s(p_in_data.m_range_start, v_pivot2, FALSE);
  v_res.m_range_end := util_pkg.get_by_pos_ct_nvarchar_s(p_in_data.m_range_end, v_pivot2, FALSE);
  v_res.m_quantity := util_pkg.get_by_pos_ct_number(p_in_data.m_quantity, v_pivot2, FALSE);
  v_res.m_model := util_stock.get_by_pos_ct_model(p_in_data.m_model, v_pivot2, FALSE);
  v_res.m_valid_until := util_pkg.get_by_pos_ct_date(p_in_data.m_valid_until, v_pivot2, FALSE);
  v_res.m_id_original := util_pkg.get_by_pos_ct_number(p_in_data.m_id_original, v_pivot2, FALSE);
  ------------------------------
  v_error_code := util_pkg.get_by_pos_ct_number(v_error_code, v_pivot2, FALSE);
  v_error_message := util_pkg.get_by_pos_ct_varchar(v_error_message, v_pivot2, FALSE);
  ------------------------------
  v_res.m_error_code := util_loc_pkg.values2keys_ct_number(v_error_code, v_res.m_id_original);
  v_res.m_error_message := util_loc_pkg.values2keys_ct_varchar(v_error_message, v_res.m_id_original);
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_count_ct_sim(p_coll ct_sim) return number
is
begin
  ------------------------------
  if p_coll is null
  then
    return 0;
  end if;
  ------------------------------
  return p_coll.count;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheckP_ct_sim(p_param ct_sim, p_label varchar2 := null)
is
begin
  ------------------------------
  if not CheckP_ct_sim(p_param)
  then
    util_pkg.Raise_Miss_Param(p_label);
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function CheckP_ct_sim(p_param ct_sim) return boolean
is
begin
  ------------------------------
  if get_count_ct_sim(p_param) = 0
  then
    return false;
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ct_sim_sns(p_coll ct_sim) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  if get_count_ct_sim(p_coll) > 0
  then
    ------------------------------
    util_pkg.resize_ct_nvarchar_s(v_res, p_coll.count);
    ------------------------------
    for v_i in p_coll.first..p_coll.last
    loop
      v_res(v_i) := p_coll(v_i).serial_number;
    end loop;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_ct_sim_models(p_coll ct_sim) return ct_model
is
  v_res ct_model;
begin
  ------------------------------
  if get_count_ct_sim(p_coll) > 0
  then
    ------------------------------
    v_res := ct_model();
    v_res.extend(p_coll.count);
    ------------------------------
    for v_i in p_coll.first..p_coll.last
    loop
      v_res(v_i) := p_coll(v_i).model;
    end loop;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_in_data_ser_nser_i(p_in_data rt_in_data, p_serial boolean) return rt_in_data
is
  v_mark_value number := util_pkg.c_true;
  v_unmark_value number := util_pkg.c_false;
  v_mark ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_serial is null, 'p_serial');
  ------------------------------
  if NOT p_serial
  then
    ------------------------------
    v_mark_value := util_pkg.c_false;
    v_unmark_value := util_pkg.c_true;
    ------------------------------
  end if;
  ------------------------------
  v_mark := util_stock.mark_val_ct_model_has_serial(p_in_data.m_model, util_stock.c_YES, v_mark_value, v_unmark_value);
  ------------------------------
  return get_marked_rt_in_data(p_in_data, v_mark, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_in_data_SER(p_in_data rt_in_data) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_ser_nser_i(p_in_data, TRUE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_in_data_NSER(p_in_data rt_in_data) return rt_in_data
is
begin
  ------------------------------
  return get_in_data_ser_nser_i(p_in_data, FALSE);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_model_id_with_ignorance(p_model ct_model) return ct_number
is
begin
  ------------------------------
  if util_stock.GS_ignore_model_type
  then
    ------------------------------
    return util_pkg.make_ct_number(util_stock.get_count_ct_model(p_model), lc_any_model_id);
    ------------------------------
  end if;
  ------------------------------
  return util_stock.get_ct_model_ids(p_model);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure normalize_ranges
(
    p_range_start ct_nvarchar_s,
    p_range_end ct_nvarchar_s,
    p_type_id ct_number,
    p_o_range_start out ct_nvarchar_s,
    p_o_range_end out ct_nvarchar_s,
    p_o_type_id out ct_number
)
is
  lc_same number := 0;
  lc_new number := 1;
  v_main_count number;
begin
  ------------------------------
  util_pkg.XCheckP_FS_ct_nvarchar_s(p_range_start, 'p_range_start');
  util_pkg.XCheckP_FS_ct_nvarchar_s(p_range_end, 'p_range_end');
  util_pkg.XCheckP_FS_ct_number(p_type_id, 'p_type_id');
  ------------------------------
  v_main_count := util_pkg.get_count_ct_nvarchar_s(p_range_start);
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_range_start) != v_main_count, 'p_range_start.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_nvarchar_s(p_range_end) != v_main_count, 'p_range_end.count != v_main_count');
  util_pkg.XCheck_Cond_Invalid(util_pkg.get_count_ct_number(p_type_id) != v_main_count, 'p_type.count != v_main_count');
  ------------------------------
  select
    min(range_start) range_start,
    max(range_end) range_end,
    type_id
  bulk collect into
    p_o_range_start,
    p_o_range_end,
    p_o_type_id
    from
    (
    select
      z2.*,
      sum(is_new_range) over (order by type_id, value_len, range_start) range_number --!_! MORE magic; no "partition by"; we number ranges sequentially: 1, 2, 3,...
      from
      (
      select
        z1.*,
        decode(
          lag(n_range_end) over (partition by type_id, value_len order by range_start),
            n_range_start - 1, lc_same,
            lc_new
        ) is_new_range --!_! magic; 1 (lc_new) - for new range start, 0 (lc_same) - for range continuation
        from
        (
        select
          range_start,
          range_end,
          type_id,
          to_number(range_start) n_range_start,
          to_number(range_end) n_range_end,
          length(range_start) value_len
        from
        (
          select /*+ ordered use_hash(q1, q2, q3)*/
            q1.range_start,
            q2.range_end,
            q3.type_id
            from
              (select column_value range_start, rownum rn from table(p_range_start)) q1,
              (select column_value range_end, rownum rn from table(p_range_end)) q2,
              (select column_value type_id, rownum rn from table(p_type_id)) q3
            where 1 = 1
            and q2.rn = q1.rn
            and q3.rn = q1.rn
            order by q1.rn, q2.rn, q3.rn
        ) q
        order by
          type_id,
          value_len,
          range_start
        ) z1
      ) z2
    ) z3
  group by
    range_number,
    type_id
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_! different range1 range2 MUST be non-overlapped themselves
--!_! same range as range1 and range2 CAN be overlapped itself (MAGIC)
----------------------------------!---------------------------------------------
--!_! method is time-expensive
----------------------------------!---------------------------------------------
function make_unique_ranges
(
    p_range_with_length1 ct_range,
    p_range_with_length2 ct_range
) return ct_range
is
  v_res ct_range;
begin
  ------------------------------
  --!_!NO CHECKS - internal method
  ------------------------------
  with
  tt1 as
  (
    select
      val1 range_start,
      val2 range_end,
      num1 type_id,
      num2 value_len
      from table(p_range_with_length1)
  ),
  tt2 as
  (
    select
      val1 range_start,
      val2 range_end,
      num1 type_id,
      num2 value_len
      from table(p_range_with_length2)
  )
  select /*+ ordered use_hash(q2)*/
    ot_range
    (
      q1.range_start, --!_!val1
      q2.range_end, --!_!val2
      q1.type_id, --!_!num1
      q1.value_len, --!_!num2
      null, --!_!num3
      null, --!_!dat1
      null --!_!num4
    )
  bulk collect into
    v_res
  from
  (
    select
      type_id,
      value_len,
      range_start,
      row_number() over(partition by type_id, value_len order by range_start) rn
    from
    (
      select /*+ ordered use_hash(z2)*/
        z.type_id,
        z.value_len,
        z.range_start
      from tt1 z, tt2 z2
      where 1 = 1
        and z2.type_id(+) = z.type_id
        and z2.value_len(+) = z.value_len
        and z.range_start between z2.range_start(+) and z2.range_end(+)
        and z2.range_start(+) != z.range_start
        and z2.type_id is null
      UNION --!_! makes TOTAL distinct for query1 and query2
      select /*+ ordered use_hash(z2)*/
        z.type_id,
        z.value_len,
        z.range_start
      from tt2 z, tt1 z2
      where 1 = 1
        and z2.type_id(+) = z.type_id
        and z2.value_len(+) = z.value_len
        and z.range_start between z2.range_start(+) and z2.range_end(+)
        and z2.range_start(+) != z.range_start
        and z2.type_id is null
    )
  ) q1,
  (
    select
      type_id,
      value_len,
      range_end,
      row_number() over(partition by type_id, value_len order by range_end) rn
    from
    (
      select /*+ ordered use_hash(z2)*/
        z.type_id,
        z.value_len,
        z.range_end
      from tt1 z, tt2 z2
      where 1 = 1
        and z2.type_id(+) = z.type_id
        and z2.value_len(+) = z.value_len
        and z.range_end between z2.range_start(+) and z2.range_end(+)
        and z2.range_end(+) != z.range_end
        and z2.type_id is null
      UNION --!_! makes TOTAL distinct for query1 and query2
      select /*+ ordered use_hash(z2)*/
        z.type_id,
        z.value_len,
        z.range_end
      from tt2 z, tt1 z2
      where 1 = 1
        and z2.type_id(+) = z.type_id
        and z2.value_len(+) = z.value_len
        and z.range_end between z2.range_start(+) and z2.range_end(+)
        and z2.range_end(+) != z.range_end
        and z2.type_id is null
    )
  ) q2
  where 1 = 1
    and q1.type_id = q2.type_id
    and q1.value_len = q2.value_len
    and q1.rn = q2.rn
  order by
    q1.type_id,
    q1.value_len,
    q1.range_start,
    q2.range_end
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_unique_ranges2
(
    p_range_with_length ct_range
) return ct_range
is
begin
  ------------------------------
  return make_unique_ranges
  (
    p_range_with_length1 => p_range_with_length,
    p_range_with_length2 => p_range_with_length
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_range(p_in_data rt_in_data) return ct_range
is
begin
  ------------------------------
  return util_stock.make_ct_range2
  (
    p_val1 => p_in_data.m_range_start,
    p_val2 => p_in_data.m_range_end,
    p_num1 => util_stock.get_ct_model_ids(p_in_data.m_model)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_range_with_length(p_in_data rt_in_data) return ct_range
is
begin
  ------------------------------
  return util_stock.make_ct_range_with_length
  (
    p_val1 => p_in_data.m_range_start,
    p_val2 => p_in_data.m_range_end,
    p_num1 => util_stock.get_ct_model_ids(p_in_data.m_model)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_range_with_id_original(p_in_data rt_in_data) return ct_range
is
begin
  ------------------------------
  return util_stock.make_ct_range3
  (
    p_val1 => p_in_data.m_range_start,
    p_val2 => p_in_data.m_range_end,
    p_num1 => util_stock.get_ct_model_ids(p_in_data.m_model),
    p_num2 => p_in_data.m_id_original
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_range_with_model_ignor(p_in_data rt_in_data) return ct_range
is
begin
  ------------------------------
  return util_stock.make_ct_range2
  (
    p_val1 => p_in_data.m_range_start,
    p_val2 => p_in_data.m_range_end,
    p_num1 => get_model_id_with_ignorance(p_in_data.m_model)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_range_with_all(p_in_data rt_in_data) return ct_range
is
begin
  ------------------------------
  return util_stock.make_ct_range0
  (
    p_val1 => p_in_data.m_range_start,
    p_val2 => p_in_data.m_range_end,
    p_num1 => util_stock.get_ct_model_ids(p_in_data.m_model),
    p_num2 => p_in_data.m_id_original,
    p_num3 => p_in_data.m_quantity,
    p_dat1 => p_in_data.m_valid_until,
    p_num4 => util_stock.get_ct_model_type_ids(p_in_data.m_model)
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
--!_!left and right ranges must be 1) fully overlapped 2) overlapped only one-time
--!_!p_range(i) must be overlapped with EXACTLY ONE p_range_add(j)
function apply_ranges01
(
  p_range ct_range,
  p_range_add ct_range,
  p_ignore_num1 boolean
) return ct_range
is
  v_res ct_range;
  v_ignore_num1 number;
begin
  ------------------------------
  --!_!all checks on p_range and p_range_add must be done before this call
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ignore_num1 is null, 'p_ignore_num1');
  ------------------------------
  v_ignore_num1 := util_pkg.bool_to_int_2val(p_ignore_num1);
  ------------------------------
  select /*+ ordered use_hash(z2) full(z1) full(z2)*/
    ot_range
    (
      val1 => z1.val1,
      val2 => z1.val2,
      num1 => z1.num1,
      num2 => nvl(z1.num2, min(z2.num2)),
      num3 => nvl(z1.num3, min(z2.num3)),
      dat1 => nvl(z1.dat1, min(z2.dat1)),
      num4 => nvl(z1.num4, min(z2.num4))
    )
  bulk collect into
    v_res
  from
    table(p_range) z1,
    table(p_range_add) z2
  where 1 = 1
    and length(z1.val1) = length(z2.val1)
    --!_!and greatest(z1.val1, z2.val1) <= least(z1.val2, z2.val2) --!_!slower way
    --!_!and z1.n_val1 <= z2.n_val2 --!_!really slower way
    --!_!and z1.n_val2 >= z2.n_val1 --!_!really slower way
    and z1.val1 <= z2.val2 --!_!fastst way
    and z1.val2 >= z2.val1 --!_!fastst way
    and decode(v_ignore_num1, util_pkg.c_true, lc_any_model_id, z1.num1) = decode(v_ignore_num1, util_pkg.c_true, lc_any_model_id, z2.num1)
  group by
    z1.val1,
    z1.val2,
    z1.num1,
    z1.num2,
    z1.num3,
    z1.dat1,
    z1.num4
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_overlap_ranges1
(
    p_range1 ct_range,
    p_range2 ct_range,
    p_ignore_same_row_number boolean
) return boolean
is
  v_cnt number;
  v_ignore_same_row_number number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ignore_same_row_number is null, 'p_ignore_same_row_number');
  ------------------------------
  v_ignore_same_row_number := util_pkg.bool_to_int_2val(p_ignore_same_row_number);
  ------------------------------
  select /*+ ordered use_hash(z2) full(z1) full(z2)*/
    count(1) cnt
    into v_cnt
    from
      (select val1 range_start, val2 range_end, num1 type_id, rownum rn from table(p_range1)) z1,
      (select val1 range_start, val2 range_end, num1 type_id, rownum rn from table(p_range2)) z2
    where 1 = 1
    and decode(v_ignore_same_row_number, util_pkg.c_true, z2.rn, util_pkg.C_TRUE) != decode(v_ignore_same_row_number, util_pkg.c_true, z1.rn, util_pkg.C_FALSE)
    and length(z2.range_start) = length(z1.range_start) --!_! MUST BE for use_hash
    and z2.range_start = z1.range_start
  ;
  ------------------------------
  return (v_cnt > 0);
  ------------------------------
end;
----------------------------------!---------------------------------------------

function is_overlap_ranges2
(
    p_range1 ct_range,
    p_range2 ct_range,
    p_ignore_same_row_number boolean
) return boolean
is
  v_cnt number;
  v_ignore_same_row_number number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ignore_same_row_number is null, 'p_ignore_same_row_number');
  ------------------------------
  v_ignore_same_row_number := util_pkg.bool_to_int_2val(p_ignore_same_row_number);
  ------------------------------
  select /*+ ordered use_hash(z2) full(z1) full(z2)*/
    count(1) cnt
    into v_cnt
    from
      (select val1 range_start, val2 range_end, num1 type_id, rownum rn from table(p_range1)) z1,
      (select val1 range_start, val2 range_end, num1 type_id, rownum rn from table(p_range2)) z2
    where 1 = 1
    and z2.range_start <> z2.range_end  --!_! quantity > 1
    and decode(v_ignore_same_row_number, util_pkg.c_true, z2.rn, util_pkg.C_TRUE) != decode(v_ignore_same_row_number, util_pkg.c_true, z1.rn, util_pkg.C_FALSE)
    and length(z2.range_start) = length(z1.range_start) --!_! MUST BE for use_hash
    and z1.range_start between z2.range_start and z2.range_end
  ;
  ------------------------------
  return (v_cnt > 0);
  ------------------------------
end;
----------------------------------!---------------------------------------------

function is_overlap_ranges
(
    p_range1 ct_range,
    p_range2 ct_range,
    p_ignore_same_row_number boolean
) return boolean
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_ignore_same_row_number is null, 'p_ignore_same_row_number');
  ------------------------------
  if is_overlap_ranges1(p_range1, p_range2, p_ignore_same_row_number)
  then
    return true;
  end if;
  ------------------------------
  if is_overlap_ranges2(p_range1, p_range2, p_ignore_same_row_number)
  then
    return true;
  end if;
  ------------------------------
  if is_overlap_ranges2(p_range2, p_range1, p_ignore_same_row_number)
  then
    return true;
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_overlap_ranges
(
    p_range1 ct_range,
    p_range2 ct_range,
    p_ignore_same_row_number boolean,
    p_label varchar2
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid
  (
    is_overlap_ranges
    (
      p_range1 => p_range1,
      p_range2 => p_range2,
      p_ignore_same_row_number => p_ignore_same_row_number
    )
    , 'Overlapping ranges' || util_pkg.c_msg_delim01 || p_label
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_overlap_ranges_own
(
    p_range ct_range,
    p_label varchar2
)
is
begin
  ------------------------------
  XCheck_overlap_ranges
  (
    p_range1 => p_range,
    p_range2 => p_range,
    p_ignore_same_row_number => TRUE,
    p_label => p_label
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_invalid_ranges
(
    p_range ct_range
) return boolean
is
  v_cnt number;
begin
  ------------------------------
  select
    count(1) cnt
    into v_cnt
    from
    (
      select
        range_start,
        range_end,
        translate(range_start, '_0123456789', '_') non_digit_range_start,
        translate(range_end, '_0123456789', '_') non_digit_range_end
        from (select val1 range_start, val2 range_end, rownum rn from table(p_range)) z
    )
    where 1 = 1
    and (1 = 0
      or length(range_start) != length(range_end)
      or non_digit_range_start is not null
      or non_digit_range_end is not null
      or (1 = 1
        and non_digit_range_start is null
        and non_digit_range_end is null
        and to_number(range_start) > to_number(range_end)
      )
    )
  ;
  ------------------------------
  return (v_cnt > 0);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_invalid_ranges
(
    p_range ct_range,
    p_label varchar2
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Invalid
  (
    is_invalid_ranges
    (
      p_range => p_range
    )
    , 'Invalid ranges' || util_pkg.c_msg_delim01 || p_label
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure clear_work_tables
is
begin
  ------------------------------
  --!_!delete from TT_XYZ_SSEXT_TMP;
  ------------------------------
  delete from TT_XYZ_SSEXT_SER_SRC;
  delete from TT_XYZ_SSEXT_SER_DST;
  ------------------------------
  delete from TT_XYZ_SSEXT_NSER_SRC;
  delete from TT_XYZ_SSEXT_NSER_DST;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Error_Range2Str
(
    p_range_err ct_range,
    p_error_ranges_str out varchar2
)
is
begin
  ------------------------------
  if util_stock.get_count_ct_range(p_range_err) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  for v_i in p_range_err.first..p_range_err.last
  loop
    ------------------------------
    if util_pkg.str_length(p_error_ranges_str) <= util_pkg.c_max_error_message_length2
    then
      ------------------------------
      p_error_ranges_str := p_error_ranges_str || util_stock.Handle_Wrong_Equipment_Str(p_range_err(v_i).val1, p_range_err(v_i).val2, p_range_err(v_i).num1, '');
      ------------------------------
    end if;
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XHandle_Errors_Break
(
    p_range_err ct_range,
    p_error_code number,
    p_error_message varchar2,
    p_label varchar2
)
is
  v_error_message varchar2(30000);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_error_code is null, 'p_error_code');
  util_pkg.XCheck_Cond_Missing(p_error_message is null, 'p_error_message');
  util_pkg.XCheck_Cond_Missing(p_label is null, 'p_label');
  ------------------------------
  if util_stock.get_count_ct_range(p_range_err) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  Error_Range2Str
  (
    p_range_err => p_range_err,
    p_error_ranges_str => v_error_message
  );
  ------------------------------
  v_error_message := p_error_message || util_pkg.c_msg_delim02 || p_label || util_pkg.c_msg_delim01 || v_error_message;
  ------------------------------
  util_pkg.raise_exception(p_error_code, v_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Handle_Errors_Set_Global
(
    p_range_err ct_range,
    p_params in out nocopy t_ss_parameters,
    p_error_code number,
    p_error_message varchar2,
    p_label varchar2
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_error_code is null, 'p_error_code');
  util_pkg.XCheck_Cond_Missing(p_error_message is null, 'p_error_message');
  util_pkg.XCheck_Cond_Missing(p_label is null, 'p_label');
  ------------------------------
  if util_stock.get_count_ct_range(p_range_err) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  for v_i in p_range_err.first..p_range_err.last
  loop
    ------------------------------
    --!_!num2 means id_original
    ------------------------------
    set_error4id_original
    (
      p_params => p_params,
      p_id_original => p_range_err(v_i).num2,
      p_code => p_error_code,
      p_message => p_error_message || util_pkg.c_msg_delim02 || p_label,
      p_force => false
    );
    ------------------------------
  end loop;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Handle_Errors_Smart
(
    p_range_err ct_range,
    p_params in out nocopy t_ss_parameters,
    p_break_on_error boolean,
    p_error_code number,
    p_error_message varchar2,
    p_label varchar2
)
is
begin
  ------------------------------
  if p_break_on_error
  then
    ------------------------------
    XHandle_Errors_Break
    (
      p_range_err => p_range_err,
      p_error_code => p_error_code,
      p_error_message => p_error_message,
      p_label => p_label
    );
    ------------------------------
  else
    ------------------------------
    Handle_Errors_Set_Global
    (
      p_range_err => p_range_err,
      p_params => p_params,
      p_error_code => p_error_code,
      p_error_message => p_error_message,
      p_label => p_label
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Handle_Errors_Smart2
(
    p_range_err ct_range,
    p_params in out nocopy t_ss_parameters,
    p_error_code number,
    p_error_message varchar2,
    p_label varchar2
)
is
begin
  ------------------------------
  Handle_Errors_Smart
  (
    p_range_err => p_range_err,
    p_params => p_params,
    p_break_on_error => XGP_do_break_on_error(p_params),
    p_error_code => p_error_code,
    p_error_message => p_error_message,
    p_label => p_label
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
------------First query------------
-----------------------------------
--| new data      |  stock state  |
-----------------------------------
--|               0               |
--| seria_start-->|<--seria_start |
--|              max              |
-----------------------------------
--
----------------------------Second query------------------------------
-----------------------------------  ---------------------------------
--| new data      |  stock state  |  | new data      |  stock state  |
-----------------------------------  ---------------------------------
--|               0               |  |               0               |
--|               |<--seria_start |  |               |<--seria_start |
--| seria_start-->|               |  | seria_start-->|               |
--|               |<--seria_end   |  |   seria_end-->|               |
--|   seria_end-->|               |  |               |<--seria_end   |
--|              max              |  |              max              |
-----------------------------------  ---------------------------------
--
------------------------------Third query-----------------------------
-----------------------------------  ---------------------------------
--| new data      |  stock state  |  | new data      |  stock state  |
-----------------------------------  ---------------------------------
--|               0               |  |               0               |
--| seria_start-->|               |  | seria_start-->|               |
--|               |<--seria_start |  |               |<--seria_start |
--|               |<--seria_end   |  |   seria_end-->|               |
--|   seria_end-->|               |  |               |<--seria_end   |
--|              max              |  |              max              |
-----------------------------------  ---------------------------------

----------------------------------!---------------------------------------------
function get_overlap_stock_state1
(
    p_range ct_range,
    p_ignore_model boolean,
    p_doc_status_id number,
    p_prev_doc_header_id number,
    p_4_nl_max_row_count number
) return ct_range
is
  v_res ct_range;
  v_ignore_model number;
  v_count number;
begin
  ------------------------------
  --!_!p_range
  util_pkg.XCheck_Cond_Missing(p_ignore_model is null, 'p_ignore_model');
  util_pkg.XCheck_Cond_Missing(p_doc_status_id is null, 'p_doc_status_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_prev_doc_header_id is null, 'p_prev_doc_header_id');
  util_pkg.XCheck_Cond_Missing(p_4_nl_max_row_count is null, 'p_4_nl_max_row_count');
  ------------------------------
  v_ignore_model := util_pkg.bool_to_int_2val(p_ignore_model);
  ------------------------------
  v_count := util_stock.get_count_ct_range(p_range);
  ------------------------------
  if v_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  if v_count < p_4_nl_max_row_count
  then
    ------------------------------
    select
      ot_range
      (
        val1,
        val2,
        num1,
        num2,
        null, --!_!num3
        null, --!_!dat1
        null --!_!num4
      )
    bulk collect into
      v_res
    from
    (
      select /*+ ordered use_nl(ss) index(ss I_STOCK_STATE_SS)*/
        DISTINCT
        tt.seria_start val1,
        tt.seria_end val2,
        tt.equipment_model_id num1,
        tt.id_original num2
        from
          (
            select
              val1 seria_start,
              val2 seria_end,
              num1 equipment_model_id,
              num2 id_original,
              rownum rn
              from table(p_range)
          ) tt,
          stock_state ss
        where 1 = 1
        and ss.seria_start = tt.seria_start
        and decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, ss.equipment_model_id) = decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, tt.equipment_model_id)
        and (1 = 0
          or p_doc_status_id != util_stock.c_docstat_open
          or p_prev_doc_header_id is null
          or ss.doc_header_id != p_prev_doc_header_id
          or ss.quantity_onstock != 0
        )
    )
    ;
    ------------------------------
  else
    ------------------------------
    select
      ot_range
      (
        val1,
        val2,
        num1,
        num2,
        null, --!_!num3
        null, --!_!dat1
        null --!_!num4
      )
    bulk collect into
      v_res
    from
    (
      select /*+ ordered use_hash(ss) full(ss)*/
        DISTINCT
        tt.seria_start val1,
        tt.seria_end val2,
        tt.equipment_model_id num1,
        tt.id_original num2
        from
          (
            select
              val1 seria_start,
              val2 seria_end,
              num1 equipment_model_id,
              num2 id_original,
              rownum rn
              from table(p_range)
          ) tt,
          stock_state ss
        where 1 = 1
        and ss.seria_start = tt.seria_start
        and decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, ss.equipment_model_id) = decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, tt.equipment_model_id)
        and (1 = 0
          or p_doc_status_id != util_stock.c_docstat_open
          or p_prev_doc_header_id is null
          or ss.doc_header_id != p_prev_doc_header_id
          or ss.quantity_onstock != 0
        )
    )
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_overlap_stock_state2
(
    p_range ct_range,
    p_ignore_model boolean,
    p_doc_status_id number,
    p_prev_doc_header_id number
) return ct_range
is
  v_res ct_range;
  v_ignore_model number;
begin
  ------------------------------
  --!_!p_range
  util_pkg.XCheck_Cond_Missing(p_ignore_model is null, 'p_ignore_model');
  util_pkg.XCheck_Cond_Missing(p_doc_status_id is null, 'p_doc_status_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_prev_doc_header_id is null, 'p_prev_doc_header_id');
  ------------------------------
  v_ignore_model := util_pkg.bool_to_int_2val(p_ignore_model);
  ------------------------------
  select
    ot_range
    (
      val1,
      val2,
      num1,
      num2,
      null, --!_!num3
      null, --!_!dat1
      null --!_!num4
    )
  bulk collect into
    v_res
  from
  (
    select /*+ ordered use_hash(ss) index(ss IDX_STOCK_STATE_INS)*/
      DISTINCT
      tt.seria_start val1,
      tt.seria_end val2,
      tt.equipment_model_id num1,
      tt.id_original num2
      from
        (
          select
            val1 seria_start,
            val2 seria_end,
            num1 equipment_model_id,
            num2 id_original,
            rownum rn
            from table(p_range)
        ) tt,
        stock_state ss
      where 1 = 1
      and length(ss.seria_start) = length(tt.seria_start)
      and tt.seria_start between ss.seria_start and ss.seria_end
      and ss.is_nonsingle_series = util_stock.c_is_nonsingle_ser_true
      and decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, ss.equipment_model_id) = decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, tt.equipment_model_id)
      and (1 = 0
        or p_doc_status_id != util_stock.c_docstat_open
        or p_prev_doc_header_id is null
        or ss.doc_header_id != p_prev_doc_header_id
        or ss.quantity_onstock != 0
      )
  )
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_overlap_stock_state3
(
    p_range ct_range,
    p_ignore_model boolean,
    p_doc_status_id number,
    p_prev_doc_header_id number
) return ct_range
is
  v_res ct_range;
  v_ignore_model number;
begin
  ------------------------------
  --!_!p_range
  util_pkg.XCheck_Cond_Missing(p_ignore_model is null, 'p_ignore_model');
  util_pkg.XCheck_Cond_Missing(p_doc_status_id is null, 'p_doc_status_id');
  --!_!util_pkg.XCheck_Cond_Missing(p_prev_doc_header_id is null, 'p_prev_doc_header_id');
  ------------------------------
  v_ignore_model := util_pkg.bool_to_int_2val(p_ignore_model);
  ------------------------------
  select
    ot_range
    (
      val1,
      val2,
      num1,
      num2,
      null, --!_!num3
      null, --!_!dat1
      null --!_!num4
    )
  bulk collect into
    v_res
  from
  (
    select
      --!_!DISTINCT
      tt.seria_start val1,
      tt.seria_end val2,
      tt.equipment_model_id num1,
      tt.id_original num2
      from
        (
          select
            val1 seria_start,
            val2 seria_end,
            num1 equipment_model_id,
            num2 id_original,
            rownum rn
            from table(p_range)
        ) tt
      where 1 = 1
      and tt.seria_start != tt.seria_end --!_! i.e. quantity > 1
      and exists (
        select /*+ nl_sj index_asc(ss I_STOCK_STATE_SS)*/
          1
          from stock_state ss
          where 1 = 1
          and length(ss.seria_start) = length(tt.seria_start)
          and ss.seria_start between tt.seria_start and tt.seria_end
          and decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, ss.equipment_model_id) = decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, tt.equipment_model_id)
          and (1 = 0
            or p_doc_status_id != util_stock.c_docstat_open
            or p_prev_doc_header_id is null
            or ss.doc_header_id != p_prev_doc_header_id
            or ss.quantity_onstock != 0
          )
      )
  )
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function lock_stock_state_ser
(
    p_range ct_range,
    p_stock_id number,
    p_4_nl_max_row_count number
) return t_xyz_ssext
is
  v_res t_xyz_ssext;
  --v_ignore_model number;
  v_count number;
begin
  ------------------------------
  --!_!p_range
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  util_pkg.XCheck_Cond_Missing(p_4_nl_max_row_count is null, 'p_4_nl_max_row_count');
  ------------------------------
  --v_ignore_model := util_pkg.bool_to_int_2val(p_ignore_model);
  ------------------------------
  v_count := util_stock.get_count_ct_range(p_range);
  ------------------------------
  if v_count = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  if v_count < p_4_nl_max_row_count
  then
    ------------------------------
    select /*+ ordered use_nl(ss) index(ss I_STOCK_STATE_SS)*/
      ss.id,
      ss.stock_id,
      ss.equipment_model_id,
      ss.seria_start,
      ss.seria_end,
      ss.quantity_onstock,
      ss.quantity_reserved,
      ss.quantity_announced,
      ss.doc_header_id,
      ss.create_date,
      ss.status,
      ss.equipment_type_id,
      ss.reserved,
      ss.user_comment,
      ss.equipment_batch_id,
      ss.is_nonsingle_series,
      tt.id_original inp_id_original,
      tt.quantity inp_quantity,
      tt.valid_until inp_valid_until,
      tt.equipment_model_id inp_equipment_model_id,
      tt.seria_start inp_seria_start,
      tt.seria_end inp_seria_end
    bulk collect into v_res
    from
      (
        select
          val1 seria_start,
          val2 seria_end,
          num1 equipment_model_id,
          num2 id_original,
          num3 quantity,
          dat1 valid_until,
          rownum rn
          from table(p_range)
      ) tt,
      stock_state ss
    where 1 = 1
      and ss.seria_start(+) = tt.seria_start
      and ss.seria_end(+) = tt.seria_end
      --!_!and decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, ss.equipment_model_id(+)) = decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, tt.equipment_model_id)
      and ss.equipment_model_id(+) = tt.equipment_model_id
      and ss.stock_id(+) = p_stock_id
    for update of ss.id nowait
    ;
    ------------------------------
  else
    ------------------------------
    select /*+ ordered use_hash(ss) full(ss)*/
      ss.id,
      ss.stock_id,
      ss.equipment_model_id,
      ss.seria_start,
      ss.seria_end,
      ss.quantity_onstock,
      ss.quantity_reserved,
      ss.quantity_announced,
      ss.doc_header_id,
      ss.create_date,
      ss.status,
      ss.equipment_type_id,
      ss.reserved,
      ss.user_comment,
      ss.equipment_batch_id,
      ss.is_nonsingle_series,
      tt.id_original inp_id_original,
      tt.quantity inp_quantity,
      tt.valid_until inp_valid_until,
      tt.equipment_model_id inp_equipment_model_id,
      tt.seria_start inp_seria_start,
      tt.seria_end inp_seria_end
    bulk collect into v_res
    from
      (
        select
          val1 seria_start,
          val2 seria_end,
          num1 equipment_model_id,
          num2 id_original,
          num3 quantity,
          dat1 valid_until,
          rownum rn
          from table(p_range)
      ) tt,
      stock_state ss
    where 1 = 1
      and ss.seria_start(+) = tt.seria_start
      and ss.seria_end(+) = tt.seria_end
      --!_!and decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, ss.equipment_model_id(+)) = decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, tt.equipment_model_id)
      and ss.equipment_model_id(+) = tt.equipment_model_id
      and ss.stock_id(+) = p_stock_id
    for update of ss.id nowait
    ;
    ------------------------------
  end if;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function lock_stock_state_nser
(
    p_range ct_range,
    p_stock_id number
) return t_xyz_ssext
is
  v_res t_xyz_ssext;
begin
  ------------------------------
  --!_!p_range
  util_pkg.XCheck_Cond_Missing(p_stock_id is null, 'p_stock_id');
  ------------------------------
  if util_stock.get_count_ct_range(p_range) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select /*+ ordered use_nl(ss) index(ss I_STOCK_STATE_EQM)*/
    ss.id,
    ss.stock_id,
    ss.equipment_model_id,
    ss.seria_start,
    ss.seria_end,
    ss.quantity_onstock,
    ss.quantity_reserved,
    ss.quantity_announced,
    ss.doc_header_id,
    ss.create_date,
    ss.status,
    ss.equipment_type_id,
    ss.reserved,
    ss.user_comment,
    ss.equipment_batch_id,
    ss.is_nonsingle_series,
    tt.id_original inp_id_original,
    tt.quantity inp_quantity,
    tt.valid_until inp_valid_until,
    tt.equipment_model_id inp_equipment_model_id,
    tt.seria_start inp_seria_start,
    tt.seria_end inp_seria_end
  bulk collect into v_res
  from
    (
      select
        val1 seria_start,
        val2 seria_end,
        num1 equipment_model_id,
        num2 id_original,
        num3 quantity,
        dat1 valid_until,
        rownum rn
        from table(p_range)
    ) tt,
    stock_state ss
  where 1 = 1
    and ss.equipment_model_id(+) = tt.equipment_model_id
    and ss.stock_id(+) = p_stock_id
  for update of ss.id nowait
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function is_valid_stock_state_ser
(
    P_REC TT_XYZ_SSEXT_SER_DST%rowtype,
    p_2_side_operation boolean,
    p_work_side_src boolean, --!_! SRC or DST
    p_eq_status_initial number,
    p_doc_header_id number
) return boolean
is
  lc_shift_for_not_equal constant number := 123;
begin
  ------------------------------
  --!_!no params checks for speedup
  ------------------------------
  if (1 = 0
    or P_REC.id is null
    or (1 = 1
      and p_work_side_src
      and p_eq_status_initial != c_eq_status_not_spec
      and P_REC.status != p_eq_status_initial
    )
    or (1 = 1
      and NOT p_2_side_operation
      and P_REC.quantity_onstock != P_REC.inp_quantity --!_! Make_1S, Delay_1S
    )
    or (1 = 1
      and p_2_side_operation
      and (1 = 0
        or nvl(P_REC.doc_header_id, p_doc_header_id + lc_shift_for_not_equal) != p_doc_header_id
        or P_REC.quantity_onstock != 0
        or (1 = 1
          and p_work_side_src
          and P_REC.quantity_reserved != P_REC.inp_quantity --!_! Apply_2S, Cancel_2S
        )
        or (1 = 1
          and NOT p_work_side_src
          and P_REC.quantity_announced != P_REC.inp_quantity --!_! Apply_2S, Cancel_2S
        )
      )
    )
  )
  then
    ------------------------------
    return false;
    ------------------------------
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_new_stock_state_nser
(
    P_REC TT_XYZ_SSEXT_SER_DST%rowtype,
    p_2_side_operation boolean,
    p_work_side_src boolean --!_! SRC or DST
) return boolean
is
begin
  ------------------------------
  --!_!no params checks for speedup
  ------------------------------
  if 1 = 1
    and P_REC.id is null
    and NOT p_work_side_src
    and NOT p_2_side_operation
  then
    ------------------------------
    return true;
    ------------------------------
  end if;
  ------------------------------
  return false;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function is_valid_stock_state_nser
(
    P_REC TT_XYZ_SSEXT_SER_DST%rowtype,
    p_2_side_operation boolean,
    p_work_side_src boolean, --!_! SRC or DST
    p_eq_status_initial number
) return boolean
is
begin
  ------------------------------
  --!_!no params checks for speedup
  ------------------------------
  ------------------------------
  --!_! p_1_side_operation
  --!_! Make_1S
  --!_! quantity_onstock - inp_quantity (src)
  --!_! quantity_onstock - inp_quantity (dst)
  --!_! Delay_1S
  --!_! quantity_onstock - inp_quantity, quantity_reserved + inp_quantity (src)
  --!_! quantity_announced + inp_quantity (dst)
  ------------------------------
  --!_! quantity_onstock - MINUS; check it
  --!_! quantity_reserved, quantity_announced - only PLUS; don't check
  ------------------------------
  ------------------------------
  --!_! p_2_side_operation
  --!_! quantity_onstock + inp_quantity
  --!_! Apply_2S (dst)
  --!_! Cancel_2S (src)
  --!_! both:
  --!_! quantity_reserved - inp_quantity (src)
  --!_! quantity_announced - inp_quantity (dst)
  ------------------------------
  --!_! quantity_onstock - only PLUS; don't check
  --!_! quantity_reserved, quantity_announced - MINUS; check it
  ------------------------------
  ------------------------------
  if (1 = 0
    or P_REC.id is null
    or (1 = 1
      and p_work_side_src
      and p_eq_status_initial != c_eq_status_not_spec
      and P_REC.status != p_eq_status_initial
    )
    or (1 = 1
      and NOT p_2_side_operation
      and P_REC.quantity_onstock < P_REC.inp_quantity --!_! Make_1S, Delay_1S
    )
    or (1 = 1
      and p_2_side_operation
      and (1 = 0
        or (1 = 1
          and p_work_side_src
          and P_REC.quantity_reserved < P_REC.inp_quantity --!_! Apply_2S, Cancel_2S
        )
        or (1 = 1
          and NOT p_work_side_src
          and P_REC.quantity_announced < P_REC.inp_quantity --!_! Apply_2S, Cancel_2S
        )
      )
    )
  )
  then
    ------------------------------
    return false;
    ------------------------------
  end if;
  ------------------------------
  return true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function Get_Error_Lock_SS_SER
(
    p_ssext t_xyz_ssext,
    p_2_side_operation boolean,
    p_work_side_src boolean, --!_! SRC or DST
    p_eq_status_initial number,
    p_doc_header_id number
) return t_xyz_ssext
is
  v_res_err t_xyz_ssext;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_2_side_operation is null, 'p_2_side_operation');
  util_pkg.XCheck_Cond_Missing(p_work_side_src is null, 'p_work_side_src');
  util_pkg.XCheck_Cond_Missing(p_eq_status_initial is null, 'p_eq_status_initial');
  --!_!util_pkg.XCheck_Cond_Missing(p_doc_header_id is null, 'p_doc_header_id');
  ------------------------------
  if get_count_t_xyz_ssext(p_ssext) = 0
  then
    ------------------------------
    return v_res_err;
    ------------------------------
  end if;
  ------------------------------
  for v_i in p_ssext.first..p_ssext.last
  loop
    ------------------------------
    if is_valid_stock_state_ser
    (
      P_REC => p_ssext(v_i),
      p_2_side_operation => p_2_side_operation,
      p_work_side_src => p_work_side_src,
      p_eq_status_initial => p_eq_status_initial,
      p_doc_header_id => p_doc_header_id
    )
    then
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    add_t_xyz_ssext_val(v_res_err, p_ssext(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res_err;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function Get_Error_Lock_SS_NSER
(
    p_ssext t_xyz_ssext,
    p_2_side_operation boolean,
    p_work_side_src boolean, --!_! SRC or DST
    p_eq_status_initial number,
    p_o_ss_new out t_xyz_ssext
) return t_xyz_ssext
is
  v_res_err t_xyz_ssext;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_2_side_operation is null, 'p_2_side_operation');
  util_pkg.XCheck_Cond_Missing(p_work_side_src is null, 'p_work_side_src');
  util_pkg.XCheck_Cond_Missing(p_eq_status_initial is null, 'p_eq_status_initial');
  ------------------------------
  if get_count_t_xyz_ssext(p_ssext) = 0
  then
    ------------------------------
    return v_res_err;
    ------------------------------
  end if;
  ------------------------------
  for v_i in p_ssext.first..p_ssext.last
  loop
    ------------------------------
    if is_new_stock_state_nser
    (
      P_REC => p_ssext(v_i),
      p_2_side_operation => p_2_side_operation,
      p_work_side_src => p_work_side_src
    )
    then
      ------------------------------
      add_t_xyz_ssext_val(p_o_ss_new, p_ssext(v_i));
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    if is_valid_stock_state_nser
    (
      P_REC => p_ssext(v_i),
      p_2_side_operation => p_2_side_operation,
      p_work_side_src => p_work_side_src,
      p_eq_status_initial => p_eq_status_initial
    )
    then
      ------------------------------
      continue;
      ------------------------------
    end if;
    ------------------------------
    add_t_xyz_ssext_val(v_res_err, p_ssext(v_i));
    ------------------------------
  end loop;
  ------------------------------
  return v_res_err;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Check_SS_SER_DST_Overlap_1S(p_params in out nocopy t_ss_parameters, p_document_operation_subtype number)
is
  v_range_check ct_range;
  v_range_err ct_range;
begin
  ------------------------------
  if is_operation_4_in_data_ext(p_document_operation_subtype)
  then
    v_range_check := make_range_with_id_original(GP_in_data_ext_SER_DST(p_params));
  else
    v_range_check := make_range_with_id_original(GP_in_data_main_SER_DST(p_params));
  end if;
  ------------------------------
  v_range_err := get_overlap_stock_state1
  (
    p_range => v_range_check,
    p_ignore_model => util_stock.GS_ignore_model_type,
    p_doc_status_id => XGP_document_status(p_params),
    p_prev_doc_header_id => NLGP_prev_doc_header_id(p_params),
    p_4_nl_max_row_count => GS_max_serial_range_count
  );
  ------------------------------
  Handle_Errors_Smart2
  (
    p_range_err => v_range_err,
    p_params => p_params,
    p_error_code => util_loc_pkg.c_ora_ranges_intersection_ss,
    p_error_message => util_loc_pkg.c_msg_ranges_intersection_ss,
    p_label => 'Step 1'
  );
  ------------------------------
  v_range_err := get_overlap_stock_state2
  (
    p_range => v_range_check,
    p_ignore_model => util_stock.GS_ignore_model_type,
    p_doc_status_id => XGP_document_status(p_params),
    p_prev_doc_header_id => NLGP_prev_doc_header_id(p_params)
  );
  ------------------------------
  Handle_Errors_Smart2
  (
    p_range_err => v_range_err,
    p_params => p_params,
    p_error_code => util_loc_pkg.c_ora_ranges_intersection_ss,
    p_error_message => util_loc_pkg.c_msg_ranges_intersection_ss,
    p_label => 'Step 2'
  );
  ------------------------------
  v_range_err := get_overlap_stock_state3
  (
    p_range => v_range_check,
    p_ignore_model => util_stock.GS_ignore_model_type,
    p_doc_status_id => XGP_document_status(p_params),
    p_prev_doc_header_id => NLGP_prev_doc_header_id(p_params)
  );
  ------------------------------
  Handle_Errors_Smart2
  (
    p_range_err => v_range_err,
    p_params => p_params,
    p_error_code => util_loc_pkg.c_ora_ranges_intersection_ss,
    p_error_message => util_loc_pkg.c_msg_ranges_intersection_ss,
    p_label => 'Step 3'
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Lock_SS_Ser
(
    p_params in out nocopy t_ss_parameters,
    p_2_side_operation boolean,
    p_lock_src boolean,
    p_lock_dst boolean,
    p_document_operation_subtype number
)
is
  v_range ct_range;
  v_ssext_src t_xyz_ssext;
  v_ssext_dst t_xyz_ssext;
  v_range_err_src ct_range;
  v_range_err_dst ct_range;
  v_err_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_2_side_operation is null, 'p_2_side_operation');
  util_pkg.XCheck_Cond_Missing(p_lock_src is null, 'p_lock_src');
  util_pkg.XCheck_Cond_Missing(p_lock_dst is null, 'p_lock_dst');
  ------------------------------
  --!_!for sure
  delete from TT_XYZ_SSEXT_SER_SRC;
  delete from TT_XYZ_SSEXT_SER_DST;
  ------------------------------
  if p_lock_src
  then
    ------------------------------
    if is_operation_4_in_data_ext(p_document_operation_subtype)
    then
      v_range := make_range_with_all(GP_in_data_ext_SER_SRC(p_params));
    else
      v_range := make_range_with_all(GP_in_data_main_SER_SRC(p_params));
    end if;
    ------------------------------
    v_ssext_src := lock_stock_state_ser
    (
      p_range => v_range,
      p_stock_id => XGP_stock_id_out(p_params),
      p_4_nl_max_row_count => GS_max_serial_range_count
    );
    ------------------------------
  end if;
  ------------------------------
  if p_lock_dst
  then
    ------------------------------
    if is_operation_4_in_data_ext(p_document_operation_subtype)
    then
      v_range := make_range_with_all(GP_in_data_ext_SER_DST(p_params));
    else
      v_range := make_range_with_all(GP_in_data_main_SER_DST(p_params));
    end if;
    ------------------------------
    v_ssext_dst := lock_stock_state_ser
    (
      p_range => v_range,
      p_stock_id => XGP_stock_id_in(p_params),
      p_4_nl_max_row_count => GS_max_serial_range_count
    );
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and get_count_t_xyz_ssext(v_ssext_src) = 0
    and get_count_t_xyz_ssext(v_ssext_dst) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  v_range_err_src := cast_t_xyz_ssext2ct_range
  (
    Get_Error_Lock_SS_SER
    (
      p_ssext => v_ssext_src,
      p_2_side_operation => p_2_side_operation,
      p_work_side_src => TRUE,
      p_eq_status_initial => XGP_eq_status_initial(p_params),
      p_doc_header_id => XGP_doc_header_id(p_params)
    )
  );
  ------------------------------
  Handle_Errors_Smart2
  (
    p_range_err => v_range_err_src,
    p_params => p_params,
    p_error_code => util_pkg.c_ora_object_not_found,
    p_error_message => util_pkg.c_msg_object_not_found,
    p_label => c_label_in_data_src
  );
  ------------------------------
  v_range_err_dst := cast_t_xyz_ssext2ct_range
  (
    Get_Error_Lock_SS_SER
    (
      p_ssext => v_ssext_dst,
      p_2_side_operation => p_2_side_operation,
      p_work_side_src => FALSE,
      p_eq_status_initial => XGP_eq_status_initial(p_params),
      p_doc_header_id => XGP_doc_header_id(p_params)
    )
  );
  ------------------------------
  Handle_Errors_Smart2
  (
    p_range_err => v_range_err_dst,
    p_params => p_params,
    p_error_code => util_pkg.c_ora_object_not_found,
    p_error_message => util_pkg.c_msg_object_not_found,
    p_label => c_label_in_data_dst
  );
  ------------------------------
  if is_operation_4_in_data_ext(p_document_operation_subtype)
  then
    v_err_id := GP_err_id_only_ext_ALL(p_params);
  else
    v_err_id := GP_err_id_only_main_ALL(p_params);
  end if;
  ------------------------------
  v_ssext_src := filter_t_xyz_ssext
  (
    p_ssext => v_ssext_src,
    p_id_original_black_list => v_err_id
  );
  ------------------------------
  v_ssext_dst := filter_t_xyz_ssext
  (
    p_ssext => v_ssext_dst,
    p_id_original_black_list => v_err_id
  );
  ------------------------------
  if get_count_t_xyz_ssext(v_ssext_src) > 0
  then
    ------------------------------
    forall v_i in v_ssext_src.first..v_ssext_src.last
      insert into TT_XYZ_SSEXT_SER_SRC
      values v_ssext_src(v_i)
    ;
    ------------------------------
  end if;
  ------------------------------
  if get_count_t_xyz_ssext(v_ssext_dst) > 0
  then
    ------------------------------
    forall v_i in v_ssext_dst.first..v_ssext_dst.last
      insert into TT_XYZ_SSEXT_SER_DST
      values v_ssext_dst(v_i)
    ;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Lock_SS_NSer
(
    p_params in out nocopy t_ss_parameters,
    p_2_side_operation boolean,
    p_lock_src boolean,
    p_lock_dst boolean,
    p_document_operation_subtype number
)
is
  v_range ct_range;
  v_ssext_src t_xyz_ssext;
  v_ssext_dst t_xyz_ssext;
  v_ssext_new_src t_xyz_ssext;
  v_ssext_new_dst t_xyz_ssext;
  v_range_err_src ct_range;
  v_range_err_dst ct_range;
  v_err_id ct_number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_2_side_operation is null, 'p_2_side_operation');
  util_pkg.XCheck_Cond_Missing(p_lock_src is null, 'p_lock_src');
  util_pkg.XCheck_Cond_Missing(p_lock_dst is null, 'p_lock_dst');
  ------------------------------
  --!_!for sure
  delete from TT_XYZ_SSEXT_NSER_SRC;
  delete from TT_XYZ_SSEXT_NSER_DST;
  ------------------------------
  if p_lock_src
  then
    ------------------------------
    if is_operation_4_in_data_ext(p_document_operation_subtype)
    then
      v_range := make_range_with_all(GP_in_data_ext_NSER_SRC(p_params));
    else
      v_range := make_range_with_all(GP_in_data_main_NSER_SRC(p_params));
    end if;
    ------------------------------
    v_ssext_src := lock_stock_state_nser
    (
      p_range => v_range,
      p_stock_id => XGP_stock_id_out(p_params)
    );
    ------------------------------
  end if;
  ------------------------------
  if p_lock_dst
  then
    ------------------------------
    if is_operation_4_in_data_ext(p_document_operation_subtype)
    then
      v_range := make_range_with_all(GP_in_data_ext_NSER_DST(p_params));
    else
      v_range := make_range_with_all(GP_in_data_main_NSER_DST(p_params));
    end if;
    ------------------------------
    v_ssext_dst := lock_stock_state_nser
    (
      p_range => v_range,
      p_stock_id => XGP_stock_id_in(p_params)
    );
    ------------------------------
  end if;
  ------------------------------
  if 1 = 1
    and get_count_t_xyz_ssext(v_ssext_src) = 0
    and get_count_t_xyz_ssext(v_ssext_dst) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  v_range_err_src := cast_t_xyz_ssext2ct_range
  (
    Get_Error_Lock_SS_NSER
    (
      p_ssext => v_ssext_src,
      p_2_side_operation => p_2_side_operation,
      p_work_side_src => TRUE,
      p_eq_status_initial => XGP_eq_status_initial(p_params),
      p_o_ss_new => v_ssext_new_src
    )
  );
  ------------------------------
  Handle_Errors_Smart2
  (
    p_range_err => v_range_err_src,
    p_params => p_params,
    p_error_code => util_pkg.c_ora_object_not_found,
    p_error_message => util_pkg.c_msg_object_not_found,
    p_label => c_label_in_data_src
  );
  ------------------------------
  Smart_Insert_Absent_NSer
  (
    p_ssext_nser => v_ssext_new_src,
    p_params => p_params,
    p_2_side_operation => p_2_side_operation,
    p_work_side_src => TRUE
  );
  ------------------------------
  v_range_err_dst := cast_t_xyz_ssext2ct_range
  (
    Get_Error_Lock_SS_NSER
    (
      p_ssext => v_ssext_dst,
      p_2_side_operation => p_2_side_operation,
      p_work_side_src => FALSE,
      p_eq_status_initial => XGP_eq_status_initial(p_params),
      p_o_ss_new => v_ssext_new_dst
    )
  );
  ------------------------------
  Handle_Errors_Smart2
  (
    p_range_err => v_range_err_dst,
    p_params => p_params,
    p_error_code => util_pkg.c_ora_object_not_found,
    p_error_message => util_pkg.c_msg_object_not_found,
    p_label => c_label_in_data_dst
  );
  ------------------------------
  Smart_Insert_Absent_NSer
  (
    p_ssext_nser => v_ssext_new_dst,
    p_params => p_params,
    p_2_side_operation => p_2_side_operation,
    p_work_side_src => FALSE
  );
  ------------------------------
  if is_operation_4_in_data_ext(p_document_operation_subtype)
  then
    v_err_id := GP_err_id_only_ext_ALL(p_params);
  else
    v_err_id := GP_err_id_only_main_ALL(p_params);
  end if;
  ------------------------------
  v_ssext_src := filter_t_xyz_ssext
  (
    p_ssext => v_ssext_src,
    p_id_original_black_list => v_err_id
  );
  ------------------------------
  v_ssext_dst := filter_t_xyz_ssext
  (
    p_ssext => v_ssext_dst,
    p_id_original_black_list => v_err_id
  );
  ------------------------------
  if get_count_t_xyz_ssext(v_ssext_src) > 0
  then
    ------------------------------
    forall v_i in v_ssext_src.first..v_ssext_src.last
      insert into TT_XYZ_SSEXT_NSER_SRC
      values v_ssext_src(v_i)
    ;
    ------------------------------
  end if;
  ------------------------------
  if get_count_t_xyz_ssext(v_ssext_dst) > 0
  then
    ------------------------------
    forall v_i in v_ssext_dst.first..v_ssext_dst.last
      insert into TT_XYZ_SSEXT_NSER_DST
      values v_ssext_dst(v_i)
    ;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Smart_Insert_Absent_NSer
(
    p_ssext_nser t_xyz_ssext,
    p_params t_ss_parameters,
    p_2_side_operation boolean,
    p_work_side_src boolean
)
is
  v_sysdate date := sysdate;
  v_ssext t_xyz_ssext;
  v_main_count number;
  v_stock_id number;
  v_rec_tmplt TT_XYZ_SSEXT_SER_DST%rowtype;
  v_rec TT_XYZ_SSEXT_SER_DST%rowtype;
  v_valid_until date;
  v_eq_status_final number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_2_side_operation is null, 'p_2_side_operation');
  util_pkg.XCheck_Cond_Missing(p_work_side_src is null, 'p_work_side_src');
  ------------------------------
  v_main_count := get_count_t_xyz_ssext(p_ssext_nser);
  ------------------------------
  if v_main_count = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid
  (
    1 = 1
    and v_main_count > 0
    and (1 = 0
      or p_2_side_operation
      or p_work_side_src
    )
    , util_loc_pkg.c_msg_incompatible_data
  );
  ------------------------------
  if p_work_side_src
  then
    ------------------------------
    v_stock_id := XGP_stock_id_out(p_params); --!_!really not used
    ------------------------------
  else
    ------------------------------
    v_stock_id := XGP_stock_id_in(p_params);
    ------------------------------
  end if;
  ------------------------------
  v_ssext := make_t_xyz_ssext(v_main_count, null);
  ------------------------------
  v_valid_until := v_sysdate; --!_!what stays in wizards?
  ------------------------------
  --!_!v_eq_status_final := XGP_eq_status_final_REAL(p_params);
  v_eq_status_final := c_eq_status_active;
  ------------------------------
  for v_i in p_ssext_nser.first..p_ssext_nser.last
  loop
    ------------------------------
    v_rec_tmplt := p_ssext_nser(v_i);
    v_rec := null;
    ------------------------------
    v_rec.id := s_stock_state.nextval;
    v_rec.stock_id := v_stock_id;
    v_rec.equipment_model_id  := v_rec_tmplt.inp_equipment_model_id;
    v_rec.seria_start := v_rec_tmplt.inp_seria_start;
    v_rec.seria_end := v_rec_tmplt.inp_seria_end;
    v_rec.quantity_onstock := c_def_ss_quantity;
    v_rec.quantity_reserved := c_def_ss_quantity;
    v_rec.quantity_announced := c_def_ss_quantity;
    v_rec.doc_header_id := c_def_ss_doc_header_id;
    v_rec.create_date := v_valid_until;
    v_rec.status := v_eq_status_final;
    v_rec.equipment_type_id := util_stock.get_ot_model2(v_rec_tmplt.inp_equipment_model_id, v_sysdate).type_id; --!_!ot_model will be not null but type_id can be null
    v_rec.reserved := c_def_ss_reserved;
    v_rec.user_comment := c_def_ss_user_comment;
    v_rec.equipment_batch_id := c_def_ss_equipment_batch_id;
    v_rec.is_nonsingle_series := util_stock.c_is_nonsingle_ser_false_NULL;
    ------------------------------
    v_ssext(v_i) := v_rec;
    ------------------------------
  end loop;
  ------------------------------
  insert_stock_state(v_ssext);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure insert_stock_state(p_coll t_xyz_ssext)
is
--!_!pragma autonomous_transaction;
  v_slot_use_trg number;
  v_flag_use_trg boolean := false;
begin
  ------------------------------
  if get_count_t_xyz_ssext(p_coll) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_loc_pkg.Save_Flag_number(v_use_stock_state_trigger, v_slot_use_trg, v_flag_use_trg);
  v_use_stock_state_trigger := util_pkg.c_false;
  ------------------------------
  forall v_i in p_coll.first..p_coll.last
    insert into stock_state
    (
      id,
      stock_id,
      equipment_model_id,
      seria_start,
      seria_end,
      quantity_onstock,
      quantity_reserved,
      quantity_announced,
      doc_header_id,
      create_date,
      status,
      equipment_type_id,
      reserved,
      user_comment,
      equipment_batch_id,
      is_nonsingle_series
    )
    values
    (
      p_coll(v_i).id,
      p_coll(v_i).stock_id,
      p_coll(v_i).equipment_model_id,
      p_coll(v_i).seria_start,
      p_coll(v_i).seria_end,
      p_coll(v_i).quantity_onstock,
      p_coll(v_i).quantity_reserved,
      p_coll(v_i).quantity_announced,
      p_coll(v_i).doc_header_id,
      p_coll(v_i).create_date,
      p_coll(v_i).status,
      p_coll(v_i).equipment_type_id,
      p_coll(v_i).reserved,
      p_coll(v_i).user_comment,
      p_coll(v_i).equipment_batch_id,
      p_coll(v_i).is_nonsingle_series
    )
  ;
  ------------------------------
  --!_!commit;
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_stock_state_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
exception
when others then
  ------------------------------
  --!_!rollback;
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_stock_state_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XMatchSER_SSEXT4SS_2S(p_doc_header_id number)
is
  v_mismatch ct_range;
  v_ignore_model number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header_id is null, 'p_doc_header_id');
  ------------------------------
  --!_!v_ignore_model := util_pkg.bool_to_int_2val(util_stock.GS_ignore_model_type);
  v_ignore_model := util_pkg.bool_to_int_2val(FALSE);
  ------------------------------
  select /*+ ordered use_hash(tt) index(ss IDX_STOCKSTATE_DHI) full(tt)*/
    ot_range
    (
      nvl(tt.seria_start, ss.seria_start), --!_!val1
      nvl(tt.seria_end, ss.seria_end), --!_!val2
      nvl(tt.equipment_model_id, ss.equipment_model_id), --!_!num1
      null, --!_!num2
      null, --!_!num3
      null, --!_!dat1
      null --!_!num4
    )
  bulk collect into v_mismatch
  from
    stock_state ss
  full outer join
    (
    select /*+ full(t1)*/
      *
      from TT_XYZ_SSEXT_SER_SRC t1
    union all
    select /*+ full(t2)*/
      *
      from TT_XYZ_SSEXT_SER_DST t2
    ) tt
  on 1 = 1
    and tt.seria_start = ss.seria_start
    and tt.seria_end = ss.seria_end
    and decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, tt.equipment_model_id) = decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, ss.equipment_model_id)
  where 1 = 1
    and ss.doc_header_id = p_doc_header_id
    and (1 = 0
      or tt.seria_start is null
      or ss.seria_start is null
    )
  ;
  ------------------------------
  XHandle_Errors_Break
  (
    p_range_err => v_mismatch,
    p_error_code => util_loc_pkg.c_ora_eqipment_absent_in_ss,
    p_error_message => util_loc_pkg.c_msg_eqipment_absent_in_ss,
    p_label => 'XMatchSER_SSEXT4SS_2S'
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XMatchSER_SSEXT_SRC4DST_2S
is
  v_mismatch ct_range;
  v_ignore_model number;
begin
  ------------------------------
  --!_!v_ignore_model := util_pkg.bool_to_int_2val(util_stock.GS_ignore_model_type);
  v_ignore_model := util_pkg.bool_to_int_2val(FALSE);
  ------------------------------
  select /*+ ordered use_hash(t2) full(t1) full(t2)*/
    ot_range
    (
      nvl(t1.seria_start, t2.seria_start), --!_!val1
      nvl(t1.seria_end, t2.seria_end), --!_!val2
      nvl(t1.equipment_model_id, t2.equipment_model_id), --!_!num1
      null, --!_!num2
      null, --!_!num3
      null, --!_!dat1
      null --!_!num4
    )
  bulk collect into v_mismatch
  from
    TT_XYZ_SSEXT_SER_SRC t1
  full outer join
    TT_XYZ_SSEXT_SER_DST t2
  on 1 = 1
    and t2.seria_start = t1.seria_start
    and t2.seria_end = t1.seria_end
    and decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, t2.equipment_model_id) = decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, t1.equipment_model_id)
  where 1 = 1
    and (1 = 0
      or t1.seria_start is null
      or t2.seria_start is null
    )
  ;
  ------------------------------
  XHandle_Errors_Break
  (
    p_range_err => v_mismatch,
    p_error_code => util_loc_pkg.c_ora_incompatible_data,
    p_error_message => util_loc_pkg.c_msg_incompatible_data,
    p_label => 'XMatchSER_SSEXT_SRC4DST_2S'
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XMatchSER_SSEXT_SRC4DST_PRT_2S
is
  v_mismatch ct_range;
  v_ignore_model number;
  v_range_start_src ct_nvarchar_s;
  v_range_end_src ct_nvarchar_s;
  v_type_id_src ct_number;
  v_range_start_dst ct_nvarchar_s;
  v_range_end_dst ct_nvarchar_s;
  v_type_id_dst ct_number;
begin
  ------------------------------
  --!_!v_ignore_model := util_pkg.bool_to_int_2val(util_stock.GS_ignore_model_type);
  v_ignore_model := util_pkg.bool_to_int_2val(FALSE);
  ------------------------------
  select
    seria_start,
    seria_end,
    decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, equipment_model_id) equipment_model_id --!_!
  bulk collect into
    v_range_start_src,
    v_range_end_src,
    v_type_id_src
    from TT_XYZ_SSEXT_SER_SRC
  ;
  ------------------------------
  select
    seria_start,
    seria_end,
    decode(v_ignore_model, util_pkg.c_true, lc_any_model_id, equipment_model_id) equipment_model_id --!_!
  bulk collect into
    v_range_start_dst,
    v_range_end_dst,
    v_type_id_dst
    from TT_XYZ_SSEXT_SER_DST
  ;
  ------------------------------
  normalize_ranges
  (
    p_range_start => v_range_start_src,
    p_range_end => v_range_end_src,
    p_type_id => v_type_id_src,
    p_o_range_start => v_range_start_src,
    p_o_range_end => v_range_end_src,
    p_o_type_id => v_type_id_src
  );
  ------------------------------
  normalize_ranges
  (
    p_range_start => v_range_start_dst,
    p_range_end => v_range_end_dst,
    p_type_id => v_type_id_dst,
    p_o_range_start => v_range_start_dst,
    p_o_range_end => v_range_end_dst,
    p_o_type_id => v_type_id_dst
  );
  ------------------------------
  select /*+ ordered use_hash(t2) full(t1) full(t2)*/
    ot_range
    (
      nvl(t1.range_start, t2.range_start), --!_!val1
      nvl(t1.range_end, t2.range_end), --!_!val2
      nvl(t1.type_id, t2.type_id), --!_!num1
      null, --!_!num2
      null, --!_!num3
      null, --!_!dat1
      null --!_!num4
    )
  bulk collect into v_mismatch
  from
    (
    select /*+ ordered use_hash(q1, q2, q3)*/
      q1.range_start,
      q2.range_end,
      q3.type_id
      from
        (select column_value range_start, rownum rn from table(v_range_start_src)) q1,
        (select column_value range_end, rownum rn from table(v_range_end_src)) q2,
        (select column_value type_id, rownum rn from table(v_type_id_src)) q3
      where 1 = 1
      and q2.rn = q1.rn
      and q3.rn = q1.rn
      order by q1.rn, q2.rn, q3.rn
    ) t1
  full outer join
    (
    select /*+ ordered use_hash(q1, q2, q3)*/
      q1.range_start,
      q2.range_end,
      q3.type_id
      from
        (select column_value range_start, rownum rn from table(v_range_start_dst)) q1,
        (select column_value range_end, rownum rn from table(v_range_end_dst)) q2,
        (select column_value type_id, rownum rn from table(v_type_id_dst)) q3
      where 1 = 1
      and q2.rn = q1.rn
      and q3.rn = q1.rn
      order by q1.rn, q2.rn, q3.rn
    ) t2
  on 1 = 1
    and t2.range_start = t1.range_start
    and t2.range_end = t1.range_end
    and t2.type_id = t1.type_id --!_! already with v_ignore_model
  where 1 = 1
    and (1 = 0
      or t1.range_start is null
      or t2.range_start is null
    )
  ;
  ------------------------------
  XHandle_Errors_Break
  (
    p_range_err => v_mismatch,
    p_error_code => util_loc_pkg.c_ora_incompatible_data,
    p_error_message => util_loc_pkg.c_msg_incompatible_data,
    p_label => 'XMatchSER_SSEXT_SRC4DST_PRT_2S'
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Prep_SER_SSEXT_DST4LCKD_SRC_1S(p_params t_ss_parameters)
is
  v_stock_id number;
  v_doc_status_id number;
  v_eq_status_final number;
  v_generate_new number;
begin
  ------------------------------
  v_stock_id := XGP_stock_id_in(p_params);
  ------------------------------
  v_doc_status_id := XGP_document_status(p_params);
  ------------------------------
  if v_doc_status_id = util_stock.c_docstat_finished
  then
    ------------------------------
    v_generate_new := util_pkg.c_false;
    ------------------------------
  else
    ------------------------------
    v_generate_new := util_pkg.c_true;
    ------------------------------
  end if;
  ------------------------------
  v_eq_status_final := XGP_eq_status_final_NEUTRAL(p_params);
  ------------------------------
  insert into TT_XYZ_SSEXT_SER_DST
  (
    id,
    stock_id,
    equipment_model_id,
    seria_start,
    seria_end,
    quantity_onstock,
    quantity_reserved,
    quantity_announced,
    doc_header_id,
    create_date,
    status,
    equipment_type_id,
    reserved,
    user_comment,
    equipment_batch_id,
    is_nonsingle_series,
    --!_!
    inp_id_original,
    inp_quantity,
    inp_valid_until,
    inp_equipment_model_id,
    inp_seria_start,
    inp_seria_end
  )
  select
    decode(v_generate_new, util_pkg.c_true, s_stock_state.nextval, id) id,
    v_stock_id stock_id,
    equipment_model_id,
    seria_start,
    seria_end,
    quantity_onstock, --!_!real value appears later in Update_SS_Ser_1S (Make, Delay)
    quantity_reserved, --!_!real value appears later in Update_SS_Ser_1S (Make, Delay)
    quantity_announced, --!_!real value appears later in Update_SS_Ser_1S (Make, Delay)
    c_def_ss_doc_header_id doc_header_id, --!_!real value appears later in Update_SS_Ser_1S (Make, Delay)
    nvl(inp_valid_until, create_date) create_date, --!_!business rule
    decode(v_eq_status_final, c_eq_status_not_spec, status, v_eq_status_final) status, --!_!business rule
    equipment_type_id,
    c_def_ss_reserved reserved,
    user_comment,
    equipment_batch_id,
    is_nonsingle_series,
    --!_!
    inp_id_original,
    inp_quantity, --!_!used later in Update_SS_Ser_1S (Make, Delay)
    inp_valid_until,
    inp_equipment_model_id,
    inp_seria_start,
    inp_seria_end
  from TT_XYZ_SSEXT_SER_SRC tt
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Prep_SER_SSEXT_DST4Input_1S(p_params t_ss_parameters, p_document_operation_subtype number)
is
  v_stock_id number;
  v_range ct_range;
  v_range_with_src ct_range;
  v_eq_status_final number;
  v_valid_until_def date;
  v_doc_type_id number;
begin
  ------------------------------
  v_stock_id := XGP_stock_id_in(p_params);
  v_doc_type_id := XGP_document_type(p_params);
  ------------------------------
  if is_operation_4_in_data_ext(p_document_operation_subtype)
  then
    v_range := util_stock.filter_val_ct_range_num2(make_range_with_all(GP_in_data_ext_SER_DST(p_params)), GP_err_id_only_ext_ALL(p_params), FALSE);
  else
    v_range := util_stock.filter_val_ct_range_num2(make_range_with_all(GP_in_data_main_SER_DST(p_params)), GP_err_id_only_main_ALL(p_params), FALSE);
  end if;
  ------------------------------
  v_eq_status_final := XGP_eq_status_final_REAL(p_params);
  ------------------------------
  v_valid_until_def := get_default_eq_valid_until_i(p_params);
  ------------------------------
  if is_doc_mutating_range(v_doc_type_id)
  then
    ------------------------------
    --!_!apply initial(src) create_date/valid_until
    v_range_with_src :=
      apply_ranges01
      (
        p_range => v_range,
        p_range_add => get_TT_SER_SRC_ranges(),
        p_ignore_num1 => FALSE
      );
    ------------------------------
    v_range := v_range_with_src;
    ------------------------------
  end if;
  ------------------------------
  --!!! Make method for match SRC/DST input for c_Doc_Type_SeriaPartition and c_Doc_Type_SeriaAssembling like XMatchSER_SSEXT_SRC4DST_PRT_2S(reverse)
  --!!! If we want for c_Doc_Type_SeriaPartition take valid_until from SRC seria use method like XMatchSER_SSEXT_SRC4DST_PRT_2S(reverse)
  ------------------------------
  insert into TT_XYZ_SSEXT_SER_DST
  (
    id,
    stock_id,
    equipment_model_id,
    seria_start,
    seria_end,
    quantity_onstock,
    quantity_reserved,
    quantity_announced,
    doc_header_id,
    create_date,
    status,
    equipment_type_id,
    reserved,
    user_comment,
    equipment_batch_id,
    is_nonsingle_series,
    --!_!
    inp_id_original,
    inp_quantity,
    inp_valid_until,
    inp_equipment_model_id,
    inp_seria_start,
    inp_seria_end
  )
  select
    s_stock_state.nextval id,
    v_stock_id stock_id,
    equipment_model_id,
    seria_start,
    seria_end,
    quantity quantity_onstock, --!_!real value appears later in Update_SS_Ser_1S (Make, Delay)
    c_def_ss_quantity quantity_reserved, --!_!real value appears later in Update_SS_Ser_1S (Make, Delay)
    c_def_ss_quantity quantity_announced, --!_!real value appears later in Update_SS_Ser_1S (Make, Delay)
    c_def_ss_doc_header_id doc_header_id, --!_!real value appears later in Update_SS_Ser_1S (Make, Delay)
    nvl(valid_until, v_valid_until_def) create_date, --!_!business rule
    v_eq_status_final status,
    equipment_type_id,
    c_def_ss_reserved reserved,
    c_def_ss_user_comment user_comment,
    c_def_ss_equipment_batch_id equipment_batch_id,
    (case when seria_start != seria_end then util_stock.c_is_nonsingle_ser_true else util_stock.c_is_nonsingle_ser_false_NULL end) is_nonsingle_series,
    --!_!
    id_original inp_id_original,
    quantity inp_quantity, --!_!used later in Update_SS_Ser_1S (Make, Delay)
    valid_until inp_valid_until,
    equipment_model_id inp_equipment_model_id,
    seria_start inp_seria_start,
    seria_end inp_seria_end
  from
  (
    select
      val1 seria_start,
      val2 seria_end,
      num1 equipment_model_id,
      num2 id_original,
      num3 quantity,
      dat1 valid_until,
      num4 equipment_type_id,
      rownum rn
      from table(v_range)
  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure get_1side_locks_src
(
    p_doc_dir_type number,
    p_o_lock_src out boolean
)
is
begin
  ------------------------------
  util_stock.XCheck_doc_dir_type(p_doc_dir_type);
  ------------------------------
  case p_doc_dir_type
  when util_stock.c_Doc_Dir_Type_In
  then
    ------------------------------
    p_o_lock_src := false;
    ------------------------------
  else
    ------------------------------
    p_o_lock_src := TRUE;
    ------------------------------
  end case;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure get_2side_locks_src_dst
(
    p_doc_dir_type number,
    p_o_lock_src out boolean,
    p_o_lock_dst out boolean
)
is
begin
  ------------------------------
  util_stock.XCheck_doc_dir_type(p_doc_dir_type);
  ------------------------------
  p_o_lock_src := false;
  p_o_lock_dst := false;
  ------------------------------
  case p_doc_dir_type
  when util_stock.c_Doc_Dir_Type_Out
  then
    ------------------------------
    p_o_lock_src := TRUE;
    ------------------------------
  when util_stock.c_Doc_Dir_Type_In
  then
    ------------------------------
    p_o_lock_dst := TRUE;
    ------------------------------
  else
    ------------------------------
    p_o_lock_src := TRUE;
    p_o_lock_dst := TRUE;
    ------------------------------
  end case;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Prepare_Stock_State_1S
(
    p_params in out nocopy t_ss_parameters,
    p_document_operation_subtype number
)
is
  v_doc_dir_type number;
  v_nser_lock_src boolean;
  v_nser_lock_dst boolean;
  v_ser_lock_src boolean;
begin
  ------------------------------
  v_doc_dir_type := XGP_doc_dir_type(p_params);
  ------------------------------
  get_2side_locks_src_dst
  (
    p_doc_dir_type => v_doc_dir_type,
    p_o_lock_src => v_nser_lock_src,
    p_o_lock_dst => v_nser_lock_dst
  );
  ------------------------------
  get_1side_locks_src
  (
    p_doc_dir_type => v_doc_dir_type,
    p_o_lock_src => v_ser_lock_src
  );
  ------------------------------
  --!!! for c_Doc_Type_Inventory, c_Doc_Type_ErrorReport maybe need to get REAL new subranges for overlap check
  if util_stock.has_doc_external_data(XGP_document_type(p_params))
  then
    ------------------------------
    Check_SS_SER_DST_Overlap_1S(p_params, p_document_operation_subtype);
    ------------------------------
  end if;
  ------------------------------
  Lock_SS_NSer
  (
    p_params => p_params,
    p_2_side_operation => FALSE,
    p_lock_src => v_nser_lock_src,
    p_lock_dst => v_nser_lock_dst,
    p_document_operation_subtype => p_document_operation_subtype
  );
  ------------------------------
  Lock_SS_Ser
  (
    p_params => p_params,
    p_2_side_operation => FALSE,
    p_lock_src => v_ser_lock_src,
    p_lock_dst => FALSE,
    p_document_operation_subtype => p_document_operation_subtype
  );
  ------------------------------
  if 1 = 1
    and v_doc_dir_type = util_stock.c_Doc_Dir_Type_InOut
    and util_stock.is_doc_eq_kept_inside_ss(XGP_document_type(p_params))
  then
    ------------------------------
    Prep_SER_SSEXT_DST4LCKD_SRC_1S(p_params);
    ------------------------------
  elsif v_doc_dir_type in (util_stock.c_Doc_Dir_Type_InOut, util_stock.c_Doc_Dir_Type_In)
  then
    ------------------------------
    Prep_SER_SSEXT_DST4Input_1S(p_params, p_document_operation_subtype);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Prepare_Stock_State_2S
(
    p_params in out nocopy t_ss_parameters,
    p_input_from_doc_detail boolean,
    p_document_operation_subtype number
)
is
  v_lock_src boolean;
  v_lock_dst boolean;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_input_from_doc_detail is null, 'p_input_from_doc_detail');
  ------------------------------
  get_2side_locks_src_dst
  (
    p_doc_dir_type => XGP_doc_dir_type(p_params),
    p_o_lock_src => v_lock_src,
    p_o_lock_dst => v_lock_dst
  );
  ------------------------------
  Lock_SS_NSer
  (
    p_params => p_params,
    p_2_side_operation => TRUE,
    p_lock_src => v_lock_src,
    p_lock_dst => v_lock_dst,
    p_document_operation_subtype => p_document_operation_subtype
  );
  ------------------------------
  Lock_SS_Ser
  (
    p_params => p_params,
    p_2_side_operation => TRUE,
    p_lock_src => v_lock_src,
    p_lock_dst => v_lock_dst,
    p_document_operation_subtype => p_document_operation_subtype
  );
  ------------------------------
  if p_input_from_doc_detail
  then
    ------------------------------
    XMatchSER_SSEXT4SS_2S(XGP_doc_header_id(p_params)); --!_! actually it's only for Change_Operation_State_Int
    ------------------------------
  end if;
  ------------------------------
  if util_stock.is_doc_symmetric(XGP_document_type(p_params)) --!_! c_Doc_Type_Movement, c_Doc_Type_OpenSeries, c_Doc_Type_CloseSeries, c_Doc_Type_EquipmentValidUntil
  then
    ------------------------------
    XMatchSER_SSEXT_SRC4DST_2S;
    ------------------------------
  end if;
  ------------------------------
  if util_stock.is_doc_partitioned(XGP_document_type(p_params)) --!_! c_Doc_Type_SeriaPartition, c_Doc_Type_SeriaAssembling
  then
    ------------------------------
    XMatchSER_SSEXT_SRC4DST_PRT_2S;
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Prepare_Stock_State
(
    p_params in out nocopy t_ss_parameters,
    p_document_operation_subtype number
)
is
begin
  ------------------------------
  XCheck_Doc_Op_Subtype(p_document_operation_subtype, 'p_document_operation_subtype');
  ------------------------------
  if is_operation_1_side(p_document_operation_subtype)
  then
    ------------------------------
    Prepare_Stock_State_1S
    (
      p_params => p_params,
      p_document_operation_subtype => p_document_operation_subtype
    );
    ------------------------------
  else
    ------------------------------
    Prepare_Stock_State_2S
    (
      p_params => p_params,
      p_input_from_doc_detail => (p_document_operation_subtype = c_dost_finalize),
      p_document_operation_subtype => p_document_operation_subtype
    );
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure i_Upd_SS_Delete_SER_SRC
is
begin
  ------------------------------
  delete /*+ ordered use_nl(ss) index(ss PK_STOCK_STATE)*/
    from stock_state ss
    where 1 = 1
    and id in (select /*+ full(t)*/id from TT_XYZ_SSEXT_SER_SRC t)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Upd_SS_Delete_SER_DST
is
begin
  ------------------------------
  delete /*+ ordered use_nl(ss) index(ss PK_STOCK_STATE)*/
    from stock_state ss
    where 1 = 1
    and id in (select /*+ full(t)*/id from TT_XYZ_SSEXT_SER_DST t)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Upd_SS_Upd_Delay_SER_SRC(p_doc_header_id number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header_id is null, 'p_doc_header_id');
  ------------------------------
  update /*+ index(ss PK_STOCK_STATE)*/
    stock_state ss
  set (quantity_onstock, quantity_reserved, quantity_announced, doc_header_id, reserved) =
  (
    select /*+ index(t, I_TT_XYZ_SSEXT_SER_SRC_ID)*/
      0, inp_quantity, 0, p_doc_header_id, c_def_ss_reserved
      from TT_XYZ_SSEXT_SER_SRC t
      where 1 = 1
      and id = ss.id
  )
  where 1 = 1
  and id in (select /*+ full(t)*/id from TT_XYZ_SSEXT_SER_SRC t)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Upd_SS_Upd_Apply_SER_DST
is
begin
  ------------------------------
  update /*+ index(ss PK_STOCK_STATE)*/
    stock_state ss
  set
    doc_header_id = c_def_ss_doc_header_id,
    quantity_onstock = quantity_announced,
    quantity_reserved = 0, --!_!redundant
    quantity_announced = 0,
    reserved = c_def_ss_reserved
  where 1 = 1
  and id in (select /*+ full(t)*/id from TT_XYZ_SSEXT_SER_DST t)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Upd_SS_Upd_Cancel_SER_SRC
is
begin
  ------------------------------
  update /*+ index(ss PK_STOCK_STATE)*/
    stock_state ss
  set
    doc_header_id = c_def_ss_doc_header_id,
    quantity_onstock = quantity_reserved,
    quantity_reserved = 0,
    quantity_announced = 0, --!_!redundant
    reserved = c_def_ss_reserved
  where 1 = 1
  and id in (select /*+ full(t)*/id from TT_XYZ_SSEXT_SER_SRC t)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Upd_SS_Insert_SER_DST
(
    p_finalize boolean,
    p_doc_header_id number
)
is
  v_finalize number := util_pkg.bool_to_int_2val(p_finalize);
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_finalize is null, 'p_finalize');
  util_pkg.XCheck_Cond_Missing(NOT p_finalize AND p_doc_header_id is null, 'p_doc_header_id'); --!_!
  ------------------------------
  insert into stock_state
  (
    id,
    stock_id,
    equipment_model_id,
    seria_start,
    seria_end,
    quantity_onstock,
    quantity_reserved,
    quantity_announced,
    doc_header_id,
    create_date,
    status,
    equipment_type_id,
    reserved,
    user_comment,
    equipment_batch_id,
    is_nonsingle_series
  )
  select
    id,
    stock_id,
    equipment_model_id,
    seria_start,
    seria_end,
    decode(v_finalize, util_pkg.c_true, inp_quantity, 0) quantity_onstock,
    decode(v_finalize, util_pkg.c_true, 0, 0) quantity_reserved,
    decode(v_finalize, util_pkg.c_true, 0, inp_quantity) quantity_announced,
    decode(v_finalize, util_pkg.c_true, c_def_ss_doc_header_id, p_doc_header_id) doc_header_id,
    create_date,
    status,
    equipment_type_id,
    decode(v_finalize, util_pkg.c_true, c_def_ss_reserved, c_def_ss_reserved) reserved,
    user_comment,
    equipment_batch_id,
    is_nonsingle_series
    from TT_XYZ_SSEXT_SER_DST
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Upd_SS_Upd_Make_NSER_SRC
is
begin
  ------------------------------
  update /*+ index(ss PK_STOCK_STATE)*/
    stock_state ss
  set (quantity_onstock) =
  (
    select /*+ index(t, I_TT_XYZ_SSEXT_NSER_SRC_ID)*/
      ss.quantity_onstock - inp_quantity
      from TT_XYZ_SSEXT_NSER_SRC t
      where 1 = 1
      and id = ss.id
  )
  where 1 = 1
  and id in (select /*+ full(tt)*/id from TT_XYZ_SSEXT_NSER_SRC tt)
  ;
end;

----------------------------------!---------------------------------------------
procedure i_Upd_SS_Upd_Make_NSER_DST
is
begin
  ------------------------------
  update /*+ index(ss PK_STOCK_STATE)*/
    stock_state ss
  set (quantity_onstock) =
  (
    select /*+ index(t, I_TT_XYZ_SSEXT_NSER_DST_ID)*/
      ss.quantity_onstock + inp_quantity
      from TT_XYZ_SSEXT_NSER_DST t
      where 1 = 1
      and id = ss.id
  )
  where 1 = 1
  and id in (select /*+ full(tt)*/id from TT_XYZ_SSEXT_NSER_DST tt)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Upd_SS_Upd_Delay_NSER_SRC
is
begin
  ------------------------------
  update /*+ index(ss PK_STOCK_STATE)*/
    stock_state ss
  set (quantity_onstock, quantity_reserved) =
  (
    select /*+ index(t, I_TT_XYZ_SSEXT_NSER_SRC_ID)*/
      ss.quantity_onstock - inp_quantity, ss.quantity_reserved + inp_quantity
      from TT_XYZ_SSEXT_NSER_SRC t
      where 1 = 1
      and id = ss.id
  )
  where 1 = 1
  and id in (select /*+ full(tt)*/id from TT_XYZ_SSEXT_NSER_SRC tt)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Upd_SS_Upd_Delay_NSER_DST
is
begin
  ------------------------------
  update /*+ index(ss PK_STOCK_STATE)*/
    stock_state ss
  set (quantity_announced) =
  (
    select /*+ index(t, I_TT_XYZ_SSEXT_NSER_DST_ID)*/
      ss.quantity_announced + inp_quantity
      from TT_XYZ_SSEXT_NSER_DST t
      where 1 = 1
      and id = ss.id
  )
  where 1 = 1
  and id in (select /*+ full(tt)*/id from TT_XYZ_SSEXT_NSER_DST tt)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Upd_SS_Upd_Apply_NSER_SRC
is
begin
  ------------------------------
  update /*+ index(ss PK_STOCK_STATE)*/
    stock_state ss
  set (quantity_reserved) =
  (
    select /*+ index(t I_TT_XYZ_SSEXT_NSER_SRC_ID)*/
      ss.quantity_reserved - inp_quantity
      from TT_XYZ_SSEXT_NSER_SRC t
      where 1 = 1
      and id = ss.id
  )
  where 1 = 1
  and id in (select /*+ full(tt)*/id from TT_XYZ_SSEXT_NSER_SRC tt)
  ;
end;

----------------------------------!---------------------------------------------
procedure i_Upd_SS_Upd_Apply_NSER_DST
is
begin
  ------------------------------
  update /*+ index(ss PK_STOCK_STATE)*/
    stock_state ss
  set (quantity_onstock, quantity_announced) =
  (
    select /*+ index(t I_TT_XYZ_SSEXT_NSER_DST_ID)*/
      ss.quantity_onstock + inp_quantity, ss.quantity_announced - inp_quantity
      from TT_XYZ_SSEXT_NSER_DST t
      where 1 = 1
      and id = ss.id
  )
  where 1 = 1
  and id in (select /*+ full(tt)*/id from TT_XYZ_SSEXT_NSER_DST tt)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Upd_SS_Upd_Cancel_NSER_SRC
is
begin
  ------------------------------
  update /*+ index(ss PK_STOCK_STATE)*/
    stock_state ss
  set (quantity_onstock, quantity_reserved) =
  (
    select /*+ index(t I_TT_XYZ_SSEXT_NSER_SRC_ID)*/
      ss.quantity_onstock + inp_quantity, ss.quantity_reserved - inp_quantity
      from TT_XYZ_SSEXT_NSER_SRC t
      where 1 = 1
      and id = ss.id
  )
  where 1 = 1
  and id in (select /*+ full(tt)*/id from TT_XYZ_SSEXT_NSER_SRC tt)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure i_Upd_SS_Upd_Cancel_NSER_DST
is
begin
  ------------------------------
  update /*+ index(ss PK_STOCK_STATE)*/
    stock_state ss
  set (quantity_announced) =
  (
    select /*+ index(t I_TT_XYZ_SSEXT_NSER_DST_ID)*/
      ss.quantity_announced - inp_quantity
      from TT_XYZ_SSEXT_NSER_DST t
      where 1 = 1
      and id = ss.id
  )
  where 1 = 1
  and id in (select /*+ full(tt)*/id from TT_XYZ_SSEXT_NSER_DST tt)
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Update_SS_Ser_Make_1S
is
begin
  ------------------------------
  i_Upd_SS_Delete_SER_SRC;
  ------------------------------
  i_Upd_SS_Insert_SER_DST
  (
    p_finalize => TRUE,
    p_doc_header_id => NULL --!_! don't care for p_finalize => TRUE
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_SS_Ser_Delay_1S(p_doc_header_id number)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header_id is null, 'p_doc_header_id');
  ------------------------------
  i_Upd_SS_Upd_Delay_SER_SRC(p_doc_header_id);
  ------------------------------
  i_Upd_SS_Insert_SER_DST
  (
    p_finalize => FALSE,
    p_doc_header_id => p_doc_header_id
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_SS_Ser_Apply_2S
is
begin
  ------------------------------
  i_Upd_SS_Delete_SER_SRC;
  ------------------------------
  i_Upd_SS_Upd_Apply_SER_DST;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_SS_Ser_Cancel_2S
is
begin
  ------------------------------
  i_Upd_SS_Upd_Cancel_SER_SRC;
  ------------------------------
  i_Upd_SS_Delete_SER_DST;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_SS_NSer_Make_1S
is
begin
  ------------------------------
  i_Upd_SS_Upd_Make_NSER_SRC;
  ------------------------------
  i_Upd_SS_Upd_Make_NSER_DST;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_SS_NSer_Delay_1S
is
begin
  ------------------------------
  i_Upd_SS_Upd_Delay_NSER_SRC;
  ------------------------------
  i_Upd_SS_Upd_Delay_NSER_DST;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_SS_NSer_Apply_2S
is
begin
  ------------------------------
  i_Upd_SS_Upd_Apply_NSER_SRC;
  ------------------------------
  i_Upd_SS_Upd_Apply_NSER_DST;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_SS_NSer_Cancel_2S
is
begin
  ------------------------------
  i_Upd_SS_Upd_Cancel_NSER_SRC;
  ------------------------------
  i_Upd_SS_Upd_Cancel_NSER_DST;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Update_SS_Ser_1S(p_params t_ss_parameters)
is
  v_doc_status_id number;
begin
  ------------------------------
  v_doc_status_id := XGP_document_status(p_params);
  ------------------------------
  if v_doc_status_id = util_stock.c_docstat_finished
  then
    ------------------------------
    Update_SS_Ser_Make_1S;
    ------------------------------
  elsif v_doc_status_id = util_stock.c_docstat_open
  then
    ------------------------------
    Update_SS_Ser_Delay_1S(XGP_doc_header_id(p_params));
    ------------------------------
  else
    ------------------------------
    XRestrict_Wrong_Doc_State(v_doc_status_id);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_SS_Ser_2S(p_params t_ss_parameters)
is
  v_doc_status_id number;
begin
  ------------------------------
  v_doc_status_id := XGP_document_status(p_params);
  ------------------------------
  if v_doc_status_id = util_stock.c_docstat_finished
  then
    ------------------------------
    Update_SS_Ser_Apply_2S;
    ------------------------------
  elsif v_doc_status_id in (util_stock.c_docstat_canceled, util_stock.c_docstat_open)
  then
    ------------------------------
    Update_SS_Ser_Cancel_2S;
    ------------------------------
  else
    ------------------------------
    XRestrict_Wrong_Doc_State(v_doc_status_id);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_SS_NSer_1S(p_params t_ss_parameters)
is
  v_doc_status_id number;
begin
  ------------------------------
  v_doc_status_id := XGP_document_status(p_params);
  ------------------------------
  if v_doc_status_id = util_stock.c_docstat_finished
  then
    ------------------------------
    Update_SS_NSer_Make_1S;
    ------------------------------
  elsif v_doc_status_id = util_stock.c_docstat_open
  then
    ------------------------------
    Update_SS_NSer_Delay_1S;
    ------------------------------
  else
    ------------------------------
    XRestrict_Wrong_Doc_State(v_doc_status_id);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_SS_NSer_2S(p_params t_ss_parameters)
is
  v_doc_status_id number;
begin
  ------------------------------
  v_doc_status_id := XGP_document_status(p_params);
  ------------------------------
  if v_doc_status_id = util_stock.c_docstat_finished
  then
    ------------------------------
    Update_SS_NSer_Apply_2S;
    ------------------------------
  elsif v_doc_status_id in (util_stock.c_docstat_canceled, util_stock.c_docstat_open)
  then
    ------------------------------
    Update_SS_NSer_Cancel_2S;
    ------------------------------
  else
    ------------------------------
    XRestrict_Wrong_Doc_State(v_doc_status_id);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Update_Stock_State_1S(p_params t_ss_parameters)
is
begin
  ------------------------------
  Update_SS_Ser_1S(p_params);
  ------------------------------
  Update_SS_NSer_1S(p_params);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_Stock_State_2S(p_params t_ss_parameters)
is
begin
  ------------------------------
  Update_SS_Ser_2S(p_params);
  ------------------------------
  Update_SS_NSer_2S(p_params);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Update_Stock_State
(
    p_params in out nocopy t_ss_parameters,
    p_document_operation_subtype number
)
is
  v_slot_use_trg number;
  v_flag_use_trg boolean := false;
begin
  ------------------------------
  XCheck_Doc_Op_Subtype(p_document_operation_subtype, 'p_document_operation_subtype');
  ------------------------------
  util_loc_pkg.Save_Flag_number(v_use_stock_state_trigger, v_slot_use_trg, v_flag_use_trg);
  v_use_stock_state_trigger := util_pkg.c_false;
  ------------------------------
  if is_operation_1_side(p_document_operation_subtype)
  then
    ------------------------------
    Update_Stock_State_1S(p_params);
    ------------------------------
  else
    ------------------------------
    Update_Stock_State_2S(p_params);
    ------------------------------
  end if;
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_stock_state_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
exception
when others then
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_stock_state_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
  raise;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
--!!! Refresh_Sims
procedure Populate_Sims
(
    p_params t_ss_parameters,
    p_document_operation_subtype number
)
is
  v_gay_force boolean := false;
  v_doc_status_id number;
  v_sims t_sims;
begin
  ------------------------------
  XCheck_Doc_Op_Subtype(p_document_operation_subtype, 'p_document_operation_subtype');
  ------------------------------
  if 1 = 1
    and XGP_do_prematurely_populate(p_params)
    and (1 = 0
      or p_document_operation_subtype = c_dost_update_add
      or p_document_operation_subtype = c_dost_update_remove
      or p_document_operation_subtype = c_dost_create
    )
  then
    ------------------------------
    v_gay_force := true;
    ------------------------------
  end if;
  ------------------------------
  v_doc_status_id := XGP_document_status(p_params);
  ------------------------------
  if 1 = 1
    and v_doc_status_id != util_stock.c_docstat_finished
    and (1 = 0
      or not v_gay_force
      or v_doc_status_id != util_stock.c_docstat_open
    )
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  if NOT XGP_do_populate_sims(p_params)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  v_sims := make_sims
  (
    p_equipment_type => NLGP_eq_types4populate_sims(p_params),
    p_eq_status => XGP_eq_status_final_REAL(p_params)
  );
  ------------------------------
  insert_sims(v_sims);
  ------------------------------
  if NOT XGP_do_populate_sims_range(p_params)
  then
    return;
  end if;
  ------------------------------
  --!_!not implemented
  --!_!insert into sims
  --!_!and t.seria_start != t.seria_end
  ------------------------------
end;

----------------------------------!---------------------------------------------
function make_sims
(
    p_equipment_type ct_number,
    p_eq_status number
) return t_sims
is
  v_res t_sims;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_eq_status is null, 'p_eq_status');
  ------------------------------
  if util_pkg.get_count_ct_number(p_equipment_type) = 0
  then
    ------------------------------
    return v_res;
    ------------------------------
  end if;
  ------------------------------
  select
    s_sims.nextval id,
    serial_number,
    control_number,
    p_eq_status status,
    serial_number || control_number full_number
  bulk collect into v_res
  from
  (
    select /*+ ordered use_hash(t) use_nl(s) full(z) full(t) index_asc(s, AK_SIMS_SN)*/
      t.seria_start serial_number,
      util_loc_pkg.make_control_digit(t.seria_start) control_number
      from
        (select column_value equipment_type_id, rownum rn from table(p_equipment_type)) z,
        TT_XYZ_SSEXT_SER_DST t,
        sims s
      where 1 = 1
      and t.equipment_type_id = z.equipment_type_id
      and t.seria_start = t.seria_end
      and s.serial_number(+) = t.seria_start
      and s.serial_number is null
  )
  ;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure insert_sims(p_coll t_sims)
is
  v_slot_use_trg number;
  v_flag_use_trg boolean := false;
begin
  ------------------------------
  if get_count_t_sims(p_coll) = 0
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  util_loc_pkg.Save_Flag_number(v_use_sims_trigger, v_slot_use_trg, v_flag_use_trg);
  v_use_sims_trigger := util_pkg.c_false;
  ------------------------------
  forall v_i in p_coll.first..p_coll.last
    insert into sims
    (
      id,
      serial_number,
      control_number,
      status,
      full_number
    )
    values
    (
      p_coll(v_i).id,
      p_coll(v_i).serial_number,
      p_coll(v_i).control_number,
      p_coll(v_i).status,
      p_coll(v_i).full_number
    )
  ;
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_sims_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
exception
when others then
  ------------------------------
  util_loc_pkg.Restore_Flag_number(v_use_sims_trigger, v_slot_use_trg, v_flag_use_trg);
  ------------------------------
  util_pkg.reraise_exception;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure XCheck_Params
(
    p_params t_ss_parameters
)
is
begin
  ------------------------------
  --!_!util_loc_pkg.touch_number(XGP_eq_status_initial(p_params));
  util_loc_pkg.touch_number(XGP_eq_status_final_NEUTRAL(p_params));
  util_loc_pkg.touch_number(XGP_doc_header_id(p_params));
  util_loc_pkg.touch_number(XGP_doc_dir_type(p_params));
  util_loc_pkg.touch_boolean(XGP_is_input_set(p_params));
  util_loc_pkg.touch_boolean(XGP_do_prematurely_populate(p_params));
  ------------------------------
  util_stock.XCheck_Stocks(XGP_doc_dir_type(p_params), XGP_stock_id_out(p_params), XGP_stock_id_in(p_params));
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_business_rules
(
    p_params t_ss_parameters,
    p_document_operation_type number
)
is
  v_doc_type_id number;
begin
  ------------------------------
  ------------------------------
  XCheck_Doc_Op_Type(p_document_operation_type, 'p_document_operation_type');
  ------------------------------
  v_doc_type_id := XGP_document_type(p_params);
  ------------------------------
  ------------------------------
  if NOT is_doc_implemented(v_doc_type_id)
  then
    ------------------------------
    XRestrict_Not_Implemented('Document type' || util_pkg.c_msg_delim01 || util_pkg.number_to_char(v_doc_type_id));
    ------------------------------
  end if;
  ------------------------------
  util_pkg.XCheck_Cond_Invalid
  (
    1 = 1
    and util_stock.is_doc_src_dst(v_doc_type_id)
    and NOT XGP_do_break_on_error(p_params)
    , 'break_on_error must be TRUE for this document type'
  );
  ------------------------------
  util_pkg.XCheck_Cond_Invalid
  (
    1 = 1
    and util_stock.is_doc_initially_finalized(v_doc_type_id)
    and XGP_document_status(p_params) != util_stock.c_docstat_finished
    , 'document must be initially finalized'
  );
  ------------------------------
  util_pkg.XCheck_Cond_Invalid
  (
    1 = 1
    and util_stock.is_doc_changes_eq_status(v_doc_type_id)
    and XGP_eq_status_final_NEUTRAL(p_params) = c_eq_status_not_spec
    , 'eq_status_final must be set EXPLICITLY for this document type'
  );
  ------------------------------
  ------------------------------
  util_pkg.XCheck_Cond_Invalid
  (
    1 = 1
    and p_document_operation_type in (c_dot_update, c_dot_finalize)
    and NOT is_exists_document_orig(p_params)
    , 'document_orig must be set up'
  );
  ------------------------------
  util_pkg.XCheck_Cond_Invalid
  (
    1 = 1
    and p_document_operation_type in (c_dot_update, c_dot_finalize)
    and is_exists_document_orig(p_params)
    and NLGP_document_status_orig(p_params) != util_stock.c_docstat_open
    , 'document must be opened'
  );
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_Input_Data
(
    p_params t_ss_parameters
)
is
  v_in_data_ser_src rt_in_data;
  v_in_data_ser_dst rt_in_data;
  v_range_ig_src ct_range;
  v_range_ig_dst ct_range;
  v_range_src ct_range;
  v_range_dst ct_range;
begin
  ------------------------------
  ------------------------------
  add_rt_in_data(v_in_data_ser_src, GP_in_data_main_SER_SRC(p_params));
  add_rt_in_data(v_in_data_ser_src, GP_in_data_ext_SER_SRC(p_params));
  add_rt_in_data(v_in_data_ser_dst, GP_in_data_main_SER_DST(p_params));
  add_rt_in_data(v_in_data_ser_dst, GP_in_data_ext_SER_DST(p_params));
  ------------------------------
  v_range_ig_src := make_range_with_model_ignor(v_in_data_ser_src);
  v_range_ig_dst := make_range_with_model_ignor(v_in_data_ser_dst);
  ------------------------------
  v_range_src := make_range(v_in_data_ser_src);
  v_range_dst := make_range(v_in_data_ser_dst);
  ------------------------------
  ------------------------------
  XCheck_invalid_ranges
  (
    p_range => v_range_src,
    p_label => c_label_in_data_src
  );
  ------------------------------
  XCheck_invalid_ranges
  (
    p_range => v_range_dst,
    p_label => c_label_in_data_dst
  );
  ------------------------------
  ------------------------------
  XCheck_overlap_ranges_own
  (
    p_range => v_range_ig_src,
    p_label => c_label_in_data_src
  );
  ------------------------------
  XCheck_overlap_ranges_own
  (
    p_range => v_range_ig_dst,
    p_label => c_label_in_data_dst
  );
  ------------------------------
  ------------------------------
  if util_stock.is_doc_only_for_ser(XGP_document_type(p_params))
  then
    ------------------------------
    XRestrict_in_data_NSER(p_params);
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
  if GP_valid_until_common_nullable(p_params) is not null
  then
    ------------------------------
    XCheck_rt_in_data_Valid_Until(p_params.m_in_data_src, 'm_in_data_src');
    XCheck_rt_in_data_Valid_Until(p_params.m_in_data_dst, 'm_in_data_dst');
    XCheck_rt_in_data_Valid_Until(p_params.m_in_data_ext_src, 'm_in_data_ext_src');
    XCheck_rt_in_data_Valid_Until(p_params.m_in_data_ext_dst, 'm_in_data_ext_dst');
    ------------------------------
  end if;
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XRestrict_in_data_NSER(p_params t_ss_parameters)
is
begin
  ------------------------------
  if GP_in_data_main_count_NSER_ALL(p_params) + GP_in_data_ext_count_NSER_ALL(p_params) > 0
  then
    ------------------------------
    util_pkg.raise_exception(util_loc_pkg.c_ora_wrong_doc_details, util_loc_pkg.c_msg_wrong_doc_details);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_Document_Header
(
    p_doc_header doc_header%rowtype,
    p_doc_type_id number,
    p_stock_id_out number,
    p_stock_id_in number,
    p_doc_status number
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_doc_header.id is null, 'p_doc_header');
  util_pkg.XCheck_Cond_Missing(p_doc_type_id is null, 'p_doc_type_id');
  util_pkg.XCheck_Cond_Missing(p_stock_id_out is null, 'p_stock_id_out');
  util_pkg.XCheck_Cond_Missing(p_stock_id_in is null, 'p_stock_id_in');
  util_pkg.XCheck_Cond_Missing(p_doc_status is null, 'p_doc_status');
  ------------------------------
  util_pkg.XCheck_Cond_Invalid(p_doc_header.doc_type_id <> p_doc_type_id, 'p_doc_type_id');
  util_pkg.XCheck_Cond_Invalid(p_doc_header.stock_out_id <> p_stock_id_out, 'p_stock_id_out');
  util_pkg.XCheck_Cond_Invalid(p_doc_header.stock_in_id <> p_stock_id_in, 'p_stock_id_in');
  util_pkg.XCheck_Cond_Invalid(p_doc_header.status_id <> p_doc_status, 'p_doc_status');
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure XCheck_rt_in_data_Valid_Until
(
    p_rt_in_data rt_in_data,
    p_label varchar2
)
is
begin
  ------------------------------
  if util_pkg.get_count_ct_date(p_rt_in_data.m_valid_until) > 0
  then
    ------------------------------
    util_pkg.XCheckP_FS_ct_date(p_rt_in_data.m_valid_until, p_label);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Latch_Input_Document
(
    p_params in out nocopy t_ss_parameters,
    p_exclusive_doc_latch boolean
)
is
  v_locker doc_locker_groups%rowtype;
  v_doc_header_id number;
  v_locker_group number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_exclusive_doc_latch is null, 'p_exclusive_doc_latch');
  ------------------------------
  if NOT XGP_do_lock_document(p_params)
  then
    return;
  end if;
  ------------------------------
  v_doc_header_id := XGP_doc_header_id(p_params);
  ------------------------------
  v_locker_group := GP_doc_locker_group(p_params);
  ------------------------------
  if p_exclusive_doc_latch
  then
    ------------------------------
    v_locker := document_pkg.create_exclusive_doc_locker(v_doc_header_id, v_locker_group);
    ------------------------------
  else
    ------------------------------
    v_locker := document_pkg.create_shared_doc_locker(v_doc_header_id, v_locker_group);
    ------------------------------
  end if;
  ------------------------------
  v_locker_group := v_locker.doc_locker_group_id; --SAME v_locker_group if came as not null in call document_pkg.create_shared_doc_locker
  ------------------------------
  SP_doc_locker_group(p_params, v_locker_group);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Check_Latch_Input_Document(p_params in out nocopy t_ss_parameters)
is
  v_locker_group number;
  v_check number;
begin
  ------------------------------
  if NOT XGP_do_check_locking_document(p_params)
  then
    return;
  end if;
  ------------------------------
  v_locker_group := GP_doc_locker_group(p_params);
  ------------------------------
  if v_locker_group is null
  then
    ------------------------------
    XRestrict_Mandat_Value(util_stock.c_msg_doc_locker_group);
    ------------------------------
  end if;
  ------------------------------
  v_check := document_pkg.check_doc_locker_group(v_locker_group);
  ------------------------------
  if v_check = util_pkg.c_false
  then
    ------------------------------
    util_pkg.Raise_exception(util_loc_pkg.c_ora_doc_locker_is_broken, util_loc_pkg.c_msg_doc_locker_is_broken || util_pkg.c_msg_delim01 || v_locker_group);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Unlatch_Input_Document
(
    p_params in out nocopy t_ss_parameters,
    p_force boolean
)
is
  v_locker_group number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_force is null, 'p_force');
  ------------------------------
  if NOT p_force and NOT XGP_do_release_doc_locker(p_params)
  then
    return;
  end if;
  ------------------------------
  v_locker_group := GP_doc_locker_group(p_params);
  ------------------------------
  if v_locker_group is null
  then
    ------------------------------
    if NOT p_force
    then
      ------------------------------
      XRestrict_Mandat_Value(util_stock.c_msg_doc_locker_group);
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    document_pkg.close_group_doc_locker(v_locker_group);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Latch_Input_Data(p_params in out nocopy t_ss_parameters)
is
  v_locker locker_pkg.t_locker;
  v_locker_group number;
begin
  ------------------------------
  if NOT XGP_do_lock_equipment(p_params)
  then
    ------------------------------
    return;
    ------------------------------
  end if;
  ------------------------------
  v_locker_group := NULL;
  ------------------------------
  v_locker := locker_pkg.Lock_Data(GP_in_data4Latch_SER(p_params), v_locker_group, false, true); --!_!v_locker_group IS NULL
  v_locker_group := v_locker.locker_group_id;
  ------------------------------
  v_locker := locker_pkg.Lock_Equipment_On_Stock(GP_in_data4Latch_NSER(p_params), v_locker_group);
  v_locker_group := v_locker.locker_group_id;
  --!_!Here is SAME v_locker_group if came as not null in call locker_pkg.Lock_Equipment_On_Stock
  ------------------------------
  SP_locker_group(p_params, v_locker_group);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Check_Latch_Input_Data(p_params in out nocopy t_ss_parameters)
is
  v_locker_group number;
  v_check number;
begin
  ------------------------------
  if NOT XGP_do_check_locking_equipment(p_params)
  then
    return;
  end if;
  ------------------------------
  v_locker_group := GP_locker_group(p_params);
  ------------------------------
  if v_locker_group is null
  then
    ------------------------------
    XRestrict_Mandat_Value(util_stock.c_msg_locker_group);
    ------------------------------
  end if;
  ------------------------------
  v_check := locker_pkg.Check_Locker_Group(v_locker_group);
  ------------------------------
  if v_check = util_pkg.c_false
  then
    ------------------------------
    util_pkg.Raise_exception(util_loc_pkg.c_ora_locker_id_broken, util_loc_pkg.c_msg_locker_id_broken || util_pkg.c_msg_delim01 || v_locker_group);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Unlatch_Input_Data
(
    p_params in out nocopy t_ss_parameters,
    p_force boolean
)
is
  v_locker_group number;
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_force is null, 'p_force');
  ------------------------------
  if NOT p_force and NOT XGP_do_release_locker(p_params)
  then
    return;
  end if;
  ------------------------------
  v_locker_group := GP_locker_group(p_params);
  ------------------------------
  if v_locker_group is null
  then
    ------------------------------
    if NOT p_force
    then
      ------------------------------
      XRestrict_Mandat_Value(util_stock.c_msg_locker_group);
      ------------------------------
    end if;
    ------------------------------
  else
    ------------------------------
    locker_pkg.Release_Locker_Group(v_locker_group);
    ------------------------------
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Latch
(
    p_params in out nocopy t_ss_parameters,
    p_exclusive_doc_latch boolean
)
is
begin
  ------------------------------
  util_pkg.XCheck_Cond_Missing(p_exclusive_doc_latch is null, 'p_exclusive_doc_latch');
  ------------------------------
  Latch_Input_Document
  (
    p_params => p_params,
    p_exclusive_doc_latch => p_exclusive_doc_latch
  );
  ------------------------------
  Latch_Input_Data(p_params);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Check_Latch(p_params in out nocopy t_ss_parameters)
is
begin
  ------------------------------
  Check_Latch_Input_Document(p_params);
  ------------------------------
  Check_Latch_Input_Data(p_params);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Unlatch
(
    p_params in out nocopy t_ss_parameters,
    p_force boolean
)
is
begin
  ------------------------------
  Unlatch_Input_Document
  (
    p_params => p_params,
    p_force => p_force
  );
  ------------------------------
  Unlatch_Input_Data
  (
    p_params => p_params,
    p_force => p_force
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Release_Latch(p_params in out nocopy t_ss_parameters)
is
begin
  ------------------------------
  Check_Latch(p_params);
  ------------------------------
  Unlatch
  (
    p_params => p_params,
    p_force => FALSE
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Do_Operation_iii
(
    p_params in out nocopy t_ss_parameters,
    p_document_operation_subtype number
)
is
begin
  ------------------------------
  XCheck_Doc_Op_Subtype(p_document_operation_subtype, 'p_document_operation_subtype');
  ------------------------------
  case p_document_operation_subtype
  when c_dost_create
  then
    ------------------------------
    document_pkg.Create_Doc_From_SSEXT
    (
      p_rec => GP_doc_header(p_params)
    );
    ------------------------------
  when c_dost_update_add
  then
    ------------------------------
    document_pkg.Update_Doc_From_SSEXT
    (
      p_doc_header_id => XGP_doc_header_id(p_params),
      p_last_user_id => XGP_last_user_id(p_params),
      p_remove_eq => FALSE
    );
    ------------------------------
  when c_dost_update_remove
  then
    ------------------------------
    document_pkg.Update_Doc_From_SSEXT
    (
      p_doc_header_id => XGP_doc_header_id(p_params),
      p_last_user_id => XGP_last_user_id(p_params),
      p_remove_eq => TRUE
    );
    ------------------------------
  else --!_! c_dost_finalize
    ------------------------------
    document_pkg.Update_Doc_State
    (
      p_doc_header_id => XGP_doc_header_id(p_params),
      p_status_id => XGP_document_status(p_params),
      p_last_user_id => XGP_last_user_id(p_params),
      p_doc_date => XGP_document_date(p_params)
    );
    ------------------------------
  end case;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Do_Operation_ii
(
    p_params in out nocopy t_ss_parameters,
    p_document_operation_subtype number
)
is
begin
  ------------------------------
  XCheck_Doc_Op_Subtype(p_document_operation_subtype, 'p_document_operation_subtype');
  ------------------------------
  clear_work_tables;
  ------------------------------
  Prepare_Stock_State
  (
    p_params => p_params,
    p_document_operation_subtype => p_document_operation_subtype
  );
  ------------------------------
  Do_Operation_iii
  (
    p_params => p_params,
    p_document_operation_subtype => p_document_operation_subtype
  );
  ------------------------------
  Update_Stock_State
  (
    p_params => p_params,
    p_document_operation_subtype => p_document_operation_subtype
  );
  ------------------------------
  Populate_Sims
  (
    p_params => p_params,
    p_document_operation_subtype => p_document_operation_subtype
  );
  ------------------------------
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Do_Operation_i
(
    p_params in out nocopy t_ss_parameters,
    p_document_operation_type number,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  XCheck_Doc_Op_Type(p_document_operation_type, 'p_document_operation_type');
  ------------------------------
  XCheck_Params
  (
    p_params => p_params
  );
  ------------------------------
  XCheck_business_rules
  (
    p_params => p_params,
    p_document_operation_type => p_document_operation_type
  );
  ------------------------------
  XCheck_Input_Data
  (
    p_params => p_params
  );
  ------------------------------
  Latch
  (
    p_params => p_params,
    p_exclusive_doc_latch => (p_document_operation_type = c_dot_finalize)
  );
  ------------------------------
  if is_in_data_for_remove(p_params)
  then
    ------------------------------
    Do_Operation_ii
    (
      p_params => p_params,
      p_document_operation_subtype => c_dost_update_remove
    );
    ------------------------------
  end if;
  ------------------------------
  Do_Operation_ii
  (
    p_params => p_params,
    p_document_operation_subtype => map_dot2dost_main(p_document_operation_type)
  );
  ------------------------------
  Release_Latch(p_params);
  ------------------------------
  util_pkg.set_ok(p_error_code, p_error_message);
  ------------------------------
exception
when others then
  ------------------------------
  util_pkg.set_error(p_error_code, p_error_message);
  ------------------------------
  Unlatch
  (
    p_params => p_params,
    p_force => TRUE
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure Create_Operation_Int
(
    p_params in out nocopy t_ss_parameters,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  Do_Operation_i
  (
    p_params => p_params,
    p_document_operation_type => c_dot_create,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Set_Operation_Equipment_Int
(
    p_params in out nocopy t_ss_parameters,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  Do_Operation_i
  (
    p_params => p_params,
    p_document_operation_type => c_dot_update,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure Change_Operation_State_Int
(
    p_params in out nocopy t_ss_parameters,
    p_error_code out number,
    p_error_message out varchar2
)
is
begin
  ------------------------------
  Do_Operation_i
  (
    p_params => p_params,
    p_document_operation_type => c_dot_finalize,
    p_error_code => p_error_code,
    p_error_message => p_error_message
  );
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
