CREATE package security_management is

----------------------------------!---------------------------------------------
  c_user_profile_id_empty        constant number := 0;

  c_msg_delim                    constant varchar2(10) := util_pkg.c_msg_delim02;

  c_default_password             constant nvarchar2(30) := '9dknLI4vYMM=';

  c_ext_user_type_COMMON         constant number := 0;
  c_ext_user_type_CRM            constant number := 1;

----------------------------------!---------------------------------------------
  c_sett_user_profile_id_common  constant varchar2(100) := 'USER_PROFILE_ID_COMMON';
  c_sett_user_profile_id_crm     constant varchar2(100) := 'USER_PROFILE_ID_CRM';
  c_sett_perm_use_hash_threshold constant varchar2(100) := 'PERM_USE_HASH_THRESHOLD';

  c_def_user_profile_id_common   constant number := c_user_profile_id_empty;
  --!_!c_def_user_profile_id_crm      constant number := 2;
  c_def_perm_use_hash_threshold  constant number := 10000;

----------------------------------!---------------------------------------------
  type ctl_users is table of users%rowtype;
  type ctl_stock_group_permission is table of stock_group_permission%rowtype;
  type ctl_user_stock_time_privilege is table of user_stock_time_privilege%rowtype;

  type rt_user_info is record
  (
    user_name nvarchar2(2000),
    user_profile_id number,
    person_name nvarchar2(2000)
  );

  type ctl_user_info is table of rt_user_info;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function validate_password(p_password users.password%type) return users.password%type;

  function make_as_null_user_profile_id(p_user_profile_id users.user_profile_id%type) return users.user_profile_id%type;
  function make_as_empty_user_profile_id(p_user_profile_id users.user_profile_id%type) return users.user_profile_id%type;

----------------------------------!---------------------------------------------
  function make_any_as_null(p_value number) return number;
  function make_any_as_num(p_value number) return number;

----------------------------------!---------------------------------------------
  function get_user_names_i
  (
    p_date date,
    p_to_upper boolean,
    p_active boolean
  ) return ct_nvarchar;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function get_count_ctl_users(p_coll ctl_users) return number;

  function get_users
  (
    p_user_id users.user_id%type
  ) return ctl_users;

----------------------------------!---------------------------------------------
  function users_ins_ii
  (
    p_user_name users.user_name%type,
    p_user_profile_id users.user_profile_id%type,
    p_name users.name%type,
    p_surname users.surname%type,
    p_password users.password%type,
    p_home_stock_id users.home_stock_id%type,
    p_is_active users.is_active%type
  ) return users.user_id%type;

  procedure users_del_ii
  (
    p_user_id users.user_id%type
  );

  procedure users_upd_ii
  (
    p_user_id users.user_id%type,
    p_user_profile_id users.user_profile_id%type,
    p_name users.name%type,
    p_surname users.surname%type,
    p_password users.password%type
  );

  procedure users_upd_is_active_ii
  (
    p_user_id users.user_id%type,
    p_is_active users.is_active%type
  );

  procedure users_upd_user_profile_id_ii
  (
    p_user_id users.user_id%type,
    p_user_profile_id users.user_profile_id%type
  );

  procedure users_upd_home_stock_id_ii
  (
    p_user_id users.user_id%type,
    p_home_stock_id users.home_stock_id%type
  );

----------------------------------!---------------------------------------------
  function user_profile_ins_ii
  (
    p_name user_profile.name%type,
    p_description user_profile.description%type
  ) return user_profile.id%type;

  procedure user_profile_del_ii
  (
    p_id user_profile.id%type
  );

  procedure user_profile_upd_ii
  (
    p_id user_profile.id%type,
    p_name user_profile.name%type,
    p_description user_profile.description%type
  );

----------------------------------!---------------------------------------------
  function prog_obj_perm_ins_ii
  (
    p_user_profile_id program_object_permission.user_profile_id%type,
    p_program_object_action_id program_object_permission.program_object_action_id%type,
    p_enabled program_object_permission.enabled%type
  ) return program_object_permission.id%type;

  procedure prog_obj_perm_ins2_ii
  (
    p_user_profile_id program_object_permission.user_profile_id%type,
    p_enabled program_object_permission.enabled%type
  );

  procedure prog_obj_perm_del_ii
  (
    p_id program_object_permission.id%type
  );

  procedure prog_obj_perm_del2_ii
  (
    p_user_profile_id program_object_permission.user_profile_id%type
  );

  procedure prog_obj_perm_upd_ii
  (
    p_id program_object_permission.id%type,
    p_enabled program_object_permission.enabled%type
  );

  procedure prog_obj_perm_upd2_ii
  (
    p_user_profile_id program_object_permission.user_profile_id%type,
    p_program_object_action_id program_object_permission.program_object_action_id%type,
    p_enabled program_object_permission.enabled%type
  );

----------------------------------!---------------------------------------------
  function get_count_ctl_stock_group_perm(p_coll ctl_stock_group_permission) return number;
  procedure dbg_ctl_user_info(p_coll ctl_user_info, p_label varchar2 := null);

  function get_stock_group_permission
  (
    p_id stock_group_permission.id%type
  ) return ctl_stock_group_permission;

  function get_stock_group_permission2
  (
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type := null,
    p_stock_id stock_group_permission.stock_id%type := null
  ) return ctl_stock_group_permission;

----------------------------------!---------------------------------------------
  function stock_group_perm_ins_ii
  (
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_stock_id stock_group_permission.stock_id%type,
    p_permission_mask stock_group_permission.permission_mask%type
  ) return stock_group_permission.id%type;

  procedure stock_group_perm_del_ii
  (
    p_id stock_group_permission.id%type
  );

  procedure stock_group_perm_del2_ii
  (
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_stock_id stock_group_permission.stock_id%type
  );

  procedure stock_group_perm_del3_ii
  (
    p_user_id stock_group_permission.user_id%type
  );

  procedure stock_group_perm_del4_ii
  (
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_with_stocks boolean
  );

  procedure stock_group_perm_del4_hier_ii
  (
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_with_stocks boolean
  );

  procedure stock_group_perm_upd_ii
  (
    p_id stock_group_permission.id%type,
    p_permission_mask stock_group_permission.permission_mask%type
  );

  procedure stock_group_perm_upd2_ii
  (
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_stock_id stock_group_permission.stock_id%type,
    p_permission_mask stock_group_permission.permission_mask%type
  );

----------------------------------!---------------------------------------------
  function get_count_ctl_user_st_tm_priv(p_coll ctl_user_stock_time_privilege) return number;

  function get_user_stock_time_privilege
  (
    p_id user_stock_time_privilege.id%type
  ) return ctl_user_stock_time_privilege;

  function get_user_stock_time_privilege2
  (
    p_stock_group_permission_id user_stock_time_privilege.stock_group_permission_id%type,
    p_date date := null
  ) return ctl_user_stock_time_privilege;

----------------------------------!---------------------------------------------
  function user_stock_time_priv_ins_ii
  (
    p_stock_group_permission_id user_stock_time_privilege.stock_group_permission_id%type,
    p_start_date user_stock_time_privilege.start_date%type,
    p_end_date user_stock_time_privilege.end_date%type,
    p_description user_stock_time_privilege.description%type
  ) return user_stock_time_privilege.id%type;

  procedure user_stock_time_priv_del_ii
  (
    p_id user_stock_time_privilege.id%type
  );

  procedure user_stock_time_priv_upd_ii
  (
    p_id user_stock_time_privilege.id%type,
    --!_!p_stock_group_permission_id user_stock_time_privilege.stock_group_permission_id%type,
    p_start_date user_stock_time_privilege.start_date%type,
    p_end_date user_stock_time_privilege.end_date%type,
    p_description user_stock_time_privilege.description%type
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  function users_ins_i
  (
    p_sa_user_id users.user_id%type,
    p_user_name users.user_name%type,
    p_user_profile_id users.user_profile_id%type,
    p_name users.name%type,
    p_surname users.surname%type,
    p_password users.password%type,
    p_home_stock_id users.home_stock_id%type,
    p_is_active users.is_active%type
  ) return users.user_id%type;

  procedure users_ins2_i
  (
    p_sa_user_id users.user_id%type,
    p_user_name users.user_name%type,
    p_user_profile_id users.user_profile_id%type,
    p_name users.name%type
  );

  procedure users_del_i
  (
    p_sa_user_id users.user_id%type,
    p_user_id users.user_id%type
  );

  procedure users_upd_i
  (
    p_sa_user_id users.user_id%type,
    p_user_id users.user_id%type,
    p_user_profile_id users.user_profile_id%type,
    p_name users.name%type,
    p_surname users.surname%type,
    p_password users.password%type
  );

  procedure users_upd_is_active_i
  (
    p_sa_user_id users.user_id%type,
    p_user_id users.user_id%type,
    p_is_active users.is_active%type
  );

  procedure users_upd_user_profile_id_i
  (
    p_sa_user_id users.user_id%type,
    p_user_id users.user_id%type,
    p_user_profile_id users.user_profile_id%type
  );

  procedure users_upd_home_stock_id_i
  (
    p_sa_user_id users.user_id%type,
    p_user_id users.user_id%type,
    p_home_stock_id users.home_stock_id%type
  );

----------------------------------!---------------------------------------------
  function user_profile_ins_i
  (
    p_sa_user_id users.user_id%type,
    p_name user_profile.name%type,
    p_description user_profile.description%type
  ) return user_profile.id%type;

  procedure user_profile_del_i
  (
    p_sa_user_id users.user_id%type,
    p_id user_profile.id%type
  );

  procedure user_profile_upd_i
  (
    p_sa_user_id users.user_id%type,
    p_id user_profile.id%type,
    p_name user_profile.name%type,
    p_description user_profile.description%type
  );

----------------------------------!---------------------------------------------
  function prog_obj_perm_ins_i
  (
    p_sa_user_id users.user_id%type,
    p_user_profile_id program_object_permission.user_profile_id%type,
    p_program_object_action_id program_object_permission.program_object_action_id%type,
    p_enabled program_object_permission.enabled%type
  ) return program_object_permission.id%type;

  procedure prog_obj_perm_ins2_i
  (
    p_sa_user_id users.user_id%type,
    p_user_profile_id program_object_permission.user_profile_id%type,
    p_enabled program_object_permission.enabled%type
  );

  procedure prog_obj_perm_del_i
  (
    p_sa_user_id users.user_id%type,
    p_id program_object_permission.id%type
  );

  procedure prog_obj_perm_del2_i
  (
    p_sa_user_id users.user_id%type,
    p_user_profile_id program_object_permission.user_profile_id%type
  );

  procedure prog_obj_perm_upd_i
  (
    p_sa_user_id users.user_id%type,
    p_id program_object_permission.id%type,
    p_enabled program_object_permission.enabled%type
  );

  procedure prog_obj_perm_upd2_i
  (
    p_sa_user_id users.user_id%type,
    p_user_profile_id program_object_permission.user_profile_id%type,
    p_program_object_action_id program_object_permission.program_object_action_id%type,
    p_enabled program_object_permission.enabled%type
  );

----------------------------------!---------------------------------------------
  function stock_group_perm_ins_i
  (
    p_sa_user_id users.user_id%type,
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_stock_id stock_group_permission.stock_id%type,
    p_permission_mask stock_group_permission.permission_mask%type,
    p_del_prev boolean
  ) return stock_group_permission.id%type;

  procedure stock_group_perm_del_i
  (
    p_sa_user_id users.user_id%type,
    p_id stock_group_permission.id%type
  );

  procedure stock_group_perm_del2_i
  (
    p_sa_user_id users.user_id%type,
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_stock_id stock_group_permission.stock_id%type
  );

  procedure stock_group_perm_upd_i
  (
    p_sa_user_id users.user_id%type,
    p_id stock_group_permission.id%type,
    p_permission_mask stock_group_permission.permission_mask%type
  );

  procedure stock_group_perm_upd2_i
  (
    p_sa_user_id users.user_id%type,
    p_user_id stock_group_permission.user_id%type,
    p_stock_group_id stock_group_permission.stock_group_id%type,
    p_stock_id stock_group_permission.stock_id%type,
    p_permission_mask stock_group_permission.permission_mask%type
  );

  procedure stock_group_perm_copy_i
  (
    p_sa_user_id users.user_id%type,
    p_user_id_from stock_group_permission.user_id%type,
    p_user_id_to stock_group_permission.user_id%type
  );

----------------------------------!---------------------------------------------
  function user_stock_time_priv_ins_i
  (
    p_sa_user_id users.user_id%type,
    p_stock_group_permission_id user_stock_time_privilege.stock_group_permission_id%type,
    p_start_date user_stock_time_privilege.start_date%type,
    p_end_date user_stock_time_privilege.end_date%type,
    p_description user_stock_time_privilege.description%type
  ) return user_stock_time_privilege.id%type;

  procedure user_stock_time_priv_del_i
  (
    p_sa_user_id users.user_id%type,
    p_id user_stock_time_privilege.id%type
  );

  procedure user_stock_time_priv_upd_i
  (
    p_sa_user_id users.user_id%type,
    p_id user_stock_time_privilege.id%type,
    --!_!p_stock_group_permission_id user_stock_time_privilege.stock_group_permission_id%type,
    p_start_date user_stock_time_privilege.start_date%type,
    p_end_date user_stock_time_privilege.end_date%type,
    p_description user_stock_time_privilege.description%type
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure users__get
  (
    p_user_name nvarchar2,
    p_active number,
    p_users_rec out sys_refcursor,
    p_error_code out number
  );

  procedure users__get_2
  (
    p_user_name nvarchar2,
    p_active number,
    p_users_rec out sys_refcursor,
    p_error_code out number
  );

  procedure users__get
  (
    p_user_name nvarchar2,
    p_users_rec out sys_refcursor,
    p_error_code out number
  );

  procedure users__get_1
  (
    p_user_name nvarchar2,
    p_users_rec out sys_refcursor,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  procedure users__ins
  (
    p_sa nvarchar2,
    p_user_name nvarchar2,
    p_user_profile_id number,
    p_name nvarchar2,
    p_surname nvarchar2,
    p_password nvarchar2,
    p_active number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure users__del
  (
    p_sa nvarchar2,
    p_user_name nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure users__upd
  (
    p_sa nvarchar2,
    p_user_name nvarchar2,
    p_user_profile_id number,
    p_name nvarchar2,
    p_surname nvarchar2,
    p_password nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure users__upd_active
  (
    p_sa nvarchar2,
    p_user_name nvarchar2,
    p_active number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure users__upd_profile
  (
    p_sa nvarchar2,
    p_user_name nvarchar2,
    p_user_profile_id number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure users__upd_homestock
  (
    p_sa nvarchar2,
    p_user_name nvarchar2,
    p_home_stock_id number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  procedure user_profile__get
  (
    p_id number,
    p_user_profile_rec out sys_refcursor,
    p_error_code out number
  );

  procedure users_profile_members_get
  (
    p_user_profile number,
    p_active number,
    p_users_rec out sys_refcursor,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  procedure user_profile__ins
  (
    p_sa nvarchar2,
    p_id out number,
    p_name nvarchar2,
    p_description nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure user_profile__del
  (
    p_sa nvarchar2,
    p_id number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure user_profile__upd
  (
    p_sa nvarchar2,
    p_id number,
    p_name nvarchar2,
    p_description nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  function get_program_object_ids
  (
    p_id number,
    p_group_id number
  ) return ct_number;

  procedure prog_obj__get
  (
    p_id number,
    p_group_id number,
    p_program_object_rec out sys_refcursor,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  function get_program_object_action_ids
  (
    p_id number,
    p_program_object_id number,
    p_action_id number
  ) return ct_number;

  procedure user_permission__get
  (
    p_user_profile number,
    p_program_object_id number,
    p_action_id number,
    p_object_permission_rec out sys_refcursor,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  procedure prog_obj_perm__ins
  (
    p_sa nvarchar2,
    p_user_profile number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure prog_obj_perm__del
  (
    p_sa nvarchar2,
    p_user_profile number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure prog_obj_perm__upd
  (
    p_sa nvarchar2,
    p_user_profile number,
    p_prog_obj_action_id number,
    p_enabled number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  function get_stock_group_permission_ids
  (
    p_id number,
    p_stock_id number,
    p_stock_group_id number,
    p_user_id stock_group_permission.user_id%type
  ) return ct_number;

  procedure stock_group_perm__get
  (
    p_user_id nvarchar2, --!_!
    p_stock_group_id number,
    p_stock_id number,
    p_stock_permission_rec out sys_refcursor,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  procedure stock_group_perm__ins
  (
    p_sa nvarchar2,
    p_user_id nvarchar2,
    p_stock_group_id number,
    p_stock_id number,
    p_permission_mask number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure stock_group_perm__del
  (
    p_sa nvarchar2,
    p_user_id nvarchar2,
    p_stock_group_id number,
    p_stock_id number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure stock_group_perm__upd
  (
    p_sa nvarchar2,
    p_user_id nvarchar2,
    p_stock_group_id number,
    p_stock_id number,
    p_permission_mask number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure users__copy_privileges
  (
    p_sa nvarchar2,
    p_user_name_from nvarchar2,
    p_user_name_to nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  procedure stock_group_dperm__get
  (
    p_user_id nvarchar2, --!_!
    p_stock_group_id number,
    p_stock_id number,
    p_stock_date_permission_rec out sys_refcursor,
    p_error_code out number
  );

  procedure stock_group_dperm__get2
  (
    p_user_id nvarchar2, --!_!
    p_stock_group_id number,
    p_stock_id number,
    p_stock_date_permission_rec out sys_refcursor,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  procedure stock_group_dperm__ins
  (
    p_sa nvarchar2,
    p_stock_group_permission_id number,
    p_start_date date,
    p_end_date date,
    p_description nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure stock_group_dperm__del
  (
    p_sa nvarchar2,
    p_id number,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

  procedure stock_group_dperm__upd
  (
    p_sa nvarchar2,
    p_id number,
    p_start_date date,
    p_end_date date,
    p_description nvarchar2,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure user_stocks__stockowners
  (
    p_user_id nvarchar2,
    p_stock_owners_rec out sys_refcursor,
    p_error_code out number
  );

  procedure user_stocks__get
  (
    p_user_id nvarchar2,
    p_permission_mask number,
    p_user_stocks_rec out sys_refcursor,
    p_error_code out number
  );

  procedure get_readable_stocks
  (
    p_user_id nvarchar2,
    p_readable_stocks_rec out sys_refcursor,
    p_error_code out number
  );

  procedure get_stock_permissions_for_user
  (
    p_stock_code util_pkg.cit_nvarchar_s,
    p_user_name varchar2,
    p_user_permis_stock_info out sys_refcursor,
    p_error_message out varchar2,
    p_error_code out number
  );

----------------------------------!---------------------------------------------
  procedure user_update_profile_i
  (
    p_user_id number,
    p_user_profile_id number,
    p_sa_user_id number
  );

  procedure users_insert_i
  (
    p_execute_user_id number,
    p_user_name nvarchar2,
    p_user_profile_id number,
    p_name nvarchar2
  );

  procedure users_update_i
  (
    p_execute_user_id number,
    p_user_id number,
    p_user_profile_id number,
    p_name nvarchar2
  );

  procedure users_update_is_active_i
  (
    p_execute_user_id number,
    p_user_id number,
    p_is_active number
  );

----------------------------------!---------------------------------------------
  function get_user_profile_id_common return number;
  function xget_user_profile_id_crm return number;

----------------------------------!---------------------------------------------
  function get_count_ctl_user_info(p_coll ctl_user_info) return number;

  function get_user
  (
    p_user_id number
  ) return ctl_users;

  function get_ctl_user_info(p_pivot_filter ct_number, p_map1 ct_number, p_map2 ct_number, p_user_types ct_number, p_user_names ct_nvarchar, p_person_names ct_nvarchar) return ctl_user_info;

  procedure filter_users(p_filter_type number, p_types ct_number, p_vals ct_nvarchar, p_pivot out ct_number, p_vals_out out ct_nvarchar);

  function get_utypes_i return ct_number;

  function get_profile_ids_i return ct_number;

  procedure prepare_users_i
  (
    p_user_types ct_number,
    p_user_names ct_nvarchar,
    p_map1 out ct_number,
    p_map2 out ct_number,
    p_unames_uni_other out ct_nvarchar,
    p_pivot_other out ct_number
  );
----------------------------------!---------------------------------------------
  procedure synchronize_users_i
  (
    p_execute_user_id users.user_id%type,
    p_user_types ct_number,
    p_user_names ct_nvarchar,
    p_person_names ct_nvarchar,
    p_new_users_pivot out ct_number,
    p_upd_users_pivot out ct_number,
    p_multiple_err_users_pivot out ct_number
  );

  procedure synchronize_stock_users
  (
    p_sa nvarchar2,
    p_user_types util_pkg.cit_number,
    p_user_names util_pkg.cit_nvarchar,
    p_person_names util_pkg.cit_nvarchar,
    p_handle_tran char := util_stock.c_tran_yes,
    p_error_code out number,
    p_error_message out varchar2
  );

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
  procedure get_result_cursor001(p_sgp_ids ct_number, p_date date, p_result out sys_refcursor);
  procedure get_result_cursor002(p_sgp_ids ct_number, p_date date, p_result out sys_refcursor);
  procedure get_result_cursor003(p_sgp_ids ct_number, p_date date, p_result out sys_refcursor);
  procedure get_result_cursor004(p_sgp_ids ct_number, p_date date, p_result out sys_refcursor);

  procedure get_result_cursor005(p_po_ids ct_number, p_result out sys_refcursor);
  procedure get_result_cursor006(p_poa_ids ct_number, p_user_profile_id number, p_result out sys_refcursor);
  procedure get_result_cursor007(p_poa_ids ct_number, p_result out sys_refcursor);

  procedure get_result_cursor008(p_user_id number, p_date date, p_is_active boolean, p_result out sys_refcursor);
  procedure get_result_cursor009(p_date date, p_is_active boolean, p_result out sys_refcursor);
  procedure get_result_cursor010(p_up_id number, p_date date, p_is_active boolean, p_result out sys_refcursor);

  procedure get_result_cursor011(p_up_id number, p_result out sys_refcursor);
  procedure get_result_cursor012(p_result out sys_refcursor);

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
