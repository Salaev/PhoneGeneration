CREATE package install_pkg is

----------------------------------!---------------------------------------------
  c_date_format_short            constant varchar2(30) := 'dd.mm.yyyy';
  c_date_format_full             constant varchar2(30) := 'dd.mm.yyyy hh24:mi:ss';
  c_date_format_full_compact     constant varchar2(30) := 'yyyymmddhh24miss';
  c_minus_infinity               constant date := to_date('01.01.1000', c_date_format_short);
  c_plus_infinity                constant date := to_date('01.01.4000', c_date_format_short);
  c_open_date_to                 constant date := c_plus_infinity;

  c_hour                         constant number := 1/24;
  c_minute                       constant number := c_hour/60;
  c_second                       constant number := c_minute/60;
  c_dt_dif                       constant number := c_second;

  c_default_post_len             constant number := 4;

  c_false                        constant number := 0;
  c_true                         constant number := 1;

  c_no                           constant varchar2(1) := 'N';
  c_yes                          constant varchar2(1) := 'Y';

  c_no2                          constant varchar2(3) := 'NO';
  c_yes2                         constant varchar2(3) := 'YES';

  c_con_tp_primary_key           constant varchar2(1) := 'P';
  c_con_tp_foreign_key           constant varchar2(1) := 'R';
  c_con_tp_unique_key            constant varchar2(1) := 'U';
  c_con_tp_check_constraint      constant varchar2(1) := 'C';
  c_con_tp_view_check            constant varchar2(1) := 'V'; --With check option, on a view
  c_con_tp_read_only             constant varchar2(1) := 'O'; --With read only, on a view
  c_con_tp_hash_expression       constant varchar2(1) := 'H';
  c_con_tp_ref_col_constraint    constant varchar2(1) := 'F'; --Constraint that involves a REF column
  c_con_tp_supplemental_loggin   constant varchar2(1) := 'S'; --Supplemental logging

----------------------------------!---------------------------------------------
  c_objt_package                 constant varchar2(50) := 'PACKAGE';
  c_objt_package_body            constant varchar2(50) := 'PACKAGE BODY';
  c_objt_function                constant varchar2(50) := 'FUNCTION';
  c_objt_procedure               constant varchar2(50) := 'PROCEDURE';
  c_objt_queue                   constant varchar2(50) := 'QUEUE';

  c_t_clob                       constant varchar2(50) := 'CLOB';
  c_t_number                     constant varchar2(50) := 'NUMBER';
  c_t_varchar2                   constant varchar2(50) := 'VARCHAR2';

  c_unq_unique                   constant varchar2(50) := 'UNIQUE';
  c_unq_nonunique                constant varchar2(50) := 'NONUNIQUE';

  c_ind_status_unusable          constant varchar2(8) := 'UNUSABLE';

  --!_!sys_context namespace
  c_sysctx_ns_userenv            constant varchar2(30) := 'USERENV';

  --!_!sys_context parameter
  c_sysctx_par_session_user      constant varchar2(30) := 'SESSION_USER';
  c_sysctx_par_bg_job_id         constant varchar2(30) := 'BG_JOB_ID';

----------------------------------!---------------------------------------------
  c_max_error_message_length     constant number := 4000;
  c_max_error_message_length2    constant number := 2048;

  c_number_format1               constant varchar2(100) := 'tm';
  c_number_format2               constant varchar2(100) := '9999999999999999999999999999999999999999D9999999999999999999999';
  c_number_nlsparam              constant varchar2(100) := q'{nls_numeric_characters = '.,'}';

----------------------------------!---------------------------------------------
  c_oracle_system_name_length    constant number := 30;
  c_oracle_sys_context_def_len   constant number := 256;

  c_db_domain_param_name         constant varchar2(30) := 'db_domain';

  c_store_priv_tab_pref          constant varchar2(30) := 'PRIV_';

  c_opt1_ts_tables               constant varchar2(127) := 'TABLESPACE_FOR_TABLES';
  c_opt1_ts_indexes              constant varchar2(127) := 'TABLESPACE_FOR_INDEXES';

  c_opt2_def_user_id             constant varchar2(100) := 'DEFAULT_USER_ID';

  c_opt_ts_tables                constant varchar2(100) := c_opt1_ts_tables;
  c_opt_ts_indexes               constant varchar2(100) := c_opt1_ts_indexes;
  c_opt_def_user_id              constant varchar2(100) := c_opt2_def_user_id;

  c_opt_delim01                  constant varchar2(10) := ',';

----------------------------------!---------------------------------------------
  c_ora_x_user_min               constant number(5) := -20999;
  c_ora_x_user_max               constant number(5) := -20000;
  c_ora_x_common                 constant number(5) := c_ora_x_user_max;

  c_ora_user_not_found           constant number(5) := -20602;
  c_ora_option_nspec_wrong       constant number(5) := -20705;

----------------------------------!---------------------------------------------
  c_msg_x_common                 constant varchar2(200) := 'Common error';

  c_msg_user_not_found           constant varchar2(200) := 'User is not found';
  c_msg_option_nspec_wrong       constant varchar2(200) := 'Option not specified or wrong';

  c_msg_delim01                  constant varchar2(10) := ':';
  c_msg_delim02                  constant varchar2(10) := ';';

----------------------------------!---------------------------------------------
  c_sql_eval_as                  constant clob := q'{
declare
  v_res :p_type;
begin
  v_res := :p_expr;
  :p_out := v_res;
end;
  }';

----------------------------------!---------------------------------------------
  currval_exception exception;
  pragma exception_init (currval_exception, -08002);

----------------------------------!---------------------------------------------
  procedure raise_exception(p_code number, p_message varchar2);

----------------------------------!---------------------------------------------
  function date_to_char(p_val date) return varchar2;
  function number_to_char(p_val number) return varchar2;
  function char_to_number(p_val varchar2) return number;
  function char_to_date(p_val varchar2) return date;
  function char_to_nchar(p_val varchar2) return nvarchar2;
  function nchar_to_char(p_val nvarchar2) return varchar2;

  function bool_to_int(p_val boolean) return number;
  function bool_to_int_2val(p_val boolean) return number;
  function bool_to_int_3val(p_val boolean) return number;
  function int_to_bool(p_val number) return boolean;
  function int_to_bool_2val(p_val number) return boolean;
  function int_to_bool_3val(p_val number) return boolean;

  function bool_to_bool_2val(p_val boolean) return boolean;
  function int_to_int_2val(p_val number) return number;
  function int_to_int_3val(p_val number) return number;

----------------------------------!---------------------------------------------
  function get_option(p_option_name varchar2, p_default varchar2) return varchar2;
  function is_exist_option(p_option_name varchar2) return boolean;

  function get_option1(p_option_name varchar2, p_default varchar2) return varchar2;
  function get_option2(p_option_name varchar2, p_default varchar2) return varchar2;

  function is_exist_option1(p_option_name varchar2) return boolean;
  function is_exist_option2(p_option_name varchar2) return boolean;

----------------------------------!---------------------------------------------
  function get_option_str(p_option_name varchar2, p_length number, p_default varchar2) return varchar2;
  function get_option_num(p_option_name varchar2, p_default number) return number;
  function get_option_bool(p_option_name varchar2, p_default boolean) return boolean;
  function get_option_date(p_option_name varchar2, p_default date) return date;

  function nnget_option_str(p_option_name varchar2, p_length number, p_default varchar2) return varchar2;
  function nnget_option_num(p_option_name varchar2, p_default number) return number;
  function nnget_option_bool(p_option_name varchar2, p_default boolean) return boolean;
  function nnget_option_date(p_option_name varchar2, p_default date) return date;

  function xget_option_str(p_option_name varchar2, p_length number) return varchar2;
  function xget_option_num(p_option_name varchar2) return number;
  function xget_option_bool(p_option_name varchar2) return boolean;
  function xget_option_date(p_option_name varchar2) return date;

  procedure ins_option_str(p_option_name varchar2, p_option_value varchar2, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null);
  procedure ins_option_num(p_option_name varchar2, p_option_value number, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null);
  procedure ins_option_bool(p_option_name varchar2, p_option_value boolean, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null);
  procedure ins_option_date(p_option_name varchar2, p_option_value date, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null);
  procedure upd_option_value_str(p_option_name varchar2, p_option_value varchar2, p_user_id number := null, p_change_date date := null);
  procedure upd_option_value_num(p_option_name varchar2, p_option_value number, p_user_id number := null, p_change_date date := null);
  procedure upd_option_value_bool(p_option_name varchar2, p_option_value boolean, p_user_id number := null, p_change_date date := null);
  procedure upd_option_value_date(p_option_name varchar2, p_option_value date, p_user_id number := null, p_change_date date := null);
  procedure upd_option_dsc(p_option_name varchar2, p_option_dsc varchar2, p_user_id number := null, p_change_date date := null);
  procedure del_option(p_option_name varchar2, p_user_id number := null, p_change_date date := null);

----------------------------------!---------------------------------------------
  function xget_option1_str(p_option_name varchar2, p_length number) return varchar2;
  function xget_option1_num(p_option_name varchar2) return number;
  function xget_option1_bool(p_option_name varchar2) return boolean;
  function xget_option1_date(p_option_name varchar2) return date;

  procedure ins_option1_str(p_option_name varchar2, p_option_value varchar2, p_option_dsc varchar2 := null/*, p_user_id number := null, p_change_date date := null*/);
  procedure ins_option1_num(p_option_name varchar2, p_option_value number, p_option_dsc varchar2 := null/*, p_user_id number := null, p_change_date date := null*/);
  procedure ins_option1_bool(p_option_name varchar2, p_option_value boolean, p_option_dsc varchar2 := null/*, p_user_id number := null, p_change_date date := null*/);
  procedure ins_option1_date(p_option_name varchar2, p_option_value date, p_option_dsc varchar2 := null/*, p_user_id number := null, p_change_date date := null*/);
  procedure upd_option1_value_str(p_option_name varchar2, p_option_value varchar2/*, p_user_id number := null, p_change_date date := null*/);
  procedure upd_option1_value_num(p_option_name varchar2, p_option_value number/*, p_user_id number := null, p_change_date date := null*/);
  procedure upd_option1_value_bool(p_option_name varchar2, p_option_value boolean/*, p_user_id number := null, p_change_date date := null*/);
  procedure upd_option1_value_date(p_option_name varchar2, p_option_value date/*, p_user_id number := null, p_change_date date := null*/);
  procedure upd_option1_dsc(p_option_name varchar2, p_option_dsc varchar2/*, p_user_id number := null, p_change_date date := null*/);
  procedure del_option1(p_option_name varchar2/*, p_user_id number := null, p_change_date date := null*/);

----------------------------------!---------------------------------------------
  function get_option2_str(p_option_name varchar2, p_length number, p_default varchar2) return varchar2;
  function get_option2_num(p_option_name varchar2, p_default number) return number;
  function get_option2_bool(p_option_name varchar2, p_default boolean) return boolean;
  function get_option2_date(p_option_name varchar2, p_default date) return date;

  function xget_option2_str(p_option_name varchar2, p_length number) return varchar2;
  function xget_option2_num(p_option_name varchar2) return number;
  function xget_option2_bool(p_option_name varchar2) return boolean;
  function xget_option2_date(p_option_name varchar2) return date;

  procedure ins_option2_str(p_option_name varchar2, p_option_value varchar2, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null);
  procedure ins_option2_num(p_option_name varchar2, p_option_value number, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null);
  procedure ins_option2_bool(p_option_name varchar2, p_option_value boolean, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null);
  procedure ins_option2_date(p_option_name varchar2, p_option_value date, p_option_dsc varchar2 := null, p_user_id number := null, p_change_date date := null);
  procedure upd_option2_value_str(p_option_name varchar2, p_option_value varchar2, p_user_id number := null, p_change_date date := null);
  procedure upd_option2_value_num(p_option_name varchar2, p_option_value number, p_user_id number := null, p_change_date date := null);
  procedure upd_option2_value_bool(p_option_name varchar2, p_option_value boolean, p_user_id number := null, p_change_date date := null);
  procedure upd_option2_value_date(p_option_name varchar2, p_option_value date, p_user_id number := null, p_change_date date := null);
  procedure upd_option2_dsc(p_option_name varchar2, p_option_dsc varchar2, p_user_id number := null, p_change_date date := null);
  procedure del_option2(p_option_name varchar2, p_user_id number := null, p_change_date date := null);

----------------------------------!---------------------------------------------
  function xget_ts_tables return varchar2;
  function xget_ts_indexes return varchar2;

----------------------------------!---------------------------------------------
  function xget_default_user_id return number;

  --!_! OBSOLETE
  procedure xcheck_user(p_user_id number, p_date date := sysdate);

  procedure xcheck_user_id(p_user_id number, p_date date := sysdate);
  procedure xcheck_user_name(p_user_name varchar2, p_date date := sysdate);
  procedure xcheck_user_name2(p_user_name nvarchar2, p_date date := sysdate);
  function check_user_id(p_user_id number, p_date date := sysdate) return number;
  function check_user_name(p_user_name varchar2, p_date date := sysdate) return number;
  function check_user_name2(p_user_name nvarchar2, p_date date := sysdate) return number;

  function xget_user_id(p_user_name varchar2, p_date date := sysdate) return number;
  function xget_user_id2(p_user_name nvarchar2, p_date date := sysdate) return number;
  function xget_user_name(p_user_id number, p_date date := sysdate) return varchar2;
  function xget_user_name2(p_user_id number, p_date date := sysdate) return nvarchar2;
  function get_user_id(p_user_name varchar2, p_date date := sysdate) return number;
  function get_user_id2(p_user_name nvarchar2, p_date date := sysdate) return number;
  function get_user_name(p_user_id number, p_date date := sysdate) return varchar2;
  function get_user_name2(p_user_id number, p_date date := sysdate) return nvarchar2;

----------------------------------!---------------------------------------------
  --!_! OBSOLETE
  function check_tab(p_table_name varchar2) return number;
  function check_seq(p_sequence_name varchar2) return number;
  function check_mv(p_mview_name varchar2) return number;
  function check_mv_in_refresh(p_refresh_name varchar2, p_miew_name varchar2) return number;
  function check_dblink(p_db_link varchar2) return number;
  --!_! OBSOLETE

----------------------------------!---------------------------------------------
  function check_table(p_table_name varchar2) return number;
  function check_index(p_index_name varchar2) return number;
  function check_index2(p_index_name varchar2, p_table_name varchar2) return number;
  function check_ind_column(p_index_name varchar2, p_column_name varchar2) return number;
  function check_ind_expression(p_index_name varchar2, p_column_position number) return number;
  function check_view(p_view_name varchar2) return number;
  function check_type(p_type_name varchar2) return number;
  function check_sequence(p_sequence_name varchar2) return number;
  function check_tab_column(p_table_name varchar2, p_column_name varchar2) return number;
  function check_constraint(p_constraint_name varchar2) return number;
  function check_constraint2(p_constraint_name varchar2, p_table_name varchar2) return number;
  function check_cons_column(p_constraint_name varchar2, p_column_name varchar2) return number;
  function check_trigger(p_trigger_name varchar2) return number;
  function check_mview_log(p_table_name varchar2) return number;
  function check_mview(p_mview_name varchar2) return number;
  function check_refresh(p_refresh_name varchar2) return number;
  function check_refresh_children(p_refresh_name varchar2, p_miew_name varchar2) return number;
  function check_db_link(p_db_link varchar2) return number;
  function check_object(p_object_name varchar2, p_object_type varchar2) return number;
  function check_package(p_package_name varchar2) return number;
  function check_package_body(p_package_body_name varchar2) return number;
  function check_function(p_function_name varchar2) return number;
  function check_procedure(p_procedure_name varchar2) return number;
  function check_synonym(p_synonym_name varchar2) return number;
  function check_queue(p_queue_name varchar2) return number;
  function check_queue_table(p_queue_table_name varchar2) return number;
  function check_queue_started(p_queue_name varchar2) return number;
  function check_aq_subscrider(p_queue_name varchar2, p_consumer_name varchar2) return number;
  function check_part_table(p_table_name varchar2) return number;

----------------------------------!---------------------------------------------
  function get_parameter_value(p_param_name varchar2) return varchar2;
  function get_def_domain return varchar2;

----------------------------------!---------------------------------------------
  function is_column_nullable(p_table_name varchar2, p_column_name varchar2) return number;

----------------------------------!---------------------------------------------
  function check_has_primary_key(p_table_name varchar2) return number;
  function get_primary_key_name(p_table_name varchar2) return varchar2;

----------------------------------!---------------------------------------------
  function get_tab_column(p_table_name varchar2, p_column_name varchar2) return user_tab_columns%rowtype;
  function get_sequence(p_sequence_name varchar2) return user_sequences%rowtype;
  function get_index(p_index_name varchar2) return user_indexes%rowtype;
  function get_mview_log(p_table_name varchar2) return user_mview_logs%rowtype;
  function get_mview(p_mview_name varchar2) return user_mviews%rowtype;
  function get_user_refresh_children(p_refresh_name varchar2, p_miew_name varchar2) return user_refresh_children%rowtype;

----------------------------------!---------------------------------------------
  function get_part_table(p_table_name varchar2) return user_part_tables%rowtype;
  function get_tab_partition(p_table_name varchar2, p_partition_name varchar2) return user_tab_partitions%rowtype;
  function get_tab_partition2(p_table_name varchar2, p_partition_position number) return user_tab_partitions%rowtype;
  function get_tab_subpartition(p_table_name varchar2, p_partition_name varchar2, p_subpartition_name varchar2) return user_tab_subpartitions%rowtype;
  function get_tab_subpartition2(p_table_name varchar2, p_partition_name varchar2, p_subpartition_position number) return user_tab_subpartitions%rowtype;

----------------------------------!---------------------------------------------
  function get_session(p_sid number) return v$session%rowtype;

  function get_job_by_id(p_job number) return user_jobs%rowtype;
  function get_job(p_what_label varchar2) return user_jobs%rowtype;
  function get_job_running(p_job number) return dba_jobs_running%rowtype;
  function is_job_running(p_job number) return number;

----------------------------------!---------------------------------------------
  function get_attr_val(p_xml xmltype, p_xpath varchar2) return clob;

----------------------------------!---------------------------------------------
  function make_backup_table_name(p_table_name varchar2) return varchar2;
  function get_backup_table_name(p_table_name varchar2) return varchar2; --!_! OBSOLETE

  function make_store_priv_tab_pref(p_table_name varchar2) return varchar2;

  function backup_table(p_table_name varchar2, p_backup_tab_prefix varchar2) return varchar2;
  function backup_table2(p_table_name varchar2) return varchar2;

  function save_privs_i(p_owner varchar2, p_table_name varchar2, p_grantor varchar2, p_store_tab_prefix varchar2) return varchar2;
  function save_privs(p_grantor varchar2, p_table_name varchar2, p_store_tab_prefix varchar2) return varchar2;
  function save_privs2(p_grantor varchar2, p_table_name varchar2) return varchar2;
  function save_privs3(p_table_name varchar2) return varchar2;

  procedure restore_privs_i(p_owner varchar2, p_table_name varchar2, p_grantor varchar2, p_store_table_name varchar2, p_drop_store_table boolean);
  procedure restore_privs(p_grantor varchar2, p_table_name varchar2, p_store_table_name varchar2, p_drop_store_table boolean);
  procedure restore_privs2(p_grantor varchar2, p_table_name varchar2, p_store_table_name varchar2);
  procedure restore_privs3(p_table_name varchar2, p_store_table_name varchar2);

  procedure drop_ref_keys(p_table_name varchar2);
  procedure drop_own_keys(p_table_name varchar2);

  procedure rename_indexes(p_table_name varchar2, p_post_len number := c_default_post_len, p_only_xcheck boolean := false);

  function get_this_ora_user_name return varchar2;
  function get_scheme_name return varchar2; --!_! OBSOLETE

  function get_this_bg_job_id return number;

----------------------------------!---------------------------------------------
  function get_sys_context_par(p_namespace varchar2, p_parameter varchar2, p_max_ret_val_length number := c_oracle_sys_context_def_len) return varchar2;
  function get_sys_context_userenv_par(p_parameter varchar2, p_max_ret_val_length number := c_oracle_sys_context_def_len) return varchar2;
  function get_sys_context_userenv_par30(p_parameter varchar2) return varchar2;
  function get_sys_context_userenv_parnum(p_parameter varchar2) return number;

----------------------------------!---------------------------------------------
  procedure shift_sequence(p_sequence_name varchar2, p_target number, p_threshold number := 1000000);
  procedure shift_sequence_hard(p_sequence_name varchar2, p_target number);

----------------------------------!---------------------------------------------
  function get_unique_incr(p_table_name varchar2, p_tab_column varchar2)return number;

----------------------------------!---------------------------------------------
  procedure create_synonym(p_synonym_name varchar2, p_table_name varchar2, p_table_owner varchar2, p_db_link varchar2);

----------------------------------!---------------------------------------------
  procedure create_queue
  (
    p_queue_name varchar2,
    p_queue_table_name varchar2,
    p_queue_payload_type varchar2,
    p_subscriber_name varchar2,
    p_queue_comment varchar2,
    p_max_retries number,
    p_retry_delay number,
    p_retention_time number,
    p_tablespace_t varchar2
  );

----------------------------------!---------------------------------------------
  function is_empty_table(p_table_name varchar2) return number;
  function is_empty_partition(p_table_name varchar2, p_partition_name varchar2) return number;
  function is_empty_subpartition(p_table_name varchar2, p_subpartition_name varchar2) return number;

  function contains_nulls(p_table_name varchar2, p_tab_column varchar2) return number;

----------------------------------!---------------------------------------------
  procedure close_cursor(p_cr sys_refcursor);

----------------------------------!---------------------------------------------
  function eval_as_str(v_expr varchar2) return varchar2;
  function eval_as_nstr(v_expr varchar2) return nvarchar2;
  function eval_as_number(v_expr varchar2) return number;
  function eval_as_date(v_expr varchar2) return date;

----------------------------------!---------------------------------------------
  procedure split_partition_down
  (
    p_table_name varchar2,
    p_partition_name varchar2,
    p_bottom_partition_name varchar2,
    p_bottom_high_value_expr varchar2,
    p_rebuild_ind_partitions boolean := true
  );

  procedure split_partition_down_date
  (
    p_table_name varchar2,
    p_partition_name varchar2,
    p_bottom_high_value date,
    p_bottom_part_name_date_fmt varchar2 := 'yyyymmdd',
    p_rebuild_ind_partitions boolean := true
  );

  procedure rebuid_part_indexes(p_table_name varchar2);
  procedure rebuid_ind_partitions(p_index_name varchar2);
  procedure rebuid_ind_subpartitions(p_index_name varchar2);

----------------------------------!---------------------------------------------

end;
/
