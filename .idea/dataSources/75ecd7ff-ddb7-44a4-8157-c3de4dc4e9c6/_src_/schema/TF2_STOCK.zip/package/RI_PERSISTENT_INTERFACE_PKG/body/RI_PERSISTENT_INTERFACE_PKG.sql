CREATE package body RI_PERSISTENT_INTERFACE_PKG is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function cast_cit_number2number(p_coll RI_PERSISTENT_INTERFACE#PCK.cit_number) return ct_number
is
  v_res ct_number;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    util_pkg.add_ct_number_val(v_res, p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_date2date(p_coll RI_PERSISTENT_INTERFACE#PCK.cit_date) return ct_date
is
  v_res ct_date;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    util_pkg.add_ct_date_val(v_res, p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_varchar_s2varchar_s(p_coll RI_PERSISTENT_INTERFACE#PCK.cit_varchar_s) return ct_varchar_s
is
  v_res ct_varchar_s;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    util_pkg.add_ct_varchar_s_val(v_res, p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_varchar2varchar(p_coll RI_PERSISTENT_INTERFACE#PCK.cit_varchar) return ct_varchar
is
  v_res ct_varchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    util_pkg.add_ct_varchar_val(v_res, p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_nvarchar_s2nvarchar_s(p_coll RI_PERSISTENT_INTERFACE#PCK.cit_nvarchar_s) return ct_nvarchar_s
is
  v_res ct_nvarchar_s;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    util_pkg.add_ct_nvarchar_s_val(v_res, p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_cit_nvarchar2nvarchar(p_coll RI_PERSISTENT_INTERFACE#PCK.cit_nvarchar) return ct_nvarchar
is
  v_res ct_nvarchar;
begin
  ------------------------------
  if p_coll is null or p_coll.count = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    util_pkg.add_ct_nvarchar_val(v_res, p_coll(v_i));
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function cast_ct_number2number(p_coll ct_number) return RI_PERSISTENT_INTERFACE#PCK.cit_number
is
  v_res RI_PERSISTENT_INTERFACE#PCK.cit_number;
begin
  ------------------------------
  if util_pkg.get_count_ct_number(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_date2date(p_coll ct_date) return RI_PERSISTENT_INTERFACE#PCK.cit_date
is
  v_res RI_PERSISTENT_INTERFACE#PCK.cit_date;
begin
  ------------------------------
  if util_pkg.get_count_ct_date(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_varchar_s2varchar_s(p_coll ct_varchar_s) return RI_PERSISTENT_INTERFACE#PCK.cit_varchar_s
is
  v_res RI_PERSISTENT_INTERFACE#PCK.cit_varchar_s;
begin
  ------------------------------
  if util_pkg.get_count_ct_varchar_s(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_varchar2varchar(p_coll ct_varchar) return RI_PERSISTENT_INTERFACE#PCK.cit_varchar
is
  v_res RI_PERSISTENT_INTERFACE#PCK.cit_varchar;
begin
  ------------------------------
  if util_pkg.get_count_ct_varchar(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_nvarchar_s2nvarchar_s(p_coll ct_nvarchar_s) return RI_PERSISTENT_INTERFACE#PCK.cit_nvarchar_s
is
  v_res RI_PERSISTENT_INTERFACE#PCK.cit_nvarchar_s;
begin
  ------------------------------
  if util_pkg.get_count_ct_nvarchar_s(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function cast_ct_nvarchar2nvarchar(p_coll ct_nvarchar) return RI_PERSISTENT_INTERFACE#PCK.cit_nvarchar
is
  v_res RI_PERSISTENT_INTERFACE#PCK.cit_nvarchar;
begin
  ------------------------------
  if util_pkg.get_count_ct_nvarchar(p_coll) = 0
  then
    return v_res;
  end if;
  ------------------------------
  for v_i in p_coll.first..p_coll.last
  loop
    v_res(v_i) := p_coll(v_i);
  end loop;
  ------------------------------
  return v_res;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_network_operator_id0(p_network_operator_code ct_varchar_s, p_date ct_date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_network_operator_code RI_PERSISTENT_INTERFACE#PCK.cit_varchar_s;
  v_date RI_PERSISTENT_INTERFACE#PCK.cit_date;
begin
  ------------------------------
  v_network_operator_code := cast_ct_varchar_s2varchar_s(p_network_operator_code);
  v_date := cast_ct_date2date(p_date);
  ------------------------------
  return cast_cit_number2number(RI_PERSISTENT_INTERFACE#PCK.get_network_operator_id0(v_network_operator_code, v_date, p_trim_empty, p_xcheck_data));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_id(p_network_operator_code ct_varchar_s, p_date date, p_trim_empty boolean, p_xcheck_data boolean := true) return ct_number
is
  v_network_operator_code RI_PERSISTENT_INTERFACE#PCK.cit_varchar_s;
begin
  ------------------------------
  v_network_operator_code := cast_ct_varchar_s2varchar_s(p_network_operator_code);
  ------------------------------
  return cast_cit_number2number(RI_PERSISTENT_INTERFACE#PCK.get_network_operator_id(v_network_operator_code, p_date, p_trim_empty, p_xcheck_data));
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_network_operator_id2(p_network_operator_code varchar2, p_date date) return number
is
begin
  ------------------------------
  return RI_PERSISTENT_INTERFACE#PCK.get_network_operator_id2(p_network_operator_code, p_date);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure prod_check_sim_list
(
    p_host_id number,
    p_net_op_id number,
    p_iccid_without_control_digit ct_nvarchar_s,
    p_iccid out ct_nvarchar_s,
    p_imsi out ct_nvarchar_s,
    p_error_code out ct_number,
    p_error_message out ct_varchar
)
is
  v_iccid_without_control_digit RI_PERSISTENT_INTERFACE#PCK.cit_nvarchar_s;
  v_iccid RI_PERSISTENT_INTERFACE#PCK.cit_nvarchar_s;
  v_imsi RI_PERSISTENT_INTERFACE#PCK.cit_nvarchar_s;
  v_error_code RI_PERSISTENT_INTERFACE#PCK.cit_number;
  v_error_message RI_PERSISTENT_INTERFACE#PCK.cit_varchar;
begin
  ------------------------------
  v_iccid_without_control_digit := cast_ct_nvarchar_s2nvarchar_s(p_iccid_without_control_digit);
  ------------------------------
  RI_PERSISTENT_INTERFACE#PCK.prod_check_sim_list
  (
    p_host_id => p_host_id,
    p_net_op_id => p_net_op_id,
    p_iccid_without_control_digit => v_iccid_without_control_digit,
    p_iccid => v_iccid,
    p_imsi => v_imsi,
    p_error_code => v_error_code,
    p_error_message => v_error_message
  );
  ------------------------------
  p_iccid := cast_cit_nvarchar_s2nvarchar_s(v_iccid);
  p_imsi := cast_cit_nvarchar_s2nvarchar_s(v_imsi);
  p_error_code := cast_cit_number2number(v_error_code);
  p_error_message := cast_cit_varchar2varchar(v_error_message);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
end;
/
