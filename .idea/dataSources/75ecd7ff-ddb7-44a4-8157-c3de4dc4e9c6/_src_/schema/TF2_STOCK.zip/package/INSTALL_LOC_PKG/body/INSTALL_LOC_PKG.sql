CREATE package body install_loc_pkg is

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
procedure touch_number(p_value number)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_varchar(p_value varchar2)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_date(p_value date)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure touch_boolean(p_value boolean)
is
begin
  ------------------------------
  if p_value is null
  then
    null;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function get_option1(p_option_name varchar2, p_default varchar2) return varchar2
is
  v_res varchar2(4000);
begin
  ------------------------------
  select
    to_char(value) into v_res
    from global_value z
    where 1 = 1
    and lower(name) = lower(p_option_name)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return p_default;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_option2(p_option_name varchar2, p_default varchar2) return varchar2
is
begin
  ------------------------------
  return get_option1(p_option_name, p_default);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option1_str(p_option_name varchar2, p_option_value varchar2, p_option_dsc varchar2/*, p_user_id number, p_change_date date*/)
is
  v_option_dsc varchar2(100) := substr(p_option_dsc, 1, 100);
begin
  ------------------------------
  insert into global_value
  (
    name,
    value,
    comments
  )
  values
  (
    to_nchar(p_option_name),
    to_nchar(p_option_value),
    v_option_dsc
  )
  ;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option1_value_str(p_option_name varchar2, p_option_value varchar2/*, p_user_id number, p_change_date date*/)
is
begin
  ------------------------------
  update
    global_value
  set
    value = to_nchar(p_option_value)
  where 1 = 1
  and upper(name) = upper(to_nchar(p_option_name))
  ;
  ------------------------------
  if sql%rowcount = 0
  then
    raise no_data_found;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option1_dsc(p_option_name varchar2, p_option_dsc varchar2/*, p_user_id number, p_change_date date*/)
is
  v_option_dsc varchar2(100) := substr(p_option_dsc, 1, 100);
begin
  ------------------------------
  update
    global_value
  set
    comments = v_option_dsc
  where 1 = 1
  and upper(name) = upper(to_nchar(p_option_name))
  ;
  ------------------------------
  if sql%rowcount = 0
  then
    raise no_data_found;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_option1(p_option_name varchar2/*, p_user_id number, p_change_date date*/)
is
begin
  ------------------------------
  delete
    from global_value
  where 1 = 1
  and upper(name) = upper(to_nchar(p_option_name))
  ;
  ------------------------------
  if sql%rowcount = 0
  then
    raise no_data_found;
  end if;
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure ins_option2_str(p_option_name varchar2, p_option_value varchar2, p_option_dsc varchar2, p_user_id number, p_change_date date)
is
begin
  ------------------------------
  touch_number(p_user_id);
  touch_date(p_change_date);
  ------------------------------
  ins_option1_str(p_option_name, p_option_value, p_option_dsc/*, p_user_id, p_change_date*/);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option2_value_str(p_option_name varchar2, p_option_value varchar2, p_user_id number, p_change_date date)
is
begin
  ------------------------------
  touch_number(p_user_id);
  touch_date(p_change_date);
  ------------------------------
  upd_option1_value_str(p_option_name, p_option_value/*, p_user_id, p_change_date*/);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure upd_option2_dsc(p_option_name varchar2, p_option_dsc varchar2, p_user_id number, p_change_date date)
is
begin
  ------------------------------
  touch_number(p_user_id);
  touch_date(p_change_date);
  ------------------------------
  upd_option1_dsc(p_option_name, p_option_dsc/*, p_user_id, p_change_date*/);
  ------------------------------
end;

----------------------------------!---------------------------------------------
procedure del_option2(p_option_name varchar2, p_user_id number, p_change_date date)
is
begin
  ------------------------------
  touch_number(p_user_id);
  touch_date(p_change_date);
  ------------------------------
  del_option1(p_option_name/*, p_user_id, p_change_date*/);
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------
function check_user(p_user_id number, p_date date := sysdate) return number
is
  v_str varchar2(100);
begin
  ------------------------------
  v_str := get_user_name(p_user_id, p_date);
  ------------------------------
  if v_str is null
  then
    return install_pkg.c_false;
  end if;
  ------------------------------
  return install_pkg.c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_user_name(p_user_name varchar2, p_date date := sysdate) return number
is
  v_num number;
begin
  ------------------------------
  v_num := get_user_id(p_user_name, p_date);
  ------------------------------
  if v_num is null
  then
    return install_pkg.c_false;
  end if;
  ------------------------------
  return install_pkg.c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function check_user_name2(p_user_name nvarchar2, p_date date := sysdate) return number
is
  v_num number;
begin
  ------------------------------
  v_num := get_user_id2(p_user_name, p_date);
  ------------------------------
  if v_num is null
  then
    return install_pkg.c_false;
  end if;
  ------------------------------
  return install_pkg.c_true;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_name(p_user_id number, p_date date := sysdate) return varchar2
is
  v_res varchar2(100);
  v_date date := nvl(p_date, sysdate);
begin
  ------------------------------
  select /*+ index_asc(z, PK_USERS)*/
    to_char(user_name) into v_res
    from users z
    where 1 = 1
    and user_id = p_user_id
    and (deleted is null or deleted > v_date)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_name2(p_user_id number, p_date date := sysdate) return nvarchar2
is
  v_res nvarchar2(100);
  v_date date := nvl(p_date, sysdate);
begin
  ------------------------------
  select /*+ index_asc(z, PK_USERS)*/
    user_name into v_res
    from users z
    where 1 = 1
    and user_id = p_user_id
    and (deleted is null or deleted > v_date)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_id(p_user_name varchar2, p_date date := sysdate) return number
is
  v_res number;
  v_date date := nvl(p_date, sysdate);
begin
  ------------------------------
  select /*+ index_asc(z, I_USERS_UPPER_USER_NAME)*/
    user_id into v_res
    from users z
    where 1 = 1
    and upper(user_name) = upper(to_nchar(p_user_name))
    and (deleted is null or deleted > v_date)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
function get_user_id2(p_user_name nvarchar2, p_date date := sysdate) return number
is
  v_res number;
  v_date date := nvl(p_date, sysdate);
begin
  ------------------------------
  select /*+ index_asc(z, I_USERS_UPPER_USER_NAME)*/
    user_id into v_res
    from users z
    where 1 = 1
    and upper(user_name) = upper(p_user_name)
    and (deleted is null or deleted > v_date)
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return null;
  ------------------------------
end;

----------------------------------!---------------------------------------------
----------------------------------!---------------------------------------------

end;
/
