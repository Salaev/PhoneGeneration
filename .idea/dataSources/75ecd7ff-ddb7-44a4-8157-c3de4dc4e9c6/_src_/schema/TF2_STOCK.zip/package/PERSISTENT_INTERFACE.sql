CREATE package persistent_interface is

----------------------------------!---------------------------------------------
  -- for Report Subsystem
  procedure prepare_user_stock_perms(p_user_name users.user_name%type, p_perm_view boolean, p_perm_change boolean, p_stock_group_id number, p_cursor OUT sys_refcursor);
  procedure prepare_user_stock_perms_wrp(p_user_name users.user_name%type, p_perm_view number, p_perm_change number, p_stock_group_id number, p_cursor OUT sys_refcursor);

----------------------------------!---------------------------------------------

end;
/
