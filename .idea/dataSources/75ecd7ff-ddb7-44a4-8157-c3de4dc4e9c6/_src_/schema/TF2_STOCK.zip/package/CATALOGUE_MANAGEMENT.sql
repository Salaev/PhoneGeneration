CREATE PACKAGE catalogue_management
AS
/*******************************************************************************
<name>          package
<author>        Petar Ulic
<version>       1.0   06.12.2003 basic Oracle implementation
<Description>   Package contains functions and procedures for catalogues
                management in Stock system
<Application>   Stock Management

-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ------------------------------------------
-- Petr Skripnik   10.11.2006  Изменен
*******************************************************************************/
   TYPE t_cursor IS REF CURSOR;

   TYPE t_modelid IS TABLE OF equipment_model.equipment_model_id%TYPE
      INDEX BY PLS_INTEGER;

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE equipment_model__get (
      p_id                          NUMBER,
      p_type_id                     NUMBER,
      p_equipment_model_rec   OUT   t_cursor,
      p_error_code            OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE equipment_model__get_by_type (
      p_code                        NVARCHAR2,
      p_equipment_model_rec   OUT   t_cursor,
      p_error_code            OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE equipment_type__get (
      p_id                         NUMBER,
      p_equipment_type_rec   OUT   t_cursor,
      p_error_code           OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE stock_state__get (
      p_stock_id                NUMBER,
      p_status                  NUMBER,
      p_stock_state_rec   OUT   t_cursor,
      p_error_code        OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE inventory__get (
      p_stock_id              NUMBER,
      p_inventory_rec   OUT   t_cursor,
      p_error_code      OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE country__get (p_id NUMBER, p_country_rec OUT t_cursor, p_error_code OUT NUMBER);

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE equipment_price__get (
      p_id                           NUMBER,
      p_equipment_prices_rec   OUT   t_cursor,
      p_error_code             OUT   NUMBER
   );

--------------------------------------------------------------------------------
-- Author  :
-- Created :
-- Editor  :
-- Changed :
-- Purpose :
--------------------------------------------------------------------------------
   PROCEDURE configuration__get (p_configuration_rec OUT t_cursor, p_error_code OUT NUMBER);

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 20.09.2006 10:10
-- Editor  : Skripnik Petr
-- Changed : 27.10.2006 10:10
-- Purpose : Вносит запись о партии оборудования
--------------------------------------------------------------------------------
   PROCEDURE equipment_batch_ins (
      p_equipment_batch_code   IN       NVARCHAR2,   --мнемокод партии
      p_equipment_model_id     IN       NUMBER,   --модель оборудования
      p_price                  IN       NUMBER,   --цена за еденицу оборудования
      p_user_of_change         IN       NVARCHAR2,   --пользователь создавший партию
      p_handle_tran            IN       CHAR DEFAULT 'Y',
      p_error_code             OUT      NUMBER   --код ошибки
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 20.09.2006 10:10
-- Editor  : Skripnik Petr
-- Changed : 27.10.2006 10:10
-- Purpose : Изменяет данные партии оборудования
--------------------------------------------------------------------------------
   PROCEDURE equipment_batch_upd (
      p_equipment_batch_id     IN       NUMBER,   --партия оборудования
      p_equipment_batch_code   IN       NVARCHAR2,   --код партии
      p_equipment_model_id     IN       NUMBER,   --модель
      p_price                  IN       NUMBER,   --цена за еденицу в партии
      p_user_of_change         IN       NVARCHAR2,   --пользователь изменивший информацию в партию
      p_date_of_close          IN       DATE,
      p_handle_tran            IN       CHAR DEFAULT 'Y',
      p_error_code             OUT      NUMBER   --код ошибки
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 21.09.2006 10:50
-- Editor  : Skripnik Petr
-- Changed : 27.09.2006 15:41
-- Purpose : Получает данные партии оборудования по моделям оборудования
--------------------------------------------------------------------------------
   PROCEDURE get_batch_cur_by_model_cur (
      p_with_closed   IN       NUMBER,
      p_cur_batch     OUT      sys_refcursor,
      p_error_code    OUT      NUMBER
   );

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 29.09.2006 10:30
-- Editor  :
-- Changed :
-- Purpose : Возвращает партии и модели в партиях
--------------------------------------------------------------------------------
   PROCEDURE get_batch_model_cur (p_cur_batch_model OUT sys_refcursor, p_error_code OUT NUMBER);

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 03.10.2006 13:49
-- Editor  :
-- Changed :
-- Purpose : Возвращает типы оборудования
--------------------------------------------------------------------------------
   PROCEDURE get_equipment_type_cur (p_cur_equipment_type OUT sys_refcursor, p_error_code OUT NUMBER);

--------------------------------------------------------------------------------
-- Author  : Ermakov Sergey
-- Created : 17.05.2009 13:49
-- Editor  :
-- Changed :
-- Purpose : Возвращает список всех поставщиков
--------------------------------------------------------------------------------
   PROCEDURE get_vendor_cur (p_cur_vendor OUT sys_refcursor, p_error_code OUT NUMBER);

END;
/
