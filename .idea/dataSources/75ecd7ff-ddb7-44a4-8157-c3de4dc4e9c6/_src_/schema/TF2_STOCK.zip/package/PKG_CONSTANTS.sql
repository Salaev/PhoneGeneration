CREATE PACKAGE pkg_constants
IS
--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 25.09.2006 17:13
-- Purpose : Используемые в исходном коде константы
-- Constants :
--   In comments: (<>) = Replaced
--                (+) = Added
--                (-) = Deleted
-- MODIFICATION HISTORY
-- Person          Date        Comments
-- ---------    ------   ----------------------------------------------
-- Petr Skripnik   09.11.2006  Изменен
-- Petr Skripnik   13.11.2006  Изменен
-- Petr Skripnik   27.12.2006  Добавлен c_flag_start,c_flag_end,c_flag_err

   --Контекст для пакета который виден для всех сессий
   --CREATE OR REPLACE CONTEXT CTX_CONSTANTS_GLOBAL USING pkg_constants ACCESSED GLOBALLY;
   --Контекст для пакета который виден для своей сессии
   --CREATE OR REPLACE CONTEXT CTX_CONSTANTS USING pkg_constants;
-----------------------------------------------------------------------------
  ctx_sufix                      constant varchar2(50) := ''; --суффикс для имени контекста
  
  --Даты
  c_date_format_short_not_use    constant varchar2(11) := 'dd.mm.yyyy';
  c_date_format_full_not_use     constant varchar2(22) := 'dd.mm.yyyy hh24:mi:ss';
  c_maxsysdate                   constant date := TO_DATE ('31.12.9999', c_date_format_short_not_use); --максимальная дата в системе
  c_minsysdate                   constant date := TO_DATE ('01.01.2000', c_date_format_short_not_use); --минимальная дата в системе
  c_minexistsdate                constant date := TO_DATE ('01.01.0100', c_date_format_short_not_use); --минимальная сушествующая дата
  c_max_datetime                 constant date := TO_DATE ('31.12.9999 23:59:59', c_date_format_full_not_use); --максимальная дата в c#
  
  --!_! OBSOLETE; Now is used only in triggers
  c_trigger_on                   constant number := 1;
  c_trigger_off                  constant number := 0;
  
  --Символы и литералы
  c_delimiter                    constant char    := ','; --разделитель по умолчанию
  c_flag_start                   constant char(5) := 'start'; --флаг начала
  c_flag_end                     constant char(3) := 'end'; --флаг конца
  c_flag_err                     constant char(5) := 'error'; --флаг ошибки
  
  c_YES                          constant char(1) := 'Y';
  c_NO                           constant char(1) := 'N';
  
--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.10.2006 10:34
-- Editor  :
-- Changed :
-- Purpose : Задает значение контексту
--------------------------------------------------------------------------------
   PROCEDURE set_context (p_name IN VARCHAR2, p_value IN VARCHAR2);

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 21.05.2007 11:44
-- Editor  :
-- Changed :
-- Purpose : Задает значение контексту
--------------------------------------------------------------------------------
   PROCEDURE set_context_global (p_name IN VARCHAR2, p_value IN VARCHAR2);

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.10.2006 10:34
-- Editor  :
-- Changed :
-- Purpose : Возвращает значение контекста
--------------------------------------------------------------------------------
   FUNCTION get_context (p_name IN VARCHAR2)
      RETURN VARCHAR2;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 11.05.2007 11:45
-- Editor  :
-- Changed :
-- Purpose : Возвращает значение контекста
--------------------------------------------------------------------------------
   FUNCTION get_context_global (p_name IN VARCHAR2)
      RETURN VARCHAR2;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.10.2006 10:34
-- Editor  :
-- Changed :
-- Purpose : Очищает контекст
--------------------------------------------------------------------------------
   PROCEDURE clear_context;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 11.05.2007 11:54
-- Editor  :
-- Changed :
-- Purpose : Очищает контекст
--------------------------------------------------------------------------------
   PROCEDURE clear_context_global;

--------------------------------------------------------------------------------
-- Author  : Skripnik Petr
-- Created : 23.10.2006 10:34
-- Editor  :
-- Changed :
-- Purpose : Просмотрим контекст
--------------------------------------------------------------------------------
   PROCEDURE list_context;
END;
/
