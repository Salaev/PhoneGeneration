CREATE PACKAGE BODY PKG_DOC
AS

   pkg_name   CONSTANT NVARCHAR2 (50) := 'PKG_DOC.';   --имя пакета

----------------------------------!---------------------------------------------
   PROCEDURE docheader_filtered_1 (
      p_stock_id        IN       NUMBER,
      p_type            IN       NUMBER,
      p_status_id       IN       NUMBER,
      p_from_date       IN       DATE,
      p_to_date         IN       DATE,
      p_cur_docheader   OUT      sys_refcursor,
      p_error_code      OUT      NUMBER
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'docheader_filtered_1';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_stock_id
                         || pkg_constants.c_delimiter
                         || p_type
                         || pkg_constants.c_delimiter
                         || p_status_id
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_from_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_to_date, 'dd.mm.yyyy')
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;

      IF p_type = 103
      THEN
         OPEN p_cur_docheader FOR
            SELECT   /*+ leading(dh)*/
                     dh.ID "Id", dh.user_id "User", dh.create_date "Date",
                     dh.doc_date "Document date", dh.doc_type_id "Type", dh.doc_no "No",
                     dh.status_id "Status Id", dh.vendor_doc "Vendor document",
                     dh.stock_out_id "From Id", s2.NAME "From Stock", dh.stock_in_id "To Id",
                     s1.NAME "To Stock", dh.valid_until "Valid", dh.description "Description",
                     dh.user_comment "Comment", dh.last_user "Last user", dh.vendor_id "Vendor Id",
                     (SELECT /*+ index(dh2 DOC_HEADER_UC_ID)*/
                             COUNT (dh2.user_comment)
                        FROM doc_header dh2
                       WHERE dh2.user_comment = dh.doc_no) "Linked documents",
                     s2.code AS "From Stock Code", s1.code AS "To Stock Code"
                FROM (SELECT /*+ use_concat index(d IDX_DOCHEADER_SI_DD_DMI) index(d IDX_DOCHEADER_SO_DD_DMO)*/
                             d.ID, d.user_id, d.create_date, d.doc_date, d.doc_type_id, d.doc_no,
                             d.status_id, d.vendor_doc, d.stock_out_id, d.stock_in_id,
                             d.valid_until, d.description, d.user_comment, d.last_user, d.vendor_id
                        FROM doc_header d
                       WHERE p_stock_id IN (d.stock_in_id, d.stock_out_id)
                         AND d.doc_type_id = p_type
                         AND d.status_id = p_status_id
                         AND d.doc_date BETWEEN p_from_date AND p_to_date) dh
                     LEFT JOIN
                     stock s1 ON s1.ID = dh.stock_in_id
                     LEFT JOIN stock s2 ON s2.ID = dh.stock_out_id
            ORDER BY dh.ID DESC;
      ELSIF p_type IN (101, 106)
      THEN
         OPEN p_cur_docheader FOR
            SELECT   /*+ index(dh IDX_DOCHEADER_SI_DD_DMI)*/
                     dh.ID "Id", dh.user_id "User", dh.create_date "Date",
                     dh.doc_date "Document date", dh.doc_type_id "Type", dh.doc_no "No",
                     dh.status_id "Status Id", dh.vendor_doc "Vendor document",
                     dh.stock_out_id "From Id", s2.NAME "From Stock", dh.stock_in_id "To Id",
                     s1.NAME "To Stock", dh.valid_until "Valid", dh.description "Description",
                     dh.user_comment "Comment", dh.last_user "Last user", dh.vendor_id "Vendor Id",
                     (SELECT /*+ index(dh2 DOC_HEADER_UC_ID)*/
                             COUNT (dh2.user_comment)
                        FROM doc_header dh2
                       WHERE dh2.user_comment = dh.doc_no) "Linked documents",
                     s2.code AS "From Stock Code", s1.code AS "To Stock Code"
                FROM doc_header dh LEFT JOIN stock s1 ON s1.ID = dh.stock_in_id
                     LEFT JOIN stock s2 ON s2.ID = dh.stock_out_id
               WHERE dh.stock_in_id = p_stock_id
                 AND dh.doc_type_id = p_type
                 AND dh.status_id = p_status_id
                 AND dh.doc_date BETWEEN p_from_date AND p_to_date
            ORDER BY dh.ID DESC;
      ELSE
         OPEN p_cur_docheader FOR
            SELECT   /*+ index(dh IDX_DOCHEADER_SO_DD_DMO)*/
                     dh.ID "Id", dh.user_id "User", dh.create_date "Date",
                     dh.doc_date "Document date", dh.doc_type_id "Type", dh.doc_no "No",
                     dh.status_id "Status Id", dh.vendor_doc "Vendor document",
                     dh.stock_out_id "From Id", s2.NAME "From Stock", dh.stock_in_id "To Id",
                     s1.NAME "To Stock", dh.valid_until "Valid", dh.description "Description",
                     dh.user_comment "Comment", dh.last_user "Last user", dh.vendor_id "Vendor Id",
                     (SELECT /*+ index(dh2 DOC_HEADER_UC_ID)*/
                             COUNT (dh2.user_comment)
                        FROM doc_header dh2
                       WHERE dh2.user_comment = dh.doc_no) "Linked documents",
                     s2.code AS "From Stock Code", s1.code AS "To Stock Code"
                FROM doc_header dh LEFT JOIN stock s1 ON s1.ID = dh.stock_in_id
                     LEFT JOIN stock s2 ON s2.ID = dh.stock_out_id
               WHERE dh.stock_out_id = p_stock_id
                 AND dh.doc_type_id = p_type
                 AND dh.status_id = p_status_id
                 AND dh.doc_date BETWEEN p_from_date AND p_to_date
            ORDER BY dh.ID DESC;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END;

----------------------------------!---------------------------------------------
   PROCEDURE docheader_filtered_2 (
      p_stock_id        IN       NUMBER,
      p_type            IN       NUMBER,
      p_status_id       IN       NUMBER,
      p_cur_docheader   OUT      sys_refcursor,
      p_error_code      OUT      NUMBER
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'docheader_filtered_2';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_stock_id
                         || pkg_constants.c_delimiter
                         || p_type
                         || pkg_constants.c_delimiter
                         || p_status_id
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;

      IF p_type = 103
      THEN
         OPEN p_cur_docheader FOR
            SELECT /*+ leading(dh)*/
                   dh.ID "Id", dh.user_id "User", dh.create_date "Date",
                   dh.doc_date "Document date", dh.doc_type_id "Type", dh.doc_no "No",
                   dh.status_id "Status Id", dh.vendor_doc "Vendor document",
                   dh.stock_out_id "From Id", s2.NAME "From Stock", dh.stock_in_id "To Id",
                   s1.NAME "To Stock", dh.valid_until "Valid", dh.description "Description",
                   dh.user_comment "Comment", dh.last_user "Last user", dh.vendor_id "Vendor Id",
                   (SELECT /*+ index(dh2 DOC_HEADER_UC_ID)*/
                           COUNT (dh2.user_comment)
                      FROM doc_header dh2
                     WHERE dh2.user_comment = dh.doc_no) "Linked documents",
                   s2.code AS "From Stock Code", s1.code AS "To Stock Code"
              FROM (SELECT /*+ use_concat index(a IDX_DOCHEADER_SI_DT_DD) index(a IDX_DOCHEADER_SO_DT_DD)*/
                           a.ID, a.user_id, a.create_date, a.doc_date, a.doc_type_id, a.doc_no,
                           a.status_id, a.vendor_doc, a.stock_out_id, a.stock_in_id, a.valid_until,
                           a.description, a.user_comment, a.last_user, a.vendor_id
                      FROM doc_header a
                     WHERE p_stock_id IN (a.stock_in_id, a.stock_out_id)
                       AND a.doc_type_id = p_type
                       AND a.status_id = p_status_id) dh,
                   stock s1,
                   stock s2
             WHERE dh.stock_in_id = s1.ID(+) AND dh.stock_out_id = s2.ID(+);
      ELSIF p_type IN (101, 106)
      THEN
         OPEN p_cur_docheader FOR
            SELECT /*+ leading(dh) index(dh IDX_DOCHEADER_SI_DT_DD)*/
                   dh.ID "Id", dh.user_id "User", dh.create_date "Date",
                   dh.doc_date "Document date", dh.doc_type_id "Type", dh.doc_no "No",
                   dh.status_id "Status Id", dh.vendor_doc "Vendor document",
                   dh.stock_out_id "From Id", s2.NAME "From Stock", dh.stock_in_id "To Id",
                   s1.NAME "To Stock", dh.valid_until "Valid", dh.description "Description",
                   dh.user_comment "Comment", dh.last_user "Last user", dh.vendor_id "Vendor Id",
                   (SELECT /*+ index(dh2 DOC_HEADER_UC_ID)*/
                           COUNT (dh2.user_comment)
                      FROM doc_header dh2
                     WHERE dh2.user_comment = dh.doc_no) "Linked documents",
                   s2.code AS "From Stock Code", s1.code AS "To Stock Code"
              FROM doc_header dh, stock s1, stock s2
             WHERE dh.stock_in_id = p_stock_id
               AND dh.doc_type_id = p_type
               AND dh.status_id = p_status_id
               AND dh.stock_in_id = s1.ID(+)
               AND dh.stock_out_id = s2.ID(+);
      ELSE
         OPEN p_cur_docheader FOR
            SELECT /*+ leading(dh) index(dh IDX_DOCHEADER_SO_DT_DD)*/
                   dh.ID "Id", dh.user_id "User", dh.create_date "Date",
                   dh.doc_date "Document date", dh.doc_type_id "Type", dh.doc_no "No",
                   dh.status_id "Status Id", dh.vendor_doc "Vendor document",
                   dh.stock_out_id "From Id", s2.NAME "From Stock", dh.stock_in_id "To Id",
                   s1.NAME "To Stock", dh.valid_until "Valid", dh.description "Description",
                   dh.user_comment "Comment", dh.last_user "Last user", dh.vendor_id "Vendor Id",
                   (SELECT /*+ index(dh2 DOC_HEADER_UC_ID)*/
                           COUNT (dh2.user_comment)
                      FROM doc_header dh2
                     WHERE dh2.user_comment = dh.doc_no) "Linked documents",
                   s2.code AS "From Stock Code", s1.code AS "To Stock Code"
              FROM doc_header dh, stock s1, stock s2
             WHERE dh.stock_out_id = p_stock_id
               AND dh.doc_type_id = p_type
               AND dh.status_id = p_status_id
               AND dh.stock_in_id = s1.ID(+)
               AND dh.stock_out_id = s2.ID(+);
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END docheader_filtered_2;

----------------------------------!---------------------------------------------
   PROCEDURE docheader_last_n_count (
      p_stock_id        IN       NUMBER,
      p_type            IN       NUMBER,
      p_status_id       IN       NUMBER,
      p_count           IN       NUMBER,
      p_cur_docheader   OUT      sys_refcursor,
      p_error_code      OUT      NUMBER
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'docheader_last_N_count';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_stock_id
                         || pkg_constants.c_delimiter
                         || p_type
                         || pkg_constants.c_delimiter
                         || p_status_id
                         || pkg_constants.c_delimiter
                         || p_count
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;

      IF p_type = 103
      THEN
         OPEN p_cur_docheader FOR
            SELECT   /*+ ordered use_nl(s1, s2) index_asc(s1 PK_STOCK) index_asc(s2 PK_STOCK) */
                     dh.ID "Id", dh.user_id "User", dh.create_date "Date",
                     dh.doc_date "Document date", dh.doc_type_id "Type", dh.doc_no "No",
                     dh.status_id "Status Id", dh.vendor_doc "Vendor document",
                     dh.stock_out_id "From Id", s2.NAME "From Stock", dh.stock_in_id "To Id",
                     s1.NAME "To Stock", dh.valid_until "Valid", dh.description "Description",
                     dh.user_comment "Comment", dh.last_user "Last user",
                     (SELECT /*+ index_desc(dh2 DOC_HEADER_UC_ID) */
                             COUNT (dh2.user_comment)
                        FROM doc_header dh2
                       WHERE dh2.user_comment = dh.doc_no) "Linked documents",
                     s2.code AS "From Stock Code", s1.code AS "To Stock Code"
                FROM (SELECT cc.*
                        FROM (SELECT   c.*
                                  FROM (SELECT aaa.*
                                          FROM (SELECT aa.*
                                                  FROM (SELECT   /*+ index_desc(a IDX_DOCHEADER_SO_DT_DD) */
                                                                 a.ID, a.user_id, a.create_date,
                                                                 a.doc_date, a.doc_type_id,
                                                                 a.doc_no, a.status_id,
                                                                 a.vendor_doc, a.stock_out_id,
                                                                 a.stock_in_id, a.valid_until,
                                                                 a.description, a.user_comment,
                                                                 a.last_user
                                                            FROM doc_header a
                                                           WHERE a.stock_out_id = p_stock_id
                                                             AND a.doc_type_id = p_type
                                                             AND a.status_id = p_status_id
                                                        ORDER BY a.doc_date DESC) aa
                                                 WHERE ROWNUM <= p_count) aaa
                                        UNION
                                        SELECT bbb.*
                                          FROM (SELECT bb.*
                                                  FROM (SELECT   /*+ index_desc(b IDX_DOCHEADER_SI_DT_DD) */
                                                                 b.ID, b.user_id, b.create_date,
                                                                 b.doc_date, b.doc_type_id,
                                                                 b.doc_no, b.status_id,
                                                                 b.vendor_doc, b.stock_out_id,
                                                                 b.stock_in_id, b.valid_until,
                                                                 b.description, b.user_comment,
                                                                 b.last_user
                                                            FROM doc_header b
                                                           WHERE b.stock_in_id = p_stock_id
                                                             AND b.doc_type_id = p_type
                                                             AND b.status_id = p_status_id
                                                        ORDER BY b.doc_date DESC) bb
                                                 WHERE ROWNUM <= p_count) bbb) c
                              ORDER BY c.doc_date DESC) cc
                       WHERE ROWNUM <= p_count) dh,
                     stock s1,
                     stock s2
               WHERE dh.stock_in_id = s1.ID(+) AND dh.stock_out_id = s2.ID(+)
            ORDER BY dh.doc_date DESC;
      ELSIF p_type IN (101, 106)
      THEN
         OPEN p_cur_docheader FOR
            SELECT   /*+ ordered use_nl(s1, s2) index_asc(s1 PK_STOCK) index_asc(s2 PK_STOCK) */
                     dh.ID "Id", dh.user_id "User", dh.create_date "Date",
                     dh.doc_date "Document date", dh.doc_type_id "Type", dh.doc_no "No",
                     dh.status_id "Status Id", dh.vendor_doc "Vendor document",
                     dh.stock_out_id "From Id", s2.NAME "From Stock", dh.stock_in_id "To Id",
                     s1.NAME "To Stock", dh.valid_until "Valid", dh.description "Description",
                     dh.user_comment "Comment", dh.last_user "Last user",
                     (SELECT /*+ INDEX_DESC(DH2 DOC_HEADER_UC_ID) */
                             COUNT (dh2.user_comment)
                        FROM doc_header dh2
                       WHERE dh2.user_comment = dh.doc_no) "Linked documents",
                     s2.code AS "From Stock Code", s1.code AS "To Stock Code"
                FROM (SELECT aa.*
                        FROM (SELECT   /*+ index_desc(a IDX_DOCHEADER_SI_DT_DD) */
                                       a.ID, a.user_id, a.create_date, a.doc_date, a.doc_type_id,
                                       a.doc_no, a.status_id, a.vendor_doc, a.stock_out_id,
                                       a.stock_in_id, a.valid_until, a.description, a.user_comment,
                                       a.last_user
                                  FROM doc_header a
                                 WHERE a.stock_in_id = p_stock_id
                                   AND a.doc_type_id = p_type
                                   AND a.status_id = p_status_id
                              ORDER BY a.doc_date DESC) aa
                       WHERE ROWNUM <= p_count) dh,
                     stock s1,
                     stock s2
               WHERE dh.stock_in_id = s1.ID(+) AND dh.stock_out_id = s2.ID(+)
            ORDER BY dh.doc_date DESC;
      ELSE
         OPEN p_cur_docheader FOR
            SELECT   /*+ ordered use_nl(s1, s2) index_asc(s1 PK_STOCK) index_asc(s2 PK_STOCK) */
                     dh.ID "Id", dh.user_id "User", dh.create_date "Date",
                     dh.doc_date "Document date", dh.doc_type_id "Type", dh.doc_no "No",
                     dh.status_id "Status Id", dh.vendor_doc "Vendor document",
                     dh.stock_out_id "From Id", s2.NAME "From Stock", dh.stock_in_id "To Id",
                     s1.NAME "To Stock", dh.valid_until "Valid", dh.description "Description",
                     dh.user_comment "Comment", dh.last_user "Last user",
                     (SELECT /*+ index_desc(dh2 DOC_HEADER_UC_ID) */
                             COUNT (dh2.user_comment)
                        FROM doc_header dh2
                       WHERE dh2.user_comment = dh.doc_no) "Linked documents",
                     s2.code AS "From Stock Code", s1.code AS "To Stock Code"
                FROM (SELECT aa.*
                        FROM (SELECT   /*+ index_desc(a IDX_DOCHEADER_SO_DT_DD) */
                                       a.ID, a.user_id, a.create_date, a.doc_date, a.doc_type_id,
                                       a.doc_no, a.status_id, a.vendor_doc, a.stock_out_id,
                                       a.stock_in_id, a.valid_until, a.description, a.user_comment,
                                       a.last_user
                                  FROM doc_header a
                                 WHERE a.stock_out_id = p_stock_id
                                   AND a.doc_type_id = p_type
                                   AND a.status_id = p_status_id
                              ORDER BY a.doc_date DESC) aa
                       WHERE ROWNUM <= p_count) dh,
                     stock s1,
                     stock s2
               WHERE dh.stock_in_id = s1.ID(+) AND dh.stock_out_id = s2.ID(+)
            ORDER BY dh.doc_date DESC;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END;

----------------------------------!---------------------------------------------
   PROCEDURE get_history (
      p_seria_start    IN       NVARCHAR2,
      p_seria_end      IN       NVARCHAR2,
      p_model_id       IN       NUMBER,
      p_date_from      IN       DATE DEFAULT pkg_constants.c_minsysdate,
      p_date_to        IN       DATE DEFAULT pkg_constants.c_maxsysdate,
      p_document_rec   OUT      sys_refcursor,
      p_error_code     OUT      NUMBER
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'get_history';
      l_ss                VARCHAR2 (50);   -- начало серии
      l_se                VARCHAR2 (50);   -- конец серии
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_seria_start
                         || pkg_constants.c_delimiter
                         || p_seria_end
                         || pkg_constants.c_delimiter
                         || p_model_id
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_date_from, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_date_to, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;

      l_ss:=p_seria_start;
      l_se:=p_seria_end;

      IF (p_seria_start IS NOT NULL) OR (p_seria_end IS NOT NULL)
      THEN
         --Установим недостающую границу серии
         pkg_equipment.get_seria_not_null (l_ss, l_se);

         OPEN p_document_rec FOR
            SELECT  /*+ leading(dd) no_expand
          use_hash(em, et, us)
          use_nl(dh, stk_out, stk_in)
          index_combine(dd, DOC_DETAIL_SS DOC_DETAIL_SE)
          full(em) full(et)
          index_asc(dh, PK_DOC_HEADER)
          index_asc(stk_out, PK_STOCK)
          index_asc(stk_in, PK_STOCK)
          full(us)
          */
          dh.ID, dh.doc_no, stk_out.code AS stock_code_out,
                     stk_in.code AS stock_code_in, dh.status_id, dh.stock_out_id, dh.stock_in_id,
                     dh.doc_date, dd.equipment_model_id, em.equipment_model_code,
                     em.equipment_model_name, dd.seria_start, dd.seria_end, dd.quantity,
                     dh.vendor_doc, dd.product, dh.last_user, dd.valid_until, dd.status_id,
                     dh.doc_type_id, et.equipment_type_id, et.equipment_type_name,
                     stk_out.NAME AS stock_name_out, stk_in.NAME AS stock_name_in,
                     us.NAME || ' ' || us.surname AS last_user_name
                FROM doc_header dh INNER JOIN
                 (
                 select * from doc_detail
                        where seria_start BETWEEN l_ss AND l_se AND LENGTH (seria_start) = LENGTH (l_ss)
                 union
                 select * from doc_detail
                        where  seria_end BETWEEN l_ss AND l_se AND LENGTH (seria_end) = LENGTH (l_se)
                 ) dd
                 ON dh.ID = dd.doc_header_id
                     LEFT JOIN stock stk_out ON stk_out.ID = dh.stock_out_id
                     LEFT JOIN stock stk_in ON stk_in.ID = dh.stock_in_id
                     LEFT JOIN equipment_model em ON em.equipment_model_id = dd.equipment_model_id
                     LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id
                     LEFT JOIN users us ON UPPER (us.user_name) = UPPER (dh.last_user)
               WHERE dh.status_id = 1
                 AND (p_model_id = -1 OR dd.equipment_model_id = p_model_id)
                 AND dh.doc_date >= p_date_from
                 AND dh.doc_date <= p_date_to
                 AND dh.doc_type_id > 100
            ORDER BY dh.ID;

      ELSE
         OPEN p_document_rec FOR
            SELECT   dh.ID, dh.doc_no, stk_out.code AS stock_code_out,
                     stk_in.code AS stock_code_in, dh.status_id, dh.stock_out_id, dh.stock_in_id,
                     dh.doc_date, dd.equipment_model_id, em.equipment_model_code,
                     em.equipment_model_name, dd.seria_start, dd.seria_end, dd.quantity,
                     dh.vendor_doc, dd.product, dh.last_user, dd.valid_until, dd.status_id,
                     dh.doc_type_id, et.equipment_type_id, et.equipment_type_name,
                     stk_out.NAME AS stock_name_out, stk_in.NAME AS stock_name_in,
                     us.NAME || ' ' || us.surname AS last_user_name
                FROM doc_header dh INNER JOIN doc_detail dd ON dh.ID = dd.doc_header_id
                     LEFT JOIN stock stk_out ON stk_out.ID = dh.stock_out_id
                     LEFT JOIN stock stk_in ON stk_in.ID = dh.stock_in_id
                     LEFT JOIN equipment_model em ON em.equipment_model_id = dd.equipment_model_id
                     LEFT JOIN equipment_type et ON et.equipment_type_id = em.equipment_type_id
                     LEFT JOIN users us ON UPPER (us.user_name) = UPPER (dh.last_user)
               WHERE dh.status_id = 1
                 AND (p_model_id = -1 OR dd.equipment_model_id = p_model_id)
                 AND dh.doc_date >= p_date_from
                 AND dh.doc_date <= p_date_to
                 AND dh.doc_type_id > 100
            ORDER BY dh.ID;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END get_history;

----------------------------------!---------------------------------------------
   PROCEDURE get_new_docnum (
      p_stock_id      IN       NUMBER,
      p_doc_type_id   IN       NUMBER,
      p_new_docnum    OUT      VARCHAR2,
      p_error_code    OUT      NUMBER
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100)        := pkg_name || 'get_new_docnum';
      l_year              NUMBER;
      l_number            NUMBER;
      l_prefix            doc_type.prefix%TYPE;
      l_code              stock.code%TYPE;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      p_error_code := 0;
      --Get current/active year
      document_management.doc_number_year__get (p_year => l_year, p_error_code => p_error_code);
      --Получим следующий за максимальным номером документа(аналог триггера)
      l_number := PKG_DOC.sq_next_docnum (p_stock_id, p_doc_type_id, l_year);

      --Generate new document number
      SELECT prefix
        INTO l_prefix
        FROM doc_type
       WHERE ID = p_doc_type_id;

      --Get stock code
      SELECT code
        INTO l_code
        FROM stock
       WHERE ID = p_stock_id;

      p_new_docnum :=
                    l_prefix || '-' || l_code || ' ' || TO_CHAR (l_number) || '/'
                    || TO_CHAR (l_year);
      pkg_db_util.DEBUG (prc_name, p_new_docnum, pkg_name);
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
   END get_new_docnum;

----------------------------------!---------------------------------------------
   PROCEDURE search (
      p_doc_type_id      IN       pkg_common.t_num,
      p_date_from        IN       DATE,
      p_date_to          IN       DATE,
      p_doc_header_rec   OUT      sys_refcursor,
      p_error_code       OUT      NUMBER,
      p_stock_out        IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_stock_in         IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_eqm_model_id     IN       pkg_common.t_num DEFAULT pkg_common.empty_t_num
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'search';
      l_cnt_eqm           NUMBER;
      --l_cnt_dtp           NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_doc_type_id.COUNT
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_date_from, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_date_to, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || ''
                         || pkg_constants.c_delimiter
                         || p_error_code
                         || pkg_constants.c_delimiter
                         || p_stock_out.COUNT
                         || pkg_constants.c_delimiter
                         || p_stock_in.COUNT
                         || pkg_constants.c_delimiter
                         || p_eqm_model_id.COUNT
                         || ')',
                         pkg_name
                        );
      p_error_code := 0;
      --Установим модели оборудования
      pkg_equipment.set_modelid (p_eqm_model_id);
      l_cnt_eqm := pkg_equipment.g_tab_model_id.COUNT;
      --Установим идентификаторы типов документов
      PKG_DOC.set_typeid (p_doc_type_id);
      --l_cnt_dtp := PKG_DOC.g_tab_type_id.COUNT;

      --Если неизвестен отправитель или получатель(склад может быть отправителем и\или получателем)
      --Учитывается списание\приход\перемещение и т.п.
      IF (NOT (p_stock_in.EXISTS (1)) OR
         (p_stock_in.COUNT = 1 AND p_stock_in(p_stock_in.FIRST) IS NULL))
      THEN
         --Заполним коллекцию идентификаторов складов
         pkg_stock.set_stockid (p_stock_id => p_stock_out, p_flag_clear => 'Y');

         OPEN p_doc_header_rec FOR
            SELECT --+ NO_MERGE(d)
                   d.ID, d.user_id, d.create_date, d.doc_date, d.doc_type_id, d.doc_no,
                   d.status_id, d.vendor_doc, so.code AS stock_code_out, so.NAME AS stock_name_out,
                   si.code AS stock_code_in, si.NAME AS stock_name_in, d.valid_until,
                   d.description, d.user_comment, d.last_user, d.vendor_id,
                   DECODE (d.doc_no, '', 0, (SELECT --+ INDEX(dh2 DOC_HEADER_UC_ID)
                                                    COUNT (dh2.user_comment)
                                               FROM doc_header dh2
                                              WHERE dh2.user_comment = d.doc_no)) AS link_doc,
                   us.NAME || ' ' || us.surname AS last_user_name
              FROM (SELECT --+ NO_MERGE(a)
                           a.*
                      FROM (SELECT /*+ CARDINALITY(stk 2)
                                       USE_CONCAT
                                       INDEX(dh IDX_DOCHEADER_SO_DD_DMO)
                                       INDEX(dh IDX_DOCHEADER_SI_DD_DMI)*/
                                   dh.ID, dh.user_id, dh.create_date, dh.doc_date, dh.doc_type_id,
                                   dh.doc_no, dh.status_id, dh.vendor_doc, dh.stock_out_id,
                                   dh.stock_in_id, dh.valid_until, dh.description, dh.user_comment,
                                   dh.last_user, dh.vendor_id
                              FROM TABLE (CAST (pkg_stock.g_tab_id AS ct_number)) stk,
                                   doc_header dh
                             WHERE dh.doc_date BETWEEN p_date_from AND p_date_to
                               AND stk.COLUMN_VALUE IN (dh.stock_out_id, dh.stock_in_id)) a
                     WHERE a.doc_type_id IN (
                                           SELECT --+ CARDINALITY(dtp 5)
                                                  COLUMN_VALUE
                                             FROM TABLE (CAST (PKG_DOC.g_tab_type_id AS ct_number)) dtp)
                       --вместо EXISTS можно AND 0 = ( SELECT COUNT(*) FROM doc_detail dd ...
                       AND EXISTS (
                              SELECT --+ FIRST_ROWS
                                     NULL
                                FROM doc_detail dd
                               WHERE a.ID = dd.doc_header_id
                                 AND (   dd.equipment_model_id IN (
                                            SELECT --+ CARDINALITY(eqm 20)
                                                   COLUMN_VALUE
                                              FROM TABLE
                                                      (CAST
                                                          (pkg_equipment.g_tab_model_id AS ct_number)
                                                      ) eqm)
                                      OR 0 = l_cnt_eqm
                                     )
                                 AND ROWNUM = 1)) d,
                   stock si,
                   stock so,
                   users us
             WHERE d.stock_in_id = si.ID(+) AND d.stock_out_id = so.ID(+)
                   AND UPPER (d.last_user) = UPPER (us.user_name(+));
      --Точно задан отправитель и\или получатель(для неизвестного склада при
      --списании\приходовании оборудования в входном массиве передается 0).
      --Неучитывает перемещение если задан только один из складов тк неизвестен другой
      ELSE
         --Заполним коллекцию идентификаторов складов отправителей и получателей
         pkg_stock.set_stockid (p_stock_id_out        => p_stock_out,
                                p_flag_clear_out      => 'Y',
                                p_stock_id_in         => p_stock_in,
                                p_flag_clear_in       => 'Y'
                               );

         OPEN p_doc_header_rec FOR
            SELECT --+ NO_MERGE(d)
                   d.ID, d.user_id, d.create_date, d.doc_date, d.doc_type_id, d.doc_no, d.status_id,
                   d.vendor_doc, so.code AS stock_code_out, so.NAME AS stock_name_out,
                   si.code AS stock_code_in, si.NAME AS stock_name_in, d.valid_until, d.description,
                   d.user_comment, d.last_user, d.vendor_id,
                   DECODE (d.doc_no, '', 0, (SELECT --+ INDEX(dh2 DOC_HEADER_UC_ID)
                                                    COUNT (dh2.user_comment)
                                               FROM doc_header dh2
                                              WHERE dh2.user_comment = d.doc_no)) AS link_doc,
                   (us.NAME || ' ' || us.surname) AS last_user_name
              FROM (SELECT --+ PUSH_SUBQ INDEX(dh IDX_DOCHEADER_SO_DD_DMO)
                           dh.ID, dh.user_id, dh.create_date, dh.doc_date, dh.doc_type_id,
                           dh.doc_no, dh.status_id, dh.vendor_doc, dh.stock_out_id, dh.stock_in_id,
                           dh.valid_until, dh.description, dh.user_comment, dh.last_user, dh.vendor_id
                      FROM doc_header dh
                     WHERE dh.doc_date BETWEEN p_date_from AND p_date_to
                       AND dh.stock_out_id IN (
                                         SELECT --+ CARDINALITY(stko 10)
                                                COLUMN_VALUE
                                           FROM TABLE (CAST (pkg_stock.g_tab_id_out AS ct_number)) stko)
                       AND dh.stock_in_id IN (
                                          SELECT --+ CARDINALITY(stki 15)
                                                 COLUMN_VALUE
                                            FROM TABLE (CAST (pkg_stock.g_tab_id_in AS ct_number)) stki)
                       AND dh.doc_type_id IN (
                                           SELECT --+ CARDINALITY(dtp 5)
                                                  COLUMN_VALUE
                                             FROM TABLE (CAST (PKG_DOC.g_tab_type_id AS ct_number)) dtp)
                       --вместо EXISTS можно AND 0 = ( SELECT COUNT(*) FROM doc_detail dd ...
                       AND EXISTS (
                              SELECT --+ FIRST_ROWS
                                     NULL
                                FROM doc_detail dd
                               WHERE dh.ID = dd.doc_header_id
                                 AND (   dd.equipment_model_id IN (
                                            SELECT --+ CARDINALITY(eqm 20)
                                                   COLUMN_VALUE
                                              FROM TABLE
                                                      (CAST
                                                          (pkg_equipment.g_tab_model_id AS ct_number)
                                                      ) eqm)
                                      OR 0 = l_cnt_eqm
                                     )
                                 AND ROWNUM = 1)) d
                   LEFT OUTER JOIN
                   stock si ON d.stock_in_id = si.ID
                   LEFT OUTER JOIN stock so ON d.stock_out_id = so.ID
                   LEFT OUTER JOIN users us ON UPPER (us.user_name) = UPPER (d.last_user)
                   ;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END search;

----------------------------------!---------------------------------------------
   PROCEDURE set_typeid (
      p_type_id      IN   pkg_common.t_num DEFAULT pkg_common.empty_t_num,
      p_flag_clear   IN   CHAR DEFAULT 'Y'
   )
   IS
      prc_name   CONSTANT NVARCHAR2 (100) := pkg_name || 'set_typeid';
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      IF (p_flag_clear = 'Y') OR (g_tab_type_id IS NULL)
      THEN
         --Чистим коллекцию идетификаторов
         g_tab_type_id := pkg_common.g_tab_empty_num;
      END IF;

      IF (p_type_id.COUNT = 1 AND p_type_id(p_type_id.FIRST) is NULL) OR
         (NOT (p_type_id.EXISTS (1))) OR (p_type_id (1) = util_stock.c_not_exists_num)
      THEN
         --Если ассоциативный массив пустой или указан флаг всех идентификаторов то "все типы"
         SELECT id
         BULK COLLECT INTO g_tab_type_id
           FROM doc_type;
         --g_tab_type_id := pkg_common.g_tab_empty_num;
      ELSE
         FOR i IN p_type_id.FIRST .. p_type_id.LAST
         LOOP
            g_tab_type_id.EXTEND;

            IF p_type_id.EXISTS (i)
            THEN
               g_tab_type_id (g_tab_type_id.COUNT) := p_type_id (i);
            ELSE
               g_tab_type_id (g_tab_type_id.COUNT) := NULL;
            END IF;
         END LOOP;
      END IF;

      pkg_db_util.DEBUG (prc_name, 'Count: ' || g_tab_type_id.COUNT, pkg_name);
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END set_typeid;

----------------------------------!---------------------------------------------
   FUNCTION sq_next_docnum (p_stock_id IN NUMBER, p_doc_type_id IN NUMBER, p_year IN NUMBER)
      RETURN NUMBER
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
      prc_name   CONSTANT NVARCHAR2 (100)        := pkg_name || 'sq_next_docnum';
      l_no                doc_number.NO%TYPE;
      l_check   number;
      --l_year              doc_number.YEAR%TYPE;
      --l_error_code        NUMBER;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);

      select count(*) into l_check from doc_number dn
          WHERE 1 = 1
            AND stock_id = p_stock_id
            AND doc_type_id = p_doc_type_id
            AND YEAR = p_year;

      if l_check = 0
      then
        insert into doc_number dn
          (
            dn.stock_id,
            dn.doc_type_id,
            dn.no,
            dn.year
          )
          values
          (
            p_stock_id,
            p_doc_type_id,
            0,
            p_year
          );
      end if;

      --Получим номер
      UPDATE doc_number dn
        SET NO = NVL (NO, 0) + 1
          WHERE stock_id = p_stock_id AND doc_type_id = p_doc_type_id AND YEAR = p_year
      RETURNING NO
           INTO l_no;

      pkg_db_util.DEBUG (prc_name, TO_CHAR (l_no), pkg_name);
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
      COMMIT;
      RETURN l_no;
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);
         RAISE;
   END sq_next_docnum;

----------------------------------!---------------------------------------------
   PROCEDURE upd_docheader_status (
      p_id            IN       NUMBER,
      p_status_id     IN       NUMBER,
      p_user_id       IN       NVARCHAR2,
      p_handle_tran   IN       CHAR := 'Y',
      p_error_code    OUT      NUMBER
   )
   IS
      v_sp_name varchar2(30);
      prc_name   CONSTANT NVARCHAR2 (100)      := pkg_name || 'upd_docheader_status';
      --l_eqm_type_id       NUMBER;
      l_rowtype           doc_header%ROWTYPE;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || p_id
                         || ','
                         || p_status_id
                         || ','
                         || p_user_id
                         || ','
                         || p_handle_tran
                         || ')',
                         pkg_name
                        );
      --Установим код ошибки в ноль
      p_error_code := 0;

      IF p_handle_tran = 'S'
      THEN
         v_sp_name := util_sys_pkg.make_savepoint;
      END IF;

      IF p_status_id <> 0
      THEN

         l_rowtype := document_pkg.get_doc_header_by_id(p_id);

         IF l_rowtype.ID is null
         THEN
           RAISE NO_DATA_FOUND;
         END IF;

         ------------------------------
         --!_! INSIDE is document_pkg.Clear_tt_Doc_Detail_table for tt_doc_detail_serial and tt_doc_detail_non_serial
         ------------------------------
         document_pkg.Retrieve_Doc_Equipment(l_rowtype.ID);
         ------------------------------

         --Изменяем статус документа и дочерних документов (документов недостачи)
         UPDATE /*+ index(DOC_HEADER PK_DOC_HEADER)*/ doc_header
            SET status_id = p_status_id,
                last_user = p_user_id
          WHERE ID IN (SELECT /*+ index(dd I_USER_COMMENT)*/ ID
                         FROM doc_header
                        WHERE user_comment = l_rowtype.doc_no
                       UNION ALL
                       SELECT l_rowtype.ID
                         FROM dual);


         IF p_status_id = -1   --Изменяем документ
         --Меняем текущее состояние склада на начальное если требуется отменить
         --перемещение\приход или изменить открытый документ
         THEN
            --Удаляем оборудование с серийными номерами со склада получателя
            --указанные в любом из документов (основной,дочерний)
            DELETE/*+ ordered use_concat index(stock_state, IDX_STOCKSTATE_DHI)*/ FROM stock_state
                  WHERE doc_header_id IN (l_rowtype.ID, (SELECT --+ INDEX(doc_header DOC_HEADER_UC_ID)
                                                                ID
                                                           FROM doc_header
                                                          WHERE user_comment = l_rowtype.doc_no))
                    AND equipment_type_id IN (SELECT equipment_type_id
                                                FROM vw_equipment_type
                                               WHERE has_serial_number = 'Y')
                    AND stock_id = l_rowtype.stock_in_id;

            --Перемещаем обратно оборудование с серийными номерами изменяя
            --кол-во на складе и обнуляя кол-во зарезерверованного оборудование
            --указанные в любом из документов (основной,дочерний)
            UPDATE/*+ ordered use_concat index(stock_state, IDX_STOCKSTATE_DHI)*/ stock_state
               SET quantity_onstock = quantity_reserved,
                   quantity_reserved = 0
             WHERE doc_header_id IN (l_rowtype.ID, (SELECT --+ INDEX(doc_header DOC_HEADER_UC_ID)
                                                           ID
                                                      FROM doc_header
                                                     WHERE user_comment = l_rowtype.doc_no))
               AND stock_id = l_rowtype.stock_out_id
               AND l_rowtype.stock_out_id <> l_rowtype.stock_in_id
               AND equipment_type_id IN (SELECT equipment_type_id
                                           FROM vw_equipment_type
                                          WHERE has_serial_number = 'Y');

            --Если оборудованию не требуется серийный номер...
            FOR v_i IN
            (
              SELECT *
                FROM tt_doc_detail_non_serial
               WHERE 1 = 1
                 AND doc_header_id = l_rowtype.ID
            )
            LOOP
               --Удаляем оборудование со склада получателя, если оно только анонсировано
               DELETE      --+ INDEX(stock_state I_STOCK_STATE_EQM)
                      FROM stock_state
                     WHERE stock_id = l_rowtype.stock_in_id
                       AND equipment_model_id = v_i.equipment_model_id
                       AND (    quantity_onstock = 0
                            AND quantity_reserved = 0
                            AND quantity_announced = v_i.quantity
                          );

               --Уменьшаем анонсированное кол-во оборудования склада получателя
               UPDATE --+ INDEX(stock_state I_STOCK_STATE_EQM)
                      stock_state
                  SET quantity_announced = quantity_announced - v_i.quantity
                WHERE stock_id = l_rowtype.stock_in_id
                  AND equipment_model_id = v_i.equipment_model_id
                  AND (   quantity_onstock <> 0
                       OR quantity_reserved <> 0
                       OR quantity_announced <> v_i.quantity
                      );

               IF l_rowtype.stock_out_id = l_rowtype.stock_in_id
               THEN
                  --Перемещения для операция диссасемблинга(например: обеденение симок в пакеты)
                  UPDATE --+ INDEX(stock_state I_STOCK_STATE_EQM)
                         stock_state
                     SET quantity_reserved = quantity_reserved + v_i.quantity,
                         quantity_onstock = quantity_onstock - v_i.quantity
                   WHERE stock_id = l_rowtype.stock_out_id
                     AND equipment_model_id = v_i.equipment_model_id
                     AND (   quantity_onstock <> 0
                          OR quantity_reserved <> v_i.quantity
                          OR quantity_announced <> 0
                         );
               ELSE
                  --Вычисляем и зменяем кол-во текущего и зарезервированного
                  --оборудования на складах отправителях при любом наличии
                  UPDATE --+ INDEX(stock_state I_STOCK_STATE_EQM)
                         stock_state
                     SET quantity_reserved = quantity_reserved - v_i.quantity,
                         quantity_onstock = quantity_onstock + v_i.quantity
                   WHERE stock_id = l_rowtype.stock_out_id
                     AND equipment_model_id = v_i.equipment_model_id
                     AND (   quantity_onstock <> 0
                          OR quantity_reserved <> v_i.quantity
                          OR quantity_announced <> 0
                         );
               END IF;

               --Вычисляем и зменяем кол-во текущего и зарезервированного
               --оборудования на складе отправителе в начальное состояние
               UPDATE --+ INDEX(stock_state I_STOCK_STATE_EQM)
                      stock_state
                  SET quantity_reserved = 0,
                      quantity_onstock = v_i.quantity
                WHERE stock_id = l_rowtype.stock_out_id
                  AND equipment_model_id = v_i.equipment_model_id
                  AND (    quantity_onstock = 0
                       AND quantity_reserved = v_i.quantity
                       AND quantity_announced = 0
                      );

            END LOOP;
         ELSE   --Открываем\(закрываем ?)документ
            IF l_rowtype.doc_type_id <> 112   --Любой документ кроме инвентарицационых
            THEN
               UPDATE /*+ ordered use_concat index(stock_state, IDX_STOCKSTATE_DHI)*/ stock_state
                  SET quantity_onstock = quantity_announced,
                      quantity_reserved = 0,
                      quantity_announced = 0
                WHERE doc_header_id IN (l_rowtype.ID, (SELECT --+ INDEX(doc_header DOC_HEADER_UC_ID)
                                                              ID
                                                         FROM doc_header
                                                        WHERE user_comment = l_rowtype.doc_no))
                  AND stock_id = l_rowtype.stock_in_id
                  AND equipment_type_id IN (SELECT equipment_type_id
                                              FROM vw_equipment_type
                                             WHERE has_serial_number = 'Y');

               pkg_db_util.DEBUG (prc_name, 'updated ' || SQL%ROWCOUNT, pkg_name);

               --Если склад получатель не является складом отправителем...
               IF l_rowtype.stock_out_id <> l_rowtype.stock_in_id
               THEN
                  DELETE /*+ ordered use_concat index(stock_state, IDX_STOCKSTATE_DHI)*/ FROM stock_state
                        WHERE stock_id = l_rowtype.stock_out_id
                          AND doc_header_id IN
                                            (l_rowtype.ID, (SELECT --+ INDEX(doc_header DOC_HEADER_UC_ID)
                                                                   ID
                                                              FROM doc_header
                                                             WHERE user_comment = l_rowtype.doc_no))
                          AND equipment_type_id IN (SELECT equipment_type_id
                                                      FROM vw_equipment_type
                                                     WHERE has_serial_number = 'Y');

                  pkg_db_util.DEBUG (prc_name, 'deleted ' || SQL%ROWCOUNT, pkg_name);

               END IF;

               --Если оборудованию не требуется серийный номер...
               FOR v_i IN
               (
                 SELECT *
                   FROM tt_doc_detail_non_serial
                  WHERE 1 = 1
                    AND doc_header_id = l_rowtype.ID
               )
               LOOP

                  UPDATE --+ INDEX(stock_state I_STOCK_STATE_EQM)
                         stock_state
                     SET quantity_onstock = quantity_onstock + v_i.quantity,
                         quantity_announced = quantity_announced - v_i.quantity
                   WHERE stock_id = l_rowtype.stock_in_id
                     AND equipment_model_id = v_i.equipment_model_id;

                  IF l_rowtype.stock_out_id = l_rowtype.stock_in_id
                  THEN
                     --
                     UPDATE --+ INDEX(stock_state I_STOCK_STATE_EQM)
                            stock_state
                        SET quantity_reserved = quantity_reserved + v_i.quantity
                      WHERE stock_id = l_rowtype.stock_out_id
                        AND equipment_model_id = v_i.equipment_model_id
                        AND (   quantity_onstock <> 0
                             OR quantity_announced <> 0
                             OR quantity_reserved <> v_i.quantity
                            );
                  ELSE
                     --
                     UPDATE --+ INDEX(stock_state I_STOCK_STATE_EQM)
                            stock_state
                        SET quantity_reserved = quantity_reserved - v_i.quantity
                      WHERE stock_id = l_rowtype.stock_out_id
                        AND equipment_model_id = v_i.equipment_model_id
                        AND (   quantity_onstock <> 0
                             OR quantity_announced <> 0
                             OR quantity_reserved <> v_i.quantity
                            );
                  END IF;

                  --
                  DELETE --+ INDEX(stock_state I_STOCK_STATE_EQM)
                         FROM stock_state
                        WHERE stock_id = l_rowtype.stock_out_id
                          AND equipment_model_id = v_i.equipment_model_id
                          AND (    quantity_onstock = 0
                               AND quantity_announced = 0
                               AND quantity_reserved = v_i.quantity
                              );

               END LOOP;
            ELSE   --Инвентарицационный документ
               --Credit
               UPDATE /*+ ordered use_concat index(stock_state, IDX_STOCKSTATE_DHI)*/ stock_state
                  SET quantity_onstock = quantity_announced,
                      quantity_reserved = 0,
                      quantity_announced = 0
                WHERE (doc_header_id IN (
                                         SELECT ID
                                           FROM doc_header
                                          WHERE user_comment = l_rowtype.doc_no
                                                AND doc_type_id = 106)
                      )
                  AND stock_id = l_rowtype.stock_in_id;

               --Debit
               UPDATE /*+ ordered use_concat index(stock_state, IDX_STOCKSTATE_DHI)*/ stock_state
                  SET quantity_onstock = quantity_onstock,
                      quantity_reserved = 0,
                      quantity_announced = 0
                WHERE (doc_header_id IN (
                                         SELECT ID
                                           FROM doc_header
                                          WHERE user_comment = l_rowtype.doc_no
                                                AND doc_type_id = 107)
                      )
                  AND stock_id = l_rowtype.stock_out_id;

            END IF;
         END IF;

         -- Update link fields
         UPDATE /*+ ordered use_concat index(stock_state, IDX_STOCKSTATE_DHI)*/stock_state
            SET doc_header_id = NULL
          WHERE doc_header_id = l_rowtype.ID;

         UPDATE/*+ ordered use_concat index(stock_state, IDX_STOCKSTATE_DHI)*/ stock_state
            SET doc_header_id = NULL
          -- было 0
         WHERE  doc_header_id IN (SELECT ID
                                    FROM doc_header
                                   WHERE user_comment = l_rowtype.doc_no);
      END IF;

      IF p_error_code <> 0
      THEN
         ROLLBACK;
      ELSE
         IF p_handle_tran = 'Y'
         THEN
            COMMIT;
         END IF;
      END IF;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         p_error_code := SQLCODE;
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM, pkg_name);

         CASE p_handle_tran
            WHEN 'S'
            THEN
              util_sys_pkg.rollback_savepoint(v_sp_name);
            WHEN 'Y'
            THEN
               ROLLBACK;
            ELSE
               NULL;
         END CASE;

         RAISE;
   END upd_docheader_status;

----------------------------------!---------------------------------------------

END;
/
