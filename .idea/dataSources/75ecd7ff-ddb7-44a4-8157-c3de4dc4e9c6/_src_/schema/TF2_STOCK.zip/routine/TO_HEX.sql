CREATE FUNCTION             "TO_HEX" (SN IN VARCHAR)
RETURN NUMBER
as
dummy number;
begin
  dummy := to_number(SN, 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');
  return dummy;
  exception
  when others then
  return null;
end;



/
