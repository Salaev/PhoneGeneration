CREATE PROCEDURE             "SP_WHO_CALLED_ME" (
   owner      OUT   VARCHAR2,
   NAME       OUT   VARCHAR2,
   lineno     OUT   NUMBER,
   caller_t   OUT   VARCHAR2
)
AS
   call_stack    VARCHAR2 (4096) DEFAULT DBMS_UTILITY.format_call_stack;
   n             NUMBER;
   found_stack   BOOLEAN         DEFAULT FALSE;
   line          VARCHAR2 (255);
   cnt           NUMBER          := 0;
BEGIN
   LOOP
      n := INSTR (call_stack, CHR (10));
      EXIT WHEN (cnt = 3 OR n IS NULL OR n = 0);
      line := SUBSTR (call_stack, 1, n - 1);
      call_stack := SUBSTR (call_stack, n + 1);

      IF (NOT found_stack)
      THEN
         IF (line LIKE '%handle%number%name%')
         THEN
            found_stack := TRUE;
         END IF;
      ELSE
         cnt := cnt + 1;

         -- cnt = 1 is ME
         -- cnt = 2 is MY Caller
         -- cnt = 3 is Their Caller
         IF (cnt = 3)
         THEN
            lineno := TO_NUMBER (SUBSTR (line, 13, 6));
            line := SUBSTR (line, 21);

            IF (line LIKE 'pr%')
            THEN
               n := LENGTH ('procedure ');
            ELSIF (line LIKE 'fun%')
            THEN
               n := LENGTH ('function ');
            ELSIF (line LIKE 'package body%')
            THEN
               n := LENGTH ('package body ');
            ELSIF (line LIKE 'pack%')
            THEN
               n := LENGTH ('package ');
            ELSIF (line LIKE 'anonymous%')
            THEN
               n := LENGTH ('anonymous block ');
            ELSE
               n := NULL;
            END IF;

            IF (n IS NOT NULL)
            THEN
               caller_t := LTRIM (RTRIM (UPPER (SUBSTR (line, 1, n - 1))));
            ELSE
               caller_t := 'TRIGGER';
            END IF;

            line := SUBSTR (line, NVL (n, 1));
            n := INSTR (line, '.');
            owner := LTRIM (RTRIM (SUBSTR (line, 1, n - 1)));
            NAME := LTRIM (RTRIM (SUBSTR (line, n + 1)));
         END IF;
      END IF;
   END LOOP;
END;

/
