CREATE PROCEDURE get_keo_logistic_on_period_nv(p_from_date              IN       DATE,            --начальная дата
                                                          p_to_date                IN       DATE,            --конечная дата
                                                          p_stock_from_code_list   IN       LONG,            --склады-отправители
                                                          p_stock_to_code_list     IN       LONG,            --склады-получатели
                                                          p_equipment_code_list    IN       LONG,            --перечисления оборудования через разделитель (,)
                                                          p_cur_start_saldo        OUT      sys_refcursor,   --начальное сальдо
                                                          p_cur_sold               OUT      sys_refcursor,   --продано
                                                          p_cur_activated          OUT      sys_refcursor,   --активировано
                                                          p_cur_returned           OUT      sys_refcursor,   --возвращено
                                                          p_cur_expired            OUT      sys_refcursor,   --просрочено
                                                          p_cur_end_saldo          OUT      sys_refcursor,   --конечное сальдо
                                                          p_cur_stock              OUT      sys_refcursor,   --группы складов
                                                          p_delimiter              IN       VARCHAR2 DEFAULT ',')
   IS

      prc_name               CONSTANT NVARCHAR2 (100)  := 'get_keo_logistic_on_period'; --pkg_name ||

      l_eqmmodelid_tab       pkg_common.t_num;   --числовая коллекция идентификаторов оборудования
      v_cur_state            sys_refcursor;
   BEGIN
      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_start);--, pkg_name);
      pkg_db_util.DEBUG (prc_name,
                            '('
                         || TO_CHAR (p_from_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || TO_CHAR (p_to_date, 'dd.mm.yyyy')
                         || pkg_constants.c_delimiter
                         || p_stock_from_code_list
                         || pkg_constants.c_delimiter
                         || p_stock_to_code_list
                         || pkg_constants.c_delimiter
                         || p_equipment_code_list
                         || ')'
                        --, pkg_name
                        );

      --Движение оборудование по документам до начальной даты
      DELETE FROM tmp_ss1;

      pkg_out_stock.get_stock_state_on_date(p_date => p_from_date,
                                            p_group_stock_id_list => null,
                                            p_stock_code_list => p_stock_to_code_list,
                                            p_equipment_code_list => p_equipment_code_list,
                                            p_cur_state => v_cur_state,
                                            p_is_detailed => 1);

      --Парсим списки кодов складов, ищем их Id и помещаем в соотв. коллекции
      pkg_stock.set_stockid(p_stock_id_out => pkg_out_stock.stockidtab_by_stockparamlist(p_stock_code_list => p_stock_from_code_list,
                                                                                         p_group_stock_id_list => NULL,
                                                                                         p_delimiter => p_delimiter),
                            p_stock_id_in  => pkg_out_stock.stockidtab_by_stockparamlist(p_stock_code_list => p_stock_to_code_list,
                                                                                         p_group_stock_id_list => NULL,
                                                                                         p_delimiter => p_delimiter)
                           );

      --Все(отправители и получатели) указанные склады
      OPEN p_cur_stock FOR
         SELECT ID, NAME
           FROM stock,
                (SELECT --+ CARDINALITY(stk_all 2)
                        COLUMN_VALUE as stock_id
                   FROM TABLE(CAST(SET(pkg_stock.g_tab_id_out MULTISET UNION pkg_stock.g_tab_id_in)  AS ct_number))stk_all
                )
        WHERE 1=1
          AND id = stock_id;      
              
      --Если список идентификаторов кодов оборудования есть то...
      IF p_equipment_code_list IS NOT NULL
      THEN
         --Получим коллекцию идентификаторов оборудования по коду
         l_eqmmodelid_tab := pkg_out_stock.eqmidtab_by_eqmcodelist(p_equipment_code_list      => p_equipment_code_list);
         --Заполним коллекцию идентификаторов оборудования...
         pkg_equipment.set_modelid (p_model_id_1 => l_eqmmodelid_tab);
      --Если список идентификаторов кодов оборудования нет то...
      ELSE
         raise_application_error (-20001, 'Is not set parameters equipment model code list');
      END IF;

      --Начальное сальдо
      pkg_db_util.DEBUG (prc_name, 'Start saldo...');--, pkg_name);

      OPEN p_cur_start_saldo FOR
          SELECT  /*+MONITOR */
                  et.equipment_type_code, et.equipment_type_name, em.equipment_model_code,
                  em.equipment_model_name, SUM (t.quantity_onstock) AS "QUANTITY"
             FROM tmp_ss1 t, equipment_model em, equipment_type et
            WHERE t.equipment_model_id = em.equipment_model_id
              AND em.equipment_type_id = et.equipment_type_id
         GROUP BY et.equipment_type_code,
                  et.equipment_type_name,
                  em.equipment_model_code,
                  em.equipment_model_name;

      --Проданные
      pkg_db_util.DEBUG (prc_name, 'Sold...');--, pkg_name);

      OPEN p_cur_sold FOR
         SELECT /*+MONITOR */
                et.equipment_type_code, et.equipment_type_name, em.equipment_model_code,
                em.equipment_model_name, so.code AS "OUT_STOCK_CODE", so.NAME AS "OUT_STOCK_NAME",
                si.code AS "IN_STOCK_CODE", si.NAME AS "IN_STOCK_NAME", dh.doc_date AS create_date,
                dd.seria_start, dd.seria_end, dd.quantity
           FROM doc_header dh,
                doc_detail dd,
                equipment_model em,
                equipment_type et,
                stock so,
                stock si
          WHERE dh.stock_out_id IN (SELECT --+ CARDINALITY(stk 1)
                                           COLUMN_VALUE
                                      FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk)
            AND dh.stock_in_id IN (SELECT --+ CARDINALITY(stk2 1)
                                          COLUMN_VALUE
                                     FROM TABLE(CAST(pkg_stock.g_tab_id_out AS ct_number)) stk2)
            AND dh.doc_date BETWEEN p_from_date AND p_to_date
            AND dh.doc_type_id = 103
            AND dh.status_id = 1
            AND dh.ID = dd.doc_header_id
            AND dd.equipment_model_id IN (SELECT --+ CARDINALITY(eqm 2)
                                                 COLUMN_VALUE
                                            FROM TABLE(CAST(pkg_equipment.g_tab_model_id AS ct_number)) eqm)
            AND dd.equipment_model_id = em.equipment_model_id
            AND em.equipment_type_id = et.equipment_type_id
            AND et.equipment_type_id = 1
            AND dh.stock_out_id = so.ID
            AND dh.stock_in_id = si.ID;

      --Активированные
      pkg_db_util.DEBUG (prc_name, 'Activated...');--, pkg_name);

      OPEN p_cur_activated FOR
         SELECT /*+MONITOR */
                et.equipment_type_code, et.equipment_type_name, em.equipment_model_code,
                em.equipment_model_name, so.code AS "STOCK_CODE", so.NAME AS "STOCK_NAME",
                b.doc_date AS create_date, b.seria_start, b.seria_end, b.quantity
           FROM (SELECT --+ INDEX(dh IDX_DOCHEADER_SO_DD_DMO)
                        dh.ID, dh.doc_date, dh.stock_out_id, dd.equipment_model_id, dd.seria_start,
                        dd.seria_end, dd.quantity
                   FROM doc_header dh, doc_detail dd, equipment_model em
                  WHERE dh.stock_out_id IN(SELECT --+ CARDINALITY(stk 1)
                                                  COLUMN_VALUE
                                             FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk)
                    AND dh.doc_date BETWEEN p_from_date AND p_to_date
                    AND dh.doc_type_id = 102
                    AND dh.status_id = 1
                    AND em.equipment_type_id = 1
                    AND dh.ID = dd.doc_header_id
                    AND dd.equipment_model_id IN(SELECT --+ CARDINALITY(eqm 2)
                                                        COLUMN_VALUE
                                                   FROM TABLE(CAST(pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                    AND dd.equipment_model_id = em.equipment_model_id
                    -- вместо EXISTS можно AND 0 = ( SELECT COUNT(*) FROM (...
                    AND EXISTS (
                           SELECT *
                             FROM (SELECT edh.stock_in_id AS stock_id, edd.equipment_model_id,
                                          edd.seria_start, edd.seria_end
                                     FROM doc_header edh, doc_detail edd, equipment_model eem
                                    WHERE edh.stock_in_id IN(SELECT --+ CARDINALITY(stk 1)
                                                                     COLUMN_VALUE
                                                               FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk)
                                      AND edh.stock_out_id IN(SELECT --+ CARDINALITY(stk2 1)
                                                                     COLUMN_VALUE
                                                                FROM TABLE(CAST(pkg_stock.g_tab_id_out AS ct_number)) stk2)
                                      AND edh.doc_date BETWEEN p_from_date AND p_to_date
                                      AND edh.doc_type_id = 103
                                      AND edh.status_id = 1
                                      AND eem.equipment_type_id = 1
                                      AND edh.ID = edd.doc_header_id
                                      AND edd.equipment_model_id IN(SELECT --+ CARDINALITY(eqm 2)
                                                                           COLUMN_VALUE
                                                                      FROM TABLE(CAST(pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                                      AND edd.equipment_model_id = eem.equipment_model_id
                                   UNION ALL
                                   SELECT stock_id, equipment_model_id, seria_start, seria_end
                                     FROM tmp_ss1) a
                            WHERE dh.stock_out_id = a.stock_id
                              AND dd.equipment_model_id = a.equipment_model_id
                              AND dd.seria_start <= a.seria_end
                              AND dd.seria_end >= a.seria_start)) b,
                equipment_model em,
                equipment_type et,
                stock so
          WHERE b.equipment_model_id = em.equipment_model_id
            AND em.equipment_type_id = et.equipment_type_id
            AND b.stock_out_id = so.ID;

      --Возвращённые
      pkg_db_util.DEBUG (prc_name, 'Returned...');--, pkg_name);

      OPEN p_cur_returned FOR
         SELECT /*+MONITOR */
                et.equipment_type_code, et.equipment_type_name, em.equipment_model_code,
                em.equipment_model_name, so.code AS "OUT_STOCK_CODE", so.NAME AS "OUT_STOCK_NAME",
                si.code AS "IN_STOCK_CODE", si.NAME AS "IN_STOCK_NAME", dh.doc_date AS create_date,
                dd.seria_start, dd.seria_end, dd.quantity
           FROM doc_header dh,
                doc_detail dd,
                equipment_model em,
                equipment_type et,
                stock so,
                stock si
          WHERE dh.stock_out_id IN (SELECT --+ CARDINALITY(stk 1)
                                           COLUMN_VALUE
                                      FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk)
            AND dh.stock_in_id IN (SELECT --+ CARDINALITY(stk2 1)
                                          COLUMN_VALUE
                                     FROM TABLE(CAST(pkg_stock.g_tab_id_out AS ct_number)) stk2)
            AND dh.doc_date BETWEEN p_from_date AND p_to_date
            AND dh.doc_type_id = 103
            AND dh.status_id = 1
            AND dh.ID = dd.doc_header_id
            AND dd.equipment_model_id IN(SELECT --+ CARDINALITY(eqm 2)
                                                 COLUMN_VALUE
                                           FROM TABLE(CAST(pkg_equipment.g_tab_model_id AS ct_number)) eqm)
            AND dd.equipment_model_id = em.equipment_model_id
            AND em.equipment_type_id = et.equipment_type_id
            AND et.equipment_type_id = 1
            AND dh.stock_out_id = so.ID
            AND dh.stock_in_id = si.ID
            AND EXISTS(SELECT --+ ORDERED USE_NL(doc dtl)
                              NULL -- А есть ли Документ о поступлении оборудования со склада, на который возвращаем
                         FROM doc_header doc JOIN
                              doc_detail dtl ON(doc.id = dtl.doc_header_id)
                        WHERE 1=1
                          AND doc.stock_in_id = dh.stock_out_id
                          AND doc.stock_out_id = dh.stock_in_id
                          AND dd.seria_start between dtl.seria_start and dtl.seria_end
                          AND dd.seria_end between dtl.seria_start and dtl.seria_end 
                          AND dtl.equipment_model_id = dd.equipment_model_id
                      );

      --Движение оборудование по документам до конечной даты
      DELETE FROM tmp_ss3;

      INSERT INTO tmp_ss3(stock_id,
                          equipment_model_id,
                          seria_start,
                          seria_end,
                          quantity_onstock,
                          valid_until,
                          equipment_batch_id)
           SELECT /*+MONITOR */
                  b.stock_id,
                  b.equipment_model_id,
                  b.seria_start,
                  b.seria_end,
                  SUM (b.quantity),
                  MAX (b.valid_until),
                  b.equipment_batch_id
             FROM (SELECT a.stock_id,
                          a.equipment_model_id,
                          a.seria_start,
                          a.seria_end,
                          a.quantity,
                          a.valid_until,
                          a.equipment_batch_id
                     FROM (SELECT --+ CARDINALITY(em 13)
                                  d.stock_id,
                                  dd.equipment_model_id,
                                  dd.seria_start,
                                  dd.seria_end,
                                  DECODE (d.quantity_sign,
                                          -1, -dd.quantity,
                                          dd.quantity
                                         ) AS quantity,
                                  dd.valid_until,
                                  dd.equipment_batch_id
                             FROM equipment_model em,
                                  doc_detail dd,
                                  (SELECT --+ INDEX(dh IDX_DOCHEADER_SO_DD_DMO)
                                          dh.ID,
                                          dh.stock_out_id AS stock_id,
                                          -1 AS quantity_sign
                                     FROM doc_header dh
                                    WHERE dh.status_id = 1
                                      AND dh.doc_type_id IN (102, 103)
                                      AND dh.doc_date >= p_from_date
                                      AND dh.doc_date < p_to_date
                                      AND (   dh.stock_out_id < dh.stock_in_id
                                           OR dh.stock_out_id > dh.stock_in_id
                                          )
                                      AND dh.stock_out_id IN(SELECT --+ CARDINALITY(stk 1)
                                                                    COLUMN_VALUE
                                                               FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk) --!
                                      AND (   dh.stock_in_id = 0
                                           OR dh.stock_in_id IN(SELECT --+ CARDINALITY(stk2 1)
                                                                       COLUMN_VALUE
                                                                  FROM TABLE(CAST(pkg_stock.g_tab_id_out AS ct_number)) stk2) --!
                                          )
                                   UNION ALL
                                   SELECT --  USE_CONCAT INDEX(dh IDX_DOCHEADER_SI_DD_DMI) INDEX(dh IDX_DOCHEADER_SO_DD_DMO)
                                          dh.ID,
                                          dh.stock_in_id AS stock_id,
                                          1 AS quantity_sign
                                     FROM doc_header dh
                                    WHERE dh.status_id = 1
                                      AND dh.doc_type_id IN (102, 103, 104, 105, 109)
                                      AND dh.doc_date >= p_from_date
                                      AND dh.doc_date < p_to_date
                                      AND (dh.stock_out_id IN(SELECT --+ CARDINALITY(stk2 1)
                                                                     COLUMN_VALUE
                                                                FROM TABLE(CAST(pkg_stock.g_tab_id_out AS ct_number)) stk2)
                                           OR dh.stock_out_id = dh.stock_in_id
                                          )
                                      AND dh.stock_in_id IN (SELECT --+ CARDINALITY(stk 1)
                                                                    COLUMN_VALUE
                                                               FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk)
                                   UNION ALL
                                   SELECT dh.ID,
                                          dh.stock_in_id AS stock_id,
                                          1 AS quantity_sign
                                     FROM doc_header dh
                                    WHERE dh.status_id = 1
                                      AND dh.doc_type_id = 108
                                      AND dh.doc_date >= p_from_date
                                      AND dh.doc_date < p_to_date
                                      AND dh.stock_out_id IN(SELECT --+ CARDINALITY(stk 1)
                                                                    COLUMN_VALUE
                                                               FROM TABLE(CAST(pkg_stock.g_tab_id_in AS ct_number)) stk)
                                      AND EXISTS(
                                                 SELECT NULL
                                                   FROM doc_detail dd, doc_detail dd2, doc_header dh2
                                                  WHERE dd.doc_header_id = dh.ID
                                                    AND dh2.status_id = 1
                                                    AND dd.quantity < 0
                                                    --AND dd2.seria_start = dd.seria_start
                                                    --AND dd2.seria_end = dd.seria_end

                                                    AND dd.seria_start between dd2.seria_start and dd2.seria_end
                                                    AND dd.seria_end between dd2.seria_start and dd2.seria_end

                                                    AND dh2.ID = dd2.doc_header_id
                                                    AND dh2.stock_out_id IN(SELECT --+ CARDINALITY(stk2 1)
                                                                                   COLUMN_VALUE
                                                                              FROM TABLE(CAST(pkg_stock.g_tab_id_out AS ct_number)) stk2)
                                                    AND dh2.stock_in_id = dh.stock_in_id
                                                    AND dh2.doc_type_id = 103
                                                    AND dh2.doc_date > pkg_constants.c_minsysdate
                                                    AND dh2.doc_date < dh.doc_date)
                                  ) d
                            WHERE em.equipment_type_id = 1
                              AND dd.equipment_model_id IN(SELECT --+ CARDINALITY(eqm 2)
                                                                  COLUMN_VALUE
                                                             FROM TABLE(CAST(pkg_equipment.g_tab_model_id AS ct_number)) eqm)
                              AND dd.equipment_model_id = em.equipment_model_id
                              AND dd.doc_header_id = d.ID
                              AND 1=0
                              ) a
                   UNION ALL
                   SELECT stock_id,
                          equipment_model_id,
                          seria_start,
                          seria_end,
                          quantity_onstock,
                          valid_until,
                          equipment_batch_id
                     FROM tmp_ss1) b
         GROUP BY b.stock_id, b.equipment_model_id, b.seria_start, b.seria_end,
                  b.equipment_batch_id
           HAVING SUM (b.quantity) > 0
           ;

      --С истёкшим сроком годности
      pkg_db_util.DEBUG (prc_name, 'Expired...');--, pkg_name);

      OPEN p_cur_expired FOR
          SELECT  /*+MONITOR */
                  et.equipment_type_code, et.equipment_type_name, em.equipment_model_code,
                  em.equipment_model_name, st.code AS "STOCK_CODE", st.NAME AS "STOCK_NAME",
                  ts.valid_until AS "VALID_UNTIL", ts.seria_start AS "SERIA_START",
                  ts.seria_end AS "SERIA_END", SUM (ts.quantity_onstock) AS "QUANTITY"
             FROM tmp_ss3 ts, equipment_model em, equipment_type et, stock st
            WHERE ts.equipment_model_id = em.equipment_model_id
              AND em.equipment_type_id = et.equipment_type_id
              AND ts.stock_id = st.ID
              AND ts.valid_until >= p_from_date
              AND ts.valid_until < p_to_date
         GROUP BY ts.stock_id,
                  et.equipment_type_code,
                  et.equipment_type_name,
                  em.equipment_model_code,
                  em.equipment_model_name,
                  st.code,
                  st.NAME,
                  ts.valid_until,
                  ts.seria_start,
                  ts.seria_end,
                  ts.equipment_batch_id;

      --Конечное сальдо
      pkg_db_util.DEBUG (prc_name, 'End saldo...');--, pkg_name);

      OPEN p_cur_end_saldo FOR
          SELECT  /*+MONITOR */
                  et.equipment_type_code, et.equipment_type_name, em.equipment_model_code,
                  em.equipment_model_name, SUM (ts.quantity_onstock) AS "QUANTITY"
             FROM tmp_ss3 ts, equipment_model em, equipment_type et
            WHERE ts.equipment_model_id = em.equipment_model_id
              AND em.equipment_type_id = et.equipment_type_id
         GROUP BY et.equipment_type_code,
                  et.equipment_type_name,
                  em.equipment_model_code,
                  em.equipment_model_name;

      pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_end);--, pkg_name);
   EXCEPTION
      WHEN OTHERS
      THEN
         pkg_db_util.DEBUG (prc_name, pkg_constants.c_flag_err || ':' || SQLERRM);--, pkg_name);
         RAISE;
   END get_keo_logistic_on_period_nv;
/
