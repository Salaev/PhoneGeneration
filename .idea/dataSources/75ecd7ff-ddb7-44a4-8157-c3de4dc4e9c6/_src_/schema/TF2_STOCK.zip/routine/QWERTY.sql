CREATE function qwerty(p_dsc clob, p_result out varchar2) return varchar2
is
  v_res varchar2(32767);
  v_log_clob_type_id number := 12345;
  v_cnt number;
function get_tran_desc return varchar2
is
  v_res varchar2(32767);
begin
  ------------------------------
SELECT util_pkg.date_to_char(sysdate) || ';' || s.sid || ';' || s.serial# || ';' ||
  CASE BITAND(t.flag, POWER(2, 28))
    WHEN 0 THEN 'READ COMMITTED'
    ELSE 'SERIALIZABLE'
  END AS isolation_level
  into v_res
FROM v$transaction t, v$session s
WHERE t.addr = s.taddr
  AND s.sid = sys_context('userenv','sid')
  --!!!AND s.serial# = :serial
  ;
  ------------------------------
  return v_res;
  ------------------------------
exception
when no_data_found then
  ------------------------------
  return 'NONE';
  ------------------------------
end;
begin
  ------------------------------
  --!!!v_res := get_tran_desc;
  --!!!insert into log_clob(log_clob_id, log_clob_type_id, dt, dsc) values(sq_log_clob.nextval, v_log_clob_type_id, sysdate, p_dsc || ';' || v_res);
  ------------------------------
  --!!!util_pkg.XCheck_Cond_Missing(true, 'p_qwerty');
  ------------------------------
  insert into log_clob(log_clob_id, log_clob_type_id, dt, dsc)
  values(sq_log_clob.nextval, v_log_clob_type_id, sysdate, p_dsc || ';' || util_pkg.date_to_char(sysdate))
  returning dsc into p_result
  ;
  ------------------------------
  select count(1) into v_cnt from log_clob;
  ------------------------------
  --!!!util_pkg.XCheck_Cond_Missing(v_cnt >= 105, 'p_qwerty');
  ------------------------------
  v_res := util_pkg.number_to_char(v_cnt) || ';' || get_tran_desc;
  ------------------------------
  dbms_lock.sleep(1);
  ------------------------------
  return v_res;
  ------------------------------
end;
/
