CREATE TRIGGER TRG_STOCK_STATE_BIU_R
BEFORE INSERT OR UPDATE
  ON STOCK_STATE
FOR EACH ROW
  DECLARE
   b_check  BOOLEAN;
BEGIN
  if (equipment_pkg.v_use_stock_state_trigger = pkg_constants.c_trigger_on) then
   b_check := :NEW.is_nonsingle_series IS NULL OR :NEW.is_nonsingle_series != -1;
   
   IF (:NEW.seria_start <> :NEW.seria_end)
   THEN
      :NEW.is_nonsingle_series := 1;
   ELSE 
      :NEW.is_nonsingle_series := NULL;
   END IF;

   IF INSERTING
   THEN
      IF b_check THEN
        --Получим тип оборудования по модели
        :NEW.EQUIPMENT_TYPE_ID := pkg_equipment.get_typeid_by_modelid (:NEW.EQUIPMENT_MODEL_ID);

      --Если серийный номер необходим для оборудования то проверяем пересечения диапозонов
      IF pkg_equipment.chk_availability_sn (:NEW.EQUIPMENT_TYPE_ID)
      THEN
         --Проверяем пересечение серий оборудования
         IF pkg_equipment.chk_cross_series_all (:NEW.seria_start,
                                                :NEW.seria_end,
                                                :NEW.doc_header_id
                                               )
         THEN
            raise_application_error (-20001, 'Series overlap');
         END IF;
      END IF;
      END IF;

      --Получим идентификатор новой записи
      SELECT s_stock_state.NEXTVAL
        INTO :NEW.ID
        FROM DUAL;
   END IF;
  end if;
END;
/
