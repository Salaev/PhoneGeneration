CREATE TRIGGER TRG_DOC_DETAIL_BI_R
BEFORE INSERT
  ON DOC_DETAIL
FOR EACH ROW
  BEGIN
  if (document_pkg.v_use_doc_detail_trigger = pkg_constants.c_trigger_on) then
   SELECT S_DOC_DETAIL.NEXTVAL
     INTO :NEW.ID
     FROM DUAL;
  end if;
END;
/
