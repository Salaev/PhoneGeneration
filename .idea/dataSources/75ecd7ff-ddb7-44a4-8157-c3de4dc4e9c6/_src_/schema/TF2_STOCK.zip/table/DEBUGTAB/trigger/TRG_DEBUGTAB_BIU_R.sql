CREATE TRIGGER TRG_DEBUGTAB_BIU_R
BEFORE INSERT OR UPDATE
  ON DEBUGTAB
FOR EACH ROW
  BEGIN
   :NEW.modules := UPPER (:NEW.modules);
   :NEW.show_date := UPPER (:NEW.show_date);
   :NEW.session_id := UPPER (:NEW.session_id);
   :NEW.userid := UPPER (:NEW.userid);

   DECLARE
      l_date   VARCHAR2 (100);
   BEGIN
      l_date := TO_CHAR (SYSDATE, :NEW.DATE_FORMAT);
   EXCEPTION
      WHEN OTHERS
      THEN
         raise_application_error (-20001, 'Invalid Date Format In Debug Date Format');
   END;

   DECLARE
      l_handle   UTL_FILE.file_type;
   BEGIN
      l_handle :=
         UTL_FILE.fopen (LOCATION          => :NEW.dir,
                         filename          => :NEW.filename,
                         open_mode         => 'a',
                         max_linesize      => 32767
                        );
      UTL_FILE.fclose (l_handle);
   EXCEPTION
      WHEN OTHERS
      THEN
         raise_application_error (-20001,
                                  'Cannot open debug dir file ' || :NEW.dir || ' ' || :NEW.filename
                                 );
   END;
END;
/
