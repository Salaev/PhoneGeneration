CREATE TRIGGER TRG_DOC_HEADER_BU_R
BEFORE UPDATE
  ON DOC_HEADER
FOR EACH ROW
  BEGIN
  if (document_pkg.v_use_doc_header_trigger = pkg_constants.c_trigger_on) then
    IF :NEW.status_id <> 0 AND :OLD.status_id = 0
    THEN
      :NEW.valid_until := NULL;
    END IF;
  end if;
END;
/
