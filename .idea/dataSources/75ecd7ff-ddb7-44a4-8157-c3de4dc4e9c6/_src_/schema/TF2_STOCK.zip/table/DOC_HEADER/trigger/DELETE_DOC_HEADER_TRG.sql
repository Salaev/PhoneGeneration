CREATE TRIGGER DELETE_DOC_HEADER_TRG
BEFORE DELETE
  ON DOC_HEADER
FOR EACH ROW
  BEGIN
  if (document_pkg.v_use_doc_header_trigger = pkg_constants.c_trigger_on) then
   DELETE FROM STOCK_STATE
   WHERE  STOCK_STATE.DOC_HEADER_ID= :OLD.ID;
  end if;
END;
/
