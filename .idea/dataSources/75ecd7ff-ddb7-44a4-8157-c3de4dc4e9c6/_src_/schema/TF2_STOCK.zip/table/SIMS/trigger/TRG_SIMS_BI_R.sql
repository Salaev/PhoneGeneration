CREATE TRIGGER TRG_SIMS_BI_R
BEFORE INSERT
  ON SIMS
FOR EACH ROW
  BEGIN
  if (equipment_pkg.v_use_sims_trigger = pkg_constants.c_trigger_on) then
   SELECT S_SIMS.NEXTVAL
     INTO :NEW.ID
     FROM DUAL;
  end if;
END;
/
